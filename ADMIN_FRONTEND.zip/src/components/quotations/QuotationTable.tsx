import {
    ClipboardText,
    EyeIcon,
    PencilIcon,
    TrashIcon,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";

import type { Quotation, QuotationStatus } from "../../types/quotation";
import { VENDORS } from "../../data/vendors";
import DataTable, {
    DataTableColumn,
} from "../DataTable";

interface QuotationTableProps {
    quotations?: Quotation[];
    onView?: (quotation: Quotation) => void;
}

const getVendorName = (vendorValue: string): string => {
    if (!vendorValue) {
        return "Unknown Vendor";
    }

    const searchValue = vendorValue.trim().toLowerCase();

    const vendor = VENDORS.find((item) => {
        const vendorId = item.id.toLowerCase();
        const vendorName = item.name.toLowerCase();

        return (
            vendorId === searchValue ||
            vendorName === searchValue ||
            vendorName.includes(searchValue) ||
            searchValue.includes(vendorName)
        );
    });

    return vendor?.name ?? "Vendor not found";
};

const getDummyQuotations = (): Quotation[] => {
    return [
        {
            id: "qt-001",
            quotationNo: "QT-2026-001",
            vendor: "vendor-001",
            vendorName: "Seiretsu JA Ltd",
            projectTitle: "Al Noor Commercial Tower",
            date: "2026-08-18",
            grandTotal: 485000.00,
            currency: "AED",
            margin: 18.5,
            status: "Issued",
            category: "Commercial",
            items: 9,
            progress: 50,
            validUntil: "2026-09-18",
            createdDate: "2026-08-18",
            clientName: "Seiretsu JA Ltd",
            formTemplate: ""
        },
        {
            id: "qt-002",
            quotationNo: "QT-2026-002",
            vendor: "vendor-002",
            vendorName: "Flow Jamaica (C&W Cable & Wireless)",
            projectTitle: "Marina Residence Development",
            date: "2026-08-16",
            grandTotal: 325000.00,
            currency: "AED",
            margin: 22.4,
            status: "Awarded",
            category: "Residential",
            items: 8,
            progress: 100,
            validUntil: "2026-09-16",
            createdDate: "2026-08-16",
            clientName: "Flow Jamaica",
            formTemplate: ""
        },
        {
            id: "qt-003",
            quotationNo: "QT-2026-003",
            vendor: "vendor-004",
            vendorName: "City Council - Kingston & St. Andrew Corporation",
            projectTitle: "Downtown Office Renovation",
            date: "2026-08-14",
            grandTotal: 178500.00,
            currency: "USD",
            margin: 14.8,
            status: "Not Responded",
            category: "Infrastructure",
            items: 10,
            progress: 0,
            validUntil: "2026-09-14",
            createdDate: "2026-08-14",
            clientName: "City Council - Kingston & St. Andrew Corporation",
            formTemplate: ""
        },
        {
            id: "qt-004",
            quotationNo: "QT-2026-004",
            vendor: "vendor-003",
            vendorName: "Digicel Metro Networks",
            projectTitle: "Palm Heights Electrical Works",
            date: "2026-08-12",
            grandTotal: 142750.00,
            currency: "AED",
            margin: 9.5,
            status: "Draft",
            category: "Electrical",
            items: 7,
            progress: 0,
            validUntil: "2026-09-12",
            createdDate: "2026-08-12",
            clientName: "Digicel Metro Networks",
            formTemplate: ""
        },

        
    ];
};

const statusClasses: Record<QuotationStatus, string> = {
    "Form Issued": "bg-blue-50 text-blue-700",
    "Form Submitted": "bg-amber-50 text-amber-700",
    "Form Approved": "bg-emerald-50 text-emerald-700",
    "Form Rejected": "bg-red-50 text-red-700",

    Issued: "bg-blue-50 text-blue-700",
    Draft: "bg-slate-100 text-slate-600",
    Submitted: "bg-amber-50 text-amber-700",
    Awarded: "bg-emerald-50 text-emerald-700",
    "Not Responded": "bg-red-100 text-red-600",
    Rejected: "bg-red-50 text-red-700",
};


const QuotationTable = ({ 
    quotations: quotationsProp,
    onView,
}: QuotationTableProps) => {
    const navigate = useNavigate();

    const [quotations, setQuotations] = useState<Quotation[]>([]);
    const [hoveredQuotationId, setHoveredQuotationId] = useState<
        string | null
    >(null);

    const loadQuotations = () => {
        if (quotationsProp) {
            setQuotations(quotationsProp);
            return;
        }

        setQuotations(getDummyQuotations());
    };

    useEffect(() => {
        loadQuotations();

        const handleStorageChange = (event: StorageEvent) => {
            if (event.key === "quotations") {
                loadQuotations();
            }
        };

        const handleFocus = () => {
            loadQuotations();
        };

        window.addEventListener("storage", handleStorageChange);
        window.addEventListener("focus", handleFocus);

        return () => {
            window.removeEventListener("storage", handleStorageChange);
            window.removeEventListener("focus", handleFocus);
        };
    }, [quotationsProp]);

    const handleDeleteQuotation = (id: string) => {
        if (!confirm("Are you sure you want to delete this quotation?")) {
            return;
        }

        try {
            const existingQuotations: Quotation[] = JSON.parse(
                localStorage.getItem("quotations") || "[]"
            );

            const updatedQuotations = existingQuotations.filter(
                (quotation) => quotation.id !== id
            );

            localStorage.setItem(
                "quotations",
                JSON.stringify(updatedQuotations)
            );

            setQuotations((previous) =>
                previous.filter((quotation) => quotation.id !== id)
            );

            setHoveredQuotationId(null);

            window.dispatchEvent(
                new StorageEvent("storage", {
                    key: "quotations",
                    newValue: JSON.stringify(updatedQuotations),
                })
            );
        } catch (error) {
            console.error("Error deleting quotation:", error);
            alert("Failed to delete quotation.");
        }
    };

    const handleEditQuotation = (quotation: Quotation) => {
        navigate("/quotation/edit_quotation", {
            state: {
                quotationId: quotation.id,
                editQuotation: quotation,
            },
        });
    };

    const handleView = (quotation: Quotation) => {
        if (onView) {
            onView(quotation);
            return;
        }

        navigate("/quotation/quotationdetails", {
            state: {
                quotation,
            },
        });
    };

    const columns: DataTableColumn<Quotation>[] = [
        {
            key: "quotationNo",
            label: "Quotation",
            width: "120px",
            sortable: true,
            align: "left",
            render: (quotation) => (
                <span className="block whitespace-nowrap text-xs font-bold text-slate-800 group-hover:text-red-600">
                    {quotation.quotationNo}
                </span>
            ),
        },
        {
            key: "vendor",
            label: "Vendor",
            width: "190px",
            sortable: true,
            align: "left",
            render: (quotation) => {
                const vendorName = getVendorName(
                    String(quotation.vendor)
                );

                return (
                    <span
                        title={vendorName}
                        className="block truncate text-xs font-medium text-slate-700"
                    >
                        {vendorName}
                    </span>
                );
            },
        },
        {
            key: "projectTitle",
            label: "Project Title",
            width: "240px",
            sortable: true,
            align: "left",
            render: (quotation) => (
                <span
                    title={quotation.projectTitle}
                    className="block truncate text-xs font-semibold text-slate-800"
                >
                    {quotation.projectTitle}
                </span>
            ),
        },
        {
            key: "date",
            label: "Due Date",
            width: "110px",
            sortable: true,
            align: "center",
            render: (quotation) => (
                <span className="block whitespace-nowrap text-xs text-slate-600">
                    {quotation.date}
                </span>
            ),
        },
        {
            key: "grandTotal",
            label: "Grand Total",
            width: "145px",
            sortable: true,
            align: "right",
            render: (quotation) => (
                <span className="block whitespace-nowrap text-xs font-bold text-slate-800">
                    {quotation.currency}{" "}
                    {Number(quotation.grandTotal).toLocaleString(
                        "en-US",
                        {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                        }
                    )}
                </span>
            ),
        },

        {
            key: "status",
            label: "Status",
            width: "135px",
            sortable: true,
            align: "center",
            render: (quotation) => (
                <span
                    className={`inline-flex min-w-[90px] items-center justify-center whitespace-nowrap rounded-full px-2.5 py-1 text-[9px] font-bold ${statusClasses[quotation.status]}`}
                >
                    {quotation.status}
                </span>
            ),
        },
        {
            key: "action",
            label: "Action",
            width: "150px",
            align: "center",
            render: (quotation) => {
                const canEdit =
                    quotation.status === "Draft" || quotation.status === "Issued" || quotation.status === "Form Approved"  ;

                const isHovered =
                    hoveredQuotationId === quotation.id;

                return (
                    <div
                        className="flex min-h-8 items-center justify-center gap-1"
                        onMouseEnter={() =>
                            setHoveredQuotationId(quotation.id)
                        }
                        onMouseLeave={() =>
                            setHoveredQuotationId(null) 
                        }
                    >
                        <div
                            className={`flex items-center justify-center gap-1 transition-opacity duration-150 ${
                                isHovered
                                    ? "opacity-100"
                                    : "pointer-events-none opacity-0"
                            }`}
                        >
                            {canEdit && (
                                <button
                                    type="button"
                                    onClick={() =>
                                        handleEditQuotation(quotation)
                                    }
                                    title="Edit quotation"
                                    aria-label="Edit quotation"
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-blue-600 transition-colors hover:bg-blue-50 hover:text-blue-700"
                                >
                                    <PencilIcon
                                        size={16}
                                        weight="duotone"
                                    />
                                </button>
                            )}

                            {quotation.status === "Form Issued" && (
                                <button
                                    type="button"
                                    onClick={(event) => {
                                        event.stopPropagation();

                                        navigate("/quotation/survey-form", {
                                            state: {
                                                quotationId: quotation.id,
                                                quotation: quotation,
                                            },
                                        });
                                    }}
                                    title="Open survey form"
                                    aria-label="Open survey form"
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-emerald-600 transition-colors hover:bg-emerald-50 hover:text-emerald-700"
                                >
                                    <ClipboardText
                                        size={16}
                                        weight="duotone"
                                    />
                                </button>
                            )}


                            <button
                                type="button"
                                onClick={() =>
                                    handleView(quotation)
                                }
                                title="Review quotation"
                                aria-label="Review quotation"
                                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-red-600 transition-colors hover:bg-red-50 hover:text-red-700"
                            >
                                <EyeIcon
                                    size={18}
                                    weight="duotone"
                                />
                            </button>

                            <button
                                type="button"
                                onClick={() =>
                                    handleDeleteQuotation(
                                        quotation.id
                                    )
                                }
                                title="Delete quotation"
                                aria-label="Delete quotation"
                                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-red-500 transition-colors hover:bg-red-50 hover:text-red-600"
                            >
                                <TrashIcon
                                    size={16}
                                    weight="duotone"
                                />
                            </button>
                        </div>
                    </div>
                );
            },
        },
    ];

    return (
        <DataTable<Quotation>
            columns={columns}
            data={quotations}
            rowKey={(quotation) => quotation.id}
            emptyMessage="No quotations found."
            className="rounded-2xl"
        />
    );
};

export default QuotationTable;
