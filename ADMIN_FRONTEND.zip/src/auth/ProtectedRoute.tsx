import React, { PropsWithChildren } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "./AuthProvider";

interface ProtectedRouteProps extends PropsWithChildren {
    allowedUserTypes?: string[];
}

export default function ProtectedRoute({
    children,
    allowedUserTypes,
}: ProtectedRouteProps) {
    const { loading, isAuthenticated, user } = useAuth();
    const location = useLocation();

    if (loading) {
        return (
            <div className="flex min-h-screen items-center justify-center bg-[#F5F7FA]">
                <div className="rounded-xl bg-white px-5 py-4 text-sm font-medium text-slate-600 shadow-sm">
                    Checking your session…
                </div>
            </div>
        );
    }

    if (!isAuthenticated) {
        const returnUrl = `${location.pathname}${location.search}${location.hash}`;

        return (
            <Navigate
                to={`/?returnUrl=${encodeURIComponent(returnUrl)}`}
                replace
            />
        );
    }

    if (
        allowedUserTypes?.length &&
        !allowedUserTypes.includes(
            String(user?.userType || "").toLowerCase(),
        )
    ) {
        return <Navigate to="/" replace />;
    }

    if (
        String(user?.userType || "").toLowerCase() === "vendor" &&
        user?.vendorPortalOnboarding?.requiresTermsAcceptance === true &&
        location.pathname !== "/vendor_terms"
    ) {
        return <Navigate to="/vendor_terms" replace />;
    }

    return <>{children}</>;
}
