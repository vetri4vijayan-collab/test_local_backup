export type UserRole = "Super Admin" | "Project Manager" ;
export type UserStatus = "Active" | "Inactive";

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  hourlyrate: string;
  status: UserStatus;
  department:string;
  location:string;
  privileges:string[];
  imageUrl?: string | null;
  imageFile?: File | null;
  removeImage?: boolean;
}

export const ALL_ROLES: UserRole[] = ["Super Admin", "Project Manager"];

export const ALL_PRIVILEGES = [
  "View Dashboard",
  "Manage Projects",
  "Manage Vendors",
  "Manage Quotations",
  "Manage Invoices",
  "Manage Users",
  "Approve Quotations",
  "View Financials",
  "Edit Settings",
];
