import {
    useCallback,
    useEffect,
    useMemo,
    useState,
} from "react";
import {
    CalendarBlankIcon,
    CheckCircleIcon,
    PencilSimpleIcon,
    PlusIcon,
    SpinnerGapIcon,
    TrashIcon,
    WarningCircleIcon,
    XCircleIcon,
} from "@phosphor-icons/react";

import ToggleSwitch from "../../components/ToggleSwitch";
import DataTable, {
    DataTableColumn,
} from "../../components/DataTable";

import api from "../../api/axios";

export interface ValidityPeriod {
    id: string;
    name: string;
    description: string;
    status: boolean;
    sortOrder?: number;
    createdAt?: string | null;
    updatedAt?: string | null;
}

interface ValidityPeriodFormData {
    name: string;
    description: string;
}

interface ValidityPeriodErrors {
    name?: string;
    description?: string;
}

interface ApiResponse<T = unknown> {
    success?: boolean;
    message?: string;
    data?: T;
    pagination?: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
}

interface DeleteResult {
    id: string;
    deleted: boolean;
}

const COMMON_ENDPOINT =
    "/settings/common";

const SETTING_TYPE =
    "validity_period";

const emptyForm: ValidityPeriodFormData = {
    name: "",
    description: "",
};

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getErrorMessage(
    error: unknown,
    fallback: string,
): string {
    const axiosError = error as {
        response?: {
            data?: {
                message?: string;
                error?: string;
            };
        };
        message?: string;
    };

    return (
        axiosError?.response?.data
            ?.message ||
        axiosError?.response?.data
            ?.error ||
        axiosError?.message ||
        fallback
    );
}

function normalizeValidityPeriod(
    value: unknown,
): ValidityPeriod | null {
    if (
        !value ||
        typeof value !==
            "object"
    ) {
        return null;
    }

    const item =
        value as Record<
            string,
            unknown
        >;

    const id =
        String(
            item.id ??
                item._id ??
                "",
        ).trim();

    if (!id) {
        return null;
    }

    return {
        id,

        name:
            String(
                item.name ??
                    "",
            ),

        description:
            String(
                item.description ??
                    "",
            ),

        status:
            Boolean(
                item.status,
            ),

        sortOrder:
            typeof item.sortOrder ===
            "number"
                ? item.sortOrder
                : undefined,

        createdAt:
            item.createdAt
                ? String(
                      item.createdAt,
                  )
                : null,

        updatedAt:
            item.updatedAt
                ? String(
                      item.updatedAt,
                  )
                : null,
    };
}

function extractValidityPeriods(
    response: ApiResponse<
        ValidityPeriod[]
    >,
): ValidityPeriod[] {
    const source =
        Array.isArray(
            response?.data,
        )
            ? response.data
            : [];

    return source
        .map(
            normalizeValidityPeriod,
        )
        .filter(
            (
                item,
            ): item is ValidityPeriod =>
                item !== null,
        );
}

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/

export default function ValidityPeriodSetting() {
    const [
        validityPeriods,
        setValidityPeriods,
    ] = useState<
        ValidityPeriod[]
    >([]);

    const [
        showForm,
        setShowForm,
    ] = useState(false);

    const [
        editingValidityPeriod,
        setEditingValidityPeriod,
    ] =
        useState<ValidityPeriod | null>(
            null,
        );

    const [
        formData,
        setFormData,
    ] =
        useState<ValidityPeriodFormData>(
            emptyForm,
        );

    const [
        deleteValidityPeriod,
        setDeleteValidityPeriod,
    ] =
        useState<ValidityPeriod | null>(
            null,
        );

    const [
        errors,
        setErrors,
    ] =
        useState<ValidityPeriodErrors>(
            {},
        );

    const [
        loading,
        setLoading,
    ] = useState(true);

    const [
        saving,
        setSaving,
    ] = useState(false);

    const [
        togglingId,
        setTogglingId,
    ] =
        useState<string | null>(
            null,
        );

    const [
        deleting,
        setDeleting,
    ] = useState(false);

    const [
        pageError,
        setPageError,
    ] = useState("");

    const [
        toast,
        setToast,
    ] = useState<{
        type:
            | "success"
            | "error";
        message: string;
    }>({
        type: "success",
        message: "",
    });

    /*
    |--------------------------------------------------------------------------
    | Toast
    |--------------------------------------------------------------------------
    */

    const showToast =
        useCallback(
            (
                type:
                    | "success"
                    | "error",
                message: string,
            ) => {
                setToast({
                    type,
                    message,
                });

                window.setTimeout(
                    () => {
                        setToast(
                            (
                                previous,
                            ) =>
                                previous.message ===
                                message
                                    ? {
                                          type:
                                              "success",
                                          message:
                                              "",
                                      }
                                    : previous,
                        );
                    },
                    3500,
                );
            },
            [],
        );

    /*
    |--------------------------------------------------------------------------
    | Load
    |--------------------------------------------------------------------------
    */

    const loadValidityPeriods =
        useCallback(
            async () => {
                setLoading(
                    true,
                );

                setPageError(
                    "",
                );

                try {
                    const response =
                        await api.get<
                            ApiResponse<
                                ValidityPeriod[]
                            >
                        >(
                            COMMON_ENDPOINT,
                            {
                                params: {
                                    type:
                                        SETTING_TYPE,
                                    page: 1,
                                    limit: 100,
                                },
                            },
                        );

                    setValidityPeriods(
                        extractValidityPeriods(
                            response.data,
                        ),
                    );
                } catch (error) {
                    const message =
                        getErrorMessage(
                            error,
                            "Unable to load validity periods.",
                        );

                    setValidityPeriods(
                        [],
                    );

                    setPageError(
                        message,
                    );

                    showToast(
                        "error",
                        message,
                    );
                } finally {
                    setLoading(
                        false,
                    );
                }
            },
            [showToast],
        );

    useEffect(() => {
        void loadValidityPeriods();
    }, [loadValidityPeriods]);

    /*
    |--------------------------------------------------------------------------
    | Add
    |--------------------------------------------------------------------------
    */

    const openAddForm =
        useCallback(() => {
            setEditingValidityPeriod(
                null,
            );

            setFormData({
                ...emptyForm,
            });

            setErrors({});

            setShowForm(
                true,
            );
        }, []);

    /*
    |--------------------------------------------------------------------------
    | Edit
    |--------------------------------------------------------------------------
    */

    const openEditForm =
        useCallback(
            (
                validityPeriod: ValidityPeriod,
            ) => {
                setEditingValidityPeriod(
                    validityPeriod,
                );

                setFormData({
                    name:
                        validityPeriod.name,
                    description:
                        validityPeriod.description,
                });

                setErrors({});

                setShowForm(
                    true,
                );
            },
            [],
        );

    /*
    |--------------------------------------------------------------------------
    | Close Form
    |--------------------------------------------------------------------------
    */

    const closeForm =
        useCallback(() => {
            if (saving) {
                return;
            }

            setShowForm(
                false,
            );

            setEditingValidityPeriod(
                null,
            );

            setFormData({
                ...emptyForm,
            });

            setErrors({});
        }, [saving]);

    /*
    |--------------------------------------------------------------------------
    | Validate
    |--------------------------------------------------------------------------
    */

    const validateForm =
        useCallback(() => {
            const nextErrors: ValidityPeriodErrors =
                {};

            const name =
                formData.name.trim();

            const description =
                formData.description.trim();

            if (!name) {
                nextErrors.name =
                    "Validity period is required.";
            }

            if (!description) {
                nextErrors.description =
                    "Description is required.";
            }

            if (
                name.length >
                150
            ) {
                nextErrors.name =
                    "Validity period cannot exceed 150 characters.";
            }

            if (
                description.length >
                1000
            ) {
                nextErrors.description =
                    "Description cannot exceed 1000 characters.";
            }

            const duplicate =
                validityPeriods.some(
                    (
                        period,
                    ) =>
                        period.name
                            .trim()
                            .toLowerCase() ===
                            name.toLowerCase() &&
                        period.id !==
                            editingValidityPeriod?.id,
                );

            if (
                duplicate
            ) {
                nextErrors.name =
                    "A validity period with this name already exists.";
            }

            setErrors(
                nextErrors,
            );

            return (
                Object.keys(
                    nextErrors,
                ).length === 0
            );
        }, [
            editingValidityPeriod,
            formData,
            validityPeriods,
        ]);

    /*
    |--------------------------------------------------------------------------
    | Save
    |--------------------------------------------------------------------------
    */

    const handleSave =
        useCallback(
            async () => {
                if (
                    saving ||
                    !validateForm()
                ) {
                    return;
                }

                setSaving(
                    true,
                );

                try {
                    const payload = {
                        name:
                            formData.name.trim(),

                        description:
                            formData.description.trim(),

                        ...(editingValidityPeriod
                            ? {}
                            : {
                                  status:
                                      true,
                              }),
                    };

                    if (
                        editingValidityPeriod
                    ) {
                        const response =
                            await api.patch<
                                ApiResponse<ValidityPeriod>
                            >(
                                `${COMMON_ENDPOINT}/${encodeURIComponent(
                                    editingValidityPeriod.id,
                                )}`,
                                payload,
                                {
                                    params: {
                                        type:
                                            SETTING_TYPE,
                                    },
                                },
                            );

                        const updated =
                            normalizeValidityPeriod(
                                response
                                    .data
                                    ?.data,
                            );

                        if (
                            updated
                        ) {
                            setValidityPeriods(
                                (
                                    previous,
                                ) =>
                                    previous.map(
                                        (
                                            item,
                                        ) =>
                                            item.id ===
                                            updated.id
                                                ? updated
                                                : item,
                                    ),
                            );
                        } else {
                            await loadValidityPeriods();
                        }

                        showToast(
                            "success",
                            response
                                .data
                                ?.message ||
                                "Validity period updated successfully.",
                        );
                    } else {
                        const response =
                            await api.post<
                                ApiResponse<ValidityPeriod>
                            >(
                                COMMON_ENDPOINT,
                                payload,
                                {
                                    params: {
                                        type:
                                            SETTING_TYPE,
                                    },
                                },
                            );

                        const created =
                            normalizeValidityPeriod(
                                response
                                    .data
                                    ?.data,
                            );

                        if (
                            created
                        ) {
                            setValidityPeriods(
                                (
                                    previous,
                                ) => [
                                    ...previous,
                                    created,
                                ],
                            );
                        } else {
                            await loadValidityPeriods();
                        }

                        showToast(
                            "success",
                            response
                                .data
                                ?.message ||
                                "Validity period created successfully.",
                        );
                    }

                    setShowForm(
                        false,
                    );

                    setEditingValidityPeriod(
                        null,
                    );

                    setFormData({
                        ...emptyForm,
                    });

                    setErrors({});
                } catch (error) {
                    const message =
                        getErrorMessage(
                            error,
                            editingValidityPeriod
                                ? "Unable to update validity period."
                                : "Unable to create validity period.",
                        );

                    if (
                        message
                            .toLowerCase()
                            .includes(
                                "already exists",
                            ) ||
                        message
                            .toLowerCase()
                            .includes(
                                "duplicate",
                            )
                    ) {
                        setErrors(
                            (
                                previous,
                            ) => ({
                                ...previous,
                                name:
                                    message,
                            }),
                        );
                    } else {
                        showToast(
                            "error",
                            message,
                        );
                    }
                } finally {
                    setSaving(
                        false,
                    );
                }
            },
            [
                editingValidityPeriod,
                formData,
                loadValidityPeriods,
                saving,
                showToast,
                validateForm,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Toggle Status
    |--------------------------------------------------------------------------
    */

    const handleToggle =
        useCallback(
            async (
                validityPeriod: ValidityPeriod,
                checked: boolean,
            ) => {
                if (
                    togglingId ===
                    validityPeriod.id
                ) {
                    return;
                }

                const previousStatus =
                    validityPeriod.status;

                /*
                 * Optimistic UI.
                 */
                setValidityPeriods(
                    (
                        previous,
                    ) =>
                        previous.map(
                            (item) =>
                                item.id ===
                                validityPeriod.id
                                    ? {
                                          ...item,
                                          status:
                                              checked,
                                      }
                                    : item,
                        ),
                );

                setTogglingId(
                    validityPeriod.id,
                );

                try {
                    /*
                     * The current Common Settings router does not
                     * expose a dedicated status endpoint.
                     *
                     * Status is therefore updated through the
                     * existing PATCH /settings/common/:id route.
                     */
                    const response =
                        await api.patch<
                            ApiResponse<ValidityPeriod>
                        >(
                            `${COMMON_ENDPOINT}/${encodeURIComponent(
                                validityPeriod.id,
                            )}`,
                            {
                                status:
                                    checked,
                            },
                            {
                                params: {
                                    type:
                                        SETTING_TYPE,
                                },
                            },
                        );

                    const updated =
                        normalizeValidityPeriod(
                            response
                                .data
                                ?.data,
                        );

                    if (
                        updated
                    ) {
                        setValidityPeriods(
                            (
                                previous,
                            ) =>
                                previous.map(
                                    (
                                        item,
                                    ) =>
                                        item.id ===
                                        updated.id
                                            ? updated
                                            : item,
                                ),
                        );
                    }

                    showToast(
                        "success",
                        response
                            .data
                            ?.message ||
                            (checked
                                ? "Validity period enabled successfully."
                                : "Validity period disabled successfully."),
                    );
                } catch (error) {
                    /*
                     * Roll back optimistic update.
                     */
                    setValidityPeriods(
                        (
                            previous,
                        ) =>
                            previous.map(
                                (
                                    item,
                                ) =>
                                    item.id ===
                                    validityPeriod.id
                                        ? {
                                              ...item,
                                              status:
                                                  previousStatus,
                                          }
                                        : item,
                            ),
                    );

                    showToast(
                        "error",
                        getErrorMessage(
                            error,
                            "Unable to update validity period status.",
                        ),
                    );
                } finally {
                    setTogglingId(
                        null,
                    );
                }
            },
            [
                showToast,
                togglingId,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Delete
    |--------------------------------------------------------------------------
    */

    const handleDelete =
        useCallback(
            async () => {
                if (
                    !deleteValidityPeriod ||
                    deleting
                ) {
                    return;
                }

                setDeleting(
                    true,
                );

                try {
                    const response =
                        await api.delete<
                            ApiResponse<DeleteResult>
                        >(
                            `${COMMON_ENDPOINT}/${encodeURIComponent(
                                deleteValidityPeriod.id,
                            )}`,
                            {
                                params: {
                                    type:
                                        SETTING_TYPE,
                                },
                            },
                        );

                    setValidityPeriods(
                        (
                            previous,
                        ) =>
                            previous.filter(
                                (
                                    period,
                                ) =>
                                    period.id !==
                                    deleteValidityPeriod.id,
                            ),
                    );

                    setDeleteValidityPeriod(
                        null,
                    );

                    showToast(
                        "success",
                        response
                            .data
                            ?.message ||
                            "Validity period deleted successfully.",
                    );
                } catch (error) {
                    showToast(
                        "error",
                        getErrorMessage(
                            error,
                            "Unable to delete validity period.",
                        ),
                    );
                } finally {
                    setDeleting(
                        false,
                    );
                }
            },
            [
                deleteValidityPeriod,
                deleting,
                showToast,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Columns
    |--------------------------------------------------------------------------
    */

    const columns =
        useMemo<
            DataTableColumn<ValidityPeriod>[]
        >(
            () => [
                {
                    key: "name",

                    label:
                        "Validity Period",

                    sortable:
                        true,

                    width:
                        "30%",

                    render:
                        (
                            row,
                        ) => (
                            <div className="flex items-center gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                    <CalendarBlankIcon
                                        size={
                                            17
                                        }
                                        weight="duotone"
                                    />
                                </div>

                                <div className="min-w-0">
                                    <p className="truncate text-xs font-bold text-slate-800">
                                        {
                                            row.name
                                        }
                                    </p>

                                    <p className="mt-0.5 text-[10px] font-medium text-slate-400">
                                        {
                                            row.id
                                        }
                                    </p>
                                </div>
                            </div>
                        ),
                },

                {
                    key: "description",

                    label:
                        "Description",

                    sortable:
                        true,

                    width:
                        "45%",

                    render:
                        (
                            row,
                        ) => (
                            <span className="text-xs leading-5 text-slate-500">
                                {
                                    row.description
                                }
                            </span>
                        ),
                },

                {
                    key: "status",

                    label:
                        "Status",

                    sortable:
                        true,

                    align:
                        "center",

                    width:
                        "15%",

                    render:
                        (
                            row,
                        ) => (
                            <div className="flex items-center justify-center">
                                <ToggleSwitch
                                    checked={
                                        row.status
                                    }
                                    onChange={(
                                        checked,
                                    ) =>
                                        void handleToggle(
                                            row,
                                            checked,
                                        )
                                    }
                                    disabled={
                                        togglingId ===
                                        row.id
                                    }
                                    srLabel={`Toggle ${row.name} status`}
                                />
                            </div>
                        ),
                },

                {
                    key: "actions",

                    label:
                        "Actions",

                    align:
                        "center",

                    width:
                        "10%",

                    render:
                        (
                            row,
                        ) => (
                            <div className="flex items-center justify-center gap-1">
                                <button
                                    type="button"
                                    onClick={() =>
                                        openEditForm(
                                            row,
                                        )
                                    }
                                    disabled={
                                        saving ||
                                        deleting
                                    }
                                    title={`Edit ${row.name}`}
                                    aria-label={`Edit ${row.name}`}
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                    <PencilSimpleIcon
                                        size={
                                            16
                                        }
                                        weight="duotone"
                                    />
                                </button>

                                <button
                                    type="button"
                                    onClick={() =>
                                        setDeleteValidityPeriod(
                                            row,
                                        )
                                    }
                                    disabled={
                                        deleting
                                    }
                                    title={`Delete ${row.name}`}
                                    aria-label={`Delete ${row.name}`}
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                    <TrashIcon
                                        size={
                                            16
                                        }
                                        weight="duotone"
                                    />
                                </button>
                            </div>
                        ),
                },
            ],
            [
                deleting,
                handleToggle,
                openEditForm,
                saving,
                togglingId,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Render
    |--------------------------------------------------------------------------
    */

    return (
        <div className="space-y-5">
            {/* Header */}

            <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-lg font-bold text-slate-900">
                        Validity
                        Periods
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                        Manage
                        the
                        validity
                        periods
                        available
                        for
                        quotations
                        and
                        vendor
                        offers.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={
                        openAddForm
                    }
                    disabled={
                        loading ||
                        saving
                    }
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                    <PlusIcon
                        size={
                            16
                        }
                        weight="bold"
                    />

                    Add
                    Validity
                    Period
                </button>
            </div>

            {/* Toast */}

            {toast.message && (
                <div
                    className={`flex items-start gap-3 rounded-xl border px-4 py-3 shadow-sm ${
                        toast.type ===
                        "success"
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : "border-red-200 bg-red-50 text-red-700"
                    }`}
                    role="status"
                    aria-live="polite"
                >
                    {toast.type ===
                    "success" ? (
                        <CheckCircleIcon
                            size={
                                18
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0"
                        />
                    ) : (
                        <XCircleIcon
                            size={
                                18
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0"
                        />
                    )}

                    <p className="text-xs font-semibold">
                        {
                            toast.message
                        }
                    </p>
                </div>
            )}

            {/* Error */}

            {pageError && (
                <div className="flex flex-col gap-3 rounded-xl border border-red-200 bg-red-50 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-start gap-3">
                        <WarningCircleIcon
                            size={
                                20
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0 text-red-600"
                        />

                        <div>
                            <p className="text-xs font-bold text-red-700">
                                Unable
                                to
                                load
                                validity
                                periods
                            </p>

                            <p className="mt-1 text-xs leading-5 text-red-600">
                                {
                                    pageError
                                }
                            </p>
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={() =>
                            void loadValidityPeriods()
                        }
                        disabled={
                            loading
                        }
                        className="rounded-lg border border-red-200 bg-white px-3 py-2 text-xs font-bold text-red-700 transition-colors hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Retry
                    </button>
                </div>
            )}

            {/* Form */}

            {showForm && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                    <div className="mb-5">
                        <h3 className="text-sm font-bold text-slate-900">
                            {editingValidityPeriod
                                ? "Edit Validity Period"
                                : "Add Validity Period"}
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            {editingValidityPeriod
                                ? "Update the validity period information."
                                : "Create a new quotation validity period."}
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        {/* ID */}

                        {editingValidityPeriod && (
                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Validity
                                    Period
                                    ID
                                </label>

                                <input
                                    type="text"
                                    value={
                                        editingValidityPeriod.id
                                    }
                                    disabled
                                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2.5 text-sm font-medium text-slate-500 outline-none"
                                />
                            </div>
                        )}

                        {/* Name */}

                        <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Validity
                                Period
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <input
                                type="text"
                                value={
                                    formData.name
                                }
                                onChange={(
                                    event,
                                ) => {
                                    const value =
                                        event
                                            .target
                                            .value;

                                    setFormData(
                                        (
                                            previous,
                                        ) => ({
                                            ...previous,
                                            name:
                                                value,
                                        }),
                                    );

                                    if (
                                        errors.name
                                    ) {
                                        setErrors(
                                            (
                                                previous,
                                            ) => ({
                                                ...previous,
                                                name:
                                                    undefined,
                                            }),
                                        );
                                    }
                                }}
                                maxLength={
                                    150
                                }
                                disabled={
                                    saving
                                }
                                placeholder="e.g. 30 Calendar Days"
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 disabled:cursor-not-allowed disabled:bg-slate-100 ${
                                    errors.name
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.name && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.name
                                    }
                                </p>
                            )}
                        </div>

                        {/* Description */}

                        <div className="md:col-span-2">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Description
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <textarea
                                rows={
                                    3
                                }
                                value={
                                    formData.description
                                }
                                onChange={(
                                    event,
                                ) => {
                                    const value =
                                        event
                                            .target
                                            .value;

                                    setFormData(
                                        (
                                            previous,
                                        ) => ({
                                            ...previous,
                                            description:
                                                value,
                                        }),
                                    );

                                    if (
                                        errors.description
                                    ) {
                                        setErrors(
                                            (
                                                previous,
                                            ) => ({
                                                ...previous,
                                                description:
                                                    undefined,
                                            }),
                                        );
                                    }
                                }}
                                maxLength={
                                    1000
                                }
                                disabled={
                                    saving
                                }
                                placeholder="Enter a description for this validity period..."
                                className={`w-full resize-none rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 disabled:cursor-not-allowed disabled:bg-slate-100 ${
                                    errors.description
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            <div className="mt-1 flex justify-end">
                                <span className="text-[10px] font-medium text-slate-400">
                                    {
                                        formData
                                            .description
                                            .length
                                    }
                                    /
                                    1000
                                </span>
                            </div>

                            {errors.description && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.description
                                    }
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Form Buttons */}

                    <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                        <button
                            type="button"
                            onClick={
                                closeForm
                            }
                            disabled={
                                saving
                            }
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={() =>
                                void handleSave()
                            }
                            disabled={
                                saving
                            }
                            className="inline-flex min-w-[150px] items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {saving ? (
                                <>
                                    <SpinnerGapIcon
                                        size={
                                            15
                                        }
                                        weight="bold"
                                        className="animate-spin"
                                    />

                                    Saving...
                                </>
                            ) : editingValidityPeriod ? (
                                "Save Changes"
                            ) : (
                                "Add Validity Period"
                            )}
                        </button>
                    </div>
                </div>
            )}

            {/* Table */}

            {loading ? (
                <div className="flex min-h-[260px] items-center justify-center rounded-xl border border-slate-200 bg-white">
                    <div className="flex flex-col items-center gap-3">
                        <SpinnerGapIcon
                            size={
                                26
                            }
                            weight="bold"
                            className="animate-spin text-red-600"
                        />

                        <p className="text-xs font-semibold text-slate-500">
                            Loading
                            validity
                            periods...
                        </p>
                    </div>
                </div>
            ) : (
                <DataTable<ValidityPeriod>
                    columns={
                        columns
                    }
                    data={
                        validityPeriods
                    }
                    rowKey={(
                        row,
                    ) =>
                        row.id
                    }
                    minWidth="760px"
                    emptyMessage="No validity periods found. Click Add Validity Period to create one."
                />
            )}

            {/* Delete Confirmation */}

            {deleteValidityPeriod && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-[2px]">
                    <div className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
                        <div className="p-5">
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
                                    <TrashIcon
                                        size={
                                            19
                                        }
                                        weight="duotone"
                                    />
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Delete
                                        Validity
                                        Period
                                    </h3>

                                    <p className="mt-1 text-xs leading-5 text-slate-500">
                                        Are
                                        you
                                        sure
                                        you
                                        want
                                        to
                                        delete{" "}
                                        <span className="font-bold text-slate-700">
                                            {
                                                deleteValidityPeriod.name
                                            }
                                        </span>
                                        ?
                                        This
                                        action
                                        cannot
                                        be
                                        undone.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 bg-slate-50 px-5 py-4">
                            <button
                                type="button"
                                onClick={() =>
                                    setDeleteValidityPeriod(
                                        null,
                                    )
                                }
                                disabled={
                                    deleting
                                }
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={() =>
                                    void handleDelete()
                                }
                                disabled={
                                    deleting
                                }
                                className="inline-flex min-w-[145px] items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                {deleting ? (
                                    <>
                                        <SpinnerGapIcon
                                            size={
                                                15
                                            }
                                            weight="bold"
                                            className="animate-spin"
                                        />

                                        Deleting...
                                    </>
                                ) : (
                                    "Delete Validity Period"
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}