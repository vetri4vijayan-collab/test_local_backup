import {
    useCallback,
    useEffect,
    useMemo,
    useState,
} from "react";

import {
    PencilSimpleIcon,
    PlusIcon,
    TrashIcon,
    TagIcon,
    WarningCircleIcon,
    CheckCircleIcon,
    XCircleIcon,
    SpinnerGapIcon,
} from "@phosphor-icons/react";

import ToggleSwitch from "../../components/ToggleSwitch";
import DataTable, {
    DataTableColumn,
} from "../../components/DataTable";

import api from "../../api/axios";

/*
|--------------------------------------------------------------------------
| Types
|--------------------------------------------------------------------------
*/

export interface Category {
    id: string;
    categoryType: string;
    category: string;
    description: string;
    status: boolean;
    sortOrder?: number;
    createdAt?: string | null;
    updatedAt?: string | null;
}

interface CategoryFormData {
    categoryType: string;
    category: string;
    description: string;
}

interface CategoryErrors {
    categoryType?: string;
    category?: string;
    description?: string;
}

interface ApiResponse<T = unknown> {
    success?: boolean;
    message?: string;
    data?: T;
    pagination?: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
    filters?: {
        search?: string;
        categoryType?: string | null;
        status?: boolean | null;
    };
}

interface CategoryListResponse
    extends ApiResponse<Category[]> {
    data?: Category[];
}

interface DeleteConfirmation {
    category: Category;
}

const CATEGORY_TYPES = [
    "Material",
    "Service",
    "Equipment",
] as const;

const emptyForm: CategoryFormData = {
    categoryType: "",
    category: "",
    description: "",
};

/*
|--------------------------------------------------------------------------
| API
|--------------------------------------------------------------------------
|
| masterRate.routes.js is mounted by the application under:
|
|   /api/master-rates
|
|--------------------------------------------------------------------------
*/

const CATEGORY_ENDPOINT =
    "/master-rates/categories";

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getErrorMessage(
    error: unknown,
    fallback: string,
): string {
    const axiosError = error as {
        response?: {
            data?: {
                message?: string;
                error?: string;
            };
        };
        message?: string;
    };

    return (
        axiosError?.response?.data?.message ||
        axiosError?.response?.data?.error ||
        axiosError?.message ||
        fallback
    );
}

function assertApiSuccess(
    response: {
        data?: ApiResponse<unknown>;
    },
    fallback: string,
): void {
    if (
        response?.data?.success ===
        false
    ) {
        throw new Error(
            response.data.message ||
                fallback,
        );
    }
}

function normalizeCategory(
    value: unknown,
): Category | null {
    if (
        !value ||
        typeof value !== "object"
    ) {
        return null;
    }

    const item =
        value as Record<
            string,
            unknown
        >;

    const id =
        String(
            item.id ??
                item._id ??
                "",
        ).trim();

    if (!id) {
        return null;
    }

    return {
        id,

        categoryType:
            String(
                item.categoryType ??
                    "",
            ),

        category:
            String(
                item.category ??
                    "",
            ),

        description:
            String(
                item.description ??
                    "",
            ),

        status:
            Boolean(
                item.status,
            ),

        sortOrder:
            typeof item.sortOrder ===
            "number"
                ? item.sortOrder
                : undefined,

        createdAt:
            item.createdAt
                ? String(
                      item.createdAt,
                  )
                : null,

        updatedAt:
            item.updatedAt
                ? String(
                      item.updatedAt,
                  )
                : null,
    };
}

function extractCategories(
    response: CategoryListResponse,
): Category[] {
    const source =
        Array.isArray(
            response?.data,
        )
            ? response.data
            : [];

    return source
        .map(normalizeCategory)
        .filter(
            (
                item,
            ): item is Category =>
                item !== null,
        );
}

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/

export default function CategorySetting() {
    const [
        categories,
        setCategories,
    ] = useState<Category[]>([]);

    const [
        showForm,
        setShowForm,
    ] = useState(false);

    const [
        editingCategory,
        setEditingCategory,
    ] =
        useState<Category | null>(
            null,
        );

    const [
        formData,
        setFormData,
    ] =
        useState<CategoryFormData>(
            emptyForm,
        );

    const [
        deleteConfirmation,
        setDeleteConfirmation,
    ] =
        useState<DeleteConfirmation | null>(
            null,
        );

    const [
        errors,
        setErrors,
    ] =
        useState<CategoryErrors>(
            {},
        );

    const [
        loading,
        setLoading,
    ] = useState(true);

    const [
        saving,
        setSaving,
    ] = useState(false);

    const [
        togglingId,
        setTogglingId,
    ] =
        useState<string | null>(
            null,
        );

    const [
        deleting,
        setDeleting,
    ] = useState(false);

    const [
        pageError,
        setPageError,
    ] = useState("");

    const [
        toast,
        setToast,
    ] = useState<{
        type:
            | "success"
            | "error";
        message: string;
    }>({
        type: "success",
        message: "",
    });

    /*
    |--------------------------------------------------------------------------
    | Toast
    |--------------------------------------------------------------------------
    */

    const showToast =
        useCallback(
            (
                type:
                    | "success"
                    | "error",
                message: string,
            ) => {
                setToast({
                    type,
                    message,
                });

                window.setTimeout(
                    () => {
                        setToast(
                            (
                                previous,
                            ) =>
                                previous.message ===
                                message
                                    ? {
                                          type:
                                              "success",
                                          message:
                                              "",
                                      }
                                    : previous,
                        );
                    },
                    3500,
                );
            },
            [],
        );

    /*
    |--------------------------------------------------------------------------
    | Load Categories
    |--------------------------------------------------------------------------
    */

    const loadCategories =
        useCallback(
            async () => {
                setLoading(
                    true,
                );

                setPageError(
                    "",
                );

                try {
                    const response =
                        await api.get<CategoryListResponse>(
                            CATEGORY_ENDPOINT,
                            {
                                params: {
                                    page: 1,
                                    limit: 100,
                                    sort: "sortOrder",
                                    sortOrder:
                                        "asc",
                                },
                            },
                        );

                    assertApiSuccess(
                        response,
                        "Unable to load categories.",
                    );

                    const data =
                        response.data;

                    setCategories(
                        extractCategories(
                            data,
                        ),
                    );
                } catch (error) {
                    const message =
                        getErrorMessage(
                            error,
                            "Unable to load categories.",
                        );

                    setCategories(
                        [],
                    );

                    setPageError(
                        message,
                    );

                    showToast(
                        "error",
                        message,
                    );
                } finally {
                    setLoading(
                        false,
                    );
                }
            },
            [showToast],
        );

    /*
    |--------------------------------------------------------------------------
    | Initial Load
    |--------------------------------------------------------------------------
    */

    useEffect(() => {
        void loadCategories();
    }, [loadCategories]);

    /*
    |--------------------------------------------------------------------------
    | Form
    |--------------------------------------------------------------------------
    */

    const openAddForm =
        useCallback(() => {
            setEditingCategory(
                null,
            );

            setFormData({
                ...emptyForm,
            });

            setErrors({});

            setPageError("");

            setShowForm(
                true,
            );
        }, []);

    const openEditForm =
        useCallback(
            (
                category: Category,
            ) => {
                setEditingCategory(
                    category,
                );

                setFormData({
                    categoryType:
                        category.categoryType,

                    category:
                        category.category,

                    description:
                        category.description,
                });

                setErrors({});

                setPageError("");

                setShowForm(
                    true,
                );
            },
            [],
        );

    const closeForm =
        useCallback(() => {
            if (saving) {
                return;
            }

            setShowForm(
                false,
            );

            setEditingCategory(
                null,
            );

            setFormData({
                ...emptyForm,
            });

            setErrors({});
        }, [saving]);

    /*
    |--------------------------------------------------------------------------
    | Local Form Validation
    |--------------------------------------------------------------------------
    */

    const validateForm =
        useCallback(() => {
            const nextErrors: CategoryErrors =
                {};

            const categoryType =
                formData.categoryType.trim();

            const category =
                formData.category.trim();

            const description =
                formData.description.trim();

            if (!categoryType) {
                nextErrors.categoryType =
                    "Category type is required.";
            }

            if (!category) {
                nextErrors.category =
                    "Category is required.";
            }

            if (!description) {
                nextErrors.description =
                    "Description is required.";
            }

            if (
                categoryType &&
                !CATEGORY_TYPES.some(
                    (type) =>
                        type.toLowerCase() ===
                        categoryType.toLowerCase(),
                )
            ) {
                nextErrors.categoryType =
                    "Please select a valid category type.";
            }

            if (
                category.length >
                150
            ) {
                nextErrors.category =
                    "Category cannot exceed 150 characters.";
            }

            if (
                description.length >
                1000
            ) {
                nextErrors.description =
                    "Description cannot exceed 1000 characters.";
            }

            /*
             * Client-side duplicate check improves UX.
             * The backend remains the final authority.
             */
            const duplicate =
                categories.some(
                    (
                        item,
                    ) =>
                        item.categoryType
                            .trim()
                            .toLowerCase() ===
                            categoryType
                                .toLowerCase() &&
                        item.category
                            .trim()
                            .toLowerCase() ===
                            category.toLowerCase() &&
                        item.id !==
                            editingCategory?.id,
                );

            if (
                duplicate
            ) {
                nextErrors.category =
                    "This category already exists under the selected category type.";
            }

            setErrors(
                nextErrors,
            );

            return (
                Object.keys(
                    nextErrors,
                ).length === 0
            );
        }, [
            categories,
            editingCategory,
            formData,
        ]);

    /*
    |--------------------------------------------------------------------------
    | Save
    |--------------------------------------------------------------------------
    */

    const handleSave =
        useCallback(
            async () => {
                if (
                    saving ||
                    !validateForm()
                ) {
                    return;
                }

                setSaving(
                    true,
                );

                try {
                    const payload =
                        {
                            categoryType:
                                formData.categoryType.trim(),

                            category:
                                formData.category.trim(),

                            description:
                                formData.description.trim(),

                            /*
                             * New categories are active by default.
                             * Existing categories do not need to
                             * send status during edit.
                             */
                            ...(editingCategory
                                ? {}
                                : {
                                      status:
                                          true,
                                  }),
                        };

                    if (
                        editingCategory
                    ) {
                        const response =
                            await api.patch<ApiResponse<Category>>(
                                `${CATEGORY_ENDPOINT}/${encodeURIComponent(
                                    editingCategory.id,
                                )}`,
                                payload,
                            );

                        assertApiSuccess(
                            response,
                            "Unable to update category.",
                        );

                        const updated =
                            normalizeCategory(
                                response
                                    .data
                                    ?.data,
                            );

                        if (
                            updated
                        ) {
                            setCategories(
                                (
                                    previous,
                                ) =>
                                    previous.map(
                                        (
                                            item,
                                        ) =>
                                            item.id ===
                                            updated.id
                                                ? updated
                                                : item,
                                    ),
                            );
                        } else {
                            await loadCategories();
                        }

                        showToast(
                            "success",
                            response
                                .data
                                ?.message ||
                                "Category updated successfully.",
                        );
                    } else {
                        const response =
                            await api.post<ApiResponse<Category>>(
                                CATEGORY_ENDPOINT,
                                payload,
                            );

                        assertApiSuccess(
                            response,
                            "Unable to create category.",
                        );

                        const created =
                            normalizeCategory(
                                response
                                    .data
                                    ?.data,
                            );

                        if (
                            created
                        ) {
                            setCategories(
                                (
                                    previous,
                                ) => [
                                    ...previous,
                                    created,
                                ],
                            );
                        } else {
                            await loadCategories();
                        }

                        showToast(
                            "success",
                            response
                                .data
                                ?.message ||
                                "Category created successfully.",
                        );
                    }

                    setShowForm(
                        false,
                    );

                    setEditingCategory(
                        null,
                    );

                    setFormData({
                        ...emptyForm,
                    });

                    setErrors({});
                } catch (error) {
                    const message =
                        getErrorMessage(
                            error,
                            editingCategory
                                ? "Unable to update category."
                                : "Unable to create category.",
                        );

                    /*
                     * Duplicate errors from the backend should
                     * display against Category field where possible.
                     */
                    const lower =
                        message.toLowerCase();

                    if (
                        lower.includes(
                            "already exists",
                        ) ||
                        lower.includes(
                            "duplicate",
                        )
                    ) {
                        setErrors(
                            (
                                previous,
                            ) => ({
                                ...previous,
                                category:
                                    message,
                            }),
                        );
                    } else {
                        showToast(
                            "error",
                            message,
                        );
                    }
                } finally {
                    setSaving(
                        false,
                    );
                }
            },
            [
                editingCategory,
                formData,
                loadCategories,
                saving,
                showToast,
                validateForm,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Toggle Status
    |--------------------------------------------------------------------------
    */

    const handleToggle =
        useCallback(
            async (
                category: Category,
                checked: boolean,
            ) => {
                if (
                    togglingId ===
                    category.id
                ) {
                    return;
                }

                const previousStatus =
                    category.status;

                /*
                 * Optimistic update keeps the UI responsive.
                 */
                setCategories(
                    (
                        previous,
                    ) =>
                        previous.map(
                            (item) =>
                                item.id ===
                                category.id
                                    ? {
                                          ...item,
                                          status:
                                              checked,
                                      }
                                    : item,
                        ),
                );

                setTogglingId(
                    category.id,
                );

                try {
                    const response =
                        await api.patch<ApiResponse<Category>>(
                            `${CATEGORY_ENDPOINT}/${encodeURIComponent(
                                category.id,
                            )}/status`,
                            {
                                status:
                                    checked,
                            },
                        );

                    assertApiSuccess(
                        response,
                        "Unable to update category status.",
                    );

                    const updated =
                        normalizeCategory(
                            response
                                .data
                                ?.data,
                        );

                    if (
                        updated
                    ) {
                        setCategories(
                            (
                                previous,
                            ) =>
                                previous.map(
                                    (
                                        item,
                                    ) =>
                                        item.id ===
                                        updated.id
                                            ? updated
                                            : item,
                                ),
                        );
                    } else {
                        await loadCategories();
                    }

                    showToast(
                        "success",
                        response
                            .data
                            ?.message ||
                            (checked
                                ? "Category enabled successfully."
                                : "Category disabled successfully."),
                    );
                } catch (error) {
                    /*
                     * Restore previous status.
                     */
                    setCategories(
                        (
                            previous,
                        ) =>
                            previous.map(
                                (
                                    item,
                                ) =>
                                    item.id ===
                                    category.id
                                        ? {
                                              ...item,
                                              status:
                                                  previousStatus,
                                          }
                                        : item,
                            ),
                    );

                    showToast(
                        "error",
                        getErrorMessage(
                            error,
                            "Unable to update category status.",
                        ),
                    );
                } finally {
                    setTogglingId(
                        null,
                    );
                }
            },
            [
                loadCategories,
                showToast,
                togglingId,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Delete
    |--------------------------------------------------------------------------
    */

    const openDeleteConfirmation =
        useCallback(
            (
                category: Category,
            ) => {
                setDeleteConfirmation({
                    category,
                });
            },
            [],
        );

    const closeDeleteConfirmation =
        useCallback(() => {
            if (deleting) {
                return;
            }

            setDeleteConfirmation(
                null,
            );
        }, [deleting]);

    const handleDelete =
        useCallback(
            async () => {
                const category =
                    deleteConfirmation?.category;

                if (
                    !category ||
                    deleting
                ) {
                    return;
                }

                setDeleting(
                    true,
                );

                try {
                    const response =
                        await api.delete<ApiResponse<{
                            id: string;
                            deleted: boolean;
                        }>>(
                            `${CATEGORY_ENDPOINT}/${encodeURIComponent(
                                category.id,
                            )}`,
                        );

                    assertApiSuccess(
                        response,
                        "Unable to delete category.",
                    );

                    setCategories(
                        (
                            previous,
                        ) =>
                            previous.filter(
                                (
                                    item,
                                ) =>
                                    item.id !==
                                    category.id,
                            ),
                    );

                    setDeleteConfirmation(
                        null,
                    );

                    showToast(
                        "success",
                        response
                            .data
                            ?.message ||
                            "Category deleted successfully.",
                    );
                } catch (error) {
                    showToast(
                        "error",
                        getErrorMessage(
                            error,
                            "Unable to delete category.",
                        ),
                    );
                } finally {
                    setDeleting(
                        false,
                    );
                }
            },
            [
                deleteConfirmation,
                deleting,
                showToast,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Table Columns
    |--------------------------------------------------------------------------
    */

    const columns =
        useMemo<
            DataTableColumn<Category>[]
        >(
            () => [
                {
                    key: "category",
                    label: "Category",
                    sortable: true,
                    width: "20%",
                    render: (
                        row,
                    ) => (
                        <span className="text-xs font-bold text-slate-700">
                            {
                                row.category
                            }
                        </span>
                    ),
                },

                {
                    key: "categoryType",
                    label: "Category Type",
                    sortable: true,
                    width: "20%",
                    render: (
                        row,
                    ) => (
                        <div className="flex items-center gap-3">
                            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                <TagIcon
                                    size={
                                        17
                                    }
                                    weight="duotone"
                                />
                            </div>

                            <div className="min-w-0">
                                <p className="text-xs font-bold text-slate-800">
                                    {
                                        row.categoryType
                                    }
                                </p>

                                <p className="mt-0.5 text-[10px] font-medium text-slate-400">
                                    {
                                        row.id
                                    }
                                </p>
                            </div>
                        </div>
                    ),
                },

                {
                    key: "description",
                    label: "Description",
                    sortable: true,
                    width: "40%",
                    render: (
                        row,
                    ) => (
                        <span className="text-xs leading-5 text-slate-500">
                            {
                                row.description
                            }
                        </span>
                    ),
                },

                {
                    key: "status",
                    label: "Status",
                    sortable: true,
                    align: "center",
                    width: "12%",
                    render: (
                        row,
                    ) => (
                        <div className="flex items-center justify-center">
                            <ToggleSwitch
                                checked={
                                    row.status
                                }
                                onChange={(
                                    checked,
                                ) =>
                                    void handleToggle(
                                        row,
                                        checked,
                                    )
                                }
                                disabled={
                                    togglingId ===
                                    row.id
                                }
                                srLabel={`Toggle ${row.category} status`}
                            />
                        </div>
                    ),
                },

                {
                    key: "actions",
                    label: "Actions",
                    align: "center",
                    width: "13%",
                    render: (
                        row,
                    ) => (
                        <div className="flex items-center justify-center gap-1">
                            <button
                                type="button"
                                onClick={() =>
                                    openEditForm(
                                        row,
                                    )
                                }
                                disabled={
                                    saving ||
                                    deleting
                                }
                                title={`Edit ${row.category}`}
                                aria-label={`Edit ${row.category}`}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                <PencilSimpleIcon
                                    size={
                                        16
                                    }
                                    weight="duotone"
                                />
                            </button>

                            <button
                                type="button"
                                onClick={() =>
                                    openDeleteConfirmation(
                                        row,
                                    )
                                }
                                disabled={
                                    deleting
                                }
                                title={`Delete ${row.category}`}
                                aria-label={`Delete ${row.category}`}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                <TrashIcon
                                    size={
                                        16
                                    }
                                    weight="duotone"
                                />
                            </button>
                        </div>
                    ),
                },
            ],
            [
                deleting,
                handleToggle,
                openDeleteConfirmation,
                openEditForm,
                saving,
                togglingId,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Render
    |--------------------------------------------------------------------------
    */

    return (
        <div className="space-y-5">
            {/* Header */}
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-lg font-bold text-slate-900">
                        Categories
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                        Manage categories used
                        across the master
                        rate configuration.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={
                        openAddForm
                    }
                    disabled={
                        loading ||
                        saving
                    }
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                    <PlusIcon
                        size={16}
                        weight="bold"
                    />

                    Add Category
                </button>
            </div>

            {/* Toast */}
            {toast.message && (
                <div
                    className={`flex items-start gap-3 rounded-xl border px-4 py-3 shadow-sm ${
                        toast.type ===
                        "success"
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : "border-red-200 bg-red-50 text-red-700"
                    }`}
                    role="status"
                    aria-live="polite"
                >
                    {toast.type ===
                    "success" ? (
                        <CheckCircleIcon
                            size={
                                18
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0"
                        />
                    ) : (
                        <XCircleIcon
                            size={
                                18
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0"
                        />
                    )}

                    <p className="text-xs font-semibold">
                        {
                            toast.message
                        }
                    </p>
                </div>
            )}

            {/* Page Error */}
            {pageError && (
                <div className="flex flex-col gap-3 rounded-xl border border-red-200 bg-red-50 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-start gap-3">
                        <WarningCircleIcon
                            size={
                                20
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0 text-red-600"
                        />

                        <div>
                            <p className="text-xs font-bold text-red-700">
                                Unable
                                to load
                                categories
                            </p>

                            <p className="mt-1 text-xs leading-5 text-red-600">
                                {
                                    pageError
                                }
                            </p>
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={() =>
                            void loadCategories()
                        }
                        disabled={
                            loading
                        }
                        className="rounded-lg border border-red-200 bg-white px-3 py-2 text-xs font-bold text-red-700 transition-colors hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Retry
                    </button>
                </div>
            )}

            {/* Add / Edit Form */}
            {showForm && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                    <div className="mb-5">
                        <h3 className="text-sm font-bold text-slate-900">
                            {editingCategory
                                ? "Edit Category"
                                : "Add Category"}
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            {editingCategory
                                ? "Update the category information."
                                : "Create a new master rate category."}
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        {/* Category ID */}
                        {editingCategory && (
                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Category
                                    ID
                                </label>

                                <input
                                    type="text"
                                    value={
                                        editingCategory.id
                                    }
                                    disabled
                                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2.5 text-sm font-medium text-slate-500 outline-none"
                                />
                            </div>
                        )}

                        {/* Category Type */}
                        <div
                            className={
                                editingCategory
                                    ? ""
                                    : "md:col-span-1"
                            }
                        >
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Category
                                Type
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <select
                                value={
                                    formData.categoryType
                                }
                                onChange={(
                                    event,
                                ) => {
                                    const value =
                                        event
                                            .target
                                            .value;

                                    setFormData(
                                        (
                                            previous,
                                        ) => ({
                                            ...previous,
                                            categoryType:
                                                value,
                                        }),
                                    );

                                    if (
                                        errors.categoryType
                                    ) {
                                        setErrors(
                                            (
                                                previous,
                                            ) => ({
                                                ...previous,
                                                categoryType:
                                                    undefined,
                                            }),
                                        );
                                    }
                                }}
                                disabled={
                                    saving
                                }
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition disabled:cursor-not-allowed disabled:bg-slate-100 ${
                                    errors.categoryType
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            >
                                <option value="">
                                    Select
                                    category
                                    type
                                </option>

                                {CATEGORY_TYPES.map(
                                    (
                                        type,
                                    ) => (
                                        <option
                                            key={
                                                type
                                            }
                                            value={
                                                type
                                            }
                                        >
                                            {
                                                type
                                            }
                                        </option>
                                    ),
                                )}
                            </select>

                            {errors.categoryType && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.categoryType
                                    }
                                </p>
                            )}
                        </div>

                        {/* Category */}
                        <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Category
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <input
                                type="text"
                                value={
                                    formData.category
                                }
                                onChange={(
                                    event,
                                ) => {
                                    const value =
                                        event
                                            .target
                                            .value;

                                    setFormData(
                                        (
                                            previous,
                                        ) => ({
                                            ...previous,
                                            category:
                                                value,
                                        }),
                                    );

                                    if (
                                        errors.category
                                    ) {
                                        setErrors(
                                            (
                                                previous,
                                            ) => ({
                                                ...previous,
                                                category:
                                                    undefined,
                                            }),
                                        );
                                    }
                                }}
                                maxLength={
                                    150
                                }
                                disabled={
                                    saving
                                }
                                placeholder="e.g. Fiber Optic"
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 disabled:cursor-not-allowed disabled:bg-slate-100 ${
                                    errors.category
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.category && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.category
                                    }
                                </p>
                            )}
                        </div>

                        {/* Description */}
                        <div className="md:col-span-2">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Description
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <textarea
                                rows={3}
                                value={
                                    formData.description
                                }
                                onChange={(
                                    event,
                                ) => {
                                    const value =
                                        event
                                            .target
                                            .value;

                                    setFormData(
                                        (
                                            previous,
                                        ) => ({
                                            ...previous,
                                            description:
                                                value,
                                        }),
                                    );

                                    if (
                                        errors.description
                                    ) {
                                        setErrors(
                                            (
                                                previous,
                                            ) => ({
                                                ...previous,
                                                description:
                                                    undefined,
                                            }),
                                        );
                                    }
                                }}
                                maxLength={
                                    1000
                                }
                                disabled={
                                    saving
                                }
                                placeholder="Enter a description for this category..."
                                className={`w-full resize-none rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 disabled:cursor-not-allowed disabled:bg-slate-100 ${
                                    errors.description
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            <div className="mt-1 flex items-center justify-between">
                                {errors.description ? (
                                    <p className="text-[10px] font-medium text-red-500">
                                        {
                                            errors.description
                                        }
                                    </p>
                                ) : (
                                    <span />
                                )}

                                <span className="text-[10px] font-medium text-slate-400">
                                    {
                                        formData
                                            .description
                                            .length
                                    }
                                    /
                                    1000
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Form Actions */}
                    <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                        <button
                            type="button"
                            onClick={
                                closeForm
                            }
                            disabled={
                                saving
                            }
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={() =>
                                void handleSave()
                            }
                            disabled={
                                saving
                            }
                            className="inline-flex min-w-[120px] items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {saving ? (
                                <>
                                    <SpinnerGapIcon
                                        size={
                                            15
                                        }
                                        weight="bold"
                                        className="animate-spin"
                                    />

                                    Saving...
                                </>
                            ) : (
                                <>
                                    {editingCategory
                                        ? "Save Changes"
                                        : "Add Category"}
                                </>
                            )}
                        </button>
                    </div>
                </div>
            )}

            {/* Loading */}
            {loading ? (
                <div className="flex min-h-[260px] items-center justify-center rounded-xl border border-slate-200 bg-white">
                    <div className="flex flex-col items-center gap-3">
                        <SpinnerGapIcon
                            size={
                                26
                            }
                            weight="bold"
                            className="animate-spin text-red-600"
                        />

                        <p className="text-xs font-semibold text-slate-500">
                            Loading
                            categories...
                        </p>
                    </div>
                </div>
            ) : (
                <DataTable<Category>
                    columns={
                        columns
                    }
                    data={
                        categories
                    }
                    rowKey={(
                        row,
                    ) =>
                        row.id
                    }
                    minWidth="900px"
                    emptyMessage="No categories found. Click Add Category to create one."
                />
            )}

            {/* Delete Confirmation */}
            {deleteConfirmation && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-[2px]">
                    <div className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
                        <div className="p-5">
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
                                    <TrashIcon
                                        size={
                                            19
                                        }
                                        weight="duotone"
                                    />
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Delete
                                        Category
                                    </h3>

                                    <p className="mt-1 text-xs leading-5 text-slate-500">
                                        Are
                                        you
                                        sure
                                        you
                                        want
                                        to
                                        delete{" "}
                                        <span className="font-bold text-slate-700">
                                            {
                                                deleteConfirmation
                                                    .category
                                                    .category
                                            }
                                        </span>
                                        ? This
                                        action
                                        cannot
                                        be
                                        undone.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 bg-slate-50 px-5 py-4">
                            <button
                                type="button"
                                onClick={
                                    closeDeleteConfirmation
                                }
                                disabled={
                                    deleting
                                }
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={() =>
                                    void handleDelete()
                                }
                                disabled={
                                    deleting
                                }
                                className="inline-flex min-w-[120px] items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                {deleting ? (
                                    <>
                                        <SpinnerGapIcon
                                            size={
                                                15
                                            }
                                            weight="bold"
                                            className="animate-spin"
                                        />

                                        Deleting...
                                    </>
                                ) : (
                                    "Delete Category"
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}