import { useEffect, useMemo, useState } from "react";
import Select, { StylesConfig } from "react-select";
import DataTable, { DataTableColumn } from "../components/DataTable";
import DataCard, {
    DataCardAction,
    DataCardField,
    DataCardMenuAction,
} from "../components/DataCard";
import StatCard from "../components/StatCard";
import { Vendor } from "../data/vendors";
import api from "../api/axios";
import {
    BuildingsIcon,
    CheckCircleIcon,
    CurrencyDollarSimpleIcon,
    EyeIcon,
    EyeSlashIcon,
    FileTextIcon,
    LayoutIcon,
    ListIcon,
    MagnifyingGlassIcon,
    MailboxIcon,
    MapPinIcon,
    PencilSimpleIcon,
    PhoneIcon,
    TagIcon,
} from "@phosphor-icons/react";
import AddNewVendor from "../offcanvas/vendor/NewVendor";
import { useNavigate } from "react-router-dom";
import { getSelectStyles } from "../utils/selectStyles";

type ViewMode = "grid" | "list";

type VendorStatus =
    | "PENDING"
    | "APPROVED"
    | "REJECTED"
    | "DEACTIVE";

const STATUS_LABELS: Record<VendorStatus, string> = {
    PENDING: "Pending",
    APPROVED: "Approve",
    REJECTED: "Reject",
    DEACTIVE: "Deactive",
};

const STATUS_STYLES: Record<VendorStatus, string> = {
    PENDING: "border-amber-200 bg-amber-50 text-amber-700",
    APPROVED: "border-emerald-200 bg-emerald-50 text-emerald-700",
    REJECTED: "border-red-200 bg-red-50 text-red-700",
    DEACTIVE: "border-slate-200 bg-slate-100 text-slate-600",
};

const STATUS_OPTIONS: VendorStatus[] = [
    "APPROVED",
    "REJECTED",
    "DEACTIVE",
    "PENDING",
];

interface SelectOption {
    value: string;
    label: string;
}

const statusSelectStyles: StylesConfig<SelectOption, false> = {
    control: (base) => ({
        ...base,
        minHeight: "30px",
        height: "30px",
        width: "auto",
        minWidth: "112px",
        border: "0",
        borderRadius: "9999px",
        boxShadow: "none",
        backgroundColor: "transparent",
        cursor: "pointer",
    }),
    valueContainer: (base) => ({
        ...base,
        padding: "0 4px 0 12px",
    }),
    singleValue: (base) => ({
        ...base,
        margin: 0,
        fontSize: "10px",
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: "0.025em",
    }),
    indicatorsContainer: (base) => ({
        ...base,
        paddingRight: "3px",
    }),
    indicatorSeparator: () => ({ display: "none" }),
    dropdownIndicator: (base) => ({
        ...base,
        padding: "0 4px 0 2px",
        color: "currentColor",
    }),
    menu: (base) => ({
        ...base,
        zIndex: 9999,
        minWidth: "150px",
        borderRadius: "8px",
        overflow: "hidden",
        marginTop: "4px",
    }),
    menuPortal: (base) => ({
        ...base,
        zIndex: 10000,
    }),
    option: (base, state) => ({
        ...base,
        fontSize: "12px",
        padding: "8px 10px",
        cursor: "pointer",
        backgroundColor: state.isSelected ? "#ef4444" : state.isFocused ? "#fef2f2" : "#ffffff",
        color: state.isSelected ? "#ffffff" : "#1e293b",
    }),
};

export default function VendorDirectory() {
    const navigate = useNavigate();

    const [vendors, setVendors] = useState<Vendor[]>([]);
    const [loading, setLoading] = useState(true);
    const [loadError, setLoadError] = useState("");
    const [successMessage, setSuccessMessage] = useState("");
    const [view, setView] = useState<ViewMode>("grid");
    const [query, setQuery] = useState("");
    const [category, setCategory] = useState("All Categories");
    const [status, setStatus] = useState("All Statuses");
    const [vendorName, setVendorName] = useState("All Vendors");
    const [showAddVendor, setShowAddVendor] = useState(false);
    const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);

    const [showApprovalModal, setShowApprovalModal] = useState(false);
    const [approvalVendor, setApprovalVendor] = useState<Vendor | null>(null);

    const loadVendors = async () => {
        setLoading(true);
        setLoadError("");
        try {
            const response = await api.get("/vendors", {
                params: { page: 1, limit: 250 },
            });

            if (response.data?.success !== true || !Array.isArray(response.data?.data)) {
                throw new Error(
                    response.data?.message || "Unable to load vendors.",
                );
            }

            setVendors(response.data.data);
        } catch (error: any) {
            const message = error?.response?.data?.message || error?.message || "Unable to load vendors.";
            setLoadError(message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        void loadVendors();
    }, []);

    const [approvalUsername, setApprovalUsername] = useState("");
    const [approvalPassword, setApprovalPassword] = useState("");
    const [showApprovalPassword, setShowApprovalPassword] = useState(false);
    const [statusSavingId, setStatusSavingId] = useState<string | null>(null);
    const [approvalSubmitting, setApprovalSubmitting] = useState(false);


    const categories = useMemo(
        () => [
            "All Categories",
            ...Array.from(
                new Set(vendors.map((vendor) => vendor.category))
            ),
        ],
        [vendors]
    );

    const statuses = useMemo(
        () => [
            "All Statuses",
            "PENDING",
            "APPROVED",
            "REJECTED",
            "DEACTIVE",
        ],
        []
    );

    const vendorNames = useMemo(
        () => [
            "All Vendors",
            ...Array.from(
                new Set(vendors.map((vendor) => vendor.name))
            ),
        ],
        [vendors]
    );

    const filtered = useMemo<Vendor[]>(() => {
        const search = query.trim().toLowerCase();

        return vendors.filter((vendor) => {
            const matchesQuery =
                !search ||
                vendor.name.toLowerCase().includes(search) ||
                vendor.trn.toLowerCase().includes(search) ||
                vendor.contactName.toLowerCase().includes(search) ||
                vendor.email.toLowerCase().includes(search);

            const matchesCategory =
                category === "All Categories" ||
                vendor.category === category;

            const matchesStatus =
                status === "All Statuses" ||
                vendor.status === status;

            const matchesVendor =
                vendorName === "All Vendors" ||
                vendor.name === vendorName;

            return (
                matchesQuery &&
                matchesCategory &&
                matchesStatus &&
                matchesVendor
            );
        });
    }, [
        vendors,
        query,
        category,
        status,
        vendorName,
    ]);

    const stats = useMemo(
        () => ({
            total: vendors.length,
            approved: vendors.filter(
                (vendor) => vendor.status === "APPROVED"
            ).length,
            leads: 0,
            currencies: Array.from(
                new Set(vendors.map((vendor) => vendor.currency))
            ).join(" / "),
        }),
        [vendors]
    );

    const handleProfile = (vendor: Vendor) => {
        navigate("/vendor/vendorprofile", {
            state: {
                vendor,
            },
        });
    };

    const handleEdit = (vendor: Vendor) => {
        setEditingVendor(vendor);
        setShowAddVendor(true);
    };

    const handleQuote = (vendor: Vendor) => {
        navigate("/quotation/new_quotation", {
            state: {
                vendorId: vendor.id,
                vendor,
            },
        });
    };

    const updateLocalVendor = (updated: Vendor) => {
        setVendors((previous) =>
            previous.map((item) =>
                item.id === updated.id ? updated : item
            )
        );
    };

    const handleStatusChange = async (
        vendor: Vendor,
        newStatus: VendorStatus,
    ) => {
        if (statusSavingId === vendor.id || vendor.status === newStatus) {
            return;
        }

        setLoadError("");
        setSuccessMessage("");
        setStatusSavingId(vendor.id);

        try {
            const response = await api.patch(
                `/vendors/${vendor.id}/status`,
                { status: newStatus },
            );

            if (response.data?.success !== true || !response.data?.data) {
                throw new Error(
                    response.data?.message ||
                        "Unable to update vendor status.",
                );
            }

            updateLocalVendor(response.data.data);
        } catch (error: any) {
            setLoadError(
                error?.response?.data?.message ||
                    error?.message ||
                    "Unable to update vendor status.",
            );
        } finally {
            setStatusSavingId(null);
        }
    };

    const handleApprovalRequest = (vendor: Vendor) => {
        setApprovalVendor(vendor);
        setApprovalUsername(vendor.email || "");
        setApprovalPassword("");
        setShowApprovalModal(true);
    };

    const handleApprovalConfirm = async () => {
        if (!approvalVendor || approvalSubmitting) {
            return;
        }

        const email = approvalUsername.trim().toLowerCase();
        const password = approvalPassword;

        if (!email || !password.trim()) {
            return;
        }

        setApprovalSubmitting(true);
        setLoadError("");
        setSuccessMessage("");

        try {
            const response = await api.post(
                `/vendor-portal/vendors/${approvalVendor.id}/approve-and-invite`,
                {
                    email,
                    displayName:
                        approvalVendor.contactName ||
                        approvalVendor.name,
                    password,
                },
            );

            if (
                response.data?.success !== true ||
                !response.data?.data
            ) {
                throw new Error(
                    response.data?.message ||
                        "Unable to approve vendor.",
                );
            }

            const result = response.data.data;

            if (result.vendor) {
                updateLocalVendor(result.vendor);
            }

            if (result.invitation?.emailSent === true) {
                setSuccessMessage(
                    `Vendor approved and portal invitation sent to ${email}.`,
                );
            } else {
                setSuccessMessage(
                    `Vendor approved and portal account created, but the invitation email was not sent. ${result.invitation?.emailError || ""}`.trim(),
                );
            }

            setShowApprovalModal(false);
            setApprovalVendor(null);
            setApprovalUsername("");
            setApprovalPassword("");
        } catch (error: any) {
            setLoadError(
                error?.response?.data?.message ||
                    error?.message ||
                    "Unable to approve vendor.",
            );
        } finally {
            setApprovalSubmitting(false);
        }
    };

    const handleResendInvitation = async (vendor: Vendor) => {
        if (vendor.status !== "APPROVED" || statusSavingId === vendor.id) {
            return;
        }

        setStatusSavingId(vendor.id);
        setLoadError("");
        setSuccessMessage("");

        try {
            const response = await api.post(
                `/vendor-portal/vendors/${vendor.id}/account/resend-invitation`,
            );

            if (
                response.data?.success !== true ||
                !response.data?.data
            ) {
                throw new Error(
                    response.data?.message ||
                        "Unable to resend vendor invitation.",
                );
            }

            const invitation = response.data.data.invitation;

            setSuccessMessage(
                invitation?.emailSent === true
                    ? `Vendor portal invitation resent to ${vendor.email}.`
                    : `Invitation could not be sent. ${invitation?.emailError || ""}`.trim(),
            );
        } catch (error: any) {
            setLoadError(
                error?.response?.data?.message ||
                    error?.message ||
                    "Unable to resend vendor invitation.",
            );
        } finally {
            setStatusSavingId(null);
        }
    };

    const handleDeactivate = async (vendor: Vendor) => {
        const nextStatus: VendorStatus =
            vendor.status === "DEACTIVE"
                ? "PENDING"
                : "DEACTIVE";

        await handleStatusChange(vendor, nextStatus);
    };

    const renderStatusDropdown = (vendor: Vendor) => {
        const selected: SelectOption = {
            value: vendor.status,
            label: STATUS_LABELS[vendor.status],
        };

        const allowedByStatus: Record<VendorStatus, VendorStatus[]> = {
            PENDING: ["APPROVED", "REJECTED", "DEACTIVE"],
            APPROVED: ["DEACTIVE"],
            REJECTED: ["PENDING"],
            DEACTIVE: ["PENDING"],
        };

        const options: SelectOption[] = allowedByStatus[vendor.status].map(
            (item) => ({
                value: item,
                label: STATUS_LABELS[item],
            }),
        );

        return (
            <div
                className={`relative inline-flex rounded-full border ${STATUS_STYLES[vendor.status]}`}
                onClick={(event) => event.stopPropagation()}
                onMouseDown={(event) => event.stopPropagation()}
            >
                <Select
                    value={selected}
                    options={options}
                    isSearchable={false}
                    isClearable={false}
                    isDisabled={statusSavingId === vendor.id}
                    onChange={(option) => {
                        const next = option?.value as VendorStatus | undefined;
                        if (!next || next === vendor.status) {
                            return;
                        }

                        if (next === "APPROVED") {
                            handleApprovalRequest(vendor);
                            return;
                        }

                        void handleStatusChange(vendor, next);
                    }}
                    styles={statusSelectStyles}
                    menuPortalTarget={
                        typeof document !== "undefined"
                            ? document.body
                            : undefined
                    }
                    menuPlacement="auto"
                    aria-label={`Change status for ${vendor.name}`}
                />
            </div>
        );
    };


    const columns: DataTableColumn<Vendor>[] = [
    {
    key: "name",
    label: "Company Name",
    sortable: true,
    render: (row) => (
        <div className="min-w-0">
            <div
                className="
                    min-w-0
                    whitespace-normal
                    break-words
                    font-bold
                    text-slate-900
                    transition-colors
                    duration-150
                    group-hover:text-red-600
                "
            >
                {row.name}
            </div>

            <div className="whitespace-normal break-words text-xs text-slate-400">
                {row.tagline}
            </div>
        </div>
    ),
},

    {
        key: "trn",
        label: "TRN",
        sortable: true,
    },
    {
        key: "category",
        label: "Category",
        sortable: true,
    },
    {
        key: "contactName",
        label: "Primary Contact",
        sortable: true,
        render: (row) => (
            <div>
                <div className="font-semibold text-slate-800">
                    {row.contactName}
                </div>

                <div className="text-xs text-slate-400">
                    {row.email}
                </div>
            </div>
        ),
    },
    {
        key: "currency",
        label: "Currency",
        sortable: true,
        align: "center",
    },
    {
        key: "paymentTerms",
        label: "Payment Terms",
        sortable: true,
    },
    {
        key: "creditLimit",
        label: "Credit Limit",
        sortable: true,
        render: (row) => (
            <span className="font-bold text-slate-800">
                {row.creditLimit}
            </span>
        ),
    },
    {
        key: "status",
        label: "Status",
        sortable: true,
        align: "center",
        render: (row) => renderStatusDropdown(row),
    },
    {
        key: "actions",
        label: "Actions",
        align: "center",
        render: (row) => (
            <div className="flex items-center justify-center gap-1.5">
                <button
                    type="button"
                    title="Edit Vendor"
                    aria-label={`Edit ${row.name}`}
                    onClick={() => handleEdit(row)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800"
                >
                    <PencilSimpleIcon
                        size={17}
                        weight="duotone"
                    />
                </button>

                <button
                    type="button"
                    title="View Profile"
                    aria-label={`View ${row.name} profile`}
                    onClick={() => handleProfile(row)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 transition-colors hover:bg-red-50 hover:text-red-600"
                >
                    <EyeIcon
                        size={17}
                        weight="duotone"
                    />
                </button>

                {/* <button
                    type="button"
                    title="Create Quotation"
                    aria-label={`Create quotation for ${row.name}`}
                    onClick={() => handleQuote(row)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 transition-colors hover:bg-blue-50 hover:text-blue-600"
                >
                    <FileTextIcon
                        size={17}
                        weight="duotone"
                    />
                </button> */}
            </div>
        ),
    },
];


const cardFields = (vendor: Vendor): DataCardField[] => [
    {
        label: "Primary Contact",
        fullWidth: true,
        value: (
            <div className="w-full min-w-0 max-w-full">
                {/* Contact name + role */}
                <div className="w-full min-w-0 max-w-full whitespace-normal break-words text-sm font-bold leading-5 text-slate-800">
                    <span className="whitespace-normal break-words">
                        {vendor.contactName}
                    </span>{" "}
                    <span className="whitespace-normal break-words text-xs font-medium text-slate-400">
                        ({vendor.contactRole})
                    </span>
                </div>

                {/* Email + Phone */}
                <div className="mt-1.5 grid w-full min-w-0 grid-cols-1 gap-1 text-xs text-slate-500">
                    <span className="flex w-full min-w-0 items-start gap-1">
                        <MailboxIcon
                            size={12}
                            className="mt-0.5 shrink-0"
                        />

                        <span className="min-w-0 whitespace-normal break-all">
                            {vendor.email}
                        </span>
                    </span>

                    <span className="flex w-full min-w-0 items-start gap-1">
                        <PhoneIcon
                            size={12}
                            className="mt-0.5 shrink-0"
                        />

                        <span className="min-w-0 whitespace-normal break-all">
                            {vendor.phone}
                        </span>
                    </span>
                </div>
            </div>
        ),
    },
    {
        label: "Key Site Locations",
        fullWidth: true,
        value: (
            <div className="flex w-full min-w-0 items-start gap-1 text-xs font-semibold leading-5 text-slate-600">
                <MapPinIcon
                    size={12}
                    className="mt-1 shrink-0 text-slate-400"
                />

                <span className="min-w-0 whitespace-normal break-words">
                    {vendor.locations || "No locations specified"}
                </span>
            </div>
        ),
    },
    {
        label: "Payment Terms",
        value: (
            <span className="block min-w-0 whitespace-normal break-words text-sm font-medium leading-5 text-slate-700">
                {vendor.paymentTerms}
            </span>
        ),
    },
    {
        label: "Credit Limit",
        value: (
            <span className="block min-w-0 whitespace-normal break-words text-sm font-medium leading-5 text-slate-700">
                {vendor.creditLimit}
            </span>
        ),
    },
];



    const cardActions = (
        vendor: Vendor
    ): DataCardAction[] => [
        {
            id: "profile",
            label: "View Profile",
            onClick: () => handleProfile(vendor),
            variant: "primary",
        },
    ];

    const cardMenuActions = (
        vendor: Vendor
    ): DataCardMenuAction[] => [
        {
            id: "edit",
            label: "Edit",
            onClick: () => handleEdit(vendor),
        },
        {
            id: "deactivate",
            label:
                vendor.status === "DEACTIVE"
                    ? "Activate"
                    : "Deactivate",
            onClick: () => handleDeactivate(vendor),
            danger: vendor.status !== "DEACTIVE",
        },
        ...(vendor.status === "APPROVED"
            ? [
                  {
                      id: "resend-invitation",
                      label: "Resend Portal Invitation",
                      onClick: () => handleResendInvitation(vendor),
                  },
              ]
            : []),
        // {
        //     id: "create-quotation",
        //     label: "Create Quotation",
        //     onClick: () => handleQuote(vendor),
        // },
    ];

    return (
        <>
            <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">
                        Vendors &amp; Accounts
                    </h1>
                </div>

                <button
                    type="button"
                    onClick={() => {
                        setEditingVendor(null);
                        setShowAddVendor(true);
                    }}
                    className="inline-flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700"
                >
                    Add New Vendor
                </button>
            </div>

            {showAddVendor && (
    <AddNewVendor
        onClose={() => {
            setShowAddVendor(false);
            setEditingVendor(null);
        }}
        editingVendor={editingVendor}
        onSave={async (formData) => {
            const payload = {
                companyName: formData.companyName,
                trn: formData.trn,
                vendorCategory: formData.vendorCategory,
                industrySector: formData.industrySector,
                accountStatus: formData.accountStatus,
                contactName: formData.contactName,
                designation: formData.designation,
                email: formData.email,
                phone: formData.phone,
                whatsapp: formData.whatsapp,
                currency: formData.currency,
                paymentTerms: formData.paymentTerms,
                creditLimit: formData.creditLimit,
                billingAddress: formData.billingAddress,
                siteAddress: formData.siteAddress,
                projectLocations: formData.projectLocations,
                internalNotes: formData.internalNotes,
                bankName: formData.bankName,
                bankBranch: formData.bankBranch,
                accountHolderName: formData.accountHolderName,
                accountNumber: formData.accountNumber,
                ifscCode: formData.ifscCode,
                swiftCode: formData.swiftCode,
            };

            try {
                const response = editingVendor
                    ? await api.patch(`/vendors/${editingVendor.id}`, payload)
                    : await api.post('/vendors', payload);

                if (
                    response.data?.success !== true ||
                    !response.data?.data
                ) {
                    throw new Error(
                        response.data?.message ||
                            "Unable to save vendor.",
                    );
                }

                const saved = response.data.data;
                setVendors((previous) => editingVendor
                    ? previous.map((item) => item.id === editingVendor.id ? saved : item)
                    : [saved, ...previous]
                );
                setSuccessMessage(
                    editingVendor
                        ? "Vendor updated successfully."
                        : "Vendor created successfully and is pending approval.",
                );
            } catch (error: any) {
                const message =
                    error?.response?.data?.message ||
                    error?.message ||
                    "Unable to save vendor.";
                setLoadError(message);
                throw error;
            }
        }}

    />
)}

            {successMessage && (
                <div className="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                    {successMessage}
                </div>
            )}

            {loadError && view === "grid" && (
                <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    {loadError}
                </div>
            )}

            <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
                <StatCard
                    label="Total Accounts"
                    value={stats.total}
                    icon={BuildingsIcon}
                    tone="red"
                />

                <StatCard
                    label="Approved Vendors"
                    value={stats.approved}
                    icon={CheckCircleIcon}
                    tone="green"
                />

                <StatCard
                    label="Sales Bids / Leads"
                    value={stats.leads}
                    icon={TagIcon}
                    tone="blue"
                />

                <StatCard
                    label="Currencies Supported"
                    value={stats.currencies}
                    icon={CurrencyDollarSimpleIcon}
                    tone="amber"
                />
            </div>

            <div className="mb-6 flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm md:flex-row md:items-center">
                <div className="relative flex-1">
                    <MagnifyingGlassIcon
                        size={16}
                        className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                    />

                    <input
                        value={query}
                        onChange={(event) =>
                            setQuery(event.target.value)
                        }
                        placeholder="Search company, TRN, contact or email..."
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2.5 pl-10 pr-3 text-sm text-slate-700 outline-none placeholder:text-slate-400 focus:border-red-300 focus:bg-white"
                    />
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    <Select<SelectOption>
                        value={{ value: category, label: category }}
                        options={categories.map((item) => ({
                            value: item,
                            label: item,
                        }))}
                        isSearchable={false}
                        isClearable={false}
                        onChange={(option) =>
                            setCategory(option?.value ?? "All Categories")
                        }
                        styles={getSelectStyles<SelectOption>()}
                        menuPortalTarget={
                            typeof document !== "undefined"
                                ? document.body
                                : undefined
                        }
                    />

                    <Select<SelectOption>
                        value={{
                            value: status,
                            label:
                                status === "All Statuses"
                                    ? status
                                    : STATUS_LABELS[status as VendorStatus],
                        }}
                        options={statuses.map((item) => ({
                            value: item,
                            label:
                                item === "All Statuses"
                                    ? item
                                    : STATUS_LABELS[item as VendorStatus],
                        }))}
                        isSearchable={false}
                        isClearable={false}
                        onChange={(option) =>
                            setStatus(option?.value ?? "All Statuses")
                        }
                        styles={getSelectStyles<SelectOption>()}
                        menuPortalTarget={
                            typeof document !== "undefined"
                                ? document.body
                                : undefined
                        }
                    />

                    <Select<SelectOption>
                        value={{ value: vendorName, label: vendorName }}
                        options={vendorNames.map((item) => ({
                            value: item,
                            label: item,
                        }))}
                        isSearchable={false}
                        isClearable={false}
                        onChange={(option) =>
                            setVendorName(option?.value ?? "All Vendors")
                        }
                        styles={getSelectStyles<SelectOption>()}
                        menuPortalTarget={
                            typeof document !== "undefined"
                                ? document.body
                                : undefined
                        }
                    />

                    <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 p-1">
                        <button
                            type="button"
                            onClick={() => setView("grid")}
                            aria-label="Grid view"
                            className={`rounded-md p-1.5 transition-colors ${
                                view === "grid"
                                    ? "bg-white text-red-600 shadow-sm"
                                    : "text-slate-400 hover:text-slate-600"
                            }`}
                        >
                            <LayoutIcon size={16} />
                        </button>

                        <button
                            type="button"
                            onClick={() => setView("list")}
                            aria-label="List view"
                            className={`rounded-md p-1.5 transition-colors ${
                                view === "list"
                                    ? "bg-white text-red-600 shadow-sm"
                                    : "text-slate-400 hover:text-slate-600"
                            }`}
                        >
                            <ListIcon size={16} />
                        </button>
                    </div>
                </div>
            </div>

            {view === "grid" ? (
                <div className="grid grid-cols-1 items-stretch gap-5 md:grid-cols-2 lg:grid-cols-3">
                    {filtered.map((vendor) => (
                        <div
                            key={vendor.id}
                            className="relative flex h-full min-w-0"
                        >
                            <DataCard
                                className="h-full w-full min-w-0"
                                title={vendor.name}
                                subtitle={vendor.tagline}
                                avatar={vendor.initial}
                                hoverTitle
                                tags={[
                                    `TRN: ${vendor.trn}`,
                                    vendor.category,
                                    vendor.currency,
                                ]}
                                fields={cardFields(vendor)}
                                actions={cardActions(vendor)}
                                menuActions={cardMenuActions(vendor)}
                            />

                            {/* Status */}
                            <div className="absolute right-4 top-4 z-30">
                                {renderStatusDropdown(vendor)}
                            </div>
                        </div>
                    ))}

                    {filtered.length === 0 && (
                        <div className="col-span-full rounded-2xl border border-slate-200 bg-white p-12 text-center text-sm text-slate-400 shadow-sm">
                            No vendors match your filters.
                        </div>
                    )}
                </div>

            ) : (
                <>
                {loading && (
                    <div className="mb-4 rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm text-slate-500">Loading vendors...</div>
                )}
                {loadError && (
                    <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{loadError}</div>
                )}

                <DataTable<Vendor>
                    columns={columns}
                    data={filtered}
                    rowKey={(row) => row.id}
                    emptyMessage="No vendors match your filters."
                />
                </>
            )}

            {showApprovalModal && approvalVendor && (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/50 px-4">
        <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white shadow-2xl">
            {/* Header */}
            <div className="border-b border-slate-200 px-5 py-4">
                <div className="flex items-start justify-between gap-4">
                    <div>
                        <h2 className="text-lg font-bold text-slate-900">
                            Approve Vendor
                        </h2>

                        <p className="mt-1 text-sm text-slate-500">
                            Enter the approval credentials to approve{" "}
                            <span className="font-semibold text-slate-700">
                                {approvalVendor.name}
                            </span>
                            .
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={() => {
                            setShowApprovalModal(false);
                            setApprovalVendor(null);
                            setApprovalUsername("");
                            setApprovalPassword("");
                        }}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                        aria-label="Close approval dialog"
                    >
                        ×
                    </button>
                </div>
            </div>

            {/* Form */}
            <div className="space-y-4 px-5 py-5">
                <div>
                    <label
                        htmlFor="approval-username"
                        className="mb-1.5 block text-sm font-semibold text-slate-700"
                    >
                        Username
                    </label>

                    <input
                        id="approval-username"
                        type="text"
                        value={approvalUsername}
                        onChange={(event) =>
                            setApprovalUsername(event.target.value)
                        }
                        placeholder="Enter username"
                        autoComplete="username"
                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-red-400 focus:ring-2 focus:ring-red-100"
                    />
                </div>

               <div>
    <label
        htmlFor="approval-password"
        className="mb-1.5 block text-sm font-semibold text-slate-700"
    >
        Password
    </label>

    <div className="relative">
        <input
            id="approval-password"
            type={showApprovalPassword ? "text" : "password"}
            value={approvalPassword}
            onChange={(event) =>
                setApprovalPassword(event.target.value)
            }
            placeholder="Enter password"
            autoComplete="current-password"
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 pr-10 text-sm text-slate-700 outline-none transition focus:border-red-400 focus:ring-2 focus:ring-red-100"
        />

        <button
            type="button"
            onClick={() =>
                setShowApprovalPassword((prev) => !prev)
            }
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition hover:text-slate-600"
            aria-label={
                showApprovalPassword
                    ? "Hide password"
                    : "Show password"
            }
        >
            {showApprovalPassword ? (
                <EyeSlashIcon size={18} weight="regular" />
            ) : (
                <EyeIcon size={18} weight="regular" />
            )}
        </button>
    </div>
</div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-2 border-t border-slate-200 px-5 py-4">
                <button
                    type="button"
                    onClick={() => {
                        setShowApprovalModal(false);
                        setApprovalVendor(null);
                        setApprovalUsername("");
                        setApprovalPassword("");
                    }}
                    className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    onClick={handleApprovalConfirm}
                    disabled={
                        approvalSubmitting ||
                        !approvalUsername.trim() ||
                        !approvalPassword.trim()
                    }
                    className="rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                    Approve & Share via Email
                </button>
            </div>
        </div>
    </div>
)}

        </>
    );
}
