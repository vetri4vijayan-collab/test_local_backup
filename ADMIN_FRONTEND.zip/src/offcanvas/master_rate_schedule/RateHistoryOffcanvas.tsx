import OffCanvas from "../../components/OffCanvas";
import {
    RateItem,
} from "../../types/rateSchedule";
import {
    fmtJmd,
} from "../../data/seedRateSchedule";

import {
    SpinnerGapIcon,
} from "@phosphor-icons/react";

interface RateHistoryItem {
    rate: number;
    effectiveDate: string;
    updatedAt: string;
    updatedBy?: string;
}

interface RateHistoryOffCanvasProps {
    row:
        | (RateItem & {
              history?: RateHistoryItem[];
          })
        | null;

    onClose: () => void;

    loading?: boolean;

    error?: string;
}

function formatDateTime(
    value: string,
): string {
    if (!value) {
        return "—";
    }

    const parsed =
        new Date(value);

    if (
        Number.isNaN(
            parsed.getTime(),
        )
    ) {
        return value;
    }

    return parsed.toLocaleString(
        undefined,
        {
            year: "numeric",
            month: "short",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
        },
    );
}

function formatEffectiveDate(
    value: string,
): string {
    if (!value) {
        return "—";
    }

    const parsed =
        new Date(value);

    if (
        Number.isNaN(
            parsed.getTime(),
        )
    ) {
        return value;
    }

    return parsed.toLocaleDateString(
        undefined,
        {
            year: "numeric",
            month: "short",
            day: "2-digit",
        },
    );
}


function normalizeHistory(
    row:
        | (RateItem & {
              history?: RateHistoryItem[];
          })
        | null,
): RateHistoryItem[] {
    if (!row) {
        return [];
    }

    if (
        !Array.isArray(
            row.history,
        )
    ) {
        return [];
    }

    return row.history
        .filter(
            (item) =>
                item &&
                typeof item ===
                    "object",
        )
        .map(
            (item) => ({
                rate:
                    Number.isFinite(
                        Number(
                            item.rate,
                        ),
                    )
                        ? Number(
                              item.rate,
                          )
                        : 0,

                effectiveDate:
                    String(
                        item.effectiveDate ||
                            "",
                    ),

                updatedAt:
                    String(
                        item.updatedAt ||
                            "",
                    ),

                updatedBy:
                    item.updatedBy
                        ? String(
                              item.updatedBy,
                          )
                        : "",
            }),
        )
        .sort(
            (a, b) => {
            const dateA =
                new Date(
                    a.effectiveDate,
                ).getTime();

            const dateB =
                new Date(
                    b.effectiveDate,
                ).getTime();

            if (
                Number.isFinite(
                    dateA,
                ) &&
                Number.isFinite(
                    dateB,
                ) &&
                dateA !== dateB
            ) {
                return (
                    dateB -
                    dateA
                );
            }

            const loggedA =
                new Date(
                    a.updatedAt,
                ).getTime();

            const loggedB =
                new Date(
                    b.updatedAt,
                ).getTime();

            if (
                Number.isFinite(
                    loggedA,
                ) &&
                Number.isFinite(
                    loggedB,
                )
            ) {
                return (
                    loggedB -
                    loggedA
                );
            }

                return 0;
            },
        );
}

export default function RateHistoryOffCanvas({
    row,
    onClose,
    loading = false,
    error = "",
}: RateHistoryOffCanvasProps) {
    const history =
        normalizeHistory(
            row,
        );

    return (
        <OffCanvas
            isOpen={!!row}
            onClose={onClose}
            title="Rate History"
            subtitle={
                row
                    ? `${row.code} · ${row.description}`
                    : ""
            }
        >
            {row && (
                <div className="space-y-3">
                    {loading ? (
                        <div className="flex min-h-[220px] items-center justify-center">
                            <div className="flex flex-col items-center gap-3 text-slate-400">
                                <SpinnerGapIcon
                                    size={
                                        26
                                    }
                                    className="animate-spin text-red-600"
                                    weight="bold"
                                />

                                <p className="text-xs font-semibold">
                                    Loading rate history...
                                </p>
                            </div>
                        </div>
                    ) : error ? (
                        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-5">
                            <p className="text-sm font-semibold text-red-700">
                                Unable to load rate history.
                            </p>

                            <p className="mt-1 text-xs text-red-600">
                                {error}
                            </p>
                        </div>
                    ) : history.length >
                      0 ? (
                        history.map(
                            (
                                item,
                                index,
                            ) => (
                                <div
                                    key={`${item.effectiveDate}-${item.updatedAt}-${index}`}
                                    className="rounded-xl border border-slate-100 bg-slate-50/60 p-4"
                                >
                                    <div className="flex items-center justify-between gap-3">
                                        <span className="font-bold text-slate-900">
                                            {fmtJmd(
                                                item.rate,
                                            )}
                                        </span>

                                        {index ===
                                            0 && (
                                            <span className="shrink-0 rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-black uppercase tracking-wide text-red-600">
                                                Current
                                            </span>
                                        )}
                                    </div>

                                    <div className="mt-1.5 flex flex-col gap-1 text-xs text-slate-400 sm:flex-row sm:items-center sm:justify-between">
                                        <span>
                                            Effective{" "}
                                            {formatEffectiveDate(
                                                item.effectiveDate,
                                            )}
                                        </span>

                                        <span className="break-words">
                                            Logged{" "}
                                            {formatDateTime(
                                                item.updatedAt,
                                            )}

                                            {item.updatedBy ? (
                                                <>
                                                    {" "}
                                                    ·{" "}
                                                    {
                                                        item.updatedBy
                                                    }
                                                </>
                                            ) : null}
                                        </span>
                                    </div>
                                </div>
                            ),
                        )
                    ) : (
                        <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-8 text-center">
                            <p className="text-sm font-semibold text-slate-600">
                                No rate history available.
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                Historical entries will appear here after the rate is created or changed.
                            </p>
                        </div>
                    )}
                </div>
            )}
        </OffCanvas>
    );
}