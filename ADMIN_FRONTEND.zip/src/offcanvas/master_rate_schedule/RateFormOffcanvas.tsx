import {
    useEffect,
    useMemo,
    useState,
} from "react";

import OffCanvas from "../../components/OffCanvas";
import Field from "../../components/Field";
import Select from "react-select";
import ToggleSwitch from "../../components/ToggleSwitch";
import Button from "../../components/Button";

import {
    RateFormValues,
} from "../../types/rateSchedule";

import {
    getSelectStyles,
} from "../../utils/selectStyles";

import api from "../../api/axios";

/*
|--------------------------------------------------------------------------
| Types
|--------------------------------------------------------------------------
*/

interface RateFormOffCanvasProps {
    isOpen: boolean;
    isEditing: boolean;
    form: RateFormValues;
    onChange: (
        form: RateFormValues,
    ) => void;
    onClose: () => void;
    onSave: () => void;
}

interface SelectOption {
    value: string;
    label: string;
}

interface ApiResponse<T = unknown> {
    success?: boolean;
    message?: string;
    data?: T;
}

interface CategoryItem {
    id: string;
    categoryType: string;
    category: string;
    description: string;
    status: boolean;
}

interface UnitItem {
    id: string;
    name: string;
    description: string;
    status: boolean;
}

/*
|--------------------------------------------------------------------------
| Endpoints
|--------------------------------------------------------------------------
*/

const CATEGORY_ENDPOINT =
    "/master-rates/categories";

const COMMON_ENDPOINT =
    "/settings/common";

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function normalizeCategory(
    value: unknown,
): CategoryItem | null {
    if (
        !value ||
        typeof value !==
            "object"
    ) {
        return null;
    }

    const item =
        value as Record<
            string,
            unknown
        >;

    const id =
        String(
            item.id ??
                item._id ??
                "",
        ).trim();

    if (!id) {
        return null;
    }

    return {
        id,

        categoryType:
            String(
                item.categoryType ??
                    "",
            ),

        category:
            String(
                item.category ??
                    "",
            ),

        description:
            String(
                item.description ??
                    "",
            ),

        status:
            Boolean(
                item.status,
            ),
    };
}

function normalizeUnit(
    value: unknown,
): UnitItem | null {
    if (
        !value ||
        typeof value !==
            "object"
    ) {
        return null;
    }

    const item =
        value as Record<
            string,
            unknown
        >;

    const id =
        String(
            item.id ??
                item._id ??
                "",
        ).trim();

    if (!id) {
        return null;
    }

    return {
        id,

        name:
            String(
                item.name ??
                    "",
            ),

        description:
            String(
                item.description ??
                    "",
            ),

        status:
            Boolean(
                item.status,
            ),
    };
}

function getArrayData<T>(
    response: ApiResponse<
        T[]
    >,
): T[] {
    return Array.isArray(
        response?.data,
    )
        ? response.data
        : [];
}

function assertApiSuccess(
    response: {
        data?: ApiResponse<unknown>;
    },
    fallback: string,
) {
    if (
        response?.data?.success ===
        false
    ) {
        throw new Error(
            response.data.message ||
                fallback,
        );
    }
}

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/

export default function RateFormOffCanvas({
    isOpen,
    isEditing,
    form,
    onChange,
    onClose,
    onSave,
}: RateFormOffCanvasProps) {
    const [
        categories,
        setCategories,
    ] = useState<CategoryItem[]>(
        [],
    );

    const [
        units,
        setUnits,
    ] = useState<UnitItem[]>(
        [],
    );

    const [
        loadingOptions,
        setLoadingOptions,
    ] = useState(false);

    const [
        optionsError,
        setOptionsError,
    ] = useState("");

    /*
    |--------------------------------------------------------------------------
    | Load Master Data
    |--------------------------------------------------------------------------
    */

    useEffect(() => {
        if (!isOpen) {
            return;
        }

        let cancelled =
            false;

        async function loadOptions() {
            setLoadingOptions(
                true,
            );

            setOptionsError(
                "",
            );

            try {
                const [
                    categoryResponse,
                    unitResponse,
                ] =
                    await Promise.all([
                        api.get<
                            ApiResponse<
                                unknown[]
                            >
                        >(
                            `${CATEGORY_ENDPOINT}/active`,
                        ),

                        api.get<
                            ApiResponse<
                                unknown[]
                            >
                        >(
                            COMMON_ENDPOINT,
                            {
                                params: {
                                    type:
                                        "unit",
                                    page: 1,
                                    limit: 100,
                                },
                            },
                        ),

                    ]);

                if (
                    cancelled
                ) {
                    return;
                }

                assertApiSuccess(
                    categoryResponse,
                    "Unable to load master rate categories.",
                );

                assertApiSuccess(
                    unitResponse,
                    "Unable to load units.",
                );

                const fetchedCategories =
                    getArrayData(
                        categoryResponse.data,
                    )
                        .map(
                            normalizeCategory,
                        )
                        .filter(
                            (
                                item,
                            ): item is CategoryItem =>
                                item !==
                                null,
                        );

                const fetchedUnits =
                    getArrayData(
                        unitResponse.data,
                    )
                        .map(
                            normalizeUnit,
                        )
                        .filter(
                            (
                                item,
                            ): item is UnitItem =>
                                item !==
                                null,
                        )
                        .filter(
                            (item) =>
                                item.status ||
                                item.name
                                    .trim()
                                    .toLowerCase() ===
                                    form.unit
                                        .trim()
                                        .toLowerCase(),
                        );

                setCategories(
                    fetchedCategories,
                );

                setUnits(
                    fetchedUnits,
                );
            } catch (error) {
                if (
                    cancelled
                ) {
                    return;
                }

                const axiosError =
                    error as {
                        response?: {
                            data?: {
                                message?: string;
                            };
                        };
                        message?: string;
                    };

                setOptionsError(
                    axiosError
                        ?.response
                        ?.data
                        ?.message ||
                        axiosError?.message ||
                        "Unable to load rate master data.",
                );
            } finally {
                if (
                    !cancelled
                ) {
                    setLoadingOptions(
                        false,
                    );
                }
            }
        }

        void loadOptions();

        return () => {
            cancelled =
                true;
        };
    }, [isOpen]);

    /*
    |--------------------------------------------------------------------------
    | Category Options
    |--------------------------------------------------------------------------
    |
    | Every active category is available. The category master owns the
    | category type, so selecting a category automatically fills the
    | hidden category type value used by the API.
    |
    |--------------------------------------------------------------------------
    */

    const categoryOptions =
        useMemo(() =>
            categories.map((item) => ({
                value: item.id,
                label: item.category,
            })),
        [categories],
    );

    /*
    |--------------------------------------------------------------------------
    | Unit Options
    |--------------------------------------------------------------------------
    */

    const unitOptions =
        useMemo(
            () =>
                units.map(
                    (
                        item,
                    ) => ({
                        value:
                            item.name,
                        label:
                            item.name,
                    }),
                ),
            [units],
        );

    /*
    |--------------------------------------------------------------------------
    | Category Change
    |--------------------------------------------------------------------------
    */

    function handleCategoryChange(
        option: SelectOption | null,
    ) {
        const selectedCategory = categories.find(
            (item) => item.id === option?.value,
        );

        onChange({
            ...form,
            category: selectedCategory?.category ?? "",
            categorytype:
                selectedCategory?.categoryType ?? "",
        });
    }

    /*
    |--------------------------------------------------------------------------
    | Unit Change
    |--------------------------------------------------------------------------
    */

    function handleUnitChange(
        option:
            | SelectOption
            | null,
    ) {
        onChange({
            ...form,

            unit:
                option?.value ??
                "",
        });
    }

    const canSave =
        !loadingOptions &&
        categoryOptions.length > 0 &&
        Boolean(
            form.category.trim(),
        ) &&
        Boolean(
            form.subcategory.trim(),
        ) &&
        Boolean(
            form.description.trim(),
        ) &&
        Boolean(
            form.unit.trim(),
        ) &&
        Boolean(
            form.standardRate.trim(),
        ) &&
        Boolean(
            form.effectiveDate,
        );

    /*
    |--------------------------------------------------------------------------
    | Render
    |--------------------------------------------------------------------------
    */

    return (
        <OffCanvas
            isOpen={
                isOpen
            }
            onClose={
                onClose
            }
            title={
                isEditing
                    ? "Edit Rate"
                    : "Add New Rate"
            }
            subtitle={
                isEditing
                    ? "Update this line item"
                    : "Add a line item to the master rate schedule"
            }
            footer={
                <div className="flex justify-end gap-2">
                    <Button
                        variant="outline"
                        onClick={
                            onClose
                        }
                        disabled={
                            loadingOptions
                        }
                    >
                        Cancel
                    </Button>

                    <Button
                        onClick={
                            onSave
                        }
                        disabled={
                            !canSave
                        }
                    >
                        {isEditing
                            ? "Save Changes"
                            : "Add Rate"}
                    </Button>
                </div>
            }
        >
            <div className="space-y-5">
                {/* ==========================================================
                 * Master Data Error
                 * ======================================================== */}

                {optionsError && (
                    <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2.5">
                        <p className="text-xs font-semibold text-red-600">
                            {
                                optionsError
                            }
                        </p>
                    </div>
                )}

                {!loadingOptions &&
                    !optionsError &&
                    categoryOptions.length === 0 && (
                        <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5">
                            <p className="text-xs font-semibold text-amber-700">
                                No active rate categories are available. Add a Master Rate Category first.
                            </p>
                        </div>
                    )}

                {/* ==========================================================
                 * Category
                 * ======================================================== */}

                <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Category

                        <span className="ml-1 text-red-500">
                            *
                        </span>
                    </label>

                    <Select<SelectOption>
                        options={
                            categoryOptions
                        }
                        value={
                            categoryOptions.find(
                                (option) => {
                                    const selected =
                                        categories.find(
                                            (item) =>
                                                item.id ===
                                                option.value,
                                        );

                                    return (
                                        selected?.category
                                            .trim()
                                            .toLowerCase() ===
                                            form.category
                                                .trim()
                                                .toLowerCase() &&
                                        selected?.categoryType
                                            .trim()
                                            .toLowerCase() ===
                                            form.categorytype
                                                .trim()
                                                .toLowerCase()
                                    );
                                },
                            ) ?? null
                        }
                        onChange={
                            handleCategoryChange
                        }
                        placeholder={
                            loadingOptions
                                ? "Loading categories..."
                                : "Select Category"
                        }
                        styles={
                            getSelectStyles()
                        }
                        isSearchable={
                            true
                        }
                        isClearable={
                            true
                        }
                        isLoading={
                            loadingOptions
                        }
                        isDisabled={
                            loadingOptions
                        }
                        noOptionsMessage={() =>
                            "No active categories available"
                        }
                    />
                </div>

                {/* ==========================================================
                 * Module
                 * ======================================================== */}

                <Field
                    label="Module"
                    type="text"
                    value={
                        form.subcategory
                    }
                    onChange={(
                        event,
                    ) =>
                        onChange({
                            ...form,
                            subcategory:
                                event
                                    .target
                                    .value,
                        })
                    }
                    placeholder="e.g. Trenching"
                />

                {/* ==========================================================
                 * Description
                 * ======================================================== */}

                <Field
                    label="Description"
                    type="textarea"
                    rows={
                        3
                    }
                    value={
                        form.description
                    }
                    onChange={(
                        event,
                    ) =>
                        onChange({
                            ...form,
                            description:
                                event
                                    .target
                                    .value,
                        })
                    }
                    placeholder="e.g. Trenching in Soft Soil (450mm depth)"
                />

                {/* ==========================================================
                 * Unit
                 * ======================================================== */}

                <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Unit of Measure

                        <span className="ml-1 text-red-500">
                            *
                        </span>
                    </label>

                    <Select<SelectOption>
                        options={
                            unitOptions
                        }
                        value={
                            unitOptions.find(
                                (
                                    option,
                                ) =>
                                    option.value ===
                                    form.unit,
                            ) ??
                            null
                        }
                        onChange={
                            handleUnitChange
                        }
                        placeholder={
                            loadingOptions
                                ? "Loading Units..."
                                : "Select Unit"
                        }
                        styles={
                            getSelectStyles()
                        }
                        isSearchable={
                            true
                        }
                        isClearable={
                            true
                        }
                        isLoading={
                            loadingOptions
                        }
                        isDisabled={
                            loadingOptions
                        }
                        noOptionsMessage={() =>
                            "No active units available"
                        }
                    />
                </div>

                {/* ==========================================================
                 * Standard Rate
                 * ======================================================== */}

                <Field
                    label="Standard Rate (JMD)"
                    type="number"
                    value={
                        form.standardRate
                    }
                    onChange={(
                        event,
                    ) =>
                        onChange({
                            ...form,
                            standardRate:
                                event
                                    .target
                                    .value,
                        })
                    }
                    placeholder="e.g. 1200"
                />

                {/* ==========================================================
                 * Effective Date
                 * ======================================================== */}

                <Field
                    label="Effective Date"
                    type="date"
                    value={
                        form.effectiveDate
                    }
                    onChange={(
                        event,
                    ) =>
                        onChange({
                            ...form,
                            effectiveDate:
                                event
                                    .target
                                    .value,
                        })
                    }
                />

                {/* ==========================================================
                 * Status
                 * ======================================================== */}

                <div>
                    <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Status
                    </span>

                    <div className="flex items-center gap-3 rounded-lg border border-slate-200 px-3.5 py-3">
                        <ToggleSwitch
                            checked={
                                form.status ===
                                "active"
                            }
                            onChange={(
                                value,
                            ) =>
                                onChange({
                                    ...form,
                                    status:
                                        value
                                            ? "active"
                                            : "inactive",
                                })
                            }
                            srLabel="Toggle rate status"
                        />

                        <span className="text-sm font-semibold text-slate-700">
                            {form.status ===
                            "active"
                                ? "Active"
                                : "Inactive"}
                        </span>
                    </div>
                </div>
            </div>
        </OffCanvas>
    );
}