import {
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Select, {
  SingleValue,
} from "react-select";
import Field from "../../components/Field";
import Button from "../../components/Button";
import { getSelectStyles } from "../../utils/selectStyles";
import {
  EyeIcon,
  EyeSlashIcon,
  WarningCircleIcon,
  CheckCircleIcon,
  CircleNotchIcon,
} from "@phosphor-icons/react";
import api, {
  getApiErrorMessage,
} from "../../api/axios";
import {
  TeamMember,
  UserRole,
} from "../../types/user";

interface AddMemberFormProps {
  member?: TeamMember | null;
  onSubmit: (member: TeamMember) => void | Promise<void>;
  onCancel: () => void;
}

interface ApiRole {
  id?: string;
  _id?: string;
  key?: string;
  code?: string;
  name?: string;
  userType?: string;
  realm?: string;
  allowedUserTypes?: string[];
  status?: string;
  active?: boolean;
  isSystem?: boolean;
  system?: boolean;
}

interface RolesResponse {
  success?: boolean;
  message?: string;
  data?:
    | ApiRole[]
    | {
        data?: ApiRole[];
        pagination?: unknown;
      };
}

interface EmailAvailabilityResponse {
  success?: boolean;
  message?: string;
  data?: {
    available?: boolean;
  };
}

interface RoleOption {
  value: string;
  label: string;
  id: string;
}

const EMPTY_FORM = {
  name: "",
  email: "",
  password: "",
  role: "",
  status: "Active" as const,
  hourlyrate: "",
};

const MAX_PROFILE_IMAGE_BYTES = 2 * 1024 * 1024;

function getRoleId(role: ApiRole): string {
  return String(role.id || role._id || "").trim();
}

function getRoleName(role: ApiRole): string {
  return String(
    role.name ||
      role.key ||
      role.code ||
      "",
  ).trim();
}

function isUsableRole(role: ApiRole): boolean {
  const roleStatus = String(
    role.status || "",
  ).trim().toLowerCase();

  const allowedUserTypes = Array.isArray(
    role.allowedUserTypes,
  )
    ? role.allowedUserTypes
        .map((value) =>
          String(value).trim().toLowerCase(),
        )
        .filter(Boolean)
    : [];

  const roleType = String(
    role.userType ||
      role.realm ||
      "",
  ).trim().toLowerCase();

  const allowsInternalOrAdmin =
    allowedUserTypes.length > 0
      ? allowedUserTypes.some((value) =>
          value === "admin" || value === "internal",
        )
      : !roleType ||
        roleType === "admin" ||
        roleType === "internal" ||
        roleType === "both";

  return (
    Boolean(getRoleId(role) && getRoleName(role)) &&
    role.active !== false &&
    roleStatus !== "inactive" &&
    allowsInternalOrAdmin
  );
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
    value.trim(),
  );
}

function isAllowedProfileImage(file: File): boolean {
  const allowedMimeTypes = new Set([
    "image/jpeg",
    "image/png",
    "image/webp",
  ]);

  return allowedMimeTypes.has(
    file.type.toLowerCase(),
  );
}

export default function AddMemberForm({
  member,
  onSubmit,
  onCancel,
}: AddMemberFormProps) {
  const isEditMode = Boolean(member);

  const [name, setName] = useState(
    member?.name || EMPTY_FORM.name,
  );
  const [hourlyrate, setHourlyRate] = useState(
    member?.hourlyrate || EMPTY_FORM.hourlyrate,
  );
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState(
    member?.email || EMPTY_FORM.email,
  );
  const [password, setPassword] = useState(EMPTY_FORM.password);
  const [role, setRole] = useState<string>(
    member?.role || EMPTY_FORM.role,
  );
  const [status, setStatus] = useState<
    "Active" | "Inactive"
  >(
    member?.status || EMPTY_FORM.status,
  );

  const [roles, setRoles] = useState<RoleOption[]>([]);
  const [loadingRoles, setLoadingRoles] = useState(true);
  const [rolesError, setRolesError] = useState("");
  const [validationError, setValidationError] = useState("");

  const [profileImageFile, setProfileImageFile] =
    useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] =
    useState<string | null>(member?.imageUrl || null);
  const [removeProfileImage, setRemoveProfileImage] =
    useState(false);

  const [checkingEmail, setCheckingEmail] = useState(false);
  const [emailAvailable, setEmailAvailable] = useState<
    boolean | null
  >(null);
  const [emailCheckError, setEmailCheckError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const emailRequestId = useRef(0);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();

    const loadRoles = async () => {
      setLoadingRoles(true);
      setRolesError("");

      try {
        const response = await api.get<RolesResponse>(
          "/settings/roles",
          { signal: controller.signal },
        );

        if (response.data?.success === false) {
          throw new Error(
            response.data.message ||
              "Unable to load available roles.",
          );
        }

        const responseData = response.data?.data;
        const apiRoles = Array.isArray(responseData)
          ? responseData
          : Array.isArray(responseData?.data)
            ? responseData.data
            : [];

        const options = apiRoles
          .filter(isUsableRole)
          .map((item) => ({
            id: getRoleId(item),
            value: getRoleName(item),
            label: getRoleName(item),
          }))
          .filter(
            (option, index, array) =>
              array.findIndex(
                (candidate) =>
                  candidate.id === option.id,
              ) === index,
          )
          .sort((a, b) =>
            a.label.localeCompare(b.label),
          );

        if (cancelled) {
          return;
        }

        setRoles(options);

        setRole((current) => {
          if (
            current &&
            options.some(
              (option) => option.value === current,
            )
          ) {
            return current;
          }

          if (
            member?.role &&
            options.some(
              (option) => option.value === member.role,
            )
          ) {
            return member.role;
          }

          // Never silently assign the first role to a new user.
          return "";
        });
      } catch (error) {
        if (
          cancelled ||
          (error instanceof DOMException &&
            error.name === "AbortError")
        ) {
          return;
        }

        if (cancelled) {
          return;
        }

        setRolesError(
          getApiErrorMessage(
            error,
            "Unable to load available roles.",
          ),
        );
      } finally {
        if (!cancelled) {
          setLoadingRoles(false);
        }
      }
    };

    void loadRoles();

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [member?.role]);

  useEffect(() => {
    setName(member?.name || EMPTY_FORM.name);
    setHourlyRate(
      member?.hourlyrate || EMPTY_FORM.hourlyrate,
    );
    setEmail(member?.email || EMPTY_FORM.email);
    setPassword(EMPTY_FORM.password);
    setRole(member?.role || EMPTY_FORM.role);
    setStatus(member?.status || EMPTY_FORM.status);
    setShowPassword(false);
    setValidationError("");
    setProfileImageFile(null);
    setProfileImagePreview(member?.imageUrl || null);
    setRemoveProfileImage(false);
    setEmailAvailable(null);
    setEmailCheckError("");
    setCheckingEmail(false);
  }, [member]);

  useEffect(() => {
    if (!profileImageFile) {
      return;
    }

    const objectUrl = URL.createObjectURL(profileImageFile);
    setProfileImagePreview(objectUrl);

    return () => URL.revokeObjectURL(objectUrl);
  }, [profileImageFile]);

  const checkEmailAvailability = async (
    candidateEmail: string,
  ): Promise<boolean> => {
    const normalizedEmail = candidateEmail.trim().toLowerCase();

    if (!isValidEmail(normalizedEmail)) {
      setEmailAvailable(null);
      setEmailCheckError("");
      return false;
    }

    const requestId = ++emailRequestId.current;
    const controller = new AbortController();

    setCheckingEmail(true);
    setEmailCheckError("");

    try {
      const response = await api.get<EmailAvailabilityResponse>(
        "/users/check-email",
        {
          params: {
            email: normalizedEmail,
            ...(member?.id
              ? { excludeUserId: member.id }
              : {}),
          },
          signal: controller.signal,
        },
      );

      if (requestId !== emailRequestId.current) {
        return false;
      }

      if (response.data?.success === false) {
        throw new Error(
          response.data.message ||
            "Unable to verify email availability.",
        );
      }

      const available =
        response.data?.data?.available === true;

      setEmailAvailable(available);

      if (!available) {
        setEmailCheckError(
          "This email address is already registered.",
        );
      }

      return available;
    } catch (error) {
      if (requestId !== emailRequestId.current) {
        return false;
      }

      if (
        error instanceof DOMException &&
        error.name === "AbortError"
      ) {
        return false;
      }

      setEmailAvailable(null);
      setEmailCheckError(
        getApiErrorMessage(
          error,
          "Unable to verify email availability.",
        ),
      );
      return false;
    } finally {
      if (requestId === emailRequestId.current) {
        setCheckingEmail(false);
      }
    }
  };

  const handleEmailChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const value = event.target.value;
    setEmail(value);
    setEmailAvailable(null);
    setEmailCheckError("");
    setValidationError("");
    emailRequestId.current += 1;
  };

  const handleEmailBlur = () => {
    if (isValidEmail(email)) {
      void checkEmailAvailability(email);
    }
  };

  const handleProfileImageChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0] || null;

    if (!file) {
      return;
    }

    if (!isAllowedProfileImage(file)) {
      setValidationError(
        "Please select a JPEG, PNG or WebP image.",
      );
      event.target.value = "";
      return;
    }

    if (file.size > MAX_PROFILE_IMAGE_BYTES) {
      setValidationError(
        "Profile image must be 2 MB or smaller.",
      );
      event.target.value = "";
      return;
    }

    setValidationError("");
    setRemoveProfileImage(false);
    setProfileImageFile(file);
  };

  const clearProfileImage = () => {
    setProfileImageFile(null);
    setProfileImagePreview(null);
    if (isEditMode && member?.imageUrl) {
      setRemoveProfileImage(true);
    }
  };

  const selectedRole = useMemo(
    () =>
      roles.find(
        (option) => option.value === role,
      ) || null,
    [roles, role],
  );

  const handleRoleChange = (
    option: SingleValue<RoleOption>,
  ) => {
    setRole(option?.value || "");
    setValidationError("");
  };

  const handleSubmit = async (
    event: React.FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();

    if (isSubmitting) {
      return;
    }

    setValidationError("");

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const enteredPassword = password;

    if (!trimmedName) {
      setValidationError("Full name is required.");
      return;
    }

    if (!isValidEmail(trimmedEmail)) {
      setValidationError("Enter a valid email address.");
      return;
    }

    if (!role) {
      setValidationError("Please select an active role.");
      return;
    }

    if (!isEditMode && !enteredPassword) {
      setValidationError(
        "Password is required when creating a user.",
      );
      return;
    }

    if (enteredPassword && enteredPassword.length < 8) {
      setValidationError(
        "Password must contain at least 8 characters.",
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const emailIsAvailable =
        emailAvailable === true &&
        trimmedEmail.toLowerCase() ===
          email.trim().toLowerCase();

      const available = emailIsAvailable
        ? true
        : await checkEmailAvailability(trimmedEmail);

      if (!available) {
        setValidationError(
          emailCheckError ||
            "This email address is already registered or could not be verified.",
        );
        return;
      }

      const updatedMember: TeamMember = {
        id: member?.id ?? "",
        name: trimmedName,
        email: trimmedEmail,
        password: enteredPassword,
        role: role as UserRole,
        status,
        hourlyrate: hourlyrate.trim(),
        department: member?.department || "",
        location: member?.location || "",
        privileges: member?.privileges || [],
        imageUrl: profileImagePreview,
        imageFile: profileImageFile,
        removeImage:
          removeProfileImage && !profileImageFile,
      };

      await onSubmit(updatedMember);
    } finally {
      setIsSubmitting(false);
    }
  };

  const hasNoRoles =
    !loadingRoles &&
    roles.length === 0 &&
    !rolesError;

  const formDisabled =
    loadingRoles ||
    hasNoRoles ||
    isSubmitting;

  return (
    <form
      onSubmit={handleSubmit}
      className="flex h-full flex-col"
      noValidate
    >
      <div className="flex-1 space-y-5 overflow-y-auto pr-1">
        {validationError && (
          <div className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-xs font-semibold text-red-700">
            <WarningCircleIcon
              size={16}
              className="mt-0.5 shrink-0"
            />
            <span>{validationError}</span>
          </div>
        )}

        {rolesError && (
          <div className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-xs font-semibold text-red-700">
            <WarningCircleIcon
              size={16}
              className="mt-0.5 shrink-0"
            />
            <span>{rolesError}</span>
          </div>
        )}

        {hasNoRoles && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs font-semibold text-amber-700">
            No active internal/admin roles are currently available. Create or activate a role from Roles &amp; Permissions first.
          </div>
        )}

        <Field
          label="Full Name"
          type="text"
          value={name}
          onChange={(event) => {
            setName(event.target.value);
            setValidationError("");
          }}
          placeholder="e.g. Priya Nair"
          required
          disabled={formDisabled}
        />

        <div>
          <Field
            label="Email Address"
            type="email"
            value={email}
            onChange={handleEmailChange}
            onBlur={handleEmailBlur}
            placeholder="name@projectflow.com"
            required
            disabled={formDisabled}
          />

          {checkingEmail && (
            <div className="mt-1.5 flex items-center gap-1.5 text-[11px] font-medium text-slate-400">
              <CircleNotchIcon
                size={13}
                className="animate-spin"
              />
              Checking email availability...
            </div>
          )}

          {!checkingEmail &&
            emailAvailable === true &&
            isValidEmail(email) && (
              <div className="mt-1.5 flex items-center gap-1.5 text-[11px] font-medium text-emerald-600">
                <CheckCircleIcon size={13} />
                Email address is available.
              </div>
            )}

          {!checkingEmail && emailCheckError && (
            <div className="mt-1.5 text-[11px] font-medium text-red-600">
              {emailCheckError}
            </div>
          )}
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            {isEditMode
              ? "Password"
              : "Default Password"}
          </label>

          <div className="relative">
            <Field
              label=""
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(event) => {
                setPassword(event.target.value);
                setValidationError("");
              }}
              placeholder={
                isEditMode
                  ? "Leave blank to keep current password"
                  : "Enter default password"
              }
              autoComplete="new-password"
              disabled={formDisabled}
            />

            <button
              type="button"
              onClick={() =>
                setShowPassword((previous) => !previous)
              }
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition-colors hover:text-slate-600 disabled:cursor-not-allowed disabled:opacity-50"
              aria-label={
                showPassword
                  ? "Hide password"
                  : "Show password"
              }
              disabled={formDisabled}
            >
              {showPassword ? (
                <EyeSlashIcon size={18} />
              ) : (
                <EyeIcon size={18} />
              )}
            </button>
          </div>

          {isEditMode && (
            <p className="mt-1.5 text-[11px] text-slate-400">
              Leave blank to keep the current password.
            </p>
          )}
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            Profile Image <span className="normal-case font-normal text-slate-300">(Optional)</span>
          </label>

          <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-3">
            <div className="flex items-center gap-3">
              {profileImagePreview ? (
                <img
                  src={profileImagePreview}
                  alt="Profile preview"
                  className="h-14 w-14 rounded-full object-cover ring-2 ring-white shadow-sm"
                />
              ) : (
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white text-xs font-bold text-slate-400 shadow-sm">
                  {name.trim().slice(0, 2).toUpperCase() || "U"}
                </div>
              )}

              <div className="min-w-0 flex-1">
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleProfileImageChange}
                  disabled={formDisabled}
                  className="block w-full text-xs text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-red-50 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-red-600 hover:file:bg-red-100 disabled:cursor-not-allowed disabled:opacity-60"
                />
                <p className="mt-1 text-[11px] text-slate-400">
                  JPEG, PNG or WebP • max 2 MB
                </p>
              </div>

              {profileImagePreview && (
                <button
                  type="button"
                  onClick={clearProfileImage}
                  disabled={formDisabled}
                  className="shrink-0 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Remove
                </button>
              )}
            </div>
          </div>
        </div>

        <Field
          label="Hourly Rate"
          type="text"
          value={hourlyrate}
          onChange={(event) =>
            setHourlyRate(event.target.value)
          }
          placeholder="e.g. $ 25"
          disabled={formDisabled}
        />

        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            Role
          </label>

          <Select<RoleOption>
            options={roles}
            value={selectedRole}
            onChange={handleRoleChange}
            isLoading={loadingRoles}
            isDisabled={formDisabled}
            isSearchable
            isClearable
            placeholder={
              loadingRoles
                ? "Loading roles..."
                : "Select a role..."
            }
            noOptionsMessage={() =>
              "No active roles available"
            }
            className="text-sm"
            styles={{
              ...getSelectStyles<RoleOption>(),
              menuPortal: (base) => ({
                ...base,
                zIndex: 100000,
              }),
            }}
            menuPortalTarget={
              typeof document !== "undefined"
                ? document.body
                : undefined
            }
            menuPosition="fixed"
          />
        </div>

        <div>
          <label className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-400">
            Status
          </label>

          <div className="flex gap-2 rounded-lg border border-slate-200 bg-slate-50 p-1">
            {(["Active", "Inactive"] as const).map(
              (item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setStatus(item)}
                  disabled={formDisabled}
                  className={`flex-1 rounded-md py-1.5 text-xs font-bold uppercase transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${
                    status === item
                      ? "bg-white text-red-600 shadow-sm"
                      : "text-slate-400 hover:text-slate-600"
                  }`}
                >
                  {item}
                </button>
              ),
            )}
          </div>
        </div>
      </div>

      <div className="mt-6 flex gap-3 border-t border-slate-100 pt-5">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={isSubmitting}
          className="flex-1"
        >
          Cancel
        </Button>

        <Button
          type="submit"
          variant="primary"
          className="flex-1"
          disabled={formDisabled || checkingEmail}
        >
          {isSubmitting
            ? "Saving..."
            : isEditMode
              ? "Update Member"
              : "Add Member"}
        </Button>
      </div>
    </form>
  );
}
