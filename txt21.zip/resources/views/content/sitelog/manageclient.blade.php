@extends('layouts/layoutMaster')

@section('title', 'Client')

@section('content')

<div id="clientlist">
  <div class="card rounded">
      <div class="d-flex justify-content-between p-3">
          <div class="d-flex gap-3 align-items-center">
              <i class="mdi mdi-office-building text-primary fs-4"></i>

              <div class="d-flex flex-column">
                  <label class="text-primary fw-bold mb-1 text-uppercase">Client</label>

                  <span class="text-muted fw-semibold">
                      Site Operations Management & Logs
                  </span>
              </div>
          </div>
          <div>
            <button
                type="button"
                class="btn btn-primary d-flex align-items-center gap-2"
                onclick="showAddClient()"
            >
                <i class="mdi mdi-plus"></i>
                Add Client
            </button>
          </div>
      </div>
  </div>

  <div class="card rounded shadow-sm mt-3">
      <div class="card-body p-4">
          <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
              <div class="position-relative" style="max-width: 500px; width: 100%;">
                  <i class="mdi mdi-magnify position-absolute top-50 start-0 translate-middle-y ms-3 text-muted fs-5"></i>
                  <input
                      type="search"
                      class="form-control ps-5 rounded"
                      placeholder="Search by client name, contact, GST, PAN, address..."
                  />
              </div>

              <div>
                  <span class="badge bg-label-primary px-3 py-2">
                      <i class="mdi mdi-account-multiple-outline me-1"></i>
                      Showing 3 client records
                  </span>
              </div>
          </div>

          <div class="table-responsive rounded">
              <table class="table border table-hover align-middle mb-0">
                  <thead class="table-light">
                      <tr>
                          <th class="text-dark text-uppercase fs-8">Client Name</th>
                          <th class="text-dark text-uppercase fs-8">Contact Person</th>
                          <th class="text-dark text-uppercase fs-8">Contact No & Email</th>
                          <th class="text-dark text-uppercase fs-8">Alternate Contact</th>
                          <th class="text-dark text-uppercase fs-8">Address</th>
                          <th class="text-dark text-uppercase fs-8">PAN / GST No</th>
                          <th class="text-dark text-uppercase fs-8">Status</th>
                          <th class="text-dark text-uppercase fs-8 text-center">Action</th>
                      </tr>
                  </thead>

                  <tbody>
                      <tr>
                          <td>
                              <div class="d-flex flex-column justify-content-between gap-2">
                                  <span class="fw-semibold text-dark fs-8">
                                      SPK And Co., - VF
                                  </span>
                                  <span class="badge rounded-pill bg-label-primary fs-8">
                                      CLI-SPK-01
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex align-items-center gap-3">
                                  <div>
                                      <label class="text-black fs-8">S. Nagarajan</label>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <i class="mdi mdi-phone-outline"></i>
                                    <span class="text-black fs-8">9080279827</span>
                                  </div>

                                  <div class="d-flex">
                                    <i class="mdi mdi-message-outline"></i>
                                    <span class="text-black fs-8">boomispk@gmail.com</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <span class="fw-semibold fs-7 text-black">Boominathan</span>
                                  <small class="text-muted">9842109876</small>
                              </div>
                          </td>

                          <td>
                              <span class="text-muted fs-8">
                                  87/2 G.N Chetty Road, N Cres Rd, near
                              </span>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">pan:</label>
                                    <span class="text-black fs-8">ABXFS5510P</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">gst:</label>
                                    <span class="text-black fs-8">33ABXFS5510P1ZG</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="form-check form-switch">
                                  <input
                                      class="form-check-input"
                                      type="checkbox"
                                      role="switch"
                                      id="clientStatus"
                                      checked
                                  >
                              </div>
                          </td>

                          <td class="text-center">
                              <div class="d-flex dropdown">
                                  <button
                                      type="button"
                                      class="btn"
                                      data-bs-toggle="modal"
                                      data-bs-target="#viewClientModal"
                                      onclick="showViewModal(
                                          'YCLI-SPK-01',
                                          'SPK And Co., - VF',
                                          'S. Nagarajan',
                                          '9080279827',
                                          'boomispk@gmail.com',
                                          'Boominathan',
                                          '9842109876',
                                          '87/2 G.N Chetty Road, N Cres Rd, near',
                                          '33ABXFS5510P1ZG',
                                          'ABXFS5510P'
                                      )"
                                  >
                                      <i class="mdi mdi-eye"></i>
                                  </button>
                                  <button
                                      class="btn"
                                      type="button"
                                      onclick="showUpdateClient(
                                          'CLI-SPK-01',
                                          'SPK And Co., - VF',
                                          'S. Nagarajan',
                                          '9080279827',
                                          'boomispk@gmail.com',
                                          'Boominathan',
                                          '9842109876',
                                          '87/2 G.N Chetty Road, N Cres Rd, near',
                                          '33ABXFS5510P1ZG',
                                          'ABXFS5510P'
                                      )"
                                  >
                                      <i class="mdi mdi-pencil"></i>
                                  </button>
                                  <button
                                      class="btn"
                                      type="button"
                                      data-bs-toggle="modal"
                                      data-bs-target="#deleteClientModal"
                                  >
                                      <i class="mdi mdi-trash-can-outline"></i>
                                  </button>
                              </div>
                          </td>
                      </tr>

                      <tr>
                          <td>
                              <div class="d-flex flex-column justify-content-between gap-2">
                                  <span class="fw-semibold text-dark fs-8">
                                      Chennai Metro Rail Limited (CMRL)
                                  </span>
                                  <span class="badge rounded-pill bg-label-primary fs-8">
                                      CLI-CMRL-02
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex align-items-center gap-3">
                                  <div>
                                      <label class="text-black fs-8">S. Ramanathan (Chief Engineer)</label>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <i class="mdi mdi-phone-outline"></i>
                                    <span class="text-black fs-8">9444012345</span>
                                  </div>

                                  <div class="d-flex">
                                    <i class="mdi mdi-message-outline"></i>
                                    <span class="text-black fs-8">s.ramanathan@cmrl.gov.in</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <span class="fw-semibold fs-7">V. Sundar</span>
                                  <small class="text-muted">9444054321</small>
                              </div>
                          </td>

                          <td>
                              <span class="text-muted fs-8">
                                  CMRL Depot, Admin Building, Koyam
                              </span>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">pan:</label>
                                    <span class="text-black fs-8">AAACC1234D</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">gst:</label>
                                    <span class="text-black fs-8">33AAACC1234D1Z2</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="form-check form-switch">
                                  <input
                                      class="form-check-input"
                                      type="checkbox"
                                      role="switch"
                                      id="clientStatus"
                                      checked
                                  >
                              </div>
                          </td>

                          <td class="text-center">
                              <div class="d-flex dropdown">
                                  <button
                                      type="button"
                                      class="btn"
                                      data-bs-toggle="modal"
                                      data-bs-target="#viewClientModal"
                                      onclick="showViewModal(
                                          'CLI-CMRL-02',
                                          'Chennai Metro Rail Limited (CMRL)',
                                          'S. Ramanathan (Chief Engineer)',
                                          '9444012345',
                                          's.ramanathan@cmrl.gov.in',
                                          'V. Sundar',
                                          '9444054321',
                                          'CMRL Depot, Admin Building, Koyam',
                                          '33AAACC1234D1Z2',
                                          'AAACC1234D'
                                      )"
                                  >
                                      <i class="mdi mdi-eye"></i>
                                  </button>
                                  <button
                                      class="btn"
                                      type="button"
                                      onclick="showUpdateClient(
                                          'CLI-CMRL-02',
                                          'Chennai Metro Rail Limited (CMRL)',
                                          'S. Ramanathan (Chief Engineer)',
                                          '9444012345',
                                          's.ramanathan@cmrl.gov.in',
                                          'V. Sundar',
                                          '9444054321',
                                          'CMRL Depot, Admin Building, Koyam',
                                          '33AAACC1234D1Z2',
                                          'AAACC1234D'
                                      )"
                                  >
                                      <i class="mdi mdi-pencil"></i>
                                  </button>

                                  <button
                                      class="btn"
                                      type="button"
                                      data-bs-toggle="modal"
                                      data-bs-target="#deleteClientModal"
                                  >
                                      <i class="mdi mdi-trash-can-outline"></i>
                                  </button>
                              </div>
                          </td>
                      </tr>

                      <tr>
                          <td>
                              <div class="d-flex flex-column justify-content-between gap-2">
                                  <span class="fw-semibold text-dark fs-8">
                                      Elysium Realty Developers
                                  </span>
                                  <span class="badge rounded-pill bg-label-primary fs-8">
                                      CLI-ELY-03
                                  </span>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex align-items-center gap-3">
                                  <div>
                                      <label class="text-black fs-8">Anand Varma (Project Director)</label>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <i class="mdi mdi-phone-outline"></i>
                                    <span class="text-black fs-8">9840167890</span>
                                  </div>

                                  <div class="d-flex">
                                    <i class="mdi mdi-message-outline"></i>
                                    <span class="text-black fs-8">a.varma@elysiumrealty.com</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <span class="fw-semibold fs-7">P. Rajesh</span>
                                  <small class="text-muted">9840111222</small>
                              </div>
                          </td>

                          <td>
                              <span class="text-muted fs-8">
                                  No 45, LB Road, Adyar, Chennai, Tamil
                              </span>
                          </td>

                          <td>
                              <div class="d-flex flex-column">
                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">pan:</label>
                                    <span class="text-black fs-8">AABCE9876F</span>
                                  </div>

                                  <div class="d-flex">
                                    <label class="text-muted text-uppercase fs-8 me-1">gst:</label>
                                    <span class="text-black fs-8">33AABCE9876F1Z8</span>
                                  </div>
                              </div>
                          </td>

                          <td>
                              <div class="form-check form-switch">
                                  <input
                                      class="form-check-input"
                                      type="checkbox"
                                      role="switch"
                                      id="clientStatus"
                                      checked
                                  >
                              </div>
                          </td>

                          <td class="text-center">
                              <div class="d-flex dropdown">
                                  <button
                                      type="button"
                                      class="btn"
                                      data-bs-toggle="modal"
                                      data-bs-target="#viewClientModal"
                                      onclick="showViewModal(
                                          'CLI-ELY-03',
                                          'Elysium Realty Developers',
                                          'Anand Varma (Project Director)',
                                          '9840167890',
                                          'a.varma@elysiumrealty.com',
                                          'P. Rajesh',
                                          '9840111222',
                                          'No 45, LB Road, Adyar, Chennai, Tamil',
                                          '33AABCE9876F1Z8',
                                          'AABCE9876F'
                                      )"
                                  >
                                      <i class="mdi mdi-eye"></i>
                                  </button>
                                  <button
                                      class="btn"
                                      type="button"
                                      onclick="showUpdateClient(
                                          'CLI-ELY-03',
                                          'Elysium Realty Developers',
                                          'Anand Varma (Project Director)',
                                          '9840167890',
                                          'a.varma@elysiumrealty.com',
                                          'P. Rajesh',
                                          '9840111222',
                                          'No 45, LB Road, Adyar, Chennai, Tamil',
                                          '33AABCE9876F1Z8',
                                          'AABCE9876F'
                                      )"
                                  >
                                      <i class="mdi mdi-pencil"></i>
                                  </button>

                                  <button
                                      class="btn"
                                      type="button"
                                      data-bs-toggle="modal"
                                      data-bs-target="#deleteClientModal"
                                  >
                                      <i class="mdi mdi-trash-can-outline"></i>
                                  </button>
                              </div>
                          </td>
                      </tr>
                  </tbody>
              </table>
          </div>
      </div>
  </div>
</div>

<!-- add client -->
<div id="addClient" class="d-none">
  <div class="card rounded shadow-sm mt-3">
    <div class="card-header bg-white border-bottom py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <button
                    type="button"
                    class="btn"
                    title="Back"
                    onclick="showClientList()"
                >
                    <i class="mdi mdi-chevron-double-left"></i>
                </button>

                <div>
                    <h6 class="mb-0 text-dark fw-bold text-uppercase">
                        Add Client
                    </h6>
                </div>
            </div>

            <div>
                <span class="">
                    System Code: CLI-NEW-660
                </span>
            </div>

        </div>
    </div>

    <div class="card-body p-4">
        <div class="row g-4">
            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Client Name
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. SPK and Co."
                />

                <small class="text-muted">
                    Enter the registered client name.
                </small>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Contact Person
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. S.Nagarajan"
                />
            </div>

            <!-- Contact Number -->
            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Contact No
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="tel"
                    class="form-control"
                    placeholder="e.g. 98765 43210"
                />
            </div>

            <!-- Email -->
            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Email
                </label>

                <input
                    type="email"
                    class="form-control"
                    placeholder="e.g. client@example.com"
                />
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Alternate Contact Person
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. Boominathan"
                />
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Alternate Contact No
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. phone or mobile"
                />
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Address
                </label>

                <textarea
                    class="form-control"
                    rows="1"
                    placeholder="Enter client address"
                ></textarea>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    GST Number
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. 33ABCDE1234F1Z5"
                />
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    PAN Number
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. ABCDE1234F"
                />
            </div>
        </div>
    </div>

    <div class="card-footer bg-white border-top d-flex justify-content-end gap-2 py-3">

      <button
          type="button"
          class="btn btn-outline-secondary"
          onclick="showClientList()"
      >
          Cancel
      </button>

      <button
          type="button"
          class="btn btn-primary"
      >
          Save Client
      </button>
    </div>
  </div>
</div>

<!-- update client -->
<div id="updateClient" class="d-none">
    <div class="card rounded shadow-sm mt-3">
        <div class="card-header bg-white border-bottom py-3">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-2">
                    <button
                        type="button"
                        class="btn"
                        title="Back"
                        onclick="showClientList()"
                    >
                        <i class="mdi mdi-chevron-double-left"></i>
                    </button>

                    <div class="mt-3">
                      <h4>Update Client</h4>
                    </div>
                </div>

                <div>
                    <span id="updateSystemCode">
                        System Code: CLI-SPK-01
                    </span>
                </div>

            </div>
        </div>

        <div class="card-body p-4">
            <div class="row g-4">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Client Name
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        id="updateClientName"
                        class="form-control"
                        placeholder="e.g. SPK and Co."
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Contact Person
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        id="updateContactPerson"
                        class="form-control"
                        placeholder="e.g. S.Nagarajan"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Contact No
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="tel"
                        id="updateContactNo"
                        class="form-control"
                        placeholder="e.g. 98765 43210"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Email
                    </label>

                    <input
                        type="email"
                        id="updateEmail"
                        class="form-control"
                        placeholder="e.g. client@example.com"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Alternate Contact Person
                    </label>

                    <input
                        type="text"
                        id="updateAlternateContactPerson"
                        class="form-control"
                        placeholder="e.g. Boominathan"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Alternate Contact No
                    </label>

                    <input
                        type="text"
                        id="updateAlternateContactNo"
                        class="form-control"
                        placeholder="e.g. phone or mobile"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Address
                    </label>

                    <textarea
                        id="updateAddress"
                        class="form-control"
                        rows="1"
                        placeholder="Enter client address"
                    ></textarea>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        GST Number
                    </label>

                    <input
                        type="text"
                        id="updateGst"
                        class="form-control"
                        placeholder="e.g. 33ABCDE1234F1Z5"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        PAN Number
                    </label>

                    <input
                        type="text"
                        id="updatePan"
                        class="form-control"
                        placeholder="e.g. ABCDE1234F"
                    />
                </div>
            </div>
        </div>

        <div class="card-footer bg-white border-top d-flex justify-content-end gap-2 py-3">
            <button
                type="button"
                class="btn btn-outline-secondary"
                onclick="showClientList()"
            >
                Cancel
            </button>
            <button
                type="button"
                class="btn btn-primary"
                onclick="saveClientUpdate()"
            >
                Update Client
            </button>
        </div>
    </div>
</div>

<!-- View Client Modal -->
<div class="modal fade" id="viewClientModal" tabindex="-1" aria-labelledby="viewClientModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-between align-items-center border-bottom">
                <div class="d-flex flex-column mb-3">
                    <h5 class="modal-title" id="viewClientModalLabel">
                        Client Details
                    </h5>

                    <small class="text-muted">
                        System Code:
                        <span id="viewSystemCode" class="fw-bold"></span>
                    </small>
                </div>

                <div class="mb-3">
                  <button
                      type="button"
                      class="btn-close mb-3"
                      data-bs-dismiss="modal"
                      aria-label="Close">
                  </button>
                </div>
            </div>

            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Client Name:
                        </label>

                        <div class="text-black">
                            <span id="viewClientName">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Contact Person:
                        </label>

                        <div class="text-black">
                            <span id="viewContactPerson">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Contact Number:
                        </label>

                        <div class="text-black">
                            <span id="viewContactNo">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Email:
                        </label>

                        <div class="text-black">
                            <span id="viewEmail">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Alternate Contact Person:
                        </label>

                        <div class="text-black">
                            <span id="viewAlternateContactPerson">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Alternate Contact Number:
                        </label>

                        <div class="text-black">
                            <span id="viewAlternateContactNo">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            GST Number:
                        </label>

                        <div class="text-black">
                            <span id="viewGst">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            PAN Number:
                        </label>

                        <div class="text-black">
                            <span id="viewPan">-</span>
                        </div>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold text-muted">
                            Address:
                        </label>

                        <div class="text-black">
                            <span id="viewAddress">-</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- delete client -->
<div class="modal fade" id="deleteClientModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow w-100" style="max-width: 400px">
            <div class="modal-body text-center p-4">
                <div
                    class="d-flex align-items-center justify-content-center rounded-circle mx-auto mb-3"
                    style="
                        width: 48px;
                        height: 48px;
                        background-color: #fff0f1;
                        color: #ff3e5b;
                    "
                >
                    <i class="mdi mdi-trash-can-outline fs-4"></i>
                </div>

                <h5 class="fw-bold text-dark mb-2">
                    Confirm Deletion
                </h5>
                <p class="text-muted small mb-4">
                    Are you sure you want to delete client record
                    <strong>"SPK And Co., - VF"</strong>?
                    This action cannot be undone.
                </p>
                <div class="row g-2">
                    <div class="col-6">
                        <button
                            type="button"
                            class="btn btn-light w-100"
                            data-bs-dismiss="modal"
                        >
                            Cancel
                        </button>
                    </div>

                    <div class="col-6">
                        <button
                            type="button"
                            class="btn btn-danger w-100"
                        >
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- add & edit client -->
  <script>
    function showAddClient() {
        document.getElementById('clientlist').classList.add('d-none');
        document.getElementById('addClient').classList.remove('d-none');
        document.getElementById('updateClient').classList.add('d-none');
    }

    function showUpdateClient(
        code,
        clientName,
        contactPerson,
        contactNo,
        email,
        alternateContactPerson,
        alternateContactNo,
        address,
        gst,
        pan
    ) {
        document.getElementById('clientlist').classList.add('d-none');
        document.getElementById('addClient').classList.add('d-none');
        document.getElementById('updateClient').classList.remove('d-none');

        document.getElementById('updateClientName').value = clientName;
        document.getElementById('updateContactPerson').value = contactPerson;
        document.getElementById('updateContactNo').value = contactNo;
        document.getElementById('updateEmail').value = email;
        document.getElementById('updateAlternateContactPerson').value = alternateContactPerson;
        document.getElementById('updateAlternateContactNo').value = alternateContactNo;
        document.getElementById('updateAddress').value = address;
        document.getElementById('updateGst').value = gst;
        document.getElementById('updatePan').value = pan;
        document.getElementById('updateSystemCode').innerText ='System Code: ' + code;
    }
    function showClientList() {
        document.getElementById('addClient').classList.add('d-none');
        document.getElementById('updateClient').classList.add('d-none');
        document.getElementById('clientlist').classList.remove('d-none');
    }


    function saveClientUpdate() {
        const clientName =
            document.getElementById('updateClientName').value;
        const contactPerson =
            document.getElementById('updateContactPerson').value;
        const contactNo =
            document.getElementById('updateContactNo').value;

        console.log(clientName);
        console.log(contactPerson);
        console.log(contactNo);
    }
  </script>

<!-- view client -->
  <script>
    function showViewModal(
        code,
        clientName,
        contactPerson,
        contactNo,
        email,
        alternateContactPerson,
        alternateContactNo,
        address,
        gst,
        pan
    ) {
        document.getElementById('viewClientName').textContent = clientName;
        document.getElementById('viewContactPerson').textContent = contactPerson;
        document.getElementById('viewContactNo').textContent = contactNo;
        document.getElementById('viewEmail').textContent = email;
        document.getElementById('viewAlternateContactPerson').textContent = alternateContactPerson;
        document.getElementById('viewAlternateContactNo').textContent = alternateContactNo;
        document.getElementById('viewAddress').textContent = address;
        document.getElementById('viewGst').textContent = gst;
        document.getElementById('viewPan').textContent = pan;
        document.getElementById('viewSystemCode').textContent = code;
    }
  </script>

@endsection
