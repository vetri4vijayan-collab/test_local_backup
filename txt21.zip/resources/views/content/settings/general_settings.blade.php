@extends('layouts/layoutMaster')

@section('title', 'General Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

  @include('layouts.sections.settings.settings-header', ['activeTab' => 'general'])

  <form>

    {{-- Branding --}}
    <div class="card mb-4 settings-card">
      <div class="card-header bg-transparent border-bottom">
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-image-outline text-primary"></i> Branding
        </h6>
        <small class="text-muted">Your company logo and browser favicon</small>
      </div>
      <div class="card-body">
        <div class="row g-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Logo <span class="text-danger">*</span></label>
            <div class="upload-dropzone">
              @if($logoUrl)
                <img src="{{ $logoUrl }}" class="upload-preview" id="uploadedlogo" alt="Logo preview">
              @else
                <img src="{{ asset('assets/img/Ryans-Logo.png') }}" class="upload-preview" id="uploadedlogo" alt="Logo preview">
              @endif
              <div class="upload-actions">
                <label for="upload" class="btn btn-sm btn-primary">
                  <i class="mdi mdi-tray-arrow-up me-1"></i> Upload
                  <input type="file" id="upload" name="logo" class="file-in" hidden accept="image/png, image/jpeg">
                </label>
                <button type="button" class="btn btn-sm btn-outline-danger file-reset">
                  <i class="mdi mdi-reload"></i>
                </button>
              </div>
              <small class="text-muted d-block mt-2">JPG or PNG. Max 800KB.</small>
            </div>
          </div>

          <div class="col-md-6">
            <label class="form-label fw-semibold">Fav Icon <span class="text-danger">*</span></label>
            <div class="upload-dropzone">
              @if($favUrl)
                <img src="{{ $favUrl }}" class="upload-preview" id="fav_uploadedlogo" alt="Fav icon preview">
              @else
                <img src="{{ asset('assets/img/Ryans-Fav-icon.jpg') }}" class="upload-preview" id="fav_uploadedlogo" alt="Fav icon preview">
              @endif
              <div class="upload-actions">
                <label for="fav_upload" class="btn btn-sm btn-primary">
                  <i class="mdi mdi-tray-arrow-up me-1"></i> Upload
                  <input type="file" id="fav_upload" name="fav_icon" class="fav_file-in" hidden accept="image/png, image/jpeg">
                </label>
                <button type="button" class="btn btn-sm btn-outline-danger fav_file-reset">
                  <i class="mdi mdi-reload"></i>
                </button>
              </div>
              <small class="text-muted d-block mt-2">JPG or PNG. Max 800KB.</small>
            </div>
          </div>
        </div>
      </div>
    </div>

    {{-- Company Information --}}
    <div class="card mb-4 settings-card">
      <div class="card-header bg-transparent border-bottom">
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-office-building-outline text-primary"></i> Company Information
        </h6>
        <small class="text-muted">Basic identity and contact details</small>
      </div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Title <span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Title" id="title" name="title" value="{{ $title ?? '' }}"  >
            <div class="invalid-feedback">Please enter the Title.</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Website (URL)</label>
            <input type="text" class="form-control" id="website" name="url"  placeholder="Enter Website (URL)" value="{{ $url ?? '' }}">
            <div class="invalid-feedback">Please enter the Website (URL).</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Email ID</label>
            <input type="text" class="form-control" placeholder="Enter Email ID" value="{{ $email_id ?? '' }}">
            <div class="invalid-feedback">Please enter the Email ID.</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Mobile No</label>
            <input type="text" class="form-control" placeholder="Enter Mobile No" id="phoneno" name="phone_number" value="{{ $phone_number ?? '' }}">
            <div class="invalid-feedback">Please enter the Phone No.</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Date Format <span class="text-danger">*</span></label>
            <select class="select3 form-select">
              <option value="">Select Date Format</option>
              <option value="1" selected>dd-mm-yyyy</option>
              <option value="2">mm-dd-yyyy</option>
              <option value="3">yyyy-mm-dd</option>
            </select>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Registered Name</label>
            <input type="text" class="form-control" placeholder="Enter Registered Name" value="Ryan Infra">
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Tax No</label>
            <input type="text" class="form-control" placeholder="Enter Tax No" value="38BBDCE8000N1F9">
          </div>
        </div>
      </div>
    </div>

    {{-- Address --}}
    <div class="card mb-4 settings-card">
      <div class="card-header bg-transparent border-bottom">
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-map-marker-outline text-primary"></i> Address
        </h6>
        <small class="text-muted">Registered office location</small>
      </div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Country</label>
            <select class="select3 form-select">
              <option value="">Select Country</option>
              <option value="1">USA</option>
              <option value="2">UAE</option>
              <option value="3" selected>India</option>
              <option value="4">South Africa</option>
            </select>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">State</label>
            <select class="select3 form-select">
              <option value="">Select State</option>
              <option value="1" selected>Tamilnadu</option>
              <option value="2">Andhra Pradesh</option>
              <option value="3">Kerala</option>
              <option value="4">Karnataka</option>
            </select>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">City</label>
            <select class="select3 form-select">
              <option value="">Select City</option>
              <option value="1" selected>Madurai</option>
              <option value="2">Virudhunagar</option>
              <option value="3">Thirunelveli</option>
              <option value="4">Coimbatore</option>
              <option value="5">Chennai</option>
            </select>
          </div>
          <div class="col-lg-8">
            <label class="form-label fw-semibold">Area / Street</label>
            <textarea class="form-control" rows="2" placeholder="Enter Area/Street">Madurai</textarea>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Pincode</label>
            <input type="text" class="form-control" placeholder="Enter Pincode" value="625020">
          </div>
        </div>
      </div>
    </div>

    {{-- Social Media --}}
    <div class="card mb-4 settings-card">
      <div class="card-header bg-transparent border-bottom">
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-share-variant-outline text-primary"></i> Social Media Links
        </h6>
        <small class="text-muted">Public profile links shown on your site</small>
      </div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-lg-6">
            <label class="form-label fw-semibold"><i class="mdi mdi-facebook text-primary me-1"></i>Facebook</label>
            <input type="text" class="form-control" placeholder="https://facebook.com/ryaninfra">
          </div>
          <div class="col-lg-6">
            <label class="form-label fw-semibold"><i class="mdi mdi-instagram text-danger me-1"></i>Instagram</label>
            <input type="text" class="form-control" placeholder="https://instagram.com/ryaninfra">
          </div>
          <div class="col-lg-6">
            <label class="form-label fw-semibold"><i class="mdi mdi-linkedin text-info me-1"></i>LinkedIn</label>
            <input type="text" class="form-control" placeholder="https://linkedin.com/ryan-infra" value="https://www.linkedin.com/ryan-infra/">
          </div>
          <div class="col-lg-6">
            <label class="form-label fw-semibold"><i class="mdi mdi-youtube text-danger me-1"></i>YouTube</label>
            <input type="text" class="form-control" placeholder="https://youtube.com/@ryan-infra" value="https://www.youtube.com/ryan-infra">
          </div>
        </div>
      </div>
    </div>

    <div class="d-flex justify-content-end align-items-center gap-2 mb-4">
      <button type="reset" class="btn btn-label-secondary">Cancel</button>
      <button type="submit" class="btn btn-primary px-4">
        <i class="mdi mdi-content-save-outline me-1"></i> Update
      </button>
    </div>
  </form>

  <style>
    .settings-card {
      border: 1px solid #eef0f2;
      border-radius: 14px;
      box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
    }
    .settings-card .card-header {
      padding: 1rem 1.25rem;
    }
    .upload-dropzone {
      border: 1px dashed #d8dce1;
      border-radius: 12px;
      padding: 1rem;
      display: flex;
      align-items: center;
      gap: 1rem;
      background: #fafbfc;
    }
    .upload-preview {
      width: 72px;
      height: 72px;
      object-fit: cover;
      border-radius: 10px;
      border: 1px solid #e2e6ea;
      flex-shrink: 0;
    }
    .upload-actions {
      display: flex;
      gap: 0.5rem;
    }
  </style>

  <script>
    let logofile = document.getElementById('uploadedlogo');
    const fileInput = document.querySelector('.file-in'),
      resetFileInput = document.querySelector('.file-reset');

    if (logofile) {
      const resetImage = logofile.src;
      fileInput.onchange = () => {
        if (fileInput.files[0]) {
          logofile.src = window.URL.createObjectURL(fileInput.files[0]);
        }
      };
      resetFileInput.onclick = () => {
        fileInput.value = '';
        logofile.src = resetImage;
      };
    }

    let faviconfile = document.getElementById('fav_uploadedlogo');
    const fav_fileInput = document.querySelector('.fav_file-in'),
      fav_resetFileInput = document.querySelector('.fav_file-reset');

    if (faviconfile) {
      const fav_resetImage = faviconfile.src;
      fav_fileInput.onchange = () => {
        if (fav_fileInput.files[0]) {
          faviconfile.src = window.URL.createObjectURL(fav_fileInput.files[0]);
        }
      };
      fav_resetFileInput.onclick = () => {
        fav_fileInput.value = '';
        faviconfile.src = fav_resetImage;
      };
    }
  </script>

@endsection