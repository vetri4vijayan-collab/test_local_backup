@extends('layouts/layoutMaster')

@section('title', 'Hired Material')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'purchase'])

<div class="row">

    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.purchase-settings-header')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-toolbox-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Hired Material</h5>
                        <small class="text-muted">
                            Manage hired material and its type details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#addHiredMaterialModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Hired Material</span>
                </button>
            </div>
            <div class="card-body p-3">
                {{-- Search --}}
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search Hired Material">
                        </div>
                    </div>
                </div>
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0" id="bankTable">
                        <thead>
                            <tr class="bg-light">
                                <th class="text-nowrap">Hired Material</th>
                                <th class="text-nowrap">Description</th>
                                <th class="text-nowrap">Status</th>
                                <th class="text-end"> Actions </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Cement</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Binding material used for concrete, mortar, and other construction works.">
                                        Binding material used for concrete, mortar, and other construction works.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MaterialStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editHiredMaterialModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteHiredMaterialModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Steel</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Structural and reinforcement material used for buildings and infrastructure.">
                                        Structural and reinforcement material used for buildings and infrastructure.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MaterialStatus2"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editHiredMaterialModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteHiredMaterialModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Sand</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Fine aggregate used in concrete, mortar, plastering, and other construction activities.">
                                        Fine aggregate used in concrete, mortar, plastering, and other construction activities.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MaterialStatus3"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editHiredMaterialModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteHiredMaterialModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Aggregate</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Coarse and fine stone materials used in concrete and road construction.">
                                        Coarse and fine stone materials used in concrete and road construction.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MaterialStatus4"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editHiredMaterialModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteHiredMaterialModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Bricks</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Masonry units used for constructing walls, partitions, and other structures.">
                                        Masonry units used for constructing walls, partitions, and other structures.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MaterialStatus5"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editHiredMaterialModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteHiredMaterialModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Blocks</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Concrete or lightweight masonry units used for wall construction.">
                                        Concrete or lightweight masonry units used for wall construction.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MaterialStatus6"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editHiredMaterialModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteHiredMaterialModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addHiredMaterialModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="addHiredMaterialModalTitle">
                    Add Hired Material
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="bankForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-12">
                            <label for="bank_name" class="form-label fw-semibold">
                                Hired Material Name
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="bank_name" class="form-control" placeholder="Enter Hired Material name"
                                required>
                        </div>
                        <div class="col-12 col-md-12">
                            <label for="ifsc_code" class="form-label fw-semibold">
                                Description
                                <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="">
                            Save Hired Material
                        </span>

                    </button>

                </div>
            </form>

        </div>

    </div>

</div>

<div class="modal fade" id="editHiredMaterialModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="addHiredMaterialModalTitle">
                    Update Hired Material
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="bankForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-12">
                            <label for="bank_name" class="form-label fw-semibold">
                                Hired Material Name
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="bank_name" class="form-control" placeholder="Enter Hired Material name"
                                required>
                        </div>
                        <div class="col-12 col-md-12">
                            <label for="ifsc_code" class="form-label fw-semibold">
                                Description
                                <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="">
                            Update Hired Material
                        </span>

                    </button>

                </div>
            </form>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- Delete Confirmation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="deleteHiredMaterialModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Hired Material
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-toolbox-outline fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="deleteBankName">
                        this Hired Material
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>



@push('styles')
<style>
/* =========================================================
   Bank Settings - Full Width + Zoom Safe
   ========================================================= */

/* Main content always uses available row width */
.col-12.col-md-8.col-lg-9 {
    min-width: 0;
    margin-left: 20%;
}


/* Desktop and above */
@media (min-width: 768px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        min-width: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
    }

}


/* Card */
.col-12.col-md-8.col-lg-9 .card {
    width: 100%;
    max-width: 100%;
}


/* Card body */
.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}


/* Table container */
.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}


/* Table */
.col-12.col-md-8.col-lg-9 #bankTable {
    width: 100%;
    min-width: 850px;
}


/* =========================================================
   Mobile
   ========================================================= */

@media (max-width: 767.98px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
    }

    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

}


/* =========================================================
   Small Mobile
   ========================================================= */

@media (max-width: 575.98px) {

    .col-12.col-md-8.col-lg-9 {
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .card-header {
        align-items: flex-start !important;
    }

    .card-header>div:first-child {
        width: 100%;
    }

    .card-header>button {
        width: 100%;
        justify-content: center;
    }

}


/* =========================================================
   Modal - Zoom / Small Screen Safe
   ========================================================= */

.modal-dialog {
    max-width: calc(100% - 2rem);
}

.modal-content {
    width: 100%;
    max-width: 100%;
}


/* Modal form columns */
@media (max-width: 767.98px) {

    #addHiredMaterialModal .row.g-3>[class*="col-md-6"] {
        width: 100%;
    }

}


/* =========================================================
   Prevent flex children from creating unexpected width
   ========================================================= */

.row {
    min-width: 0;
}

.row>[class*="col-"] {
    min-width: 0;
}
</style>
@endpush



@endsection
