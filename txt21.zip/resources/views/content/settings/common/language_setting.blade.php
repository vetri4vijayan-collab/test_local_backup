@extends('layouts/layoutMaster')

@section('title', 'Language Settings - Common Settings')

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

<div class="row g-4">


    {{-- Left Area: Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Right Area: Main Settings Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">

            {{-- Card Header --}}
            <div class="card-header border-bottom py-3">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">

                    <div class="d-flex align-items-center gap-3">
                        <div
                            class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center flex-shrink-0">
                            <i class="mdi mdi-translate fs-4 text-primary"></i>
                        </div>

                        <div>
                            <h5 class="mb-0 fw-bold">Language Settings</h5>
                            <small class="text-muted">
                                Manage available languages and their status
                            </small>
                        </div>
                    </div>

                    <button type="button" class="btn btn-primary d-flex align-items-center justify-content-center gap-1"
                        data-bs-toggle="modal" data-bs-target="#languageModal">
                        <i class="mdi mdi-plus fs-5"></i>
                        <span>Add Language</span>
                    </button>

                </div>
            </div>

            {{-- Card Body --}}
            <div class="card-body pt-4">

                {{-- Search Toolbar --}}
                <div class="row g-3 mb-4 align-items-center">

                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>

                            <input type="text" class="form-control" placeholder="Search language..." />
                        </div>
                    </div>

                </div>

                {{-- Language Table --}}
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">
                            <tr class="bg-light">
                                <th>
                                    Language
                                </th>

                                <th>
                                    Status
                                </th>

                                <th class="text-end">
                                    Actions
                                </th>
                            </tr>
                        </thead>

                        <tbody class="table-border-bottom-0">

                            {{-- Dummy Row 1 --}}
                            <tr>

                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span
                                            class="avatar avatar-xs bg-label-primary rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="mdi mdi-translate text-primary"></i>
                                        </span>

                                        <span class="fw-bold text-heading">
                                            English
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#languageModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteLanguageModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>

                            {{-- Dummy Row 2 --}}
                            <tr>

                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span
                                            class="avatar avatar-xs bg-label-primary rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="mdi mdi-translate text-primary"></i>
                                        </span>

                                        <span class="fw-bold text-heading">
                                            Tamil
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#languageModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteLanguageModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>

                            {{-- Dummy Row 3 --}}
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span
                                            class="avatar avatar-xs bg-label-primary rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="mdi mdi-translate text-primary"></i>
                                        </span>

                                        <span class="fw-bold text-heading">
                                            Hindi
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#languageModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteLanguageModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>

                            {{-- Dummy Row 4 --}}
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span
                                            class="avatar avatar-xs bg-label-primary rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="mdi mdi-translate text-primary"></i>
                                        </span>

                                        <span class="fw-bold text-heading">
                                            Spanish
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#languageModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteLanguageModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>

                            {{-- Dummy Row 5 --}}
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span
                                            class="avatar avatar-xs bg-label-primary rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="mdi mdi-translate text-primary"></i>
                                        </span>

                                        <span class="fw-bold text-heading">
                                            French
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#languageModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteLanguageModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr>

                        </tbody>

                    </table>
                </div>

            </div>
        </div>
    </div>
    ```

</div>

{{-- Add / Edit Language Modal --}}

<div class="modal fade" id="languageModal" tabindex="-1" aria-labelledby="languageModalTitle" aria-hidden="true">

    ```
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="languageModalTitle">
                    Language
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            <form action="#" method="POST">
                @csrf

                <input type="hidden" name="language_id" value="">

                <div class="modal-body text-start">

                    {{-- Language --}}
                    <div class="mb-3">
                        <label for="language" class="form-label fw-semibold">
                            Language
                            <span class="text-danger">*</span>
                        </label>

                        <input type="text" id="language" name="language" class="form-control"
                            placeholder="Enter language name" required>
                    </div>

                </div>

                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="submit" class="btn btn-primary d-flex align-items-center gap-1">

                        <i class="mdi mdi-check"></i>

                        <span>
                            Save Language
                        </span>

                    </button>

                </div>

            </form>

        </div>
    </div>
    ```

</div>

{{-- Delete Confirmation Modal --}}

<div class="modal fade" id="deleteLanguageModal" tabindex="-1" aria-labelledby="deleteLanguageModalTitle"
    aria-hidden="true">

    ```
    <div class="modal-dialog modal-dialog-centered modal-sm">

        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="deleteLanguageModalTitle">
                    Delete Language
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            <div class="modal-body text-center py-4">

                <div
                    class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-delete-outline fs-3 text-danger"></i>
                </div>

                <h6 class="fw-bold mb-2">
                    Are you sure?
                </h6>

                <p class="text-muted mb-0">
                    Do you really want to delete this language?
                    This action cannot be undone.
                </p>

            </div>

            <div class="modal-footer border-top justify-content-center">

                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" class="btn btn-danger">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>

            </div>

        </div>

    </div>


</div>

@endsection