@extends('layouts/layoutMaster')

@section('title', 'Relations - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

{{-- Relations Main Content --}}

<div class="row">

    {{-- Left Area: Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Right Area: Main Relations Content --}}
    <div class="col-12 col-md-8 col-lg-9">

        <div class="card">

            {{-- Card Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">

                <div class="d-flex align-items-center gap-3">

                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-account-switch fs-4 text-primary"></i>
                    </div>

                    <div>
                        <h5 class="mb-0 fw-bold">Relations</h5>
                        <small class="text-muted">
                            Manage relation types and their status
                        </small>
                    </div>

                </div>

                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#relationModal">

                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Relation</span>

                </button>

            </div>


            {{-- Card Body --}}
            <div class="card-body pt-4">

                {{-- Search --}}
                <div class="row g-3 mb-4 align-items-center">

                    <div class="col-12 col-md-6 col-lg-5">

                        <div class="input-group input-group-merge">

                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>

                            <input type="text" id="tableSearch" class="form-control" placeholder="Search relation..." />

                        </div>

                    </div>

                    <div class="col-12 col-md-4 col-lg-3">

                        <select class="form-select">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>

                    </div>

                </div>


                {{-- Relations Table --}}
                <div class="table-responsive text-nowrap rounded border">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr class="bg-light">
                                <th> Relation </th>
                                <th> Status </th>
                                <th class="text-end">
                                    Actions</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            {{-- Dummy Row 1 --}}
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">
                                        Parent
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#relationModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteRelationModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            {{-- Dummy Row 2 --}}
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">
                                        Child
                                    </span>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#relationModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteRelationModal" title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>


                            {{-- Dummy Row 3 --}}
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">
                                        Spouse
                                    </span>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#relationModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteRelationModal" title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>


                            {{-- Dummy Row 4 --}}
                            <tr>

                                <td>
                                    <span class="fw-bold text-heading">
                                        Sibling
                                    </span>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#relationModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteRelationModal" title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>


                            {{-- Dummy Row 5 --}}
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">
                                        Guardian
                                    </span>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#relationModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteRelationModal" title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- Add / Edit Relation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="relationModal" tabindex="-1" aria-labelledby="relationModalTitle" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header border-bottom">

                <h5 class="modal-title fw-bold" id="relationModalTitle">
                    Relation
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>


            <form action="#" method="POST">

                @csrf

                <input type="hidden" name="relation_id" value="">


                <div class="modal-body text-start">

                    {{-- Relation --}}
                    <div class="mb-3">

                        <label for="relation" class="form-label fw-semibold">

                            Relation
                            <span class="text-danger">*</span>

                        </label>

                        <input type="text" id="relation" name="relation" class="form-control"
                            placeholder="Enter relation" required>

                    </div>
                </div>


                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary d-flex align-items-center gap-1">

                        <i class="mdi mdi-check"></i>

                        <span>
                            Save Relation
                        </span>

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- Delete Confirmation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="deleteRelationModal" tabindex="-1" aria-labelledby="deleteRelationModalTitle"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header border-bottom">

                <h5 class="modal-title fw-bold" id="deleteRelationModalTitle">

                    Delete Relation

                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>


            <div class="modal-body text-center py-4">

                <div class="avatar avatar-lg bg-label-danger mx-auto mb-3">

                    <i class="mdi mdi-delete-outline fs-3 text-danger"></i>

                </div>

                <h5 class="fw-bold mb-2">
                    Are you sure?
                </h5>

                <p class="text-muted mb-0">
                    Are you sure you want to delete this relation?
                    This action cannot be undone.
                </p>

            </div>


            <div class="modal-footer border-top justify-content-center">

                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button" class="btn btn-danger">

                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete

                </button>

            </div>

        </div>

    </div>

</div>


{{-- Responsive Styles --}}
@push('styles')

<style>
/* Main Content */
.relations-main-content {
    width: 100%;
    max-width: 100%;
}


/* Table */
.table-responsive {
    width: 100%;
    max-width: 100%;
    overflow-x: auto;
}


.table-responsive table {
    width: 100%;
    min-width: 600px;
}


/* Mobile */
@media (max-width: 767.98px) {

    .card-header {
        align-items: flex-start !important;
    }

    .card-header>div:first-child {
        width: 100%;
    }

    .card-header>button {
        width: 100%;
        justify-content: center;
    }

}


/* Small Mobile */
@media (max-width: 575.98px) {

    .card-body {
        padding-left: 1rem;
        padding-right: 1rem;
    }

    .modal-dialog {
        margin: .75rem;
    }

}
</style>

@endpush

@endsection
