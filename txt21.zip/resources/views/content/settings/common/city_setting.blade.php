@extends('layouts/layoutMaster')

@section('title', 'City Settings - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

<div class="row">
    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">

            {{-- Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between gap-2 flex-wrap">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded">
                        <i class="mdi mdi-city fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">City Settings</h5>
                        <small class="text-muted">
                            Manage country, state and city configurations
                        </small>
                    </div>
                </div>

                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#citySettingModal" onclick="resetCityForm()">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add City Setting</span>
                </button>
            </div>

            {{-- Body --}}
            <div class="card-body">

                {{-- Search --}}
                <div class="row mb-4">
                    <div class="col-12 col-md-5 col-lg-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search country, state or city...">
                        </div>
                    </div>
                </div>

                {{-- Table --}}
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0" id="citySettingsTable">
                        <thead>
                            <tr class="bg-light">
                                <th class=" text-nowrap" style="">Country</th>
                                <th class=" text-nowrap" style="">State</th>
                                <th class=" text-nowrap" style="">City</th>
                                <th class="" style="">Description</th>
                                <th class="" style="">Status</th>
                                <th class=" text-end" style="width:100px;">Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            {{-- Row 1 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">India</span>
                                </td>
                                <td class="text-nowrap">Tamil Nadu</td>
                                <td class="text-nowrap fw-medium">Chennai</td>
                                <td>
                                    <span class="d-block text-truncate" style="max-width:200px;">
                                        South India regional office with IST based configuration rules.
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#citySettingModal" title="Edit"
                                            onclick="editCitySetting({ id: 1, country: 'IN', state: 'TN', city: 'CHN', description: 'South India regional office with IST based configuration rules.' })">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCityModal" title="Delete"
                                            onclick="setDeleteCity(1, 'Chennai')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 2 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">United States</span>
                                </td>
                                <td class="text-nowrap">California</td>
                                <td class="text-nowrap fw-medium">Los Angeles</td>
                                <td>
                                    <span class="d-block text-truncate" style="max-width:200px;">
                                        Primary west coast city configuration and regional operating rules.
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#citySettingModal" title="Edit"
                                            onclick="editCitySetting({ id: 2, country: 'US', state: 'CA', city: 'LA', description: 'Primary west coast city configuration and regional operating rules.' })">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCityModal" title="Delete"
                                            onclick="setDeleteCity(2, 'Los Angeles')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 3 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">United Kingdom</span>
                                </td>
                                <td class="text-nowrap">England</td>
                                <td class="text-nowrap fw-medium">London</td>
                                <td>
                                    <span class="d-block text-truncate" style="max-width:200px;">
                                        European hub operating on GMT/BST rules.
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#citySettingModal" title="Edit"
                                            onclick="editCitySetting({ id: 3, country: 'GB', state: 'ENG', city: 'LON', description: 'European hub operating on GMT/BST rules.' })">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCityModal" title="Delete"
                                            onclick="setDeleteCity(3, 'London')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>


{{-- Add / Edit Modal --}}
<div class="modal fade" id="citySettingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="cityModalTitle">City Setting</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form id="citySettingForm" action="#" method="POST">
                @csrf

                <input type="hidden" id="city_setting_id" name="city_setting_id">

                <div class="modal-body">

                    <div class="mb-3">
                        <label for="country_code" class="form-label fw-semibold">
                            Country Name <span class="text-danger">*</span>
                        </label>

                        <select id="country_code" name="country_code" class="form-select select3" required>
                            <option value="">Select a country</option>
                            <option value="US">United States</option>
                            <option value="IN">India</option>
                            <option value="GB">United Kingdom</option>
                            <option value="CA">Canada</option>
                            <option value="AU">Australia</option>
                            <option value="DE">Germany</option>
                            <option value="FR">France</option>
                            <option value="SG">Singapore</option>
                            <option value="AE">United Arab Emirates</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="state_code" class="form-label fw-semibold">
                            State Name <span class="text-danger">*</span>
                        </label>

                        <select id="state_code" name="state_code" class="form-select select2" required disabled>
                            <option value="">Select a state</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="city_code" class="form-label fw-semibold">
                            City Name <span class="text-danger">*</span>
                        </label>

                        <input type="text" class="form-control" placeholder="Enter City Name"/>
                    </div>

                    <div>
                        <label for="description" class="form-label fw-semibold">
                            Description
                        </label>

                        <textarea id="description" name="description" class="form-control" rows="3"
                            placeholder="Enter description..."></textarea>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="submit" class="btn btn-primary">
                        <i class="mdi mdi-check me-1"></i>
                        <span id="saveCityButtonText">Save Setting</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>


{{-- Delete Modal --}}
<div class="modal fade" id="deleteCityModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title fw-bold">Delete City Setting</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-delete-outline fs-3 text-danger"></i>
                </div>
                <h5>Are you sure?</h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="deleteCityName">this city</strong>.
                    This action cannot be undone.
                </p>
            </div>

            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>

                <form id="deleteCityForm" action="#" method="POST">
                    @csrf
                    @method('DELETE')
                    <input type="hidden" id="delete_city_id" name="city_setting_id">
                    <button type="submit" class="btn btn-danger">
                        <i class="mdi mdi-delete-outline me-1"></i>
                        Delete
                    </button>
                </form>
            </div>

        </div>
    </div>
</div>

@endsection