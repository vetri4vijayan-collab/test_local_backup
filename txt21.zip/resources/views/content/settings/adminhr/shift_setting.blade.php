@extends('layouts/layoutMaster')

@section('title', 'Shift')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Settings Header --}}
@include('layouts.sections.settings.settings-header', [
    'activeTab' => 'admin_hr'
])

<style>
    .department-status {
        width: 50px !important;
        height: 26px !important;
        cursor: pointer;
    }

    .department-status:checked {
        background-color: #1976ad;
        border-color: #1976ad;
    }

    .table > :not(caption) > * > * {
        border-bottom-color: #e5e5e5;
    }

    .table tbody tr {
        height: 50px;
    }

    .table tbody td {
        color: #333;
        font-size: 14px;
    }

    .table thead th {
        color: #212529;
        font-size: 14px;
        font-weight: 600;
    }

    .table tbody tr:nth-child(odd) {
        background-color: #fafafa;
    }

    .btn-link:hover {
        text-decoration: none;
    }
</style>

<div class="row mt-4">

    {{-- LEFT SIDEBAR --}}
    <div class="col-md-3">
        @include('layouts.sections.settings.adminsettings-sidebar')
    </div>

    {{-- RIGHT CONTENT --}}
    <div class="col-md-9">
        <div class="card ">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-clock-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Shift Settings</h5>
                        <small class="text-muted">
                            Manage shift and its details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#addShiftModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Shift</span>
                </button>
            </div>
            <div class="card-body p-3">
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search Shift">
                        </div>
                    </div>
                </div>

              <div class="table-responsive rounded border">
                  <table class="table table-hover align-middle mb-0 border">
                      <thead class="table-light">
                          <tr class="bg-light">
                              <th>
                                  Shift name
                              </th>

                              <th>
                                  Start time
                              </th>

                              <th>
                                  End time
                              </th>

                              <th>
                                  Status
                              </th>

                              <th>
                                  Actions
                              </th>
                          </tr>
                      </thead>

                      <tbody>

                          <tr>
                              <td class="px-3">
                                  First Shift
                              </td>

                              <td class="px-3">
                                  8:00
                              </td>

                              <td class="px-3">
                                  16:00
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editShiftModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteShiftModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Third Shift
                              </td>

                              <td class="px-3">
                                  12:00
                              </td>

                              <td class="px-3">
                                  8:00
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editShiftModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteShiftModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  General Shift
                              </td>

                              <td class="px-3">
                                  9:00
                              </td>

                              <td class="px-3">
                                  18:00
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editShiftModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteShiftModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>
                  </table>
              </div>
            </div>
        </div>
    </div>
</div>

{{-- Add Shift Modal --}}
<div class="modal fade" id="addShiftModal" tabindex="-1" aria-labelledby="addShiftModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="addShiftModalLabel">
                    Create Shift
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>

            <form action="#" method="POST">
                @csrf

                <div class="modal-body">

                    {{-- Shift Name --}}
                    <div class="mb-3">
                        <label for="shift_name" class="form-label">
                            Shift Name <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="shift_name"
                            name="shift_name"
                            placeholder="Enter shift name"
                            required
                        >
                    </div>

                    {{-- Start Time --}}
                    <div class="mb-3">
                        <label for="start_time" class="form-label">
                            Start Time <span class="text-danger">*</span>
                        </label>

                        <input
                            type="time"
                            class="form-control"
                            id="start_time"
                            name="start_time"
                            required
                        >
                    </div>

                    {{-- End Time --}}
                    <div class="mb-3">
                        <label for="end_time" class="form-label">
                            End Time <span class="text-danger">*</span>
                        </label>

                        <input
                            type="time"
                            class="form-control"
                            id="end_time"
                            name="end_time"
                            required
                        >
                    </div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-outline-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary">
                        Save Shift
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

{{-- Edit Shift Modal --}}
<div class="modal fade" id="editShiftModal" tabindex="-1" aria-labelledby="editShiftModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="editShiftModalLabel">
                    Edit Shift
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>

            <form id="editShiftForm" action="#" method="POST">
                @csrf
                @method('PUT')

                <input type="hidden" name="id" id="edit_shift_id">

                <div class="modal-body">

                    {{-- Shift Name --}}
                    <div class="mb-3">
                        <label for="edit_shift_name" class="form-label">
                            Shift Name <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="edit_shift_name"
                            name="shift_name"
                            placeholder="Enter shift name"
                            required
                        >
                    </div>

                    {{-- Start Time --}}
                    <div class="mb-3">
                        <label for="edit_start_time" class="form-label">
                            Start Time <span class="text-danger">*</span>
                        </label>

                        <input
                            type="time"
                            class="form-control"
                            id="edit_start_time"
                            name="start_time"
                            required
                        >
                    </div>

                    {{-- End Time --}}
                    <div class="mb-3">
                        <label for="edit_end_time" class="form-label">
                            End Time <span class="text-danger">*</span>
                        </label>

                        <input
                            type="time"
                            class="form-control"
                            id="edit_end_time"
                            name="end_time"
                            required
                        >
                    </div>
                </div>

                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-outline-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary">
                        Update Shift
                    </button>

                </div>

            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteShiftModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Shift
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto">
                    <i class="mdi mdi-clock-outline fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="">
                        this shift
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>

@endsection
