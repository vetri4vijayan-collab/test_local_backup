@extends('layouts/layoutMaster')

@section('title', 'Grade List')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Settings Header --}}
@include('layouts.sections.settings.settings-header', [
    'activeTab' => 'admin_hr'
])

<style>
    .department-status {
        width: 50px !important;
        height: 26px !important;
        cursor: pointer;
    }

    .department-status:checked {
        background-color: #1976ad;
        border-color: #1976ad;
    }

    .table > :not(caption) > * > * {
        border-bottom-color: #e5e5e5;
    }

    .table tbody tr {
        height: 50px;
    }

    .table tbody td {
        color: #333;
        font-size: 14px;
    }

    .table thead th {
        color: #212529;
        font-size: 14px;
        font-weight: 600;
    }

    .table tbody tr:nth-child(odd) {
        background-color: #fafafa;
    }

    .btn-link:hover {
        text-decoration: none;
    }
</style>

<div class="row mt-4">

    {{-- LEFT SIDEBAR --}}
    <div class="col-md-3">
        @include('layouts.sections.settings.adminsettings-sidebar')
    </div>

    {{-- RIGHT CONTENT --}}
    <div class="col-md-9">
        <div class="card ">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-format-list-numbered fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Grade Settings</h5>
                        <small class="text-muted">
                            Manage grade and its details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#createGradeModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Grade</span>
                </button>
            </div>
            <div class="card-body p-3">
               <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search grade">
                        </div>
                    </div>
                </div>

              <div class="table-responsive rounded border">
                  <table class="table table-hover align-middle mb-0 border">
                      <thead class="table-light">
                          <tr class="bg-light">
                              <th>
                                  Grade
                              </th>

                              <th>
                                  Status
                              </th>

                              <th>
                                  Actions
                              </th>
                          </tr>
                      </thead>

                      <tbody>

                          <tr>
                              <td class="px-3">
                                  A
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  B
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  C
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  D
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  E
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  F
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  G
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  H
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  I
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  J
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  K
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                   <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editGradeModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteGradeModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>
                      </tbody>
                  </table>
              </div>
            </div>
        </div>
    </div>
</div>

{{-- ================= CREATE GRADE MODAL ================= --}}
<div class="modal fade" id="createGradeModal" tabindex="-1" aria-labelledby="createGradeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="createGradeModalLabel">
                    Create Grade
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>

            <form action="#" method="POST">
                @csrf

                <div class="modal-body">

                    {{-- Grade --}}
                    <div class="mb-3">
                        <label for="create_grade" class="form-label">
                            Grade <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            name="grade"
                            id="create_grade"
                            class="form-control"
                            placeholder="Enter grade"
                            maxlength="100"
                            required
                        >
                    </div>

                    <div class="mb-3">
                        <label for="edit_grade_description" class="form-label">
                            Description
                        </label>

                        <textarea
                            name="description"
                            id="edit_grade_description"
                            class="form-control"
                            rows="3"
                            placeholder="Enter description"
                        ></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary">
                        <i class="mdi mdi-content-save me-1"></i>
                        Save Grade
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

{{-- ================= EDIT GRADE MODAL ================= --}}
<div class="modal fade" id="editGradeModal" tabindex="-1" aria-labelledby="editGradeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="editGradeModalLabel">
                    Edit Grade
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>

            <form action="#" method="POST" id="editGradeForm">
                @csrf
                @method('PUT')

                <div class="modal-body">

                    {{-- Grade --}}
                    <div class="mb-3">
                        <label for="edit_grade" class="form-label">
                            Grade <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            name="grade"
                            id="edit_grade"
                            class="form-control"
                            placeholder="Enter grade"
                            maxlength="100"
                            required
                        >
                    </div>

                    <div class="mb-3">
                        <label for="edit_grade_description" class="form-label">
                            Description
                        </label>

                        <textarea
                            name="description"
                            id="edit_grade_description"
                            class="form-control"
                            rows="3"
                            placeholder="Enter description"
                        ></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary">
                        <i class="mdi mdi-content-save me-1"></i>
                        Update Grade
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<div class="modal fade" id="deleteGradeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Grade
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto">
                    <i class="mdi mdi-format-list-numbered fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="">
                        this grade
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>

@endsection
