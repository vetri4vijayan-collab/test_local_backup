@extends('layouts/layoutMaster')

@section('title', 'Depot Yard Registry')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>
<script>
    function toggleWarehouseDropdown(button) {
        const dropdown = button.closest('.settings-tab-dropdown');

        document
            .querySelectorAll('.settings-tab-dropdown')
            .forEach(item => {
                if (item !== dropdown) {
                    item.classList.remove('open');
                }
            });

        dropdown.classList.toggle('open');
    }

    document.addEventListener('click', function (event) {
        if (!event.target.closest('.settings-tab-dropdown')) {
            document
                .querySelectorAll('.settings-tab-dropdown')
                .forEach(item => {
                    item.classList.remove('open');
                });
        }
    });
</script>
@php
  $warehouseTabs = [
    ['key' => 'depot_yard','label' => 'Depot Yard Registry','route' => 'store-purchase.warehouse'],
    ['key' => 'inventory_ledger','label' => 'Inventory Ledger','route' => 'store-purchase.inventory-ledger'],
    ['key' => 'stock_transfer','label' => 'Stock Transfer','route' => 'store-purchase.stock-transfer'],
    [
        'key' => 'allocation_return',
        'label' => 'Allocations & Returns',
        'route' => 'store-purchase.material_allocation',
        'active_keys' => ['material_allocation', 'unused_material_return'], // top pill lights up for both
    ],
  ];

  $currentRoute = Route::currentRouteName();
  $activeTab = $activeTab ?? match ($currentRoute) {
      'store-purchase.material_allocation'    => 'material_allocation',
      'store-purchase.unused_material_return' => 'unused_material_return',
      'store-purchase.warehouse'              => 'depot_yard',
      'store-purchase.inventory-ledger'       => 'inventory_ledger',
      'store-purchase.stock-transfer'         => 'stock_transfer',
      default                                 => 'depot_yard',
  };
  // no override line here — let $activeTab stay whatever match() resolved it to
@endphp
<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-package-variant-closed"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Store & Purchase Management System' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}</small>
      </div>
    </div>

    <div class="settings-tabs-wrapper d-flex align-items-center">
      <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
        <i class="mdi mdi-chevron-left"></i>
      </button>

      <div class="settings-tabs-scroller">
        <div class="settings-tabs-track" id="warehouseTabScroller"> 
            @foreach ($warehouseTabs as $tab) 
                @if (isset($tab['children'])) 
                    @php 
                        $childActive = collect($tab['children']) ->contains('key', $activeTab); 
                    @endphp 
                    <div class="settings-tab-dropdown"> 
                        <button type="button" class="settings-tab-pill {{ $childActive || $activeTab === $tab['key'] ? 'active' : '' }}" onclick="toggleWarehouseDropdown(this)" > 
                            {{ $tab['label'] }} 
                            <span class="ms-1"> 
                                <i class="mdi mdi-chevron-down"></i> 
                            </span> 
                        </button> 
                        <div class="settings-tab-dropdown-menu"> 
                            @foreach ($tab['children'] as $child) 
                            <a href="{{ Route::has($child['route']) ? route($child['route']) : 'javascript:void(0)' }}" class="settings-tab-dropdown-item {{ $activeTab === $child['key'] ? 'active' : '' }}" > 
                                {{ $child['label'] }} 
                            </a> 
                            @endforeach 
                        </div> 
                    </div> 
                    @else 
                    <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}" class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}" > 
                        {{ $tab['label'] }} 
                    </a> 
                @endif 
            @endforeach 
        </div>
      </div>

      <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
        <i class="mdi mdi-chevron-right"></i>
      </button>
    </div>

  </div>
</div>
<div class="card mb-4 border-0 shadow-sm">
    <div class="card-body p-3">

        @php
            // ---- STATIC DEMO DATA (remove once wired to real controller/model) ----
            $regions = ['South Region', 'West Region', 'North Region', 'East Region'];

            $warehouses = [
                [
                    'id' => 1,
                    'code' => 'WH-MAA-CEN',
                    'region' => 'South Region',
                    'status' => 'Active',
                    'name' => 'Chennai Central Logistics Yard',
                    'officer_name' => 'Vignesh Kumar',
                    'officer_role' => 'Senior Store Manager & Logistics Response Officer',
                    'officer_email' => 'vignesh.kumar@srkinfra.com',
                    'officer_phone' => '+91 94440 10221',
                    'address' => 'Chennai Port Area, Chennai, Tamil Nadu - 600001',
                    'city' => 'Chennai',
                    'district' => 'Chennai',
                    'projects_mapped' => 3,
                    'total_inventory_value' => 184.50,
                    'stocks' => [
                        ['item_name' => 'Cement OPC 53 Grade', 'quantity' => 4500, 'unit' => 'Bags'],
                        ['item_name' => 'TMT Reinforcement Steel 16mm', 'quantity' => 85, 'unit' => 'MT'],
                        ['item_name' => 'Paving Bitumen 60/70', 'quantity' => 120, 'unit' => 'Drums'],
                        ['item_name' => 'Fly Ash Bricks', 'quantity' => 22000, 'unit' => 'Pcs'],
                        ['item_name' => 'PVC Conduit Pipes', 'quantity' => 900, 'unit' => 'Mtrs'],
                    ],
                    'transfers' => [
                        [
                            'direction' => 'OUTGOING',
                            'reference_no' => 'TN-09-C-4412',
                            'item_name' => 'TMT Reinforcement Steel 16mm',
                            'quantity' => 15,
                            'unit' => 'MT',
                            'driver_name' => 'R. Loganathan',
                            'eta' => '2026-07-28',
                        ],
                        [
                            'direction' => 'INCOMING',
                            'reference_no' => 'TN-01-AB-8840',
                            'item_name' => 'Cement OPC 53 Grade',
                            'quantity' => 1500,
                            'unit' => 'Bags',
                            'driver_name' => 'S. Loganathan',
                            'eta' => '2026-07-27',
                        ],
                    ],
                ],
                [
                    'id' => 2,
                    'code' => 'WH-VPM-DEP',
                    'region' => 'South Region',
                    'status' => 'Active',
                    'name' => 'Villupuram Highway Depot',
                    'officer_name' => 'K. Subramaniam',
                    'officer_role' => 'Assistant Depot Manager & Site Response Officer',
                    'officer_email' => 'k.subramaniam@srkinfra.com',
                    'officer_phone' => '+91 98421 44521',
                    'address' => 'NH-45 bypass, Near Toll Plaza, Villupuram, Tamil Nadu - 605602',
                    'city' => 'Villupuram',
                    'district' => 'Villupuram',
                    'projects_mapped' => 1,
                    'total_inventory_value' => 72.00,
                    'stocks' => [
                        ['item_name' => 'Cement OPC 53 Grade', 'quantity' => 1200, 'unit' => 'Bags'],
                        ['item_name' => 'TMT Reinforcement Steel 12mm', 'quantity' => 35, 'unit' => 'MT'],
                        ['item_name' => 'Paving Bitumen 60/70', 'quantity' => 80, 'unit' => 'Drums'],
                        ['item_name' => 'Curing Compound', 'quantity' => 40, 'unit' => 'Drums'],
                    ],
                    'transfers' => [
                        [
                            'direction' => 'INCOMING',
                            'reference_no' => 'TN-01-AX-9912',
                            'item_name' => 'Cement OPC 53 Grade',
                            'quantity' => 500,
                            'unit' => 'Bags',
                            'driver_name' => 'M. Sundaram',
                            'eta' => '2026-07-23',
                        ],
                    ],
                ],
                [
                    'id' => 3,
                    'code' => 'WH-SLM-JV',
                    'region' => 'West Region',
                    'status' => 'Active',
                    'name' => 'Salem Steel Plant Yard (JV)',
                    'officer_name' => 'Ramesh Babu',
                    'officer_role' => 'Yard In-Charge & Material Response Manager',
                    'officer_email' => 'ramesh.babu@srkinfra.com',
                    'officer_phone' => '+91 97890 55122',
                    'address' => 'SIDCO Estate, Steel Plant Rd, Salem, Tamil Nadu - 636013',
                    'city' => 'Salem',
                    'district' => 'Salem',
                    'projects_mapped' => 0,
                    'total_inventory_value' => 125.00,
                    'stocks' => [
                        ['item_name' => 'TMT Reinforcement Steel 20mm', 'quantity' => 120, 'unit' => 'MT'],
                        ['item_name' => 'Binding Wire 18G', 'quantity' => 850, 'unit' => 'Kgs'],
                        ['item_name' => 'Structural Steel Beams ISMB 300', 'quantity' => 45, 'unit' => 'MT'],
                        ['item_name' => 'Anchor Bolts M20', 'quantity' => 3000, 'unit' => 'Pcs'],
                    ],
                    'transfers' => [
                        [
                            'direction' => 'OUTGOING',
                            'reference_no' => 'TN-27-E-1022',
                            'item_name' => 'Structural Steel Beams ISMB 300',
                            'quantity' => 20,
                            'unit' => 'MT',
                            'driver_name' => 'P. Velu',
                            'eta' => '2026-07-29',
                        ],
                    ],
                ],
            ];
        @endphp

        {{-- Toolbar: Search / Region filter / Actions --}}
        <div class="d-flex flex-wrap align-items-center gap-2 mb-4 pb-3 border-bottom">
            <div class="flex-grow-1" style="min-width: 260px;">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                        <i class="mdi mdi-magnify text-muted"></i>
                    </span>
                    <input type="text"
                           id="warehouseSearch"
                           class="form-control border-start-0 ps-0"
                           placeholder="Search by warehouse, manager, location, or stock items...">
                </div>
            </div>

            <div style="min-width: 160px;">
                <select id="regionFilter" class="form-select">
                    <option value="">All Regions</option>
                    @foreach($regions as $region)
                        <option value="{{ $region }}">{{ $region }}</option>
                    @endforeach
                </select>
            </div>

            <button
                type="button"
                id="toggleNearestSuggestion"
                class="btn btn-outline-secondary d-flex align-items-center gap-1"
            >
                <i class="mdi mdi-navigation-variant-outline"></i>
                <span>Nearest Suggestion Tool</span>
            </button>

            <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#add_warehouse_modal">
                <i class="mdi mdi-plus"></i>
                <span>Add Warehouse Master</span>
            </button>
        </div>

        {{-- Warehouse Cards Grid --}}
        <div class="row g-3" id="warehouseGrid">
            <div
                id="nearestSuggestionTool"
                class="bg-label-primary border border-primary rounded-3 p-4 mt-3 d-none"
            >
                <div class="d-flex justify-content-between align-items-start mb-4">
                    <div>
                        <h6 class="fw-bold text-primary text-uppercase mb-1 d-flex align-items-center gap-1">
                            <i class="mdi mdi-navigation-variant-outline"></i>
                            Nearest Warehouse Auto-Suggestion Tool
                        </h6>
                        <p class="text-dark small mb-0">
                            Simulate project creation to see which warehouse is automatically
                            suggested based on location vectors.
                        </p>
                    </div>
                    <button
                        type="button"
                        id="closeNearestSuggestion"
                        class="btn btn-sm btn-link text-muted p-0 border border-secondary"
                        style="box-shadow: none;"
                        aria-label="Close"
                    >
                        <i class="mdi mdi-close fs-5"></i>
                    </button>
                </div>
                <div class="row g-3">
                    {{-- Project Name --}}
                    <div class="col-md-4">
                        <label for="suggestionProjectName" class="form-label fw-semibold small">
                            Project Name
                        </label>
                        <input
                            type="text"
                            id="suggestionProjectName"
                            name="suggestion_project_name"
                            class="form-control"
                            placeholder="e.g. Madurai Outer Ring Road"
                        >
                    </div>
                    {{-- Project Location --}}
                    <div class="col-md-4">
                        <label for="suggestionProjectLocation" class="form-label fw-semibold small">
                            Project Location (City)
                        </label>
                        <select
                            id="suggestionProjectLocation"
                            name="suggestion_project_location"
                            class="form-select select3"
                        >
                            <option value="Chennai">Chennai</option>
                            <option value="Madurai">Madurai</option>
                            <option value="Coimbatore">Coimbatore</option>
                            <option value="Villupuram">Villupuram</option>
                            <option value="Trichy">Trichy</option>
                            <option value="Salem">Salem</option>
                        </select>
                    </div>
                    {{-- Generate --}}
                    <div class="col-md-4 d-flex align-items-end">
                        <button
                            type="button"
                            id="generateRecommendation"
                            class="btn btn-primary w-100"
                        >
                            <i class="mdi mdi-map-marker-distance me-1"></i>
                            Generate Recommendation
                        </button>
                    </div>
                </div>
            </div>
            @forelse($warehouses as $warehouse)
                @php
                    $searchBlob = strtolower(
                        $warehouse['name'] . ' ' .
                        $warehouse['officer_name'] . ' ' .
                        $warehouse['city'] . ' ' .
                        collect($warehouse['stocks'])->pluck('item_name')->implode(' ')
                    );
                    $stockCount = count($warehouse['stocks']);
                    $transferCount = count($warehouse['transfers']);
                @endphp
                <div class="col-12 col-md-6 col-xl-4 warehouse-card-col"
                     data-region="{{ $warehouse['region'] }}"
                     data-search="{{ $searchBlob }}">
                    <div class="card h-100 border shadow-sm wh-card">
                      <div class="card-header border-bottom d-flex flex-column gap-2">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="d-flex gap-1">
                                <span class="badge bg-light text-dark border font-monospace fs-9">{{ $warehouse['code'] }}</span>
                                <span class="badge bg-primary-subtle text-primary border text-uppercase rounded fs-9">{{ $warehouse['region'] }}</span>
                            </div>
                            <div class="d-flex gap-1">
                                <span class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit_warehouse_modal"> 
                                    <i class="mdi mdi-pencil-outline text-secondary"></i>
                                </span>
                                <span class="badge fs-9 {{ $warehouse['status'] === 'Active' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary' }} rounded-pill px-2">
                                    <i class="mdi mdi-circle-fill me-1" style="font-size: 6px;"></i>{{ strtoupper($warehouse['status']) }}
                                </span>
                            </div>
                        </div>
                        <h6 class="fw-bold mb-3">{{ $warehouse['name'] }}</h6>
                      </div>
                      <div class="card-body d-flex flex-column p-0 pb-2">
                        <div class="p-3 border-bottom bg-light-subtle">
                          <div class="d-flex justify-content-between align-items-start mb-1">
                            <div class="text-uppercase text-muted small fw-semibold" style="font-size: .7rem;">
                                <i class="mdi mdi-account-outline me-1"></i>Responsible Officer
                            </div>
                            <span class="badge fs-9 bg-success-subtle text-success mb-1">ON DUTY</span>
                          </div>
                          <div class="d-flex justify-content-between align-items-start">
                            <div class="d-flex flex-column gap-1">
                                <span class="fw-bold small">{{ $warehouse['officer_name'] }}</span>
                                <span class="text-muted fs-9 text-wrap">{{ $warehouse['officer_role'] }}</span>
                                <span class="text-muted fs-9">
                                    <i class="mdi mdi-email-outline me-1"></i>{{ $warehouse['officer_email'] }}
                                </span>
                            </div>
                            <div class="text-end">
                                <div class="small">
                                    <a href="tel:{{ $warehouse['officer_phone'] }}" class="text-decoration-none fs-8 text-primary border p-1 rounded">
                                        <i class="mdi mdi-phone-outline me-1 fs-9"></i>{{ $warehouse['officer_phone'] }}
                                    </a>
                                </div>
                            </div>
                          </div>
                        </div>

                        {{-- Location --}}
                        <div class="mb-3 p-3 border-bottom">
                            <div class="text-uppercase text-muted small fw-semibold mb-1" style="font-size: .7rem; letter-spacing: .03em;">
                                Location Address & Proximity
                            </div>
                            <div class="d-flex align-items-start gap-1">
                              <i class="mdi mdi-map-marker-radius-outline text-primary fs-9"></i>
                              <div class="small mb-1">{{ $warehouse['address'] }}</div>
                            </div>
                            <div class="d-flex flex-wrap align-items-center gap-1">
                                <span class="badge bg-light text-dark border fs-8">City: {{ $warehouse['city'] }}</span>
                                <span class="badge bg-light text-dark border fs-8">District: {{ $warehouse['district'] }}</span>
                                <span class="text-primary fs-8">{{ $warehouse['projects_mapped'] }} Projects Mapped</span>
                            </div>
                        </div>
                        <div class="p-2">
                          {{-- Stocks present --}}
                          <div class="border rounded border-dark p-2 mb-2">
                              <div class="d-flex justify-content-between align-items-center mb-2">
                                  <span class="fw-semibold small">
                                      <i class="mdi mdi-package-variant-closed text-success me-1"></i>Stocks Present in Warehouse
                                  </span>
                                  <span class="badge bg-success-subtle rounded text-success fs-9">{{ $stockCount }} Items Stored</span>
                              </div>

                              @foreach(array_slice($warehouse['stocks'], 0, 3) as $index => $stock)
                                  <div class="d-flex justify-content-between small py-1 {{ $index < 2 ? 'border-bottom' : '' }}">
                                      <span class="text-truncate pe-2">{{ $stock['item_name'] }}</span>
                                      <span class="fw-semibold text-nowrap">{{ number_format($stock['quantity']) }} {{ $stock['unit'] }}</span>
                                  </div>
                              @endforeach

                              @if($stockCount > 3)
                              <div class="text-end">
                                  <a href="#" class="small text-decoration-none fs-9">
                                      + {{ $stockCount - 3 }} more stock items...
                                  </a>
                              </div>
                              @endif

                              <div class="d-flex justify-content-between border-top pt-2 mt-2">
                                  <span class="small text-muted">Total Inventory Value:</span>
                                  <span class="fw-bold small">₹{{ number_format($warehouse['total_inventory_value'], 2) }} Lakhs</span>
                              </div>
                          </div>

                          {{-- Stock in transfer --}}
                          <div class="border rounded border-dark p-2 mb-3">
                              <div class="d-flex justify-content-between align-items-center mb-2">
                                  <span class="fw-semibold small">
                                      <i class="mdi  mdi-truck-outline text-warning me-1"></i>Stock in Transfer
                                  </span>
                                  @if($transferCount > 0)
                                      <span class="badge bg-warning-subtle text-warning">{{ $transferCount }} In-Transit</span>
                                  @else
                                      <span class="badge bg-light text-muted border fs-9">0 In-Transit</span>
                                  @endif
                              </div>

                              @forelse($warehouse['transfers'] as $index => $transfer)
                                  <div class="mb-2 p-2 bg-gray-100 rounded d-flex flex-column gap-1">
                                      <div class="d-flex justify-content-between align-items-center">
                                          <span class="badge {{ $transfer['direction'] === 'OUTGOING' ? 'bg-danger-subtle text-danger' : 'bg-info-subtle text-info' }}" style="font-size: .65rem;">
                                              {{ $transfer['direction'] }}
                                          </span>
                                          <span class="small font-monospace text-muted">{{ $transfer['reference_no'] }}</span>
                                      </div>
                                      <div class="d-flex justify-content-between small mt-1">
                                          <span>{{ $transfer['item_name'] }}</span>
                                          <span class="fw-semibold">{{ $transfer['quantity'] }} {{ $transfer['unit'] }}</span>
                                      </div>
                                      <div class="d-flex justify-content-between small text-muted">
                                          <span>Driver: {{ $transfer['driver_name'] }}</span>
                                          <span class="text-danger">ETA: {{ $transfer['eta'] }}</span>
                                      </div>
                                  </div>
                              @empty
                                  <div class="text-muted small text-center py-2">No active transfers</div>
                              @endforelse
                          </div>

                          {{-- Actions --}}
                          <div class="mt-auto">
                              {{-- Overview --}}
                                <button
                                    type="button"
                                    class="btn btn-primary w-100 mb-2 d-flex align-items-center justify-content-center gap-2"
                                    data-bs-toggle="modal"
                                    data-bs-target="#inspection_stock_modal"
                                    data-inspection-tab="#warehouse-overview"
                                >
                                    <i class="mdi mdi-eye"></i>
                                    Inspect Stock & Transfer Details
                                </button>

                                <div class="d-flex flex-wrap gap-2 justify-content-evenly">

                                    {{-- Stocks --}}
                                    <button
                                        type="button"
                                        class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center gap-1"
                                        data-bs-toggle="modal"
                                        data-bs-target="#inspection_stock_modal"
                                        data-inspection-tab="#warehouse-stock"
                                    >
                                        <i class="mdi mdi-package-variant-closed text-success"></i>
                                        Stocks
                                    </button>

                                    {{-- Transfers --}}
                                    <button
                                        type="button"
                                        class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center gap-1"
                                        data-bs-toggle="modal"
                                        data-bs-target="#inspection_stock_modal"
                                        data-inspection-tab="#warehouse-transfer"
                                    >
                                        <i class="mdi mdi-truck-outline text-warning"></i>
                                        Transfers
                                    </button>
                                  <button type="button" class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center gap-1">
                                      <i class="mdi mdi-printer-outline"></i>Report
                                  </button>
                              </div>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center py-5 text-muted">
                    No warehouses found.
                </div>
            @endforelse
        </div>

    </div>
</div>


{{-- Modals --}}
{{-- Add / Edit Country Setting Modal --}}
<div class="modal fade" id="add_warehouse_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="countryModalTitle">Add Construction Warehouse Master</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="countrySettingForm" action="#" method="POST">
                @csrf
                <input type="hidden" id="country_id" name="country_id" value="">

                <div class="modal-body text-start">
                    <div class="row g-2 mb-3">
                        <div class="col-lg-12">
                            <label class="form-label">Warehouse Name <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Warehouse Name" value=""/>
                        </div>
                        <div class="col-lg-12">
                            <label class="form-label">Address / Physical Location</label>
                            <textarea class="form-control" rows="2"></textarea>
                        </div> 
                        <div class="col-lg-4">
                            <label for="country_id" class="form-label fw-semibold">Country <span
                                    class="text-danger">*</span></label>
                            <select id="country_id" name="country_id" class="form-select select3" required>
                                <option value="" disabled selected>Select a country</option>
                                <option value="1">United States</option>
                                <option value="2">India</option>
                                <option value="3">United Kingdom</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label for="state_id" class="form-label fw-semibold">State <span
                                    class="text-danger">*</span></label>
                            <select id="state_id" name="state_id" class="form-select select3" required>
                                <option value="" disabled selected>Select a State</option>
                                <option value="1">Andhra Pradesh</option>
                                <option value="2">Tamil Nadu</option>
                                <option value="3">Kerala</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label for="city_id" class="form-label fw-semibold">City <span
                                    class="text-danger">*</span></label>
                            <select id="city_id" name="city_id" class="form-select select3" required>
                                <option value="" disabled selected>Select a City</option>
                                <option value="1">Madurai</option>
                                <option value="2">Tuticorin</option>
                                <option value="3">Trichy</option>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2 rounded-3 p-2 bg-label-primary mb-2">
                        <label class="form-label">Response Officer/Store Manager Details</label>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Response Officer Name <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Response Officer Name" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Contact Phone <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Contact Phone" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Designation/Role <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Designation/Role" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Email Id <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Email Id" value=""/>
                        </div>
                    </div>
                    <div class="row g-2 mb-2">
                        <label>Nearby Project (Assigned)</label>
                        <div
                            class="col-lg-12 rounded-3 p-2 bg-label-primary"
                            style="max-height: 150px; overflow-y: auto;"
                        >
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_1">
                                <label class="form-check-label" for="proj_1">
                                    Chennai Metro Phase 2 - Corridor 4
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_2">
                                <label class="form-check-label" for="proj_2">
                                    Adyar Premium Residences
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_3">
                                <label class="form-check-label" for="proj_3">
                                    East Coast Road Elevated Bridge
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_4">
                                <label class="form-check-label" for="proj_4">
                                    SIPCOT Industrial Park
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_5">
                                <label class="form-check-label" for="proj_5">
                                    ELCOT IT Park
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary">Cancel</button>
                    <button type="" class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>Save Warehouse Master</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>


<div class="modal fade" id="edit_warehouse_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="countryModalTitle">Update Construction Warehouse Master</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="countrySettingForm" action="#" method="POST">
                @csrf
                <input type="hidden" id="country_id" name="country_id" value="">

                <div class="modal-body text-start">
                    <div class="row g-2 mb-3">
                        <div class="col-lg-12">
                            <label class="form-label">Warehouse Name <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Warehouse Name" value=""/>
                        </div>
                        <div class="col-lg-12">
                            <label class="form-label">Address / Physical Location</label>
                            <textarea class="form-control" rows="2"></textarea>
                        </div> 
                        <div class="col-lg-4">
                            <label for="country_id" class="form-label fw-semibold">Country <span
                                    class="text-danger">*</span></label>
                            <select id="country_id" name="country_id" class="form-select select3" required>
                                <option value="" disabled selected>Select a country</option>
                                <option value="1">United States</option>
                                <option value="2">India</option>
                                <option value="3">United Kingdom</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label for="state_id" class="form-label fw-semibold">State <span
                                    class="text-danger">*</span></label>
                            <select id="state_id" name="state_id" class="form-select select3" required>
                                <option value="" disabled selected>Select a State</option>
                                <option value="1">Andhra Pradesh</option>
                                <option value="2">Tamil Nadu</option>
                                <option value="3">Kerala</option>
                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label for="city_id" class="form-label fw-semibold">City <span
                                    class="text-danger">*</span></label>
                            <select id="city_id" name="city_id" class="form-select select3" required>
                                <option value="" disabled selected>Select a City</option>
                                <option value="1">Madurai</option>
                                <option value="2">Tuticorin</option>
                                <option value="3">Trichy</option>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2 rounded-3 p-2 bg-label-primary mb-2">
                        <label class="form-label">Response Officer/Store Manager Details</label>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Response Officer Name <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Response Officer Name" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Contact Phone <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Contact Phone" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Designation/Role <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Designation/Role" value=""/>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <label class="form-label text-black">Email Id <span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Enter Email Id" value=""/>
                        </div>
                    </div>
                    <div class="row g-2 mb-2">
                        <label>Nearby Project (Assigned)</label>
                        <div
                            class="col-lg-12 rounded-3 p-2 bg-label-primary"
                            style="max-height: 150px; overflow-y: auto;"
                        >
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_1">
                                <label class="form-check-label" for="proj_1">
                                    Chennai Metro Phase 2 - Corridor 4
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_2">
                                <label class="form-check-label" for="proj_2">
                                    Adyar Premium Residences
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_3">
                                <label class="form-check-label" for="proj_3">
                                    East Coast Road Elevated Bridge
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_4">
                                <label class="form-check-label" for="proj_4">
                                    SIPCOT Industrial Park
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="proj_5">
                                <label class="form-check-label" for="proj_5">
                                    ELCOT IT Park
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary">Cancel</button>
                    <button type="" class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>Update Warehouse Master</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>

<div class="modal fade" id="inspection_stock_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content border-0 shadow-lg overflow-hidden">
            <div class="modal-header bg-dark text-white border-0 p-4">
                <div class="flex-grow-1">
                    <div class="d-flex align-items-center flex-wrap gap-2 mb-2">
                        <span class="badge bg-secondary font-monospace">
                            WH-VPM-DEP
                        </span>
                        <span class="badge bg-primary rounded-pill text-uppercase">
                            South Region
                        </span>
                        <span class="badge bg-success bg-opacity-10 text-success border border-success">
                            <i class="mdi mdi-check-circle-outline me-1"></i>
                            Active
                        </span>
                    </div>
                    <h4 class="fw-bold text-white mb-1">
                        Villupuram Highway Depot
                    </h4>
                    <div class="small text-white-80 d-flex align-items-start gap-2">
                        <i class="mdi mdi-map-marker-outline text-primary"></i>
                        <span>
                            NH-45 bypass, Near Toll Plaza, Villupuram,
                            Tamil Nadu - 605602
                        </span>
                    </div>
                </div>
                <button
                    type="button"
                    class="btn btn-sm btn-secondary ms-3"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                >
                    <i class="mdi mdi-close fs-5"></i>
                </button>
            </div>
            <div class="bg-light border-bottom px-4 py-2">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <ul class="nav nav-pills gap-1" id="warehouseInspectionTabs">
                        <li class="nav-item fs-7">
                            <button
                                type="button"
                                style="padding:7px;"
                                class="nav-link active d-flex align-items-center gap-1"
                                data-bs-toggle="tab"
                                data-bs-target="#warehouse-overview"
                            >
                                <i class="mdi mdi-office-building-outline"></i>
                                Overview & Response Person
                            </button>
                        </li>
                        <li class="nav-item fs-7">
                            <button
                                type="button"
                                style="padding:7px;"
                                class="nav-link d-flex align-items-center gap-1"
                                data-bs-toggle="tab"
                                data-bs-target="#warehouse-stock"
                            >
                                <i class="mdi mdi-package-variant-closed"></i>
                                Stocks Present
                                <span class="badge bg-secondary ms-1">5</span>
                            </button>
                        </li>
                        <li class="nav-item fs-7">
                            <button
                                type="button"
                                style="padding:7px;"
                                class="nav-link d-flex align-items-center gap-1"
                                data-bs-toggle="tab"
                                data-bs-target="#warehouse-transfer"
                            >
                                <i class="mdi mdi-truck-outline"></i>
                                Stock in Transfer
                                <span class="badge bg-secondary ms-1">1</span>
                            </button>
                        </li>
                    </ul>
                    <button
                        type="button"
                        id="toggleRecordStockInward"
                        class="btn btn-primary btn-sm d-flex align-items-center gap-1"
                    >
                        <i class="mdi mdi-plus"></i>
                        Record Stock Inward
                    </button>
                </div>
            </div>
            <div class="modal-body bg-white p-3">
                <div
                    id="recordStockInward"
                    class="bg-label-primary border border-primary rounded-3 p-4 m-3 d-none"
                >
                    <div class="d-flex justify-content-between align-items-start mb-4">
                        <div>
                            <h6 class="fw-bold text-primary text-uppercase mb-1 d-flex align-items-center gap-1">
                                <i class="mdi mdi-plus"></i>
                                Record Material Stock Inward For Villupuram Highway Depot
                            </h6>
                        </div>
                        <button
                            type="button"
                            id="closeRecordStock"
                            class="btn btn-sm btn-link text-muted p-0 border border-secondary"
                            style="box-shadow: none;"
                            aria-label="Close"
                        >
                            <i class="mdi mdi-close fs-5"></i>
                        </button>
                    </div>
                    <div class="row g-3">
                        {{-- Project Name --}}
                        <div class="col-md-4">
                            <label for="recordMaterialName" class="form-label fw-semibold small">
                                Material Name
                            </label>
                            <input
                                type="text"
                                id="recordMaterialName"
                                name="material_name"
                                class="form-control"
                                placeholder="Enter Material Name"
                            >
                        </div>
                        {{-- Project Location --}}
                        <div class="col-md-4">
                            <label for="recordMaterialCategory" class="form-label fw-semibold small">
                                Material Category
                            </label>
                            <select
                                id="recordMaterialCategory"
                                name="material_category"
                                class="form-select select3"
                            >
                                <option value="Cement">Cement</option>
                                <option value="Bitumen">Bitumen</option>
                                <option value="Steel & Rebars">Steel & Rebars</option>
                                <option value="Chemicals & Additives">Chemicals & Additives</option>
                                <option value="Aggregates & M-Sand">Aggregates & M-Sand</option>
                                <option value="Pipes & MEP">Pipes & MEP</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="recordStockQuantity" class="form-label fw-semibold small">
                                Stock Quantity
                            </label>
                            <input
                                type="text"
                                id="recordStockQuantity"
                                name="stock_quantity"
                                class="form-control"
                                placeholder="Enter Stock Quantity"
                            >
                        </div>
                        <div class="col-md-4">
                            <label for="recordUnitMeasure" class="form-label fw-semibold small">
                                Unit Of Measure
                            </label>
                            <select
                                id="recordUnitMeasure"
                                name="unit_measure"
                                class="form-select select3"
                            >
                                <option value="Bags">Bags</option>
                                <option value="MT (Metric Tonnes)">MT (Metric Tonnes)</option>
                                <option value="Drums">Drums</option>
                                <option value="PCs">PCs</option>
                                <option value="Kgs">Kgs</option>
                                <option value="Sheets">Sheets</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="recordUnitRate" class="form-label fw-semibold small">
                                Unit Purchase Rate (₹)
                            </label>
                            <input
                                type="text"
                                id="recordUnitRate"
                                name="unit_rate"
                                class="form-control"
                                placeholder="Enter Unit Purchase Rate (₹)"
                            >
                        </div>
                        {{-- Generate --}}
                        <div class="col-md-4 d-flex align-items-end">
                            <button
                                type="button"
                                id="generateRecommendation"
                                class="btn btn-primary w-100"
                            >
                                <i class="mdi mdi-map-marker-distance me-1"></i>
                                Save Stock Inward
                            </button>
                        </div>
                    </div>
                </div>
                <div class="tab-content">
                    <div
                        class="tab-pane fade show active"
                        id="warehouse-overview"
                    >
                        <div class="card border-primary border-opacity-25 bg-label-primary bg-opacity-10 shadow-none mb-4">
                            <div class="card-body p-4">
                                <div class="d-flex justify-content-between align-items-start border-bottom border-primary border-opacity-25 pb-3 mb-3">
                                    <div>
                                        <span class="text-primary fw-bold text-uppercase small">
                                            Primary Response Person & Store Manager
                                        </span>
                                        <h5 class="fw-bold text-dark mb-1 mt-1">
                                            K. Subramaniam
                                        </h5>
                                        <p class="text-dark small fw-semibold mb-0">
                                            Assistant Depot Manager & Site Response Officer
                                        </p>
                                    </div>
                                    <span class="badge bg-success bg-opacity-10 text-success border border-success px-3 py-2 rounded-pill">
                                        <i class="mdi mdi-check-circle me-1"></i>
                                        Active Duty Assigned
                                    </span>
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <div class="bg-white border border-primary border-opacity-10 rounded-3 p-3 h-100">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Contact Phone Number
                                            </small>
                                            <a
                                                href="tel:+919842144521"
                                                class="text-primary fw-bold font-monospace text-decoration-none"
                                            >
                                                <i class="mdi mdi-phone-outline me-1"></i>
                                                +91 98421 44521
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="bg-white border border-primary border-opacity-10 rounded-3 p-3 h-100">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Official Email Address
                                            </small>
                                            <span class="text-dark fw-bold font-monospace small">
                                                <i class="mdi mdi-email-outline text-muted me-1"></i>
                                                k.subramaniam@srkinfra.com
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="bg-white border border-primary border-opacity-10 rounded-3 p-3 h-100">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Location Officer ID
                                            </small>
                                            <span class="text-dark fw-bold font-monospace small">
                                                <i class="mdi mdi-shield-check-outline text-primary me-1"></i>
                                                RESP-OFF-VPM-DEP
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card bg-light border shadow-none mb-4">
                            <div class="card-body p-4">
                                <h6 class="fw-bold text-uppercase text-dark mb-3">
                                    <i class="mdi mdi-map-marker-outline text-primary me-1"></i>
                                    Location Address & Regional Network
                                </h6>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <div class="bg-white border rounded-3 p-3 h-100">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Physical Address
                                            </small>
                                            <p class="fw-semibold text-dark small mb-0">
                                                NH-45 bypass, Near Toll Plaza,
                                                Villupuram, Tamil Nadu - 605602
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="bg-white border rounded-3 p-3 h-100">
                                            <div class="row">
                                                <div class="col-6">
                                                    <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                        City & District
                                                    </small>
                                                    <span class="fw-bold text-dark small">
                                                        Villupuram, Villupuram
                                                    </span>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                        State & Country
                                                    </small>
                                                    <span class="fw-bold text-dark small">
                                                        Tamil Nadu, India
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="bg-white border rounded-3 p-3">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-2">
                                                Mapped Highway / Rail Construction Projects
                                            </small>
                                            <span class="badge bg-label-primary bg-opacity-10 text-primary border border-primary border-opacity-25 px-3 py-2">
                                                East Coast Road Elevated Bridge
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="card border shadow-none h-100">
                                    <div class="card-body">
                                        <small class="text-muted fw-bold text-uppercase">
                                            Storage Area Capacity
                                        </small>
                                        <h4 class="fw-bold font-monospace text-dark mt-2 mb-1">
                                            25,000 sq.ft
                                        </h4>
                                        <small class="text-muted">
                                            Covered shed + open storage yard
                                        </small>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="card border shadow-none h-100">
                                    <div class="card-body">
                                        <small class="text-muted fw-bold text-uppercase">
                                            Capacity Utilization
                                        </small>
                                        <div class="d-flex align-items-center gap-2 mt-2">
                                            <h4 class="fw-bold font-monospace text-dark mb-0">
                                                58%
                                            </h4>
                                            <div class="progress flex-grow-1" style="height: 8px;">
                                                <div
                                                    class="progress-bar bg-primary"
                                                    role="progressbar"
                                                    style="width: 58%;"
                                                    aria-valuenow="58"
                                                    aria-valuemin="0"
                                                    aria-valuemax="100"
                                                ></div>
                                            </div>
                                        </div>
                                        <small class="text-muted">
                                            Optimal threshold below 85%
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border shadow-none h-100">
                                    <div class="card-body">
                                        <small class="text-muted fw-bold text-uppercase">
                                            Total Asset Stock Valuation
                                        </small>
                                        <h4 class="fw-bold font-monospace text-success mt-2 mb-1">
                                            ₹2,40,00,072
                                        </h4>
                                        <small class="text-muted">
                                            Verified as per central store ledger
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                        class="tab-pane fade"
                        id="warehouse-stock"
                    >
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="fw-bold mb-1">
                                    Stock Present
                                </h6>
                                <small class="text-muted">
                                    Materials and assets currently available at this warehouse.
                                </small>
                            </div>
                            <span class="badge bg-primary">
                                5 Items
                            </span>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Item</th>
                                        <th>Category</th>
                                        <th>Quantity</th>
                                        <th>Unit</th>
                                        <th>Value</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="fw-semibold">
                                            Cement
                                        </td>
                                        <td>Construction Material</td>
                                        <td class="fw-bold">1,250</td>
                                        <td>Bags</td>
                                        <td>₹5,62,500</td>
                                        <td>
                                            <span class="badge bg-success">
                                                Available
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-semibold">
                                            TMT Steel
                                        </td>
                                        <td>Steel Material</td>
                                        <td class="fw-bold">85</td>
                                        <td>MT</td>
                                        <td>₹5,10,000</td>
                                        <td>
                                            <span class="badge bg-success">
                                                Available
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-semibold">
                                            Aggregate
                                        </td>
                                        <td>Construction Material</td>
                                        <td class="fw-bold">320</td>
                                        <td>MT</td>
                                        <td>₹2,88,000</td>
                                        <td>
                                            <span class="badge bg-success">
                                                Available
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-semibold">
                                            Safety Helmets
                                        </td>
                                        <td>Safety Equipment</td>
                                        <td class="fw-bold">145</td>
                                        <td>Nos</td>
                                        <td>₹43,500</td>
                                        <td>
                                            <span class="badge bg-warning text-dark">
                                                Low Stock
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-semibold">
                                            Welding Machines
                                        </td>
                                        <td>Equipment</td>
                                        <td class="fw-bold">12</td>
                                        <td>Nos</td>
                                        <td>₹3,60,000</td>
                                        <td>
                                            <span class="badge bg-success">
                                                Available
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div
                            class="tab-pane fade"
                            id="warehouse-transfer"
                        >
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6 class="fw-bold mb-1">
                                        Stock in Transfer
                                    </h6>
                                    <small class="text-muted">
                                        Materials currently moving to or received by this warehouse.
                                    </small>
                                </div>
                                <span class="badge bg-warning text-dark fs-8">
                                    1 Transfer
                                </span>
                            </div>
                            {{-- Transfer Card --}}
                            <div class="card border shadow-none rounded-3 mb-3">
                                <div class="card-body p-4">
                                    <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-2 border-bottom pb-3 mb-3">
                                        <div class="d-flex align-items-center flex-wrap gap-2">
                                            <span class="badge bg-light text-dark border font-monospace px-2 py-1">
                                                TRF-2026-001
                                            </span>
                                            <span class="badge bg-success bg-opacity-10 text-success text-uppercase">
                                                Incoming Shipment
                                            </span>
                                        </div>
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success px-3 py-2">
                                            Status: Received
                                        </span>
                                    </div>
                                    <div class="row g-4">
                                        <div class="col-md-4">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                Material Transferred
                                            </small>
                                            <p class="fw-bold text-dark mb-1">
                                                Cement OPC 53 Grade
                                            </p>
                                            <span class="font-monospace fw-bold text-success">
                                                500 Bags
                                            </span>
                                        </div>
                                        <div class="col-md-4">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                Source / Destination Hub
                                            </small>
                                            <p class="fw-bold text-dark mb-1">
                                                Chennai Central Logistics Yard
                                                <span class="text-muted">
                                                    (WH-001)
                                                </span>
                                            </p>
                                            <small class="text-muted">
                                                Dispatched:
                                                <span class="font-monospace">
                                                    2026-07-22
                                                </span>
                                            </small>
                                        </div>
                                        <div class="col-md-4">
                                            <small class="text-muted fw-bold text-uppercase d-block mb-1">
                                                Vehicle & Driver Details
                                            </small>
                                            <p class="fw-bold font-monospace text-dark mb-1">
                                                TN-01-AX-9912
                                            </p>
                                            <p class="small text-dark mb-1">
                                                <i class="mdi mdi-account-outline text-muted me-1"></i>
                                                M. Sundaram
                                                <span class="text-muted">
                                                    (+91 97880 11223)
                                                </span>
                                            </p>
                                            <small class="text-warning fw-bold font-monospace">
                                                Expected ETA:
                                                2026-07-23
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            <div class="modal-footer bg-light border-top d-flex justify-content-between">
                <div class="text-muted small d-flex align-items-center gap-1">
                    <i class="mdi mdi-clock-outline"></i>
                    <span>
                        Last System Update:
                        <strong>2026-07-25 15:45</strong>
                    </span>
                </div>
                <button
                    type="button"
                    class="btn btn-dark"
                    data-bs-dismiss="modal"
                >
                    Close Inspector
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Client-side search + region filter --}}
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const searchInput = document.getElementById('warehouseSearch');
        const regionSelect = document.getElementById('regionFilter');
        const cards = document.querySelectorAll('.warehouse-card-col');

        function applyFilters() {
            const term = searchInput.value.trim().toLowerCase();
            const region = regionSelect.value;

            cards.forEach(function (col) {
                const matchesSearch = !term || col.dataset.search.includes(term);
                const matchesRegion = !region || col.dataset.region === region;
                col.style.display = (matchesSearch && matchesRegion) ? '' : 'none';
            });
        }

        searchInput.addEventListener('input', applyFilters);
        regionSelect.addEventListener('change', applyFilters);
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        const toggleButton = document.getElementById('toggleNearestSuggestion');
        const closeButton = document.getElementById('closeNearestSuggestion');
        const suggestionTool = document.getElementById('nearestSuggestionTool');

        toggleButton.addEventListener('click', function () {
            suggestionTool.classList.toggle('d-none');
        });

        closeButton.addEventListener('click', function () {
            suggestionTool.classList.add('d-none');
        });

    });
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const toggleButton = document.getElementById('toggleRecordStockInward');
    const closeButton = document.getElementById('closeRecordStock');
    const suggestionTool = document.getElementById('recordStockInward');

    toggleButton.addEventListener('click', function () {
        suggestionTool.classList.toggle('d-none');
    });

    closeButton.addEventListener('click', function () {
        suggestionTool.classList.add('d-none');
    });

});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const inspectionModal = document.getElementById('inspection_stock_modal');

    if (!inspectionModal) {
        return;
    }

    inspectionModal.addEventListener('show.bs.modal', function (event) {

        // Button which opened the modal
        const button = event.relatedTarget;

        if (!button) {
            return;
        }

        // Get the target tab
        const targetTab = button.getAttribute('data-inspection-tab');

        if (!targetTab) {
            return;
        }

        // Find the corresponding tab button
        const tabButton = inspectionModal.querySelector(
            `[data-bs-target="${targetTab}"]`
        );

        if (tabButton) {

            // Bootstrap 5 Tab API
            const tab = new bootstrap.Tab(tabButton);

            tab.show();
        }
    });

});
</script>
@endsection