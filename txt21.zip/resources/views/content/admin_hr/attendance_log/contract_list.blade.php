@extends('layouts.layoutMaster')

@section('title', 'Contract Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@php
$employmentType = 'Permanent';
$viewMode = 'List';

// ======= DEPARTMENTS =======
$departments = [
'ALL',
'Management',
'Engineering',
'Quality Control',
'Accounts',
'Purchase',
'Skilled Labor',
'General Labor',
];

$selectedDept = 'ALL';
@endphp

<div class="container-fluid px-0">

    {{-- ================= SUMMARY CARDS ================= --}}
    <div class="row g-3 mb-4">

        {{-- Permanent Pool --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary summary-card-label">
                        Permanent Pool
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value" style="color:#0C3C62;">
                        10 Staff
                    </span>
                </div>
            </div>
        </div>

        {{-- Present --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-success summary-card-label">
                        Checked In (Present)
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-success">
                        8 Present
                    </span>
                </div>
            </div>
        </div>

        {{-- Absent --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-danger summary-card-label">
                        Unexcused Absences
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-danger">
                        1 Absent
                    </span>
                </div>
            </div>
        </div>

        {{-- Leave --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-warning summary-card-label">
                        Sabbatical & Leaves
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-warning">
                        1 On Leave
                    </span>
                </div>
            </div>
        </div>

    </div>

    {{-- ================= STAFF HEADER ================= --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="d-flex flex-column flex-md-row
                    justify-content-between
                    align-items-start
                    align-items-md-center
                    gap-3">

                {{-- TITLE --}}
                <div class="w-100 w-md-auto">
                    <div class="px-3 py-2 bg-white">

                        <span class="fw-bold" style="font-size:20px;color:#0C3C62;">
                            Contract Staff
                        </span>

                    </div>
                </div>


                {{-- VIEW SWITCH --}}
                <div class="d-flex justify-content-start justify-content-md-end w-100 w-md-auto">

                    <div class="btn-group responsive-view-buttons" role="group">

                        {{-- LIST --}}
                        <a href="{{ url('/admin-hr/contract-log') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('/admin-hr/contract-log') ? 'active' : '' }}">

                            <span class="mdi mdi-format-list-bulleted me-1"></span>
                            List View

                        </a>


                        {{-- TABLE --}}
                        <a href="{{ url('/admin-hr/contact-log/table') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('/admin-hr/contact-log/table  ') ? 'active' : '' }}">

                            <span class="mdi mdi-table me-1"></span>
                            Table View

                        </a>


                        {{-- CALENDAR --}}
                        <a href="{{ url('admin-hr/permanent-log/calender') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log/calender') ? 'active' : '' }}">

                            <span class="mdi mdi-calendar-month me-1"></span>
                            Calendar View

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

    {{-- ================= MINI DASHBOARD STYLES ================= --}}
    <style>
    .summary-card .card-body {
        min-height: 75px;
    }

    .summary-card-label {
        font-size: 9px;
        letter-spacing: .5px;
        line-height: 1.4;
    }

    .summary-card-value {
        font-size: 1.25rem;
        line-height: 1.3;
        margin-top: 4px;
    }

    .view-mode-container {
        background: #f1f5f9;
    }
    </style>

    {{-- ================= FILTER SECTION ================= --}}
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-3">

            <div class="attendance-filter-row">

                {{-- ================= SEARCH ================= --}}
                <div class="attendance-search">
                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                            style="pointer-events:none;">
                            <i class="mdi mdi-magnify"></i>
                        </span>

                        <input id="hr-search-field" type="text" placeholder="Search personnel..."
                            class="form-control form-control-sm ps-5 bg-light border-0 rounded-3">

                    </div>
                </div>

                {{-- ================= DEPARTMENT FILTERS ================= --}}
                <div class="attendance-departments">

                    <div class="department-scroll">

                        @foreach ($departments as $dept)

                        <button type="button" id="hr-dept-tab-{{ Str::slug($dept) }}" data-department="{{ $dept }}"
                            class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn
                                        {{ $selectedDept === $dept ? 'active' : '' }}">
                            {{ $dept === 'ALL' ? 'All' : $dept }}
                        </button>

                        @endforeach

                    </div>

                </div>

            </div>

        </div>
    </div>

    {{-- ================= ATTENDANCE TABLE ================= --}}
    <div class="card border-0 shadow-sm rounded-4">

        <div class="table-responsive">

            <table class="table table-hover mb-0" id="attendance-table">

                <thead>
                    <tr style="background-color:#f8fafc;">

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Personnel Information
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Department Unit
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Site / Project Allocation
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Monthly Rate
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Last Toggle Action
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Checklist Status
                        </th>

                    </tr>
                </thead>

                <tbody>

                    {{-- ================= EMPLOYEE 1 ================= --}}
                    <tr data-department="Management">

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-3">

                                <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                                    style="
                                            width:36px;
                                            height:36px;
                                            background:#f1f5f9;
                                            color:#475569;
                                        ">
                                    <i class="mdi mdi-account"></i>
                                </div>

                                <div>
                                    <div class="fw-bold text-dark">
                                        Arun Kumar
                                    </div>

                                    <small class="text-muted">
                                        SRK-EMP-001 • Project Manager
                                    </small>
                                </div>

                            </div>
                        </td>

                        <td class="py-3">
                            <span class="badge rounded-2" style="
                                        background:#f1f5f9;
                                        color:#475569;
                                        font-size:9px;
                                    ">
                                Management
                            </span>
                        </td>

                        <td class="py-3 fw-semibold text-secondary">
                            Chennai Metro Phase 1
                        </td>

                        <td class="py-3 fw-bold font-monospace" style="color:#0C3C62;">
                            $250
                        </td>

                        <td class="py-3">
                            <div class="d-flex flex-wrap gap-1">

                                <button type="button" class="btn btn-sm attendance-btn present-btn active-status">
                                    Present
                                </button>

                                <button type="button" class="btn btn-sm attendance-btn absent-btn">
                                    Absent
                                </button>

                                <button type="button" class="btn btn-sm attendance-btn leave-btn">
                                    Leave
                                </button>

                            </div>
                        </td>

                        <td class="py-3 px-4 text-center">
                            <span class="status-text present-status">
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Attended Site
                            </span>
                        </td>

                    </tr>

                    {{-- ================= EMPLOYEE 2 ================= --}}
                    <tr data-department="Engineering">

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-3">

                                <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                                    style="
                                            width:36px;
                                            height:36px;
                                            background:#f1f5f9;
                                            color:#475569;
                                        ">
                                    <i class="mdi mdi-account"></i>
                                </div>

                                <div>
                                    <div class="fw-bold text-dark">
                                        Suresh Raj
                                    </div>

                                    <small class="text-muted">
                                        SRK-EMP-002 • Civil Engineer
                                    </small>
                                </div>

                            </div>
                        </td>

                        <td class="py-3">
                            <span class="badge rounded-2" style="
                                        background:#f1f5f9;
                                        color:#475569;
                                        font-size:9px;
                                    ">
                                Engineering
                            </span>
                        </td>

                        <td class="py-3 fw-semibold text-secondary">
                            Chennai Metro Phase 2
                        </td>

                        <td class="py-3 fw-bold font-monospace" style="color:#0C3C62;">
                            $180
                        </td>

                        <td class="py-3">
                            <div class="d-flex flex-wrap gap-1">

                                <button type="button" class="btn btn-sm attendance-btn present-btn">
                                    Present
                                </button>

                                <button type="button" class="btn btn-sm attendance-btn absent-btn active-status">
                                    Absent
                                </button>

                                <button type="button" class="btn btn-sm attendance-btn leave-btn">
                                    Leave
                                </button>

                            </div>
                        </td>

                        <td class="py-3 px-4 text-center">
                            <span class="status-text absent-status">
                                <i class="mdi mdi-close-circle-outline me-1"></i>
                                Deducted Wage
                            </span>
                        </td>

                    </tr>

                    {{-- ================= EMPLOYEE 3 ================= --}}
                    <tr data-department="General Labor">

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-3">

                                <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                                    style="
                                            width:36px;
                                            height:36px;
                                            background:#f1f5f9;
                                            color:#475569;
                                        ">
                                    <i class="mdi mdi-account"></i>
                                </div>

                                <div>
                                    <div class="fw-bold text-dark">
                                        Priya Devi
                                    </div>

                                    <small class="text-muted">
                                        SRK-EMP-003 • Supervisor
                                    </small>
                                </div>

                            </div>
                        </td>

                        <td class="py-3">
                            <span class="badge rounded-2" style="
                                        background:#f1f5f9;
                                        color:#475569;
                                        font-size:9px;
                                    ">
                                General Labor
                            </span>
                        </td>

                        <td class="py-3 fw-semibold text-secondary">
                            Chennai Metro Phase 1
                        </td>

                        <td class="py-3 fw-bold font-monospace" style="color:#0C3C62;">
                            $145
                        </td>

                        <td class="py-3">
                            <div class="d-flex flex-wrap gap-1">

                                <button type="button" class="btn btn-sm attendance-btn present-btn">
                                    Present
                                </button>

                                <button type="button" class="btn btn-sm attendance-btn absent-btn">
                                    Absent
                                </button>

                                <button type="button" class="btn btn-sm attendance-btn leave-btn active-status">
                                    Leave
                                </button>

                            </div>
                        </td>

                        <td class="py-3 px-4 text-center">
                            <span class="status-text leave-status">
                                <i class="mdi mdi-alert-circle-outline me-1"></i>
                                Excused Rest
                            </span>
                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

    </div>

</div>

{{-- ================= FILTER STYLES ================= --}}
<style>
.attendance-filter-row {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    min-width: 0;
}

.attendance-search {
    flex: 0 0 180px;
    width: 180px;
    min-width: 180px;
}

.attendance-search .position-relative {
    width: 100%;
}

#hr-search-field {
    width: 100%;
    height: 36px;
    font-size: 11px;
    padding-right: 8px;
}

.attendance-departments {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
}

.department-scroll {
    display: flex;
    align-items: center;
    gap: 5px;
    width: 100%;
    min-width: 0;
    overflow-x: auto;
    overflow-y: hidden;
    white-space: nowrap;
    scrollbar-width: none;
    -ms-overflow-style: none;
    padding: 1px 0;
}

.department-scroll::-webkit-scrollbar {
    display: none;
}

.dept-filter-btn {
    flex: 0 0 auto;
    height: 36px;
    padding: 0 12px !important;
    font-size: 10px;
    background-color: #f8fafc;
    color: #475569;
    border: 1px solid transparent;
    white-space: nowrap;
    transition: all 0.2s ease;
}

.dept-filter-btn:hover {
    background-color: #e2e8f0;
    color: #0f172a;
}

.dept-filter-btn.active {
    background-color: #16659E !important;
    color: #ffffff !important;
    border-color: #16659E;
    box-shadow: 0 2px 5px rgba(22, 101, 158, 0.20);
}

/* ================= LARGE DESKTOP ================= */
@media (min-width: 1400px) {
    .attendance-search {
        flex: 0 0 180px;
        width: 180px;
        min-width: 180px;
    }

    .attendance-filter-row {
        gap: 8px;
    }

    .dept-filter-btn {
        padding-left: 10px !important;
        padding-right: 10px !important;
    }
}

/* ================= DESKTOP ================= */
@media (min-width: 1200px) and (max-width: 1399.98px) {
    .attendance-search {
        flex: 0 0 160px;
        width: 160px;
        min-width: 160px;
    }

    .dept-filter-btn {
        padding-left: 8px !important;
        padding-right: 8px !important;
        font-size: 9px;
    }
}

/* ================= TABLET ================= */
@media (min-width: 768px) and (max-width: 1199.98px) {
    .attendance-search {
        flex: 0 0 150px;
        width: 150px;
        min-width: 150px;
    }

    .dept-filter-btn {
        padding-left: 9px !important;
        padding-right: 9px !important;
        font-size: 9px;
    }
}

/* ================= MOBILE ================= */
@media (max-width: 767.98px) {
    .attendance-filter-row {
        flex-direction: column;
        align-items: stretch;
        gap: 10px;
    }

    .attendance-search {
        width: 100%;
        min-width: 0;
        flex: none;
    }

    .attendance-departments {
        width: 100%;
    }

    .department-scroll {
        overflow-x: auto;
    }

    .dept-filter-btn {
        font-size: 10px;
        padding-left: 10px !important;
        padding-right: 10px !important;
    }
}

/* ===============================
   RESPONSIVE VIEW SWITCH
================================ */

.responsive-view-buttons {
    white-space: nowrap;
}

/* Tablet */
@media (max-width: 991.98px) {

    .responsive-view-buttons .btn {
        padding-left: 10px !important;
        padding-right: 10px !important;
        font-size: 11px;
    }

}

/* Mobile */
@media (max-width: 575.98px) {

    .responsive-view-buttons {
        width: 100%;
        display: flex;
    }

    .responsive-view-buttons .btn {
        flex: 1 1 0;
        padding: 8px 5px !important;
        font-size: 10px;
        white-space: nowrap;
    }

    .responsive-view-buttons .mdi {
        margin-right: 2px !important;
    }

}

/* Very small mobile */
@media (max-width: 400px) {

    .responsive-view-buttons .btn {
        padding: 7px 3px !important;
        font-size: 9px;
    }

    .responsive-view-buttons .mdi {
        display: none;
    }

}
</style>

@endsection
