@php
  $configData = Helper::appClasses();
  $currentRouteName = Route::currentRouteName();

  $menuJson  = File::get(resource_path('menu/verticalMenu.json'));
  $menuItems = json_decode(file_get_contents(resource_path('menu/verticalMenu.json')))->menu;
@endphp

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme d-flex flex-column" style="background-color: #0F172B !important;">

  @if(!isset($navbarFull))
  <div class="app-brand demo m-2">
    <a href="{{ url('/dashboards') }}" class="app-brand-link">
      <img src="{{ asset('assets/img/Ryans-Logo.png') }}" class="app-brand-logo demo bg-white rounded p-2 ms-12" width="85" height="65" alt="Ryan Infra Logo">
      <!-- <span class="app-brand-text demo menu-text fw-bold ms-3 fs-6 text-white">Ryans Infra</span> -->
    </a>
    <a href="javascript:;" class="layout-menu-toggle menu-link text-large ms-auto">
      <span class="mdi mdi-chevron-double-right text-white fs-3"></span>
    </a>
  </div>
  @endif

  <ul class="menu-inner py-1 flex-grow-1 overflow-auto">
    <!-- @foreach ($menuItems as $menu)
      @php
        $activeClass = null;
        $isOpen = false;

        if ($currentRouteName === $menu->slug) {
          $activeClass = 'active';
        } elseif (isset($menu->submenu)) {
          $slugs = is_array($menu->slug ?? null) ? $menu->slug : [$menu->slug ?? null];

          if (in_array($currentRouteName, $slugs, true)) {
            $activeClass = 'active';
          } elseif (isset($menu->submenu)) {
            foreach ($slugs as $slug) {
              if ($slug && str_contains($currentRouteName, $slug) && strpos($currentRouteName, $slug) === 0) {
                $activeClass = 'active open';
                $isOpen = true;
              }
            }
          }
        }
      @endphp

      <li class="menu-item {{ $activeClass }}">
        <a href="{{ isset($menu->url) ? url($menu->url) : 'javascript:;' }}"
           class="{{ isset($menu->submenu) ? 'menu-link menu-toggle' : 'menu-link' }}">
          <i class="{{ $menu->icon }} me-1"></i>
          <div class="d-flex flex-column">
            <span class="fs-7 fw-medium">{{ $menu->name }}</span>
            @isset($menu->desc)
              <span class="menu-item-desc" style="font-size: 10px; line-height: 1; opacity: .6;">{{ $menu->desc }}</span>
            @endisset
          </div>
        </a>

        @isset($menu->submenu)
          @include('layouts.sections.menu.submenu', ['menu' => $menu->submenu])
        @endisset
      </li>
    @endforeach -->
      @include('layouts.sections.menu.item', ['items' => $menuItems, 'depth' => 0])
  </ul>

  {{-- Role selector + profile footer (from Sidebar.tsx bottom section) --}}
  <div class="menu-footer border-top border-secondary p-3" style="background-color: rgba(2,6,23,.4);">

    <div class="d-flex align-items-center">
      <div class="avatar avatar-sm me-2 shrink-0">
        <span class="avatar-initial rounded-circle bg-label-primary">{{ Auth::user()->initials ?? 'SA' }}</span>
      </div>
      <div class="d-menu-expanded-block text-truncate">
        <span class="d-block text-white fw-semibold small text-truncate">{{ Auth::user()->name ?? 'Super Admin' }}</span>
        <span class="d-block text-white-50 text-truncate" style="font-size: 10px;">{{ Auth::user()->email ?? 'superadmin@mail.com' }}</span>
      </div>
    </div>
  </div>

</aside>