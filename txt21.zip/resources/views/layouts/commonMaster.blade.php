<!DOCTYPE html>
@php
$menuFixed = ($configData['layout'] === 'vertical') ? ($menuFixed ?? '') : (($configData['layout'] === 'front') ? '' : $configData['headerType']);
$navbarType = ($configData['layout'] === 'vertical') ? $configData['navbarType']: (($configData['layout'] === 'front') ? 'layout-navbar-fixed': '');
$isFront = ($isFront ?? '') == true ? 'Front' : '';
$contentLayout = (isset($container) ? (($container === 'container-xxl') ? "layout-compact" : "layout-wide") : "");
@endphp

<html id="project_tag" lang="{{ session()->get('locale') ?? app()->getLocale() }}" class="{{ $configData['style'] }}-style {{($contentLayout ?? '')}} {{ ($navbarType ?? '') }} {{ ($menuFixed ?? '') }} {{ $menuCollapsed ?? '' }} {{ $menuFlipped ?? '' }} {{ $menuOffcanvas ?? '' }} {{ $footerFixed ?? '' }} {{ $customizerHidden ?? '' }}" dir="{{ $configData['textDirection'] }}" data-theme="{{ $configData['theme'] }}" data-assets-path="{{ asset('/assets') . '/' }}" data-base-url="{{url('/')}}" data-framework="laravel" data-template="{{ $configData['layout'] . '-menu-' . $configData['themeOpt'] . '-' . $configData['styleOpt'] }}">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title>Ryan Infra | @yield('title')</title>
  <meta name="description" content="{{ config('variables.templateDescription') ? config('variables.templateDescription') : '' }}" />
  <meta name="keywords" content="{{ config('variables.templateKeyword') ? config('variables.templateKeyword') : '' }}">
  <!-- laravel CRUD token -->
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <!-- Canonical SEO -->
  <link rel="canonical" href="{{ config('variables.productPage') ? config('variables.productPage') : '' }}">
  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="{{ asset('assets/img/Ryans-Fav-icon.png') }}" />
  <link href="{{url ('assets/custom_file/swal2.css')}}" rel="stylesheet" type="text/css" />

  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

  <!-- Include Styles -->
  <!-- $isFront is used to append the front layout styles only on the front layout otherwise the variable will be blank -->
  @include('layouts/sections/styles' . $isFront)

  <!-- Include Scripts for customizer, helper, analytics, config -->
  <!-- $isFront is used to append the front layout scriptsIncludes only on the front layout otherwise the variable will be blank -->
  @include('layouts/sections/scriptsIncludes' . $isFront)

</head>

<script src="{{url ('assets/custom_file/jquery-3.7.1.js')}}"></script>
<script src="{{url ('assets/custom_file/dataTables.js')}}"></script>
<script src="{{url ('assets/custom_file/dataTables.bootstrap5.js')}}"></script>
<!-- <script src="{{url ('assets/custom_file/fslightbox.bundle.js')}}"></script> -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.11/clipboard.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
  <!-- <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
  <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/plugins/weekSelect/weekSelect.js"></script> -->
<style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
            z-index: 99999999 !important;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
            z-index: 99999999 !important;
        }
    </style>
  <style>
        .skeleton-loader {
            /*display: flex;*/
            /*flex-direction: row;*/
            /*gap: 10px;*/
        }

        .skeleton-row {
            display: flex;
            flex-direction: row;
            gap: 10px;
        }

        .skeleton {
            width: 100%;
            height: 30px; /* Adjust height as needed */
            background: linear-gradient(90deg, #e0e0e0 25%, #f0f0f0 50%, #e0e0e0 75%);
            background-size: 200% 100%;
            border-radius: 4px;
            animation: loading 1.2s infinite;
        }

        .skeleton-cell {
            flex: 1;
            height: 40px; /* Match the row height */
        }

        /*@keyframes loading {*/
        /*    0% { background-position: 200% 0; }*/
        /*    100% { background-position: -200% 0; }*/
        /*}*/
        
        .skeleton-loader-view {
            background-color: #e0e0e0;
            background-image: linear-gradient(90deg, #e0e0e0 25%, #f0f0f0 50%, #e0e0e0 75%);
            background-size: 200% 100%;
            animation: loading 1.2s infinite;
            border-radius: 4px;
            height: 20px;
        }
          
        .skeleton-loader-view.max-w-75 {
            width: 75%;
        }
          
        @keyframes loading {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }
    </style>

<body>

  <!-- Layout Content -->
  @yield('layoutContent')
  <!--/ Layout Content -->



  <!-- Include Scripts -->
  <!-- $isFront is used to append the front layout scripts only on the front layout otherwise the variable will be blank -->
  @include('layouts/sections/scripts' . $isFront)
  <!-- <script>
    const textarea = document.querySelector("txt_area");
    autosize(textarea);
  </script> -->
  <!-- Modal Dropdown box start -->
  <script>
    'use strict';
    $(function() {
      const select2 = $('.select3');
      if (select2.length) {
        select2.each(function() {
          var $this = $(this);
          select2Focus($this);
          $this.wrap('<div class="position-relative"></div>').select2({
            // placeholder: 'Select value',
            dropdownParent: $this.parent()
          });
        });
      }
    });
  </script>
  <!-- Modal Dropdown box end -->
  <!-- Modal Dropdown box(Multi Select) start -->
  <script>
    'use strict';
    $(function() {
      const select2 = $('.select4');
      if (select2.length) {
        select2.each(function() {
          var $this = $(this);
          select2Focus($this);
          $this.wrap('<div class="position-relative"></div>').select2({
            placeholder: 'Select',
            dropdownParent: $this.parent()
          });
        });
      }
    });
  </script>
  <!-- Modal Dropdown box(Multi Select) end -->
  <script>
    $('[data-bs-toggle="tooltip"]').on("mouseleave", function() {
      $(this).tooltip("hide");
    })
  </script>


</body>

</html>