<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;

class Client extends Controller
{
    public function index()
    {
        return view('content.sitelog.manageclient');
    }
}
