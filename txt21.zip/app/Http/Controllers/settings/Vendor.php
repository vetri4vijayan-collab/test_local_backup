<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Vendor extends Controller
{
  public function index()
  {
    return view('content.settings.site_log.vendor_settiing');
  }

}
