<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UserRole extends Controller
{
  public function index()
  {
    return view('content.settings.users_role');
  }
}
