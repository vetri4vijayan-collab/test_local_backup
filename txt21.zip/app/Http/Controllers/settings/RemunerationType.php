<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RemunerationType extends Controller
{
  public function index()
  {
    return view('content.settings.adminhr.remuneration_type');
  }
}
