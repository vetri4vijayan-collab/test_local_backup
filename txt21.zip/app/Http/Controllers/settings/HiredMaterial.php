<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HiredMaterial extends Controller
{
  public function index()
  {
    return view('content.settings.store_purchase.hired_material');
  }
}
