<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;

class Shiftsettings extends Controller
{
    public function index()
    {
        return view('content.settings.adminhr.shift_setting');
    }
}
