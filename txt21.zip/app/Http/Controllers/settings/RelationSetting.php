<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RelationSetting extends Controller
{
  public function index()
  {
    return view('content.settings.common.relation_setting');
  }
}
