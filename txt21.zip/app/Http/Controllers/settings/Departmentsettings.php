<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;

class Departmentsettings extends Controller
{
    public function index()
    {
        return view('content.settings.adminhr.department_setting');
    }
}
