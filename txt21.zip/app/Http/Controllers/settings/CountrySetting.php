<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CountrySetting extends Controller
{
  public function index()
  {
    return view('content.settings.common.country_setting');
  }

}
