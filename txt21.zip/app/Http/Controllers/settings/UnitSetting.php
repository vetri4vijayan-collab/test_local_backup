<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UnitSetting extends Controller
{
  public function index()
  {
    return view('content.settings.common.unit_setting');
  }

}
