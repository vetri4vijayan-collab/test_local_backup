<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;

class Designationsettings extends Controller
{
    public function index()
    {
        return view('content.settings.adminhr.designation_setting');
    }
}
