<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;

class Gradelistsettings extends Controller
{
    public function index()
    {
        return view('content.settings.adminhr.gradelist_setting');
    }
}
