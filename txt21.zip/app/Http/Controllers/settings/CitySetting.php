<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CitySetting extends Controller
{
  public function index()
  {
    return view('content.settings.common.city_setting');
  }

}