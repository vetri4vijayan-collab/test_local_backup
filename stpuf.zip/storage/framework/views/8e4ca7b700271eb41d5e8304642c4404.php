<?php
    use Illuminate\Support\Str;

    $currentRouteName = Route::currentRouteName();
    $configData = Helper::appClasses();
    $isVertical = ($configData['layout'] ?? 'vertical') === 'vertical';

    /*
    |--------------------------------------------------------------------------
    | Recursive active route checker
    |--------------------------------------------------------------------------
    */
    $isItemActive = function ($item) use (&$isItemActive, $currentRouteName) {

        $slugs = is_array($item->slug ?? null)
            ? $item->slug
            : [$item->slug ?? null];

        // Exact match
        foreach ($slugs as $slug) {
            if ($slug && $currentRouteName === $slug) {
                return true;
            }
        }

        // Check all children recursively
        if (isset($item->submenu)) {
            foreach ($item->submenu as $child) {
                if ($isItemActive($child)) {
                    return true;
                }
            }
        }

        return false;
    };
?>


<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        $hasSubmenu = isset($item->submenu);

        /*
        |--------------------------------------------------------------------------
        | Determine whether this item or any child is active
        |--------------------------------------------------------------------------
        */
        $isActive = $isItemActive($item);

        /*
        |--------------------------------------------------------------------------
        | Exact match for this particular item
        |--------------------------------------------------------------------------
        */
        $slugs = is_array($item->slug ?? null)
            ? $item->slug
            : [$item->slug ?? null];

        $isExactMatch = false;

        foreach ($slugs as $slug) {
            if ($slug && $currentRouteName === $slug) {
                $isExactMatch = true;
                break;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Parent with active child
        |--------------------------------------------------------------------------
        */
        $activeClass = null;

        if ($isExactMatch) {

            $activeClass = 'active';

        } elseif ($hasSubmenu && $isActive) {

            $activeClass = $isVertical
                ? 'active open'
                : 'active';
        }
    ?>


    <li class="menu-item <?php echo e($activeClass); ?>">

        <a
            href="<?php echo e(isset($item->url) ? url($item->url) : 'javascript:void(0)'); ?>"
            class="<?php echo e($hasSubmenu ? 'menu-link menu-toggle' : 'menu-link'); ?>"
            <?php if(!empty($item->target)): ?> target="_blank" <?php endif; ?>
        >

            <?php if(isset($item->icon)): ?>
                <i class="<?php echo e($item->icon); ?> me-1"></i>
            <?php endif; ?>

            <div class="d-flex flex-column">

                <span class="fs-7 fw-medium">
                    <?php echo e(__($item->name)); ?>

                </span>

                <?php if(isset($item->desc)): ?>
                    <span
                        class="menu-item-desc"
                        style="font-size: 10px; line-height: 1; opacity: .6;"
                    >
                        <?php echo e($item->desc); ?>

                    </span>
                <?php endif; ?>

            </div>

            <?php if(isset($item->badge)): ?>
                <div class="badge bg-<?php echo e($item->badge[0]); ?> rounded-pill ms-auto">
                    <?php echo e($item->badge[1]); ?>

                </div>
            <?php endif; ?>

        </a>


        <?php if($hasSubmenu): ?>

            <?php echo $__env->make('layouts.sections.menu.submenu', [
                'menu' => $item->submenu
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php endif; ?>

    </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/layouts/sections/menu/item.blade.php ENDPATH**/ ?>