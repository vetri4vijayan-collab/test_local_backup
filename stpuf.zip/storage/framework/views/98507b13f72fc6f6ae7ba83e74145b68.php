<?php $__env->startSection('title', 'State Settings - Common Settings'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('layouts.sections.settings.settings-header', ['activeTab' => 'common'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="row g-4">
    
    <?php echo $__env->make('layouts.sections.settings.settings-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Right Area: Main Settings Content & Table -->
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2 text-start">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-map-marker-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">State Settings</h5>
                        <small class="text-muted">Manage state and province rules mapped to configured countries</small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#stateSettingModal" onclick="resetForm()">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add State Setting</span>
                </button>
            </div>

            
            <div class="card-body pt-4">

                
                <div class="row g-3 mb-4 justify-content-between align-items-center">
                    <div class="col-12 col-md-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search state, country, or description..." />
                        </div>
                    </div>
                    <div class="col-12 col-md-3">
                        <select class="form-select select2" id="filterCountry">
                            <option value="">All Countries</option>
                            <option value="US">United States</option>
                            <option value="IN">India</option>
                        </select>
                    </div>
                </div>

                
                <div class="table-responsive text-nowrap rounded border">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr class="bg-light">
                                <th>Country</th>
                                <th>State / Province</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th class="text-end">
                                    Actions</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">United States</span>
                                </td>
                                <td><span class="fw-semibold">California</span></td>
                                <td><span class="text-truncate d-inline-block" style="max-width: 300px;">West coast
                                        operations center and regional tax zone.</span></td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#stateSettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteStateModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">India</span>
                                </td>
                                <td><span class="fw-semibold">Tamil Nadu</span></td>
                                <td><span class="text-truncate d-inline-block" style="max-width: 300px;">Primary
                                        southern regional hub with localized rules.</span></td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#stateSettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteStateModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="stateSettingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="stateModalTitle">State Setting</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="stateSettingForm" action="#" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="state_id" name="state_id" value="">

                <div class="modal-body text-start">
                    
                    <div class="mb-3">
                        <label for="country_id" class="form-label fw-semibold">Country <span
                                class="text-danger">*</span></label>
                        <select id="country_id" name="country_id" class="form-select select3" required>
                            <option value="" disabled selected>Select a country</option>
                            <option value="1">United States</option>
                            <option value="2">India</option>
                            <option value="3">United Kingdom</option>
                        </select>
                    </div>

                    
                    <div class="mb-3">
                        <label for="state_name" class="form-label fw-semibold">State / Province Name <span
                                class="text-danger">*</span></label>
                        <input type="text" id="state_name" name="state_name" class="form-control"
                            placeholder="e.g. California, Tamil Nadu, Ontario" required />
                    </div>

                    
                    <div class="mb-3">
                        <label for="description" class="form-label fw-semibold">Description</label>
                        <textarea id="description" name="description" class="form-control" rows="3"
                            placeholder="Enter state specific notes, rules, or configurations..."></textarea>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>Save Setting</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>


<div class="modal fade" id="deleteStateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">
            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                    style="width: 56px; height: 56px;">
                    <i class="mdi mdi-alert-outline fs-2 text-danger"></i>
                </div>
                <h6 class="fw-bold mb-1">Delete State Setting?</h6>
                <p class="text-muted text-xs mb-0">This action cannot be undone.</p>
            </div>
            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button" class="btn btn-sm btn-outline-secondary px-3"
                    data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-sm btn-danger px-3">Delete</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Select2 dropdowns if jQuery & Select2 are loaded
    if (typeof $ !== 'undefined' && $.fn.select2) {
        $('.select2').select2();
        $('.select2-modal').select2({
            dropdownParent: $('#stateSettingModal')
        });
    }

    // Client-side active pill switching
    const navLinks = document.querySelectorAll('.nav-pills .nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            navLinks.forEach(item => {
                item.classList.remove('active');
                item.classList.add('text-muted');
            });
            this.classList.add('active');
            this.classList.remove('text-muted');
        });
    });
});

function resetForm() {
    document.getElementById('stateSettingForm').reset();
    document.getElementById('state_id').value = '';
    document.getElementById('stateModalTitle').innerText = 'Add State Setting';
    if (typeof $ !== 'undefined' && $.fn.select2) {
        $('.select2-modal').val('').trigger('change');
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/content/settings/common/state_setting.blade.php ENDPATH**/ ?>