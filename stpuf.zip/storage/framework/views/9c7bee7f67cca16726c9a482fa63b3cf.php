<?php
  $configData = Helper::appClasses();
  $currentRouteName = Route::currentRouteName();

  $menuJson  = File::get(resource_path('menu/verticalMenu.json'));
  $menuItems = json_decode(file_get_contents(resource_path('menu/verticalMenu.json')))->menu;
?>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme d-flex flex-column" style="background-color: #0F172B !important;">

  <?php if(!isset($navbarFull)): ?>
  <div class="app-brand demo m-2">
    <a href="<?php echo e(url('/dashboards')); ?>" class="app-brand-link">
      <img src="<?php echo e(asset('assets/img/Ryans-Logo.png')); ?>" class="app-brand-logo demo bg-white rounded p-2 ms-12" width="85" height="65" alt="Ryan Infra Logo">
      <!-- <span class="app-brand-text demo menu-text fw-bold ms-3 fs-6 text-white">Ryans Infra</span> -->
    </a>
    <a href="javascript:;" class="layout-menu-toggle menu-link text-large ms-auto">
      <span class="mdi mdi-chevron-double-right text-white fs-3"></span>
    </a>
  </div>
  <?php endif; ?>

  <ul class="menu-inner py-1 flex-grow-1 overflow-auto">
    <!-- <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $activeClass = null;
        $isOpen = false;

        if ($currentRouteName === $menu->slug) {
          $activeClass = 'active';
        } elseif (isset($menu->submenu)) {
          $slugs = is_array($menu->slug ?? null) ? $menu->slug : [$menu->slug ?? null];

          if (in_array($currentRouteName, $slugs, true)) {
            $activeClass = 'active';
          } elseif (isset($menu->submenu)) {
            foreach ($slugs as $slug) {
              if ($slug && str_contains($currentRouteName, $slug) && strpos($currentRouteName, $slug) === 0) {
                $activeClass = 'active open';
                $isOpen = true;
              }
            }
          }
        }
      ?>

      <li class="menu-item <?php echo e($activeClass); ?>">
        <a href="<?php echo e(isset($menu->url) ? url($menu->url) : 'javascript:;'); ?>"
           class="<?php echo e(isset($menu->submenu) ? 'menu-link menu-toggle' : 'menu-link'); ?>">
          <i class="<?php echo e($menu->icon); ?> me-1"></i>
          <div class="d-flex flex-column">
            <span class="fs-7 fw-medium"><?php echo e($menu->name); ?></span>
            <?php if(isset($menu->desc)): ?>
              <span class="menu-item-desc" style="font-size: 10px; line-height: 1; opacity: .6;"><?php echo e($menu->desc); ?></span>
            <?php endif; ?>
          </div>
        </a>

        <?php if(isset($menu->submenu)): ?>
          <?php echo $__env->make('layouts.sections.menu.submenu', ['menu' => $menu->submenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
      <?php echo $__env->make('layouts.sections.menu.item', ['items' => $menuItems, 'depth' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </ul>

  
  <div class="menu-footer border-top border-secondary p-3" style="background-color: rgba(2,6,23,.4);">

    <div class="d-flex align-items-center">
      <div class="avatar avatar-sm me-2 shrink-0">
        <span class="avatar-initial rounded-circle bg-label-primary"><?php echo e(Auth::user()->initials ?? 'SA'); ?></span>
      </div>
      <div class="d-menu-expanded-block text-truncate">
        <span class="d-block text-white fw-semibold small text-truncate"><?php echo e(Auth::user()->name ?? 'Super Admin'); ?></span>
        <span class="d-block text-white-50 text-truncate" style="font-size: 10px;"><?php echo e(Auth::user()->email ?? 'superadmin@mail.com'); ?></span>
      </div>
    </div>
  </div>

</aside><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/layouts/sections/menu/verticalMenu.blade.php ENDPATH**/ ?>