<?php $__env->startSection('title', 'Department'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('layouts.sections.settings.settings-header', [
    'activeTab' => 'admin_hr'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .department-status {
        width: 50px !important;
        height: 26px !important;
        cursor: pointer;
    }

    .department-status:checked {
        background-color: #1976ad;
        border-color: #1976ad;
    }

    .table > :not(caption) > * > * {
        border-bottom-color: #e5e5e5;
    }

    .table tbody tr {
        height: 50px;
    }

    .table tbody td {
        color: #333;
        font-size: 14px;
    }

    .table thead th {
        color: #212529;
        font-size: 14px;
        font-weight: 600;
    }

    .table tbody tr:nth-child(odd) {
        background-color: #fafafa;
    }

    .btn-link:hover {
        text-decoration: none;
    }
</style>

<div class="row mt-4">

    
    <div class="col-md-3">
        <?php echo $__env->make('layouts.sections.settings.adminsettings-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    
    <div class="col-md-9">
        <div class="card ">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-domain fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Department Settings</h5>
                        <small class="text-muted">
                            Manage department and its details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#createDepartmentModal" onclick="resetBankForm()">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Department</span>
                </button>
            </div>
            <div class="card-body p-3">
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search department">
                        </div>
                    </div>
                </div>
                <div class="row g-2">
                    <div class="col-12">
                        <div class="table-responsive rounded border">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                    <tr class="bg-light">
                                        <th>
                                            Department
                                        </th>

                                        <th>
                                            Status
                                        </th>

                                        <th>
                                            Actions
                                        </th>
                                    </tr>
                                </thead>

                                <tbody>

                                    
                                    <tr>
                                        <td class="px-3">
                                            Store & Purchase
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>


                                    
                                    <tr>
                                        <td class="px-3">
                                            Management
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>


                                    
                                    <tr>
                                        <td class="px-3">
                                            Admin & HR
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>


                                    
                                    <tr>
                                        <td class="px-3">
                                            Structure Team
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>


                                    
                                    <tr>
                                        <td class="px-3">
                                            Accounts
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>


                                    
                                    <tr>
                                        <td class="px-3">
                                            Electrical
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="px-3">
                                            Mechanical
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="px-3">
                                            Plant & Machinery
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="px-3">
                                            Planning & Quantity Survey
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="px-3">
                                            Stores & Inventory
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="px-3">
                                            Civil Engineering
                                        </td>

                                        <td class="px-3">
                                            <div class="form-check form-switch mb-0">
                                                <input class="form-check-input"
                                                    type="checkbox"
                                                    id="RemunerationStatus1"
                                                    checked>
                                            </div>
                                        </td>

                                        <td class="px-3">
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#departmentModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDepartmentModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Create Department Modal -->
<div class="modal fade" id="createDepartmentModal" tabindex="-1" aria-labelledby="createDepartmentModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">

          <!-- Modal Header -->
          <div class="modal-header border-bottom">
              <h5 class="modal-title" id="createDepartmentModalLabel">
                  Create Department
              </h5>

              <button type="button"
                      class="btn-close"
                      data-bs-dismiss="modal"
                      aria-label="Close">
              </button>
          </div>

          <!-- Modal Body -->
          <div class="modal-body">
              <div class="mb-3">
                  <label for="department" class="form-label">
                      Department <span class="text-danger">*</span>
                  </label>

                  <input type="text"
                        class="form-control"
                        id="department"
                        name="department"
                        placeholder="Enter department name"
                        required>
              </div>

              <div class="mb-3">
                  <label for="description" class="form-label">
                      Description
                  </label>

                  <textarea class="form-control"
                            id="description"
                            name="description"
                            rows="4"
                            placeholder="Enter department description"></textarea>
              </div>
          </div>

          <!-- Modal Footer -->
          <div class="modal-footer">
              <button type="button"
                      class="btn btn-light"
                      data-bs-dismiss="modal">
                  Cancel
              </button>

              <button type="button"
                      class="btn btn-primary"
                      id="saveDepartment">
                  <i class="mdi mdi-content-save-outline me-1"></i>
                  Save Department
              </button>
          </div>

      </div>
  </div>
</div>

<!-- Edit Department Modal -->
<div class="modal fade" id="departmentModal" tabindex="-1"
     aria-labelledby="departmentModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <!-- Header -->
            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="departmentModalLabel">
                    Update Department
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <!-- Body -->
            <div class="modal-body">

                <input type="hidden" id="department_id">

                <div class="mb-3">
                    <label for="department" class="form-label">
                        Department <span class="text-danger">*</span>
                    </label>

                    <input type="text"
                           class="form-control"
                           id="department"
                           name="department"
                           placeholder="Enter department name"
                           required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">
                        Description
                    </label>

                    <textarea class="form-control"
                      id="description"
                      name="description"
                      rows="4"
                      placeholder="Enter department description"></textarea>
                </div>

            </div>

            <!-- Footer -->
            <div class="modal-footer">

                <button type="button"
                        class="btn btn-light"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button"
                        class="btn btn-primary"
                        id="saveDepartment">

                    <i class="mdi mdi-content-save-outline me-1"></i>

                    <span id="saveDepartmentText">
                        Save Department
                    </span>

                </button>

            </div>

        </div>
    </div>
</div>


<div class="modal fade" id="deleteDepartmentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Department
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto">
                    <i class="mdi mdi-domain-remove fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="">
                        this department
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/content/settings/adminhr/department_setting.blade.php ENDPATH**/ ?>