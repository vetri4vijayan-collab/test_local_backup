<?php $__env->startSection('title', 'Designation'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sections.settings.settings-header', [
    'activeTab' => 'admin_hr'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row mt-4">

    
    <div class="col-md-3">

        <?php echo $__env->make('layouts.sections.settings.adminsettings-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    
    <div class="col-md-9">
      <div class="card ">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-badge-account-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Designation Settings</h5>
                        <small class="text-muted">
                            Manage designation and its details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#createDesignationModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Designation</span>
                </button>
            </div>
            <div class="card-body p-3">
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search designation">
                        </div>
                    </div>
                </div>

                <div class="table-responsive rounded border">
                  <table class="table table-hover align-middle mb-0 border">
                      <thead class="table-light">
                          <tr class="bg-light">
                              <th>
                                  Designation
                              </th>

                              <th>
                                  Status
                              </th>

                              <th>
                                  Actions
                              </th>
                          </tr>
                      </thead>

                      <tbody>
                          <tr>
                              <td class="px-3">
                                  Accountant
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#designationModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteDesignationModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  AGM
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Asst. Engineer
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Asst. Manager
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Cook
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Deputy manager
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  DET
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  DGM
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Driver
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Electrician
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Executive
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Foreman
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  General Manager
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>
                          <tr>
                              <td class="px-3">
                                  GET
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Jr. Engineer
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Machanic
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Manager
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Managing Director
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Office Assistant
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Office Boy
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Officer
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Partner
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Plumber
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Project Coordinator
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Senior Site Engineer
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch">
                                      <input
                                          class="form-check-input department-status"
                                          type="checkbox"
                                          checked
                                      >
                                  </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#designationModal"
                                                    title="Edit">
                                                <i class="mdi mdi-pencil fs-5"></i>
                                            </button>
                                            <button type="button"
                                                    class="btn btn-sm btn-icon btn-outline-danger border-0"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteDesignationModal">
                                                <i class="mdi mdi-trash-can-outline fs-5"></i>
                                            </button>
                              </td>
                          </tr>
                      </tbody>
                  </table>
              </div>
            </div>
        </div>
    </div>

</div>





<div
    class="modal fade"
    id="createDesignationModal"
    tabindex="-1"
    aria-labelledby="createDesignationModalLabel"
    aria-hidden="true"
>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            
            <div class="modal-header border-bottom">

                <h5
                    class="modal-title"
                    id="createDesignationModalLabel"
                >
                    Create Designation
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>

            </div>

            
            <div class="modal-body">

                <div class="mb-3">

                    <label
                        for="create_designation"
                        class="form-label"
                    >
                        Designation <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="create_designation"
                        name="designation"
                        placeholder="Enter designation"
                        required
                    >

                </div>

                <div class="mb-3">

                    <label
                        for="create_designation_description"
                        class="form-label"
                    >
                        Description
                    </label>

                    <textarea
                        class="form-control"
                        id="create_designation_description"
                        name="description"
                        rows="4"
                        placeholder="Enter designation description"
                    ></textarea>

                </div>

            </div>

            
            <div class="modal-footer">

                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    class="btn btn-primary"
                    id="saveDesignation"
                >
                    <i class="mdi mdi-content-save-outline me-1"></i>
                    Save Designation
                </button>

            </div>

        </div>

    </div>
</div>






<div
    class="modal fade"
    id="designationModal"
    tabindex="-1"
    aria-labelledby="designationModalLabel"
    aria-hidden="true"
>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            
            <div class="modal-header border-bottom">

                <h5
                    class="modal-title"
                    id="designationModalLabel"
                >
                    Update Designation
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>

            </div>

            
            <div class="modal-body">

                <input
                    type="hidden"
                    id="designation_id"
                >

                <div class="mb-3">

                    <label
                        for="edit_designation"
                        class="form-label"
                    >
                        Designation <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="edit_designation"
                        name="designation"
                        placeholder="Enter designation"
                        required
                    >

                </div>

                <div class="mb-3">

                    <label
                        for="edit_designation_description"
                        class="form-label"
                    >
                        Description
                    </label>

                    <textarea
                        class="form-control"
                        id="edit_designation_description"
                        name="description"
                        rows="4"
                        placeholder="Enter designation description"
                    ></textarea>

                </div>

            </div>

            
            <div class="modal-footer">

                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    class="btn btn-primary"
                    id="updateDesignation"
                >
                    <i class="mdi mdi-content-save-outline me-1"></i>

                    <span id="updateDesignationText">
                        Update Designation
                    </span>

                </button>

            </div>

        </div>

    </div>
</div>


<div class="modal fade" id="deleteDesignationModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Designation
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto">
                    <i class="mdi mdi-badge-account-outline fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="">
                        this designation
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/content/settings/adminhr/designation_setting.blade.php ENDPATH**/ ?>