<?php $__env->startSection('title', 'Country Settings - Common Settings'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('layouts.sections.settings.settings-header', ['activeTab' => 'common'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="row g-4">

    
    <?php echo $__env->make('layouts.sections.settings.settings-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Right Area: Main Settings Content & Table -->
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2 text-start">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-earth fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Country Settings</h5>
                        <small class="text-muted">Manage global country configurations, defaults, and regional
                            rules</small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#countrySettingModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Country Setting</span>
                </button>
            </div>

            
            <div class="card-body pt-4">

                
                <div class="row g-3 mb-4 justify-content-between align-items-center">
                    <div class="col-12 col-md-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search country or description..." />
                        </div>
                    </div>
                </div>

                
                <div class="table-responsive text-nowrap rounded border">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr class="bg-light">
                                <th>Country Name</th>
                                <th >Description</th>
                                <th >Status</th>
                                <th class="text-end">
                                    Actions</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">United States</span>
                                </td>
                                <td><span class="text-truncate d-inline-block" style="max-width: 350px;">Primary North
                                        American operations hub with standard SLA defaults.</span></td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#countrySettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCountryModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">India</span>
                                </td>
                                <td><span class="text-truncate d-inline-block" style="max-width: 350px;">APAC regional
                                        office setting with IST time-zone rule mappings.</span></td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#countrySettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCountryModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            
                            <tr>
                                <td>
                                    <span class="fw-bold text-heading">United Kingdom</span>
                                </td>
                                <td><span class="text-truncate d-inline-block" style="max-width: 350px;">European
                                        headquarters covering GMT and BST operational policies.</span></td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#countrySettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCountryModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="countrySettingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="countryModalTitle">Country Setting</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="countrySettingForm" action="#" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="country_id" name="country_id" value="">

                <div class="modal-body text-start">
                    
                    <div class="mb-3">
                        <label for="country_code" class="form-label fw-semibold">Country Name <span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Country Name"/>
                    </div>

                    
                    <div class="mb-3">
                        <label for="description" class="form-label fw-semibold">Description</label>
                        <textarea id="description" name="description" class="form-control" rows="3"
                            placeholder="Enter details, regional notes, or configuration rules..."></textarea>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary">Cancel</button>
                    <button type="" class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>Save Setting</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>


<div class="modal fade" id="deleteCountryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">
            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                    style="width: 56px; height: 56px;">
                    <i class="mdi mdi-alert-outline fs-2 text-danger"></i>
                </div>
                <h6 class="fw-bold mb-1">Delete Country Setting?</h6>
                <p class="text-muted text-xs mb-0">This action cannot be undone.</p>
            </div>
            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button" class="btn btn-sm btn-outline-secondary px-3"
                    data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-sm btn-danger px-3">Delete</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* =========================================================
   Country Settings - Alignment Only
   Existing HTML/content remains unchanged
   ========================================================= */


/* Main settings row alignment */
.row {
    align-items: stretch;
}


/* =========================================================
   Settings Sidebar
   ========================================================= */

.settings-sidebar,
.settings-sidebar-wrapper {
    min-width: 0 !important;
    max-width: 100% !important;
}


/* =========================================================
   Main Content Alignment
   ========================================================= */

.col-12.col-md-4.col-lg-9 {
    min-width: 0 !important;
    display: flex;
    flex-direction: column;
}

.col-12.col-md-4.col-lg-9>.card {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
}


/* =========================================================
   Card Header
   Same alignment style as reference header
   ========================================================= */

.col-12.col-md-4.col-lg-9 .card-header {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    flex-wrap: wrap;
    gap: 1rem;
}


/* Left side: Icon + Title + Description */
.col-12.col-md-4.col-lg-9 .card-header>div:first-child {
    display: flex !important;
    align-items: center !important;
    gap: 1rem !important;
    min-width: 0;
    flex: 1 1 auto;
}


/* Icon should never shrink */
.col-12.col-md-4.col-lg-9 .card-header .avatar {
    flex-shrink: 0 !important;
}


/* Title / description container */
.col-12.col-md-4.col-lg-9 .card-header>div:first-child>div:last-child {
    min-width: 0;
}


/* Title */
.col-12.col-md-4.col-lg-9 .card-header h5 {
    margin-bottom: 0 !important;
    white-space: normal;
    overflow-wrap: anywhere;
}


/* Description */
.col-12.col-md-4.col-lg-9 .card-header small {
    display: block;
    white-space: normal;
    overflow-wrap: anywhere;
}


/* Right side: Add button */
.col-12.col-md-4.col-lg-9 .card-header>button {
    flex: 0 0 auto;
    white-space: nowrap;
}


/* =========================================================
   Card Body
   ========================================================= */

.col-12.col-md-4.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}


/* =========================================================
   Search Alignment
   ========================================================= */

.col-12.col-md-4.col-lg-9 .card-body>.row {
    width: 100%;
    align-items: center;
}


/* Search field */
.col-12.col-md-4.col-lg-9 #tableSearch {
    width: 100%;
}


/* =========================================================
   Table Alignment
   ========================================================= */

.col-12.col-md-4.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
}

.col-12.col-md-4.col-lg-9 table {
    width: 100%;
}


/* =========================================================
   Tablet
   ========================================================= */

@media (max-width: 991.98px) {

    .col-12.col-md-4.col-lg-9 .card-header {
        align-items: flex-start !important;
    }

}


/* =========================================================
   Mobile
   ========================================================= */

@media (max-width: 767.98px) {

    /* Main content */
    .col-12.col-md-4.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
    }


    /* Header becomes stacked */
    .col-12.col-md-4.col-lg-9 .card-header {
        display: flex !important;
        flex-direction: column !important;
        align-items: stretch !important;
        justify-content: flex-start !important;
    }


    /* Header left content */
    .col-12.col-md-4.col-lg-9 .card-header>div:first-child {
        width: 100%;
        flex: 1 1 100%;
    }


    /* Add button */
    .col-12.col-md-4.col-lg-9 .card-header>button {
        width: 100%;
        flex: 1 1 100%;
        justify-content: center;
    }


    /* Search */
    .col-12.col-md-4.col-lg-9 .card-body .row>div {
        width: 100%;
        max-width: 100%;
    }


    /* Table */
    .col-12.col-md-4.col-lg-9 .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

    .col-12.col-md-4.col-lg-9 table {
        min-width: 650px;
    }

}


/* =========================================================
   Very Small Screens
   ========================================================= */

@media (max-width: 320px) {

    .col-12.col-md-4.col-lg-9 .card-header {
        padding: .75rem !important;
    }


    .col-12.col-md-4.col-lg-9 .card-header>div:first-child {
        gap: .5rem !important;
        align-items: flex-start !important;
    }


    .col-12.col-md-4.col-lg-9 .card-header h5 {
        font-size: .9rem;
    }


    .col-12.col-md-4.col-lg-9 .card-header small {
        font-size: .7rem;
        line-height: 1.3;
    }


    .col-12.col-md-4.col-lg-9 .card-header>button {
        font-size: .75rem;
        padding: .5rem;
    }

}


/* =========================================================
   Large Screens / Zoom Out
   ========================================================= */

@media (min-width: 992px) {

    .col-12.col-md-4.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
    }

}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/content/settings/common/country_setting.blade.php ENDPATH**/ ?>