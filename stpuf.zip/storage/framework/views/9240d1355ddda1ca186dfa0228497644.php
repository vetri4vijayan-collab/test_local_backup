<?php
$configData = Helper::appClasses();
?>


<?php $__env->startSection('title', 'Under Development'); ?>

<?php $__env->startSection('page-style'); ?>
<style>
  :root {
    /* Ryan Infra palette: deep navy sidebar + blue accent, copper only as a logo highlight */
    --ryn-navy: #0B1B33;
    --ryn-navy-soft: #16294A;
    --ryn-navy-deep: #071224;
    --ryn-blue: #2F5FA8;
    --ryn-blue-light: #6E9BD6;
    --ryn-copper: #C1793F;
    --ryn-mist: #A9B8CC;
    --ryn-cream: #F4F6F9;
  }

  .ryn-ud-wrap {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: calc(100vh - 220px);
    padding: 2rem 1rem;
  }

  .ryn-ud-card {
    position: relative;
    width: 100%;
    max-width: 620px;
    text-align: center;
    background: linear-gradient(180deg, #ffffff 0%, var(--ryn-cream) 100%);
    border: 1px solid rgba(47, 95, 168, 0.14);
    border-radius: 24px;
    padding: 3.5rem 2.5rem 3rem;
    overflow: hidden;
    box-shadow: 0 24px 60px -24px rgba(11, 27, 51, 0.2);
  }

  .ryn-ud-arc {
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
  }
  .ryn-ud-arc--1 {
    width: 420px; height: 420px; right: -160px; top: -180px;
    border: 1px solid rgba(47, 95, 168, 0.14);
  }
  .ryn-ud-arc--2 {
    width: 300px; height: 300px; left: -140px; bottom: -160px;
    border: 1px solid rgba(11, 27, 51, 0.08);
  }
  .ryn-ud-glow {
    position: absolute;
    width: 300px; height: 300px;
    right: -80px; top: -120px;
    background: radial-gradient(circle, rgba(47,95,168,0.22) 0%, rgba(47,95,168,0) 70%);
    filter: blur(20px);
    border-radius: 50%;
  }

  .ryn-ud-ring {
    position: relative;
    z-index: 1;
    width: 92px; height: 92px;
    margin: 0 auto 1.75rem;
    border-radius: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, var(--ryn-copper) 0%, var(--ryn-blue) 55%, var(--ryn-navy) 130%);
    box-shadow: 0 16px 34px -12px rgba(47, 95, 168, 0.5);
  }
  .ryn-ud-ring i {
    font-size: 2.4rem;
    color: #fff;
    animation: ryn-spin 3.5s linear infinite;
    transform-origin: center;
  }
  @keyframes ryn-spin {
    0%   { transform: rotate(0deg); }
    45%  { transform: rotate(35deg); }
    55%  { transform: rotate(-15deg); }
    100% { transform: rotate(0deg); }
  }

  .ryn-ud-eyebrow {
    position: relative; z-index: 1;
    display: inline-flex; align-items: center; gap: .5rem;
    font-size: .68rem; letter-spacing: .16em; text-transform: uppercase;
    color: var(--ryn-blue);
    border: 1px solid rgba(47,95,168,0.35);
    background: rgba(47,95,168,0.08);
    padding: .4rem .9rem; border-radius: 999px; margin-bottom: 1.25rem;
  }
  .ryn-ud-eyebrow::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: var(--ryn-blue); }

  .ryn-ud-card h2 {
    position: relative; z-index: 1;
    font-size: 1.65rem; font-weight: 800; color: var(--ryn-navy);
    margin-bottom: .6rem;
  }
  .ryn-ud-card h2 span {
    background: linear-gradient(90deg, var(--ryn-blue), var(--ryn-copper));
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  .ryn-ud-card p.ryn-ud-lede {
    position: relative; z-index: 1;
    color: #64748B; font-size: .95rem; line-height: 1.65;
    max-width: 440px; margin: 0 auto 2rem;
  }

  .ryn-ud-progress {
    position: relative; z-index: 1;
    width: 100%; max-width: 320px; margin: 0 auto 2.25rem;
    height: 8px; border-radius: 999px;
    background: rgba(11, 27, 51, 0.08);
    overflow: hidden;
  }
  .ryn-ud-progress-bar {
    height: 100%; width: 62%; border-radius: 999px;
    background: linear-gradient(90deg, var(--ryn-blue), var(--ryn-blue-light));
    animation: ryn-progress-pulse 2.4s ease-in-out infinite;
  }
  @keyframes ryn-progress-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: .65; }
  }

  .ryn-ud-actions {
    position: relative; z-index: 1;
    display: flex; flex-wrap: wrap; gap: .75rem;
    align-items: center; justify-content: center;
  }
  .ryn-ud-btn-primary {
    display: inline-flex; align-items: center; gap: .5rem;
    padding: .7rem 1.5rem; border-radius: 10px;
    background: linear-gradient(135deg, var(--ryn-blue) 0%, var(--ryn-navy) 130%);
    color: #fff; font-weight: 700; font-size: .9rem;
    text-decoration: none;
    box-shadow: 0 12px 24px -10px rgba(47,95,168,0.5);
    transition: transform .15s ease, filter .15s ease;
  }
  .ryn-ud-btn-primary:hover { transform: translateY(-1px); filter: brightness(1.06); color: #fff; }

  .ryn-ud-btn-ghost {
    display: inline-flex; align-items: center; gap: .5rem;
    padding: .7rem 1.5rem; border-radius: 10px;
    background: transparent;
    border: 1.5px solid rgba(11,27,51,0.15);
    color: var(--ryn-navy); font-weight: 700; font-size: .9rem;
    text-decoration: none;
    transition: border-color .15s ease, color .15s ease;
  }
  .ryn-ud-btn-ghost:hover { border-color: var(--ryn-blue); color: var(--ryn-blue); }

  .ryn-ud-footnote {
    position: relative; z-index: 1;
    margin-top: 1.75rem;
    font-size: .78rem;
    color: #9AA6B2;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row gy-4">
  <div class="col-12">
    <div class="ryn-ud-wrap">
      <div class="ryn-ud-card">
        <div class="ryn-ud-arc ryn-ud-arc--1"></div>
        <div class="ryn-ud-arc ryn-ud-arc--2"></div>
        <div class="ryn-ud-glow"></div>

        <span class="ryn-ud-eyebrow">Coming Soon</span>

        <div class="ryn-ud-ring">
          <i class="mdi mdi-hammer-wrench"></i>
        </div>

        <h2>This page is <span>under development</span></h2>
        <p class="ryn-ud-lede">
          Our team at Ryan Infra is actively building this module. Check back soon —
          in the meantime you can head back to your dashboard or reach out to support.
        </p>

        <div class="ryn-ud-progress">
          <div class="ryn-ud-progress-bar"></div>
        </div>

        <div class="ryn-ud-actions">
          <a href="<?php echo e(url('/dashboards')); ?>" class="ryn-ud-btn-primary">
            <i class="mdi mdi-view-dashboard-outline"></i> Back to Dashboard
          </a>
          <a href="javascript:history.back()" class="ryn-ud-btn-ghost">
            <i class="mdi mdi-arrow-left"></i> Go Back
          </a>
        </div>

        <p class="ryn-ud-footnote">Ryan Infra ERP &copy; <?php echo e(date('Y')); ?></p>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/content/under-development.blade.php ENDPATH**/ ?>