<?php $__env->startSection('title', 'Contractor - Site Settings'); ?>

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('layouts.sections.settings.settings-header', ['activeTab' => 'site_log'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<div class="row g-4">

    
    
    

    <?php echo $__env->make('layouts.sections.settings.settings-site_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
    

    <div class="col-12 col-md-8 col-lg-9">

        <div class="card">

            
            
            

            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2 text-start">

                <div class="d-flex align-items-center gap-3">

                    
                    <div
                        class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center flex-shrink-0">

                        <i class="mdi mdi-account-hard-hat fs-4 text-primary"></i>

                    </div>

                    
                    <div>

                        <h5 class="mb-0 fw-bold">
                            Contractor Type
                        </h5>

                        <small class="text-muted">
                            Manage contractors and their operating status
                        </small>

                    </div>

                </div>

                
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#contractorModal">

                    <i class="mdi mdi-plus fs-5"></i>

                    <span>
                        Create Contractor
                    </span>

                </button>

            </div>

            
            
            

            <div class="card-body pt-4">

                
                <div class="row g-3 mb-4 justify-content-between align-items-center">

                    <div class="col-12 col-md-4">

                        <div class="input-group input-group-merge">

                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>

                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search contractor..." />

                        </div>

                    </div>

                </div>

                
                
                

                <div class="table-responsive text-nowrap rounded border">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr class="bg-light">
                                <th>
                                    Contractor Type
                                </th>

                                <th>
                                    Status
                                </th>

                                <th class="text-end">
                                    Actions
                                </th>

                            </tr>

                        </thead>

                        <tbody class="table-border-bottom-0">

                            
                            
                            

                            <tr>

                                <td>
                                    <span class="fw-semibold">
                                        Plumbing Contractor
                                    </span>
                                </td>

                                <td>

                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>

                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#contractorModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteContractorModal"
                                            title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                            
                            
                            

                            <tr>

                                <td>
                                    <span class="fw-semibold">
                                        Electrical Contractor
                                    </span>
                                </td>

                                <td>

                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>

                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#contractorModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteContractorModal"
                                            title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                            
                            
                            

                            <tr>
                                <td>
                                    <span class="fw-semibold">
                                        Civil Contractor
                                    </span>
                                </td>

                                <td>

                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>

                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#contractorModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteContractorModal"
                                            title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                            
                            
                            

                            <tr>
                                <td>
                                    <span class="fw-semibold">
                                        Mechanical Contractor
                                    </span>
                                </td>

                                <td>

                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>

                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#contractorModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteContractorModal"
                                            title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                            
                            
                            

                            <tr>
                                <td>
                                    <span class="fw-semibold">
                                        Hire Machinery
                                    </span>
                                </td>

                                <td>

                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            checked>
                                    </div>

                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#contractorModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteContractorModal"
                                            title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>




<div class="modal fade" id="contractorModal" tabindex="-1" aria-labelledby="contractorModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-md modal-dialog-centered">

        <div class="modal-content">

            
            <div class="modal-header border-bottom">

                <h5 class="modal-title fw-bold" id="contractorModalLabel">

                    Contractor

                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>

            
            <form action="#">

                <?php echo csrf_field(); ?>

                
                <div class="modal-body">

                    <div class="row g-4">

                        
                        <div class="col-12">

                            <label for="contractor" class="form-label fw-semibold">

                                Contractor

                                <span class="text-danger">*</span>

                            </label>

                            <input type="text" id="contractor" name="contractor" class="form-control"
                                placeholder="Enter contractor" required>

                        </div>

                    </div>

                </div>

                
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        Save Contractor

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>




<div class="modal fade" id="deleteContractorModal" tabindex="-1" aria-labelledby="deleteContractorModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-sm modal-dialog-centered">

        <div class="modal-content">

            
            <div class="modal-body text-center py-4">

                <div
                    class="avatar bg-label-danger rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center">

                    <i class="mdi mdi-account-hard-hat fs-3 text-danger"></i>

                </div>

                <h5 class="mb-2">
                    Are you sure?
                </h5>

                <p class="text-muted mb-0">

                    You are about to delete
                    <strong>this contractor</strong>.
                    This action cannot be undone.

                </p>

            </div>

            
            <div class="modal-footer justify-content-center border-top">

                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">

                    <i class="mdi mdi-delete-outline me-1"></i>

                    Delete

                </button>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>

<style>
/* =========================================================
   Contractor Settings - Alignment
   ========================================================= */

.row {
    align-items: stretch;
}


/* =========================================================
   Settings Sidebar
   ========================================================= */

.settings-sidebar,
.settings-sidebar-wrapper {
    min-width: 0 !important;
    max-width: 100% !important;
}


/* =========================================================
   Main Content
   ========================================================= */

.col-12.col-md-8.col-lg-9 {
    min-width: 0 !important;
    display: flex;
    flex-direction: column;
}


.col-12.col-md-8.col-lg-9>.card {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
}


/* =========================================================
   Card Header
   ========================================================= */

.col-12.col-md-8.col-lg-9 .card-header {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    flex-wrap: wrap;
    gap: 1rem;
}


.col-12.col-md-8.col-lg-9 .card-header>div:first-child {
    display: flex !important;
    align-items: center !important;
    gap: 1rem !important;
    min-width: 0;
    flex: 1 1 auto;
}


.col-12.col-md-8.col-lg-9 .card-header .avatar {
    flex-shrink: 0 !important;
}


.col-12.col-md-8.col-lg-9 .card-header>div:first-child>div:last-child {
    min-width: 0;
}


.col-12.col-md-8.col-lg-9 .card-header h5 {
    margin-bottom: 0 !important;
    white-space: normal;
    overflow-wrap: anywhere;
}


.col-12.col-md-8.col-lg-9 .card-header small {
    display: block;
    white-space: normal;
    overflow-wrap: anywhere;
}


/* =========================================================
   Create Button
   ========================================================= */

.col-12.col-md-8.col-lg-9 .card-header>button {
    flex: 0 0 auto;
    white-space: nowrap;
}


/* =========================================================
   Card Body
   ========================================================= */

.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}


/* =========================================================
   Search
   ========================================================= */

.col-12.col-md-8.col-lg-9 .card-body>.row {
    width: 100%;
    align-items: center;
}


.col-12.col-md-8.col-lg-9 #tableSearch {
    width: 100%;
}


/* =========================================================
   Table
   ========================================================= */

.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
}


.col-12.col-md-8.col-lg-9 table {
    width: 100%;
}


.col-12.col-md-8.col-lg-9 table td:nth-child(2) {
    min-width: 0;
}


.col-12.col-md-8.col-lg-9 table td:nth-child(2) .fw-semibold {
    overflow-wrap: anywhere;
}


/* =========================================================
   Action Buttons
   ========================================================= */

.col-12.col-md-8.col-lg-9 table td:last-child {
    white-space: nowrap;
}


/* =========================================================
   Tablet
   ========================================================= */

@media (max-width: 991.98px) {

    .col-12.col-md-8.col-lg-9 .card-header {
        align-items: flex-start !important;
    }

}


/* =========================================================
   Mobile
   ========================================================= */

@media (max-width: 767.98px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
    }


    .col-12.col-md-8.col-lg-9 .card-header {
        display: flex !important;
        flex-direction: column !important;
        align-items: stretch !important;
        justify-content: flex-start !important;
    }


    .col-12.col-md-8.col-lg-9 .card-header>div:first-child {
        width: 100%;
        flex: 1 1 100%;
    }


    .col-12.col-md-8.col-lg-9 .card-header>button {
        width: 100%;
        flex: 1 1 100%;
        justify-content: center;
    }


    .col-12.col-md-8.col-lg-9 .card-body .row>div {
        width: 100%;
        max-width: 100%;
    }


    .col-12.col-md-8.col-lg-9 .table-responsive {
        width: 100%;
        overflow-x: auto;
    }


    .col-12.col-md-8.col-lg-9 table {
        min-width: 650px;
    }

}


/* =========================================================
   Very Small Screens
   ========================================================= */

@media (max-width: 320px) {

    .col-12.col-md-8.col-lg-9 .card-header {
        padding: .75rem !important;
    }


    .col-12.col-md-8.col-lg-9 .card-header>div:first-child {
        gap: .5rem !important;
        align-items: flex-start !important;
    }


    .col-12.col-md-8.col-lg-9 .card-header h5 {
        font-size: .9rem;
    }


    .col-12.col-md-8.col-lg-9 .card-header small {
        font-size: .7rem;
        line-height: 1.3;
    }


    .col-12.col-md-8.col-lg-9 .card-header>button {
        font-size: .75rem;
        padding: .5rem;
    }

}


/* =========================================================
   Large Screens
   ========================================================= */

@media (min-width: 992px) {

    .col-12.col-md-8.col-lg-9 {
        min-width: 0 !important;
    }


    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
    }

}
</style>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/content/settings/site_log/contractor_setting.blade.php ENDPATH**/ ?>