<style>
  .menu-sub.menu-sub-line {
    position: relative;
    margin-left: 1.25rem;   // ml-5
    padding-left: 1rem;     // pl-4
    margin-top: 0.25rem;
    border-left: 1px solid rgba(94, 97, 104, 0.4);

    // Kill the theme's default ::before dot/pill on submenu links
    > .menu-item > .menu-link::before {
      display: none !important;
      content: none !important;
    }

    // Reset any left padding the theme adds to make room for the dot,
    // since the line now sits outside the <ul> instead of per-item.
    > .menu-item > .menu-link {
      padding-left: 0.5rem;
    }

    // Nested submenus (e.g. a 3rd level) get their own line, indented further
    .menu-sub.menu-sub-line {
      margin-left: 0.75rem;
    }
  }
</style>

<?php
  use Illuminate\Support\Str;

  $currentRouteName = Route::currentRouteName();
  $configData = Helper::appClasses();
  $isVertical = ($configData['layout'] ?? 'vertical') === 'vertical';
?>

<ul class="menu-sub menu-sub-line">
  <?php if(isset($menu)): ?>
    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $slugs = is_array($submenu->slug ?? null) ? $submenu->slug : [$submenu->slug ?? null];
        $hasSubmenu = isset($submenu->submenu);

        $isExactMatch = in_array($currentRouteName, $slugs, true);

        // Prefix match only against a real dotted boundary, so a slug
        // never falsely matches an unrelated sibling with a shared prefix.
        $isDescendantMatch = false;
        foreach ($slugs as $slug) {
          if ($slug && Str::startsWith($currentRouteName, $slug . '.')) {
            $isDescendantMatch = true;
            break;
          }
        }

        $activeClass = null;
        if ($isExactMatch) {
          $activeClass = 'active';
        } elseif ($hasSubmenu && $isDescendantMatch) {
          $activeClass = $isVertical ? 'active open' : 'active';
        }
      ?>

      <li class="menu-item <?php echo e($activeClass); ?>">
        <a href="<?php echo e(isset($submenu->url) ? url($submenu->url) : 'javascript:void(0)'); ?>"
           class="<?php echo e($hasSubmenu ? 'menu-link menu-toggle' : 'menu-link'); ?>"
           <?php if(!empty($submenu->target)): ?> target="_blank" <?php endif; ?>>
          <?php if(isset($submenu->icon)): ?>
            <i class="<?php echo e($submenu->icon); ?> me-1"></i>
          <?php endif; ?>
          <div class="fs-7 fw-medium"><?php echo e(isset($submenu->name) ? __($submenu->name) : ''); ?></div>
          <?php if(isset($submenu->badge)): ?>
            <div class="badge bg-<?php echo e($submenu->badge[0]); ?> rounded-pill ms-auto"><?php echo e($submenu->badge[1]); ?></div>
          <?php endif; ?>
        </a>

        <?php if($hasSubmenu): ?>
          <?php echo $__env->make('layouts.sections.menu.submenu', ['menu' => $submenu->submenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/layouts/sections/menu/submenu.blade.php ENDPATH**/ ?>