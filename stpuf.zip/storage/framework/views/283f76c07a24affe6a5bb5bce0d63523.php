<?php

    $containerNav = $containerNav ?? 'container-fluid';
    $navbarDetached = ($navbarDetached ?? '');

    // ---------------------------------------------------------------
    // Current route
    // ---------------------------------------------------------------
    $currentRouteName = Route::currentRouteName();

    // ---------------------------------------------------------------
    // Load menu
    // ---------------------------------------------------------------
    $menuItems = json_decode(
        file_get_contents(resource_path('menu/verticalMenu.json'))
    )->menu;


    $findActivePath = function ($items, $path = []) use (
        &$findActivePath,
        $currentRouteName
    ) {

        foreach ($items as $item) {

            $slugs = is_array($item->slug ?? null)
                ? $item->slug
                : [$item->slug ?? null];


            // Current item matches
            if (in_array($currentRouteName, $slugs, true)) {

                return array_merge($path, [$item]);
            }


            // Search children
            if (isset($item->submenu)) {

                $result = $findActivePath(
                    $item->submenu,
                    array_merge($path, [$item])
                );

                if ($result) {
                    return $result;
                }
            }
        }

        return null;
    };


    // Find complete active path
    $activePath = $findActivePath($menuItems) ?? [];


    // First level
    $activeParent = $activePath[0] ?? null;


    // Last matching item
    $activeChild = count($activePath) > 1
        ? end($activePath)
        : null;


    // Page title
    $pageTitle = $pageTitle
        ?? ($activeChild->name
        ?? ($activeParent->name
        ?? 'Dashboard'));


    // Breadcrumb
    $breadcrumbTrail = collect([
        config('variables.templateName', 'Ryan Infra ERP')
    ]);


?>


<?php if(isset($navbarDetached) && $navbarDetached == 'navbar-detached'): ?>
<nav class="layout-navbar <?php echo e($containerNav); ?> navbar navbar-expand-xl <?php echo e($navbarDetached); ?> align-items-center bg-navbar-theme" id="layout-navbar">
  <?php endif; ?>
  <?php if(isset($navbarDetached) && $navbarDetached == ''): ?>
  <nav class="layout-navbar navbar navbar-expand-xl align-items-center bg-navbar-theme" id="layout-navbar">
    <div class="<?php echo e($containerNav); ?>">
      <?php endif; ?>

      <!--  Brand demo (display only for navbar-full and hide on below xl) -->
      <?php if(isset($navbarFull)): ?>
      <div class="navbar-brand app-brand demo d-none d-xl-flex py-0 me-4">
        <a href="<?php echo e(url('/')); ?>" class="app-brand-link gap-2">
          <span class="app-brand-logo demo"><?php echo $__env->make('_partials.macros',["width"=>25,"withbg"=>'var(--bs-primary)'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
          <span class="app-brand-text demo menu-text fw-bold"><?php echo e(config('variables.templateName')); ?></span>
        </a>
        <?php if(isset($menuHorizontal)): ?>
        <a href="javascript:;" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
          <i class="mdi mdi-close align-middle"></i>
        </a>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <!-- ! Not required for layout-without-menu -->
      <?php if(!isset($navbarHideToggle)): ?>
      <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0<?php echo e(isset($menuHorizontal) ? ' d-xl-none ' : ''); ?> <?php echo e(isset($contentNavbar) ?' d-xl-none ' : ''); ?>">
        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
          <i class="mdi mdi-menu mdi-24px"></i>
        </a>
      </div>
      <?php endif; ?>

      

      <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
<!-- Active-menu breadcrumb + page title -->
      <div class="navbar-page-heading d-none d-md-flex flex-column me-auto" style="line-height:1.5;">

        <small class="text-muted" style="font-size:.72rem;">
            <?php echo e($breadcrumbTrail->implode(' / ')); ?>


            <?php if($activeParent): ?>
                / <?php echo e($activeParent->name); ?>

            <?php endif; ?>

            <!-- <?php if($activeChild && $activeChild !== $activeParent): ?>
                / <?php echo e($activeChild->name); ?>

            <?php endif; ?> -->
        </small>

        <span class="fw-bold" style="font-size:1.05rem;">
            <?php echo e($pageTitle); ?>

        </span>

    </div>
        <?php if(!isset($menuHorizontal)): ?>
        <!-- Search -->
        <!-- <div class="navbar-nav align-items-center">
          <div class="nav-item navbar-search-wrapper mb-0">
            <a class="nav-item nav-link search-toggler fw-normal px-0" href="javascript:;">
              <i class="mdi mdi-magnify mdi-24px scaleX-n1-rtl"></i>
              <span class="d-none d-md-inline-block text-muted">Search (Ctrl+/)</span>
            </a>
          </div>
        </div> -->
        <!-- /Search -->
        <?php endif; ?>

        <ul class="navbar-nav flex-row align-items-center ms-auto">

          <!-- Notification -->
          <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-1 me-xl-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Notification">
            <a class="nav-link btn btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow" href="javascript:;" data-bs-toggle="offcanvas" data-bs-target="#notification_tab">
              <i class="mdi mdi-bell-outline mdi-24px"></i>
              <span class="position-absolute top-0 start-50 translate-middle-y badge badge-dot bg-danger mt-2 border"></span>
            </a>
          </li>
          <!--/ Notification -->

          <!-- User -->
          <li class="nav-item navbar-dropdown dropdown-user dropdown">
            <a class="nav-link dropdown-toggle hide-arrow d-flex align-items-center gap-2" href="javascript:;" data-bs-toggle="dropdown">
              <div class="avatar avatar-online">
                <img src="<?php echo e(Auth::user() ? Auth::user()->profile_photo_url : asset('assets/img/avatar/admin.png')); ?>" alt class="w-px-40 h-px-40 rounded-circle border border-gray-400">
              </div>
              <div class="d-none d-md-flex flex-column" style="line-height:1.1;">
                <span class="fw-semibold small"><?php echo e(Auth::user()->name ?? 'Senthil Kumaran'); ?></span>
                <label>
                  <span class="badge bg-label-primary" style="font-size:.65rem;"><?php echo e(Auth::user()->role ?? 'Admin'); ?></span>
                </label>
              </div>
              <i class="mdi mdi-chevron-down"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end p-0" style="min-width:280px;">
              <li class="p-3 border-bottom">
                <div class="d-flex align-items-center">
                  <div class="flex-shrink-0 me-2">
                    <div class="avatar avatar-online">
                      <img src="<?php echo e(Auth::user() ? Auth::user()->profile_photo_url : asset('assets/img/avatar/admin.png')); ?>" alt class="w-px-40 h-px-40 rounded-circle">
                    </div>
                  </div>
                  <div class="flex-grow-1">
                    <span class="fw-bold d-block"><?php echo e(Auth::user()->name ?? 'Senthil Kumaran'); ?></span>
                    <small class="text-muted d-block"><?php echo e(Auth::user()->email ?? 'admin@srkinfra.com'); ?></small>
                    <span class="badge bg-label-primary mt-1">Role: <?php echo e(Auth::user()->role ?? 'Admin'); ?></span>
                  </div>
                </div>
              </li>
              <li class="px-3 py-2 border-bottom">
                <div class="d-flex justify-content-between py-1">
                  <small class="text-muted">Department:</small>
                  <small class="fw-medium"><?php echo e(Auth::user()->department ?? 'Management'); ?></small>
                </div>
                <div class="d-flex justify-content-between py-1">
                  <small class="text-muted">Designation:</small>
                  <small class="fw-medium"><?php echo e(Auth::user()->designation ?? 'Executive Director & IT Admin'); ?></small>
                </div>
                <div class="d-flex justify-content-between py-1">
                  <small class="text-muted">Username:</small>
                  <small class="fw-medium text-primary"><?php echo e(Auth::user()->username ?? 'admin'); ?></small>
                </div>
              </li>
              <li class="p-2">
                <a class="dropdown-item text-danger bg-label-danger rounded d-flex align-items-center justify-content-center py-2" href="<?php echo e(url('/')); ?>">
                  <i class="mdi mdi-logout me-2"></i>
                  <span class="align-middle fw-medium">Sign Out</span>
                </a>
              </li>
            </ul>
          </li>
          <!--/ User -->
        </ul>
      </div>

      <!-- Search Small Screens -->
      <div class="navbar-search-wrapper search-input-wrapper <?php echo e(isset($menuHorizontal) ? $containerNav : ''); ?> d-none">
        <input type="text" class="form-control search-input <?php echo e(isset($menuHorizontal) ? '' : $containerNav); ?> border-0" placeholder="Search..." aria-label="Search...">
        <i class="mdi mdi-close search-toggler cursor-pointer"></i>
      </div>
      <?php if(!isset($navbarDetached)): ?>
    </div>
    <?php endif; ?>
  </nav>
  <!-- / Navbar -->

  <!--begin:: Notification Offcanvan-->
  <div class="offcanvas offcanvas-end" id="notification_tab" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="offcanvas-header border-bottom d-block bg-label-secondary">
      <div class="d-flex align-items-center justify-content-between mb-3">
        <div class="d-flex align-items-center gap-1">
          <h5 class="offcanvas-title text-dark fw-bold">Notifications</h5>
          <span class="badge rounded-pill bg-dark text-white">3 New</span>
        </div>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="d-flex align-items-center justify-content-between">
        <label>
          <span class="fs-6 fw-semibold text-black">Clear All</span>
        </label>
        <label>
          <span class="fs-6 fw-semibold text-black">Mark all as read</span>
        </label>
      </div>
    </div>
    <div class="offcanvas-body flex-grow-1">
      <ul class="list-group list-group-flush list-unstyled scrollable-container">
        <li class="list-group-item list-group-item-action bg-label-success rounded mb-2">
          <div class="d-flex align-items-center justify-content-between gap-2 bg-opacity-75 rounded">
            <!--begin::Section-->
            <div class="d-flex align-items-center">
              <!--begin::Symbol-->
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-multiple-outline fs-3 text-black"></i></span>
              </div>
              <!--end::Symbol-->
              <!--begin::Title-->
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
                <div class="text-secondary fs-8 fw-semibold">New Lead Created</div>
              </div>
              <!--end::Title-->
            </div>
            <!--end::Section-->
            <!--begin::Label-->
            <div class="flex-shrink-0">
              <span class="badge bg-label-danger text-danger fw-semibold fs-8">Just Now</span>
            </div>
            <!--end::Label-->
          </div>
        </li>
        <li class="list-group-item list-group-item-action rounded mb-2">
          <div class="d-flex align-items-center justify-content-between gap-2 bg-opacity-75 rounded">
            <!--begin::Section-->
            <div class="d-flex align-items-center">
              <!--begin::Symbol-->
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-cash-outline fs-3 text-black"></i></span>
              </div>
              <!--end::Symbol-->
              <!--begin::Title-->
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Customer</a>
                <div class="text-secondary fw-semibold fs-8">New Payment Made</div>
              </div>
              <!--end::Title-->
            </div>
            <!--end::Section-->
            <!--begin::Label-->
            <div class="flex-shrink-0">
              <span class="badge bg-label-danger text-danger fw-semibold fs-8">5 Mins ago</span>
            </div>
            <!--end::Label-->
          </div>
        </li>
        <li class="list-group-item list-group-item-action rounded mb-2">
          <div class="d-flex align-items-center justify-content-between gap-2 bg-opacity-75 rounded">
            <!--begin::Section-->
            <div class="d-flex align-items-center">
              <!--begin::Symbol-->
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-outline fs-3 text-black"></i></span>
              </div>
              <!--end::Symbol-->
              <!--begin::Title-->
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Customer</a>
                <div class="text-secondary fw-semibold fs-8">Lead Converted to Customer</div>
              </div>
              <!--end::Title-->
            </div>
            <!--end::Section-->
            <!--begin::Label-->
            <div class="flex-shrink-0">
              <span class="badge bg-label-danger text-danger fw-semibold fs-8">10 Mins ago</span>
            </div>
            <!--end::Label-->
          </div>
        </li>
        <li class="list-group-item list-group-item-action rounded mb-2">
          <div class="d-flex align-items-center justify-content-between gap-2 bg-opacity-75 rounded">
            <!--begin::Section-->
            <div class="d-flex align-items-center">
              <!--begin::Symbol-->
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-book fs-3 text-black"></i></span>
              </div>
              <!--end::Symbol-->
              <!--begin::Title-->
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Course</a>
                <div class="text-secondary fw-semibold fs-8">New Course Created</div>
              </div>
              <!--end::Title-->
            </div>
            <!--end::Section-->
            <!--begin::Label-->
            <div class="flex-shrink-0">
              <span class="badge bg-label-danger text-danger fw-semibold fs-8">1 Hr ago</span>
            </div>
            <!--end::Label-->
          </div>
        </li>
      </ul>
    </div>
  </div>
  <!--end:: Notification Offcanvan--><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/layouts/sections/navbar/navbar.blade.php ENDPATH**/ ?>