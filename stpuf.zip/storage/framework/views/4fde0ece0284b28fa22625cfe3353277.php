<?php
    $settingsTabs = [
        [
            'key'   => 'department',
            'label' => 'Department',
            'route' => 'settings-department-setting',
            'icon'  => 'mdi-domain',
        ],
        [
            'key'   => 'jobrole',
            'label' => 'Job Role',
            'route' => 'settings-jobrole-setting',
            'icon'  => 'mdi-account-tie-outline',
        ],
        [
            'key'   => 'designation',
            'label' => 'Designation',
            'route' => 'settings-designation-setting',
            'icon'  => 'mdi-badge-account-outline',
        ],
        [
            'key'   => 'grade',
            'label' => 'Grade',
            'route' => 'settings-gradelist-setting',
            'icon'  => 'mdi-format-list-numbered',
        ],
        [
            'key'   => 'shift',
            'label' => 'Shift',
            'route' => 'settings-shift-setting',
            'icon'  => 'mdi-clock-outline',
        ],
        [
            'key'   => 'remuneration',
            'label' => 'Remuneration Type',
            'route' => 'settings-remuneration-type',
            'icon'  => 'mdi-credit-card-outline',
        ],
    ];
?>


<div class="col-12 col-lg-3 settings-sidebar">
    <div class="card h-100">
        <div class="card-body p-2 p-sm-3">

            <ul class="nav nav-pills flex-column w-100 gap-1 settings-nav">

                <?php $__currentLoopData = $settingsTabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li class="nav-item w-100">

                        <a href="<?php echo e(Route::has($tab['route']) 
                            ? route($tab['route']) 
                            : 'javascript:void(0);'); ?>"
                           class="nav-link 
                           <?php echo e(request()->routeIs($tab['route']) ? 'active' : 'text-muted'); ?>

                           d-flex align-items-center gap-2 px-3 py-2">

                            <i class="mdi <?php echo e($tab['icon']); ?> fs-5"></i>

                            <span class="fw-semibold">
                                <?php echo e($tab['label']); ?>

                            </span>

                        </a>

                    </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>
    </div>
</div>


<style>
/* ======= SETTINGS SIDEBAR - LIST FORMAT ====== */

.settings-sidebar {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    box-sizing: border-box;
}

/* UL */
.settings-sidebar ul {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    margin: 0;
    padding: 0;

    list-style: none;
    box-sizing: border-box;
}

/* LI */
.settings-sidebar ul li {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    margin: 0;
    padding: 0;

    list-style: none;
    box-sizing: border-box;
}

/* LINK */
.settings-sidebar ul li a {
    display: flex;
    align-items: center;

    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;

    padding: 8px 10px;
    gap: 8px;

    text-decoration: none;
    white-space: nowrap;

    overflow: hidden;
}

/* ICON */
.settings-sidebar ul li a i {
    flex: 0 0 18px;

    width: 18px;
    min-width: 18px;

    text-align: center;
}

/* TEXT */
.settings-sidebar ul li a span {
    flex: 1 1 auto;

    width: auto;
    min-width: 0;
    max-width: 100%;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;

    text-align: left;
}

/* ACTIVE */
.settings-sidebar ul li a.active {
    width: 100%;
    max-width: 100%;
}

/* CARD */
.settings-sidebar .card {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;
}

/* CARD BODY */
.settings-sidebar .card-body {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;
}


/* ==========================================
   DESKTOP
========================================== */

@media (min-width: 992px) {

    .settings-sidebar {
        width: 100%;
        max-width: 100%;
        min-width: 0;
    }

    .settings-sidebar ul li a {
        padding: 8px 10px;
    }
}


/* ========TABLET============= */

@media (max-width: 991.98px) {

    .settings-sidebar,
    .settings-sidebar .card,
    .settings-sidebar .card-body,
    .settings-sidebar ul,
    .settings-sidebar ul li,
    .settings-sidebar ul li a {
        width: 100%;
        max-width: 100%;
        min-width: 0;
    }
}


/* ==========================================
   MOBILE
========================================== */

@media (max-width: 575.98px) {

    .settings-sidebar .card-body {
        padding: 8px !important;
    }

    .settings-sidebar ul li a {
        padding: 8px 10px !important;
        gap: 6px !important;
    }

    .settings-sidebar ul li a i {
        flex: 0 0 18px;
        width: 18px;
        min-width: 18px;
    }

    .settings-sidebar ul li a span {
        font-size: 14px;
    }
}




/* =========================================================
   MOBILE SIDEBAR - HORIZONTAL SCROLL
   Existing desktop/tablet styles remain unchanged
   ========================================================= */

@media (max-width: 767.98px) {

    /* Sidebar column */
    .col-12.col-lg-3 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        min-width: 0 !important;
    }

    /* Sidebar card */
    .settings-sidebar {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
        overflow: hidden !important;
    }

    .settings-sidebar .card {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
        overflow: hidden !important;
    }

    /* Card body becomes horizontal scroll container */
    .settings-sidebar .card-body {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;

        overflow-x: auto !important;
        overflow-y: hidden !important;

        -webkit-overflow-scrolling: touch;

        scrollbar-width: thin;
        white-space: nowrap;
    }

    /* Keep the menu in one horizontal row */
    .settings-sidebar .settings-nav {
        display: flex !important;
        flex-direction: row !important;

        flex-wrap: nowrap !important;

        width: max-content !important;
        min-width: max-content !important;
        max-width: none !important;

        gap: 6px !important;
    }

    /* Each menu item keeps its natural width */
    .settings-sidebar .settings-nav .nav-item {
        flex: 0 0 auto !important;

        width: auto !important;
        max-width: none !important;
        min-width: max-content !important;
    }

    /* Menu links */
    .settings-sidebar .settings-nav .nav-link {
        width: auto !important;
        max-width: none !important;
        min-width: max-content !important;

        display: flex !important;
        align-items: center !important;
        justify-content: flex-start !important;

        white-space: nowrap !important;

        padding: 8px 14px !important;
        gap: 7px !important;

        overflow: visible !important;
    }

    /* Icons */
    .settings-sidebar .settings-nav .nav-link i {
        flex: 0 0 auto !important;

        width: 18px !important;
        min-width: 18px !important;

        text-align: center;
    }

    /* Text */
    .settings-sidebar .settings-nav .nav-link span {
        flex: 0 0 auto !important;

        width: auto !important;
        max-width: none !important;
        min-width: max-content !important;

        white-space: nowrap !important;

        overflow: visible !important;
        text-overflow: unset !important;
    }

    /* Optional: make scrollbar less intrusive */
    .settings-sidebar .card-body::-webkit-scrollbar {
        height: 5px;
    }

    .settings-sidebar .card-body::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    .settings-sidebar .card-body::-webkit-scrollbar-thumb {
        background: #b8b8b8;
        border-radius: 10px;
    }

    .settings-sidebar .card-body::-webkit-scrollbar-thumb:hover {
        background: #888;
    }
}
</style><?php /**PATH C:\xampp\htdocs\Ryans-infra\resources\views/layouts/sections/settings/adminsettings-sidebar.blade.php ENDPATH**/ ?>