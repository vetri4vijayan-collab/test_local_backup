<?php
// Variables
return [
  "creatorName" => "Ryan Infra",
  "creatorUrl" => "https://eibsglobal.com/",
  "templateName" => "Ryan Infra Developer",
  "templateSuffix" => "Ryan Infra Developer",
  "templateVersion" => "1.0",
  "templateFree" => false,
  "templateDescription" => "Ryan Infra Developer –  We create exceptional living and working environments through modern design, quality construction, and sustainable",
  "templateKeyword" => " We create exceptional living and working environments through modern design, quality construction, and sustainable",
  "licenseUrl" => "https://themeforest.net/licenses/standard",
  "livePreview" => "",
  "productPage" => "",
  "support" => "",
  "moreThemes" => "",
  "documentation" => "",
  "generator" => "",
  "changelog" => "",
  "repository" => "",
  "gitRepo" => "",
  "gitRepoAccess" => "",
  "facebookUrl" => "https://www.facebook.com/SriRadhaKrishnaDevelopers",
  "twitterUrl" => "",
  "githubUrl" => "",
  "dribbbleUrl" => "",
  "instagramUrl" => "https://www.instagram.com/sriradhakrishnadevelopers?fbclid=IwY2xjawOgxrlleHRuA2FlbQIxMABicmlkETFKVk1MQ1diOVFJU0h4MUxxc3J0YwZhcHBfaWQQMjIyMDM5MTc4ODIwMDg5MgABHgcTNstj0qRVWXa5RoZICYiuxIVq0BxDOf5iwrdc4tqLa0keiUKPgQDyOyEn_aem_o_OvVfyYqNtgWwVmJdcK0A"
];
