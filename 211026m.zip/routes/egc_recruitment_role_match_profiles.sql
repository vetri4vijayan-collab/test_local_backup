-- Optional, additive ATS role-matching profiles for egc_recruitment_roles.
-- Tested syntax target: MariaDB 10.4 / MySQL 8.0.
-- No existing role, applicant, application, job_role_id or AI fields are modified.
-- The application has a built-in keyword taxonomy when this table is absent or empty.

CREATE TABLE IF NOT EXISTS `egc_recruitment_role_match_profiles` (
  `role_code` varchar(80) NOT NULL,
  `role_title_keywords` longtext DEFAULT NULL,
  `education_keywords` longtext DEFAULT NULL,
  `employment_keywords` longtext DEFAULT NULL,
  `internship_keywords` longtext DEFAULT NULL,
  `skill_keywords` longtext DEFAULT NULL,
  `exclude_keywords` longtext DEFAULT NULL,
  `minimum_match_score` tinyint(3) unsigned NOT NULL DEFAULT 27,
  `profile_version` int(10) unsigned NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned NOT NULL DEFAULT 0,
  `updated_by` bigint(20) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT '0=Active, 1=Inactive, 2=Deleted',
  PRIMARY KEY (`role_code`),
  KEY `idx_egc_role_match_profiles_status_score` (`status`, `minimum_match_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Idempotently create starter rows for active role definitions.
-- The service merges these with its baseline taxonomy. Do not overwrite existing
-- customized profiles on subsequent deployments; INSERT IGNORE preserves them.
INSERT IGNORE INTO `egc_recruitment_role_match_profiles`
    (`role_code`, `role_title_keywords`, `education_keywords`, `employment_keywords`,
     `internship_keywords`, `skill_keywords`, `exclude_keywords`, `minimum_match_score`,
     `profile_version`, `created_by`, `updated_by`, `status`)
SELECT
    r.`role_code`,
    JSON_ARRAY(r.`role_name`, REPLACE(LOWER(r.`role_code`), '_', ' ')),
    JSON_ARRAY(), JSON_ARRAY(), JSON_ARRAY(), JSON_ARRAY(), JSON_ARRAY(),
    27, 1, 0, 0, 0
FROM `egc_recruitment_roles` AS r
WHERE r.`status` = 0 AND r.`match_enabled` = 1;

-- Example profile refinement (edit only after reviewing the resume and role):
-- UPDATE `egc_recruitment_role_match_profiles`
-- SET `skill_keywords` = JSON_ARRAY('PHP', 'Laravel', 'REST API', 'MySQL', 'PostgreSQL'),
--     `employment_keywords` = JSON_ARRAY('backend developer', 'API development', 'server side development'),
--     `internship_keywords` = JSON_ARRAY('backend developer intern', 'backend development intern'),
--     `education_keywords` = JSON_ARRAY('computer science', 'computer applications', 'BCA', 'MCA'),
--     `updated_by` = 1
-- WHERE `role_code` = 'BACK_END_DEVELOPER';
