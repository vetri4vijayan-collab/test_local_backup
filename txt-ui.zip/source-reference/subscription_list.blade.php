@extends('layouts/layoutMaster')

@section('title', 'Subscription & Others')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/dropzone/dropzone.scss', 
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
    'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/dropzone/dropzone.js', 
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')

<style>
  .table-wrapper {
    max-height: 380px;
    overflow-y: auto;
    overflow-x: hidden;
    border: 1px solid #eee;
}

/* Sticky Header */
.table-header th {
    position: sticky;
    top: 0;
    z-index: 5;
    background: #AB2B22 !important;
    color: white;
    padding-top: 10px;
    padding-bottom: 10px;
}
</style>

<!-- Lead List Table -->
<div class="card card-action mb-4">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage Subscription & Others</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home me-1"></i>Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-shield-crown-outline me-1"></i>Corporate Admin
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                          Policies & RD Accounts
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                    <span><i class="mdi mdi-filter-outline"></i></span>
                </a> -->
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white"  data-bs-toggle="modal" data-bs-target="#kt_modal_add_subscription">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Subscription
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row ">
            <div class="col-lg-12 mb-2">
                <div class="row g-2">
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                            <div class="d-flex align-items-center justify-content-between gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-dark">Annual Subscription Spend</label>
                                    <label class="fs-2 fw-semibold text-black">&#8377; 2,53,000</label>
                                </div>
                                <label>
                                    <span class="badge bg-label-secondary rounded-circle">
                                        <i class="mdi mdi-currency-rupee fs-3"></i>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                            <div class="d-flex align-items-center justify-content-between gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-dark">Total Seats</label>
                                    <label class="fs-2 fw-semibold text-black">885</label>
                                </div>
                                <label>
                                    <span class="badge bg-label-danger rounded-circle">
                                        <i class="mdi mdi-text-box-outline fs-3"></i>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                            <div class="d-flex align-items-center justify-content-between gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-dark">Utilisation</label>
                                    <label class="fs-2 fw-semibold text-black">71.9 % </label>
                                </div>
                                <label>
                                    <span class="badge bg-label-success rounded-circle">
                                        <i class="mdi mdi-widgets fs-3"></i>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                            <div class="d-flex align-items-center justify-content-between gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-dark">Underutilised</label>
                                    <div class="d-flex align-items-center gap-2">
                                        <label class="fs-2 fw-semibold text-black">2</label>
                                        <small class="pt-2">Flags</small>
                                    </div>
                                </div>
                                <label>
                                    <span class="badge bg-label-dark rounded-circle">
                                        <i class=" mdi mdi-circle-half-full fs-3"></i>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row g-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="d-flex align-items-center justify-content-between mb-1 gap-2">
                            <div class="badge d-flex align-items-center gap-2 rounded-2 fw-semibold  fs-6 bg-label-success" >
                                <i class="mdi mdi-widgets fs-3"></i>
                                <label class="text-black" >Licence Utilisation</label>
                            </div>
                            <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                <div class="searchBar">
                                    <input class="searchQueryInput" type="text" name="searchQueryInput"
                                        placeholder="Enter Subscription / Vendor" value=""
                                        oninput="toggleIcons(this)" />
                                    <a href="{{url('/manage_amc-contract')}}"
                                    class="searchQuerySubmit searchIcon">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                                C16,11.11 15.41,12.59 14.44,13.73
                                                L14.71,14H15.5L20.5,19L19,20.5
                                                L14,15.5V14.71L13.73,14.44
                                                C12.59,15.41 11.11,16
                                                9.5,16A6.5,6.5 0 0,1 3,9.5
                                                A6.5,6.5 0 0,1 9.5,3
                                                M9.5,5C7,5 5,7 5,9.5
                                                C5,12 7,14 9.5,14
                                                C12,14 14,12 14,9.5
                                                C14,7 12,5 9.5,5Z"/>
                                        </svg>
                                    </a>
                                    <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                                A8,8 0 0,0 4,12H1L4.89,16.89
                                                L9,12H6A6,6 0 0,1 12,6
                                                C13.66,6 15.14,6.69 16.22,7.78
                                                L17.65,6.35M19.11,7.11L15,12
                                                H18A6,6 0 0,1 12,18
                                                C10.34,18 8.86,17.31 7.78,16.22
                                                L6.35,17.65C7.8,19.1 9.79,20
                                                12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="table-wrapper mt-4">
                            <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                                <thead class="table-header">
                                    <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">ID</th>
                                        <th class="min-w-100px text-nowrap"><label  data-bs-toggle="tooltip" data-bs-placement="bottom" title="Subscription">Subsc.</label> / Vendor</th>
                                        <th class="min-w-100px">Category</th>
                                        <th class="min-w-100px text-center">Seats</th>
                                        <th class="min-w-100px text-nowrap  text-center">Cost / Seat</th>
                                        <th class="min-w-100px">Annual</th>
                                        <th class="min-w-100px">Renews</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="table-body text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">SUB-101</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Atlas Work Suite">Atlas Work Suite</div>
                                            <div class="d-block">
                                                <div class="text-truncate text-dark" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Atlas Cloud">Atlas Cloud</div>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <div>
                                                <label class="badge bg-label-dark fw-semibold fs-7">SaaS</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column align-items-start gap-1" style="width:100%;">                                        
                                                <small class="text-end text-black text-nowrap " style="width:100%;">420 Total</small>
                                                <div class="progress bg-lighter rounded " style="width:150px;">
                                                    <div class="progress-bar" role="progressbar" style="width: 81%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                                    <div class="progress-bar bg-success" role="progressbar" style="width: 94%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <div class="d-flex align-items-center gap-2">
                                                    <small class="text-black text-nowrap">341 Used</small>
                                                    <small class="text-muted">|</small>
                                                    <small class="text-black text-nowrap">394 Assigned</small>
                                                </div>
                                            </div>
                                        </td>
                                        
                                        <td align="center">
                                            <label class="fw-semibold fs-7 badge bg-label-primary">&#8377; 196</label>
                                        </td>
                                        <td>
                                            <label>&#8377; 82,400</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold text-nowrap">04-Apr-2026</label>
                                                <label class="text-danger">In 12 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">SUB-102</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Nimbus CRM">Nimbus CRM</div>
                                            <div class="d-block">
                                                <div class="text-truncate text-dark" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Nimbus Sales">Nimbus Sales</div>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="badge bg-label-dark fw-semibold fs-7">CRM</label>
                                        </td>
                                        
                                        <td>
                                            <div class="d-flex flex-column align-items-start gap-1" style="width:100%;">                                        
                                                <small class="text-end text-black text-nowrap " style="width:100%;">300 Total</small>
                                                <div class="progress bg-lighter rounded " style="width:150px;">
                                                    <div class="progress-bar" role="progressbar" style="width: 70%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                                    <div class="progress-bar bg-success" role="progressbar" style="width:85%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <div class="d-flex align-items-center gap-2">
                                                    <small class="text-black text-nowrap">210 Used</small>
                                                    <small class="text-muted">|</small>
                                                    <small class="text-black text-nowrap">255 Assigned</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <label class="fw-semibold fs-7 badge bg-label-primary">&#8377; 250</label>
                                        </td>
                                        <td><label>&#8377; 75,000</label></td>
                                        <td>
                                            <div>
                                                <label class="fw-semibold">10-Apr-2026</label>
                                                <label class="text-danger">In 18 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><label class="text-truncate max-w-175px">SUB-103</label></td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="ZenDesk Suite">ZenDesk Suite</div>
                                            <div class="d-block">
                                                <div class="text-truncate text-dark" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Support Pro">Support Pro</div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <label class="badge bg-label-dark fw-semibold fs-7">Support</label>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <div class="d-flex flex-column align-items-start gap-1" style="width:100%;">                                        
                                                <small class="text-end text-black text-nowrap " style="width:100%;">150 Total</small>
                                                <div class="progress bg-lighter rounded " style="width:150px;">
                                                    <div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                                    <div class="progress-bar bg-success" role="progressbar" style="width:90%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <div class="d-flex align-items-center gap-2">
                                                    <small class="text-black text-nowrap">90 Used</small>
                                                    <small class="text-muted">|</small>
                                                    <small class="text-black text-nowrap">135 Assigned</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <label class="fw-semibold fs-7 badge bg-label-primary">&#8377; 180</label>
                                        </td>
                                        <td>&#8377; 27,000</td>
                                        <td>
                                            <label>02-May-2026</label>
                                            <label class="text-danger">In 30 days</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2 bg-label-success"  >
                                                Healthy
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><label>SUB-104</label></td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Google Workspace">Google Workspace</div>
                                            <div class="d-block">
                                                <div class="text-truncate text-dark" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Business Plus">Business Plus</div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <label class="badge bg-label-dark fw-semibold fs-7">Email</label>
                                            </div>
                                        </td>
                                        
                                        
                                        <td>
                                            <div class="d-flex flex-column align-items-start gap-1" style="width:100%;">                                        
                                                <small class="text-end text-black text-nowrap " style="width:100%;">500 Total</small>
                                                <div class="progress bg-lighter rounded " style="width:150px;">
                                                    <div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                                    <div class="progress-bar bg-success" role="progressbar" style="width:80%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <div class="d-flex align-items-center gap-2">
                                                    <small class="text-black text-nowrap">250 Used</small>
                                                    <small class="text-muted">|</small>
                                                    <small class="text-black text-nowrap">400 Assigned</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <label class="fw-semibold fs-7 badge bg-label-primary">&#8377; 125</label>
                                        </td>
                                        <td>&#8377; 62,500</td>
                                        <td>
                                            <label>15-Apr-2026</label>
                                            <label class="text-danger">In 10 days</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><label>SUB-105</label></td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Slack Enterprise">Slack Enterprise</div>
                                            <div class="d-block">
                                                <div class="text-truncate text-dark" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Collaboration">Collaboration</div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <label class="badge bg-label-dark fw-semibold fs-7">Communication</label>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <div class="d-flex flex-column align-items-start gap-1" style="width:100%;">                                        
                                                <small class="text-end text-black text-nowrap " style="width:100%;">200 Total</small>
                                                <div class="progress bg-lighter rounded " style="width:150px;">
                                                    <div class="progress-bar" role="progressbar" style="width: 65%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                                    <div class="progress-bar bg-success" role="progressbar" style="width:88%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <div class="d-flex align-items-center gap-2">
                                                    <small class="text-black text-nowrap">130 Used</small>
                                                    <small class="text-muted">|</small>
                                                    <small class="text-black text-nowrap">176 Assigned</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <label class="fw-semibold fs-7 badge bg-label-primary">&#8377; 300</label>
                                        </td>
                                        <td>&#8377; 60,000</td>
                                        <td>
                                            <label>20-Apr-2026</label>
                                            <label class="text-danger">In 5 days</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><label>SUB-106</label></td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Adobe Creative Cloud">Adobe Creative Cloud </div>
                                            <div class="d-block">
                                                <div class="text-truncate text-dark" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Design Suite">Design Suite</div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <label class="badge bg-label-dark fw-semibold fs-7">Design</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column align-items-start gap-1" style="width:100%;">                                        
                                                <small class="text-end text-black text-nowrap " style="width:100%;">100 Total</small>
                                                <div class="progress bg-lighter rounded " style="width:150px;">
                                                    <div class="progress-bar" role="progressbar" style="width: 40%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                                    <div class="progress-bar bg-success" role="progressbar" style="width:70%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <div class="d-flex align-items-center gap-2">
                                                    <small class="text-black text-nowrap">40 Used</small>
                                                    <small class="text-muted">|</small>
                                                    <small class="text-black text-nowrap">70 Assigned</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td align="center">
                                            <label class="fw-semibold fs-7 badge bg-label-primary">&#8377; 450</label>
                                        </td>
                                        <td>&#8377; 45,000</td>
                                        <td>
                                            <label>25-Apr-2026</label>
                                            <label class="text-danger">In 7 days</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2 bg-label-success"  >
                                                Healthy
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>        
                </div>        
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12 " >
                        <div class="d-flex align-items-center justify-content-between mb-1 gap-2">

                            <div class="badge d-flex align-items-center gap-2 rounded-2 fw-semibold  fs-6 bg-label-danger" >
                                <i class="mdi mdi-text-box-outline fs-3"></i>
                                <label class="text-black" >Organisation Memberships</label>
                            </div>

                            <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                <div class="searchBar">
                                    <input class="searchQueryInput" type="text" name="searchQueryInput"
                                        placeholder="Enter Body / Tier / Fee" value=""
                                        oninput="toggleIcons(this)" />
                                    <a href="{{url('/manage_amc-contract')}}"
                                    class="searchQuerySubmit searchIcon">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                                C16,11.11 15.41,12.59 14.44,13.73
                                                L14.71,14H15.5L20.5,19L19,20.5
                                                L14,15.5V14.71L13.73,14.44
                                                C12.59,15.41 11.11,16
                                                9.5,16A6.5,6.5 0 0,1 3,9.5
                                                A6.5,6.5 0 0,1 9.5,3
                                                M9.5,5C7,5 5,7 5,9.5
                                                C5,12 7,14 9.5,14
                                                C12,14 14,12 14,9.5
                                                C14,7 12,5 9.5,5Z"/>
                                        </svg>
                                    </a>
                                    <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                                A8,8 0 0,0 4,12H1L4.89,16.89
                                                L9,12H6A6,6 0 0,1 12,6
                                                C13.66,6 15.14,6.69 16.22,7.78
                                                L17.65,6.35M19.11,7.11L15,12
                                                H18A6,6 0 0,1 12,18
                                                C10.34,18 8.86,17.31 7.78,16.22
                                                L6.35,17.65C7.8,19.1 9.79,20
                                                12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="table-wrapper mt-4">
                            <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                                <thead class="table-header">
                                    <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">ID</th>
                                        <th class="min-w-100px">Body</th>
                                        <th class="min-w-100px">Tier</th>
                                        <th class="min-w-100px text-center">Fee</th>
                                        <th class="min-w-100px text-center">Benefits</th>
                                        <th class="min-w-100px text-center">Contacts</th>
                                        <th class="min-w-100px">Renews</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="table-body text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">MEM-011</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Continental Business Council</div>
                                        </td>
                                        
                                        <td>
                                            <label class="badge bg-label-primary text-primary fw-semibold fs-7">Platinum</label>
                                        </td>
                                        <td>
                                            <label >&#8377; 14,000</label>
                                        </td>
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary" style=" color:#fff; border-radius:50px; width:40px; height:40px;">08</span>
                                        </td>
                                        
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary" style=" color:#fff; border-radius:50px; width:40px; height:40px;">03</span>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">04-Apr-2026</label>
                                                <label class="text-danger">In 1 day</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal Due
                                            </label>
                                        </td>

                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEndAMC"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">MEM-007</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Global Exchange Forum</div>
                                        </td>
                                        <td>
                                            <label class="badge bg-label-warning text-warning fw-semibold fs-7">Gold</label>
                                        </td>
                                        <td>
                                            <label >&#8377; 5,000</label>
                                        </td>
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary" style=" color:#fff; border-radius:50px; width:40px; height:40px;">05</span>
                                        </td>
                                        
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary" style=" color:#fff; border-radius:50px; width:40px; height:40px;">03</span>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">16-May-2026</label>
                                                <label class="text-danger">In 12 day</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2 bg-label-success" >
                                               Active
                                            </label>
                                        </td>

                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEndAMC"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">MEM-004</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Industry Standards Body</div>
                                        </td>
                                        <td>
                                            <label class="badge bg-label-dark fw-semibold fs-7">Silver</label>
                                        </td>
                                        <td>
                                            <label >&#8377; 2,400</label>
                                        </td>
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary" style=" color:#fff; border-radius:50px; width:40px; height:40px;">04</span>
                                        </td>
                                        
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary" style=" color:#fff; border-radius:50px; width:40px; height:40px;">01</span>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">05-May-2026</label>
                                                <label class="text-danger">In 13 day</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2 bg-label-success" >
                                               Active
                                            </label>
                                        </td>

                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEndAMC"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12 " >
                        <div class="d-flex align-items-center justify-content-between mb-1 gap-2">
                            <div class="badge d-flex align-items-center gap-2 rounded-2 fw-semibold  fs-6 bg-label-warning" >
                                <i class="mdi mdi-currency-rupee fs-3"></i>
                                <label class="text-black" >Upcoming Payments</label>
                            </div>
                            <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                <div class="searchBar">
                                    <input class="searchQueryInput" type="text" name="searchQueryInput"
                                        placeholder="Enter Body / Tier / Fee" value=""
                                        oninput="toggleIcons(this)" />
                                    <a href="{{url('/manage_amc-contract')}}"
                                    class="searchQuerySubmit searchIcon">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                                C16,11.11 15.41,12.59 14.44,13.73
                                                L14.71,14H15.5L20.5,19L19,20.5
                                                L14,15.5V14.71L13.73,14.44
                                                C12.59,15.41 11.11,16
                                                9.5,16A6.5,6.5 0 0,1 3,9.5
                                                A6.5,6.5 0 0,1 9.5,3
                                                M9.5,5C7,5 5,7 5,9.5
                                                C5,12 7,14 9.5,14
                                                C12,14 14,12 14,9.5
                                                C14,7 12,5 9.5,5Z"/>
                                        </svg>
                                    </a>
                                    <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                                A8,8 0 0,0 4,12H1L4.89,16.89
                                                L9,12H6A6,6 0 0,1 12,6
                                                C13.66,6 15.14,6.69 16.22,7.78
                                                L17.65,6.35M19.11,7.11L15,12
                                                H18A6,6 0 0,1 12,18
                                                C10.34,18 8.86,17.31 7.78,16.22
                                                L6.35,17.65C7.8,19.1 9.79,20
                                                12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="table-wrapper mt-4">
                            <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                                <thead class="table-header">
                                    <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Date</th>
                                        <th class="min-w-100px">Reference</th>
                                        <th class="min-w-100px">Method</th>
                                        <th class="min-w-100px text-center">Amount</th>
                                        <th class="min-w-100px text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="table-body text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <label class="">02-Apr-2026</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:250px;">Granite Security Cloud · renewal</div>
                                        </td>
                                        <td>
                                            <label class="">Card</label>
                                        </td>
                                        <td align="center">
                                            <label >&#8377; 14,000</label>
                                        </td>
                                        
                                        <td align="center">
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Scheduled
                                            </label>
                                        </td>                                      
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="">05-Apr-2026</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:250px;">Adobe Creative Cloud · renewal</div>
                                        </td>
                                        <td>
                                            <label class="">UPI</label>
                                        </td>
                                        <td align="center">
                                            <label>&#8377; 8,500</label>
                                        </td>
                                        <td align="center">
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Scheduled
                                            </label>
                                        </td>  
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="">08-Apr-2026</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:250px;">Microsoft 365 Business · renewal</div>
                                        </td>
                                        <td>
                                            <label class="">Net Banking</label>
                                        </td>
                                        <td align="center">
                                            <label>&#8377; 22,000</label>
                                        </td>
                                        <td align="center">
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#FDEBD2; color:#C47A1B;">
                                                Scheduled
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="">11-Apr-2026</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:250px;">Zoho CRM Pro · renewal</div>
                                        </td>
                                        <td>
                                            <label class="">Card</label>
                                        </td>
                                        <td align="center">
                                            <label>&#8377; 6,200</label>
                                        </td>
                                        <td align="center">
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Scheduled
                                            </label>
                                        </td>  
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="">15-Apr-2026</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:250px;">AWS Infrastructure · renewal</div>
                                        </td>
                                        <td>
                                            <label class="">Card</label>
                                        </td>
                                        <td align="center">
                                            <label>&#8377; 45,000</label>
                                        </td>
                                        <td align="center">
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Scheduled
                                            </label>
                                        </td>  
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="">19-Apr-2026</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:250px;">Slack Business+ · renewal</div>
                                        </td>
                                        <td>
                                            <label class="">UPI</label>
                                        </td>
                                        <td align="center">
                                            <label>&#8377; 11,800</label>
                                        </td>
                                        <td align="center">
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#FDEBD2; color:#C47A1B;">
                                                Scheduled
                                            </label>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<div class="offcanvas offcanvas-end " style="width:565px;" tabindex="-1" id="offcanvasEnd" aria-labelledby="offcanvasEndLabel">
  <div class="offcanvas-header border-bottom">
    <div class="d-flex align-items-center gap-2">
        <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
            SMM
        </label>
        <div class="d-flex flex-column">
            <label class="text-black fs-6 fw-semibold text-truncate" style="max-width:200px;">Atlas Work Suite</label>
            <label class="text-dark fs-8">SUB-101</label>
        </div>
    </div>
    <button type="button" class="btn-close text-reset border border-dark" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>

  <div class="offcanvas-body ">
    <div class="row g-3">
        <div class="col-lg-12 d-flex align-items-end justify-content-between">
            <div class="d-flex flex-column">
                <label class="text-dark fs-8">Annual Cost</label>
                 <label class="text-black fs-3 fw-semibold ">&#8377; 82,400</label>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="d-flex align-items-center justify-content-between gap-2">
                            <div class="d-flex flex-column">
                                <label class="fs-8 fw-semibold text-dark">Seats In Use</label>
                                <label class="fs-6 fw-semibold text-black">341 / 420</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="d-flex align-items-center justify-content-between gap-2">
                            <div class="d-flex flex-column">
                                <label class="fs-8 fw-semibold text-dark">Cost Per Seat</label>
                                <label class="fs-6 fw-semibold text-black">&#8377; 196</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                          <div class="col-lg-12 pb-2 mb-2 border-bottom">
                                <div class="text-black fs-6 fw-semibold">
                                    Licence Utilisation
                                </div>
                          </div>
                          <div class="col-lg-12 d-flex flex-column gap-2">
                            <div class="progress bg-lighter rounded mt-3" >
                                <div class="progress-bar" role="progressbar" style="width: 81%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                <div class="progress-bar bg-success" role="progressbar" style="width: 94%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                <div class="progress-bar bg-label-dark" role="progressbar" style="width: 94%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center gap-2">
                                    <span class="p-2 " style="width:3px; height:3px; background:#666cff;"></span>
                                    <small class=" text-dark  fw-semibold pt-1">Active Use . 341</small>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="p-2 " style="width:3px; height:3px; background:#038701;"></span>
                                    <small class=" text-dark  fw-semibold pt-1">Assigned Only . 53</small>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="p-2 bg-label-dark" style="width:3px; height:3px;"></span>
                                    <small class=" text-dark  fw-semibold pt-1">Available . 53</small>
                                </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                          <div class="col-lg-12 pb-2 mb-2 border-bottom">
                                <div class="text-black fs-6 fw-semibold">
                                    Subscription Detials
                                </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Vendor</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Atlas Cloud
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Category</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              SaaS
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Billing Cycle</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Annual
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Owner</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              IT Ops
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Next Renewal</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              09-May-2025
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Payment History
                                </div>
                                <span class="badge bg-dark text-white">02</span>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1">
                                    <thead>
                                        <tr class="text-start align-top  fw-bold fs-7 gs-0 bg-label-dark">
                                            <th class="min-w-100px text-black">Date</th>
                                            <th class="min-w-100px text-black">Referance</th>
                                            <th class="min-w-100px text-black">Method</th>
                                            <th class="min-w-100px text-black">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-medium fs-7">
                                        <tr>
                                            <td>
                                                <label class="">09-May-2025</label>
                                            </td>
                                            <td>
                                                <label class="">TXN-88412</label>
                                            </td>
                                            <td>
                                                <label class="">Wire</label>
                                            </td>
                                            <td>
                                                <label  >
                                                    &#8377; 16,870
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="">09-May-2024</label>
                                            </td>
                                            <td>
                                                <label class="">TXN-71992</label>
                                            </td>
                                            <td>
                                                <label class="">Wire</label>
                                            </td>
                                            <td>
                                                <label  >
                                                    &#8377; 75,808
                                                </label>
                                            </td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Credentials
                                </div>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <div class="row">
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-dark fs-8">App URL</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">https://app.atlas.com</label>
                                                
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2  border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                 <label class="text-dark fs-8">Username</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">billing@northstar.co</label>
                                               
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-dark fs-8">Password</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">-</label>
                                                
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between pt-2 ">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-dark fs-8">Registered Email</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">accounts.team@northstar.co</label>
                                                
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
    <div class="offcanvas-footer border-top p-3 pt-4 d-flex justify-content-end gap-2">
        <i class="mdi mdi-square-edit-outline fs-3 text-black me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_update_subscription"></i>
        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="offcanvas">
            Export
        </button>
        <button type="button" class="btn btn-sm btn-primary">
            Initiate Renewal
        </button>
    </div>
</div>


<div class="offcanvas offcanvas-end " style="width:565px;" tabindex="-1" id="offcanvasEndAMC" aria-labelledby="offcanvasEndAMCLabel">
  <div class="offcanvas-header border-bottom">
    <div class="d-flex align-items-center gap-2">
        <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
            SMM
        </label>
        <div class="d-flex flex-column">
            <label class="text-black fs-6 fw-semibold text-truncate" style="max-width:200px;">Continental Business Council</label>
            <label class="text-dark fs-8">MEM-011</label>
        </div>
    </div>
    <button type="button" class="btn-close text-reset border border-dark" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>

  <div class="offcanvas-body ">
    <div class="row g-3">
        <div class="col-lg-12 d-flex align-items-end justify-content-between">
            <div class="d-flex flex-column">
                <label class="text-dark fs-8">Annual Fee</label>
                 <label class="text-black fs-3 fw-semibold ">&#8377; 14,000</label>
            </div>
            <label class="badge bg-label-primary text-primary fw-semibold fs-7">Platinum</label>
        </div>
        
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Benefits
                                </div>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <div class="row">
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                
                                                <label class="text-black fs-7 fw-semibold ">Annual Conference - 4 Delegates</label>
                                                
                                            </div>
                                        </div>                             
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                
                                                <label class="text-black fs-7 fw-semibold ">Member - Only Research Reports</label>
                                                
                                            </div>
                                        </div>                             
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                
                                                <label class="text-black fs-7 fw-semibold ">Quartely CEO Roundtable</label>
                                                
                                            </div>
                                        </div>                             
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between pt-2 ">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-black fs-7 fw-semibold ">Industry Awards Nominations Rights</label>
                                               
                                            </div>
                                        </div>                             
                                    </div>
                                    
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Contacts
                                </div>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <div class="row">
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-dark fs-8">Membership Director</label>
                                                <label class="text-black fs-7 fw-semibold ">D.Albright.dalbright@gmail.com</label>
                                                
                                            </div>
                                        </div>                             
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between pt-2 ">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                 <label class="text-dark fs-8">Events Lead</label>
                                                <label class="text-black fs-7 fw-semibold ">N.Ferreira.nferreira@gmail.com</label>
                                               
                                            </div>
                                        </div>                             
                                    </div>
                                    
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Credentials
                                </div>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <div class="row">
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-dark fs-8">App URL</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">https://members.continental.org</label>
                                                
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2  border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                 <label class="text-dark fs-8">Username</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">secretariat@northstar.co</label>
                                               
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-dark fs-8">Password</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">-</label>
                                                
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2  border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-dark fs-8">Registered Email</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">accounts.team@northstar.co</label>
                                                
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between pt-2 ">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="d-flex flex-column">
                                                <label class="text-dark fs-8">Registered Mobile</label>
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">+91 98210 44128</label>
                                            </div>
                                        </div>
                                        <span class="mdi mdi-file-document-outline fs-4"></span>                                        
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
    <div class="offcanvas-footer border-top p-3 pt-4 d-flex justify-content-end gap-2">
        <i class="mdi mdi-square-edit-outline fs-3 text-black me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_update_subscription"></i>
        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="offcanvas">
            Export
        </button>
        
    </div>
</div>


<!--begin::Modal - Add Subscription -->
<div class="modal fade" id="kt_modal_add_subscription" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Create Subscription</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">
                    <div class="nav-align-top ">
                        <ul class="nav nav-pills" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab"
                                    data-bs-target="#navs-top-home"
                                    aria-controls="navs-top-home"
                                    aria-selected="true">
                                    Subscription
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab"
                                    data-bs-target="#navs-top-profile"
                                    aria-controls="navs-top-profile"
                                    aria-selected="false">
                                    Membership
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab"
                                    data-bs-target="#navs-top-messages"
                                    aria-controls="navs-top-messages"
                                    aria-selected="false">
                                    Other
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content p-0 m-0" style="box-shadow:none;">
                            <div class="tab-pane fade show active" id="navs-top-home" role="tabpanel">
                                <div class="row mt-4 pt-2">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Subscription Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Subscription Name">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Vendor<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Vendor">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Category</option>
                                            <option value="1">Saas</option>
                                            <option value="2">CRM</option>
                                            <option value="3">Dev Ops</option>
                                            <option value="4">BI</option>
                                            <option value="5">Design</option>
                                            <option value="6">Security</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Seats<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Seats">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Cost / Seat (₹)<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Cost / Seat (₹)">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Billing<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Billing</option>
                                            <option value="1">Annual</option>
                                            <option value="2">Monthly</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Rental Information</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Renewal date<span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" name="month" placeholder="Select Month" class="form-control common_datepicker" readonly />
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter URL">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Person Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Person Name">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Contact Number<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Contact Number">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Email ID">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Credentials</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">App URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter App URL">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Username<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Username">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Password">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Registered Email<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Registered Email">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Registered Mobile<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Registered Mobile">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Payment</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Through<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Payment Through</option>
                                            <option value="1">Credit Card</option>
                                            <option value="2">Bank</option>
                                            <option value="3">UPI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Bank</option>
                                            <option value="1">SBI</option>
                                            <option value="2">HDFC</option>
                                            <option value="3">Axis</option>
                                            <option value="3">ICICI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Credit Card<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Credit Card</option>
                                            <option value="1">SBI</option>
                                            <option value="2">HDFC</option>
                                            <option value="3">Axis</option>
                                            <option value="3">ICICI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Pay from (company)<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Pay from (company)</option>
                                            <option value="1">Northstar Corp</option>
                                            <option value="2">Northstar Holding</option>
                                            <option value="3">Northstar Labs LLP</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12 mb-3 mt-2">
                                        <div class="bg-label-primary p-3 d-flex align-items-center justify-content-between rounded">
                                            <label class="">Estimated Annual Spend</label>
                                            <label class="fw-semibold">₹ 0</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="navs-top-profile" role="tabpanel">
                                <div class="row mt-4 pt-2">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Body / Organisation<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Body / Organisation">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Primary Contact<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Primary Contact">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Tier<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Tier</option>
                                            <option value="1">Platinum</option>
                                            <option value="2">Gold</option>
                                            <option value="3">Silver</option>
                                            <option value="4">Standard</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Annual Fee (₹)<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Annual Fee (₹)">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Benefits Included<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Benefits Included">
                                    </div>
                                    
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Rental Information</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Renewal date<span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" name="month" placeholder="Select Month" class="form-control common_datepicker" readonly />
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter URL">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Person Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Person Name">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Contact Number<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Contact Number">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Email ID">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Credentials</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">App URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter App URL">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Username<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Username">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Password">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Registered Email<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Registered Email">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Registered Mobile<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Registered Mobile">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Payment</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Through<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Payment Through</option>
                                            <option value="1">Credit Card</option>
                                            <option value="2">Bank</option>
                                            <option value="3">UPI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Bank</option>
                                            <option value="1">SBI</option>
                                            <option value="2">HDFC</option>
                                            <option value="3">Axis</option>
                                            <option value="3">ICICI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Pay from (company)<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Pay from (company)</option>
                                            <option value="1">Northstar Corp</option>
                                            <option value="2">Northstar Holding</option>
                                            <option value="3">Northstar Labs LLP</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12 mb-3 mt-2">
                                        <div class="bg-label-primary p-3 d-flex align-items-center justify-content-between rounded">
                                            <label class="">Estimated Annual Spend</label>
                                            <label class="fw-semibold">₹ 0</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="navs-top-messages" role="tabpanel">
                                <div class="row mt-4 pt-2">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Expense name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Expense name">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Amount (₹)<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Amount (₹)">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Recurrence<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Recurrence</option>
                                            <option value="1">One-off</option>
                                            <option value="2">Monthly</option>
                                            <option value="3">Quarterly</option>
                                            <option value="4">Annual</option>
                                        </select>
                                    </div>
                                    
                                    
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Rental Information</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Renewal date<span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" name="month" placeholder="Select Month" class="form-control common_datepicker" readonly />
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter URL">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Person Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Person Name">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Contact Number<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Contact Number">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Email ID">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Payment</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Through<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Payment Through</option>
                                            <option value="1">Credit Card</option>
                                            <option value="2">Bank</option>
                                            <option value="3">UPI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Bank</option>
                                            <option value="1">SBI</option>
                                            <option value="2">HDFC</option>
                                            <option value="3">Axis</option>
                                            <option value="3">ICICI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Pay from (company)<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Pay from (company)</option>
                                            <option value="1">Northstar Corp</option>
                                            <option value="2">Northstar Holding</option>
                                            <option value="3">Northstar Labs LLP</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12 mb-3 mt-2">
                                        <div class="bg-label-primary p-3 d-flex align-items-center justify-content-between rounded">
                                            <label class="">Estimated Annual Spend</label>
                                            <label class="fw-semibold">₹ 0</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Create subscription</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add  Subscription-->

<!--begin::Modal - Update Subscription -->
<div class="modal fade" id="kt_modal_update_subscription" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Subscription</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">
                    <div class="nav-align-top ">
                        <ul class="nav nav-pills" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab"
                                    data-bs-target="#navs-top-home-edit"
                                    aria-controls="navs-top-home-edit"
                                    aria-selected="true">
                                    Subscription
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab"
                                    data-bs-target="#navs-top-profile-edit"
                                    aria-controls="navs-top-profile-edit"
                                    aria-selected="false">
                                    Membership
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab"
                                    data-bs-target="#navs-top-messages-edit"
                                    aria-controls="navs-top-messages-edit"
                                    aria-selected="false">
                                    Other
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content p-0 m-0" style="box-shadow:none;">
                            <div class="tab-pane fade show active" id="navs-top-home-edit" role="tabpanel">
                                <div class="row mt-4 pt-2">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Subscription Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Subscription Name" value="CRM Pro Subscription">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Vendor<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Vendor" value="Zoho">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Category</option>
                                            <option value="1">Saas</option>
                                            <option value="2"selected>CRM</option>
                                            <option value="3">Dev Ops</option>
                                            <option value="4">BI</option>
                                            <option value="5">Design</option>
                                            <option value="6">Security</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Seats<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Seats" value="10">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Cost / Seat (₹)<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Cost / Seat (₹)" value="1500">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Billing<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Billing</option>
                                            <option value="1">Annual</option>
                                            <option value="2"selected>Monthly</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Rental Information</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Renewal date<span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" name="month" placeholder="Select Month" class="form-control common_datepicker" readonly value="12-May-2026"/>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter URL" value="https://www.zoho.com/crm">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Person Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Person Name" value="Rajesh Kumar">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Contact Number<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Contact Number" value="9876543210">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Email ID" value="support@zoho.com">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Credentials</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">App URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter App URL" value="https://crm.zoho.com">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Username<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Username" value="admin@company.com">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Password" value="Test@123">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Registered Email<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Registered Email" value="admin@company.com">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Registered Mobile<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Registered Mobile" value="9123456780">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Payment</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Through<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Payment Through</option>
                                            <option value="1">Credit Card</option>
                                            <option value="2">Bank</option>
                                            <option value="3"selected>UPI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Bank</option>
                                            <option value="1">SBI</option>
                                            <option value="2"selected>HDFC</option>
                                            <option value="3">Axis</option>
                                            <option value="3">ICICI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Credit Card<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Credit Card</option>
                                            <option value="1">SBI</option>
                                            <option value="2"selected>HDFC</option>
                                            <option value="3">Axis</option>
                                            <option value="3">ICICI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Pay from (company)<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Pay from (company)</option>
                                            <option value="1"selected>Northstar Corp</option>
                                            <option value="2">Northstar Holding</option>
                                            <option value="3">Northstar Labs LLP</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12 mb-3 mt-2">
                                        <div class="bg-label-primary p-3 d-flex align-items-center justify-content-between rounded">
                                            <label class="">Estimated Annual Spend</label>
                                            <label class="fw-semibold">₹ 1,80,000</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="navs-top-profile-edit" role="tabpanel">
                                <div class="row mt-4 pt-2">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Body / Organisation<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Body / Organisation">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Primary Contact<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Primary Contact">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Tier<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Tier</option>
                                            <option value="1">Platinum</option>
                                            <option value="2">Gold</option>
                                            <option value="3">Silver</option>
                                            <option value="4">Standard</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Annual Fee (₹)<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Annual Fee (₹)">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Benefits Included<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Benefits Included">
                                    </div>
                                    
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Rental Information</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Renewal Date<span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" name="month" placeholder="Select Month" class="form-control common_datepicker" readonly />
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter URL">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Person Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Person Name">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Contact Number<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Contact Number">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Email ID">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Credentials</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">App URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter App URL">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Username<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Username">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Password">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Registered Email<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Registered Email">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Registered Mobile<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Registered Mobile">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Payment</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Through<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Payment Through</option>
                                            <option value="1">Credit Card</option>
                                            <option value="2">Bank</option>
                                            <option value="3">UPI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Bank</option>
                                            <option value="1">SBI</option>
                                            <option value="2">HDFC</option>
                                            <option value="3">Axis</option>
                                            <option value="3">ICICI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Pay From (Company)<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Pay From (Company)</option>
                                            <option value="1">Northstar Corp</option>
                                            <option value="2">Northstar Holding</option>
                                            <option value="3">Northstar Labs LLP</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12 mb-3 mt-2">
                                        <div class="bg-label-primary p-3 d-flex align-items-center justify-content-between rounded">
                                            <label class="">Estimated Annual Spend</label>
                                            <label class="fw-semibold">₹ 0</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="navs-top-messages-edit" role="tabpanel">
                                <div class="row mt-4 pt-2">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Expense Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Expense Name">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Amount (₹)<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Amount (₹)">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Recurrence<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Recurrence</option>
                                            <option value="1">One-off</option>
                                            <option value="2">Monthly</option>
                                            <option value="3">Quarterly</option>
                                            <option value="4">Annual</option>
                                        </select>
                                    </div>
                                    
                                    
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Rental Information</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Renewal date<span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" name="month" placeholder="Select Month" class="form-control common_datepicker" readonly />
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">URL<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter URL">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Person Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Person Name">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Support Contact Number<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Support Contact Number">
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Email ID">
                                    </div>
                                    <div class="col-lg-12 ">
                                        <h6 class="text-primary fw-bold  fs-4">Payment</h6>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Through<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Payment Through</option>
                                            <option value="1">Credit Card</option>
                                            <option value="2">Bank</option>
                                            <option value="3">UPI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Bank</option>
                                            <option value="1">SBI</option>
                                            <option value="2">HDFC</option>
                                            <option value="3">Axis</option>
                                            <option value="3">ICICI</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Pay From (Company)<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" >
                                            <option value="">Select Pay From (Company)</option>
                                            <option value="1">Northstar Corp</option>
                                            <option value="2">Northstar Holding</option>
                                            <option value="3">Northstar Labs LLP</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-12 mb-3 mt-2">
                                        <div class="bg-label-primary p-3 d-flex align-items-center justify-content-between rounded">
                                            <label class="">Estimated Annual Spend</label>
                                            <label class="fw-semibold">₹ 0</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Update subscription</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update  Subscription-->




<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength": 25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>


<script>
    const OffcanvasModalManager = (() => {

    function openModal(targetSelector) {
        const modalEl = document.querySelector(targetSelector.trim());
        if (!modalEl) return;
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();
    }

    function init() {
        document.addEventListener('click', function (e) {
            const trigger = e.target.closest('[data-bs-toggle="modal"]');
            if (!trigger) return;

            const modalTarget = trigger.getAttribute('data-bs-target');
            if (!modalTarget) return;

            const parentOffcanvas = trigger.closest('.offcanvas');
            if (!parentOffcanvas) return;

            e.preventDefault();
            e.stopPropagation();

            const offcanvasInstance = bootstrap.Offcanvas.getInstance(parentOffcanvas);

            if (offcanvasInstance) {
                parentOffcanvas.addEventListener('hidden.bs.offcanvas', function handler() {
                    parentOffcanvas.removeEventListener('hidden.bs.offcanvas', handler);

                    // ✅ Only remove backdrop, let Bootstrap handle body scroll itself
                    document.querySelectorAll('.offcanvas-backdrop').forEach(el => el.remove());
                    document.body.classList.remove('offcanvas-open');

                    openModal(modalTarget);
                });

                offcanvasInstance.hide();
            } else {
                openModal(modalTarget);
            }
        });
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => {
    OffcanvasModalManager.init();
});
</script>

@endsection
