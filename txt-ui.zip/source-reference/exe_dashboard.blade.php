@extends('layouts/layoutMaster')

@section('title', 'Executive Dashbaord')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/dropzone/dropzone.scss', 
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
    'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/dropzone/dropzone.js', 
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')

<style>
  /* =====================
     CALENDAR COMPONENT CSS
     Scoped under .cal-widget
  ===================== */
  .cal-widget {
    --cal-bg: #ffffff;
    --cal-border: #e8e8e8;
    --cal-text: #2c2c2c;
    --cal-muted: #9a9a9a;
    --cal-today-bg: #1a3a5c;
    --cal-today-text: #ffffff;
    --cal-header-bg: #fafafa;
    --cal-nav-hover: #f0f4f8;
    --cal-event-1-bg: #dbeafe;
    --cal-event-1-border: #3b82f6;
    --cal-event-1-text: #1e40af;
    --cal-event-2-bg: #d1fae5;
    --cal-event-2-border: #10b981;
    --cal-event-2-text: #065f46;
    --cal-event-3-bg: #e0f2fe;
    --cal-event-3-border: #0ea5e9;
    --cal-event-3-text: #0c4a6e;
    --cal-event-dark-bg: #1a3a5c;
    --cal-event-dark-text: #ffffff;
    --cal-font: 'DM Sans', 'Segoe UI', sans-serif;
 
    font-family: var(--cal-font);
    background: var(--cal-bg);
    border: 1px solid var(--cal-border);
    border-radius: 12px;
    overflow: hidden;
    width: 100%;
    user-select: none;
  }
 
  /* Header */
  .cal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 20px;
    background: var(--cal-header-bg);
    border-bottom: 1px solid var(--cal-border);
  }
 
  .cal-title {
    font-size: 15px;
    font-weight: 600;
    color: var(--cal-text);
    letter-spacing: -0.02em;
  }
 
  .cal-nav {
    display: flex;
    align-items: center;
    gap: 4px;
  }
 
  .cal-nav-btn {
    background: none;
    border: 1px solid var(--cal-border);
    border-radius: 6px;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    color: var(--cal-muted);
    transition: background 0.15s, color 0.15s;
    font-size: 13px;
  }
 
  .cal-nav-btn:hover {
    background: var(--cal-nav-hover);
    color: var(--cal-text);
  }
 
  .cal-today-btn {
    background: none;
    border: 1px solid var(--cal-border);
    border-radius: 6px;
    padding: 0 12px;
    height: 30px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 500;
    color: var(--cal-text);
    font-family: var(--cal-font);
    transition: background 0.15s;
    margin-right: 6px;
  }
 
  .cal-today-btn:hover {
    background: var(--cal-nav-hover);
  }
 
  /* Day labels */
  .cal-days-header {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    border-bottom: 1px solid var(--cal-border);
    background: var(--cal-header-bg);
  }
 
  .cal-day-label {
    padding: 8px 10px;
    font-size: 11px;
    font-weight: 600;
    color: var(--cal-muted);
    letter-spacing: 0.06em;
    text-transform: uppercase;
    text-align: left;
  }
 
  /* Grid */
  .cal-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    grid-auto-rows: minmax(90px, auto);
  }
 
  .cal-cell {
    border-right: 1px solid var(--cal-border);
    border-bottom: 1px solid var(--cal-border);
    padding: 8px 10px 6px;
    min-height: 90px;
    box-sizing: border-box;
    transition: background 0.1s;
    cursor: default;
    position: relative;
  }
 
  .cal-cell:nth-child(7n) {
    border-right: none;
  }
 
  .cal-cell.other-month {
    background: #f7f7f5;
  }
 
  .cal-cell.other-month .cal-date-num {
    color: #c8c8c8;
  }
 
  .cal-cell:hover {
    background: #f8fafc;
  }
 
  .cal-date-num {
    font-size: 12px;
    font-weight: 500;
    color: var(--cal-muted);
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    margin-bottom: 4px;
    line-height: 1;
  }
 
  .cal-cell.today .cal-date-num {
    background: var(--cal-today-bg);
    color: var(--cal-today-text);
    font-weight: 700;
  }
 
  /* Events */
  .cal-events {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
 
  .cal-event {
    font-size: 11px;
    font-weight: 500;
    padding: 2px 6px;
    border-radius: 3px;
    border-left: 3px solid;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    cursor: pointer;
    transition: opacity 0.15s;
  }
 
  .cal-event:hover {
    opacity: 0.82;
  }
 
  .cal-event.type-blue {
    background: var(--cal-event-1-bg);
    border-color: var(--cal-event-1-border);
    color: var(--cal-event-1-text);
  }
 
  .cal-event.type-green {
    background: var(--cal-event-2-bg);
    border-color: var(--cal-event-2-border);
    color: var(--cal-event-2-text);
  }
 
  .cal-event.type-sky {
    background: var(--cal-event-3-bg);
    border-color: var(--cal-event-3-border);
    color: var(--cal-event-3-text);
  }
 
  .cal-event.type-dark {
    background: var(--cal-event-dark-bg);
    border-color: var(--cal-event-dark-bg);
    color: var(--cal-event-dark-text);
    border-left-color: #3a6ea5;
  }
 
  /* Tooltip */
  .cal-tooltip {
    position: fixed;
    background: #1a1a1a;
    color: #fff;
    font-size: 12px;
    padding: 6px 10px;
    border-radius: 6px;
    pointer-events: none;
    z-index: 9999;
    white-space: nowrap;
    opacity: 0;
    transition: opacity 0.15s;
    font-family: var(--cal-font);
  }
  .cal-tooltip.visible {
    opacity: 1;
  }
</style>
<style>
  .table-wrapper {
    max-height: 405px;
    overflow-y: auto;
    overflow-x: hidden;
    border: 1px solid #eee;
    }

    /* Sticky Header */
    .table-header th {
        position: sticky;
        top: 0;
        z-index: 5;
        background: #F2DFDE !important;
        color: white;
        padding-top: 10px;
        padding-bottom: 10px;
    }
</style>
<style>
    /* ===== Global scrollbar styling ===== */

    /* Works on Chrome, Edge, Safari */
    * {
    scrollbar-width: thin; /* Firefox */
    scrollbar-color: #9aa0a6 #fff; /* thumb | track */
    }

    /* WebKit browsers */
    *::-webkit-scrollbar {
    width: 6px;   /* thin vertical scrollbar */
    height: 6px;  /* thin horizontal scrollbar */
    }

    *::-webkit-scrollbar-track {
    background: #f1f3f4; /* light neutral track */
    border-radius: 10px;
    }

    *::-webkit-scrollbar-thumb {
    background-color: #9aa0a6; /* soft gray thumb */
    border-radius: 10px;
    border: 2px solid #f1f3f4; /* creates padding effect */
    }

    *::-webkit-scrollbar-thumb:hover {
    background-color: #6b7280; /* darker on hover */
    }
</style>

<div class="row g-3">
    <div class="col-lg-3">
        <div class="card rounded-0 p-3" style="box-shadow: none; background:#E3F2FD; border-left:2px solid #1E88E5">
            <div class="d-flex align-items-center justify-content-between gap-2">
                <div class="d-flex flex-column">
                    <label class="fs-7 fw-semibold text-dark">Annual Commitment</label>
                    <label class="fs-1 fw-semibold text-black">&#8377; 7,56,000</label>
                </div>
                <label>
                    <span class="badge  rounded-circle" style="background:#E3F2FD; color:#1E88E5;">
                        <i class="mdi mdi-cash-multiple fs-1"></i>
                    </span>
                </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card rounded-0 p-3" style="box-shadow: none; background:#F3E5F5; border-left:2px solid #6A1B9A">
            <div class="d-flex align-items-center justify-content-between gap-2">
                <div class="d-flex flex-column">
                    <label class="fs-7 fw-semibold text-dark">Monthly RD Allocation</label>
                    <label class="fs-1 fw-semibold text-black">&#8377; 54,300</label>
                </div>
                <label>
                    <span class="badge  rounded-circle" style="color:#6A1B9A;">
                        <i class="mdi mdi-calendar-today fs-1"></i>
                    </span>
                </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card rounded-0 p-3" style="box-shadow: none; background:#FDECEA; border-left:2px solid #C62828">
            <div class="d-flex align-items-center justify-content-between gap-2">
                <div class="d-flex flex-column">
                    <label class="fs-7 fw-semibold text-dark">Renewals Next 30D</label>
                    <label class="fs-1 fw-semibold text-black">08</label>
                </div>
                <label>
                    <span class="badge  rounded-circle" style="color:#C62828;">
                        <i class="mdi mdi-calendar-month fs-1"></i>
                    </span>
                </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card rounded-0 p-3" style="box-shadow: none; background:#E8F5E9; border-left:2px solid #2E7D32">
            <div class="d-flex align-items-center justify-content-between gap-2">
                <div class="d-flex flex-column">
                    <label class="fs-7 fw-semibold text-dark">Contracts On-Time %</label>
                    <label class="fs-1 fw-semibold text-black">94.8</label>
                </div>
                <label>
                    <span class="badge  rounded-circle" style="color:#2E7D32;">
                        <i class="mdi mdi-percent-circle fs-1"></i>
                    </span>
                </label>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card p-3 border" style="box-shadow: none; background:#F8F9FA;">
            <div class="row g-4">
                <div class="col-lg-12 border-bottom ">
                    <div class="pb-3 d-flex flex-column">
                        <label class="fs-7 fw-semibold text-dark">Portfolio By Module</label>
                        <small>Annual Commitment . FY 26</small>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="d-flex flex-column gap-2">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                    ISAMM
                                </label>
                                <label class="text-black fs-6 fw-semibold ">Insurance & AMC</label>
                                <small>13 records</small>
                            </div>
                            <div class="d-flex aling-items-center gap-2 ">
                                 <small class="badge bg-label-danger fw-semibold text-black" >&#8377; 4,81,000</small>
                                 <small class="badge bg-label-primary fw-semibold text-black">3 in 30d</small>
                            </div>
                        </div>
                        <div class="progress " style="background:#E3F2FD; ">
                            <div class="progress-bar " role="progressbar" style="width: 25%; color:#6469dd;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="d-flex flex-column gap-2">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <label class="fs-8 badge rounded px-2 py-2 bg-label-success" >
                                    SMM
                                </label>
                                <label class="text-black fs-6 fw-semibold ">Subsriptions & Memberships</label>
                                <small>10 records</small>
                            </div>
                            <div class="d-flex aling-items-center gap-2 ">
                                 <small class="badge bg-label-danger fw-semibold text-black" >&#8377; 2,75,000</small>
                                 <small class="badge bg-label-primary fw-semibold text-black">3 in 30d</small>
                            </div>
                        </div>
                        <div class="progress bg-label-success " style="" >
                            <div class="progress-bar bg-success" role="progressbar" style="width: 60%; color:#639562;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 pb-3">
                    <div class="d-flex flex-column gap-2">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <label class="fs-8 badge rounded px-2 py-2 bg-label-info" >
                                    YERD
                                </label>
                                <label class="text-black fs-6 fw-semibold ">Yearly RD Plans</label>
                                <small>7 records</small>
                            </div>
                            <div class="d-flex aling-items-center gap-2 ">
                                 <small class="badge bg-label-danger fw-semibold text-black" >&#8377; 6,51,000</small>
                                 <small class="badge bg-label-primary fw-semibold text-black">2 in 30d</small>
                            </div>
                        </div>
                        <div class="progress bg-label-info ">
                            <div class="progress-bar bg-info" role="progressbar" style="width: 44%; color:#56a8c3;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card rounded p-3 border" style="box-shadow: none; background:#F8F9FA; height:307px;">
            <div class="row g-4">
                <div class="col-lg-12 border-bottom ">
                    <div class="pb-3 d-flex flex-column">
                        <label class="fs-7 fw-semibold text-dark">Category Mix</label>
                        <small>Share Of Annual Spend</small>
                    </div>
                </div>
                <div class="col-lg-4 ">
                    <div class="position-relative progress-circle" style="width:200px; height:200px;">
                        <svg width="200" height="200" viewBox="0 0 100 100" class="multi-donut">
                            <circle cx="50" cy="50" r="40" fill="none" stroke="#e9ecef" stroke-width="10"/>
                        </svg>
                        <div class="position-absolute top-50 start-50 translate-middle text-center">
                            <label class="text-black fw-semibold fs-5">&#8377; 7,56,000</label>
                            <small class="d-block text-muted">FY 26 Annual</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 d-flex align-items-center justify-content-between " >
                    <div class="row g-3 "   style="width:100%; ">
                        <div class="col-lg-12 d-flex aling-items-center justify-content-between " style="width:100%;">
                            <div class="d-flex align-items-center gap-2">
                                <span class="p-2 " style="width:4px; height:4px; background:#1D9E75;"></span>
                                <label class="text-black fs-6 fw-semibold ">Insurance</label>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <label class="text-black fs-6 fw-semibold ">₹ 4,29,000</label>
                                <label class="text-muted fs-6 fw-semibold ">|</label>
                                <label class="text-muted fs-6 fw-semibold ">57%</label>
                            </div>
                        </div>
                        <div class="col-lg-12 d-flex aling-items-center justify-content-between " style="width:100%;">
                            <div class="d-flex align-items-center gap-2">
                                <span class="p-2 " style="width:4px; height:4px; background:#378ADD;"></span>
                                <label class="text-black fs-6 fw-semibold ">AMC</label>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <label class="text-black fs-6 fw-semibold ">₹ 51,4,000</label>
                                <label class="text-muted fs-6 fw-semibold ">|</label>
                                <label class="text-muted fs-6 fw-semibold ">7%</label>
                            </div>
                        </div>
                        <div class="col-lg-12 d-flex aling-items-center justify-content-between " style="width:100%;">
                            <div class="d-flex align-items-center gap-2">
                                <span class="p-2 " style="width:4px; height:4px; background:#EF9F27;"></span>
                                <label class="text-black fs-6 fw-semibold ">SaaS Subs</label>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <label class="text-black fs-6 fw-semibold ">₹ 2,53,000</label>
                                <label class="text-muted fs-6 fw-semibold ">|</label>
                                <label class="text-muted fs-6 fw-semibold ">33%</label>
                            </div>
                        </div>
                        <div class="col-lg-12 d-flex aling-items-center justify-content-between" style="width:100%;">
                            <div class="d-flex align-items-center gap-2">
                                <span class="p-2 " style="width:4px; height:4px; background:#D4537E;"></span>
                                <label class="text-black fs-6 fw-semibold ">Memberships</label>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <label class="text-black fs-6 fw-semibold ">₹ 22,2,000</label>
                                <label class="text-muted fs-6 fw-semibold ">|</label>
                                <label class="text-muted fs-6 fw-semibold ">3%</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="row g-3">
            <div class="col-lg-12">
                <div class="card p-3 border" style="box-shadow: none; background:#F8F9FA;">
                    <div class="row g-3">
                        <div class="col-lg-12 border-bottom ">
                            <div class="pb-3 d-flex flex-column">
                                <label class="fs-7 fw-semibold text-dark">RD Accumulation Health</label>
                                <small>Virtual Recurring Deposits . FY26</small>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="d-flex flex-column gap-2">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex flex-column">
                                        <small>Accumulated Vs Target</small>
                                        <label class="fs-7 fw-semibold text-black">₹ 4.88,000</label>
                                    </div>
                                    <label class="fs-5 fw-semibold text-black">75.0 %</label>
                                </div>
                                 <div class="progress bg-label-primary" >
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 ">
                            <div class="row">
                                <div class="col-lg-9 ">
                                    <div class="d-flex align-items-center gap-4">
                                        <div class="d-flex flex-column">
                                            <small >Active Accounts</small>
                                            <label class="fs-7 fw-semibold text-black" >07</label>
                                        </div>
                                        <div>|</div>
                                        <div class="d-flex flex-column">
                                            <small >Shortfalls</small>
                                            <label class="fs-7 fw-semibold text-black" >01</label>
                                        </div>
                                        <div>|</div>
                                        <div class="d-flex flex-column">
                                            <small >This Month</small>
                                            <label class="fs-7 fw-semibold text-black" >₹ 54,7000</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 d-flex align-items-center justify-content-center">
                                    <small class="badge bg-label-primary fw-semibold text-black">Action Required</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card p-3 border" style="box-shadow: none; background:#F8F9FA;">
                    <div class="row ">
                        <div class="col-lg-12 border-bottom ">
                            <div class="pb-3 d-flex flex-column">
                                <label class="fs-7 fw-semibold text-dark">Recent Activity</label>
                                <small>Annual Commitment . FY 26</small>
                            </div>
                        </div>

                        <div class="col-lg-12">
                            <div class="row scroll-y" style="max-height:200px;">
                                <div class="col-lg-12 py-2 border-bottom">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center gap-2">
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                    ISAMM
                                                </label>
                                                <label class="text-black fs-6 fw-semibold ">Insurance & AMC</label>
                                            </div>
                                            <div class="d-flex aling-items-center gap-2 ">
                                                <small class=" fw-semibold ">1d ago</small>
                                            </div>
                                        </div>
                                        <small class=" fw-semibold ">Uploaded Renewed Policy Document INS-0477 Group Medical</small>
                                    </div>
                                </div>
                                <div class="col-lg-12 py-2 border-bottom">
                                    <div class="d-flex flex-column ">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center gap-2">
                                                <label class="fs-8 badge rounded px-2 py-2 bg-label-info">
                                                    YERD
                                                </label>
                                                <label class="text-black fs-6 fw-semibold ">System</label>
                                            </div>
                                            <div class="d-flex aling-items-center gap-2 ">
                                                <small class=" fw-semibold ">1d ago</small>
                                            </div>
                                        </div>
                                        <small class=" fw-semibold ">Generated Apirl Contribution Tasks For 7 RD account</small>
                                    </div>
                                </div>
                                <div class="col-lg-12 py-2 border-bottom">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center gap-2">
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                    ISAMM
                                                </label>
                                                <label class="text-black fs-6 fw-semibold">Insurance & AMC</label>
                                            </div>
                                            <div class="d-flex aling-items-center gap-2">
                                                <small class="fw-semibold">1d ago</small>
                                            </div>
                                        </div>
                                        <small class="fw-semibold">
                                            Uploaded Renewed Policy Document INS-0477 Group Medical
                                        </small>
                                    </div>
                                </div>
                                <div class="col-lg-12 py-2 border-bottom">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center gap-2">
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                    YERD
                                                </label>
                                                <label class="text-black fs-6 fw-semibold">System</label>
                                            </div>
                                            <div class="d-flex aling-items-center gap-2">
                                                <small class="fw-semibold">1d ago</small>
                                            </div>
                                        </div>
                                        <small class="fw-semibold">
                                            Generated April Contribution Tasks for 7 RD accounts
                                        </small>
                                    </div>
                                </div>
                                <div class="col-lg-12 py-2 border-bottom">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center gap-2">
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#FFF3E0; color:#EF6C00;">
                                                    AMC
                                                </label>
                                                <label class="text-black fs-6 fw-semibold">Maintenance</label>
                                            </div>
                                            <div class="d-flex aling-items-center gap-2">
                                                <small class="fw-semibold">2d ago</small>
                                            </div>
                                        </div>
                                        <small class="fw-semibold">
                                            Scheduled quarterly inspection for Passenger Lift at Tower B
                                        </small>
                                    </div>
                                </div>
                                <div class="col-lg-12 py-2 border-bottom">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center gap-2">
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#F3E5F5; color:#6A1B9A;">
                                                    ALERT
                                                </label>
                                                <label class="text-black fs-6 fw-semibold">Notification</label>
                                            </div>
                                            <div class="d-flex aling-items-center gap-2">
                                                <small class="fw-semibold">3d ago</small>
                                            </div>
                                        </div>
                                        <small class="fw-semibold">
                                            Policy INS-0482 is nearing renewal deadline within 5 days
                                        </small>
                                    </div>
                                </div>
                                <div class="col-lg-12 py-2">
                                    <div class="d-flex flex-column ">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center gap-2">
                                                <label class="fs-8 badge rounded px-2 py-2 bg-label-success">
                                                    SMM
                                                </label>
                                                <label class="text-black fs-6 fw-semibold ">S. Chen</label>
                                            </div>
                                            <div class="d-flex aling-items-center gap-2 ">
                                                <small class=" fw-semibold ">1d ago</small>
                                            </div>
                                        </div>
                                        <small class=" fw-semibold ">Initiated renewal for SUB-101 Alas Work Suite</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card p-3 border" style="box-shadow: none; background:#F8F9FA;">
            <div class="row ">
                <div class="col-lg-12 border-bottom ">
                    <div class="pb-3 d-flex flex-column">
                        <label class="fs-7 fw-semibold text-dark">Upcoming Renewal & Payments</label>
                        <small>Across All Modules</small>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="table-wrapper mt-4">
                            <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                                <thead class="table-header">
                                    <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px text-primary">Due</th>
                                        <th class="min-w-100px text-primary">Item</th>
                                        <th class="min-w-100px text-primary">Module</th>
                                        <th class="min-w-100px text-primary text-center">Amount</th>
                                        <th class="min-w-50px text-primary">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="table-body text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <label class="text-nowrap">24-Apr-2026</label>
                                            <label class="d-block text-danger">In 3D</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Granite Security Cloud</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">SUB-07.4 .Subscription Renewal</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                ISAMM
                                            </label>
                                        </td>
                                        <td>
                                            <label class="text-black fs-6 fw-semibold text-nowrap">₹ 22,2,000</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Action Required
                                            </label>
                                        </td>
                                        
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-nowrap">26-Apr-2026</label>
                                            <label class="d-block text-danger">In 5D</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">CloudTech Backup Services</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">SUB-09.1 Subscription Renewal</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                ISAMM
                                            </label>
                                        </td>
                                        <td>
                                            <label class="text-black fs-6 fw-semibold text-nowrap">₹ 18,50,000</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#FDEBD2; color:#C47A1B;">
                                                Action Required
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-nowrap">28-Apr-2026</label>
                                            <label class="d-block text-danger">In 7D</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Nova ERP Licensing</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">SUB-11.2 Software Renewal</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                ERP
                                            </label>
                                        </td>
                                        <td>
                                            <label class="text-black fs-6 fw-semibold text-nowrap">₹ 32,75,000</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#FFF3E0; color:#EF6C00;">
                                                Pending Review
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-nowrap">30-Apr-2026</label>
                                            <label class="d-block text-danger">In 9D</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">SecureNet Firewall Subscription</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">SUB-14.3 Security Renewal</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#F3E5F5; color:#6A1B9A;">
                                                SECURITY
                                            </label>
                                        </td>
                                        <td>
                                            <label class="text-black fs-6 fw-semibold text-nowrap">₹ 14,80,000</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                Scheduled
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-nowrap">02-May-2026</label>
                                            <label class="d-block text-danger">In 11D</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Oracle Database License</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">SUB-18.0 Enterprise Renewal</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                DATABASE
                                            </label>
                                        </td>
                                        <td>
                                            <label class="text-black fs-6 fw-semibold text-nowrap">₹ 55,00,000</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#FDECEA; color:#C62828;">
                                                High Priority
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-nowrap">05-May-2026</label>
                                            <label class="d-block text-danger">In 14D</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Microsoft 365 Enterprise</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">SUB-21.5 Cloud Subscription</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                CLOUD
                                            </label>
                                        </td>
                                        <td>
                                            <label class="text-black fs-6 fw-semibold text-nowrap">₹ 41,20,000</label>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                Renewal Due
                                            </label>
                                        </td>
                                    </tr>                                    
                                </tbody>
                            </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="cal-widget" id="calWidget">
        <div class="cal-header">
            <div class="d-flex align-items-center gap-2">
                <label class="fs-6 fw-semibold text-dark">Renewal Calendar</label>
                <span class="cal-title" id="calTitle">April 2026</span>
            </div>
            
            <div class="cal-nav">
            <button class="cal-today-btn" id="calTodayBtn">Today</button>
            <button class="cal-nav-btn" id="calPrevBtn">&#8249;</button>
            <button class="cal-nav-btn" id="calNextBtn">&#8250;</button>
            </div>
        </div>
        <div class="cal-days-header">
            <div class="cal-day-label">Sun</div>
            <div class="cal-day-label">Mon</div>
            <div class="cal-day-label">Tue</div>
            <div class="cal-day-label">Wed</div>
            <div class="cal-day-label">Thu</div>
            <div class="cal-day-label">Fri</div>
            <div class="cal-day-label">Sat</div>
        </div>
        <div class="cal-grid" id="calGrid"></div>
        </div>
        <div class="cal-tooltip" id="calTooltip"></div>
    </div>
</div>

<script>
  /* =====================
     CALENDAR COMPONENT JS
  ===================== */
  (function () {
    // ---- EVENT DATA ----
    // Format: { date: 'YYYY-MM-DD', label: 'Event Name', type: 'blue|green|sky|dark' }
    const calEvents = [
      { date: '2026-03-11', label: 'Plant & Machinery — Site B', type: 'blue' },
      { date: '2026-03-24', label: 'Granite Security Cloud', type: 'sky' },
      { date: '2026-03-27', label: 'UPS — Server Room AMC', type: 'blue' },
      { date: '2026-03-30', label: 'Global Fleet Vehicle Policy', type: 'dark' },
      { date: '2026-03-30', label: 'Fleet Vehicle Policy Renewal', type: 'green' },
      { date: '2026-04-05', label: 'Industry Standards Body', type: 'sky' },
      { date: '2026-04-09', label: 'Atlas Work Suite', type: 'blue' },
      { date: '2026-04-09', label: 'Atlas Work Suite Renewal', type: 'green' },
    ];
 
    let currentYear, currentMonth;
 
    function init() {
      const today = new Date();
      currentYear = today.getFullYear();
      currentMonth = today.getMonth();
      render();
    }
 
    function getEventsForDate(y, m, d) {
      const key = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      return calEvents.filter(e => e.date === key);
    }
 
    function render() {
      const grid = document.getElementById('calGrid');
      const title = document.getElementById('calTitle');
      const today = new Date();
 
      const monthNames = ['January','February','March','April','May','June',
                          'July','August','September','October','November','December'];
      title.textContent = `${monthNames[currentMonth]} ${currentYear}`;
 
      grid.innerHTML = '';
 
      const firstDay = new Date(currentYear, currentMonth, 1).getDay();
      const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
      const daysInPrev = new Date(currentYear, currentMonth, 0).getDate();
 
      // Prev month tail
      for (let i = firstDay - 1; i >= 0; i--) {
        const d = daysInPrev - i;
        const prevM = currentMonth === 0 ? 11 : currentMonth - 1;
        const prevY = currentMonth === 0 ? currentYear - 1 : currentYear;
        grid.appendChild(makeCell(d, prevY, prevM, true));
      }
 
      // Current month
      for (let d = 1; d <= daysInMonth; d++) {
        const isToday = d === today.getDate() &&
                        currentMonth === today.getMonth() &&
                        currentYear === today.getFullYear();
        grid.appendChild(makeCell(d, currentYear, currentMonth, false, isToday));
      }
 
      // Next month fill
      const totalCells = firstDay + daysInMonth;
      const remaining = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
      for (let d = 1; d <= remaining; d++) {
        const nextM = currentMonth === 11 ? 0 : currentMonth + 1;
        const nextY = currentMonth === 11 ? currentYear + 1 : currentYear;
        grid.appendChild(makeCell(d, nextY, nextM, true));
      }
    }
 
    function makeCell(day, year, month, otherMonth, isToday) {
      const cell = document.createElement('div');
      cell.className = 'cal-cell' +
                       (otherMonth ? ' other-month' : '') +
                       (isToday ? ' today' : '');
 
      const num = document.createElement('div');
      num.className = 'cal-date-num';
      num.textContent = day;
      cell.appendChild(num);
 
      const events = getEventsForDate(year, month, day);
      if (events.length) {
        const evContainer = document.createElement('div');
        evContainer.className = 'cal-events';
        events.forEach(ev => {
          const evEl = document.createElement('div');
          evEl.className = `cal-event type-${ev.type}`;
          evEl.textContent = ev.label;
          evEl.addEventListener('mouseenter', e => showTooltip(e, ev.label));
          evEl.addEventListener('mouseleave', hideTooltip);
          evEl.addEventListener('mousemove', moveTooltip);
          evContainer.appendChild(evEl);
        });
        cell.appendChild(evContainer);
      }
 
      return cell;
    }
 
    // Tooltip
    const tooltip = document.getElementById('calTooltip');
    function showTooltip(e, text) {
      tooltip.textContent = text;
      tooltip.classList.add('visible');
      moveTooltip(e);
    }
    function moveTooltip(e) {
      tooltip.style.left = (e.clientX + 12) + 'px';
      tooltip.style.top = (e.clientY - 28) + 'px';
    }
    function hideTooltip() {
      tooltip.classList.remove('visible');
    }
 
    // Navigation
    document.getElementById('calPrevBtn').addEventListener('click', () => {
      currentMonth--;
      if (currentMonth < 0) { currentMonth = 11; currentYear--; }
      render();
    });
    document.getElementById('calNextBtn').addEventListener('click', () => {
      currentMonth++;
      if (currentMonth > 11) { currentMonth = 0; currentYear++; }
      render();
    });
    document.getElementById('calTodayBtn').addEventListener('click', () => {
      const t = new Date();
      currentYear = t.getFullYear();
      currentMonth = t.getMonth();
      render();
    });
 
    init();
  })();
</script>
<script>
    document.addEventListener('DOMContentLoaded', () => {

    const segments = [
        { label: 'Spent',     percent: 57, color: '#1D9E75' },
        { label: 'Tax',       percent: 7, color: '#378ADD' },
        { label: 'Savings',   percent: 33, color: '#EF9F27' },
        { label: 'Remaining', percent: 3, color: '#D4537E' },
    ];

    document.querySelectorAll('.multi-donut').forEach(svg => {
        const r = 40;
        const cx = 50, cy = 50;
        const circumference = 2 * Math.PI * r;
        const gapDeg = 3;           // degrees of gap between segments
        const gapFrac = gapDeg / 360;
        const scale = 1 - (gapFrac * segments.length);

        let angleDeg = -90;         // start from top

        segments.forEach(seg => {
            const arcFrac = (seg.percent / 100) * scale;
            const arcDeg  = arcFrac * 360;
            const dashLen = arcFrac * circumference;

            const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('cx', cx);
            circle.setAttribute('cy', cy);
            circle.setAttribute('r', r);
            circle.setAttribute('fill', 'none');
            circle.setAttribute('stroke', seg.color);
            circle.setAttribute('stroke-width', '10');
            circle.setAttribute('stroke-linecap', 'round');
            // dasharray: arc length  +  rest of circumference (hidden)
            circle.setAttribute('stroke-dasharray', `${dashLen} ${circumference - dashLen}`);
            circle.setAttribute('transform', `rotate(${angleDeg} ${cx} ${cy})`);
            svg.appendChild(circle);

            angleDeg += arcDeg + gapFrac * 360;
        });
    });

});
</script>

@endsection
