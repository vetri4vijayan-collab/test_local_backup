# Policies & RD Accounts — source audit and implementation notes

## What the supplied source actually contained

| Area | Source finding | Work included |
|---|---|---|
| Executive Dashboard | View-only controller; Blade has hard-coded KPI values, portfolio mix and calendar examples | Live dashboard API/KPI panel added; decorative/legacy chart content remains and must be mapped before claiming every dashboard graphic is live |
| Manage Insurance & AMC | View-only controller; Blade has hard-coded policy/AMC rows and operational modal examples | Live insurance/AMC CRUD tables, contract payment ledger, claims, surrender, AMC maintenance, service reports and document endpoints |
| Renewal Calendar | View-only controller; table/calendar contains demo renewals | Renewal records sync from source records; paginated renewal table and mark-processed action |
| Manage Subscriptions | View-only controller; subscription, membership and payment examples are static | Subscription CRUD, membership-type rendering, payment ledger, renewal sync and encrypted secret storage |
| Manage RD | View-only controller; static RD examples and closing modal | RD CRUD, installment generation, payment allocation, immutable payment ledger, reversal and closure |
| Dropdown masters | Bookmarks controller shows add/edit/archive category management | Master list/add/edit/archive endpoints and Manage buttons for provider/category/frequency/subscription type/RD bank/claim/maintenance type |
| Loading and pagination | Staff List uses shimmer skeleton rows, fetch, pagination and Select2 | New list script uses skeleton rows, API pagination and Select2; it does not copy unrelated staff filters |
| Entity scope | `User::staff()` relates the authenticated user to `egc_staff`; navbar workspace switcher reads `Auth::user()->staff->entity_id` | Service scopes every query using linked staff `company_id` and `entity_id`; request payload cannot override tenant IDs |
| Permissions | `User::hasPermission()` supports menu/submenu/lastmenu | API and page controllers check exact Corporate Admin > Policies & RD Accounts submenu labels |

## Existing ERP finance modules

The source slice includes models for:
- `egc_finc_daily_account`
- `egc_acc_common_expenditure`
- `egc_acct_payment_type`
- `egc_acct_payment_mode`
- `egc_tool_manage_spent_category`

It does not include the posting controller/service or migrations/schema for these tables. The new module therefore does not write to those tables. It stores its own contract, subscription and RD payment ledgers with idempotency and audit records. Before automatic posting is enabled, finance owners must specify the debit/credit account mapping, category/payment type/payment mode IDs, voucher reference format, settlement direction, reversal workflow and reconciliation requirements.

## Implementation scope / remaining integration work

The live module panel is wired into the five existing pages and updates the main data tables identified in the original markup. It also intercepts the original Add Policy/Add AMC/Add Subscription/Add RD triggers to use the dynamic forms.

Some original presentation-only dashboard values, dashboard portfolio charts/calendar event samples and older offcanvas detail fragments remain in the source Blade files. They are not the authoritative data entry path after this integration, but they have not all been converted to live widgets. If the acceptance criterion is literally zero static/demo content in every panel, those remaining visual blocks require a second page-specific pass rather than being silently represented as complete.

RD interest and maturity are deliberately bank-confirmed. The source contains no bank-specific compounding/day-count/tax/penalty rules. The system generates the principal installment schedule and stores the bank's quoted maturity/closure values; it does not invent a maturity-interest formula.

## Validation performed

- PHP syntax lint: all new PHP models/services/controllers/requests/resources and the updated full `routes/web.php`.
- JavaScript syntax check: `node --check` on the new frontend script.
- No Laravel boot, `route:list`, database migration execution, browser test or production accounting reconciliation was possible because the supplied ZIP is a source slice without `composer.json`, bootstrap/config, vendor, migrations or database schema. The package must pass the included staging QA checklist before production deployment.
