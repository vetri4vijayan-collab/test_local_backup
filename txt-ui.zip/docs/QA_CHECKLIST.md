# Staging QA checklist

## Setup and access
- [ ] Run SQL on a restored staging database; verify all 16 `egc_policy_*` tables.
- [ ] Confirm authenticated `Auth::user()->staff` has correct company/entity after switching ERP workspace.
- [ ] Test each submenu permission separately and verify 403 for unauthorized API calls.
- [ ] Confirm one entity cannot list, show, update, archive, upload or download another entity's records.

## Dynamic CRUD
- [ ] Create/edit/archive insurance policies and AMC contracts.
- [ ] Create/edit/archive subscriptions and membership-type subscriptions.
- [ ] Create/edit/archive RD accounts; account number and subscription secret must not appear in JSON responses or logs.
- [ ] Add/edit/archive each master type; verify duplicate master names are rejected.
- [ ] Search and paginate every list; test empty results and API errors.
- [ ] Verify skeleton rows appear while each list reloads and are removed after success/failure.

## Financial flows
- [ ] Record contract premium/AMC payments; retry same idempotency key and verify no duplicate.
- [ ] Record subscription payments; verify ledger totals and references.
- [ ] Record RD full and partial installment payments; verify principal and installment balance.
- [ ] Attempt an RD overpayment and verify 422 with no database changes.
- [ ] Reverse an RD deposit; verify a reversal ledger row, original row unchanged, totals restored, and second reversal rejected.
- [ ] Close RD account; verify status is closed and no further deposits are accepted.
- [ ] Verify all amounts remain exact to two decimals for high values and fractional values.
- [ ] Verify surrender/closure penalties greater than quoted proceeds are rejected.
- [ ] Compare RD maturity and premature closure amounts to the bank statement; no automatic interest is claimed.

## Operational workflows
- [ ] Create/update insurance claims; test approved amount <= claimed amount and settled amount <= approved amount.
- [ ] Schedule AMC maintenance and create service reports; verify maintenance completion updates.
- [ ] Upload/download PDF/image/Office documents; verify entity isolation and max size/type restrictions.
- [ ] Process renewals and verify the dashboard counts due/overdue renewals.
- [ ] Verify renewal sync after changing policy/AMC/subscription/RD maturity dates.

## Integration and browser
- [ ] Verify no existing ERP module or route behavior changed.
- [ ] Verify Select2 dropdowns and Manage Master modals on desktop/mobile.
- [ ] Verify browser console has no JS errors.
- [ ] Reconcile contract/subscription/RD payment ledgers against source documents.
- [ ] Do not enable Accounts & Finance posting until category, payment type, payment mode, voucher and reversal mapping is approved.
