(function () {
  'use strict';
  const root = document.getElementById('policies-live-root');
  if (!root) return;
  const moduleName = root.dataset.module;
  const api = '/policies-data';
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
  const state = { page: 1, perPage: 25, search: '', rows: [], masterType: 'provider' };
  const $ = (sel, ctx=document) => ctx.querySelector(sel);
  const $$ = (sel, ctx=document) => [...ctx.querySelectorAll(sel)];
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const newIdempotencyKey = () => window.crypto?.randomUUID ? window.crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.random()*16|0;return (c==='x'?r:(r&3|8)).toString(16)});
  const money = v => {const raw=String(v??'0').replace(/,/g,'');const neg=raw.startsWith('-');const clean=neg?raw.slice(1):raw;const [whole='0',fraction='']=clean.split('.');const grouped=whole.replace(/\B(?=(\d{3})+(?!\d))/g,',');return '₹ '+(neg?'-':'')+grouped+'.'+fraction.padEnd(2,'0').slice(0,2);};
  const date = v => v ? new Date(v+'T00:00:00').toLocaleDateString('en-IN') : '—';
  const request = async (url, method='GET', body=null, isForm=false) => {
    const opts={method,headers:{'X-Requested-With':'XMLHttpRequest','X-CSRF-TOKEN':csrf,'Accept':'application/json'}};
    if(body){ if(isForm) opts.body=body; else {opts.headers['Content-Type']='application/json';opts.body=JSON.stringify(body);} }
    const res=await fetch(url,opts); const json=await res.json().catch(()=>({message:'Unexpected server response'}));
    if(!res.ok) throw new Error(json.message || Object.values(json.errors||{}).flat().join('\n') || 'Request failed');
    return json;
  };
  const modal = (id,title,body,footer='') => {
    let el=document.getElementById(id);
    if(!el){ el=document.createElement('div');el.id=id;el.className='modal fade';el.tabIndex=-1;document.body.appendChild(el); }
    el.innerHTML=`<div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${esc(title)}</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">${body}</div>${footer?`<div class="modal-footer">${footer}</div>`:''}</div></div>`;
    bootstrap.Modal.getOrCreateInstance(el).show(); return el;
  };
  const fields = {
    insurance:[
      ['title','Policy Name','text',true],['reference_number','Policy ID / Reference','text'],['policy_number','Policy Number','text'],
      ['provider_name','Provider','master:provider',true],['category','Category','master:category'],['owner_name','Owner','text'],
      ['start_date','Start Date','date'],['end_date','Expiry Date','date',true],['next_due_date','Next Due Date','date'],
      ['sum_insured','Sum Insured','number'],['premium_amount','Premium Amount','number'],['payment_frequency','Payment Frequency','master:payment_frequency'],['notes','Notes','textarea']
    ],
    amc:[
      ['title','Contract Name','text',true],['reference_number','Contract Reference','text'],['provider_name','Vendor','master:provider',true],
      ['category','Category','master:category'],['asset_name','Asset','text'],['start_date','Start Date','date'],['end_date','End Date','date',true],
      ['next_due_date','Next Service Date','date'],['contract_amount','Contract Amount','number'],['payment_frequency','Frequency','master:payment_frequency'],['notes','Notes','textarea']
    ],
    subscription:[
      ['subscription_name','Subscription Name','text',true],['provider_name','Provider','master:provider',true],['category','Category','master:category'],
      ['subscription_type','Type','master:subscription_type'],['tier','Tier','text'],['benefits','Benefits','textarea'],['contact_name','Contact Name','text'],['contact_email','Contact Email','email'],['start_date','Start Date','date'],['renewal_date','Renewal Date','date',true],
      ['billing_cycle','Billing Cycle','select:monthly,quarterly,half_yearly,yearly,one_time,custom',true],
      ['seat_count','Total Seats','number'],['used_seats','Used Seats','number'],['unit_cost','Cost / Seat','number'],
      ['annual_cost','Annual Cost','number',true],['currency','Currency (ISO)','text'],['credential_username','Login / Account','text'],
      ['credential_secret','Password / Secret','password'],['notes','Notes','textarea']
    ],
    rd:[
      ['account_name','Account Name','text',true],['bank_name','Bank','master:rd_bank',true],['account_number','Account Number','text',true],
      ['opening_date','Opening Date','date',true],['maturity_date','Maturity Date','date',true],['tenure_months','Tenure (months)','number',true],
      ['monthly_installment','Monthly Installment','number',true],['interest_rate_pa','Interest Rate (% p.a.)','number',true],
      ['interest_method','Interest Calculation','select:bank_confirmed',true],
      ['maturity_value','Bank-confirmed Maturity Value','number'],['interest_earned','Bank-confirmed Interest Earned','number'],['notes','Notes','textarea']
    ]
  };
  const moduleType = moduleName==='insurance-amc'?'insurance':moduleName;
  function fieldHtml(f, value='') {
    const [name,label,type,required]=f; const req=required?'required':'';
    if(type.startsWith('master:')) {
      const mt=type.split(':')[1];
      return `<div class="col-md-6"><label class="form-label">${esc(label)}${required?' *':''}</label><div class="input-group"><select class="select3 form-select" name="${name}" data-master-type="${mt}" ${req}><option value="">Select ${esc(label)}</option></select><button class="btn btn-outline-secondary" type="button" data-manage-master="${mt}">Manage</button></div></div>`;
    }
    if(type.startsWith('select:')) return `<div class="col-md-6"><label class="form-label">${esc(label)}${required?' *':''}</label><select class="select3 form-select" name="${name}" ${req}>${type.split(':')[1].split(',').map(x=>`<option value="${x}">${x.replaceAll('_',' ')}</option>`).join('')}</select></div>`;
    if(type==='textarea') return `<div class="col-12"><label class="form-label">${esc(label)}</label><textarea class="form-control" name="${name}" rows="2"></textarea></div>`;
    return `<div class="col-md-6"><label class="form-label">${esc(label)}${required?' *':''}</label><input class="form-control" name="${name}" type="${type}" ${type==='number'?'step="0.01" min="0"':''} value="${esc(value)}" ${req}></div>`;
  }
  function addShell() {
    root.innerHTML=`<div class="card border mb-3"><div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2"><div><h5 class="mb-0 text-black">Live ${moduleName==='insurance-amc'?'Insurance & AMC':moduleName==='rd'?'RD Accounts':moduleName==='subscription'?'Subscriptions':moduleName==='renewals'?'Renewal Calendar':'Executive Dashboard'}</h5><small class="text-muted">Live ERP records · company and entity scoped</small></div><div class="d-flex flex-wrap gap-2" id="policies-controls"><input id="policies-search" class="form-control form-control-sm" placeholder="Search records" style="max-width:220px"><select id="policies-perpage" class="form-select form-select-sm" style="width:90px"><option>10</option><option selected>25</option><option>50</option><option>100</option></select><button id="policies-refresh" class="btn btn-sm btn-outline-secondary">Refresh</button>${moduleName==='insurance-amc'?'<button id="policies-add" data-add-type="insurance" class="btn btn-sm btn-primary">Add Policy</button><button id="policies-add-amc" data-add-type="amc" class="btn btn-sm btn-outline-primary">Add AMC</button>':(['dashboard','renewals'].includes(moduleName)?'':`<button id="policies-add" class="btn btn-sm btn-primary">Add ${moduleName==='rd'?'RD Account':moduleName==='subscription'?'Subscription':'Record'}</button>`)}</div></div><div class="card-body" id="policies-live-body"><div class="text-center py-4"><span class="spinner-border spinner-border-sm"></span> Loading records…</div></div></div><style>
      .policies-skeleton{height:14px;border-radius:5px;background:#f3ece5;position:relative;overflow:hidden}
      .policies-skeleton:after{content:'';position:absolute;inset:0;transform:translateX(-100%);background:linear-gradient(90deg,transparent,rgba(255,255,255,.75),transparent);animation:policies-shimmer 1.25s infinite}
      @keyframes policies-shimmer{100%{transform:translateX(100%)}}
    </style>`;
    $('#policies-refresh').addEventListener('click',()=>load(1));
    $('#policies-search').addEventListener('keydown',e=>{if(e.key==='Enter'){state.search=e.target.value;load(1)}});
    $('#policies-perpage').addEventListener('change',e=>{state.perPage=+e.target.value;load(1)});
    $('#policies-add')?.addEventListener('click',()=>openForm(null,$('#policies-add').dataset.addType||null));
    $('#policies-add-amc')?.addEventListener('click',()=>openForm(null,'amc'));
    const legacyAdds = {
      '#kt_modal_add_policy':'insurance',
      '#kt_modal_add_amc':'amc',
      '#kt_modal_add_subscription':'subscription',
      '#kt_modal_add_yerd':'rd'
    };
    Object.entries(legacyAdds).forEach(([target,type])=>{
      $$(`[data-bs-target="${target}"]`).forEach(btn=>btn.addEventListener('click',e=>{
        e.preventDefault();e.stopPropagation();openForm(null,type);
      }));
    });
  }
  async function openForm(row=null,typeOverride=null) {
    const type=typeOverride || row?.type || moduleType;
    const html=`<form id="policies-record-form"><div class="row g-3">${fields[type].map(f=>fieldHtml(f,row?.[f[0]]??'')).join('')}</div></form>`;
    const el=modal('policies-record-modal',`${row?'Edit':'Add'} ${type}`,html,`<button class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" form="policies-record-form" type="submit">Save</button>`);
    const form=$('#policies-record-form',el);
    if(row && type==='rd') { form.elements.account_number.required=false; form.elements.account_number.placeholder='Leave blank to keep existing account number'; }
    if(row) Object.entries(row).forEach(([k,v])=>{const input=form.elements[k];if(input && v!=null) input.value=v;});
    if(type==='subscription' && !row) form.elements.currency.value='INR';
    await populateMasterSelects(form);
    $$('[data-master-type]',form).forEach(sel=>{if(row?.[sel.name])sel.value=row[sel.name];});
    form.addEventListener('submit',async e=>{
      e.preventDefault();const payload=Object.fromEntries(new FormData(form).entries());
      try{await request(`${api}/${type}${row?'/'+row.id:''}`,row?'PUT':'POST',payload);bootstrap.Modal.getInstance(el).hide();await load(state.page);}
      catch(err){alert(err.message);}
    });
  }
  async function openMasters(type) {
    const data=await request(`${api}/masters?type=${type}`);
    const body=`<form id="master-form" class="d-flex gap-2 mb-3"><input type="hidden" name="master_type" value="${type}"><input class="form-control" name="master_name" placeholder="New ${type.replaceAll('_',' ')}" required><button class="btn btn-primary">Add</button></form><div id="master-list" class="list-group">${(data.data||[]).map(m=>`<div class="list-group-item d-flex justify-content-between align-items-center"><span>${esc(m.master_name)}</span><div><button class="btn btn-sm btn-outline-primary me-1" data-edit-master="${m.sno}" data-master-name="${esc(m.master_name)}">Edit</button><button class="btn btn-sm btn-outline-danger" data-delete-master="${m.sno}">Archive</button></div></div>`).join('')||'<div class="text-muted p-2">No values yet.</div>'}</div>`;
    const el=modal('policies-master-modal',`Manage ${type.replaceAll('_',' ')}`,body);
    $('#master-form',el).addEventListener('submit',async e=>{e.preventDefault();try{await request(`${api}/masters`,'POST',Object.fromEntries(new FormData(e.target)));bootstrap.Modal.getInstance(el).hide();await populateMasterSelects(document);openMasters(type); }catch(err){alert(err.message)}});
    $$('[data-edit-master]',el).forEach(b=>b.addEventListener('click',async()=>{const name=prompt('Update value',b.dataset.masterName);if(name===null||!name.trim())return;try{await request(`${api}/masters/${b.dataset.editMaster}`,'PUT',{master_type:type,master_name:name.trim()});bootstrap.Modal.getInstance(el).hide();await populateMasterSelects(document);openMasters(type);}catch(err){alert(err.message)}}));
    $$('[data-delete-master]',el).forEach(b=>b.addEventListener('click',async()=>{if(!confirm('Archive this dropdown value?'))return;try{await request(`${api}/masters/${b.dataset.deleteMaster}`,'DELETE');bootstrap.Modal.getInstance(el).hide();await populateMasterSelects(document);openMasters(type);}catch(err){alert(err.message)}}));
  }
  function tableFor(headerText) {
    return $$('table').find(t=>$( 'thead',t)?.innerText.toLowerCase().replace(/\s+/g,' ').includes(headerText.toLowerCase()));
  }
  function setTableRows(table, rows, renderer, colspan) {
    if(!table) return;
    let body=$('tbody',table); if(!body) body=table.appendChild(document.createElement('tbody'));
    body.innerHTML=rows.length?rows.map(renderer).join(''):`<tr><td colspan="${colspan}" class="text-center text-muted py-4">No records found</td></tr>`;
  }
  function actionButtons(row,type) {
    const common=`<button class="btn btn-xs btn-outline-primary me-1" data-type="${type}" data-edit="${row.id}">Edit</button><button class="btn btn-xs btn-outline-danger" data-type="${type}" data-archive="${row.id}">Archive</button>`;
    const extra=type==='insurance'?`<button class="btn btn-xs btn-outline-secondary mt-1" data-type="insurance" data-claims="${row.id}">Claims</button><button class="btn btn-xs btn-outline-secondary mt-1" data-type="insurance" data-contract-pay="${row.id}">Payment</button><button class="btn btn-xs btn-outline-secondary mt-1" data-type="insurance" data-surrender="${row.id}">Surrender</button>`:
      type==='amc'?`<button class="btn btn-xs btn-outline-secondary mt-1" data-type="amc" data-maintenance="${row.id}">Maintenance</button><button class="btn btn-xs btn-outline-secondary mt-1" data-type="amc" data-report="${row.id}">Service Report</button><button class="btn btn-xs btn-outline-secondary mt-1" data-type="amc" data-contract-pay="${row.id}">Payment</button>`:
      type==='subscription'?`<button class="btn btn-xs btn-outline-secondary mt-1" data-type="subscription" data-subpayment="${row.id}">Payment</button>`:
      `<button class="btn btn-xs btn-outline-secondary mt-1" data-type="rd" data-installments="${row.id}">Installments</button>${row.status===1?`<button class="btn btn-xs btn-outline-danger mt-1" data-type="rd" data-close-rd="${row.id}">Close RD</button>`:''}`;
    return `${common}${extra}<button class="btn btn-xs btn-outline-info mt-1" data-docs="${type}:${row.id}">Documents</button>`;
  }
  function bindRows() {
    $$('[data-edit]').forEach(b=>b.onclick=async()=>{try{const x=await request(`${api}/${b.dataset.type}/${b.dataset.edit}`);openForm(x.data,b.dataset.type)}catch(e){alert(e.message)}});
    $$('[data-archive]').forEach(b=>b.onclick=async()=>{if(!confirm('Archive this record?'))return;try{await request(`${api}/${b.dataset.type}/${b.dataset.archive}`,'DELETE');load(state.page)}catch(e){alert(e.message)}});
    $$('[data-claims]').forEach(b=>b.onclick=()=>openClaims(b.dataset.claims).catch(e=>alert(e.message)));
    $$('[data-contract-pay]').forEach(b=>b.onclick=()=>openContractPayment(b.dataset.type,b.dataset.contractPay).catch(e=>alert(e.message)));
    $$('[data-surrender]').forEach(b=>b.onclick=()=>openSurrender(b.dataset.surrender));
    $$('[data-maintenance]').forEach(b=>b.onclick=()=>openMaintenance(b.dataset.maintenance).catch(e=>alert(e.message)));
    $$('[data-report]').forEach(b=>b.onclick=()=>openServiceReport(b.dataset.report));
    $$('[data-subpayment]').forEach(b=>b.onclick=()=>openPayment('subscription',b.dataset.subpayment));
    $$('[data-installments]').forEach(b=>b.onclick=()=>openInstallments(b.dataset.installments).catch(e=>alert(e.message)));
    $$('[data-close-rd]').forEach(b=>b.onclick=()=>closeRd(b.dataset.closeRd));
    $$('[data-docs]').forEach(b=>b.onclick=()=>openDocuments(b.dataset.docs).catch(e=>alert(e.message)));
  }
  function renderInsurance(rows) {
    const table=tableFor('Policy ID');
    setTableRows(table,rows,r=>`<tr><td>${esc(r.reference_number||r.policy_number||r.id)}</td><td>${esc(r.title)}<small class="d-block text-muted">${esc(r.category||'Insurance')}</small></td><td>${esc(r.provider_name)}<small class="d-block text-muted">${esc(r.owner_name||'')}</small></td><td>—</td><td>${esc(r.asset_name||'—')}</td><td>${money(r.premium_amount)}</td><td>${date(r.end_date)}</td><td>${r.status?'Active':'Archived'}</td><td>${actionButtons(r,'insurance')}</td></tr>`,9);
  }
  function renderAmc(rows) {
    const table=tableFor('Contract');
    setTableRows(table,rows,r=>`<tr><td>${esc(r.reference_number||r.id)}</td><td>${esc(r.asset_name||r.title)}</td><td>${esc(r.payment_frequency||'—')}</td><td>${money(r.contract_amount)}</td><td>${date(r.next_due_date)}</td><td>—</td><td>${date(r.end_date)}</td><td>${r.status?'Active':'Archived'}</td><td>${actionButtons(r,'amc')}</td></tr>`,9);
  }
  function renderSubscriptions(rows) {
    const table=tableFor('Subsc.');
    setTableRows(table,rows,r=>`<tr><td>${esc('SUB-'+r.id)}</td><td>${esc(r.subscription_name)}<small class="d-block text-muted">${esc(r.provider_name)}</small></td><td>${esc(r.category||'—')}</td><td class="text-center">${r.used_seats}/${r.seat_count}</td><td>${money(r.unit_cost)}</td><td>${money(r.annual_cost)}</td><td>${date(r.renewal_date)}</td><td>${r.status?'Active':'Archived'}</td><td>${actionButtons(r,'subscription')}</td></tr>`,9);
    const membershipTable=tableFor('Body');
    if(membershipTable) {
      const memberships=rows.filter(r=>(r.subscription_type||'').toLowerCase()==='membership');
      setTableRows(membershipTable,memberships,r=>`<tr><td>${esc('MEM-'+r.id)}</td><td>${esc(r.provider_name)}</td><td>${esc(r.tier||'—')}</td><td>${money(r.annual_cost)}</td><td>${esc(r.benefits||'—')}</td><td>${esc(r.contact_name||r.contact_email||'—')}</td><td>${date(r.renewal_date)}</td><td>${r.status?'Active':'Archived'}</td><td>${actionButtons(r,'subscription')}</td></tr>`,9);
    }
  }
  function renderSubscriptionPayments(rows) {
    const table=tableFor('Reference');
    if(!table)return;
    setTableRows(table,rows,r=>`<tr><td>${date((r.paid_at||'').slice(0,10))}</td><td>${esc(r.reference_no||r.subscription_name)}</td><td>${esc(r.payment_mode||'—')}</td><td>${money(r.amount)}</td><td>Recorded</td></tr>`,5);
  }
  function renderRenewals(rows) {
    const table=tableFor('Date');
    if(!table)return;
    setTableRows(table,rows,r=>`<tr><td>${date(r.due_date)}</td><td>${Math.ceil((new Date(r.due_date)-new Date())/86400000)}d</td><td>${esc(r.source_type)}</td><td>${esc(r.title)}</td><td>${esc(r.provider_name||'—')}</td><td>${money(r.amount)}</td><td><button class="btn btn-sm btn-outline-success" data-complete-renewal="${r.sno}">Mark Processed</button></td></tr>`,7);
    $$('[data-complete-renewal]').forEach(b=>b.onclick=async()=>{try{await request(`${api}/renewals/${b.dataset.completeRenewal}/complete`,'POST',{});load(1)}catch(e){alert(e.message)}});
  }
  function renderRdSchedule(rows) {
    const table=tableFor('Required');
    if(!table)return;
    setTableRows(table,rows,r=>`<tr><td>${esc(r.account_name)}<small class="d-block text-muted">${esc(r.bank_name)}</small></td><td>${date(r.due_date)}</td><td>${money(r.due_amount)}</td><td>${money(r.paid_amount)}</td><td>${r.status===2?'Paid':r.status===3?'Part Paid':'Due'}</td></tr>`,5);
  }
  function skeletonTable(header,cols) {
    const table=tableFor(header); if(!table)return;
    let body=$('tbody',table);if(!body)body=table.appendChild(document.createElement('tbody'));
    body.innerHTML=Array.from({length:6},()=>`<tr>${Array.from({length:cols},()=>'<td><div class="policies-skeleton"></div></td>').join('')}</tr>`).join('');
  }
  async function load(page=1) {
    state.page=page;state.search=$('#policies-search')?.value||state.search;
    const qs=new URLSearchParams({page:String(page),per_page:String(state.perPage),search:state.search});
    const body=$('#policies-live-body'); if(body) body.innerHTML='<div class="text-center py-3"><span class="spinner-border spinner-border-sm"></span> Loading…</div>';
    if(moduleName==='insurance-amc'){skeletonTable('Policy ID',9);skeletonTable('Contract',9);}
    if(moduleName==='subscription'){skeletonTable('Subsc.',9);skeletonTable('Body',9);skeletonTable('Reference',5);}
    if(moduleName==='renewals')skeletonTable('Date In Type Item Vendor Value',7);
    if(moduleName==='rd')skeletonTable('Required',5);
    try {
      if(moduleName==='dashboard') {const d=await request(`${api}/dashboard`);renderDashboard(d.data);return;}
      if(moduleName==='renewals') {const d=await request(`${api}/renewals?${qs}`);renderRenewals(d.data||[]);setPager(d.meta);if(body)body.innerHTML=`<div class="small text-muted">Showing ${d.meta?.total||0} renewal records in the calendar table below.</div>`;return;}
      if(moduleName==='rd') {const [a,b]=await Promise.all([request(`${api}/rd?${qs}`),request(`${api}/rd-schedule?${qs}`)]);state.rows=a.data?.data||[];renderRdSchedule(b.data?.data||[]);renderRdAccounts(state.rows);setPager(a.meta);return;}
      if(moduleName==='insurance-amc') {
        const [a,b]=await Promise.all([request(`${api}/insurance?${qs}`),request(`${api}/amc?${qs}`)]);
        renderInsurance(a.data?.data||[]);renderAmc(b.data?.data||[]);state.rows=a.data?.data||[];
        if(body)body.innerHTML=`<div class="small text-muted">Insurance: ${a.meta?.total||0} · AMC: ${b.meta?.total||0} records</div>`;setPager(a.meta);bindRows();return;
      }
      const [d,payments]=await Promise.all([request(`${api}/${moduleType}?${qs}`),request(`${api}/subscription-payments?${qs}`)]);
      state.rows=d.data?.data||[];renderSubscriptions(state.rows);renderSubscriptionPayments(payments.data||[]);
      if(body)body.innerHTML=`<div class="small text-muted">${d.meta?.total||0} subscription records · ${payments.meta?.total||0} payments</div>`;setPager(d.meta);bindRows();
    } catch(e) { if(body)body.innerHTML=`<div class="alert alert-danger mb-0">${esc(e.message)}</div>`; }
  }
  function renderRdAccounts(rows) {
    let table=tableFor('Account');
    if(!table) {
      let wrap=$('#policies-rd-account-table');
      if(!wrap){wrap=document.createElement('div');wrap.id='policies-rd-account-table';wrap.className='table-responsive mt-3';$('#policies-live-body')?.appendChild(wrap);}
      wrap.innerHTML='<h6>RD Accounts</h6><table class="table table-sm"><thead><tr><th>Account</th><th>Bank</th><th>Account No.</th><th>Installment</th><th>Maturity</th><th>Principal Paid</th><th>Maturity Value</th><th>Status</th><th>Action</th></tr></thead><tbody></tbody></table>';
      table=$('table',wrap);
    }
    setTableRows(table,rows,r=>`<tr><td>${esc(r.account_name)}</td><td>${esc(r.bank_name)}</td><td>${esc(r.account_number_masked)}</td><td>${money(r.monthly_installment)}</td><td>${date(r.maturity_date)}</td><td>${money(r.principal_paid)}</td><td>${money(r.maturity_value)}</td><td>${r.status===1?'Active':r.status===2?'Closed':'Archived'}</td><td>${actionButtons(r,'rd')}</td></tr>`,9);
    bindRows();
  }
  function setPager(meta) {
    if(!meta)return;const body=$('#policies-live-body');if(!body)return;
    let p=$('#policies-pager');if(!p){p=document.createElement('div');p.id='policies-pager';p.className='d-flex justify-content-between align-items-center mt-3';body.appendChild(p);}
    p.innerHTML=`<small class="text-muted">${meta.total||0} records · Page ${meta.current_page||1} of ${meta.last_page||1}</small><div class="btn-group btn-group-sm"><button class="btn btn-outline-secondary" ${meta.current_page<=1?'disabled':''} id="pol-prev">Previous</button><button class="btn btn-outline-secondary" ${meta.current_page>=meta.last_page?'disabled':''} id="pol-next">Next</button></div>`;
    $('#pol-prev')?.addEventListener('click',()=>load(meta.current_page-1));$('#pol-next')?.addEventListener('click',()=>load(meta.current_page+1));
  }
  function renderDashboard(d) {
    const body=$('#policies-live-body');if(!body)return;
    const items=[['Insurance Policies',d.insurance_count],['AMC Contracts',d.amc_count],['Subscriptions',d.subscription_count],['RD Accounts',d.rd_accounts_count],['Insurance Premium',money(d.premium_total)],['AMC Contract Value',money(d.amc_total)],['Annual Subscription Cost',money(d.subscription_annual_total)],['RD Principal Deposited',money(d.rd_principal_total)],['RD Monthly Allocation',money(d.rd_monthly_allocation)],['Insurance Coverage',money(d.insurance_coverage_total)],['Open Claims',d.open_claims],['Renewals Next 30 Days',d.renewals_due_30_days],['Overdue Renewals',d.overdue_renewals]];
    body.innerHTML=`<div class="row g-3">${items.map(([l,v])=>`<div class="col-6 col-md-4 col-xl-2"><div class="border rounded p-3 h-100"><small class="text-muted">${l}</small><div class="fs-4 fw-bold text-black">${esc(v)}</div></div></div>`).join('')}</div><h6 class="mt-4">Upcoming renewals</h6><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Due</th><th>Record</th><th>Provider</th><th>Amount</th></tr></thead><tbody>${(d.recent_renewals||[]).map(r=>`<tr><td>${date(r.due_date)}</td><td>${esc(r.title)}</td><td>${esc(r.provider_name)}</td><td>${money(r.amount)}</td></tr>`).join('')||'<tr><td colspan="4">No upcoming renewals</td></tr>'}</tbody></table></div>`;
  }
  async function openContractPayment(type,id) {
    const d=await request(`${api}/${type}/${id}/payments`);
    const body=`<h6>Payment Ledger</h6><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Kind</th><th>Due</th><th>Paid</th><th>Amount</th><th>Mode</th><th>Reference</th></tr></thead><tbody>${(d.data||[]).map(p=>`<tr><td>${esc(p.payment_kind)}</td><td>${date(p.due_date)}</td><td>${esc(p.paid_at)}</td><td>${money(p.amount)}</td><td>${esc(p.payment_mode||'—')}</td><td>${esc(p.reference_no||'—')}</td></tr>`).join('')}</tbody></table></div><form id="contract-payment-form" class="row g-2"><div class="col-md-6"><select class="select3 form-select" name="payment_kind"><option value="premium">Premium</option><option value="amc_fee">AMC Fee</option><option value="other">Other</option></select></div><div class="col-md-6"><input class="form-control" name="due_date" type="date"></div><div class="col-md-6"><input class="form-control" name="amount" type="number" min=".01" step=".01" placeholder="Amount" required></div><div class="col-md-6"><input class="form-control" name="paid_at" type="datetime-local"></div><div class="col-md-6"><input class="form-control" name="payment_mode" placeholder="Payment mode"></div><div class="col-md-6"><input class="form-control" name="reference_no" placeholder="Reference number"></div><div class="col-12"><textarea class="form-control" name="notes" placeholder="Notes"></textarea></div><div class="col-12"><button class="btn btn-primary">Record Payment</button></div></form>`;
    const el=modal('policies-child-modal',`${type.toUpperCase()} Payment Ledger`,body);
    initSelect3(el);
    $('#contract-payment-form',el).addEventListener('submit',async e=>{e.preventDefault();try{const payload=Object.fromEntries(new FormData(e.target));payload.idempotency_key=newIdempotencyKey();await request(`${api}/${type}/${id}/payments`,'POST',payload);bootstrap.Modal.getInstance(el).hide();openContractPayment(type,id)}catch(x){alert(x.message)}});
  }
  async function openClaims(id) {
    const d=await request(`${api}/insurance/${id}/claims`);
    const body=`<div class="table-responsive"><table class="table table-sm"><thead><tr><th>Claim</th><th>Date</th><th>Claimed</th><th>Approved</th><th>Settled</th><th>Status</th><th>Update</th></tr></thead><tbody>${(d.data||[]).map(c=>`<tr><td>${esc(c.claim_number||c.sno)}</td><td>${date(c.claim_date)}</td><td>${money(c.claimed_amount)}</td><td><input class="form-control form-control-sm" type="number" min="0" step=".01" id="claim-approved-${c.sno}" value="${esc(c.approved_amount)}" style="width:110px"></td><td><input class="form-control form-control-sm" type="number" min="0" step=".01" id="claim-settled-${c.sno}" value="${esc(c.settled_amount)}" style="width:110px"></td><td><select class="select3 form-select form-select-sm" id="claim-status-${c.sno}">${['submitted','under_review','approved','rejected','settled'].map(st=>`<option ${st===c.status?'selected':''}>${st}</option>`).join('')}</select></td><td><button class="btn btn-sm btn-outline-primary" data-update-claim="${c.sno}">Save</button></td></tr>`).join('')}</tbody></table></div><form id="claim-form" class="row g-2"><div class="col-md-6"><div class="input-group"><select class="form-select" name="claim_type" data-master-type="claim_type" required><option value="">Claim type</option></select><button class="btn btn-outline-secondary" type="button" data-manage-master="claim_type">Manage</button></div></div><div class="col-md-6"><input class="form-control" name="claim_date" type="date" required></div><div class="col-md-6"><input class="form-control" name="claimed_amount" type="number" min="0.01" step=".01" placeholder="Claim amount" required></div><div class="col-md-6"><select class="form-select" name="status"><option>submitted</option><option>under_review</option><option>approved</option><option>rejected</option><option>settled</option></select></div><div class="col-12"><textarea class="form-control" name="notes" placeholder="Notes"></textarea></div><div class="col-12"><button class="btn btn-primary">Save Claim</button></div></form>`;
    const el=modal('policies-child-modal','Insurance Claims',body);
    await populateMasterSelects(el); initSelect3(el);
    $$('[data-update-claim]',el).forEach(b=>b.onclick=async()=>{try{await request(`${api}/insurance/${id}/claims/${b.dataset.updateClaim}`,'PUT',{status:$(`#claim-status-${b.dataset.updateClaim}`,el).value,approved_amount:$(`#claim-approved-${b.dataset.updateClaim}`,el).value,settled_amount:$(`#claim-settled-${b.dataset.updateClaim}`,el).value});openClaims(id)}catch(x){alert(x.message)}});
    $('#claim-form',el).addEventListener('submit',async e=>{e.preventDefault();try{await request(`${api}/insurance/${id}/claims`,'POST',Object.fromEntries(new FormData(e.target)));bootstrap.Modal.getInstance(el).hide();}catch(x){alert(x.message)}});
  }
  function openSurrender(id) {
    const body=`<form id="surrender-form" class="row g-3"><div class="col-md-6"><label class="form-label">Surrender Date</label><input class="form-control" name="surrender_date" type="date" required></div><div class="col-md-6"><label class="form-label">Surrender Value</label><input class="form-control" name="surrender_value" type="number" min="0" step=".01" required></div><div class="col-md-6"><label class="form-label">Penalty</label><input class="form-control" name="penalty_amount" type="number" min="0" step=".01" value="0"></div><div class="col-12"><textarea class="form-control" name="reason" placeholder="Reason" required></textarea></div><div class="col-12"><button class="btn btn-danger">Confirm Surrender</button></div></form>`;
    const el=modal('policies-child-modal','Surrender Policy',body);
    $('#surrender-form',el).addEventListener('submit',async e=>{e.preventDefault();if(!confirm('Surrendering will close this policy. Continue?'))return;try{await request(`${api}/insurance/${id}/surrender`,'POST',Object.fromEntries(new FormData(e.target)));bootstrap.Modal.getInstance(el).hide();load(1)}catch(x){alert(x.message)}});
  }
  async function openMaintenance(id) {
    const d=await request(`${api}/amc/${id}/maintenance`);
    const body=`<div class="table-responsive"><table class="table table-sm"><thead><tr><th>Type</th><th>Scheduled</th><th>Status</th></tr></thead><tbody>${(d.data||[]).map(x=>`<tr><td>${esc(x.maintenance_type)}</td><td>${esc(x.scheduled_at)}</td><td>${esc(x.status)}</td></tr>`).join('')}</tbody></table></div><form id="maintenance-form" class="row g-2"><div class="col-md-6"><div class="input-group"><select class="form-select" name="maintenance_type" data-master-type="maintenance_type" required><option value="">Maintenance type</option></select><button class="btn btn-outline-secondary" type="button" data-manage-master="maintenance_type">Manage</button></div></div><div class="col-md-6"><input class="form-control" name="scheduled_at" type="datetime-local" required></div><div class="col-md-6"><input class="form-control" name="estimated_cost" type="number" min="0" step=".01" placeholder="Estimated cost"></div><div class="col-md-6"><input class="form-control" name="assigned_to" placeholder="Technician / Vendor"></div><div class="col-12"><textarea class="form-control" name="notes" placeholder="Notes"></textarea></div><div class="col-12"><button class="btn btn-primary">Schedule Maintenance</button></div></form>`;
    const el=modal('policies-child-modal','AMC Maintenance',body);
    await populateMasterSelects(el);
    $('#maintenance-form',el).addEventListener('submit',async e=>{e.preventDefault();try{await request(`${api}/amc/${id}/maintenance`,'POST',Object.fromEntries(new FormData(e.target)));bootstrap.Modal.getInstance(el).hide()}catch(x){alert(x.message)}});
  }
  function openServiceReport(id) {
    const body=`<form id="report-form" class="row g-2"><div class="col-md-6"><input class="form-control" name="service_date" type="date" required></div><div class="col-md-6"><input class="form-control" name="service_cost" type="number" min="0" step=".01" placeholder="Service cost"></div><div class="col-12"><textarea class="form-control" name="service_summary" placeholder="Service report" required></textarea></div><div class="col-md-6"><select class="form-select" name="rating"><option value="">Rating</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select></div><div class="col-md-6"><input class="form-control" name="next_service_date" type="date"></div><div class="col-12"><button class="btn btn-primary">Save Service Report</button></div></form>`;
    const el=modal('policies-child-modal','AMC Service Report',body);
    $('#report-form',el).addEventListener('submit',async e=>{e.preventDefault();try{await request(`${api}/amc/${id}/service-reports`,'POST',Object.fromEntries(new FormData(e.target)));bootstrap.Modal.getInstance(el).hide()}catch(x){alert(x.message)}});
  }
  async function openPayment(kind,id) {
    const body=`<form id="payment-form" class="row g-2"><div class="col-md-6"><label class="form-label">Amount</label><input class="form-control" name="amount" type="number" min=".01" step=".01" required></div><div class="col-md-6"><label class="form-label">Paid At</label><input class="form-control" name="paid_at" type="datetime-local"></div><div class="col-md-6"><input class="form-control" name="payment_mode" placeholder="Payment mode"></div><div class="col-md-6"><input class="form-control" name="reference_no" placeholder="Reference number"></div><div class="col-12"><textarea class="form-control" name="notes" placeholder="Notes"></textarea></div><div class="col-12"><button class="btn btn-primary">Record Payment</button></div></form>`;
    const el=modal('policies-child-modal','Record Subscription Payment',body);
    $('#payment-form',el).addEventListener('submit',async e=>{e.preventDefault();try{const payload=Object.fromEntries(new FormData(e.target));payload.idempotency_key=newIdempotencyKey();await request(`${api}/subscriptions/${id}/payments`,'POST',payload);bootstrap.Modal.getInstance(el).hide()}catch(x){alert(x.message)}});
  }
  async function openInstallments(id) {
    const [d,tx]=await Promise.all([request(`${api}/rd/${id}/installments`),request(`${api}/rd/${id}/transactions`)]);
    const rows=d.data?.data||[];
    const body=`<h6>Installment Schedule</h6><div class="table-responsive"><table class="table table-sm"><thead><tr><th>#</th><th>Due</th><th>Due Amount</th><th>Paid</th><th>Balance</th><th>Action</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r.installment_no}</td><td>${date(r.due_date)}</td><td>${money(r.due_amount)}</td><td>${money(r.paid_amount)}</td><td>${money(r.balance)}</td><td><button class="btn btn-sm btn-outline-primary" data-rd-pay="${r.sno}" ${r.status===2?'disabled':''}>Pay</button></td></tr>`).join('')}</tbody></table></div><h6 class="mt-3">Payment Ledger</h6><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Amount</th><th>Action</th></tr></thead><tbody>${(tx.data||[]).map(t=>`<tr><td>${esc(t.paid_at)}</td><td>${esc(t.transaction_type)}</td><td>${esc(t.reference_no||'—')}</td><td>${money(t.amount)}</td><td>${t.transaction_type==='deposit'?`<button class="btn btn-sm btn-outline-danger" data-reverse-rd-payment="${t.sno}">Reverse</button>`:'—'}</td></tr>`).join('')}</tbody></table></div>`;
    const el=modal('policies-child-modal','RD Installments & Ledger',body);
    $$('[data-rd-pay]',el).forEach(b=>b.onclick=()=>rdPayment(id,b.dataset.rdPay));
    $$('[data-reverse-rd-payment]',el).forEach(b=>b.onclick=async()=>{const reason=prompt('Reason for reversing this RD payment');if(!reason?.trim())return;try{await request(`${api}/rd-transactions/${b.dataset.reverseRdPayment}/reverse`,'POST',{reason:reason.trim()});openInstallments(id);load(1)}catch(x){alert(x.message)}});
  }
  function rdPayment(id,installment) {
    const body=`<form id="rd-payment-form" class="row g-2"><div class="col-md-6"><input class="form-control" name="amount" type="number" min=".01" step=".01" placeholder="Amount" required></div><div class="col-md-6"><input class="form-control" name="paid_at" type="datetime-local"></div><div class="col-md-6"><input class="form-control" name="payment_mode" placeholder="Payment mode"></div><div class="col-md-6"><input class="form-control" name="reference_no" placeholder="Reference number"></div><div class="col-12"><button class="btn btn-primary">Record Deposit</button></div></form>`;
    const el=modal('policies-payment-modal','RD Installment Payment',body);
    $('#rd-payment-form',el).addEventListener('submit',async e=>{e.preventDefault();try{const payload=Object.fromEntries(new FormData(e.target));payload.idempotency_key=newIdempotencyKey();await request(`${api}/rd/${id}/installments/${installment}/payments`,'POST',payload);bootstrap.Modal.getInstance(el).hide();bootstrap.Modal.getInstance(document.getElementById('policies-child-modal'))?.hide();openInstallments(id);load(1)}catch(x){alert(x.message)}});
  }
  function closeRd(id) {
    const body=`<form id="rd-close-form" class="row g-2"><div class="col-md-6"><label class="form-label">Closure Date</label><input class="form-control" name="close_date" type="date" required></div><div class="col-md-6"><label class="form-label">Bank Quoted Closing Value</label><input class="form-control" name="closing_value" type="number" min="0" step=".01" required></div><div class="col-md-6"><label class="form-label">Penalty / TDS / Charges</label><input class="form-control" name="penalty_amount" type="number" min="0" step=".01" value="0"></div><div class="col-12"><textarea class="form-control" name="reason" placeholder="Closure reason and bank reference" required></textarea></div><div class="col-12"><small class="text-muted">Enter the amount confirmed by the bank. The system does not guess premature-closure interest or penalties.</small></div><div class="col-12"><button class="btn btn-danger">Confirm RD Closure</button></div></form>`;
    const el=modal('policies-rd-close-modal','Close RD Account',body);
    $('#rd-close-form',el).addEventListener('submit',async e=>{e.preventDefault();if(!confirm('This closes the RD account and cannot be undone from this screen. Continue?'))return;try{await request(`${api}/rd/${id}/close`,'POST',Object.fromEntries(new FormData(e.target)));bootstrap.Modal.getInstance(el).hide();load(1)}catch(x){alert(x.message)}});
  }
  async function openDocuments(key) {
    const [type,id]=key.split(':');
    const docs=await request(`${api}/${type}/${id}/documents`);
    const body=`<h6>Existing Documents</h6><div class="list-group mb-3">${(docs.data||[]).map(d=>`<a class="list-group-item list-group-item-action d-flex justify-content-between" href="${api}/documents/${d.sno}" target="_blank"><span>${esc(d.original_name)} <small class="text-muted">${esc(d.document_type||'')}</small></span><small>${date((d.created_at||'').slice(0,10))}</small></a>`).join('')||'<div class="text-muted p-2">No documents uploaded.</div>'}</div><form id="document-form" class="row g-2" enctype="multipart/form-data"><div class="col-md-6"><input class="form-control" type="file" name="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx" required></div><div class="col-md-6"><input class="form-control" name="document_type" placeholder="Document type"></div><div class="col-12"><textarea class="form-control" name="notes" placeholder="Notes"></textarea></div><div class="col-12"><button class="btn btn-primary">Upload Document</button></div></form>`;
    const el=modal('policies-doc-modal','Upload Document',body);
    $('#document-form',el).addEventListener('submit',async e=>{e.preventDefault();try{await request(`${api}/${type}/${id}/documents`,'POST',new FormData(e.target),true);bootstrap.Modal.getInstance(el).hide()}catch(x){alert(x.message)}});
  }
  addShell();
  load(1);
})();
