# Policies & RD Accounts — integration package

## Source audit

Built against the supplied `erpmvc.zip` (not the earlier generic scaffold).

Findings from the supplied source:
- The five original Policies & RD Accounts page controllers were view-only controllers.
- The five original Blade pages contained demo/static rows and static operational examples.
- The menu already defines these five submenus; `verticalMenu.json` is included unchanged.
- `User` has a `staff()` relationship to `StaffModel`; the navbar workspace switcher reads `Auth::user()->staff->entity_id`. The service therefore scopes data using the authenticated linked staff record's `company_id` and `entity_id`, not request-supplied tenant values or guessed session keys.
- `User::hasPermission()` supports the exact menu hierarchy. The five page controllers and API methods check the `Corporate Admin > Policies & RD Accounts > <submenu>` permission.
- The Staff List page uses asynchronous fetch, skeleton rows, pagination and Select2; the new dynamic panel uses the same shimmer/skeleton pattern, paginated API responses and Select2.
- The Bookmarks implementation has dynamic board categories with add/edit/archive actions; the new master-data manager follows that CRUD pattern.
- Existing finance models include `DailyaccountsModel`, `PaymenttypeModel`, `PaymentmodeModel` and `CommonExpenditureModel`, but the supplied ZIP contains no corresponding posting controller/service or schema/migrations. The module therefore records its own immutable payment ledgers and does **not** silently post to Accounts & Finance. An incorrect or duplicate finance posting is more dangerous than an unverified integration.

## Included implementation

- Controllers: original five page controllers updated with permission checks; new `PoliciesAccountsController`.
- Models: contracts, claims, surrender, AMC maintenance/service reports, subscription/payment, RD account/installments/transactions/closure, renewals, masters, documents and audit.
- Service: tenant scoping, CRUD, renewal synchronization, RD schedule generation, decimal-safe RD payment allocation, idempotency, payment reversal, subscription and contract payment ledgers, audit logging.
- Form Requests: policy/AMC, subscription, RD, payment and master validation.
- API Resources: safe policy, subscription and RD representations; encrypted credentials and account numbers are never returned.
- Routes: full updated `routes/web.php` and a route snippet.
- Frontend: five original Blade views with a live module mount point and `public/js/policies-accounts.js`; dynamic record lists, add/edit/archive, search, pagination, staff-style skeleton loading, Select2, master add/edit/archive, claims, surrender, contract payments, AMC maintenance/service reports, documents, subscription payments, RD installments/payment ledger/reversal/closure and renewal processing.
- SQL: schema and rollback scripts.

## Install

1. Back up the production database and source tree.
2. Review `database/policies_rd_accounts.sql` against your production MySQL version. The script targets MySQL 8.0+ and creates only `egc_policy_*` tables.
3. Run the SQL once. Do not run the down script except when intentionally deleting all module data.
4. Copy `app/Models/Policies`, `app/Services/Policies`, `app/Http/Requests/Policies`, `app/Http/Resources/Policies` and the new controller into the matching application paths.
5. Replace the five page controllers with the versions in this package.
6. Merge the policies-data route group from `routes/policies-rd-routes.snippet.php` into the existing `Route::middleware(['auth:web', 'timezone'])` group. The supplied full `routes/web.php` shows the merge location. Do not replace a newer production routes file blindly.
7. Deploy the five updated Blade files and `public/js/policies-accounts.js`.
8. Ensure the `local` filesystem disk is writable and `APP_KEY` is stable. Uploaded documents are stored on the `local` disk under `policies/<company>/<entity>/`.
9. Confirm role permissions for each submenu. The permission labels are the exact menu labels from `verticalMenu.json`.
10. Run `php artisan route:list --path=policies-data`, clear route/view caches as appropriate, and perform the QA checklist on staging before production.

## Financial integrity rules

- Amount columns use MySQL `DECIMAL(18,2)`, not PHP float arithmetic.
- RD payment allocations are transaction records; installment/account totals are adjusted inside a database transaction and an overpayment is rejected.
- RD payment requests support idempotency keys; reversal creates a new immutable reversal row and does not rewrite the original payment.
- Contract and subscription payments are ledger rows with idempotency keys.
- Surrender/closure net proceeds are calculated by MySQL DECIMAL arithmetic; penalties cannot exceed the bank-quoted amount.
- RD principal schedules are generated from monthly installment and tenure. **Interest/maturity is bank-confirmed, not guessed.** The archive does not specify the bank's compounding convention, day-count basis, missed-installment penalty, tax/TDS or premature-closure rules. The user enters the bank-confirmed maturity/closure quote. Supply the bank product formula and policy before enabling automated maturity-interest calculations.
- Payments are not automatically posted to `egc_finc_daily_account` or `egc_acc_common_expenditure`; the supplied source does not contain the finance posting workflow or verified category/payment-type mapping. A finance adapter must be mapped and reconciled with the Accounts & Finance owner before enabling journal postings.

## Important scope/verification boundary

The supplied archive is a source slice: it does not include `composer.json`, Laravel bootstrap/config, database migrations, schema dump, vendor directory or the referenced Productivity access-service implementation. Consequently, this package can be syntax-checked but cannot be booted against the actual production app/database here. It is **not certified production-ready until** staging migration, route resolution, permission, storage, browser, concurrency and accounting reconciliation tests pass.

The new live data tables are dynamic. Some legacy decorative dashboard charts and old sample-detail offcanvas markup remain in the original Blade source as design references; the new live panel is the authoritative operational UI. Review and remove any remaining static demo-only fragments before rollout if the requirement is that no sample values remain visible anywhere.


i update mvc in my file 
 dont give new ui use existing ui into developement if any thing  want to implement just inlcude that into existing ui and update that ui in to production dynamic fetch
 and i dont wnat global publick script sript include that every blade file separately and i dont wnat script format (function () {
  'use strict'; like this i want open free function and table pagination and skeleton loder like in candidate_list for use in policies because that is standard give the updated files for production without change ui totally in exitsting ui
