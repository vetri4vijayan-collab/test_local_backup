-- Rollback for policies_rd_accounts.sql. Backup first; this permanently deletes module data.
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS egc_policy_audit_logs;
DROP TABLE IF EXISTS egc_policy_documents;
DROP TABLE IF EXISTS egc_policy_renewals;
DROP TABLE IF EXISTS egc_policy_rd_closures;
DROP TABLE IF EXISTS egc_policy_rd_transactions;
DROP TABLE IF EXISTS egc_policy_rd_installments;
DROP TABLE IF EXISTS egc_policy_rd_accounts;
DROP TABLE IF EXISTS egc_policy_subscription_payments;
DROP TABLE IF EXISTS egc_policy_subscriptions;
DROP TABLE IF EXISTS egc_policy_service_reports;
DROP TABLE IF EXISTS egc_policy_maintenance;
DROP TABLE IF EXISTS egc_policy_surrenders;
DROP TABLE IF EXISTS egc_policy_claims;
DROP TABLE IF EXISTS egc_policy_contract_payments;
DROP TABLE IF EXISTS egc_policy_contracts;
DROP TABLE IF EXISTS egc_policy_masters;
SET FOREIGN_KEY_CHECKS=1;
