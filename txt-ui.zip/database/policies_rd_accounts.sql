-- Policies & RD Accounts module
-- MySQL 8.0+ / InnoDB / utf8mb4. Run once after backup.
-- Tenant keys are copied from the authenticated ERP user (egc_users.company_id/entity_id).
-- This module uses status=1 active, status=0 archived; this is intentionally module-local.
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS egc_policy_masters (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  master_type VARCHAR(40) NOT NULL,
  master_name VARCHAR(160) NOT NULL,
  status TINYINT NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_master_name (company_id,entity_id,master_type,master_name),
  KEY idx_policy_master_scope (company_id,entity_id,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_contracts (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  record_type ENUM('insurance','amc') NOT NULL,
  title VARCHAR(190) NOT NULL,
  reference_number VARCHAR(100) NULL,
  policy_number VARCHAR(100) NULL,
  provider_name VARCHAR(190) NOT NULL,
  category VARCHAR(100) NULL,
  owner_name VARCHAR(190) NULL,
  asset_name VARCHAR(190) NULL,
  start_date DATE NULL,
  end_date DATE NOT NULL,
  next_due_date DATE NULL,
  sum_insured DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  premium_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  contract_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  payment_frequency VARCHAR(40) NULL,
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  notes TEXT NULL,
  status TINYINT NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  KEY idx_policy_contract_scope (company_id,entity_id,record_type,status),
  KEY idx_policy_contract_end (company_id,entity_id,end_date),
  KEY idx_policy_contract_ref (company_id,entity_id,reference_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_contract_payments (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  contract_id BIGINT UNSIGNED NOT NULL,
  record_type ENUM('insurance','amc') NOT NULL,
  payment_kind ENUM('premium','amc_fee','other') NOT NULL,
  due_date DATE NULL,
  amount DECIMAL(18,2) NOT NULL,
  paid_at DATETIME NOT NULL,
  payment_mode VARCHAR(60) NULL,
  reference_no VARCHAR(120) NULL,
  idempotency_key CHAR(36) NOT NULL,
  notes TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_contract_payment_idem (company_id,entity_id,idempotency_key),
  KEY idx_policy_contract_payment_scope (company_id,entity_id,contract_id,paid_at),
  CONSTRAINT fk_policy_contract_payment_contract FOREIGN KEY (contract_id) REFERENCES egc_policy_contracts(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_claims (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  contract_id BIGINT UNSIGNED NOT NULL,
  claim_number VARCHAR(100) NULL,
  claim_type VARCHAR(100) NOT NULL,
  claim_date DATE NOT NULL,
  claimed_amount DECIMAL(18,2) NOT NULL,
  approved_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  settled_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  status ENUM('submitted','under_review','approved','rejected','settled') NOT NULL DEFAULT 'submitted',
  notes TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  KEY idx_policy_claim_scope (company_id,entity_id,contract_id,status),
  CONSTRAINT fk_policy_claim_contract FOREIGN KEY (contract_id) REFERENCES egc_policy_contracts(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_surrenders (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  contract_id BIGINT UNSIGNED NOT NULL,
  surrender_date DATE NOT NULL,
  surrender_value DECIMAL(18,2) NOT NULL,
  penalty_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  net_payable DECIMAL(18,2) NOT NULL,
  reason TEXT NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_surrender_contract (company_id,entity_id,contract_id),
  CONSTRAINT fk_policy_surrender_contract FOREIGN KEY (contract_id) REFERENCES egc_policy_contracts(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_maintenance (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  contract_id BIGINT UNSIGNED NOT NULL,
  maintenance_type VARCHAR(100) NOT NULL,
  scheduled_at DATETIME NOT NULL,
  completed_at DATETIME NULL,
  estimated_cost DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  actual_cost DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  assigned_to VARCHAR(190) NULL,
  status ENUM('scheduled','in_progress','completed','cancelled') NOT NULL DEFAULT 'scheduled',
  notes TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  KEY idx_policy_maintenance_scope (company_id,entity_id,contract_id,scheduled_at),
  CONSTRAINT fk_policy_maintenance_contract FOREIGN KEY (contract_id) REFERENCES egc_policy_contracts(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_service_reports (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  contract_id BIGINT UNSIGNED NOT NULL,
  maintenance_id BIGINT UNSIGNED NULL,
  service_date DATE NOT NULL,
  service_summary TEXT NOT NULL,
  service_cost DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  rating TINYINT NULL,
  next_service_date DATE NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  KEY idx_policy_service_scope (company_id,entity_id,contract_id,service_date),
  CONSTRAINT fk_policy_service_contract FOREIGN KEY (contract_id) REFERENCES egc_policy_contracts(sno),
  CONSTRAINT fk_policy_service_maintenance FOREIGN KEY (maintenance_id) REFERENCES egc_policy_maintenance(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_subscriptions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  subscription_name VARCHAR(190) NOT NULL,
  provider_name VARCHAR(190) NOT NULL,
  category VARCHAR(100) NULL,
  subscription_type VARCHAR(80) NULL,
  tier VARCHAR(100) NULL,
  benefits TEXT NULL,
  contact_name VARCHAR(190) NULL,
  contact_email VARCHAR(190) NULL,
  start_date DATE NULL,
  renewal_date DATE NOT NULL,
  billing_cycle ENUM('monthly','quarterly','half_yearly','yearly','one_time','custom') NOT NULL DEFAULT 'yearly',
  seat_count INT UNSIGNED NOT NULL DEFAULT 0,
  used_seats INT UNSIGNED NOT NULL DEFAULT 0,
  unit_cost DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  annual_cost DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  credential_username VARCHAR(190) NULL,
  credential_secret_encrypted TEXT NULL,
  notes TEXT NULL,
  status TINYINT NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  KEY idx_policy_subscription_scope (company_id,entity_id,status),
  KEY idx_policy_subscription_renewal (company_id,entity_id,renewal_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_subscription_payments (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  subscription_id BIGINT UNSIGNED NOT NULL,
  amount DECIMAL(18,2) NOT NULL,
  paid_at DATETIME NOT NULL,
  payment_mode VARCHAR(60) NULL,
  reference_no VARCHAR(120) NULL,
  idempotency_key CHAR(36) NOT NULL,
  notes TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_sub_payment_idem (company_id,entity_id,idempotency_key),
  KEY idx_policy_sub_payment_scope (company_id,entity_id,subscription_id,paid_at),
  CONSTRAINT fk_policy_sub_payment_subscription FOREIGN KEY (subscription_id) REFERENCES egc_policy_subscriptions(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_rd_accounts (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  account_name VARCHAR(190) NOT NULL,
  bank_name VARCHAR(190) NOT NULL,
  account_number_encrypted TEXT NOT NULL,
  account_number_hash CHAR(64) NOT NULL,
  account_number_masked VARCHAR(100) NOT NULL,
  opening_date DATE NOT NULL,
  maturity_date DATE NOT NULL,
  tenure_months SMALLINT UNSIGNED NOT NULL,
  monthly_installment DECIMAL(18,2) NOT NULL,
  interest_rate_pa DECIMAL(9,4) NOT NULL,
  interest_method ENUM('bank_confirmed') NOT NULL DEFAULT 'bank_confirmed',
  principal_paid DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  interest_earned DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  maturity_value DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  notes TEXT NULL,
  status TINYINT NOT NULL DEFAULT 1,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_rd_account_hash (company_id,entity_id,bank_name,account_number_hash),
  KEY idx_policy_rd_scope (company_id,entity_id,status),
  KEY idx_policy_rd_maturity (company_id,entity_id,maturity_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_rd_installments (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  account_id BIGINT UNSIGNED NOT NULL,
  installment_no SMALLINT UNSIGNED NOT NULL,
  due_date DATE NOT NULL,
  due_amount DECIMAL(18,2) NOT NULL,
  paid_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  status TINYINT NOT NULL DEFAULT 1 COMMENT '1=due, 2=paid, 3=part-paid',
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_rd_installment (account_id,installment_no),
  KEY idx_policy_rd_inst_scope (company_id,entity_id,account_id,due_date),
  CONSTRAINT fk_policy_rd_installment_account FOREIGN KEY (account_id) REFERENCES egc_policy_rd_accounts(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_rd_transactions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  account_id BIGINT UNSIGNED NOT NULL,
  installment_id BIGINT UNSIGNED NOT NULL,
  transaction_type ENUM('deposit','reversal') NOT NULL DEFAULT 'deposit',
  amount DECIMAL(18,2) NOT NULL,
  paid_at DATETIME NOT NULL,
  payment_mode VARCHAR(60) NULL,
  reference_no VARCHAR(120) NULL,
  idempotency_key CHAR(36) NOT NULL,
  reversal_of BIGINT UNSIGNED NULL,
  notes TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_rd_txn_reversal (reversal_of),
  UNIQUE KEY uq_policy_rd_txn_idem (company_id,entity_id,idempotency_key),
  KEY idx_policy_rd_txn_scope (company_id,entity_id,account_id,paid_at),
  CONSTRAINT fk_policy_rd_txn_account FOREIGN KEY (account_id) REFERENCES egc_policy_rd_accounts(sno),
  CONSTRAINT fk_policy_rd_txn_installment FOREIGN KEY (installment_id) REFERENCES egc_policy_rd_installments(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_rd_closures (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  account_id BIGINT UNSIGNED NOT NULL,
  close_date DATE NOT NULL,
  closing_value DECIMAL(18,2) NOT NULL,
  penalty_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  net_payable DECIMAL(18,2) NOT NULL,
  reason TEXT NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_rd_closure (company_id,entity_id,account_id),
  CONSTRAINT fk_policy_rd_closure_account FOREIGN KEY (account_id) REFERENCES egc_policy_rd_accounts(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_renewals (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  source_type ENUM('insurance','amc','subscription','rd') NOT NULL,
  source_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(190) NOT NULL,
  provider_name VARCHAR(190) NULL,
  due_date DATE NOT NULL,
  amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  status TINYINT NOT NULL DEFAULT 1,
  renewed_at DATE NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_policy_renewal_source (company_id,entity_id,source_type,source_id),
  KEY idx_policy_renewal_scope_date (company_id,entity_id,status,due_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_documents (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  record_type VARCHAR(30) NOT NULL,
  record_id BIGINT UNSIGNED NOT NULL,
  document_type VARCHAR(100) NULL,
  original_name VARCHAR(255) NOT NULL,
  storage_path VARCHAR(500) NOT NULL,
  mime_type VARCHAR(120) NOT NULL,
  size_bytes BIGINT UNSIGNED NOT NULL,
  notes VARCHAR(1000) NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (sno),
  KEY idx_policy_document_record (company_id,entity_id,record_type,record_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_policy_audit_logs (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  module VARCHAR(40) NOT NULL,
  record_id BIGINT UNSIGNED NOT NULL,
  action VARCHAR(60) NOT NULL,
  before_json JSON NULL,
  after_json JSON NULL,
  performed_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno),
  KEY idx_policy_audit_scope (company_id,entity_id,module,record_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
