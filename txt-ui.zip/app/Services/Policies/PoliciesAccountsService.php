<?php

namespace App\Services\Policies;

use App\Models\Policies\{
    PolicyContract, InsuranceClaim, PolicySurrender, AmcMaintenance, AmcServiceReport,
    Subscription, SubscriptionPayment, RdAccount, RdInstallment, RdTransaction,
    PolicyRenewal, PolicyMaster, PolicyAudit
};
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Validation\ValidationException;
use Carbon\Carbon;

class PoliciesAccountsService
{
    public function context(): array
    {
        $user = Auth::user();
        abort_unless($user, 401);
        // The ERP navbar's workspace switcher reads Auth::user()->staff->entity_id.
        // Use that same linked staff record so the active ERP workspace is respected.
        $staff = $user->staff;
        abort_unless($staff, 403, 'Your ERP staff/entity context is unavailable.');
        $companyId = (int) ($staff->company_id ?? 0);
        $entityId = (int) ($staff->entity_id ?? 0);
        abort_if($companyId < 0 || $entityId < 0, 403, 'Invalid company/entity context.');
        return ['company_id'=>$companyId, 'entity_id'=>$entityId, 'user_id'=>(int)$staff->sno];
    }

    public function scope(Builder $query): Builder
    {
        $ctx = $this->context();
        return $query->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id']);
    }

    public function table(string $table)
    {
        $ctx=$this->context();
        return DB::table($table)->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id']);
    }

    public function list(string $type, array $filters=[])
    {
        $map=[
            'insurance'=>[PolicyContract::class,'insurance'],
            'amc'=>[PolicyContract::class,'amc'],
            'subscription'=>[Subscription::class,null],
            'rd'=>[RdAccount::class,null],
        ];
        abort_unless(isset($map[$type]),404);
        [$model,$subtype]=$map[$type];
        $q=$model::query();
        $this->scope($q);
        if($subtype) $q->where('record_type',$subtype);
        if(isset($filters['status']) && $filters['status']!=='') $q->where('status',(int)$filters['status']);
        else $q->where('status',1);
        if(!empty($filters['search'])) {
            $term=trim($filters['search']);
            $q->where(function($w) use($term,$type) {
                foreach(($type==='rd'?['account_name','bank_name','account_number_masked']:($type==='subscription'?['subscription_name','provider_name','category']:['title','provider_name','reference_number','category'])) as $col) {
                    $w->orWhere($col,'like','%'.$term.'%');
                }
            });
        }
        if(!empty($filters['from_date'])) $q->whereDate($type==='rd'?'maturity_date':($type==='subscription'?'renewal_date':'end_date'),'>=',$filters['from_date']);
        if(!empty($filters['to_date'])) $q->whereDate($type==='rd'?'maturity_date':($type==='subscription'?'renewal_date':'end_date'),'<=',$filters['to_date']);
        $perPage=max(10,min(100,(int)($filters['per_page']??25)));
        return $q->orderByDesc('sno')->paginate($perPage);
    }

    public function create(string $type,array $data)
    {
        $ctx=$this->context(); $data=$this->normalizePayload($type,$this->clean($data));
        if($type==='rd') {
            if(!empty($data['account_number'])) {
                $plain=(string)$data['account_number']; $data['account_number_encrypted']=Crypt::encryptString($plain);
                $data['account_number_hash']=hash_hmac('sha256',$plain,(string)config('app.key'));
                $data['account_number_masked']=str_repeat('*',max(0,strlen($plain)-4)).substr($plain,-4);
            }
            unset($data['account_number']);
        }
        if($type==='subscription') {
            if(!empty($data['credential_secret'])) $data['credential_secret_encrypted']=Crypt::encryptString((string)$data['credential_secret']);
            unset($data['credential_secret']);
        }
        return DB::transaction(function() use($type,$data,$ctx) {
            $payload=$data+['company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'created_by'=>$ctx['user_id'],'updated_by'=>$ctx['user_id'],'status'=>1];
            if(in_array($type,['insurance','amc'],true)) {
                $payload['record_type']=$type;
                $row=PolicyContract::create($payload);
                $this->syncRenewal($type,$row->sno,$row->title,$row->provider_name,$row->end_date,$type==='amc'?$row->contract_amount:$row->premium_amount,$ctx);
            } elseif($type==='subscription') {
                $row=Subscription::create($payload);
                $this->syncRenewal('subscription',$row->sno,$row->subscription_name,$row->provider_name,$row->renewal_date,$row->annual_cost,$ctx);
            } elseif($type==='rd') {
                $duplicate=RdAccount::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])
                    ->where('bank_name',$payload['bank_name'])->where('account_number_hash',$payload['account_number_hash'])->exists();
                if($duplicate) throw ValidationException::withMessages(['account_number'=>'This RD account is already registered for this entity.']);
                $row=RdAccount::create($payload);
                $this->generateInstallments($row);
                $this->syncRenewal('rd',$row->sno,$row->account_name,$row->bank_name,$row->maturity_date,$row->maturity_value,$ctx);
            } else abort(404);
            $this->audit('created',$type,$row->sno,null,$row->toArray());
            return $row->fresh();
        });
    }

    public function update(string $type,int $id,array $data)
    {
        $ctx=$this->context(); $data=$this->normalizePayload($type,$this->clean($data));
        if($type==='rd') {
            if(!empty($data['account_number'])) {
                $plain=(string)$data['account_number']; $data['account_number_encrypted']=Crypt::encryptString($plain);
                $data['account_number_hash']=hash_hmac('sha256',$plain,(string)config('app.key'));
                $data['account_number_masked']=str_repeat('*',max(0,strlen($plain)-4)).substr($plain,-4);
            }
            unset($data['account_number']);
        }
        if($type==='subscription') {
            if(!empty($data['credential_secret'])) $data['credential_secret_encrypted']=Crypt::encryptString((string)$data['credential_secret']);
            unset($data['credential_secret']);
        }
        return DB::transaction(function() use($type,$id,$data,$ctx) {
            $row=$this->find($type,$id,true);
            abort_unless((int)$row->status===1,409,'Archived or closed records cannot be edited.');
            $before=$row->toArray();
            $rdScheduleChanged=false;
            if($type==='rd') {
                $scheduleFields=['opening_date','maturity_date','tenure_months','monthly_installment'];
                foreach($scheduleFields as $field) {
                    if(!array_key_exists($field,$data)) continue;
                    $current=$row->{$field};
                    if(in_array($field,['opening_date','maturity_date'],true)) $current=$current ? Carbon::parse($current)->toDateString() : null;
                    elseif($field==='monthly_installment') $current=$this->minorUnits((string)$current);
                    else $current=(int)$current;
                    $incoming=in_array($field,['opening_date','maturity_date'],true)?(string)$data[$field]:($field==='monthly_installment'?$this->minorUnits((string)$data[$field]):(int)$data[$field]);
                    if($incoming!==$current) $rdScheduleChanged=true;
                }
                $hasPayments=RdTransaction::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('account_id',$id)->exists();
                if($hasPayments && $rdScheduleChanged) throw ValidationException::withMessages(['tenure_months'=>'The RD schedule cannot be changed after payments exist. Create an adjustment or a new account instead.']);
            }
            $data['updated_by']=$ctx['user_id'];
            if($type==='rd' && (!empty($data['account_number_hash']) || isset($data['bank_name']))) {
                $duplicate=RdAccount::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])
                    ->where('bank_name',$data['bank_name']??$row->bank_name)->where('account_number_hash',$data['account_number_hash']??$row->account_number_hash)
                    ->where('sno','!=',$id)->exists();
                if($duplicate) throw ValidationException::withMessages(['account_number'=>'This RD account is already registered for this entity.']);
            }
            $row->fill($data); $row->save();
            if($type==='rd' && $rdScheduleChanged) {
                RdInstallment::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('account_id',$id)->delete();
                $this->generateInstallments($row);
            }
            if(in_array($type,['insurance','amc'],true)) $this->syncRenewal($type,$row->sno,$row->title,$row->provider_name,$row->end_date,$type==='amc'?$row->contract_amount:$row->premium_amount,$ctx);
            if($type==='subscription') $this->syncRenewal('subscription',$row->sno,$row->subscription_name,$row->provider_name,$row->renewal_date,$row->annual_cost,$ctx);
            if($type==='rd') $this->syncRenewal('rd',$row->sno,$row->account_name,$row->bank_name,$row->maturity_date,$row->maturity_value,$ctx);
            $this->audit('updated',$type,$id,$before,$row->fresh()->toArray());
            return $row->fresh();
        });
    }

    public function find(string $type,int $id,bool $lock=false)
    {
        $class=match($type){'insurance','amc'=>PolicyContract::class,'subscription'=>Subscription::class,'rd'=>RdAccount::class,default=>abort(404)};
        $q=$class::query(); $this->scope($q);
        if(in_array($type,['insurance','amc'],true)) $q->where('record_type',$type);
        if($lock) $q->lockForUpdate();
        return $q->findOrFail($id);
    }

    public function archive(string $type,int $id): void
    {
        $row=$this->find($type,$id,true);
        $before=$row->toArray(); $row->status=0; $row->updated_by=$this->context()['user_id']; $row->save();
        $this->audit('archived',$type,$id,$before,$row->fresh()->toArray());
        $this->table('egc_policy_renewals')->where('source_type',$type)->where('source_id',$id)->update(['status'=>0,'updated_at'=>now()]);
    }

    protected function normalizePayload(string $type,array $data): array
    {
        if(in_array($type,['insurance','amc'],true)) {
            foreach(['sum_insured','premium_amount','contract_amount'] as $field) if(!isset($data[$field])) $data[$field]='0.00';
        } elseif($type==='subscription') {
            foreach(['seat_count','used_seats'] as $field) if(!isset($data[$field])) $data[$field]=0;
            if(!isset($data['unit_cost'])) $data['unit_cost']='0.00';
            if(empty($data['currency'])) $data['currency']='INR';
        } elseif($type==='rd') {
            foreach(['maturity_value','interest_earned'] as $field) if(!isset($data[$field])) $data[$field]='0.00';
            if(empty($data['currency'])) $data['currency']='INR';
        }
        return $data;
    }

    protected function clean(array $data): array
    {
        unset($data['company_id'],$data['entity_id'],$data['created_by'],$data['updated_by'],$data['status']);
        return $data;
    }

    protected function syncRenewal(string $source,int $id,?string $title,?string $provider,$date,$amount,array $ctx): void
    {
        if(!$date) return;
        $key=['company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'source_type'=>$source,'source_id'=>$id];
        $existing=DB::table('egc_policy_renewals')->where($key)->first();
        $values=['title'=>$title ?: 'Renewal','provider_name'=>$provider,'due_date'=>$date,'amount'=>$amount ?: '0.00','status'=>1,'updated_at'=>now()];
        if($existing) DB::table('egc_policy_renewals')->where('sno',$existing->sno)->update($values);
        else DB::table('egc_policy_renewals')->insert($key+$values+['created_at'=>now()]);
    }

    protected function generateInstallments(RdAccount $account): void
    {
        $months=(int)($account->tenure_months ?? 0);
        if($months<1 || $months>600) throw ValidationException::withMessages(['tenure_months'=>'RD tenure must be between 1 and 600 months.']);
        $date=Carbon::parse($account->opening_date);
        for($i=1;$i<=$months;$i++) {
            $date=$date->copy()->addMonthNoOverflow();
            if($i===$months && Carbon::parse($account->maturity_date)->lt($date)) {
                throw ValidationException::withMessages(['maturity_date'=>'Maturity date cannot be earlier than the final scheduled installment.']);
            }
            RdInstallment::create([
                'company_id'=>$account->company_id,'entity_id'=>$account->entity_id,'account_id'=>$account->sno,
                'installment_no'=>$i,'due_date'=>$date->toDateString(),'due_amount'=>$account->monthly_installment,
                'paid_amount'=>'0.00','status'=>1,'created_at'=>now(),'updated_at'=>now()
            ]);
        }
    }

    public function recordRdPayment(int $accountId,int $installmentId,array $data)
    {
        $ctx=$this->context();
        return DB::transaction(function() use($accountId,$installmentId,$data,$ctx) {
            $account=RdAccount::query()->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->lockForUpdate()->findOrFail($accountId);
            abort_unless((int)$account->status===1,409,'RD account is not active.');
            $inst=RdInstallment::query()->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('account_id',$accountId)->lockForUpdate()->findOrFail($installmentId);
            $amount=(string)$data['amount'];
            $key=(string)($data['idempotency_key']??Str::uuid());
            $existing=RdTransaction::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('idempotency_key',$key)->first();
            if($existing) {
                if((int)$existing->account_id!==$accountId || (int)$existing->installment_id!==$installmentId)
                    throw ValidationException::withMessages(['idempotency_key'=>'This request key was already used for another payment.']);
                return $existing;
            }
            $remaining=DB::table('egc_policy_rd_installments')->where('sno',$inst->sno)->selectRaw('(due_amount-paid_amount) as balance')->value('balance');
            if($this->minorUnits($amount)>$this->minorUnits((string)$remaining)) throw ValidationException::withMessages(['amount'=>'Payment cannot exceed the outstanding installment balance.']);
            $txn=RdTransaction::create([
                'company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'account_id'=>$accountId,'installment_id'=>$installmentId,
                'transaction_type'=>'deposit','amount'=>$amount,'paid_at'=>$data['paid_at']??now(),'payment_mode'=>$data['payment_mode']??null,
                'reference_no'=>$data['reference_no']??null,'idempotency_key'=>$key,'notes'=>$data['notes']??null,
                'created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()
            ]);
            DB::table('egc_policy_rd_installments')->where('sno',$inst->sno)->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->increment('paid_amount',$amount,['updated_at'=>now()]);
            DB::table('egc_policy_rd_accounts')->where('sno',$accountId)->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->increment('principal_paid',$amount,['updated_at'=>now()]);
            DB::table('egc_policy_rd_installments')->where('sno',$inst->sno)->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->update([
                'status'=>$this->minorUnits((string)$remaining)===$this->minorUnits($amount)?2:3,'updated_at'=>now()
            ]);
            $this->audit('rd_payment','rd_account',$accountId,null,$txn->toArray());
            return $txn;
        });
    }

    public function reverseRdPayment(int $transactionId,string $reason)
    {
        $ctx=$this->context();
        return DB::transaction(function() use($transactionId,$reason,$ctx) {
            $original=RdTransaction::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->lockForUpdate()->findOrFail($transactionId);
            abort_unless($original->transaction_type==='deposit',409,'Only deposit transactions can be reversed.');
            $already=RdTransaction::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('reversal_of',$original->sno)->exists();
            abort_if($already,409,'This payment has already been reversed.');
            $account=RdAccount::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->lockForUpdate()->findOrFail($original->account_id);
            $installment=RdInstallment::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('account_id',$account->sno)->lockForUpdate()->findOrFail($original->installment_id);
            if($this->minorUnits((string)$installment->paid_amount)<$this->minorUnits((string)$original->amount) ||
               $this->minorUnits((string)$account->principal_paid)<$this->minorUnits((string)$original->amount)) {
                throw ValidationException::withMessages(['payment'=>'Current paid totals do not support this reversal.']);
            }
            RdInstallment::where('sno',$installment->sno)->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->decrement('paid_amount',$original->amount,['updated_at'=>now()]);
            RdAccount::where('sno',$account->sno)->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->decrement('principal_paid',$original->amount,['updated_at'=>now()]);
            $fresh=RdInstallment::findOrFail($installment->sno);
            $status=$this->minorUnits((string)$fresh->paid_amount)===0?1:($this->minorUnits((string)$fresh->paid_amount)>=$this->minorUnits((string)$fresh->due_amount)?2:3);
            RdInstallment::where('sno',$fresh->sno)->update(['status'=>$status,'updated_at'=>now()]);
            $reversal=RdTransaction::create([
                'company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'account_id'=>$account->sno,'installment_id'=>$installment->sno,
                'transaction_type'=>'reversal','amount'=>$original->amount,'paid_at'=>now(),'payment_mode'=>$original->payment_mode,
                'reference_no'=>$original->reference_no,'idempotency_key'=>(string)Str::uuid(),'reversal_of'=>$original->sno,
                'notes'=>$reason,'created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()
            ]);
            $this->audit('rd_payment_reversed','rd_account',$account->sno,$original->toArray(),$reversal->toArray());
            return $reversal;
        });
    }

    public function recordSubscriptionPayment(int $id,array $data)
    {
        $ctx=$this->context();
        return DB::transaction(function() use($id,$data,$ctx) {
            $sub=Subscription::query()->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->lockForUpdate()->findOrFail($id);
            abort_unless((int)$sub->status===1,409,'Subscription is not active.');
            $key=(string)($data['idempotency_key']??Str::uuid());
            $exists=SubscriptionPayment::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('idempotency_key',$key)->first();
            if($exists) {
                if((int)$exists->subscription_id!==$id) throw ValidationException::withMessages(['idempotency_key'=>'This request key was already used for another subscription.']);
                return $exists;
            }
            $payment=SubscriptionPayment::create([
                'company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'subscription_id'=>$id,
                'amount'=>(string)$data['amount'],'paid_at'=>$data['paid_at']??now(),'payment_mode'=>$data['payment_mode']??null,
                'reference_no'=>$data['reference_no']??null,'idempotency_key'=>$key,'notes'=>$data['notes']??null,
                'created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()
            ]);
            $this->audit('subscription_payment','subscription',$id,null,$payment->toArray());
            return $payment;
        });
    }

    public function contractPayments(string $type,int $contractId)
    {
        $contract=$this->find($type,$contractId);
        abort_unless(in_array($type,['insurance','amc'],true),404);
        $ctx=$this->context();
        return DB::table('egc_policy_contract_payments')->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])
            ->where('contract_id',$contract->sno)->where('record_type',$type)->orderByDesc('paid_at')->paginate(50, ['sno','contract_id','record_type','payment_kind','due_date','amount','paid_at','payment_mode','reference_no','notes']);
    }

    public function recordContractPayment(string $type,int $contractId,array $data)
    {
        abort_unless(in_array($type,['insurance','amc'],true),404);
        $ctx=$this->context();
        return DB::transaction(function() use($type,$contractId,$data,$ctx) {
            $contract=$this->find($type,$contractId,true);
            abort_unless((int)$contract->status===1,409,'Contract is not active.');
            $key=(string)($data['idempotency_key']??Str::uuid());
            $existing=DB::table('egc_policy_contract_payments')->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('idempotency_key',$key)->first();
            if($existing) {
                if((int)$existing->contract_id!==$contractId || $existing->record_type!==$type)
                    throw ValidationException::withMessages(['idempotency_key'=>'This request key was already used for another contract.']);
                return $existing;
            }
            $id=DB::table('egc_policy_contract_payments')->insertGetId([
                'company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'contract_id'=>$contractId,'record_type'=>$type,
                'payment_kind'=>$data['payment_kind'],'due_date'=>$data['due_date']??null,'amount'=>(string)$data['amount'],
                'paid_at'=>$data['paid_at']??now(),'payment_mode'=>$data['payment_mode']??null,'reference_no'=>$data['reference_no']??null,
                'idempotency_key'=>$key,'notes'=>$data['notes']??null,'created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()
            ]);
            $payment=DB::table('egc_policy_contract_payments')->where('sno',$id)->first();
            $this->audit('contract_payment','contract',$contractId,null,(array)$payment);
            return $payment;
        });
    }

    public function createClaim(int $contractId,array $data)
    {
        $ctx=$this->context(); $contract=PolicyContract::query()->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('record_type','insurance')->where('status',1)->findOrFail($contractId);
        return DB::transaction(function() use($contract,$data,$ctx) {
            $data['approved_amount']=$data['approved_amount']??'0.00';
            $data['settled_amount']=$data['settled_amount']??'0.00';
            $claim=InsuranceClaim::create($data+['company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'contract_id'=>$contract->sno,'created_by'=>$ctx['user_id'],'updated_by'=>$ctx['user_id'],'status'=>1]);
            $this->audit('claim_created','claim',$claim->sno,null,$claim->toArray()); return $claim;
        });
    }

    public function dashboard(): array
    {
        $ctx=$this->context();
        $contract=PolicyContract::query()->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('status',1);
        $subs=Subscription::query()->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('status',1);
        $rd=RdAccount::query()->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('status',1);
        $today=now()->toDateString(); $soon=now()->addDays(30)->toDateString();
        return [
            'insurance_count'=>(clone $contract)->where('record_type','insurance')->count(),
            'amc_count'=>(clone $contract)->where('record_type','amc')->count(),
            'subscription_count'=>(clone $subs)->count(),
            'rd_accounts_count'=>(clone $rd)->count(),
            'premium_total'=>(clone $contract)->where('record_type','insurance')->selectRaw('CAST(COALESCE(SUM(premium_amount),0) AS CHAR) AS total')->value('total'),
            'amc_total'=>(clone $contract)->where('record_type','amc')->selectRaw('CAST(COALESCE(SUM(contract_amount),0) AS CHAR) AS total')->value('total'),
            'subscription_annual_total'=>(clone $subs)->selectRaw('CAST(COALESCE(SUM(annual_cost),0) AS CHAR) AS total')->value('total'),
            'rd_principal_total'=>(clone $rd)->selectRaw('CAST(COALESCE(SUM(principal_paid),0) AS CHAR) AS total')->value('total'),
            'rd_monthly_allocation'=>(clone $rd)->selectRaw('CAST(COALESCE(SUM(monthly_installment),0) AS CHAR) AS total')->value('total'),
            'insurance_coverage_total'=>(clone $contract)->where('record_type','insurance')->selectRaw('CAST(COALESCE(SUM(sum_insured),0) AS CHAR) AS total')->value('total'),
            'open_claims'=>InsuranceClaim::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->whereIn('status',['submitted','under_review','approved'])->count(),
            'renewals_due_30_days'=>$this->table('egc_policy_renewals')->where('status',1)->whereBetween('due_date',[$today,$soon])->count(),
            'overdue_renewals'=>$this->table('egc_policy_renewals')->where('status',1)->whereDate('due_date','<',$today)->count(),
            'recent_renewals'=>$this->table('egc_policy_renewals')->where('status',1)->whereDate('due_date','<=',$soon)->orderBy('due_date')->limit(10)->get(['sno','source_type','source_id','title','provider_name','due_date','amount','status']),
        ];
    }

    public function masters(?string $type=null)
    {
        $q=$this->table('egc_policy_masters')->where('status',1);
        if($type) $q->where('master_type',$type);
        return $q->orderBy('master_name')->get(['sno','master_type','master_name']);
    }

    public function saveMaster(array $data,?int $id=null)
    {
        $ctx=$this->context();
        if($id) {
            $row=$this->table('egc_policy_masters')->where('sno',$id)->first();
            abort_unless($row,404);
            $duplicate=$this->table('egc_policy_masters')->where('master_type',$row->master_type)
                ->whereRaw('LOWER(master_name)=?', [mb_strtolower($data['master_name'])])->where('status',1)->where('sno','!=',$id)->exists();
            if($duplicate) throw ValidationException::withMessages(['master_name'=>'This value already exists.']);
            $this->table('egc_policy_masters')->where('sno',$id)->update(['master_name'=>$data['master_name'],'updated_by'=>$ctx['user_id'],'updated_at'=>now()]);
            $updated=$this->table('egc_policy_masters')->where('sno',$id)->first();
            $this->audit('master_updated','master',$id,(array)$row,(array)$updated);
            return $updated;
        }
        $exists=$this->table('egc_policy_masters')->where('master_type',$data['master_type'])->whereRaw('LOWER(master_name)=?', [mb_strtolower($data['master_name'])])->where('status',1)->exists();
        if($exists) throw ValidationException::withMessages(['master_name'=>'This value already exists.']);
        $id=$this->table('egc_policy_masters')->insertGetId([
            'master_type'=>$data['master_type'],'master_name'=>$data['master_name'],'status'=>1,
            'created_by'=>$ctx['user_id'],'updated_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now(),
            'company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id']
        ]);
        $created=$this->table('egc_policy_masters')->where('sno',$id)->first();
        $this->audit('master_created','master',$id,null,(array)$created);
        return $created;
    }

    public function logAction(string $action,string $module,int $recordId,$before=null,$after=null): void
    {
        $this->audit($action,$module,$recordId,$before,$after);
    }

    protected function minorUnits(string $value): int
    {
        $value=trim($value);
        if(!preg_match('/^\\d{1,14}(?:\\.\\d{1,2})?$/',$value)) {
            throw ValidationException::withMessages(['amount'=>'Amount must be a non-negative decimal with up to two decimal places.']);
        }
        [$whole,$fraction]=array_pad(explode('.',$value,2),2,'');
        return ((int)$whole*100)+(int)str_pad($fraction,2,'0');
    }

    protected function audit(string $action,string $module,int $recordId,$before,$after): void
    {
        $ctx=$this->context();
        PolicyAudit::create([
            'company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'module'=>$module,'record_id'=>$recordId,
            'action'=>$action,'before_json'=>$before,'after_json'=>$after,'performed_by'=>$ctx['user_id'],'created_at'=>now()
        ]);
    }
}
