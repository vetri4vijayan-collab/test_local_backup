<?php
namespace App\Http\Resources\Policies;
use Illuminate\Http\Resources\Json\JsonResource;
class RdAccountResource extends JsonResource {
 public function toArray($request): array { return [
  'id'=>$this->sno,'account_name'=>$this->account_name,'bank_name'=>$this->bank_name,
  'account_number_masked'=>$this->account_number_masked,'opening_date'=>$this->opening_date?->toDateString(),
  'maturity_date'=>$this->maturity_date?->toDateString(),'tenure_months'=>(int)$this->tenure_months,
  'monthly_installment'=>$this->monthly_installment,'interest_rate_pa'=>$this->interest_rate_pa,
  'interest_method'=>$this->interest_method,'principal_paid'=>$this->principal_paid,
  'interest_earned'=>$this->interest_earned,'maturity_value'=>$this->maturity_value,'status'=>(int)$this->status
 ]; }
}
