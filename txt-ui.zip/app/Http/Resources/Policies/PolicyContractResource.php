<?php
namespace App\Http\Resources\Policies;
use Illuminate\Http\Resources\Json\JsonResource;
class PolicyContractResource extends JsonResource {
 public function toArray($request): array { return [
  'id'=>$this->sno,'type'=>$this->record_type,'title'=>$this->title,'reference_number'=>$this->reference_number,
  'policy_number'=>$this->policy_number,'provider_name'=>$this->provider_name,'category'=>$this->category,
  'owner_name'=>$this->owner_name,'start_date'=>$this->start_date?->toDateString(),'end_date'=>$this->end_date?->toDateString(),
  'next_due_date'=>$this->next_due_date?->toDateString(),'sum_insured'=>$this->sum_insured,
  'premium_amount'=>$this->premium_amount,'contract_amount'=>$this->contract_amount,'status'=>(int)$this->status,'notes'=>$this->notes
 ]; }
}
