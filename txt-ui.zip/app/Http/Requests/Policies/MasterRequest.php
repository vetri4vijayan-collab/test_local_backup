<?php
namespace App\Http\Requests\Policies;
use Illuminate\Foundation\Http\FormRequest;
class MasterRequest extends FormRequest {
 public function authorize(): bool { return true; }
 public function rules(): array { return [
  'master_type'=>['required','in:provider,category,payment_frequency,subscription_type,rd_bank,claim_type,maintenance_type'],
  'master_name'=>['required','string','max:160']
 ]; }
}
