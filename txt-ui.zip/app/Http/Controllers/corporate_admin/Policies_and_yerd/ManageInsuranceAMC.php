<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class ManageInsuranceAMC extends Controller
{
    public function index()
    {
        $user = Auth::user();
        abort_unless($user && $user->hasPermission('Corporate Admin', 'Policies & RD Accounts', 'Manage Insurance & AMC'), 403);
        return view('content.corporate_admin.Policies_and_yerd.manage_insurance_Amc.manage_insurance_AMC');
    }
}
