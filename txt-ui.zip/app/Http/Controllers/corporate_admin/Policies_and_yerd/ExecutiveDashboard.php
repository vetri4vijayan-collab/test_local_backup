<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class ExecutiveDashboard extends Controller
{
    public function index()
    {
        $user = Auth::user();
        abort_unless($user && $user->hasPermission('Corporate Admin', 'Policies & RD Accounts', 'Executive Dashbaord'), 403);
        return view('content.corporate_admin.Policies_and_yerd.executive_dashboard.exe_dashboard');
    }
}
