<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class PolicyRenewal extends Model {
 protected $table='egc_policy_renewals'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['due_date'=>'date','renewed_at'=>'date','amount'=>'decimal:2'];
}
