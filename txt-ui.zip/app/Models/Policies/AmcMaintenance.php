<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class AmcMaintenance extends Model {
 protected $table='egc_policy_maintenance'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['scheduled_at'=>'datetime','completed_at'=>'datetime','estimated_cost'=>'decimal:2','actual_cost'=>'decimal:2'];
}
