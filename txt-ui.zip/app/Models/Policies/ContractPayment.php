<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class ContractPayment extends Model {
 protected $table='egc_policy_contract_payments'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['due_date'=>'date','paid_at'=>'datetime','amount'=>'decimal:2'];
}
