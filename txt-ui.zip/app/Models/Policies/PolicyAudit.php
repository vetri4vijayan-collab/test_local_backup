<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class PolicyAudit extends Model {
 protected $table='egc_policy_audit_logs'; protected $primaryKey='sno'; public $timestamps=false; protected $guarded=[];
 protected $casts=['before_json'=>'array','after_json'=>'array','created_at'=>'datetime'];
}
