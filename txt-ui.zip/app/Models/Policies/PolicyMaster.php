<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class PolicyMaster extends Model {
 protected $table='egc_policy_masters'; protected $primaryKey='sno'; protected $guarded=[];
}
