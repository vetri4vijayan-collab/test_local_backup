<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class InsuranceClaim extends Model {
 protected $table='egc_policy_claims'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['claim_date'=>'date','settled_at'=>'date','claimed_amount'=>'decimal:2','approved_amount'=>'decimal:2','settled_amount'=>'decimal:2'];
}
