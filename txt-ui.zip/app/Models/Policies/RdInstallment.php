<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class RdInstallment extends Model {
 protected $table='egc_policy_rd_installments'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['due_date'=>'date','due_amount'=>'decimal:2','paid_amount'=>'decimal:2','status'=>'integer'];
}
