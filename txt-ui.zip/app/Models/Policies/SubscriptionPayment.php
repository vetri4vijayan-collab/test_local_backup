<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class SubscriptionPayment extends Model {
 protected $table='egc_policy_subscription_payments'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['paid_at'=>'datetime','amount'=>'decimal:2'];
}
