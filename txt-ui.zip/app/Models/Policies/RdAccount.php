<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class RdAccount extends Model {
 protected $table='egc_policy_rd_accounts'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['opening_date'=>'date','maturity_date'=>'date','monthly_installment'=>'decimal:2','interest_rate_pa'=>'decimal:4','principal_paid'=>'decimal:2','interest_earned'=>'decimal:2','maturity_value'=>'decimal:2','status'=>'integer'];
 public function installments(){return $this->hasMany(RdInstallment::class,'account_id','sno');}
 public function transactions(){return $this->hasMany(RdTransaction::class,'account_id','sno');}
}
