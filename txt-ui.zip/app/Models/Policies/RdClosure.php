<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class RdClosure extends Model {
 protected $table='egc_policy_rd_closures'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['close_date'=>'date','closing_value'=>'decimal:2','penalty_amount'=>'decimal:2','net_payable'=>'decimal:2'];
}
