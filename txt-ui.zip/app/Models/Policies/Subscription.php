<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class Subscription extends Model {
 protected $table='egc_policy_subscriptions'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['start_date'=>'date','renewal_date'=>'date','unit_cost'=>'decimal:2','annual_cost'=>'decimal:2','seat_count'=>'integer','used_seats'=>'integer'];
}
