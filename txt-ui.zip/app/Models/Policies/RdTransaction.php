<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class RdTransaction extends Model {
 protected $table='egc_policy_rd_transactions'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['paid_at'=>'datetime','amount'=>'decimal:2','reversed_at'=>'datetime'];
}
