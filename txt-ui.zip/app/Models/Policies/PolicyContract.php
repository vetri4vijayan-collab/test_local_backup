<?php
namespace App\Models\Policies;

use Illuminate\Database\Eloquent\Model;

class PolicyContract extends Model
{
    protected $table = 'egc_policy_contracts';
    protected $primaryKey = 'sno';
    protected $guarded = [];
    protected $casts = [
        'start_date' => 'date', 'end_date' => 'date', 'next_due_date' => 'date',
        'sum_insured' => 'decimal:2', 'premium_amount' => 'decimal:2',
        'contract_amount' => 'decimal:2', 'status' => 'integer',
    ];
    public function claims(){ return $this->hasMany(InsuranceClaim::class, 'contract_id', 'sno'); }
    public function documents(){ return $this->hasMany(PolicyDocument::class, 'contract_id', 'sno'); }
}
