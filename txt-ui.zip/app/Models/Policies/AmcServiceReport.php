<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class AmcServiceReport extends Model {
 protected $table='egc_policy_service_reports'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['service_date'=>'date','rating'=>'integer','service_cost'=>'decimal:2'];
}
