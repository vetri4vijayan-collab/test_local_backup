<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class PolicyDocument extends Model {
 protected $table='egc_policy_documents'; protected $primaryKey='sno'; protected $guarded=[];
}
