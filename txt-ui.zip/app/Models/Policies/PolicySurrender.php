<?php
namespace App\Models\Policies;
use Illuminate\Database\Eloquent\Model;
class PolicySurrender extends Model {
 protected $table='egc_policy_surrenders'; protected $primaryKey='sno'; protected $guarded=[];
 protected $casts=['surrender_date'=>'date','surrender_value'=>'decimal:2','penalty_amount'=>'decimal:2','net_payable'=>'decimal:2'];
}
