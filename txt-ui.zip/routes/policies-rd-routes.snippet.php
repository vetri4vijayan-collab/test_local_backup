
  // Policies & RD Accounts: authenticated, tenant-scoped data workflows.
  Route::prefix('policies-data')->name('policies.data.')->group(function () {
      $controller = \App\Http\Controllers\corporate_admin\Policies_and_yerd\PoliciesAccountsController::class;
      Route::get('/dashboard', [$controller, 'dashboard'])->name('dashboard');
      Route::get('/renewals', [$controller, 'renewals'])->name('renewals');
      Route::post('/renewals/{id}/complete', [$controller, 'completeRenewal'])->whereNumber('id')->name('renewals.complete');
      Route::get('/rd-schedule', [$controller, 'rdSchedule'])->name('rd.schedule');
      Route::get('/masters', [$controller, 'masters'])->name('masters.index');
      Route::post('/masters', [$controller, 'saveMaster'])->name('masters.store');
      Route::put('/masters/{id}', [$controller, 'saveMaster'])->whereNumber('id')->name('masters.update');
      Route::delete('/masters/{id}', [$controller, 'deleteMaster'])->whereNumber('id')->name('masters.destroy');

      Route::post('/rd/{id}/close', [$controller, 'closeRd'])->whereNumber('id')->name('rd.close');
      Route::post('/rd-transactions/{transactionId}/reverse', [$controller, 'reverseRdPayment'])->whereNumber('transactionId')->name('rd.transactions.reverse');
      Route::get('/rd/{id}/transactions', [$controller, 'rdTransactions'])->whereNumber('id')->name('rd.transactions');
      Route::get('/rd/{id}/installments', [$controller, 'rdInstallments'])->whereNumber('id')->name('rd.installments');
      Route::post('/rd/{id}/installments/{installment}/payments', [$controller, 'rdPayment'])->whereNumber('id')->whereNumber('installment')->name('rd.payments.store');
      Route::get('/subscription-payments', [$controller, 'subscriptionPayments'])->name('subscriptions.payments.index');
      Route::post('/subscriptions/{id}/payments', [$controller, 'subscriptionPayment'])->whereNumber('id')->name('subscriptions.payments.store');

      Route::get('/{type}/{id}/payments', [$controller, 'contractPayments'])->where('type', 'insurance|amc')->whereNumber('id')->name('contracts.payments.index');
      Route::post('/{type}/{id}/payments', [$controller, 'storeContractPayment'])->where('type', 'insurance|amc')->whereNumber('id')->name('contracts.payments.store');
      Route::put('/insurance/{id}/claims/{claimId}', [$controller, 'updateClaim'])->whereNumber('id')->whereNumber('claimId')->name('insurance.claims.update');
      Route::get('/insurance/{id}/claims', [$controller, 'claims'])->whereNumber('id')->name('insurance.claims.index');
      Route::post('/insurance/{id}/claims', [$controller, 'storeClaim'])->whereNumber('id')->name('insurance.claims.store');
      Route::post('/insurance/{id}/surrender', [$controller, 'surrender'])->whereNumber('id')->name('insurance.surrender');
      Route::get('/amc/{id}/maintenance', [$controller, 'maintenance'])->whereNumber('id')->name('amc.maintenance.index');
      Route::post('/amc/{id}/maintenance', [$controller, 'storeMaintenance'])->whereNumber('id')->name('amc.maintenance.store');
      Route::post('/amc/{id}/service-reports', [$controller, 'storeServiceReport'])->whereNumber('id')->name('amc.service-reports.store');

      Route::get('/{type}/{id}/documents', [$controller, 'documents'])->where('type', 'insurance|amc|subscription|rd')->whereNumber('id')->name('documents.index');
      Route::post('/{type}/{id}/documents', [$controller, 'uploadDocument'])->where('type', 'insurance|amc|subscription|rd')->whereNumber('id')->name('documents.store');
      Route::get('/documents/{id}', [$controller, 'downloadDocument'])->whereNumber('id')->name('documents.download');

      Route::get('/{type}', [$controller, 'index'])->where('type', 'insurance|amc|subscription|rd')->name('index');
      Route::post('/{type}', [$controller, 'store'])->where('type', 'insurance|amc|subscription|rd')->name('store');
      Route::get('/{type}/{id}', [$controller, 'show'])->where('type', 'insurance|amc|subscription|rd')->whereNumber('id')->name('show');
      Route::put('/{type}/{id}', [$controller, 'update'])->where('type', 'insurance|amc|subscription|rd')->whereNumber('id')->name('update');
      Route::delete('/{type}/{id}', [$controller, 'destroy'])->where('type', 'insurance|amc|subscription|rd')->whereNumber('id')->name('destroy');
  });
