<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

/**
 * Blocks login requests from IP addresses not present in egc_allowed_ips.
 * Keep this middleware on the same login routes where the current version runs.
 */
class RestrictLoginIP
{
    public function handle(Request $request, Closure $next)
    {
        // Request::ip() honours Laravel's trusted-proxy configuration.
        $userIp = (string) $request->ip();

        try {
            $isAllowed = DB::table('egc_allowed_ips')
                ->where('ip_address', $userIp)
                ->where('status', 0)
                ->exists();
        } catch (Throwable $exception) {
            // Fail closed: a database failure must not bypass the IP restriction.
            Log::critical('Login IP restriction could not verify the client IP.', [
                'ip_address' => $userIp,
                'message' => $exception->getMessage(),
            ]);

            abort(503, 'Unable to verify network access at this time. Please try again later.');
        }

        if (!$isAllowed) {
            $this->recordUnauthorizedAttempt($request, $userIp);
            abort(403, 'Access denied: Unauthorized IP address.');
        }

        return $next($request);
    }

    private function recordUnauthorizedAttempt(Request $request, string $userIp): void
    {
        $now = now();
        $userAgent = (string) $request->userAgent();
        $client = $this->parseClient($userAgent);
        $referer = $this->safeReferer((string) $request->headers->get('referer', ''));

        $validatedIp = filter_var($userIp, FILTER_VALIDATE_IP);
        $ipVersion = $validatedIp === false
            ? 'Unknown'
            : (filter_var($userIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? 'IPv6' : 'IPv4');

        try {
            DB::table('egc_unauthorized_ip_logs')->insert([
                'request_id' => (string) Str::uuid(),
                'entity_id' => 0,
                'ip_address' => substr($userIp, 0, 45),
                'ip_version' => $ipVersion,
                'request_method' => substr($request->method(), 0, 10),
                'response_status' => 403,
                'request_path' => substr('/' . ltrim($request->path(), '/'), 0, 512),
                'user_agent' => $userAgent !== '' ? substr($userAgent, 0, 2000) : null,
                'referer' => $referer,
                'accept_language' => substr((string) $request->headers->get('accept-language', ''), 0, 255) ?: null,
                'device_type' => $client['device_type'],
                'browser' => $client['browser'],
                'platform' => $client['platform'],
                'is_bot' => $client['is_bot'] ? 1 : 0,
                'blocked_at' => $now,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        } catch (Throwable $exception) {
            // Do not let an audit-table failure turn a blocked request into an allowed one.
            Log::error('Unauthorized login IP attempt could not be written to the audit table.', [
                'ip_address' => $userIp,
                'request_path' => '/' . ltrim($request->path(), '/'),
                'message' => $exception->getMessage(),
            ]);
        }
    }

    private function safeReferer(string $referer): ?string
    {
        if ($referer === '') {
            return null;
        }

        $parts = parse_url($referer);
        if (!is_array($parts) || empty($parts['host'])) {
            return null;
        }

        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        if (!in_array($scheme, ['http', 'https'], true)) {
            return null;
        }

        $safe = $scheme . '://' . $parts['host'];
        if (!empty($parts['port'])) {
            $safe .= ':' . (int) $parts['port'];
        }

        // Query strings and fragments are intentionally omitted to avoid logging tokens.
        $safe .= $parts['path'] ?? '';

        return $safe !== '' ? substr($safe, 0, 1024) : null;
    }

    private function parseClient(string $userAgent): array
    {
        $ua = strtolower($userAgent);
        $isBot = $ua !== '' && (bool) preg_match(
            '/bot|crawler|spider|headless|slurp|preview|monitoring|uptime|curl|wget|python-requests|scrapy/i',
            $ua
        );

        if ($isBot) {
            $deviceType = 'Bot';
        } elseif (preg_match('/ipad|tablet|playbook|silk/i', $ua)
            || (strpos($ua, 'android') !== false && strpos($ua, 'mobile') === false)) {
            $deviceType = 'Tablet';
        } elseif (preg_match('/mobile|iphone|ipod|android|windows phone/i', $ua)) {
            $deviceType = 'Mobile';
        } elseif ($ua !== '') {
            $deviceType = 'Desktop';
        } else {
            $deviceType = 'Unknown';
        }

        if (preg_match('/edg(?:e|a|ios)?\/[\d.]+/i', $userAgent)) {
            $browser = 'Microsoft Edge';
        } elseif (preg_match('/opr\/[\d.]+|opera(?: mini)?\/[\d.]+/i', $userAgent)) {
            $browser = 'Opera';
        } elseif (preg_match('/(?:chrome|crios)\/[\d.]+/i', $userAgent)
            && !preg_match('/edg(?:e|a|ios)?\/[\d.]+/i', $userAgent)) {
            $browser = 'Chrome';
        } elseif (preg_match('/(?:firefox|fxios)\/[\d.]+/i', $userAgent)) {
            $browser = 'Firefox';
        } elseif (preg_match('/safari\/[\d.]+/i', $userAgent)
            && !preg_match('/(?:chrome|crios|chromium)\/[\d.]+/i', $userAgent)) {
            $browser = 'Safari';
        } elseif (preg_match('/msie|trident\/[\d.]+/i', $userAgent)) {
            $browser = 'Internet Explorer';
        } else {
            $browser = 'Unknown';
        }

        if (preg_match('/windows nt/i', $userAgent)) {
            $platform = 'Windows';
        } elseif (preg_match('/android/i', $userAgent)) {
            $platform = 'Android';
        } elseif (preg_match('/iphone|ipad|ipod/i', $userAgent)) {
            $platform = 'iOS';
        } elseif (preg_match('/mac os x|macintosh/i', $userAgent)) {
            $platform = 'macOS';
        } elseif (preg_match('/linux/i', $userAgent)) {
            $platform = 'Linux';
        } else {
            $platform = 'Unknown';
        }

        return [
            'device_type' => $deviceType,
            'browser' => $browser,
            'platform' => $platform,
            'is_bot' => $isBot,
        ];
    }
}
