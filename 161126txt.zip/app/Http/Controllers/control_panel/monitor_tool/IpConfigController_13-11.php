<?php
namespace App\Http\Controllers\control_panel\monitor_tool;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\IpConfigModel;

use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class IpConfigController extends Controller
{
  public function index(Request $request)
  {
    $startTime = microtime(true);
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';


    $helper = new \App\Helpers\Helpers();
    $general_setting = $helper->general_setting_data();

    $staffData = DB::table('egc_allowed_ips')->where('egc_allowed_ips.status', '!=', 2);
    if ($search_filter != '') {
      $staffData->where(function ($subquery) use ($search_filter) {
        $subquery->where('egc_allowed_ips.ip_name', 'LIKE', "%{$search_filter}%")
          ->orWhere('egc_allowed_ips.ip_address', 'LIKE', "%{$search_filter}%");
      });
    }
    $staffData = $staffData->orderBy('egc_allowed_ips.sno', 'desc')->paginate($perpage);

    if ($request->ajax()) {

      $data = $staffData->map(function ($item) use ($helper) {

        $helper = new \App\Helpers\Helpers();
        $general_setting = $helper->general_setting_data();

        return [
          'sno' => $item->sno,
          'status' => $item->status,
          'ip_name' => $item->ip_name,
          'ip_address' => $item->ip_address,
          'data' => $item,
          'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
        ];
      });

      return response()->json([
        'data' => $data,
        'current_page' => $staffData->currentPage(),
        'last_page' => $staffData->lastPage(),
        'total' => $staffData->total(),
      ]);
    }


    return view('content.control_panel.monitor_tool.ip_config.ip_config_list', [
      'perpage' => $perpage,
    ]);
  }

  public function Status($id, Request $request)
  {

    $user_id = $request->user()->user_id;

    $staff =  IpConfigModel::where('sno', $id)->first();
    $staff->status = $request->input('status', 0);
    $staff->updated_by = $user_id;
    $staff->update();
    if ($staff) {
      $EntityData=DB::table('egc_entity')->where('status',0)->get();
        
      if($EntityData){
          $payload=[
            'sno' => $staff->sno,
            'status' => $staff->status,
          ];

          foreach($EntityData as $entity){
            if($entity->entity_base_url){
                $this->dispatchUpdateWebhooks($payload, $user_id, 'STATUS_UPDATE_IP_ADDRESS',$entity->sno);
            }
          }   
      }
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    }
  }

  public function Delete($id,Request $request)
  {
    $user_id = $request->user()->user_id;
    $upd_StaffModel = IpConfigModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->updated_by = $user_id;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      $EntityData=DB::table('egc_entity')->where('status',0)->get();
        
      if($EntityData){
          $payload=[
            'sno' => $upd_StaffModel->sno,
            'status' => 2,
          ];

          foreach($EntityData as $entity){
            if($entity->entity_base_url){
                $this->dispatchUpdateWebhooks($payload, $user_id, 'DELETE_IP_ADDRESS',$entity->sno);
            }
          }   
      }

      return response([
        'status'    => 200,
        'message'   => 'Staff Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Staff ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function Save(Request $request)
  {

      $validator = Validator::make($request->all(), [
        'ip_name' => 'required',
        'ip_address' => 'required'
      ]);

      if ($validator->fails()) {
        return response()->json([
          'status' => 401,
          'message' => 'Incorrect format input fields',
          'error_msg' => $validator->errors()->all(),
          'data' => null,
        ], 200);
      }

      $user_id = $request->user()->user_id;

      $ip_name = $request->ip_name ;
      $ip_address = $request->ip_address ;
      
      $ipAlreadyExistCheck = IpConfigModel::where('ip_address',$ip_address)->where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if ($ipAlreadyExistCheck) {
        return response()->json([
          'status' => 401,
          'message' => 'IP Address Already Exit',
          'error_msg' => 'IP Address Already Exit',
          'data' => null,
        ], 200);
      }
   
      // Create new staff record
      $add_ipaddress = new IpConfigModel();
      $add_ipaddress->ip_address = $ip_address;
      $add_ipaddress->ip_name = $ip_name;
      $add_ipaddress->created_by = $request->user()->user_id;
      $add_ipaddress->updated_by = $request->user()->user_id;
      $add_ipaddress->save();

      $EntityData=DB::table('egc_entity')->where('status',0)->get();
        
      if($EntityData){
          $payload=[
            'sno' => $add_ipaddress->sno,
            'ip_address' => $add_ipaddress->ip_address,
            'ip_name' => $add_ipaddress->ip_name,
          ];

          foreach($EntityData as $entity){
            if($entity->entity_base_url){
                $this->dispatchUpdateWebhooks($payload, $user_id, 'ADD_IP_ADDRESS',$entity->sno);
            }
          }   
      }

      return response()->json([
        'status' => 200,
        'message' => 'IP Address Added Successfully',
        'error_msg' => null,
        'data' => null,
      ], 200);
   
  }

  public function Update(Request $request)
  {
      $validator = Validator::make($request->all(), [
        'edit_id' => 'required',
        'ip_name' => 'required',
        'ip_address' => 'required'
      ]);

      if ($validator->fails()) {
        return response()->json([
          'status' => 401,
          'message' => 'Incorrect format input fields',
          'error_msg' => $validator->errors()->all(),
          'data' => null,
        ], 200);
      }

      $user_id = $request->user()->user_id;

      $edit_id = $request->edit_id ;
      $ip_name = $request->ip_name ;
      $ip_address = $request->ip_address ;
      
      $ipAlreadyExistCheck = IpConfigModel::where('ip_address',$ip_address)->where('sno', '!=',$edit_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if ($ipAlreadyExistCheck) {
        return response()->json([
          'status' => 401,
          'message' => 'IP Address Already Exit',
          'error_msg' => 'IP Address Already Exit',
          'data' => null,
        ], 200);
      }
   
      $update_ipaddress = IpConfigModel::where('sno', $edit_id)->first();
      $update_ipaddress->ip_address = $ip_address;
      $update_ipaddress->ip_name = $ip_name;
      $update_ipaddress->updated_by = $request->user()->user_id;
      $update_ipaddress->save();

      $EntityData=DB::table('egc_entity')->where('status',0)->get();
        
      if($EntityData){
          $payload=[
            'sno' => $update_ipaddress->sno,
            'ip_address' => $update_ipaddress->ip_address,
            'ip_name' => $update_ipaddress->ip_name,
          ];

          foreach($EntityData as $entity){
            if($entity->entity_base_url){
                $this->dispatchUpdateWebhooks($payload, $user_id, 'UPDATE_IP_ADDRESS',$entity->sno);
            }
          }   
      }

      return response()->json([
        'status' => 200,
        'message' => 'IP Address Added Successfully',
        'error_msg' => null,
        'data' => null,
      ], 200);
   
  }
  
  protected function dispatchUpdateWebhooks($broadcast, $userId = 1,$dispatchHook , $entity_id)
  {
    $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module', $dispatchHook)->where('entity_id', $entity_id)->first();
    if ($webhook) {
      $dispatch = WebhookDispatchModel::create([
        'sub_erp_webhook_sno' => $webhook->sno,
        'dispatchable_type' => 'App\Models\StaffModel',
        'dispatchable_id' => $broadcast['sno'],
        'message_uuid' => $broadcast['sno'],
        'payload' => json_encode($broadcast),
        'status' => 0,
        'attempts' => 0,
        'created_by' => $userId,
        'updated_by' => $userId,
      ]);

      // broadcast creation once
      broadcast(new WebhookDispatchedEvent($dispatch));

      // enqueue the job
      try {
        $result = $this->sendWebhookNow($dispatch, $webhook);
        \Log::info("send result : " . json_encode($result));

        if (!$result['success']) {
          // If fails, dispatch to queue
          SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
        }
      } catch (\Throwable $e) {
        // On any exception, fallback to queue
        SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
        \Log::error("Webhook fallback to queue: " . $e->getMessage());
      }
    }
  }

  protected function sendWebhookNow($dispatch, $hook)
  {
    $payload = $dispatch->payload ?? [];
    $bodyString = json_encode($payload);

    $dispatch->increment('attempts');
    $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
    broadcast(new WebhookDispatchedEvent($dispatch));

    $timestamp = now()->getTimestamp();
    $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

    $headers = array_merge(
      is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
      [
        'X-WEBHOOK-TIMESTAMP' => $timestamp,
        'X-WEBHOOK-SIGNATURE' => $signature,
        'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
        'Accept' => 'application/json',
      ]
    );

    try {
      $response = Http::withHeaders($headers)
        ->timeout(15)
        ->post($hook->url, $payload);

      WebhookDispatchAttemptModel::create([
        'webhook_dispatch_sno' => $dispatch->sno,
        'http_status' => $response->status(),
        'request_headers' => json_encode($headers),
        'request_body' => $bodyString,
        'response_body' => $response->body(),
      ]);

      if ($response->successful()) {
        $dispatch->update([
          'status' => 2,
          'http_status' => $response->status(),
          'last_response' => $response->body(),
          'next_attempt_at' => null
        ]);
        broadcast(new WebhookDispatchedEvent($dispatch));
        return ['success' => true];
      } else {
        $dispatch->update([
          'status' => 3,
          'last_response' => 'Webhook failed. Will retry automatically.'
        ]);
        broadcast(new WebhookDispatchedEvent($dispatch));
        return ['success' => false];
      }
    } catch (\Throwable $e) {
      \Log::error("Immediate webhook send failed: " . $e->getMessage());
      $dispatch->update([
        'status' => 3,
        'last_response' => 'Webhook failed. Will retry automatically.'
      ]);
      broadcast(new WebhookDispatchedEvent($dispatch));
      return ['success' => false];
    }
  }

}
