<?php

namespace App\Http\Controllers\control_panel\monitor_tool;

use App\Events\WebhookDispatchedEvent;
use App\Http\Controllers\Controller;
use App\Jobs\SendWebhookJob;
use App\Models\IpConfigModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\WebhookDispatchModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Throwable;
use App\Models\UnAuthorizedIPModel;
use Carbon\Carbon;

class IpConfigController extends Controller
{
    /**
     * List active/inactive IP rules. Deleted records (status 2) stay soft-deleted.
     */
    public function index(Request $request)
    {
      
        try {
            $perpage = (int) $request->input('sorting_filter', 25);
            $perpage = max(5, min($perpage, 500));
            $search = trim((string) $request->input('search_filter', ''));

            $query = IpConfigModel::query()
                ->where('status', '!=', IpConfigModel::STATUS_DELETED);

            if ($search !== '') {
                $query->where(function ($builder) use ($search) {
                    $builder->where('ip_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('ip_address', 'LIKE', '%' . $search . '%');
                });
            }

            $records = $query->orderByDesc('sno')->paginate($perpage);

            if ($request->ajax()) {
                $data = $records->getCollection()->map(static function (IpConfigModel $item) {
                    return [
                        'sno' => (int) $item->sno,
                        'status' => (int) $item->status,
                        'ip_name' => $item->ip_name,
                        'ip_address' => $item->ip_address,
                    ];
                })->values();

                return response()->json([
                    'data' => $data,
                    'current_page' => $records->currentPage(),
                    'last_page' => $records->lastPage(),
                    'total' => $records->total(),
                ]);
            }
                 $ipAddress = $request->ip();
            return view('content.control_panel.monitor_tool.ip_config.ip_config_list', [
                'perpage' => $perpage,
                'ipAddress' => $ipAddress,
            ]);
        } catch (Throwable $exception) {
            Log::error('IP config list failed.', [
                'message' => $exception->getMessage(),
                'exception' => $exception,
            ]);

            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unable to load IP configuration records.',
                    'data' => [],
                    'current_page' => 1,
                    'last_page' => 1,
                    'total' => 0,
                ], 500);
            }

            throw $exception;
        }
    }


    

    /** Create a new allowed IP. The main DB transaction commits before webhooks run. */
    public function Save(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'ip_name' => ['required', 'string', 'max:255'],
            'ip_address' => ['required', 'string', 'ip', 'max:45'],
        ], [
            'ip_name.required' => 'Please enter an IP name.',
            'ip_address.required' => 'Please enter an IP address.',
            'ip_address.ip' => 'Enter a valid IPv4 or IPv6 address.',
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $userId = $this->actorId($request);
        $ipName = trim($validator->validated()['ip_name']);
        $ipAddress = trim($validator->validated()['ip_address']);

        try {
            $result = DB::transaction(function () use ($ipName, $ipAddress, $userId) {
                $duplicate = IpConfigModel::query()
                    ->where('ip_address', $ipAddress)
                    ->where('status', '!=', IpConfigModel::STATUS_DELETED)
                    ->lockForUpdate()
                    ->exists();

                if ($duplicate) {
                    return ['duplicate' => true, 'record' => null];
                }

                $record = new IpConfigModel();
                $record->ip_name = $ipName;
                $record->ip_address = $ipAddress;
                $record->status = IpConfigModel::STATUS_ACTIVE;
                $record->created_by = $userId;
                $record->updated_by = $userId;
                $record->save();

                return ['duplicate' => false, 'record' => $record->fresh()];
            });

            if ($result['duplicate']) {
                return response()->json([
                    'success' => false,
                    'status' => 409,
                    'message' => 'This IP address is already configured.',
                    'errors' => ['ip_address' => ['This IP address is already configured.']],
                ], 409);
            }

            $record = $result['record'];
            $this->syncIpConfigWithEntities($record, $userId, 'UPDATE_IP_ADDRESS');

            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'IP address added successfully.',
                'data' => $this->serializeRecord($record),
            ]);
        } catch (Throwable $exception) {
            Log::error('IP config create failed.', [
                'ip_address' => $ipAddress,
                'message' => $exception->getMessage(),
                'exception' => $exception,
            ]);

            return $this->serverError('Unable to add the IP address. Please try again.');
        }
    }

    /** Update an existing IP rule. The record ID is submitted as edit_id. */
    public function Update(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edit_id' => ['required', 'integer', 'min:1'],
            'ip_name' => ['required', 'string', 'max:255'],
            'ip_address' => ['required', 'string', 'ip', 'max:45'],
        ], [
            'ip_name.required' => 'Please enter an IP name.',
            'ip_address.required' => 'Please enter an IP address.',
            'ip_address.ip' => 'Enter a valid IPv4 or IPv6 address.',
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $input = $validator->validated();
        $recordId = (int) $input['edit_id'];
        $ipName = trim($input['ip_name']);
        $ipAddress = trim($input['ip_address']);
        $userId = $this->actorId($request);

        try {
            $result = DB::transaction(function () use ($recordId, $ipName, $ipAddress, $userId) {
                $record = IpConfigModel::query()
                    ->where('sno', $recordId)
                    ->where('status', '!=', IpConfigModel::STATUS_DELETED)
                    ->lockForUpdate()
                    ->first();

                if (!$record) {
                    return ['not_found' => true, 'duplicate' => false, 'record' => null];
                }

                $duplicate = IpConfigModel::query()
                    ->where('ip_address', $ipAddress)
                    ->where('sno', '!=', $recordId)
                    ->where('status', '!=', IpConfigModel::STATUS_DELETED)
                    ->lockForUpdate()
                    ->exists();

                if ($duplicate) {
                    return ['not_found' => false, 'duplicate' => true, 'record' => null];
                }

                $record->ip_name = $ipName;
                $record->ip_address = $ipAddress;
                $record->updated_by = $userId;
                $record->save();

                return ['not_found' => false, 'duplicate' => false, 'record' => $record->fresh()];
            });

            if ($result['not_found']) {
                return response()->json([
                    'success' => false,
                    'status' => 404,
                    'message' => 'The IP configuration record was not found.',
                ], 404);
            }

            if ($result['duplicate']) {
                return response()->json([
                    'success' => false,
                    'status' => 409,
                    'message' => 'This IP address is already configured.',
                    'errors' => ['ip_address' => ['This IP address is already configured.']],
                ], 409);
            }

            $record = $result['record'];
            $this->syncIpConfigWithEntities($record, $userId, 'UPDATE_IP_ADDRESS');

            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'IP address updated successfully.',
                'data' => $this->serializeRecord($record),
            ]);
        } catch (Throwable $exception) {
            Log::error('IP config update failed.', [
                'record_id' => $recordId,
                'message' => $exception->getMessage(),
                'exception' => $exception,
            ]);

            return $this->serverError('Unable to update the IP address. Please try again.');
        }
    }

    /** Change status to active (0) or inactive (1). */
    public function Status(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'id' => ['required', 'integer', 'min:1'],
            'status' => ['required', 'integer', 'in:0,1'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $recordId = (int) $validator->validated()['id'];
        $newStatus = (int) $validator->validated()['status'];
        $userId = $this->actorId($request);

        try {
            $result = DB::transaction(function () use ($recordId, $newStatus, $userId) {
                $record = IpConfigModel::query()
                    ->where('sno', $recordId)
                    ->where('status', '!=', IpConfigModel::STATUS_DELETED)
                    ->lockForUpdate()
                    ->first();

                if (!$record) {
                    return ['not_found' => true, 'changed' => false, 'record' => null];
                }

                if ((int) $record->status === $newStatus) {
                    return ['not_found' => false, 'changed' => false, 'record' => $record];
                }

                $record->status = $newStatus;
                $record->updated_by = $userId;
                $record->save();

                return ['not_found' => false, 'changed' => true, 'record' => $record->fresh()];
            });

            if ($result['not_found']) {
                return response()->json([
                    'success' => false,
                    'status' => 404,
                    'message' => 'The IP configuration record was not found.',
                ], 404);
            }

            if ($result['changed']) {
                $this->syncIpConfigWithEntities($result['record'], $userId, 'STATUS_UPDATE_IP_ADDRESS');
            }

            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => $result['changed'] ? 'IP address status updated successfully.' : 'IP address status is already up to date.',
                'data' => $this->serializeRecord($result['record']),
            ]);
        } catch (Throwable $exception) {
            Log::error('IP config status update failed.', [
                'record_id' => $recordId,
                'message' => $exception->getMessage(),
                'exception' => $exception,
            ]);

            return $this->serverError('Unable to update the IP address status. Please try again.');
        }
    }

    /** Soft-delete an IP rule by setting status to 2 and sync the same status to entities. */
    public function Delete(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'id' => ['required', 'integer', 'min:1'],
        ]);

        if ($validator->fails()) {
            return $this->validationError($validator->errors()->toArray());
        }

        $recordId = (int) $validator->validated()['id'];
        $userId = $this->actorId($request);

        try {
            $result = DB::transaction(function () use ($recordId, $userId) {
                $record = IpConfigModel::query()
                    ->where('sno', $recordId)
                    ->lockForUpdate()
                    ->first();

                if (!$record) {
                    return ['not_found' => true, 'changed' => false, 'record' => null];
                }

                if ((int) $record->status === IpConfigModel::STATUS_DELETED) {
                    return ['not_found' => false, 'changed' => false, 'record' => $record];
                }

                $record->status = IpConfigModel::STATUS_DELETED;
                $record->updated_by = $userId;
                $record->save();

                return ['not_found' => false, 'changed' => true, 'record' => $record->fresh()];
            });

            if ($result['not_found']) {
                return response()->json([
                    'success' => false,
                    'status' => 404,
                    'message' => 'The IP configuration record was not found.',
                ], 404);
            }

            if ($result['changed']) {
                // Deletion is a status change; no separate DELETE webhook module is required.
                $this->syncIpConfigWithEntities($result['record'], $userId, 'STATUS_UPDATE_IP_ADDRESS');
            }

            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => $result['changed'] ? 'IP address deleted successfully.' : 'IP address was already deleted.',
                'data' => $this->serializeRecord($result['record']),
            ]);
        } catch (Throwable $exception) {
            Log::error('IP config soft delete failed.', [
                'record_id' => $recordId,
                'message' => $exception->getMessage(),
                'exception' => $exception,
            ]);

            return $this->serverError('Unable to delete the IP address. Please try again.');
        }
    }

    /**
     * Paginated security audit log for login requests denied by RestrictLoginIP.
     * Statistics are intentionally global; list filters only affect the table rows.
     */
    public function unauthorizedLogs(Request $request): JsonResponse
    {
        try {
            $perpage = (int) $request->input('sorting_filter', 25);
            $perpage = max(5, min($perpage, 100));
            $search = substr(trim((string) $request->input('search_filter', '')), 0, 150);
            $period = (string) $request->input('period', '24h');
            $method = strtoupper(trim((string) $request->input('request_method', '')));

            $baseQuery = DB::table('egc_unauthorized_ip_logs');

            $totalAttempts = (clone $baseQuery)->count();
            $uniqueIps = (clone $baseQuery)->distinct()->count('ip_address');
            $last24Hours = (clone $baseQuery)
                ->where('blocked_at', '>=', now()->subDay())
                ->count();
            $latestAttempt = (clone $baseQuery)->max('blocked_at');

            $query = DB::table('egc_unauthorized_ip_logs')
            ->leftJoin('egc_entity','egc_unauthorized_ip_logs.entity_id','egc_entity.sno')
            ->select(
                'egc_unauthorized_ip_logs.*',
                'egc_entity.entity_name',
                'egc_entity.entity_base_color',
                'egc_entity.entity_logo',
                'egc_entity.entity_favicon',
                'egc_entity.company_id',
            );

            if ($period === '24h') {
                $query->where('blocked_at', '>=', now()->subDay());
            } elseif ($period === '7d') {
                $query->where('blocked_at', '>=', now()->subDays(7));
            } elseif ($period === '30d') {
                $query->where('blocked_at', '>=', now()->subDays(30));
            } elseif ($period !== 'all') {
                $period = '24h';
                $query->where('blocked_at', '>=', now()->subDay());
            }

            if (in_array($method, ['GET', 'POST'], true)) {
                $query->where('request_method', $method);
            } else {
                $method = '';
            }

            if ($search !== '') {
                $query->where(function ($builder) use ($search) {
                    $builder->where('ip_address', 'LIKE', '%' . $search . '%')
                        ->orWhere('request_path', 'LIKE', '%' . $search . '%')
                        ->orWhere('user_agent', 'LIKE', '%' . $search . '%')
                        ->orWhere('referer', 'LIKE', '%' . $search . '%')
                        ->orWhere('browser', 'LIKE', '%' . $search . '%')
                        ->orWhere('platform', 'LIKE', '%' . $search . '%');
                });
            }

            $records = $query->orderByDesc('blocked_at')->orderByDesc('sno')->paginate($perpage);
            $helper = new \App\Helpers\Helpers();
    
            $data = $records->getCollection()->map(static function ($item) use ($helper){

                    $general_setting=$helper->general_setting_data();

                    if($item->entity_id == 0){
                        $item->entity_name=$general_setting->title;
                        $item->entity_favicon=$general_setting->logo;
                        $item->company_id=0;
                        $item->entity_logo=$general_setting->logo;
                        $item->entity_base_color ='#ab2b22';
                    }

                return [
                    'sno' => (int) $item->sno,
                    'entity_id' => $item->entity_id,
                    'entity_name' => $item->entity_name,
                    'entity_base_color' => $item->entity_base_color,
                    'entity_logo' => $item->entity_logo,
                    'entity_favicon' => $item->entity_favicon,
                    'company_id' => $item->company_id,
                    'request_id' => $item->request_id,
                    'ip_address' => $item->ip_address,
                    'ip_version' => $item->ip_version,
                    'request_method' => $item->request_method,
                    'response_status' => (int) $item->response_status,
                    'request_path' => $item->request_path,
                    'user_agent' => $item->user_agent,
                    'referer' => $item->referer,
                    'accept_language' => $item->accept_language,
                    'device_type' => $item->device_type,
                    'browser' => $item->browser,
                    'platform' => $item->platform,
                    'is_bot' => (bool) $item->is_bot,
                    'blocked_at' => $item->blocked_at,
                ];
            })->values();

            return response()->json([
                'success' => true,
                'data' => $data,
                'current_page' => $records->currentPage(),
                'last_page' => $records->lastPage(),
                'per_page' => $records->perPage(),
                'total' => $records->total(),
                'filters' => [
                    'period' => $period,
                    'request_method' => $method,
                ],
                'stats' => [
                    'total_attempts' => (int) $totalAttempts,
                    'unique_ips' => (int) $uniqueIps,
                    'last_24_hours' => (int) $last24Hours,
                    'latest_attempt' => $latestAttempt,
                ],
            ]);
        } catch (Throwable $exception) {
            Log::error('Unauthorized IP audit log list failed.', [
                'message' => $exception->getMessage(),
                'exception' => $exception,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load unauthorized IP activity. Please verify the audit table is installed.',
                'data' => [],
                'current_page' => 1,
                'last_page' => 1,
                'total' => 0,
            ], 500);
        }
    }

    private function actorId(Request $request)
    {
        $user = $request->user();

        return $user ? ($user->user_id ?? $user->id ?? 1) : 1;
    }

    private function serializeRecord(IpConfigModel $record): array
    {
        return [
            'sno' => (int) $record->sno,
            'ip_name' => $record->ip_name,
            'ip_address' => $record->ip_address,
            'status' => (int) $record->status,
        ];
    }

    private function validationError(array $errors): JsonResponse
    {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $errors,
        ], 422);
    }

    private function serverError(string $message): JsonResponse
    {
        return response()->json([
            'success' => false,
            'status' => 500,
            'message' => $message,
        ], 500);
    }

    /**
     * Dispatch after the primary record transaction has committed. Each entity
     * is isolated so a failed endpoint does not undo a saved main-application rule.
     */
    private function syncIpConfigWithEntities(IpConfigModel $record, $userId, string $module): void
    {
        $payload = [
            'sno' => (int) $record->sno,
            'ip_name' => $record->ip_name,
            'ip_address' => $record->ip_address,
            'status' => (int) $record->status,
            'created_by' => $record->created_by ?? $userId,
            'updated_by' => $record->updated_by ?? $userId,
        ];

        try {
            $entities = DB::table('egc_entity')
                ->select('sno')
                ->where('status', 0)
                ->whereNotNull('entity_base_url')
                ->where('entity_base_url', '!=', '')
                ->orderBy('sno')
                ->get();
        } catch (Throwable $exception) {
            Log::error('Unable to load entities for IP config synchronization.', [
                'record_id' => $record->sno,
                'module' => $module,
                'message' => $exception->getMessage(),
            ]);
            return;
        }

        foreach ($entities as $entity) {
            try {
                $this->dispatchUpdateWebhooks($payload, $userId, $module, (int) $entity->sno);
            } catch (Throwable $exception) {
                Log::error('IP config webhook dispatch failed for entity.', [
                    'entity_id' => $entity->sno,
                    'record_id' => $record->sno,
                    'module' => $module,
                    'message' => $exception->getMessage(),
                    'exception' => $exception,
                ]);
            }
        }
    }

    private function dispatchUpdateWebhooks(array $payload, $userId, string $dispatchHook, int $entityId): void
    {
        $webhook = SubErpWebhookModel::query()
            ->where('status', 0)
            ->where('webhook_module', $dispatchHook)
            ->where('entity_id', $entityId)
            ->first();

        if (!$webhook) {
            return;
        }

        $dispatch = WebhookDispatchModel::create([
            'sub_erp_webhook_sno' => $webhook->sno,
            'dispatchable_type' => IpConfigModel::class,
            'dispatchable_id' => $payload['sno'],
            'message_uuid' => $payload['sno'],
            'payload' => json_encode($payload),
            'status' => 0,
            'attempts' => 0,
            'created_by' => $userId,
            'updated_by' => $userId,
        ]);

        try {
            broadcast(new WebhookDispatchedEvent($dispatch));
        } catch (Throwable $exception) {
            Log::warning('IP config dispatch event broadcast failed.', [
                'dispatch_id' => $dispatch->sno,
                'message' => $exception->getMessage(),
            ]);
        }

        try {
            $result = $this->sendWebhookNow($dispatch, $webhook);
            if (empty($result['success'])) {
                SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            }
        } catch (Throwable $exception) {
            Log::error('IP config immediate webhook delivery failed; queue fallback requested.', [
                'dispatch_id' => $dispatch->sno,
                'message' => $exception->getMessage(),
            ]);

            try {
                SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            } catch (Throwable $queueException) {
                Log::critical('IP config webhook queue fallback failed.', [
                    'dispatch_id' => $dispatch->sno,
                    'message' => $queueException->getMessage(),
                ]);
            }
        }
    }

    private function sendWebhookNow(WebhookDispatchModel $dispatch, SubErpWebhookModel $hook): array
    {
        $payload = $dispatch->payload ?? [];
        if (is_string($payload)) {
            $decoded = json_decode($payload, true);
            $payload = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($payload)) {
            $payload = [];
        }

        $bodyString = json_encode($payload);
        if ($bodyString === false) {
            throw new \RuntimeException('Unable to encode IP config webhook payload.');
        }

        $dispatch->increment('attempts');
        $dispatch->update([
            'status' => 1,
            'last_attempt_at' => now(),
        ]);

        try {
            broadcast(new WebhookDispatchedEvent($dispatch));
        } catch (Throwable $exception) {
            Log::warning('IP config dispatch status broadcast failed.', [
                'dispatch_id' => $dispatch->sno,
                'message' => $exception->getMessage(),
            ]);
        }

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret
            ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret)
            : null;

        $configuredHeaders = is_array($hook->headers)
            ? $hook->headers
            : json_decode($hook->headers ?? '[]', true);
        $configuredHeaders = is_array($configuredHeaders) ? $configuredHeaders : [];

        $headers = array_merge($configuredHeaders, [
            'X-WEBHOOK-TIMESTAMP' => (string) $timestamp,
            'X-WEBHOOK-SIGNATURE' => $signature,
            'X-IDEMPOTENCY-KEY' => (string) $dispatch->message_uuid,
            'Accept' => 'application/json',
        ]);

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null,
                ]);
                try {
                    broadcast(new WebhookDispatchedEvent($dispatch));
                } catch (Throwable $broadcastException) {
                    Log::warning('IP config success event broadcast failed.', [
                        'dispatch_id' => $dispatch->sno,
                        'message' => $broadcastException->getMessage(),
                    ]);
                }

                return ['success' => true, 'http_status' => $response->status()];
            }

            $dispatch->update([
                'status' => 3,
                'http_status' => $response->status(),
                'last_response' => 'Webhook failed. Will retry automatically.',
            ]);
            try {
                broadcast(new WebhookDispatchedEvent($dispatch));
            } catch (Throwable $broadcastException) {
                Log::warning('IP config failure event broadcast failed.', [
                    'dispatch_id' => $dispatch->sno,
                    'message' => $broadcastException->getMessage(),
                ]);
            }

            Log::warning('IP config webhook returned an unsuccessful response.', [
                'dispatch_id' => $dispatch->sno,
                'http_status' => $response->status(),
            ]);

            return ['success' => false, 'http_status' => $response->status()];
        } catch (Throwable $exception) {
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.',
            ]);
            try {
                broadcast(new WebhookDispatchedEvent($dispatch));
            } catch (Throwable $broadcastException) {
                Log::warning('IP config exception event broadcast failed.', [
                    'dispatch_id' => $dispatch->sno,
                    'message' => $broadcastException->getMessage(),
                ]);
            }

            Log::error('IP config webhook request failed.', [
                'dispatch_id' => $dispatch->sno,
                'message' => $exception->getMessage(),
            ]);

            return ['success' => false];
        }
    }

    public function sync(Request $request)
    {
        $rawBody = $request->getContent();

        if (!$this->isValidSignature($request, $rawBody)) {

            $timestamp = (string) $request->header('X-EGC-Timestamp');
            $providedSignature = (string) $request->header('X-EGC-Signature');
            $timecheck = false;
            if (abs(time() - (int) $timestamp) > 300) {
                $timecheck = true;
            }


            Log::error('Internal EGC Unauthorised Ip Log synchronization failed', [
                'timecheck' => $timecheck,
                'timestamp' => $timestamp,
                'providedSignature' => $providedSignature,
                'timestamp_dig' => ctype_digit($timestamp),
                'external_uuid' => $request->external_uuid,
                'source' => $request->source,
                'request' => $request,
                'rawBody' => $rawBody,
            ]);

            return response()->json([
                'status' => 401,
                'message' => 'Unauthorized synchronization request.',
                'error_msg' => 'Invalid EGC synchronization signature.',
                'data' => null,
            ], 401);
        }

        $validator = Validator::make($request->all(), [
            'external_uuid' => 'required|string|max:64',
            'source_log_id' => 'required|integer|min:1',
            'source' => 'required|string|max:100',
            'source_entity_id' => 'required|integer|min:0',
            'entity_id' => 'required|integer|min:0',

            'branch_id' => 'nullable|integer|min:0',
            'request_id' => 'nullable|string',
            'ip_address' => 'nullable|string',
            'ip_version' => 'nullable|string',

            'request_path' => 'nullable|string',
            'user_agent' => 'nullable|string',
            'referer' => 'nullable|string',
            'accept_language' => 'nullable|string',
            'request_method' => 'nullable|string',
            'response_status' => 'nullable|integer',

            'device_type' => 'nullable|string',
            'browser' => 'nullable|string',
            'platform' => 'nullable|string',
            'is_bot' => 'nullable|integer',

            'blocked_at' => 'nullable|date',
            'created_at' => 'nullable|date',
            'updated_at' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null,
            ], 422);
        }

        $entityId = (int) $request->entity_id;


        DB::beginTransaction();

        try {
            $existing = UnAuthorizedIPModel::where('external_uuid', $request->external_uuid)
                ->lockForUpdate()
                ->first();

            if ($existing) {
                DB::commit();

                return response()->json([
                    'status' => 200,
                    'message' => 'Unauthorised IP Log already synchronized.',
                    'error_msg' => null,
                    'data' => [
                        'sno' => $existing->sno,
                        'external_uuid' => $existing->external_uuid,
                        'entity_id' => $existing->entity_id,
                        'duplicated' => true,
                    ],
                ], 200);
            }

            $now = Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s');

            $logId = DB::table('egc_unauthorized_ip_logs')->insertGetId([
                'entity_id' => $entityId,
                'request_id' => $request->request_id,
                'ip_address' => $request->ip_address,
                'ip_version' => $request->ip_version,
                'request_method' => $request->request_method,
                'response_status' => $request->response_status,
                'request_path' => $request->request_path,
                'user_agent' => $request->user_agent,
                
                'referer' => $request->referer,
                'accept_language' => $request->accept_language,
                'device_type' => $request->device_type,
                'browser' => $request->browser,
                'platform' => $request->platform,
                'is_bot' => $request->is_bot,
                'external_uuid' => $request->external_uuid,
                'blocked_at' => $request->filled('blocked_at')
                    ? Carbon::parse($request->blocked_at)->format('Y-m-d H:i:s')
                    : $now,
                'created_at' => $request->filled('created_at')
                    ? Carbon::parse($request->created_at)->format('Y-m-d H:i:s')
                    : $now,
                'updated_at' => $request->filled('updated_at')
                    ? Carbon::parse($request->updated_at)->format('Y-m-d H:i:s')
                    : $now,
            ]);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Unauthorised IP Log synchronized successfully.',
                'error_msg' => null,
                'data' => [
                    'sno' => $logId,
                    'external_uuid' => $request->external_uuid,
                    'entity_id' => $entityId,
                ],
            ], 200);
        } catch (\Throwable $e) {
            DB::rollBack();

            if (str_contains(strtolower($e->getMessage()), 'duplicate') ||
                str_contains(strtolower($e->getMessage()), 'unique')) {
                $existing = CallTrackerModel::where('external_uuid', $request->external_uuid)->first();

                if ($existing) {
                    return response()->json([
                        'status' => 200,
                        'message' => 'Unauthorised IP Log already synchronized.',
                        'error_msg' => null,
                        'data' => [
                            'sno' => $existing->sno,
                            'external_uuid' => $existing->external_uuid,
                            'entity_id' => $existing->entity_id,
                            'duplicated' => true,
                        ],
                    ], 200);
                }
            }

            Log::error('Internal EGC Unauthorised IP Log synchronization failed', [
                'external_uuid' => $request->external_uuid,
                'source' => $request->source,
                'entity_id' => $entityId,
                'exception' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'Unable to synchronize Unauthorised IP Log.',
                'error_msg' => config('app.debug') ? $e->getMessage() : 'Internal synchronization error.',
                'data' => null,
            ], 500);
        }
    }

    private function isValidSignature(Request $request, string $rawBody): bool
    {
        $secret = (string) env('EGC_SYNC_SECRET', 'EGCREP@2030UNAuthorisedIPCODESECRETHOOK657');

        if ($secret === '') {
            return false;
        }

        $timestamp = (string) $request->header('X-EGC-Timestamp');
        $providedSignature = (string) $request->header('X-EGC-Signature');

        if ($timestamp === '' || $providedSignature === '' || !ctype_digit($timestamp)) {
            return false;
        }

        /*
         * Five-minute replay window.
         */
        if (abs(time() - (int) $timestamp) > 300) {
            return false;
        }

        $expected = hash_hmac(
            'sha256',
            $timestamp . '.' . $rawBody,
            $secret
        );

        return hash_equals($expected, $providedSignature);
    }
}
