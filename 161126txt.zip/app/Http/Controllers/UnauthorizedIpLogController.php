<?php

namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Services\IpIntelligenceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Admin-only JSON endpoint for unauthorized IP audit activity.
 * The route must use EnsureUnauthorizedIpLogAdmin middleware.
 */
class UnauthorizedIpLogController extends Controller
{
    private $ipIntelligence;

    public function __construct(IpIntelligenceService $ipIntelligence)
    {
        $this->ipIntelligence = $ipIntelligence;
    }

    public function index(Request $request)
    {
        try {
            $perPage = (int) $request->input('sorting_filter', 25);
            $perPage = max(5, min($perPage, 100));
            $search = substr(trim((string) $request->input('search_filter', '')), 0, 150);
            $period = (string) $request->input('period', '24h');
            $method = strtoupper(trim((string) $request->input('request_method', '')));

            $baseQuery = DB::table('egc_unauthorized_ip_logs');

            $totalAttempts = (clone $baseQuery)->count();
            $uniqueIps = (clone $baseQuery)->distinct()->count('ip_address');
            $last24Hours = (clone $baseQuery)
                ->where('blocked_at', '>=', now()->subDay())
                ->count();
            $latestAttempt = (clone $baseQuery)->max('blocked_at');

            $query = DB::table('egc_unauthorized_ip_logs')
                ->leftJoin('egc_entity', 'egc_unauthorized_ip_logs.entity_id', '=', 'egc_entity.sno')
                ->select(
                    'egc_unauthorized_ip_logs.*',
                    'egc_entity.entity_name',
                    'egc_entity.entity_base_color',
                    'egc_entity.entity_logo',
                    'egc_entity.entity_favicon',
                    'egc_entity.company_id'
                );

            // if ($period === '24h') {
            //     $query->where('egc_unauthorized_ip_logs.blocked_at', '>=', now()->subDay());
            // } elseif ($period === '7d') {
            //     $query->where('egc_unauthorized_ip_logs.blocked_at', '>=', now()->subDays(7));
            // } elseif ($period === '30d') {
            //     $query->where('egc_unauthorized_ip_logs.blocked_at', '>=', now()->subDays(30));
            // } elseif ($period !== 'all') {
            //     $period = '24h';
            //     $query->where('egc_unauthorized_ip_logs.blocked_at', '>=', now()->subDay());
            // }

            $allowedMethods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD'];
            if (in_array($method, $allowedMethods, true)) {
                $query->where('egc_unauthorized_ip_logs.request_method', $method);
            } else {
                $method = '';
            }

            if ($search !== '') {
                $query->where(function ($builder) use ($search) {
                    $like = '%' . $search . '%';
                    $builder->where('egc_unauthorized_ip_logs.ip_address', 'LIKE', $like)
                        ->orWhere('egc_unauthorized_ip_logs.request_path', 'LIKE', $like)
                        ->orWhere('egc_unauthorized_ip_logs.user_agent', 'LIKE', $like)
                        ->orWhere('egc_unauthorized_ip_logs.referer', 'LIKE', $like)
                        ->orWhere('egc_unauthorized_ip_logs.browser', 'LIKE', $like)
                        ->orWhere('egc_unauthorized_ip_logs.platform', 'LIKE', $like)
                        ->orWhere('egc_unauthorized_ip_logs.device_type', 'LIKE', $like);
                });
            }

            $records = $query
                ->orderByDesc('egc_unauthorized_ip_logs.blocked_at')
                ->orderByDesc('egc_unauthorized_ip_logs.sno')
                ->paginate($perPage);
//  return $records;
      

            // Load branding once, not once per row.
            $helper = new Helpers();
            $generalSetting = $helper->general_setting_data();

            $data = $records->getCollection()->map(function ($item) use ($generalSetting) {
                if ((int) $item->entity_id === 0 && $generalSetting) {
                    $item->entity_name = $generalSetting->title ?? $item->entity_name;
                    $item->entity_favicon = $generalSetting->logo ?? $item->entity_favicon;
                    $item->company_id = 0;
                    $item->entity_logo = $generalSetting->logo ?? $item->entity_logo;
                    $item->entity_base_color = '#ab2b22';
                }

                return [
                    'sno' => (int) $item->sno,
                    'entity_id' => (int) $item->entity_id,
                    'entity_name' => $item->entity_name,
                    'entity_base_color' => $item->entity_base_color,
                    'entity_logo' => $item->entity_logo,
                    'entity_favicon' => $item->entity_favicon,
                    'company_id' => $item->company_id,
                    'request_id' => $item->request_id,
                    'ip_address' => $item->ip_address,
                    'ip_version' => $item->ip_version,
                    'ip_details' => $this->ipIntelligence->lookup((string) $item->ip_address),
                    'request_method' => $item->request_method,
                    'response_status' => (int) $item->response_status,
                    'request_path' => $item->request_path,
                    'user_agent' => $item->user_agent,
                    'referer' => $item->referer,
                    'accept_language' => $item->accept_language,
                    'device_type' => $item->device_type,
                    'browser' => $item->browser,
                    'platform' => $item->platform,
                    'is_bot' => (bool) $item->is_bot,
                    'blocked_at' => $item->blocked_at,
                ];
            })->values();

            return response()->json([
                'success' => true,
                'data' => $data,
                'current_page' => $records->currentPage(),
                'last_page' => $records->lastPage(),
                'per_page' => $records->perPage(),
                'total' => $records->total(),
                'filters' => [
                    'period' => $period,
                    'request_method' => $method,
                ],
                'stats' => [
                    'total_attempts' => (int) $totalAttempts,
                    'unique_ips' => (int) $uniqueIps,
                    'last_24_hours' => (int) $last24Hours,
                    'latest_attempt' => $latestAttempt,
                ],
            ]);
        } catch (Throwable $exception) {
            Log::error('Unauthorized IP audit log list failed.', [
                'message' => $exception->getMessage(),
                'exception' => $exception,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load unauthorized IP activity. Please verify the audit table and application configuration.',
                'data' => [],
                'current_page' => 1,
                'last_page' => 1,
                'per_page' => 25,
                'total' => 0,
            ], 500);
        }
    }
}
