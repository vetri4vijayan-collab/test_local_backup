# Current release note — Candidate Name + Mobile Production Hotfix v6 (15 October 2026)

**This release supersedes the v5 behavior described below.** It keeps candidate-name extraction AI-first, rejects unsupported AI answers, and strengthens the local identity-header fallback. It also extracts the Indian candidate mobile locally, fills the Add Candidate field without `+91`, checks duplicate mobiles while typing, and enforces a second check when Add/Edit is saved. Other candidate fields and the optional Job Roles behavior are intentionally unchanged.

## v6 fixes https://chatgpt.com/share/6ad0d87c-abb8-83ee-8d18-ae27c133fe8e

https://chatgpt.com/share/6ad0d9ef-3a9c-83ec-a9d3-2d9a468da679

- **AI success is not extraction success:** model HTTP 200 is not treated as a correct name. `data.candidate_name_ai_result_status` reports a safe status code such as `accepted`, `malformed_name`, `implausible_name`, `source_evidence_rejected`, `empty_or_invalid_model_output`, or `request_failed`. No resume text, AI response body, name, mobile or token is written to diagnostic logs.
- **Stronger name fallback:** malformed response fragments such as `DE<>E<>P...` are rejected. The local parser uses a new narrow identity-header pass after its scored scan. It considers early identity-looking lines and lines next to candidate contact details while continuing to reject known skills, project, certification and objective phrases. The model is still attempted before local parsing, and only one paid inference attempt is made by default.
- **Candidate mobile is extracted automatically:** new `CandidateMobileService` parses the resume text locally; phone PII is not sent to Hugging Face. It handles Indian mobile formats such as `+91 98765 43210`, `91-9876543210`, `09876543210` and grouped digits, returning just the ten-digit number when valid (Indian mobile starts 6–9). It can join a number split across up to three adjacent PDF text lines, prioritizes labelled owner contact lines, and skips Aadhaar/PAN/DOB or parent/spouse/reference/emergency/alternate numbers.
- **Mobile form autofill:** when the resume extraction endpoint returns a valid `candidate_mobile`, it fills the Add Candidate mobile field only when blank or still equal to the previous automatic suggestion. A recruiter-entered number is preserved. The UI strips a supported Indian country/trunk prefix from pasted values.
- **Live duplicate check:** Add and Edit Candidate fields use a debounced AJAX check on input/keyup. A duplicate displays a `text-danger` message. Edit validation excludes that same applicant ID. The backend save paths independently validate and check duplicates, so disabling JavaScript or a failed AJAX request does not bypass the duplicate check.
- **Database compatibility:** no migration is required. Duplicate checks compare normalized 10-digit values against an expanded set of common legacy country-code, trunk-prefix and grouped-digit formats in `egc_applicant.mobile`. New Add/Edit saves use the canonical ten-digit format. The lookup uses indexed `whereIn` comparisons rather than normalizing every row on each debounced keyup request; unusually formatted legacy values outside the listed patterns should be normalized during controlled data cleanup.
- **Privacy and credit control:** the AI request remains name-only and contact-redacted; mobile extraction is local and does not trigger a second Hugging Face request. The default is still one configured model attempt per upload.

## v6 files and integration points

- `app/Services/Recruitment/ResumeAutomation/CandidateNameExtractionService.php` — parser version `2026-10-15.6`; AI result outcome status and header fallback.
- `app/Services/Recruitment/ResumeAutomation/CandidateMobileService.php` — local Indian phone extraction/normalization plus common-format duplicate lookup.
- `app/Http/Controllers/hr_management/hr_recruiter/ManageCandidate.php` — returns name AI result diagnostics and mobile extraction fields, and defines `checkCandidateMobile()` for the live checker; Edit Candidate validates duplicate mobile excluding the current record.
- `app/Http/Controllers/hr_management/hr_recruiter/JobRequest.php` — canonicalizes Add Candidate mobile input, enforces 10-digit Indian format, and performs server-side duplicate checks.
- `resources/views/content/hr_management/hr_recruiter/manage_candidate/candidate_list.blade.php` — Add/Edit mobile input normalization, auto-fill, debounced duplicate warnings, and submit-time state checks.
- `tests/Unit/CandidateNameExtractionServiceTest.php` — updated parser version and header fallback regressions.
- `tests/Unit/CandidateMobileServiceTest.php` — prefix normalization, source selection, split-line phone recovery, parent/reference filtering and invalid-number tests.
- `deployment/routes_web_addition.php.txt` — route addition required in the application's existing authenticated recruitment route group.

## Change map (line numbers in this archive)

Line numbers below refer to the files packaged in this v6 ZIP; they may shift if merged into a different branch.

- `app/Services/Recruitment/ResumeAutomation/CandidateNameExtractionService.php`: parser version **11**; AI-first model-response validation and fallback **29–131**; bounded local parser **192–338**; identity-header fallback **340–418**; source evidence validation **420 onward**.
- `app/Services/Recruitment/ResumeAutomation/CandidateMobileService.php`: service version **10**; local resume/mobile extraction and adjacent-line reconstruction **18–122**; normalization to 10 digits without `+91` **124–145**; indexed common-format duplicate query **147 onward**.
- `app/Services/Recruitment/ResumeAutomation/HuggingFaceInferenceService.php`: model request/prompt **19–96**; response status-only logging avoids storing model response text; configured sequential model limit is implemented in `getModels()`.
- `app/Http/Controllers/hr_management/hr_recruiter/ManageCandidate.php`: new service import **31**; resume extraction and mobile/name response fields **1115–1298**; AJAX duplicate endpoint **1304–1332**; Edit Candidate normalization and server-side duplicate validation **1889 onward**.
- `app/Http/Controllers/hr_management/hr_recruiter/JobRequest.php`: service import **34**; Add Candidate normalization and validation **2460–2515**; database duplicate check and conflict response are inside the Add flow after that section.
- `resources/views/content/hr_management/hr_recruiter/manage_candidate/candidate_list.blade.php`: Add mobile field and error region **1489–1490**; Edit mobile field and error region **1848–1849**; debounced duplicate-check state and request **6948–7030**; Add validation **7041 onward**; mobile resume auto-fill **7334–7365**; Add/Edit typing handlers **7600–7618**; Edit submit validation **7982 onward**.
- `tests/Unit/CandidateNameExtractionServiceTest.php`: regression scenarios for AI-first acceptance/rejection and local fallback; `tests/Unit/CandidateMobileServiceTest.php`: Indian prefix normalization, split-line reconstruction and excluding unrelated numbers.
- `deployment/routes_web_addition.php.txt`: required `check_candidate_mobile` route snippet; integrate inside the same authenticated route group as the existing candidate routes.

## Required route addition

The v5 archive did not include the full application `routes/web.php`, so this overlay cannot safely replace that file. **Before deploying the updated Blade view**, add the route in `deployment/routes_web_addition.php.txt` to the same authenticated middleware group as the existing `extract_resume` / candidate-management routes. Ensure `ManageCandidate` is imported once. The Blade view expects route name `check_candidate_mobile`; without this one route registration, Laravel cannot render the named URL.

## v6 deployment and tests

1. Back up the deployed files. Copy all project-relative paths in this overlay ZIP; do not replace the Laravel project root.
2. Add the route described above to `routes/web.php` inside the same authentication/authorization middleware group as the existing candidate routes.
3. Keep `HF_CANDIDATE_NAME_MAX_MODEL_ATTEMPTS=1` unless additional inference cost is explicitly approved. No new environment variable or database migration is required.
4. Run syntax checks and the tests in the full Laravel application:

   ```bash
   php -l app/Services/Recruitment/ResumeAutomation/CandidateNameExtractionService.php
   php -l app/Services/Recruitment/ResumeAutomation/CandidateMobileService.php
   php -l app/Http/Controllers/hr_management/hr_recruiter/ManageCandidate.php
   php -l app/Http/Controllers/hr_management/hr_recruiter/JobRequest.php
   php artisan optimize:clear
   php artisan test --filter=CandidateNameExtractionServiceTest
   php artisan test --filter=CandidateMobileServiceTest
   php artisan route:list --name=check_candidate_mobile
   ```

5. On staging, test resume upload → name suggestion → mobile auto-fill → duplicate message → Add save and Edit save. Check that mobile `+91 98765 43210` fills as `9876543210`, duplicates show red text, and editing a record does not flag its own existing mobile.
6. Confirm `candidate_name_parser_version` is `2026-10-15.6`, `candidate_mobile_parser_version` is `2026-10-15.1`, and `candidate_name_ai_result_status` identifies why AI output was rejected. Review the safe counters only; never log resume text, model response, mobile number, email, API token or names.

## Verification caveat

Focused standalone PHP tests are run for parser/normalization behavior in the build workspace, and all PHP syntax plus ZIP integrity are checked. This overlay does not include `artisan`, Composer `vendor/`, full route definitions, database credentials or the live Hugging Face provider. Therefore it cannot be claimed that the full PHPUnit suite, live database duplicate check, browser AJAX request or production upload/save has been executed here. Complete those checks in staging before production deployment.

---

**This v5 section supersedes the older v4 local-first behavior and deployment notes below.** The requested sequence is now AI-first, then deterministic local parsing when AI returns an empty, malformed, incomplete, or source-unsupported answer. The default remains one Hugging Face model attempt per resume. The controller has been updated as well as the extraction service so it no longer bypasses AI by calling the local-only parser first.

For the supplied `Deepika_AR_Resume.pdf`, the local regression harness expects `Deepika A R` after rejecting the malformed model string `DE<>E<>P<>IK<>A<> <>A<>` or an unsupported certification phrase such as `Poetry Competition`. A valid AI answer is preferred only when it matches reliable identity evidence in the original resume. All outputs remain recruiter-review suggestions; do not auto-save candidate names without review.

## v5 behavior and production safeguards

- **AI-first:** `CandidateNameExtractionService::extract()` sends a bounded, contact-redacted excerpt to Hugging Face before running local parsing. This is the priority requested for this release.
- **One attempt by default:** `HF_CANDIDATE_NAME_MAX_MODEL_ATTEMPTS=1` remains the default. Do not increase it unless additional inference cost is acceptable. A second AI call is not made after the controller's OCR fallback.
- **Evidence validation:** AI candidates must be plausible and supported by an identity/header line, an explicit name label, or tightly controlled compact-OCR evidence. Certification, award, skill, project, education, and experience list entries are not accepted as identity evidence.
- **Local fallback:** if AI fails, returns the malformed angle-bracket output, returns an incomplete or unsupported name, is unavailable, or returns invalid JSON, the local parser scans bounded resume text. It prefers the identity header and requires nearby contact evidence for late-document candidates.
- **PDF OCR fallback:** after AI plus local parsing still find no name, the controller tries one bounded first-page OCR fallback and runs local parsing against OCR/combined text only. It does not make a second Hugging Face request for the same upload. For scanned PDFs with no native text, OCR is done first solely to produce text; AI is then attempted before local parsing.
- **Privacy:** the Hugging Face client logs model ID and HTTP status only; it must not log the prompt, resume text, candidate name, response body, or token. The external inference excerpt is bounded and redacts common contact identifiers.
- **Response diagnostics:** `data.candidate_name_parser_version` is `2026-10-15.5`; `data.candidate_name_ai_attempted` says whether a model request was actually attempted; `data.candidate_name_evidence_engine` identifies the text/OCR source used.

## v5 changed files and code locations

Line numbers below are for this package version; they can shift if your branch differs.

- `app/Services/Recruitment/ResumeAutomation/CandidateNameExtractionService.php`: `VERSION` and bounds near lines 9–17; AI-first candidate validation/fallback in `extract()` near lines 28–101; strict local name fallback in `extractLocally()` near lines 157–300; identity-section-aware evidence in `hasReliableNameEvidence()` near lines 318–390; bounded inference excerpt in `getHeader()` near lines 530–560; model artifact cleanup in `cleanNameCandidate()` near the end of the service.
- `app/Services/Recruitment/ResumeAutomation/HuggingFaceInferenceService.php`: safer ATS-specific system/user prompt in the request payload near lines 50–70; single-attempt cap in `getModels()` near the bottom. Response-body logging is intentionally omitted.
- `app/Http/Controllers/hr_management/hr_recruiter/ManageCandidate.php`: upload extraction block near lines 1145–1220 now calls AI-first service before local fallback; bounded OCR runs after a failed extraction and does not make another paid model request.
- `config/recruitment_resume_ai.php`: HF enablement, model, timeouts and `HF_CANDIDATE_NAME_MAX_MODEL_ATTEMPTS` default of one.
- `tests/Unit/CandidateNameExtractionServiceTest.php`: AI-first ordering, malformed output, wrong certification suggestion, verified AI answer, partial initials, local fallback and negative cases.

## v5 deployment

1. Back up the currently deployed files. Copy all files from this archive into the matching paths in the Laravel project; do not replace the application root with this overlay ZIP.
2. Confirm `.env` has a valid `HF_TOKEN`, the chosen model is available to your enabled Hugging Face provider, and keep `HF_CANDIDATE_NAME_MAX_MODEL_ATTEMPTS=1`. A model HTTP 200 is not proof that its extracted name is valid; source-evidence validation is required.
3. Clear cached configuration/views and restart PHP workers if OPcache or long-running workers are enabled:

   ```bash
   php artisan optimize:clear
   php artisan config:clear
   php artisan view:clear
   ```

4. In the full Laravel repository, run `php artisan test --filter=CandidateNameExtractionServiceTest` and test upload → preview → candidate save on staging. The overlay ZIP intentionally does not contain `artisan`, `vendor`, or your application bootstrap.
5. Upload the exact sample again. When the model response is malformed, expected fields are `candidate_name: "Deepika A R"`, `candidate_name_source: "local_parser"`, `candidate_name_model: null`, `candidate_name_parser_version: "2026-10-15.5"`, and `candidate_name_ai_attempted: true`. If AI returns a clean, source-supported name, `candidate_name_source` should be `huggingface_primary`.
6. If the name still differs, preserve only the trace ID, parser version, text engine, evidence engine, AI-attempt flag, response source, and non-PII parser counters. Do not log or send the full resume text, prompt, model response body, or credential.

## v5 verification performed in this workspace

- PHP syntax check passed for all PHP files in the overlay.
- An isolated PHP regression harness ran the actual candidate-name service against the supplied PDF's Poppler-extracted text and simulated Hugging Face results: malformed `DE<>E<>P...` → `Deepika A R` via local fallback; `Poetry Competition` as the model answer → rejected and `Deepika A R` via local fallback; verified `DEEPIKA A R` → accepted as AI; no-name skills/certifications-only text → `not_found`; flattened text → `Deepika A R`.
- The controller is syntax-checked, and the code path contains one inference call before local parsing and no inference retry after OCR.
- The standalone harness is not the same as running Laravel PHPUnit or the production PHP-FPM/database/upload flow. The live Hugging Face endpoint/provider was not called from this workspace. Run the provided PHPUnit tests and staging upload/save test before production rollout.

---

# Recruitment Resume Automation — Candidate Name (Stage 1)

> **Production hotfix v4 (15 October 2026): local-first candidate-name extraction and credit-safe fallback.** The deterministic local parser runs before Hugging Face; flattened/out-of-order PDF text is segmented, and a bounded first-page OCR retry runs before any model request. A confirmed local name does not trigger inference. See the final v4 section for deployment and verification.

## Purpose and scope

This patch is based on the **latest uploaded** `ManageCandidate(4).php` and `JobRequest(3).php`, plus the already-updated candidate Blade view containing the optional Job Roles multi-select. It replaces the removed `App\Services\CandidateServices\ResumeExtractionService` dependency with a new, isolated service architecture under `App\Services\Recruitment\ResumeAutomation`.

**This release automates the candidate name only.** The resume is read in real time when selected; an AI/local-parser suggestion is shown in Title Case; the recruiter must verify or edit it. It intentionally does not auto-populate email, mobile, gender, marital status, qualification, major, or experience in this stage, and it avoids clearing these manually entered fields when another resume is selected or reset.

This package uses pretrained Hugging Face models through Inference Providers. It does **not** fine-tune a model on your candidate records; no approved labelled training dataset was supplied. Name extraction cannot be guaranteed for every OCR/resume layout, so manual verification remains part of the workflow.

## Files included

The archive paths are project-relative. Copy the complete files to the matching destinations.

| File                                                                                           | Change                                                                                                                                          | Important locations in the packaged file                                                                                                                                                                                                                                        |
| ---------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `resources/views/content/hr_management/hr_recruiter/manage_candidate/candidate_list.blade.php` | Updated Add Candidate resume upload/name assistance UI                                                                                          | CSS lines **1427–1436**; upload input and preview/status UI around **1578–1605**; name-only response handling **7221–7250**; safe resume preview **7360–7445**; upload/AJAX handler **7487–7596**; drag/drop/click/keyboard/reset handling **7599–7663**                        |
| `app/Http/Controllers/hr_management/hr_recruiter/ManageCandidate.php`                          | Replaced the removed parser dependency on the existing `extract_resume` endpoint                                                                | new service imports **29–30**; `extractCandidateData()` **1114–1209**                                                                                                                                                                                                           |
| `app/Http/Controllers/hr_management/hr_recruiter/JobRequest.php`                               | Add-candidate save path uses the new parser, validates resume tokens/hash, persists the selected resume and normalizes the submitted name       | new service imports **32–33**; `AddNewCandidate()` and validation **2459–2500**; secure cache/hash verification and parser fallback **2568–2604**; safe stored-file handling **2606–2650**; role selection/applicant save **2669–2700**; sanitized error response **2729–2741** |
| `app/Services/Recruitment/ResumeAutomation/ResumeTextExtractionService.php`                    | Text extraction across supported resume formats; PDF extraction prefers `pdftotext`, then falls back to the PHP parser and OCR                  | full file, **1–788**; PDF extractor/fallback around **209–300**; other extractors later in the file                                                                                                                                                                             |
| `app/Services/Recruitment/ResumeAutomation/HuggingFaceInferenceService.php`                    | Bounded Hugging Face chat-completions request; tries configured models sequentially up to the configured cap; local parsing continues on errors | full file, **1–168**; request and safe logging **28–91**; token/model configuration **93–168**                                                                                                                                                                                  |
| `app/Services/Recruitment/ResumeAutomation/CandidateNameExtractionService.php`                 | Name-only extraction, Indian-name/initial support, evidence checks, redaction, Title Case and deterministic fallback                            | full file, **1–327**; extraction flow **23 onward**; local fallback and plausibility rules **100 onward**                                                                                                                                                                       |
| `config/recruitment_resume_ai.php`                                                             | Hugging Face endpoint/model/attempt/timeouts, resume extraction limits and binary paths including `pdftotext`                                   | full file, **1–34**                                                                                                                                                                                                                                                             |

Line numbers refer to the files in this ZIP. Recount them after making any further edits.

## Architecture / request flow (v4)

1. The existing `POST` route named `extract_resume` receives the file. `web.php` is not changed because the route already points to `ManageCandidate::extractCandidateData()`.
2. `ResumeTextExtractionService` extracts text from the upload. The original uploaded file remains in the browser for final form submission; extracted resume text is cached server-side only.
3. `CandidateNameExtractionService::extractLocallyOnly()` runs first. It normalizes invisible characters, expands flattened lines/sections/contact fragments, rejects known skills and boilerplate, and scores candidate-like lines. A local match returns immediately and skips Hugging Face.
4. If local text parsing fails for a PDF, the controller performs a bounded first-page OCR retry. Local parsing runs on the OCR and combined text. If it still cannot find a reliable name, only then does the single configured Hugging Face attempt run.
5. Model output is cleaned and must be supported by extracted source evidence. Malformed/incomplete output is rejected unless the complete name can be reconstructed from explicit source-line evidence. Response text is not logged. The result always requires recruiter review.
6. The endpoint caches extracted resume text using a random token, SHA-256 of the actual file and a hash of the active session. The final `AddNewCandidate()` request verifies those values before reusing cached text; if the token is missing/expired/mismatched, it reparses the uploaded file.
7. At save time the submitted candidate name is normalized server-side and persisted to the existing applicant/candidate fields. The existing optional Job Roles multi-select continues to use the current `egc_applicant.job_role_id` JSON field.

## Supported resume formats

The allowlist is defined in `ResumeTextExtractionService::SUPPORTED_EXTENSIONS` and also used by the two controller validators:

- **PDF:** Poppler `pdftotext` first when available, then the PHP native PDF parser; scanned/low-text PDF OCR fallback on the first configured pages. If `pdftotext` is not installed, the service keeps using the PHP parser/OCR path.
- **Word:** DOCX and DOCM XML extraction, then PhpWord/LibreOffice fallback; legacy DOC tries Antiword, then LibreOffice/PhpWord.
- **OpenDocument:** ODT XML extraction with PhpWord/LibreOffice fallback.
- **Slides/spreadsheets:** PPTX/XLSX OpenXML extraction; legacy PPT/XLS and fallback conversions use LibreOffice.
- **Text/web:** RTF, TXT, TEXT, MD, MARKDOWN, HTML and HTM.
- **Images:** JPG/JPEG, PNG, WEBP, BMP, GIF, TIF and TIFF with Tesseract OCR. Image pixel limits and subprocess timeouts bound expensive OCR work.

This is a practical allowlist of common resume formats, **not every file format ever created**. A format not in the list is rejected. Scanned PDFs and images require OCR binaries/language data; legacy office formats require the relevant converter. If a supported file is unreadable, it can still be attached while the recruiter enters the name manually.

### HTML safety

HTML/HTM can be used as an extraction source, but it is not stored as an executable `.html` file in the public resume directory. The submitted HTML source is escaped and stored with a `.txt` attachment suffix to prevent same-origin script execution. The in-modal viewer opens the selected HTML as `text/plain` rather than executing it.

## Hugging Face configuration

The code makes a bounded request to the configured Hugging Face chat-completions endpoint. Set the model ID and token to values verified with your own account. The model output is treated as an untrusted suggestion and must match the resume header; otherwise the local parser runs. One model attempt is the default to avoid unexpected inference credits.

```dotenv
HF_TOKEN=hf_REPLACE_WITH_SERVER_SECRET
HF_CANDIDATE_NAME_ENABLED=true
HF_CHAT_COMPLETIONS_URL=https://router.huggingface.co/v1/chat/completions
HF_CANDIDATE_NAME_MODELS=meta-llama/Llama-3.1-8B-Instruct:fastest
HF_CANDIDATE_NAME_MAX_MODEL_ATTEMPTS=1
HF_CANDIDATE_NAME_TIMEOUT_SECONDS=8
HF_CANDIDATE_NAME_CONNECT_TIMEOUT_SECONDS=2
RESUME_PARSE_CACHE_TTL_MINUTES=20
RESUME_TEXT_MAX_CHARACTERS=150000
RESUME_OCR_ENABLED=true
RESUME_OCR_LANGUAGES=eng
RESUME_OCR_PDF_MAX_PAGES=3
RESUME_OCR_MAX_IMAGE_PIXELS=40000000
RESUME_PDFTOPPM_BINARY=pdftoppm
RESUME_PDFTOTEXT_BINARY=pdftotext
RESUME_TESSERACT_BINARY=tesseract
RESUME_ANTIWORD_BINARY=antiword
RESUME_LIBREOFFICE_BINARY=libreoffice
```

If you do not wish to use AI while testing the local parser, set `HF_CANDIDATE_NAME_ENABLED=false`. The local parser still runs. If the configured model is unavailable, it is not necessary to add multiple models; use the local suggestion and verify it manually.

## Server dependencies

Check these on the target production host before deployment:

1. PHP extensions: `fileinfo`, `mbstring`, `dom`, `zip`, and the extensions required by your existing Laravel app. `dom` and `zip` are needed for direct HTML/OpenXML parsing; fallbacks are best-effort when optional parsers are absent.
2. Composer packages referenced by the existing backend: `smalot/pdfparser` and `phpoffice/phpword`; Laravel/Symfony Process is used to run OCR/conversion programs without shell-string interpolation. Confirm their installed versions and security updates in the application lock file.
3. OS tools: Poppler `pdftotext` for reliable text-based PDF extraction and `pdftoppm` for scanned PDF pages; Tesseract with the selected language packs for image/PDF OCR; Antiword for legacy DOC fallback; LibreOffice headless for legacy Office fallback. Configure alternate absolute binary paths using the environment variables above. The service falls back if `pdftotext` is unavailable, but installing Poppler is recommended for production PDF name extraction.
4. Laravel cache and session must be configured consistently across the web nodes so the upload parse token can be resolved on candidate save. Keep the cache TTL short; the full extracted CV text is stored in cache temporarily but is not returned to the browser or logged by these services.

The parser caps uploads at **10 MB**, caps extracted text at the configured maximum, bounds archive sizes and OCR subprocesses, does not log resume text/LLM prompts, and redacts common contact/ID/address/parent/reference lines from the external header excerpt. Redaction is best-effort and does not guarantee that every personal detail in an unusual layout will be removed.

## Install/deploy

1. Back up the current Blade view and the two uploaded controller files.
2. Copy all seven code/config files from the ZIP to the project paths shown in the table. Do not copy the included README over an application README.
3. Set `HF_TOKEN`, `HF_CANDIDATE_NAME_MODELS` and `HF_CANDIDATE_NAME_MAX_MODEL_ATTEMPTS` as needed. Keep the attempt cap at `1` to avoid extra inference credits.
4. Install/verify the server dependencies above. Confirm `pdftotext -v` works under the same OS user/environment as PHP-FPM. Do not install OS binaries or change PHP extensions blindly on production; validate on staging first.
5. Run:

   ```bash
   php artisan optimize:clear
   php artisan config:clear
   php artisan view:clear
   php -l app/Http/Controllers/hr_management/hr_recruiter/ManageCandidate.php
   php -l app/Http/Controllers/hr_management/hr_recruiter/JobRequest.php
   php -l app/Services/Recruitment/ResumeAutomation/ResumeTextExtractionService.php
   php -l app/Services/Recruitment/ResumeAutomation/HuggingFaceInferenceService.php
   php -l app/Services/Recruitment/ResumeAutomation/CandidateNameExtractionService.php
   php -l config/recruitment_resume_ai.php
   ```

6. Use a staging account to test the complete upload → name preview → form save → applicant detail flow before releasing.

No migration is required. The patch reuses existing routes, applicant columns and role-selection storage.

## Acceptance test checklist

- [ ] Clear-text PDF with an all-caps Indian name and initials, e.g. `R.MAHA MUNIEESWARAN` → `R.Maha Munieeshwaran` (recruiter confirms spelling).
- [ ] `Name: ARUN KUMAR`, one-word `Name: ARUN`, names with apostrophes/hyphens, Unicode letters, multi-part South Indian names and spaced initials.
- [ ] No candidate name on the resume; only email, phone, objective text or reference/parent names → do not use email username, objective or parent/reference as the candidate name; allow manual entry.
- [ ] Contact-heavy header with mobile, DOB, Aadhaar/PAN labels and address → name still works; contact data are not sent as part of the external excerpt where recognized by the redaction rules.
- [ ] Scanned PDF, photo/scan image, DOC/DOCX/DOCM, ODT, RTF, TXT/Markdown/HTML, PPT/PPTX and XLS/XLSX. Test missing OCR/conversion binaries to confirm a manual-entry warning instead of a broken save.
- [ ] HF token unset/invalid, model unavailable, provider timeout/429, empty/invalid JSON, unsupported AI name and fallback model path.
- [ ] Name is editable. If the recruiter manually edits it, a later upload/reset must not clear that manual value. Selecting a new file clears only the unchanged previous AI suggestion.
- [ ] The selected resume remains attached if extraction fails. Expired/incorrect cache token or mismatched file hash must trigger safe reparsing, never reuse another file's text.
- [ ] Candidate name, mobile and email are resume suggestions only. They fill empty fields or replace the previous unchanged auto-suggestion; manually edited values are preserved. Gender, marital status, qualification, major, experience, source, description and roles remain under existing manual/form behavior. Existing `AddJobCandidate` behavior is retained.
- [ ] Repeated `AddNewCandidate` requests work in the same PHP worker; duplicate-mobile early returns roll back their open transaction; optional Job Roles selections and candidates with no selected roles continue to save correctly.

## Validation performed for this package

- PHP syntax checks: both updated controllers, all three new services and the updated config.
- Local parser regressions: a malformed AI suggestion is rejected and the clean PDF header still resolves locally to `Deepika A R`.
- Mocked name extraction regressions: uppercase Indian name + initials, explicit multi-word and one-word `Name:` labels, apostrophe name, rejection of headings/company names/objective prose, rejection of email-based guesses, rejection of `S/o` parent names, and evidence-backed AI output/title-casing.
- Parser smoke tests available in this environment: TXT, RTF and HTML fallback; extension allowlist; HTML content is not passed through as visible script text.
- JavaScript syntax check (`node --check`) on the updated resume upload/name-assistance script block.
- ZIP integrity and packaged project paths are checked after packaging.
- The Hugging Face endpoint was not live-tested because the production token/provider configuration is not available here. Verify the configured model on staging using the same token as the production application.

**Not verified here:** no live Hugging Face call or full Laravel upload/save integration was performed because the target application's vendor runtime and production token/provider configuration were not available. Poppler `pdftotext` is available in this working environment and was used to verify the exact uploaded PDF header. Real production PHP-FPM, database, browser, Office/OCR and server integration tests must still run in staging before release.

## Existing resume storage security limitation

To avoid breaking the existing attachment/Google Drive integration, non-HTML resumes continue to use the application's existing `public/job_applications/resume_files/` storage path. That means the **existing application storage model may expose personally identifiable resumes if the web server serves that directory publicly**. Confirm that this path is access-controlled in production. For a production platform handling Indian personal data, the longer-term fix is private disk storage plus an authenticated download/preview endpoint; that change was intentionally not included in this narrowly-scoped patch because it needs coordinated updates to existing resume links/viewers and integrations.

## Production candidate-name fix v4 — 15 October 2026

This revision supersedes earlier candidate-name hotfix notes in previous ZIPs. It responds to the same uploaded PDF (SHA-256 `1e2d3651b99a3662b58c00f7ba303b456a6ee4784b421922d455ee67ea571b58`) still returning `not_found` on v3 and to v3's `Canva Designing` false positive.

### Root cause addressed

Some PHP PDF parsers flatten most or all page content into a single long line, or return content out of visual order. The previous parser rejected long lines before searching them for contact separators, so it could discard the actual name. It also attempted Hugging Face before the local parser could reliably recover a name, spending an inference credit for a result that the application later rejected.

### v4 behavior

- **Local-first / no credit on local success:** local name extraction runs before AI. If it finds a source-supported name, `candidate_name_ai_attempted` is `false` and no Hugging Face HTTP request is made.
- **Flattened-layout recovery:** invisible Unicode whitespace is normalized; section labels and bullet boundaries are inserted; long and short lines are expanded into bounded fragments and contact-header suffixes before name scoring.
- **False-positive resistance:** common skill/tool terms (including Canva), section headings, list entries, education/project/company phrases, and objective boilerplate are excluded. If only skills or prose are present, the result stays `not_found` rather than inventing a name.
- **Bounded PDF OCR before inference:** if local text parsing fails for a PDF, page one is rendered and OCR'd with 12-second subprocess limits. Local parsing is rerun on OCR and combined text. Only after both text and OCR attempts fail can the configured single Hugging Face request run.
- **Source-evidence repair:** malformed separator artifacts are normalized. Missing trailing initials can only be restored when they appear explicitly in the source line or the compact OCR equivalent is supported by the header context. Otherwise the AI result is rejected.
- **Privacy / observability:** logs contain parser version, source, HTTP status, and non-PII parser counters only—not resume text, candidate names, prompts, or the model response body.
- **API diagnostic fields:** `data.candidate_name_parser_version` is `2026-10-15.4`; `data.candidate_name_ai_attempted` reports whether an inference request was attempted; `data.candidate_name_evidence_engine` shows whether the name came from resume text, OCR, or both.
- **Inference cap:** defaults to one model request when necessary. Do not configure multiple model IDs unless you intentionally accept additional inference requests/credits.

### Deploy

1. Back up the existing files, then deploy all project-relative files from this ZIP, especially `CandidateNameExtractionService.php`, `HuggingFaceInferenceService.php`, `ResumeTextExtractionService.php`, and `ManageCandidate.php`. Also deploy the matching `JobRequest.php`, Blade view, config and test file included in the package so the release stays coherent.
2. Check tools as the PHP-FPM/application user where practical: `pdftotext -v`, `pdftoppm -v`, and `tesseract --version`. `pdftotext` is preferred for the primary PDF text path; `pdftoppm` plus Tesseract support only the bounded page-one retry. Missing OCR tools do not prevent text parsing, but may leave some scanned PDFs requiring manual entry.
3. Clear Laravel caches and restart workers/OPcache if applicable:

   ```bash
   php artisan optimize:clear
   php artisan config:clear
   php artisan view:clear
   ```

4. On staging, run `php artisan test --filter=CandidateNameExtractionServiceTest` in the actual project (with its Composer dependencies installed), then test upload → name preview → candidate save and verify the resume hash/token still refers to the selected file.
5. Upload the same PDF. Expected result for its provided readable text is `candidate_name: "Deepika A R"`, `candidate_name_source: "local_parser"`, `candidate_name_parser_version: "2026-10-15.4"`, and `candidate_name_ai_attempted: false`. Do not treat this expected local regression result as proof of a live production upload; verify the real endpoint after deployment.
6. If the name is still not found, capture only these safe response/log fields: parser version, text engine, `candidate_name_ai_attempted`, `candidate_name_evidence_engine`, `local_parser_diagnostics` counters, and trace ID. Do not log the extracted resume text or HF response body. If the version is not `2026-10-15.4`, the request is serving stale or different code; inspect the active route, deployed path, workers, and OPcache before further parser edits.

### Validation / limits

- PHP syntax checks passed for all included PHP files.
- A standalone regression harness passed for the exact supplied PDF text, a flattened one-line version, skills appearing before the name, skills-only/no-name text, objective-only text, explicit one-word name labels, Unicode non-breaking spaces, and compact OCR + partial model output. It confirmed zero mocked AI calls when local extraction finds the name.
- ZIP integrity was checked after packaging.
- The full Laravel PHPUnit suite, database-backed candidate save, production PHP-FPM environment, and live Hugging Face account were not available here. Run the provided unit tests and complete upload/save flow on staging before deploying broadly.

For the supplied resume, the source text visibly contains `DEEPIKA A R` before `ABOUT ME`; its PDF hash matches the reported production hash. The parser output remains a suggestion and `review_required` stays `true`; the recruiter should confirm the spelling before saving.

## Production candidate email automation v7 — 15 October 2026

This incremental update is based on the working v6 package. It adds email suggestion only and keeps the existing candidate-name AI-first/local fallback and Indian mobile normalization/duplicate-check flow intact.

### What changed and why

- Added `app/Services/Recruitment/ResumeAutomation/CandidateEmailService.php` (`CandidateEmailService::VERSION = 2026-10-15.1`). It extracts email addresses locally from the existing parsed resume text; it does **not** send email addresses or extra prompts to Hugging Face and does not consume additional inference credits.
- The service normalizes case/whitespace, validates addresses with PHP's email validator, handles common PDF line-wraps around `@` and dots, scans a bounded amount of text, scores contact-header and labelled addresses above later body addresses, and rejects placeholders/generic mailboxes such as `candidate@example.com`, `yourname@gmail.com`, `support@...` and `careers@...`.
- For PDFs only, if the primary text has no usable email and the name/mobile pipeline has not already attempted OCR, the endpoint reuses the existing bounded first-page OCR fallback once and reruns local email extraction. It does not issue another Hugging Face call.
- `ManageCandidate::extractCandidateData()` returns `candidate_email`, `candidate_email_source` and `candidate_email_parser_version`; its short-lived resume-token cache includes the same metadata. Completion logs record only found/source/version flags, never the email address itself.
- `candidate_list.blade.php` fills the Add Candidate email field from a valid extracted suggestion only when the field is empty or still equals the previous resume auto-suggestion. Recruiter-entered values are not overwritten. Replacing/resetting a resume clears only the unchanged email auto-suggestion. The status/toast now lists whichever of name, mobile and email were suggested. The Edit Candidate email field and save validation are unchanged.
- Added `tests/Unit/CandidateEmailServiceTest.php` for header extraction, case normalization, whitespace and split-line repair, preference for candidate contact over reference email, placeholder rejection, and no-email/generic-mailbox cases.

### Response example

```json
{
  "candidate_email": "candidate@gmail.com",
  "candidate_email_source": "local_parser",
  "candidate_email_parser_version": "2026-10-15.1"
}
```

The value is a suggestion and still requires recruiter review. If the resume contains multiple real email addresses, the parser chooses the highest-ranked candidate based on contact labels and text position; it cannot guarantee ownership of an email from syntax alone. A recruiter should confirm the selected address before saving.

### Exact modified/additional code locations

The following line references match the files in this ZIP. Re-check after merging with any local changes.

- `app/Services/Recruitment/ResumeAutomation/CandidateEmailService.php` (new, lines 1–267): `extractFromResume()` lines 16–98; split-line repair lines 100–126; validation and placeholder rejection lines 165–214; candidate ranking lines 216–260.
- `app/Http/Controllers/hr_management/hr_recruiter/ManageCandidate.php`: import line 32; `extractCandidateData()` injection at lines 1116–1121; local email extraction/OCR retry at lines 1212–1227; non-PII completion log at lines 1245–1247; resume-token cache metadata at lines 1272–1274; response fields at lines 1305–1307.
- `resources/views/content/hr_management/hr_recruiter/manage_candidate/candidate_list.blade.php`: email auto-suggestion state line 7333; fill-if-empty/previous-suggestion logic lines 7368–7379; field status composition at lines 7387 onward; manual-edit tracking lines 7639–7642; clear-on-new-resume logic lines 7700–7704; toast field list lines 7760–7765; clear-on-file-reset logic lines 7853–7857.
- `tests/Unit/CandidateEmailServiceTest.php` (new, lines 1–70): seven focused regression tests.
- `README.md`: this deployment/verification section. No route addition, schema migration, or database change is needed.

### Deploy and verify

1. Back up the working v6 versions of `ManageCandidate.php` and `candidate_list.blade.php`.
2. Copy the included `CandidateEmailService.php`, updated `ManageCandidate.php`, updated `candidate_list.blade.php`, new `CandidateEmailServiceTest.php`, and README section to the matching paths. Do not replace unrelated project files with this patch.
3. Run:

   ```bash
   php artisan optimize:clear
   php artisan config:clear
   php artisan view:clear
   php -l app/Services/Recruitment/ResumeAutomation/CandidateEmailService.php
   php -l app/Http/Controllers/hr_management/hr_recruiter/ManageCandidate.php
   php artisan test --filter=CandidateEmailServiceTest
   ```

4. On staging, upload resumes covering: one header email; uppercase email; `name @ domain . com`; an email split at `@`/dot across PDF lines; placeholder email plus a real email; reference-only emails; scanned PDF; and no email. Confirm `data.candidate_email`, `candidate_email_source`, and `candidate_email_parser_version`.
5. Type a manual email, then upload or replace a resume: the manually entered value must remain unchanged. Clear the field or keep the prior unedited suggestion and upload a second resume: the new suggestion should fill it.
6. Confirm the existing name suggestion, 10-digit Indian mobile auto-fill, real-time duplicate mobile warning, Add Candidate save and Edit Candidate behavior still work. This update makes no email duplicate-check route and does not change database uniqueness rules.

### Validation and limits

- `php -l` passed for the new service, updated controller and new test file.
- A standalone harness passed seven focused cases: common header email, whitespace around `@`/dots, line-wrapped domain, candidate-vs-reference selection, placeholder exclusion, no email, and generic company mailboxes only.
- The package includes Laravel PHPUnit tests, but the full Laravel test runner and the browser/database upload-save flow were not available in this patch workspace. Run the included test in the actual application and verify on staging before production rollout.
