@extends('layouts/layoutMaster')

@section('title', 'Expenditure Management')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss', 
'resources/assets/vendor/libs/apex-charts/apex-charts.scss',

'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/apex-charts/apexcharts.js',
'resources/assets/vendor/libs/dropzone/dropzone.js', 
])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;

        $module_name = 'Accounts & Finance';
        $submenu_name = 'Credit Card Expenditure';
        $last_name = null;

        $add_expense = 0;
        $filter_expense = 0;
        $manage_product_permisn = 0;
        $manage_category_permisn = 0;
        $dashboard_permisn = 0;

        if (auth()->user()->hasPermission($module_name, $submenu_name, $last_name, 'Add Expense')) {
            $add_expense = 1;
        }
        if (auth()->user()->hasPermission($module_name, $submenu_name, $last_name, 'Filter')) {
            $filter_expense = 1;
        }
        if (auth()->user()->hasPermission($module_name, $submenu_name, $last_name, 'Manage Product')) {
            $manage_product_permisn = 1;
        }
        if (auth()->user()->hasPermission($module_name, $submenu_name, $last_name, 'Manage Category')) {
            $manage_category_permisn = 1;
        }
        if (auth()->user()->hasPermission($module_name, $submenu_name, $last_name, 'Dashboard')) {
            $dashboard_permisn = 1;
        }

  @endphp



  <style>
    
:root {
  /* Primary Brand */
  --expense-primary: #b12a1f;
  --expense-primary-hover: #8f1f16;
  --expense-secondary: #f5a623;

  /* Status */
  --expense-success: #22c55e;
  --expense-danger: #ef4444;
  --expense-warning: #f59e0b;
  --expense-info: #0ea5e9;

  /* Background */
  --expense-bg: #f5f5f9;
  --expense-card: #ffffff;

  /* Text */
  --expense-text: #1f2937;
  --expense-text-light: #6b7280;

  /* Borders */
  --expense-border: #e5e7eb;
  --expense-border-light: #f1f3f5;

  /* Brand Accent */
  --expense-accent: #f5a623;
  --expense-accent-light: #fff4de;

  /* Radius */
  --expense-radius-sm: 10px;
  --expense-radius: 14px;
  --expense-radius-lg: 18px;

  /* Shadow */
  --expense-shadow-sm: 0 2px 6px rgba(0, 0, 0, 0.05);

  --expense-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);

  --expense-shadow-hover: 0 12px 28px rgba(177, 42, 31, 0.15);

  /* Animation */
  --expense-transition: 0.28s ease;
}

.expense-chart-card {
  border: none;

  border-radius: var(--expense-radius);

  background: var(--expense-card);

  box-shadow: var(--expense-shadow);

  overflow: hidden;

  transition: var(--expense-transition);

  position: relative;
}



.expense-chart-card:hover {
  transform: translateY(-4px);

  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
}
.expense-chart-card .card-header {
  background: #fff;

  padding: 22px 24px 8px;

  border-bottom: none;
}

.expense-chart-card h5 {
  font-weight: 700;

  letter-spacing: -0.4px;

  color: var(--expense-text);
}

.expense-chart-card small {
  color: var(--expense-muted);
}
.expense-chart-card .card-body {
  padding: 20px 24px 24px;
}
.expense-chart-container {
  width: 100%;

  min-height: 360px;
}
.expense-donut-chart {
  width: 100%;

  height: 340px;

  display: flex;

  align-items: center;

  justify-content: center;
}
.expense-bar-chart {
  width: 100%;

  min-height: 340px;
}
#expenseCategoryLegend {
  display: flex;

  flex-direction: column;

  gap: 14px;
}
.category-item {
  display: flex;

  align-items: center;

  justify-content: space-between;
}
.category-left {
  display: flex;

  align-items: center;

  gap: 12px;
}
.category-dot {
  width: 11px;

  height: 11px;

  border-radius: 50%;
}
.category-title {
  font-weight: 600;

  font-size: 13px;
}
.category-value {
  color: #6b7280;

  font-size: 13px;
}
/* =========================================================
   RECENT EXPENSE ACTIVITY
   ========================================================= */

.expense-timeline {

    max-height: 430px;

    overflow-y: auto;

    overflow-x: hidden;

    padding: 4px 8px 4px 2px;

}


/* Scrollbar */

.expense-timeline::-webkit-scrollbar {

    width: 5px;

}

.expense-timeline::-webkit-scrollbar-track {

    background: transparent;

}

.expense-timeline::-webkit-scrollbar-thumb {

    background: #d9dce5;

    border-radius: 20px;

}


/* =========================================================
   ACTIVITY ITEM
   ========================================================= */

.expense-activity-item {

    display: flex;

    position: relative;

    min-height: 78px;

    padding-bottom: 15px;

}


/* =========================================================
   LEFT ICON / CONNECTOR
   ========================================================= */
.expense-activity-line {

    width: 38px;

    flex: 0 0 38px;

    position: relative;

    display: flex;

    justify-content: center;

}


.expense-activity-line::after {

    content: '';

    position: absolute;

    top: 34px;

    bottom: -2px;

    left: 18px;

    width: 1px;

    background: #e5e7eb;

}


/* Hide connector for last item */

.expense-activity-item:last-child
.expense-activity-line::after {

    display: none;

}


/* =========================================================
   ICON
   ========================================================= */

.expense-activity-icon {

    width: 34px;

    height: 34px;

    border-radius: 9px;

    display: flex;

    align-items: center;

    justify-content: center;

    position: relative;

    z-index: 2;

    flex-shrink: 0;

    background: color-mix(
        in srgb,
        var(--activity-color) 10%,
        #ffffff
    );

    color: var(--activity-color);

    border: 1px solid color-mix(
        in srgb,
        var(--activity-color) 16%,
        #ffffff
    );

}


.expense-activity-icon i {

    font-size: 17px;

    line-height: 1;

}



/* =========================================================
   CONTENT
   ========================================================= */

.expense-activity-body {

    flex: 1;

    min-width: 0;

    padding: 0 2px 0 10px;


}


/* =========================================================
   TOP ROW
   ========================================================= */

.expense-activity-top {

    display: flex;

    align-items: flex-start;

    justify-content: space-between;

    gap: 14px;

}


/* Product */

.expense-activity-product {

    font-size: 14px;

    line-height: 19px;

    font-weight: 700;

    color: #172033;

    white-space: nowrap;

    overflow: hidden;

    text-overflow: ellipsis;

}


/* Category */

.expense-activity-category {

    margin-top: 2px;

    font-size: 12px;

    line-height: 17px;

    color: #8b93a3;

}


/* =========================================================
   AMOUNT / TIME
   ========================================================= */

.expense-activity-finance {

    flex-shrink: 0;

    text-align: right;

}


.expense-activity-amount {

    font-size: 14px;

    line-height: 19px;

    font-weight: 750;

    color: #d93025;

    white-space: nowrap;

}


.expense-activity-time {

    margin-top: 2px;

    font-size: 11px;

    line-height: 16px;

    color: #9aa1ae;

    white-space: nowrap;

}


/* =========================================================
   META
   ========================================================= */
/* =========================================================
   ACTIVITY META
   ========================================================= */

.expense-activity-meta {

    display: flex;

    align-items: center;

    gap: 6px;

    width: 100%;

    min-width: 0;

    margin-top: 9px;

}

.expense-meta-text {

    min-width: 0;

    overflow: hidden;

    text-overflow: ellipsis;

    white-space: nowrap;

}


/* Common meta item */

.expense-meta {

    display: inline-flex;

    align-items: center;

    gap: 5px;

    height: 26px;

    min-width: 0;

    padding: 0 8px;

    border-radius: 7px;

    font-size: 10.5px;

    line-height: 26px;

    font-weight: 600;

    white-space: nowrap;

    overflow: hidden;

    text-overflow: ellipsis;

    border: 1px solid transparent;

}


/* Icon */

.expense-meta i {

    flex: 0 0 auto;

    font-size: 13px;

    line-height: 1;

}


/* =========================================================
   COMPANY
   ========================================================= */

.expense-meta.company {

    flex: 1 1 auto;

    min-width: 0;

    max-width: 210px;

    background: #fff8e8;

    color: #9a6700;

    border-color: #f9e5b4;

}


/* Company text should truncate */

.expense-meta.company {

    overflow: hidden;

    text-overflow: ellipsis;

}


/* =========================================================
   CREDIT CARD
   ========================================================= */

.expense-meta.card {

    flex: 0 0 auto;

    max-width: 100px;

    background: #eef8fc;
    align-items: center;
    justify-content: center;

    color: #087b9e;

    border-color: #d4edf5;

}


/* =========================================================
   META HOVER
   ========================================================= */

.expense-meta {

    transition:
        background-color .15s ease,
        border-color .15s ease;

}


.expense-meta.company:hover {

    background: #fff3d6;

    border-color: #f3d995;

}


.expense-meta.card:hover {

    background: #e4f5fa;

    border-color: #c3e5ef;

}


/* =========================================================
   SMALL SCREEN
   ========================================================= */

@media (max-width: 576px) {

    .expense-activity-meta {

        gap: 5px;

    }


    .expense-meta {

        height: 24px;

        padding: 0 7px;

        font-size: 10px;

        line-height: 24px;

    }


    .expense-meta.company {

        max-width: 155px;

    }


    .expense-meta.card {

        max-width: 85px;

    }

}


/* =========================================================
   HOVER
   ========================================================= */

.expense-activity-item {

    transition:
        transform 0.15s ease,
        background-color 0.15s ease;

}


.expense-activity-item:hover {

    background: #fafbfc;

    border-radius: 10px;

}


.expense-activity-item:hover
.expense-activity-icon {

    transform: translateY(-1px);

}


/* =========================================================
   MOBILE
   ========================================================= */

@media (max-width: 576px) {

    .expense-timeline {

        padding-right: 2px;

    }


    .expense-activity-line {

        width: 36px;

        flex-basis: 36px;

    }


    .expense-activity-line::after {

        left: 17px;

    }


    .expense-activity-icon {

        width: 34px;

        height: 34px;

        border-radius: 9px;

    }


    .expense-activity-icon i {

        font-size: 17px;

    }


    .expense-activity-body {

        padding-left: 8px;

    }


    .expense-activity-top {

        gap: 8px;

    }


    .expense-activity-product {

        max-width: 150px;

    }


    .expense-activity-amount {

        font-size: 13px;

    }

}
.expense-skeleton {
  border-radius: 12px;

  background: linear-gradient(
    90deg,
    #f4f5f8 25%,

    #eceef3 37%,

    #f4f5f8 63%
  );

  background-size: 400% 100%;

  animation: expenseLoading 1.2s infinite;
}
@keyframes expenseLoading {
  0% {
    background-position: 100% 0;
  }

  100% {
    background-position: -100% 0;
  }
}
@media (max-width: 1200px) {
  .expense-chart-container {
    min-height: 300px;
  }

  .expense-bar-chart {
    min-height: 300px;
  }
}

@media (max-width: 991px) {
  .expense-chart-card {
    margin-bottom: 20px;
  }
}
@media (max-width: 768px) {
  .expense-chart-container {
    min-height: 260px;
  }

  .expense-donut-chart {
    height: 260px;
  }

  .expense-bar-chart {
    min-height: 260px;
  }
}

.expense-stat-card,
.expense-chart-card {
  transition: var(--expense-transition);

  border: 1px solid var(--expense-border);

  border-radius: var(--expense-radius);

  background: #fff;
  /* padding:10px; */

  box-shadow: var(--expense-shadow-sm);
}
.expense-stat-card .expense-card-top {
    display:flex;
    align-items:center;
    gap:6px;
    margin-bottom:8px;
}

.expense-stat-card{
  padding: 18px 24px;
}

.expense-card-icon{
    padding: 6px;
    border-radius: 4px;
}


.expense-stat-card:hover,
.expense-chart-card:hover {
  transform: translateY(-4px);

  border-color: var(--expense-primary);

  box-shadow: var(--expense-shadow-hover);
}

.btn-expense-primary {
  background: var(--expense-primary);

  border-color: var(--expense-primary);

  color: #fff;
}

.btn-expense-primary:hover {
  background: var(--expense-primary-hover);

  border-color: var(--expense-primary-hover);
}

.bg-expense-primary {
  background: #fde8e6;
  color: #b12a1f;
}

.bg-expense-warning {
  background: #fff4de;
  color: #f5a623;
}

.bg-expense-success {
  background: #dcfce7;
  color: #22c55e;
}

.bg-expense-info {
  background: #e0f2fe;
  color: #0284c7;
}
.timeline-item {
  cursor: pointer;

  transition: 0.25s;

  border-radius: 12px;

  padding: 12px;
}

.timeline-item:hover {
  background: #fafafa;

  transform: translateX(6px);
}

.timeline-dot {
  transition: 0.25s;
}

.timeline-item:hover .timeline-dot {
  transform: scale(1.12);
}
.expense-table-card {
  border: none;

  border-radius: 18px;

  overflow: hidden;

  box-shadow: var(--expense-shadow);
}

/* Keep the expenditure table's horizontal overflow inside its own viewport.
   Do not add a fixed height: the table grows naturally and pagination stays below it. */
.expense-transactions-card {
  width: 100%;
  max-width: 100%;
  min-width: 0;
}

.expense-transactions-card .card-body {
  width: 100%;
  max-width: 100%;
  min-width: 0;
}

.expense-table-scroll {
  display: block;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior-x: contain;
}

#expenseTable {
  width: max-content;
  min-width: 1200px;
  margin-bottom: 0;
  table-layout: auto;
}

#expenseTable thead th {
  /* background: #fafafa; */
  font-size: 13px;
  font-weight: 700;
  white-space: nowrap;
}

#expenseTable tbody td {
  vertical-align: middle;
  white-space: nowrap;
}

/* Prevent table contents from forcing the browser viewport wider than the page. */
@media (max-width: 768px) {
  #expenseTable {
    min-width: 1100px;
  }

  #pagination-container {
    column-gap: 10px;
    row-gap: 10px;
  }

  #pagination-container .pagination {
    flex-wrap: wrap;
  }
}
.table-loading {
  opacity: 0.55;

  pointer-events: none;

  transition: 0.25s;
}
.expense-date {
  line-height: 1.2;
}

.expense-date small {
  font-size: 11px;
}

.expense-check {
  cursor: pointer;
}

.avatar-xs {
  width: 26px;

  height: 26px;
}

#expenseTable code {
  color: var(--expense-primary);

  font-size: 12px;
}

#expenseTable .badge {
  font-size: 12px;
  font-weight: 600;
}
.table-success {
  animation: rowHighlight 2.5s;
}

@keyframes rowHighlight {
  0% {
    background: #dcfce7;
  }

  100% {
    background: transparent;
  }
}

#expenseBulkToolbar {
  border-radius: 12px;

  margin-bottom: 15px;

  animation: fadeBulk 0.25s;
}

@keyframes fadeBulk {
  from {
    opacity: 0;

    transform: translateY(-10px);
  }

  to {
    opacity: 1;

    transform: none;
  }
}

/*=====================================================
Dashboard Loading
=====================================================*/

.expense-loading {
  opacity: 0.55;

  pointer-events: none;

  transition: 0.25s;
}

.expense-loading .expense-card-value {
  color: #c9c9c9;
}
.expense-stat-card.active {
  border-color: var(--expense-primary);

  transform: translateY(-3px);
}
.card-action .card-header{
    display:block;
}

/* =========================================================
   COMPANY CELL
========================================================= */

.expense-company-cell {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 170px;
}


/* =========================================================
   COMPANY BADGE
========================================================= */

.expense-company-badge {
    width: 34px;
    height: 34px;

    flex: 0 0 34px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background:
        color-mix(
            in srgb,
            var(--company-color) 12%,
            #ffffff
        );

    color: var(--company-color);

    border: 1px solid
        color-mix(
            in srgb,
            var(--company-color) 20%,
            #ffffff
        );

    font-size: 11px;
    font-weight: 800;
    letter-spacing: .4px;

    line-height: 1;

    transition:
        transform .15s ease,
        box-shadow .15s ease;
}
.expense-entity-badge {
 
    display: inline-flex;
    align-items: center;
    justify-content: center;

    background:
        color-mix(
            in srgb,
            var(--entity-color) 12%,
            #ffffff
        );

    color: var(--entity-color);

    border: 1px solid
        color-mix(
            in srgb,
            var(--entity-color) 20%,
            #ffffff
        );

    font-size: 12px;
    font-weight: 800;
    letter-spacing: .4px;

    line-height: 1;

    transition:
        transform .15s ease,
        box-shadow .15s ease;
}


/* =========================================================
   COMPANY NAME
========================================================= */

.expense-company-name {
    max-width: 150px;

    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;

    font-size: 13px;
    font-weight: 600;

    color: #374151;
}


/* =========================================================
   HOVER
========================================================= */

.expense-company-cell:hover .expense-company-badge {
    transform: translateY(-1px);

    box-shadow:
        0 3px 8px
        color-mix(
            in srgb,
            var(--company-color) 18%,
            transparent
        );
}


/* EXPENSE AMOUNT BREAKDOWN */

.expense-amount-wrapper {
    position: relative;
    display: inline-flex;
    justify-content: flex-end;
    align-items: center;
}

.expense-total-amount {
    display: inline-flex;
    align-items: center;
    justify-content: flex-end;
    gap: 5px;

    color: #b12a1f;
    font-weight: 750;
    font-size: 13px;

    white-space: nowrap;
    cursor: default;
}

.expense-amount-info {
    width: 19px;
    height: 19px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    color: #6b7280;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;

    font-size: 12px;

    cursor: help;

    transition:
        color .18s ease,
        background-color .18s ease,
        border-color .18s ease,
        transform .18s ease;
}

.expense-amount-info:hover {
    color: #b12a1f;
    background: #fde8e6;
    border-color: #f1c4bf;
    transform: scale(1.08);
}


/* =========================================================
   TOOLTIP
   ========================================================= */

.expense-amount-tooltip {
    position: absolute;

    right: 0;
    top: calc(100% + 12px);

    width: 330px;

    padding: 16px;

    background: #ffffff;

    border: 1px solid #e5e7eb;
    border-radius: 14px;

    box-shadow:
        0 16px 45px rgba(15, 23, 42, .16),
        0 3px 10px rgba(15, 23, 42, .06);

    z-index: 9999;

    opacity: 0;
    visibility: hidden;

    transform:
        translateY(-6px)
        scale(.98);

    transform-origin: top right;

    transition:
        opacity .18s ease,
        visibility .18s ease,
        transform .18s ease;

    pointer-events: none;

    white-space: normal;
}


/* Tooltip arrow */

.expense-amount-tooltip::before {
    content: '';

    position: absolute;

    top: -6px;
    right: 18px;

    width: 11px;
    height: 11px;

    background: #ffffff;

    border-left: 1px solid #e5e7eb;
    border-top: 1px solid #e5e7eb;

    transform: rotate(45deg);
}


/* Show */

.expense-amount-wrapper:hover .expense-amount-tooltip {
    opacity: 1;
    visibility: visible;

    transform:
        translateY(0)
        scale(1);
}


/* =========================================================
   HEADER
   ========================================================= */

.expense-tooltip-header {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 12px;
}

.expense-tooltip-title {
    font-size: 14px;
    font-weight: 750;

    color: #172033;

    line-height: 20px;
}

.expense-tooltip-subtitle {
    margin-top: 2px;

    font-size: 11px;

    color: #8b93a3;
}

.expense-tooltip-icon {
    width: 34px;
    height: 34px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 9px;

    color: #b12a1f;
    background: #fde8e6;

    border: 1px solid #f4d0cc;

    flex-shrink: 0;
}

.expense-tooltip-icon i {
    font-size: 17px;
}


/* =========================================================
   DIVIDER
   ========================================================= */

.expense-tooltip-divider {
    height: 1px;

    margin: 12px 0;

    background: #eef0f3;
}


/* =========================================================
   ROW
   ========================================================= */

.expense-tooltip-row {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 15px;

    min-height: 30px;

    font-size: 12px;
}

.expense-tooltip-row span {
    display: inline-flex;

    align-items: center;

    gap: 7px;

    color: #667085;
}

.expense-tooltip-row span i {
    font-size: 14px;

    color: #98a2b3;
}

.expense-tooltip-row strong {
    color: #344054;

    font-size: 12px;

    font-weight: 650;

    white-space: nowrap;
}


/* =========================================================
   GST SECTION
   ========================================================= */

.expense-tooltip-section-label {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 10px;

    margin-top: 7px;
    margin-bottom: 3px;

    padding: 7px 9px;

    border-radius: 8px;

    background: #f8fafc;

    font-size: 11px;

    font-weight: 700;

    color: #475467;
}

.expense-tooltip-section-label > span:first-child {
    display: inline-flex;

    align-items: center;

    gap: 5px;
}

.expense-tooltip-section-label i {
    color: #667085;
}

.expense-gst-badge {
    padding: 3px 7px;

    border-radius: 20px;

    background: #ecfdf3;

    color: #027a48;

    border: 1px solid #abefc6;

    font-size: 9px;

    font-weight: 700;

    white-space: nowrap;
}

.expense-tooltip-subrow {
    padding-left: 9px;
}

.expense-tooltip-gst-total {
    margin-top: 2px;

    padding: 5px 9px;

    border-radius: 7px;

    background: #fffaf0;
}

.expense-tooltip-gst-total span,
.expense-tooltip-gst-total strong {
    color: #9a6700;
}


/* =========================================================
   GST NOT APPLICABLE
   ========================================================= */

.expense-gst-not-applicable {
    display: flex;

    align-items: center;

    gap: 6px;

    margin: 5px 0;

    padding: 7px 9px;

    border-radius: 8px;

    background: #f8fafc;

    color: #667085;

    border: 1px solid #eaecf0;

    font-size: 11px;

    font-weight: 600;
}

.expense-gst-not-applicable i {
    font-size: 14px;
}


/* =========================================================
   FINAL TOTAL
   ========================================================= */

.expense-tooltip-total {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 15px;

    padding: 10px;

    border-radius: 9px;

    background: #fff7f5;

    border: 1px solid #f4d0cc;
}

.expense-tooltip-total span {
    display: inline-flex;

    align-items: center;

    gap: 6px;

    color: #7f1d1d;

    font-size: 12px;

    font-weight: 700;
}

.expense-tooltip-total span i {
    font-size: 15px;
}

.expense-tooltip-total strong {
    color: #b12a1f;

    font-size: 13px;

    font-weight: 800;

    white-space: nowrap;
}


/* =========================================================
   MOBILE
   ========================================================= */

@media (max-width: 576px) {

    .expense-amount-tooltip {
        position: fixed;

        left: 50%;
        right: auto;

        top: 50%;

        width: min(330px, calc(100vw - 30px));

        transform:
            translate(-50%, -46%)
            scale(.98);
    }

    .expense-amount-wrapper:hover .expense-amount-tooltip {
        transform:
            translate(-50%, -50%)
            scale(1);
    }

    .expense-amount-tooltip::before {
        display: none;
    }
}

  

/* Amount breakdown: keep template content hidden inside table cells. The visible
   tooltip is portalled to <body> by the delegated JS below, outside overflow wrappers. */
.expense-amount-wrapper > .expense-amount-tooltip {
    display: none !important;
}

.expense-amount-tooltip.expense-amount-tooltip-portal {
    display: block !important;
    position: fixed !important;
    inset: auto;
    box-sizing: border-box;
    width: min(330px, calc(100vw - 24px)) !important;
    max-width: calc(100vw - 24px) !important;
    max-height: calc(100vh - 24px) !important;
    overflow-x: hidden;
    overflow-y: auto;
    overscroll-behavior: contain;
    margin: 0 !important;
    opacity: 1 !important;
    visibility: visible !important;
    transform: none !important;
    transform-origin: initial !important;
    pointer-events: auto !important;
    z-index: 20000 !important;
    -webkit-overflow-scrolling: touch;
}

/* The portalled panel is positioned dynamically above/below its trigger, so an
   in-cell arrow would point incorrectly. Hiding it avoids a misleading pointer. */
.expense-amount-tooltip.expense-amount-tooltip-portal::before {
    display: none !important;
}

@media (max-width: 576px) {
    .expense-amount-tooltip.expense-amount-tooltip-portal {
        width: min(330px, calc(100vw - 24px)) !important;
        max-width: calc(100vw - 24px) !important;
    }
}

</style>
<!-- Lead List Table -->
 <div class="card card-action mb-2" style="box-shadow: none;">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Expenditure Management </h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb mb-1">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-cash-multiple"></i> Accounts & Finance
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            Expenditure
                        </a>
                    </li>
                </ol>
            </nav>
            <p class="text-muted mb-2">
                Track and manage all company credit expenses.
            </p>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
             <div class="d-flex justify-content-lg-end justify-content-start align-items-center gap-2 mt-lg-0 mt-3 flex-wrap">
                {{-- Refresh --}}
                <div>
                    @if($manage_category_permisn == 1)
                    <span class="text-primary cursor-pointer badge bg-label-primary border border-primary" id="btnAddCategory" data-bs-toggle="modal"  data-bs-target="#categoryModal"><i class="mdi mdi-plus"></i>Manage Category</span>
                    @endif 
                     @if($manage_product_permisn == 1)
                    <span class="ms-2 text-primary cursor-pointer badge bg-label-primary border border-primary"id="btnAddProduct" data-bs-toggle="modal" data-bs-target="#productModal"><i class="mdi mdi-plus"></i>Manage Product</span>
                    @endif  
                </div>
                <button id="btnRefreshExpense" class="btn btn-label-secondary">
                    <i class="mdi mdi-refresh me-1"></i>
                    Refresh
                </button>
                {{-- Export --}}
                <div class="dropdown">
                    <!-- <button class="btn btn-label-primary dropdown-toggle"  data-bs-toggle="dropdown">
                        <i class="mdi mdi-download me-1"></i>
                        Export
                    </button> -->
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item" href="javascript:void(0)" id="exportExcel">
                                <i class="mdi mdi-file-excel me-2"></i>
                                Excel
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="javascript:void(0)" id="exportPDF">
                                <i class="mdi mdi-file-pdf-box me-2"></i>
                                PDF
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="javascript:void(0)" id="exportCSV">
                                <i class="mdi mdi-file-document-outline me-2"></i>
                                CSV
                            </a>
                        </li>
                    </ul>
                </div>
                {{-- Add Expense --}}
                @if($add_expense == 1)
                <button  id="btnAddExpense" class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#expenseModal">
                    <i class="mdi mdi-plus me-1"></i>
                    Add Expense
                </button>
                @endif
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="card shadow-none border mb-4" id="expenseToolbar">
            <div class="card-body py-3">
                <div class="row g-3 align-items-end">
                    {{-- Search --}}
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <label class="form-label fw-semibold">
                            Search
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-label-secondary">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" class="form-control" id="expenseSearch" placeholder="Expense / Ref No / Invoice">
                        </div>
                    </div>

                    {{-- Card --}}

                    <div class="col-xl-2 col-lg-3 col-md-6">
                        <label class="form-label fw-semibold">
                            Card
                        </label>
                        <select class="form-select select3" id="filterCard">
                            <option value="">All Cards</option>
                        </select>
                    </div>
                    {{-- Company --}}

                    <div class="col-xl-2 col-lg-3 col-md-6">
                        <label class="form-label fw-semibold">
                            Company
                        </label>
                        <select class="form-select select3" id="filterCompany">
                            <option value="">
                                All Companies
                            </option>
                        </select>
                    </div>

                    {{-- Entity --}}

                    <div class="col-xl-2 col-lg-3 col-md-6">

                        <label class="form-label fw-semibold">

                            Entity

                        </label>

                        <select
                            class="form-select select3"
                            id="filterEntity">

                            <option value="">

                                All Entities

                            </option>

                        </select>

                    </div>

                    {{-- FY --}}

                    <div class="col-xl-2 col-lg-3 col-md-6">
                        <label class="form-label fw-semibold">Financial Year</label>
                        <select class="form-select select3" id="filterFY">
                            <option>2026-2027</option>
                        </select>
                    </div>

                    {{-- Month --}}

                    <div class="col-xl-2 col-lg-3 col-md-6">
                        <label class="form-label fw-semibold">Month</label>
                        <select class="form-select select3" id="filterMonth">
                            <option value="">All</option>
                            <option value="1">January</option>
                            <option value="2">February</option>
                            <option value="3">March</option>
                            <option value="4">April</option>
                            <option value="5">May</option>
                            <option value="6">June</option>
                            <option value="7">July</option>
                            <option value="8">August</option>
                            <option value="9">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>
                    </div>

                    {{-- Filter Button --}}
                    <!-- <div class="col-xl-1 col-lg-3 col-md-6">
                        <button class="btn btn-primary w-100" id="btnToggleFilter">
                            <i class="mdi mdi-tune"></i>
                        </button>
                    </div> -->
                </div>
            </div>
        </div>

        {{-- ===========================================================
                Advanced Filter Card
        ============================================================ --}}
        <div class="card border mb-4 d-none" id="advancedExpenseFilter">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">Advanced Filters</h6>
                    <button class="btn btn-sm btn-label-danger" id="btnCloseAdvance">
                        Close
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    {{-- Category --}}
                    <div class="col-xl-3">
                        <label class="form-label">
                            Expense Category
                        </label>
                        <select  class="form-select select3"  id="filterCategory">
                            <option value="">All Categories</option>
                        </select>
                    </div>
                    {{-- Product --}}
                    <div class="col-xl-3">
                        <label class="form-label">Expense Product</label>
                        <select  class="form-select select3"  id="filterProduct">
                            <option value="">All Products</option>
                        </select>
                    </div>
                    {{-- Credit Card --}}
                    <div class="col-xl-3">
                        <label class="form-label">Credit Card</label>
                        <select class="form-select select3" id="filterCreditCard">
                            <option value=""> All Cards</option>
                        </select>
                    </div>
                    {{-- Date --}}
                    <div class="col-xl-3">
                        <label class="form-label">Expense Date</label>
                        <input type="text" class="form-control flatpickr-range" id="filterDate">
                    </div>
                    {{-- Amount --}}
                    <div class="col-xl-3">
                        <label class="form-label"> Amount Range</label>
                        <input type="text" class="form-control" id="filterAmount"  placeholder="1000 - 10000">
                    </div>
                    {{-- Reference --}}
                    <div class="col-xl-3">
                        <label class="form-label">Reference No</label>
                        <input type="text"  class="form-control"  id="filterReference">
                    </div>
                    {{-- Created By --}}
                    <div class="col-xl-3">
                        <label class="form-label"> Created By</label>
                        <select  class="form-select select3" id="filterCreatedBy">
                            <option>All Users</option>
                        </select>
                    </div>
                    {{-- Status --}}
                    <div class="col-xl-3">
                        <label class="form-label">Status</label>
                        <select class="form-select select3" id="filterStatus">
                            <option value="">All</option>
                            <option value="0">Active</option>
                            <option value="1">Inactive</option>
                        </select>
                    </div>
                </div>

                <hr>

                <div class="text-end">
                    <button class="btn btn-label-secondary" id="btnResetFilter">
                        Reset
                    </button>
                    <button class="btn btn-primary" id="btnApplyFilter">
                        Apply Filters
                    </button>
                </div>
            </div>
        </div>


        <div class="row g-4 mb-4">
            {{-- Total Expense --}}
            <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="expense-stat-card " id="cardTotalExpense">
                    <div class="expense-card-top">
                        <div class="expense-card-icon bg-label-danger">
                            <i class="mdi mdi-wallet"></i>
                        </div>
                        <span class="expense-trend up" id="expenseGrowth">
                            +12%
                        </span>
                    </div>
                    <div class="expense-card-body">
                        <span class="expense-card-title">
                            Total Expense
                        </span>
                        <h3 class="expense-card-value counter" id="totalExpense">
                            ₹0
                        </h3>
                        <small> Compared to previous month</small>
                    </div>
                </div>
            </div>

            {{-- Month Expense --}}

            <div class="col-xl-3 col-lg-6">
                <div class="expense-stat-card">
                    <div class="expense-card-top">
                        <div class="expense-card-icon bg-label-warning">
                            <i class="mdi mdi-calendar-month"></i>
                        </div>
                        <span class="expense-trend">
                            This Month
                        </span>
                    </div>
                    <div class="expense-card-body">
                        <span class="expense-card-title">
                            Monthly Expense
                        </span>
                        <h3 class="expense-card-value counter" id="monthlyExpense">
                            ₹0
                        </h3>
                        <small>
                            Current Financial Month
                        </small>
                    </div>
                </div>
            </div>
            {{-- Today --}}
            <div class="col-xl-3 col-lg-6">
                <div class="expense-stat-card">
                    <div class="expense-card-top">
                        <div class="expense-card-icon bg-label-success">
                            <i class="fa-solid fa-calendar-check"></i>
                        </div>
                        <span class="expense-trend">
                            Today
                        </span>
                    </div>
                    <div class="expense-card-body">
                        <span class="expense-card-title">
                            Today's Expense
                        </span>
                        <h3 class="expense-card-value counter" id="todayExpense">
                            ₹0
                        </h3>
                        <small>
                            Current Date
                        </small>
                    </div>
                </div>
            </div>
            {{-- Average --}}
            <div class="col-xl-3 col-lg-6">
                <div class="expense-stat-card">
                    <div class="expense-card-top">
                        <div class="expense-card-icon bg-label-info">
                            <i class="mdi mdi-chart-line"></i>
                        </div>
                        <span class="expense-trend">
                            Average
                        </span>
                    </div>
                    <div class="expense-card-body">
                        <span class="expense-card-title">
                            Daily Average
                        </span>
                        <h3 class="expense-card-value counter" id="dailyAverage">
                            ₹0
                        </h3>
                        <small>
                            Average Daily Spend
                        </small>
                    </div>
                </div>
            </div>
        </div>
        <div class="row g-4 mb-4">

            {{-- Monthly Expense Trend --}}
            <div class="col-12 col-xl-8">

                <div class="card expense-chart-card h-100">

                    <div class="card-header border-0 pb-0">

                        <div class="d-flex justify-content-between align-items-start">

                            <div>

                                <h5 class="mb-1 fw-semibold">

                                    Monthly Expense Trend

                                </h5>

                                <small class="text-muted">

                                    Expense analysis for selected financial period

                                </small>

                            </div>

                            <div class="dropdown">

                                <button
                                    class="btn btn-sm btn-label-secondary dropdown-toggle"
                                    data-bs-toggle="dropdown">

                                    This Year

                                </button>

                                <ul class="dropdown-menu dropdown-menu-end">

                                    <li>
                                        <a class="dropdown-item chart-period"
                                        data-period="month"
                                        href="javascript:void(0);">

                                            This Month

                                        </a>
                                    </li>

                                    <li>
                                        <a class="dropdown-item chart-period"
                                        data-period="quarter"
                                        href="javascript:void(0);">

                                            This Quarter

                                        </a>
                                    </li>

                                    <li>
                                        <a class="dropdown-item chart-period"
                                        data-period="year"
                                        href="javascript:void(0);">

                                            This Year

                                        </a>
                                    </li>

                                </ul>

                            </div>

                        </div>

                    </div>

                    <div class="card-body">

                        <div
                            id="expenseTrendChart"
                            class="expense-chart-container">

                        </div>

                    </div>

                </div>

            </div>

            {{-- Expense Category --}}
            <div class="col-12 col-xl-4">

                <div class="card expense-chart-card h-100">

                    <div class="card-header border-0 pb-0">

                        <h5 class="mb-1 fw-semibold">

                            Expense Categories

                        </h5>

                        <small class="text-muted">

                            Category-wise distribution

                        </small>

                    </div>

                    <div class="card-body">

                        <div
                            id="expenseCategoryChart"
                            class="expense-donut-chart">

                        </div>

                        <div
                            id="expenseCategoryLegend"
                            class="mt-4">

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="row g-4 mb-4">

            {{-- Top Expense Products --}}

            <div class="col-xl-7">

                <div class="card expense-chart-card h-100">

                    <div class="card-header border-0">

                        <h5 class="mb-1">

                            Top Expense Products

                        </h5>

                        <small class="text-muted">

                            Highest spending products

                        </small>

                    </div>

                    <div class="card-body">

                        <div
                            id="expenseProductChart"
                            class="expense-bar-chart">

                        </div>

                    </div>

                </div>

            </div>

            {{-- Recent Activity --}}

            <div class="col-xl-5">

                <div class="card expense-chart-card h-100">

                    <div class="card-header border-0">

                        <div class="d-flex justify-content-between">

                            <div>

                                <h5 class="mb-1">

                                    Recent Expense Activity

                                </h5>

                                <small class="text-muted">

                                    Latest expense logs

                                </small>

                            </div>

                            <button
                                class="btn btn-sm btn-label-primary"
                                id="btnRefreshTimeline">

                                <i class="mdi mdi-refresh"></i>

                            </button>

                        </div>

                    </div>

                    <div
                        class="card-body expense-timeline"

                        id="expenseTimeline">

                        {{-- AJAX Timeline --}}

                    </div>

                </div>

            </div>

        </div>

        <div class="card expense-transactions-card">

            <div class="card-header border-0 pb-0">
                <div class="row align-items-center">
                    {{-- Left --}}
                    <div class="col-lg-6">
                        <h5 class="mb-1">
                            Expense Transactions
                        </h5>
                        <small class="text-muted">
                            Credit expense logs
                        </small>
                    </div>
                    {{-- Right --}}
                    <div class="col-lg-6">
                        <div class="d-flex justify-content-end">
                            <div>
                                @php
                                    $perpage = 25;
                                @endphp
                                <span>Show</span>
                                <select id="perpage" class="form-select select3 form-select-sm w-75px"
                                    onchange="window.expenseTable && window.expenseTable.changePageLength(this.value)">
                                    @php $options = [5,10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="alert alert-primary d-none" id="expenseBulkToolbar">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <b id="selectedCount">0</b>Selected
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-sm btn-danger" id="btnBulkDelete">
                                        <i class="mdi mdi-delete"></i>
                                        Delete
                                    </button>
                                    <button class="btn btn-sm btn-success" id="btnBulkExport">
                                        <i class="mdi mdi-download"></i>
                                        Export
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body pt-2">
                <div class="expense-table-scroll" role="region" aria-label="Expense transactions table" tabindex="0">
                    <table id="expenseTable" class="table table-hover align-middle">
                        <thead>
                            <tr class="text-start fw-bold fs-7 gs-0 bg-primary text-white sticky-top">
                                <th>Expense Date</th>
                                <th>Company / <br>Entity</th>
                                <th>Product /Category</th>
                                <th>Credit Card</th>
                                <th>Transaction</th>
                                <th class="text-end">Amount</th>
                                <th>Frequency /<br>Next Payment</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>

        </div>

    </div>
</div>

@include('content.accounts_finance.expenditure.modal.expense_modal')
@include('content.accounts_finance.expenditure.modal.category_modal')
@include('content.accounts_finance.expenditure.modal.product_modal')



<script>

window.expenseRoutes = {
    dashboard: "{{ route('accounts.expenditure.dashboard') }}",
    dashboardCards: "{{ route('accounts.expenditure.dashboard.cards') }}",
    monthly: "{{ route('accounts.expenditure.chart.monthly') }}",
    category: "{{ route('accounts.expenditure.chart.category') }}",
    product: "{{ route('accounts.expenditure.chart.product') }}",
    timeline: "{{ route('accounts.expenditure.timeline') }}",
    datatable: "{{ route('accounts.expenditure.datatable') }}",
    store: "{{ route('accounts.expenditure.store') }}",
    bulkDelete: "{{ route('accounts.expenditure.bulk.delete') }}",
    bulkExport: "{{ route('accounts.expenditure.bulk.export') }}",
    companies: "{{ route('accounts.expenditure.companies') }}",
    entities: "{{ route('accounts.expenditure.entities') }}",
    categories: "{{ route('accounts.expenditure.categories') }}",
    products: "{{ route('accounts.expenditure.products') }}",
    creditCards: "{{ route('accounts.expenditure.credit.cards') }}",
    show: "{{ route('accounts.expenditure.show', ':id') }}",
    edit: "{{ route('accounts.expenditure.edit', ':id') }}",
    update: "{{ route('accounts.expenditure.update', ':id') }}",
    destroy: "{{ route('accounts.expenditure.destroy', ':id') }}",
    duplicate: "{{ route('accounts.expenditure.duplicate', ':id') }}",
    history: "{{ route('accounts.expenditure.history', ':id') }}",

    categoryStore: "{{ route('accounts.expenditure.categories.store') }}",
    categoryShow: "{{ route('accounts.expenditure.categories.show', ':id') }}",
    categoryUpdate: "{{ route('accounts.expenditure.categories.update', ':id') }}",
    categoryDelete: "{{ route('accounts.expenditure.categories.destroy', ':id') }}",

    productStore: "{{ route('accounts.expenditure.products.store') }}",
    productShow: "{{ route('accounts.expenditure.products.show', ':id') }}",
    productUpdate: "{{ route('accounts.expenditure.products.update', ':id') }}",
    productDelete: "{{ route('accounts.expenditure.products.destroy', ':id') }}",
    productList: "{{ route('accounts.expenditure.products_list') }}",
};

</script>






<script>
    'use strict';

class ExpenseDataTable {
    constructor() {
        this.table = null;
        this.selectedRows = [];
        this.currentPage = 1;
        this.pageLength = 25;
        this.totalRecords = 0;
        this.totalPages = 1;
        this.searchTimer = null;
    }

  init() {
    this.initialize();

    this.registerEvents();
  }
  

    initialize() {

        this.table = $('#expenseTable');

        if (!this.table.length) {

            console.warn(
                'Expense table #expenseTable not found.'
            );

            this.renderNoData();

            return;
        }

        this.load();

    }

    load() {

        const self = this;

        const params = {

            page: this.currentPage,

            sorting_filter: this.pageLength,

            search: $('#expenseSearch').val() || '',

            card_id: $('#filterCard').val() || '',
            company: $('#filterCompany').val() || '',

            entity: $('#filterEntity').val() || '',

            financial_year:
                $('#filterFY').val() || '',

            month:
                $('#filterMonth').val() || '',

            category:
                $('#filterCategory').val() || '',

            product:
                $('#filterProduct').val() || '',

            credit_card:
                $('#filterCreditCard').val() || '',

            date:
                $('#filterDate').val() || '',

            amount:
                $('#filterAmount').val() || '',

            reference:
                $('#filterReference').val() || '',

            created_by:
                $('#filterCreatedBy').val() || '',

            status:
                $('#filterStatus').val() || ''

        };


        this.table.addClass('table-loading');


        $.ajax({

            url: window.expenseRoutes.datatable,

            type: 'GET',

            data: params,

            dataType: 'json',

            success: function (response) {

                self.render(response);

            },

            error: function (xhr) {

                console.error(
                    'Expense table load error:',
                    xhr.responseText
                );

                self.renderEmpty(
                    'Unable to load expense transactions.'
                );

            },

            complete: function () {

                self.table.removeClass(
                    'table-loading'
                );

            }

        });

    }

    render(response) {

        const rows =
            Array.isArray(response.data)
                ? response.data
                : [];


        this.totalRecords = Number(
            response.total ||
            response.recordsTotal ||
            rows.length
        );


        this.totalPages = Math.max(
            1,
            Math.ceil(
                this.totalRecords /
                this.pageLength
            )
        );


        const tbody =
            this.table.find('tbody');


        tbody.empty();


        if (!rows.length) {

            this.renderEmpty(
                'No expense transactions found.'
            );

            this.updateRecordCount(
                this.totalRecords
            );

            this.updatePagination(
                Number(response.current_page || this.currentPage),
                Number(response.last_page || 1),
                this.totalRecords,
                this.pageLength
            );

            return;
        }


        rows.forEach(row => {

            tbody.append(
                this.renderRow(row)
            );

        });


        this.updateRecordCount(
            this.totalRecords
        );


        this.updatePagination(
            Number(response.current_page || this.currentPage),
            Number(response.last_page || 1),
            this.totalRecords,
            this.pageLength
        );


        this.selectedRows = [];

        // $('#checkAllExpense')
        //     .prop('checked', false)
        //     .prop('indeterminate', false);


        this.updateBulkToolbar();


        $('[data-bs-toggle="tooltip"]').tooltip();

    }

    

    formatDisplayDate(date) {

      if (!date) {
          return '—';
      }

      const value = String(date).substring(0, 10);

      const parts = value.split('-');

      if (parts.length !== 3) {
          return this.escapeHtml(value);
      }

      return `${parts[2]}-${parts[1]}-${parts[0]}`;
  }

    renderRow(row) {

        const frequency = row.frequency || 'One Time';

        const isRecurring =
            row.frequency_key &&
            row.frequency_key !== 'one_time';

        const nextPayment =
            row.next_payment_date
                ? this.formatDisplayDate(row.next_payment_date)
                : '—';

        return `
            <tr
                class="expense-row"
                data-row="true"
                data-id="${this.escapeHtml(row.id)}"
                data-transaction-type="${this.escapeHtml(row.transaction_type || 'expense')}"
            >

                <!-- Expense Date -->
                <td>
                    <div class="expense-date-cell">
                        ${this.renderExpenseDate(row.expense_date)}
                    </div>
                </td>


                <!-- Company -->
                <td>
                    ${this.renderCompany(
                        row.company,
                        null,
                        row
                    )}

                    ${row.entity
                        ? this.renderEntity(row.entity, null,row)
                        : '<span class="text-muted">—</span>'
                    }
                </td>

                <!-- Category -->
                <td>
                  ${this.renderProduct(
                        row.product,
                        null,
                        row
                    )}
                    ${this.renderCategory(
                        row.category,
                        null,
                        row
                    )}
                </td>


                <!-- Credit Card -->
                <td>
                    ${this.renderCreditCard(
                        row.credit_card,
                        null,
                        row
                    )}
                </td>


                <!-- Transaction -->
                <td>
                    <div class="expense-reference-cell">

                        <div class="expense-reference-name">
                            ${this.escapeHtml(
                                row.reference || '—'
                            )}
                        </div>

                    </div>
                </td>


                <!-- Amount -->
                <td class="text-end">
                    ${this.renderAmount(row)}
                    <div class="d-block">
                      ${ (row.is_gst == 1 && row.gst_amount > 0)  ? '<span class="expense-gst-badge">GST Applicable</span>' : ''}
                    </div>
                </td>


                <!-- Frequency -->
                <td>
                    <div class="expense-frequency-cell">

                        <span
                            class="
                                expense-frequency-badge badge rounded
                                ${row.transaction_type === 'credit_card_payment'
                                    ? 'is-payment'
                                    : (isRecurring ? 'is-recurring bg-label-info' : (row.transaction_type === 'credit_card_other_expense' ? '' :'is-onetime bg-label-info') )
                                }
                            "
                            ${row.transaction_type === 'credit_card_payment'
                                ? 'style="background:#dcfce7;color:#166534;border-color:#bbf7d0;"'
                                : (row.transaction_type === 'credit_card_other_expense'
                                    ? 'style="background:#fee2e2;color:#991b1b;border-color:#fecaca;"'
                                    : '')
                            }
                        >
                            <i class="
                                mdi
                                ${row.transaction_type === 'credit_card_payment'
                                    ? 'mdi-cash-check'
                                    : (row.transaction_type === 'credit_card_other_expense'
                                        ? 'mdi-receipt-text-outline'
                                        : (isRecurring ? 'mdi-refresh' : 'mdi-check-circle-outline'))
                                }
                            "></i>

                            ${this.escapeHtml(frequency)}
                        </span>

                    </div>
                    ${
                        row.transaction_type !== 'credit_card_payment' && isRecurring && row.next_payment_date

                        ? `
                            <div class="expense-next-payment">
                                <div class="expense-next-payment-date">
                                    <i class="mdi mdi-calendar-clock-outline"></i>
                                    ${nextPayment}
                                </div>
                            </div>
                        `

                        : `
                            <span class="text-muted">
                                ${row.transaction_type === 'credit_card_payment'
                                    ? '-'
                                    : (row.transaction_type === 'credit_card_other_expense' ? '-' : '—')}
                            </span>
                        `
                    }
                </td>
            </tr>
        `;
    }
    renderNoData() {

        const tbody =
            this.table.find('tbody');


        tbody.html(`
            <tr>
                <td
                    colspan="9"
                    class="text-center py-5"
                >

                    <div class="text-muted">

                        <i
                            class="mdi mdi-receipt-text-outline fs-2"
                        ></i>

                        <div class="mt-2">
                            No Transaction Found
                        </div>

                    </div>

                </td>
            </tr>
        `);

    }

    renderEmpty(message) {

        const tbody =
            this.table.find('tbody');


        tbody.html(`
            <tr>
                <td
                    colspan="9"
                    class="text-center py-5"
                >

                    <div class="text-muted">

                        <i
                            class="mdi mdi-receipt-text-outline fs-2"
                        ></i>

                        <div class="mt-2">
                            ${this.escapeHtml(message)}
                        </div>

                    </div>

                </td>
            </tr>
        `);

    }
    updateRecordCount(count) {

        $('#expenseRecordCount').text(
            Number(count || 0)
                .toLocaleString('en-IN') +
            ' Records'
        );

    }

    updatePagination(currentPage, lastPage, total, perpage) {
        const container = document.getElementById('pagination-container');
        if (!container) return;

        currentPage = Math.max(1, Number(currentPage) || 1);
        lastPage = Math.max(1, Number(lastPage) || 1);
        total = Math.max(0, Number(total) || 0);
        perpage = Math.max(1, Number(perpage) || this.pageLength);

        const start = total === 0 ? 0 : ((currentPage - 1) * perpage) + 1;
        const end = Math.min(currentPage * perpage, total);

        container.innerHTML = '';
        container.style.display = 'flex';
        container.style.justifyContent = 'space-between';
        container.style.alignItems = 'center';
        container.style.flexWrap = 'wrap';
        container.style.gap = '12px';

        const showingInfo = document.createElement('span');
        showingInfo.className = 'text-muted small';
        showingInfo.textContent = `Showing ${start} to ${end} of ${total} results`;
        container.appendChild(showingInfo);

        const pageButton = (label, page, disabled, active = false, title = '') => `
            <li class="page-item ${disabled ? 'disabled' : ''} ${active ? 'active' : ''}">
                <button type="button" class="page-link expense-page"
                    data-page="${page}" ${disabled ? 'disabled' : ''}
                    ${title ? `aria-label="${title}" title="${title}"` : ''}>${label}</button>
            </li>`;

        let html = '<nav aria-label="Expense pagination"><ul class="pagination mb-0">';
        html += pageButton('«', 1, currentPage <= 1, false, 'First page');
        html += pageButton('‹', currentPage - 1, currentPage <= 1, false, 'Previous page');

        const startPage = Math.max(1, currentPage - 2);
        const endPage = Math.min(lastPage, currentPage + 2);
        for (let page = startPage; page <= endPage; page++) {
            html += pageButton(page, page, false, page === currentPage, `Page ${page}`);
        }

        html += pageButton('›', currentPage + 1, currentPage >= lastPage, false, 'Next page');
        html += pageButton('»', lastPage, currentPage >= lastPage, false, 'Last page');
        html += '</ul></nav>';
        container.insertAdjacentHTML('beforeend', html);

        const perpageSelect = document.getElementById('perpage');
        if (perpageSelect) perpageSelect.value = String(perpage);
    }

    renderCheckbox(data) {
    return `

    <label class="form-check">

    <input

    type="checkbox"

    class="form-check-input expense-check"

    value="${data}">

    </label>

    `;
  }
  syncCheckbox() {
    const total = $('.expense-check').length;

    const checked = $('.expense-check:checked').length;

    // $('#checkAllExpense').prop(
    //   'checked',

    //   checked === total
    // );

    // $('#checkAllExpense').prop(
    //   'indeterminate',

    //   checked > 0 && checked < total
    // );
  }
  renderExpenseDate(data) {
    if (!data) return '-';

    const date = new Date(data);

    const day = date.toLocaleDateString('en-IN', {
      day: '2-digit'
    });

    const month = date.toLocaleDateString('en-IN', {
      month: 'short'
    });

    const year = date.getFullYear();

    return `

        <div class="expense-date">

        <div class="fw-semibold">

        ${day} ${month}

        </div>

        <small class="text-muted">

        ${year}

        </small>

        </div>

        `;
  }

  renderCompany(company, type = null, row = null) {

    const shortName = row?.company_short || 'EG';

    const color = row?.company_base_color || '#B12A1F';

    return `
        <div class="expense-company-cell">

          

            <div class="expense-company-info">
                <div class="expense-company-name">
                    ${this.escapeHtml(company || 'Elysium Groups')}
                </div>
            </div>

        </div>
    `;
}
  renderEntity(entity, type = null, row = null) {
      const color = row?.entity_base_color || '#B12A1F';
    return `

        <span class=" badge expense-entity-badge" style="--entity-color: ${this.escapeHtml(color)};">

        ${entity}

        </span>

        `;
  }
  renderCategory(data, type, row) {
    return `

    <span

    class="badge"

    style="background:${row.category_color};color:#fff;">

    ${this.escapeHtml(data || '')}

    </span>

    `;
  }
  renderProduct(data, type, row) {
    return `

    <div>

      <div class="fw-semibold">

      ${data}

      </div>
    </div>

    `;
  }
  renderCreditCard(data, type, row) {
    return `

    <div>

    <div>

    ${data}

    </div>

    <small class="text-muted">

    •••• ${row.card_last_four}

    </small>

    </div>

    `;
    }
    renderReference(data) {
        return `

    <code>

    ${data}

    </code>

    `;
  }
  renderAmount(row) {

    const money = (value) => {
        return Number(value || 0).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    };

    // Card repayments are positive/green; card-specific other expenses are debits/red.
    if (row.transaction_type === 'credit_card_payment') {
        const paymentAmount = Math.abs(Number(row.amount || row.total_amount || 0));

        return `
            <div class="expense-amount-wrapper" style="flex-direction:column;align-items:flex-end;gap:2px;">
                <div class="expense-total-amount" style="color:#15803d;">
                    + ₹ ${money(paymentAmount)}
                </div>
                <small class="text-success">Card payment</small>
            </div>
        `;
    }

    if (row.transaction_type === 'credit_card_other_expense') {
        const otherExpenseAmount = Math.abs(Number(row.amount || row.total_amount || 0));

        return `
            <div class="expense-amount-wrapper" style="flex-direction:column;align-items:flex-end;gap:2px;">
                <div class="expense-total-amount" style="color:#dc2626;">
                    − ₹ ${money(otherExpenseAmount)}
                </div>
                <small class="text-danger">Other card expense</small>
            </div>
        `;
    }

    const amount = Number(row.amount || 0);
    const sgst = Number(row.sgst || 0);
    const cgst = Number(row.cgst || 0);
    const gstAmount = Number(row.gst_amount || 0);
    const fcyFee = Number(row.fcy_conversion_fee || 0);
    const otherFee = Number(row.other_transaction_fee || 0);
    const total = Number(row.total_amount || 0);
    const isGst = Number(row.is_gst || 0) === 1;

    return `
        <div class="expense-amount-wrapper">

            <div class="expense-total-amount" style="color:#dc2626;">
                − ₹ ${money(total)}

                <span
                    class="expense-amount-info"
                    role="button"
                    tabindex="0"
                    aria-label="View amount breakdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                >
                    <i class="mdi mdi-information-outline"></i>
                </span>
                
            </div>

            <div class="expense-amount-tooltip">

                <div class="expense-tooltip-header">
                    <div>
                        <div class="expense-tooltip-title">
                            Amount Breakdown
                        </div>

                        <div class="expense-tooltip-subtitle">
                            Final payable amount
                        </div>
                    </div>

                    <div class="expense-tooltip-icon">
                        <i class="mdi mdi-receipt-text-outline"></i>
                    </div>
                </div>

                <div class="expense-tooltip-divider"></div>

                <div class="expense-tooltip-row">
                    <span>
                        <i class="mdi mdi-cash-minus"></i>
                        Expense Amount
                    </span>

                    <strong>
                        ₹ ${money(amount)}
                    </strong>
                </div>

                ${
                    isGst
                    ? `
                        <div class="expense-tooltip-section-label">
                            <span>
                                <i class="mdi mdi-receipt-text-check-outline"></i>
                                GST Details
                            </span>

                            <span class="expense-gst-badge">
                                GST Applicable
                            </span>
                        </div>

                        <div class="expense-tooltip-row expense-tooltip-subrow">
                            <span>
                                SGST
                            </span>

                            <strong>
                                ₹ ${money(sgst)}
                            </strong>
                        </div>

                        <div class="expense-tooltip-row expense-tooltip-subrow">
                            <span>
                                CGST
                            </span>

                            <strong>
                                ₹ ${money(cgst)}
                            </strong>
                        </div>

                        <div class="expense-tooltip-row expense-tooltip-gst-total">
                            <span>
                                Total GST
                            </span>

                            <strong>
                                ₹ ${money(gstAmount)}
                            </strong>
                        </div>
                    `
                    : `
                        <div class="expense-gst-not-applicable">
                            <i class="mdi mdi-information-outline"></i>
                            GST Not Applicable
                        </div>
                    `
                }

                ${
                    fcyFee > 0
                    ? `
                        <div class="expense-tooltip-row">
                            <span>
                                <i class="mdi mdi-currency-usd"></i>
                                FCY Conversion Fee
                            </span>

                            <strong>
                                ₹ ${money(fcyFee)}
                            </strong>
                        </div>
                    `
                    : ''
                }

                ${
                    otherFee > 0
                    ? `
                        <div class="expense-tooltip-row">
                            <span>
                                <i class="mdi mdi-cash-plus"></i>
                                Other Transaction Fee
                            </span>

                            <strong>
                                ₹ ${money(otherFee)}
                            </strong>
                        </div>
                    `
                    : ''
                }

                <div class="expense-tooltip-divider"></div>

                <div class="expense-tooltip-total">
                    <span>
                        <i class="mdi mdi-calculator-variant-outline"></i>
                        Total Amount
                    </span>

                    <strong>
                        ₹ ${money(total)}
                    </strong>
                </div>

            </div>
        </div>
    `;
}
  renderCreatedBy(data, type, row) {
    return `

    <div class="d-flex align-items-center">

    <div class="avatar avatar-xs me-2">

    <span class="avatar-initial bg-label-success">

    ${row.created_initial}

    </span>

    </div>

    ${data}

    </div>

    `;
  }
  renderAction(data, type, row) {
    return `

    <div class="dropdown">

    <button

    class="btn btn-sm btn-icon"

    data-bs-toggle="dropdown">

    <i class="mdi mdi-dots-vertical"></i>

    </button>

    <ul class="dropdown-menu dropdown-menu-end">

    <li>

    <a

    class="dropdown-item btn-view"

    data-id="${row.id}">

    <i class="mdi mdi-eye-outline me-2"></i>

    View

    </a>

    </li>

    <li>

    <a

    class="dropdown-item btn-edit"

    data-id="${row.id}">

    <i class="mdi mdi-pencil-outline me-2"></i>

    Edit

    </a>

    </li>

    <li>

    <a

    class="dropdown-item btn-history"

    data-id="${row.id}">

    <i class="mdi mdi-history me-2"></i>

    History

    </a>

    </li>

    <li><hr class="dropdown-divider"></li>

    <li>

    <a

    class="dropdown-item text-danger btn-delete"

    data-id="${row.id}">

    <i class="mdi mdi-delete me-2"></i>

    Delete

    </a>

    </li>
    <li>

    <a

    class="dropdown-item btn-duplicate"

    data-id="${row.id}">

    <i class="mdi mdi-content-copy me-2"></i>

    Duplicate

    </a>

    </li>

    </ul>

    </div>

    `;
  }
  registerEvents() {
    const self = this;

    $('#btnRefreshTable').on('click', function () {
      self.reload();
    });
    $('#btnRefreshExpense').on('click', function () {
      self.reload();
    });

    $('#expenseSearch').on('keyup', function () {
      clearTimeout(self.searchTimer);

      self.searchTimer = setTimeout(function () {
        self.reload();
      }, 400);
    });

    $('#btnApplyFilter').on('click', function () {
      self.reload();
    });

    $(document).on('click', '.btn-view', e => {
      const id = $(e.currentTarget).data('id');

      this.view(id);
    });
    $(document).on('keydown', e => {
      if (e.altKey && e.key === 'n') {
        $('#btnAddExpense').click();
      }
    });

    $(document).on('click', '.btn-edit', e => {
      const id = $(e.currentTarget).data('id');

      this.edit(id);
    });
    $(document).on('click', '.btn-history', e => {
      const id = $(e.currentTarget).data('id');

      this.history(id);
    });

    $(document).on(
        'click',
        '.expense-page',
        function () {

            const page =
                Number($(this).data('page'));

            if (!page) {
                return;
            }

            if (
                page < 1 ||
                page > self.totalPages
            ) {
                return;
            }

            self.currentPage = page;

            self.load();

        }
    );

    // $('#checkAllExpense').on('change', e => {
    //   const checked = $(e.currentTarget).prop('checked');

    //   $('.expense-check')
    //     .prop('checked', checked)

    //     .trigger('change');
    // });
    // $(document).on(
    //   'change',

    //   '.expense-check',

    //   () => {
    //     this.collectSelection();
    //   }
    // );

    $('#btnBulkDelete').click(() => {
      this.bulkDelete();
    });

    $(document).on('click', '.btn-duplicate', e => {
      this.duplicate($(e.currentTarget).data('id'));
    });
   

    $('#expenseTable tbody').on(
        'dblclick',
        'tr[data-id][data-transaction-type="expense"]',
        e => {

            const id =
                $(e.currentTarget)
                    .data('id');

            if (id) {

                this.edit(id);

            }

        }
    );

    $('#btnBulkExport').click(() => {
      window.location = window.expenseRoutes.bulkExport + '?ids=' + this.selectedRows.join(',');
    });

    $('#btnResetFilter').on('click', function () {
      $('.select2').val('').trigger('change');

      $('#filterDate').val('');

      $('#filterAmount').val('');

      $('#filterReference').val('');

      self.reload();
    });
  }

  collectSelection() {
    this.selectedRows = [];

    // $('.expense-check:checked').each((i, item) => {
    //   this.selectedRows.push($(item).val());
    // });

    this.updateBulkToolbar();
    this.syncCheckbox();
  }

  updateBulkToolbar() {
    if (this.selectedRows.length === 0) {
      $('#expenseBulkToolbar').addClass('d-none');

      return;
    }

    $('#expenseBulkToolbar').removeClass('d-none');

    $('#selectedCount').html(this.selectedRows.length);
  }

  bulkDelete() {
    if (this.selectedRows.length === 0) {
      toastr.warning('Please select expense.');

      return;
    }

    Swal.fire({
      title: 'Delete Selected?',

      icon: 'warning',

      showCancelButton: true,

      confirmButtonText: 'Delete'
    }).then(result => {
      if (result.isConfirmed) {
        this.destroySelected();
      }
    });
  }

  destroySelected() {
    $.ajax({
      url: window.expenseRoutes.bulkDelete,

      type: 'POST',

      data: {
        _token: $('meta[name="csrf-token"]').attr('content'),

        ids: this.selectedRows
      },

      success: response => {
        toastr.success(response.message);

        this.reload();

        // $('#checkAllExpense').prop('checked', false);

        this.selectedRows = [];

        this.updateBulkToolbar();
      }
    });
  }

  duplicate(id) {
    $.ajax({
      url: window.expenseRoutes.duplicate.replace(':id', id),

      type: 'POST',

      data: {
        _token: $('meta[name="csrf-token"]').attr('content')
      },

      success: response => {
        toastr.success(response.message);

        this.reload();
      }
    });
  }
  highlight(id) {
    const row = $('#expenseTable').find(`tr[data-id="${id}"]`);

    row.addClass('table-success');

    setTimeout(() => {
      row.removeClass('table-success');
    }, 2500);
  }

  view(id) {
    $.ajax({
      url: window.expenseRoutes.view.replace(':id', id),

      type: 'GET',

      success: response => {
        ExpenseModal.view(response.data);
      },

      error: () => {
        toastr.error('Unable to load expense.');
      }
    });
  }

  edit(id) {
    $.ajax({
      url: window.expenseRoutes.edit.replace(':id', id),

      type: 'GET',

      success: response => {
        ExpenseModal.edit(response.data);
      },

      error: () => {
        toastr.error('Unable to load expense.');
      }
    });
  }
  delete(id) {
    Swal.fire({
      title: 'Delete Expense?',

      text: 'This action cannot be undone.',

      icon: 'warning',

      showCancelButton: true,

      confirmButtonColor: '#B12A1F',

      confirmButtonText: 'Delete',

      cancelButtonText: 'Cancel'
    }).then(result => {
      if (result.isConfirmed) {
        this.destroy(id);
      }
    });
  }
  destroy(id) {
    $.ajax({
      url: window.expenseRoutes.delete.replace(':id', id),

      type: 'DELETE',

      data: {
        _token: $('meta[name="csrf-token"]').attr('content')
      },

      success: response => {
        toastr.success(response.message);

        this.reload();
      },

      error: xhr => {
        toastr.error(xhr.responseJSON.message);
      }
    });
  }
  history(id) {
    $.ajax({
      url: window.expenseRoutes.history.replace(':id', id),

      type: 'GET',

      success: response => {
        ExpenseModal.history(response.data);
      }
    });
  }
  changePageLength(value) {
    const parsed = Number.parseInt(value, 10);
    if (![5, 10, 25, 100, 500].includes(parsed)) return;
    this.pageLength = parsed;
    this.currentPage = 1;
    this.load();
  }

  reload() {
    if (this.table) {
      this.currentPage = 1;
      this.load();
    }
  }

    escapeHtml(value) {

        if (
            value === null ||
            value === undefined
        ) {
            return '';
        }


        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');

    }
}

window.ExpenseDataTable =
    ExpenseDataTable;


$(function () {

    window.expenseTable =
        new ExpenseDataTable();

    window.expenseTable.init();

});

</script>


<script>
    'use strict';

/* ==========================================================
 | Elysium ERP
 | Expenditure Dashboard Charts
 | Version : 1.0
========================================================== */

class ExpenseDashboardCharts {
  constructor() {
    this.chart = {};

    this.chartPalette = ['#B12A1F', '#F5A623', '#22C55E', '#0EA5E9', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'];

    this.endpoint = {

        dashboard: window.expenseRoutes.dashboard,

        dashboardCards: window.expenseRoutes.dashboardCards,

        monthly: window.expenseRoutes.monthly,

        category: window.expenseRoutes.category,

        product: window.expenseRoutes.product,

        timeline: window.expenseRoutes.timeline

    };

    this.colors = {
      primary: '#B12A1F',

      secondary: '#F5A623',

      success: '#22C55E',

      info: '#0EA5E9',

      danger: '#EF4444',

      light: '#F5F5F9',

      border: '#ECECEC'
    };
  }

  init() {
    this.renderMonthlyChart();

    this.renderCategoryChart();

    this.renderProductChart();

    this.loadTimeline();

    this.registerEvents();

    this.loadCompanies();
    this.loadFilterCards();
  }

  loadCompanies(selected = '') {
    $.get(
      window.expenseRoutes.companies,

      response => {
        let html = '<option value="">Select Company</option><option value="0">Elysium Groups</option>';

        response.data.forEach(company => {
          html += `

                <option

                    value="${company.sno}"

                    ${selected == company.sno ? 'selected' : ''}>

                    ${company.company_name}

                </option>

                `;
        });

        $('#filterCompany').html(html).trigger('change.select2');
      }
    );
  }

  loadFilterCards(selected = '') {
    $.get(
      window.expenseRoutes.creditCards,

      response => {
        let html = '<option value="">All Cards</option>';

        response.data.forEach(card => {
          html += `
                <option value="${card.sno}" ${selected == card.sno ? 'selected' : ''}>
                    ${card.b_name}
                •••• ${card.rd_prt4}
                </option>

                `;
        });

        $('#filterCard').html(html).trigger('change.select2');
      }
    );
  }

  registerEvents() {
    const self = this;

    $(document)
      .on('click', '.chart-period', function () {
        self.renderMonthlyChart($(this).data('period'));
      })

      .on('click', '#btnRefreshTimeline', function () {
        self.loadTimeline();
      })

      .on('click', '.timeline-item', function () {
        const id = $(this).data('id');

        $(document).trigger(
          'expense:view',

          [id]
        );
      })

      .on('click', '#btnLoadMoreTimeline', () => {
        this.loadTimeline(30);
      });
  }

  showSkeleton(id, height = 350) {
    $(id).html(
      `<div class="expense-skeleton"

            style="height:${height}px">

        </div>`
    );
  }

  emptyChart(id) {
    $(id).html(`

        <div class="text-center py-5">

            <i class="mdi mdi-chart-bar-stacked fs-1 text-muted"></i>

            <h6 class="mt-3">

                No Data Found

            </h6>

        </div>

    `);
  }

  async fetchChart(url, data = {}) {
    try {
      return await $.ajax({
        url: url,

        type: 'GET',

        data: data,

        dataType: 'json'
      });
    } catch (e) {
      console.error(e);

      return false;
    }
  }
  destroy(name) {
    if (this.chart[name]) {
      this.chart[name].destroy();

      this.chart[name] = null;
    }
  }

 

  async renderMonthlyChart(period = 'year') {

    const container = $('#expenseTrendChart');

    this.showSkeleton('#expenseTrendChart');

    const response = await this.fetchChart(
      this.endpoint.monthly,

      {
        period: period
      }
    );

    if (!response || !response.status) {
      this.emptyChart('#expenseTrendChart');
      return;
    }

    this.destroy('monthly');

    container.empty();

    const options = this.getMonthlyChartOptions(response.data);

    this.chart.monthly = new ApexCharts(
        container[0],
        options
    );

    await this.chart.monthly.render();

    
  }

  

  async renderCategoryChart() {
    const container = $('#expenseCategoryChart');
    this.showSkeleton('#expenseCategoryChart', 320);

    $('#expenseCategoryLegend').empty();

    const response = await this.fetchChart(this.endpoint.category);

    if (!response || !response.status) {
      this.emptyChart('#expenseCategoryChart');

      return;
    }

    this.destroy('category');
    container.empty();

    const options = this.getCategoryChartOptions(response.data);

    this.chart.category = new ApexCharts(
        container[0],
        options
    );

     await this.chart.category.render();



    this.renderCategoryLegend(response.data);
  }

  
  async renderProductChart(limit = 10) {

    const container = $('#expenseProductChart');
    this.showSkeleton('#expenseProductChart', 340);

    const response = await this.fetchChart(this.endpoint.product, {
      limit: limit
    });

    if (!response || !response.status) {
      this.emptyChart('#expenseProductChart');

      return;
    }

    this.destroy('product');
    container.empty();

    const options = this.getProductChartOptions(response.data);
    
    this.chart.product = new ApexCharts(
        container[0],
        options
    );

    await this.chart.product.render();


  }

  // async loadTimeline() {
  //   $('#expenseTimeline').html(
  //     `<div class="expense-skeleton"

  //           style="height:320px">

  //       </div>`
  //   );
  // }
  async loadTimeline(limit = 10) {
    $('#expenseTimeline').html(`<div class="expense-skeleton" style="height:320px"></div>`);

    const response = await this.fetchChart(
      this.endpoint.timeline,

      {
        limit: limit
      }
    );

    if (!response || !response.status) {
      this.renderEmptyTimeline();

      return;
    }

    this.renderTimeline(response.data);
  }
  renderTimeline(data) {
    let html = '';

    data.forEach(item => {
      html += this.timelineItem(item);
    });

    html += `

        <div class="text-center mt-3">

            <button

                class="btn btn-sm btn-label-primary"

                id="btnLoadMoreTimeline">

                <i class="mdi mdi-history me-1"></i>

                Load More

            </button>

        </div>

    `;

    $('#expenseTimeline').html(html);
    $('[data-bs-toggle="tooltip"]').tooltip();
  }
  timelineItem(item) {

    const amount = Number(item.amount || 0);

    const icon = item.icon
        ? `mdi ${item.icon}`
        : 'mdi mdi-receipt-text-outline';

    const color = item.color || 'var(--expense-primary)';

    return `
        <div
            class="expense-activity-item"
            data-id="${item.id}"
        >

            <div class="expense-activity-line">

                <div
                    class="expense-activity-icon"
                    style="--activity-color: ${color};"
                >
                    <i class="${icon}"></i>
                </div>

            </div>


            <div class="expense-activity-body">

                <div class="expense-activity-top">

                    <div class="expense-activity-main">

                        <div class="expense-activity-product">
                            ${item.product || 'Expense'}
                        </div>

                        <div class="expense-activity-category">
                            ${item.category || 'Uncategorized'}
                        </div>

                    </div>


                    <div class="expense-activity-finance">

                        <div class="expense-activity-amount">
                            ₹ ${amount.toLocaleString('en-IN', {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 2
                            })}
                        </div>

                        <div class="expense-activity-time">
                            ${item.time || ''}
                        </div>

                    </div>

                </div>


                <div class="expense-activity-meta">

                    ${item.company ? `
                        <span
                            class="expense-meta company"
                             data-bs-toggle="tooltip" data-bs-placement="top"
                            title="${item.company}"
                        >
                            <i class="mdi mdi-domain"></i>

                            <span class="expense-meta-text">
                                ${item.company}
                            </span>
                        </span>
                    ` : ''}


                      ${item.credit_card ? `
                        <span class="expense-meta card"  data-bs-toggle="tooltip" data-bs-placement="top" title="${item.credit_card}"><i class="mdi mdi-credit-card-outline"></i>
                          
                        </span>
                    ` : ''} 

                </div>

            </div>

        </div>
    `;
}
  renderEmptyTimeline() {
    $('#expenseTimeline').html(`

        <div class="text-center py-5">

            <i

                class="mdi mdi-clock-off-outline fs-1 text-muted">

            </i>

            <h6 class="mt-3">

                No Recent Expenses

            </h6>

            <small class="text-muted">

                Expense activity will appear here.

            </small>

        </div>

    `);
  }
  resize() {
    Object.keys(this.chart).forEach(key => {
      if (this.chart[key]) {
        this.chart[key].render();
      }
    });
  }
  getMonthlyChartOptions(data) {
    return {
      chart: {
        type: 'area',

        height: 360,

        toolbar: {
          show: false
        },

        zoom: {
          enabled: false
        },

        animations: {
          enabled: true,

          easing: 'easeinout',

          speed: 800
        }
      },

      colors: [this.colors.primary],
      // colors: this.chartPalette.slice(0, data.labels.length),
      // style="background:${this.chartPalette[index]}"

      stroke: {
        curve: 'smooth',

        width: 3
      },

      fill: {
        type: 'gradient',

        gradient: {
          shadeIntensity: 0.3,

          opacityFrom: 0.35,

          opacityTo: 0.02,

          stops: [0, 90, 100]
        }
      },

      dataLabels: {
        enabled: false
      },

      grid: {
        borderColor: this.colors.border,

        strokeDashArray: 5
      },

      series: [
        {
          name: 'Expense',

          data: data.values
        }
      ],

      xaxis: {
        categories: data.labels,

        axisBorder: {
          show: false
        },

        axisTicks: {
          show: false
        }
      },

      yaxis: {
        labels: {
          formatter: function (value) {
            return '₹' + value.toLocaleString();
          }
        }
      },

      tooltip: {
        y: {
          formatter: function (value) {
            return '₹ ' + value.toLocaleString();
          }
        }
      },

      markers: {
        size: 5,

        hover: {
          size: 7
        }
      }
    };
  }
  getCategoryChartOptions(data) {
    return {
      chart: {
        type: 'donut',

        height: 320
      },

      labels: data.labels,

      series: data.values,

      colors: data.colors,

      stroke: {
        width: 0
      },

      legend: {
        show: false
      },

      dataLabels: {
        enabled: false
      },

      plotOptions: {
        pie: {
          donut: {
            size: '72%',

            labels: {
              show: true,

              total: {
                show: true,

                label: 'Total',

                formatter: function () {
                  return '₹' + data.total.toLocaleString();
                }
              }
            }
          }
        }
      },

      tooltip: {
        y: {
          formatter: function (value) {
            return '₹ ' + value.toLocaleString();
          }
        }
      }
    };
  }
  renderCategoryLegend(data) {
    let html = '';

    data.labels.forEach((label, index) => {
      html += `

        <div class="category-item">

            <div class="category-left">

                <span

                    class="category-dot" >

                </span>

                <span class="category-title">

                    ${label}

                </span>

            </div>

            <div class="category-value">

                ₹ ${Number(data.values[index]).toLocaleString()}

            </div>

        </div>

        `;
    });

    $('#expenseCategoryLegend').html(html);
  }
  getProductChartOptions(data) {
    return {
      chart: {
        type: 'bar',

        height: 340,

        toolbar: {
          show: false
        },

        animations: {
          enabled: true,

          speed: 900
        },

        events: {
          dataPointSelection: (event, chartContext, config) => {
            const product = data.labels[config.dataPointIndex];

            $(document).trigger('expense:productFilter', [product]);
          }
        }
      },

      series: [
        {
          name: 'Expense',

          data: data.values
        }
      ],

      colors: [this.colors.primary],

      plotOptions: {
        bar: {
          horizontal: true,

          borderRadius: 6,

          distributed: false,

          barHeight: '60%'
        }
      },

      dataLabels: {
        enabled: true,

        formatter: function (value) {
          return '₹ ' + Number(value).toLocaleString();
        },

        style: {
          fontSize: '11px',

          fontWeight: 600
        }
      },

      xaxis: {
        categories: data.labels,

        labels: {
          formatter: function (value) {
            return '₹ ' + Number(value).toLocaleString();
          }
        },

        axisBorder: {
          show: false
        },

        axisTicks: {
          show: false
        }
      },

      yaxis: {
        labels: {
          style: {
            fontWeight: 600
          }
        }
      },

      grid: {
        borderColor: this.colors.border,

        strokeDashArray: 4
      },

      tooltip: {
        y: {
          formatter: function (value) {
            return '₹ ' + Number(value).toLocaleString();
          }
        }
      }
    };
  }
}

window.ExpenseDashboardCharts = ExpenseDashboardCharts;

/* ==========================================================
 | Initialize Dashboard
========================================================== */

$(document).ready(function () {
  window.expenseChart = new ExpenseDashboardCharts();

  expenseChart.init();
});

/* ==========================================================
 | Window Resize
========================================================== */

$(window).on('resize', function () {
  if (window.expenseChart) {
    expenseChart.resize();
  }
});

</script>
<script>
    'use strict';

class ExpenseDashboard {
  constructor() {
    this.url = window.expenseRoutes.dashboardCards;
  }

  init() {
    this.load();
  }

  refresh() {
    this.load();
  }

  load() {
    const self = this;

    self.loading(true);

    $.ajax({
      url: self.url,

      type: 'GET',

      data: self.filters(),

      success: function (response) {
        self.render(response.data);
      },

      complete: function () {
        self.loading(false);
      }
    });
  }

  filters() {
    return {
        search: $('#expenseSearch').val() || '',

        card_id: $('#filterCard').val() || '',
        company: $('#filterCompany').val() || '',

        entity: $('#filterEntity').val() || '',

        financial_year: $('#filterFY').val() || '',

        month:
            $('#filterMonth').val() || '',

        category:
            $('#filterCategory').val() || '',

        product:
            $('#filterProduct').val() || '',

        credit_card:
            $('#filterCreditCard').val() || '',

        date:
            $('#filterDate').val() || '',

        amount:
            $('#filterAmount').val() || '',

        reference:
            $('#filterReference').val() || '',

        created_by:
            $('#filterCreatedBy').val() || '',

        status:
            $('#filterStatus').val() || ''
    };
  }

  render(data) {
    this.animateCounter(
      '#totalExpense',

      data.total_expense
    );

    this.animateCounter(
      '#monthlyExpense',

      data.monthly_expense
    );

    this.animateCounter(
      '#todayExpense',

      data.today_expense
    );

    this.animateCounter(
      '#dailyAverage',

      data.daily_average
    );
  }

  animateCounter(target, value) {
    const element = $(target);

    $({
      Counter: 0
    }).animate(
      {
        Counter: value
      },
      {
        duration: 700,

        easing: 'swing',

        step: function () {
          element.html(
            '₹ ' +
              Math.ceil(this.Counter)

                .toLocaleString('en-IN')
          );
        },

        complete: function () {
          element.html(
            '₹ ' +
              Number(value).toLocaleString(
                'en-IN',

                {
                  minimumFractionDigits: 2
                }
              )
          );
        }
      }
    );
  }

  loading(show) {
    $('.expense-stat-card').toggleClass(
      'expense-loading',

      show
    );
  }
}

$(function () {
  window.expenseDashboard = new ExpenseDashboard();

  expenseDashboard.init();
});

</script>

<script>
    'use strict';

class ExpenseFilter {
  constructor() {
    this.timer = null;
  }

  init() {
    this.initializePlugins();

    this.registerEvents();
  }

  initializePlugins() {
    $('.select2').select2({
      width: '100%'
    });
  }

  registerEvents() {
    const self = this;

    /*
        |--------------------------------------------------------------------------
        | Company
        |--------------------------------------------------------------------------
        */

    $('.expense-stat-card').click(function () {
      $('.expense-stat-card').removeClass('active');

      $(this).addClass('active');
    });

    $('#filterCompany').on('change', function () {
      self.loadEntities();

      self.refresh();
    });

    $('#filterCard').on('change', function () {
      self.refresh();
    });

    /*
        |--------------------------------------------------------------------------
        | Entity
        |--------------------------------------------------------------------------
        */

    $('#filterEntity').on('change', function () {
      self.refresh();
    });

    /*
        |--------------------------------------------------------------------------
        | Financial Year
        |--------------------------------------------------------------------------
        */

    $('#filterFY').on('change', function () {
      self.refresh();
    });

    /*
        |--------------------------------------------------------------------------
        | Month
        |--------------------------------------------------------------------------
        */

    $('#filterMonth').on('change', function () {
      self.refresh();
    });

    /*
        |--------------------------------------------------------------------------
        | Category
        |--------------------------------------------------------------------------
        */

    $('#filterCategory').on('change', function () {
      self.loadProducts();

      self.refresh();
    });

    /*
        |--------------------------------------------------------------------------
        | Product
        |--------------------------------------------------------------------------
        */

    $('#filterProduct').on('change', function () {
      self.refresh();
    });

    /*
        |--------------------------------------------------------------------------
        | Credit Card
        |--------------------------------------------------------------------------
        */

    $('#filterCreditCard').on('change', function () {
      self.refresh();
    });

    /*
        |--------------------------------------------------------------------------
        | Date
        |--------------------------------------------------------------------------
        */

    $('#filterDate').on('change', function () {
      self.refresh();
    });

    /*
        |--------------------------------------------------------------------------
        | Amount
        |--------------------------------------------------------------------------
        */

    $('#filterAmount').on('keyup', function () {
      clearTimeout(self.timer);

      self.timer = setTimeout(function () {
        self.refresh();
      }, 500);
    });

    /*
        |--------------------------------------------------------------------------
        | Search
        |--------------------------------------------------------------------------
        */

    $('#expenseSearch').on('keyup', function () {
      clearTimeout(self.timer);

      self.timer = setTimeout(function () {
        self.refresh();
      }, 400);
    });

    /*
        |--------------------------------------------------------------------------
        | Reset
        |--------------------------------------------------------------------------
        */

    $('#btnResetFilter').on('click', function () {
      self.reset();
    });
  }

  refresh() {
    /*
        |--------------------------------------------------------------------------
        | DataTable
        |--------------------------------------------------------------------------
        */

    if (
        window.expenseTable &&
        typeof window.expenseTable.reload === 'function'
    ) {
        window.expenseTable.reload();
    } else if (
        $.fn.DataTable &&
        $.fn.DataTable.isDataTable('#expenseTable')
    ) {
        $('#expenseTable')
            .DataTable()
            .ajax
            .reload(null, false);
    }

    /*
        |--------------------------------------------------------------------------
        | Dashboard
        |--------------------------------------------------------------------------
        */

    if (window.expenseDashboard) {
      expenseDashboard.refresh();
    }

    /*
        |--------------------------------------------------------------------------
        | Charts
        |--------------------------------------------------------------------------
        */

    if (window.expenseChart) {
      // expenseChart.loadCards();

      expenseChart.renderMonthlyChart();

      expenseChart.renderCategoryChart();

      expenseChart.renderProductChart();

      expenseChart.loadTimeline();
    }
  }

  reset() {
    $('#expenseToolbar')
      .find('input')

      .val('');

    $('#expenseToolbar')
      .find('select')

      .val('')

      .trigger('change');

    this.refresh();
  }

  /*
    |--------------------------------------------------------------------------
    | Load Entity
    |--------------------------------------------------------------------------
    */

  loadEntities(selected = '') {
    $.get(
      window.expenseRoutes.entities,

      {
        company_id: $('#filterCompany').val()
      },

      function (response) {
        let html = '<option value="">All Entity</option>';

        response.data.forEach(function (item) {
          html += `

                        <option

                        value="${item.sno}"

                        ${selected == item.sno ? 'selected' : ''}>

                        ${item.entity_name}

                        </option>

                    `;
        });

        $('#filterEntity')
          .html(html)

          .trigger('change.select2');
      }
    );
  }

  /*
    |--------------------------------------------------------------------------
    | Load Product
    |--------------------------------------------------------------------------
    */

  loadProducts(selected = '') {
    $.get(
      window.expenseRoutes.products,

      {
        category_id: $('#filterCategory').val()
      },

      function (response) {
        let html = '<option value="">All Product</option>';

        response.data.forEach(function (item) {
          html += `

                    <option

                    value="${item.sno}"

                    ${selected == item.sno ? 'selected' : ''}>

                    ${item.product_name}

                    </option>

                    `;
        });

        $('#filterProduct')
          .html(html)

          .trigger('change.select2');
      }
    );
  }
}

$(function () {
  window.expenseFilter = new ExpenseFilter();

  expenseFilter.init();
});
if (
    window.expenseTable &&
    typeof window.expenseTable.reload === 'function'
) {
    window.expenseTable.reload();
} else if (
    $.fn.DataTable &&
    $.fn.DataTable.isDataTable('#expenseTable')
) {
    $('#expenseTable')
        .DataTable()
        .ajax
        .reload(null, false);
}
if (window.expenseDashboard) {
  expenseDashboard.refresh();
}
if (window.expenseChart) {
  expenseChart.renderMonthlyChart();

  expenseChart.renderCategoryChart();

  expenseChart.renderProductChart();

  expenseChart.loadTimeline();
}


/* --------------------------------------------------------------------------
 * Amount breakdown tooltip portal
 *
 * The table intentionally uses overflow-x:auto. CSS descendants cannot reliably
 * escape that clipping boundary, even with a very high z-index. Clone the hidden
 * tooltip into document.body and position it against the information icon instead.
 * Delegated events work for rows added by AJAX pagination/filtering.
 * -------------------------------------------------------------------------- */
(function initExpenseAmountTooltipPortal() {
    if (window.__expenseAmountTooltipPortalInitialized) return;
    window.__expenseAmountTooltipPortalInitialized = true;

    let activeTrigger = null;
    let activeTooltip = null;
    let closeTimer = null;

    function cancelClose() {
        if (closeTimer) {
            window.clearTimeout(closeTimer);
            closeTimer = null;
        }
    }

    function closeTooltip() {
        cancelClose();
        if (activeTrigger && activeTrigger.isConnected) {
            activeTrigger.setAttribute('aria-expanded', 'false');
        }
        if (activeTooltip) activeTooltip.remove();
        activeTrigger = null;
        activeTooltip = null;
    }

    function positionTooltip() {
        if (!activeTrigger || !activeTooltip || !activeTrigger.isConnected) {
            closeTooltip();
            return;
        }

        const triggerRect = activeTrigger.getBoundingClientRect();
        const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
        const viewportHeight = document.documentElement.clientHeight || window.innerHeight;
        const padding = 12;
        const gap = 10;
        const tooltipWidth = Math.min(330, Math.max(220, viewportWidth - padding * 2));

        activeTooltip.style.width = tooltipWidth + 'px';
        activeTooltip.style.maxWidth = (viewportWidth - padding * 2) + 'px';
        activeTooltip.style.maxHeight = Math.max(140, viewportHeight - padding * 2) + 'px';
        activeTooltip.style.left = padding + 'px';
        activeTooltip.style.top = padding + 'px';

        // Force layout after the tooltip is attached, so we can measure its actual height.
        const tooltipRect = activeTooltip.getBoundingClientRect();
        const tooltipHeight = Math.min(tooltipRect.height, viewportHeight - padding * 2);
        const maxLeft = Math.max(padding, viewportWidth - tooltipWidth - padding);
        // Align the right edge near the amount icon, then clamp into the viewport.
        const left = Math.min(maxLeft, Math.max(padding, triggerRect.right - tooltipWidth));

        const spaceBelow = viewportHeight - triggerRect.bottom - gap - padding;
        const spaceAbove = triggerRect.top - gap - padding;
        let top;

        if (spaceBelow >= tooltipHeight || spaceBelow >= spaceAbove) {
            top = triggerRect.bottom + gap;
            top = Math.min(top, viewportHeight - tooltipHeight - padding);
        } else {
            top = triggerRect.top - tooltipHeight - gap;
            top = Math.max(padding, top);
        }

        activeTooltip.style.left = Math.round(left) + 'px';
        activeTooltip.style.top = Math.round(top) + 'px';
    }

    function openTooltip(trigger) {
        if (!trigger) return;
        if (activeTrigger === trigger && activeTooltip) {
            cancelClose();
            return;
        }

        closeTooltip();

        const wrapper = trigger.closest('.expense-amount-wrapper');
        const sourceTooltip = wrapper && wrapper.querySelector('.expense-amount-tooltip');
        if (!sourceTooltip) return;

        activeTrigger = trigger;
        activeTooltip = sourceTooltip.cloneNode(true);
        activeTooltip.classList.add('expense-amount-tooltip-portal');
        activeTooltip.setAttribute('role', 'tooltip');
        activeTooltip.removeAttribute('id');
        document.body.appendChild(activeTooltip);
        trigger.setAttribute('aria-expanded', 'true');
        positionTooltip();
    }

    function scheduleClose() {
        cancelClose();
        // Small grace period lets the pointer cross the gap between the icon and panel.
        closeTimer = window.setTimeout(closeTooltip, 220);
    }

    document.addEventListener('pointerover', function (event) {
        const target = event.target;
        if (!(target instanceof Element)) return;

        const trigger = target.closest('.expense-amount-info');
        if (trigger) {
            if (event.relatedTarget instanceof Node && trigger.contains(event.relatedTarget)) return;
            openTooltip(trigger);
            return;
        }

        if (activeTooltip && (target === activeTooltip || activeTooltip.contains(target))) {
            cancelClose();
        }
    });

    document.addEventListener('pointerout', function (event) {
        const target = event.target;
        if (!(target instanceof Element)) return;

        if (activeTrigger) {
            const trigger = target.closest('.expense-amount-info');
            if (trigger === activeTrigger &&
                !(event.relatedTarget instanceof Node && activeTrigger.contains(event.relatedTarget)) &&
                !(event.relatedTarget instanceof Node && activeTooltip && activeTooltip.contains(event.relatedTarget))) {
                scheduleClose();
            }
        }

        if (activeTooltip && (target === activeTooltip || activeTooltip.contains(target))) {
            if (event.relatedTarget instanceof Node &&
                (activeTooltip.contains(event.relatedTarget) || event.relatedTarget === activeTrigger ||
                 (activeTrigger && activeTrigger.contains(event.relatedTarget)))) {
                return;
            }
            scheduleClose();
        }
    });

    // Click/tap and keyboard activation supplement hover for touch and accessibility.
    document.addEventListener('click', function (event) {
        const target = event.target;
        if (!(target instanceof Element)) return;
        const trigger = target.closest('.expense-amount-info');
        if (trigger) {
            openTooltip(trigger);
            return;
        }
        if (activeTooltip && (target === activeTooltip || activeTooltip.contains(target))) return;
        closeTooltip();
    });

    document.addEventListener('keydown', function (event) {
        const target = event.target;
        if (event.key === 'Escape' && activeTooltip) {
            closeTooltip();
            return;
        }
        if (!(target instanceof Element) || !target.matches('.expense-amount-info')) return;
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            openTooltip(target);
        }
    });

    // Close on scroll/resize to avoid a stale panel detached from its table row.
    document.addEventListener('scroll', function (event) {
        // Allow scrolling inside the tooltip itself if its content exceeds the viewport.
        if (activeTooltip && (event.target === activeTooltip || activeTooltip.contains(event.target))) return;
        closeTooltip();
    }, true);
    window.addEventListener('resize', closeTooltip, { passive: true });
})();

</script>
@endsection