@extends('layouts/layoutMaster')

@section('title', 'PassWallet')
@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection
@section('page-script')
@vite(['resources/assets/js/form_wizard_icons.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/forms-pickers.js')
@vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection

@section('content')
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $module_name = 'Tool Management';
    $submenu_name = 'PassWallet';
    $last_name = null;

    $add_entry = 0;
    if (auth()->user()->hasPermission($module_name, $submenu_name, $last_name, 'New Entry')) {
        $add_entry = 1;
    }
@endphp

<style>
    #egPassWallet{
        --pw-red:var(--expense-primary,#ab2b22);
        --pw-primary:var(--expense-primary,#ab2b22);
        --pw-primary-dark:var(--expense-primary-hover,#8f1d1d);
        --pw-red-dark:var(--expense-primary-hover,#8f1d1d);
        --pw-gold:#fba919;
        --pw-bg:#f7f7f9;
        --pw-card:#fff;
        --pw-border:#e3e5ea;
        --pw-text:#1f1f1f;
        --pw-muted:#7d8a9e;
        background:var(--pw-bg);
        min-height:calc(100vh - 70px);
        padding:8px 18px 26px;
        color:var(--pw-text);
    }

    #egPassWallet .pw-hero{
        background:linear-gradient(100deg,var(--pw-red),var(--pw-red-dark));
        color:#fff;
        border-radius:12px;
        padding:16px 18px 15px;
        display:flex;
        align-items:flex-start;
        justify-content:space-between;
        gap:18px;
        box-shadow:0 8px 24px rgba(171,43,34,.10);
    }

    #egPassWallet .pw-hero-title{
        display:flex;
        align-items:flex-start;
        gap:12px;
        min-width:0;
    }

    #egPassWallet .pw-hero-icon{
        width:42px;
        height:42px;
        flex:0 0 42px;
        border-radius:11px;
        display:grid;
        place-items:center;
        color:var(--pw-gold);
        background:rgba(255,255,255,.08);
        border:1px solid rgba(255,255,255,.12);
    }

    #egPassWallet .pw-hero-icon i{font-size:22px}

    #egPassWallet .pw-hero-kicker{
        color:#f9e4e1;
        font-size:9px;
        font-weight:800;
        letter-spacing:.05em;
        text-transform:uppercase;
    }

    #egPassWallet .pw-hero h2{
        margin:1px 0 2px;
        font-size:20px;
        font-weight:900;
        color:#fff;
    }

    #egPassWallet .pw-hero p{
        margin:0;
        color:#f9e4e1;
        font-size:10px;
        line-height:1.5;
    }

    #egPassWallet .pw-hero-meta{
        display:flex;
        align-items:center;
        flex-wrap:wrap;
        gap:6px;
        margin-top:8px;
    }

    #egPassWallet .pw-hero-pill{
        display:inline-flex;
        align-items:center;
        gap:5px;
        padding:4px 8px;
        border-radius:999px;
        /* background:rgba(255,255,255,.08); */
        border:1px solid rgba(255,255,255,.12);
        color:#fff6f4;
        font-size:9px;
        font-weight:700;
    }

    #egPassWallet .pw-hero-actions{
        display:flex;
        align-items:center;
        gap:7px;
        flex:0 0 auto;
    }

    #egPassWallet .pw-hero-actions .btn{
        min-height:38px;
        border-radius:9px;
        font-weight:800;
    }

    /* #egPassWallet .pw-tabs{
        display:flex;
        gap:4px;
        margin:10px 0;
        overflow:auto;
        scrollbar-width:none;
    }

    #egPassWallet .pw-tabs::-webkit-scrollbar{
        display:none;
    } */

    #egPassWallet .pw-tab{
        border:1px solid var(--pw-border);
        background:#fff;
        border-radius:9px;
        padding:8px 12px;
        color:#647089;
        white-space:nowrap;
        font-size:10px;
        font-weight:800;
        cursor:pointer;
    }

    #egPassWallet .pw-tab.active{
        background:var(--pw-red);
        border-color:var(--pw-red);
        color:#fff;
        box-shadow:0 5px 14px rgba(171,43,34,.15);
    }

    #egPassWallet .pw-toolbar,
    #egPassWallet .pw-card,
    #egPassWallet .pw-side-card{
        background:#fff;
        /* border:1px solid var(--pw-border);
        border-radius:12px; */
    }

    #egPassWallet .pw-toolbar{
        padding:9px;
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
        margin-bottom:10px;
    }

    #egPassWallet .pw-toolbar .pw-search{
        min-width:250px;
        flex:1 1 300px;
    }

    #egPassWallet .pw-toolbar .pw-filter{
        width:185px;
        flex:0 0 185px;
    }

    /* #egPassWallet .pw-toolbar .form-control,
    #egPassWallet .pw-toolbar .form-select{
        min-height:38px;
        border-radius:9px;
        border-color:#d9e0ea;
        font-size:11px;
    } */

    #egPassWallet .pw-toolbar .btn{
        min-height:38px;
        border-radius:9px;
    }

    #egPassWallet .pw-toolbar .btn-primary,
    #egPassWallet .pw-modal .btn-primary,
    #egPassWallet .pw-empty .btn-primary,
    #egPassWallet .pw-error .btn-primary{
        background:var(--pw-red);
        border-color:var(--pw-red);
        color:#fff;
    }

    #egPassWallet .pw-toolbar .btn-primary:hover,
    #egPassWallet .pw-modal .btn-primary:hover,
    #egPassWallet .pw-empty .btn-primary:hover,
    #egPassWallet .pw-error .btn-primary:hover{
        background:var(--pw-red-dark);
        border-color:var(--pw-red-dark);
        color:#fff;
    }

    #egPassWallet .pw-toolbar .btn-outline-primary,
    #egPassWallet .pw-modal .btn-outline-primary{
        color:var(--pw-red);
        border-color:var(--pw-red);
    }

    #egPassWallet .pw-toolbar .btn-outline-primary:hover,
    #egPassWallet .pw-modal .btn-outline-primary:hover{
        background:var(--pw-red);
        border-color:var(--pw-red);
        color:#fff;
    }

    #egPassWallet .pw-toolbar .btn-primary:hover{
        background:var(--pw-primary-dark);
        border-color:var(--pw-primary-dark);
    }

    #egPassWallet .pw-summary-row{
        display:grid;
        grid-template-columns:repeat(5,minmax(0,1fr));
        gap:8px;
        margin-bottom:10px;
    }

    #egPassWallet .pw-stat{
        background:#fff;
        border:1px solid var(--pw-border);
        border-radius:11px;
        padding:10px 11px;
        display:flex;
        align-items:center;
        gap:9px;
        min-width:0;
    }

    #egPassWallet .pw-stat-icon{
        width:31px;
        height:31px;
        flex:0 0 31px;
        display:grid;
        place-items:center;
        border-radius:9px;
        color:var(--pw-red);
        background:#fff1ef;
    }

    #egPassWallet .pw-stat-label{
        color:var(--pw-muted);
        font-size:8px;
        text-transform:uppercase;
        letter-spacing:.04em;
        font-weight:900;
    }

    #egPassWallet .pw-stat-value{
        color:var(--pw-red);
        font-size:16px;
        font-weight:900;
        line-height:1.1;
    }

    #egPassWallet .pw-stat-meta{
        color:#9aa4b3;
        font-size:8px;
        margin-top:2px;
    }

    #egPassWallet .pw-table-wrap{
        overflow:auto;
        /* border-radius:12px; */
    }
    #egPassWallet .pw-table{
        min-width:1050px;
        margin:0;
    }

    #egPassWallet .pw-table thead th{
        background:var(--pw-red);
        color:#fff;
        font-size:9px;
        font-weight:900;
        letter-spacing:.03em;
        text-transform:uppercase;
        padding:10px 12px;
        border:0;
        white-space:nowrap;
    }

    /* #egPassWallet .pw-table thead th:first-child{
        border-radius:11px 0 0 0; 
    }
    #egPassWallet .pw-table thead th:last-child{
        border-radius:0 11px 0 0;
    } */

    #egPassWallet .pw-table tbody td{
        padding:10px 12px;
        border-color:#edf0f4;
        vertical-align:middle;
        font-size:10px;
        color:#34455f;
    }
    #egPassWallet .pw-table tbody tr{
        cursor:pointer;
        transition:.12s ease;
        background:#fff;
    }

    #egPassWallet .pw-table tbody tr:hover{
        background:#fbfcfe;
    }

    #egPassWallet .pw-entry-wrap{
        display:flex;
        align-items:center;
        gap:9px;
        min-width:230px;
    }

    #egPassWallet .pw-entry-icon{
        width:34px;
        height:34px;
        flex:0 0 34px;
        border-radius:9px;
        display:grid;
        place-items:center;
        background:#f3f5f8;
        color:var(--pw-red);
        border:1px solid #e6eaf0;
        overflow:hidden;
    }

    #egPassWallet .pw-entry-icon img{
        width:23px;
        height:23px;
        object-fit:contain;
        display:block;
    }

    #egPassWallet .pw-entry-name{
        font-size:11px;
        font-weight:900;
        color:#17263e;
        line-height:1.25;
    }

    #egPassWallet .pw-entry-url{
        font-size:8px;
        color:#8b97a8;
        margin-top:2px;
        max-width:245px;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }

    #egPassWallet .pw-type-badge,
    #egPassWallet .pw-scope-badge,
    #egPassWallet .pw-rotation-badge{
        display:inline-flex;
        align-items:center;
        gap:5px;
        border-radius:999px;
        padding:4px 8px;
        font-size:8px;
        font-weight:800;
        white-space:nowrap;
    }

    #egPassWallet .pw-type-badge{
        color:#46536b;
        border:1px solid #dfe5ed;
        background:#fff;
    }

    #egPassWallet .pw-scope-badge{
        color:#55657e;
        border:1px solid #dfe5ed;
        background:#f8fafc;
    }

    #egPassWallet .pw-rotation-badge.ok{
        background:#edf8ef;
        color:#2b7b4a;
    }

    #egPassWallet .pw-rotation-badge.due{
        background:#fff8e8;
        color:#a16c00;
    }

    #egPassWallet .pw-rotation-badge.overdue{
        background:#fff0ef;
        color:#b52b25;
    }

    #egPassWallet .pw-rotation-badge.none{
        background:#f1f3f6;
        color:#758094;
    }

    #egPassWallet .pw-inline-secret{
        display:inline-flex;
        align-items:center;
        gap:4px;
        white-space:nowrap;
    }

    #egPassWallet .pw-secret-mask{
        font-size:11px;
        letter-spacing:.12em;
        color:#1d2d48;
    }

    #egPassWallet .pw-inline-btn{
        width:26px;
        height:26px;
        padding:0;
        border-radius:7px;
        border:1px solid transparent;
        background:transparent;
        color:#8290a4;
        display:inline-grid;
        place-items:center;
    }

    #egPassWallet .pw-inline-btn:hover{
        background:#f1f3f8;
        color:var(--pw-red);
    }

    #egPassWallet .pw-username{
        font-size:10px;
        color:#34455f;
        font-weight:700;
    }

    #egPassWallet .pw-username-copy{
        border:0;
        background:transparent;
        color:#b4bdcb;
        padding:0;
        margin-left:2px;
    }

    #egPassWallet .pw-row-actions{
        display:flex;
        gap:4px;
        justify-content:flex-end;
        white-space:nowrap;
    }

    #egPassWallet .pw-row-actions .btn{
        width:28px;
        height:28px;
        padding:0;
        display:grid;
        place-items:center;
        border-radius:7px;
    }

    #egPassWallet .pw-empty,
    #egPassWallet .pw-error{
        padding:46px 18px;
        text-align:center;
        color:#7d8a9e;
    }

    #egPassWallet .pw-empty i,
    #egPassWallet .pw-error i{
        font-size:35px;
        color:#b8c1cf;
        display:block;
        margin-bottom:8px;
    }

    #egPassWallet .pw-skeleton-wrap{
        display:grid;
        gap:0;
    }

    #egPassWallet .pw-skeleton-line,
    #egPassWallet .pw-skeleton-icon{
        position:relative;
        overflow:hidden;
        background:linear-gradient(90deg,#eef1f5 25%,#f8f9fb 50%,#eef1f5 75%);
        background-size:220% 100%;animation:pwSkeleton 1.4s ease-in-out infinite;
    }

    #egPassWallet .pw-skeleton-line{
        height:9px;
        border-radius:999px;
    }

    #egPassWallet .pw-skeleton-icon{
        width:34px;
        height:34px;
        border-radius:9px;
        flex:0 0 34px;
    }

    #egPassWallet .pw-skeleton-row td{
        padding:13px 12px;
    }

    #egPassWallet .pw-sk-20{
        width:20%;
    }
    #egPassWallet .pw-sk-30{
        width:30%;
    }
    #egPassWallet .pw-sk-45{
        width:45%;
    }
    #egPassWallet .pw-sk-60{
        width:60%;
    }
    #egPassWallet .pw-sk-80{
        width:80%;
    }

    @keyframes pwSkeleton{
        0%{
            background-position:200% 0;
        }
        100%{
            background-position:-20% 0;
        }
    }

    #egPassWallet .pw-pagination{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:8px;
        padding:9px 1px 0;
        color:#8994a6;
        font-size:9px;
    }

    #egPassWallet .pw-pagination .btn{
        width:30px;
        height:29px;
        padding:0;
        border-radius:7px;
    }

    #egPassWallet .pw-form-section{
        border:1px solid #e4e9f0;
        border-radius:12px;
        background:#fbfcfe;
        padding:12px;
        margin-bottom:12px;
    }
    #egPassWallet .pw-form-section-title{
        font-size:10px;
        font-weight:900;
        color:#27364f;
        margin-bottom:9px;
    }

    #egPassWallet .pw-advanced-section{
        border:1px solid #e4e9f0;
        border-radius:12px;
        background:#fff;
        overflow:hidden;
        margin-bottom:12px;
    }

    #egPassWallet .pw-advanced-toggle{
        width:100%;
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:12px;
        padding:12px 13px;
        border:0;
        background:#fff;
        color:#25344c;
        text-align:left;
        transition:.15s ease;
    }

    #egPassWallet .pw-advanced-toggle:hover{
        background:#fffaf9;
    }

    #egPassWallet .pw-advanced-toggle:focus{
        outline:0;
        box-shadow:inset 0 0 0 .15rem rgba(171,43,34,.08);
    }

    #egPassWallet .pw-advanced-toggle-left{
        display:flex;
        align-items:center;
        gap:9px;
        min-width:0;
    }

    #egPassWallet .pw-advanced-icon{
        width:32px;
        height:32px;
        flex:0 0 32px;
        display:grid;
        place-items:center;
        border-radius:9px;
        background:#fff3ef;
        color:var(--pw-red);
        border:1px solid #f1d8d4;
    }

    #egPassWallet .pw-advanced-icon i{
        font-size:16px;
    }

    #egPassWallet .pw-advanced-copy{
        display:flex;
        flex-direction:column;
        min-width:0;
    }

    #egPassWallet .pw-advanced-title{
        font-size:10px;
        font-weight:900;
        color:#25344c;
        line-height:1.25;
    }

    #egPassWallet .pw-advanced-subtitle{
        margin-top:2px;
        font-size:8px;
        color:#8a96a8;
        line-height:1.35;
    }

    #egPassWallet .pw-advanced-chevron{
        color:#8b96a8;
        font-size:17px;
        transition:transform .18s ease;
        flex:0 0 auto;
    }

    #egPassWallet .pw-advanced-toggle:not(.collapsed) .pw-advanced-chevron{
        transform:rotate(180deg);
        color:var(--pw-red);
    }

    #egPassWallet .pw-advanced-body{
        padding:0 13px 13px;
        border-top:1px solid #edf0f4;
    }

    #egPassWallet .pw-field-label{
        display:block;
        margin-bottom:6px;
        font-size:9px;
        font-weight:800;
        color:#52627b;
    }

    #egPassWallet .pw-form-control,
    #egPassWallet .pw-form-select{
        min-height:42px;
        border:1px solid #dbe2eb;
        border-radius:10px;
        font-size:11px;
    }

    #egPassWallet textarea.pw-form-control{
        min-height:92px;
        resize:vertical;
    }

    #egPassWallet .pw-form-control:focus,
    #egPassWallet .pw-form-select:focus{
        border-color:#b9c4d5;
        box-shadow:0 0 0 .15rem rgba(171,43,34,.08);
    }

    #egPassWallet .pw-password-group{
        display:flex;
        gap:6px;
        align-items:center;
    }

    #egPassWallet .pw-password-group .form-control{
        flex:1;
    }

    #egPassWallet .pw-password-note{
        font-size:8px;
        color:#8793a7;
        margin-top:5px;
    }

    #egPassWallet .pw-password-strength{
        font-size:8px;
        font-weight:800;
        margin-top:5px;
    }

    #egPassWallet .pw-password-strength.strong{
        color:#2c7c4f;
    }
    #egPassWallet .pw-password-strength.medium{
        color:#a47200;
    }
    #egPassWallet .pw-password-strength.weak{
        color:#b52b25;
    }

    #egPassWallet .pw-audience-builder{
        border:1px solid #e3e8f0;
        border-radius:12px;
        background:#fbfcfe;
        padding:11px;
    }

    #egPassWallet .pw-audience-modes{
        display:grid;
        grid-template-columns:repeat(4,minmax(0,1fr));
        gap:6px;
        margin-bottom:10px;
    }

    #egPassWallet .pw-audience-mode{
        border:1px solid #dfe5ed;
        background:#fff;
        color:#647189;
        border-radius:9px;
        padding:8px 6px;
        display:flex;
        align-items:center;
        justify-content:center;
        gap:5px;
        cursor:pointer;
        font-size:9px;
        font-weight:800;
        transition:.15s ease;
    }

    #egPassWallet .pw-audience-mode:hover{
        border-color:#c5cdd9;
        background:#fff;
    }

    #egPassWallet .pw-audience-mode.active{
        border-color:var(--pw-red);
        color:var(--pw-red);
        background:#fff4f2;
        box-shadow:0 3px 10px rgba(171,43,34,.08);
    }

    #egPassWallet .pw-audience-mode i{
        font-size:15px;
    }

    #egPassWallet .pw-audience-hint{
        font-size:8px;
        color:#8793a7;
        line-height:1.45;
        margin-bottom:8px;
    }

    #egPassWallet .pw-audience-panel{
        border:1px solid #e7ebf1;
        background:#fff;
        border-radius:10px;
        padding:10px;
    }

    /* #egPassWallet .pw-audience-panel .form-select{
        min-height:42px;
        border-radius:9px;
        font-size:10px;
    } */

    #egPassWallet .pw-audience-panel select[multiple]{
        min-height:112px;
        background-image:none;
        padding:7px 9px;
        cursor:pointer;
    }

    #egPassWallet .pw-audience-panel select[multiple] option{
        padding:6px 7px;
        border-radius:5px;
    }

    #egPassWallet .pw-audience-panel select:disabled{
        background-color:#f8f9fb;
        color:#8d98a8;
        cursor:wait;
        opacity:.9;
    }

    #egPassWallet .pw-audience-summary{
        display:flex;
        align-items:flex-start;
        gap:7px;
        flex-wrap:wrap;
        margin-top:9px;
        padding:8px 9px;
        background:#f7f9fc;
        border:1px solid #e7ebf1;
        border-radius:9px;
    }

    #egPassWallet .pw-audience-summary-label{
        font-size:8px;
        font-weight:900;
        text-transform:uppercase;
        letter-spacing:.05em;
        color:#59687f;
        padding-top:3px;
    }

    #egPassWallet .pw-audience-chip{
        display:inline-flex;
        align-items:center;
        gap:4px;
        padding:4px 7px;
        border-radius:999px;
        background:#f0f2f7;
        border:1px solid #e1e6ee;
        color:#4e5f77;
        font-size:8px;
        font-weight:800;
    }

    #egPassWallet .pw-audience-chip i{
        color:var(--pw-red);
    }

    /* #egPassWallet .pw-select2 .select2-container{
        width:100%!important;
    } */

    /* #egPassWallet .pw-select2 .select2-container--default .select2-selection--multiple{
        min-height:42px;
        border:1px solid #dbe2eb;
        border-radius:9px;
        background:#fff;
        padding:4px 6px;
    } */

    /* #egPassWallet .pw-select2 .select2-container--default.select2-container--focus .select2-selection--multiple{
        border-color:#aab6c8;
        box-shadow:0 0 0 .15rem rgba(171,43,34,.08);
    }

    #egPassWallet .pw-select2 .select2-selection__choice{
        border:1px solid #dfe5ed!important;
        background:#f3f5f8!important;
        color:#4d5e76!important;
        border-radius:999px!important;
        font-size:8px!important;
        font-weight:800!important;
        padding:3px 7px 3px 20px!important;
    }

    #egPassWallet .pw-select2 .select2-selection__choice__remove{
        color:#8a96a8!important;
        left:5px!important;
        right:auto!important;
        border:0!important;
    }

    #egPassWallet .pw-select2 .select2-search--inline .select2-search__field{
        font-size:9px;
        min-height:26px;
        margin-top:2px;
    }

    #egPassWallet .pw-select2 .select2-dropdown{
        border-color:#dfe5ed;
        box-shadow:0 14px 35px rgba(17,24,39,.12);
    }

    #egPassWallet .pw-select2 .select2-results__option{
        font-size:9px;
        padding:8px 10px;
    } */

    #egPassWallet .pw-modal .modal-content{
        border:0;
        border-radius:16px;
        overflow:hidden;
        box-shadow:0 25px 85px rgba(15,23,42,.19);
    }
    #egPassWallet .pw-modal-head{
        padding:15px 17px;
        border-bottom:1px solid #e8edf3;
        background:#fff;
    }
    #egPassWallet .pw-modal-head h5{
        font-size:15px;
        font-weight:900;
        color:#20314a;
        margin:0;
    }
    #egPassWallet .pw-modal-head p{
        font-size:9px;
        color:#8793a6;
        margin:3px 0 0;
    }
    #egPassWallet .pw-modal-body{
        padding:15px 17px;
        background:#fff;
    }
    #egPassWallet .pw-modal-foot{
        padding:11px 17px;
        border-top:1px solid #e8edf3;
        background:#fbfcfe;
        display:flex;
        justify-content:flex-end;
        gap:7px;
    }

    #egPassWallet .pw-modal-foot .btn{
        min-height:36px;
        border-radius:9px;
        font-size:10px;
        font-weight:800;
    }

    #egPassWallet .pw-entry-modal .modal-dialog{
        max-width:1080px;
    }
    #egPassWallet .pw-stepup-modal .modal-dialog{
        max-width:430px;}
    #egPassWallet .pw-share-modal .modal-dialog{
        max-width:760px;
    }

    #egPassWallet .pw-security-box{
        border:1px solid #eeddb1;
        background:#fffaf0;
        border-radius:10px;
        padding:9px 10px;
        color:#8a670c;
        font-size:9px;
        line-height:1.5;
    }
    #egPassWallet .pw-security-box i{
        font-size:15px;
        vertical-align:-2px;
        margin-right:4px;
    }

    #egPassWallet .pw-offcanvas{
        width:min(515px,100vw)!important;
        border:0;
        box-shadow:-18px 0 55px rgba(15,23,42,.14);
    }

    #egPassWallet .pw-offcanvas-head{
        background:var(--pw-red);
        color:#fff;padding:17px;
    }

    #egPassWallet .pw-offcanvas-head h5{
        color:#fff;
        margin:0;
        font-size:15px;
        font-weight:900;
    }
    #egPassWallet .pw-offcanvas-head p{
        color:#f7d9d5;
        font-size:9px;
        margin:3px 0 0;
    }

    #egPassWallet .pw-offcanvas-head .btn-close{
        filter:brightness(0) invert(1);
        opacity:.85;
    }

    #egPassWallet .pw-offcanvas-body{
        padding:0;
        background:#fff;
    }

    #egPassWallet .pw-detail-tabs{
        display:flex;
        gap:0;
        border-bottom:1px solid #e6ebf2;
        padding:0 17px;
        overflow:auto;
    }

    #egPassWallet .pw-detail-tab{
        border:0;
        background:transparent;
        padding:12px 10px 10px;
        color:#78859a;
        font-size:10px;
        font-weight:800;
        white-space:nowrap;
        border-bottom:2px solid transparent;
    }
    #egPassWallet .pw-detail-tab.active{
        color:var(--pw-red);
        border-bottom-color:var(--pw-red);
    }
    #egPassWallet .pw-detail-pane{
        padding:15px 17px;
    }
    #egPassWallet .pw-detail-password{
        border:1px solid #e2e8f0;
        border-radius:11px;
        padding:11px 12px;
        background:#fbfcfe;
        margin-bottom:10px;
    }
    #egPassWallet .pw-detail-password-label{
        font-size:8px;
        font-weight:900;
        letter-spacing:.05em;
        color:#8793a6;
    }

    #egPassWallet .pw-detail-password-row{
        display:flex;
        align-items:center;
        gap:8px;
        margin-top:4px;
    }

    #egPassWallet .pw-detail-password-value{
        flex:1;
        font-size:15px;
        font-weight:900;
        color:#17263e;
        letter-spacing:.12em;
        word-break:break-all;
    }

    #egPassWallet .pw-detail-password-meter{
        height:5px;
        border-radius:999px;
        background:#dfe5ed;
        margin-top:7px;
        overflow:hidden;
    }

    #egPassWallet .pw-detail-password-meter span{
        display:block;
        width:88%;
        height:100%;
        background:#34864b;
        border-radius:999px;
    }

    #egPassWallet .pw-detail-grid{
        display:grid;
        grid-template-columns:110px minmax(0,1fr);
        border-top:1px solid #edf0f4;
    }

    #egPassWallet .pw-detail-grid>div{
        padding:9px 0;
        border-bottom:1px solid #edf0f4;
        font-size:10px;
    }

    #egPassWallet .pw-detail-grid .label{
        color:#8792a5;
    }

    #egPassWallet .pw-detail-grid .value{
        font-weight:700;
        color:#34455f;
        word-break:break-word;
    }

    #egPassWallet .pw-detail-actions{
        display:flex;
        gap:7px;
        margin-top:11px;
    }

    #egPassWallet .pw-detail-actions .btn{
        flex:1;
        min-height:38px;
        border-radius:9px;
        font-size:10px;
        font-weight:800;
    }

    #egPassWallet .pw-detail-list{
        display:grid;
        gap:7px;
    }
    #egPassWallet .pw-detail-list-row{
        border:1px solid #e5eaf1;
        background:#fff;
        border-radius:9px;
        padding:9px;
    }

    #egPassWallet .pw-detail-list-row strong{
        font-size:10px;
        color:#24334c;
    }
    #egPassWallet .pw-detail-list-row small{
        display:block;
        font-size:8px;
        color:#8793a6;
        margin-top:2px;
    }

    #egPassWallet .pw-share-current{
        padding:9px 10px;
        border:1px solid #e4e9f0;
        border-radius:9px;
        background:#fbfcfe;
        margin-bottom:10px;
    }
    #egPassWallet .pw-share-current-label{
        font-size:8px;
        color:#8b96a8;
        text-transform:uppercase;
        letter-spacing:.04em;
        font-weight:900;
    }
    #egPassWallet .pw-share-current strong{
        font-size:11px;
        color:#24334c;
    }

    #egPassWallet .pw-guided-step{
        display:flex;
        gap:9px;
        align-items:flex-start;
        border:1px solid #e6ebf1;
        border-radius:10px;
        padding:10px;
        margin-bottom:7px;
    }
    #egPassWallet .pw-guided-num{
        width:24px;
        height:24px;
        border-radius:50%;
        display:grid;
        place-items:center;
        flex:0 0 24px;
        background:#fff1ef;
        color:var(--pw-red);
        font-size:9px;
        font-weight:900;
    }
    #egPassWallet .pw-guided-step strong{
        display:block;
        font-size:10px;
        color:#25344c;
    }
    #egPassWallet .pw-guided-step span{
        display:block;
        margin-top:2px;
        font-size:8px;
        color:#8793a7;
        line-height:1.45;
    }

    #egPassWallet .pw-confirm .modal-dialog{
        max-width:430px;
    }
    #egPassWallet .pw-confirm-icon{
        width:38px;
        height:38px;
        border-radius:11px;
        display:grid;
        place-items:center;
        background:#fff7e6;
        color:#b37c09;
        font-size:19px;
    }

    @media(max-width:1199.98px){
        #egPassWallet .pw-summary-row{
            grid-template-columns:repeat(2,minmax(0,1fr));
        }
    }
    @media(max-width:767.98px){
        #egPassWallet .pw-hero-top{
            flex-direction:column;
            align-items:stretch;
        }
        #egPassWallet .pw-hero-actions{
            justify-content:flex-start;
        }
        /* #egPassWallet .pw-tabs{
            overflow:auto;
            flex-wrap:nowrap;
        } */
        #egPassWallet{
            padding:7px 10px 20px;
        }
        #egPassWallet .pw-hero{
            padding:13px;
        }
        #egPassWallet .pw-hero-actions{
            width:100%;
            justify-content:flex-end;
        }
        #egPassWallet .pw-hero{
            flex-direction:column;
        }
        #egPassWallet .pw-toolbar .pw-filter{
            width:100%;
            flex:1 1 100%;
        }
        #egPassWallet .pw-audience-modes{
            grid-template-columns:1fr 1fr;
        }
        #egPassWallet .pw-entry-modal .modal-dialog,
        #egPassWallet .pw-share-modal .modal-dialog{
            margin:.5rem;
        }
    }
    @media(max-width:479.98px){
        #egPassWallet .pw-hero h2{
            font-size:18px;
        }
    }
    @media(prefers-reduced-motion:reduce){
        #egPassWallet .pw-skeleton-line,
        #egPassWallet .pw-skeleton-icon{
            animation:none;
        }
    }

    #egPassWallet .pw-hero{
        display:block;
    }
    #egPassWallet .pw-hero-top{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:18px;
    }
    /* #egPassWallet .pw-tabs{
        margin:12px 0 -15px;
        padding:0;
        gap:4px;
    } */
    #egPassWallet .pw-hero .pw-tab{
        border:0;
        background:transparent;
        color:#f7d9d5;
        border-radius:8px 8px 0 0;
        padding:9px 13px;
    }
    #egPassWallet .pw-hero .pw-tab:hover{
        background:rgba(255,255,255,.07);
        color:#fff;
    }
    #egPassWallet .pw-hero .pw-tab.active{
        background:rgba(255,255,255,.12);
        border-color:transparent;
        color:#fff;
        box-shadow:none;
    }
    #egPassWallet .pw-hero p{
        margin:2px 0 0;
        color:#f7d9d5;
        font-size:10px;
        }
</style>

<div id="egPassWallet" >

    <div class="card card-action">
        <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
            <div class="d-flex flex-column align-items-start">
                <div class="d-flex align-items-center gap-2">
                    <h5 class="card-title mb-1 text-black"><i class="mdi mdi-shield-key-outline me-2 text-warning"></i>PassWallet</h5>
                    <span id="pwHeroSubtitle" class="badge bg-label-success border border-success">0 credentials</span>
                    <div class="pw-hero-meta">
                        <span class="pw-hero-pill bg-label-primary"><i class="mdi mdi-lock-open-outline"></i> Vault unlocked</span>
                        <span class="pw-hero-pill bg-label-primary" id="pwRotationHero"><i class="mdi mdi-autorenew"></i> Rotation status loading…</span>
                    </div>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> Tool Mangement
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                            PassWallet
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                <div class="pw-hero-actions">
                    <button type="button" class="btn btn-warning px-3" data-pw-action="lock-now">
                        <i class="mdi mdi-lock-outline me-1"></i> Lock
                    </button>
                    @if($add_entry == 1)
                        <button type="button" class="btn btn-primary px-3" data-pw-action="new-entry">
                            <i class="mdi mdi-plus me-1"></i> New entry
                        </button>
                    @endif
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="pw-tabs mb-2" role="tablist" aria-label="PassWallet views">
                <button type="button" class="pw-tab text-dark text-white active" data-pw-tab="all"><i class="mdi mdi-shield-key-outline me-1"></i> My Vault <span class="ms-1 opacity-75" id="pwMyCount">0</span></button>
                <button type="button" class="pw-tab text-dark" data-pw-tab="shared"><i class="mdi mdi-share-variant-outline me-1"></i> Shared with me <span class="ms-1 opacity-75" id="pwSharedCount">0</span></button>
                <button type="button" class="pw-tab text-dark" data-pw-tab="company"><i class="mdi mdi-domain me-1"></i> Company Vault <span class="ms-1 opacity-75" id="pwCompanyCount">0</span></button>
            </div>
            
            <div class="row">
             
                <div class="col-lg-12">
                    
                    <div class="pw-toolbar">
                        <div>
                            @php 
                                $perpage =25;
                            @endphp
                            <select id="perpage" class="form-select form-select-sm w-75px select3"
                                onchange="loadData(1)">
                                @php $options = [5,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="pw-search input-group input-group-merge">
                            <span class="input-group-text bg-white border-end-0"><i class="mdi mdi-magnify text-muted"></i></span>
                            <input type="search" id="pwSearch" class="form-control border-start-0 ps-1" placeholder="Search entries…" autocomplete="off">
                        </div>
                        <div>
                            <select id="pwTypeFilter" class="form-select select3 pw-filter" aria-label="Type filter" onchange="typeFilterChangeFunc()">
                                <option value="">Type · All</option>
                            </select>
                         </div>
                        <button type="button" class="btn btn-light border shadow-none" data-pw-action="refresh" title="Refresh"><i class="mdi mdi-refresh"></i></button>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="pw-card">
                        <div class="pw-table-wrap">
                            <table class="table pw-table mb-0" aria-describedby="PassWallet credential list">
                                <thead>
                                    <tr class=" text-muted fw-semibold fs-8 text-uppercase bg-primary ">
                                        <th>Entry</th>
                                        <th>Type</th>
                                        <th>Username</th>
                                        <th>Password</th>
                                        <th>Scope</th>
                                        <th>Rotation</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="pwWorkspace">
                                    <tr><td colspan="7"><div class="pw-empty"><div class="spinner-border spinner-border-sm text-danger"></div><div class="small mt-2">Loading secure vault…</div></div></td></tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="px-3 pb-3">
                            <div class="text-center " id="pagination-container">
                                <!-- Pagination buttons will appear here -->
                            </div>
                            <!-- <div id="pwPagination"></div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- modals Start -->
  
    <!-- New / Edit Entry Modal -->
    <div id="pwEntryModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="pwEntryModalTitle">New vault entry</h5>
                        <div class="small text-muted" id="pwEntryModalSubtitle">Store the credential encrypted and keep the default masked until step-up verification.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="pwEntryForm" autocomplete="off">
                    <div class="modal-body" >
                        <input type="hidden" name="company_id" id="pwEntryCompanyId">
                        <input type="hidden" name="visibility" value="Private">
                        <input type="hidden" name="entry_id" id="pwEntryId">

                        <div class="pw-form-section">
                            <div class="pw-form-section-title">Credential</div>
                            <div class="row g-2">
                                <div class="col-12">
                                    <label class="pw-field-label">Entry name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control pw-form-control" name="entry_name" id="pwEntryName" maxlength="180" placeholder="e.g. AWS Console — production" required>
                                </div>
                                <div class="col-md-7">
                                    <label class="pw-field-label">Link / app</label>
                                    <input type="url" class="form-control pw-form-control" name="url" id="pwEntryUrl" maxlength="2000" placeholder="https://example.com">
                                </div>
                                <div class="col-md-5">
                                    <label class="pw-field-label form-label text-black fs-8 fw-semibold">Type <span class="text-danger">*</span></label>
                                    <select class="form-select select3" id="pwEntryType" name="entry_type" required>
                                      
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="pw-field-label">Username</label>
                                    <input type="text" class="form-control pw-form-control" name="username" id="pwEntryUsername" maxlength="255" placeholder="admin@example.com">
                                </div>
                            </div>
                        </div>

                        <div class="pw-form-section">
                            <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                                <div class="pw-form-section-title mb-0">Password</div>
                                <span class="small text-muted" id="pwEditPasswordHint"></span>
                            </div>
                            <div class="pw-password-group">
                                <input type="password" class="form-control pw-form-control" name="password" id="pwEntryPassword" maxlength="1000" placeholder="Enter or generate" required>
                                <button type="button" class="btn btn-outline-primary px-3" data-pw-action="generate-password">
                                    <i class="mdi mdi-dice-multiple-outline me-1"></i> Generate
                                </button>
                                <button type="button" class="btn btn-light border shadow-none" data-pw-action="toggle-entry-password" title="Show password">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                            </div>
                            <div class="pw-password-strength" id="pwPasswordStrength"></div>
                            <div class="pw-password-note">Stored encrypted · always masked by default · rotation reminder starts at 90 days.</div>
                        </div>

                        <div class="pw-form-section">
                            <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                                <div class="pw-form-section-title mb-0">Scope / audience</div>
                                <span class="small text-muted" id="pwAudienceModeChip"><i class="mdi mdi-lock-outline"></i> Private</span>
                            </div>
                            <div class="pw-audience-builder">
                                <div class="pw-audience-modes" id="pwAudienceModes">
                                    <button type="button" class="pw-audience-mode active" data-pw-audience-mode="private"><i class="mdi mdi-lock-outline"></i> Private</button>
                                    <button type="button" class="pw-audience-mode" data-pw-audience-mode="company"><i class="mdi mdi-office-building-outline"></i> Company</button>
                                    <button type="button" class="pw-audience-mode" data-pw-audience-mode="entity"><i class="mdi mdi-domain"></i> Entity</button>
                                    <button type="button" class="pw-audience-mode" data-pw-audience-mode="role"><i class="mdi mdi-account-badge-outline"></i> Role</button>
                                    <button type="button" class="pw-audience-mode" data-pw-audience-mode="staff"><i class="mdi mdi-account-multiple-outline"></i> Staff</button>
                                </div>
                                <div class="pw-audience-hint" id="pwAudienceHint">Only you can access this credential. Switch to another scope to share it.</div>

                                <div id="pwAudienceFields">
                                    <div class="pw-audience-panel" data-pw-audience-panel="company">
                                        <label class="pw-field-label">Companies</label>
                                        <div class="pw-select2">
                                            <select class="form-select select3" id="pwAudienceCompany" multiple>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="pw-audience-panel d-none" data-pw-audience-panel="entity">
                                        <label class="pw-field-label">Entities</label>
                                        <div class="pw-select2">
                                            <select class="form-select select3" id="pwAudienceEntity" multiple size="4" aria-label="Entities">

                                            </select>
                                        </div>
                                    </div>
                                    <div class="pw-audience-panel d-none" data-pw-audience-panel="role">
                                        <div class="row g-2">
                                            <div class="col-md-6">
                                                <label class="pw-field-label">Entities</label>
                                                <div class="pw-select2">
                                                    <select class="form-select select3" id="pwAudienceRoleEntity" multiple size="4" aria-label="Role entities" onchange="postRoleEntityChangeFunction()">

                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="pw-field-label">Roles</label>
                                                <div class="pw-select2">
                                                    <select class="form-select select3" id="pwAudienceRole" multiple>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="pw-audience-panel d-none" data-pw-audience-panel="staff">
                                        <div class="row g-2">
                                            <div class="col-md-6">
                                                <label class="pw-field-label">Entities</label>
                                                <div class="pw-select2">
                                                    <select class="form-select select3" id="pwAudienceStaffEntity" multiple size="4" aria-label="Staff entities" onchange="postStaffEntityChangeFunction()">

                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="pw-field-label">Staff</label>
                                                <div class="pw-select2">
                                                    <select class="form-select select3" id="pwAudienceStaff" multiple>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pw-audience-summary" id="pwAudienceSummary">
                                    <div class="pw-audience-summary-label">Selected</div>
                                    <div class="pw-audience-chip">
                                        <i class="mdi mdi-office-building-outline"></i>Choose at least one company.
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="pw-advanced-section" id="pwAdvancedAccordion">
                            <button type="button"
                                    id="pwAdvancedToggle"
                                    class="pw-advanced-toggle collapsed"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#pwAdvancedBody"
                                    aria-expanded="false"
                                    aria-controls="pwAdvancedBody">
                                <span class="pw-advanced-toggle-left">
                                    <span class="pw-advanced-icon"><i class="mdi mdi-tune-variant"></i></span>
                                    <span class="pw-advanced-copy">
                                        <span class="pw-advanced-title">Recovery &amp; notes</span>
                                        <span class="pw-advanced-subtitle">Optional recovery details, notes and rotation settings</span>
                                    </span>
                                </span>
                                <i class="mdi mdi-chevron-down pw-advanced-chevron"></i>
                            </button>

                            <div id="pwAdvancedBody" class="collapse" aria-labelledby="pwAdvancedToggle">
                                <div class="pw-advanced-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="pw-field-label">Recovery email</label>
                                            <input type="email"
                                                   class="form-control pw-form-control"
                                                   name="email"
                                                   id="pwEntryEmail"
                                                   maxlength="180"
                                                   placeholder="recovery@example.com">
                                        </div>

                                        <div class="col-md-6">
                                            <label class="pw-field-label">Recovery mobile</label>
                                            <input type="text"
                                                   class="form-control pw-form-control"
                                                   name="mobile"
                                                   id="pwEntryMobile"
                                                   maxlength="40"
                                                   placeholder="+91 …">
                                        </div>

                                        <div class="col-12">
                                            <label class="pw-field-label">Notes</label>
                                            <textarea class="form-control pw-form-control"
                                                      name="notes"
                                                      id="pwEntryNotes"
                                                      maxlength="10000"
                                                      placeholder="Add a short internal note, recovery instruction or handling detail…"></textarea>
                                        </div>

                                        <div class="col-md-6">
                                            <label class="pw-field-label">Rotation reminder</label>
                                            <select class="form-select pw-form-select select3"
                                                    name="rotation_days"
                                                    id="pwEntryRotation">
                                                <option value="30">Every 30 days</option>
                                                <option value="60">Every 60 days</option>
                                                <option value="90" selected>Every 90 days</option>
                                                <option value="180">Every 180 days</option>
                                                <option value="365">Every 365 days</option>
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label class="pw-field-label">Custom icon URL <span class="text-muted fw-normal">(optional)</span></label>
                                            <input type="url"
                                                   class="form-control pw-form-control"
                                                   name="icon_url"
                                                   id="pwEntryIconUrl"
                                                   maxlength="1000"
                                                   placeholder="https://example.com/icon.png">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="pw-security-box">
                            <i class="mdi mdi-shield-check-outline"></i> PassWallet secrets are encrypted at rest. Reveal, copy, sharing and sensitive changes remain auditable server-side.
                        </div>                            

                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm shadow-none" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="pwEntrySubmit" ><i class="mdi mdi-content-save-outline me-1"></i><span>Save entry</span></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="kShareModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <div class="k-modal-kicker fs-9 fw-semibold text-dark">KNOWLEDGE</div>
                        <h5 class="modal-title mb-1" id="kShareTitle">Share Knowledge</h5>
                        <div class="small text-muted" id="kShareSubtitle"></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="kShareForm" novalidate>
                    <div class="modal-body">
                        <input type="hidden" name="resource_id" id="kShareResourceId">

                        <div class="k-audience-builder">
                            <div class="d-flex align-items-start justify-content-between gap-2 mb-2">
                                <div>
                                    <div class="fw-bold" style="font-size:10px">Share audience</div>
                                    <div class="k-form-hint fs-9 text-muted">Choose exactly who should receive access to this post.</div>
                                </div>
                                <span class="k-audience-chip fs-9 text-dark fw-semibold" id="kShareAudienceModeChip"><i class="mdi mdi-office-building-outline"></i> Company</span>
                            </div>
                            <div class="k-audience-modes" id="kShareAudienceModes">
                                <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold active" data-k-audience-mode="company"><i class="mdi mdi-office-building-outline"></i><span>Company</span></button>
                                <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="entity"><i class="mdi mdi-domain"></i><span>Entity</span></button>
                                <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="role"><i class="mdi mdi-account-badge-outline"></i><span>Role</span></button>
                                <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="staff"><i class="mdi mdi-account-multiple-outline"></i><span>Staff</span></button>
                            </div>
                            <div id="kShareAudienceSummary" class="k-audience-selection"></div>
                            <div id="kShareAudienceFields" class="k-audience-fields">
                                <div class="k-audience-field" data-k-audience-panel="company">
                                    <label class="form-label  text-black fs-8 fw-semibold">Companies <span class="text-muted">Select one or more</span></label>
                                    <select class="form-select select3" id="kShareAudienceCompany" name="audience_company_ids[]" multiple size="4" aria-label="Share companies"></select>
                                </div>
                                <div class="k-audience-field d-none" data-k-audience-panel="entity">
                                    <label class="form-label  text-black fs-8 fw-semibold">Entities <span class="text-muted">Select one or more</span></label>
                                    <select class="form-select select3" id="kShareAudienceEntity" name="audience_entity_ids[]" multiple size="4" aria-label="Share entities"></select>
                                </div>
                                <div class="k-audience-field d-none" data-k-audience-panel="role">
                                    <div class="mb-3">
                                        <label class="form-label  text-black fs-8 fw-semibold">Entities <span class="text-muted">Roles are loaded from these entities</span></label>
                                        <select class="form-select select3" id="kShareAudienceRoleEntity" multiple size="4" aria-label="Share role entities"  onchange="shareRoleEntityChangeFunction()"></select>
                                    </div>
                                    <label class="form-label  text-black fs-8 fw-semibold">Roles <span class="text-muted">Select one or more</span></label>
                                    <select class="form-select select3" id="kShareAudienceRole" name="audience_role_ids[]" multiple size="4" aria-label="Share roles"></select>
                                </div>
                                <div class="k-audience-field d-none" data-k-audience-panel="staff">
                                    <div class="mb-3">
                                        <label class="form-label  text-black fs-8 fw-semibold">Entities <span class="text-muted">Staff are loaded from these entities</span></label>
                                        <select class="form-select select3" id="kShareAudienceStaffEntity" multiple size="4" aria-label="Share staff entities"  onchange="shareStaffEntityChangeFunction()"></select>
                                    </div>
                                    <label class="form-label  text-black fs-8 fw-semibold">Staff <span class="text-muted">Select one or more</span></label>
                                    <select class="form-select select3" id="kShareAudienceStaff" name="audience_staff_ids[]" multiple size="4" aria-label="Share staff"></select>
                                </div>
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            <div class="col-md-6">
                                <label class="form-label text-black fs-8 fw-semibold">Permission</label>
                                <select class="form-select select3" id="kSharePermission" name="permission">
                                    <option value="View" selected>View only</option>
                                    <option value="Manage">Can manage</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-black fs-8 fw-semibold">Expires <span class="text-muted">(optional)</span></label>
                                <input class="form-control" type="text" name="expires_at" id="kShareExpiresAt">
                            </div>
                        </div>

                        <!-- <div class="k-share-link-box mt-3">
                            <div>
                                <div class="fw-bold">Quick share</div>
                                <div class="k-form-hint">Copy the Knowledge link or use your device share menu.</div>
                            </div>
                            <button type="button" class="btn btn-light btn-sm" id="kShareCopyLink"><i class="mdi mdi-link-variant me-1"></i>Copy link</button>
                        </div> -->
                        <div id="kShareExisting" class="mt-3 d-none"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="kShareSave"><i class="mdi mdi-share-variant-outline me-1"></i>Share</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="kConfirmModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="kConfirmTitle">Confirm</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="kConfirmBody"></div><div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-danger btn-sm" id="kConfirmYes">Continue</button></div></div></div>
    </div>


    
 

    <!-- Step-up Modal -->
    <div class="modal fade pw-modal pw-stepup-modal" id="pwStepUpModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="pw-modal-head d-flex align-items-start justify-content-between gap-3">
                    <div>
                        <h5><i class="mdi mdi-shield-lock-outline text-warning me-1"></i> Confirm it’s you</h5>
                        <p>Password reveal, copy, change and sharing require fresh step-up verification.</p>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="pwStepUpForm">
                    <div class="pw-modal-body">
                        <label class="pw-field-label">ERP password <span class="text-danger">*</span></label>
                        <input type="password" class="form-control pw-form-control" name="stepup_password" id="pwStepUpPassword" autocomplete="current-password" required>
                        <div class="small text-muted mt-2">Verified for 5 minutes in this secure session.</div>
                    </div>
                    <div class="pw-modal-foot">
                        <button type="button" class="btn btn-light border shadow-none" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="pwStepUpSubmit"><i class="mdi mdi-lock-open-outline me-1"></i> Verify & unlock</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Share Modal -->
    <div class="modal fade pw-modal pw-share-modal" id="pwShareModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="pw-modal-head d-flex align-items-start justify-content-between gap-3">
                    <div><h5>Share credential</h5><p>Use the same Company / Entity / Role / Staff audience model as Knowledge Panel.</p></div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="pwShareForm">
                    <div class="pw-modal-body">
                        <input type="hidden" id="pwShareEntryId">
                        <div class="row g-2 mb-3">
                            <div class="col-md-6">
                                <label class="pw-field-label">Permission</label>
                                <select class="form-select pw-form-select" name="permission" id="pwSharePermission"><option value="View">View</option><option value="Manage">Manage</option></select>
                            </div>
                            <div class="col-md-6">
                                <label class="pw-field-label">Expires</label>
                                <select class="form-select pw-form-select" id="pwShareExpiryPreset"><option value="">No expiry</option><option value="7">7 days</option><option value="30">30 days</option><option value="90">90 days</option></select>
                                <input type="hidden" name="expires_at" id="pwShareExpiresAt">
                            </div>
                        </div>
                        <div class="pw-audience-builder" id="pwShareAudienceBuilder">
                            <div class="pw-audience-modes" id="pwShareAudienceModes">
                                <button type="button" class="pw-audience-mode active" data-pw-share-audience-mode="company"><i class="mdi mdi-office-building-outline"></i> Company</button>
                                <button type="button" class="pw-audience-mode" data-pw-share-audience-mode="entity"><i class="mdi mdi-domain"></i> Entity</button>
                                <button type="button" class="pw-audience-mode" data-pw-share-audience-mode="role"><i class="mdi mdi-account-badge-outline"></i> Role</button>
                                <button type="button" class="pw-audience-mode" data-pw-share-audience-mode="staff"><i class="mdi mdi-account-multiple-outline"></i> Staff</button>
                            </div>
                            <div class="pw-audience-hint" id="pwShareAudienceHint">Everyone matching the selected companies will have access.</div>
                            <div id="pwShareAudienceFields">
                                <div class="pw-audience-panel" data-pw-share-audience-panel="company"><label class="pw-field-label">Companies</label><div class="pw-select2"><select class="form-select" id="pwShareAudienceCompany" multiple></select></div></div>
                                <div class="pw-audience-panel d-none" data-pw-share-audience-panel="entity"><label class="pw-field-label">Entities</label><div class="pw-select2"><select class="form-select" id="pwShareAudienceEntity" multiple></select></div></div>
                                <div class="pw-audience-panel d-none" data-pw-share-audience-panel="role"><div class="row g-2"><div class="col-md-6"><label class="pw-field-label">Entities</label><div class="pw-select2"><select class="form-select" id="pwShareAudienceRoleEntity" multiple></select></div></div><div class="col-md-6"><label class="pw-field-label">Roles</label><div class="pw-select2"><select class="form-select" id="pwShareAudienceRole" multiple></select></div></div></div></div>
                                <div class="pw-audience-panel d-none" data-pw-share-audience-panel="staff"><div class="row g-2"><div class="col-md-6"><label class="pw-field-label">Entities</label><div class="pw-select2"><select class="form-select" id="pwShareAudienceStaffEntity" multiple></select></div></div><div class="col-md-6"><label class="pw-field-label">Staff</label><div class="pw-select2"><select class="form-select" id="pwShareAudienceStaff" multiple></select></div></div></div></div>
                            </div>
                            <div class="pw-audience-summary" id="pwShareAudienceSummary"><div class="pw-audience-summary-label">Selected</div><div class="pw-audience-chip"><i class="mdi mdi-office-building-outline"></i>Choose at least one company.</div></div>
                        </div>
                        <div class="mt-3" id="pwShareExisting"></div>
                    </div>
                    <div class="pw-modal-foot">
                        <button type="button" class="btn btn-light border shadow-none" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="pwShareSubmit"><i class="mdi mdi-share-variant-outline me-1"></i> Save share</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Change Password Guided Modal -->
    <div class="modal fade pw-modal" id="pwChangePasswordModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" style="max-width:560px">
            <div class="modal-content">
                <div class="pw-modal-head d-flex align-items-start justify-content-between gap-3">
                    <div><h5>Change password (guided)</h5><p>Open the target site, generate a replacement, then save it back to PassWallet.</p></div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="pw-modal-body">
                    <div class="pw-guided-step"><div class="pw-guided-num">1</div><div><strong>Open the target</strong><span>Use the button below to open the stored Link / app in a new tab.</span><div class="mt-2"><a href="#" target="_blank" rel="noopener noreferrer" class="btn btn-light border shadow-none btn-sm" id="pwChangeTarget"><i class="mdi mdi-open-in-new me-1"></i> Open target</a></div></div></div>
                    <div class="pw-guided-step"><div class="pw-guided-num">2</div><div class="flex-grow-1"><strong>Generate the replacement</strong><span>A generated secret will not be persisted until you confirm the change.</span><div class="pw-password-group mt-2"><input type="text" class="form-control pw-form-control" id="pwChangePasswordValue" readonly><button type="button" class="btn btn-outline-primary" data-pw-action="change-generate"><i class="mdi mdi-dice-multiple-outline"></i></button></div></div></div>
                    <div class="pw-guided-step"><div class="pw-guided-num">3</div><div><strong>Save to PassWallet</strong><span>PassWallet will require step-up verification before the new secret is stored and the old secret is archived.</span></div></div>
                </div>
                <div class="pw-modal-foot">
                    <button type="button" class="btn btn-light border shadow-none" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" data-pw-action="change-save"><i class="mdi mdi-content-save-outline me-1"></i> Save new password</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Confirm Modal -->
    <div class="modal fade pw-modal pw-confirm" id="pwConfirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="pw-modal-body">
                    <div class="d-flex gap-3 align-items-start">
                        <div class="pw-confirm-icon"><i class="mdi mdi-alert-outline"></i></div>
                        <div class="flex-grow-1"><h5 class="mb-1 fw-bold fs-6" id="pwConfirmTitle">Confirm action</h5><div class="small text-muted" id="pwConfirmBody"></div></div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                </div>
                <div class="pw-modal-foot"><button type="button" class="btn btn-light border shadow-none" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="pwConfirmYes">Continue</button></div>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-end pw-offcanvas" tabindex="-1" id="pwDetailOffcanvas" aria-labelledby="pwDetailTitle">
        <div class="pw-offcanvas-head d-flex align-items-start justify-content-between gap-3">
            <div class="d-flex gap-10px align-items-center flex-grow-1 min-w-0">
                <div class="pw-entry-icon" id="pwDetailIcon" style="background:rgba(255,255,255,.09);border-color:rgba(255,255,255,.13);color:#fff;flex:0 0 38px;width:38px;height:38px"><i class="mdi mdi-shield-key-outline"></i></div>
                <div class="min-w-0"><h5 id="pwDetailTitle">Credential</h5><p id="pwDetailSubtitle">Loading secure record…</p></div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="pw-offcanvas-body">
            <div class="pw-detail-tabs">
                <button type="button" class="pw-detail-tab active" data-pw-detail-tab="details">Details</button>
                <button type="button" class="pw-detail-tab" data-pw-detail-tab="history">History</button>
                <button type="button" class="pw-detail-tab" data-pw-detail-tab="audit">Audit trail</button>
                <button type="button" class="pw-detail-tab" data-pw-detail-tab="sharing">Sharing</button>
            </div>
            <div id="pwDetailContent" class="pw-detail-pane"></div>
        </div>
    </div>
    <!-- modals End -->
</div>



<script>
    const addEntry = @json($add_entry);

    const config = @js([
        'csrf' => csrf_token(),
        'dateFormat' => $common_date_format,
        'permissions' => [
            'newEntry' => (int) $add_entry,
        ],
        'routes' => [
            'options' => route('productivity.passwallet.options'),
            'audienceOptions' => route('productivity.passwallet.audience.options'),
            'data' => route('productivity.passwallet.data'),
            'generator' => route('productivity.passwallet.generator'),
            'store' => route('productivity.passwallet.store'),
            'show' => url('/productivity/passwallet'),
            'update' => url('/productivity/passwallet'),
            'reveal' => url('/productivity/passwallet/{id}/reveal'),
            'copyAudit' => url('/productivity/passwallet/{id}/copy-audit'),
            'history' => url('/productivity/passwallet/{id}/history'),
            'audit' => url('/productivity/passwallet/{id}/audit'),
            'shares' => url('/productivity/passwallet/{id}/shares'),
            'shareStore' => url('/productivity/passwallet/{id}/share'),
            'shareRevoke' => url('/productivity/passwallet/shares'),
            'delete' => url('/productivity/passwallet'),
            'stepup' => route('productivity.passwallet.stepup'),
            'lockdown' => url('/productivity/passwallet/lockdown'),
            'users' => route('productivity.users'),
            'companies' => route('productivity.companies')
        ],
    ]);

    const R = config.routes || {};
    const $root = $('#egPassWallet');
    const $workspace = $('#pwWorkspace');
    const state = {
        page:1,
        perPage:25,
        search:'',
        type:'',
        tab:'all',
        types:[],
        audience:{post:{mode:'private'},share:{mode:'company'}},
        currentEntry:null,
        currentDetailTab:'details',
        loading:false,
        requestToken:0,
        stepUpPending:null,
        stepUpBusy:false,
        confirmPending:null,
        editMode:false,
        changeEntry:null
    };

    $.ajaxSetup({
        headers:{
            'X-CSRF-TOKEN':config.csrf,
            'X-Requested-With':'XMLHttpRequest',
            'Accept':'application/json'
        }
    });

    function esc(v){
        return $('<div>').text(v == null ? '' : String(v)).html();
    }

    function query(params){
        const q=new URLSearchParams();
        Object.keys(params||{}).forEach(function(key){
            const value=params[key];
            if(value === undefined || value === null || value === '') return;
            if(Array.isArray(value)){
                value.forEach(function(item){
                    if(item !== undefined && item !== null && item !== '') q.append(key+'[]',item);
                });
            }else{
                q.set(key,value);
            }
        });
        return q.toString();
    }

    function routeUrl(base,id,suffix){
        let value=String(base||'').replace(/\/$/,'');
        if(id !== undefined && id !== null && id !== ''){
            value=value.includes('{id}') ? value.replace('{id}',encodeURIComponent(id)) : value.includes('__ID__') ? value.replace('__ID__',encodeURIComponent(id)) : value+'/'+encodeURIComponent(id);
        }
        if(suffix) value=value+'/'+String(suffix).replace(/^\//,'');
        return value;
    }

    function ajax(method,endpoint,data,options){
        const opts=options||{};
        const isForm=data instanceof FormData;
        return $.ajax({
            url:endpoint,
            method:method||'GET',
            data:data||{},
            processData:!isForm,
            contentType:isForm?false:'application/x-www-form-urlencoded; charset=UTF-8',
            dataType:'json',
            timeout:opts.timeout||30000,
            headers:{
                'X-CSRF-TOKEN':config.csrf,
                'X-Requested-With':'XMLHttpRequest',
                'Accept':'application/json'
            }
        }).then(function(res){return res;}).catch(function(xhr){
            const response=xhr?.responseJSON||xhr||{};
            if(response.errors){
                const first=Object.values(response.errors)[0];
                if(Array.isArray(first)&&first[0]) response.message=first[0];
            }
            return $.Deferred().reject(response).promise();
        });
    }

    function notify(message,type){
        if(typeof toastr==='undefined'){
            console.warn(message||'PassWallet notification');
            return;
        }
        if(type==='error') return toastr.error(message||'Action failed.');
        if(type==='warning') return toastr.warning(message||'Please review the action.');
        return toastr.success(message||'Done.');
    }

    function errMsg(error,fallback){
        return error?.message || error?.responseJSON?.message || fallback || 'Server request failed.';
    }

    function modal(id){
        const el=document.getElementById(id);
        return el ? bootstrap.Modal.getOrCreateInstance(el) : null;
    }

    function offcanvas(id){
        const el=document.getElementById(id);
        return el ? bootstrap.Offcanvas.getOrCreateInstance(el) : null;
    }

    function confirmAction(title,body,yes,fn){
        $('#pwConfirmTitle').text(title||'Confirm action');
        $('#pwConfirmBody').text(body||'');
        $('#pwConfirmYes').text(yes||'Continue').off('click.pwConfirm').on('click.pwConfirm',function(){
            const button=$(this).prop('disabled',true);
            let request;
            try{ request=fn(); }catch(e){ notify(e.message||'Action failed.','error'); button.prop('disabled',false); return; }
            const done=function(){ button.prop('disabled',false); modal('pwConfirmModal')?.hide(); };
            if(request && typeof request.always==='function') request.always(done); else Promise.resolve(request).finally(done);
        });
        modal('pwConfirmModal')?.show();
    }

   

    function setSelect2Values(selector,values){
        const $el=$(selector);
        if(!$el.length) return;
        const strings=(values||[]).map(String);
        $el.val(strings).trigger('change.select2');
    }

    function populateSelect(selector,items,placeholder){
        const el=document.querySelector(selector);
        if(!el) return;
        
        el.innerHTML='';
        (items||[]).forEach(function(item){
            const option=document.createElement('option');
            option.value=String(item.value);
            option.textContent=String(item.label||'');
            el.appendChild(option);
        });
        if(placeholder) el.setAttribute('data-placeholder',placeholder);
        
    }

    function typeIcon(type){
        const found=state.types.find(x=>String(x.value)===String(type));
        return found?.icon || ({Website:'mdi-web',System:'mdi-server-outline',Application:'mdi-apps','Mobile App':'mdi-cellphone-outline'}[type] || 'mdi-key-outline');
    }

    function typeLabel(type){
        return state.types.find(x=>String(x.value)===String(type))?.label || type || '—';
    }

    function formatDate(value){
        if(!value) return '—';
        const d=new Date(String(value).replace(' ','T'));
        if(Number.isNaN(d.getTime())) return String(value);
        return d.toLocaleDateString(undefined,{day:'2-digit',month:'short',year:'numeric'});
    }

    function formatDateTime(value){
        if(!value) return '—';
        const d=new Date(String(value).replace(' ','T'));
        if(Number.isNaN(d.getTime())) return String(value);
        return d.toLocaleString(undefined,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
    }

    function formatDomain(url){
        try{
            return new URL(url).hostname.replace(/^www\./,'');
        }catch(e){return url||'';}
    }

    function rotationState(entry){
        if(entry?.rotation_state) return entry.rotation_state;
        if(!entry?.next_rotation_at) return {key:'none',label:'Not scheduled'};
        const date=new Date(String(entry.next_rotation_at).replace(' ','T'));
        if(Number.isNaN(date.getTime())) return {key:'none',label:'—'};
        const diff=Math.ceil((date.getTime()-Date.now())/86400000);
        if(diff<0) return {key:'overdue',label:'Overdue '+Math.abs(diff)+'d'};
        if(diff===0) return {key:'due',label:'Due today'};
        if(diff<=30) return {key:'due',label:'Due in '+diff+'d'};
        return {key:'ok',label:'OK'};
    }

    function entryIconHtml(entry,large){
        const iconUrl=entry?.icon_path || entry?.icon_url || '';
        const size=large ? '38px':'34px';
        if(iconUrl){
            return `<div class="pw-entry-icon" style="width:${size};height:${size};flex-basis:${size}"><img src="${esc(iconUrl)}" alt="" onerror="this.parentNode.innerHTML='<i class=&quot;mdi mdi-shield-key-outline&quot;></i>'"></div>`;
        }
        return `<div class="pw-entry-icon" style="width:${size};height:${size};flex-basis:${size}"><i class="mdi ${esc(typeIcon(entry?.entry_type))}"></i></div>`;
    }

    function passwordScore(password){
        const value=String(password||'');
        if(!value) return {label:'',className:''};
        let score=0;
        if(value.length>=12) score++;
        if(/[A-Z]/.test(value)) score++;
        if(/[a-z]/.test(value)) score++;
        if(/[0-9]/.test(value)) score++;
        if(/[^A-Za-z0-9]/.test(value)) score++;
        if(score>=5) return {label:'Strong',className:'strong'};
        if(score>=3) return {label:'Medium',className:'medium'};
        return {label:'Weak',className:'weak'};
    }

    function renderPasswordStrength(){
        const value=$('#pwEntryPassword').val()||'';
        const score=passwordScore(value);
        $('#pwPasswordStrength').attr('class','pw-password-strength '+score.className).text(score.label ? score.label+' password' : '');
    }

    function renderTypes(){
        const current=state.type||'';
        $('#pwTypeFilter').html('<option value="">Type · All</option>'+(state.types||[]).map(x=>`<option value="${esc(x.value)}">${esc(x.label)}</option>`).join('')).val(current);
        populateSelect('#pwEntryType',(state.types||[]).map(x=>({value:x.value,label:x.label})),'Choose type');
    }

    function loadOptions(){
        return ajax('GET',R.options).done(function(response){
            const data=response?.data||{};
            state.types=Array.isArray(data.types)?data.types:[];
            renderTypes();
        });
    }

    function renderSkeleton(count){
        return Array.from({length:count||6}).map(function(){
            return `<tr class="pw-skeleton-row" aria-hidden="true">
                <td><div class="d-flex align-items-center gap-2"><div class="pw-skeleton-icon"></div><div class="flex-grow-1"><div class="pw-skeleton-line pw-sk-60 mb-1"></div><div class="pw-skeleton-line pw-sk-45"></div></div></div></td>
                <td><div class="pw-skeleton-line pw-sk-45"></div></td>
                <td><div class="pw-skeleton-line pw-sk-60"></div></td>
                <td><div class="pw-skeleton-line pw-sk-45"></div></td>
                <td><div class="pw-skeleton-line pw-sk-45"></div></td>
                <td><div class="pw-skeleton-line pw-sk-30"></div></td>
                <td><div class="pw-skeleton-line pw-sk-30 ms-auto"></div></td>
            </tr>`;
        }).join('');
    }

    function renderRows(rows){
        if(!rows.length){
            return `<tr><td colspan="7"><div class="pw-empty"><i class="mdi mdi-shield-off-outline"></i><div class="fw-bold mb-1 text-dark">No credentials found</div><div class="small mb-3">Try another type or search term.</div>${addEntry==1?'<button type="button" class="btn btn-primary btn-sm" data-pw-action="new-entry"><i class="mdi mdi-plus me-1"></i>New entry</button>':''}</div></td></tr>`;
        }
        return rows.map(function(entry){
            const rotation=rotationState(entry);
            const scope=entry.scope_label||entry.visibility||'Private';
            const domain=entry.url?formatDomain(entry.url):'';
            return `<tr data-pw-row="${esc(entry.sno)}">
                <td>
                    <div class="pw-entry-wrap">
                        ${entryIconHtml(entry)}
                        <div class="min-w-0">
                            <div class="pw-entry-name text-truncate">${esc(entry.entry_name)}</div>
                            ${domain?`<div class="pw-entry-url">${esc(domain)}</div>`:''}
                        </div>
                    </div>
                </td>
                <td><span class="pw-type-badge"><i class="mdi ${esc(typeIcon(entry.entry_type))}"></i>${esc(typeLabel(entry.entry_type))}</span></td>
                <td><span class="pw-username">${esc(entry.username||entry.email||'—')}</span><button type="button" class="pw-username-copy" data-pw-action="copy-username" data-id="${esc(entry.sno)}" title="Copy username"><i class="mdi mdi-content-copy fs-6"></i></button></td>
                <td>
                    <div class="pw-inline-secret">
                        <span class="pw-secret-mask">••••••••</span>
                        <button type="button" class="pw-inline-btn" data-pw-action="show-password" data-id="${esc(entry.sno)}" title="Reveal"><i class="mdi mdi-eye-outline"></i></button>
                        <button type="button" class="pw-inline-btn" data-pw-action="copy-password" data-id="${esc(entry.sno)}" title="Copy"><i class="mdi mdi-content-copy"></i></button>
                    </div>
                </td>
                <td><span class="pw-scope-badge"><i class="mdi mdi-shield-account-outline"></i>${esc(scope)}</span></td>
                <td><span class="pw-rotation-badge ${esc(rotation.key)}">${esc(rotation.label)}</span></td>
                <td><div class="pw-row-actions">
                    <button type="button" class="btn btn-light border shadow-none" data-pw-action="open-entry" data-id="${esc(entry.sno)}" title="Open"><i class="mdi mdi-open-in-new"></i></button>
                    
                </div></td>
            </tr>`;
        }).join('');
    }


    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadData(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadData(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadData(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadData(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadData(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function renderPagination(pager){
        const current=Number(pager?.current_page||1);
        const last=Number(pager?.last_page||1);
        const total=Number(pager?.total||0);
        const from=Number(pager?.from||0);
        const to=Number(pager?.to||0);
        $('#pwPagination').html(`<div class="pw-pagination"><div>${total?`Showing ${from}–${to} of ${total}`:'No records'}</div><div class="d-flex gap-1"><button type="button" class="btn btn-light border shadow-none" ${current<=1?'disabled':''} data-pw-page="${current-1}"><i class="mdi mdi-chevron-left"></i></button><span class="align-self-center px-1">Page ${current} / ${last}</span><button type="button" class="btn btn-light border shadow-none" ${current>=last?'disabled':''} data-pw-page="${current+1}"><i class="mdi mdi-chevron-right"></i></button></div></div>`);
    }

    function currentDataParams(){
        return {
            page:state.page,
            per_page:state.perPage,
            search:state.search,
            entry_type:state.type,
            view:state.tab==='shared'?'shared':state.tab==='company'?'company':'mine'
        };
    }

    function loadData(page=1,options){
        const opts=options||{};
        const requestToken=++state.requestToken;
        state.loading=true;
        state.page =page;
        state.perPage =$('#perpage').val();
        if(opts.skeleton!==false){
            $workspace.html(renderSkeleton(6));
        }
        return ajax('GET',R.data+'?'+query(currentDataParams())).done(function(response){
            if(requestToken!==state.requestToken) return;
            const data=response?.data||{};
            const pager=data.rows||{};
            const rows=Array.isArray(pager.data)?pager.data:[];
            state.loading=false;
            $workspace.html(renderRows(rows));
            updatePagination(pager.current_page, pager.last_page, pager.total, pager.per_page);
            // renderPagination(pager);
            $('#pwStatTotal').text(Number(pager.total||0));
            $('#pwStatOverdue').text(Number(data.rotation_overdue||0));
            $('#pwRotationHero').html(`<i class="mdi mdi-autorenew"></i> ${Number(data.rotation_overdue||0)} overdue rotation${Number(data.rotation_overdue||0)===1?'':'s'}`);
            $('#pwHeroSubtitle').text(`${Number(data?.summary?.total ?? pager.total ?? 0)} credentials`);
            const counts=data.tab_counts||{};
            $('#pwMyCount').text(Number(counts.mine||0));
            $('#pwSharedCount').text(Number(counts.shared||0));
            $('#pwCompanyCount').text(Number(counts.company||0));
        }).fail(function(error){
            if(requestToken!==state.requestToken) return;
            state.loading=false;
            $workspace.html(`<tr><td colspan="7"><div class="pw-error"><i class="mdi mdi-cloud-alert-outline"></i><div class="fw-bold mb-1 text-dark">PassWallet could not be loaded</div><div class="small mb-3">${esc(errMsg(error,'Server request failed.'))}</div><button type="button" class="btn btn-primary btn-sm" data-pw-action="refresh"><i class="mdi mdi-refresh me-1"></i>Retry</button></div></td></tr>`);
            $('#pagination-container').empty();
            // $('#pwPagination').empty();
        });
    }

    function updateTabCount(mode,value){
        if(value===null) return;
        if(mode==='mine') $('#pwMyCount').text(value);
    }

    function renderStatsFromTabs(){
        // Tab counts are intentionally loaded on demand so the current audience query
        // remains the authoritative source for visible rows.
    }

    function audienceModeMeta(mode){
        return {
            private:{icon:'mdi-lock-outline',label:'Private',hint:'Only you can access this credential. Switch to another scope to share it.'},
            company:{icon:'mdi-office-building-outline',label:'Company',hint:'Everyone matching the selected companies will have access.'},
            entity:{icon:'mdi-domain',label:'Entity',hint:'Everyone belonging to the selected entities will have access.'},
            role:{icon:'mdi-account-badge-outline',label:'Role',hint:'Users with the selected roles inside the selected entities will have access.'},
            staff:{icon:'mdi-account-multiple-outline',label:'Staff',hint:'Only the selected staff members will have access.'}
        }[mode] || {};
    }

    function audiencePrefix(scope){ return scope==='share' ? 'pwShare' : 'pw'; }

    function audienceSelectId(scope,type){
        const prefix=audiencePrefix(scope);
        if(type==='entity' && state.audience[scope].mode==='role') return '#'+prefix+'AudienceRoleEntity';
        if(type==='entity' && state.audience[scope].mode==='staff') return '#'+prefix+'AudienceStaffEntity';
        return '#'+prefix+'Audience'+type.charAt(0).toUpperCase()+type.slice(1);
    }

    function selectedAudienceValues(scope,type){
        const el=document.querySelector(audienceSelectId(scope,type));
        if(!el) return [];
        return Array.from(el.selectedOptions||[]).map(option=>String(option.value));
    }

    function audienceFieldPanelSelector(scope,mode){
        return scope==='share' ? `[data-pw-share-audience-panel="${mode}"]` : `[data-pw-audience-panel="${mode}"]`;
    }

    function audienceModeButtonSelector(scope){
        return scope==='share' ? '#pwShareAudienceModes [data-pw-share-audience-mode]' : '#pwAudienceModes [data-pw-audience-mode]';
    }

    function audienceHintSelector(scope){ return scope==='share' ? '#pwShareAudienceHint' : '#pwAudienceHint'; }
    function audienceSummarySelector(scope){ return scope==='share' ? '#pwShareAudienceSummary' : '#pwAudienceSummary'; }

    function setAudienceNativeOptions(select,options,selectedValues){
        if(!select) return;

        const wanted=new Set((selectedValues||[]).map(String));
        select.innerHTML='';
        (options||[]).forEach(function(item){
            const option=document.createElement('option');
            option.value=String(item.value);
            option.textContent=String(item.label||'');
            option.selected=wanted.has(option.value);
            select.appendChild(option);
        });

        // Refresh an enhanced select without firing the dependent AJAX handler.
        if($(select).hasClass('select2-hidden-accessible')){
            $(select).trigger('change.select2');
        }
    }

    function enforceAudienceAllOption(scope,type){
        const el=document.querySelector(audienceSelectId(scope,type));
        if(!el || !el.multiple) return [];
        let values=Array.from(el.selectedOptions).map(o=>String(o.value));
        if(values.includes('all') && values.length>1){
            const allOption=Array.from(el.options).find(o=>String(o.value)==='all');
            const nonAllSelected=Array.from(el.selectedOptions).filter(o=>String(o.value)!=='all');
            const lastSelected=nonAllSelected[nonAllSelected.length-1];
            const keepAll=allOption && (!lastSelected || lastSelected===allOption);
            Array.from(el.options).forEach(o=>o.selected=keepAll?String(o.value)==='all':String(o.value)!=='all');
            $(el).trigger('change.select2');
            values=Array.from(el.selectedOptions).map(o=>String(o.value));
        }
        return values;
    }

    function audienceText(scope,type,value){
        const el=document.querySelector(audienceSelectId(scope,type));
        const option=el ? Array.from(el.options).find(o=>String(o.value)===String(value)) : null;
        return option?.textContent||String(value);
    }

    function renderAudienceSummary(scope,mode){
        const meta=audienceModeMeta(mode);
        let parts=[];

        if(mode==='private'){
            parts=['Only you'];
        }else if(mode==='company'){
            const values=enforceAudienceAllOption(scope,'company');
            parts=values.includes('all')?['All companies']:values.map(v=>audienceText(scope,'company',v));
            if(!parts.length) parts=['Choose at least one company.'];
        }else if(mode==='entity'){
            const values=enforceAudienceAllOption(scope,'entity');
            parts=values.includes('all')?['All entities']:values.map(v=>audienceText(scope,'entity',v));
            if(!parts.length) parts=['Choose at least one entity.'];
        }else if(mode==='role'){
            const entities=enforceAudienceAllOption(scope,'entity');
            const roles=enforceAudienceAllOption(scope,'role');
            parts=[
                entities.includes('all')?'All entities':(entities.length?entities.map(v=>audienceText(scope,'entity',v)).slice(0,3).join(', '):'Choose entities'),
                roles.includes('all')?'All roles':(roles.length?roles.map(v=>audienceText(scope,'role',v)).slice(0,3).join(', '):'Choose roles')
            ];
        }else{
            const entities=enforceAudienceAllOption(scope,'entity');
            const staff=selectedAudienceValues(scope,'staff');
            parts=[
                entities.includes('all')?'All entities':(entities.length?entities.map(v=>audienceText(scope,'entity',v)).slice(0,3).join(', '):'Choose entities'),
                staff.length?staff.map(v=>audienceText(scope,'staff',v)).slice(0,3).join(', '):'Choose staff'
            ];
        }

        const chips=parts.filter(Boolean).map(function(part){
            return `<span class="pw-audience-chip"><i class="mdi ${esc(meta.icon)}"></i>${esc(part)}</span>`;
        }).join('');

        $(audienceSummarySelector(scope)).html(
            `<div class="pw-audience-summary-label">Selected</div>${chips}`
        );
    }

    function clearAudienceSelections(scope){
        ['company','entity','role','staff'].forEach(function(type){
            const el=document.querySelector(audienceSelectId(scope,type));
            if(el) Array.from(el.options).forEach(option=>option.selected=false);
            if(el && $(el).hasClass('select2-hidden-accessible')) $(el).trigger('change.select2');
        });
        const roleEntity=document.querySelector('#'+audiencePrefix(scope)+'AudienceRoleEntity');
        const staffEntity=document.querySelector('#'+audiencePrefix(scope)+'AudienceStaffEntity');
        [roleEntity,staffEntity].forEach(function(el){
            if(el) Array.from(el.options).forEach(option=>option.selected=false);
            if(el && $(el).hasClass('select2-hidden-accessible')) $(el).trigger('change.select2');
        });
    }

    function setAudienceMode(scope,mode,options){
        const opts=options||{};
        const allowed=['private','company','entity','role','staff'];
        mode=allowed.includes(String(mode))?String(mode):'private';

        state.audience[scope].mode=mode;

        $(audienceModeButtonSelector(scope)).removeClass('active text-danger');
        const button=scope==='share'
            ? `[data-pw-share-audience-mode="${mode}"]`
            : `[data-pw-audience-mode="${mode}"]`;
        $(button).addClass('active');

        const fieldsRoot=scope==='share' ? '#pwShareAudienceFields' : '#pwAudienceFields';
        $(fieldsRoot).find('[data-pw-audience-panel],[data-pw-share-audience-panel]').addClass('d-none');

        if(mode!=='private'){
            $(audienceFieldPanelSelector(scope,mode)).removeClass('d-none');
        }

        const meta=audienceModeMeta(mode);
        $(audienceHintSelector(scope)).text(meta.hint||'');

        if(scope==='post'){
            $('#pwAudienceModeChip').html(`<i class="mdi ${esc(meta.icon)}"></i> ${esc(meta.label)}`);
        }

        clearAudienceSelections(scope);
        renderAudienceSummary(scope,mode);

        if(mode==='private' || opts.skipLoad){
            return $.Deferred().resolve().promise();
        }

        return loadAudienceOptions(scope,mode,[]);
    }

    function setAudienceLoading(selectId,busy,label){
        const el=document.querySelector(selectId);
        if(!el) return;

        if(busy){
            el.disabled=true;
            el.innerHTML=`<option value="">${esc(label||'Loading…')}</option>`;
            el.selectedIndex=0;
            if($(el).hasClass('select2-hidden-accessible')) $(el).trigger('change.select2');
        }else{
            el.disabled=false;
            if($(el).hasClass('select2-hidden-accessible')) $(el).trigger('change.select2');
        }
    }

    function loadAudienceOptions(scope,mode,dependencyEntityIds,restore){
        const prefix=audiencePrefix(scope);
        mode=String(mode||state.audience[scope].mode||'private');

        if(mode==='private'){
            clearAudienceSelections(scope);
            renderAudienceSummary(scope,mode);
            return $.Deferred().resolve().promise();
        }

        const entityIds=(dependencyEntityIds||[]).map(v=>String(v));
        const payload={mode:mode};
        if(entityIds.length) payload.entity_ids=entityIds;

        const requestNo=(state.audience[scope]._requestNo||0)+1;
        state.audience[scope]._requestNo=requestNo;

        const previous={
            company:selectedAudienceValues(scope,'company'),
            entity:selectedAudienceValues(scope,'entity'),
            role:selectedAudienceValues(scope,'role'),
            staff:selectedAudienceValues(scope,'staff')
        };

        // Show a deterministic loading state in dependent dropdowns so users
        // never interact with stale Role/Staff options while AJAX is pending.
        if(mode==='role'){
            setAudienceLoading('#'+prefix+'AudienceRole',true,'Loading roles…');
        }else if(mode==='staff'){
            setAudienceLoading('#'+prefix+'AudienceStaff',true,'Loading staff…');
        }

        return ajax('GET',R.audienceOptions,payload).done(function(response){
            if(requestNo!==state.audience[scope]._requestNo) return;

            const data=response?.data||{};
            const generalLabel=data.general?.label||'Elysium Groups';
            const entities=data.entities||data;
            const entityRows=Array.isArray(entities.items)?entities.items:[];

            const entityOptions=[
                {value:'all',label:'All entities'},
                {value:0,label:generalLabel}
            ].concat(entityRows.map(function(row){
                return {
                    value:row.sno,
                    label:(row.entity_name||'')+(row.company_name?' · '+row.company_name:'')
                };
            }));

            const currentDependency=(
                mode==='role'
                    ? selectedAudienceValues(scope,'entity')
                    : mode==='staff'
                        ? selectedAudienceValues(scope,'entity')
                        : []
            ).map(String);

            // A newer user selection must never be overwritten by an older
            // response that happened to finish later.
            if((mode==='role'||mode==='staff') && entityIds.length){
                const requested=entityIds.slice().sort().join('|');
                const current=currentDependency.slice().sort().join('|');
                if(requested!==current && requestNo===state.audience[scope]._requestNo){
                    return;
                }
            }

            if(mode==='company'){
                const rows=Array.isArray(data.items)?data.items:[];
                const options=[
                    {value:'all',label:'All companies'},
                    {value:0,label:generalLabel}
                ].concat(rows.map(function(row){
                    return {
                        value:row.sno,
                        label:row.company_name||row.company_short_name||''
                    };
                }));
                setAudienceNativeOptions(
                    document.querySelector('#'+prefix+'AudienceCompany'),
                    options,
                    restore?.company||previous.company
                );
            }else if(mode==='entity'){
                setAudienceNativeOptions(
                    document.querySelector('#'+prefix+'AudienceEntity'),
                    entityOptions,
                    restore?.entity||previous.entity
                );
            }else if(mode==='role'){
                setAudienceNativeOptions(
                    document.querySelector('#'+prefix+'AudienceRoleEntity'),
                    entityOptions,
                    entityIds.length?entityIds:(restore?.entity||previous.entity)
                );
                const roles=Array.isArray(data.items)?data.items:[];
                const roleOptions=[{value:'all',label:'All roles'}].concat(
                    roles.map(function(row){
                        return {
                            value:row.sno,
                            label:(row.role_name||'')+(row.entity_name?' - '+row.entity_name:' - Elysium Groups')
                        };
                    })
                );
                setAudienceNativeOptions(
                    document.querySelector('#'+prefix+'AudienceRole'),
                    roleOptions,
                    restore?.role||[]
                );
                setAudienceLoading('#'+prefix+'AudienceRole',false);
            }else if(mode==='staff'){
                setAudienceNativeOptions(
                    document.querySelector('#'+prefix+'AudienceStaffEntity'),
                    entityOptions,
                    entityIds.length?entityIds:(restore?.entity||previous.entity)
                );
                const staff=Array.isArray(data.items)?data.items:[];
                const staffOptions=staff.map(function(row){
                    return {
                        value:row.sno,
                        label:(row.staff_name||'')+
                              (row.staff_id?' · '+row.staff_id:'')+
                              (row.entity_name?' - '+row.entity_name:' - Elysium Groups')
                    };
                });
                setAudienceNativeOptions(
                    document.querySelector('#'+prefix+'AudienceStaff'),
                    staffOptions,
                    restore?.staff||[]
                );
                setAudienceLoading('#'+prefix+'AudienceStaff',false);
            }

            renderAudienceSummary(scope,mode);
        }).fail(function(error){
            if(requestNo!==state.audience[scope]._requestNo) return;
            setAudienceLoading('#'+prefix+'AudienceRole',false);
            setAudienceLoading('#'+prefix+'AudienceStaff',false);
            notify(errMsg(error,'Unable to load audience options.'),'error');
        });
    }

    function getAudienceEntityIds(selectId){
        const el=document.getElementById(selectId);
        if(!el) return [];
        return Array.from(el.selectedOptions||[]).map(option=>String(option.value));
    }

    function clearAudienceDependentSelect(selectId){
        const el=document.getElementById(selectId);
        if(!el) return;

        Array.from(el.options||[]).forEach(function(option){
            option.selected=false;
        });

        if($(el).hasClass('select2-hidden-accessible')){
            $(el).trigger('change.select2');
        }
    }

    // Explicit handlers mirror Knowledge Panel so the dependent Entity -> Role/Staff
    // relationship remains deterministic even when the selects are enhanced.
    function postRoleEntityChangeFunction(){
        const entityIds=getAudienceEntityIds('pwAudienceRoleEntity')
            .map(String)
            .filter(function(v){ return v!==''; });

        enforceAudienceAllOption('post','entity');
        const normalizedEntityIds=getAudienceEntityIds('pwAudienceRoleEntity')
            .map(String)
            .filter(function(v){ return v!==''; });

        clearAudienceDependentSelect('pwAudienceRole');
        setAudienceLoading('#pwAudienceRole',true,'Loading roles…');
        renderAudienceSummary('post','role');

        if(!normalizedEntityIds.length){
            setAudienceNativeOptions(
                document.querySelector('#pwAudienceRole'),
                [{value:'all',label:'Select role after choosing an entity'}],
                []
            );
            setAudienceLoading('#pwAudienceRole',false);
            renderAudienceSummary('post','role');
            return $.Deferred().resolve().promise();
        }

        return loadAudienceOptions('post','role',normalizedEntityIds);
    }

    function postStaffEntityChangeFunction(){
        const entityIds=getAudienceEntityIds('pwAudienceStaffEntity')
            .map(String)
            .filter(function(v){ return v!==''; });

        enforceAudienceAllOption('post','entity');
        const normalizedEntityIds=getAudienceEntityIds('pwAudienceStaffEntity')
            .map(String)
            .filter(function(v){ return v!==''; });

        clearAudienceDependentSelect('pwAudienceStaff');
        setAudienceLoading('#pwAudienceStaff',true,'Loading staff…');
        renderAudienceSummary('post','staff');

        if(!normalizedEntityIds.length){
            setAudienceNativeOptions(
                document.querySelector('#pwAudienceStaff'),
                [{value:'',label:'Select staff after choosing an entity'}],
                []
            );
            setAudienceLoading('#pwAudienceStaff',false);
            renderAudienceSummary('post','staff');
            return $.Deferred().resolve().promise();
        }

        return loadAudienceOptions('post','staff',normalizedEntityIds);
    }

    function collectAudiencePayload(scope){
        const mode=state.audience[scope].mode;
        const payload={audience_mode:mode};

        if(mode==='private'){
            return payload;
        }

        if(mode==='company'){
            payload.audience_company_ids=enforceAudienceAllOption(scope,'company');
        }

        if(mode==='entity'){
            payload.audience_entity_ids=enforceAudienceAllOption(scope,'entity');
        }

        if(mode==='role'){
            payload.audience_entity_ids=enforceAudienceAllOption(scope,'entity');
            payload.audience_role_ids=enforceAudienceAllOption(scope,'role');
        }

        if(mode==='staff'){
            payload.audience_entity_ids=enforceAudienceAllOption(scope,'entity');
            payload.audience_staff_ids=selectedAudienceValues(scope,'staff');
        }

        return payload;
    }

    function appendAudienceToFormData(formData,scope){
        const payload=collectAudiencePayload(scope);
        Object.keys(payload).forEach(function(key){
            formData.delete(key);formData.delete(key+'[]');
            const value=payload[key];
            if(Array.isArray(value)) value.forEach(v=>formData.append(key+'[]',v));
            else formData.set(key,value);
        });
        return payload;
    }

    function bindAudienceEvents(scope){
        const prefix=audiencePrefix(scope);

        const selectors=[
            `#${prefix}AudienceCompany`,
            `#${prefix}AudienceEntity`,
            `#${prefix}AudienceRole`,
            `#${prefix}AudienceStaff`
        ];

        selectors.forEach(function(selector){
            const el=document.querySelector(selector);
            if(!el) return;

            if(el.__pwAudienceChangeHandler){
                el.removeEventListener('change',el.__pwAudienceChangeHandler);
            }

            const handler=function(){
                const mode=state.audience[scope].mode;
                const id=this.id;

                if(id===prefix+'AudienceCompany'){
                    enforceAudienceAllOption(scope,'company');
                }else if(id===prefix+'AudienceEntity' && mode==='entity'){
                    enforceAudienceAllOption(scope,'entity');
                }else if(id===prefix+'AudienceRole'){
                    enforceAudienceAllOption(scope,'role');
                }else if(id===prefix+'AudienceStaff'){
                    // Staff selections are direct values; no dependent request.
                }

                renderAudienceSummary(scope,mode);
            };

            el.__pwAudienceChangeHandler=handler;
            el.addEventListener('change',handler);
        });

        const modeRoot=document.querySelector(
            scope==='share'
                ? '#pwShareAudienceModes'
                : '#pwAudienceModes'
        );

        if(modeRoot){
            if(modeRoot.__pwAudienceClickHandler){
                modeRoot.removeEventListener('click',modeRoot.__pwAudienceClickHandler);
            }

            const clickHandler=function(event){
                const button=event.target.closest(
                    scope==='share'
                        ? '[data-pw-share-audience-mode]'
                        : '[data-pw-audience-mode]'
                );
                if(!button || !modeRoot.contains(button)) return;

                event.preventDefault();

                const mode=scope==='share'
                    ? button.dataset.pwShareAudienceMode
                    : button.dataset.pwAudienceMode;

                setAudienceMode(scope,String(mode||'private'));
            };

            modeRoot.__pwAudienceClickHandler=clickHandler;
            modeRoot.addEventListener('click',clickHandler);
        }
    }

    function resetEntryForm(){
        const form=document.getElementById('pwEntryForm');
        if(form) form.reset();
        $('#pwEntryId').val('');
        $('#pwEntryPassword').attr('type','password').val('');
        $('#pwEditPasswordHint').text('');
        $('#pwEntryModalTitle').text('New vault entry');
        $('#pwEntryModalSubtitle').text('Store the credential encrypted and keep the default masked until step-up verification.');
        $('#pwEntrySubmit span').text('Save entry');
        $('#pwPasswordStrength').text('').attr('class','pw-password-strength');
        state.editMode=false;
        setAudienceMode('post','private',{skipLoad:false});
    }

    function openNewEntry(){
        resetEntryForm();
        $('#pwEntryType').val(state.types[0]?.value||'Website').trigger('change');
        $('#pwEntryRotation').val('90');
        modal('pwEntryModal')?.show();
    }

    function setEntryAudienceFromCurrent(audience){
        const mode=String(audience?.audience_mode||'private').toLowerCase();

        state.audience.post.mode=mode;
        renderAudienceFieldsOnly('post',mode);

        if(mode==='private'){
            clearAudienceSelections('post');
            $('#pwAudienceModeChip').html('<i class="mdi mdi-lock-outline"></i> Private');
            $('#pwAudienceHint').text('Only you can access this credential. Switch to another scope to share it.');
            renderAudienceSummary('post','private');
            return;
        }

        const restore={
            company:(audience?.company_ids||[]).map(String),
            entity:(audience?.entity_ids||[]).map(String),
            role:(audience?.role_ids||[]).map(String),
            staff:(audience?.staff_ids||[]).map(String)
        };

        setTimeout(function(){
            loadAudienceOptions('post',mode,[],restore);
        },20);
    }

    function renderAudienceFieldsOnly(scope,mode){
        const prefix=audiencePrefix(scope);
        $(audienceModeButtonSelector(scope)).removeClass('active text-danger');
        const selector=scope==='share' ? `[data-pw-share-audience-mode="${mode}"]` : `[data-pw-audience-mode="${mode}"]`;
        $(selector).addClass('active text-danger');
        $(`${scope==='share'?'#pwShareAudienceFields':'#pwAudienceFields'} [data-pw-${scope==='share'?'share-':''}audience-panel]`).addClass('d-none');
        $(audienceFieldPanelSelector(scope,mode)).removeClass('d-none');
        const meta=audienceModeMeta(mode);
        $(audienceHintSelector(scope)).text(meta.hint||'');
        if(scope==='post') $('#pwAudienceModeChip').html(`<i class="mdi ${esc(meta.icon)}"></i> ${esc(meta.label)}`);
    }

    function openEditEntry(entry){
        state.editMode=true;
        $('#pwEntryModalTitle').text('Edit vault entry');
        $('#pwEntryModalSubtitle').text('Sensitive changes require step-up verification and the previous secret is retained in credential history.');
        $('#pwEntrySubmit span').text('Update entry');
        $('#pwEditPasswordHint').text('Leave password blank to keep the current secret.');
        $('#pwEntryId').val(entry.sno);
        $('#pwEntryName').val(entry.entry_name||'');
        $('#pwEntryUrl').val(entry.url||'');
        $('#pwEntryUsername').val(entry.username||'');
        $('#pwEntryEmail').val(entry.email||'');
        $('#pwEntryMobile').val(entry.mobile||'');
        $('#pwEntryNotes').val('');
        // $('#pwEntryIconUrl').val(entry.icon_url||'');
        $('#pwEntryPassword').val('').attr('type','password').prop('required',false);
        $('#pwEntryType').val(entry.entry_type||'Website').trigger('change');
        $('#pwEntryRotation').val(String(entry.rotation_days||90));
        state.editMode=true;
        setEntryAudienceFromCurrent(entry.audience||{});
        modal('pwEntryModal')?.show();
    }

    function openEntry(id){
        state.currentDetailTab='details';
        $('.pw-detail-tab').removeClass('active');
        $('.pw-detail-tab[data-pw-detail-tab="details"]').addClass('active');
        $('#pwDetailContent').html(`<div class="pw-empty"><div class="spinner-border spinner-border-sm text-danger"></div><div class="small mt-2">Loading secure record…</div></div>`);
        const panel=offcanvas('pwDetailOffcanvas');
        panel?.show();
        ajax('GET',routeUrl(R.show,id)).done(function(response){
            state.currentEntry=response?.data||null;
            renderDetailDetails(state.currentEntry);
        }).fail(function(error){
            $('#pwDetailContent').html(`<div class="pw-error"><i class="mdi mdi-alert-circle-outline"></i><div class="fw-bold mb-1 text-dark">Unable to open entry</div><div class="small">${esc(errMsg(error))}</div></div>`);
        });
    }

    function renderDetailDetails(entry){
        if(!entry) return;
        const rotation=rotationState(entry);
        const scope=entry.scope_label||entry.visibility||'Private';
        $('#pwDetailTitle').text(entry.entry_name||'Credential');
        $('#pwDetailSubtitle').text(`${typeLabel(entry.entry_type)} · ${entry.company_name||'Elysium Groups'} · ${scope}`);
        $('#pwDetailIcon').html(`<i class="mdi ${esc(typeIcon(entry.entry_type))}"></i>`);
        $('#pwDetailContent').html(`
            <div class="pw-detail-password">
                <div class="pw-detail-password-label">PASSWORD</div>
                <div class="pw-detail-password-row">
                    <div class="pw-detail-password-value" id="pwDetailPasswordValue">••••••••••••</div>
                    <button type="button" class="pw-inline-btn" data-pw-action="detail-reveal"><i class="mdi mdi-eye-outline"></i></button>
                    <button type="button" class="pw-inline-btn" data-pw-action="detail-copy"><i class="mdi mdi-content-copy"></i></button>
                </div>
                <div class="pw-detail-password-meter"><span></span></div>
                <div class="small text-success fw-bold mt-1">Rotation · ${esc(rotation.label)}</div>
            </div>
            <div class="pw-detail-grid">
                <div class="label">Link / app</div><div class="value">${entry.url?`<a href="${esc(entry.url)}" target="_blank" rel="noopener noreferrer">${esc(entry.url)}</a>`:'—'}</div>
                <div class="label">Username</div><div class="value">${esc(entry.username||'—')} ${entry.username?`<button class="pw-username-copy" data-pw-action="detail-copy-username"><i class="mdi mdi-content-copy"></i></button>`:''}</div>
                <div class="label">Recovery email</div><div class="value">${esc(entry.email||'—')}</div>
                <div class="label">Recovery mobile</div><div class="value">${esc(entry.mobile||'—')}</div>
                <div class="label">Scope</div><div class="value">${esc(scope)}</div>
                <div class="label">Last rotated</div><div class="value">${esc(formatDateTime(entry.last_rotated_at))}</div>
                <div class="label">Next rotation</div><div class="value">${esc(formatDateTime(entry.next_rotation_at))}</div>
                ${entry.notes_available?`<div class="label">Notes</div><div class="value text-muted">Encrypted notes available. Use step-up to manage the credential record.</div>`:''}
            </div>
            <div class="pw-detail-actions">
                ${entry.can_manage ? '<button type="button" class="btn btn-primary" data-pw-action="detail-change"><i class="mdi mdi-key-change me-1"></i> Change password (guided)</button>' : ''}
                ${entry.can_manage ? '<button type="button" class="btn btn-light border shadow-none" data-pw-action="detail-share"><i class="mdi mdi-share-variant-outline me-1"></i> Sharing</button>' : ''}
                ${entry.can_manage ? '<button type="button" class="btn btn-light border shadow-none text-danger" data-pw-action="detail-delete"><i class="mdi mdi-delete-outline me-1"></i> Delete</button>' : ''}
            </div>
        `);
    }

    function renderDetailTabLoading(){
        $('#pwDetailContent').html(`<div class="pw-empty"><div class="spinner-border spinner-border-sm text-danger"></div><div class="small mt-2">Loading…</div></div>`);
    }

    function loadDetailTab(tab){
        const entry=state.currentEntry;
        if(!entry) return;
        state.currentDetailTab=tab;
        $('.pw-detail-tab').removeClass('active');
        $(`.pw-detail-tab[data-pw-detail-tab="${tab}"]`).addClass('active');
        if(tab==='details') return renderDetailDetails(entry);
        renderDetailTabLoading();
        if(tab==='history'){
            ajax('GET',routeUrl(R.history,entry.sno)).done(function(response){
                const rows=Array.isArray(response?.data)?response.data:[];
                $('#pwDetailContent').html(rows.length?`<div class="pw-detail-list">${rows.map(function(row){return `<div class="pw-detail-list-row"><strong>Password changed</strong><small>${esc(row.changed_by_name||'ERP User')} · ${esc(formatDateTime(row.changed_at))}</small></div>`;}).join('')}</div>`:'<div class="pw-empty py-4"><i class="mdi mdi-history"></i><div class="small">No password history available.</div></div>');
            }).fail(error=>$('#pwDetailContent').html(`<div class="pw-error"><i class="mdi mdi-alert-circle-outline"></i><div class="small">${esc(errMsg(error))}</div></div>`));
        }
        if(tab==='audit'){
            ajax('GET',routeUrl(R.audit,entry.sno)).done(function(response){
                const rows=Array.isArray(response?.data)?response.data:[];
                $('#pwDetailContent').html(rows.length?`<div class="pw-detail-list">${rows.map(function(row){return `<div class="pw-detail-list-row"><strong>${esc(row.action||'action')}</strong><small>${esc(row.actor_name||'ERP User')} · ${esc(formatDateTime(row.created_at))} · ${row.is_high_sensitivity?'<span class="text-danger fw-bold">Sensitive</span>':''}</small></div>`;}).join('')}</div>`:'<div class="pw-empty py-4"><i class="mdi mdi-shield-search-outline"></i><div class="small">No audit entries yet.</div></div>');
            }).fail(error=>$('#pwDetailContent').html(`<div class="pw-error"><i class="mdi mdi-alert-circle-outline"></i><div class="small">${esc(errMsg(error))}</div></div>`));
        }
        if(tab==='sharing') loadShares(entry.sno);
    }

    function loadShares(id){
        ajax('GET',routeUrl(R.shares,id)).done(function(response){
            const rows=Array.isArray(response?.data)?response.data:[];
            let html='<div class="pw-share-current"><div class="pw-share-current-label">Current entry audience</div><strong>'+esc(state.currentEntry?.scope_label||state.currentEntry?.visibility||'Private')+'</strong></div>';

            if(rows.length){
                html+='<div class="pw-detail-list">';
                rows.forEach(function(row){
                    const audience=row.audience||{};
                    const details=Array.isArray(audience.details)?audience.details:[];
                    const label=String(row.audience_mode||'legacy');
                    const revoke=row.sno?'<button type="button" class="btn btn-sm btn-light border" data-pw-action="revoke-share" data-id="'+esc(row.sno)+'"><i class="mdi mdi-link-off"></i></button>':'';
                    const detailText=details.length?details.slice(0,5).join(' · '):'Audience grant';
                    const expiry=row.expires_at?formatDateTime(row.expires_at):'No expiry';
                    html+='<div class="pw-detail-list-row"><div class="d-flex align-items-center justify-content-between gap-2"><strong>'+esc(label.charAt(0).toUpperCase()+label.slice(1))+' · '+esc(row.permission||'View')+'</strong>'+revoke+'</div><small>'+esc(detailText)+' · '+esc(expiry)+'</small></div>';
                });
                html+='</div>';
            }else{
                html+='<div class="pw-empty py-3"><i class="mdi mdi-share-off-outline"></i><div class="small">No additional sharing grants.</div></div>';
            }

            if(state.currentEntry?.can_manage){
                html+='<button type="button" class="btn btn-primary w-100 mt-2" data-pw-action="detail-share"><i class="mdi mdi-share-variant-outline me-1"></i> Add audience share</button>';
            }
            $('#pwDetailContent').html(html);
        }).fail(error=>$('#pwDetailContent').html('<div class="pw-error"><i class="mdi mdi-alert-circle-outline"></i><div class="small">'+esc(errMsg(error))+'</div></div>'));
    }

    function requestStepUp(callback){
        if(state.stepUpBusy){
            return $.Deferred().reject({message:'A secure verification request is already in progress.'}).promise();
        }
        const deferred=$.Deferred();
        state.stepUpPending=callback;
        state.stepUpDeferred=deferred;
        $('#pwStepUpPassword').val('');
        modal('pwStepUpModal')?.show();
        return deferred.promise();
    }

    function revealEntrySecret(id,callback){
        requestStepUp(function(){
            return ajax('POST',routeUrl(R.reveal,id),{}).done(function(response){
                const secret=String(response?.data?.password||'');
                if(!secret){notify('Password is not available.','error');return;}
                callback(secret);
            });
        });
    }

    function copyToClipboard(text){
        if(!navigator.clipboard) return $.Deferred().reject({message:'Clipboard access is unavailable in this browser.'}).promise();
        return navigator.clipboard.writeText(text);
    }

    function copyPassword(id){
        revealEntrySecret(id,function(secret){
            copyToClipboard(secret).done(function(){
                ajax('POST',routeUrl(R.copyAudit,id),{});
                notify('Password copied. Clipboard access has been audited.');
                setTimeout(function(){ try{ navigator.clipboard.writeText(''); }catch(e){} },30000);
            }).fail(function(){notify('Unable to copy to clipboard.','error');});
        });
    }

    function showPassword(id,target){
        revealEntrySecret(id,function(secret){
            if(target) $(target).text(secret);
            else notify('Credential revealed for this secure action.');
            setTimeout(function(){if(target) $(target).text('••••••••••••');},15000);
        });
    }

    function copyUsername(id){
        ajax('GET',routeUrl(R.show,id)).done(function(response){
            const username=response?.data?.username||response?.data?.email||'';
            if(!username){notify('No username is available.','warning');return;}
            copyToClipboard(username).done(function(){notify('Username copied.');});
        }).fail(error=>notify(errMsg(error),'error'));
    }

    function generatePassword(targetSelector){
        return ajax('POST',R.generator,{length:20,upper:1,lower:1,numbers:1,symbols:1}).done(function(response){
            const password=String(response?.data?.password||'');
            $(targetSelector||'#pwEntryPassword').val(password);
            if(targetSelector==='#pwEntryPassword') renderPasswordStrength();
        });
    }

    function submitEntryForm(){
        const form=document.getElementById('pwEntryForm');
        if(!form || !form.checkValidity()){
            form?.reportValidity();
            return;
        }

        const button=$('#pwEntrySubmit').prop('disabled',true);
        const formData=new FormData(form);
        if(state.editMode && !String($('#pwEntryPassword').val()||'')) formData.delete('password');
        appendAudienceToFormData(formData,'post');

        let endpoint=R.store;
        if(state.editMode){
            endpoint=routeUrl(R.update,$('#pwEntryId').val());
            formData.append('_method','PUT');
        }

        const save=function(){
            return ajax('POST',endpoint,formData);
        };

        const finish=function(response){
            modal('pwEntryModal')?.hide();
            notify(response?.message||'Vault entry saved.');
            loadData();
            const editedId=$('#pwEntryId').val();
            if(editedId && state.currentEntry?.sno && String(state.currentEntry.sno)===String(editedId)){
                openEntry(state.currentEntry.sno);
            }
        };

        if(state.editMode){
            requestStepUp(save)
                .done(finish)
                .fail(function(error){notify(errMsg(error,'Unable to save entry.'),'error');})
                .always(function(){button.prop('disabled',false);});
            return;
        }

        save()
            .done(finish)
            .fail(function(error){notify(errMsg(error,'Unable to save entry.'),'error');})
            .always(function(){button.prop('disabled',false);});
    }

    function openShare(entry){
        $('#pwShareEntryId').val(entry.sno);
        $('#pwSharePermission').val('View');
        $('#pwShareExpiryPreset').val('');
        $('#pwShareExpiresAt').val('');
        state.audience.share.mode='company';
        renderAudienceFieldsOnly('share','company');
        clearAudienceSelections('share');
        renderAudienceSummary('share','company');
        loadAudienceOptions('share','company',[]);
        $('#pwShareExisting').html('<div class="small text-muted">Loading current shares…</div>');
        ajax('GET',routeUrl(R.shares,entry.sno)).done(function(response){
            renderShareExisting(response?.data||[]);
        }).fail(function(error){notify(errMsg(error),'error');});
        modal('pwShareModal')?.show();
    }

    function renderShareExisting(rows){
        const list=Array.isArray(rows)?rows:[];
        if(!list.length){$('#pwShareExisting').html('');return;}
        $('#pwShareExisting').html(`<div class="small fw-bold text-dark mb-2">Existing audience shares</div><div class="pw-detail-list">${list.map(function(row){
            const details=Array.isArray(row.audience?.details)?row.audience.details:[];
            return `<div class="pw-detail-list-row"><div class="d-flex justify-content-between gap-2"><strong>${esc((row.audience_mode||'share').toUpperCase())} · ${esc(row.permission||'View')}</strong><button type="button" class="btn btn-sm btn-light border" data-pw-action="revoke-share" data-id="${esc(row.sno)}"><i class="mdi mdi-link-off"></i></button></div><small>${esc(details.length?details.join(' · '):'Audience grant')} · ${row.expires_at?esc(formatDateTime(row.expires_at)):'No expiry'}</small></div>`;
        }).join('')}</div>`);
    }

    function submitShare(){
        const id=$('#pwShareEntryId').val();
        if(!id) return;
        const button=$('#pwShareSubmit').prop('disabled',true);
        const payload=collectAudiencePayload('share');
        if(!payload.audience_mode){button.prop('disabled',false);return;}
        requestStepUp(function(){
            const formData=new FormData(document.getElementById('pwShareForm'));
            formData.set('permission',$('#pwSharePermission').val());
            if($('#pwShareExpiresAt').val()) formData.set('expires_at',$('#pwShareExpiresAt').val()); else formData.delete('expires_at');
            appendAudienceToFormData(formData,'share');
            return ajax('POST',routeUrl(R.shareStore,id),formData).done(function(response){
                notify(response?.message||'Credential share updated.');
                renderShareExisting([]);
                if(state.currentEntry?.sno===Number(id)) loadShares(id);
                modal('pwShareModal')?.hide();
            }).fail(function(error){notify(errMsg(error),'error');}).always(function(){button.prop('disabled',false);});
        });
    }

    function openChangePassword(entry){
        state.changeEntry=entry;
        $('#pwChangeTarget').attr('href',entry.url||'#').toggle(!!entry.url);
        $('#pwChangePasswordValue').val('');
        generatePassword('#pwChangePasswordValue');
        modal('pwChangePasswordModal')?.show();
    }

    function saveGuidedPassword(){
        const entry=state.changeEntry;
        const password=String($('#pwChangePasswordValue').val()||'');
        if(!entry || !password){notify('Generate a new password first.','warning');return;}
        requestStepUp(function(){
            const formData=new FormData();
            formData.set('_method','PUT');
            formData.set('entry_name',entry.entry_name||'');
            formData.set('entry_type',entry.entry_type||'Website');
            formData.set('url',entry.url||'');
            formData.set('username',entry.username||'');
            formData.set('email',entry.email||'');
            formData.set('mobile',entry.mobile||'');
            formData.set('icon_url',entry.icon_url||'');
            formData.set('rotation_days',entry.rotation_days||90);
            formData.set('password',password);
            const audience=entry.audience||{};
            formData.set('audience_mode',audience.audience_mode||'company');
            const mode=audience.audience_mode||'company';
            if(mode==='company') (audience.company_ids||[]).forEach(v=>formData.append('audience_company_ids[]',v));
            if(mode==='entity') (audience.entity_ids||[]).forEach(v=>formData.append('audience_entity_ids[]',v));
            if(mode==='role'){(audience.entity_ids||[]).forEach(v=>formData.append('audience_entity_ids[]',v));(audience.role_ids||[]).forEach(v=>formData.append('audience_role_ids[]',v));}
            if(mode==='staff'){(audience.entity_ids||[]).forEach(v=>formData.append('audience_entity_ids[]',v));(audience.staff_ids||[]).forEach(v=>formData.append('audience_staff_ids[]',v));}
            return ajax('POST',routeUrl(R.update,entry.sno),formData).done(function(response){
                notify(response?.message||'Password changed securely.');
                modal('pwChangePasswordModal')?.hide();
                loadData();
                openEntry(entry.sno);
            }).fail(error=>notify(errMsg(error),'error'));
        });
    }

    function lockNow(){
        // Session step-up remains the protected action; the UI simply closes sensitive
        // views and clears transient values. The existing backend lockdown endpoint is
        // retained for Super Admin user lockdown and is intentionally not called here.
        $('#pwStepUpPassword').val('');
        state.currentEntry=null;
        offcanvas('pwDetailOffcanvas')?.hide();
        notify('Sensitive PassWallet view closed.');
    }

    function revokeShare(grantId){
        confirmAction('Revoke share','The selected audience grant will no longer have access to this credential.','Revoke',function(){
            return requestStepUp(function(){
                return ajax('DELETE',routeUrl(R.shareRevoke,grantId)).done(function(response){
                    notify(response?.message||'Share revoked.');
                    if(state.currentEntry) loadShares(state.currentEntry.sno);
                });
            });
        });
    }

    $('#pwSearch').on('input.pw',function(){
        state.search=String(this.value||'').trim();clearTimeout(state.searchTimer);state.searchTimer=setTimeout(function(){state.page=1;loadData();},320);
    });

    function typeFilterChangeFunc(){
        state.type=$('#pwTypeFilter').val();
        state.page=1;
        loadData();                                         
    }

    $('#pwEntryPassword').on('input.pw',renderPasswordStrength);

    $('#pwEntryForm').on('submit.pw',function(event){event.preventDefault();submitEntryForm();});
    $('#pwStepUpForm').on('submit.pw',function(event){
        event.preventDefault();
        if(state.stepUpBusy) return;
        state.stepUpBusy=true;
        const button=$('#pwStepUpSubmit').prop('disabled',true);
        ajax('POST',R.stepup,{stepup_password:$('#pwStepUpPassword').val()})
            .done(function(response){
                const next=state.stepUpPending;
                const deferred=state.stepUpDeferred;
                state.stepUpPending=null;
                state.stepUpDeferred=null;
                modal('pwStepUpModal')?.hide();
                $('#pwStatStepUp').text('Verified');
                $('#pwStepUpPassword').val('');

                if(typeof next==='function'){
                    let request=null;
                    try{request=next();}
                    catch(error){
                        deferred?.reject({message:error?.message||'Secure action failed.'});
                    }

                    if(request && typeof request.done==='function'){
                        request.done(function(){deferred?.resolve.apply(deferred,arguments);})
                            .fail(function(){deferred?.reject.apply(deferred,arguments);});
                    }else if(deferred && deferred.state()==='pending'){
                        deferred.resolve(request);
                    }
                }else if(deferred){
                    deferred.reject({message:'Secure action was cancelled.'});
                }

                notify(response?.message||'Step-up verification successful.');
            })
            .fail(function(error){notify(errMsg(error,'Step-up verification failed.'),'error');})
            .always(function(){state.stepUpBusy=false;button.prop('disabled',false);});
    });
    $('#pwShareForm').on('submit.pw',function(event){event.preventDefault();submitShare();});
    $('#pwShareExpiryPreset').on('change.pw',function(){
        const days=Number(this.value||0);
        if(!days){$('#pwShareExpiresAt').val('');return;}
        const date=new Date();date.setDate(date.getDate()+days);
        const pad=n=>String(n).padStart(2,'0');
        $('#pwShareExpiresAt').val(`${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:00`);
    });

    $('#pwStepUpModal').on('hidden.bs.modal',function(){
        $('#pwStepUpPassword').val('');
        const deferred=state.stepUpDeferred;
        state.stepUpPending=null;
        state.stepUpDeferred=null;
        if(deferred && deferred.state()==='pending'){
            deferred.reject({message:'Secure verification was cancelled.'});
        }
    });

    $('.pw-detail-tab').on('click.pw',function(){loadDetailTab(String($(this).data('pw-detail-tab')||'details'));});

    $(document).on('click.pw','[data-pw-page]',function(){
        const page=Number($(this).data('pw-page'));if(page>0){state.page=page;loadData();}
    });

    $(document).on('click.pw','[data-pw-tab]',function(){
        const tab=String($(this).data('pw-tab')||'all');
        state.tab=tab;state.page=1;
        $('.pw-tab').removeClass('active');
        $('.pw-tab').removeClass('text-white');
        $(this).addClass('active');
        $(this).addClass('text-white');
        loadData();
    });

    $(document).on('click.pw','[data-pw-action]',function(event){
        const action=String($(this).data('pw-action')||'');
        const id=$(this).data('id');
        event.stopPropagation();
        switch(action){
            case 'new-entry': openNewEntry(); break;
            case 'refresh': loadData(); break;
            case 'generate-password': generatePassword('#pwEntryPassword').done(renderPasswordStrength).fail(error=>notify(errMsg(error),'error')); break;
            case 'toggle-entry-password':
                const input=$('#pwEntryPassword');input.attr('type',input.attr('type')==='password'?'text':'password');break;
            case 'open-entry': openEntry(id); break;
            case 'show-password': revealEntrySecret(id,function(secret){notify('Credential revealed. It will be re-masked after 15 seconds.');}); break;
            case 'copy-password': copyPassword(id); break;
            case 'copy-username': copyUsername(id); break;
            case 'detail-reveal':
                if(state.currentEntry) showPassword(state.currentEntry.sno,'#pwDetailPasswordValue');
                break;
            case 'detail-copy': if(state.currentEntry) copyPassword(state.currentEntry.sno); break;
            case 'detail-copy-username': if(state.currentEntry) copyUsername(state.currentEntry.sno); break;
            case 'detail-change': if(state.currentEntry) openChangePassword(state.currentEntry); break;
            case 'detail-share': if(state.currentEntry) openShare(state.currentEntry); break;
            case 'detail-delete': if(state.currentEntry) deleteEntry(state.currentEntry.sno); break;
            case 'revoke-share': revokeShare(id); break;
            case 'change-generate': generatePassword('#pwChangePasswordValue').fail(error=>notify(errMsg(error),'error')); break;
            case 'change-save': saveGuidedPassword(); break;
            case 'lock-now': lockNow(); break;
            case 'delete-entry': deleteEntry(id); break;
        }
    });

    $(document).on('click.pw','[data-pw-row]',function(event){
        if($(event.target).closest('button,a,select,input').length) return;
        openEntry($(this).data('pw-row'));
    });

    function deleteEntry(id){
        confirmAction('Delete credential','This will remove the vault entry and revoke its active audience grants. Continue only when the record is no longer required.','Delete',function(){
            return requestStepUp(function(){
                return ajax('DELETE',routeUrl(R.delete,id)).done(function(response){
                    notify(response?.message||'Vault entry removed.');
                    if(String(state.currentEntry?.sno||'')===String(id)){state.currentEntry=null;offcanvas('pwDetailOffcanvas')?.hide();}
                    loadData();
                });
            });
        });
    }

    // Audience events are bound after the dynamic fields exist in the DOM.
    bindAudienceEvents('post');
    bindAudienceEvents('share');

    // Keep one initial audience/type population; all subsequent option changes remain AJAX-driven like Knowledge Panel.
    loadOptions().always(function(){
        state.audience.post.mode='private';
        state.audience.share.mode='company';
        renderAudienceFieldsOnly('post','private');
        renderAudienceFieldsOnly('share','company');
        loadData();
    });
</script>
@endsection
