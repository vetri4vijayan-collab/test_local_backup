@extends('layouts/layoutMaster')

@section('title', 'Knowledge Panel')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection
@section('page-script')
@vite(['resources/assets/js/form_wizard_icons.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/forms-pickers.js')
@vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $module_name = 'Tool Management';
    $submenu_name = 'Knowledge Panel';
    $last_name = NULL;
   
    $add_post = 0;
    $share_post = 0;
    $manage_category = 0;

    
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'New Post')){
        $add_post = 1;
    }else{
       $add_post = 0;
    }
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Share')){
        $share_post = 1;
    }else{
       $share_post = 0;
    }
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Manage Category')){
        $manage_category = 1;
    }else{
       $manage_category = 0;
    }
    
@endphp


<style>
    #egKnowledge{
        --k-red:var(--expense-primary,#b52b25);
        --k-red-dark:var(--expense-primary-hover,#8f1d1d);
        --k-gold:var(--expense-secondary,#c89a20);
        --k-navy:#203f6d;
        --k-purple:var(--expense-primary,#b52b25);
        --k-bg:#f5f6fb;--k-card:#fff;
        --k-border:#dfe4ed;
        --k-text:#18243a;
        --k-muted:#7d8a9e;
        background:var(--k-bg);
        min-height:calc(100vh - 70px);
        padding:8px 18px 24px;
        color:var(--k-text);
    }

    #egKnowledge .k-shell{
        display:grid;
        grid-template-columns:265px minmax(0,1fr) 300px;
        gap:18px;
        align-items:start;
    }

    #egKnowledge .k-sidebar,
    #egKnowledge .k-trending,
    #egKnowledge .k-library{
        background:#fff;
        border:1px solid var(--k-border);
        border-radius:13px;
    }

    #egKnowledge .k-sidebar{
        padding:14px 12px;
        position:sticky;
        top:78px;
    }
    #egKnowledge .k-right{
        /* padding:14px 12px; */
        position:sticky;
        top:78px;
    }

    #egKnowledge .k-new-post{
        width:100%;
        height:50px;
        border:0;
        border-radius:10px;
        background:var(--k-red);
        color:#fff;
        /* font-size:13px;
        font-weight:900; */
        box-shadow:0 7px 17px rgba(32,63,109,.13);
    }

    #egKnowledge .k-new-post:hover{
        background:var(--k-red-dark);
    }

    #egKnowledge .k-side-title-row{
        display:flex;
        align-items:center;
        justify-content:space-between;
        padding:16px 10px 8px;
    }

    #egKnowledge .k-side-title{
        /* font-size:13px;
        font-weight:900; */
        color:var(--k-red);
    }

    #egKnowledge .k-mini-settings{
        /* width:28px;
        height:28px; */
        padding:0;
        /* border-radius:7px; */
        /* border:1px solid var(--k-border);
        background:#fff;
        color:#8692a3; */
        display:grid;
        place-items:center;
    }

    #egKnowledge .k-mini-settings:hover{
        border-color:#d9aaa6;
        color:var(--k-red);
    }

    #egKnowledge .k-category-row{
        display:grid;
        grid-template-columns:minmax(0,1fr) auto auto;
        gap:4px;
        align-items:center;
        padding:9px 8px;
        border-radius:8px;
    }

    #egKnowledge .k-category-row:hover,
    #egKnowledge .k-category-row.active{
        background:rgba(181,43,37,.06);
    }

    #egKnowledge .k-category-name{
        border:0;
        background:transparent;
        /* text-align:left;
        color:#283348;
        font-size:11px;
        font-weight:800;
        padding:0; */
        min-width:0;
        /* white-space:nowrap; */
        overflow:hidden;
        text-overflow:ellipsis;
    }

    #egKnowledge .k-category-row.active .k-category-name{
        color:var(--k-red);
    }

    #egKnowledge .k-category-count{
        /* font-size:9px;color:#929daf; */
        /* padding-left:6px; */
    }

    #egKnowledge .k-follow{
        border:0;
        background:transparent;
        /* color:#c7cfdb; */
        padding:2px 1px;
        /* font-size:14px; */
    }

    #egKnowledge .k-follow.active{
        color:var(--k-gold);
    }

    #egKnowledge .k-inline-gear{
        /* opacity:0;
        margin-left:1px; */
    }

    #egKnowledge .k-category-row:hover .k-inline-gear{
        opacity:1;
    }

    #egKnowledge .k-main{
        min-width:0;
    }

    #egKnowledge .k-feed-head{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:16px;
        padding:0 0 12px;
    }

    #egKnowledge .k-feed-title{
        /* font-size:20px;
        font-weight:900; */
        color:var(--k-red);
        margin:0;
    }

    #egKnowledge .k-type-pills{
        display:flex;
        flex-wrap:wrap;
        justify-content:flex-end;
        gap:7px;
    }

    #egKnowledge .k-type-pill{
        border:1px solid var(--k-border);
        background:#fff;
        /* color:#31415d;
        border-radius:999px;
        padding:6px 12px;
        font-size:10px;
        font-weight:800; */
    }

    #egKnowledge .k-type-pill.active{
        background:var(--k-red);
        border-color:var(--k-red);
        color:#fff;
    }

    #egKnowledge .k-post{
        background:#fff;
        border:1px solid var(--k-border);
        border-radius:12px;
        margin-bottom:12px;
        overflow:hidden;
    }

    #egKnowledge .k-post-head{
        display:flex;
        align-items:flex-start;
        justify-content:space-between;
        gap:12px;
        padding:15px 18px 10px;
    }

    #egKnowledge .k-author-wrap{
        display:flex;
        align-items:flex-start;
        gap:10px;
    }

    #egKnowledge .k-avatar{
        width:44px;
        height:44px;
        border-radius:50%;
        display:grid;
        place-items:center;
        color:#fff;
        font-size:12px;
        font-weight:900;
        flex:0 0 44px;
    }

    #egKnowledge .k-author{
        /* font-size:12px;
        font-weight:900;
        color:#16273f; */
        line-height:1.2;
    }

    #egKnowledge .k-company-chip{
        display:inline-flex;
        margin-left:7px;
        padding:3px 7px;
        border-radius:999px;
        background:#f0edf8;
        color:#4e4191;
        font-size:8px;
        font-weight:900;
        vertical-align:1px;
    }

    #egKnowledge .k-post-meta{
        margin-top:4px;
        /* color:#7e8ca1;
        font-size:9px; */
    }

    #egKnowledge .k-post-more{
        width:28px;
        height:28px;
        border:0;
        background:transparent;
        color:#9aa5b5;
        padding:0;
        border-radius:7px;
    }

    #egKnowledge .k-post-more:hover{
        background:#f7f8fa;
        color:var(--k-red);
    }

    #egKnowledge .k-post-body{
        padding:0 18px 13px;
        /* color:#11243b; */
        /* font-size:13px; */
        line-height:1.55;
    }

    #egKnowledge .k-post-body{

    }

    #egKnowledge .k-post-body img{
        max-width:100%;
        height:auto;
        border-radius:8px;
    }

    #egKnowledge .k-post-actions{
        display:flex;
        align-items:center;
        gap:17px;
        border-top:1px solid #edf0f4;
        padding:10px 17px;
    }

    #egKnowledge .k-post-action{
        border:0;
        background:transparent;
        /* color:#718096;
        font-size:10px;
        font-weight:800; */
        padding:0;
    }

    #egKnowledge .k-post-action:hover,#egKnowledge .k-post-action.active{
        color:var(--k-red);
    }

    #egKnowledge .k-post-actions .save{
        margin-left:auto;
    }

    #egKnowledge .k-post-age{
        color:#9aa4b3;
        font-size:9px;
        white-space:nowrap;
        line-height:1;
    }

    #egKnowledge .k-post{
        content-visibility:auto;
        contain-intrinsic-size:320px;
    }

    #egKnowledge .k-infinite-skeleton{
        display:grid;
        gap:12px;
        margin-top:12px;
    }

    #egKnowledge .k-scroll-sentinel{
        width:100%;
        height:1px;
        margin:4px 0 0;
    }

    #egKnowledge .k-trending{
        overflow:hidden;
    }

    #egKnowledge .k-trend-head{
        padding:13px 14px;
        border-bottom:2px solid var(--k-gold);
        /* font-size:13px;
        font-weight:900;
        color:#243247; */
    }

    #egKnowledge .k-trend-row{
        display:grid;
        grid-template-columns:24px minmax(0,1fr);
        gap:9px;
        padding:12px 14px;
        border-bottom:1px solid #edf0f4;
    }

    #egKnowledge .k-trend-row:last-child{
        border-bottom:0;
    }

    #egKnowledge .k-trend-num{
        /* font-size:13px;
        font-weight:900; */
        color:#c69c14;
    }

    #egKnowledge .k-trend-title{
        /* font-size:11px;
        font-weight:900; */
        line-height:1.35;
        /* color:#1c2a40; */
    }

    #egKnowledge .k-trend-meta{
        /* font-size:8px; */
        /* color:#8390a3; */
        margin-top:4px;
    }

    #egKnowledge .k-library{
        margin-top:14px;
        padding:14px;
    }

    #egKnowledge .k-library-title{
        display:flex;
        align-items:center;
        gap:9px;
        /* font-size:11px;
        font-weight:900;
        color:#263246; */
    }

    #egKnowledge .k-library-title i{
        /* font-size:19px; */
        color:var(--k-gold);
    }

    #egKnowledge .k-library-sub{
        margin-left:28px;
        /* color:#8290a4;
        font-size:9px; */
    }

    #egKnowledge .k-pager{
        display:flex;
        justify-content:space-between;
        align-items:center;
        padding:6px 0 2px;
        color:#8b96a6;
        font-size:9px;
    }

    #egKnowledge .k-pager .btn{
        width:29px;
        height:28px;
        padding:0;
        border-radius:7px;
    }

    #egKnowledge .k-settings-modal .modal-content{
        border:0;
        border-radius:22px;
        overflow:hidden;
        box-shadow:0 28px 90px rgba(15,23,42,.20);
    }

    #egKnowledge .k-settings-head{
        background:#f8fafc;
        border-bottom:1px solid #e8edf4;
        padding:18px 22px;
    }

    #egKnowledge .k-settings-form{
        background:#f8fafc;
        border:1px solid #e7ecf2;
        border-radius:15px;
        padding:15px;
    }

    #egKnowledge .k-settings-form-title{
        font-size:13px;
        font-weight:850;
        color:#0f172a;
    }

    #egKnowledge .k-settings-form .form-control,
    #egKnowledge .k-settings-form .form-select{
        min-height:44px;
        border-radius:11px;
        border-color:#d8e0ea;
    }

    #egKnowledge .k-settings-form .form-label{
        font-size:12px!important;
        font-weight:800!important;
        color:#334155;
        margin-bottom:7px;
    }

    #egKnowledge .k-settings-status{
        display:inline-flex;
        align-items:center;
        gap:6px;
        padding:5px 9px;
        border-radius:999px;
        font-size:10px;
        font-weight:850;
    }

    #egKnowledge .k-settings-status.active{
        background:#ecfdf5;
        color:#047857;
    }

    #egKnowledge .k-settings-status.inactive{
        background:#fef2f2;
        color:#b91c1c;
    }

    #egKnowledge .k-settings-toggle{
        width:2.25rem!important;
        height:1.15rem!important;
        cursor:pointer;
        margin:0;
    }

    #egKnowledge .k-settings-action-btn{
        width:36px;
        height:36px;
        border-radius:10px;
        display:inline-flex;
        align-items:center;
        justify-content:center;
    }

    #egKnowledge .k-settings-number{
        font-size:11px;
        color:#64748b;
        font-weight:800;
    }

    @media(max-width:767.98px){
        #egKnowledge .k-settings-head{
            padding:16px;
        }
        #egKnowledge .k-settings-form{
            padding:13px;
        }
    }

    #egKnowledge .k-settings-tabs{
        display:flex;
        gap:6px;
        margin-bottom:13px;
    }

    #egKnowledge .k-settings-tab{
        border:1px solid var(--k-border);
        background:#fff;color:#67748a;
        border-radius:8px;
        padding:7px 11px;
        font-size:10px;
        font-weight:900;
    }

    #egKnowledge .k-settings-tab.active{
        background:var(--k-red);
        border-color:var(--k-red);
        color:#fff;
    }

    #egKnowledge .k-settings-toolbar{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        margin-bottom:10px;
    }

    #egKnowledge .k-settings-table-wrap{
        overflow:auto;
        border:1px solid var(--k-border);
        /* border-radius:10px; */
    }
    
    #egKnowledge .k-settings-table{
        width:100%;
        min-width:760px;
        border-collapse:separate;
        border-spacing:0;
    }

    #egKnowledge .k-settings-table th{
        /* background:#fafbfd;
        color:#7d899b; */
        padding:9px;
        /* font-size:8px; */
        text-transform:uppercase;
        letter-spacing:.04em;
        text-align:left;
        border-bottom:1px solid var(--k-border);
    }

    #egKnowledge .k-settings-table td{
        padding:9px;
        font-size:10px;
        border-bottom:1px solid #eef1f5;
        vertical-align:middle;
    }

    #egKnowledge .k-settings-table tr:last-child td{
        border-bottom:0;
    }

    #egKnowledge .k-color-dot{
        display:inline-block;
        width:12px;
        height:12px;
        border-radius:50%;
        margin-right:5px;
        border:1px solid rgba(0,0,0,.08);
        vertical-align:-2px;
    }

    #egKnowledge .k-settings-actions{
        display:flex;
        gap:4px;
        justify-content:flex-end;
    }

    #egKnowledge .egpk-badge{
        display:inline-flex;
        align-items:center;
        border-radius:999px;
        padding:4px 7px;
        font-size:8px;
        font-weight:800;
        line-height:1;
        border:1px solid transparent;
    }

    #egKnowledge .egpk-badge-green{
        background:#eaf7ef;
        color:#2d8152;
        border-color:#ccebd8;
    }

    #egKnowledge .egpk-badge-red{
        background:#fff0ef;
        color:#b52b25;
        border-color:#f4d0cd;
    }

    #egKnowledge .egpk-badge-slate{
        background:#f2f4f7;
        color:#6f7c8e;
        border-color:#e5e9ef;
    }

    #egKnowledge .k-settings-actions .btn{
        width:29px;
        height:29px;
        padding:0;
        display:grid;
        place-items:center;
        border-radius:7px;
    }

    /* #egKnowledge .k-select2-wrap .select2-container{
        width:100%!important;
    }

    #egKnowledge .select2-container--default .select2-selection--single{
        height:36px!important;
        border:1px solid #dfe4eb!important;
        border-radius:8px!important;
    } */

    /* #egKnowledge .select2-container--default .select2-selection--single .select2-selection__rendered{
        line-height:34px!important;
        font-size:10px;
    }

    #egKnowledge .select2-container--default .select2-selection--single .select2-selection__arrow{
        height:34px!important;
    } */

    /* Background live-sync indicators. These never replace the current feed with a skeleton. */
    #egKnowledge .k-live-status{
        display:inline-flex;
        align-items:center;
        gap:6px;
        margin-left:8px;
        color:#7d899d;
        font-size:8px;
        font-weight:700;
        vertical-align:middle;
    }
    #egKnowledge .k-live-dot{
        width:7px;
        height:7px;
        border-radius:50%;
        background:#2f9e67;
        box-shadow:0 0 0 0 rgba(47,158,103,.32);
        animation:kLivePulse 1.9s ease-out infinite;
    }
    #egKnowledge .k-live-dot.syncing{
        background:#c69c14;
        animation:none;
        box-shadow:0 0 0 3px rgba(198,156,20,.12);
    }
    #egKnowledge .k-live-dot.offline{
        background:#9aa5b5;
        animation:none;
        box-shadow:none;
    }
    #egKnowledge .k-live-new-banner{
        display:none;
        margin:0 0 10px;
        padding:8px 11px;
        border:1px solid #dce5f0;
        border-radius:10px;
        background:#f7fbff;
        color:#35506f;
        align-items:center;
        justify-content:space-between;
        gap:10px;
    }
    #egKnowledge .k-live-new-banner.show{display:flex;}
    #egKnowledge .k-live-new-banner button{
        border:0;
        background:transparent;
        color:var(--k-red);
        font-size:9px;
        font-weight:800;
        padding:3px 0;
        white-space:nowrap;
    }
    @keyframes kLivePulse{
        0%{box-shadow:0 0 0 0 rgba(47,158,103,.32)}
        70%{box-shadow:0 0 0 6px rgba(47,158,103,0)}
        100%{box-shadow:0 0 0 0 rgba(47,158,103,0)}
    }

    #egKnowledge .k-loading{
        padding:18px 0;
        color:#8290a4;
        font-size:11px;
    }

    #egKnowledge .k-skeleton-wrap{
        display:grid;
        gap:12px;
    }

    #egKnowledge .k-skeleton-card{
        background:#fff;
        border:1px solid var(--k-border);
        border-radius:12px;padding:15px 18px;
        overflow:hidden;
    }

    #egKnowledge .k-skeleton-line,
    #egKnowledge .k-skeleton-avatar,
    #egKnowledge .k-skeleton-chip{
        position:relative;
        overflow:hidden;
        background:linear-gradient(90deg,#eef1f5 25%,#f8f9fb 50%,#eef1f5 75%);
        background-size:220% 100%;
        animation:kSkeletonShimmer 1.45s ease-in-out infinite;
    }

    #egKnowledge .k-skeleton-line{
        height:10px;
        border-radius:999px;
        margin:8px 0;
    }

    #egKnowledge .k-skeleton-line.w-20{
        width:20%;
    }

    #egKnowledge .k-skeleton-line.w-35{
        width:35%;
    }

    #egKnowledge .k-skeleton-line.w-50{
        width:50%;
    }

    #egKnowledge .k-skeleton-line.w-65{
        width:65%;
    }

    #egKnowledge .k-skeleton-line.w-80{
        width:80%;
    }

    #egKnowledge .k-skeleton-line.w-92{
        width:92%;
    }

    #egKnowledge .k-skeleton-avatar{
        width:44px;
        height:44px;
        border-radius:50%;
        flex:0 0 44px;
    }

    #egKnowledge .k-skeleton-chip{
        width:66px;
        height:16px;
        border-radius:999px;
        display:inline-block;
        vertical-align:middle;
        margin-left:7px;
    }

    #egKnowledge .k-skeleton-actions{
        display:flex;
        gap:15px;
        border-top:1px solid #edf0f4;
        margin:12px -18px -15px;
        padding:10px 18px;
    }

    #egKnowledge .k-skeleton-action{
        width:48px;
        height:9px;
        border-radius:999px;
        position:relative;
        overflow:hidden;
        background:linear-gradient(90deg,#eef1f5 25%,#f8f9fb 50%,#eef1f5 75%);
        background-size:220% 100%;
        animation:kSkeletonShimmer 1.45s ease-in-out infinite;
    }

    #egKnowledge .k-skeleton-side{
        background:#fff;
        border:1px solid var(--k-border);
        border-radius:13px;
        padding:14px 12px;
    }
    
    #egKnowledge .k-skeleton-side .k-skeleton-line{
        margin:9px 0;
    }
    @keyframes kSkeletonShimmer{
        0%{
            background-position:200% 0;
        }
        100%{
            background-position:-20% 0;
        }
    }
    @media (prefers-reduced-motion:reduce){
        #egKnowledge .k-skeleton-line,
        #egKnowledge .k-skeleton-avatar,
        #egKnowledge .k-skeleton-chip,
        #egKnowledge .k-skeleton-action{
            animation:none;
        }
    }
    #egKnowledge .k-modal-kicker{
        /* font-size:8px;
        font-weight:900; */
        letter-spacing:.12em;
        /* color:#8c96a7; */
        margin-bottom:3px;
    }

    #egKnowledge .k-content-types{
        display:grid;
        grid-template-columns:repeat(4,minmax(0,1fr));
        gap:8px;
        margin-bottom:15px;
    }

    #egKnowledge .k-content-type{
        border:1px solid var(--k-border);
        border-radius:10px;
        background:#fff;
        /* color:#44536b; */
        min-height:74px;
        padding:10px 8px;
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:center;
        gap:5px;
        /* font-size:9px;
        font-weight:800; */
        transition:.16s ease;
    }

    #egKnowledge .k-content-type i{
        /* font-size:20px; */
        /* color:#7f8b9f; */
    }

    #egKnowledge .k-content-type:hover{
        border-color:#c7ceda;
        background:#fafbfe;
    }

    #egKnowledge .k-content-type.active{
        border-color:var(--k-red);
        background:rgba(181,43,37,.06);
        color:var(--k-red);
        box-shadow:0 4px 12px rgba(181,43,37,.08);
    }

    #egKnowledge .k-content-type.active i{
        color:var(--k-red);
    }

    #egKnowledge .k-editor-section{
        border:1px solid var(--k-border);
        border-radius:11px;
        background:#fbfcfe;
        padding:12px;
    }

    #egKnowledge .k-field-label{
        /* font-size:9px;
        font-weight:800; */
        /* color:#52627c; */
        margin-bottom:5px;
        display:block;
    }

    #egKnowledge .k-media-drop{
        border:1.5px dashed #cfd6e2;
        border-radius:11px;
        background:#fff;
        padding:19px 14px;
        text-align:center;
        cursor:pointer;
        transition:.16s ease;
    }

    #egKnowledge .k-media-drop:hover,
    #egKnowledge .k-media-drop.dragover{
        border-color:var(--k-red);
        background:rgba(181,43,37,.035);
    }

    #egKnowledge .k-media-drop i{
        font-size:30px;
        color:var(--k-red);
        display:block;
        margin-bottom:6px;
    }

    #egKnowledge .k-media-drop strong{
        display:block;
        /* color:#324563;
        font-size:10px; */
    }

    #egKnowledge .k-media-drop span{
        display:block;
        /* color:#8c96a7;
        font-size:8px; */
        margin-top:3px;
    }

    #egKnowledge .k-media-preview-list{
        display:grid;
        gap:7px;
        margin-top:9px;
    }

    #egKnowledge .k-media-preview{
        display:flex;
        align-items:center;
        gap:8px;
        padding:8px 9px;
        border:1px solid #edf0f4;
        background:#fff;
        border-radius:8px;
    }

    #egKnowledge .k-media-preview-icon{
        width:28px;
        height:28px;
        border-radius:7px;
        background:#f3f5f8;
        color:#738197;
        display:grid;
        place-items:center;
        flex:0 0 28px;
    }

    #egKnowledge .k-media-preview-name{
        flex:1;
        min-width:0;
        font-size:9px;
        font-weight:700;
        color:#3a4b66;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }

    #egKnowledge .k-media-preview-size{
        font-size:8px;
        color:#99a2b1;
    }

    /* Friendly image upload preview for Create Knowledge Post. */
    #egKnowledge .k-media-image-preview{
        display:flex;
        align-items:center;
        gap:11px;
        padding:9px;
        border:1px solid #e4e9f0;
        background:#fff;
        border-radius:10px;
        margin-top:8px;
    }

    #egKnowledge .k-media-image-thumb{
        width:88px;
        height:72px;
        flex:0 0 88px;
        border-radius:9px;
        overflow:hidden;
        background:#f3f5f8;
        border:1px solid #e7ebf0;
        display:flex;
        align-items:center;
        justify-content:center;
    }

    #egKnowledge .k-media-image-thumb img{
        width:100%;
        height:100%;
        object-fit:cover;
        display:block;
    }

    #egKnowledge .k-media-image-meta{
        min-width:0;
        flex:1;
    }

    #egKnowledge .k-media-image-name{
        font-size:9px;
        font-weight:800;
        color:#34455f;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }

    #egKnowledge .k-media-image-info{
        margin-top:4px;
        font-size:8px;
        color:#8a96a7;
    }

    #egKnowledge .k-media-image-status{
        display:inline-flex;
        align-items:center;
        gap:4px;
        margin-top:7px;
        padding:3px 7px;
        border-radius:999px;
        background:#eef8f2;
        color:#2f7d55;
        font-size:7px;
        font-weight:800;
    }

    @media(max-width:600px){
        #egKnowledge .k-media-image-thumb{
            width:72px;
            height:60px;
            flex-basis:72px;
        }
    }

    #egKnowledge .k-url-preview{
        display:flex;
        gap:9px;
        align-items:flex-start;
        padding:10px;
        border:1px solid #e9edf3;
        border-radius:9px;
        background:#fff;
    }

    #egKnowledge .k-url-preview-icon{
        width:30px;
        height:30px;
        border-radius:8px;
        display:grid;
        place-items:center;
        background:#f0f3f8;
        color:var(--k-red);
        flex:0 0 30px;
    }

    #egKnowledge .k-post-media{
        display:grid;
        gap:10px;
        margin-top:10px;
    }

    /* Professional social-style preview for Knowledge URL posts. */
    #egKnowledge .k-post-url-card{
        display:block;
        width:100%;
        padding:13px 14px;
        border:1px solid #e2e7ef;
        border-radius:12px;
        background:#fff;
        color:#22314a;
        text-decoration:none;
        box-shadow:0 3px 12px rgba(31,44,68,.05);
        transition:border-color .16s ease, box-shadow .16s ease, transform .16s ease, background .16s ease;
    }

    #egKnowledge .k-post-url-card:hover{
        color:#22314a;
        border-color:#c8d1df;
        background:#fcfdff;
        box-shadow:0 8px 22px rgba(31,44,68,.09);
        transform:translateY(-1px);
    }

    #egKnowledge .k-post-url-card:focus-visible{
        outline:2px solid var(--k-red);
        outline-offset:2px;
    }

    #egKnowledge .k-post-url-top{
        display:flex;
        align-items:center;
        gap:12px;
        min-width:0;
    }

    #egKnowledge .k-post-url-icon{
        width:46px;
        height:46px;
        flex:0 0 46px;
        display:grid;
        place-items:center;
        border:1px solid #e5eaf1;
        border-radius:10px;
        background:#f7f9fc;
        overflow:hidden;
    }

    #egKnowledge .k-post-url-icon img{
        width:30px;
        height:30px;
        object-fit:contain;
        display:block;
    }

    #egKnowledge .k-post-url-icon-fallback{
        color:var(--k-red);
        font-size:22px;
    }

    #egKnowledge .k-post-url-main{
        min-width:0;
        flex:1;
    }

    #egKnowledge .k-post-url-title{
        font-size:11px;
        font-weight:900;
        line-height:1.35;
        color:#20314a;
        display:-webkit-box;
        -webkit-line-clamp:2;
        -webkit-box-orient:vertical;
        overflow:hidden;
    }

    #egKnowledge .k-post-url-description{
        margin-top:9px;
        padding-top:9px;
        border-top:1px solid #eef1f5;
        color:#718097;
        font-size:9px;
        line-height:1.45;
        display:-webkit-box;
        -webkit-line-clamp:2;
        -webkit-box-orient:vertical;
        overflow:hidden;
    }

    #egKnowledge .k-post-url-domain{
        display:block;
        margin-top:4px;
        color:#7f8b9e;
        font-size:8px;
        font-weight:800;
        text-transform:lowercase;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }

    #egKnowledge .k-post-url-open{
        width:32px;
        height:32px;
        flex:0 0 32px;
        display:grid;
        place-items:center;
        border:1px solid #e1e6ee;
        border-radius:8px;
        color:#8a97aa;
        background:#fff;
    }

    #egKnowledge .k-post-url-card:hover .k-post-url-open{
        color:var(--k-red);
        border-color:#d5dce6;
    }

    @media(max-width:600px){
        #egKnowledge .k-post-url-card{
            padding:11px 12px;
        }

        #egKnowledge .k-post-url-top{
            gap:10px;
        }

        #egKnowledge .k-post-url-icon{
            width:42px;
            height:42px;
            flex-basis:42px;
        }

        #egKnowledge .k-post-url-icon img{
            width:26px;
            height:26px;
        }

        #egKnowledge .k-post-url-open{
            width:30px;
            height:30px;
            flex-basis:30px;
        }
    }

    /* Professional audience selector used by both Create Post and Share. */
    #egKnowledge .k-audience-builder{
        border:1px solid #e3e8f0;
        border-radius:14px;
        background:#fbfcfe;
        padding:12px;
    }
    #egKnowledge .k-audience-modes{
        display:grid;
        grid-template-columns:repeat(4,minmax(0,1fr));
        gap:7px;
        margin-bottom:11px;
    }
    #egKnowledge .k-audience-mode{
        border:1px solid #e0e5ed;
        background:#fff;
        border-radius:10px;
        padding:9px 7px;
        display:flex;
        align-items:center;
        justify-content:center;
        gap:5px;
        /* color:#65738a;
        font-size:9px;
        font-weight:850; */
        cursor:pointer;
        transition:.15s ease;
    }
    #egKnowledge .k-audience-mode:hover{
        border-color:#c6cedb;
        background:#fff;
    }
    #egKnowledge .k-audience-mode.active{
        border-color:var(--k-red);
        color:var(--k-red);
        background:rgba(181,43,37,.055);
        box-shadow:0 3px 9px rgba(181,43,37,.06);
    }
    #egKnowledge .k-audience-mode i{font-size:16px}
    #egKnowledge .k-audience-fields{
        display:grid;
        gap:10px;
    }
    #egKnowledge .k-audience-field{
        border:1px solid #e7ebf1;
        background:#fff;
        border-radius:11px;
        padding:10px;
    }
    #egKnowledge .k-audience-field .form-label{
        /* font-size:9px!important;
        font-weight:850!important; */
        /* color:#4f6077; */
        margin-bottom:6px;
    }
    #egKnowledge .k-audience-field .form-select{min-height:44px;border-radius:10px}
    #egKnowledge .k-audience-field select[multiple]{min-height:118px;padding:8px 10px;cursor:pointer;background-image:none}
    #egKnowledge .k-audience-field select[multiple] option{padding:7px 8px;border-radius:6px}
    #egKnowledge .k-audience-field select[multiple] option:checked{font-weight:700}
    #egKnowledge .k-audience-summary{
        display:flex;
        flex-wrap:wrap;
        align-items:center;
        gap:6px;
        margin-top:9px;
        color:#7d899d;
        font-size:8px;
        line-height:1.35;
    }
    #egKnowledge .k-audience-summary strong{color:#32445f}
    #egKnowledge .k-audience-chip{
        display:inline-flex;
        align-items:center;
        gap:4px;
        padding:4px 8px;
        border-radius:999px;
        background:#f1f4f8;
        border:1px solid #e3e8ee;
        color:#52637b;
        /* font-size:8px;
        font-weight:800; */
    }
    #egKnowledge .k-audience-selection{
        display:flex;
        align-items:flex-start;
        gap:8px;
        margin:0 0 10px;
        padding:8px 10px;
        border-radius:10px;
        background:#f7f9fc;
        border:1px solid #e7ebf1;
    }
    #egKnowledge .k-audience-selection-label{
        flex:0 0 auto;
        padding-top:3px;
        /* color:#718096;
        font-size:8px;
        font-weight:850; */
        text-transform:uppercase;
        letter-spacing:.05em;
    }
    #egKnowledge .k-audience-selection-values{
        display:flex;
        flex-wrap:wrap;
        gap:5px;
        min-width:0;
    }
    #egKnowledge .k-audience-selection-empty{
        /* color:#9aa5b5;
        font-size:8px;
        font-weight:700; */
    }
    /* #egKnowledge .k-audience-builder .select2-container{
        width:100%!important;
    }
    #egKnowledge .k-audience-builder .select2-container--default .select2-selection--multiple{
        min-height:44px;
        border:1px solid #dfe5ed;
        border-radius:10px;
        background:#fff;
        padding:5px 7px;
    }
    #egKnowledge .k-audience-builder .select2-container--default.select2-container--focus .select2-selection--multiple{
        border-color:var(--k-red);
        box-shadow:0 0 0 3px rgba(181,43,37,.08);
    }
    #egKnowledge .k-audience-builder .select2-selection__choice{
        border:1px solid #dfe5ed!important;
        background:#f3f5f8!important;
        color:#42536b!important;
        border-radius:999px!important;
        padding:4px 8px 4px 22px!important;
        font-size:8px!important;
        font-weight:800!important;
    }
    #egKnowledge .k-audience-builder .select2-selection__choice__remove{
        color:#8c98aa!important;
        border:0!important;
        left:7px!important;
        right:auto!important;
    }
    #egKnowledge .k-audience-builder .select2-search--inline .select2-search__field{
        min-height:27px;
        font-size:9px;
        margin-top:2px;
    }
    #egKnowledge .k-audience-builder .select2-dropdown{
        border-color:#dfe5ed;
        box-shadow:0 14px 38px rgba(17,24,39,.12);
    }
    #egKnowledge .k-audience-builder .select2-results__option{
        font-size:9px;
        padding:8px 10px;
    } */
    #egKnowledge .k-text-editor-wrap{
        border:1px solid #dfe5ed;
        border-radius:12px;
        overflow:hidden;
        background:#fff;
    }
    #egKnowledge .k-text-editor-wrap .ql-toolbar.ql-snow{
        border:0;
        border-bottom:1px solid #e9edf2;
        background:#fbfcfe;
        padding:7px 8px;
    }
    #egKnowledge .k-text-editor-wrap .ql-container.ql-snow{
        border:0;
        min-height:260px;
        font-family:inherit;
        font-size:13px;
    }
    #egKnowledge .k-text-editor-wrap .ql-editor{
        min-height:220px;
        padding:14px;
        color:#11243b;
        line-height:1.65;
    }
    #egKnowledge .k-text-editor-wrap .ql-editor.ql-blank::before{
        color:#9aa5b5;
        font-style:normal;
        left:14px;
        right:14px;
    }

    @media(max-width:600px){
        #egKnowledge .k-audience-modes{grid-template-columns:repeat(2,minmax(0,1fr));}
    }

    #egKnowledge .k-post-media img,
    #egKnowledge .k-post-media video{
        width:100%;
        max-height:420px;
        object-fit:contain;
        background:#f5f6f9;
        border-radius:9px;
    }

    /* Social-style image carousel + fullscreen photo viewer. */
    #egKnowledge .k-image-slide-open,
    #egKnowledge .k-single-image-open{
        width:100%;
        min-height:250px;
        border:0;
        padding:0;
        margin:0;
        background:#f5f6f9;
        display:flex;
        align-items:center;
        justify-content:center;
        cursor:zoom-in;
        text-align:inherit;
    }

    #egKnowledge .k-image-slide-open:focus-visible,
    #egKnowledge .k-single-image-open:focus-visible{
        outline:2px solid var(--k-red);
        outline-offset:-2px;
    }

    #egKnowledge .k-single-image-open img{
        display:block;
        width:100%;
        height:auto;
        max-height:520px;
        object-fit:contain;
        background:#f5f6f9;
        border-radius:8px;
    }

    #egKnowledge .k-image-slide-open img{
        display:block;
        width:100%;
        height:auto;
        max-height:520px;
        object-fit:contain;
        background:#f5f6f9;
        border-radius:0;
        user-select:none;
        -webkit-user-drag:none;
    }

    #egKnowledge .k-image-carousel-track{
        touch-action:pan-y pinch-zoom;
        cursor:grab;
    }

    #egKnowledge .k-image-carousel-track:active{
        cursor:grabbing;
    }

    #egKnowledge .k-image-carousel-btn{
        cursor:pointer;
    }

    #egKnowledge .k-image-viewer-modal{
        z-index:2000;
    }

    #egKnowledge .k-image-viewer-modal .modal-dialog,
    #egKnowledge .k-image-viewer-modal .modal-content{
        width:100%;
        height:100%;
        margin:0;
        border:0;
        border-radius:0;
        background:transparent;
    }

    #egKnowledge .k-image-viewer-modal .modal-content{
        position:relative;
        overflow:hidden;
        isolation:isolate;
        color:#fff;
    }

    #egKnowledge .k-image-viewer-backdrop{
        position:absolute;
        inset:0;
        z-index:0;
        background:
            radial-gradient(circle at center, rgba(37,45,63,.72) 0%, rgba(7,11,18,.96) 72%),
            #080b11;
    }

    #egKnowledge .k-image-viewer-toolbar{
        position:absolute;
        left:0;
        right:0;
        top:0;
        z-index:5;
        display:flex;
        align-items:center;
        justify-content:space-between;
        padding:18px 22px;
        pointer-events:none;
    }

    #egKnowledge .k-image-viewer-counter,
    #egKnowledge .k-image-viewer-close{
        pointer-events:auto;
        background:rgba(15,23,42,.68);
        border:1px solid rgba(255,255,255,.13);
        backdrop-filter:blur(12px);
        -webkit-backdrop-filter:blur(12px);
    }

    #egKnowledge .k-image-viewer-counter{
        min-width:52px;
        padding:7px 11px;
        border-radius:999px;
        text-align:center;
        font-size:11px;
        font-weight:800;
        line-height:1;
        color:#fff;
    }

    #egKnowledge .k-image-viewer-close{
        width:40px;
        height:40px;
        padding:0;
        border-radius:50%;
        color:#fff;
        display:grid;
        place-items:center;
        cursor:pointer;
        box-shadow:0 10px 30px rgba(0,0,0,.18);
        transition:transform .16s ease, background .16s ease;
    }

    #egKnowledge .k-image-viewer-close:hover{
        transform:scale(1.05);
        background:rgba(15,23,42,.84);
    }

    #egKnowledge .k-image-viewer-close i{
        font-size:21px;
    }

    #egKnowledge .k-image-viewer-stage{
        position:absolute;
        inset:68px 0 118px;
        z-index:2;
        display:flex;
        align-items:center;
        justify-content:center;
        padding:0 76px;
    }

    #egKnowledge .k-image-viewer-image-wrap{
        width:min(1180px, 90vw);
        height:100%;
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:center;
        position:relative;
        min-width:0;
    }

    #egKnowledge .k-image-viewer-image{
        display:block;
        max-width:100%;
        max-height:100%;
        width:auto;
        height:auto;
        object-fit:contain;
        border-radius:10px;
        box-shadow:0 24px 80px rgba(0,0,0,.38);
        user-select:none;
        -webkit-user-drag:none;
        transition:opacity .16s ease, transform .16s ease;
    }

    #egKnowledge .k-image-viewer-image.is-loading{
        opacity:.15;
        transform:scale(.985);
    }

    #egKnowledge .k-image-viewer-loading{
        position:absolute;
        left:50%;
        top:50%;
        transform:translate(-50%,-50%);
        z-index:2;
        color:#fff;
        display:none;
    }

    #egKnowledge .k-image-viewer-loading.show{
        display:block;
    }

    #egKnowledge .k-image-viewer-caption{
        max-width:min(780px, 86vw);
        margin-top:12px;
        padding:6px 11px;
        border-radius:999px;
        background:rgba(15,23,42,.58);
        backdrop-filter:blur(10px);
        -webkit-backdrop-filter:blur(10px);
        color:rgba(255,255,255,.92);
        font-size:10px;
        font-weight:700;
        line-height:1.35;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
    }

    #egKnowledge .k-image-viewer-nav{
        position:absolute;
        top:50%;
        transform:translateY(-50%);
        width:46px;
        height:46px;
        border:1px solid rgba(255,255,255,.14);
        border-radius:50%;
        background:rgba(15,23,42,.62);
        color:#fff;
        display:grid;
        place-items:center;
        z-index:4;
        cursor:pointer;
        box-shadow:0 12px 36px rgba(0,0,0,.2);
        backdrop-filter:blur(12px);
        -webkit-backdrop-filter:blur(12px);
        transition:opacity .16s ease, transform .16s ease, background .16s ease;
    }

    #egKnowledge .k-image-viewer-nav:hover{
        background:rgba(15,23,42,.84);
        transform:translateY(-50%) scale(1.04);
    }

    #egKnowledge .k-image-viewer-nav:disabled{
        opacity:0;
        pointer-events:none;
    }

    #egKnowledge .k-image-viewer-nav.prev{
        left:18px;
    }

    #egKnowledge .k-image-viewer-nav.next{
        right:18px;
    }

    #egKnowledge .k-image-viewer-nav i{
        font-size:25px;
    }

    #egKnowledge .k-image-viewer-bottom{
        position:absolute;
        left:0;
        right:0;
        bottom:0;
        z-index:5;
        display:flex;
        flex-direction:column;
        align-items:center;
        gap:8px;
        padding:10px 16px 18px;
        pointer-events:none;
    }

    #egKnowledge .k-image-viewer-thumbs{
        width:min(760px, 92vw);
        display:flex;
        gap:7px;
        align-items:center;
        justify-content:center;
        overflow-x:auto;
        padding:5px 2px;
        scrollbar-width:none;
        pointer-events:auto;
        scroll-behavior:smooth;
    }

    #egKnowledge .k-image-viewer-thumbs::-webkit-scrollbar{
        display:none;
    }

    #egKnowledge .k-image-viewer-thumb{
        width:58px;
        height:48px;
        flex:0 0 58px;
        padding:0;
        border:1px solid rgba(255,255,255,.18);
        border-radius:8px;
        overflow:hidden;
        background:#10151e;
        opacity:.55;
        cursor:pointer;
        transition:opacity .16s ease, transform .16s ease, border-color .16s ease;
    }

    #egKnowledge .k-image-viewer-thumb:hover{
        opacity:.85;
        transform:translateY(-1px);
    }

    #egKnowledge .k-image-viewer-thumb.active{
        opacity:1;
        border-color:rgba(255,255,255,.92);
        box-shadow:0 0 0 2px rgba(255,255,255,.13);
    }

    #egKnowledge .k-image-viewer-thumb img{
        width:100%;
        height:100%;
        object-fit:cover;
        display:block;
    }

    #egKnowledge .k-image-viewer-hint{
        padding:5px 9px;
        border-radius:999px;
        background:rgba(15,23,42,.55);
        color:rgba(255,255,255,.72);
        font-size:8px;
        font-weight:700;
        backdrop-filter:blur(10px);
        -webkit-backdrop-filter:blur(10px);
    }

    /* Instagram-style horizontal image carousel for posts containing multiple images. */
    #egKnowledge .k-image-carousel{
        position:relative;
        overflow:hidden;
        border:1px solid #edf0f4;
        border-radius:12px;
        background:#f5f6f9;
    }

    #egKnowledge .k-image-carousel-track{
        display:flex;
        width:100%;
        overflow-x:auto;
        overscroll-behavior-x:contain;
        scroll-snap-type:x mandatory;
        scroll-behavior:smooth;
        scrollbar-width:none;
        -webkit-overflow-scrolling:touch;
    }

    #egKnowledge .k-image-carousel-track::-webkit-scrollbar{
        display:none;
    }

    #egKnowledge .k-image-slide{
        position:relative;
        flex:0 0 100%;
        min-width:100%;
        scroll-snap-align:start;
        scroll-snap-stop:always;
        display:flex;
        align-items:center;
        justify-content:center;
        min-height:250px;
        max-height:520px;
        background:#f5f6f9;
    }

    #egKnowledge .k-image-slide a{
        width:100%;
        height:100%;
        min-height:250px;
        display:flex;
        align-items:center;
        justify-content:center;
        text-decoration:none;
    }

    #egKnowledge .k-image-slide img{
        display:block;
        width:100%;
        height:auto;
        max-height:520px;
        object-fit:contain;
        background:#f5f6f9;
        border-radius:0;
    }

    #egKnowledge .k-image-carousel-btn{
        position:absolute;
        top:50%;
        transform:translateY(-50%);
        z-index:3;
        width:34px;
        height:34px;
        padding:0;
        border:0;
        border-radius:50%;
        display:flex;
        align-items:center;
        justify-content:center;
        background:rgba(15,23,42,.68);
        color:#fff;
        box-shadow:0 5px 16px rgba(15,23,42,.18);
        transition:opacity .15s ease, transform .15s ease, background .15s ease;
    }

    #egKnowledge .k-image-carousel-btn:hover{
        background:rgba(15,23,42,.82);
        transform:translateY(-50%) scale(1.04);
    }

    #egKnowledge .k-image-carousel-btn:disabled{
        opacity:0;
        pointer-events:none;
    }

    #egKnowledge .k-image-carousel-btn.prev{
        left:10px;
    }

    #egKnowledge .k-image-carousel-btn.next{
        right:10px;
    }

    #egKnowledge .k-image-carousel-count{
        position:absolute;
        top:10px;
        right:10px;
        z-index:3;
        display:inline-flex;
        align-items:center;
        min-height:24px;
        padding:4px 8px;
        border-radius:999px;
        background:rgba(15,23,42,.68);
        color:#fff;
        font-size:9px;
        font-weight:800;
        line-height:1;
        pointer-events:none;
        backdrop-filter:blur(5px);
    }

    #egKnowledge .k-image-carousel-dots{
        position:absolute;
        left:50%;
        bottom:10px;
        transform:translateX(-50%);
        z-index:3;
        display:flex;
        align-items:center;
        justify-content:center;
        gap:5px;
        max-width:70%;
        padding:5px 8px;
        border-radius:999px;
        background:rgba(15,23,42,.48);
        backdrop-filter:blur(5px);
    }

    #egKnowledge .k-image-carousel-dot{
        width:6px;
        height:6px;
        padding:0;
        border:0;
        border-radius:50%;
        background:rgba(255,255,255,.55);
        box-shadow:none;
    }

    #egKnowledge .k-image-carousel-dot.active{
        width:7px;
        height:7px;
        background:#fff;
    }

    #egKnowledge .k-image-carousel-hint{
        position:absolute;
        left:50%;
        bottom:10px;
        transform:translateX(-50%);
        z-index:2;
        color:#fff;
        font-size:8px;
        font-weight:800;
        background:rgba(15,23,42,.52);
        padding:4px 8px;
        border-radius:999px;
        pointer-events:none;
        white-space:nowrap;
    }

    @media(max-width:600px){
        #egKnowledge .k-image-slide,
        #egKnowledge .k-image-slide a{
            min-height:205px;
        }

        #egKnowledge .k-image-slide img{
            max-height:440px;
        }

        #egKnowledge .k-image-carousel-btn{
            width:30px;
            height:30px;
        }
    }

    @media(prefers-reduced-motion:reduce){
        #egKnowledge .k-image-carousel-track{
            scroll-behavior:auto;
        }
    }

    #egKnowledge .k-post-media audio{
        width:100%;
    }

    #egKnowledge .k-media-file{
        display:flex;
        align-items:center;
        gap:10px;
        padding:10px;
        border:1px solid #e8ecf2;
        border-radius:9px;
        background:#fbfcfe;
        color:#334763;
        text-decoration:none;
    }

    #egKnowledge .k-media-file:hover{
        background:#f7f8fb;
        border-color:#ccd3df;
    }

    #egKnowledge .k-media-file i{
        font-size:21px;
        color:var(--k-red);
    }

    #egKnowledge .k-media-file-main{
        min-width:0;
        flex:1;
    }

    #egKnowledge .k-media-file-name{
        font-size:9px;
        font-weight:800;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }

    #egKnowledge .k-media-file-meta{
        margin-top:2px;
        font-size:8px;
        color:#929bab;
    }

    #egKnowledge .k-share-tabs{
        display:grid;
        grid-template-columns:repeat(4,minmax(0,1fr));
        gap:6px;
        margin-bottom:12px;
    }

    #egKnowledge .k-share-tab{
        border:1px solid var(--k-border);
        background:#fff;
        border-radius:8px;
        padding:8px 5px;
        display:flex;
        align-items:center;
        justify-content:center;
        gap:4px;
        font-size:8px;
        font-weight:800;
        color:#68758a;
    }

    #egKnowledge .k-share-tab i{
        font-size:15px;
    }

    #egKnowledge .k-share-tab.active{
        color:var(--k-red);
        border-color:var(--k-red);
        background:rgba(181,43,37,.05);
    }

    #egKnowledge .k-share-panel,
    #egKnowledge .k-share-link-box{
        border:1px solid #edf0f4;
        border-radius:10px;
        padding:11px;
        background:#fbfcfe;
    }

    #egKnowledge .k-share-link-box{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
    }

    #egKnowledge .k-share-link-box .fw-bold{
        font-size:9px;
        color:#344662;
    }

    #egKnowledge .k-share-existing{
        /* border-top:1px solid #edf0f4; */
        padding-top:10px;
    }

    #egKnowledge .k-library-button{
        width:100%;
        border:0;
        background:transparent;
        padding:0;
        text-align:left;
        color:inherit;
    }

    @media(max-width:600px){
        #egKnowledge .k-content-types{
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        #egKnowledge .k-share-tabs{
            grid-template-columns:repeat(2,minmax(0,1fr));
        }
    }

    #egKnowledge .k-empty{
        padding:65px 20px;
        text-align:center;
        color:#8290a4;
    }

    #egKnowledge .k-empty i{
        font-size:36px;
        display:block;
        margin-bottom:9px;
        color:#c0c7d3;
    }

    #egKnowledge .k-form-hint{
        /* font-size:8px;
        color:#8a96a6; */
        margin-top:3px;
    }

    @media(max-width:1180px){
        #egKnowledge .k-shell{
            grid-template-columns:235px minmax(0,1fr);
        }
        #egKnowledge .k-right{
            display:none;
        }
    }

    @media(max-width:920px){
        #egKnowledge .k-shell{
            grid-template-columns:1fr;
        }
        #egKnowledge .k-sidebar{
            position:static;
            order:2;
        }
        .k-sidebar .k-cat-list{
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:2px;
        }
        #egKnowledge .k-feed-head{
            align-items:flex-start;
            flex-direction:column;
        }
        #egKnowledge .k-type-pills{
            justify-content:flex-start;
        }
    }
    @media(max-width:600px){
        #egKnowledge{
            padding:6px 9px 18px;
        }
        #egKnowledge .k-feed-title{
            /* font-size:17px; */
        }
        #egKnowledge .k-type-pills{
            gap:5px;
        }
        #egKnowledge .k-type-pill{
            /* padding:5px 9px; */
        }
        #egKnowledge .k-post-head{
            padding:12px;
        }
        #egKnowledge .k-post-body{
            padding:0 12px 10px;
        }
        #egKnowledge .k-post-actions{
            padding:9px 12px;gap:12px;
        }
    }
</style>

<div id="egKnowledge" class="eg-knowledge-page">

    <div class="card card-action">
        <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
            <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Knowledge Panel </h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> Tool Mangement
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                            Knowledge Panel
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex align-items-center justify-content-between gap-2">
                <div class="k-type-pills" id="kTypePills"></div>
            </div>
        </div>
        <div class="card-body">
            
        
            <div class="row">
                <div class="col-lg-12">
                    <div class="k-shell pt-2 px-2 bg-light">
                        <aside class="k-sidebar" id="kSidebar"></aside>
                        <main class="k-main">
                            <div class="k-feed-head">
                                <div class="d-flex align-items-center gap-2 min-w-0">
                                    <h1 class="k-feed-title fs-3 fw-bold" id="kFeedTitle">All categories</h1>
                                    <!-- <span class="k-live-status" id="kLiveStatus" aria-live="polite">
                                        <span class="k-live-dot" id="kLiveDot"></span>Live
                                    </span> -->
                                </div>
                            </div>
                            <div class="k-live-new-banner" id="kLiveNewBanner" role="status" aria-live="polite">
                                <span><i class="mdi mdi-bell-ring-outline me-1"></i><span id="kLiveNewText">New Knowledge available</span></span>
                                <button type="button" id="kLiveNewView">View latest</button>
                            </div>
                            <div id="kWorkspace"><div class="k-loading" aria-label="Loading Knowledge Panel" aria-busy="true"></div></div>
                        </main>
                        <aside class="k-right" id="kRight"></aside>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- modals Start -->
    <div id="kSettingsModal" class="modal fade k-settings-modal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content">
                <div class="k-settings-head">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="btn btn-label-primary rounded-circle p-2 d-flex align-items-center justify-content-center" style="width:42px;height:42px">
                                <i class="mdi mdi-shape-outline fs-5"></i>
                            </div>
                            <div>
                                <div class="small text-muted fw-semibold">Knowledge Panel</div>
                                <h5 class="mb-0 fw-bold">Manage Categories</h5>
                                <div class="small text-muted mt-1">Add, update and activate or deactivate categories used by Knowledge posts.</div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary fw-bold" id="kSettingsAddBtn">
                            <i class="mdi mdi-plus me-1"></i> Add Category
                        </button>
                    </div>
                </div>

                <div class="modal-body px-3 px-lg-4 py-3">
                    <div id="kSettingsAlert" class="alert d-none py-2 mb-3"></div>

                    <div class="k-settings-tabs">
                        <button type="button" class="k-settings-tab active" data-ksettings-tab="categories">
                            <i class="mdi mdi-shape-outline me-1"></i> Categories
                        </button>
                    </div>

                    <div id="kSettingsFormPanel" class="k-settings-form mb-3 d-none">
                        <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
                            <div>
                                <div class="k-settings-form-title" id="kSettingsFormTitle">Add Category</div>
                                <div class="small text-muted" id="kSettingsFormSubtitle">Create a category used by Knowledge posts.</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-light" id="kSettingsFormCloseBtn">Cancel</button>
                        </div>

                        <form id="kSettingsForm" novalidate>
                            <input type="hidden" id="kSettingsFormId">
                            <input type="hidden" id="kSettingsFormKind">

                            <div id="kSettingsFormBody"></div>

                            <div class="alert alert-danger d-none mt-3 mb-0" id="kSettingsFormError"></div>

                            <div class="mt-3 d-flex justify-content-end gap-2">
                                <button type="button" class="btn btn-light" id="kSettingsFormCancelBtn">Cancel</button>
                                <button type="submit" class="btn btn-primary fw-bold" id="kSettingsSaveBtn">
                                    <span id="kSettingsSaveLabel"><i class="mdi mdi-content-save-outline me-1"></i> Save Category</span>
                                    <span id="kSettingsSaveLoading" class="d-none"><span class="spinner-border spinner-border-sm me-2"></span> Saving...</span>
                                </button>
                            </div>
                        </form>
                    </div>

                    <div id="kSettingsBody"></div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div id="kPostModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <div class="k-modal-kicker fs-9 fw-semibold text-dark">CREATE KNOWLEDGE</div>
                        <h5 class="modal-title" id="kPostTitle">Create Knowledge Post</h5>
                        <div class="small text-muted">Choose a format, write the content, and select exactly who can access it.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="kPostForm" novalidate>
                    <div class="modal-body" id="kPostBody">
                        <input type="hidden" id="kPostType" name="content_type" value="text">

                        <div class="mb-3">
                            <div class="k-field-label mb-2 text-black fs-8 fw-semibold">Post type</div>
                            <div id="kPostTypeCards" class="k-content-types">
                                <button type="button" class="k-content-type fs-8 fw-semibold text-dark active" data-k-post-type="text"><i class="mdi mdi-format-text"></i><span>Text</span></button>
                                <button type="button" class="k-content-type fs-8 fw-semibold text-dark" data-k-post-type="image"><i class="mdi mdi-image-outline"></i><span>Image</span></button>
                                <button type="button" class="k-content-type fs-8 fw-semibold text-dark" data-k-post-type="video"><i class="mdi mdi-video-outline"></i><span>Video</span></button>
                                <button type="button" class="k-content-type fs-8 fw-semibold text-dark" data-k-post-type="audio"><i class="mdi mdi-music-note-outline"></i><span>Audio</span></button>
                                <button type="button" class="k-content-type fs-8 fw-semibold text-dark" data-k-post-type="pdf"><i class="mdi mdi-file-pdf-box"></i><span>Pdf</span></button>
                                <button type="button" class="k-content-type fs-8 fw-semibold text-dark" data-k-post-type="url"><i class="mdi mdi-link-variant"></i><span>Url</span></button>
                                <button type="button" class="k-content-type fs-8 fw-semibold text-dark" data-k-post-type="files"><i class="mdi mdi-file-multiple-outline"></i><span>Files</span></button>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label  text-black fs-8 fw-semibold">Title <span class="text-danger">*</span></label>
                                <input class="form-control" id="kPostTitleField" name="title" type="text" maxlength="220" placeholder="Give your knowledge a clear, searchable title" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label  text-black fs-8 fw-semibold">Status <span class="text-danger">*</span></label>
                                <select class="form-select select3" id="kPostStatus" name="status" required>
                                    <option value="published" selected>Publish now</option>
                                    <option value="draft">Save draft</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label  text-black fs-8 fw-semibold">Category <span class="text-danger">*</span></label>
                                <select class="form-select select3" id="kPostCategory" name="category_id" required>
                                    <option value="">Choose category</option>
                                </select>
                            </div>
                        </div>

                        <div id="kPostAudienceBuilder" class="mt-3">
                            <div class="k-audience-builder">
                                <div class="d-flex align-items-start justify-content-between gap-2 mb-2">
                                    <div>
                                        <div class="fw-bold" style="font-size:10px">Audience</div>
                                        <div class="k-form-hint fs-9 text-muted">Choose who can access this Knowledge content.</div>
                                    </div>
                                    <span class="k-audience-chip fs-9 text-dark fw-semibold" id="kPostAudienceModeChip"><i class="mdi mdi-office-building-outline"></i> Company</span>
                                </div>
                                <div class="k-audience-modes" id="kPostAudienceModes">
                                    <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold active" data-k-audience-mode="company"><i class="mdi mdi-office-building-outline"></i><span>Company</span></button>
                                    <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="entity"><i class="mdi mdi-domain"></i><span>Entity</span></button>
                                    <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="role"><i class="mdi mdi-account-badge-outline"></i><span>Role</span></button>
                                    <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="staff"><i class="mdi mdi-account-multiple-outline"></i><span>Staff</span></button>
                                </div>
                                <div id="kPostAudienceSummary" class="k-audience-selection"></div>

                                <div id="kPostAudienceFields" class="k-audience-fields">
                                    <div class="k-audience-field" data-k-audience-panel="company">
                                        <label class="form-label fs-8 text-dark fw-semibold">Companies <span class="text-muted fs-9">Select one or more</span></label>
                                        <select class="form-select select3" id="kPostAudienceCompany" name="audience_company_ids[]" multiple size="4" aria-label="Companies">

                                        </select>
                                    </div>
                                    <div class="k-audience-field d-none" data-k-audience-panel="entity">
                                        <label class="form-label fs-8 text-dark fw-semibold">Entities <span class="text-muted fs-9">Select one or more</span></label>
                                        <select class="form-select select3" id="kPostAudienceEntity" name="audience_entity_ids[]" multiple size="4" aria-label="Entities">

                                        </select>
                                    </div>
                                    <div class="k-audience-field d-none" data-k-audience-panel="role">
                                        <div class="mb-3">
                                            <label class="form-label fs-8 text-dark fw-semibold">Entities <span class="text-muted fs-9">Roles are loaded from these entities</span></label>
                                            <select class="form-select select3" id="kPostAudienceRoleEntity" multiple size="4" aria-label="Role entities" onchange="postRoleEntityChangeFunction()">

                                            </select>
                                        </div>
                                        <label class="form-label fs-8 text-dark fw-semibold">Roles <span class="text-muted fs-9">Select one or more</span></label>
                                        <select class="form-select select3" id="kPostAudienceRole" name="audience_role_ids[]" multiple size="4" aria-label="Roles" ></select>
                                    </div>
                                    <div class="k-audience-field  d-none" data-k-audience-panel="staff">
                                        <div class="mb-3">
                                            <label class="form-label fs-8 text-dark fw-semibold">Entities <span class="text-muted fs-9">Staff are loaded from these entities</span></label>
                                            <select class="form-select select3" id="kPostAudienceStaffEntity" multiple size="4" aria-label="Staff entities" onchange="postStaffEntityChangeFunction()"></select>
                                        </div>
                                        <label class="form-label fs-8 text-dark fw-semibold">Staff <span class="text-muted fs-9">Select one or more</span></label>
                                        <select class="form-select select3" id="kPostAudienceStaff" name="audience_staff_ids[]" multiple size="4" aria-label="Staff"></select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="kPostContentArea" class="mt-3">
                            <div class="k-editor-section" data-k-post-content-panel="text">
                                <label class="k-field-label mb-2 text-black fs-8 fw-semibold">Knowledge content</label>
                                <textarea class="d-none" id="kPostContent" name="body_html"></textarea>
                                <div class="k-text-editor-wrap"><div id="kPostContentEditor"></div></div>
                                <div class="k-form-hint mt-2 fs-9 text-muted">Format your knowledge with headings, lists, links, quotes and code blocks.</div>
                            </div>
                            <div class="k-editor-section d-none" data-k-post-content-panel="url">
                                <label class="k-field-label mb-2 text-black fs-8 fw-semibold">Resource URL</label>
                                <input class="form-control" id="kPostUrl" name="post_url" type="url" placeholder="https://example.com/help/article">
                                <div id="kUrlPreview" class="mt-2 d-none"></div>
                                <label class="k-field-label mt-3 mb-2 text-black fs-8 fw-semibold">Description <span class="text-muted">(optional)</span></label>
                                <textarea class="form-control" id="kPostUrlDescription" name="url_description" rows="4" placeholder="Explain why this resource is useful…"></textarea>
                            </div>
                            <div class="k-editor-section d-none" data-k-post-content-panel="media">
                                <label class="k-field-label mb-2 text-black fs-8 fw-semibold" id="kPostMediaLabel">Attachment</label>
                                <label class="k-media-drop" for="kPostMedia">
                                    <i class="mdi mdi-upload-outline"></i>
                                    <span id="kPostMediaAction" class="fs-8 text-dark fw-semibold">Click to choose a file</span>
                                    <span id="kPostMediaDescription" class="fs-9 text-muted fw-light">Share supporting content · Up to 50 MB per file</span>
                                </label>
                                <input class="d-none" type="file" id="kPostMedia" name="media[]">
                                <div id="kPostMediaPreview" class="k-media-preview-list"></div>
                                <div class="k-form-hint mt-2 fs-9 text-muted">Only supported file types are accepted by the Knowledge service.</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="kPostSave"><i class="mdi mdi-send-outline"></i> Publish</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="kShareModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <div class="k-modal-kicker fs-9 fw-semibold text-dark">KNOWLEDGE</div>
                        <h5 class="modal-title mb-1" id="kShareTitle">Share Knowledge</h5>
                        <div class="small text-muted" id="kShareSubtitle"></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="kShareForm" novalidate>
                    <div class="modal-body">
                        <input type="hidden" name="resource_id" id="kShareResourceId">

                        <div class="k-audience-builder">
                            <div class="d-flex align-items-start justify-content-between gap-2 mb-2">
                                <div>
                                    <div class="fw-bold" style="font-size:10px">Share audience</div>
                                    <div class="k-form-hint fs-9 text-muted">Choose exactly who should receive access to this post.</div>
                                </div>
                                <span class="k-audience-chip fs-9 text-dark fw-semibold" id="kShareAudienceModeChip"><i class="mdi mdi-office-building-outline"></i> Company</span>
                            </div>
                            <div class="k-audience-modes" id="kShareAudienceModes">
                                <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold active" data-k-audience-mode="company"><i class="mdi mdi-office-building-outline"></i><span>Company</span></button>
                                <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="entity"><i class="mdi mdi-domain"></i><span>Entity</span></button>
                                <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="role"><i class="mdi mdi-account-badge-outline"></i><span>Role</span></button>
                                <button type="button" class="k-audience-mode fs-8 text-dark fw-semibold" data-k-audience-mode="staff"><i class="mdi mdi-account-multiple-outline"></i><span>Staff</span></button>
                            </div>
                            <div id="kShareAudienceSummary" class="k-audience-selection"></div>
                            <div id="kShareAudienceFields" class="k-audience-fields">
                                <div class="k-audience-field" data-k-audience-panel="company">
                                    <label class="form-label  text-black fs-8 fw-semibold">Companies <span class="text-muted">Select one or more</span></label>
                                    <select class="form-select select3" id="kShareAudienceCompany" name="audience_company_ids[]" multiple size="4" aria-label="Share companies"></select>
                                </div>
                                <div class="k-audience-field d-none" data-k-audience-panel="entity">
                                    <label class="form-label  text-black fs-8 fw-semibold">Entities <span class="text-muted">Select one or more</span></label>
                                    <select class="form-select select3" id="kShareAudienceEntity" name="audience_entity_ids[]" multiple size="4" aria-label="Share entities"></select>
                                </div>
                                <div class="k-audience-field d-none" data-k-audience-panel="role">
                                    <div class="mb-3">
                                        <label class="form-label  text-black fs-8 fw-semibold">Entities <span class="text-muted">Roles are loaded from these entities</span></label>
                                        <select class="form-select select3" id="kShareAudienceRoleEntity" multiple size="4" aria-label="Share role entities"  onchange="shareRoleEntityChangeFunction()"></select>
                                    </div>
                                    <label class="form-label  text-black fs-8 fw-semibold">Roles <span class="text-muted">Select one or more</span></label>
                                    <select class="form-select select3" id="kShareAudienceRole" name="audience_role_ids[]" multiple size="4" aria-label="Share roles"></select>
                                </div>
                                <div class="k-audience-field d-none" data-k-audience-panel="staff">
                                    <div class="mb-3">
                                        <label class="form-label  text-black fs-8 fw-semibold">Entities <span class="text-muted">Staff are loaded from these entities</span></label>
                                        <select class="form-select select3" id="kShareAudienceStaffEntity" multiple size="4" aria-label="Share staff entities"  onchange="shareStaffEntityChangeFunction()"></select>
                                    </div>
                                    <label class="form-label  text-black fs-8 fw-semibold">Staff <span class="text-muted">Select one or more</span></label>
                                    <select class="form-select select3" id="kShareAudienceStaff" name="audience_staff_ids[]" multiple size="4" aria-label="Share staff"></select>
                                </div>
                            </div>
                        </div>

                        <div class="row g-3 mt-1">
                            <div class="col-md-6">
                                <label class="form-label text-black fs-8 fw-semibold">Permission</label>
                                <select class="form-select select3" id="kSharePermission" name="permission">
                                    <option value="View" selected>View only</option>
                                    <option value="Manage">Can manage</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-black fs-8 fw-semibold">Expires <span class="text-muted">(optional)</span></label>
                                <input class="form-control" type="text" name="expires_at" id="kShareExpiresAt">
                            </div>
                        </div>

                        <!-- <div class="k-share-link-box mt-3">
                            <div>
                                <div class="fw-bold">Quick share</div>
                                <div class="k-form-hint">Copy the Knowledge link or use your device share menu.</div>
                            </div>
                            <button type="button" class="btn btn-light btn-sm" id="kShareCopyLink"><i class="mdi mdi-link-variant me-1"></i>Copy link</button>
                        </div> -->
                        <div id="kShareExisting" class="mt-3 d-none"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="kShareSave"><i class="mdi mdi-share-variant-outline me-1"></i>Share</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="kDetailModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered "><div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title" id="kDetailTitle">Knowledge</h5><div class="small text-muted" id="kDetailSubtitle"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body" id="kDetailBody"></div>
        </div></div>
    </div>

    <div id="kImageViewerModal"
         class="modal fade k-image-viewer-modal"
         tabindex="-1"
         aria-hidden="true"
         data-bs-backdrop="static">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="k-image-viewer-backdrop" data-k-image-viewer-close></div>

                <div class="k-image-viewer-toolbar">
                    <div class="k-image-viewer-counter" id="kImageViewerCounter">1 / 1</div>
                    <button type="button"
                            class="k-image-viewer-close"
                            data-k-image-viewer-close
                            aria-label="Close image viewer">
                        <i class="mdi mdi-close"></i>
                    </button>
                </div>

                <div class="k-image-viewer-stage">
                    <button type="button"
                            class="k-image-viewer-nav prev"
                            id="kImageViewerPrev"
                            aria-label="Previous image">
                        <i class="mdi mdi-chevron-left"></i>
                    </button>

                    <div class="k-image-viewer-image-wrap">
                        <div class="k-image-viewer-loading" id="kImageViewerLoading">
                            <span class="spinner-border"></span>
                        </div>
                        <img id="kImageViewerImage"
                             class="k-image-viewer-image"
                             tabindex="-1"
                             src=""
                             alt="">
                        <div class="k-image-viewer-caption" id="kImageViewerCaption"></div>
                    </div>

                    <button type="button"
                            class="k-image-viewer-nav next"
                            id="kImageViewerNext"
                            aria-label="Next image">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>
                </div>

                <div class="k-image-viewer-bottom">
                    <div class="k-image-viewer-thumbs"
                         id="kImageViewerThumbs"
                         aria-label="Image thumbnails"></div>
                    <div class="k-image-viewer-hint d-none" id="kImageViewerHint">
                        <i class="mdi mdi-swipe-horizontal me-1"></i>
                        Swipe to browse
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="kConfirmModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="kConfirmTitle">Confirm</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="kConfirmBody"></div><div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-danger btn-sm" id="kConfirmYes">Continue</button></div></div></div>
    </div>
    <!-- modals End -->
</div>


<script>
    const addNewPost = @json($add_post);
    const sharePost = @json($share_post);
    const manageCategory = @json($manage_category);
    const config = @js(
        [
            'module' => 'knowledge',
            'csrf' => csrf_token(),
            'routes' => [
                'categories'=>route('productivity.knowledge.categories'),
                'data'=>route('productivity.knowledge.data'),
                'settings'=>route('productivity.knowledge.settings.data'),
                'categoryStore'=>route('productivity.knowledge.settings.category.store'),
                'categoryUpdate'=>url('/productivity/knowledge/settings/categories'),
                'categoryDelete'=>url('/productivity/knowledge/settings/categories'),
                'categoryStatus'=>url('/productivity/knowledge/settings/categories_status'),
                'store'=>route('productivity.knowledge.store'),
                'show'=>url('/productivity/knowledge'),
                'update'=>url('/productivity/knowledge'),
                'like'=>url('/productivity/knowledge/{id}/like'),
                'save'=>url('/productivity/knowledge/{id}/save'),
                'reply'=>url('/productivity/knowledge'),
                'report'=>url('/productivity/knowledge'),
                'follow'=>url('/productivity/knowledge/categories/__ID__/follow'),
                'companies'=>route('productivity.companies'),
                'users'=>route('productivity.users'),
                'audienceOptions'=>route('productivity.knowledge.audience.options'),
                'knowledgeShares'=>url('/productivity/knowledge/{id}/shares'),
                'knowledgeShareStore'=>url('/productivity/knowledge/{id}/shares'),
                'shares'=>route('productivity.shares.data'),
                'shareStore'=>route('productivity.shares.store'),
                'shareRevoke'=>url('/productivity/shares'),
                'media'=>url('/productivity/knowledge/{id}/media')

            ],
        ]);

    const R = config.routes || {};
    const state = {
        page:1,
        perPage:10,
        search:'',
        category:'',
        categoryName:'All categories',
        contentType:'all',
        categories:[],
        settings:{
            categories:[],
                can_manage:false,
            is_group_admin:false,
            is_company_admin:false
        },
        currentPost:null,
        library:false,
        postType:'text',
        audience:{post:{mode:'company'},share:{mode:'company'}},
        loading:false,
        hasMore:true,
        observer:null,
        requestToken:0
    };
    const $ws=$('#kWorkspace');
    $.ajaxSetup({
        headers:{
            'X-CSRF-TOKEN':config.csrf,
            'X-Requested-With':'XMLHttpRequest',
            'Accept':'application/json'
        }
    });

    function esc(v) {
        return $('<div>').text(v==null?'':String(v)).html();
    }

    function url(base,id,suffix) {
        let v=String(base||'').replace(/\/$/,'');
        if(id!==undefined&&id!==null&&id!==''){
            v=v.includes('__ID__')?v.replace('__ID__',encodeURIComponent(id)):v.includes('{id}')?v.replace('{id}',encodeURIComponent(id)):`${v}/${encodeURIComponent(id)}`;
        }
        if(suffix)v=`${v}/${String(suffix).replace(/^\//,'')}`;
        return v;
    }

    function query(p) {
        const q=new URLSearchParams();
        Object.keys(p||{}).forEach(k=>{
            const v=p[k];
            if(v!==undefined&&v!==null&&v!=='')q.set(k,v);
        });
        return q.toString();
    }

    function ajax(method,endpoint,data,opts) {
        const o=opts||{}, isForm=data instanceof FormData;
        return $.ajax({
            url:endpoint,
            method:method||'GET',
            data:data||{},
            processData:!isForm,
            contentType:isForm?false:'application/x-www-form-urlencoded; charset=UTF-8',
            dataType:'json',
            timeout:o.timeout||30000,
            headers:{
                'X-CSRF-TOKEN':config.csrf,
                'X-Requested-With':'XMLHttpRequest',
                'Accept':'application/json'
            }
        }).then(function(res){
            return res;
        }).catch(function(xhr){
            const d=xhr?.responseJSON||xhr;
            if(d?.errors){
                const first=Object.values(d.errors)[0];
                if(Array.isArray(first)&&first[0])d.message=first[0];
            }
            return $.Deferred().reject(d||{
                message:'Server request failed.'
            }).promise();
        });
    }

    function modal(id) {
        return bootstrap.Modal.getOrCreateInstance(document.getElementById(id));
    }

    function notify(message,type) {
        const text=message||'Done.';
        if(typeof toastr==='undefined'){
            console.warn('Toastr is not loaded.',text);
            return;
        }
        if(type==='error')return toastr.error(text);
        if(type==='warning')return toastr.warning(text);
        return toastr.success(text);
    }

    function badge(status) {
        const s=String(status||'').toLowerCase();
        const cls=['active','published'].includes(s)?'egpk-badge-green':['inactive','unpublished','deprecated'].includes(s)?'egpk-badge-red':'egpk-badge-slate';
        return `<span class="egpk-badge ${cls}">${esc(status||'-')}</span>`;
    }

    function knowledgeCategorySignature(categories) {
        return (Array.isArray(categories)?categories:[]).map(c=>[
            c.sno,
            c.category_name,
            c.color,
            c.status,
            c.post_count,
            c.following
        ].join(':')).join('|');
    }

    function loadCategories(options) {
        const opts=options||{};
        return ajax('GET',R.categories).done(function(res){
            const d=res.data||{};
            const next=Array.isArray(d.categories)?d.categories:[];
            const previousSignature=knowledgeCategorySignature(state.categories);
            const nextSignature=knowledgeCategorySignature(next);
            state.categories=next;
            if (opts.render !== false && previousSignature !== nextSignature) {
                renderSidebar();
            }
            if (state.live) state.live.lastCategorySignature=nextSignature;
            if (state.category && !next.some(c=>String(c.sno)===String(state.category))) {
                state.category='';
                state.categoryName='All categories';
                if (opts.keepFeed !== true) {
                    $('#kFeedTitle').text('All categories');
                }
            }
            return res;
        });
    }

    function renderTypes() {
        const items=[['all','All'],['text','Text'],['image','Image'],['video','Video'],['audio','Audio'],['pdf','Pdf'],['url','Url'],['files','Files']];
        $('#kTypePills').html(items.map(x=>`<button type="button" class="k-type-pill badge fs-8  fw-semibold rounded ${state.contentType===x[0]?'active text-white':'text-dark'}" data-k-type="${x[0]}">${x[1]}</button>`).join(''));
    }

    function renderSidebar() {
        const cats=state.categories||[];
        const categoryRows=cats.map(c=>`
                <div class="k-category-row ${!state.library && String(state.category)===String(c.sno)?'active':''} d-flex justify-content-between align-items-center">
                    <button type="button" class="k-category-name fs-7 border-none text-start text-dark fw-semibold p-0 text-nowrap" data-k-category="${esc(c.sno)}">${esc(c.category_name)}</button>
                    <div class="d-flex gap-1 align-items-center">
                        <span class="k-category-count fs-9 badge bg-label-success border border-success rounded-circle">${esc(c.post_count||0)}</span>
                        <button type="button" 
                            class="k-follow fs-7 fw-semibold  ${Number(c.following)?'active ':'text-dark'}" 
                            title="${Number(c.following)?'Unfollow':'Follow'}" 
                            data-egpk-action="follow-category" data-id="${esc(c.sno)}" data-k-no-select>
                            <i class="mdi ${Number(c.following)?'mdi-bell':'mdi-bell-outline'}"></i>
                        </button>
                        <!-- ${manageCategory == 1?
                            `<button type="button" class="k-mini-settings k-inline-gear" 
                                title="Manage category" 
                                data-egpk-action="knowledge-category-inline-settings" 
                                data-id="${esc(c.sno)}" data-k-no-select>
                                    <i class="mdi mdi-cog-outline"></i>
                            </button>`
                        :''} -->
                    </div>
                </div>`).join('');
                    
        const settingsButton=manageCategory == 1? `
            <button type="button" 
                class="k-mini-settings border-none text-dark fw-bold fs-6 bg-white" title="Manage categories" 
                data-egpk-action="knowledge-categories-settings">
                    <i class="mdi mdi-cog-outline"></i>
                    </button>`
            :'';

        $('#kSidebar').html(`
                ${addNewPost == 1 ?
                `<button type="button" class="k-new-post fs-6 fw-bold" 
                data-egpk-action="new-knowledge">
                    <i class="mdi mdi-square-edit-outline me-1 fs-6 fw-bold"></i>New Post
                </button>` : ''
                }
                <div class="k-side-title-row">
                    <span class="k-side-title fs-6 fw-semibold">All categories</span>
                    ${settingsButton}
                </div>
                <div class="k-cat-list">
                    <div class="k-category-row ${!state.library && state.category===''?'active':''}">
                    <button type="button" class="k-category-name fs-7 border-none text-start text-dark fw-semibold p-0 text-nowrap" data-k-category="">
                        All categories
                    </button>
                <span class="k-category-count fs-9 badge bg-label-success border border-success rounded-circle">${cats.reduce((n,c)=>n+Number(c.post_count||0),0)}</span>
                <span></span>
                </div>${categoryRows}</div>
        `);
    }

    function formatFileSize(bytes) {
        const size = Number(bytes || 0);
        if (!size) return '0 KB';
        if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} KB`;
        return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    }

    function mediaIcon(media) {
        const type = String(media?.media_type || '').toLowerCase();
        if (type === 'image') return 'mdi-image-outline';
        if (type === 'video') return 'mdi-video-outline';
        if (type === 'audio') return 'mdi-music-note-outline';
        if (String(media?.mime_type || '').toLowerCase() === 'application/pdf') return 'mdi-file-pdf-box';
        return 'mdi-file-outline';
    }

    function renderMedia(mediaRows) {
        const rows = Array.isArray(mediaRows) ? mediaRows : [];
        if (!rows.length) return '';

        /*
         * The Knowledge media endpoint can contain the same image more than once
         * for a post (for example after an upload/update cycle). The UI must never
         * count or render those duplicates as separate carousel slides.
         *
         * Prefer the database media id when available, otherwise fall back to the
         * secure URL. Keep the first occurrence and preserve display order.
         */
        const seenMediaIds = new Set();
        const seenMediaUrls = new Set();
        const uniqueRows = rows
            .map((media, originalIndex) => ({
                media,
                originalIndex,
                displayOrder: Number.isFinite(Number(media?.display_order))
                    ? Number(media.display_order)
                    : originalIndex,
                mediaId: String(media?.sno ?? '').trim(),
                mediaUrl: String(media?.url ?? '').trim()
            }))
            .sort((a, b) => a.displayOrder - b.displayOrder || a.originalIndex - b.originalIndex)
            .filter(item => {
                /*
                 * Treat a repeated database media id OR repeated secure URL as
                 * the same slide. This covers duplicate API rows and prevents
                 * the carousel counter from showing more images than were
                 * actually uploaded to the post.
                 */
                if (item.mediaId && seenMediaIds.has(item.mediaId)) return false;
                if (item.mediaUrl && seenMediaUrls.has(item.mediaUrl)) return false;

                if (item.mediaId) seenMediaIds.add(item.mediaId);
                if (item.mediaUrl) seenMediaUrls.add(item.mediaUrl);
                return true;
            })
            .map(item => item.media);

        const imageRows = uniqueRows.filter(media =>
            String(media?.media_type || '').toLowerCase() === 'image'
        );
        const otherRows = uniqueRows.filter(media =>
            String(media?.media_type || '').toLowerCase() !== 'image'
        );

        let html = '';

        

        if (imageRows.length > 1) {

            const slideCount = imageRows.length;
            // console.log("slideCount - ",slideCount)    
               
            const slides = imageRows.map((media, index) => {
                const imageUrl = esc(media.url || '');
                const name = esc(media.original_name || `Knowledge image ${index + 1}`);

                if (!imageUrl) {
                    return `<div class="k-image-slide" data-k-image-index="${index}">
                        <div class="k-media-file w-100 m-3">
                            <i class="mdi ${mediaIcon(media)}"></i>
                            <div class="k-media-file-main">
                                <div class="k-media-file-name">${name}</div>
                                <div class="k-media-file-meta">Media is available but its secure link could not be generated.</div>
                            </div>
                        </div>
                    </div>`;
                }

                return `<div class="k-image-slide" data-k-image-index="${index}">
                    <button type="button"
                        class="k-image-slide-open"
                        data-k-image-open
                        data-k-image-index="${index}"
                        aria-label="View ${name}">
                        <img src="${imageUrl}"
                             alt="${name}"
                             loading="${index === 0 ? 'eager' : 'lazy'}"
                             ${index === 0 ? 'fetchpriority="high"' : ''}>
                    </button>
                </div>`;
            }).join('');

            const dots = imageRows.map((_, index) => `
                <button type="button"
                    class="k-image-carousel-dot ${index === 0 ? 'active' : ''}"
                    data-k-image-dot="${index}"
                    aria-label="Go to image ${index + 1}"
                    aria-current="${index === 0 ? 'true' : 'false'}"></button>`
            ).join('');

            html += `<div class="k-image-carousel"
                data-k-image-carousel
                data-k-image-count="${slideCount}">
                <div class="k-image-carousel-track"
                     data-k-image-track
                     tabindex="0"
                     aria-label="Post images, swipe horizontally to view more images">
                    ${slides} 
                </div>

                <button type="button"
                    class="k-image-carousel-btn prev"
                    data-k-image-prev
                    aria-label="Previous image"
                    disabled>
                    <i class="mdi mdi-chevron-left"></i>
                </button>

                <button type="button"
                    class="k-image-carousel-btn next"
                    data-k-image-next
                    aria-label="Next image">
                    <i class="mdi mdi-chevron-right"></i>
                </button>

                <span class="k-image-carousel-count" data-k-image-count-label > 1 / ${slideCount}</span>

                <div class="k-image-carousel-dots"
                     role="tablist"
                     aria-label="Image navigation">
                    ${dots} 
                </div>

                <span class="k-image-carousel-hint ${slideCount > 1 ? '' : 'd-none'}"
                      data-k-image-hint>
                    <i class="mdi mdi-swipe-horizontal me-1"></i>Swipe to explore
                </span>
            </div>`;
             
        } else if (imageRows.length === 1) {
            const media = imageRows[0];
            const imageUrl = esc(media.url || '');
            const name = esc(media.original_name || 'Knowledge image');

            if (imageUrl) {
                html += `<button type="button"
                    class="k-single-image-open"
                    data-k-image-open
                    aria-label="View ${name}">
                    <img src="${imageUrl}" alt="${name}" loading="lazy">
                </button>`;
            } else {
                html += `<div class="k-media-file">
                    <i class="mdi ${mediaIcon(media)}"></i>
                    <div class="k-media-file-main">
                        <div class="k-media-file-name">${name}</div>
                        <div class="k-media-file-meta">Media is available but its secure link could not be generated.</div>
                    </div>
                </div>`;
            }
        }

        otherRows.forEach(media => {
            const mediaUrl = esc(media.url || '');
            const name = esc(media.original_name || 'Knowledge file');
            const type = String(media.media_type || '').toLowerCase();
            const mime = String(media.mime_type || '').toLowerCase();

            if (!mediaUrl) {
                html += `<div class="k-media-file">
                    <i class="mdi ${mediaIcon(media)}"></i>
                    <div class="k-media-file-main">
                        <div class="k-media-file-name">${name}</div>
                        <div class="k-media-file-meta">Media is available but its secure link could not be generated.</div>
                    </div>
                </div>`;
                return;
            }

            if (type === 'video') {
                html += `<video controls preload="metadata">
                    <source src="${mediaUrl}" type="${esc(mime)}">
                    Your browser does not support video playback.
                </video>`;
                return;
            }

            if (type === 'audio') {
                html += `<audio controls preload="metadata">
                    <source src="${mediaUrl}" type="${esc(mime)}">
                    Your browser does not support audio playback.
                </audio>`;
                return;
            }

            html += `<a class="k-media-file"
                href="${mediaUrl}"
                target="_blank"
                rel="noopener noreferrer">
                <i class="mdi ${mediaIcon(media)}"></i>
                <div class="k-media-file-main">
                    <div class="k-media-file-name">${name}</div>
                    <div class="k-media-file-meta">${formatFileSize(media.file_size)} · Open file</div>
                </div>
                <i class="mdi mdi-open-in-new"></i>
            </a>`;
        });

        return `<div class="k-post-media">${html}</div>`;
    }

    function relativeTime(value) {
        if (!value) return '';

        let date = new Date(value);
        if (Number.isNaN(date.getTime())) {
            date = new Date(String(value).replace(' ', 'T'));
        }

        if (Number.isNaN(date.getTime())) return '';

        const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));

        if (seconds < 60) return 'just now';

        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes}m ago`;

        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours}h ago`;

        const days = Math.floor(hours / 24);
        if (days < 7) return `${days}d ago`;

        const weeks = Math.floor(days / 7);
        if (weeks < 5) return `${weeks}w ago`;

        const months = Math.floor(days / 30);
        if (months < 12) return `${months}mo ago`;

        const years = Math.floor(days / 365);
        return `${years}y ago`;
    }

    function absoluteDate(value) {
        if (!value) return '';

        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return String(value);

        return date.toLocaleString(undefined, {
            dateStyle:'medium',
            timeStyle:'short'
        });
    }

    function renderUrlPostCard(preview) {
        const item = preview && typeof preview === 'object' ? preview : null;
        if (!item || !item.url) return '';

        const href = esc(item.url);
        // For URL posts the card title comes from the target page's official
        // HTML <title>, not from the Knowledge post title entered by the user.
        const title = esc(item.site_title || item.title || item.domain || item.url);
        const description = esc(item.description || '');
        const domain = esc(item.domain || '');
        const favicon = esc(item.favicon_url || '');

        return `<a class="k-post-url-card"
            href="${href}"
            target="_blank"
            rel="noopener noreferrer nofollow"
            aria-label="Open ${title}">
            <span class="k-post-url-top">
                <span class="k-post-url-icon" aria-hidden="true">
                    ${favicon
                        ? `<img src="${favicon}" alt="" loading="lazy" data-k-url-favicon>
                           <i class="mdi mdi-link-variant k-post-url-icon-fallback d-none" data-k-url-favicon-fallback></i>`
                        : `<i class="mdi mdi-link-variant k-post-url-icon-fallback"></i>`}
                </span>
                <span class="k-post-url-main">
                    <span class="k-post-url-title">${title}</span>
                    ${domain ? `<span class="k-post-url-domain">${domain}</span>` : ''}
                </span>
                <span class="k-post-url-open" aria-hidden="true">
                    <i class="mdi mdi-open-in-new"></i>
                </span>
            </span>
            ${description ? `<span class="k-post-url-description">${description}</span>` : ''}
        </a>`;
    }

    function renderPost(p) {
        const initials = (
            String(p.author_name || 'ERP User')
                .split(/\s+/)
                .filter(Boolean)
                .slice(0, 2)
                .map(x => x[0])
                .join('') || 'KN'
        ).toUpperCase();

        const liked = Number(p.liked_by_me) > 0;
        const saved = Number(p.saved_by_me) > 0;
        const mediaHtml = renderMedia(p.media);

        return `<article class="k-post" data-k-post-id="${esc(p.sno)}" data-k-post-updated-at="${esc(p.updated_at || p.edited_at || p.created_at || "")}" data-k-post-time="${esc(p.published_at || p.created_at || "")}">
            <div class="k-post-head">
                <div class="k-author-wrap">
                    <div class="k-avatar" style="background:${esc(p.category_color || '#286fbe')}">
                    ${p.author_profile_url ? 
                        `<img src="${p.author_profile_url}"  alt="user-avatar" class="rounded-circle outline-success" style="width:44px; height:44px; object-fit:fill;"/>` :
                         `${esc(initials)}`}
                    
                    </div>
                    <div>
                        <div class="k-author fs-6 fw-semibold text-black">
                            ${esc(p.author_name || 'ERP User')}
                           <!-- <span class="k-company-chip">${esc(p.company_name || 'Group')}</span> -->
                        </div>
                        <div class="k-post-meta fs-9 text-dark fw-light">
                            ${esc(p.category_name || 'All categories')} · ${p.published_at ? formatDateTime (esc(p.published_at)) :(p.created_at ?formatDateTime (esc(p.created_at)) : '' )}
                        </div>
                    </div>
                </div>
                <!-- <button type="button" class="k-post-more" data-egpk-action="view-knowledge" data-id="${esc(p.sno)}" title="Open knowledge">
                    <i class="mdi mdi-dots-horizontal"></i>
                </button> -->
            </div>
            <div class="k-post-body text-black">
                <div class="k-post-title fs-7 fw-bold text-black mb-2">
                    ${p.title ? esc(p.title) : ''}
                </div>
                <div class="text-black fs-8">
                ${p.url_preview ? renderUrlPostCard(p.url_preview) : String(p.body_html || '')}
                ${mediaHtml}
                </div>
            </div>
            <div class="k-post-actions">
                <button type="button" class="k-post-action fs-8 fw-semibold text-dark ${liked ? 'active text-primary' : ''}" data-egpk-action="like-knowledge" data-id="${esc(p.sno)}" data-liked="${liked ? 1 : 0}">
                    <i class="mdi ${liked ? 'mdi-thumb-up' : 'mdi-thumb-up-outline'}"></i>
                    <span class="k-like-count">${esc(p.likes_count || 0)}</span>
                </button>
                <!-- <button type="button" class="k-post-action fs-8 fw-semibold text-dark" data-egpk-action="view-knowledge" data-id="${esc(p.sno)}">
                    <i class="mdi mdi-comment-outline"></i>
                    <span>${esc(p.replies_count || 0)}</span>
                </button> -->
                ${sharePost == 1 ?
                `<button type="button" class="k-post-action fs-8 fw-semibold text-dark" data-egpk-action="share" data-id="${esc(p.sno)}" data-k-title="${esc(p.title || "Knowledge")}">
                    <i class="mdi mdi-share-variant-outline"></i>
                    Share
                </button>` : ''
                }
                <span class="k-post-age fs-9 fw-semibold text-dark" data-k-post-age="1" title="${esc(absoluteDate(p.published_at || p.created_at))}">
                    ${esc(relativeTime(p.published_at || p.created_at))}
                </span>
                <button type="button" class="k-post-action save fs-8 fw-semibold text-dark ${saved ? 'active' : ''}" data-egpk-action="save-knowledge" data-id="${esc(p.sno)}" data-saved="${saved ? 1 : 0}">
                    <i class="mdi ${saved ? 'mdi-bookmark' : 'mdi-bookmark-outline'}"></i>
                    <span class="visually-hidden">${saved ? 'Saved' : 'Save'}</span>
                </button>
            </div>
        </article>`;
    }

    function renderTrending(rows) {
        const r = Array.isArray(rows) ? rows : [];
        const trendRows = r.length
            ? r.map((x, i) => `<div class="k-trend-row">
                <div class="k-trend-num fs-8 fw-semibold">${i + 1}</div>
                <div>
                    <div class="k-trend-title fs-8 fw-semibold text-dark">${esc(x.title || 'Knowledge post')}</div>
                    <div class="k-trend-meta fs-9 fw-light text-dark">${esc(x.author_name || 'ERP User')} · 👍 ${esc(x.likes_count || 0)}</div>
                </div>
            </div>`).join('')
            : '<div class="k-trend-row"><div class="k-trend-title fs-8 fw-semibold text-dark">No trending posts yet.</div></div>';

        return `<div class="k-trending">
            <div class="k-trend-head fs-7 fw-bold text-black"><i class="mdi mdi-fire fs-5 me-1 text-warning"></i>Trending · 30 days</div>
            ${trendRows}
        </div>
        <div class="k-library">
            <button type="button" class="k-library-button" data-egpk-action="knowledge-library">
                <div class="k-library-title fs-8 fw-bold text-black"><i class="mdi mdi-bookmark"></i><span>My Library</span></div>
                <div class="k-library-sub fs-9 fw-light text-dark">Saved posts &amp; files · Open library</div>
            </button>
        </div>`;
    }

    function pagination(p,last,total) {
        p=Number(p||1);
        last=Number(last||1);
        if(last<=1)return '';
        return `<div class="k-pager"><span>${esc(total||0)} posts</span><div class="btn-group"><button type="button" class="btn btn-light btn-sm" data-k-page="${Math.max(1,p-1)}" ${p<=1?'disabled':''}><i class="mdi mdi-chevron-left"></i></button><button type="button" class="btn btn-light btn-sm" data-k-page="${Math.min(last,p+1)}" ${p>=last?'disabled':''}><i class="mdi mdi-chevron-right"></i></button></div></div>`;
    }

    function loadSettingsSnapshot() {
        const fallback={
            data:{
                categories:[],can_manage:false,is_group_admin:false,is_company_admin:false
            }
        };
        return ajax('GET',R.settings).then(function(res){
            return res;
        }).catch(function(){
            return fallback;
        });
    }

    function skeletonPost() {
        return `<article class="k-skeleton-card" aria-hidden="true"><div class="k-author-wrap"><div class="k-skeleton-avatar"></div><div style="flex:1;min-width:0"><div class="k-skeleton-line w-35"></div><div class="k-skeleton-line w-20"></div></div></div><div class="k-skeleton-line w-92"></div><div class="k-skeleton-line w-80"></div><div class="k-skeleton-line w-65"></div><div class="k-skeleton-line w-50"></div><div class="k-skeleton-actions"><div class="k-skeleton-action"></div><div class="k-skeleton-action"></div><div class="k-skeleton-action"></div><div class="k-skeleton-action" style="margin-left:auto"></div></div></article>`;
    }

    function skeletonSidebar() {
        return `<div class="k-skeleton-side" aria-hidden="true"><div class="k-skeleton-line w-80" style="height:34px;border-radius:9px;margin-bottom:18px"></div><div class="k-skeleton-line w-35"></div>${['92','65','80','50','80','65'].map(width=>`<div class="k-skeleton-line w-${width}"></div>`).join('')}</div>`;
    }

    function skeletonTrending() {
        return `<div class="k-skeleton-side" aria-hidden="true"><div class="k-skeleton-line w-50"></div>${Array.from({length:5},()=>`<div style="padding:8px 0 10px;border-bottom:1px solid #edf0f4"><div class="k-skeleton-line w-92"></div><div class="k-skeleton-line w-50"></div></div>`).join('')}<div style="margin-top:14px"><div class="k-skeleton-line w-35"></div><div class="k-skeleton-line w-65"></div></div></div>`;
    }

    function showKnowledgeSkeleton() {
        $('#kSidebar').html(skeletonSidebar());
        $ws.html(`<div class="k-loading" aria-label="Loading Knowledge Panel" aria-busy="true"><div class="k-skeleton-wrap">${Array.from({length:3},()=>skeletonPost()).join('')}</div></div>`);
        $('#kRight').html(skeletonTrending());
    }

    function renderWorkspaceRows(rows, pager) {
        const list = Array.isArray(rows) ? rows : [];
        const hasRows = list.length > 0;
        state.hasMore = Number(pager?.current_page || 1) < Number(pager?.last_page || 1);

        if (!hasRows) {
            return `<div class="k-empty">
                <i class="mdi ${state.library ? 'mdi-bookmark-outline' : 'mdi-school-outline'}"></i>
                <div class="fw-bold mb-1">${state.library ? 'Your library is empty' : 'No knowledge posts found'}</div>
                <div class="small mb-3">${state.library ? 'Save a Knowledge post and it will appear here for quick access.' : 'Try another category or create your first post.'}</div>
                ${state.library ? '' :
                    addNewPost == 1 ?
                 '<button type="button" class="btn btn-primary btn-sm" data-egpk-action="new-knowledge"><i class="mdi mdi-plus me-1"></i>Create Post</button>'
                  : ''
                 }
            </div>`;
        }

        return `${list.map(renderPost).join('')}
            ${state.hasMore ? '<div class="k-scroll-sentinel" data-k-scroll-sentinel aria-hidden="true"></div>' : ''}`;
    }

    function appendSkeletonPosts(count = 2) {
        const skeletons = Array.from({length:count},()=>skeletonPost()).join('');
        const sentinel = $ws.find('[data-k-scroll-sentinel]');

        if (sentinel.length) {
            sentinel.before(`<div class="k-infinite-skeleton" data-k-infinite-skeleton aria-hidden="true">${skeletons}</div>`);
        } else {
            $ws.append(`<div class="k-infinite-skeleton" data-k-infinite-skeleton aria-hidden="true">${skeletons}</div>`);
        }
    }

    function removeSkeletonPosts() {
        $ws.find('[data-k-infinite-skeleton]').remove();
    }

    function observeInfiniteScroll() {
        if (state.observer) {
            state.observer.disconnect();
            state.observer = null;
        }

        const sentinel = $ws.find('[data-k-scroll-sentinel]')[0];
        if (!sentinel || !state.hasMore) return;

        if ('IntersectionObserver' in window) {
            state.observer = new IntersectionObserver(function(entries) {
                if (entries.some(entry => entry.isIntersecting)) {
                    loadMoreKnowledge();
                }
            }, {
                root:null,
                rootMargin:'500px 0px',
                threshold:0
            });

            state.observer.observe(sentinel);
            return;
        }

        $(window).off('scroll.kInfinite').on('scroll.kInfinite',function() {
            if (state.loading || !state.hasMore) return;

            const scrollTop = $(window).scrollTop();
            const viewport = window.innerHeight;
            const documentHeight = $(document).height();

            if (scrollTop + viewport >= documentHeight - 500) {
                loadMoreKnowledge();
            }
        });
    }

    function currentFeedParams() {
        return {
            page:state.page,
            per_page:state.perPage,
            search:state.search,
            category_id:state.library ? '' : state.category,
            content_type:state.library ? '' : (state.contentType === 'all' ? '' : state.contentType),
            saved_only:state.library ? 1 : '',
            sort:state.sort || 'newest'
        };
    }

    function loadMoreKnowledge() {
        if (state.loading || !state.hasMore) return;

        state.loading = true;
        appendSkeletonPosts(2);

        const nextPage = state.page + 1;
        const requestToken = state.requestToken;
        const params = {
            ...currentFeedParams(),
            page:nextPage
        };

        ajax('GET',`${R.data}?${query(params)}`)
            .done(function(res) {
                if (requestToken !== state.requestToken) {
                    removeSkeletonPosts();
                    return;
                }

                const payload = res?.data || {};
                const pager = payload.rows || {};
                const rows = Array.isArray(pager.data) ? pager.data : [];

                removeSkeletonPosts();
                state.page = Number(pager.current_page || nextPage);
                state.hasMore = state.page < Number(pager.last_page || state.page);

                const html = rows.map(renderPost).join('');
                const sentinel = $ws.find('[data-k-scroll-sentinel]');

                if (html) {
                    if (sentinel.length) {
                        sentinel.before(html);
                    } else {
                        $ws.append(html);
                    }
                }

                if (!state.hasMore) {
                    $ws.find('[data-k-scroll-sentinel]').remove();
                }

                observeInfiniteScroll();
            })
            .fail(function(err) {
                removeSkeletonPosts();
                notify(err.message || 'Unable to load more Knowledge posts.','error');
            })
            .always(function() {
                state.loading = false;
            });
    }

    function loadKnowledge(options) {
        const opts = options || {};

        state.library = Boolean(opts.library);
        state.page = 1;
        state.hasMore = true;
        state.loading = false;
        state.requestToken += 1;

        if (state.observer) {
            state.observer.disconnect();
            state.observer = null;
        }
        $(window).off('scroll.kInfinite');

        if (!state.library) {
            state.contentType = state.contentType || 'all';
            state.categoryName = state.category ? (state.categoryName || 'All categories') : 'All categories';
        }

        $('#kFeedTitle').text(state.library ? 'My Library' : state.categoryName);
        renderTypes();
        showKnowledgeSkeleton();

        const requestToken = state.requestToken;
        const params = currentFeedParams();

        $.when(
            loadCategories(),
            loadSettingsSnapshot(),
            ajax('GET',`${R.data}?${query(params)}`)
        ).done(function(catRes,settingsRes,dataRes) {
            if (requestToken !== state.requestToken) return;

            const catData = catRes?.data || {};
            state.categories = Array.isArray(catData.categories) ? catData.categories : [];
            state.settings = settingsRes?.data || {
                categories:[],
                        can_manage:false,
                is_group_admin:false,
                is_company_admin:false
            };

            const payload = dataRes?.data || {};
            const pager = payload.rows || {};
            const rows = Array.isArray(pager.data) ? pager.data : [];
            state.trending = payload.trending || [];
            state.page = Number(pager.current_page || 1);
            state.hasMore = state.page < Number(pager.last_page || state.page);

            if (!state.library && state.category) {
                const selectedCategory = state.categories.find(item => String(item.sno) === String(state.category));
                if (selectedCategory) {
                    state.categoryName = selectedCategory.category_name || 'All categories';
                }
            }

            $('#kFeedTitle').text(state.library ? 'My Library' : state.categoryName);
            renderSidebar();
            $ws.html(renderWorkspaceRows(rows,pager));
            $('#kRight').html(renderTrending(state.trending));
            observeInfiniteScroll();

            if (state.live) {
                state.live.lastCategorySignature=knowledgeCategorySignature(state.categories);
                state.live.lastFeedSignature=postLiveSignature(rows);
                state.live.lastTrendingSignature=trendingLiveSignature(state.trending);
                state.live.lastSyncAt=Date.now();
            }
        }).fail(function(err) {
            if (requestToken !== state.requestToken) return;

            $ws.html(`<div class="k-empty">
                <i class="mdi mdi-cloud-alert-outline"></i>
                <div class="fw-bold mb-1">Knowledge could not be loaded</div>
                <div class="small mb-3">${esc(err.message || 'Server request failed.')}</div>
                <button type="button" class="btn btn-primary btn-sm" data-egpk-action="knowledge-retry">
                    <i class="mdi mdi-refresh me-1"></i>Retry
                </button>
            </div>`);
        });
    }

    /* -------------------------------------------------------------------------
     * Knowledge live synchronization
     * -------------------------------------------------------------------------
     * Polling is intentionally background-only: it never calls loadKnowledge(),
     * therefore it never shows the normal skeleton and never resets the user's
     * filters or scroll position. The existing authenticated data endpoints are
     * reused, so audience/security rules remain the single source of truth.
     */
    const KNOWLEDGE_LIVE_INTERVAL = 10000;
    const KNOWLEDGE_RELATIVE_INTERVAL = 15000;
    state.live = {
        timer:null,
        relativeTimer:null,
        syncing:false,
        stopped:false,
        lastFeedSignature:'',
        lastTrendingSignature:'',
        lastCategorySignature:'',
        lastSyncAt:0,
        pendingNew:0
    };

    function setKnowledgeLiveStatus(mode, textValue) {
        // const dot=$('#kLiveDot');
        // const status=$('#kLiveStatus');
        // if (!dot.length || !status.length) return;

        // dot.removeClass('syncing offline');
        // if (mode === 'syncing') dot.addClass('syncing');
        // if (mode === 'offline') dot.addClass('offline');
        // status.attr('title', textValue || (mode === 'offline' ? 'Live updates unavailable' : 'Live updates active'));
    }

    function showLiveNewBanner(count) {
        const n=Math.max(0,Number(count||0));
        state.live.pendingNew=n;
        if (!n) {
            $('#kLiveNewBanner').removeClass('show');
            return;
        }
        $('#kLiveNewText').text(n===1 ? '1 new Knowledge post available' : `${n} new Knowledge posts available`);
        $('#kLiveNewBanner').addClass('show');
    }

    function clearLiveNewBanner() {
        state.live.pendingNew=0;
        $('#kLiveNewBanner').removeClass('show');
    }

    function liveFeedParams(page=1, perPage=30) {
        const params=currentFeedParams();
        params.page=page;
        params.per_page=perPage;
        return params;
    }

    function postLiveSignature(rows) {
        return (Array.isArray(rows)?rows:[]).map(p=>[
            p.sno,
            p.updated_at || p.edited_at || p.created_at || '',
            p.status || '',
            p.published_at || '',
            p.likes_count || 0,
            p.replies_count || 0,
            p.saves_count || 0,
            Number(p.liked_by_me)>0 ? 1 : 0,
            Number(p.saved_by_me)>0 ? 1 : 0,
            p.title || ''
        ].join('::')).join('|');
    }

    function trendingLiveSignature(rows) {
        return (Array.isArray(rows)?rows:[]).map(p=>[
            p.sno,
            p.updated_at || p.edited_at || p.created_at || '',
            p.likes_count || 0,
            p.replies_count || 0,
            p.saves_count || 0,
            p.title || ''
        ].join('::')).join('|');
    }

    function updateRenderedPostLive(post) {
        const article=$(`#kWorkspace [data-k-post-id="${String(post.sno).replace(/"/g,'\\"')}"]`)[0];
        if (!article) return false;

        const incomingUpdated=String(post.updated_at || post.edited_at || post.created_at || '');
        const currentUpdated=String(article.getAttribute('data-k-post-updated-at') || '');

        /* Full replacement is only used when the post content/metadata changed. */
        if (incomingUpdated && currentUpdated && incomingUpdated !== currentUpdated) {
            $(article).replaceWith(renderPost(post));
            return true;
        }

        const liked=Number(post.liked_by_me)>0;
        const likeButton=article.querySelector('[data-egpk-action="like-knowledge"]');
        if (likeButton) {
            likeButton.classList.toggle('active',liked);
            likeButton.setAttribute('data-liked',liked?'1':'0');
            const icon=likeButton.querySelector('i');
            if (icon) icon.className=`mdi ${liked?'mdi-thumb-up':'mdi-thumb-up-outline'}`;
            const count=likeButton.querySelector('.k-like-count');
            if (count) count.textContent=String(post.likes_count || 0);
        }

        const saved=Number(post.saved_by_me)>0;
        const saveButton=article.querySelector('[data-egpk-action="save-knowledge"]');
        if (saveButton) {
            saveButton.classList.toggle('active',saved);
            saveButton.setAttribute('data-saved',saved?'1':'0');
            const icon=saveButton.querySelector('i');
            if (icon) icon.className=`mdi ${saved?'mdi-bookmark':'mdi-bookmark-outline'}`;
        }

        article.setAttribute('data-k-post-updated-at',incomingUpdated);
        article.setAttribute('data-k-post-time',String(post.published_at || post.created_at || ''));
        const age=article.querySelector('[data-k-post-age]');
        if (age) {
            const stamp=post.published_at || post.created_at || '';
            age.textContent=relativeTime(stamp);
            age.setAttribute('title',absoluteDate(stamp));
        }
        return false;
    }

    function updateRelativePostTimes() {
        document.querySelectorAll('#kWorkspace [data-k-post-age]').forEach(function(age){
            const article=age.closest('[data-k-post-id]');
            const stamp=article?.getAttribute('data-k-post-time') || '';
            if (!stamp) return;
            age.textContent=relativeTime(stamp);
            age.setAttribute('title',absoluteDate(stamp));
        });
    }

    function reconcileLiveFeed(rows, pager, options) {
        const list=Array.isArray(rows)?rows:[];
        const opts=options||{};
        const currentIds=new Set();
        $('#kWorkspace [data-k-post-id]').each(function(){
            currentIds.add(String(this.getAttribute('data-k-post-id')||''));
        });

        let newCount=0;
        list.forEach(function(post){
            const id=String(post.sno);
            if (!currentIds.has(id)) newCount++;
            currentIds.add(id);
        });

        const previousTopId=String($('#kWorkspace [data-k-post-id]').first().attr('data-k-post-id')||'');
        const hasLoadedMore=Number(state.page||1)>1 || $('#kWorkspace [data-k-post-id]').length>state.perPage;

        if (newCount > 0 && hasLoadedMore) {
            showLiveNewBanner(newCount);
        }

        /* On the first page it is safe to reconcile the visible feed wholesale,
         * preserving scroll position. On deeper infinite-scroll states we patch
         * existing cards and leave pagination offsets untouched. */
        if (!hasLoadedMore) {
            const nextSignature=postLiveSignature(list);
            if (opts.forceFeed || nextSignature !== state.live.lastFeedSignature) {
                const scrollTop=window.scrollY;
                state.page=1;
                state.hasMore=Number(pager?.current_page||1) < Number(pager?.last_page||1);
                $ws.html(renderWorkspaceRows(list,pager||{}));
                observeInfiniteScroll();
                window.scrollTo(0,scrollTop);
            }
            if (newCount>0 || (previousTopId && String(list[0]?.sno||'') !== previousTopId)) {
                clearLiveNewBanner();
            }
        } else {
            list.forEach(updateRenderedPostLive);
            /* Newest posts that match the current filter are intentionally not
             * injected into a deep infinite-scroll stack. The banner lets the
             * user bring the feed back to page 1 without duplication/skipping. */
        }

        state.live.lastFeedSignature=postLiveSignature(list);
    }

    function refreshVisibleFeedPage() {
        const page=Math.max(1,Number(state.page||1));

        /* Always read page 1 so newly-created posts can be detected even when
         * the user has already loaded deeper infinite-scroll pages. When deeper
         * pages are present, also read the current tail page so edits/likes on
         * currently-visible older content stay fresh. */
        const firstRequest=ajax(
            'GET',
            `${R.data}?${query(liveFeedParams(1,30))}`,
            null,
            {timeout:15000}
        );

        const tailRequest=page>1
            ? ajax('GET',`${R.data}?${query(liveFeedParams(page,state.perPage))}`,null,{timeout:15000})
            : $.Deferred().resolve(null).promise();

        return $.when(firstRequest,tailRequest)
            .done(function(firstRes,tailRes){
                const firstPayload=firstRes?.data||{};
                const firstPager=firstPayload.rows||{};
                const firstRows=Array.isArray(firstPager.data)?firstPager.data:[];

                reconcileLiveFeed(firstRows,firstPager,{forceFeed:false});

                if (page>1 && tailRes) {
                    const tailPayload=tailRes?.data||{};
                    const tailRows=tailPayload.rows?.data;
                    (Array.isArray(tailRows)?tailRows:[]).forEach(updateRenderedPostLive);
                }

                const trending=Array.isArray(firstPayload.trending)?firstPayload.trending:[];
                const trendSig=trendingLiveSignature(trending);
                if (trendSig !== state.live.lastTrendingSignature) {
                    state.trending=trending;
                    $('#kRight').html(renderTrending(trending));
                    state.live.lastTrendingSignature=trendSig;
                }
            });
    }

    function refreshKnowledgeLive(options) {
        const opts=options||{};
        if (state.live.syncing || document.hidden || !document.getElementById('egKnowledge')) return $.Deferred().resolve().promise();

        state.live.syncing=true;
        setKnowledgeLiveStatus('syncing','Synchronizing Knowledge updates…');

        const categoryRequest=loadCategories({render:true,keepFeed:true});
        const feedRequest=refreshVisibleFeedPage();

        let settingsRequest=$.Deferred().resolve().promise();
        if ($('#kSettingsModal').hasClass('show') && $('#kSettingsFormPanel').hasClass('d-none')) {
            settingsRequest=loadSettingsSnapshot().done(function(res){
                state.settings=res?.data || state.settings;
                renderSettings();
            });
        }

        return $.when(categoryRequest,feedRequest,settingsRequest)
            .done(function(){
                /* If the current category was deleted/deactivated remotely, return
                 * the user to the safe All categories view without a hard refresh. */
                if (state.category && !state.categories.some(c=>String(c.sno)===String(state.category))) {
                    state.category='';
                    state.categoryName='All categories';
                    $('#kFeedTitle').text('All categories');
                    renderSidebar();
                    clearLiveNewBanner();
                    refreshVisibleFeedPage();
                }
                state.live.lastSyncAt=Date.now();
                setKnowledgeLiveStatus('live','Live updates active');
            })
            .fail(function(){
                setKnowledgeLiveStatus('offline','Live update check failed; will retry automatically');
            })
            .always(function(){
                state.live.syncing=false;
            });
    }

    function startKnowledgeLiveRefresh() {
        if (state.live.timer) clearInterval(state.live.timer);
        if (state.live.relativeTimer) clearInterval(state.live.relativeTimer);

        state.live.stopped=false;
        state.live.timer=setInterval(function(){
            if (!document.hidden) refreshKnowledgeLive();
        },KNOWLEDGE_LIVE_INTERVAL);

        state.live.relativeTimer=setInterval(function(){
            if (!document.hidden) updateRelativePostTimes();
        },KNOWLEDGE_RELATIVE_INTERVAL);

        $(document).off('visibilitychange.kKnowledgeLive').on('visibilitychange.kKnowledgeLive',function(){
            if (!document.hidden) {
                updateRelativePostTimes();
                refreshKnowledgeLive();
            }
        });
    }

    function field(name,label,value,type,opt) {
        const o = opt || {};
        const required = o.required ? ' required' : '';

        if (type === 'select') {
            const options = (o.options || []).map(x => `<option value="${esc(x.value ?? x.id ?? x.sno)}" ${String(x.value ?? x.id ?? x.sno) === String(value ?? '') ? 'selected' : ''}>${esc(x.label ?? x.name ?? x.category_name ?? x.company_name)}</option>`).join('');
            const placeholder = o.placeholder !== false ? '<option value="">Select</option>' : '';

            return `<div class="col-md-${o.col || 6}">
                <label class="form-label" style="font-size:10px;font-weight:700">
                    ${esc(label)}${o.required ? ' *' : ''}
                </label>
                <select
                    id="${esc(o.id || name)}"
                    class="form-select select3"
                    data-placeholder="${esc(o.placeholder || 'Select')}"
                    name="${esc(name)}"${required}
                >
                    ${placeholder}
                    ${options}
                </select>
            </div>`;
        }

        if (type === 'textarea') {
            return `<div class="col-12">
                <label class="form-label" style="font-size:10px;font-weight:700">
                    ${esc(label)}${o.required ? ' *' : ''}
                </label>
                <textarea
                    class="form-control"
                    name="${esc(name)}"
                    rows="${o.rows || 5}"
                    placeholder="${esc(o.placeholder || '')}"${required}
                >${esc(value || '')}</textarea>
            </div>`;
        }

        return `<div class="col-md-${o.col || 6}">
            <label class="form-label" style="font-size:10px;font-weight:700">
                ${esc(label)}${o.required ? ' *' : ''}
            </label>
            <input
                class="form-control"
                type="${esc(type || 'text')}"
                name="${esc(name)}"
                value="${esc(value ?? '')}"
                placeholder="${esc(o.placeholder || '')}"${required}
            >
        </div>`;
    }

    function resetSettingsForm() {
        const form = $('#kSettingsForm')[0];
        if (form) form.reset();

        $('#kSettingsFormId').val('');
        $('#kSettingsFormKind').val('category');
        $('#kSettingsFormTitle').text('Add Category');
        $('#kSettingsFormSubtitle').text('Create a category used by Knowledge posts.');
        $('#kSettingsFormBody').empty();
        $('#kSettingsFormError').addClass('d-none').empty();
        $('#kSettingsSaveLabel').html('<i class="mdi mdi-content-save-outline me-1"></i> Save Category');
        $('#kSettingsFormPanel').addClass('d-none');
    }

    function setSettingsFormLoading(isLoading) {
        $('#kSettingsSaveBtn').prop('disabled', isLoading);
        $('#kSettingsSaveLabel').toggleClass('d-none', isLoading);
        $('#kSettingsSaveLoading').toggleClass('d-none', !isLoading);
    }

    function showSettingsForm(mode, item) {
        const edit = mode === 'edit';
        const normalized = item || {};

        $('#kSettingsFormId').val(edit ? (normalized.sno || '') : '');
        $('#kSettingsFormKind').val('category');
        $('#kSettingsFormTitle').text(edit ? 'Update Category' : 'Add Category');
        $('#kSettingsFormSubtitle').text('Add or update the category used across Knowledge posts.');
        $('#kSettingsFormError').addClass('d-none').empty();

        $('#kSettingsFormBody').html(categoryForm(normalized));
        $('#kSettingsSaveLabel').html(
            `<i class="mdi mdi-content-save-outline me-1"></i> ${edit ? 'Update' : 'Save'} Category`
        );
        $('#kSettingsFormPanel').removeClass('d-none');

        setTimeout(function() {
            $('#kSettingsFormBody input[name="category_name"]').trigger('focus');
        }, 50);
    }

    function saveSettingsForm() {
        const id = $('#kSettingsFormId').val();
        const edit = !!id;
        const endpoint = edit ? url(R.categoryUpdate, id) : R.categoryStore;
        const method = edit ? 'PUT' : 'POST';
        const form = $('#kSettingsForm');

        $('#kSettingsFormError').addClass('d-none').empty();
        setSettingsFormLoading(true);

        ajax(
            method,
            endpoint,
            Object.fromEntries(form.serializeArray().map(x => [x.name, x.value]))
        ).done(function(res) {
            notify(res.message || (edit ? 'Category updated.' : 'Category saved.'));
            $('#kSettingsFormPanel').addClass('d-none');
            resetSettingsForm();
            refreshKnowledgeLive({forceFeed:true});
            loadSettings();
        }).fail(function(e) {
            $('#kSettingsFormError')
                .removeClass('d-none')
                .text(e.message || (edit ? 'Category update failed.' : 'Category save failed.'));
        }).always(function() {
            setSettingsFormLoading(false);
        });
    }

    const knowledgeContentTypes = {
        text: {
            label:'Text',
            icon:'mdi-format-text',
            description:'Write searchable knowledge directly.'
        },
        image: {
            label:'Image',
            icon:'mdi-image-outline',
            description:'Upload diagrams, screenshots or photos.'
        },
        video: {
            label:'Video',
            icon:'mdi-video-outline',
            description:'Share a short video walkthrough.'
        },
        audio: {
            label:'Audio',
            icon:'mdi-music-note-outline',
            description:'Share audio guidance or training.'
        },
        pdf: {
            label:'Pdf',
            icon:'mdi-file-pdf-box',
            description:'Upload a PDF reference document.'
        },
        url: {
            label:'Url',
            icon:'mdi-link-variant',
            description:'Publish a useful external resource.'
        },
        files: {
            label:'Files',
            icon:'mdi-file-multiple-outline',
            description:'Attach one or more supporting files.'
        }
    };

    function createPostTypeCards(activeType) {
        $('#kPostTypeCards [data-k-post-type]').removeClass('active');
        $('#kPostTypeCards [data-k-post-type]').removeClass('text-primary');
        $(`#kPostTypeCards [data-k-post-type=\"${activeType}\"]`).addClass('active');
        $(`#kPostTypeCards [data-k-post-type=\"${activeType}\"]`).addClass('text-primary');
        return '';
    }

    function bindPostTypeCardEvents() {
        const root = document.getElementById('kPostTypeCards');
        if (!root) return;

        if (root.__knowledgePostTypeHandler) {
            root.removeEventListener('click', root.__knowledgePostTypeHandler);
        }

        const handler = function (event) {
            const button = event.target.closest('[data-k-post-type]');
            if (!button || !root.contains(button)) return;
            event.preventDefault();
            event.stopPropagation();

            const type = String(button.getAttribute('data-k-post-type') || 'text');
            updatePostType(type);
        };

        root.__knowledgePostTypeHandler = handler;
        root.addEventListener('click', handler);
    }

    function postTypeAccept(type) {
        if (type === 'image') return 'image/jpeg,image/png,image/webp';
        if (type === 'video') return 'video/mp4,video/webm';
        if (type === 'audio') return 'audio/mpeg,audio/wav';
        if (type === 'pdf') return 'application/pdf';
        if (type === 'files') return '.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv,.jpg,.jpeg,.png,.webp';
        return '';
    }

    function postTypeSection(type) {
        return '';
    }

    // Keep one Quill instance for the lifetime of the Knowledge page.
    // Reconstructing Quill on every modal open leaves previous toolbars in the DOM
    // and can trigger the legacy DOMNodeInserted warning repeatedly in Quill 1.x.
    let kPostQuill = null;
    let kPostPreviewObjectUrls = [];

    function revokePostPreviewObjectUrls() {
        kPostPreviewObjectUrls.forEach(function(url){
            try { URL.revokeObjectURL(url); } catch (e) {}
        });
        kPostPreviewObjectUrls = [];
    }

    function destroyKnowledgeTextEditor() {
        // Intentionally do not destroy the instance. Quill is initialized once and
        // reused so the toolbar is never duplicated when the modal is reopened.
        syncKnowledgeTextEditor();
    }

    function syncKnowledgeTextEditor() {
        const editor = document.getElementById('kPostContentEditor');
        const hidden = document.getElementById('kPostContent');
        if (!hidden) return '';
        if (kPostQuill && editor) {
            hidden.value = kPostQuill.root.innerHTML === '<p><br></p>' ? '' : kPostQuill.root.innerHTML.trim();
        }
        return String(hidden.value || '').trim();
    }

    function initKnowledgeTextEditor(initialHtml = '') {
        const editor = document.getElementById('kPostContentEditor');
        const hidden = document.getElementById('kPostContent');
        if (!editor || !hidden || typeof window.Quill !== 'function') return;

        // Reuse the existing editor instead of creating another Quill toolbar.
        if (kPostQuill) {
            if (initialHtml) {
                kPostQuill.setContents([]);
                kPostQuill.clipboard.dangerouslyPasteHTML(initialHtml);
            }
            syncKnowledgeTextEditor();
            return;
        }

        kPostQuill = new Quill(editor, {
            theme: 'snow',
            placeholder: 'Write your procedure, policy, update or learning note…',
            modules: {
                toolbar: [
                    [{header:[1,2,3,false]}],
                    ['bold','italic','underline','strike'],
                    [{color:[]},{background:[]}],
                    [{list:'ordered'},{list:'bullet'}],
                    [{align:[]}],
                    ['blockquote','code-block'],
                    ['link'],
                    ['clean']
                ]
            }
        });

        if (initialHtml) {
            kPostQuill.clipboard.dangerouslyPasteHTML(initialHtml);
        }

        const sync = () => syncKnowledgeTextEditor();
        kPostQuill.on('text-change', sync);
        sync();
    }

    function updatePostType(type) {
        state.postType = type;
        $('#kPostType').val(type);
        createPostTypeCards(type);

        $('#kPostContentArea [data-k-post-content-panel]').addClass('d-none');
        if (type === 'text' || type === 'url') {
            $(`#kPostContentArea [data-k-post-content-panel="${type}"]`).removeClass('d-none');
        } else {
            $('#kPostContentArea [data-k-post-content-panel="media"]').removeClass('d-none');
            const multiple = type === 'files';
            $('#kPostMedia').attr({accept:postTypeAccept(type), multiple:multiple});
            $('#kPostMediaLabel').text(`${knowledgeContentTypes[type].label} ${multiple ? 'attachments' : 'file'}`);
            $('#kPostMediaAction').text(`Click to choose ${multiple ? 'files' : 'a file'}`);
            $('#kPostMediaDescription').text(`${knowledgeContentTypes[type].description} · Up to 50 MB per file`);
        }

        if (type === 'text') {
            initKnowledgeTextEditor();
        } else {
            destroyKnowledgeTextEditor();
        }

        $('#kPostMedia').off('change.kmedia').on('change.kmedia', function() {
            const files = Array.from(this.files || []);
            revokePostPreviewObjectUrls();

            if (!files.length) {
                $('#kPostMediaPreview').empty();
                return;
            }

            if (type === 'image') {
                const file = files[0];
                const objectUrl = URL.createObjectURL(file);
                kPostPreviewObjectUrls.push(objectUrl);

                const image = $('<img>', {
                    src: objectUrl,
                    alt: file.name
                });

                const thumb = $('<div>', {class:'k-media-image-thumb'}).append(image);
                const meta = $('<div>', {class:'k-media-image-meta'})
                    .append($('<div>', {class:'k-media-image-name', text:file.name}))
                    .append($('<div>', {class:'k-media-image-info', text:`${formatFileSize(file.size)} · ${file.type || 'Image'}`}))
                    .append($('<span>', {class:'k-media-image-status'}).append(
                        $('<i>', {class:'mdi mdi-check-circle-outline'}),
                        document.createTextNode('Ready to upload')
                    ));

                $('#kPostMediaPreview').empty().append(
                    $('<div>', {class:'k-media-image-preview'}).append(thumb, meta)
                );
                return;
            }

            const preview = files.map(file => `<div class="k-media-preview"><div class="k-media-preview-icon"><i class="mdi ${knowledgeContentTypes[type]?.icon || 'mdi-file-outline'}"></i></div><div class="k-media-preview-name">${esc(file.name)}</div><div class="k-media-preview-size">${formatFileSize(file.size)}</div></div>`).join('');
            $('#kPostMediaPreview').html(preview);
        });

        $('#kPostUrl').off('input.kurl').on('input.kurl', function() {
            const value=String(this.value||'').trim();
            if (!value) { $('#kUrlPreview').addClass('d-none').empty(); return; }
            $('#kUrlPreview').removeClass('d-none').html(`<div class="k-url-preview"><div class="k-url-preview-icon"><i class="mdi mdi-link-variant"></i></div><div><div class="k-field-label mb-0 mb-2 text-black fs-8 fw-semibold">External resource</div><div class="k-form-hint fs-9 text-muted text-break">${esc(value)}</div></div></div>`);
        });
    }

    function populateCategorySelect() {
        const select = $('#kPostCategory');
        const current = String(select.val() || '');
        select.empty().append($('<option>', {value:'', text:'Choose category'}));
        (state.categories || []).forEach(function(item) {
            select.append($('<option>', {value:item.sno, text:item.category_name || ''}));
        });
        if (current) select.val(current);
    }

    function openPostForm() {
        state.postType = 'text';
        state.postEditorHtml = '';

        $('#kPostForm')[0].reset();
        $('#kPostType').val('text');
        $('#kPostTitleField').val('');
        populateCategorySelect();
        $('#kPostAudienceSummary').empty();
        if (kPostQuill) {
            kPostQuill.setText('');
        }
        $('#kPostContent').val('');
        $('#kPostUrl').val('');
        $('#kPostUrlDescription').val('');
        $('#kPostMedia').val('');
        revokePostPreviewObjectUrls();
        $('#kPostMediaPreview').empty();
        $('#kUrlPreview').addClass('d-none').empty();
        createPostTypeCards('text');
        setAudienceMode('post','company');
        updatePostType('text');
        modal('kPostModal').show();
        audienceSummary('post','company');
    }

    function getKnowledgeShareLink(id) {
        return `${window.location.origin}/productivity/knowledge/${encodeURIComponent(id)}`;
    }

    function audienceModeMeta(mode) {
        return {
            company:{icon:'mdi-office-building-outline',label:'Company',hint:'Everyone matching the selected companies will have access.'},
            entity:{icon:'mdi-domain',label:'Entity',hint:'Everyone belonging to the selected entities will have access.'},
            role:{icon:'mdi-account-badge-outline',label:'Role',hint:'Users with the selected roles inside the selected entities will have access.'},
            staff:{icon:'mdi-account-multiple-outline',label:'Staff',hint:'Only the selected staff members will have access.'}
        }[mode] || {};
    }


    function renderAudienceFields(scope, mode) {
        const prefix = scope === 'post' ? 'kPost' : 'kShare';
        const meta = audienceModeMeta(mode);
        $(`#${prefix}AudienceFields [data-k-audience-panel]`).addClass('d-none');
        $(`#${prefix}AudienceFields [data-k-audience-panel="${mode}"]`).removeClass('d-none');
        $(`#${prefix}AudienceModeChip`).html(`<i class="mdi ${meta.icon}"></i> ${esc(meta.label)}`);
    }

    function audienceSelectId(scope, type) {
        const prefix = scope === 'post' ? 'kPost' : 'kShare';
        if (type === 'entity' && state.audience[scope].mode === 'role') return `#${prefix}AudienceRoleEntity`;
        if (type === 'entity' && state.audience[scope].mode === 'staff') return `#${prefix}AudienceStaffEntity`;
        return `#${prefix}Audience${type.charAt(0).toUpperCase()}${type.slice(1)}`;
    }

    function selectedAudienceValues(scope, type) {
        const id = audienceSelectId(scope, type);
        const el = document.querySelector(id);
        if (!el) return [];
        return Array.from(el.selectedOptions || []).map(o => String(o.value));
    }

    function setNativeOptions(select, options, selectedValues) {
        if (!select) return;
        const wanted = new Set((selectedValues || []).map(v => String(v)));
        select.innerHTML = '';
        (options || []).forEach(function(item) {
            const option = document.createElement('option');
            option.value = String(item.value);
            option.textContent = String(item.label || '');
            option.selected = wanted.has(option.value);
            select.appendChild(option);
        });
    }

    function setAudienceValues(scope, type, values) {
        const el = document.querySelector(audienceSelectId(scope, type));
        if (!el) return;
        const wanted = new Set((values || []).map(v => String(v)));
        Array.from(el.options).forEach(o => o.selected = wanted.has(String(o.value)));
        audienceSummary(scope, state.audience[scope].mode);
    }

    function enforceAudienceAllOption(scope, type) {
        
        const el = document.querySelector(audienceSelectId(scope, type));
        if (!el || !el.multiple) return [];
        let values = Array.from(el.selectedOptions).map(o => String(o.value));
        if (values.includes('all') && values.length > 1) {
            const allOption = Array.from(el.options).find(o => String(o.value) === 'all');
            const nonAllSelected = Array.from(el.selectedOptions).filter(o => String(o.value) !== 'all');
            const lastSelected = nonAllSelected[nonAllSelected.length - 1];
            const keepAll = allOption && (!lastSelected || lastSelected === allOption);
            Array.from(el.options).forEach(o => o.selected = keepAll ? String(o.value) === 'all' : String(o.value) !== 'all');
            values = Array.from(el.selectedOptions).map(o => String(o.value));
        }
        return values;
    }

    function audienceSummary(scope, mode) {
        const prefix = scope === 'post' ? 'kPost' : 'kShare';
        const meta = audienceModeMeta(mode);
        const textFor = (type, value) => {
            const el = document.querySelector(audienceSelectId(scope, type));
            const option = el ? Array.from(el.options).find(o => String(o.value) === String(value)) : null;
            return option?.textContent || String(value);
        };
        let parts=[];
        if (mode === 'company') {
            const values=enforceAudienceAllOption(scope,'company');
            parts=values.includes('all') ? ['All companies'] : values.map(v=>textFor('company',v));
        } else if (mode === 'entity') {
            const values=enforceAudienceAllOption(scope,'entity');
            parts=values.includes('all') ? ['All entities'] : values.map(v=>textFor('entity',v));
        } else if (mode === 'role') {
            const entities=enforceAudienceAllOption(scope,'entity');
            const roles=enforceAudienceAllOption(scope,'role');
            parts=[entities.includes('all')?'All entities':(entities.length?entities.map(v=>textFor('entity',v)).slice(0,3).join(', '):'Choose entities'),roles.includes('all')?'All roles':(roles.length?roles.map(v=>textFor('role',v)).slice(0,3).join(', '):'Choose roles')];
        } else {
            const entities=enforceAudienceAllOption(scope,'entity');
            const staff=selectedAudienceValues(scope,'staff');
            parts=[entities.includes('all')?'All entities':(entities.length?entities.map(v=>textFor('entity',v)).slice(0,3).join(', '):'Choose entities'),staff.length?staff.map(v=>textFor('staff',v)).slice(0,3).join(', '):'Choose staff'];
        }
        const chips=parts.filter(Boolean).map(v=>`<span class="k-audience-chip fs-9 text-dark fw-semibold"><i class="mdi ${meta.icon}"></i>${esc(v)}</span>`).join('');
        $(`#${prefix}AudienceSummary`).html(chips ? `<div class="k-audience-selection-label fs-9 fw-semibold text-dark">Selected</div><div class="k-audience-selection-values">${chips}</div>` : `<div class="k-audience-selection-label fs-9 fw-semibold text-dark">Selected</div><div class="k-audience-selection-empty fs-9 fw-light text-muted">Choose at least one audience option.</div>`);
    }

    function loadAudienceOptions(scope, mode, dependencyEntityIds) {
        const prefix=scope==='post'?'kPost':'kShare';
        const entityIds=(dependencyEntityIds||[]).map(v=>String(v));
        const payload={mode};
        if(entityIds.length) payload.entity_ids=entityIds;
        const requestNo=(state.audience[scope]._requestNo||0)+1;
        state.audience[scope]._requestNo=requestNo;

        const previous={
            company:selectedAudienceValues(scope,'company'),
            entity:selectedAudienceValues(scope,'entity'),
            role:selectedAudienceValues(scope,'role'),
            staff:selectedAudienceValues(scope,'staff')
        };

        return ajax('GET',R.audienceOptions,payload).done(function(res){
            if (requestNo !== state.audience[scope]._requestNo) return;
            const data=res?.data||{};
            const generalLabel=data.general?.label || 'Elysium Groups';
            const entities=data.entities || data;
            const entityRows=Array.isArray(entities.items)?entities.items:[];
            const entityOptions=[{value:'all',label:'All entities'},{value:0,label:generalLabel},...entityRows.map(x=>({value:x.sno,label:(x.entity_name||'')+(x.company_name?` · ${x.company_name}`:'')}))];

            if(mode==='company') {
                const rows=Array.isArray(data.items)?data.items:[];
                setNativeOptions(document.querySelector(`#${prefix}AudienceCompany`),[{value:'all',label:'All companies'},{value:0,label:generalLabel},...rows.map(x=>({value:x.sno,label:x.company_name||x.company_short_name||''}))],previous.company);
            } else if(mode==='entity') {
                setNativeOptions(document.querySelector(`#${prefix}AudienceEntity`),entityOptions,previous.entity);
            } else if(mode==='role') {
                setNativeOptions(document.querySelector(`#${prefix}AudienceRoleEntity`),entityOptions,entityIds.length?entityIds:previous.entity);
                const roles=Array.isArray(data.items)?data.items:[];
                setNativeOptions(document.querySelector(`#${prefix}AudienceRole`),[{value:'all',label:'All roles'},...roles.map(x=>({value:x.sno,label:(x.role_name||'')+(x.entity_name?` - ${x.entity_name}`:' - Elysium Groups')}))],previous.role);
            } else if(mode==='staff') {
                setNativeOptions(document.querySelector(`#${prefix}AudienceStaffEntity`),entityOptions,entityIds.length?entityIds:previous.entity);
                const staff=Array.isArray(data.items)?data.items:[];
                setNativeOptions(document.querySelector(`#${prefix}AudienceStaff`),staff.map(x=>({value:x.sno,label:(x.staff_name||'')+(x.staff_id?` · ${x.staff_id}`:'')+(x.entity_name?` - ${x.entity_name}`:' - Elysium Groups')})),previous.staff);
            }
            audienceSummary(scope,mode);
        }).fail(function(err){
            if (requestNo !== state.audience[scope]._requestNo) return;
            notify(err.message||'Unable to load audience options.','error');
        });
    }

    function setAudienceMode(scope, mode) {
        const prefix=scope==='post'?'kPost':'kShare';
        state.audience[scope].mode=mode;
        $(`#${prefix}AudienceModes [data-k-audience-mode]`).removeClass('active');
        $(`#${prefix}AudienceModes [data-k-audience-mode]`).removeClass('text-primary');
        $(`#${prefix}AudienceModes [data-k-audience-mode="${mode}"]`).addClass('active');
        $(`#${prefix}AudienceModes [data-k-audience-mode="${mode}"]`).addClass('text-primary');
        renderAudienceFields(scope,mode);
        // Clear selections belonging to the previous audience mode.
        const ids=['company','entity','role','staff'];
        ids.forEach(type=>{
            const el=document.querySelector(audienceSelectId(scope,type));
            if(el) Array.from(el.options).forEach(o=>o.selected=false);
        });
        const roleEntity=document.querySelector(`#${prefix}AudienceRoleEntity`);
        const staffEntity=document.querySelector(`#${prefix}AudienceStaffEntity`);
        if(roleEntity) Array.from(roleEntity.options).forEach(o=>o.selected=false);
        if(staffEntity) Array.from(staffEntity.options).forEach(o=>o.selected=false);
        audienceSummary(scope,mode);
        loadAudienceOptions(scope,mode,[]);
    }

    // Explicit handlers for the dependent Entity -> Role/Staff dropdowns.
    // These are intentionally small and predictable so they can also be called
    // directly from the static select onchange attributes in the modal HTML.
    function getAudienceEntityIds(selectId) {
        const el = document.getElementById(selectId);
        if (!el) return [];
        return Array.from(el.selectedOptions || []).map(option => String(option.value));
    }

    function clearAudienceDependentSelect(selectId) {
        const el = document.getElementById(selectId);
        if (!el) return;
        Array.from(el.options || []).forEach(option => { option.selected = false; });
    }

    function postRoleEntityChangeFunction() {
        const entityIds = getAudienceEntityIds('kPostAudienceRoleEntity');
        clearAudienceDependentSelect('kPostAudienceRole');
        audienceSummary('post', 'role');
        return loadAudienceOptions('post', 'role', entityIds);
    }

    function postStaffEntityChangeFunction() {
        const entityIds = getAudienceEntityIds('kPostAudienceStaffEntity');
        clearAudienceDependentSelect('kPostAudienceStaff');
        audienceSummary('post', 'staff');
        return loadAudienceOptions('post', 'staff', entityIds);
    }

    function shareRoleEntityChangeFunction() {
        const entityIds = getAudienceEntityIds('kShareAudienceRoleEntity');
        clearAudienceDependentSelect('kShareAudienceRole');
        audienceSummary('share', 'role');
        return loadAudienceOptions('share', 'role', entityIds);
    }

    function shareStaffEntityChangeFunction() {
        const entityIds = getAudienceEntityIds('kShareAudienceStaffEntity');
        clearAudienceDependentSelect('kShareAudienceStaff');
        audienceSummary('share', 'staff');
        return loadAudienceOptions('share', 'staff', entityIds);
    }

    function bindAudienceDynamicEvents(scope) {
        const prefix = scope === 'post' ? 'kPost' : 'kShare';

        // Role/Staff dependency selects use their explicit global onchange
        // handlers above. They are deliberately excluded here to prevent
        // duplicate AJAX requests.
        const dependencyIds = [
            `#${prefix}AudienceEntity`,
            `#${prefix}AudienceCompany`,
            `#${prefix}AudienceRole`,
            `#${prefix}AudienceStaff`
        ];

        dependencyIds.forEach(selector => {
            const el = document.querySelector(selector);
            if (!el) return;
            if (el.__knowledgeAudienceChangeHandler) {
                el.removeEventListener('change', el.__knowledgeAudienceChangeHandler);
            }

            const handler = function () {
                const mode = state.audience[scope].mode;
                const id = this.id;

                if (id === `${prefix}AudienceCompany`) {
                    enforceAudienceAllOption(scope, 'company');
                } else if (id === `${prefix}AudienceEntity` && mode === 'entity') {
                    enforceAudienceAllOption(scope, 'entity');
                } else if (id === `${prefix}AudienceRole`) {
                    enforceAudienceAllOption(scope, 'role');
                }

                audienceSummary(scope, mode);
            };

            el.__knowledgeAudienceChangeHandler = handler;
            el.addEventListener('change', handler);
        });

        const modeRoot = document.querySelector(`#${prefix}AudienceModes`);
        if (modeRoot) {
            if (modeRoot.__knowledgeAudienceClickHandler) {
                modeRoot.removeEventListener('click', modeRoot.__knowledgeAudienceClickHandler);
            }
            const clickHandler = function (event) {
                const button = event.target.closest('[data-k-audience-mode]');
                if (!button || !modeRoot.contains(button)) return;
                event.preventDefault();
                setAudienceMode(scope, String(button.dataset.kAudienceMode || 'company'));
            };
            modeRoot.__knowledgeAudienceClickHandler = clickHandler;
            modeRoot.addEventListener('click', clickHandler);
        }
    }

    function collectAudiencePayload(scope) {
        const mode = state.audience[scope].mode;
        const payload = {audience_mode:mode};
        if (mode === 'company') payload.audience_company_ids = enforceAudienceAllOption(scope,'company');
        if (mode === 'entity') payload.audience_entity_ids = enforceAudienceAllOption(scope,'entity');
        if (mode === 'role') {
            payload.audience_entity_ids = enforceAudienceAllOption(scope,'entity');
            payload.audience_role_ids = enforceAudienceAllOption(scope,'role');
        }
        if (mode === 'staff') {
            payload.audience_entity_ids = enforceAudienceAllOption(scope,'entity');
            payload.audience_staff_ids = selectedAudienceValues(scope,'staff');
        }
        return payload;
    }

    function appendAudienceToFormData(formData, scope) {
        const payload = collectAudiencePayload(scope);
        Object.keys(payload).forEach(key => {
            const value = payload[key];
            formData.delete(key);
            formData.delete(`${key}[]`);
            if (Array.isArray(value)) {
                value.forEach(v => formData.append(`${key}[]`, v));
            } else {
                formData.set(key, value);
            }
        });
        return payload;
    }

    function renderExistingShares(rows) {
        const list = Array.isArray(rows) ? rows : [];
        if (!list.length) {
            $('#kShareExisting').addClass('d-none').empty();
            return;
        }

        const html = list.map(row => {
            const meta = row.audience || {};
            const mode = row.audience_mode || 'group';
            const metaInfo = audienceModeMeta(mode);
            const details = Array.isArray(row.audience_details) ? row.audience_details : [];

            let summary = metaInfo.label || (row.legacy_grantee_type || row.grantee_type || 'Recipient');
            let detailHtml = '';

            if (details.length) {
                detailHtml = details.map(function(detail) {
                    let name = '';
                    let context = [];

                    if (detail.type === 'company') {
                        name = detail.company_name || 'Company';
                    } else if (detail.type === 'entity') {
                        name = detail.entity_name || 'Entity';
                        if (detail.company_name) context.push(detail.company_name);
                    } else if (detail.type === 'role') {
                        name = detail.role_name || 'Role';
                        if (detail.entity_name) context.push(detail.entity_name);
                        if (detail.company_name) context.push(detail.company_name);
                    } else if (detail.type === 'staff') {
                        name = detail.staff_name || 'Staff';
                        if (detail.entity_name) context.push(detail.entity_name);
                        if (detail.company_name) context.push(detail.company_name);
                        if (detail.role_name) context.push(detail.role_name);
                    }

                    return `<div class="text-muted" style="line-height:1.45">
                        <span class="fs-9 fw-semibold text-muted">${esc(name)}</span>${context.length ? ` · ${esc(context.join(' · '))}` : ''}
                    </div>`;
                }).join('');
            } else {
                // Preserve a useful fallback for older grants or "all" selections.
                if (mode === 'company' && Array.isArray(meta.company_ids)) {
                    summary += meta.company_ids.includes('all') ? ' · All companies' : ` · ${meta.company_ids.length} selected`;
                }
                if ((mode === 'entity' || mode === 'role' || mode === 'staff') && Array.isArray(meta.entity_ids)) {
                    summary += meta.entity_ids.includes('all') ? ' · All entities' : ` · ${meta.entity_ids.length} entities`;
                }
                if (mode === 'role' && Array.isArray(meta.role_ids)) {
                    summary += meta.role_ids.includes('all') ? ' · All roles' : ` · ${meta.role_ids.length} roles`;
                }
                if (mode === 'staff' && Array.isArray(meta.staff_ids)) {
                    summary += ` · ${meta.staff_ids.length} staff`;
                }
            }

            const revoke = row.sno ?
                `<button type="button" class="btn btn-link p-0 text-danger k-share-revoke shadow-none" data-k-share-revoke="${esc(row.sno)}" title="Remove access" aria-label="Remove access"><i class="mdi mdi-close-circle-outline"></i></button>` : '';

            return `<div class="">
                <div class="d-flex justify-content-between align-items-start gap-2">
                    <span class="fs-9 fw-light text-dark"><i class="mdi ${metaInfo.icon || 'mdi-share-variant-outline'} me-1"></i>${esc(summary)}</span>
                    <div class="d-flex align-items-center gap-2">
                        <span class="text-muted fs-9 fw-light" >${esc(row.permission || 'View')}</span>
                        ${revoke}
                    </div>
                </div>
                ${detailHtml}
                <div class="text-muted fs-9 fw-light" >${row.expires_at ? ` · Expires ${esc(row.expires_at)}` : ''}</div>
            </div>`;
        }).join('');

        $('#kShareExisting')
            .removeClass('d-none')
            .html(`<div class="k-share-existing border rounded shadow-none py-2 px-2">
                <div class="fw-bold mb-1 fs-8 text-dark" >Existing access</div>
                ${html}
            </div>`);
    }

    function route(base, id, suffix) {
        return String(base).replace(/\/$/, '') + '/' + encodeURIComponent(id) + (suffix ? '/' + suffix : '');
    }

    function openShareForm(id,title) {
        const shareTitle = title || (
            state.currentPost && String(state.currentPost.sno) === String(id)
                ? state.currentPost.title
                : 'Knowledge'
        );

        $('#kShareResourceId').val(id);
        $('#kShareTitle').text('Share Knowledge');
        $('#kShareSubtitle').text(`Share “${shareTitle || 'Knowledge'}” securely with the right audience.`);
        $('#kShareExpiresAt').val('');
        $('#kSharePermission').val('View');
        $('#kShareCopyLink').data('knowledge-id',id);
        $('#kShareExisting').addClass('d-none').empty();
        
        resetShareExpiryPicker(true);
        $('#kShareExpiresAt').val('')
        bindAudienceDynamicEvents('share');
        setAudienceMode('share','company');
        modal('kShareModal').show();

        ajax('GET',url(R.knowledgeShares,id)).done(function(res) {
            renderExistingShares(res.data);
        });
    }

    $('#kShareExisting').on('click', '[data-k-share-revoke]', function() {
        const id = Number($(this).data('k-share-revoke'));
        if (!id) return;

        const postId = Number($('#kShareResourceId').val());
       
        confirmAction(
            'Remove access',
            'This recipient will lose access to this Knowledge post.',
            'Remove',
            function() {
                return ajax('POST', route(R.shareRevoke, id, 'revoke')).done(function(res) {
                    toastr.success(res.message || 'Access removed.');
                    if (postId) {
                        ajax('GET', url(R.knowledgeShares, postId)).done(function(data) {
                            renderExistingShares(data.data);
                        });
                    } else {
                        $('#kShareExisting').addClass('d-none').empty();
                    }
                });
            }
        );
    });

    function confirmAction(title,body,yes,fn) {
        $('#kConfirmTitle').text(title);
        $('#kConfirmBody').text(body);
        $('#kConfirmYes').text(yes||'Continue').off('click.k').on('click.k',function(){
            const b=$(this).prop('disabled',true);
            let req;
            try{
                req=fn();
            } catch(e){
                notify(e.message||'Action failed.','error');
                b.prop('disabled',false);
                return;
            }if(req&&typeof req.always==='function'){
                req.always(function(){
                    b.prop('disabled',false);
                    modal('kConfirmModal').hide();
                });
            } else{
                Promise.resolve(req).finally(function(){
                    b.prop('disabled',false);
                    modal('kConfirmModal').hide();
                });
            }
        });
        modal('kConfirmModal').show();
    }

    function renderSettings() {
        const can = (manageCategory == 1);
        const categories = Array.isArray(state.settings.categories) ? state.settings.categories : [];
        const count = categories.length;

        $('#kSettingsAddBtn')
            .toggle(can)
            .html('<i class="mdi mdi-plus me-1"></i> Add Category');

        $('#kSettingsModal .k-settings-tab').removeClass('active');
        $('#kSettingsModal .k-settings-tab[data-ksettings-tab="categories"]').addClass('active');

        const html = `
            <div class="k-settings-toolbar">
                <div>
                    <div class="fw-bold" style="font-size:12px">Categories</div>
                    <div class="text-muted" style="font-size:9px">
                        ${esc(count)} configured categor${count === 1 ? 'y' : 'ies'}.
                    </div>
                </div>
            </div>

            <div class="k-settings-table-wrap">
                <div class="table-responsive">
                    <table class="k-settings-table">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-8 text-white gs-0 bg-primary">
                                <th>#</th>
                                <th>Category</th>
                                <th>Posts</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${categories.length ? categories.map((c, index) => {
                                const active = Number(c.status) === 0;
                                return `<tr>
                                    <td class="k-settings-number">${index + 1}</td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="k-color-dot m-0" style="background:${esc(c.color || '#b52b25')}"></span>
                                            <strong>${esc(c.category_name)}</strong>
                                        </div>
                                    </td>
                                    <td>${esc(c.post_count || 0)}</td>
                                    <td class="text-center">
                                        <span class="k-settings-status ${active ? 'active' : 'inactive'}">
                                            <i class="mdi ${active ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'}"></i>
                                            ${active ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-inline-flex align-items-center gap-2">
                                            ${can ? `
                                                <button type="button"
                                                    class="btn btn-light-primary k-settings-action-btn shadow-none js-k-category-edit"
                                                    data-id="${esc(c.sno)}"
                                                    title="Edit category">
                                                    <i class="mdi mdi-square-edit-outline"></i>
                                                </button>
                                                <div class="form-check form-switch m-0"
                                                    title="${active ? 'Deactivate category' : 'Activate category'}">
                                                    <input class="form-check-input k-settings-toggle js-k-category-toggle"
                                                        type="checkbox"
                                                        data-id="${esc(c.sno)}"
                                                        ${active ? 'checked' : ''}>
                                                </div>
                                                <button type="button"
                                                    class="btn btn-light-danger k-settings-action-btn shadow-none js-k-category-delete"
                                                    data-id="${esc(c.sno)}"
                                                    title="Delete category">
                                                    <i class="mdi mdi-delete-outline"></i>
                                                </button>
                                            ` : ''}
                                        </div>
                                    </td>
                                </tr>`;
                            }).join('') : `
                                <tr>
                                    <td colspan="5">
                                        ${emptyHtml('mdi-shape-outline', 'No categories configured.')}
                                    </td>
                                </tr>
                            `}
                        </tbody>
                    </table>
                </div>
            </div>
        `;

        $('#kSettingsBody').html(html);
    }

    function emptyHtml(icon,text) {
        return `<div class="text-center text-muted py-4"><i class="mdi ${esc(icon)} fs-3 d-block mb-2"></i><span style="font-size:10px">${esc(text)}</span></div>`;
    }

    function loadSettings() {
        return ajax('GET',R.settings).done(function(res){
            state.settings=res.data||{
                categories:[],can_manage:false,is_group_admin:false,is_company_admin:false
            };
            if(manageCategory != 1){
                notify('You do not have permission to manage Knowledge settings.','error');
                return;
            }

            renderSettings();
            modal('kSettingsModal').show();
        }).fail(e=>notify(e.message||'Unable to load settings','error'));
    }

    function categoryForm(item) {
        const color = item?.color ||
            (getComputedStyle(document.documentElement).getPropertyValue('--expense-primary').trim() || '#b52b25');

        return `<div class="row g-3">
            ${field('category_name','Category Name',item?.category_name||'','text',{required:true,col:8,placeholder:'Enter category name'})}
            ${field('color','Colour',color,'color',{col:4})}
        </div>
        <div class="k-form-hint fs-9 text-muted mt-2">
            Active categories are available when creating Knowledge posts.
        </div>`;
    }

    function openCategorySettingsForm(item,edit) {
        showSettingsForm(edit ? 'edit' : 'add', item || {});
    }

    function formatDateTime(value) {
        if (!value) {
            return '—';
        }

        const date = new Date(value);

        if (Number.isNaN(date.getTime())) {
            return '—';
        }

        return date.toLocaleString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        });
    }

    $('#kSettingsAddBtn').on('click',function(e){
        e.preventDefault();
        showSettingsForm('add',{});
    });

    $('#kSettingsFormCloseBtn, #kSettingsFormCancelBtn').on('click',function(e){
        e.preventDefault();
        resetSettingsForm();
    });

    $('#kSettingsForm').on('submit',function(e){
        e.preventDefault();
        saveSettingsForm();
    });

    $('#kSettingsModal').on('hidden.bs.modal',function(){
        resetSettingsForm();
    });


    $('#egKnowledge').on('click','.js-k-category-edit',function(e){
        e.preventDefault();
        e.stopPropagation();

        const id=$(this).data('id');
        const item=(state.settings.categories||[]).find(x=>String(x.sno)===String(id));
        if(!item) return notify('Category could not be found.','error');

        showSettingsForm('edit',item);
    });

    $('#egKnowledge').on('click','.js-k-category-delete',function(e){
        e.preventDefault();
        e.stopPropagation();

        const id=$(this).data('id');
        return confirmAction(
            'Delete category',
            'The category will be removed from selection. Existing posts remain intact.',
            'Delete',
            ()=>ajax('DELETE',url(R.categoryDelete,id)).done(()=>{
                notify('Category deleted.');
                refreshKnowledgeLive({forceFeed:true});
                loadSettings();
            })
        );
    });


    let egbmShareExpiryPicker = null;

    function initializeShareExpiryPicker() {
        const element = document.getElementById('kShareExpiresAt');

        if (!element || typeof flatpickr === 'undefined') {
            return;
        }

        if (element._flatpickr) {
            element._flatpickr.destroy();
        }

        egbmShareExpiryPicker = flatpickr(element, {
            enableTime: true,
            dateFormat: 'Y-m-d H:i',
            time_24hr: true,
            minuteIncrement: 5,
            defaultDate: new Date(),
            minDate: new Date(),
            allowInput: false,
            disableMobile: true,
            clickOpens: true
        });
    }

    function resetShareExpiryPicker(defaultToNow) {
        const useCurrentDateTime = defaultToNow !== false;
        const element = document.getElementById('kShareExpiresAt');

        if (!element) {
            return;
        }

        if (!element._flatpickr) {
            initializeShareExpiryPicker();
        }

        if (!element._flatpickr) {
            return;
        }

        if (useCurrentDateTime) {
            element._flatpickr.set('minDate', new Date());
            element._flatpickr.setDate(new Date(), true);
        } else {
            element._flatpickr.clear();
        }
    }

    initializeShareExpiryPicker();

    $('#egKnowledge').on('change','.js-k-category-toggle',function(){
        const checkbox=this;
        const $checkbox=$(checkbox);
        const id=$checkbox.data('id');
        const currentChecked=checkbox.checked;
        const nextStatus=currentChecked?0:1;

        if(!id) return;

        checkbox.disabled=true;

        ajax('POST',url(R.categoryStatus,id),{status:nextStatus})
            .done(function(res){
                notify(res.message || 'Category status updated.');
                refreshKnowledgeLive({forceFeed:true});
                loadSettings();
            })
            .fail(function(e){
                checkbox.checked=!currentChecked;
                notify(e.message || 'Category status could not be updated.','error');
            })
            .always(function(){
                checkbox.disabled=false;
            });
    });

    $('#egKnowledge').on('click','[data-egpk-action]',function(e) {
        e.preventDefault();
        e.stopPropagation();

        const a=$(this).data('egpk-action');
        const id=$(this).data('id');
        const extra=$(this).data();

        if(a==='new-knowledge') return openPostForm();
        if(a==='knowledge-retry') return loadKnowledge({library:state.library});
        if(a==='knowledge-library') {
            state.library=true;
            state.category='';
            state.categoryName='My Library';
            state.page=1;
            $('#kFeedTitle').text('My Library');
            return loadKnowledge({library:true});
        }
        if(a==='knowledge-categories-settings') return loadSettings();
        if(a==='knowledge-category-inline-settings') return loadSettings();
        if(a==='knowledge-category-new') return openCategorySettingsForm(null,false);

        if(a==='knowledge-category-edit') {
            const it=(state.settings.categories||[]).find(x=>String(x.sno)===String(id));
            return openCategorySettingsForm(it,true);
        }

        if(a==='knowledge-category-status') {
            return confirmAction(
                Number(extra.status)===0?'Activate category':'Deactivate category',
                'This changes category availability. Existing posts are retained.',
                'Continue',
                ()=>ajax('POST',url(R.categoryStatus,id),{status:Number(extra.status)}).done(()=>{
                    notify('Category status updated.');
                    refreshKnowledgeLive({forceFeed:true});
                    loadSettings();
                })
            );
        }

        if(a==='knowledge-category-delete') {
            return confirmAction(
                'Delete category',
                'The category will be removed from selection. Existing posts remain intact.',
                'Delete',
                ()=>ajax('DELETE',url(R.categoryDelete,id)).done(()=>{
                    notify('Category deleted.');
                    refreshKnowledgeLive({forceFeed:true});
                    loadSettings();
                })
            );
        }

        if(a==='follow-category') {
            const btn=$(this);
            const beforeFollowing=Number(btn.find('i').hasClass('mdi-bell'))===1;

            btn.prop('disabled',true);

            return ajax('POST',url(R.follow,id)).done(res=>{
                const following=Boolean(res?.data?.following);
                notify(res.message || 'Follow status updated.');

                btn.toggleClass('active',following)
                    .toggleClass('text-dark',!following)
                    .attr('title',following?'Unfollow':'Follow');

                btn.find('i').attr(
                    'class',
                    `mdi ${following?'mdi-bell':'mdi-bell-outline'}`
                );

                loadCategories()
                    .done(function(){
                        renderSidebar();
                    })
                    .fail(function(){
                        // Keep the successful local toggle even when a background
                        // category refresh fails.
                        btn.toggleClass('active',following)
                            .toggleClass('text-dark',!following)
                            .attr('title',following?'Unfollow':'Follow');
                    });
            }).fail(err=>{
                // No visual state was committed on failure.
                btn.toggleClass('active',beforeFollowing)
                    .toggleClass('text-dark',!beforeFollowing)
                    .attr('title',beforeFollowing?'Unfollow':'Follow')
                    .find('i')
                    .attr('class',`mdi ${beforeFollowing?'mdi-bell':'mdi-bell-outline'}`);

                notify(err.message||'Unable to update follow status','error');
            }).always(()=>{
                btn.prop('disabled',false);
            });
        }

        if(a==='view-knowledge') {
            return ajax('GET',url(R.show,id)).done(res=>{
                const d=res.data||{};
                state.currentPost=d.post;
                const post=d.post||{};
                const liked=Number(post.liked_by_me)>0;
                const saved=Number(post.saved_by_me)>0;
                const mediaHtml=renderMedia(d.media);
                const versions=(d.versions||[]).length
                    ? (d.versions||[]).map(v=>`<div class="border-bottom py-2">
                        <strong style="font-size:10px">v${esc(v.version_no)}</strong>
                        <span class="text-muted ms-2" style="font-size:8px">${esc(v.created_at||'')} · ${esc(v.edited_by_name||'')}</span>
                        <div class="small mt-1">${esc(v.title||'')}</div>
                    </div>`).join('')
                    : '<div class="text-muted" style="font-size:9px">No additional versions.</div>';

                $('#kDetailTitle').text(post.title||'Knowledge');
                $('#kDetailSubtitle').text(`${post.author_name||''} · ${post.published_at||post.created_at||''}`);
                $('#kDetailBody').html(`
                    <div class="k-post-body px-0">
                        
                        ${post.url_preview ? renderUrlPostCard(post.url_preview) : String(post.body_html||'')}
                        ${mediaHtml}
                    </div>
                    <div class="d-flex align-items-center gap-3 border-top mt-3 pt-3">
                        <button type="button" class="k-post-action ${liked?'active':''}" data-egpk-action="like-knowledge" data-id="${esc(post.sno)}" data-liked="${liked?1:0}">
                            <i class="mdi ${liked?'mdi-thumb-up':'mdi-thumb-up-outline'}"></i>
                            <span class="k-like-count">${esc(post.likes_count||0)}</span>
                        </button>
                        <button type="button" class="k-post-action ${saved?'active':''}" data-egpk-action="save-knowledge" data-id="${esc(post.sno)}" data-saved="${saved?1:0}">
                            <i class="mdi ${saved?'mdi-bookmark':'mdi-bookmark-outline'}"></i> Save
                        </button>
                        <button type="button" class="k-post-action" data-egpk-action="share" data-id="${esc(post.sno)}" data-k-title="${esc(post.title || "Knowledge")}">
                            <i class="mdi mdi-share-variant-outline"></i> Share
                        </button>
                        <span class="k-post-age" title="${esc(absoluteDate(post.published_at || post.created_at))}">
                            ${esc(relativeTime(post.published_at || post.created_at))}
                        </span>
                    </div>
                    <div class="border-top mt-3 pt-3">
                        <div class="fw-bold mb-2" style="font-size:11px">Version history</div>
                        ${versions}
                    </div>
                `);
                modal('kDetailModal').show();
            }).fail(err=>notify(err.message||'Unable to open post','error'));
        }

        if(a==='like-knowledge') {
            const btn=$(this);
            const currentlyLiked=Number(btn.data('liked'))===1;
            return ajax('POST',url(R.like,id)).done(function(res) {
                const liked=Boolean(res?.data?.liked);
                const countEl=btn.find('.k-like-count');
                const currentCount=Number(countEl.text())||0;
                const nextCount=Math.max(0,currentCount+(liked?1:-1));

                btn.data('liked',liked?1:0)
                    .toggleClass('active',liked)
                    .find('i')
                    .attr('class',`mdi ${liked?'mdi-thumb-up':'mdi-thumb-up-outline'}`);
                countEl.text(nextCount);
                notify(res.message||'Reaction updated.');
            }).fail(err=>{
                btn.data('liked',currentlyLiked?1:0);
                notify(err.message||'Reaction failed','error');
            });
        }

        if(a==='save-knowledge') {
            const btn=$(this);
            return ajax('POST',url(R.save,id)).done(function(res) {
                const saved=Boolean(res?.data?.saved);
                btn.data('saved',saved?1:0)
                    .toggleClass('active',saved)
                    .find('i')
                    .attr('class',`mdi ${saved?'mdi-bookmark':'mdi-bookmark-outline'}`);
                notify(res.message||'Library updated.');

                if(state.library && !saved) {
                    btn.closest('[data-k-post-id]').fadeOut(160,function(){
                        $(this).remove();
                        if(!$('.k-post[data-k-post-id]').length) {
                            $ws.html(`<div class="k-empty">
                                <i class="mdi mdi-bookmark-outline"></i>
                                <div class="fw-bold mb-1">Your library is empty</div>
                                <div class="small">Save a Knowledge post and it will appear here for quick access.</div>
                            </div>`);
                        }
                    });
                }
            }).fail(err=>notify(err.message||'Save failed','error'));
        }

        if(a==='share') return openShareForm(id,$(this).data('k-title'));
    });
    const imageViewerState = {
        images: [],
        index: 0,
        touchStartX: 0,
        touchStartY: 0,
        touching: false
    };

    function normalizeViewerImages(images) {
        return (Array.isArray(images) ? images : [])
            .map(item => ({
                url: String(item?.url || ''),
                name: String(item?.name || 'Knowledge image')
            }))
            .filter(item => item.url);
    }

    function renderImageViewerThumbs() {
        const $thumbs = $('#kImageViewerThumbs');
        $thumbs.empty();

        imageViewerState.images.forEach((item, index) => {
            const button = $(`
                <button type="button"
                    class="k-image-viewer-thumb ${index === imageViewerState.index ? 'active' : ''}"
                    data-k-viewer-thumb="${index}"
                    aria-label="View image ${index + 1}">
                    <img src="${esc(item.url)}" alt="${esc(item.name)}" loading="lazy">
                </button>
            `);

            $thumbs.append(button);
        });

        const activeThumb = $thumbs.find(`[data-k-viewer-thumb="${imageViewerState.index}"]`)[0];
        if (activeThumb && typeof activeThumb.scrollIntoView === 'function') {
            activeThumb.scrollIntoView({
                behavior:'smooth',
                inline:'center',
                block:'nearest'
            });
        }
    }

    function renderImageViewer(index) {
        const images = imageViewerState.images;
        if (!images.length) return;

        imageViewerState.index = Math.max(0, Math.min(Number(index) || 0, images.length - 1));

        const item = images[imageViewerState.index];
        const $image = $('#kImageViewerImage');
        const $loading = $('#kImageViewerLoading');

        $('#kImageViewerCounter').text(`${imageViewerState.index + 1} / ${images.length}`);
        $('#kImageViewerCaption').text(item.name || '');
        $('#kImageViewerPrev').prop('disabled', imageViewerState.index <= 0);
        $('#kImageViewerNext').prop('disabled', imageViewerState.index >= images.length - 1);
        $('#kImageViewerHint').toggleClass('d-none', images.length <= 1);

        $image.addClass('is-loading');
        $loading.addClass('show');

        const temp = new Image();
        temp.onload = function() {
            $image.attr('src', item.url);
            $image.attr('alt', item.name || 'Knowledge image');
            $image.removeClass('is-loading');
            $loading.removeClass('show');
        };
        temp.onerror = function() {
            $image.attr('src', item.url);
            $image.attr('alt', item.name || 'Knowledge image');
            $image.removeClass('is-loading');
            $loading.removeClass('show');
            notify('Unable to load this image.','error');
        };
        temp.src = item.url;

        renderImageViewerThumbs();
    }

    function openImageViewer(images, index) {
        const normalized = normalizeViewerImages(images);
        if (!normalized.length) {
            notify('This image is not available.','warning');
            return;
        }

        imageViewerState.images = normalized;
        imageViewerState.index = Math.max(0, Math.min(Number(index) || 0, normalized.length - 1));

        renderImageViewer(imageViewerState.index);

        const viewer = modal('kImageViewerModal');
        viewer.show();
    }

    function closeImageViewer() {
        const viewerEl = document.getElementById('kImageViewerModal');
        if (!viewerEl) return;

        const viewer = modal('kImageViewerModal');
        viewer.hide();

        imageViewerState.images = [];
        imageViewerState.index = 0;
        imageViewerState.touching = false;

        $('#kImageViewerImage').attr({
            src:'',
            alt:''
        });
        $('#kImageViewerThumbs').empty();
    }

    function changeImageViewer(direction) {
        if (!imageViewerState.images.length) return;

        const nextIndex = imageViewerState.index + Number(direction || 0);
        if (nextIndex < 0 || nextIndex >= imageViewerState.images.length) return;

        renderImageViewer(nextIndex);
    }

    $('#kImageViewerPrev').on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        changeImageViewer(-1);
    });

    $('#kImageViewerNext').on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        changeImageViewer(1);
    });

    $('#kImageViewerThumbs').on('click', '[data-k-viewer-thumb]', function(event) {
        event.preventDefault();
        event.stopPropagation();
        renderImageViewer(Number($(this).data('k-viewer-thumb')) || 0);
    });

    $('#kImageViewerModal').on('click', '[data-k-image-viewer-close]', function(event) {
        event.preventDefault();
        event.stopPropagation();
        closeImageViewer();
    });

    $('#kImageViewerModal').on('pointerdown', function(event) {
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        imageViewerState.touching = true;
        imageViewerState.touchStartX = event.clientX || 0;
        imageViewerState.touchStartY = event.clientY || 0;
    });

    $('#kImageViewerModal').on('pointerup', function(event) {
        if (!imageViewerState.touching) return;
        imageViewerState.touching = false;

        const dx = (event.clientX || 0) - imageViewerState.touchStartX;
        const dy = (event.clientY || 0) - imageViewerState.touchStartY;

        if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy)) return;

        if (dx < 0) {
            changeImageViewer(1);
        } else {
            changeImageViewer(-1);
        }
    });

    $('#kImageViewerModal').on('shown.bs.modal', function() {
        $('#kImageViewerImage').trigger('focus');
    });

    $(document).on('keydown.kImageViewer', function(event) {
        const viewerEl = document.getElementById('kImageViewerModal');
        if (!viewerEl || !viewerEl.classList.contains('show')) return;

        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            changeImageViewer(-1);
        } else if (event.key === 'ArrowRight') {
            event.preventDefault();
            changeImageViewer(1);
        } else if (event.key === 'Escape') {
            event.preventDefault();
            closeImageViewer();
        }
    });

    function getCarouselIndex(carousel) {
        const track = carousel?.querySelector('[data-k-image-track]');
        const slides = carousel ? Array.from(carousel.querySelectorAll('.k-image-slide')) : [];
        if (!track || !slides.length) return 0;

        const pageWidth = Math.max(1, track.clientWidth);
        const estimated = Math.round(track.scrollLeft / pageWidth);
        return Math.max(0, Math.min(estimated, slides.length - 1));
    }

    function updateImageCarousel(carousel, index, behavior) {
        const track = carousel?.querySelector('[data-k-image-track]');
        const slides = carousel ? Array.from(carousel.querySelectorAll('.k-image-slide')) : [];
        const dots = carousel ? Array.from(carousel.querySelectorAll('[data-k-image-dot]')) : [];
        //  console.log("slides- ",slides)      
        if (!track || !slides.length) return;
               
        const nextIndex = Math.max(0, Math.min(Number(index) || 0, slides.length - 1));
        const targetLeft = nextIndex * track.clientWidth;

        track.scrollTo({
            left: targetLeft,
            behavior: behavior || 'smooth'
        });

        const syncUi = function() {
            dots.forEach((dot, dotIndex) => {
                const active = dotIndex === nextIndex;
                dot.classList.toggle('active', active);
                dot.setAttribute('aria-current', active ? 'true' : 'false');
            });

            const prev = carousel.querySelector('[data-k-image-prev]');
            const next = carousel.querySelector('[data-k-image-next]');
            const countLabel = carousel.querySelector('[data-k-image-count-label]');
            const hint = carousel.querySelector('[data-k-image-hint]');
          
            if (prev) prev.disabled = nextIndex <= 0;
            if (next) next.disabled = nextIndex >= slides.length - 1;
            if (countLabel) countLabel.textContent = `${nextIndex + 1} / ${slides.length}`;
            if (hint) hint.classList.toggle('d-none', slides.length <= 1 || nextIndex >= 1);
        };

        syncUi();
    }

    function syncImageCarouselFromScroll(carousel) {
        const track = carousel?.querySelector('[data-k-image-track]');
        const slides = carousel ? Array.from(carousel.querySelectorAll('.k-image-slide')) : [];
        if (!track || !slides.length) return;

        const index = getCarouselIndex(carousel);

        slides.forEach((slide, slideIndex) => {
            const distance = Math.abs(slide.offsetLeft - track.scrollLeft);
            if (slideIndex === index || distance <= Math.max(8, track.clientWidth * 0.12)) {
                slide.setAttribute('aria-current', slideIndex === index ? 'true' : 'false');
            }
        });

        const dots = carousel.querySelectorAll('[data-k-image-dot]');
        dots.forEach((dot, dotIndex) => {
            const active = dotIndex === index;
            dot.classList.toggle('active', active);
            dot.setAttribute('aria-current', active ? 'true' : 'false');
        });

        const prev = carousel.querySelector('[data-k-image-prev]');
        const next = carousel.querySelector('[data-k-image-next]');
        const countLabel = carousel.querySelector('[data-k-image-count-label]');
        const hint = carousel.querySelector('[data-k-image-hint]');

        if (prev) prev.disabled = index <= 0;
        if (next) next.disabled = index >= slides.length - 1;
        if (countLabel) countLabel.textContent = `${index + 1} / ${slides.length}`;
        if (hint) hint.classList.toggle('d-none', slides.length <= 1 || index >= 1);
    }

    function initImageCarousels(scope) {
        const root = scope ? $(scope) : $('#egKnowledge');

        root.find('[data-k-image-carousel]').each(function() {
            const carousel = this;
            if (carousel.dataset.kImageReady === '1') return;

            const track = carousel.querySelector('[data-k-image-track]');
            if (!track) return;

            carousel.dataset.kImageReady = '1';

            let scrollFrame = null;
            track.addEventListener('scroll', function() {
                if (scrollFrame) return;

                scrollFrame = window.requestAnimationFrame(function() {
                    scrollFrame = null;
                    syncImageCarouselFromScroll(carousel);
                });
            }, { passive: true });

            track.addEventListener('keydown', function(event) {
                if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
                event.preventDefault();

                const current = getCarouselIndex(carousel);
                const nextIndex = current + (event.key === 'ArrowRight' ? 1 : -1);
                updateImageCarousel(carousel, nextIndex);
            });

            syncImageCarouselFromScroll(carousel);
        });
    }

    $('#egKnowledge').on('click', '[data-k-image-prev],[data-k-image-next],[data-k-image-dot]', function(event) {
        event.preventDefault();
        event.stopPropagation();

        const button = this;
        const carousel = button.closest('[data-k-image-carousel]');
        if (!carousel) return;

        const currentIndex = getCarouselIndex(carousel);
        let targetIndex = currentIndex;

        if (button.hasAttribute('data-k-image-prev')) {
            targetIndex = currentIndex - 1;
        } else if (button.hasAttribute('data-k-image-next')) {
            targetIndex = currentIndex + 1;
        } else {
            targetIndex = Number(button.getAttribute('data-k-image-dot')) || 0;
        }

        updateImageCarousel(carousel, targetIndex);
    });

    $('#egKnowledge').on('pointerdown', '[data-k-image-carousel]', function(event) {
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        this.dataset.kCarouselPointerX = String(event.clientX || 0);
        this.dataset.kCarouselPointerY = String(event.clientY || 0);
        this.dataset.kCarouselPointerMoved = '0';
    });

    $('#egKnowledge').on('pointermove', '[data-k-image-carousel]', function(event) {
        if (!this.dataset.kCarouselPointerX) return;

        const startX = Number(this.dataset.kCarouselPointerX);
        const startY = Number(this.dataset.kCarouselPointerY);
        const dx = (event.clientX || 0) - startX;
        const dy = (event.clientY || 0) - startY;

        if (Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy)) {
            this.dataset.kCarouselPointerMoved = '1';
        }
    });

    $('#egKnowledge').on('click', '[data-k-image-open]', function(event) {
        event.preventDefault();
        event.stopPropagation();

        const opener = this;
        const carousel = opener.closest('[data-k-image-carousel]');

        if (carousel) {
            const slides = Array.from(carousel.querySelectorAll('.k-image-slide'));
            const images = slides.map(slide => {
                const img = slide.querySelector('img');
                return {
                    url: img?.currentSrc || img?.src || '',
                    name: img?.alt || 'Knowledge image'
                };
            }).filter(item => item.url);

            const index = Math.max(0, Math.min(Number(opener.getAttribute('data-k-image-index')) || 0, images.length - 1));
            return openImageViewer(images, index);
        }

        const img = opener.querySelector('img');
        if (img) {
            return openImageViewer([{
                url: img.currentSrc || img.src || '',
                name: img.alt || 'Knowledge image'
            }], 0);
        }
    });

    $(window).on('resize.kImageCarousel', function(){
        initImageCarousels('#egKnowledge');
        $('#egKnowledge [data-k-image-carousel]').each(function(){
            const track = this.querySelector('[data-k-image-track]');
            const slides = Array.from(this.querySelectorAll('.k-image-slide'));
            if (!track || !slides.length) return;
            let activeIndex = 0;
            let closest = Infinity;
            slides.forEach((slide, index) => {
                const distance = Math.abs(slide.offsetLeft - track.scrollLeft);
                if (distance < closest) {
                    closest = distance;
                    activeIndex = index;
                }
            });
            updateImageCarousel(this, activeIndex, 'auto');
        });
    });

    const imageCarouselObserver = new MutationObserver(function(mutations){
        for (const mutation of mutations) {
            if (mutation.addedNodes && mutation.addedNodes.length) {
                initImageCarousels('#kWorkspace');
                return;
            }
        }
    });

    if (document.getElementById('kWorkspace')) {
        imageCarouselObserver.observe(document.getElementById('kWorkspace'), {childList:true, subtree:true});
        initImageCarousels('#kWorkspace');
    }

    $('#egKnowledge').on('click','[data-k-category]',function(){
        state.library=false;
        state.category=$(this).data('k-category')||'';
        state.page=1;

        if (!state.category) {
            state.categoryName='All categories';
        } else {
            const selectedCategory=state.categories.find(item=>String(item.sno)===String(state.category));
            state.categoryName=selectedCategory?.category_name || String($(this).text()).trim() || 'All categories';
        }

        $('#kFeedTitle').text(state.categoryName);
        loadKnowledge({library:false});
    });

    $('#egKnowledge').on('click','[data-k-type]',function(){
        state.library=false;
        state.contentType=$(this).data('k-type')||'all';
        state.page=1;
        renderTypes();
        loadKnowledge({library:false});
    });

    $('#kShareCopyLink').on('click',async function() {
        const id=$(this).data('knowledge-id');
        const link=getKnowledgeShareLink(id);
        try {
            if(navigator.clipboard?.writeText) {
                await navigator.clipboard.writeText(link);
            } else {
                const input=$('<input>').val(link).appendTo('body').select();
                document.execCommand('copy');
                input.remove();
            }
            notify('Knowledge link copied.');
        } catch(e) {
            notify('Unable to copy the Knowledge link.','error');
        }
    });

    $('#kShareForm').on('submit.kshare',function(e) {
        e.preventDefault();

        const id=$('#kShareResourceId').val();
        const payload=collectAudiencePayload('share');
        const hasSelection = Object.keys(payload).some(key => Array.isArray(payload[key]) ? payload[key].length : false);
        if(!hasSelection) {
            notify('Choose an audience before sharing.','warning');
            return;
        }

        const btn=$('#kShareSave')
            .prop('disabled',true)
            .html('<span class="spinner-border spinner-border-sm me-1"></span>Sharing…');

        const data = {
            audience_mode: payload.audience_mode,
            permission: $('#kSharePermission').val() || 'View',
            expires_at: $('#kShareExpiresAt').val() || null
        };
        Object.keys(payload).forEach(key => {
            if (key === 'audience_mode') return;
            data[key] = payload[key];
        });

        ajax('POST',url(R.knowledgeShareStore,id),data).done(function(res) {
            notify(res.message||'Knowledge audience updated successfully.');
            ajax('GET',url(R.knowledgeShares,id)).done(function(r) {
                renderExistingShares(r.data);
            });
        }).fail(function(err) {
            notify(err.message||'Unable to share this Knowledge post.','error');
        }).always(function() {
            btn.prop('disabled',false).html('<i class="mdi mdi-share-variant-outline me-1"></i>Share');
        });
    });

    $('#egKnowledge').on('error.kurlfavicon','img[data-k-url-favicon]',function() {
        $(this).addClass('d-none');
        $(this).siblings('[data-k-url-favicon-fallback]').removeClass('d-none');
    });

    $('#kPostForm').on('submit.k',function(e) {
        e.preventDefault();

        const form=this;
        const btn=$('#kPostSave')
            .prop('disabled',true)
            .html('<span class="spinner-border spinner-border-sm me-1"></span>Publishing…');

        const contentType=String($('#kPostType').val()||'text');
        if (contentType === 'text') syncKnowledgeTextEditor();

        const formData=new FormData(form);

        if(contentType==='text' && !String($('#kPostContent').val()||'').trim()) {
            btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish');
            notify('Add some Knowledge content before publishing.','warning');
            return;
        }

        if(contentType==='url') {
            const urlValue=String($('#kPostUrl').val()||'').trim();
            if(!urlValue) {
                btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish');
                notify('Enter a valid resource URL.','warning');
                return;
            }
        }

        if(['image','video','audio','pdf','files'].includes(contentType)) {
            const files=Array.from($('#kPostMedia')[0]?.files||[]);
            if(!files.length) {
                btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish');
                notify(`Choose ${contentType==='files'?'at least one file':'a file'} before publishing.`,'warning');
                return;
            }
        }

        formData.set('content_type',contentType);
        appendAudienceToFormData(formData,'post');

        const audiencePayload = collectAudiencePayload('post');
        const audienceHasSelection = Object.keys(audiencePayload).some(key => Array.isArray(audiencePayload[key]) ? audiencePayload[key].length : false);
        if(!audienceHasSelection) {
            btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish');
            notify('Choose who can access this Knowledge post.','warning');
            return;
        }

        if(contentType==='url') {
            const urlValue=String($('#kPostUrl').val()||'').trim();
            const description=String($('#kPostUrlDescription').val()||'').trim();
            formData.set('post_url',urlValue);
            formData.delete('url_description');
            formData.set('body_html',description);
        }

        ajax('POST',R.store,formData).done(function(r) {
            modal('kPostModal').hide();
            notify(r.message||'Knowledge post published.');
            state.page=1;
            refreshKnowledgeLive({forceFeed:true});
        }).fail(err=>notify(err.message||'Unable to publish post','error'))
            .always(()=>btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish'));
    });

    $('#kPostModal').on('dragover.kmedia','label.k-media-drop',function(e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });

    $('#kPostModal').on('dragleave.kmedia','label.k-media-drop',function() {
        $(this).removeClass('dragover');
    });

    $('#kPostModal').on('drop.kmedia','label.k-media-drop',function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
        const input=$('#kPostMedia')[0];
        if(!input || !e.originalEvent.dataTransfer?.files?.length) return;
        input.files=e.originalEvent.dataTransfer.files;
        $(input).trigger('change');
    });

    bindPostTypeCardEvents();
    bindAudienceDynamicEvents('post');
    bindAudienceDynamicEvents('share');

    state.settings={
        categories:[],can_manage:false,is_group_admin:false,is_company_admin:false
    };
    resetSettingsForm();
    loadKnowledge();
    startKnowledgeLiveRefresh();

    $('#kLiveNewView').on('click',function(e){
        e.preventDefault();
        clearLiveNewBanner();
        state.page=1;
        state.hasMore=true;
        refreshVisibleFeedPage();
    });
</script>
@endsection