@extends('layouts/layoutMaster')
@section('title', 'Knowledge Panel')
@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/sortablejs/sortable.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')

@endsection
@section('content')

<style>
    #egKnowledge{
        --k-red:var(--expense-primary,#b52b25);
        --k-red-dark:var(--expense-primary-hover,#8f1d1d);
        --k-gold:var(--expense-secondary,#c89a20);
        --k-navy:#203f6d;
        --k-purple:var(--expense-primary,#b52b25);
        --k-bg:#f5f6fb;--k-card:#fff;
        --k-border:#dfe4ed;
        --k-text:#18243a;
        --k-muted:#7d8a9e;
        background:var(--k-bg);
        min-height:calc(100vh - 70px);
        padding:8px 18px 24px;
        color:var(--k-text);
    }

    #egKnowledge .k-shell{
        display:grid;
        grid-template-columns:265px minmax(0,1fr) 300px;
        gap:18px;
        align-items:start;
    }

    #egKnowledge .k-sidebar,
    #egKnowledge .k-trending,
    #egKnowledge .k-library{
        background:#fff;
        border:1px solid var(--k-border);
        border-radius:13px;
    }

    #egKnowledge .k-sidebar{
        padding:14px 12px;
        position:sticky;
        top:78px;
    }
    #egKnowledge .k-right{
        /* padding:14px 12px; */
        position:sticky;
        top:78px;
    }

    #egKnowledge .k-new-post{
        width:100%;
        height:50px;
        border:0;
        border-radius:10px;
        background:var(--k-red);
        color:#fff;
        font-size:13px;
        font-weight:900;
        box-shadow:0 7px 17px rgba(32,63,109,.13);
    }

    #egKnowledge .k-new-post:hover{
        background:var(--k-red-dark);
    }

    #egKnowledge .k-side-title-row{
        display:flex;
        align-items:center;
        justify-content:space-between;
        padding:16px 10px 8px;
    }

    #egKnowledge .k-side-title{
        font-size:13px;
        font-weight:900;
        color:var(--k-red);
    }

    #egKnowledge .k-mini-settings{
        width:28px;
        height:28px;
        padding:0;
        border-radius:7px;
        border:1px solid var(--k-border);
        background:#fff;
        color:#8692a3;
        display:grid;
        place-items:center;
    }

    #egKnowledge .k-mini-settings:hover{
        border-color:#d9aaa6;
        color:var(--k-red);
    }

    #egKnowledge .k-category-row{
        display:grid;
        grid-template-columns:minmax(0,1fr) auto auto;
        gap:4px;
        align-items:center;
        padding:9px 8px;
        border-radius:8px;
    }

    #egKnowledge .k-category-row:hover,
    #egKnowledge .k-category-row.active{
        background:rgba(181,43,37,.06);
    }

    #egKnowledge .k-category-name{
        border:0;
        background:transparent;
        text-align:left;
        color:#283348;
        font-size:11px;
        font-weight:800;
        padding:0;
        min-width:0;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
    }

    #egKnowledge .k-category-row.active .k-category-name{
        color:var(--k-red);
    }

    #egKnowledge .k-category-count{
        font-size:9px;color:#929daf;
        padding-left:6px;
    }

    #egKnowledge .k-follow{
        border:0;
        background:transparent;
        color:#c7cfdb;
        padding:2px 1px;
        font-size:14px;
    }

    #egKnowledge .k-follow.active{
        color:var(--k-gold);
    }

    #egKnowledge .k-inline-gear{
        /* opacity:0;
        margin-left:1px; */
    }

    #egKnowledge .k-category-row:hover .k-inline-gear{
        opacity:1;
    }

    #egKnowledge .k-main{
        min-width:0;
    }

    #egKnowledge .k-feed-head{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:16px;
        padding:0 0 12px;
    }

    #egKnowledge .k-feed-title{
        font-size:20px;
        font-weight:900;
        color:var(--k-red);
        margin:0;
    }

    #egKnowledge .k-type-pills{
        display:flex;
        flex-wrap:wrap;
        justify-content:flex-end;
        gap:7px;
    }

    #egKnowledge .k-type-pill{
        border:1px solid var(--k-border);
        background:#fff;
        color:#31415d;
        border-radius:999px;
        padding:6px 12px;
        font-size:10px;
        font-weight:800;
    }

    #egKnowledge .k-type-pill.active{
        background:var(--k-red);
        border-color:var(--k-red);
        color:#fff;
    }

    #egKnowledge .k-post{
        background:#fff;
        border:1px solid var(--k-border);
        border-radius:12px;
        margin-bottom:12px;
        overflow:hidden;
    }

    #egKnowledge .k-post-head{
        display:flex;
        align-items:flex-start;
        justify-content:space-between;
        gap:12px;
        padding:15px 18px 10px;
    }

    #egKnowledge .k-author-wrap{
        display:flex;
        align-items:flex-start;
        gap:10px;
    }

    #egKnowledge .k-avatar{
        width:44px;
        height:44px;
        border-radius:50%;
        display:grid;
        place-items:center;
        color:#fff;
        font-size:12px;
        font-weight:900;
        flex:0 0 44px;
    }

    #egKnowledge .k-author{
        font-size:12px;
        font-weight:900;
        color:#16273f;
        line-height:1.2;
    }

    #egKnowledge .k-company-chip{
        display:inline-flex;
        margin-left:7px;
        padding:3px 7px;
        border-radius:999px;
        background:#f0edf8;
        color:#4e4191;
        font-size:8px;
        font-weight:900;
        vertical-align:1px;
    }

    #egKnowledge .k-post-meta{
        margin-top:4px;
        color:#7e8ca1;
        font-size:9px;
    }

    #egKnowledge .k-post-more{
        width:28px;
        height:28px;
        border:0;
        background:transparent;
        color:#9aa5b5;
        padding:0;
        border-radius:7px;
    }

    #egKnowledge .k-post-more:hover{
        background:#f7f8fa;
        color:var(--k-red);
    }

    #egKnowledge .k-post-body{
        padding:0 18px 13px;
        color:#11243b;
        font-size:13px;
        line-height:1.55;
    }

    #egKnowledge .k-post-body img{
        max-width:100%;
        height:auto;
        border-radius:8px;
    }

    #egKnowledge .k-post-actions{
        display:flex;
        align-items:center;
        gap:17px;
        border-top:1px solid #edf0f4;
        padding:10px 17px;
    }

    #egKnowledge .k-post-action{
        border:0;
        background:transparent;
        color:#718096;
        font-size:10px;
        font-weight:800;
        padding:0;
    }

    #egKnowledge .k-post-action:hover,#egKnowledge .k-post-action.active{
        color:var(--k-red);
    }

    #egKnowledge .k-post-actions .save{
        margin-left:auto;
    }

    #egKnowledge .k-trending{
        overflow:hidden;
    }

    #egKnowledge .k-trend-head{
        padding:13px 14px;
        border-bottom:2px solid var(--k-gold);
        font-size:13px;
        font-weight:900;
        color:#243247;
    }

    #egKnowledge .k-trend-row{
        display:grid;
        grid-template-columns:24px minmax(0,1fr);
        gap:9px;
        padding:12px 14px;
        border-bottom:1px solid #edf0f4;
    }

    #egKnowledge .k-trend-row:last-child{
        border-bottom:0;
    }

    #egKnowledge .k-trend-num{
        font-size:13px;
        font-weight:900;
        color:#c69c14;
    }

    #egKnowledge .k-trend-title{
        font-size:11px;
        font-weight:900;
        line-height:1.35;
        color:#1c2a40;
    }

    #egKnowledge .k-trend-meta{
        font-size:8px;
        color:#8390a3;
        margin-top:4px;
    }

    #egKnowledge .k-library{
        margin-top:14px;
        padding:14px;
    }

    #egKnowledge .k-library-title{
        display:flex;
        align-items:center;
        gap:9px;
        font-size:11px;
        font-weight:900;
        color:#263246;
    }

    #egKnowledge .k-library-title i{
        font-size:19px;
        color:var(--k-gold);
    }

    #egKnowledge .k-library-sub{
        margin-left:28px;
        color:#8290a4;
        font-size:9px;
    }

    #egKnowledge .k-pager{
        display:flex;
        justify-content:space-between;
        align-items:center;
        padding:6px 0 2px;
        color:#8b96a6;
        font-size:9px;
    }

    #egKnowledge .k-pager .btn{
        width:29px;
        height:28px;
        padding:0;
        border-radius:7px;
    }

    #egKnowledge .k-settings-modal .modal-content{
        border:0;
        border-radius:14px;
        overflow:hidden;
        box-shadow:0 20px 55px rgba(25,39,64,.18);
    }

    #egKnowledge .k-settings-tabs{
        display:flex;
        gap:6px;
        margin-bottom:13px;
    }

    #egKnowledge .k-settings-tab{
        border:1px solid var(--k-border);
        background:#fff;color:#67748a;
        border-radius:8px;
        padding:7px 11px;
        font-size:10px;
        font-weight:900;
    }

    #egKnowledge .k-settings-tab.active{
        background:var(--k-red);
        border-color:var(--k-red);
        color:#fff;
    }

    #egKnowledge .k-settings-toolbar{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        margin-bottom:10px;
    }

    #egKnowledge .k-settings-table-wrap{
        overflow:auto;
        border:1px solid var(--k-border);
        border-radius:10px;
    }
    
    #egKnowledge .k-settings-table{
        width:100%;
        min-width:760px;
        border-collapse:separate;
        border-spacing:0;
    }

    #egKnowledge .k-settings-table th{
        background:#fafbfd;
        color:#7d899b;
        padding:9px;
        font-size:8px;
        text-transform:uppercase;
        letter-spacing:.04em;
        text-align:left;
        border-bottom:1px solid var(--k-border);
    }

    #egKnowledge .k-settings-table td{
        padding:9px;
        font-size:10px;
        border-bottom:1px solid #eef1f5;
        vertical-align:middle;
    }

    #egKnowledge .k-settings-table tr:last-child td{
        border-bottom:0;
    }

    #egKnowledge .k-color-dot{
        display:inline-block;
        width:12px;
        height:12px;
        border-radius:50%;
        margin-right:5px;
        border:1px solid rgba(0,0,0,.08);
        vertical-align:-2px;
    }

    #egKnowledge .k-settings-actions{
        display:flex;
        gap:4px;
        justify-content:flex-end;
    }

    #egKnowledge .egpk-badge{
        display:inline-flex;
        align-items:center;
        border-radius:999px;
        padding:4px 7px;
        font-size:8px;
        font-weight:800;
        line-height:1;
        border:1px solid transparent;
    }

    #egKnowledge .egpk-badge-green{
        background:#eaf7ef;
        color:#2d8152;
        border-color:#ccebd8;
    }

    #egKnowledge .egpk-badge-red{
        background:#fff0ef;
        color:#b52b25;
        border-color:#f4d0cd;
    }

    #egKnowledge .egpk-badge-slate{
        background:#f2f4f7;
        color:#6f7c8e;
        border-color:#e5e9ef;
    }

    #egKnowledge .k-settings-actions .btn{
        width:29px;
        height:29px;
        padding:0;
        display:grid;
        place-items:center;
        border-radius:7px;
    }

    /* #egKnowledge .k-select2-wrap .select2-container{
        width:100%!important;
    }

    #egKnowledge .select2-container--default .select2-selection--single{
        height:36px!important;
        border:1px solid #dfe4eb!important;
        border-radius:8px!important;
    } */

    /* #egKnowledge .select2-container--default .select2-selection--single .select2-selection__rendered{
        line-height:34px!important;
        font-size:10px;
    }

    #egKnowledge .select2-container--default .select2-selection--single .select2-selection__arrow{
        height:34px!important;
    } */

    #egKnowledge .k-loading{
        padding:18px 0;
        color:#8290a4;
        font-size:11px;
    }

    #egKnowledge .k-skeleton-wrap{
        display:grid;
        gap:12px;
    }

    #egKnowledge .k-skeleton-card{
        background:#fff;
        border:1px solid var(--k-border);
        border-radius:12px;padding:15px 18px;
        overflow:hidden;
    }

    #egKnowledge .k-skeleton-line,
    #egKnowledge .k-skeleton-avatar,
    #egKnowledge .k-skeleton-chip{
        position:relative;
        overflow:hidden;
        background:linear-gradient(90deg,#eef1f5 25%,#f8f9fb 50%,#eef1f5 75%);
        background-size:220% 100%;
        animation:kSkeletonShimmer 1.45s ease-in-out infinite;
    }

    #egKnowledge .k-skeleton-line{
        height:10px;
        border-radius:999px;
        margin:8px 0;
    }

    #egKnowledge .k-skeleton-line.w-20{
        width:20%;
    }

    #egKnowledge .k-skeleton-line.w-35{
        width:35%;
    }

    #egKnowledge .k-skeleton-line.w-50{
        width:50%;
    }

    #egKnowledge .k-skeleton-line.w-65{
        width:65%;
    }

    #egKnowledge .k-skeleton-line.w-80{
        width:80%;
    }

    #egKnowledge .k-skeleton-line.w-92{
        width:92%;
    }

    #egKnowledge .k-skeleton-avatar{
        width:44px;
        height:44px;
        border-radius:50%;
        flex:0 0 44px;
    }

    #egKnowledge .k-skeleton-chip{
        width:66px;
        height:16px;
        border-radius:999px;
        display:inline-block;
        vertical-align:middle;
        margin-left:7px;
    }

    #egKnowledge .k-skeleton-actions{
        display:flex;
        gap:15px;
        border-top:1px solid #edf0f4;
        margin:12px -18px -15px;
        padding:10px 18px;
    }

    #egKnowledge .k-skeleton-action{
        width:48px;
        height:9px;
        border-radius:999px;
        position:relative;
        overflow:hidden;
        background:linear-gradient(90deg,#eef1f5 25%,#f8f9fb 50%,#eef1f5 75%);
        background-size:220% 100%;
        animation:kSkeletonShimmer 1.45s ease-in-out infinite;
    }

    #egKnowledge .k-skeleton-side{
        background:#fff;
        border:1px solid var(--k-border);
        border-radius:13px;
        padding:14px 12px;
    }
    
    #egKnowledge .k-skeleton-side .k-skeleton-line{
        margin:9px 0;
    }
    @keyframes kSkeletonShimmer{
        0%{
            background-position:200% 0;
        }
        100%{
            background-position:-20% 0;
        }
    }
    @media (prefers-reduced-motion:reduce){
        #egKnowledge .k-skeleton-line,
        #egKnowledge .k-skeleton-avatar,
        #egKnowledge .k-skeleton-chip,
        #egKnowledge .k-skeleton-action{
            animation:none;
        }
    }
    #egKnowledge .k-modal-kicker{
        font-size:8px;
        font-weight:900;
        letter-spacing:.12em;
        color:#8c96a7;
        margin-bottom:3px;
    }

    #egKnowledge .k-content-types{
        display:grid;
        grid-template-columns:repeat(4,minmax(0,1fr));
        gap:8px;
        margin-bottom:15px;
    }

    #egKnowledge .k-content-type{
        border:1px solid var(--k-border);
        border-radius:10px;
        background:#fff;
        color:#44536b;
        min-height:74px;
        padding:10px 8px;
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:center;
        gap:5px;
        font-size:9px;
        font-weight:800;
        transition:.16s ease;
    }

    #egKnowledge .k-content-type i{
        font-size:20px;
        color:#7f8b9f;
    }

    #egKnowledge .k-content-type:hover{
        border-color:#c7ceda;
        background:#fafbfe;
    }

    #egKnowledge .k-content-type.active{
        border-color:var(--k-red);
        background:rgba(181,43,37,.06);
        color:var(--k-red);
        box-shadow:0 4px 12px rgba(181,43,37,.08);
    }

    #egKnowledge .k-content-type.active i{
        color:var(--k-red);
    }

    #egKnowledge .k-editor-section{
        border:1px solid var(--k-border);
        border-radius:11px;
        background:#fbfcfe;
        padding:12px;
    }

    #egKnowledge .k-field-label{
        font-size:9px;
        font-weight:800;
        color:#52627c;
        margin-bottom:5px;
        display:block;
    }

    #egKnowledge .k-media-drop{
        border:1.5px dashed #cfd6e2;
        border-radius:11px;
        background:#fff;
        padding:19px 14px;
        text-align:center;
        cursor:pointer;
        transition:.16s ease;
    }

    #egKnowledge .k-media-drop:hover,
    #egKnowledge .k-media-drop.dragover{
        border-color:var(--k-red);
        background:rgba(181,43,37,.035);
    }

    #egKnowledge .k-media-drop i{
        font-size:30px;
        color:var(--k-red);
        display:block;
        margin-bottom:6px;
    }

    #egKnowledge .k-media-drop strong{
        display:block;
        color:#324563;
        font-size:10px;
    }

    #egKnowledge .k-media-drop span{
        display:block;
        color:#8c96a7;
        font-size:8px;
        margin-top:3px;
    }

    #egKnowledge .k-media-preview-list{
        display:grid;
        gap:7px;
        margin-top:9px;
    }

    #egKnowledge .k-media-preview{
        display:flex;
        align-items:center;
        gap:8px;
        padding:8px 9px;
        border:1px solid #edf0f4;
        background:#fff;
        border-radius:8px;
    }

    #egKnowledge .k-media-preview-icon{
        width:28px;
        height:28px;
        border-radius:7px;
        background:#f3f5f8;
        color:#738197;
        display:grid;
        place-items:center;
        flex:0 0 28px;
    }

    #egKnowledge .k-media-preview-name{
        flex:1;
        min-width:0;
        font-size:9px;
        font-weight:700;
        color:#3a4b66;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }

    #egKnowledge .k-media-preview-size{
        font-size:8px;
        color:#99a2b1;
    }

    #egKnowledge .k-url-preview{
        display:flex;
        gap:9px;
        align-items:flex-start;
        padding:10px;
        border:1px solid #e9edf3;
        border-radius:9px;
        background:#fff;
    }

    #egKnowledge .k-url-preview-icon{
        width:30px;
        height:30px;
        border-radius:8px;
        display:grid;
        place-items:center;
        background:#f0f3f8;
        color:var(--k-red);
        flex:0 0 30px;
    }

    #egKnowledge .k-post-media{
        display:grid;
        gap:8px;
        margin-top:10px;
    }

    #egKnowledge .k-post-media img,
    #egKnowledge .k-post-media video{
        width:100%;
        max-height:420px;
        object-fit:contain;
        background:#f5f6f9;
        border-radius:9px;
    }

    #egKnowledge .k-post-media audio{
        width:100%;
    }

    #egKnowledge .k-media-file{
        display:flex;
        align-items:center;
        gap:10px;
        padding:10px;
        border:1px solid #e8ecf2;
        border-radius:9px;
        background:#fbfcfe;
        color:#334763;
        text-decoration:none;
    }

    #egKnowledge .k-media-file:hover{
        background:#f7f8fb;
        border-color:#ccd3df;
    }

    #egKnowledge .k-media-file i{
        font-size:21px;
        color:var(--k-red);
    }

    #egKnowledge .k-media-file-main{
        min-width:0;
        flex:1;
    }

    #egKnowledge .k-media-file-name{
        font-size:9px;
        font-weight:800;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }

    #egKnowledge .k-media-file-meta{
        margin-top:2px;
        font-size:8px;
        color:#929bab;
    }

    #egKnowledge .k-share-tabs{
        display:grid;
        grid-template-columns:repeat(4,minmax(0,1fr));
        gap:6px;
        margin-bottom:12px;
    }

    #egKnowledge .k-share-tab{
        border:1px solid var(--k-border);
        background:#fff;
        border-radius:8px;
        padding:8px 5px;
        display:flex;
        align-items:center;
        justify-content:center;
        gap:4px;
        font-size:8px;
        font-weight:800;
        color:#68758a;
    }

    #egKnowledge .k-share-tab i{
        font-size:15px;
    }

    #egKnowledge .k-share-tab.active{
        color:var(--k-red);
        border-color:var(--k-red);
        background:rgba(181,43,37,.05);
    }

    #egKnowledge .k-share-panel,
    #egKnowledge .k-share-link-box{
        border:1px solid #edf0f4;
        border-radius:10px;
        padding:11px;
        background:#fbfcfe;
    }

    #egKnowledge .k-share-link-box{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
    }

    #egKnowledge .k-share-link-box .fw-bold{
        font-size:9px;
        color:#344662;
    }

    #egKnowledge .k-share-existing{
        border-top:1px solid #edf0f4;
        padding-top:10px;
    }

    #egKnowledge .k-library-button{
        width:100%;
        border:0;
        background:transparent;
        padding:0;
        text-align:left;
        color:inherit;
    }

    @media(max-width:600px){
        #egKnowledge .k-content-types{
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        #egKnowledge .k-share-tabs{
            grid-template-columns:repeat(2,minmax(0,1fr));
        }
    }

    #egKnowledge .k-empty{
        padding:65px 20px;
        text-align:center;
        color:#8290a4;
    }

    #egKnowledge .k-empty i{
        font-size:36px;
        display:block;
        margin-bottom:9px;
        color:#c0c7d3;
    }

    #egKnowledge .k-form-hint{
        font-size:8px;
        color:#8a96a6;
        margin-top:3px;
    }

    @media(max-width:1180px){
        #egKnowledge .k-shell{
            grid-template-columns:235px minmax(0,1fr);
        }
        #egKnowledge .k-right{
            display:none;
        }
    }

    @media(max-width:920px){
        #egKnowledge .k-shell{
            grid-template-columns:1fr;
        }
        #egKnowledge .k-sidebar{
            position:static;
            order:2;
        }
        .k-sidebar .k-cat-list{
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:2px;
        }
        #egKnowledge .k-feed-head{
            align-items:flex-start;
            flex-direction:column;
        }
        #egKnowledge .k-type-pills{
            justify-content:flex-start;
        }
    }
    @media(max-width:600px){
        #egKnowledge{
            padding:6px 9px 18px;
        }
        #egKnowledge .k-feed-title{
            font-size:17px;
        }
        #egKnowledge .k-type-pills{
            gap:5px;
        }
        #egKnowledge .k-type-pill{
            padding:5px 9px;
        }
        #egKnowledge .k-post-head{
            padding:12px;
        }
        #egKnowledge .k-post-body{
            padding:0 12px 10px;
        }
        #egKnowledge .k-post-actions{
            padding:9px 12px;gap:12px;
        }
    }
</style>

<div id="egKnowledge" class="eg-knowledge-page">
   
    
 

    <div id="kSettingsModal" class="modal fade k-settings-modal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl "><div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title">Knowledge settings</h5><div class="small text-muted">Manage categories and sub-categories in the same Knowledge workspace.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div id="kSettingsAlert" class="alert d-none py-2"></div>
                <div class="k-settings-tabs"><button type="button" class="k-settings-tab active" data-ksettings-tab="categories"><i class="mdi mdi-shape-outline me-1"></i>Categories</button><button type="button" class="k-settings-tab" data-ksettings-tab="subcategories"><i class="mdi mdi-format-list-bulleted-square me-1"></i>Sub-categories</button></div>
                <div id="kSettingsBody"></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Close</button></div>
        </div></div>
    </div>

    <div id="kFormModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered"><div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title" id="kFormTitle">Create</h5><div class="small text-muted" id="kFormSubtitle"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <form id="kForm"><div class="modal-body" id="kFormBody"></div><div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary btn-sm" id="kFormSave"><i class="mdi mdi-content-save-outline"></i> Save</button></div></form>
        </div></div>
    </div>

    <div id="kPostModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered "><div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title" id="kPostTitle">Create Knowledge Post</h5><div class="small text-muted">Share clear, searchable knowledge with your permitted audience.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <form id="kPostForm"><div class="modal-body" id="kPostBody"></div><div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary btn-sm" id="kPostSave"><i class="mdi mdi-send-outline"></i> Publish</button></div></form>
        </div></div>
    </div>


    <div id="kShareModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <div class="k-modal-kicker">KNOWLEDGE</div>
                        <h5 class="modal-title mb-1" id="kShareTitle">Share Knowledge</h5>
                        <div class="small text-muted" id="kShareSubtitle"></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="kShareForm">
                    <div class="modal-body">
                        <div class="k-share-tabs" role="tablist" aria-label="Share recipient type">
                            <button type="button" class="k-share-tab active" data-k-share-type="user">
                                <i class="mdi mdi-account-outline"></i>
                                <span>Person</span>
                            </button>
                            <button type="button" class="k-share-tab" data-k-share-type="company">
                                <i class="mdi mdi-office-building-outline"></i>
                                <span>Company</span>
                            </button>
                            <button type="button" class="k-share-tab" data-k-share-type="role">
                                <i class="mdi mdi-account-group-outline"></i>
                                <span>Role</span>
                            </button>
                            <button type="button" class="k-share-tab" data-k-share-type="group">
                                <i class="mdi mdi-earth"></i>
                                <span>Group</span>
                            </button>
                        </div>

                        <input type="hidden" name="resource_type" value="knowledge">
                        <input type="hidden" name="resource_id" id="kShareResourceId">
                        <input type="hidden" name="grantee_type" id="kShareGranteeType" value="user">

                        <div class="k-share-panel">
                            <label class="form-label">Share with</label>
                            <div id="kShareRecipientField"></div>
                            <div class="k-form-hint" id="kShareRecipientHint">Choose one active staff member.</div>
                        </div>

                        <div class="row g-3 mt-1">
                            <div class="col-md-6">
                                <label class="form-label">Permission</label>
                                <select class="form-select select3" id="kSharePermission" name="permission" data-placeholder="Select permission">
                                    <option value="View" selected>View only</option>
                                    <option value="Manage">Can manage</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Expires <span class="text-muted">(optional)</span></label>
                                <input class="form-control" type="datetime-local" name="expires_at" id="kShareExpiresAt">
                            </div>
                        </div>

                        <div class="k-share-link-box mt-3">
                            <div>
                                <div class="fw-bold">Quick share</div>
                                <div class="k-form-hint">Copy the Knowledge link or use your device share menu.</div>
                            </div>
                            <button type="button" class="btn btn-light btn-sm" id="kShareCopyLink">
                                <i class="mdi mdi-link-variant me-1"></i>Copy link
                            </button>
                        </div>

                        <div id="kShareExisting" class="mt-3 d-none"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="kShareSave">
                            <i class="mdi mdi-share-variant-outline me-1"></i>Share
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="kDetailModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered "><div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title" id="kDetailTitle">Knowledge</h5><div class="small text-muted" id="kDetailSubtitle"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body" id="kDetailBody"></div>
        </div></div>
    </div>

    <div id="kConfirmModal" class="modal fade" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="kConfirmTitle">Confirm</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="kConfirmBody"></div><div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-danger btn-sm" id="kConfirmYes">Continue</button></div></div></div>
    </div>

    <div class="card card-action egbm-card-shell">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Knowledge Panel</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item " aria-current="page">
                            <a href="javascript:void(0);" >
                                Tool Management
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Knowledge Panel
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>

            <div class="egbm-header-actions d-flex justify-content-end align-items-center gap-2 flex-wrap">
                <div class="k-type-pills" id="kTypePills"></div>
            </div>
        </div>

        <div class="card-body p-0  ">

            <div class="k-shell pt-2 px-2 bg-light">
                <aside class="k-sidebar" id="kSidebar"></aside>
                <main class="k-main">
                    <div class="k-feed-head">
                        <h1 class="k-feed-title" id="kFeedTitle">All categories</h1>
                        
                    </div>
                    <div id="kWorkspace"><div class="k-loading" aria-label="Loading Knowledge Panel" aria-busy="true"></div></div>
                </main>
                <aside class="k-right" id="kRight"></aside>
            </div>
        
        </div>
    </div>
</div>
    

<script>
    const $=window.jQuery;

    const config = @js(
        [
            'module' => 'knowledge',
            'csrf' => csrf_token(),
            'routes' => [
                'categories'=>route('productivity.knowledge.categories'),
                'data'=>route('productivity.knowledge.data'),
                'settings'=>route('productivity.knowledge.settings.data'),
                'categoryStore'=>route('productivity.knowledge.settings.category.store'),
                'categoryUpdate'=>url('/productivity/knowledge/settings/categories'),
                'categoryDelete'=>url('/productivity/knowledge/settings/categories'),
                'categoryStatus'=>url('/productivity/knowledge/settings/categories'),
                'subcategoryStore'=>route('productivity.knowledge.settings.subcategory.store'),
                'subcategoryUpdate'=>url('/productivity/knowledge/settings/subcategories'),
                'subcategoryDelete'=>url('/productivity/knowledge/settings/subcategories'),
                'subcategoryStatus'=>url('/productivity/knowledge/settings/subcategories'),
                'store'=>route('productivity.knowledge.store'),
                'show'=>url('/productivity/knowledge'),
                'update'=>url('/productivity/knowledge'),
                'like'=>url('/productivity/knowledge/{id}/like'),
                'save'=>url('/productivity/knowledge/{id}/save'),
                'reply'=>url('/productivity/knowledge'),
                'report'=>url('/productivity/knowledge'),
                'follow'=>url('/productivity/knowledge/categories'),
                'companies'=>route('productivity.companies'),
                'users'=>route('productivity.users'),
                'shares'=>route('productivity.shares.data'),
                'shareStore'=>route('productivity.shares.store'),
                'media'=>url('/productivity/knowledge/{id}/media')

            ],
        ]);

    const R = config.routes || {};
    const state = {
        page:1,
        perPage:10,
        search:'',
        category:'',
        contentType:'all',
        categories:[],
        subcategories:[],
        settings:{
            categories:[],
            subcategories:[],
            can_manage:false,
            is_group_admin:false,
            is_company_admin:false
        },
        settingsTab:'categories',
        currentPost:null,
        library:false,
        postType:'text'
    };
    const $ws=$('#kWorkspace');
    $.ajaxSetup({
        headers:{
            'X-CSRF-TOKEN':config.csrf,
            'X-Requested-With':'XMLHttpRequest',
            'Accept':'application/json'
        }
    });

    function esc(v) {
        return $('<div>').text(v==null?'':String(v)).html();
    }

    function url(base,id,suffix) {
        let v=String(base||'').replace(/\/$/,'');
        if(id!==undefined&&id!==null&&id!==''){
            v=v.includes('__ID__')?v.replace('__ID__',encodeURIComponent(id)):v.includes('{id}')?v.replace('{id}',encodeURIComponent(id)):`${v}/${encodeURIComponent(id)}`;
        }
        if(suffix)v=`${v}/${String(suffix).replace(/^\//,'')}`;
        return v;
    }

    function query(p) {
        const q=new URLSearchParams();
        Object.keys(p||{}).forEach(k=>{
            const v=p[k];
            if(v!==undefined&&v!==null&&v!=='')q.set(k,v);
        });
        return q.toString();
    }

    function ajax(method,endpoint,data,opts) {
        const o=opts||{}, isForm=data instanceof FormData;
        return $.ajax({
            url:endpoint,
            method:method||'GET',
            data:data||{},
            processData:!isForm,
            contentType:isForm?false:'application/x-www-form-urlencoded; charset=UTF-8',
            dataType:'json',
            timeout:o.timeout||30000,
            headers:{
                'X-CSRF-TOKEN':config.csrf,
                'X-Requested-With':'XMLHttpRequest',
                'Accept':'application/json'
            }
        }).then(function(res){
            return res;
        }).catch(function(xhr){
            const d=xhr?.responseJSON||xhr;
            if(d?.errors){
                const first=Object.values(d.errors)[0];
                if(Array.isArray(first)&&first[0])d.message=first[0];
            }
            return $.Deferred().reject(d||{
                message:'Server request failed.'
            }).promise();
        });
    }

    function modal(id) {
        return bootstrap.Modal.getOrCreateInstance(document.getElementById(id));
    }

    function notify(message,type) {
        const text=message||'Done.';
        if(typeof toastr==='undefined'){
            console.warn('Toastr is not loaded.',text);
            return;
        }
        if(type==='error')return toastr.error(text);
        if(type==='warning')return toastr.warning(text);
        return toastr.success(text);
    }

    function badge(status) {
        const s=String(status||'').toLowerCase();
        const cls=['active','published'].includes(s)?'egpk-badge-green':['inactive','unpublished','deprecated'].includes(s)?'egpk-badge-red':'egpk-badge-slate';
        return `<span class="egpk-badge ${cls}">${esc(status||'-')}</span>`;
    }

    function loadCategories() {
        return ajax('GET',R.categories).done(function(res){
            const d=res.data||{};
            state.categories=Array.isArray(d.categories)?d.categories:[];
            state.subcategories=Array.isArray(d.subcategories)?d.subcategories:[];
        });
    }

    function renderTypes() {
        const items=[['all','All'],['text','Text'],['image','Image'],['video','Video'],['audio','Audio'],['pdf','Pdf'],['url','Url'],['files','Files']];
        $('#kTypePills').html(items.map(x=>`<button type="button" class="k-type-pill ${state.contentType===x[0]?'active':''}" data-k-type="${x[0]}">${x[1]}</button>`).join(''));
    }

    function renderSidebar() {
        const cats=state.categories||[];
        const categoryRows=cats.map(c=>`
                <div class="k-category-row ${String(state.category)===String(c.sno)?'active':''} d-flex justify-content-between align-items-center">
                    <button type="button" class="k-category-name" data-k-category="${esc(c.sno)}">${esc(c.category_name)}</button>
                    <div class="d-flex gap-1 align-items-center">
                        <span class="k-category-count">${esc(c.post_count||0)}</span>
                        <button type="button" 
                            class="k-follow ${Number(c.following)?'active':''}" 
                            title="${Number(c.following)?'Unfollow':'Follow'}" 
                            data-egpk-action="follow-category" data-id="${esc(c.sno)}" data-k-no-select>
                            <i class="mdi ${Number(c.following)?'mdi-bell':'mdi-bell-outline'}"></i>
                        </button>
                        <!-- ${state.settings.can_manage?
                            `<button type="button" class="k-mini-settings k-inline-gear" 
                                title="Manage category" 
                                data-egpk-action="knowledge-category-inline-settings" 
                                data-id="${esc(c.sno)}" data-k-no-select>
                                    <i class="mdi mdi-cog-outline"></i>
                            </button>`
                        :''} -->
                    </div>
                </div>`).join('');
                    
        const settingsButton=state.settings.can_manage? `
            <button type="button" 
                class="k-mini-settings border-none text-dark" title="Manage categories" 
                data-egpk-action="knowledge-categories-settings">
                    <i class="mdi mdi-cog-outline"></i>
                    </button>`
            :'';

        $('#kSidebar').html(`
            <button type="button" class="k-new-post" 
                data-egpk-action="new-knowledge">
                    <i class="mdi mdi-square-edit-outline me-1"></i>New post
                </button>
                <div class="k-side-title-row">
                    <span class="k-side-title">All categories</span>
                    ${settingsButton}
                </div>
                <div class="k-cat-list">
                    <div class="k-category-row ${state.category===''?'active':''}">
                    <button type="button" class="k-category-name" data-k-category="">
                        All categories
                    </button>
                <span class="k-category-count">${cats.reduce((n,c)=>n+Number(c.post_count||0),0)}</span>
                <span></span>
                </div>${categoryRows}</div>
        `);
    }

    function formatFileSize(bytes) {
        const size = Number(bytes || 0);
        if (!size) return '0 KB';
        if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} KB`;
        return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    }

    function mediaIcon(media) {
        const type = String(media?.media_type || '').toLowerCase();
        if (type === 'image') return 'mdi-image-outline';
        if (type === 'video') return 'mdi-video-outline';
        if (type === 'audio') return 'mdi-music-note-outline';
        if (String(media?.mime_type || '').toLowerCase() === 'application/pdf') return 'mdi-file-pdf-box';
        return 'mdi-file-outline';
    }

    function renderMedia(mediaRows) {
        const rows = Array.isArray(mediaRows) ? mediaRows : [];
        if (!rows.length) return '';

        const html = rows.map(media => {
            const url = esc(media.url || '');
            const name = esc(media.original_name || 'Knowledge file');
            const type = String(media.media_type || '').toLowerCase();
            const mime = String(media.mime_type || '').toLowerCase();

            if (!url) {
                return `<div class="k-media-file">
                    <i class="mdi ${mediaIcon(media)}"></i>
                    <div class="k-media-file-main">
                        <div class="k-media-file-name">${name}</div>
                        <div class="k-media-file-meta">Media is available but its secure link could not be generated.</div>
                    </div>
                </div>`;
            }

            if (type === 'image') {
                return `<a href="${url}" target="_blank" rel="noopener noreferrer">
                    <img src="${url}" alt="${name}" loading="lazy">
                </a>`;
            }

            if (type === 'video') {
                return `<video controls preload="metadata">
                    <source src="${url}" type="${esc(mime)}">
                    Your browser does not support video playback.
                </video>`;
            }

            if (type === 'audio') {
                return `<audio controls preload="metadata">
                    <source src="${url}" type="${esc(mime)}">
                    Your browser does not support audio playback.
                </audio>`;
            }

            return `<a class="k-media-file" href="${url}" target="_blank" rel="noopener noreferrer">
                <i class="mdi ${mediaIcon(media)}"></i>
                <div class="k-media-file-main">
                    <div class="k-media-file-name">${name}</div>
                    <div class="k-media-file-meta">${formatFileSize(media.file_size)} · Open file</div>
                </div>
                <i class="mdi mdi-open-in-new"></i>
            </a>`;
        }).join('');

        return `<div class="k-post-media">${html}</div>`;
    }

    function renderPost(p) {
        const initials = (
            String(p.author_name || 'ERP User')
                .split(/\s+/)
                .filter(Boolean)
                .slice(0, 2)
                .map(x => x[0])
                .join('') || 'KN'
        ).toUpperCase();

        const liked = Number(p.liked_by_me) > 0;
        const saved = Number(p.saved_by_me) > 0;
        const mediaHtml = renderMedia(p.media);

        return `<article class="k-post" data-k-post-id="${esc(p.sno)}">
            <div class="k-post-head">
                <div class="k-author-wrap">
                    <div class="k-avatar" style="background:${esc(p.category_color || '#286fbe')}">${esc(initials)}</div>
                    <div>
                        <div class="k-author">
                            ${esc(p.author_name || 'ERP User')}
                            <span class="k-company-chip">${esc(p.company_name || 'Group')}</span>
                        </div>
                        <div class="k-post-meta">
                            ${esc(p.category_name || 'All categories')} › ${esc(p.subcategory_name || 'General')} · ${esc(p.published_at || p.created_at || '')}
                        </div>
                    </div>
                </div>
                <button type="button" class="k-post-more" data-egpk-action="view-knowledge" data-id="${esc(p.sno)}" title="Open knowledge">
                    <i class="mdi mdi-dots-horizontal"></i>
                </button>
            </div>
            <div class="k-post-body">
                ${String(p.body_html || '')}
                ${mediaHtml}
            </div>
            <div class="k-post-actions">
                <button type="button" class="k-post-action ${liked ? 'active' : ''}" data-egpk-action="like-knowledge" data-id="${esc(p.sno)}" data-liked="${liked ? 1 : 0}">
                    <i class="mdi ${liked ? 'mdi-thumb-up' : 'mdi-thumb-up-outline'}"></i>
                    <span class="k-like-count">${esc(p.likes_count || 0)}</span>
                </button>
                <button type="button" class="k-post-action" data-egpk-action="view-knowledge" data-id="${esc(p.sno)}">
                    <i class="mdi mdi-comment-outline"></i>
                    <span>${esc(p.replies_count || 0)}</span>
                </button>
                <button type="button" class="k-post-action" data-egpk-action="share" data-id="${esc(p.sno)}" data-k-title="${esc(p.title || "Knowledge")}">
                    <i class="mdi mdi-share-variant-outline"></i>
                    Share
                </button>
                <button type="button" class="k-post-action save ${saved ? 'active' : ''}" data-egpk-action="save-knowledge" data-id="${esc(p.sno)}" data-saved="${saved ? 1 : 0}">
                    <i class="mdi ${saved ? 'mdi-bookmark' : 'mdi-bookmark-outline'}"></i>
                    <span class="visually-hidden">${saved ? 'Saved' : 'Save'}</span>
                </button>
            </div>
        </article>`;
    }

    function renderTrending(rows) {
        const r = Array.isArray(rows) ? rows : [];
        const trendRows = r.length
            ? r.map((x, i) => `<div class="k-trend-row">
                <div class="k-trend-num">${i + 1}</div>
                <div>
                    <div class="k-trend-title">${esc(x.title || 'Knowledge post')}</div>
                    <div class="k-trend-meta">${esc(x.author_name || 'ERP User')} · 👍 ${esc(x.likes_count || 0)}</div>
                </div>
            </div>`).join('')
            : '<div class="k-trend-row"><div class="k-trend-title">No trending posts yet.</div></div>';

        return `<div class="k-trending">
            <div class="k-trend-head"><i class="mdi mdi-fire me-1 text-warning"></i>Trending · 30 days</div>
            ${trendRows}
        </div>
        <div class="k-library">
            <button type="button" class="k-library-button" data-egpk-action="knowledge-library">
                <div class="k-library-title"><i class="mdi mdi-bookmark"></i><span>My Library</span></div>
                <div class="k-library-sub">Saved posts &amp; files · Open library</div>
            </button>
        </div>`;
    }

    function pagination(p,last,total) {
        p=Number(p||1);
        last=Number(last||1);
        if(last<=1)return '';
        return `<div class="k-pager"><span>${esc(total||0)} posts</span><div class="btn-group"><button type="button" class="btn btn-light btn-sm" data-k-page="${Math.max(1,p-1)}" ${p<=1?'disabled':''}><i class="mdi mdi-chevron-left"></i></button><button type="button" class="btn btn-light btn-sm" data-k-page="${Math.min(last,p+1)}" ${p>=last?'disabled':''}><i class="mdi mdi-chevron-right"></i></button></div></div>`;
    }

    function loadSettingsSnapshot() {
        const fallback={
            data:{
                categories:[],subcategories:[],can_manage:false,is_group_admin:false,is_company_admin:false
            }
        };
        return ajax('GET',R.settings).then(function(res){
            return res;
        }).catch(function(){
            return fallback;
        });
    }

    function skeletonPost() {
        return `<article class="k-skeleton-card" aria-hidden="true"><div class="k-author-wrap"><div class="k-skeleton-avatar"></div><div style="flex:1;min-width:0"><div class="k-skeleton-line w-35"></div><div class="k-skeleton-line w-20"></div></div></div><div class="k-skeleton-line w-92"></div><div class="k-skeleton-line w-80"></div><div class="k-skeleton-line w-65"></div><div class="k-skeleton-line w-50"></div><div class="k-skeleton-actions"><div class="k-skeleton-action"></div><div class="k-skeleton-action"></div><div class="k-skeleton-action"></div><div class="k-skeleton-action" style="margin-left:auto"></div></div></article>`;
    }

    function skeletonSidebar() {
        return `<div class="k-skeleton-side" aria-hidden="true"><div class="k-skeleton-line w-80" style="height:34px;border-radius:9px;margin-bottom:18px"></div><div class="k-skeleton-line w-35"></div>${['92','65','80','50','80','65'].map(width=>`<div class="k-skeleton-line w-${width}"></div>`).join('')}</div>`;
    }

    function skeletonTrending() {
        return `<div class="k-skeleton-side" aria-hidden="true"><div class="k-skeleton-line w-50"></div>${Array.from({length:5},()=>`<div style="padding:8px 0 10px;border-bottom:1px solid #edf0f4"><div class="k-skeleton-line w-92"></div><div class="k-skeleton-line w-50"></div></div>`).join('')}<div style="margin-top:14px"><div class="k-skeleton-line w-35"></div><div class="k-skeleton-line w-65"></div></div></div>`;
    }

    function showKnowledgeSkeleton() {
        $('#kSidebar').html(skeletonSidebar());
        $ws.html(`<div class="k-loading" aria-label="Loading Knowledge Panel" aria-busy="true"><div class="k-skeleton-wrap">${Array.from({length:3},()=>skeletonPost()).join('')}</div></div>`);
        $('#kRight').html(skeletonTrending());
    }

    function renderWorkspaceRows(rows, pager) {
        const list = Array.isArray(rows) ? rows : [];
        if (!list.length) {
            return `<div class="k-empty">
                <i class="mdi ${state.library ? 'mdi-bookmark-outline' : 'mdi-school-outline'}"></i>
                <div class="fw-bold mb-1">${state.library ? 'Your library is empty' : 'No knowledge posts found'}</div>
                <div class="small mb-3">${state.library ? 'Save a Knowledge post and it will appear here for quick access.' : 'Try another category or create your first post.'}</div>
                ${state.library ? '' : '<button type="button" class="btn btn-primary btn-sm" data-egpk-action="new-knowledge"><i class="mdi mdi-plus me-1"></i>Create Post</button>'}
            </div>${pagination(pager?.current_page,pager?.last_page,pager?.total)}`;
        }

        return `${list.map(renderPost).join('')}${pagination(pager?.current_page,pager?.last_page,pager?.total)}`;
    }

    function loadKnowledge(options) {
        const opts = options || {};
        state.library = Boolean(opts.library);
        if (!state.library) state.contentType = state.contentType || 'all';
        
        $('#kFeedTitle').text(state.library ? 'My Library' : 'All categories');
        renderTypes();
        showKnowledgeSkeleton();

        const params = {
            page: state.page,
            per_page: state.perPage,
            search: state.search,
            category_id: state.library ? '' : state.category,
            content_type: state.library ? '' : (state.contentType === 'all' ? '' : state.contentType),
            saved_only: state.library ? 1 : '',
            sort: state.sort || 'newest'
        };

        $.when(
            loadCategories(),
            loadSettingsSnapshot(),
            ajax('GET', `${R.data}?${query(params)}`)
        ).done(function(catRes,settingsRes,dataRes) {
            const catData = catRes?.data || {};
            state.categories = Array.isArray(catData.categories) ? catData.categories : [];
            state.subcategories = Array.isArray(catData.subcategories) ? catData.subcategories : [];
            state.settings = settingsRes?.data || {
                categories: [],
                subcategories: [],
                can_manage: false,
                is_group_admin: false,
                is_company_admin: false
            };

            const payload = dataRes?.data || {};
            const pager = payload.rows || {};
            const rows = Array.isArray(pager.data) ? pager.data : [];
            state.trending = payload.trending || [];

            renderSidebar();
            $ws.html(renderWorkspaceRows(rows, pager));
            $('#kRight').html(renderTrending(state.trending));
        }).fail(function(err) {
            $ws.html(`<div class="k-empty">
                <i class="mdi mdi-cloud-alert-outline"></i>
                <div class="fw-bold mb-1">Knowledge could not be loaded</div>
                <div class="small mb-3">${esc(err.message || 'Server request failed.')}</div>
                <button type="button" class="btn btn-primary btn-sm" data-egpk-action="knowledge-retry">
                    <i class="mdi mdi-refresh me-1"></i>Retry
                </button>
            </div>`);
        });
    }

    function field(name,label,value,type,opt) {
        const o = opt || {};
        const required = o.required ? ' required' : '';

        if (type === 'select') {
            const options = (o.options || []).map(x => `<option value="${esc(x.value ?? x.id ?? x.sno)}" ${String(x.value ?? x.id ?? x.sno) === String(value ?? '') ? 'selected' : ''}>${esc(x.label ?? x.name ?? x.category_name ?? x.company_name)}</option>`).join('');
            const placeholder = o.placeholder !== false ? '<option value="">Select</option>' : '';

            return `<div class="col-md-${o.col || 6}">
                <label class="form-label" style="font-size:10px;font-weight:700">
                    ${esc(label)}${o.required ? ' *' : ''}
                </label>
                <select
                    id="${esc(o.id || name)}"
                    class="form-select ${o.select2 ? 'k-select3 select3' : 'select3'}"
                    data-placeholder="${esc(o.placeholder || 'Select')}"
                    name="${esc(name)}"${required}
                >
                    ${placeholder}
                    ${options}
                </select>
            </div>`;
        }

        if (type === 'textarea') {
            return `<div class="col-12">
                <label class="form-label" style="font-size:10px;font-weight:700">
                    ${esc(label)}${o.required ? ' *' : ''}
                </label>
                <textarea
                    class="form-control"
                    name="${esc(name)}"
                    rows="${o.rows || 5}"
                    placeholder="${esc(o.placeholder || '')}"${required}
                >${esc(value || '')}</textarea>
            </div>`;
        }

        return `<div class="col-md-${o.col || 6}">
            <label class="form-label" style="font-size:10px;font-weight:700">
                ${esc(label)}${o.required ? ' *' : ''}
            </label>
            <input
                class="form-control"
                type="${esc(type || 'text')}"
                name="${esc(name)}"
                value="${esc(value ?? '')}"
                placeholder="${esc(o.placeholder || '')}"${required}
            >
        </div>`;
    }

    function destroySelect3($select) {
        const $target = $select && $select.jquery ? $select : $($select);
        if (!$target.length) return;
        if ($target.hasClass('select2-hidden-accessible')) $target.select2('destroy');
        $target.removeAttr('data-select2-id');
    }

    function setSelect3($select, items, selected, placeholder, format) {
        const $target = $select && $select.jquery ? $select : $($select);
        if (!$target.length) return;
        const value = selected == null ? '' : String(selected);
        // destroySelect3($target);
        $target.empty().append('<option value=""></option>');
        (items || []).forEach(function(item) {
            const itemValue = item.value ?? item.sno ?? item.id;
            const label = format ? format(item) : (item.label ?? item.name ?? item.company_name ?? item.category_name ?? '');
            $target.append($('<option>', {
                value: itemValue, text: label
            }));
        });
        $target.val(value);
    }

    function initSelect3(scope) {
        if (typeof $.fn.select2 !== 'function') return;
        const $scope = scope ? $(scope) : $('#egKnowledge');
        $scope.find('select.select3').addBack('select.select3').each(function() {
            const $select = $(this);
            if ($select.hasClass('select2-hidden-accessible')) return;
            const $modal = $select.closest('.modal');
            $select.select2({
                width: '100%',
                dropdownParent: $modal.length ? $modal : $(document.body),
                placeholder: $select.data('placeholder') || $select.find('option:first').text() || 'Select',
                allowClear: true,
                closeOnSelect: !$select.prop('multiple'),
                minimumResultsForSearch: 8,
                maximumSelectionLength: $select.data('max-selected') ? Number($select.data('max-selected')) : 0,
            });
        });
    }

    function initSelect2Within(parent) {
        // Compatibility alias retained so existing BookMarks-style call sites do not change.
        // initSelect3(parent);
    }

    function openForm(title,subtitle,body,onSubmit) {
        $('#kFormTitle').text(title);
        $('#kFormSubtitle').text(subtitle||'');
        $('#kFormBody').html(body||'');
        // initSelect3('#kFormBody');
        $('#kForm').off('submit.k').on('submit.k',function(e){
            e.preventDefault();
            onSubmit($(this));
        });
        modal('kFormModal').show();
    }

    function submitForm(endpoint,method,formEl,after) {
        const btn = $('#kFormSave')
            .prop('disabled',true)
            .html('<span class="spinner-border spinner-border-sm me-1"></span>Saving…');

        ajax(
            method,
            endpoint,
            Object.fromEntries(formEl.serializeArray().map(x => [x.name,x.value]))
        ).done(function(res) {
            modal('kFormModal').hide();
            notify(res.message || 'Saved.');
            if (after) after(res);
        }).fail(function(e) {
            notify(e.message || 'Save failed.','error');
        }).always(()=>btn.prop('disabled',false).html('<i class="mdi mdi-content-save-outline"></i> Save'));
    }

    const knowledgeContentTypes = {
        text: {
            label:'Text',
            icon:'mdi-format-text',
            description:'Write searchable knowledge directly.'
        },
        image: {
            label:'Image',
            icon:'mdi-image-outline',
            description:'Upload diagrams, screenshots or photos.'
        },
        video: {
            label:'Video',
            icon:'mdi-video-outline',
            description:'Share a short video walkthrough.'
        },
        audio: {
            label:'Audio',
            icon:'mdi-music-note-outline',
            description:'Share audio guidance or training.'
        },
        pdf: {
            label:'Pdf',
            icon:'mdi-file-pdf-box',
            description:'Upload a PDF reference document.'
        },
        url: {
            label:'Url',
            icon:'mdi-link-variant',
            description:'Publish a useful external resource.'
        },
        files: {
            label:'Files',
            icon:'mdi-file-multiple-outline',
            description:'Attach one or more supporting files.'
        }
    };

    function createPostTypeCards(activeType) {
        return Object.entries(knowledgeContentTypes).map(([type,item]) => `
            <button type="button" class="k-content-type ${activeType === type ? 'active' : ''}" data-k-post-type="${type}">
                <i class="mdi ${item.icon}"></i>
                <span>${item.label}</span>
            </button>
        `).join('');
    }

    function postTypeAccept(type) {
        if (type === 'image') return 'image/jpeg,image/png,image/webp';
        if (type === 'video') return 'video/mp4,video/webm';
        if (type === 'audio') return 'audio/mpeg,audio/wav';
        if (type === 'pdf') return 'application/pdf';
        if (type === 'files') return '.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv,.jpg,.jpeg,.png,.webp';
        return '';
    }

    function postTypeSection(type) {
        if (type === 'text') {
            return `<div class="k-editor-section">
                <label class="k-field-label">Knowledge content</label>
                <textarea class="form-control" id="kPostContent" name="body_html" rows="10" placeholder="Write the procedure, policy, update or learning note…"></textarea>
                <div class="k-form-hint mt-2">Keep the content clear, concise and searchable.</div>
            </div>`;
        }

        if (type === 'url') {
            return `<div class="k-editor-section">
                <label class="k-field-label">Resource URL</label>
                <input class="form-control" id="kPostUrl" name="post_url" type="url" placeholder="https://example.com/help/article">
                <div id="kUrlPreview" class="mt-2 d-none"></div>
                <label class="k-field-label mt-3">Description <span class="text-muted">(optional)</span></label>
                <textarea class="form-control" id="kPostUrlDescription" name="url_description" rows="4" placeholder="Explain why this resource is useful…"></textarea>
            </div>`;
        }

        const multiple = type === 'files';
        return `<div class="k-editor-section">
            <label class="k-field-label">${knowledgeContentTypes[type].label} ${multiple ? 'attachments' : 'file'}</label>
            <label class="k-media-drop" for="kPostMedia">
                <i class="mdi ${knowledgeContentTypes[type].icon}"></i>
                <strong>Click to choose ${multiple ? 'files' : 'a file'}</strong>
                <span>${knowledgeContentTypes[type].description} · Up to 50 MB per file</span>
            </label>
            <input class="d-none" type="file" id="kPostMedia" name="media[]" accept="${postTypeAccept(type)}" ${multiple ? 'multiple' : ''}>
            <div id="kPostMediaPreview" class="k-media-preview-list"></div>
            <div class="k-form-hint mt-2">Only supported file types are accepted by the Knowledge service.</div>
        </div>`;
    }

    function updatePostType(type) {
        state.postType = type;
        $('#kPostType').val(type);
        $('#kPostTypeCards').html(createPostTypeCards(type));
        $('#kPostContentArea').html(postTypeSection(type));

        if (type === 'image' || type === 'video' || type === 'audio' || type === 'pdf' || type === 'files') {
            $('#kPostMedia').off('change.kmedia').on('change.kmedia', function() {
                const files = Array.from(this.files || []);
                const preview = files.map(file => `<div class="k-media-preview">
                    <div class="k-media-preview-icon"><i class="mdi ${knowledgeContentTypes[type].icon}"></i></div>
                    <div class="k-media-preview-name">${esc(file.name)}</div>
                    <div class="k-media-preview-size">${formatFileSize(file.size)}</div>
                </div>`).join('');
                $('#kPostMediaPreview').html(preview);
            });
        }

        if (type === 'url') {
            $('#kPostUrl').off('input.kurl').on('input.kurl', function() {
                const value = String(this.value || '').trim();
                if (!value) {
                    $('#kUrlPreview').addClass('d-none').empty();
                    return;
                }
                $('#kUrlPreview').removeClass('d-none').html(`<div class="k-url-preview">
                    <div class="k-url-preview-icon"><i class="mdi mdi-link-variant"></i></div>
                    <div>
                        <div class="k-field-label mb-0">External resource</div>
                        <div class="k-form-hint text-break">${esc(value)}</div>
                    </div>
                </div>`);
            });
        }
    }

    function openPostForm() {
        const cats = state.categories || [];
        const subs = state.subcategories || [];

        $('#kPostBody').html(`
            <div class="mb-3">
                <div class="k-modal-kicker">CREATE KNOWLEDGE</div>
                <div class="fw-bold" style="font-size:13px">What would you like to share?</div>
                <div class="small text-muted">Choose the format first, then add only the fields you need.</div>
            </div>

            <input type="hidden" id="kPostType" name="content_type" value="text">
            <div id="kPostTypeCards" class="k-content-types">${createPostTypeCards('text')}</div>

            <div class="row g-3">
                ${field('title','Title','','text',{required:true,col:8,placeholder:'Give your knowledge a clear, searchable title'})}
                ${field('status','Status','published','select',{required:true,col:4,options:[
                    {value:'published',label:'Publish now'},
                    {value:'draft',label:'Save draft'}
                ]})}
                ${field('category_id','Category','','select',{required:true,col:4,id:'kPostCategory',options:cats.map(c=>({value:c.sno,label:c.category_name})),select2:true,placeholder:'Choose category'})}
                ${field('subcategory_id','Sub-category','','select',{required:true,col:4,id:'kPostSubcategory',options:[],select2:true,placeholder:'Choose sub-category'})}
                ${field('audience_scope','Audience','Group','select',{required:true,col:4,options:[
                    {value:'Group',label:'Group-wide'},
                    {value:'Company',label:'Company'},
                    {value:'Private',label:'Only me'}
                ]})}
            </div>

            <div id="kPostContentArea" class="mt-3"></div>
        `);

        modal('kPostModal').show();
        initPostSelects(cats,subs);
        updatePostType('text');

        $('#kPostTypeCards').off('click.ktype').on('click.ktype','[data-k-post-type]',function() {
            updatePostType(String($(this).data('k-post-type')));
        });
    }

    function initPostSelects(cats,subs) {
        // destroySelect3($('#kPostCategory'));
        // destroySelect3($('#kPostSubcategory'));
        // initSelect3('#kPostModal');

        $('#kPostCategory').off('change.k').on('change.k',function() {
            const id=this.value;
            const options=subs
                .filter(x=>String(x.category_id)===String(id))
                .map(x=>`<option value="${esc(x.sno)}">${esc(x.subcategory_name)}</option>`)
                .join('');

            // destroySelect3($('#kPostSubcategory'));
            $('#kPostSubcategory')
                .html(`<option value="">Choose sub-category</option>${options}`)
                .val('');
            // initSelect3('#kPostModal');
        });
    }

    function getKnowledgeShareLink(id) {
        return `${window.location.origin}/productivity/knowledge/${encodeURIComponent(id)}`;
    }

    function shareRecipientHtml(type) {
        if (type === 'company') {
            return `<select class="form-select select3" id="kShareCompany" name="grantee_id" data-placeholder="Choose company">
                <option value="">Choose company</option>
            </select>`;
        }

        if (type === 'role') {
            return `<select class="form-select select3" id="kShareRole" name="grantee_id" data-placeholder="Choose role">
                <option value="">Choose role</option>
                <option value="Super Admin">Super Admin</option>
                <option value="Group Admin">Group Admin</option>
                <option value="Company Admin">Company Admin</option>
                <option value="Module Manager">Module Manager</option>
                <option value="Staff">Staff</option>
                <option value="Auditor">Auditor</option>
            </select>`;
        }

        if (type === 'group') {
            return `<div class="form-control bg-light">Everyone in the Knowledge group</div>`;
        }

        return `<select class="form-select select3" id="kShareUser" name="grantee_id" data-placeholder="Choose staff member">
            <option value="">Choose staff member</option>
        </select>`;
    }

    function updateShareRecipientType(type) {
        $('#kShareGranteeType').val(type);
        $('#kShareRecipientField').html(shareRecipientHtml(type));
        $('#kShareRecipientHint').text(
            type === 'company'
                ? 'Everyone in the selected active company can access the Knowledge post.'
                : type === 'role'
                    ? 'Every active user with this role will be eligible to access the post.'
                    : type === 'group'
                        ? 'This will make the post available to the entire group.'
                        : 'Choose one active staff member.'
        );

        // initSelect3('#kShareRecipientField');

        if (type === 'company') {
            ajax('GET',R.companies).done(function(res) {
                const rows = Array.isArray(res.data) ? res.data : [];
                const options = rows.map(x=>`<option value="${esc(x.sno)}">${esc(x.company_name)}</option>`).join('');
                $('#kShareCompany').html(`<option value="">Choose company</option>${options}`);
                // destroySelect3($('#kShareCompany'));
                // initSelect3('#kShareRecipientField');
            }).fail(err=>notify(err.message||'Unable to load companies','error'));
        }

        if (type === 'user') {
            ajax('GET',R.users).done(function(res) {
                const rows = Array.isArray(res.data) ? res.data : [];
                const options = rows.map(x=>`<option value="${esc(x.sno)}">${esc(x.staff_name)}${x.email_id ? ` · ${esc(x.email_id)}` : ''}</option>`).join('');
                $('#kShareUser').html(`<option value="">Choose staff member</option>${options}`);
                // destroySelect3($('#kShareUser'));
                // initSelect3('#kShareRecipientField');
            }).fail(err=>notify(err.message||'Unable to load staff members','error'));
        }
    }

    function renderExistingShares(rows) {
        const list = Array.isArray(rows) ? rows : [];
        if (!list.length) {
            $('#kShareExisting').addClass('d-none').empty();
            return;
        }

        const html = list.map(row => `<div class="border-bottom py-2">
            <div class="d-flex justify-content-between gap-2">
                <strong style="font-size:9px">${esc(row.grantee_type || 'Recipient')}</strong>
                <span class="text-muted" style="font-size:8px">${esc(row.permission || 'View')}</span>
            </div>
            <div class="text-muted" style="font-size:8px">Grant #${esc(row.sno)}</div>
        </div>`).join('');

        $('#kShareExisting')
            .removeClass('d-none')
            .html(`<div class="k-share-existing">
                <div class="fw-bold mb-1" style="font-size:9px">Existing access</div>
                ${html}
            </div>`);
    }

    function openShareForm(id,title) {
        const shareTitle = title || (
            state.currentPost && String(state.currentPost.sno) === String(id)
                ? state.currentPost.title
                : 'Knowledge'
        );

        $('#kShareResourceId').val(id);
        $('#kShareGranteeType').val('user');
        $('#kShareTitle').text('Share Knowledge');
        $('#kShareSubtitle').text(`Share “${shareTitle || 'Knowledge'}” securely with the right audience.`);
        $('#kShareExpiresAt').val('');
        $('#kSharePermission').val('View');
        $('#kShareCopyLink').data('knowledge-id',id);
        $('#kShareExisting').addClass('d-none').empty();
        $('#kShareModal .k-share-tab').removeClass('active');
        $('#kShareModal .k-share-tab[data-k-share-type="user"]').addClass('active');

        updateShareRecipientType('user');
        modal('kShareModal').show();

        ajax('GET',R.shares+`?${query({resource_type:'knowledge',resource_id:id})}`).done(function(res) {
            renderExistingShares(res.data);
        });
    }

    function confirmAction(title,body,yes,fn) {
        $('#kConfirmTitle').text(title);
        $('#kConfirmBody').text(body);
        $('#kConfirmYes').text(yes||'Continue').off('click.k').on('click.k',function(){
            const b=$(this).prop('disabled',true);
            let req;
            try{
                req=fn();
            } catch(e){
                notify(e.message||'Action failed.','error');
                b.prop('disabled',false);
                return;
            }if(req&&typeof req.always==='function'){
                req.always(function(){
                    b.prop('disabled',false);
                    modal('kConfirmModal').hide();
                });
            } else{
                Promise.resolve(req).finally(function(){
                    b.prop('disabled',false);
                    modal('kConfirmModal').hide();
                });
            }
        });
        modal('kConfirmModal').show();
    }

    function renderSettings() {
        const can=state.settings.can_manage;
        let html='';
        if(state.settingsTab==='categories'){
            html=`<div class="k-settings-toolbar"><div><div class="fw-bold" style="font-size:12px">Categories</div><div class="text-muted" style="font-size:9px">${esc(state.settings.categories.length)} configured category(ies).</div></div>${can?'<button type="button" class="btn btn-primary btn-sm" data-egpk-action="knowledge-category-new"><i class="mdi mdi-plus"></i> Add category</button>':''}</div><div class="k-settings-table-wrap"><table class="k-settings-table"><thead><tr><th>Category</th><th>Company</th><th>Posts</th><th>Status</th><th class="text-end">Actions</th></tr></thead><tbody>${state.settings.categories.length?state.settings.categories.map(c=>`<tr><td><span class="k-color-dot" style="background:${esc(c.color||'#b52b25')}"></span><strong>${esc(c.category_name)}</strong></td><td>${esc(c.company_name||'Group')}</td><td>${esc(c.post_count||0)}</td><td>${badge(Number(c.status)===0?'Active':'Inactive')}</td><td><div class="k-settings-actions">${can?`<button type="button" class="btn btn-light" title="Edit" data-egpk-action="knowledge-category-edit" data-id="${esc(c.sno)}"><i class="mdi mdi-pencil-outline"></i></button><button type="button" class="btn btn-light" title="Toggle active / inactive" data-egpk-action="knowledge-category-status" data-id="${esc(c.sno)}" data-status="${Number(c.status)===0?1:0}"><i class="mdi ${Number(c.status)===0?'mdi-toggle-switch-outline':'mdi-toggle-switch-off-outline'}"></i></button><button type="button" class="btn btn-light text-danger" title="Delete" data-egpk-action="knowledge-category-delete" data-id="${esc(c.sno)}"><i class="mdi mdi-delete-outline"></i></button>`:''}</div></td></tr>`).join(''):`<tr><td colspan="5">${emptyHtml('mdi-shape-outline','No categories configured.')}</td></tr>`}</tbody></table></div>`;
        } else{
            html=`<div class="k-settings-toolbar"><div><div class="fw-bold" style="font-size:12px">Sub-categories</div><div class="text-muted" style="font-size:9px">${esc(state.settings.subcategories.length)} configured sub-category(ies).</div></div>${can?'<button type="button" class="btn btn-primary btn-sm" data-egpk-action="knowledge-subcategory-new"><i class="mdi mdi-plus"></i> Add sub-category</button>':''}</div><div class="k-settings-table-wrap"><table class="k-settings-table"><thead><tr><th>Sub-category</th><th>Category</th><th>Company</th><th>Posts</th><th>Status</th><th class="text-end">Actions</th></tr></thead><tbody>${state.settings.subcategories.length?state.settings.subcategories.map(c=>`<tr><td><strong>${esc(c.subcategory_name)}</strong></td><td>${esc(c.category_name)}</td><td>${esc(c.company_name||'Group')}</td><td>${esc(c.post_count||0)}</td><td>${badge(Number(c.status)===0?'Active':'Inactive')}</td><td><div class="k-settings-actions">${can?`<button type="button" class="btn btn-light" title="Edit" data-egpk-action="knowledge-subcategory-edit" data-id="${esc(c.sno)}"><i class="mdi mdi-pencil-outline"></i></button><button type="button" class="btn btn-light" title="Toggle active / inactive" data-egpk-action="knowledge-subcategory-status" data-id="${esc(c.sno)}" data-status="${Number(c.status)===0?1:0}"><i class="mdi ${Number(c.status)===0?'mdi-toggle-switch-outline':'mdi-toggle-switch-off-outline'}"></i></button><button type="button" class="btn btn-light text-danger" title="Delete" data-egpk-action="knowledge-subcategory-delete" data-id="${esc(c.sno)}"><i class="mdi mdi-delete-outline"></i></button>`:''}</div></td></tr>`).join(''):`<tr><td colspan="6">${emptyHtml('mdi-format-list-bulleted-square','No sub-categories configured.')}</td></tr>`}</tbody></table></div>`;
        }
        $('#kSettingsBody').html(html);
    }

    function emptyHtml(icon,text) {
        return `<div class="text-center text-muted py-4"><i class="mdi ${esc(icon)} fs-3 d-block mb-2"></i><span style="font-size:10px">${esc(text)}</span></div>`;
    }

    function loadSettings() {
        return ajax('GET',R.settings).done(function(res){
            state.settings=res.data||{
                categories:[],subcategories:[],can_manage:false,is_group_admin:false,is_company_admin:false
            };
            if(!state.settings.can_manage){
                notify('You do not have permission to manage Knowledge settings.','error');
                return;
            }renderSettings();
            modal('kSettingsModal').show();
        }).fail(e=>notify(e.message||'Unable to load settings','error'));
    }

    function categoryForm(item) {
        const group=!!state.settings.is_group_admin;
        const scope=`${group?'<option value="">Group-wide</option>':''}${(window.__kCompanies||[]).map(c=>`<option value="${esc(c.sno)}" ${String(c.sno)===String(item?.company_id||'')?'selected':''}>${esc(c.company_name)}</option>`).join('')}`;
        return `<div class="row g-3">${field('category_name','Category Name',item?.category_name||'','text',{required:true,col:7})}${field('color','Colour',item?.color||(getComputedStyle(document.documentElement).getPropertyValue('--expense-primary').trim()||'#b52b25'),'color',{col:2})}<div class="col-md-3"><label class="form-label" style="font-size:10px;font-weight:700">Scope</label><select id="kCategoryCompany" class="form-select k-select3 select3" data-placeholder="${group?'Group-wide':'Company'}" name="company_id">${scope}</select></div></div><div class="k-form-hint mt-2">Active categories are available in New Post. Deactivating a category also deactivates its sub-categories.</div>`;
    }

    function subcategoryForm(item) {
        const cats=(state.settings.categories||[]).filter(c=>Number(c.status)===0||String(c.sno)===String(item?.category_id||''));
        const opts=cats.map(c=>({
            value:c.sno,label:Number(c.status)===0?c.category_name:`${c.category_name} (Inactive)`
        }));
        return `<div class="row g-3">${field('category_id','Category',item?.category_id||'','select',{required:true,col:5,id:'kSettingsCategory',options:opts,select2:true})}${field('subcategory_name','Sub-category Name',item?.subcategory_name||'','text',{required:true,col:7})}</div><div class="k-form-hint mt-2">Moving a sub-category requires an active category. You can rename an inactive sub-category without activating its parent.</div>`;
    }

    function loadKnowledgeCompanies() {
        if(Array.isArray(window.__kCompanies)&&window.__kCompanies.length)return $.Deferred().resolve(window.__kCompanies).promise();
        return ajax('GET',R.companies).done(function(res){
            window.__kCompanies=Array.isArray(res.data)?res.data:[];
        });
    }

    function openCategorySettingsForm(item,edit) {
        loadKnowledgeCompanies().always(function(){
            openForm(edit?'Edit Category':'Create Category','Manage the category used across Knowledge posts.',edit?categoryForm(item):categoryForm({}),function(f){
                submitForm(edit?url(R.categoryUpdate,item.sno):R.categoryStore,edit?'PUT':'POST',f,function(){
                    loadKnowledge();
                    loadSettings();
                });
            });
        });
    }

    function openSubcategorySettingsForm(item,edit) {
        openForm(edit?'Edit Sub-category':'Create Sub-category','Place the sub-category beneath an active Knowledge category.',edit?subcategoryForm(item):subcategoryForm({}),function(f){
            submitForm(edit?url(R.subcategoryUpdate,item.sno):R.subcategoryStore,edit?'PUT':'POST',f,function(){
                loadKnowledge();
                loadSettings();
            });
        });
    }
    $('#egKnowledge').on('click','[data-egpk-action]',function(e) {
        e.preventDefault();
        e.stopPropagation();

        const a=$(this).data('egpk-action');
        const id=$(this).data('id');
        const extra=$(this).data();

        if(a==='new-knowledge') return openPostForm();
        if(a==='knowledge-retry') return loadKnowledge({library:state.library});
        if(a==='knowledge-library') {
            state.page=1;
            return loadKnowledge({library:true});
        }
        if(a==='knowledge-categories-settings') return loadSettings();
        if(a==='knowledge-category-inline-settings') return loadSettings();
        if(a==='knowledge-category-new') return openCategorySettingsForm(null,false);

        if(a==='knowledge-category-edit') {
            const it=(state.settings.categories||[]).find(x=>String(x.sno)===String(id));
            return openCategorySettingsForm(it,true);
        }

        if(a==='knowledge-category-status') {
            return confirmAction(
                Number(extra.status)===0?'Activate category':'Deactivate category',
                'This changes category availability. Existing posts are retained.',
                'Continue',
                ()=>ajax('POST',url(R.categoryStatus,id),{status:Number(extra.status)}).done(()=>{
                    notify('Category status updated.');
                    loadKnowledge({library:state.library});
                    loadSettings();
                })
            );
        }

        if(a==='knowledge-category-delete') {
            return confirmAction(
                'Delete category',
                'The category and its sub-categories will be removed from selection. Existing posts remain intact.',
                'Delete',
                ()=>ajax('DELETE',url(R.categoryDelete,id)).done(()=>{
                    notify('Category deleted.');
                    loadKnowledge({library:state.library});
                    loadSettings();
                })
            );
        }

        if(a==='knowledge-subcategory-new') return openSubcategorySettingsForm(null,false);

        if(a==='knowledge-subcategory-edit') {
            const it=(state.settings.subcategories||[]).find(x=>String(x.sno)===String(id));
            return openSubcategorySettingsForm(it,true);
        }

        if(a==='knowledge-subcategory-status') {
            return confirmAction(
                Number(extra.status)===0?'Activate sub-category':'Deactivate sub-category',
                'This changes sub-category availability for new posts.',
                'Continue',
                ()=>ajax('POST',url(R.subcategoryStatus,id),{status:Number(extra.status)}).done(()=>{
                    notify('Sub-category status updated.');
                    loadKnowledge({library:state.library});
                    loadSettings();
                })
            );
        }

        if(a==='knowledge-subcategory-delete') {
            return confirmAction(
                'Delete sub-category',
                'Existing posts remain intact. The sub-category will no longer be selectable.',
                'Delete',
                ()=>ajax('DELETE',url(R.subcategoryDelete,id)).done(()=>{
                    notify('Sub-category deleted.');
                    loadKnowledge({library:state.library});
                    loadSettings();
                })
            );
        }

        if(a==='follow-category') {
            return ajax('POST',url(R.follow,id)).done(res=>{
                notify(res.message || 'Follow status updated.');
                loadCategories().always(renderSidebar);
            }).fail(err=>notify(err.message||'Unable to update follow status','error'));
        }

        if(a==='view-knowledge') {
            return ajax('GET',url(R.show,id)).done(res=>{
                const d=res.data||{};
                state.currentPost=d.post;
                const post=d.post||{};
                const liked=Number(post.liked_by_me)>0;
                const saved=Number(post.saved_by_me)>0;
                const mediaHtml=renderMedia(d.media);
                const versions=(d.versions||[]).length
                    ? (d.versions||[]).map(v=>`<div class="border-bottom py-2">
                        <strong style="font-size:10px">v${esc(v.version_no)}</strong>
                        <span class="text-muted ms-2" style="font-size:8px">${esc(v.created_at||'')} · ${esc(v.edited_by_name||'')}</span>
                        <div class="small mt-1">${esc(v.title||'')}</div>
                    </div>`).join('')
                    : '<div class="text-muted" style="font-size:9px">No additional versions.</div>';

                $('#kDetailTitle').text(post.title||'Knowledge');
                $('#kDetailSubtitle').text(`${post.author_name||''} · ${post.published_at||post.created_at||''}`);
                $('#kDetailBody').html(`
                    <div class="k-post-body px-0">
                        ${String(post.body_html||'')}
                        ${mediaHtml}
                    </div>
                    <div class="d-flex align-items-center gap-3 border-top mt-3 pt-3">
                        <button type="button" class="k-post-action ${liked?'active':''}" data-egpk-action="like-knowledge" data-id="${esc(post.sno)}" data-liked="${liked?1:0}">
                            <i class="mdi ${liked?'mdi-thumb-up':'mdi-thumb-up-outline'}"></i>
                            <span class="k-like-count">${esc(post.likes_count||0)}</span>
                        </button>
                        <button type="button" class="k-post-action ${saved?'active':''}" data-egpk-action="save-knowledge" data-id="${esc(post.sno)}" data-saved="${saved?1:0}">
                            <i class="mdi ${saved?'mdi-bookmark':'mdi-bookmark-outline'}"></i> Save
                        </button>
                        <button type="button" class="k-post-action" data-egpk-action="share" data-id="${esc(post.sno)}" data-k-title="${esc(post.title || "Knowledge")}">
                            <i class="mdi mdi-share-variant-outline"></i> Share
                        </button>
                    </div>
                    <div class="border-top mt-3 pt-3">
                        <div class="fw-bold mb-2" style="font-size:11px">Version history</div>
                        ${versions}
                    </div>
                `);
                modal('kDetailModal').show();
            }).fail(err=>notify(err.message||'Unable to open post','error'));
        }

        if(a==='like-knowledge') {
            const btn=$(this);
            const currentlyLiked=Number(btn.data('liked'))===1;
            return ajax('POST',url(R.like,id)).done(function(res) {
                const liked=Boolean(res?.data?.liked);
                const countEl=btn.find('.k-like-count');
                const currentCount=Number(countEl.text())||0;
                const nextCount=Math.max(0,currentCount+(liked?1:-1));

                btn.data('liked',liked?1:0)
                    .toggleClass('active',liked)
                    .find('i')
                    .attr('class',`mdi ${liked?'mdi-thumb-up':'mdi-thumb-up-outline'}`);
                countEl.text(nextCount);
                notify(res.message||'Reaction updated.');
            }).fail(err=>{
                btn.data('liked',currentlyLiked?1:0);
                notify(err.message||'Reaction failed','error');
            });
        }

        if(a==='save-knowledge') {
            const btn=$(this);
            return ajax('POST',url(R.save,id)).done(function(res) {
                const saved=Boolean(res?.data?.saved);
                btn.data('saved',saved?1:0)
                    .toggleClass('active',saved)
                    .find('i')
                    .attr('class',`mdi ${saved?'mdi-bookmark':'mdi-bookmark-outline'}`);
                notify(res.message||'Library updated.');

                if(state.library && !saved) {
                    btn.closest('[data-k-post-id]').fadeOut(160,function(){
                        $(this).remove();
                        if(!$('.k-post[data-k-post-id]').length) {
                            $ws.html(`<div class="k-empty">
                                <i class="mdi mdi-bookmark-outline"></i>
                                <div class="fw-bold mb-1">Your library is empty</div>
                                <div class="small">Save a Knowledge post and it will appear here for quick access.</div>
                            </div>`);
                        }
                    });
                }
            }).fail(err=>notify(err.message||'Save failed','error'));
        }

        if(a==='share') return openShareForm(id,$(this).data('k-title'));
    });
    $('#egKnowledge').on('click','[data-k-category]',function(){
        state.library=false;
        state.category=$(this).data('k-category')||'';
        state.page=1;
        loadKnowledge({library:false});
    });

    $('#egKnowledge').on('click','[data-k-type]',function(){
        state.library=false;
        state.contentType=$(this).data('k-type')||'all';
        state.page=1;
        renderTypes();
        loadKnowledge({library:false});
    });

    $('#egKnowledge').on('click','[data-k-page]',function(){
        state.page=Number($(this).data('k-page'))||1;
        loadKnowledge({library:state.library});
    });
    $('#kSettingsModal').on('click','[data-ksettings-tab]',function(){
        state.settingsTab=$(this).data('ksettings-tab');
        $('#kSettingsModal [data-ksettings-tab]').removeClass('active');
        $(this).addClass('active');
        renderSettings();
    });
    $('#kShareModal').on('click','[data-k-share-type]',function() {
        $('#kShareModal [data-k-share-type]').removeClass('active');
        $(this).addClass('active');
        updateShareRecipientType(String($(this).data('k-share-type')));
    });

    $('#kShareCopyLink').on('click',async function() {
        const id=$(this).data('knowledge-id');
        const link=getKnowledgeShareLink(id);
        try {
            if(navigator.clipboard?.writeText) {
                await navigator.clipboard.writeText(link);
            } else {
                const input=$('<input>').val(link).appendTo('body').select();
                document.execCommand('copy');
                input.remove();
            }
            notify('Knowledge link copied.');
        } catch(e) {
            notify('Unable to copy the Knowledge link.','error');
        }
    });

    $('#kShareForm').on('submit.kshare',function(e) {
        e.preventDefault();

        const form=$(this);
        const type=$('#kShareGranteeType').val();
        const id=$('#kShareResourceId').val();
        let recipient='';

        if(type==='user') recipient=$('#kShareUser').val();
        if(type==='company') recipient=$('#kShareCompany').val();
        if(type==='role') recipient=$('#kShareRole').val();
        if(type==='group') recipient='0';

        if(!recipient) {
            notify('Choose a recipient before sharing.','warning');
            return;
        }

        const btn=$('#kShareSave')
            .prop('disabled',true)
            .html('<span class="spinner-border spinner-border-sm me-1"></span>Sharing…');

        ajax('POST',R.shareStore,{
            resource_type:'knowledge',
            resource_id:id,
            grantee_type:type,
            grantee_id:recipient,
            permission:$('#kSharePermission').val()||'View',
            expires_at:$('#kShareExpiresAt').val()||null
        }).done(function(res) {
            notify(res.message||'Resource shared successfully.');
            ajax('GET',R.shares+`?${query({resource_type:'knowledge',resource_id:id})}`).done(function(r) {
                renderExistingShares(r.data);
            });
        }).fail(function(err) {
            notify(err.message||'Unable to share this Knowledge post.','error');
        }).always(function() {
            btn.prop('disabled',false).html('<i class="mdi mdi-share-variant-outline me-1"></i>Share');
        });
    });

    $('#kPostForm').on('submit.k',function(e) {
        e.preventDefault();

        const form=this;
        const btn=$('#kPostSave')
            .prop('disabled',true)
            .html('<span class="spinner-border spinner-border-sm me-1"></span>Publishing…');
        const formData=new FormData(form);
        const contentType=String($('#kPostType').val()||'text');

        if(contentType==='text' && !String($('#kPostContent').val()||'').trim()) {
            btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish');
            notify('Add some Knowledge content before publishing.','warning');
            return;
        }

        if(contentType==='url') {
            const urlValue=String($('#kPostUrl').val()||'').trim();
            if(!urlValue) {
                btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish');
                notify('Enter a valid resource URL.','warning');
                return;
            }
        }

        if(['image','video','audio','pdf','files'].includes(contentType)) {
            const files=Array.from($('#kPostMedia')[0]?.files||[]);
            if(!files.length) {
                btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish');
                notify(`Choose ${contentType==='files'?'at least one file':'a file'} before publishing.`,'warning');
                return;
            }
        }

        formData.set('content_type',contentType);

        if(contentType==='url') {
            const urlValue=String($('#kPostUrl').val()||'').trim();
            const description=String($('#kPostUrlDescription').val()||'').trim();
            formData.set('post_url',urlValue);
            formData.delete('url_description');
            formData.set('body_html',description);
        }

        ajax('POST',R.store,formData).done(function(r) {
            modal('kPostModal').hide();
            notify(r.message||'Knowledge post published.');
            state.page=1;
            loadKnowledge({library:false});
        }).fail(err=>notify(err.message||'Unable to publish post','error'))
            .always(()=>btn.prop('disabled',false).html('<i class="mdi mdi-send-outline"></i> Publish'));
    });

    $('#kPostModal').on('dragover.kmedia','label.k-media-drop',function(e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });

    $('#kPostModal').on('dragleave.kmedia','label.k-media-drop',function() {
        $(this).removeClass('dragover');
    });

    $('#kPostModal').on('drop.kmedia','label.k-media-drop',function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
        const input=$('#kPostMedia')[0];
        if(!input || !e.originalEvent.dataTransfer?.files?.length) return;
        input.files=e.originalEvent.dataTransfer.files;
        $(input).trigger('change');
    });

    // Use the same ERP company endpoint as other Productivity tools; it is only needed for the settings scope selector.
    state.settings={
        categories:[],subcategories:[],can_manage:false,is_group_admin:false,is_company_admin:false
    };
    loadKnowledge();
</script>
@endsection
