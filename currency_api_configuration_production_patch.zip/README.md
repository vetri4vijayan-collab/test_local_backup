# ARGUS Vendor Preferred Currency — API Configuration Integration Patch

## Scope

This update makes the existing **Settings → API Configurations → Add API** form the source of truth for currency-provider settings. The Admin adds an API label, base URL, provider type, optional/required key, feature assignment, and enabled state. The Vendor Preferred Currency card selects one saved API entry and turns conversions on/off. Provider selection, secrets, historical-rate logic, cache, and rounding remain backend-owned.

The original financial amount/source currency remains unchanged. Conversion is a secondary display only. Existing generic API configurations retain their existing behavior; their existing keys are not automatically migrated or modified.

## Included source files

### Additional Admin settings changes
- `admin/src/pages/Settings/ApiConfigurations.tsx` — add/edit API URL, feature, provider type and active flag; show entry feature/provider details; allow a keyless public Frankfurter entry.
- `admin/src/components/settings/CurrencyProviderSettingsCard.tsx` — select an API configuration created below, enable/disable conversions, save selection and test its historical endpoint.

### Additional backend API Configuration changes
- `server/src/models/ApiConfiguration.js` — feature/provider metadata and encrypted-key field for currency entries.
- `server/src/services/settings/apiConfigService.js` — validates and saves base URL/feature/provider metadata, keeps generic API rules, and decrypts currency API secrets only for protected server-side integrations.
- `server/src/utils/apiKeyEncryption.js` — AES-256-GCM at-rest key encryption using the existing `JWT_REFRESH_SECRET`-derived key.

### Currency backend files (from the previous currency-conversion patch, still required)
- `server/src/models/CurrencyExchangeSetting.js` — points to the selected API configuration.
- `server/src/models/CurrencyRateCache.js` — rate cache.
- `server/src/services/currency/currencyService.js` — provider adapters, URL validation, historical dates, cache, conversion and rounding.
- `server/src/controllers/settings/currencyExchangeController.js` — Admin settings/test endpoints.
- `server/src/controllers/vendor/currencyDisplayController.js` — authenticated vendor conversion endpoint.
- `server/src/routes/settings.routes.js` and `server/src/routes/vendorPortal.routes.js` — RBAC/auth-protected routes.
- `server/src/models/Fleet.js` and `server/src/services/fleet/fleetService.js` — explicit source currency on new fleet claim records, with USD compatibility for legacy records.

### Vendor frontend currency displays (from the previous currency-conversion patch, still required)
- `vendor/src/api/currencyApi.ts`
- `vendor/src/hooks/useSecondaryCurrencyAmounts.ts`
- `vendor/src/components/quotations/Bids&Proposal.tsx`
- `vendor/src/components/quotations/QuotationCards.tsx`
- `vendor/src/components/quotations/QuotationDetails.tsx`
- `vendor/src/components/quotations/QuotationTable.tsx`
- `vendor/src/components/projects/ProjectFinancialSummary.tsx`
- `vendor/src/components/projects/project.tsx`
- `vendor/src/components/projects/project_list.tsx`
- `vendor/src/components/projects/project_overview.tsx`
- `vendor/src/components/invoices/InvoiceApproval.tsx`
- `vendor/src/components/invoices/InvoiceDetailsPanel.tsx`
- `vendor/src/components/invoices/invoice_list.tsx`
- `vendor/src/components/fleet/VendorFleet.tsx`

### Deployment data-entry guide
- `docs/CURRENCY_API_CONFIGURATION_PRODUCTION.txt` — ready-to-follow API configuration values for Frankfurter and ExchangeRate-API Pro. It intentionally contains no real credentials.

## Deployment

1. Back up the current Admin, Vendor and server files. Apply the files in this ZIP to the corresponding project roots, preserving `server/`, `admin/`, and `vendor/` relative paths.
2. Deploy the backend files first and restart/redeploy the Node.js server. Keep the existing `JWT_REFRESH_SECRET` stable across all backend instances; currency-provider keys are encrypted using a key derived from it.
3. Rebuild and deploy the Admin frontend and Vendor frontend from the updated source. Deploy the frontend and backend changes together so the response contract matches.
4. In Admin, open **Settings → API Configurations → Add API**. Enter the fields listed in `docs/CURRENCY_API_CONFIGURATION_PRODUCTION.txt`. Set `API Feature` to **Vendor Preferred Currency**, select a provider type, enter the URL and key as appropriate, and enable the entry.
5. In the **Vendor Preferred Currency** card, select that saved API entry, enable currency conversion, and click **Save Currency Settings**.
6. Click **Test selected API**. The test calls a historical rate endpoint, so an ExchangeRate-API account without historical-data entitlement should fail the test instead of appearing production-ready.
7. Run staging tests for quotation, project, invoice and fleet values using multiple currencies and a weekday/weekend transaction date. Confirm original amounts are unchanged and the secondary display shows the effective rate date.

## Provider values

### Frankfurter public endpoint
- Label: `Frankfurter Currency Exchange`
- API Feature: `Vendor Preferred Currency`
- Provider Type: `Frankfurter v2`
- Base URL: `https://api.frankfurter.dev/v2`
- API Key: blank (public API does not need a key)
- Enable API configuration: yes

For Frankfurter self-hosting, enter the reachable HTTPS base URL for your separately deployed Frankfurter v2 service, ending in `/v2`. This patch integrates with the URL; it does not deploy the Frankfurter service itself.

### ExchangeRate-API Pro
- Label: `ExchangeRate-API Pro`
- API Feature: `Vendor Preferred Currency`
- Provider Type: `ExchangeRate-API Pro`
- Base URL: `https://v6.exchangerate-api.com/v6`
- API Key: paste the key issued by your account directly into the password field; do not store it in source control or this text file.
- Enable API configuration: yes

The account must allow its historical-rate endpoint for historical invoice-date conversions. The test checks historical-rate access.

## Behavior and safety

- Only API configurations assigned to `Vendor Preferred Currency` appear in the currency-provider selector.
- The selected API entry must be active; disabling it disables its use for secondary currency amounts.
- One selected provider is used at a time. The global enable flag and the selected API entry's active flag must both be enabled.
- Currency API keys for entries created under this feature are encrypted at rest with AES-256-GCM. Public API list/settings responses contain only a masked key suffix, never the key or ciphertext. Generic API entries continue using their existing storage semantics to avoid unrelated migrations.
- Keep `JWT_REFRESH_SECRET` stable across backend instances. If it is rotated, re-enter currency-provider API keys in Admin API Configurations.
- Provider URL must be absolute HTTP(S), without credentials, query parameters or fragments; HTTPS is required in production.
- The service uses the last available provider rate on or before a transaction date. If a conversion cannot be fetched, the source amount remains visible and no fabricated secondary amount is shown.
- Rates are indicative reference rates and can differ from Google, a bank, or settlement amounts. Use the agreed bank/accounting rate for actual accounting or payment settlements.
- Older `CurrencyExchangeSetting` configurations remain readable until a new API Configuration is selected. Once selected, the API Configuration entry becomes authoritative; the service does not silently fall back if that selected entry is deleted or invalid.

## Database

No SQL migration is needed. Mongoose adds the `feature`, `providerType`, and `encryptedApiKey` fields to the existing `api_configurations` collection, and `apiConfigurationId` to `currency_exchange_settings`. Existing documents receive model defaults when read; existing generic API configuration records are not automatically changed.

If Mongoose `autoIndex` is disabled in production, review current indexes and create the new/required indexes during a planned deployment:

```javascript
db.api_configurations.createIndex(
  { feature: 1, active: 1, providerType: 1 },
  { name: "api_configurations_feature_active_provider" }
);

db.currency_exchange_settings.createIndex(
  { singletonKey: 1 },
  { unique: true, name: "singletonKey_1" }
);

db.currency_rate_cache.createIndex(
  { configFingerprint: 1, baseCurrency: 1, targetCurrency: 1, requestedDate: 1 },
  { unique: true, name: "currency_rate_cache_pair_date_unique" }
);

db.currency_rate_cache.createIndex(
  { requestedDate: 1, baseCurrency: 1, targetCurrency: 1 },
  { name: "currency_rate_cache_pair_lookup" }
);
```

Check for existing equivalent indexes before creating them.

## Verification performed

- `node --check` passed for all changed/new backend JavaScript files.
- TypeScript `transpileModule` syntax/transpilation checks passed for the modified Admin TSX files.
- ZIP integrity check passed.
- The supplied archives do not include installable manifests, installed dependencies or a live database/backend environment. Run the standard Admin/Vendor builds and provider API/database/browser scenarios in staging before production release.
