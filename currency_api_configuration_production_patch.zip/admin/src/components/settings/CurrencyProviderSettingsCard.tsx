import { useCallback, useEffect, useMemo, useState } from "react";
import { CheckCircleIcon, FloppyDiskBackIcon, PlugIcon, SpinnerGapIcon, WarningCircleIcon } from "@phosphor-icons/react";
import api, { getApiErrorMessage } from "../../api/axios";
import Button from "../Button";

type ProviderType = "frankfurter" | "exchange_rate_api";
interface CurrencyProviderSettings {
    enabled: boolean;
    apiConfigurationId: string;
    provider: ProviderType | "";
    updatedAt: string | null;
}
interface ApiConfigurationOption {
    id: string;
    label: string;
    baseUrl: string;
    feature: string;
    providerType: ProviderType | "";
    active: boolean;
    hasKey: boolean;
    keyLast4: string;
}
interface Props { showToast?: (type: "success" | "error", message: string) => void; }
interface ApiEnvelope<T> { data?: T; message?: string; }

const SETTINGS_ENDPOINT = "/settings/currency-exchange";
const API_CONFIG_ENDPOINT = "/settings/api-configurations";
const EMPTY: CurrencyProviderSettings = { enabled: false, apiConfigurationId: "", provider: "", updatedAt: null };

export default function CurrencyProviderSettingsCard({ showToast }: Props) {
    const [settings, setSettings] = useState<CurrencyProviderSettings>(EMPTY);
    const [apiOptions, setApiOptions] = useState<ApiConfigurationOption[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [testing, setTesting] = useState(false);
    const [localMessage, setLocalMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

    const currencyOptions = useMemo(
        () => apiOptions.filter((item) => item.feature === "currency_exchange"),
        [apiOptions],
    );
    const selectedOption = currencyOptions.find((item) => item.id === settings.apiConfigurationId);
    const selectedOptionReady = Boolean(selectedOption?.active && selectedOption?.providerType && (selectedOption.providerType !== "exchange_rate_api" || selectedOption.hasKey));

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const [settingsResponse, configResponse] = await Promise.all([
                api.get<ApiEnvelope<Record<string, unknown>>>(SETTINGS_ENDPOINT),
                api.get<ApiEnvelope<unknown[]>>(API_CONFIG_ENDPOINT, { params: { page: 1, limit: 100, sort: "sortOrder", sortOrder: "asc" } }),
            ]);
            const value = settingsResponse.data?.data || {};
            const rawOptions = Array.isArray(configResponse.data?.data) ? configResponse.data.data : [];
            const options = rawOptions.map((raw): ApiConfigurationOption | null => {
                if (!raw || typeof raw !== "object") return null;
                const item = raw as Record<string, unknown>;
                const providerType = item.providerType === "frankfurter" || item.providerType === "exchange_rate_api" ? item.providerType : "";
                const id = String(item.id ?? item._id ?? "").trim();
                if (!id) return null;
                return {
                    id,
                    label: String(item.label ?? item.name ?? "API Configuration"),
                    baseUrl: String(item.baseUrl ?? ""),
                    feature: String(item.feature ?? "general"),
                    providerType,
                    active: item.active === true,
                    hasKey: item.hasKey === true || Boolean(item.keyLast4),
                    keyLast4: String(item.keyLast4 ?? ""),
                };
            }).filter((item): item is ApiConfigurationOption => item !== null);
            setApiOptions(options);
            const apiConfigurationId = String(value.apiConfigurationId ?? "");
            const option = options.find((item) => item.id === apiConfigurationId);
            setSettings({
                enabled: value.enabled === true && Boolean(option?.active),
                apiConfigurationId,
                provider: option?.providerType || (value.provider === "frankfurter" || value.provider === "exchange_rate_api" ? value.provider : ""),
                updatedAt: value.updatedAt ? String(value.updatedAt) : null,
            });
            setLocalMessage(null);
        } catch (error) {
            setLocalMessage({ type: "error", text: getApiErrorMessage(error, "Unable to load currency API configuration.") });
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { void load(); }, [load]);
    useEffect(() => {
        const refreshConfigurations = () => { void load(); };
        window.addEventListener("argus:api-configurations-updated", refreshConfigurations);
        return () => window.removeEventListener("argus:api-configurations-updated", refreshConfigurations);
    }, [load]);

    const notify = (type: "success" | "error", message: string) => {
        setLocalMessage({ type, text: message });
        showToast?.(type, message);
    };

    const changeSelection = (id: string) => {
        const option = currencyOptions.find((item) => item.id === id);
        setSettings((current) => ({
            ...current,
            apiConfigurationId: id,
            provider: option?.providerType || "",
            enabled: current.enabled && Boolean(option?.active),
        }));
        setLocalMessage(null);
    };

    const save = async () => {
        if (saving) return;
        if (settings.enabled && (!settings.apiConfigurationId || !selectedOptionReady)) {
            notify("error", "Select an active, correctly configured API entry for Vendor Preferred Currency before enabling conversions.");
            return;
        }
        setSaving(true);
        try {
            const response = await api.patch<ApiEnvelope<Record<string, unknown>>>(SETTINGS_ENDPOINT, {
                enabled: settings.enabled,
                apiConfigurationId: settings.apiConfigurationId,
            });
            const value = response.data?.data || {};
            setSettings((current) => ({
                ...current,
                enabled: value.enabled === true && Boolean(selectedOption?.active),
                apiConfigurationId: String(value.apiConfigurationId ?? current.apiConfigurationId),
                updatedAt: value.updatedAt ? String(value.updatedAt) : null,
            }));
            notify("success", response.data?.message || "Vendor Preferred Currency settings saved.");
        } catch (error) {
            notify("error", getApiErrorMessage(error, "Unable to save currency configuration."));
        } finally {
            setSaving(false);
        }
    };

    const test = async () => {
        if (testing || saving) return;
        if (!settings.enabled || !selectedOptionReady) {
            notify("error", "Enable currency conversion and select an active API entry first.");
            return;
        }
        setTesting(true);
        setLocalMessage(null);
        try {
            // Test the selection shown on screen, not a previously saved provider.
            // Persist the current selection first so an unsaved provider switch is
            // never reported as a test of the wrong API configuration.
            const savedResponse = await api.patch<ApiEnvelope<Record<string, unknown>>>(SETTINGS_ENDPOINT, {
                enabled: settings.enabled,
                apiConfigurationId: settings.apiConfigurationId,
            });
            const saved = savedResponse.data?.data || {};
            setSettings((current) => ({
                ...current,
                enabled: saved.enabled === true && Boolean(selectedOption?.active),
                apiConfigurationId: String(saved.apiConfigurationId ?? current.apiConfigurationId),
                updatedAt: saved.updatedAt ? String(saved.updatedAt) : current.updatedAt,
            }));

            const response = await api.post<ApiEnvelope<Record<string, unknown>>>(`${SETTINGS_ENDPOINT}/test`);
            const result = response.data?.data || {};
            const rate = Number(result.rate);
            const message = `${result.message || "Connection succeeded."} EUR/USD: ${Number.isFinite(rate) ? rate.toLocaleString("en-US", { maximumFractionDigits: 8 }) : "—"}; rate date: ${result.rateDate || "—"}.`;
            notify("success", message);
        } catch (error) {
            notify("error", getApiErrorMessage(error, "Currency provider test failed."));
        } finally {
            setTesting(false);
        }
    };

    return (
        <section className="mt-5 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex flex-col justify-between gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-start">
                <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-700"><PlugIcon size={20} /></div>
                    <div>
                        <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-sm font-bold text-slate-900">Vendor Preferred Currency</h3>
                            <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${settings.enabled && selectedOptionReady ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{settings.enabled && selectedOptionReady ? "Conversion enabled" : "Conversion disabled"}</span>
                        </div>
                        <p className="mt-1 max-w-3xl text-xs leading-5 text-slate-500">Add an API under “Add API” below, assign the Vendor Preferred Currency feature, and enable that API entry. Select it here to activate conversions. API keys are saved server-side; original financial values are never rewritten.</p>
                    </div>
                </div>
            </div>

            {localMessage && <div className={`mt-4 flex items-start gap-2 rounded-lg border px-3 py-2.5 text-xs ${localMessage.type === "success" ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-red-200 bg-red-50 text-red-700"}`} role="status">{localMessage.type === "success" ? <CheckCircleIcon size={16} className="mt-0.5 shrink-0" /> : <WarningCircleIcon size={16} className="mt-0.5 shrink-0" />}<span>{localMessage.text}</span></div>}

            {loading ? <div className="flex min-h-24 items-center justify-center gap-2 text-xs text-slate-500"><SpinnerGapIcon size={18} className="animate-spin" />Loading API configurations…</div> : <>
                <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                    <label className="block text-xs font-semibold text-slate-700 md:col-span-2">Currency API Configuration
                        <select value={settings.apiConfigurationId} disabled={saving} onChange={(event) => changeSelection(event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs font-medium text-slate-800 outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100">
                            <option value="">Choose a saved API configuration…</option>
                            {currencyOptions.map((option) => <option key={option.id} value={option.id}>{option.label} — {option.providerType === "frankfurter" ? "Frankfurter v2" : option.providerType === "exchange_rate_api" ? "ExchangeRate-API Pro" : "Provider not set"}{option.active ? " (Enabled)" : " (Disabled)"}</option>)}
                        </select>
                        <span className="mt-1 block text-[10px] font-normal text-slate-500">Only entries assigned to the Vendor Preferred Currency feature appear here.</span>
                    </label>
                    <label className="flex items-center gap-3 rounded-lg border border-slate-200 px-3 py-2.5"><input type="checkbox" checked={settings.enabled} disabled={saving || !settings.apiConfigurationId || !selectedOptionReady} onChange={(event) => setSettings((current) => ({ ...current, enabled: event.target.checked }))} className="h-4 w-4 rounded border-slate-300 text-red-600 focus:ring-red-500" /><span><span className="block text-xs font-semibold text-slate-800">Enable currency conversions</span><span className="mt-0.5 block text-[10px] text-slate-500">Uses the selected enabled API configuration only.</span></span></label>
                    <div className="rounded-lg border border-slate-100 bg-slate-50 px-3 py-2.5 text-xs text-slate-600">
                        <span className="block font-semibold text-slate-800">Selected API status</span>
                        {selectedOption ? <><span className="mt-1 block">{selectedOption.active ? "API entry enabled" : "API entry disabled — enable it below in API Configurations"}</span><span className="mt-1 block break-all text-[10px] text-slate-500">{selectedOption.baseUrl || "No base URL configured"}</span>{selectedOption.providerType === "exchange_rate_api" && <span className="mt-1 block text-[10px] text-slate-500">API key: {selectedOption.hasKey ? `configured${selectedOption.keyLast4 ? ` (ends ${selectedOption.keyLast4})` : ""}` : "missing"}</span>}</> : <span className="mt-1 block">{currencyOptions.length ? "Choose a currency API entry." : "No currency API entry yet. Use Add API below."}</span>}
                    </div>
                </div>
                {!currencyOptions.length && <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs text-amber-800">First add the provider in the API Configuration form below. Set <b>API Feature</b> to <b>Vendor Preferred Currency</b>, choose its provider type, enter the API URL/key as required, and keep the entry enabled.</div>}
                <div className="mt-5 flex flex-col-reverse gap-2 border-t border-slate-100 pt-4 sm:flex-row sm:items-center sm:justify-between">
                    <p className="text-[10px] text-slate-400">Reference rates only. Historical conversions use the latest available rate on or before each transaction date.</p>
                    <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => void test()} disabled={testing || saving || !settings.enabled || !selectedOptionReady}>{testing ? <SpinnerGapIcon size={15} className="animate-spin" /> : <PlugIcon size={15} />}{testing ? "Testing…" : "Test selected API"}</Button><Button onClick={() => void save()} loading={saving}><FloppyDiskBackIcon size={16} />Save Currency Settings</Button></div>
                </div>
            </>}
        </section>
    );
}
