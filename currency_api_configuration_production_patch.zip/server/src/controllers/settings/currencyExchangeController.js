import {
    getCurrencyExchangeSettings,
    saveCurrencyExchangeSettings,
    testCurrencyProviderConfiguration,
    CurrencyServiceError,
} from "../../services/currency/currencyService.js";

function actorId(req) { return req.user?.id || req.user?._id || null; }

function sendError(res, error) {
    if (error instanceof CurrencyServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            code: error.code,
            message: error.message,
            ...(error.details ? { details: error.details } : {}),
        });
    }
    console.error("[currencyExchangeController]", error);
    return res.status(500).json({ success: false, code: "CURRENCY_SETTINGS_ERROR", message: "Unable to process currency provider settings." });
}

export async function getSettings(req, res) {
    try { return res.status(200).json({ success: true, data: await getCurrencyExchangeSettings() }); }
    catch (error) { return sendError(res, error); }
}

export async function saveSettings(req, res) {
    try {
        const data = await saveCurrencyExchangeSettings(req.body || {}, actorId(req));
        return res.status(200).json({ success: true, message: "Currency provider settings saved.", data });
    } catch (error) { return sendError(res, error); }
}

export async function testConnection(req, res) {
    try { return res.status(200).json({ success: true, data: await testCurrencyProviderConfiguration() }); }
    catch (error) { return sendError(res, error); }
}

export default { getSettings, saveSettings, testConnection };
