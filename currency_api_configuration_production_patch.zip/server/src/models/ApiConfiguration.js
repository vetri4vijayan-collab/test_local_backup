import mongoose from "mongoose";
import { encryptStoredApiKey } from "../utils/apiKeyEncryption.js";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| API Configuration
|--------------------------------------------------------------------------
|
| Represents an external API/integration configuration maintained by
| authorized ARGUS internal users.
|
| Frontend contract:
|
|   label
|   key
|   description
|   active
|
| Database / runtime contract:
|
|   name        -> human-readable API label
|   apiKey      -> protected secret
|   keyLast4    -> safe masked display
|   description
|   active
|
| IMPORTANT
| ----------
| apiKey is select:false so normal list/get queries do not expose the
| secret accidentally.
|
|--------------------------------------------------------------------------
*/

const apiConfigurationSchema = new Schema(
    {
        /*
         * Human-readable API name shown in the Settings UI.
         *
         * Example:
         *   Weather API
         *   Maps API
         */
        name: {
            type: String,
            required: [true, "API label is required."],
            trim: true,
            minlength: 2,
            maxlength: 150,
        },

        /*
         * Stable optional integration identifier.
         *
         * This is useful when application services need to identify
         * an integration programmatically without depending on the
         * display name.
         *
         * Example:
         *   weather_api
         *   maps_api
         */
        code: {
            type: String,
            trim: true,
            lowercase: true,
            maxlength: 100,
            match: [
                /^[a-z0-9_.-]*$/,
                "API code contains invalid characters.",
            ],
            default: null,
        },

        /*
         * Optional base URL for the external service. Currency API entries
         * require this value (or use a provider default from the API service).
         */
        baseUrl: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: null,
        },

        /* Feature association used by backend adapters. Generic API records
         * keep their existing behavior; currency entries are selected by ID. */
        feature: {
            type: String,
            enum: ["general", "currency_exchange"],
            default: "general",
            index: true,
        },
        providerType: {
            type: String,
            enum: ["frankfurter", "exchange_rate_api", null],
            default: null,
        },

        /*
         * Secret API key.
         *
         * select:false prevents accidental exposure from ordinary
         * mongoose queries.
         *
         * The service layer must explicitly request it only when
         * the secret is actually required.
         */
        apiKey: {
            type: String,
            required: function apiKeyRequired() {
                if (this.feature === "currency_exchange" && this.providerType === "frankfurter") return false;
                if (this.feature === "currency_exchange") return Boolean(!this.encryptedApiKey && !this.apiKey);
                return true;
            },
            trim: true,
            minlength: 0,
            maxlength: 4000,
            default: "",
            select: false,
        },
        encryptedApiKey: {
            type: String,
            trim: true,
            default: "",
            select: false,
        },

        /*
         * Last four characters retained separately for safe display.
         *
         * Example:
         *   ••••••••••••1A2B
         */
        keyLast4: {
            type: String,
            trim: true,
            maxlength: 4,
            default: "",
        },

        /*
         * Optional description displayed by the existing frontend.
         */
        description: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: "",
        },

        /*
         * Enable/disable the configuration without physically removing
         * it from the system.
         */
        active: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },

        /*
         * Marks whether this configuration is system-managed.
         *
         * System records should normally be protected from destructive
         * operations in the service layer.
         */
        system: {
            type: Boolean,
            required: true,
            default: false,
            index: true,
        },

        /*
         * UI ordering.
         */
        sortOrder: {
            type: Number,
            default: 0,
            min: 0,
            index: true,
        },

        /*
         * Audit identity.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        /*
         * Last time the secret itself was changed.
         *
         * This is separate from updatedAt because changing unrelated
         * metadata should not look like a credential rotation.
         */
        keyUpdatedAt: {
            type: Date,
            default: null,
        },
    },
    {
        collection: "api_configurations",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

apiConfigurationSchema.index(
    {
        active: 1,
        sortOrder: 1,
        name: 1,
    },
    {
        name: "api_configurations_active_sort_name",
    },
);

apiConfigurationSchema.index(
    {
        code: 1,
    },
    {
        unique: true,
        sparse: true,
        name: "api_configurations_code_unique",
    },
);

apiConfigurationSchema.index(
    { feature: 1, active: 1, providerType: 1 },
    { name: "api_configurations_feature_active_provider" },
);

apiConfigurationSchema.index(
    {
        system: 1,
        active: 1,
    },
    {
        name: "api_configurations_system_active",
    },
);

/*
|--------------------------------------------------------------------------
| Validation / Normalization
|--------------------------------------------------------------------------
*/

apiConfigurationSchema.pre(
    "validate",
    function apiConfigurationValidation() {
        if (typeof this.name === "string") {
            this.name = this.name.trim();
        }

        if (typeof this.code === "string") {
            const normalizedCode = this.code
                .trim()
                .toLowerCase();

            this.code =
                normalizedCode || null;
        }

        if (typeof this.baseUrl === "string") {
            const normalizedBaseUrl =
                this.baseUrl.trim();

            this.baseUrl =
                normalizedBaseUrl || null;
        }

        if (typeof this.description === "string") {
            this.description = this.description.trim();
        }

        if (this.feature === "general") {
            this.providerType = null;
        }

        if (this.feature === "currency_exchange") {
            if (!this.providerType) {
                this.invalidate("providerType", "Choose the currency API provider type.");
            }
            // New currency credentials are encrypted at rest. Older/general
            // API records remain compatible with their existing storage.
            if (typeof this.apiKey === "string") {
                const normalizedKey = this.apiKey.trim();
                if (normalizedKey && (this.isNew || this.isModified("apiKey") || this.isModified("feature"))) {
                    this.keyLast4 = normalizedKey.slice(-4);
                    this.encryptedApiKey = encryptStoredApiKey(normalizedKey);
                    this.apiKey = "";
                }
            }
        }

        if (typeof this.apiKey === "string" && this.apiKey.trim()) {
            const normalizedKey = this.apiKey.trim();
            this.apiKey = normalizedKey;
            this.keyLast4 = normalizedKey.slice(-4);
            if (this.isNew || this.isModified("apiKey")) this.keyUpdatedAt = new Date();
        }
        if (this.feature === "currency_exchange" && this.encryptedApiKey && (this.isNew || this.isModified("apiKey") || this.isModified("feature"))) {
            this.keyUpdatedAt = new Date();
        }
        if (this.feature === "currency_exchange" && this.providerType === "exchange_rate_api" && !this.encryptedApiKey && !this.apiKey) {
            this.invalidate("apiKey", "An API key is required for ExchangeRate-API Pro.");
        }
    },
);

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Return whether this integration can currently be used.
 */
apiConfigurationSchema.methods.isActive =
    function isActive() {
        return this.active === true;
    };

/**
 * Return whether this is a protected/system configuration.
 */
apiConfigurationSchema.methods.isSystemConfiguration =
    function isSystemConfiguration() {
        return this.system === true;
    };

/**
 * Safe masked representation.
 *
 * NEVER exposes apiKey.
 */
apiConfigurationSchema.methods.toSafeJSON =
    function toSafeJSON() {
        const suffix =
            this.keyLast4 || "";

        return {
            id: this._id?.toString(),

            label: this.name,

            code:
                this.code || null,

            baseUrl:
                this.baseUrl || null,

            feature: this.feature || "general",
            providerType: this.providerType || null,

            key:
                suffix
                    ? `••••••••••••${suffix}`
                    : "••••••••••••",

            keyLast4:
                suffix,

            hasKey:
                Boolean(this.apiKey || this.encryptedApiKey || suffix),

            description:
                this.description || "",

            active:
                this.active === true,

            system:
                this.system === true,

            sortOrder:
                this.sortOrder,

            keyUpdatedAt:
                this.keyUpdatedAt,

            createdBy:
                this.createdBy
                    ? this.createdBy.toString()
                    : null,

            updatedBy:
                this.updatedBy
                    ? this.updatedBy.toString()
                    : null,

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/**
 * Explicit secret response.
 *
 * This method must only be called by a protected service/controller
 * operation after RBAC has already been passed.
 */
apiConfigurationSchema.methods.toSecretJSON =
    function toSecretJSON() {
        return {
            id:
                this._id?.toString(),

            label:
                this.name,

            code:
                this.code || null,

            baseUrl:
                this.baseUrl || null,

            feature: this.feature || "general",
            providerType: this.providerType || null,

            key:
                this.apiKey || "",

            description:
                this.description || "",

            active:
                this.active === true,

            system:
                this.system === true,

            sortOrder:
                this.sortOrder,

            keyUpdatedAt:
                this.keyUpdatedAt,

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find an active configuration by MongoDB id.
 */
apiConfigurationSchema.statics.findActiveById =
    function findActiveById(id) {
        return this.findOne({
            _id: id,
            active: true,
        });
    };

/**
 * Find a configuration by id including its secret.
 *
 * This must only be used by backend integration services that
 * actually need to call the configured API.
 */
apiConfigurationSchema.statics.findWithSecretById =
    function findWithSecretById(id) {
        return this.findOne({
            _id: id,
        }).select("+apiKey +encryptedApiKey");
    };

/**
 * Find active configuration by stable code.
 */
apiConfigurationSchema.statics.findActiveByCode =
    function findActiveByCode(code) {
        if (
            typeof code !== "string" ||
            !code.trim()
        ) {
            return null;
        }

        return this.findOne({
            code: code
                .trim()
                .toLowerCase(),

            active: true,
        });
    };

/**
 * Find all active API configurations.
 *
 * Secret remains excluded.
 */
apiConfigurationSchema.statics.findActive =
    function findActive() {
        return this.find({
            active: true,
        }).sort({
            sortOrder: 1,
            name: 1,
        });
    };

/*
|--------------------------------------------------------------------------
| JSON Serialization
|--------------------------------------------------------------------------
|
| Even if a document somehow contains a legacy key or encrypted API key,
| normal JSON serialization must never expose either secret field.
|--------------------------------------------------------------------------
*/

apiConfigurationSchema.set(
    "toJSON",
    {
        transform(_doc, ret) {
            delete ret.apiKey;
            delete ret.encryptedApiKey;

            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

apiConfigurationSchema.set(
    "toObject",
    {
        transform(_doc, ret) {
            delete ret.apiKey;
            delete ret.encryptedApiKey;

            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const ApiConfiguration =
    models.ApiConfiguration ||
    model(
        "ApiConfiguration",
        apiConfigurationSchema,
    );

export default ApiConfiguration;
export {
    ApiConfiguration,
};