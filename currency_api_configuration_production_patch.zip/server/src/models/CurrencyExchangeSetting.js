import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const currencyExchangeSettingSchema = new Schema({
    singletonKey: { type: String, required: true, unique: true, default: "default", immutable: true },
    enabled: { type: Boolean, required: true, default: false },
    provider: { type: String, enum: ["frankfurter", "exchange_rate_api"], required: true, default: "frankfurter" },
    apiConfigurationId: { type: Schema.Types.ObjectId, ref: "ApiConfiguration", default: null, index: true },
    baseUrl: { type: String, trim: true, maxlength: 1000, default: "https://api.frankfurter.dev/v2" },
    encryptedApiKey: { type: String, select: false, default: "" },
    apiKeyLast4: { type: String, trim: true, maxlength: 4, default: "" },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, {
    collection: "currency_exchange_settings",
    timestamps: true,
    strict: "throw",
    versionKey: false,
    minimize: false,
});


const CurrencyExchangeSetting = models.CurrencyExchangeSetting || model("CurrencyExchangeSetting", currencyExchangeSettingSchema);
export default CurrencyExchangeSetting;
