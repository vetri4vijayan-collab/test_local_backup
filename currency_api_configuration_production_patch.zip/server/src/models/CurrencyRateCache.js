import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const currencyRateCacheSchema = new Schema({
    configFingerprint: { type: String, required: true, maxlength: 64 },
    provider: { type: String, enum: ["frankfurter", "exchange_rate_api"], required: true },
    baseCurrency: { type: String, required: true, uppercase: true, match: /^[A-Z]{3}$/ },
    targetCurrency: { type: String, required: true, uppercase: true, match: /^[A-Z]{3}$/ },
    requestedDate: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ },
    rateDate: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ },
    rate: { type: Number, required: true, min: Number.MIN_VALUE },
    source: { type: String, trim: true, maxlength: 100, default: "" },
    fetchedAt: { type: Date, required: true, default: Date.now },
}, {
    collection: "currency_rate_cache",
    timestamps: true,
    strict: "throw",
    versionKey: false,
    minimize: false,
});

currencyRateCacheSchema.index(
    { configFingerprint: 1, baseCurrency: 1, targetCurrency: 1, requestedDate: 1 },
    { unique: true, name: "currency_rate_cache_pair_date_unique" },
);
currencyRateCacheSchema.index({ requestedDate: 1, baseCurrency: 1, targetCurrency: 1 }, { name: "currency_rate_cache_pair_lookup" });

const CurrencyRateCache = models.CurrencyRateCache || model("CurrencyRateCache", currencyRateCacheSchema);
export default CurrencyRateCache;
