import crypto from "node:crypto";
import env from "../config/env.js";

function encryptionKey() {
    const secret = env?.jwt?.refresh?.secret;
    if (!secret) throw new Error("The JWT refresh secret is required to encrypt API configuration keys.");
    return crypto.createHash("sha256").update(`argus-api-configuration:${secret}`).digest();
}

export function encryptStoredApiKey(value) {
    const secret = String(value ?? "").trim();
    if (!secret) return "";
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
    const encrypted = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
    return `v1.${iv.toString("base64url")}.${cipher.getAuthTag().toString("base64url")}.${encrypted.toString("base64url")}`;
}

export function decryptStoredApiKey(payload) {
    const value = String(payload ?? "");
    if (!value) return "";
    const parts = value.split(".");
    if (parts.length !== 4 || parts[0] !== "v1") {
        throw new Error("Unsupported encrypted API key format.");
    }
    const decipher = crypto.createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(parts[1], "base64url"));
    decipher.setAuthTag(Buffer.from(parts[2], "base64url"));
    return Buffer.concat([decipher.update(Buffer.from(parts[3], "base64url")), decipher.final()]).toString("utf8");
}
