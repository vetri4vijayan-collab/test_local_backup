import crypto from "node:crypto";
import mongoose from "mongoose";
import env from "../../config/env.js";
import Vendor from "../../models/Vendor.js";
import CurrencyExchangeSetting from "../../models/CurrencyExchangeSetting.js";
import CurrencyRateCache from "../../models/CurrencyRateCache.js";
import ApiConfiguration from "../../models/ApiConfiguration.js";
import { decryptStoredApiKey } from "../../utils/apiKeyEncryption.js";

const SINGLETON_KEY = "default";
const FRANKFURTER_DEFAULT_URL = "https://api.frankfurter.dev/v2";
const EXCHANGE_RATE_API_BASE_URL = "https://v6.exchangerate-api.com/v6";
const CURRENCY_RE = /^[A-Z]{3}$/;
const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const MAX_BATCH_ITEMS = 150;
const FETCH_TIMEOUT_MS = 9000;

export class CurrencyServiceError extends Error {
    constructor(message, { code = "CURRENCY_SERVICE_ERROR", statusCode = 400, details = null } = {}) {
        super(message);
        this.name = "CurrencyServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, CurrencyServiceError);
    }
}

function text(value) { return String(value ?? "").trim(); }
function normalizeCurrency(value, field = "currency") {
    const code = text(value).toUpperCase();
    if (!CURRENCY_RE.test(code)) throw new CurrencyServiceError(`Invalid ${field} code. Use a three-letter ISO currency code.`, { code: "INVALID_CURRENCY_CODE", statusCode: 422 });
    return code;
}
function isoDate(value) {
    if (!value) return new Date().toISOString().slice(0, 10);
    if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?$/.test(value)) {
        // HTML datetime-local values have no timezone; retain the chosen business date instead of shifting it by the server timezone.
        return isoDate(value.slice(0, 10));
    }
    if (typeof value === "string" && ISO_DATE_RE.test(value)) {
        const date = new Date(`${value}T00:00:00.000Z`);
        if (!Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value) return value;
    }
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) throw new CurrencyServiceError("Invalid transaction date. Use YYYY-MM-DD.", { code: "INVALID_TRANSACTION_DATE", statusCode: 422 });
    return parsed.toISOString().slice(0, 10);
}
function dateAdd(dateString, days) {
    const date = new Date(`${dateString}T00:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
}
function nowDate() { return new Date().toISOString().slice(0, 10); }
function isRateCacheFresh(row, settings, requestedDate) {
    const today = nowDate();
    if (requestedDate < today) return true;
    const fetchedAt = new Date(row?.fetchedAt || 0).getTime();
    if (!Number.isFinite(fetchedAt) || fetchedAt <= 0) return false;
    const maxAgeMs = settings?.provider === "exchange_rate_api" ? 30 * 60 * 1000 : 6 * 60 * 60 * 1000;
    return Date.now() - fetchedAt < maxAgeMs;
}

function encryptionKey() {
    const secret = env?.jwt?.refresh?.secret;
    if (!secret) throw new Error("The JWT refresh secret is required to encrypt currency API credentials.");
    return crypto.createHash("sha256").update(`argus-currency-provider:${secret}`).digest();
}
function encryptSecret(secret) {
    const value = text(secret);
    if (!value) return "";
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
    const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
    return [iv, cipher.getAuthTag(), encrypted].map((part) => part.toString("base64url")).join(".");
}
function decryptSecret(payload) {
    const [ivPart, tagPart, encryptedPart] = String(payload || "").split(".");
    if (!ivPart || !tagPart || !encryptedPart) return "";
    const decipher = crypto.createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(ivPart, "base64url"));
    decipher.setAuthTag(Buffer.from(tagPart, "base64url"));
    return Buffer.concat([decipher.update(Buffer.from(encryptedPart, "base64url")), decipher.final()]).toString("utf8");
}
function publicSettings(document) {
    const provider = document?.provider || "frankfurter";
    return {
        enabled: document?.enabled === true,
        provider,
        apiConfigurationId: document?.apiConfigurationId ? String(document.apiConfigurationId) : "",
        baseUrl: document?.baseUrl || (provider === "frankfurter" ? FRANKFURTER_DEFAULT_URL : EXCHANGE_RATE_API_BASE_URL),
        hasApiKey: Boolean(document?.encryptedApiKey || document?.apiKeyLast4),
        apiKeyLast4: document?.apiKeyLast4 || "",
        updatedAt: document?.updatedAt || null,
    };
}
function normalizeBaseUrl(value, provider) {
    const fallback = provider === "exchange_rate_api" ? EXCHANGE_RATE_API_BASE_URL : FRANKFURTER_DEFAULT_URL;
    const input = text(value) || fallback;
    let url;
    try { url = new URL(input); } catch { throw new CurrencyServiceError("Enter a valid absolute currency API base URL.", { code: "INVALID_CURRENCY_BASE_URL", statusCode: 422 }); }
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
        throw new CurrencyServiceError("The currency API base URL must be an HTTP(S) URL without credentials, query parameters or fragments.", { code: "INVALID_CURRENCY_BASE_URL", statusCode: 422 });
    }
    if (process.env.NODE_ENV === "production" && url.protocol !== "https:") {
        throw new CurrencyServiceError("Currency API URLs must use HTTPS in production.", { code: "CURRENCY_API_HTTPS_REQUIRED", statusCode: 422 });
    }
    return url.toString().replace(/\/+$/, "");
}
async function getSettingsDocument({ includeSecret = true } = {}) {
    let query = CurrencyExchangeSetting.findOne({ singletonKey: SINGLETON_KEY });
    if (includeSecret) query = query.select("+encryptedApiKey");
    return query.exec();
}
async function resolvedSettings() {
    const document = await getSettingsDocument({ includeSecret: true });
    if (!document) return {
        enabled: false,
        provider: "frankfurter",
        baseUrl: FRANKFURTER_DEFAULT_URL,
        apiKey: "",
        apiConfigurationId: "",
        configFingerprint: crypto.createHash("sha256").update(`frankfurter|${FRANKFURTER_DEFAULT_URL}|no-key`).digest("hex"),
    };

    // New configuration is linked to the API entry created from Settings > API Configurations.
    // It is authoritative when present; do not silently fall back if it is deleted/disabled.
    if (document.apiConfigurationId) {
        const config = await ApiConfiguration.findById(document.apiConfigurationId)
            .select("+apiKey +encryptedApiKey")
            .exec();
        if (!config || config.feature !== "currency_exchange" || !["frankfurter", "exchange_rate_api"].includes(config.providerType)) {
            const fingerprint = crypto.createHash("sha256").update(`missing-currency-api-config|${document.apiConfigurationId}`).digest("hex");
            return { enabled: false, provider: document.provider || "frankfurter", baseUrl: document.baseUrl || FRANKFURTER_DEFAULT_URL, apiKey: "", apiConfigurationId: String(document.apiConfigurationId), apiConfigurationActive: false, configFingerprint: fingerprint };
        }
        const provider = config.providerType;
        const baseUrl = normalizeBaseUrl(config.baseUrl, provider);
        let apiKey = config.apiKey || ""; // legacy plaintext keys remain readable during migration
        if (config.encryptedApiKey) {
            try { apiKey = decryptStoredApiKey(config.encryptedApiKey); }
            catch { throw new CurrencyServiceError("The selected API key cannot be decrypted. Re-enter it in Settings → API Configurations.", { code: "CURRENCY_API_KEY_DECRYPTION_FAILED", statusCode: 500 }); }
        }
        if (provider === "exchange_rate_api" && !apiKey) {
            return { enabled: false, provider, baseUrl, apiKey: "", apiConfigurationId: String(config._id), apiConfigurationActive: config.active === true, configFingerprint: crypto.createHash("sha256").update(`${config._id}|${provider}|${baseUrl}|missing-key`).digest("hex") };
        }
        const fingerprint = crypto.createHash("sha256").update(`${config._id}|${provider}|${baseUrl}|${crypto.createHash("sha256").update(apiKey).digest("hex")}`).digest("hex");
        return { enabled: document.enabled === true && config.active === true, provider, baseUrl, apiKey, apiConfigurationId: String(config._id), apiConfigurationActive: config.active === true, apiConfigurationLabel: config.name, configFingerprint: fingerprint };
    }

    // Backward compatibility for installations that configured a provider with the earlier currency-only card.
    const provider = document.provider || "frankfurter";
    const apiKey = provider === "exchange_rate_api" && document.encryptedApiKey ? decryptSecret(document.encryptedApiKey) : "";
    const baseUrl = normalizeBaseUrl(document.baseUrl, provider);
    const fingerprint = crypto.createHash("sha256").update(`${provider}|${baseUrl}|${apiKey}`).digest("hex");
    return { enabled: document.enabled === true, provider, baseUrl, apiKey, apiConfigurationId: "", configFingerprint: fingerprint };
}

async function fetchJson(url) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    try {
        const response = await fetch(url, { method: "GET", headers: { Accept: "application/json" }, signal: controller.signal });
        let body = null;
        try { body = await response.json(); } catch { body = null; }
        if (!response.ok) {
            const errorType = text(body?.["error-type"] || body?.message || body?.error || body?.detail).toLowerCase();
            const error = new Error(`Currency provider returned HTTP ${response.status}${errorType ? ` (${errorType})` : ""}.`);
            error.status = response.status;
            error.providerError = errorType;
            error.body = body;
            throw error;
        }
        return body;
    } catch (error) {
        if (error?.name === "AbortError") throw new Error("Currency provider request timed out.");
        throw error;
    } finally {
        clearTimeout(timeout);
    }
}

async function requestFrankfurterRate(settings, baseCurrency, targetCurrency, requestedDate) {
    const today = nowDate();
    const effectiveRequestDate = requestedDate > today ? today : requestedDate;
    const start = new URL(`${settings.baseUrl}/rate/${encodeURIComponent(baseCurrency.toLowerCase())}/${encodeURIComponent(targetCurrency.toLowerCase())}`);
    const firstDate = effectiveRequestDate;
    for (let offset = 0; offset <= 10; offset += 1) {
        const tryDate = dateAdd(firstDate, -offset);
        start.search = new URLSearchParams({ date: tryDate }).toString();
        try {
            const body = await fetchJson(start.toString());
            const rate = Number(body?.rate);
            if (Number.isFinite(rate) && rate > 0) {
                const effectiveDate = isoDate(body?.date || tryDate);
                if (effectiveDate <= effectiveRequestDate) return { rate, rateDate: effectiveDate, source: "Frankfurter" };
            }
        } catch (error) {
            if (error?.status === 422 || error?.status === 400) {
                // Validation or unavailable dates can occur on non-business days; try the prior date.
                continue;
            }
            if (error?.status === 404) continue;
            throw error;
        }
    }
    throw new CurrencyServiceError(`No Frankfurter rate was found for ${baseCurrency}/${targetCurrency} on or before ${effectiveRequestDate}.`, { code: "CURRENCY_RATE_NOT_FOUND", statusCode: 502 });
}

async function requestExchangeRateApiRate(settings, baseCurrency, targetCurrency, requestedDate) {
    if (!settings.apiKey) throw new CurrencyServiceError("ExchangeRate-API Pro credentials are not configured.", { code: "CURRENCY_API_KEY_REQUIRED", statusCode: 422 });
    const today = nowDate();
    const effectiveRequestDate = requestedDate > today ? today : requestedDate;
    if (effectiveRequestDate >= today) {
        const url = `${settings.baseUrl}/${encodeURIComponent(settings.apiKey)}/pair/${encodeURIComponent(baseCurrency)}/${encodeURIComponent(targetCurrency)}`;
        const body = await fetchJson(url);
        if (body?.result !== "success" || !(Number(body?.conversion_rate) > 0)) {
            throw new CurrencyServiceError(`ExchangeRate-API rejected the currency pair (${text(body?.["error-type"]) || "unexpected response"}).`, { code: "CURRENCY_PROVIDER_ERROR", statusCode: 502 });
        }
        const rateDate = body?.time_last_update_utc ? new Date(body.time_last_update_utc).toISOString().slice(0, 10) : today;
        return { rate: Number(body.conversion_rate), rateDate: rateDate > today ? today : rateDate, source: "ExchangeRate-API" };
    }
    for (let offset = 0; offset <= 10; offset += 1) {
        const tryDate = dateAdd(effectiveRequestDate, -offset);
        const [year, month, day] = tryDate.split("-").map(Number);
        const url = `${settings.baseUrl}/${encodeURIComponent(settings.apiKey)}/history/${encodeURIComponent(baseCurrency)}/${year}/${month}/${day}`;
        try {
            const body = await fetchJson(url);
            if (body?.result === "success") {
                const rate = Number(body?.conversion_rates?.[targetCurrency]);
                if (Number.isFinite(rate) && rate > 0) return { rate, rateDate: tryDate, source: "ExchangeRate-API Pro historical" };
                throw new CurrencyServiceError(`ExchangeRate-API does not support ${targetCurrency} for ${tryDate}.`, { code: "CURRENCY_PAIR_NOT_AVAILABLE", statusCode: 422 });
            }
            const errorType = text(body?.["error-type"]).toLowerCase();
            if (errorType === "no-data-available") continue;
            throw new CurrencyServiceError(`ExchangeRate-API error: ${errorType || "unexpected response"}.`, { code: errorType === "quota-reached" ? "CURRENCY_PROVIDER_QUOTA_REACHED" : errorType === "plan-upgrade-required" ? "CURRENCY_PROVIDER_PLAN_REQUIRED" : "CURRENCY_PROVIDER_ERROR", statusCode: 502 });
        } catch (error) {
            const providerError = String(error?.providerError || "");
            if (error?.status === 404 || providerError.includes("no-data-available")) continue;
            throw error;
        }
    }
    throw new CurrencyServiceError(`No ExchangeRate-API historical rate was found for ${baseCurrency}/${targetCurrency} on or before ${effectiveRequestDate}.`, { code: "CURRENCY_RATE_NOT_FOUND", statusCode: 502 });
}

async function fetchProviderRate(settings, baseCurrency, targetCurrency, date) {
    if (settings.provider === "frankfurter") return requestFrankfurterRate(settings, baseCurrency, targetCurrency, date);
    if (settings.provider === "exchange_rate_api") return requestExchangeRateApiRate(settings, baseCurrency, targetCurrency, date);
    throw new CurrencyServiceError("Unsupported currency provider.", { code: "CURRENCY_PROVIDER_UNSUPPORTED", statusCode: 422 });
}

async function getFrankfurterRangeRates(settings, baseCurrency, targetCurrency, requestedDates) {
    const today = nowDate();
    const normalizedDates = [...new Set(requestedDates.map((date) => (date > today ? today : date)))];
    const cachedRows = await CurrencyRateCache.find({
        configFingerprint: settings.configFingerprint,
        baseCurrency,
        targetCurrency,
        requestedDate: { $in: requestedDates },
    }).lean();
    const result = new Map();
    for (const row of cachedRows) {
        if (isRateCacheFresh(row, settings, row.requestedDate)) result.set(row.requestedDate, { rate: Number(row.rate), rateDate: row.rateDate, source: row.source || "Frankfurter" });
    }

    const missingOriginal = requestedDates.filter((date) => !result.has(date));
    const missingEffective = missingOriginal.map((date) => (date > today ? today : date));
    if (!missingOriginal.length) return result;

    const earliest = missingEffective.reduce((min, date) => date < min ? date : min, missingEffective[0]);
    const latest = missingEffective.reduce((max, date) => date > max ? date : max, missingEffective[0]);
    const from = dateAdd(earliest, -10);
    const url = new URL(`${settings.baseUrl}/rates`);
    url.search = new URLSearchParams({ base: baseCurrency, quotes: targetCurrency, from, to: latest }).toString();
    const payload = await fetchJson(url.toString());
    const rows = Array.isArray(payload) ? payload : Array.isArray(payload?.data) ? payload.data : [];
    const validRows = rows.map((row) => ({
        date: text(row?.date),
        rate: Number(row?.rate),
        base: text(row?.base).toUpperCase(),
        quote: text(row?.quote).toUpperCase(),
    })).filter((row) => ISO_DATE_RE.test(row.date) && row.base === baseCurrency && row.quote === targetCurrency && Number.isFinite(row.rate) && row.rate > 0);

    for (const originalDate of missingOriginal) {
        const targetDate = originalDate > today ? today : originalDate;
        const row = validRows.filter((rateRow) => rateRow.date <= targetDate).sort((a, b) => b.date.localeCompare(a.date))[0];
        if (!row) {
            result.set(originalDate, { error: new CurrencyServiceError(`No Frankfurter rate was found for ${baseCurrency}/${targetCurrency} on or before ${targetDate}.`, { code: "CURRENCY_RATE_NOT_FOUND", statusCode: 502 }) });
            continue;
        }
        const record = { rate: row.rate, rateDate: row.date, source: "Frankfurter" };
        result.set(originalDate, record);
        try {
            await CurrencyRateCache.updateOne(
                { configFingerprint: settings.configFingerprint, baseCurrency, targetCurrency, requestedDate: originalDate },
                { $set: { rateDate: record.rateDate, rate: record.rate, source: record.source, provider: settings.provider, fetchedAt: new Date() } },
                { upsert: true, runValidators: true },
            );
        } catch (error) { if (error?.code !== 11000) throw error; }
    }
    return result;
}

async function getRate(settings, baseCurrency, targetCurrency, requestedDate) {
    if (baseCurrency === targetCurrency) return { rate: 1, rateDate: requestedDate, source: "same currency" };
    const existing = await CurrencyRateCache.findOne({
        configFingerprint: settings.configFingerprint,
        baseCurrency,
        targetCurrency,
        requestedDate,
    }).lean();
    if (existing && Number(existing.rate) > 0 && isRateCacheFresh(existing, settings, requestedDate)) return { rate: Number(existing.rate), rateDate: existing.rateDate, source: existing.source || settings.provider };

    const received = await fetchProviderRate(settings, baseCurrency, targetCurrency, requestedDate);
    try {
        await CurrencyRateCache.updateOne(
            { configFingerprint: settings.configFingerprint, baseCurrency, targetCurrency, requestedDate },
            { $set: { rateDate: received.rateDate, rate: received.rate, source: received.source, provider: settings.provider, fetchedAt: new Date() } },
            { upsert: true, runValidators: true },
        );
    } catch (error) {
        // A concurrent cache insert is harmless; the persisted rate remains reusable.
        if (error?.code !== 11000) throw error;
    }
    return received;
}

function currencyDigits(currency) {
    try { return new Intl.NumberFormat("en-US", { style: "currency", currency }).resolvedOptions().maximumFractionDigits; }
    catch { return 2; }
}
function roundCurrency(value, currency) {
    const digits = Math.max(0, Math.min(4, currencyDigits(currency)));
    return Number(Number(value).toFixed(digits));
}

export async function getCurrencyExchangeSettings() {
    return publicSettings(await getSettingsDocument({ includeSecret: true }));
}

export async function saveCurrencyExchangeSettings(payload, actorId = null) {
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw new CurrencyServiceError("Currency settings payload must be an object.", { code: "INVALID_CURRENCY_SETTINGS", statusCode: 422 });
    const allowed = new Set(["enabled", "apiConfigurationId", "provider", "baseUrl", "apiKey"]);
    const unknown = Object.keys(payload).filter((key) => !allowed.has(key));
    if (unknown.length) throw new CurrencyServiceError(`Unknown currency settings field: ${unknown[0]}.`, { code: "UNKNOWN_CURRENCY_SETTINGS_FIELD", statusCode: 422 });
    const enabled = payload.enabled === true || payload.enabled === "true" || payload.enabled === 1;
    let document = await CurrencyExchangeSetting.findOne({ singletonKey: SINGLETON_KEY }).select("+encryptedApiKey");
    if (!document) document = new CurrencyExchangeSetting({ singletonKey: SINGLETON_KEY });

    if (Object.prototype.hasOwnProperty.call(payload, "apiConfigurationId")) {
        const id = text(payload.apiConfigurationId);
        let config = null;
        if (id) {
            if (!mongoose.Types.ObjectId.isValid(id)) throw new CurrencyServiceError("Select a valid API Configuration entry.", { code: "INVALID_CURRENCY_API_CONFIGURATION", statusCode: 422 });
            config = await ApiConfiguration.findById(id).select("+apiKey +encryptedApiKey").exec();
            if (!config) throw new CurrencyServiceError("The selected API Configuration entry was not found.", { code: "CURRENCY_API_CONFIGURATION_NOT_FOUND", statusCode: 404 });
            if (config.feature !== "currency_exchange" || !["frankfurter", "exchange_rate_api"].includes(config.providerType)) {
                throw new CurrencyServiceError("Choose an API Configuration entry assigned to Vendor Preferred Currency.", { code: "INVALID_CURRENCY_API_CONFIGURATION", statusCode: 422 });
            }
            if (enabled && config.active !== true) throw new CurrencyServiceError("Enable the selected API entry in API Configurations before enabling currency conversion.", { code: "CURRENCY_API_CONFIGURATION_DISABLED", statusCode: 422 });
            if (config.providerType === "exchange_rate_api") {
                let selectedKey = config.apiKey || "";
                if (config.encryptedApiKey) {
                    try { selectedKey = decryptStoredApiKey(config.encryptedApiKey); }
                    catch { throw new CurrencyServiceError("The API key cannot be decrypted. Re-enter it in Settings → API Configurations.", { code: "CURRENCY_API_KEY_DECRYPTION_FAILED", statusCode: 422 }); }
                }
                if (enabled && !selectedKey) throw new CurrencyServiceError("Enter the API key on the selected API Configuration entry.", { code: "CURRENCY_API_KEY_REQUIRED", statusCode: 422 });
            }
            // Validate and normalize the same URL the provider adapter will call.
            config.baseUrl = normalizeBaseUrl(config.baseUrl, config.providerType);
        } else if (enabled) {
            throw new CurrencyServiceError("Add an API Configuration with the Vendor Preferred Currency feature, then select it here.", { code: "CURRENCY_API_CONFIGURATION_REQUIRED", statusCode: 422 });
        }

        document.apiConfigurationId = id ? config._id : null;
        document.enabled = enabled;
        if (config) {
            document.provider = config.providerType;
            document.baseUrl = config.baseUrl;
        }
    } else {
        // Backwards compatibility for previously deployed currency-provider settings forms.
        const provider = text(payload.provider || document.provider || "frankfurter").toLowerCase();
        if (!["frankfurter", "exchange_rate_api"].includes(provider)) throw new CurrencyServiceError("Select Frankfurter or ExchangeRate-API Pro.", { code: "INVALID_CURRENCY_PROVIDER", statusCode: 422 });
        const baseUrl = normalizeBaseUrl(payload.baseUrl || document.baseUrl, provider);
        const requestedKey = text(payload.apiKey);
        if (provider === "exchange_rate_api" && requestedKey.length > 4000) throw new CurrencyServiceError("The currency API key is too long.", { code: "INVALID_CURRENCY_API_KEY", statusCode: 422 });
        let priorSecret = "";
        if (provider === "exchange_rate_api" && !requestedKey && document.encryptedApiKey) {
            try { priorSecret = decryptSecret(document.encryptedApiKey); }
            catch { throw new CurrencyServiceError("The saved currency API key cannot be decrypted with the current server secret. Enter the key again to replace it.", { code: "CURRENCY_API_KEY_REENTRY_REQUIRED", statusCode: 422 }); }
        }
        const apiKey = requestedKey || priorSecret;
        if (enabled && provider === "exchange_rate_api" && !apiKey) throw new CurrencyServiceError("Enter the ExchangeRate-API Pro key before enabling this provider.", { code: "CURRENCY_API_KEY_REQUIRED", statusCode: 422 });
        document.apiConfigurationId = null;
        document.enabled = enabled;
        document.provider = provider;
        document.baseUrl = baseUrl;
        if (provider === "exchange_rate_api") {
            document.encryptedApiKey = apiKey ? (requestedKey ? encryptSecret(apiKey) : document.encryptedApiKey) : "";
            document.apiKeyLast4 = apiKey ? apiKey.slice(-4) : "";
        }
    }
    if (actorId && mongoose.Types.ObjectId.isValid(String(actorId))) document.updatedBy = actorId;
    await document.save();
    return { ...publicSettings(document), apiConfigurationId: document.apiConfigurationId ? String(document.apiConfigurationId) : "" };
}

export async function testCurrencyProviderConfiguration() {
    const settings = await resolvedSettings();
    if (!settings.enabled) throw new CurrencyServiceError("Enable currency conversions and select an active Vendor Preferred Currency API Configuration first.", { code: "CURRENCY_PROVIDER_DISABLED", statusCode: 422 });
    if (settings.provider === "exchange_rate_api" && !settings.apiKey) throw new CurrencyServiceError("Enter the API key on the selected API Configuration entry.", { code: "CURRENCY_API_KEY_REQUIRED", statusCode: 422 });
    // Test the historical endpoint as well, so a subscription without historical
    // access is not incorrectly reported as ready for invoice-date conversions.
    const testDate = dateAdd(nowDate(), -3);
    const sample = await fetchProviderRate(settings, "EUR", "USD", testDate);
    return { success: true, provider: settings.provider, apiConfigurationId: settings.apiConfigurationId || "", testPair: "EUR/USD", requestedDate: testDate, rate: sample.rate, rateDate: sample.rateDate, message: "Currency provider and historical-rate access test succeeded." };
}

export async function convertVendorCurrencyBatch({ vendorId, items }) {
    if (!mongoose.Types.ObjectId.isValid(String(vendorId || ""))) throw new CurrencyServiceError("The signed-in vendor account is not linked to a vendor record.", { code: "VENDOR_NOT_LINKED", statusCode: 403 });
    if (!Array.isArray(items) || items.length < 1 || items.length > MAX_BATCH_ITEMS) throw new CurrencyServiceError(`Submit between 1 and ${MAX_BATCH_ITEMS} currency items per request.`, { code: "INVALID_CURRENCY_BATCH", statusCode: 422 });
    const vendor = await Vendor.findById(vendorId).select("currency companyName accountStatus").lean();
    if (!vendor) throw new CurrencyServiceError("Vendor record was not found.", { code: "VENDOR_NOT_FOUND", statusCode: 404 });
    const preferredCurrency = CURRENCY_RE.test(text(vendor.currency).toUpperCase()) ? text(vendor.currency).toUpperCase() : "";
    const settings = await resolvedSettings();
    const prepared = items.map((raw, index) => {
        if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new CurrencyServiceError(`Currency item ${index + 1} is invalid.`, { code: "INVALID_CURRENCY_ITEM", statusCode: 422 });
        const key = text(raw.key);
        if (!key || key.length > 120) throw new CurrencyServiceError(`Currency item ${index + 1} has an invalid key.`, { code: "INVALID_CURRENCY_ITEM_KEY", statusCode: 422 });
        const amount = Number(raw.amount);
        if (!Number.isFinite(amount) || amount < 0 || amount > 1e15) throw new CurrencyServiceError(`Currency item ${index + 1} has an invalid amount.`, { code: "INVALID_CURRENCY_AMOUNT", statusCode: 422 });
        const baseCurrency = normalizeCurrency(raw.currency, "source currency");
        const date = isoDate(raw.date);
        return { key, amount, baseCurrency, requestedDate: date };
    });

    if (!settings.enabled || !preferredCurrency) {
        return { enabled: false, preferredCurrency, provider: settings.provider, items: [] };
    }
    const targetCurrency = normalizeCurrency(preferredCurrency, "vendor preferred currency");
    const ratesByPair = new Map();
    const itemsByBase = new Map();
    for (const item of prepared) {
        if (item.baseCurrency === targetCurrency) continue;
        if (!itemsByBase.has(item.baseCurrency)) itemsByBase.set(item.baseCurrency, []);
        itemsByBase.get(item.baseCurrency).push(item);
    }

    if (settings.provider === "frankfurter") {
        await Promise.all([...itemsByBase.entries()].map(async ([baseCurrency, baseItems]) => {
            try {
                const fetched = await getFrankfurterRangeRates(settings, baseCurrency, targetCurrency, baseItems.map((item) => item.requestedDate));
                for (const item of baseItems) ratesByPair.set(`${baseCurrency}|${item.requestedDate}`, fetched.get(item.requestedDate) || { error: new Error("Rate not found") });
            } catch (error) {
                for (const item of baseItems) ratesByPair.set(`${baseCurrency}|${item.requestedDate}`, { error });
            }
        }));
    } else {
        const uniquePairs = new Map();
        for (const item of prepared) {
            if (item.baseCurrency === targetCurrency) continue;
            const pairKey = `${item.baseCurrency}|${item.requestedDate}`;
            if (!uniquePairs.has(pairKey)) uniquePairs.set(pairKey, { baseCurrency: item.baseCurrency, requestedDate: item.requestedDate });
        }
        const pairList = [...uniquePairs.entries()];
        for (let index = 0; index < pairList.length; index += 6) {
            await Promise.all(pairList.slice(index, index + 6).map(async ([pairKey, pair]) => {
                try { ratesByPair.set(pairKey, await getRate(settings, pair.baseCurrency, targetCurrency, pair.requestedDate)); }
                catch (error) { ratesByPair.set(pairKey, { error }); }
            }));
        }
    }

    const results = [];
    for (const item of prepared) {
        if (item.baseCurrency === targetCurrency) continue;
        const rate = ratesByPair.get(`${item.baseCurrency}|${item.requestedDate}`);
        if (!rate || rate.error) {
            results.push({ key: item.key, convertedAmount: null, targetCurrency, rate: null, rateDate: null, available: false, message: "Historical conversion rate is currently unavailable." });
            continue;
        }
        results.push({ key: item.key, convertedAmount: roundCurrency(item.amount * rate.rate, targetCurrency), targetCurrency, rate: rate.rate, rateDate: rate.rateDate, sourceCurrency: item.baseCurrency, available: true });
    }
    return { enabled: true, preferredCurrency: targetCurrency, provider: settings.provider, items: results };
}

export async function convertVendorCurrencyBatchControllerPayload(req) {
    return convertVendorCurrencyBatch({ vendorId: req.user?.vendorId, items: req.body?.items });
}

export default {
    getCurrencyExchangeSettings,
    saveCurrencyExchangeSettings,
    testCurrencyProviderConfiguration,
    convertVendorCurrencyBatch,
};
