<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BugReasonsModel extends Model {
    use HasFactory;
    public $table = 'et_bug_reasons';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'type',
        'reason_name',
        'created_by',
        'status',
    ];
}