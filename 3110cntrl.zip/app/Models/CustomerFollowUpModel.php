<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerFollowUpModel extends Model
{
    use HasFactory;
    public $table      = "et_customer_follow_up";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'customer_follow_up_id',
        'customer_id',
        'branch_id',
        'appointment_date',
        'appointment_time',
        'created_by',
        'created_at',
        'follow_through',
        'status',
    ];
}
