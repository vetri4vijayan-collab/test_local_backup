<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BugsListModel extends Model {
    use HasFactory;
    public $table      = 'et_bugs_list';
    public $primaryKey = 'sno';

    // protected $fillable = [
    //     'name',
    //     'description',
    //     'status',
    //     'created_by',
    //     'updated_by',
    //     'created_at',
    //     'updated_at',
    // ];
}