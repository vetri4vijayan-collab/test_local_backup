<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerReferalModel extends Model
{
    use HasFactory;
    public $table      = "et_customer_referal";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'customer_id',
        'product_id',
        'referer_id',
        'referer_type',
        'created_at',
        'updated_at',
        'created_by',
        'created_at',
        'status',
    ];
}
