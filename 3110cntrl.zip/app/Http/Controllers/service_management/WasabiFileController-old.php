<?php

namespace App\Http\Controllers\service_management;

use App\Http\Controllers\Controller;
use App\Services\WasabiFileService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WasabiFileController extends Controller
{
    protected WasabiFileService $wasabi;

    public function __construct(WasabiFileService $wasabi)
    {
        $this->wasabi = $wasabi;
    }

    /**
     * Generate a short-lived signed URL for a Wasabi object.
     *
     * Expected JSON body: { "path": "production/task_docs/123/file.pdf" }
     * Returns: { "signed_url": "https://..." }
     */
    public function signUrl(Request $request)
    {
        $request->validate([
            'path' => 'required|string',
        ]);

        $path = $request->input('path');

        if (! $this->wasabi->exists($path)) {
            return response()->json([
                'status' => 404,
                'message' => 'File not found.',
            ], 404);
        }

        try {
            $signedUrl = $this->wasabi->signedUrl($path);

            return response()->json([
                'status' => 200,
                'message' => 'Signed URL generated.',
                'signed_url' => $signedUrl,
            ]);
        } catch (\Exception $e) {
            Log::error('Wasabi sign-url failed', [
                'path' => $path,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'Failed to generate signed URL.',
            ], 500);
        }
    }

    /**
     * Stream a file download from Wasabi through Laravel.
     * Path is the object key (e.g. production/task_docs/123/file.pdf).
     */
    public function download(string $path)
    {
        if (! $this->wasabi->exists($path)) {
            abort(404, 'File not found.');
        }

        $mimeType = $this->wasabi->mimeType($path) ?? 'application/octet-stream';
        $downloadName = basename($path);

        return $this->wasabi->downloadResponse($path, $downloadName);
    }

    /**
     * Stream a file preview inline from Wasabi through Laravel.
     */
    public function preview(string $path)
    {
        if (! $this->wasabi->exists($path)) {
            abort(404, 'File not found.');
        }

        return $this->wasabi->previewResponse($path);
    }

    /**
     * Delete a file from Wasabi.
     */
    public function delete(Request $request, string $path)
    {
        $request->validate([
            'path' => 'required|string',
        ]);

        if ($path !== $request->input('path')) {
            return response()->json([
                'status' => 400,
                'message' => 'Path mismatch.',
            ], 400);
        }

        if (! $this->wasabi->exists($path)) {
            return response()->json([
                'status' => 404,
                'message' => 'File not found.',
            ], 404);
        }

        $this->wasabi->delete($path);

        return response()->json([
            'status' => 200,
            'message' => 'File deleted successfully.',
        ]);
    }
}
