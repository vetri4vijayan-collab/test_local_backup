<?php

namespace App\Http\Controllers\lead_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\AppointmentCategoryModel;
use App\Models\AppointmentModel;
use App\Models\DropReasonModel;
use App\Models\FollowupReasonModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\RawLeadModel;
use App\Models\LeadBankReasonModel;
use App\Models\ProductModel;
use App\Models\SpamReasonModel;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\DB;

class ManagePotentialLead extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;

        // Filters
        $lead_fill = $request->input('lead_fill', '');

        $leads = LeadModel::select(
            'et_lead.sno',
            'et_lead.lead_id',
            'et_lead.transfer_status',
            'et_lead.is_hot_lead',
            'et_lead.created_at',
            'et_lead.created_by',
            'et_lead.inter_calls',
            'et_lead.registered_date',
            'et_lead.lead_mobile',
            'et_lead.dialed_count',
            'et_lead.document_send_count',
            'et_lead.incoming_count',
            'et_lead.outgoing_count',
            'et_lead.missed_reject_count',
            'et_lead.spam_verified',
            'et_lead.drop_verified',
            'et_lead.spam_tl_verified',
            'et_lead.drop_tl_verified',
            'et_lead.service_id',
            'et_lead.phone_verify_status',
            'et_lead.phone_verify_content',

            'et_lead.just_dial_id',
            'et_lead.cloud_call_id',
            'et_lead.website_id',
            'et_lead.call_tracker_id',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.staff_name',
            'et_staff.nick_name',
            'et_lead.lead_score',
            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno as lead_type_id',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno as lead_source_id',
            'et_potential_type.potential_type_name as potential_type_name',
            'et_potential_type.potential_type_image',
            'et_lead.is_potential',
            'et_lead.potential_comments',
            'et_lead.potentail_reason',
            'appointment_counts.lead_id as followup_id',
            'latest_appointment.lead_id as latest_lead_id',
            'latest_appointment.appointment_date',
            'latest_appointment.lead_id as followup_latest_id',
            DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
            DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')

        )
            ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
          SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
          FROM et_appointment
          WHERE (lead_id, appointment_date) IN (
              SELECT lead_id, MAX(appointment_date) AS appointment_date
              FROM et_appointment              
              GROUP BY lead_id
          )) AS latest_appointment'), 'et_lead.sno', '=', 'latest_appointment.lead_id')
            ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
          FROM et_appointment
          GROUP BY lead_id) AS appointment_counts'), 'et_lead.sno', '=', 'appointment_counts.lead_id')
            ->leftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
            ->leftJoin('et_lead_status', 'et_lead.lead_status_id', '=', 'et_lead_status.sno')
            ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->leftJoin('et_potential_type', 'et_lead.lead_potential_type_id', '=', 'et_potential_type.sno')
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.created_by', '!=', $user_id)
            ->where('et_lead.potential_verify', 1)
            ->where('et_lead.is_dc', 0)
            ->where('et_lead.status', 0)
            ->where('lead_bank_status', '!=', 1);

        // Add groupBy
        $leads = $leads->groupBy(
            'et_lead.sno',
            'et_lead.lead_id',
            'et_lead.transfer_status',
            'et_lead.is_hot_lead',
            'et_lead.lead_mobile',
            'et_lead.created_at',
            'et_lead.incoming_count',
            'et_lead.dialed_count',
            'et_lead.created_by',

            'et_lead.outgoing_count',
            'et_lead.missed_reject_count',
            'et_lead.spam_verified',
            'et_lead.drop_verified',
            'et_lead.spam_tl_verified',
            'et_lead.drop_tl_verified',
            'et_lead.document_send_count',
            'et_lead.phone_verify_status',
            'et_lead.phone_verify_content',
            'et_lead.just_dial_id',
            'et_lead.cloud_call_id',
            'et_lead.website_id',
            'et_lead.call_tracker_id',
            'et_lead.registered_date',
            //   'et_lead_appointment.appointment_status',
            //   'et_lead_appointment.lead_id',
            'et_lead.lead_email_id',
            'et_lead.service_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.inter_calls',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.staff_name',
            'et_staff.nick_name',
            'et_lead.lead_score',

            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno',
            'latest_appointment.appointment_date',
            'latest_appointment.total_app_score',
            'et_potential_type.potential_type_name',
            'et_potential_type.potential_type_image',
            'et_lead.potential_comments',
            'et_lead.is_potential',
            'et_lead.potentail_reason',
            'appointment_counts.lead_id',
            'latest_appointment.lead_id',
            'appointment_counts.total_appointments'
        );
        if ($lead_fill != '') {
            $leads->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
            });
        }
        $leads = $leads->orderBy('et_lead.spam_verified', 'asc')->paginate($perpage);

        $follwup_count = 0;
        $not_follow_up_ids = [];
        foreach ($leads as $singleLead) {
            $createdAt       = Carbon::parse($singleLead->created_at);
            $currentDateTime = Carbon::now();
            $chk1day         = $createdAt->diffInHours($currentDateTime) >= 24;

            if ($chk1day) {
                // Increment only if follow-up IDs do not exist
                if (!$singleLead->followup_latest_id && !$singleLead->followup_id) {
                    $follwup_count++;
                    $not_follow_up_ids[] = $singleLead->sno;
                }
            }

            $normalizedPhoneNo    = ltrim($singleLead->lead_mobile, '0'); // Remove leading zero if present
            $phoneWithCountryCode = '+91' . $normalizedPhoneNo;           // Add the country code

            $proposal_list = DB::table('et_proposal')->where('status', 0)->where('lead_id', $singleLead->sno)->orderBy('sno', 'desc')->get();
            foreach ($proposal_list as $proposal) {
                $helper = new \App\Helpers\Helpers();
                $encrypted_values = $helper->encrypt_decrypt($proposal->sno, 'encrypt');
                $proposal->encrypt_id = $encrypted_values;
            }

            $singleLead->proposal_list = $proposal_list;

            if ($singleLead->service_id) {
                $service_ids = json_decode($singleLead->service_id);

                if (is_array($service_ids) && count($service_ids) > 0) {
                    $product_data = ProductModel::select('et_product.product_name', 'et_product_category.product_category_name')
                        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
                        ->whereIn('et_product.sno', $service_ids)
                        ->get();

                    $singleLead->productsData = $product_data;
                } else {
                    $singleLead->productsData = collect();  // empty collection if no valid service ids
                }
            }



            $singleLead->staff_id = $lead->staff_id ?? "0";
            $lead                 = DB::table('et_appointment')
                ->where('lead_id', $singleLead->sno)
                ->orderBy('sno', 'desc')
                ->first();
            $leadapp = DB::table('et_lead_appointment')
                ->where('lead_id', $singleLead->sno)
                ->orderBy('sno', 'desc')
                ->first();
            $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
            $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
            $singleLead->appointment_status = $lead->status ?? "0";
            $chk1day         = false;
            $createdAt       = Carbon::parse($singleLead->created_at);
            $currentDateTime = Carbon::now();
            if ($createdAt->diffInHours($currentDateTime) >= 24) {
                $chk1day = true;
            } else {
                $chk1day = false;
            }
            $alert_status = 0;
            if ($chk1day) {
                if ($singleLead->followup_latest_id) {
                    $alert_status = 0;
                } else if ($singleLead->followup_id) {
                    $alert_status = 0;
                } else {
                    $alert_status = 1;
                }
            }

            $singleLead->alert_status = $alert_status;
            $registeredDate = Carbon::parse($singleLead->registered_date);
            $diff = $registeredDate->diff(Carbon::now());

            $years = $diff->y;
            $months = $diff->m;
            $days = $diff->d;

            // Build the formatted difference string
            $parts = [];

            if ($years > 0) {
                $parts[] = "{$years} year" . ($years > 1 ? 's' : '');
            }
            if ($months > 0) {
                $parts[] = "{$months} month" . ($months > 1 ? 's' : '');
            }
            if ($days > 0 || empty($parts)) {
                // If all other parts are zero, still show "0 days"
                $parts[] = "{$days} day" . ($days > 1 ? 's' : '');
            }

            $singleLead->formattedDifference = implode(' and ', $parts);
            $singleLead->formattedDayDifference = $days;
        }

        $verified_spam_count     = 0;
        $not_verified_spam_count = 0;

        $verified_drop_count     = 0;
        $not_verified_drop_count = 0;

        $verified_spam_count     = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 1)->count();
        $not_verified_spam_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

        $verified_drop_count     = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 1)->count();
        $not_verified_drop_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

        // return $reasonList_internal;
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $totalFollowup = DB::table('et_appointment')
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.status', '!=', 4)
                ->where('et_lead.status', '=', 0)
                ->where('et_appointment.created_by', $user_id)
                ->whereDate('et_appointment.appointment_date', '=', today())
                ->count();
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $totalFollowup = DB::table('et_appointment')
                ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
                ->where('et_appointment.branch_id', $branch_id)
                ->where('et_appointment.status', '!=', 4)
                ->where('et_lead.status', '=', 0)
                ->whereDate('et_appointment.appointment_date', '=', today())
                ->count();
            // return "global_lead";
        }
        // $totalFollowup = DB::table('et_appointment')
        //     ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
        //     ->where('et_appointment.branch_id', $branch_id)
        //     ->where('et_appointment.status', '!=', 4)
        //     ->where('et_lead.status', '=', 0)
        //     ->whereDate('et_appointment.appointment_date', '=', today())
        //     ->count();

        $leadbankCount = DB::table('et_lead_bank')
            ->where('et_lead_bank.branch_id', $branch_id)
            ->where('et_lead_bank.status', 0)
            ->count();

        $walletCount = DB::table('et_lead')
            ->where('et_lead.created_by', $user_id)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.wallet_status', '=', 1)
            ->count();

        $leadOriginal = DB::table('et_lead')
            ->where('et_lead.branch_id', $branch_id)->whereNotIn('et_lead.status', [2, 6])->where('et_lead.drop_verified', 0)->where('et_lead.spam_verified', 0)->where('et_lead.internal_status', '!=', 1)->where('et_lead.created_by', '!=', 0)
            ->distinct('et_lead.sno');
        // Apply permission-based filtering
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $leadOriginalCount = $leadOriginal->where('et_lead.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $leadOriginalCount = $leadOriginal->count();
        $totalLeadCount = RawLeadModel::where('status', 6)->where('et_raw_lead.branch_id', $branch_id)->count();
        $internal_calls_count = DB::table('et_lead')
            ->where('et_lead.internal_status', 1)
            ->where('et_lead.branch_id', $branch_id)
            ->where('et_lead.internal_verify', 0)
            ->count();

        $reasonList_lead_bank = LeadBankReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();


        // Continue with other operations and calculations for totalLeadCount, percentage calculations, etc.
        // Get the total count of leads
        $totalLeadCounts = LeadModel::whereNotIn('et_lead.status', [2, 6])->where('et_lead.internal_status', '!=', 1)->where('et_lead.spam_verified', 0)->where('et_lead.drop_verified', 0);
        if ($branch_id != 0) {
            $totalLeadCounts->where('et_lead.branch_id', $branch_id)->where('et_lead.entity_id', $entity_id);
        }
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $totalLeadCount = $totalLeadCounts->where('et_lead.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $totalLeadCount = $totalLeadCounts->count();

        // Get the count of leads for the current month
        $currentMonthLeadCounts = LeadModel::whereNotIn('et_lead.status', [2, 6])->where('et_lead.spam_verified', 0)->where('et_lead.internal_status', 0)->where('et_lead.drop_verified', 0);
        if ($branch_id != 0) {
            $currentMonthLeadCounts->where('et_lead.branch_id', $branch_id)->where('et_lead.entity_id', $entity_id);
        }
        $currentMonthLeadCounts = $currentMonthLeadCounts
            ->whereYear('registered_date', date('Y'))
            ->whereMonth('registered_date', date('m'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $currentMonthLeadCount = $currentMonthLeadCounts->where('et_lead.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $currentMonthLeadCount = $currentMonthLeadCounts->count();

        $totalCustomerCount = LeadModel::where('status', 4)->where('et_lead.internal_status', '!=', 1)->where('et_lead.registered_date', '!=', 0);
        if ($branch_id != 0) {
            $totalCustomerCount->where('et_lead.branch_id', $branch_id)->where('et_lead.entity_id', $entity_id);
        }
        $totalCustomerCount = $totalCustomerCount->count();

        // Get the count of leads for the current month
        $currentMonthCustomerCount = LeadModel::where('status', 4)->where('et_lead.internal_status', '!=', 1)->where('et_lead.registered_date', '!=', 0);
        if ($branch_id != 0) {
            $currentMonthCustomerCount->where('et_lead.branch_id', $branch_id)->where('et_lead.entity_id', $entity_id);
        }
        $currentMonthCustomerCount = $currentMonthCustomerCount->whereYear('registered_date', date('Y'))
            ->whereMonth('registered_date', date('m'))
            ->count();

        // Calculate the percentage
        $percentageover = 0;
        $percentagecurrentmonth = 0;
        if ($totalLeadCount > 0) {
            $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
        }
        if ($currentMonthLeadCount > 0) {
            $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
        }

        // Format the percentage to 2 decimal places
        $percentageover = round($percentageover) . '%';
        $percentagecurrentmonth = round($percentagecurrentmonth) . '%';
        $reasonList_drop = DropReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();
        $followupReasonList = FollowupReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();
        $reasonList = SpamReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();
        // return $leads;
        $categories = AppointmentCategoryModel::where('status', 0)->get();
        return view('content.lead_management.manage_lead.potential_lead_list', compact(
            'leads',
            'leadOriginalCount',
            'internal_calls_count',
            'perpage',
            'totalFollowup',
            'walletCount',
            'categories',
            'reasonList',
            'verified_spam_count',
            'followupReasonList',
            'not_verified_spam_count',
            'verified_drop_count',
            'leadbankCount',
            'totalLeadCount',
            'not_verified_drop_count',
            'lead_fill',
            'currentMonthLeadCount',
            'percentageover',
            'percentagecurrentmonth',
            'follwup_count',
            'reasonList_drop',
            'reasonList_lead_bank'
        ));
    }
    public function trans_potential_to_lead(Request $request)
    {
        $id = $request->lead_id;
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        DB::beginTransaction();
        try {

            $lead = LeadModel::where('sno', $id)->first();

            if (!$lead) {
                return response([
                    'status' => 400,
                    'message' => 'Lead not found.',
                    'error_msg' => 'Invalid lead ID.',
                    'data' => null,
                ], 400);
            }

            $old_staff_id = $lead->created_by;

            // Close previous transfer history
            $lead_history = LeadTransferLogModel::where('lead_id', $id)
                ->whereNull('end_date')
                ->where('current_staff_id', $old_staff_id)
                ->first();

            if ($lead_history) {
                $lead_history->end_date = date('Y-m-d');
                $lead_history->change_staff_id = $request->convert_staff_id ?? $user_id;
                // $lead_history->transferred_from = 15; // spam transfer
                $lead_history->save();
            }

            // New transfer history entry
            $add_history = new LeadTransferLogModel();
            $add_history->lead_id = $lead->sno;
            $add_history->branch_id = $lead->branch_id;
            $add_history->start_date = date('Y-m-d'); // new start date = today
            $add_history->current_staff_id = $request->convert_staff_id ?? $user_id;
            $add_history->change_staff_id = 0;
            $add_history->transferred_from = 17;
            $add_history->created_by = $user_id;
            $add_history->updated_by = $user_id;
            $add_history->save();

            // Update lead details
            $lead->status = 0;
            $lead->drop_verified = 0;
            $lead->drop_tl_verified = 0;
            $lead->spam_verified = 0;
            $lead->spam_tl_verified = 0;
            $lead->internal_status = 0;
            $lead->lead_status_id = 1;
            $lead->transfer_status = 1;
            $lead->potential_verify = 0;
            // $lead->created_by = $request->convert_staff_id ?? $user_id;
            // $lead->updated_by   = $user_id;
            // $lead->converted_by = $user_id;
            $lead->save();

            DB::commit();

            if ($lead) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Successfully Lead Converted!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Convert the Lead!'
                ]);
            }
            // return $lead;
            return redirect('/lead_management/potential_lead');
        } catch (\Exception $e) {
            DB::rollBack();
            //    return $e->getMessage();
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not Convert the Lead!' . $e->getMessage()
            ]);
            return redirect('/lead_management/potential_lead');
        }
    }
    public function Update(Request $request)
    {

        // return $request;
        $validator = Validator::make($request->all(), [
            'lead_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $lead_name       = $request->lead_name;
            $lead_id       = $request->lead_id;
            $lead_dob = isset($request->lead_dob) ? date('Y-m-d', strtotime($request->lead_dob)) : null;
            $upd_lead =  LeadModel::where('sno', $lead_id)->first();

            $chk = LeadModel::where('lead_name', ucwords($lead_name))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $lead_id) {
                    $result = response([
                        'status'    => 401,
                        'message'   => 'Error',
                        'error_msg' => 'Name has been  already assigned!',
                        'data'      => null,

                    ], 200);
                } else {
                }
            }

            $upd_lead->lead_name             = $lead_name;
            $upd_lead->lead_mobile           = $request->mobile_check ? $request->lead_mobile : null;
            $upd_lead->inter_calls           = $request->mobile_check ? $request->country_code_name_edit : null;
            $upd_lead->lead_alternate_mobile = $request->lead_alternate_mobile;
            $upd_lead->lead_email_id         = $request->email_check ? $request->lead_email_id : null;
            $upd_lead->lead_gender           = $request->lead_gender;
            $upd_lead->lead_dob              = $lead_dob;
            $upd_lead->country               = $request->country_edit;
            $upd_lead->state                 = $request->state_edit;
            $upd_lead->city                  = $request->city_edit;
            $upd_lead->address               = $request->address;
            $upd_lead->door_no               = $request->door_no;
            $upd_lead->pincode               = $request->pincode;
            $upd_lead->lead_source_id        = $request->lead_source_id_edit;
            $upd_lead->lead_type_id          = $request->lead_type_id_edit;
            $upd_lead->lead_question_id      = $request->lead_question_id;
            $upd_lead->lead_comments         = $request->lead_comments;
            $upd_lead->university_id            = $request->university_id ?? 0;
            $upd_lead->lead_potential_type_id            = $request->potential_type_id;
            $upd_lead->service_id            = json_encode($request->service_id);
            $upd_lead->lead_condition          = 2; //new lead
            $upd_lead->update();

            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
            if ($upd_lead) {
                $notificationData = [
                    'branch_id' => $branch_id,
                    'notification_content' => ' <div class="d-flex align-items-center">
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-multiple-outline fs-3 text-black"></i></span>
              </div>
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
                <div class="text-secondary fs-8 fw-semibold">' . $upd_lead->lead_name . ' Lead Updated</div>
              </div>
            </div>',
                    'who' => $user_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'status' => 0
                ];
                $notificationtype = 'Lead';
                $newNotification = new \App\Helpers\Helpers();
                $newNotification->createNotification($notificationData, $notificationtype);
            }


            if ($upd_lead) {
                $result = response([
                    'status'    => 200,
                    'message'   => 'Successfully Updated!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            } else {
                $result = response([
                    'status'    => 401,
                    'message'   => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data'      => null,
                ], 401);
            }
            // return $result;
        }

        return redirect('/lead_management/potential_lead');
    }
    public function add_appointment_pb(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'appointment_date' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            // return $request;
            $lead_id            = $request->lead_id;
            $appointment_time   = $request->appointment_time;
            $appointment_date   = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
            $user_id            = $request->user()->user_id;
            $branch_id          = $request->user()->branch_id;
            $category_check     = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date("y"), -2);
                $appointment_id = "AP-0001/" . $year;
            } else {
                $data = $category_check->appointment_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $request = sprintf("AP-%04d", $next_number);
                $year = substr(date("y"), -2);
                $appointment_id = $request . '/' . $year;
            }
            $add_category = new AppointmentModel();
            $add_category->appointment_id          = $appointment_id;
            $add_category->lead_id                 = $lead_id;
            $add_category->appointment_date        = $appointment_date;
            $add_category->appointment_time        = $appointment_time;
            $add_category->branch_id               = $branch_id;
            $add_category->status                  = 1;
            $add_category->created_by              = $user_id;
            $add_category->updated_by              = $user_id;
            $add_category->save();
            if ($add_category) {
                $lead =  LeadModel::where('sno', $lead_id)->first();
                $lead->lead_status_id          = 2; //followup lead
                $lead->update();
            }

            if ($add_category) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Appointment added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Appointment!'
                ]);
            }
            return redirect('lead_management/potential_lead');
        }
    }


    public function appointment_update_pb($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'progressed' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            //   return $request;
            $progressed       = $request->progressed;
            $reason_appt      = $request->reason;
            $appointment_time     = $request->appointment_time;
            $app_score            = $request->app_score;
            $follow_through            = $request->follow_through ?? 0;
            $hot_lead             = $request->hot_lead;
            $pb                   = $request->pb ?? 0;
            $user_id              = $request->user()->user_id;
            $branch_id            = $request->user()->branch_id;
            $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
            if ($progressed == 1) {
                $upd_lead =  AppointmentModel::where('lead_id', $id)->orderBy('sno', 'desc')->first();

                $upd_lead->progressed                 = $progressed;
                $upd_lead->app_score                  = $request->app_score;
                $upd_lead->follow_through                  = $request->follow_through;
                $upd_lead->convo_message              = $request->convo_message;
                $upd_lead->status                     = 4;
                // return $upd_lead;
                $upd_lead->update();

                if ($pb == 1) {
                    $LeadData = LeadModel::where('sno', $upd_lead->lead_id)->first();
                    if ($LeadData) {
                        // $LeadData->drop_verified = 0;
                        // $LeadData->drop_tl_verified = 0;
                        // $LeadData->spam_verified = 0;
                        // $LeadData->spam_tl_verified = 0;
                        // $LeadData->internal_status  = 0;
                        // $LeadData->transfer_status  = 1;
                        // $LeadData->potential_verify = 0;
                        // $LeadData->is_dc = 0;
                        // $LeadData->dc_date = null;
                        // $LeadData->is_potential = 0;
                        // // $LeadData->created_by   = $user_id;
                        // $LeadData->save();
                    }
                    $add_history = new LeadTransferLogModel();
                    $add_history->lead_id = $LeadData->sno;
                    $add_history->branch_id = $LeadData->branch_id;
                    $add_history->start_date = date('Y-m-d', strtotime($LeadData->created_at));
                    $add_history->current_staff_id = $LeadData->created_by;
                    $add_history->change_staff_id = 0;
                    $add_history->transferred_from = 17; // from Bulk transfer  
                    $add_history->created_by = $user_id;
                    $add_history->updated_by = $user_id;
                    // return $add_history;
                    $add_history->save();
                }
            } else {
                $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $appointment_id = "AP-0001/" . $year;
                } else {

                    $data = $category_check->appointment_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf("AP-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $appointment_id = $request . '/' . $year;
                }

                $upd_app = AppointmentModel::where('lead_id', $id)
                    ->where('status', 1)
                    ->where(function ($query) {
                        $query->where('progressed', 0)
                            ->orWhere('progressed', 2);
                    })
                    ->orderBy('sno', 'desc')
                    ->first();

                if ($upd_app) {
                    $upd_app->status = 5;
                    $upd_app->update();
                }



                $upd_lead = new AppointmentModel();
                $upd_lead->appointment_id           = $appointment_id;
                $upd_lead->lead_id                  = $id;
                $upd_lead->branch_id                = $branch_id;
                $upd_lead->progressed               = $progressed;
                $upd_lead->app_score                = $app_score;
                $upd_lead->follow_through                = $follow_through;
                $upd_lead->reason                   = $reason_appt;
                $upd_lead->appointment_date         = $appointment_date;
                $upd_lead->appointment_time         = $appointment_time;
                $upd_lead->status                   = 1;
                $upd_lead->created_by               = $user_id;
                $upd_lead->updated_by               = $user_id;
                //  return $upd_lead;
                $upd_lead->save();



                // $upd_app =  AppointmentModel::where('lead_id', $id)->whereIN('progressed', [null,2])->where('status', 1)->orderBy('sno', 'desc')->first();
                // if($upd_app){
                //     $upd_app->status = 5;
                //     $upd_app->update();
                // // }

                //****************** */ Update Staff Sales Person Points
                // Define point category:
                // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
                // $helper = new \App\Helpers\Helpers();
                // $pointsData = $helper->get_points_by_id(3);
                // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
                // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
                // // Save new points for the staff
                // $newPoints = new StaffpointsModel();
                // $newPoints->branch_id = $branch_id;
                // $newPoints->staff_id = $user_id;
                // $newPoints->points_by = $id;
                // $newPoints->points_id = 3;
                // $newPoints->points = $point;
                // $newPoints->reason = $reason;
                // $newPoints->save();

                // // Update staff's available points
                // $staff_points = StaffModel::where('sno', $user_id)->first();
                // if ($staff_points) {
                //   $staff_points->avaiable_points += $point; // Increment the available points
                //   $staff_points->save();
                // }
                //****************** */ Update Staff Sales Person Points

                // if ($hot_lead == 1) {
                //   $lead =  LeadModel::where('sno', $id)->first();
                //   $lead->lead_status_id          = 3; //Hot lead
                //   $lead->update();
                // }
            }
            //   if ($upd_lead) {
            //         // Embed the lead_name directly in notification content
            //         $notificationData = [
            //             'branch_id' => $branch_id,
            //             'notification_content' => '
            //                 <div class="d-flex align-items-center">
            //                     <div class="me-3">
            //                         <span class="badge bg-gray-300">
            //                             <i class="mdi mdi-account-multiple-outline fs-3 text-black"></i>
            //                         </span>
            //                     </div>
            //                     <div class="me-2">
            //                         <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
            //                         <div class="text-secondary fs-8 fw-semibold">' . $upd_lead->lead_name . ' - Checklist Not Completed</div>
            //                     </div>
            //                 </div>',
            //             'who' => $user_id,
            //             'created_by' => $user_id,
            //             'updated_by' => $user_id,
            //             'status' => 0
            //         ];
            //         $notificationtype = 'CheckList';
            //         $newNotification = new \App\Helpers\Helpers();

            //         $newNotification->createNotification($notificationData, $notificationtype);
            //     }
            if ($upd_lead) {
                $result = response([
                    'status'    => 200,
                    'message'   => 'Successfully Updated!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            } else {
                $result = response([
                    'status'    => 401,
                    'message'   => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data'      => null,
                ], 401);
            }
            return $result;
        }
    }
    
    public function MoveBasketToLead($id, Request $request)
    {
        $user_id = $request->user()->user_id;
 
        $LeadData = LeadModel::where('sno', $id)->first();
 
        if (!$LeadData) {
            return response()->json(['message' => 'Lead not found'], 404);
        }
 
        // Update lead
        $LeadData->update([
            'drop_verified' => 0,
            'drop_tl_verified' => 0,
            'spam_verified' => 0,
            'spam_tl_verified' => 0,
            'internal_status' => 0,
            'transfer_status' => 1,
            'potential_verify' => 0,
            'is_dc' => 0,
            'dc_date' => null,
            'is_potential' => 0,
            'status' => 10,
            'updated_by' => $user_id,
        ]);
 
        // Close existing open log
        $lead_history = LeadTransferLogModel::where('lead_id', $id)
            ->whereNull('end_date')
            ->where('current_staff_id', $LeadData->created_by)
            ->first();
 
        if ($lead_history) {
            $lead_history->update([
                'end_date' => now(),
                'change_staff_id' => $LeadData->created_by,
                'transferred_from' => 17,
            ]);
        }
 
        // Create new log
        LeadTransferLogModel::create([
            'lead_id' => $LeadData->sno,
            'branch_id' => $LeadData->branch_id,
            'start_date' => now(),
            'current_staff_id' => $LeadData->created_by,
            'change_staff_id' => 0,
            'transferred_from' => 17,
            'created_by' => $user_id,
            'updated_by' => $user_id,
        ]);
 
       
        return response([
            'status' => 200,
            'message' => 'Lead moved successfully !',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    
    public function convertStaff(Request $request)
    {
        try {
            $request->validate([
                'lead_id' => 'required',
                'new_staff_id' => 'required',
            ]);
 
            $leadId = $request->lead_id;
            $newStaffId = $request->new_staff_id;
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            // Fetch the lead
 
            $LeadData = LeadModel::where('sno', $leadId)->first();
 
            if (! $LeadData) {
                return response()->json(['message' => 'Lead not found'], 404);
            }
 
            // Update lead
            $LeadData->update([
                'drop_verified' => 0,
                'drop_tl_verified' => 0,
                'spam_verified' => 0,
                'spam_tl_verified' => 0,
                'internal_status' => 0,
                'transfer_status' => 1,
                'potential_verify' => 0,
                'is_dc' => 0,
                'dc_date' => null,
                'is_potential' => 0,
                'created_by' => $newStaffId, // new staff
                'convert_date' => now(),
                'updated_by' => $user_id,
            ]);
 
            // Close existing open log
            $lead_history = LeadTransferLogModel::where('lead_id', $leadId)
                ->whereNull('end_date')
                ->where('current_staff_id', $LeadData->created_by)
                ->first();
 
            if ($lead_history) {
                $lead_history->update([
                    'end_date' => now(),
                    'change_staff_id' => $LeadData->created_by,
                    'transferred_from' => 17,
                ]);
            }
 
            // Create new log
            LeadTransferLogModel::create([
                'lead_id' => $LeadData->sno,
                'branch_id' => $LeadData->branch_id,
                'start_date' => now(),
                'current_staff_id' => $LeadData->created_by,
                'change_staff_id' => 0,
                'transferred_from' => 17,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
 
            return response()->json([
                'status' => 200,
                'message' => 'Staff changed successfully',
                'data' => [
                    'lead_id' => $leadId,
                    'new_staff_id' => $newStaffId,
                    'convert_date' => now()->format('Y-m-d H:i:s'),
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Failed to change staff: '.$e->getMessage(),
            ], 500);
        }
    }
    
}
