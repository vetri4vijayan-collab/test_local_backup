<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\JournalBookletModel;
use App\Models\ManageJournalModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class JournalReportController extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;

        $search_fill = $request->search_fill ?? '';
        $status_fill = $request->status_fill ?? '';
        $dashboard_filter = $request->dashboard_filter ?? '';
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);

        // Sort parameters
        $sort_by = $request->input('sort_by', 'journal_name');
        $sort_dir = $request->input('sort_dir', 'asc');
        $allowedSortColumns = [
            'journal_name',
            'status_0', 'status_1', 'status_3', 'status_4',
            'status_5', 'status_6', 'status_7', 'status_8', 'status_9',
            'customer_count', 'service_count'
        ];
        $sortColumn = in_array($sort_by, $allowedSortColumns) ? $sort_by : 'journal_name';
        $sortDirection = strtolower($sort_dir) === 'desc' ? 'desc' : 'asc';

        // Status mapping from workflow
        $statusMap = [
            0 => 'Submitted',
            1 => 'With Editor',
            3 => 'Under Reviewer',
            4 => 'Reviewed / Revision',
            5 => 'Accepted',
            6 => 'Rejected',
            7 => 'E-Proofing',
            8 => 'Published',
            9 => 'Resubmitted',
        ];

        // ===================== MINI DASHBOARD COUNTS (with filters) =====================
        
        // Base booklet query with filters
        $baseBookletQuery = function () use ($branch_id, $search_fill, $status_fill, $dashboard_filter) {
            $query = JournalBookletModel::where('status', 0)
                ->where('branch_id', $branch_id);
            
            // Apply search filter
            if ($search_fill != '') {
                $query->where('journal_name', 'LIKE', "%{$search_fill}%");
            }
            
            // Apply status filter - only booklets with journals in selected status
            if ($status_fill !== '') {
                $query->whereExists(function ($q) use ($branch_id, $status_fill) {
                    $q->select(DB::raw(1))
                        ->from('et_manage_journal')
                        ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                        ->where('et_manage_journal.branch_id', $branch_id)
                        ->where('et_manage_journal.status', $status_fill)
                        ->where('et_manage_journal.status', '!=', 2)
                        ->whereNotNull('et_manage_journal.service_id');
                });
            }
            
            // Apply dashboard filter
            if ($dashboard_filter === 'used') {
                $query->whereExists(function ($q) use ($branch_id) {
                    $q->select(DB::raw(1))
                        ->from('et_manage_journal')
                        ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                        ->where('et_manage_journal.branch_id', $branch_id)
                        ->where('et_manage_journal.status', '!=', 2);
                });
            } elseif ($dashboard_filter === 'unused') {
                $query->whereNotExists(function ($q) use ($branch_id) {
                    $q->select(DB::raw(1))
                        ->from('et_manage_journal')
                        ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                        ->where('et_manage_journal.branch_id', $branch_id)
                        ->where('et_manage_journal.status', '!=', 2);
                });
            }
            
            return $query;
        };

        // Total Booklets (with filters)
        $totalBooklets = $baseBookletQuery()->count();

        // Used Booklets (have at least one linked journal, with filters)
        $usedBooklets = $baseBookletQuery()
            ->whereExists(function ($q) use ($branch_id) {
                $q->select(DB::raw(1))
                    ->from('et_manage_journal')
                    ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                    ->where('et_manage_journal.branch_id', $branch_id)
                    ->where('et_manage_journal.status', '!=', 2);
            })
            ->count();

        // Unused Booklets (no linked journals, with filters)
        $unusedBooklets = $baseBookletQuery()
            ->whereNotExists(function ($q) use ($branch_id) {
                $q->select(DB::raw(1))
                    ->from('et_manage_journal')
                    ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                    ->where('et_manage_journal.branch_id', $branch_id)
                    ->where('et_manage_journal.status', '!=', 2);
            })
            ->count();

        // Total Service-Booklet Pairs (distinct service_id + booklet_id, with filters)
        $serviceBookletPairsQuery = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->whereNotNull('service_id')
            ->whereNotNull('booklet_id');
        
        // Apply search filter to service-booklet pairs
        if ($search_fill != '') {
            $serviceBookletPairsQuery->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                $q->select('sno')->from('et_journal_booklet')
                    ->where('branch_id', $branch_id)
                    ->where('status', 0)
                    ->where('journal_name', 'LIKE', "%{$search_fill}%");
            });
        }
        
        // Apply status filter to service-booklet pairs
        if ($status_fill !== '') {
            $serviceBookletPairsQuery->where('status', $status_fill);
        }
        
        $totalServiceBookletPairs = $serviceBookletPairsQuery
            ->selectRaw('COUNT(DISTINCT CONCAT(service_id, "-", booklet_id)) as total_pairs')
            ->value('total_pairs') ?? 0;

        // Total Customers (distinct customer_id across all journals in filtered booklets)
        $totalCustomersQuery = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->whereNotNull('customer_id');
        
        if ($search_fill != '') {
            $totalCustomersQuery->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                $q->select('sno')->from('et_journal_booklet')
                    ->where('branch_id', $branch_id)
                    ->where('status', 0)
                    ->where('journal_name', 'LIKE', "%{$search_fill}%");
            });
        }
        if ($status_fill !== '') {
            $totalCustomersQuery->where('status', $status_fill);
        }
        
        // Apply permission scoping
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) { // JE
                $totalCustomersQuery->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                });
            } elseif ($user_role == 33) { // JTL
                $totalCustomersQuery->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                });
            }
        }
        
        $totalCustomers = $totalCustomersQuery
            ->distinct('customer_id')
            ->count('customer_id');

        // Total Services (distinct service_id across all journals in filtered booklets)
        $totalServicesQuery = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->whereNotNull('service_id');
        
        if ($search_fill != '') {
            $totalServicesQuery->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                $q->select('sno')->from('et_journal_booklet')
                    ->where('branch_id', $branch_id)
                    ->where('status', 0)
                    ->where('journal_name', 'LIKE', "%{$search_fill}%");
            });
        }
        if ($status_fill !== '') {
            $totalServicesQuery->where('status', $status_fill);
        }
        
        // Apply permission scoping
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) { // JE
                $totalServicesQuery->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                });
            } elseif ($user_role == 33) { // JTL
                $totalServicesQuery->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                });
            }
        }
        
        $totalServices = $totalServicesQuery
            ->distinct('service_id')
            ->count('service_id');

        // ===================== STATUS FILTER COUNTS (for dashboard tiles - distinct services, with search filter) =====================
        $statusCounts = [];
        foreach ($statusMap as $statusId => $statusLabel) {
            $query = DB::table('et_manage_journal')
                ->where('branch_id', $branch_id)
                ->where('status', $statusId)
                ->where('status', '!=', 2)
                ->whereNotNull('service_id')
                ->distinct('service_id');

            // Apply search filter - only count journals for booklets matching search
            if ($search_fill != '') {
                $query->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                    $q->select('sno')->from('et_journal_booklet')
                        ->where('branch_id', $branch_id)
                        ->where('status', 0)
                        ->where('journal_name', 'LIKE', "%{$search_fill}%");
                });
            }

            // Apply permission scoping
            if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
                if ($user_role == 34) {
                    $query->whereIn('service_id', function ($q) use ($user_id) {
                        $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                    });
                } elseif ($user_role == 33) {
                    $query->whereIn('service_id', function ($q) use ($user_id) {
                        $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                    });
                }
            }

            $statusCounts[$statusId] = $query->count('service_id');
        }

        // ===================== MAIN QUERY: Booklet-wise Status Report with Conditional Aggregation =====================
        
        // Build filtered journals query (same logic as modal detail)
        $buildJournalQuery = function () use ($branch_id, $search_fill, $user_id, $user_role) {
            $query = DB::table('et_manage_journal')
                ->where('branch_id', $branch_id)
                ->where('status', '!=', 2)
                ->whereNotNull('service_id')
                ->select('booklet_id', 'service_id', 'customer_id', 'status');

            // Apply search filter
            if ($search_fill != '') {
                $query->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                    $q->select('sno')->from('et_journal_booklet')
                        ->where('branch_id', $branch_id)
                        ->where('status', 0)
                        ->where('journal_name', 'LIKE', "%{$search_fill}%");
                });
            }

            // Apply permission scoping
            if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
                if ($user_role == 34) { // JE
                    $query->whereIn('service_id', function ($q) use ($user_id) {
                        $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                    });
                } elseif ($user_role == 33) { // JTL
                    $query->whereIn('service_id', function ($q) use ($user_id) {
                        $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                    });
                }
            }
            return $query;
        };

        // Main query - direct join with filtered journals
        $bookletsQuery = JournalBookletModel::where('et_journal_booklet.status', 0)
            ->where('et_journal_booklet.branch_id', $branch_id)
            ->leftJoinSub($buildJournalQuery(), 'j', function ($join) {
                $join->on('j.booklet_id', '=', 'et_journal_booklet.sno');
            })
            ->select(
                'et_journal_booklet.sno',
                'et_journal_booklet.journal_name',
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 0 THEN j.service_id END) as status_0'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 1 THEN j.service_id END) as status_1'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 3 THEN j.service_id END) as status_3'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 4 THEN j.service_id END) as status_4'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 5 THEN j.service_id END) as status_5'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 6 THEN j.service_id END) as status_6'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 7 THEN j.service_id END) as status_7'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 8 THEN j.service_id END) as status_8'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 9 THEN j.service_id END) as status_9'),
                DB::raw('COUNT(DISTINCT j.customer_id) as customer_count'),
                DB::raw('COUNT(DISTINCT j.service_id) as service_count'),
            )
            ->groupBy('et_journal_booklet.sno', 'et_journal_booklet.journal_name');

        // Apply dashboard filter (used/unused) using HAVING
        if ($dashboard_filter === 'used') {
            $bookletsQuery->havingRaw(
                'COALESCE(status_0,0) + COALESCE(status_1,0) + COALESCE(status_3,0) + COALESCE(status_4,0) + ' .
                'COALESCE(status_5,0) + COALESCE(status_6,0) + COALESCE(status_7,0) + COALESCE(status_8,0) + COALESCE(status_9,0) > 0'
            );
        } elseif ($dashboard_filter === 'unused') {
            $bookletsQuery->havingRaw(
                'COALESCE(status_0,0) + COALESCE(status_1,0) + COALESCE(status_3,0) + COALESCE(status_4,0) + ' .
                'COALESCE(status_5,0) + COALESCE(status_6,0) + COALESCE(status_7,0) + COALESCE(status_8,0) + COALESCE(status_9,0) = 0'
            );
        }

        // Apply status filter - only show booklets having journals in selected status
        if ($status_fill !== '') {
            $bookletsQuery->having("status_{$status_fill}", '>', 0);
        }

        // Wrap in subquery to allow ORDER BY on aggregate aliases
        $bookletsQuery = DB::table(DB::raw("({$bookletsQuery->toSql()}) as booklet_status"))
            ->mergeBindings($bookletsQuery->getQuery());

        // Sort with NULLS LAST for status columns
        if ($sortColumn === 'journal_name') {
            $bookletsQuery->orderBy('journal_name', $sortDirection);
        } else {
            $bookletsQuery->orderByRaw("{$sortColumn} IS NULL, {$sortColumn} {$sortDirection}");
        }

        $booklets = $bookletsQuery->paginate($perpage);

        // Build bookletStatusData from query results for backward compatibility with view
        $bookletStatusData = [];
        foreach ($booklets as $booklet) {
            foreach ($statusMap as $statusId => $statusLabel) {
                $colName = "status_{$statusId}";
                $bookletStatusData[$booklet->sno][$statusId] = $booklet->$colName ?? 0;
            }
        }

        return view('content.journal_management.journal_reports.list', compact(
            'booklets',
            'bookletStatusData',
            'statusMap',
            'totalBooklets',
            'usedBooklets',
            'unusedBooklets',
            'totalServiceBookletPairs',
            'totalCustomers',
            'totalServices',
            'statusCounts',
            'search_fill',
            'status_fill',
            'dashboard_filter',
            'perpage',
            'sort_by',
            'sort_dir',
            'allowedSortColumns'
        ));
    }

    public function export(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;

        $search_fill = $request->search_fill ?? '';
        $status_fill = $request->status_fill ?? '';
        $dashboard_filter = $request->dashboard_filter ?? '';
        $sort_by = $request->input('sort_by', 'journal_name');
        $sort_dir = $request->input('sort_dir', 'asc');
        $allowedSortColumns = [
            'journal_name',
            'status_0', 'status_1', 'status_3', 'status_4',
            'status_5', 'status_6', 'status_7', 'status_8', 'status_9',
            'customer_count', 'service_count'
        ];
        $sortColumn = in_array($sort_by, $allowedSortColumns) ? $sort_by : 'journal_name';
        $sortDirection = strtolower($sort_dir) === 'desc' ? 'desc' : 'asc';

        // Check permission
        if (!auth()->user()->hasPermission('Journal Management', 'Export', 'Journal Reports')) {
            abort(403, 'Unauthorized');
        }

        // Status mapping from workflow
        $statusMap = [
            0 => 'Submitted',
            1 => 'With Editor',
            3 => 'Under Reviewer',
            4 => 'Reviewed / Revision',
            5 => 'Accepted',
            6 => 'Rejected',
            7 => 'E-Proofing',
            8 => 'Published',
            9 => 'Resubmitted',
        ];

        // CTE for permission-scoped journals
        $journalCte = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->whereNotNull('service_id')
            ->select('booklet_id', 'service_id', 'customer_id', 'status');

        // Apply search filter to CTE
        if ($search_fill != '') {
            $journalCte->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                $q->select('sno')->from('et_journal_booklet')
                    ->where('branch_id', $branch_id)
                    ->where('status', 0)
                    ->where('journal_name', 'LIKE', "%{$search_fill}%");
            });
        }

        // Apply permission scoping to CTE
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) { // JE
                $journalCte->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                });
            } elseif ($user_role == 33) { // JTL
                $journalCte->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                });
            }
        }

        // Main query with conditional aggregation
        $bookletsQuery = JournalBookletModel::where('et_journal_booklet.status', 0)
            ->where('et_journal_booklet.branch_id', $branch_id)
            ->leftJoinSub($journalCte, 'filtered_journals', function ($join) {
                $join->on('filtered_journals.booklet_id', '=', 'et_journal_booklet.sno');
            })
            ->select(
                'et_journal_booklet.sno',
                'et_journal_booklet.journal_name',
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 0 THEN filtered_journals.service_id END) as status_0'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 1 THEN filtered_journals.service_id END) as status_1'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 3 THEN filtered_journals.service_id END) as status_3'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 4 THEN filtered_journals.service_id END) as status_4'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 5 THEN filtered_journals.service_id END) as status_5'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 6 THEN filtered_journals.service_id END) as status_6'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 7 THEN filtered_journals.service_id END) as status_7'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 8 THEN filtered_journals.service_id END) as status_8'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 9 THEN filtered_journals.service_id END) as status_9'),
                DB::raw('COUNT(DISTINCT filtered_journals.customer_id) as customer_count'),
                DB::raw('COUNT(DISTINCT filtered_journals.service_id) as service_count'),
            )
            ->groupBy('et_journal_booklet.sno', 'et_journal_booklet.journal_name');

        // Wrap in subquery to allow HAVING/ORDER BY on aliases
        $bookletsQuery = DB::table(DB::raw("({$bookletsQuery->toSql()}) as booklet_status"))
            ->mergeBindings($bookletsQuery->getQuery());

        // Apply dashboard filter
        if ($dashboard_filter === 'used') {
            $bookletsQuery->havingRaw(
                'COALESCE(status_0,0) + COALESCE(status_1,0) + COALESCE(status_3,0) + COALESCE(status_4,0) + ' .
                'COALESCE(status_5,0) + COALESCE(status_6,0) + COALESCE(status_7,0) + COALESCE(status_8,0) + COALESCE(status_9,0) > 0'
            );
        } elseif ($dashboard_filter === 'unused') {
            $bookletsQuery->havingRaw(
                'COALESCE(status_0,0) + COALESCE(status_1,0) + COALESCE(status_3,0) + COALESCE(status_4,0) + ' .
                'COALESCE(status_5,0) + COALESCE(status_6,0) + COALESCE(status_7,0) + COALESCE(status_8,0) + COALESCE(status_9,0) = 0'
            );
        }

        // Apply status filter
        if ($status_fill !== '') {
            $bookletsQuery->having("status_{$status_fill}", '>', 0);
        }

        // Sort with NULLS LAST
        if ($sortColumn === 'journal_name') {
            $bookletsQuery->orderBy('journal_name', $sortDirection);
        } else {
            $bookletsQuery->orderByRaw("{$sortColumn} IS NULL, {$sortColumn} {$sortDirection}");
        }

        $booklets = $bookletsQuery->get();

        // Build bookletStatusData for export
        $bookletStatusData = [];
        foreach ($booklets as $booklet) {
            foreach ($statusMap as $statusId => $statusLabel) {
                $colName = "status_{$statusId}";
                $bookletStatusData[$booklet->sno][$statusId] = $booklet->$colName ?? 0;
            }
            $bookletStatusData[$booklet->sno]['customer_count'] = $booklet->customer_count ?? 0;
            $bookletStatusData[$booklet->sno]['service_count'] = $booklet->service_count ?? 0;
        }

        // Generate CSV
        $filename = 'journal_reports_' . date('Y-m-d_H-i-s') . '.csv';
        
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function() use ($booklets, $bookletStatusData, $statusMap) {
            $file = fopen('php://output', 'w');
            
            // Header row
            $headerRow = ['Booklet Name'];
            foreach ($statusMap as $statusLabel) {
                $headerRow[] = $statusLabel;
            }
            $headerRow[] = 'Customers';
            $headerRow[] = 'Services';
            fputcsv($file, $headerRow);

            // Data rows
            foreach ($booklets as $booklet) {
                $row = [$booklet->journal_name];
                foreach ($statusMap as $statusId => $statusLabel) {
                    $count = $bookletStatusData[$booklet->sno][$statusId] ?? 0;
                    $row[] = $count;
                }
                $row[] = $bookletStatusData[$booklet->sno]['customer_count'] ?? 0;
                $row[] = $bookletStatusData[$booklet->sno]['service_count'] ?? 0;
                fputcsv($file, $row);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    public function getBookletDetails(Request $request)
    {
        $bookletId = $request->input('booklet_id');
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;

        if (!$bookletId) {
            return response()->json([
                'status' => false,
                'message' => 'Booklet ID is required',
                'data' => null
            ], 400);
        }

        // Verify booklet exists and belongs to branch
        $booklet = JournalBookletModel::where('sno', $bookletId)
            ->where('branch_id', $branch_id)
            ->where('status', 0)
            ->first();

        if (!$booklet) {
            return response()->json([
                'status' => false,
                'message' => 'Booklet not found',
                'data' => null
            ], 404);
        }

        // Build base journal query with ALL filters (booklet_id + permission scoping)
        $buildJournalQuery = function () use ($branch_id, $bookletId, $user_id, $user_role) {
            $query = DB::table('et_manage_journal')
                ->where('branch_id', $branch_id)
                ->where('booklet_id', $bookletId)
                ->where('status', '!=', 2)
                ->whereNotNull('service_id')
                ->select('service_id', 'customer_id', 'status', 'paper_name', 'submited_date', 'accepted_at', 'published_at', 'sno as journal_sno');

            // Apply permission scoping
            if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
                if ($user_role == 34) { // JE
                    $query->whereIn('service_id', function ($q) use ($user_id) {
                        $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                    });
                } elseif ($user_role == 33) { // JTL
                    $query->whereIn('service_id', function ($q) use ($user_id) {
                        $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                    });
                }
            }
            return $query;
        };

        // Get filtered journals for this booklet (with permission scoping) - use as subquery
        $filteredJournals = $buildJournalQuery();

        // Per-service aggregates from booklet journals (source of truth for report counts)
        $serviceAggSub = DB::query()
            ->fromSub($filteredJournals, 'j')
            ->select(
                'j.service_id',
                DB::raw('COUNT(DISTINCT j.journal_sno) as total_journals'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 0 THEN j.journal_sno END) as submitted_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 1 THEN j.journal_sno END) as with_editor_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 3 THEN j.journal_sno END) as under_reviewer_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 4 THEN j.journal_sno END) as reviewed_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 5 THEN j.journal_sno END) as accepted_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 6 THEN j.journal_sno END) as rejected_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 7 THEN j.journal_sno END) as eproofing_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 8 THEN j.journal_sno END) as published_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 9 THEN j.journal_sno END) as resubmitted_count'),
                DB::raw('MAX(CASE WHEN j.status = 8 THEN j.published_at END) as last_published_date')
            )
            ->groupBy('j.service_id');

        // Get services for this booklet - joined to display info
        $services = DB::query()
            ->fromSub($serviceAggSub, 'agg')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'agg.service_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_staff as je', 'je.sno', '=', 'et_customer_services.jc_staff')
            ->leftJoin('et_staff as jtl', 'jtl.sno', '=', 'et_customer_services.jc_id')
            ->select(
                'agg.service_id',
                'et_customer_services.created_at as service_created',
                DB::raw('CASE 
                    WHEN et_customer_services.product_package = 1 THEN (SELECT product_name FROM et_product WHERE sno = et_customer_services.product_id)
                    WHEN et_customer_services.product_package = 2 THEN (SELECT package_name FROM et_package WHERE sno = et_customer_services.package_id)
                    ELSE CONCAT("Service #", agg.service_id)
                END as service_name'),
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id as cus_email',
                'je.staff_name as je_name',
                'jtl.staff_name as jtl_name',
                'agg.total_journals',
                'agg.submitted_count',
                'agg.with_editor_count',
                'agg.under_reviewer_count',
                'agg.reviewed_count',
                'agg.accepted_count',
                'agg.rejected_count',
                'agg.eproofing_count',
                'agg.published_count',
                'agg.resubmitted_count',
                'agg.last_published_date'
            )
            ->orderByRaw('et_customer_services.created_at desc')
            ->get();

        // Append SR ID (same format as other pages: SR-00004/2025)
        foreach ($services as $service) {
            $year = $service->service_created ? date('Y', strtotime($service->service_created)) : date('Y');
            $id = str_pad($service->service_id, 5, '0', STR_PAD_LEFT);
            $service->service_sr_id = "SR-{$id}/{$year}";
        }

        // Per-customer aggregates from booklet journals
        $customerAggSub = DB::query()
            ->fromSub($buildJournalQuery(), 'j')
            ->select(
                'j.customer_id',
                DB::raw('COUNT(DISTINCT j.service_id) as services_count'),
                DB::raw('COUNT(DISTINCT j.journal_sno) as journals_count'),
                DB::raw('COUNT(DISTINCT CASE WHEN j.status = 8 THEN j.service_id END) as published_count')
            )
            ->groupBy('j.customer_id');

        // Get customers summary - joined to display info
        $customers = DB::query()
            ->fromSub($customerAggSub, 'agg')
            ->leftJoin('et_customer as cu', 'cu.sno', '=', 'agg.customer_id')
            ->select(
                'agg.customer_id as journal_customer_id',
                'cu.sno as customer_id',
                'cu.cus_name',
                'cu.customer_id as customer_code',
                'cu.cus_mobile',
                'cu.cus_email_id as cus_email',
                'agg.services_count',
                'agg.journals_count',
                'agg.published_count'
            )
            ->orderByRaw('journals_count desc')
            ->get();

        // Get status breakdown using a fresh query with same filters
        $statusBreakdown = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->where('booklet_id', $bookletId)
            ->where('status', '!=', 2)
            ->whereNotNull('service_id')
            ->when(auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus'), function ($q) use ($user_id, $user_role) {
                if ($user_role == 34) { // JE
                    $q->whereIn('service_id', function ($sub) use ($user_id) {
                        $sub->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                    });
                } elseif ($user_role == 33) { // JTL
                    $q->whereIn('service_id', function ($sub) use ($user_id) {
                        $sub->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                    });
                }
            })
            ->select('status', DB::raw('COUNT(DISTINCT sno) as cnt'))
            ->groupBy('status')
            ->pluck('cnt', 'status')
            ->toArray();

        $statusMap = [
            0 => 'Submitted',
            1 => 'With Editor',
            3 => 'Under Reviewer',
            4 => 'Reviewed / Revision',
            5 => 'Accepted',
            6 => 'Rejected',
            7 => 'E-Proofing',
            8 => 'Published',
            9 => 'Resubmitted',
        ];

        $statusData = [];
        foreach ($statusMap as $id => $label) {
            $statusData[] = [
                'status_id' => $id,
                'status_label' => $label,
                'count' => $statusBreakdown[$id] ?? 0
            ];
        }

        return response()->json([
            'status' => true,
            'message' => 'Booklet details fetched successfully',
            'data' => [
                'booklet' => [
                    'id' => $booklet->sno,
                    'name' => $booklet->journal_name
                ],
                'services' => $services,
                'customers' => $customers,
                'status_breakdown' => $statusData
            ]
        ]);
    }
}