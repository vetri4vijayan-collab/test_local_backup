<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\SimpleType\Jc;
use Carbon\Carbon;
use Exception;
use App\Models\CustomerModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;
class ManageAuthorBiographyController extends Controller
{
    // public function index(Request $request)
    // {
    //     $user_id = $request->user()->user_id;
    //     $user_role = $request->user()->role_id;
    //     $query = DB::table('et_author_biography as ab')

    // ->leftJoin(
    //     'et_customer_services as cs',
    //     'cs.sno',
    //     '=',
    //     'ab.service_id'
    // )
    //  ->leftJoin(
    //     'et_proposal as proposal',
    //     'proposal.sno',
    //     '=',
    //     'cs.proposal_id'
    // )

    // ->leftJoin(
    //     'et_customer as c',
    //     'c.sno',
    //     '=',
    //     'ab.customer_id'
    // )

    // ->leftJoin(
    //     'et_product as p',
    //     'p.sno',
    //     '=',
    //     'cs.product_id'
    // )

    // ->leftJoin(
    //     'et_staff as jtl',
    //     'jtl.sno',
    //     '=',
    //     'ab.jtl_id'
    // )

    // ->leftJoin(
    //     'et_staff as je',
    //     'je.sno',
    //     '=',
    //     'ab.je_id'
    // )
    // ->leftJoin(
    //     'et_staff as ce',
    //     'ce.sno',
    //     '=',
    //     'proposal.collection_id'
    // )
    // ->leftJoin(
    //     'et_staff as cre',
    //     'cre.sno',
    //     '=',
    //     'cs.cre_id'
    // )

    // ->select(
    //     'ab.*',
    //     'cs.customer_id',
    //     'cs.sno as service_id',
    //     'proposal.sno as proposal_id',
    //     'proposal.proposal_id as formatted_proposal_id',
    //     'cs.created_at as service_created_at',
    //     'c.sno as customer_sno',
    //     'c.customer_id as customer_code',
    //     'c.cus_name',
    //     'c.cus_mobile',
    //     'c.cus_email_id',
    //     'p.product_name as service_name',
    //     'jtl.staff_name as jtl_name',
    //     'jtl.staff_image as jtl_image',
    //     'je.staff_name as je_name',
    //     'je.staff_image as je_image',
    //     'proposal.collection_id',
    //     'ce.sno as ce_id',
    //     'ce.staff_name as ce_name',
    //     'ce.staff_image as ce_image',
    //     'cre.sno as cre_id',
    //     'cre.staff_name as cre_name',
    //     'cre.staff_image as cre_image'
    // );

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Filters
    //     |--------------------------------------------------------------------------
    //     */

    //     if($request->filled('customer_id'))
    //     {
    //         $query->where(
    //             'cs.customer_id',
    //             'LIKE',
    //             '%'.$request->customer_id.'%'
    //         );
    //     }

    //     if($request->filled('customer_name'))
    //     {
    //         $query->where(
    //             'c.cus_name',
    //             'LIKE',
    //             '%'.$request->customer_name.'%'
    //         );
    //     }
    //     if($request->filled('cre_filter'))
    //     {
    //         $query->where(
    //             'cre.sno',$request->cre_filter
    //         );
    //     }
    //      if($request->filled('ce_filter'))
    //     {
    //         $query->where(
    //             'ce.sno',$request->ce_filter
    //         );
    //     }
    //      if($request->filled('jtl_filter'))
    //     {
    //         $query->where(
    //             'jtl.sno',$request->jtl_filter
    //         );
    //     }
    //      if($request->filled('je_filter'))
    //     {
    //         $query->where(
    //             'je.sno',$request->je_filter
    //         );
    //     }
    //     if($request->filled('status'))
    //     {
    //         $query->where(
    //             'ab.production_status',
    //             $request->status
    //         );
    //     }
    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'view_self_cus')) {

    //         if ($user_role == 33) {
    //             $query->where('ab.jtl_id', $user_id);

    //         } elseif ($user_role == 34) {

    //             $query->where('ab.je_id', $user_id);

    //         }elseif ($user_role == 42) {

    //             $query->where('proposal.collection_id', $user_id);

    //         }
    //     }elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'global_cus')) {
    //         abort(403, 'Unauthorized');
    //     }
    //     $list = $query

    //         ->orderByDesc('ab.created_at')

    //         ->paginate(20);
    //         foreach ($list as $row) {

    //             $row->authors = DB::table('et_author_biography_members')
    //                 ->where('biography_id', $row->sno)
    //                 ->pluck('author_name')
    //                 ->implode(', ');
    //              $year = date('Y', strtotime($row->service_created_at));
    //             $formattedId = str_pad($row->service_id, 5, '0', STR_PAD_LEFT);
    //             $row->formatted_service_id = "SR-{$formattedId}/{$year}";
    //         }
    // $jtlList = DB::table('et_staff')
    //     ->whereIn('role_id', [33, 20])
    //     ->where('status', 0)
    //     ->orderBy('staff_name')
    //     ->get();
    //     $jeList = DB::table('et_staff')
    //     ->where('role_id', 34)
    //     ->where('status', 0)
    //     ->orderBy('staff_name')
    //     ->get();

    //  $creList = DB::table('et_staff')
    //     ->where('role_id', 16)
    //     ->where('status', 0)
    //     ->orderBy('staff_name')
    //     ->get();
    //      $ceList = DB::table('et_staff')
    //     ->where('role_id', 42)
    //     ->where('status', 0)
    //     ->orderBy('staff_name')
    //     ->get();
    //     // return $list;
    //     return view(
    //         'content.journal_management.manage_journal.manage_author_biography',
    //         compact(
    //             'list',
    //             'jtlList',
    //             'jeList',
    //             'creList',
    //             'ceList'
    //             )
    //         );
    // }
    
    public function index(Request $request)
    {
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;
        $search_fill = $request->search_fill;
        $perpage = (int) $request->input('sorting_filter', 25);
        $query = DB::table('et_author_biography as ab')
 
    ->leftJoin(
        'et_customer_services as cs',
        'cs.sno',
        '=',
        'ab.service_id'
    )
     ->leftJoin(
        'et_proposal as proposal',
        'proposal.sno',
        '=',
        'cs.proposal_id'
    )
 
    ->leftJoin(
        'et_customer as c',
        'c.sno',
        '=',
        'ab.customer_id'
    )
 
    ->leftJoin(
        'et_product as p',
        'p.sno',
        '=',
        'cs.product_id'
    )
 
    ->leftJoin(
        'et_staff as jtl',
        'jtl.sno',
        '=',
        'ab.jtl_id'
    )
 
    ->leftJoin(
        'et_staff as je',
        'je.sno',
        '=',
        'ab.je_id'
    )
    ->leftJoin(
        'et_staff as ce',
        'ce.sno',
        '=',
        'proposal.collection_id'
    )
    ->leftJoin(
        'et_staff as cre',
        'cre.sno',
        '=',
        'cs.cre_id'
    )
 
    ->select(
        'ab.*',
        'cs.customer_id',
        'cs.sno as service_id',
        'proposal.sno as proposal_id',
        'proposal.proposal_id as formatted_proposal_id',
        'cs.created_at as service_created_at',
        'c.sno as customer_sno',
        'c.customer_id as customer_code',
        'c.cus_name',
        'c.cus_mobile',
        'c.cus_email_id',
        'p.product_name as service_name',
        'jtl.staff_name as jtl_name',
        'jtl.staff_image as jtl_image',
        'je.staff_name as je_name',
        'je.staff_image as je_image',
        'proposal.collection_id',
        'ce.sno as ce_id',
        'ce.staff_name as ce_name',
        'ce.staff_image as ce_image',
        'cre.sno as cre_id',
        'cre.staff_name as cre_name',
        'cre.staff_image as cre_image'
    );
 
        /*
        |--------------------------------------------------------------------------
        | Filters
        |--------------------------------------------------------------------------
        */
 
        if($request->filled('customer_id'))
        {
            $query->where(
                'cs.customer_id',
                'LIKE',
                '%'.$request->customer_id.'%'
            );
        }
 
        if($request->filled('customer_name'))
        {
            $query->where(
                'c.cus_name',
                'LIKE',
                '%'.$request->customer_name.'%'
            );
        }
        if($request->filled('cre_filter'))
        {
            $query->where(
                'cre.sno',$request->cre_filter
            );
        }
         if($request->filled('ce_filter'))
        {
            $query->where(
                'ce.sno',$request->ce_filter
            );
        }
         if($request->filled('jtl_filter'))
        {
            $query->where(
                'jtl.sno',$request->jtl_filter
            );
        }
         if($request->filled('je_filter'))
        {
            $query->where(
                'je.sno',$request->je_filter
            );
        }
        if($request->filled('status'))
        {
            $query->where(
                'ab.production_status',
                $request->status
            );
        }
        // Filters
        if ($request->filled('search_fill')) {
            $query->where(function ($query) use ($search_fill) {
                $query->orWhere('c.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('c.cus_mobile', 'LIKE', "%{$search_fill}%")
                    ->orWhere('c.cus_email_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('c.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('p.product_name', 'LIKE', "%{$search_fill}%");
            });
        }
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'view_self_cus')) {
 
            if ($user_role == 33) {
                $query->where('ab.jtl_id', $user_id);
 
            } elseif ($user_role == 34) {
 
                $query->where('ab.je_id', $user_id);
 
            }elseif ($user_role == 42) {
 
                $query->where('proposal.collection_id', $user_id);
 
            }
        }elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'global_cus')) {
            abort(403, 'Unauthorized');
        }
        $list = $query
 
            ->orderByDesc('ab.created_at')
 
            ->paginate($perpage);
            foreach ($list as $row) {
 
                $row->authors = DB::table('et_author_biography_members')
                    ->where('biography_id', $row->sno)
                    ->pluck('author_name')
                    ->implode(', ');
                 $year = date('Y', strtotime($row->service_created_at));
                $formattedId = str_pad($row->service_id, 5, '0', STR_PAD_LEFT);
                $row->formatted_service_id = "SR-{$formattedId}/{$year}";
            }
    $jtlList = DB::table('et_staff')
        ->whereIn('role_id', [33, 20, 45])
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();
        $jeList = DB::table('et_staff')
        ->where('role_id', 34)
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();
 
     $creList = DB::table('et_staff')
        ->where('role_id', 16)
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();
         $ceList = DB::table('et_staff')
        ->where('role_id', 42)
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();
        // return $list;
        return view(
            'content.journal_management.manage_journal.manage_author_biography',
            compact(
                'list',
                'jtlList',
                'jeList',
                'creList',
                'ceList',
                'search_fill',
                'perpage'
                )
            );
    }
    
    public function assignJTL(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        DB::table('et_author_biography')

            ->where('sno',$request->biography_id)

            ->update([

                'jtl_id'=>$request->jtl_id,

                'production_status'=>1,

                'assigned_date'=>now()

            ]);
    $bio = DB::table('et_author_biography as ab')

            ->leftJoin(
                'et_customer_services as cs',
                'cs.sno',
                '=',
                'ab.service_id'
            )

            ->leftJoin(
                'et_customer as c',
                'c.sno',
                '=',
                'ab.customer_id'
            )

            ->select(
                'ab.sno',
                'cs.customer_id',
                'cs.branch_id',
                'c.cus_name'
            )

            ->where('ab.sno', $request->biography_id)

            ->first();
              $assignedBy = DB::table('et_staff')
            ->where('sno', auth()->user()->user_id)
            ->value('staff_name');

             $notificationData = [

            'branch_id' => $bio->branch_id,

            'notification_type' => 'Task',

            'notification_content' => '
                <div class="d-flex align-items-center">

                    <div class="me-3">
                        <span class="badge bg-light-primary">
                            <i class="mdi mdi-account-check-outline fs-3 text-primary"></i>
                        </span>
                    </div>

                    <div>

                        <div class="fs-7 text-primary fw-bold">
                           Journal Biography Assigned
                        </div>

                        <div class="text-secondary fs-8 fw-semibold">
                            '.e($assignedBy).' assigned you as the Journal Team Lead for
                            
                            <br>
                            Customer : '.e($bio->cus_name).'
                        </div>

                    </div>

                </div>
            ',

            'who' => auth()->user()->user_id,

            'whom' =>$request->jtl_id,

            'created_by' => auth()->user()->user_id,

            'updated_by' => auth()->user()->user_id,

            'status' => 0

        ];

        $helper->createNotificationToStaff($notificationData);
        return response()->json([

            'status'=>200,

            'message'=>'JTL Assigned Successfully'

        ]);

    }
    public function assignJE(Request $request)
{
      $helper = new \App\Helpers\Helpers();
    DB::table('et_author_biography')

        ->where('sno', $request->biography_id)

        ->update([

            'je_id' => $request->je_id,

            'production_status' => 2,

            'je_assigned_date' => now()

        ]);
        $bio = DB::table('et_author_biography as ab')

            ->leftJoin(
                'et_customer_services as cs',
                'cs.sno',
                '=',
                'ab.service_id'
            )

            ->leftJoin(
                'et_customer as c',
                'c.sno',
                '=',
                'ab.customer_id'
            )

            ->select(
                'ab.sno',
                'cs.customer_id',
                'cs.branch_id',
                'c.cus_name'
            )

            ->where('ab.sno', $request->biography_id)

            ->first();
              $assignedBy = DB::table('et_staff')
            ->where('sno', auth()->user()->user_id)
            ->value('staff_name');

             $notificationData = [

            'branch_id' => $bio->branch_id,

            'notification_type' => 'Task',

            'notification_content' => '
                <div class="d-flex align-items-center">

                    <div class="me-3">
                        <span class="badge bg-light-primary">
                            <i class="mdi mdi-account-check-outline fs-3 text-primary"></i>
                        </span>
                    </div>

                    <div>

                        <div class="fs-7 text-primary fw-bold">
                           Journal Biography Assigned
                        </div>

                        <div class="text-secondary fs-8 fw-semibold">
                            '.e($assignedBy).' assigned you as the Journal Executive for
                            
                            <br>
                            Customer : '.e($bio->cus_name).'
                        </div>

                    </div>

                </div>
            ',

            'who' => auth()->user()->user_id,

            'whom' =>$request->je_id,

            'created_by' => auth()->user()->user_id,

            'updated_by' => auth()->user()->user_id,

            'status' => 0

        ];

        $helper->createNotificationToStaff($notificationData);

    return response()->json([

        'status' => 200,

        'message' => 'Journal Editor Assigned Successfully'

    ]);
}
public function getProposalJournalServices(Request $request)
{
    $bio = DB::table('et_author_biography')

        ->where('sno',$request->biography_id)

        ->first();

    $proposalId = DB::table('et_customer_services')

        ->where('sno',$bio->service_id)

        ->value('proposal_id');

    $services = DB::table('et_customer_services as cs')

        ->join(
            'et_product as p',
            'p.sno',
            '=',
            'cs.product_id'
        )

        ->where(
            'cs.proposal_id',
            $proposalId
        )

        ->where(
            'p.journal_product',
            1
        )

        ->select(
            'cs.sno',
            'p.product_name'
        )

        ->get();

    return response()->json([

        'services'=>$services

    ]);
}
public function submitUpdatedManuscript(Request $request)
{
    $bio = DB::table('et_author_biography')

        ->where('sno',$request->biography_id)

        ->first();
    // return $request->services;
    if($request->hasFile('manuscript'))
    {

        $file=$request->file('manuscript');

        $name=time().'.'.$file->extension();

        $file->move(
            public_path('updated_manuscripts'),
            $name
        );

        DB::table('et_author_biography')

            ->where(
                'sno',
                $bio->sno
            )

            ->update([

                'updated_manuscript'=>$name,

                'production_status'=>3

            ]);

    }

   DB::transaction(function () use ($bio, $request) {

        // Save selected services in biography
      DB::table('et_author_biography_services')
        ->where('biography_id', $bio->sno)
        ->delete();

        foreach ($request->services as $service) {

            DB::table('et_author_biography_services')->insert([

                'biography_id' => $bio->sno,

                'service_id' => $service,

                'created_at' => now(),

                'updated_at' => now()

            ]);
        }


    });

    return response()->json([

        'status'=>200,

        'message'=>'Updated successfully.'

    ]);
}
public function journalConfirmation($id)
{
    $helper = new \App\Helpers\Helpers();
      $biographyId = $helper->encrypt_decrypt($id, 'decrypt');
    $bio = DB::table('et_author_biography as ab')

        ->leftJoin(
            'et_customer_services as cs',
            'cs.sno',
            '=',
            'ab.service_id'
        )

        ->leftJoin(
            'et_customer as c',
            'c.sno',
            '=',
            'ab.customer_id'
        )
         ->leftJoin(
            'et_proposal as p',
            'cs.proposal_id',
            '=',
            'p.sno'
        )
        ->select(
            'ab.*',
            'cs.customer_id',
            'cs.sno as service_id',
            'cs.created_at as service_created_at',
            'c.customer_id as customer_code',
            'c.cus_name',
            'p.proposal_id as proposal_id'
        )

        ->where('ab.sno',$biographyId)

        ->first();


        $year = date('Y', strtotime($bio->service_created_at));
        $formattedId = str_pad($bio->service_id, 5, '0', STR_PAD_LEFT);
        $bio->formatted_service_id = "SR-{$formattedId}/{$year}";
        
        $serviceIds = DB::table('et_author_biography_services')
            ->where('biography_id', $bio->sno)
            ->pluck('service_id')
            ->toArray();
        $services = DB::table('et_customer_services')

            ->leftJoin(
                'et_product',
                'et_product.sno',
                '=',
                'et_customer_services.product_id'
            )

            ->whereIn(
                'et_customer_services.sno',
                $serviceIds
            )

            ->select(
                'et_customer_services.*',
                'et_product.product_name'
            )

            ->get();
            $selectedServices = DB::table('et_author_biography_services as bs')

            ->join(
                'et_customer_services as cs',
                'cs.sno',
                '=',
                'bs.service_id'
            )

            ->join(
                'et_product as p',
                'p.sno',
                '=',
                'cs.product_id'
            )

            ->where(
                'bs.biography_id',
                $bio->sno
            )

            ->select(
                'cs.sno',
                'cs.customer_id',
                'p.product_name',
                'cs.created_at as service_created_at'
            )

            ->get();
               foreach ($selectedServices as $row) {
                 $year = date('Y', strtotime($row->service_created_at));
                $formattedId = str_pad($row->sno, 5, '0', STR_PAD_LEFT);
                $row->formatted_service_id = "SR-{$formattedId}/{$year}";
            }
            // return $bio;
    return view(
        'content.production_management.manage_deliverables.journal_confirmation',
        compact(
            'bio',
            'services',
            'selectedServices'
        )
    );
}
public function confirmJournalSubmission(Request $request)
{

    $bio = DB::table('et_author_biography')
        ->where('sno',$request->biography_id)
        ->first();

    if ($bio->customer_confirmation == 1) {

        return response()->json([

            'status' => 200,

            'message' => 'Journal requirement already confirmed.'

        ]);

    }

    $services = DB::table('et_author_biography_services')

        ->where('biography_id',$bio->sno)

        ->pluck('service_id');

    DB::table('et_customer_services')

        ->whereIn('sno',$services)

        ->update([
            'jc_id' => $bio->jtl_id,
            'jc_staff' => $bio->je_id,
            'journal_check' => 1
        ]);

    DB::table('et_author_biography')

        ->where('sno',$bio->sno)

        ->update([

            'customer_confirmation' => 1,

            'customer_confirmed_at' => now(),

            'production_status' => 4

        ]);

    return response()->json([

        'status'=>200,

        'message'=>'Journal submission confirmed successfully.'

    ]);

}

// public function downloadBiography($id)
// {

//     $bio = DB::table('et_author_biography as ab')

//         ->leftJoin(
//             'et_customer_services as cs',
//             'cs.sno',
//             '=',
//             'ab.service_id'
//         )

//         ->leftJoin(
//             'et_customers as c',
//             'c.sno',
//             '=',
//             'ab.customer_id'
//         )

//         ->leftJoin(
//             'et_product as p',
//             'p.sno',
//             '=',
//             'cs.service_name'
//         )

//         ->select(

//             'ab.*',

//             'c.cus_name',

//             'cs.customer_id',

//             'p.product_name'

//         )

//         ->where(
//             'ab.sno',
//             $id
//         )

//         ->first();

//     if(!$bio){

//         abort(404);

//     }

//     $members = DB::table('et_author_biography_members')

//         ->where(
//             'biography_id',
//             $bio->sno
//         )

//         ->orderBy('author_type')

//         ->get();

//     $phpWord = new PhpWord();

//     $section = $phpWord->addSection();

//     /*
//     |--------------------------------------------------------------------------
//     | Title
//     |--------------------------------------------------------------------------
//     */

//     $section->addText(

//         'AUTHOR BIOGRAPHY',

//         [

//             'bold'=>true,

//             'size'=>18

//         ],

//         [

//             'alignment'=>Jc::CENTER

//         ]

//     );

//     $section->addTextBreak();

//     /*
//     |--------------------------------------------------------------------------
//     | Customer Details
//     |--------------------------------------------------------------------------
//     */

//     $section->addText(

//         'Customer Details',

//         [

//             'bold'=>true,

//             'size'=>14

//         ]

//     );

//     $section->addText(

//         'Customer ID : '.$bio->customer_id
//     );

//     $section->addText(

//         'Customer Name : '.$bio->cus_name
//     );

//     $section->addText(

//         'Service : '.$bio->product_name
//     );

//     $section->addTextBreak();

//     /*
//     |--------------------------------------------------------------------------
//     | Authors
//     |--------------------------------------------------------------------------
//     */

//     foreach($members as $member){

//         $title = $member->author_type == 1

//             ? 'Corresponding Author'

//             : 'Co Author';

//         $section->addText(

//             $title,

//             [

//                 'bold'=>true,

//                 'size'=>14,

//                 'color'=>'0066CC'

//             ]

//         );

//         $section->addText(

//             'Name : '.$member->author_name,

//             [

//                 'bold'=>true

//             ]

//         );

//         $section->addTextBreak(1);

//         $section->addText(

//             $member->biography

//         );

//         /*
//         |--------------------------------------------------------------------------
//         | Photo
//         |--------------------------------------------------------------------------
//         */

//         if(!empty($member->photo)){

//             $photo = public_path(
//                 'author_biography/'.$member->photo
//             );

//             if(file_exists($photo)){

//                 $section->addTextBreak();

//                 $section->addImage(

//                     $photo,

//                     [

//                         'width'=>120,

//                         'height'=>120,

//                         'alignment'=>Jc::CENTER

//                     ]

//                 );

//             }

//         }

//         $section->addTextBreak(2);

//     }

//     /*
//     |--------------------------------------------------------------------------
//     | Download
//     |--------------------------------------------------------------------------
//     */

//     $fileName =

//         'Author_Biography_'.

//         $bio->customer_id.

//         '.docx';

//     $tempFile = tempnam(

//         sys_get_temp_dir(),

//         'bio'

//     );

//     IOFactory::createWriter(

//         $phpWord,

//         'Word2007'

//     )->save(

//         $tempFile

//     );

//     return response()

//         ->download(

//             $tempFile,

//             $fileName

//         )

//         ->deleteFileAfterSend(true);

// }
public function downloadBiography($id)
{
    $helper = new \App\Helpers\Helpers();

    $serviceId = $helper->encrypt_decrypt($id,'decrypt');

    $biography = DB::table('et_author_biography as ab')

        ->join('et_customer_services as cs','cs.sno','=','ab.service_id')

        ->join('et_customer as c','c.sno','=','ab.customer_id')

        ->leftJoin('et_product as p','p.sno','=','cs.product_id')

        ->select(
            'ab.*',
            'c.cus_name',
            'c.customer_id',
            'p.product_name'
        )

        ->where('ab.service_id',$serviceId)

        ->first();

    if(!$biography){
        abort(404);
    }

    $authors = DB::table('et_author_biography_members')

        ->where('biography_id',$biography->sno)

        ->where('status',0)

        ->orderBy('author_type')

        ->get();

    $html = view(
        'content.production_management.manage_deliverables.word_author_biography',
        [
            'biography' => $biography,
            'authors' => $authors
        ]
    )->render();
 return $html;
    return response($html)
        ->header('Content-Type','application/msword')
        ->header(
            'Content-Disposition',
            'attachment; filename="Author_Biography_'.$serviceId.'.doc"'
        );
}

// public function getBiographyForEdit(Request $request)
// {
//     $biography = DB::table('et_author_biography')
//         ->where('sno', $request->biography_id)
//         ->first();

//     if(!$biography){

//         return response()->json([
//             'status' => 404,
//             'message' => 'Biography not found.'
//         ]);
//     }

//     /*
//     |--------------------------------------------------------------------------
//     | Important: JTL lock
//     |--------------------------------------------------------------------------
//     */

//     if(!empty($biography->jtl_id)){

//         return response()->json([
//             'status' => 403,
//             'message' => 'Biography cannot be edited after JTL assignment.'
//         ]);
//     }

//     $authors = DB::table('et_author_biography_members')
//         ->where('biography_id', $biography->sno)
//         ->where('status', 0)
//         ->orderBy('author_type')
//         ->get();

//     return response()->json([

//         'status' => 200,

//         'biography' => $biography,

//         'authors' => $authors

//     ]);
// }

public function getBiographyForEdit(Request $request)
{
    $biography = DB::table('et_author_biography')
        ->where('sno', $request->biography_id)
        ->first();
 
    if(!$biography){
 
        return response()->json([
            'status' => 404,
            'message' => 'Biography not found.'
        ]);
    }
 
    /*
    |--------------------------------------------------------------------------
    | Important: JTL lock
    |--------------------------------------------------------------------------
    */
 
    // if(!empty($biography->jtl_id)){
 
    //     return response()->json([
    //         'status' => 403,
    //         'message' => 'Biography cannot be edited after JTL assignment.'
    //     ]);
    // }
 
    $authors = DB::table('et_author_biography_members')
        ->where('biography_id', $biography->sno)
        ->where('status', 0)
        ->orderBy('author_type')
        ->get();
 
    return response()->json([
 
        'status' => 200,
 
        'biography' => $biography,
 
        'authors' => $authors
 
    ]);
}

// public function updateAuthorBiography(Request $request)
// {
//     $biography = DB::table('et_author_biography')
//         ->where('sno', $request->biography_id)
//         ->first();

//     if(!$biography){

//         return response()->json([
//             'status' => 404,
//             'message' => 'Biography not found.'
//         ]);
//     }

//     /*
//     |--------------------------------------------------------------------------
//     | JTL Assignment Lock
//     |--------------------------------------------------------------------------
//     */

//     if(!empty($biography->jtl_id)){

//         return response()->json([
//             'status' => 403,
//             'message' => 'Biography cannot be edited after JTL assignment.'
//         ]);
//     }

//     /*
//     |--------------------------------------------------------------------------
//     | Corresponding Author
//     |--------------------------------------------------------------------------
//     */

//     $corresponding = DB::table('et_author_biography_members')
//         ->where('sno', $request->corresponding_member_id)
//         ->where('biography_id', $biography->sno)
//         ->first();

//     if($corresponding){

//         $update = [

//             'author_name' => $request->corresponding_name,

//             'biography' => $request->corresponding_bio,

//             'updated_at' => now()

//         ];

//         if($request->hasFile('corresponding_photo')){

//             $file = $request->file('corresponding_photo');

//             $name =
//                 time().'_corresponding.'.
//                 $file->getClientOriginalExtension();

//             $file->move(
//                 public_path('author_biography'),
//                 $name
//             );

//             $update['photo'] = $name;
//         }

//         DB::table('et_author_biography_members')
//             ->where('sno', $corresponding->sno)
//             ->update($update);
//     }


//     /*
//     |--------------------------------------------------------------------------
//     | Existing Co Authors
//     |--------------------------------------------------------------------------
//     */

//     $submittedMemberIds = [];

//     if($request->has('co_authors')){

//         foreach($request->co_authors as $co){

//             $memberId = $co['member_id'] ?? null;

//             /*
//             |--------------------------------------------------------------------------
//             | Existing Co Author
//             |--------------------------------------------------------------------------
//             */

//             if($memberId){

//                 $member = DB::table(
//                     'et_author_biography_members'
//                 )
//                 ->where('sno', $memberId)
//                 ->where(
//                     'biography_id',
//                     $biography->sno
//                 )
//                 ->first();

//                 if(!$member){
//                     continue;
//                 }

//                 $update = [

//                     'author_name' =>
//                         $co['name'] ?? '',

//                     'biography' =>
//                         $co['biography'] ?? '',

//                     'updated_at' =>
//                         now()

//                 ];

//                 if(
//                     isset($co['photo']) &&
//                     $co['photo'] instanceof \Illuminate\Http\UploadedFile
//                 ){

//                     $file = $co['photo'];

//                     $name =
//                         time().'_co_'.$memberId.'.'.
//                         $file->getClientOriginalExtension();

//                     $file->move(
//                         public_path('author_biography'),
//                         $name
//                     );

//                     $update['photo'] = $name;
//                 }

//                 DB::table(
//                     'et_author_biography_members'
//                 )
//                 ->where('sno', $memberId)
//                 ->update($update);

//                 $submittedMemberIds[] = $memberId;

//             }

//             /*
//             |--------------------------------------------------------------------------
//             | New Co Author
//             |--------------------------------------------------------------------------
//             */

//             else {

//                 $photo = null;

//                 if(
//                     isset($co['photo']) &&
//                     $co['photo'] instanceof \Illuminate\Http\UploadedFile
//                 ){

//                     $file = $co['photo'];

//                     $photo =
//                         time().'_co_'.uniqid().'.'.
//                         $file->getClientOriginalExtension();

//                     $file->move(
//                         public_path('author_biography'),
//                         $photo
//                     );
//                 }

//                 $newId = DB::table(
//                     'et_author_biography_members'
//                 )->insertGetId([

//                     'biography_id' =>
//                         $biography->sno,

//                     'author_type' => "co_author",

//                     'author_name' =>
//                         $co['name'] ?? '',

//                     'biography' =>
//                         $co['biography'] ?? '',

//                     'photo' => $photo,

//                     'status' => 0,

//                     'created_at' => now(),

//                     'updated_at' => now()

//                 ]);

//                 $submittedMemberIds[] = $newId;
//             }
//         }
//     }


//     /*
//     |--------------------------------------------------------------------------
//     | Remove deleted Co Authors
//     |--------------------------------------------------------------------------
//     */

//     $existingCoAuthors = DB::table(
//         'et_author_biography_members'
//     )
//     ->where('biography_id', $biography->sno)
//     ->where('author_type', 2)
//     ->where('status', 0)
//     ->pluck('sno')
//     ->toArray();

//     foreach($existingCoAuthors as $existingId){

//         if(!in_array($existingId, $submittedMemberIds)){

//             DB::table(
//                 'et_author_biography_members'
//             )
//             ->where('sno', $existingId)
//             ->update([
//                 'status' => 1,
//                 'updated_at' => now()
//             ]);
//         }
//     }


//     return response()->json([

//         'status' => 200,

//         'message' =>
//             'Biography updated successfully.'

//     ]);
// }

public function updateAuthorBiography(Request $request)
{
    $biography = DB::table('et_author_biography')
        ->where('sno', $request->biography_id)
        ->first();
 
    if(!$biography){
 
        return response()->json([
            'status' => 404,
            'message' => 'Biography not found.'
        ]);
    }
 
    /*
    |--------------------------------------------------------------------------
    | JTL Assignment Lock
    |--------------------------------------------------------------------------
    */
 
    if(!empty($biography->jtl_id)){
 
        return response()->json([
            'status' => 403,
            'message' => 'Biography cannot be edited after JTL assignment.'
        ]);
    }
 
    /*
    |--------------------------------------------------------------------------
    | Corresponding Author
    |--------------------------------------------------------------------------
    */
 
    $corresponding = DB::table('et_author_biography_members')
        ->where('sno', $request->corresponding_member_id)
        ->where('biography_id', $biography->sno)
        ->first();
 
    if($corresponding){
 
        $update = [
 
            'author_name' => $request->corresponding_name,
 
            'biography' => $request->corresponding_bio,
 
            'updated_at' => now()
 
        ];
 
        if($request->hasFile('corresponding_photo')){
 
            $file = $request->file('corresponding_photo');
 
            $name =
                time().'_corresponding.'.
                $file->getClientOriginalExtension();
 
            $file->move(
                public_path('author_biography'),
                $name
            );
 
            $update['photo'] = $name;
        }
 
        DB::table('et_author_biography_members')
            ->where('sno', $corresponding->sno)
            ->update($update);
    }
 
 
    /*
    |--------------------------------------------------------------------------
    | Existing Co Authors
    |--------------------------------------------------------------------------
    */
 
    $submittedMemberIds = [];
 
    if($request->has('co_authors')){
 
        foreach($request->co_authors as $co){
 
            $memberId = $co['member_id'] ?? null;
 
            /*
            |--------------------------------------------------------------------------
            | Existing Co Author
            |--------------------------------------------------------------------------
            */
 
            if($memberId){
 
                $member = DB::table(
                    'et_author_biography_members'
                )
                ->where('sno', $memberId)
                ->where(
                    'biography_id',
                    $biography->sno
                )
                ->first();
 
                if(!$member){
                    continue;
                }
 
                $update = [
 
                    'author_name' =>
                        $co['name'] ?? '',
 
                    'biography' =>
                        $co['biography'] ?? '',
 
                    'updated_at' =>
                        now()
 
                ];
 
                if(
                    isset($co['photo']) &&
                    $co['photo'] instanceof \Illuminate\Http\UploadedFile
                ){
 
                    $file = $co['photo'];
 
                    $name =
                        time().'_co_'.$memberId.'.'.
                        $file->getClientOriginalExtension();
 
                    $file->move(
                        public_path('author_biography'),
                        $name
                    );
 
                    $update['photo'] = $name;
                }
 
                DB::table(
                    'et_author_biography_members'
                )
                ->where('sno', $memberId)
                ->update($update);
 
                $submittedMemberIds[] = $memberId;
 
            }
 
            /*
            |--------------------------------------------------------------------------
            | New Co Author
            |--------------------------------------------------------------------------
            */
 
            else {
 
                $photo = null;
 
                if(
                    isset($co['photo']) &&
                    $co['photo'] instanceof \Illuminate\Http\UploadedFile
                ){
 
                    $file = $co['photo'];
 
                    $photo =
                        time().'_co_'.uniqid().'.'.
                        $file->getClientOriginalExtension();
 
                    $file->move(
                        public_path('author_biography'),
                        $photo
                    );
                }
 
                $newId = DB::table(
                    'et_author_biography_members'
                )->insertGetId([
 
                    'biography_id' =>
                        $biography->sno,
 
                    'author_type' => "co_author",
 
                    'author_name' =>
                        $co['name'] ?? '',
 
                    'biography' =>
                        $co['biography'] ?? '',
 
                    'photo' => $photo,
 
                    'status' => 0,
 
                    'created_at' => now(),
 
                    'updated_at' => now()
 
                ]);
 
                $submittedMemberIds[] = $newId;
            }
        }
    }
 
 
    /*
    |--------------------------------------------------------------------------
    | Remove deleted Co Authors
    |--------------------------------------------------------------------------
    */
 
    $existingCoAuthors = DB::table(
        'et_author_biography_members'
    )
    ->where('biography_id', $biography->sno)
    ->where('author_type', 2)
    ->where('status', 0)
    ->pluck('sno')
    ->toArray();
 
    foreach($existingCoAuthors as $existingId){
 
        if(!in_array($existingId, $submittedMemberIds)){
 
            DB::table(
                'et_author_biography_members'
            )
            ->where('sno', $existingId)
            ->update([
                'status' => 1,
                'updated_at' => now()
            ]);
        }
    }
 
 
    return response()->json([
 
        'status' => 200,
 
        'message' =>
            'Biography updated successfully.'
 
    ]);
}

public function updateAuthorBiographyManuscript(Request $request)
{
    $request->validate([
 
        'biography_id' => 'required|integer',
 
        'manuscript_file' =>
            'required|file|mimes:doc,docx,pdf|max:20480'
 
    ]);
 
    $biography = DB::table('et_author_biography')
        ->where('sno', $request->biography_id)
        ->first();
 
    if (!$biography) {
 
        return response()->json([
 
            'status' => 404,
            'message' => 'Biography not found.'
 
        ]);
 
    }
 
    // // BH can edit only before JTL assignment
    // if ($biography->production_status != 0) {
 
    //     return response()->json([
 
    //         'status' => 403,
    //         'message' =>
    //             'Manuscript cannot be edited after JTL assignment.'
 
    //     ]);
 
    // }
 
    $file = $request->file('manuscript_file');
 
    $fileName =
       time().'_'.$file->getClientOriginalName();
 
    $file->move(
        public_path('manuscripts'),
        $fileName
    );
    //  $manuscript = time().'_'.$file->getClientOriginalName();
 
    //         $file->move(public_path('manuscripts'), $manuscript);
 
    DB::table('et_author_biography')
        ->where('sno', $request->biography_id)
        ->update([
 
            'manuscript_file' => $fileName,
            'updated_at' => now()
 
        ]);
 
    return response()->json([
 
        'status' => 200,
        'message' =>
            'Manuscript updated successfully.'
 
    ]);
}

public function CustomerBiographyCredentials($id = '')
  {
    $credentials = DB::table('et_biography_pass_locker')
      ->select('et_biography_pass_locker.email_id', 'et_biography_pass_locker.password', 'et_biography_pass_locker.status', 'et_biography_pass_locker.link')
      ->where('et_biography_pass_locker.customer_id', $id)
      ->get();
 
    $customer = CustomerModel::select('sno', 'cus_name', 'cus_mobile', 'cus_email_id')->where('sno', $id)->first();
 
    if ($customer) {
      return response([
        'status' => 200,
        'message' => 'Credentials Fetched Successfully',
        'error_msg' => null,
        'data' => [
          'credentials' => $credentials,
          'customer' => $customer
        ]
      ], 200);
    } else {
      return response([
        'status' => 302,
        'message' => 'No Records Found!',
        'error_msg' => null,
        'data' => null
      ], 302);
    }
  }
  
}