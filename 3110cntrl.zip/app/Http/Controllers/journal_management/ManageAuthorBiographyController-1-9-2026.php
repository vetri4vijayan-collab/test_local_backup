<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\JournalBookletModel;
use App\Models\JournalHistoryModel;
use App\Models\ManageJournalModel;
use App\Models\FollowupReasonModel;
use App\Models\PassLockerModel;
use App\Models\StaffModel;
use App\Models\TaskRequestModel;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;
class ManageAuthorBiographyController extends Controller
{

    // public function index(Request $request)
    // {
    //     $user_id = $request->user()->user_id;
    //     $user_role = $request->user()->role_id;
    //     $query = DB::table('et_author_biography as ab')
 
    // ->leftJoin(
    //     'et_customer_services as cs',
    //     'cs.sno',
    //     '=',
    //     'ab.service_id'
    // )
    //  ->leftJoin(
    //     'et_proposal as proposal',
    //     'proposal.sno',
    //     '=',
    //     'cs.proposal_id'
    // )
 
    // ->leftJoin(
    //     'et_customer as c',
    //     'c.sno',
    //     '=',
    //     'ab.customer_id'
    // )
 
    // ->leftJoin(
    //     'et_product as p',
    //     'p.sno',
    //     '=',
    //     'cs.product_id'
    // )
 
    // ->leftJoin(
    //     'et_staff as jtl',
    //     'jtl.sno',
    //     '=',
    //     'ab.jtl_id'
    // )
 
    // ->leftJoin(
    //     'et_staff as je',
    //     'je.sno',
    //     '=',
    //     'ab.je_id'
    // )
    // ->leftJoin(
    //     'et_staff as ce',
    //     'ce.sno',
    //     '=',
    //     'proposal.collection_id'
    // )
 
    // ->select(
    //     'ab.*',
    //     'cs.customer_id',
    //     'cs.sno as service_id',
    //     'proposal.sno as proposal_id',
    //     'proposal.proposal_id as formatted_proposal_id',
    //     'cs.created_at as service_created_at',
    //     'c.sno as customer_sno',
    //     'c.customer_id as customer_code',
    //     'c.cus_name',
    //     'c.cus_mobile',
    //     'c.cus_email_id',
    //     'p.product_name as service_name',
    //     'jtl.staff_name as jtl_name',
    //     'jtl.staff_image as jtl_image',
    //     'je.staff_name as je_name',
    //     'je.staff_image as je_image',
    //     'proposal.collection_id',
    //     'ce.staff_name as ce_name',
    //     'ce.staff_image as ce_image'
    // );
 
    //     /*
    //     |--------------------------------------------------------------------------
    //     | Filters
    //     |--------------------------------------------------------------------------
    //     */
 
    //     if($request->filled('customer_id'))
    //     {
    //         $query->where(
    //             'cs.customer_id',
    //             'LIKE',
    //             '%'.$request->customer_id.'%'
    //         );
    //     }
 
    //     if($request->filled('customer_name'))
    //     {
    //         $query->where(
    //             'c.cus_name',
    //             'LIKE',
    //             '%'.$request->customer_name.'%'
    //         );
    //     }
 
    //     if($request->filled('status'))
    //     {
    //         $query->where(
    //             'ab.production_status',
    //             $request->status
    //         );
    //     }
    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'view_self_cus')) {
 
    //         if ($user_role == 33) {
    //             $query->where('ab.jtl_id', $user_id);
 
    //         } elseif ($user_role == 34) {
 
    //             $query->where('ab.je_id', $user_id);
 
    //         }elseif ($user_role == 42) {
 
    //             $query->where('proposal.collection_id', $user_id);
 
    //         }
    //     }elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'global_cus')) {
    //         abort(403, 'Unauthorized');
    //     }
    //     $list = $query
 
    //         ->orderByDesc('ab.created_at')
 
    //         ->paginate(20);
    //         foreach ($list as $row) {
 
    //             $row->authors = DB::table('et_author_biography_members')
    //                 ->where('biography_id', $row->sno)
    //                 ->pluck('author_name')
    //                 ->implode(', ');
    //              $year = date('Y', strtotime($row->service_created_at));
    //             $formattedId = str_pad($row->service_id, 5, '0', STR_PAD_LEFT);
    //             $row->formatted_service_id = "SR-{$formattedId}/{$year}";
    //         }
    // $jtlList = DB::table('et_staff')
    //     ->whereIn('role_id', [33, 20])
    //     ->where('status', 0)
    //     ->orderBy('staff_name')
    //     ->get();
    //     $jeList = DB::table('et_staff')
    //     ->where('role_id', 34)
    //     ->where('status', 0)
    //     ->orderBy('staff_name')
    //     ->get();
    //     // return $list;
    //     return view(
    //         'content.journal_management.manage_journal.manage_author_biography',
    //         compact(
    //             'list',
    //             'jtlList',
    //             'jeList'
    //             )
    //         );
    // }
 
    // public function index(Request $request)
    // {
    //     $user_id = $request->user()->user_id;
    //     $user_role = $request->user()->role_id;
    //     $query = DB::table('et_author_biography as ab')
 
    // ->leftJoin(
    //     'et_customer_services as cs',
    //     'cs.sno',
    //     '=',
    //     'ab.service_id'
    // )
    //  ->leftJoin(
    //     'et_proposal as proposal',
    //     'proposal.sno',
    //     '=',
    //     'cs.proposal_id'
    // )
 
    // ->leftJoin(
    //     'et_customer as c',
    //     'c.sno',
    //     '=',
    //     'ab.customer_id'
    // )
 
    // ->leftJoin(
    //     'et_product as p',
    //     'p.sno',
    //     '=',
    //     'cs.product_id'
    // )
 
    // ->leftJoin(
    //     'et_staff as jtl',
    //     'jtl.sno',
    //     '=',
    //     'ab.jtl_id'
    // )
 
    // ->leftJoin(
    //     'et_staff as je',
    //     'je.sno',
    //     '=',
    //     'ab.je_id'
    // )
    // ->leftJoin(
    //     'et_staff as ce',
    //     'ce.sno',
    //     '=',
    //     'proposal.collection_id'
    // )
    // ->leftJoin(
    //     'et_staff as cre',
    //     'cre.sno',
    //     '=',
    //     'cs.cre_id'
    // )
 
    // ->select(
    //     'ab.*',
    //     'cs.customer_id',
    //     'cs.sno as service_id',
    //     'proposal.sno as proposal_id',
    //     'proposal.proposal_id as formatted_proposal_id',
    //     'cs.created_at as service_created_at',
    //     'c.sno as customer_sno',
    //     'c.customer_id as customer_code',
    //     'c.cus_name',
    //     'c.cus_mobile',
    //     'c.cus_email_id',
    //     'p.product_name as service_name',
    //     'jtl.staff_name as jtl_name',
    //     'jtl.staff_image as jtl_image',
    //     'je.staff_name as je_name',
    //     'je.staff_image as je_image',
    //     'proposal.collection_id',
    //     'ce.staff_name as ce_name',
    //     'ce.staff_image as ce_image',
    //     'cre.staff_name as cre_name',
    //     'cre.staff_image as cre_image'
    // );
 
    //     /*
    //     |--------------------------------------------------------------------------
    //     | Filters
    //     |--------------------------------------------------------------------------
    //     */
 
    //     if($request->filled('customer_id'))
    //     {
    //         $query->where(
    //             'cs.customer_id',
    //             'LIKE',
    //             '%'.$request->customer_id.'%'
    //         );
    //     }
 
    //     if($request->filled('customer_name'))
    //     {
    //         $query->where(
    //             'c.cus_name',
    //             'LIKE',
    //             '%'.$request->customer_name.'%'
    //         );
    //     }
 
    //     if($request->filled('status'))
    //     {
    //         $query->where(
    //             'ab.production_status',
    //             $request->status
    //         );
    //     }
    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'view_self_cus')) {
 
    //         if ($user_role == 33) {
    //             $query->where('ab.jtl_id', $user_id);
 
    //         } elseif ($user_role == 34) {
 
    //             $query->where('ab.je_id', $user_id);
 
    //         }elseif ($user_role == 42) {
 
    //             $query->where('proposal.collection_id', $user_id);
 
    //         }
    //     }elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'global_cus')) {
    //         abort(403, 'Unauthorized');
    //     }
    //     $list = $query
 
    //         ->orderByDesc('ab.created_at')
 
    //         ->paginate(20);
    //         foreach ($list as $row) {
 
    //             $row->authors = DB::table('et_author_biography_members')
    //                 ->where('biography_id', $row->sno)
    //                 ->pluck('author_name')
    //                 ->implode(', ');
    //              $year = date('Y', strtotime($row->service_created_at));
    //             $formattedId = str_pad($row->service_id, 5, '0', STR_PAD_LEFT);
    //             $row->formatted_service_id = "SR-{$formattedId}/{$year}";
    //         }
    // $jtlList = DB::table('et_staff')
    //     ->whereIn('role_id', [33, 20])
    //     ->where('status', 0)
    //     ->orderBy('staff_name')
    //     ->get();
    //     $jeList = DB::table('et_staff')
    //     ->where('role_id', 34)
    //     ->where('status', 0)
    //     ->orderBy('staff_name')
    //     ->get();
    //     // return $list;
    //     return view(
    //         'content.journal_management.manage_journal.manage_author_biography',
    //         compact(
    //             'list',
    //             'jtlList',
    //             'jeList'
    //             )
    //         );
    // }
    
    public function index(Request $request)
    {
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;
        $query = DB::table('et_author_biography as ab')
 
    ->leftJoin(
        'et_customer_services as cs',
        'cs.sno',
        '=',
        'ab.service_id'
    )
     ->leftJoin(
        'et_proposal as proposal',
        'proposal.sno',
        '=',
        'cs.proposal_id'
    )
 
    ->leftJoin(
        'et_customer as c',
        'c.sno',
        '=',
        'ab.customer_id'
    )
 
    ->leftJoin(
        'et_product as p',
        'p.sno',
        '=',
        'cs.product_id'
    )
 
    ->leftJoin(
        'et_staff as jtl',
        'jtl.sno',
        '=',
        'ab.jtl_id'
    )
 
    ->leftJoin(
        'et_staff as je',
        'je.sno',
        '=',
        'ab.je_id'
    )
    ->leftJoin(
        'et_staff as ce',
        'ce.sno',
        '=',
        'proposal.collection_id'
    )
    ->leftJoin(
        'et_staff as cre',
        'cre.sno',
        '=',
        'cs.cre_id'
    )
 
    ->select(
        'ab.*',
        'cs.customer_id',
        'cs.sno as service_id',
        'proposal.sno as proposal_id',
        'proposal.proposal_id as formatted_proposal_id',
        'cs.created_at as service_created_at',
        'c.sno as customer_sno',
        'c.customer_id as customer_code',
        'c.cus_name',
        'c.cus_mobile',
        'c.cus_email_id',
        'p.product_name as service_name',
        'jtl.staff_name as jtl_name',
        'jtl.staff_image as jtl_image',
        'je.staff_name as je_name',
        'je.staff_image as je_image',
        'proposal.collection_id',
        'ce.sno as ce_id',
        'ce.staff_name as ce_name',
        'ce.staff_image as ce_image',
        'cre.sno as cre_id',
        'cre.staff_name as cre_name',
        'cre.staff_image as cre_image'
    );
 
        /*
        |--------------------------------------------------------------------------
        | Filters
        |--------------------------------------------------------------------------
        */
 
        if($request->filled('customer_id'))
        {
            $query->where(
                'cs.customer_id',
                'LIKE',
                '%'.$request->customer_id.'%'
            );
        }
 
        if($request->filled('customer_name'))
        {
            $query->where(
                'c.cus_name',
                'LIKE',
                '%'.$request->customer_name.'%'
            );
        }
        if($request->filled('cre_filter'))
        {
            $query->where(
                'cre.sno',$request->cre_filter
            );
        }
         if($request->filled('ce_filter'))
        {
            $query->where(
                'ce.sno',$request->ce_filter
            );
        }
         if($request->filled('jtl_filter'))
        {
            $query->where(
                'jtl.sno',$request->jtl_filter
            );
        }
         if($request->filled('je_filter'))
        {
            $query->where(
                'je.sno',$request->je_filter
            );
        }
        if($request->filled('status'))
        {
            $query->where(
                'ab.production_status',
                $request->status
            );
        }
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'view_self_cus')) {
 
            if ($user_role == 33) {
                $query->where('ab.jtl_id', $user_id);
 
            } elseif ($user_role == 34) {
 
                $query->where('ab.je_id', $user_id);
 
            }elseif ($user_role == 42) {
 
                $query->where('proposal.collection_id', $user_id);
 
            }
        }elseif (!auth()->user()->hasPermissionradio('Journal Management', 'Manage Biography', 'global_cus')) {
            abort(403, 'Unauthorized');
        }
        $list = $query
 
            ->orderByDesc('ab.created_at')
 
            ->paginate(20);
            foreach ($list as $row) {
 
                $row->authors = DB::table('et_author_biography_members')
                    ->where('biography_id', $row->sno)
                    ->pluck('author_name')
                    ->implode(', ');
                 $year = date('Y', strtotime($row->service_created_at));
                $formattedId = str_pad($row->service_id, 5, '0', STR_PAD_LEFT);
                $row->formatted_service_id = "SR-{$formattedId}/{$year}";
            }
    $jtlList = DB::table('et_staff')
        ->whereIn('role_id', [33, 20])
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();
        $jeList = DB::table('et_staff')
        ->where('role_id', 34)
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();
 
     $creList = DB::table('et_staff')
        ->where('role_id', 16)
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();
         $ceList = DB::table('et_staff')
        ->where('role_id', 42)
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();
        // return $list;
        return view(
            'content.journal_management.manage_journal.manage_author_biography',
            compact(
                'list',
                'jtlList',
                'jeList',
                'creList',
                'ceList'
                )
            );
    }
    
    public function assignJTL(Request $request)
    {

        DB::table('et_author_biography')

            ->where('sno',$request->biography_id)

            ->update([

                'jtl_id'=>$request->jtl_id,

                'production_status'=>1,

                'assigned_date'=>now()

            ]);

        return response()->json([

            'status'=>200,

            'message'=>'JTL Assigned Successfully'

        ]);

    }
    public function assignJE(Request $request)
{
    DB::table('et_author_biography')

        ->where('sno', $request->biography_id)

        ->update([

            'je_id' => $request->je_id,

            'production_status' => 2,

            'je_assigned_date' => now()

        ]);

    return response()->json([

        'status' => 200,

        'message' => 'Journal Editor Assigned Successfully'

    ]);
}
public function getProposalJournalServices(Request $request)
{
    $bio = DB::table('et_author_biography')

        ->where('sno',$request->biography_id)

        ->first();

    $proposalId = DB::table('et_customer_services')

        ->where('sno',$bio->service_id)

        ->value('proposal_id');

    $services = DB::table('et_customer_services as cs')

        ->join(
            'et_product as p',
            'p.sno',
            '=',
            'cs.product_id'
        )

        ->where(
            'cs.proposal_id',
            $proposalId
        )

        ->where(
            'p.journal_product',
            1
        )

        ->select(
            'cs.sno',
            'p.product_name'
        )

        ->get();

    return response()->json([

        'services'=>$services

    ]);
}
public function submitUpdatedManuscript(Request $request)
{
    $bio = DB::table('et_author_biography')

        ->where('sno',$request->biography_id)

        ->first();
    // return $request->services;
    if($request->hasFile('manuscript'))
    {

        $file=$request->file('manuscript');

        $name=time().'.'.$file->extension();

        $file->move(
            public_path('updated_manuscripts'),
            $name
        );

        DB::table('et_author_biography')

            ->where(
                'sno',
                $bio->sno
            )

            ->update([

                'updated_manuscript'=>$name,

                'production_status'=>3

            ]);

    }

   DB::transaction(function () use ($bio, $request) {

        // Save selected services in biography
      DB::table('et_author_biography_services')
        ->where('biography_id', $bio->sno)
        ->delete();

        foreach ($request->services as $service) {

            DB::table('et_author_biography_services')->insert([

                'biography_id' => $bio->sno,

                'service_id' => $service,

                'created_at' => now(),

                'updated_at' => now()

            ]);
        }


    });

    return response()->json([

        'status'=>200,

        'message'=>'Updated successfully.'

    ]);
}
public function journalConfirmation($id)
{
    $helper = new \App\Helpers\Helpers();
      $biographyId = $helper->encrypt_decrypt($id, 'decrypt');
    $bio = DB::table('et_author_biography as ab')

        ->leftJoin(
            'et_customer_services as cs',
            'cs.sno',
            '=',
            'ab.service_id'
        )

        ->leftJoin(
            'et_customer as c',
            'c.sno',
            '=',
            'ab.customer_id'
        )
         ->leftJoin(
            'et_proposal as p',
            'cs.proposal_id',
            '=',
            'p.sno'
        )
        ->select(
            'ab.*',
            'cs.customer_id',
            'cs.sno as service_id',
            'cs.created_at as service_created_at',
            'c.customer_id as customer_code',
            'c.cus_name',
            'p.proposal_id as proposal_id'
        )

        ->where('ab.sno',$biographyId)

        ->first();


        $year = date('Y', strtotime($bio->service_created_at));
        $formattedId = str_pad($bio->service_id, 5, '0', STR_PAD_LEFT);
        $bio->formatted_service_id = "SR-{$formattedId}/{$year}";
        
        $serviceIds = DB::table('et_author_biography_services')
            ->where('biography_id', $bio->sno)
            ->pluck('service_id')
            ->toArray();
        $services = DB::table('et_customer_services')

            ->leftJoin(
                'et_product',
                'et_product.sno',
                '=',
                'et_customer_services.product_id'
            )

            ->whereIn(
                'et_customer_services.sno',
                $serviceIds
            )

            ->select(
                'et_customer_services.*',
                'et_product.product_name'
            )

            ->get();
            $selectedServices = DB::table('et_author_biography_services as bs')

            ->join(
                'et_customer_services as cs',
                'cs.sno',
                '=',
                'bs.service_id'
            )

            ->join(
                'et_product as p',
                'p.sno',
                '=',
                'cs.product_id'
            )

            ->where(
                'bs.biography_id',
                $bio->sno
            )

            ->select(
                'cs.sno',
                'cs.customer_id',
                'p.product_name',
                'cs.created_at as service_created_at'
            )

            ->get();
               foreach ($selectedServices as $row) {
                 $year = date('Y', strtotime($row->service_created_at));
                $formattedId = str_pad($row->sno, 5, '0', STR_PAD_LEFT);
                $row->formatted_service_id = "SR-{$formattedId}/{$year}";
            }
            // return $bio;
    return view(
        'content.production_management.manage_deliverables.journal_confirmation',
        compact(
            'bio',
            'services',
            'selectedServices'
        )
    );
}
public function confirmJournalSubmission(Request $request)
{

    $bio = DB::table('et_author_biography')
        ->where('sno',$request->biography_id)
        ->first();

    if ($bio->customer_confirmation == 1) {

        return response()->json([

            'status' => 200,

            'message' => 'Journal requirement already confirmed.'

        ]);

    }

    $services = DB::table('et_author_biography_services')

        ->where('biography_id',$bio->sno)

        ->pluck('service_id');

    DB::table('et_customer_services')

        ->whereIn('sno',$services)

        ->update([
            'jc_id' => $bio->jtl_id,
            'jc_staff' => $bio->je_id,
            'journal_check' => 1
        ]);

    DB::table('et_author_biography')

        ->where('sno',$bio->sno)

        ->update([

            'customer_confirmation' => 1,

            'customer_confirmed_at' => now(),

            'production_status' => 4

        ]);

    return response()->json([

        'status'=>200,

        'message'=>'Journal submission confirmed successfully.'

    ]);

}
}