<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\JournalBookletModel;
use App\Models\ManageJournalModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class JournalReportController extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;

        $search_fill = $request->search_fill ?? '';
        $status_fill = $request->status_fill ?? '';
        $dashboard_filter = $request->dashboard_filter ?? '';
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);

        // Sort parameters
        $sort_by = $request->input('sort_by', 'journal_name');
        $sort_dir = $request->input('sort_dir', 'asc');
        $allowedSortColumns = [
            'journal_name',
            'status_0', 'status_1', 'status_3', 'status_4',
            'status_5', 'status_6', 'status_7', 'status_8', 'status_9'
        ];
        $sortColumn = in_array($sort_by, $allowedSortColumns) ? $sort_by : 'journal_name';
        $sortDirection = strtolower($sort_dir) === 'desc' ? 'desc' : 'asc';

        // Status mapping from workflow
        $statusMap = [
            0 => 'Submitted',
            1 => 'With Editor',
            3 => 'Under Reviewer',
            4 => 'Reviewed / Revision',
            5 => 'Accepted',
            6 => 'Rejected',
            7 => 'E-Proofing',
            8 => 'Published',
            9 => 'Resubmitted',
        ];

        // ===================== MINI DASHBOARD COUNTS (with filters) =====================
        
        // Base booklet query with filters
        $baseBookletQuery = function () use ($branch_id, $search_fill, $status_fill, $dashboard_filter) {
            $query = JournalBookletModel::where('status', 0)
                ->where('branch_id', $branch_id);
            
            // Apply search filter
            if ($search_fill != '') {
                $query->where('journal_name', 'LIKE', "%{$search_fill}%");
            }
            
            // Apply status filter - only booklets with journals in selected status
            if ($status_fill !== '') {
                $query->whereExists(function ($q) use ($branch_id, $status_fill) {
                    $q->select(DB::raw(1))
                        ->from('et_manage_journal')
                        ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                        ->where('et_manage_journal.branch_id', $branch_id)
                        ->where('et_manage_journal.status', $status_fill)
                        ->where('et_manage_journal.status', '!=', 2)
                        ->whereNotNull('et_manage_journal.service_id');
                });
            }
            
            // Apply dashboard filter
            if ($dashboard_filter === 'used') {
                $query->whereExists(function ($q) use ($branch_id) {
                    $q->select(DB::raw(1))
                        ->from('et_manage_journal')
                        ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                        ->where('et_manage_journal.branch_id', $branch_id)
                        ->where('et_manage_journal.status', '!=', 2);
                });
            } elseif ($dashboard_filter === 'unused') {
                $query->whereNotExists(function ($q) use ($branch_id) {
                    $q->select(DB::raw(1))
                        ->from('et_manage_journal')
                        ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                        ->where('et_manage_journal.branch_id', $branch_id)
                        ->where('et_manage_journal.status', '!=', 2);
                });
            }
            
            return $query;
        };

        // Total Booklets (with filters)
        $totalBooklets = $baseBookletQuery()->count();

        // Used Booklets (have at least one linked journal, with filters)
        $usedBooklets = $baseBookletQuery()
            ->whereExists(function ($q) use ($branch_id) {
                $q->select(DB::raw(1))
                    ->from('et_manage_journal')
                    ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                    ->where('et_manage_journal.branch_id', $branch_id)
                    ->where('et_manage_journal.status', '!=', 2);
            })
            ->count();

        // Unused Booklets (no linked journals, with filters)
        $unusedBooklets = $baseBookletQuery()
            ->whereNotExists(function ($q) use ($branch_id) {
                $q->select(DB::raw(1))
                    ->from('et_manage_journal')
                    ->whereRaw('et_manage_journal.booklet_id = et_journal_booklet.sno')
                    ->where('et_manage_journal.branch_id', $branch_id)
                    ->where('et_manage_journal.status', '!=', 2);
            })
            ->count();

        // Total Service-Booklet Pairs (distinct service_id + booklet_id, with filters)
        $serviceBookletPairsQuery = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->whereNotNull('service_id')
            ->whereNotNull('booklet_id');
        
        // Apply search filter to service-booklet pairs
        if ($search_fill != '') {
            $serviceBookletPairsQuery->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                $q->select('sno')->from('et_journal_booklet')
                    ->where('branch_id', $branch_id)
                    ->where('status', 0)
                    ->where('journal_name', 'LIKE', "%{$search_fill}%");
            });
        }
        
        // Apply status filter to service-booklet pairs
        if ($status_fill !== '') {
            $serviceBookletPairsQuery->where('status', $status_fill);
        }
        
        $totalServiceBookletPairs = $serviceBookletPairsQuery
            ->selectRaw('COUNT(DISTINCT CONCAT(service_id, "-", booklet_id)) as total_pairs')
            ->value('total_pairs') ?? 0;

        // ===================== STATUS FILTER COUNTS (for dashboard tiles - distinct services, with search filter) =====================
        $statusCounts = [];
        foreach ($statusMap as $statusId => $statusLabel) {
            $query = DB::table('et_manage_journal')
                ->where('branch_id', $branch_id)
                ->where('status', $statusId)
                ->where('status', '!=', 2)
                ->whereNotNull('service_id')
                ->distinct('service_id');

            // Apply search filter - only count journals for booklets matching search
            if ($search_fill != '') {
                $query->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                    $q->select('sno')->from('et_journal_booklet')
                        ->where('branch_id', $branch_id)
                        ->where('status', 0)
                        ->where('journal_name', 'LIKE', "%{$search_fill}%");
                });
            }

            // Apply permission scoping
            if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
                if ($user_role == 34) {
                    $query->whereIn('service_id', function ($q) use ($user_id) {
                        $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                    });
                } elseif ($user_role == 33) {
                    $query->whereIn('service_id', function ($q) use ($user_id) {
                        $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                    });
                }
            }

            $statusCounts[$statusId] = $query->count('service_id');
        }

        // ===================== MAIN QUERY: Booklet-wise Status Report with Conditional Aggregation =====================
        
        // CTE for permission-scoped journals
        $journalCte = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->whereNotNull('service_id');

        // Apply search filter to CTE
        if ($search_fill != '') {
            $journalCte->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                $q->select('sno')->from('et_journal_booklet')
                    ->where('branch_id', $branch_id)
                    ->where('status', 0)
                    ->where('journal_name', 'LIKE', "%{$search_fill}%");
            });
        }

        // Apply permission scoping to CTE
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) { // JE
                $journalCte->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                });
            } elseif ($user_role == 33) { // JTL
                $journalCte->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                });
            }
        }

        // Main query with conditional aggregation - use subquery to allow HAVING/ORDER BY on aliases
        $bookletsQuery = JournalBookletModel::where('et_journal_booklet.status', 0)
            ->where('et_journal_booklet.branch_id', $branch_id)
            ->leftJoinSub($journalCte, 'filtered_journals', function ($join) {
                $join->on('filtered_journals.booklet_id', '=', 'et_journal_booklet.sno');
            })
            ->select(
                'et_journal_booklet.sno',
                'et_journal_booklet.journal_name',
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 0 THEN filtered_journals.service_id END) as status_0'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 1 THEN filtered_journals.service_id END) as status_1'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 3 THEN filtered_journals.service_id END) as status_3'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 4 THEN filtered_journals.service_id END) as status_4'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 5 THEN filtered_journals.service_id END) as status_5'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 6 THEN filtered_journals.service_id END) as status_6'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 7 THEN filtered_journals.service_id END) as status_7'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 8 THEN filtered_journals.service_id END) as status_8'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 9 THEN filtered_journals.service_id END) as status_9'),
            )
            ->groupBy('et_journal_booklet.sno', 'et_journal_booklet.journal_name');

        // Wrap in subquery to allow HAVING/ORDER BY on aliases
        $bookletsQuery = DB::table(DB::raw("({$bookletsQuery->toSql()}) as booklet_status"))
            ->mergeBindings($bookletsQuery->getQuery());

        // Apply dashboard filter (used/unused) using HAVING on aliases (now allowed in outer query)
        if ($dashboard_filter === 'used') {
            $bookletsQuery->havingRaw(
                'COALESCE(status_0,0) + COALESCE(status_1,0) + COALESCE(status_3,0) + COALESCE(status_4,0) + ' .
                'COALESCE(status_5,0) + COALESCE(status_6,0) + COALESCE(status_7,0) + COALESCE(status_8,0) + COALESCE(status_9,0) > 0'
            );
        } elseif ($dashboard_filter === 'unused') {
            $bookletsQuery->havingRaw(
                'COALESCE(status_0,0) + COALESCE(status_1,0) + COALESCE(status_3,0) + COALESCE(status_4,0) + ' .
                'COALESCE(status_5,0) + COALESCE(status_6,0) + COALESCE(status_7,0) + COALESCE(status_8,0) + COALESCE(status_9,0) = 0'
            );
        }

        // Apply status filter - only show booklets having journals in selected status
        if ($status_fill !== '') {
            $bookletsQuery->having("status_{$status_fill}", '>', 0);
        }

        // Sort with NULLS LAST for status columns
        if ($sortColumn === 'journal_name') {
            $bookletsQuery->orderBy('journal_name', $sortDirection);
        } else {
            $bookletsQuery->orderByRaw("{$sortColumn} IS NULL, {$sortColumn} {$sortDirection}");
        }

        $booklets = $bookletsQuery->paginate($perpage);

        // Build bookletStatusData from query results for backward compatibility with view
        $bookletStatusData = [];
        foreach ($booklets as $booklet) {
            foreach ($statusMap as $statusId => $statusLabel) {
                $colName = "status_{$statusId}";
                $bookletStatusData[$booklet->sno][$statusId] = $booklet->$colName ?? 0;
            }
        }

        return view('content.journal_management.journal_reports.list', compact(
            'booklets',
            'bookletStatusData',
            'statusMap',
            'totalBooklets',
            'usedBooklets',
            'unusedBooklets',
            'totalServiceBookletPairs',
            'statusCounts',
            'search_fill',
            'status_fill',
            'dashboard_filter',
            'perpage',
            'sort_by',
            'sort_dir',
            'allowedSortColumns'
        ));
    }

    public function export(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user_role = $request->user()->role_id;

        $search_fill = $request->search_fill ?? '';
        $status_fill = $request->status_fill ?? '';
        $dashboard_filter = $request->dashboard_filter ?? '';
        $sort_by = $request->input('sort_by', 'journal_name');
        $sort_dir = $request->input('sort_dir', 'asc');
        $allowedSortColumns = [
            'journal_name',
            'status_0', 'status_1', 'status_3', 'status_4',
            'status_5', 'status_6', 'status_7', 'status_8', 'status_9'
        ];
        $sortColumn = in_array($sort_by, $allowedSortColumns) ? $sort_by : 'journal_name';
        $sortDirection = strtolower($sort_dir) === 'desc' ? 'desc' : 'asc';

        // Check permission
        if (!auth()->user()->hasPermission('Journal Management', 'Export', 'Journal Reports')) {
            abort(403, 'Unauthorized');
        }

        // Status mapping from workflow
        $statusMap = [
            0 => 'Submitted',
            1 => 'With Editor',
            3 => 'Under Reviewer',
            4 => 'Reviewed / Revision',
            5 => 'Accepted',
            6 => 'Rejected',
            7 => 'E-Proofing',
            8 => 'Published',
            9 => 'Resubmitted',
        ];

        // CTE for permission-scoped journals
        $journalCte = DB::table('et_manage_journal')
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->whereNotNull('service_id');

        // Apply search filter to CTE
        if ($search_fill != '') {
            $journalCte->whereIn('booklet_id', function ($q) use ($branch_id, $search_fill) {
                $q->select('sno')->from('et_journal_booklet')
                    ->where('branch_id', $branch_id)
                    ->where('status', 0)
                    ->where('journal_name', 'LIKE', "%{$search_fill}%");
            });
        }

        // Apply permission scoping to CTE
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Journal', 'view_self_cus')) {
            if ($user_role == 34) { // JE
                $journalCte->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_staff', $user_id);
                });
            } elseif ($user_role == 33) { // JTL
                $journalCte->whereIn('service_id', function ($q) use ($user_id) {
                    $q->select('sno')->from('et_customer_services')->where('jc_id', $user_id);
                });
            }
        }

        // Main query with conditional aggregation
        $bookletsQuery = JournalBookletModel::where('et_journal_booklet.status', 0)
            ->where('et_journal_booklet.branch_id', $branch_id)
            ->leftJoinSub($journalCte, 'filtered_journals', function ($join) {
                $join->on('filtered_journals.booklet_id', '=', 'et_journal_booklet.sno');
            })
            ->select(
                'et_journal_booklet.sno',
                'et_journal_booklet.journal_name',
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 0 THEN filtered_journals.service_id END) as status_0'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 1 THEN filtered_journals.service_id END) as status_1'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 3 THEN filtered_journals.service_id END) as status_3'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 4 THEN filtered_journals.service_id END) as status_4'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 5 THEN filtered_journals.service_id END) as status_5'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 6 THEN filtered_journals.service_id END) as status_6'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 7 THEN filtered_journals.service_id END) as status_7'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 8 THEN filtered_journals.service_id END) as status_8'),
                DB::raw('COUNT(DISTINCT CASE WHEN filtered_journals.status = 9 THEN filtered_journals.service_id END) as status_9'),
            )
            ->groupBy('et_journal_booklet.sno', 'et_journal_booklet.journal_name');

        // Wrap in subquery to allow HAVING/ORDER BY on aliases
        $bookletsQuery = DB::table(DB::raw("({$bookletsQuery->toSql()}) as booklet_status"))
            ->mergeBindings($bookletsQuery->getQuery());

        // Apply dashboard filter
        if ($dashboard_filter === 'used') {
            $bookletsQuery->havingRaw(
                'COALESCE(status_0,0) + COALESCE(status_1,0) + COALESCE(status_3,0) + COALESCE(status_4,0) + ' .
                'COALESCE(status_5,0) + COALESCE(status_6,0) + COALESCE(status_7,0) + COALESCE(status_8,0) + COALESCE(status_9,0) > 0'
            );
        } elseif ($dashboard_filter === 'unused') {
            $bookletsQuery->havingRaw(
                'COALESCE(status_0,0) + COALESCE(status_1,0) + COALESCE(status_3,0) + COALESCE(status_4,0) + ' .
                'COALESCE(status_5,0) + COALESCE(status_6,0) + COALESCE(status_7,0) + COALESCE(status_8,0) + COALESCE(status_9,0) = 0'
            );
        }

        // Apply status filter
        if ($status_fill !== '') {
            $bookletsQuery->having("status_{$status_fill}", '>', 0);
        }

        // Sort with NULLS LAST
        if ($sortColumn === 'journal_name') {
            $bookletsQuery->orderBy('journal_name', $sortDirection);
        } else {
            $bookletsQuery->orderByRaw("{$sortColumn} IS NULL, {$sortColumn} {$sortDirection}");
        }

        $booklets = $bookletsQuery->get();

        // Build bookletStatusData for export
        $bookletStatusData = [];
        foreach ($booklets as $booklet) {
            foreach ($statusMap as $statusId => $statusLabel) {
                $colName = "status_{$statusId}";
                $bookletStatusData[$booklet->sno][$statusId] = $booklet->$colName ?? 0;
            }
        }

        // Generate CSV
        $filename = 'journal_reports_' . date('Y-m-d_H-i-s') . '.csv';
        
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function() use ($booklets, $bookletStatusData, $statusMap) {
            $file = fopen('php://output', 'w');
            
            // Header row
            $headerRow = ['Booklet Name'];
            foreach ($statusMap as $statusLabel) {
                $headerRow[] = $statusLabel;
            }
            fputcsv($file, $headerRow);

            // Data rows
            foreach ($booklets as $booklet) {
                $row = [$booklet->journal_name];
                foreach ($statusMap as $statusId => $statusLabel) {
                    $count = $bookletStatusData[$booklet->sno][$statusId] ?? 0;
                    $row[] = $count;
                }
                fputcsv($file, $row);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }
}