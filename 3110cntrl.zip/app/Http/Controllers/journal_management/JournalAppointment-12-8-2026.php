<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\AppointmentModeModel;
use App\Models\ConnectingWayModel;
use App\Models\CustomerModel;
use App\Models\ManageAppointmentsModel;
use App\Models\JournalAppointmentModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class JournalAppointment extends Controller
{
    // public function index(Request $request)
    // {

    //     $branch_id = $request->user()->branch_id;
    //     $user_id = $request->user()->user_id;
    //     $user = auth()->user();

    //     // Filter
    //     $page = $request->input('page', 1);
    //     $perpage = (int) $request->input('sorting_filter', 25);
    //     $offset = ($page - 1) * $perpage;
    //     $pageConfigs = ['myLayout' => 'default'];

    //     // Data Fetching Variables
    //     $query = JournalAppointmentModel::where('et_journal_appointments.status', '!=', 2)
    //     ->select(
    //         'et_journal_appointments.*',

    //         'et_customer.cus_name',

    //         'et_customer.customer_id',

    //         'et_product.product_name',

    //         'et_manage_journal.paper_name',

    //         'et_manage_journal.journal_id',

    //         'normal_staff.staff_name as normal_staff_name',

    //         'pc_staff.staff_name as pc_staff_name',

    //         'et_connecting_way.connecting_way_name as con_name',

    //         'et_appointment_mode.appointment_mode_name'
    //     )

    //     ->leftJoin(
    //         'et_customer',
    //         'et_customer.sno',
    //         '=',
    //         'et_journal_appointments.customer_id'
    //     )

    //     ->leftJoin(
    //         'et_customer_services',
    //         'et_customer_services.sno',
    //         '=',
    //         'et_journal_appointments.service_id'
    //     )
    //     ->leftJoin(
    //         'et_product',
    //         'et_customer_services.product_id',
    //         '=',
    //         'et_product.sno'
    //     )

    //     ->leftJoin(
    //         'et_manage_journal',
    //         'et_manage_journal.sno',
    //         '=',
    //         'et_journal_appointments.journal_id'
    //     )

    //     ->leftJoin(
    //         'et_connecting_way',
    //         'et_connecting_way.sno',
    //         '=',
    //         'et_journal_appointments.connecting_way_id'
    //     )

    //     ->leftJoin(
    //         'et_appointment_mode',
    //         'et_appointment_mode.sno',
    //         '=',
    //         'et_journal_appointments.appointment_mode_id'
    //     )

    //     ->leftJoin(
    //         'et_staff as normal_staff',
    //         'normal_staff.sno',
    //         '=',
    //         'et_journal_appointments.staff_id'
    //     )

    //     ->leftJoin(
    //         'et_staff as pc_staff',
    //         'pc_staff.sno',
    //         '=',
    //         'et_journal_appointments.pc_id'
    //     );
    //     // Returning View

    //     $search_fill = $request->search_fill ?? '';

    //     if (! empty($search_fill)) {
    //         $query->where(function ($q) use ($search_fill) {

    //           $columns = [
    //             'et_customer.cus_name',
    //             'et_customer.customer_id',

    //             'et_customer_services.service_name',

    //             'et_journal.journal_name',

    //             'et_journal.journal_id',

    //             'et_connecting_way.connecting_way_name',

    //             'et_appointment_mode.appointment_mode_name',

    //             'normal_staff.staff_name',

    //             'pc_staff.staff_name',
    //         ];

    //             foreach ($columns as $column) {
    //                 $q->orWhere($column, 'LIKE', "%{$search_fill}%");
    //             }
    //         });
    //     }

    //     if ($user->role_id == 16) {
    //         if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Appointments', 'view_self_cus')) {
    //             $query = $query->where('et_journal_appointments.created_by', $user_id);
    //         } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Customer Appointment', 'global_cus')) {
    //             $query = $query;
    //         } else {
    //             abort(403, 'Unauthorized');
    //         }
    //     } else {
    //         if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Appointments', 'view_self_cus')) {
    //             $query = $query->where('et_journal_appointments.staff_id', $user_id);
    //         } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Appointments', 'global_cus')) {
    //             $query = $query;
    //         } else {
    //             abort(403, 'Unauthorized');
    //         }
    //     }

    //     $appointments = $query
    //         ->where('et_journal_appointments.branch_id', $branch_id)
    //         ->orderBy('et_journal_appointments.sno', 'desc')
    //         ->paginate($perpage);

    //     $customers = CustomerModel::select('sno', 'cus_name', 'customer_id')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->get();
    //     $apps = AppointmentModeModel::select('sno', 'appointment_mode_name')->where('status', 0)->get();
    //     $staffs = StaffModel::select('sno', 'staff_name')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->where('role_id', '=', 15)->get();
    //     $ways = ConnectingWayModel::select('sno', 'connecting_way_name', 'url_link')->where('status', 0)->get();
    //     $je_list= DB::table('et_staff')
    //         ->where('role_id',34)
    //          ->where('status', 0)
    //         ->select('sno','staff_name')
    //         ->orderBy('staff_name')
    //         ->get();
    //         // return $appointments;
    //         return view('content.journal_management.manage_appointment.journal_appointments', compact(
    //             'customers',
    //             'appointments',
    //             'apps',
    //             'ways',
    //             'staffs',
    //             'perpage',
    //             'pageConfigs',
    //             'search_fill',
    //             'je_list'
    //         ));
     

    // }
    
    public function index(Request $request)
    {

 

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user = auth()->user();

 

        // Filter
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $pageConfigs = ['myLayout' => 'default'];

 

        // Data Fetching Variables
        $query = JournalAppointmentModel::where('et_journal_appointments.status', '!=', 2)
        ->select(
            'et_journal_appointments.*',

 

            'et_customer.cus_name',

 

            'et_customer.customer_id',

 

            'et_product.product_name',

 

            'et_manage_journal.paper_name',

 

            'et_manage_journal.journal_id',

 

            'normal_staff.staff_name as normal_staff_name',

 

            'pc_staff.staff_name as pc_staff_name',

 

            'et_connecting_way.connecting_way_name as con_name',

 

            'et_appointment_mode.appointment_mode_name'
        )

 

        ->leftJoin(
            'et_customer',
            'et_customer.sno',
            '=',
            'et_journal_appointments.customer_id'
        )

 

        ->leftJoin(
            'et_customer_services',
            'et_customer_services.sno',
            '=',
            'et_journal_appointments.service_id'
        )
        ->leftJoin(
            'et_product',
            'et_customer_services.product_id',
            '=',
            'et_product.sno'
        )

 

        ->leftJoin(
            'et_manage_journal',
            'et_manage_journal.sno',
            '=',
            'et_journal_appointments.journal_id'
        )

 

        ->leftJoin(
            'et_connecting_way',
            'et_connecting_way.sno',
            '=',
            'et_journal_appointments.connecting_way_id'
        )

 

        ->leftJoin(
            'et_appointment_mode',
            'et_appointment_mode.sno',
            '=',
            'et_journal_appointments.appointment_mode_id'
        )

 

        ->leftJoin(
            'et_staff as normal_staff',
            'normal_staff.sno',
            '=',
            'et_journal_appointments.staff_id'
        )

 

        ->leftJoin(
            'et_staff as pc_staff',
            'pc_staff.sno',
            '=',
            'et_journal_appointments.pc_id'
        );
        // Returning View

 

        $search_fill = $request->search_fill ?? '';

 

        if (! empty($search_fill)) {
            $query->where(function ($q) use ($search_fill) {

 

               $columns = [
                'et_customer.cus_name',
                'et_customer.customer_id',

 

                'et_customer_services.service_name',

 

                'et_journal.journal_name',

 

                'et_journal.journal_id',

 

                'et_connecting_way.connecting_way_name',

 

                'et_appointment_mode.appointment_mode_name',

 

                'normal_staff.staff_name',

 

                'pc_staff.staff_name',
            ];

 

                foreach ($columns as $column) {
                    $q->orWhere($column, 'LIKE', "%{$search_fill}%");
                }
            });
        }

 

         if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Appointments', 'view_self_cus')) {
             if ($user->role_id == 16) {
                $query = $query->where('et_journal_appointments.created_by', $user_id);
             }else if($user->role_id == 34){
                 $query = $query->where('et_journal_appointments.staff_id', $user_id);
             }
            } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Appointments', 'global_cus')) {
                // $query = $query;
            } else {
                abort(403, 'Unauthorized');
            }

 

        $appointments = $query
            ->where('et_journal_appointments.branch_id', $branch_id)
            ->orderBy('et_journal_appointments.sno', 'desc')
            ->paginate($perpage);

 

        $customers = CustomerModel::select('sno', 'cus_name', 'customer_id')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->get();
        $apps = AppointmentModeModel::select('sno', 'appointment_mode_name')->where('status', 0)->get();
        $staffs = StaffModel::select('sno', 'staff_name')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->where('role_id', '=', 15)->get();
        $ways = ConnectingWayModel::select('sno', 'connecting_way_name', 'url_link')->where('status', 0)->get();
        $je_list= DB::table('et_staff')
            ->where('role_id',34)
             ->where('status', 0)
            ->select('sno','staff_name')
            ->orderBy('staff_name')
            ->get();
            // return $appointments;
            return view('content.journal_management.manage_appointment.journal_appointments', compact(
                'customers',
                'appointments',
                'apps',
                'ways',
                'staffs',
                'perpage',
                'pageConfigs',
                'search_fill',
                'je_list'
            ));

 

    }


   public function getServices(Request $request)
{
    $customer_id = $request->customer_id;

    $services = DB::table('et_customer_services')
        ->where('et_customer_services.customer_id', $customer_id)
        ->where('et_customer_services.status', '!=', 2)
        ->leftJoin(
            'et_product',
            'et_customer_services.product_id',
            '=',
            'et_product.sno'
        )
        ->orderBy('service_name')
        ->get([
            'et_customer_services.sno',
            'et_product.product_name as service_name'
        ]);

    return response()->json($services);
}
public function getJournals(Request $request)
{
    $service_id = $request->service_id;

    $journals = DB::table('et_manage_journal')
        ->where('service_id', $service_id)
        ->where('status', '!=', 2)
        ->orderBy('paper_name')
        ->get([
            'sno',
            'paper_name',
            'paper_name as journal_name'
        ]);

    return response()->json($journals);
}
    public function ConnectingURL($id)
    {
        $way = ConnectingWayModel::where('sno', $id)->where('status', 0)->first();

        if (! $way) {
            return response()->json([
                'status' => 404,
                'message' => 'Connecting Way Not Found',
            ]);
        }

        return response()->json([
            'url_link' => $way->url_link,
        ]);
    }

    public function cre_customer(Request $request)
    {

        $id = $request->user()->user_id;
        $role_id = $request->user()->role_id;
        $data = [];
        // if($role_id == 16) {
        //     $data = DB::table('et_proposal')
        //         ->select(
        //             'et_customer.sno',
        //             'et_customer.cus_name',
        //             'et_customer.customer_id'
        //         )
        //         ->leftJoin('et_customer', 'et_customer.lead_id', '=', 'et_proposal.lead_id')
        //         ->where('et_proposal.cre_id', $id)
        //         ->where('et_customer.status', 0)
        //         ->whereNotIn('et_customer.post_sale_check', [1])
        //         ->whereNotIn('et_proposal.proposal_status', [0, 2])
        //         ->get();
        // } elseif($role_id == 35) {
        $data = DB::table('et_customer')
            ->select(
                'et_customer.sno',
                'et_customer.cus_name',
                'et_customer.customer_id'
            )
            ->where('et_customer.status', 0)
            // ->where('et_customer.post_sale_check', 1)
            ->get();
        // }

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        }
    }

    public function staff_list()
    {
        $data = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_job_position.job_position_name'
            )
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.role_id', 34)
            ->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        }
    }

  public function Create(Request $request)
{
    $request->validate([
        'customer_id'         => 'required|integer',
        'service_id'          => 'required|integer',
        'journal_id'          => 'required|integer',
        'appointment_date'    => 'required',
        'appointment_mode_id' => 'required|integer',
        'staff_id'            => 'required|integer',
        'appointment_reason'  => 'required|string',
    ]);

    try {

        $user = $request->user();

        $appointment = new JournalAppointmentModel();

        $appointment->customer_id          = $request->customer_id;
        $appointment->service_id           = $request->service_id;
        $appointment->journal_id           = $request->journal_id;

        $appointment->appointment_date     = date(
            'Y-m-d H:i:s',
            strtotime($request->appointment_date)
        );

        $appointment->appointment_mode_id  = $request->appointment_mode_id;
        $appointment->connecting_way_id    = $request->connecting_way_id;
        $appointment->connecting_link      = $request->connectingLink;

        // Since this is Journal Appointment, assigning JE
        $appointment->staff_id             = $request->staff_id;

        // Optional
        $appointment->pc_id                = $user->user_id;

        $appointment->appointment_reason   = $request->appointment_reason;
        $appointment->appointment_desc     = $request->appointment_desc;

        $appointment->status               = 0;

        $appointment->branch_id            = $user->branch_id;
        $appointment->created_by           = $user->user_id;
        $appointment->updated_by           = $user->user_id;

        $appointment->save();

        return response()->json([
            'status'  => true,
            'message' => 'Journal Appointment created successfully.'
        ]);

    } catch (\Exception $e) {

        return response()->json([
            'status'  => false,
            'message' => $e->getMessage()
        ], 500);

    }
}
    public function CreatePost(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'appointment_reason' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        $dt = Carbon::createFromFormat('Y-m-d h:i A', $request->appointment_date);

        $create = new ManageAppointmentsModel();
        $create->appointment_date = $dt->format('Y-m-d H:i:s');
        $create->is_post_sale = 1;
        $create->customer_id = $request->customer_id;
        $create->appointment_mode_id = $request->appointment_mode_id;
        $create->pc_id = $request->pc_id;
        $create->appointment_reason = $request->appointment_reason;
        $create->appointment_desc = $request->appointment_desc;
        $create->connecting_way_id = $request->connecting_way_id;
        $create->connecting_link = $request->connectingLink;
        $create->branch_id = $branch_id;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Customer Appointment Created Successfully !',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Customer Appointment Creation Failed !',
            ]);
        }

        return redirect()->back();
    }

    public function view($id)
    {
        $data = JournalAppointmentModel::where('et_journal_appointments.status', '!=', 2)
            ->select(
                'et_journal_appointments.*',
                'et_customer.cus_name as name',
                'et_customer.customer_id as id',
                'et_customer.cus_mobile',
                'et_connecting_way.connecting_way_name as con_name',
                'et_appointment_mode.appointment_mode_name',
                'et_staff.staff_image', 'et_staff.staff_name',
                'et_staff.nick_name',
                'et_staff.gender')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_appointments.customer_id')
            ->leftJoin('et_connecting_way', 'et_connecting_way.sno', '=', 'et_journal_appointments.connecting_way_id')
            ->leftJoin('et_appointment_mode', 'et_appointment_mode.sno', '=', 'et_journal_appointments.appointment_mode_id')
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_journal_appointments.staff_id')
            ->orderBy('sno', 'desc')->where('et_journal_appointments.sno', $id)->first();

        if (! $data) {
            return response([
                'status' => 404,
                'message' => 'Appointments Not Found !',
                'error_msg' => 'No Appointments in the given Id !',
                'data' => null,
            ], 404);
        }

        $uploadedFiles = [];
        if (! empty($data->other_attachments)) {
            $uploadedFiles = json_decode($data->other_attachments, true);
            if (! is_array($uploadedFiles)) {
                $uploadedFiles = [];
            }
        }

        $responseData = $data->toArray();
        $responseData['uploaded_files'] = $uploadedFiles;

        return response([
            'status' => 200,
            'message' => 'Appointment Fetched Successfully !',
            'error_msg' => null,
            'data' => $responseData,
        ], 200);
    }

    public function edit($id)
    {

        $data = JournalAppointmentModel::where('status', '!=', 2)->where('sno', $id)->first();

        if (! $data) {
            return response([
                'status' => 404,
                'message' => 'Appointments Not Found !',
                'error_msg' => 'No Appointments in the given Id !',
                'data' => null,
            ], 404);
        }

        return response([
            'status' => 200,
            'message' => 'Appointment Fetched Successfully !',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function editConnectingURL($id)
    {
        $way = ConnectingWayModel::where('sno', $id)->where('status', '!=', 2)->first();

        if (! $way) {
            return response()->json([
                'status' => 404,
                'message' => 'Connecting Way Not Found',
            ]);
        }

        return response()->json([
            'url_link' => $way->url_link,
        ]);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_reason' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        }
        $sno = $request->edit_id;
        $user_id = $request->user()->user_id;
        $dt = Carbon::createFromFormat('Y-m-d h:i A', $request->edit_appointment_date);

        $Update = JournalAppointmentModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $Update->appointment_date = $dt->format('Y-m-d H:i:s');
        $Update->customer_id = $request->edit_customer_name;
        $Update->appointment_mode_id = $request->edit_appointment_id;
        $Update->connecting_way_id = $request->edit_connecting_way_id;
        $Update->staff_id = $request->edit_staff_id;
        $Update->appointment_reason = $request->edit_reason;
        $Update->appointment_desc = $request->edit_desc;
        $Update->connecting_link = $request->edit_connectingLink ?? null;
        $Update->updated_by = $user_id;
        $Update->update();

        if ($Update) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Customer Appointment Updated Successfully !',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Customer Appointment Updation Failed !',
            ]);
        }

        return redirect()->back();
    }

    public function getAppointmentDetails($id)
    {
        $data = JournalAppointmentModel::where('et_journal_appointments.status', '!=', 2)
            ->select(
                'et_journal_appointments.*',
                'et_customer.cus_name as name',
                'et_customer.customer_id as id',
                'et_customer.cus_mobile',
                'et_connecting_way.connecting_way_name as con_name',
                'et_appointment_mode.appointment_mode_name',
                'et_staff.staff_image',
                'et_staff.staff_name',
                'et_staff.nick_name',
                'et_staff.gender'
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_appointments.customer_id')
            ->leftJoin('et_connecting_way', 'et_connecting_way.sno', '=', 'et_journal_appointments.connecting_way_id')
            ->leftJoin('et_appointment_mode', 'et_appointment_mode.sno', '=', 'et_journal_appointments.appointment_mode_id')
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_journal_appointments.staff_id')
            ->orderBy('sno', 'desc')->where('et_journal_appointments.sno', $id)->first();

        if (! $data) {
            return response([
                'status' => 404,
                'message' => 'Appointments Not Found !',
                'error_msg' => 'No Appointments in the given Id !',
                'data' => null,
            ], 404);
        }

        return response([
            'status' => 200,
            'message' => 'Appointment Cancelled Successfully !',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function cancellAppointment(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'appointment_cancel' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format.',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        }

        $alter = JournalAppointmentModel::where('sno', $id)->where('status', '!=', 2)->first();

        if (! $alter) {
            return response([
                'status' => 404,
                'message' => 'Appointment not found!',
                'data' => null,
            ], 404);
        }
        $alter->appointment_cancel_reason = $request->appointment_cancel;
        $alter->status = 3;
        $alter->save();

        if ($alter) {
            return response([
                'status' => 200,
                'message' => 'Status Updated Successfully !',
                'error_msg' => 'Status Updation Failed !',
                'data' => null,
            ], 200);
        }

    }

    public function rescheduleAppointment($id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'appointment_reschedule_reason' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ]);
        }

        $alter = JournalAppointmentModel::where('sno', $id)->where('status', '!=', 2)->first();

        if (! $alter) {
            return response([
                'status' => 401,
                'message' => 'Appointment Not Found!',
                'error_msg' => null,
                'data' => null,
            ], 401);
        }

        $dt = Carbon::createFromFormat('Y-m-d h:i A', $request->appointment_reschedule_date);

        $alter->status = 4;
        $alter->reschedule_reason = $request->appointment_reschedule_reason;
        $alter->reschedule_date = $dt->format('Y-m-d H:i:s');
        $alter->save();

        // Creating new records
        $newAppointment = $alter->replicate();
        $newAppointment->status = 0;
        $newAppointment->appointment_date = $dt->format('Y-m-d H:i:s');
        $newAppointment->reschedule_reason = null;
        $newAppointment->reschedule_date = null;
        $newAppointment->appointment_cancel_reason = null;
        $newAppointment->other_attachments = null;
        $newAppointment->appointment_summary = null;
        $newAppointment->save();

        if ($alter) {
            return response([
                'status' => 200,
                'message' => 'Status Updated Successfully !',
                'error_msg' => 'Status Updation Failed !',
                'data' => null,
            ], 200);
        }
    }

    public function completeAppointment(Request $request)
    {
        $request->validate([
            'summary' => 'required|string',
            'uploaded_files' => 'nullable|string',
        ]);

        $appointment = JournalAppointmentModel::where('sno', $request->completed_id)
            ->where('status', '!=', 2)
            ->first();

        if (! $appointment) {
            return redirect()->back()->with('toastr', [
                'type' => 'error',
                'message' => 'Something Wents Wrong !',
            ]);
        }

        $appointment->appointment_summary = $request->summary;
        $appointment->status = 1; // Mark as completed
        $appointment->save();

        if ($request->filled('uploaded_files')) {
            $files = json_decode($request->uploaded_files, true);
        }

        if ($request->filled('uploaded_files')) {
            $files = json_decode($request->uploaded_files, true);
            // Assuming $appointment has a column `uploaded_files` as JSON
            $appointment->other_attachments = json_encode($files);
            $appointment->save();
        }

        return redirect()->back()->with('toastr', [
            'type' => 'success',
            'message' => 'Appointment Completed Successfully !',
        ]);
    }

    // Controller for AJAX file upload
    public function uploadFiles(Request $request)
    {
        $request->validate([
            'file_upload.*' => 'required|file|max:10240', // max 10MB
        ]);

        $uploaded = [];

        foreach ($request->file('file_upload') as $file) {
            $fileName = uniqid().'_'.$file->getClientOriginalName();
            $file->move(public_path('appointments'), $fileName);
            $uploaded[] = $fileName;
        }

        return response()->json([
            'success' => true,
            'files' => $uploaded,
        ]);
    }

    public function production_customer_appointment(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        // Filter
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $pageConfigs = ['myLayout' => 'default'];

        $fill_chk = $request->fill_chk ?? 0;
        if ($fill_chk == 1) {
            $fill = true;
        } else {
            $fill = false;
        }

        // Data Fetching Variables
        $query = ManageAppointmentsModel::where('et_manage_appointments.status', '!=', 2)
            ->select('et_manage_appointments.*', 'et_customer.cus_name as name', 'et_customer.customer_id as id', 'et_connecting_way.connecting_way_name as con_name', 'et_appointment_mode.appointment_mode_name', 'normal_staff.staff_name as normal_staff_name', 'pc_staff.staff_name as pc_staff_name')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_appointments.customer_id')
            ->leftJoin('et_connecting_way', 'et_connecting_way.sno', '=', 'et_manage_appointments.connecting_way_id')
            ->leftJoin('et_appointment_mode', 'et_appointment_mode.sno', '=', 'et_manage_appointments.appointment_mode_id')
            ->leftJoin('et_staff as normal_staff', 'normal_staff.sno', '=', 'et_manage_appointments.staff_id')
            ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_manage_appointments.pc_id');
        // Returning View

        $customer_type_fill = $request->customer_type_fill ?? '';
        if ($customer_type_fill) {
            $query->where('et_manage_appointments.customer_id', 'LIKE', "%$customer_type_fill%");
        }

        $appointment_type_fill = $request->appointment_type_fill ?? '';
        if ($appointment_type_fill) {
            $query->where('et_manage_appointments.appointment_mode_id', $appointment_type_fill);
        }

        $connecting_type_fill = $request->connecting_type_fill ?? '';
        if ($connecting_type_fill) {
            $query->where('et_manage_appointments.connecting_way_id', $connecting_type_fill);
        }

        $staff_type_fill = $request->staff_type_fill ?? '';
        if ($staff_type_fill) {
            $query->where('et_manage_appointments.staff_id', $staff_type_fill);
        }

        $appointments = $query->where('et_manage_appointments.branch_id', $branch_id)->orderBy('et_manage_appointments.sno', 'desc')->paginate($perpage);

        $customers = CustomerModel::select('sno', 'cus_name', 'customer_id')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->get();
        $apps = AppointmentModeModel::select('sno', 'appointment_mode_name')->where('status', 0)->get();
        $staffs = StaffModel::select('sno', 'staff_name')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->where('role_id', '=', 15)->get();
        $ways = ConnectingWayModel::select('sno', 'connecting_way_name', 'url_link')->where('status', 0)->get();

        return view('content.production_management.production_appointment.customer_appointment', compact(
            'customers',
            'appointments',
            'apps',
            'ways',
            'staffs',
            'perpage',
            'pageConfigs',
            'customer_type_fill',
            'appointment_type_fill',
            'connecting_type_fill',
            'staff_type_fill'
        ))->with('filter_on', $fill);
    }

    public function pc_staff_assign(Request $request)
    {
        // return $request;
        $sno = $request->staff_appt_id;
        $staff_id = $request->assign_staff_id;

        $staff_assign = ManageAppointmentsModel::where('sno', $sno)->first();
        $staff_assign->staff_id = $request->assign_staff_id;
        $staff_assign->update();

        if ($staff_assign) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Staff Assigned Successfully!',
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Assigning Staff Failed!',
            ]);

            return redirect()->back();
        }
    }

    public function fetchAppointmentMode()
    {
        $data = DB::table('et_appointment_mode')
            ->select('appointment_mode_name', 'sno')
            ->where('status', 0)
            ->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function fetchConnectingWay()
    {
        $data = DB::table('et_connecting_way')
            ->select('connecting_way_name', 'sno', 'url_link')
            ->where('status', 0)
            ->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function fetchAssignStaff()
    {
        $data = DB::table('et_staff')
            ->select('et_staff.staff_name', 'et_staff.sno', 'et_job_position.job_position_name')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.department_id', 2)
            ->where('et_staff.status', 0)
            ->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }
}
