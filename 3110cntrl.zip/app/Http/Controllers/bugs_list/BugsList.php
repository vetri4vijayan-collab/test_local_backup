<?php

namespace App\Http\Controllers\bugs_list;

use App\Http\Controllers\Controller;
use App\Models\BugsListModel;
use App\Models\BugsListHistoryModel;
use App\Models\ModulesListModel;
use App\Models\BugReasonsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class BugsList extends Controller
{

    public static $bug_types_list = [
        1 => 'Bug',
        2 => 'New',
        3 => 'Modification'
    ];

    public static $bug_priority_list = [
        1 => 'Low',
        2 => 'Normal',
        3 => 'High',
        4 => 'Emergency'
    ];

    public static $bug_status_list = [
        1 => 'In Progress',
        2 => 'Staff Not Assigned',
        3 => 'Completed (OR) Verification Pending',
        4 => 'Delayed',
        5 => 'Drop',
        6 => 'Hold',
        // 7 => 'In Progress'
    ];

    public function index(Request $request)
    {

        $perpage = (int) $request->input('sorting_filter', 25);
        
        $pageConfigs = [
            'myLayout' => 'default'
        ];
        
        // return self::$bug_types_list;

        $role_id = $request->user()->role_id;

        if(auth()->user()->hasPermission('Dashboard', 'Bug Fixes', null)){
            return view('content.bugs_list.list', [
                'pageConfigs' => $pageConfigs,
                'bug_types_list' => self::$bug_types_list,
                'bug_priority_list' => self::$bug_priority_list,
                'bug_status_list' => self::$bug_status_list,
                'perpage' => $perpage
            ]);
        }else{
            return view('content.bugs_list.unauth_list');
        }
    }

    public function get_bugs_list(Request $request)
    {

        $helper     = new \App\Helpers\Helpers();
        $page     = (int) $request->input('page', 1);
        $perpage  = (int) $request->input('sorting_filter', 25);
        $bug_type_fill  = $request->input('bug_type_fill', '');
        $bug_status_fill  = $request->input('bug_status_fill', '');
        $bug_priority_fill  = $request->input('bug_priority_fill', '');
        $rating_value  = $request->input('rating_value', '');
        $dt_fill_issue_rpt         = $request->input('dt_fill_issue_rpt', '');
        $from_date                 = $request->input('dt_fill_issue_rpt_from', '');
        $to_date                   = $request->input('dt_fill_issue_rpt_to', '');

        // return $bug_status_fill;

        $user = $request->user();
        $branch_id = $user->branch_id ?? null;

        $query = BugsListModel::select(
            'sno',
            'branch_id',
            'module_id',
            'module_name',

            'bug_title',
            'bug_description',

            'bug_type',
            'priority',
            'bug_status',

            'assigned_to',
            'assign_staff_details',

            'start_date',
            'expected_date',

            'completed_date',
            'completed_by',
            'completed_by_details',
            'completed_description',
            'completed_url',

            'hold_start_date',
            'hold_end_date',

            'hold_duration_hours',
            'hold_duration_days',

            'hold_reason_id',
            'hold_reason',
            'hold_others_reason',

            'drop_reason_id',
            'drop_reason',
            'drop_others_reason',

            'remarks',

            'attachments',

            'status',

            'created_by',
            'updated_by',

            'created_at',
            'updated_at'

        )
        ->where('status', '!=', 2)
        ->where('branch_id', $branch_id);

        if (!empty($bug_type_fill)) {
            $query->whereIn('et_bugs_list.bug_type', $bug_type_fill);
        }

        if (!empty($bug_priority_fill)) {
            $query->whereIn('et_bugs_list.priority', $bug_priority_fill);
        }

        if (!empty($rating_value)) {
            if ($rating_value == 2) {
                $query->where('et_bugs_list.bug_type', 2);
            }else if ($rating_value == 3) {
                $query->where('et_bugs_list.bug_type', 3);
            }else if ($rating_value == 4) {
                $query->where('et_bugs_list.bug_status', 3);
            }
        }

        if (!empty($bug_status_fill)) {

            $query->where(function ($q) use ($bug_status_fill) {

                // Bug status 3,5,6
                $status_filters = array_intersect($bug_status_fill, [3, 5, 6]);

                if (!empty($status_filters)) {
                    $q->orWhereIn('et_bugs_list.bug_status', $status_filters);
                }

                // Overdue
                if (in_array(4, $bug_status_fill)) {
                    $q->orWhereDate('et_bugs_list.expected_date', '<', date('Y-m-d'))
                    ->where('et_bugs_list.bug_status', '<', 3);
                }

                // Assigned
                if (in_array(1, $bug_status_fill)) {
                    $q->orWhere(function ($subQ) {
                        $subQ->where('et_bugs_list.bug_status', 1)
                            ->whereNotNull('assign_staff_details');
                    });
                }

                // Unassigned
                if (in_array(2, $bug_status_fill)) {
                    $q->orWhere(function ($subQ) {
                        $subQ->where('et_bugs_list.bug_status', 1)
                            ->whereNull('assign_staff_details');
                    });
                }

            });
        }

        /*
        ==========================
        DATE FILTERS
        ==========================
        */

        if ($dt_fill_issue_rpt === 'today') {

            $query->whereDate('et_bugs_list.created_at', now()->toDateString());

        } elseif ($dt_fill_issue_rpt === 'week') {

            $weekFromDate = now()->startOfWeek()->toDateString();
            $weekToDate   = now()->endOfWeek()->toDateString();

            $query->whereBetween('et_bugs_list.created_at', [$weekFromDate, $weekToDate]);

        } elseif ($dt_fill_issue_rpt === 'monthly') {

            $query->whereBetween('et_bugs_list.created_at', [
                now()->startOfMonth()->toDateString(),
                now()->endOfMonth()->toDateString()
            ]);

        } elseif ($dt_fill_issue_rpt === 'custom_date') {

            if ($from_date && $to_date) {
                $query->whereBetween('et_bugs_list.created_at', [
                    date('Y-m-d', strtotime($from_date)),
                    date('Y-m-d', strtotime($to_date))
                ]);
            } elseif ($from_date) {
                $query->whereDate('et_bugs_list.created_at', '>=', date('Y-m-d', strtotime($from_date)));
            } elseif ($to_date) {
                $query->whereDate('et_bugs_list.created_at', '<=', date('Y-m-d', strtotime($to_date)));
            }
        }

        $bugs_list =  $query->orderBy('et_bugs_list.sno', 'desc')->paginate($perpage, ['*'], 'page', $page);

        /*
        |--------------------------------------------------------------------------
        | FORMAT DATA
        |--------------------------------------------------------------------------
        */

        foreach ($bugs_list as $bug) {

            $bug->bug_type_name =
                self::$bug_types_list[$bug->bug_type] ?? '-';

            $bug->priority_name =
                self::$bug_priority_list[$bug->priority] ?? '-';

            $bug->bug_status_name =
                self::$bug_status_list[$bug->bug_status] ?? '-'; 
            
            $credential = ModulesListModel::where('sno', $bug->module_id)->first();

            $bug->module_name = isset($bug->module_name) && !empty($bug->module_name) ? $bug->module_name : (isset($credential->module_name) && !empty($credential->module_name) ? $credential->module_name : '');

            /*
            |--------------------------------------------------------------------------
            | ASSIGNED STAFF IDS
            |--------------------------------------------------------------------------
            */

            $bug->assigned_staff_ids = isset($bug->assigned_to) && !empty($bug->assigned_to) ? json_decode($bug->assigned_to, true) : [];

            $assigned_staff_details = isset($bug->assign_staff_details) && !empty($bug->assign_staff_details) ? json_decode($bug->assign_staff_details) : [];

            /*
            |--------------------------------------------------------------------------
            | ATTACHMENTS
            |--------------------------------------------------------------------------
            */
            $bug->attachments_list = [];

            if (!empty($bug->attachments)) {

                $bug->attachments_list =
                    json_decode($bug->attachments, true) ?? [];
            }

            $bug->bug_date = isset($bug->created_at) && !empty($bug->created_at) ? date('d-M-Y',strtotime($bug->created_at)) : '';
            $bug->bug_time = isset($bug->created_at) && !empty($bug->created_at) ? date('h:i A',strtotime($bug->created_at)) : '';
            $bug->bug_start_date = isset($bug->start_date) && !empty($bug->start_date) ? date('d-M-Y',strtotime($bug->start_date)) : '';
            $bug->bug_encrypt_id = isset($bug->sno) && !empty($bug->sno) ? $helper->encrypt_decrypt($bug->sno,'encrypt') : '';
            $bug->assign_staffs_count = isset($bug->assigned_staff_ids) && !empty($bug->assigned_staff_ids) ? count($bug->assigned_staff_ids) : 0;

            $bug->completed_date = isset($bug->completed_date) && !empty($bug->completed_date) ? date('d-M-Y',strtotime($bug->completed_date)) : null;
            $bug->expected_date = isset($bug->expected_date) && !empty($bug->expected_date) ? date('d-M-Y',strtotime($bug->expected_date)) : null;
            
            $completed_by_id = isset($bug->completed_by) && ((int)$bug->completed_by >= 0) ? (int)$bug->completed_by : -1;

            $completed_by_details = isset($bug->completed_by_details) && !empty($bug->completed_by_details) ? json_decode($bug->completed_by_details, true) : '';

            // $staff_details = ($completed_by_id >= 0) ? $helper->staff_details($completed_by_id) : null;

            $staff_image_path = '';

            // $staff_image_full_path = isset($staff_details->staff_image) && !empty($staff_details->staff_image) ? $staff_image_path.$staff_details->staff_image :'';

            // $staff_backgrounds = '';
            // $staff_bg_color = '';
            // $staff_bg_text_color = '';

            // if (!$staff_image_full_path || !file_exists(public_path($staff_image_full_path))) {
            //     $staff_backgrounds = isset($staff_details->sno) ? $this->generateAvatarColors((int)$staff_details->staff_sno) : null;
            //     $staff_bg_color = isset($staff_backgrounds['bg']) ? $staff_backgrounds['bg'] : null;
            //     $staff_bg_text_color = isset($staff_backgrounds['text']) ? $staff_backgrounds['text'] : null;
            // }

            $staff_img_html = '';

            if($completed_by_id >= 0){

                // $staff_img_html .= ($staff_image_full_path && file_exists(public_path($staff_image_full_path)))
                // ? '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle w-50px h-50px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
                // : '<div class="avatar">
                //     <span class="avatar-initial rounded-circle" style="background-color:' . $staff_bg_color . ' !important;color:' . $staff_bg_text_color . ' !important">' . (isset($staff_details->staff_name) && !empty($staff_details->staff_name) ? strtoupper(substr(($staff_details->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                // </div>';

                $staff_image_path = isset($completed_by_details->image) && !empty($completed_by_details->image) ? $completed_by_details->image :'';
    
                $staff_img_html = (!empty($staff_image_path))
                ? '<img style="box-shadow: rgba(0, 0, 0, 0.16) -2px 0px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;" class="rounded-circle" src="'.$staff_image_path.'" alt="Avatar">'
                : '<div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff Profile">
                    <i class="un_staff mdi mdi-account-circle"></i>
                </div>';
                
            }else{
                $staff_img_html .= '<div class="d-flex flex-column gap-1">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                            <i class="mdi mdi-account-off fs-5"></i>
                        </div>
                        <label class="fw-semibold fs-8 text-dark mb-0">Bug Not Completed</label>
                    </div>
                </div>';
            }

            $bug->completed_by_id = $completed_by_id;
            $bug->completed_staff_image_full_path = $staff_image_path ?? null;
            $bug->completed_staff_img_html = $staff_img_html ?? null;
            $bug->completed_staff_details = $completed_by_details;

            $bug->bug_drop_reason = isset($bug->drop_reason_id) && !empty($bug->drop_reason_id) ? $bug->drop_reason : (isset($bug->drop_others_reason) && !empty($bug->drop_others_reason) ? $bug->drop_others_reason : '');
            $bug->bug_hold_reason = isset($bug->hold_reason_id) && !empty($bug->hold_reason_id) ? $bug->hold_reason : (isset($bug->hold_others_reason) && !empty($bug->hold_others_reason) ? $bug->hold_others_reason : '');

            $bug->bug_hold_ext_date = isset($bug->hold_end_date) && !empty($bug->hold_end_date) ? date('d-M-Y',strtotime($bug->hold_end_date)) : '';
            

            $hold_expriy_date = isset($bug->hold_end_date) && !empty($bug->hold_end_date) ? strtotime($bug->hold_end_date) : '';
            $bug_expriy_date = isset($bug->expected_date) && !empty($bug->expected_date) ? strtotime($bug->expected_date) : '';
            $hold_now_date = strtotime(date('Y-m-d'));

            $bug->bug_hold_exp_status = false;
            $bug->bug_exp_status = false;

            
            if(!empty($assigned_staff_details)){
                
                foreach ($assigned_staff_details as $assigned_staff_data) {

                    // $assign_staff_img_html = '';

                    $assign_staff_image_full_path = isset($assigned_staff_data->image) && !empty($assigned_staff_data->image) ? $assigned_staff_data->image :'';
    
                    $assign_staff_img_html = (!empty($assign_staff_image_full_path))
                    ? '<img style="box-shadow: rgba(0, 0, 0, 0.16) -2px 0px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;" class="rounded-circle" src="'.$assign_staff_image_full_path.'" alt="Avatar">'
                    : '<div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff Profile">
                        <i class="un_staff mdi mdi-account-circle"></i>
                    </div>';

                    $assigned_staff_data->assigned_staff_html = $assign_staff_img_html;
                }
            }

            if(!empty($hold_expriy_date)){
                if($hold_now_date > $hold_expriy_date){
                    $bug->bug_hold_exp_status = true;
                }
            }

            if(isset($bug->bug_status) && ((int)$bug->bug_status == 1)){
                if(!empty($bug_expriy_date)){
                    if($hold_now_date > $bug_expriy_date){
                        $bug->bug_exp_status = true;
                    }
                }
            }

            $bug->assigned_staff_details = isset($assigned_staff_details) && !empty($assigned_staff_details) ? ($assigned_staff_details) : null;

            $bug->bug_hold_ext_date = isset($bug->hold_end_date) && !empty($bug->hold_end_date) ? date('d-M-Y',strtotime($bug->hold_end_date)) : '';
        }

        $total_bugs = BugsListModel::where('status', '!=' ,2)->count();

        // $total_pending_bugs_list = BugsListModel::where('status', '!=', 2)->whereNotNull('bug_status')->where('bug_status', '<', 8)->get();

        // $total_pending_bugs = 0;

        // foreach ($total_pending_bugs_list as $total_pending_bugs_data) {

        //     if ($total_pending_bugs_data->bug_status < 8) {

        //         // $total_pending_assigned_staff_ids = isset($total_pending_bugs_data->assigned_to) && !empty($total_pending_bugs_data->assigned_to) ? json_decode($total_pending_bugs_data->assigned_to, true) : [];

        //         // If assigned staffs exists count 1 bug
        //         // if (count($total_pending_assigned_staff_ids) <= 0) {
        //             $total_pending_bugs++;
        //         // }
        //     }
        // }

        $total_pending_bugs_list = BugsListModel::where('status', '!=', 2)->whereNotNull('bug_status')->whereIn('bug_status', [1,3,6,9])->get();
 
        $total_pending_bugs = 0;
 
        foreach ($total_pending_bugs_list as $total_pending_bugs_data) {
 
            if (in_array($total_pending_bugs_data->bug_status, [1,3,6,9])) {
 
                // $total_pending_assigned_staff_ids = isset($total_pending_bugs_data->assigned_to) && !empty($total_pending_bugs_data->assigned_to) ? json_decode($total_pending_bugs_data->assigned_to, true) : [];
 
                // If assigned staffs exists count 1 bug
                // if (count($total_pending_assigned_staff_ids) <= 0) {
                    $total_pending_bugs++;
                // }
            }
        }
        
        // BUG TYPE COUNTS
        $total_bug_type = BugsListModel::where('status', '!=' ,2)
            ->where('bug_type', 1)
            ->count();

        $total_new_type = BugsListModel::where('status', '!=' ,2)
            ->where('bug_type', 2)
            ->count();

        $total_modification_type = BugsListModel::where('status', '!=' ,2)
            ->where('bug_type', 3)
            ->count();

        // COMPLETED BUGS
        $total_completed_bugs = BugsListModel::where('status', '!=' ,2)
            ->where('bug_status', 3)
            ->count();

        $pageConfigs = [
            'myLayout' => 'default'
        ];

        return response([
            'status' => 200,
            'message' => 'Bugs List Fetched Successfully',
            'error_msg' => null,
            'data' => [
                'bugs_list' => $bugs_list,
                'pageConfigs' => $pageConfigs,
                'bug_types_list' => self::$bug_types_list,
                'bug_priority_list' => self::$bug_priority_list,
                'bug_status_list' => self::$bug_status_list,
                'total_bugs' => $total_bugs,
                'total_pending_bugs' => $total_pending_bugs,
                'total_bug_type' => $total_bug_type,
                'total_new_type' => $total_new_type,
                'total_modification_type' => $total_modification_type,
                'total_completed_bugs' => $total_completed_bugs
            ]
        ], 200);
    }

    public function get_modules_list(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $staffs = ModulesListModel::where('status', 0)->get();

        if(!$staffs) {
        return response([
            'status' => 400,
            'message' => 'No Such Records !',
            'error_msg' => null,
            'data' => null
        ], 404);
        } else {
        return response([
            'status' => 200,
            'message' => 'Module List Fetched Successfully',
            'error_msg' => null,
            'data' => $staffs
        ], 200);
        }
    }

    public function add_module_list(Request $request)
    {
        // return $request;

        $validator = Validator::make($request->all(), [
            'module_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {


            $module_name = $request->module_name;
            $module_desc = $request->module_desc;
            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
            $chk = ModulesListModel::where('module_name', strtolower($module_name))->where('status', '!=', 2)->first();

            if ($chk) {
                return response([
                    'status' => 401,
                    'message' => 'Already Module Name is exist!',
                    'error_msg' => 'Already Module Name is exist!',
                    'data' => null,
                ], 200);
            } else {
                $category_check = ModulesListModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $module_id = "Module-0001/" . $year;
                } else {

                    $data = $category_check->module_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf("Module-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $module_id = $request . '/' . $year;
                }


                $add = new ModulesListModel();
                $add->module_id = $module_id;
                $add->module_name = Ucfirst($module_name);
                $add->description = $module_desc;
                $add->created_at = now();
                $add->created_by = $user_id;
                // return $add;
                $add->save();

                if ($add) {
                    return response([
                        'status' => 200,
                        'message' => 'Module Name is added Successfully!',
                        'error_msg' => '',
                        'data' => null,
                    ], 200);
                } else {
                    return response([
                        'status' => 401,
                        'message' => 'Module Name is added Unsuccessfully!',
                        'error_msg' => '',
                        'data' => null,
                    ], 401);
                }
            }
        }
    }

    public function Add(Request $request)
    {

        try {

            $validator = Validator::make($request->all(), [

                'bug_module_id'   => 'required|integer',

                'bug_name'        => 'required|string|max:255',

                'bug_description' => 'nullable|string',

                'bug_type'        => 'required|integer',

                'bug_priority'    => 'required|integer',

                // 'bug_attachments'   => 'nullable|array',

                // 'bug_attachments.*' => 'file|max:5120'

            ]);

            if ($validator->fails()) {

                return response()->json([

                    'status' => false,

                    'message' => 'Validation Error',

                    'errors' => $validator->errors()

                ], 422);
            }

            DB::beginTransaction();

            $branch_id = $request->user()->branch_id ?? 0;

            $staff_id = $request->user()->user_id ?? 0;


            /*
            |--------------------------------------------------------------------------
            | INSERT BUG
            |--------------------------------------------------------------------------
            */

            $bug = new BugsListModel();

            $bug->branch_id = $branch_id;

            $bug->module_id = $request->bug_module_id;

            $bug->module_name = null;

            $bug->bug_title = $request->bug_name;

            $bug->bug_description = $request->bug_description;

            $bug->bug_type = $request->bug_type;

            $bug->priority = $request->bug_priority;

            $bug->bug_status = 1;

            $bug->assigned_to = json_encode([]);

            $bug->start_date = now();

            $bug->expected_date = isset($request->bug_end_date) && !empty($request->bug_end_date) ? date('Y-m-d',strtotime($request->bug_end_date)) : null;

            $bug->completed_date = null;

            $bug->hold_start_date = null;

            $bug->hold_end_date = null;

            $bug->hold_duration_hours = 0;

            $bug->hold_duration_days = 0;

            $bug->hold_reason = null;

            $bug->drop_reason_id = null;

            $bug->drop_reason = null;
            
            $bug->drop_others_reason = null;

            $bug->remarks = null;

            $bug->attachments = NULL;

            // $bug->status = 1;

            $bug->created_by = $staff_id;

            $bug->updated_by = $staff_id;

            $bug->created_at = now();

            $bug->updated_at = now();

            $bug->save();

            $bug_id = $bug->sno;

            $attachments = [];

            if ($request->hasFile('bug_attachments')) {

                $upload_path = public_path('bug_attachments/' . $bug_id);

                if (!file_exists($upload_path)) {

                    mkdir($upload_path, 0777, true);
                }

                foreach ($request->file('bug_attachments') as $file) {

                    if (!$file) {
                        continue;
                    }

                    $original_name = $file->getClientOriginalName();

                    $extension = $file->getClientOriginalExtension();

                    $file_name = time() . '_' . rand(1000,9999) . '.' . $extension;

                    $file->move($upload_path, $file_name);

                    $attachments[] = [

                        'file_name'      => $file_name,

                        'original_name'  => $original_name,

                        'file_extension' => $extension,

                        'file_path'      => 'bug_attachments/' . $bug_id . '/' . $file_name

                    ];
                }

                
                $bug->attachments = json_encode($attachments);
                
            }
                
            $credential = ModulesListModel::where('sno', $request->bug_module_id)->first();
            $bug->module_name = isset($credential->module_name) && !empty($credential->module_name) ? $credential->module_name : NULL;

            $bug->save();

            /*
            |--------------------------------------------------------------------------
            | INSERT HISTORY
            |--------------------------------------------------------------------------
            */

            $history = new BugsListHistoryModel();

            $history->bug_id = $bug_id;

            $history->old_bug_status = null;

            $history->new_bug_status = 1;

            $history->old_priority = null;

            $history->new_priority = $request->bug_priority;

            $history->assigned_from = null;

            $history->assigned_to = json_encode([]);

            $history->action_type = 1;

            $history->comments = 'Bug Created';

            $history->hold_start_date = null;

            $history->hold_end_date = null;

            $history->hold_duration_hours = 0;

            $history->hold_duration_days = 0;

            // $history->status = 1;

            $history->created_by = $staff_id;

            $history->updated_by = $staff_id;

            $history->created_at = now();

            $history->updated_at = now();

            $history->save();



            DB::commit();

            return response()->json([

                'status' => true,

                'message' => 'Bug Added Successfully',

                'bug_id' => $bug_id

            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([

                'status' => false,

                'message' => $e->getMessage()

            ], 500);
        }
    }

    public function Edit($id, Request $request)
    {
        try {

            $user = $request->user();
            $branch_id = $user->branch_id ?? null;
            $helper = new \App\Helpers\Helpers();

            $sno  = $helper->encrypt_decrypt($id,'decrypt');

            if(empty($sno)){
                return response([
                    'status'=>400,
                    'message'=>'Invalid ID'
                ],200);
            }

            $bug = BugsListModel::select(
                'sno',
                'branch_id',

                'module_id',
                'module_name',

                'bug_title',
                'bug_description',

                'bug_type',
                'priority',
                'bug_status',

                'assigned_to',

                'start_date',
                'expected_date',

                'completed_date',
                'completed_by',
                'completed_by_details',
                'completed_description',
                'completed_url',

                'testing_verified_by',
                'testing_verified_by_details',
                'testing_description',
                'testing_verified_at',

                'completed_verified_by',
                'completed_verified_at',

                'hold_start_date',
                'hold_end_date',

                'hold_duration_hours',
                'hold_duration_days',

                'hold_reason',

                'drop_reason_id',
                'drop_reason',
                'drop_others_reason',

                'remarks',

                'attachments',

                'status',

                'created_by',
                'updated_by',

                'created_at',
                'updated_at'
            )
            ->where('status', '!=', 2)
            ->where('sno', $sno)
            ->first();


            /* =========================================
            NOT FOUND
            ========================================= */

            if (!$bug) {

                return response([
                    'status' => 404,
                    'message' => 'Bug Not Found',
                    'error_msg' => 'Invalid Bug ID',
                    'data' => null
                ], 404);

            }


            /* =========================================
            BUG TYPE NAME
            ========================================= */

            $bug->bug_type_name =
                self::$bug_types_list[$bug->bug_type] ?? '-';


            /* =========================================
            PRIORITY NAME
            ========================================= */

            $bug->priority_name =
                self::$bug_priority_list[$bug->priority] ?? '-';


            /* =========================================
            BUG STATUS NAME
            ========================================= */

            $bug->bug_status_name =
                self::$bug_status_list[$bug->bug_status] ?? '-';


            /* =========================================
            MODULE NAME
            ========================================= */

            $module = ModulesListModel::where(
                'sno',
                $bug->module_id
            )->first();

            $bug->module_name =
                !empty($bug->module_name)
                ? $bug->module_name
                : ($module->module_name ?? '');


            /* =========================================
            ASSIGNED STAFF IDS
            ========================================= */

            $bug->assigned_staff_ids = [];

            if (!empty($bug->assigned_to)) {

                $bug->assigned_staff_ids =
                    json_decode(
                        $bug->assigned_to,
                        true
                    ) ?? [];
            }


            /* =========================================
            ATTACHMENTS
            ========================================= */

            $bug->attachments_list = [];

            if (!empty($bug->attachments)) {

                $bug->attachments_list =
                    json_decode(
                        $bug->attachments,
                        true
                    ) ?? [];
            }


            /* =========================================
            DATE FORMATS
            ========================================= */

            $bug->bug_date =
                !empty($bug->created_at)
                ? date(
                    'd-M-Y',
                    strtotime($bug->created_at)
                )
                : '';

            $bug->bug_time =
                !empty($bug->created_at)
                ? date(
                    'h:i A',
                    strtotime($bug->created_at)
                )
                : '';

            $bug->bug_start_date =
                !empty($bug->start_date)
                ? date(
                    'd-M-Y',
                    strtotime($bug->start_date)
                )
                : '';


            /* =========================================
            ENCRYPT ID
            ========================================= */

            $bug->bug_encrypt_id =
                !empty($bug->sno)
                ? $helper->encrypt_decrypt(
                    $bug->sno,
                    'encrypt'
                )
                : '';


            $bug->assign_staffs_count = isset($bug->assigned_staff_ids) && !empty($bug->assigned_staff_ids) ? count($bug->assigned_staff_ids) : 0;

            $bug->expected_date = isset($bug->expected_date) && !empty($bug->expected_date) ? date('d-M-Y',strtotime($bug->expected_date)) : null;

            $bug->completed_date = isset($bug->completed_date) && !empty($bug->completed_date) ? date('d-M-Y',strtotime($bug->completed_date)) : null;

            $bug->completed_verified_at = isset($bug->completed_verified_at) && !empty($bug->completed_verified_at) ? date('d-M-Y',strtotime($bug->completed_verified_at)) : null;
            
            $bug->testing_verified_date = isset($bug->testing_verified_at) && !empty($bug->testing_verified_at) ? date('d-M-Y',strtotime($bug->testing_verified_at)) : null;
            
            $completed_verified_by_id = isset($bug->completed_verified_by) && ($bug->completed_verified_by >= 0) ? $bug->completed_verified_by : -1;
            
            $completed_by_id = isset($bug->completed_by) && ($bug->completed_by >= 0) ? $bug->completed_by : -1;
            $testing_verified_by_id = isset($bug->testing_verified_by) && ($bug->testing_verified_by >= 0) ? $bug->testing_verified_by : -1;

            $completed_by_details = isset($bug->completed_by_details) && !empty($bug->completed_by_details) ? json_decode($bug->completed_by_details) : '';
            $testing_verified_by_details = isset($bug->testing_verified_by_details) && !empty($bug->testing_verified_by_details) ? json_decode($bug->testing_verified_by_details) : '';

            // $staff_details = ($completed_by_id >= 0) ? $helper->staff_details($completed_by_id) : null;

            $staff_image_path = '';

            // $staff_image_full_path = isset($staff_details->staff_image) && !empty($staff_details->staff_image) ? $staff_image_path.$staff_details->staff_image :'';

            // $staff_backgrounds = '';
            // $staff_bg_color = '';
            // $staff_bg_text_color = '';

            // if (!$staff_image_full_path || !file_exists(public_path($staff_image_full_path))) {
            //     $staff_backgrounds = isset($staff_details->sno) ? $this->generateAvatarColors((int)$staff_details->staff_sno) : null;
            //     $staff_bg_color = isset($staff_backgrounds['bg']) ? $staff_backgrounds['bg'] : null;
            //     $staff_bg_text_color = isset($staff_backgrounds['text']) ? $staff_backgrounds['text'] : null;
            // }

            $staff_img_html = '';

            if($completed_by_id >= 0){

                // $staff_img_html .= ($staff_image_full_path && file_exists(public_path($staff_image_full_path)))
                // ? '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle w-50px h-50px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
                // : '<div class="avatar">
                //     <span class="avatar-initial rounded-circle" style="background-color:' . $staff_bg_color . ' !important;color:' . $staff_bg_text_color . ' !important">' . (isset($staff_details->staff_name) && !empty($staff_details->staff_name) ? strtoupper(substr(($staff_details->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                // </div>';

                $staff_image_path = isset($completed_by_details->image) && !empty($completed_by_details->image) ? $completed_by_details->image :'';

    
                $staff_img_html = (!empty($staff_image_path))
                ? '<img class="rounded-circle w-50px h-50px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;" src="'.$staff_image_path.'" alt="Avatar">'
                : '<div class="avatar">
                    <span class="avatar-initial rounded-circle" style="background-color:#eae1fc !important;color:#7239ea !important">' . (isset($completed_by_details->staff_name) && !empty($completed_by_details->staff_name) ? strtoupper(substr(($completed_by_details->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                </div>';
            }else{
                $staff_img_html .= '<div class="d-flex flex-column gap-1">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                            <i class="mdi mdi-account-off fs-5"></i>
                        </div>
                        <label class="fw-semibold fs-8 text-dark mb-0">Bug Not Completed</label>
                    </div>
                </div>';
            }

            $complete_verified_staff_details = ($completed_verified_by_id >= 0) ? $helper->staff_details($completed_verified_by_id) : null;

            $complete_verified_staff_image_path = 'staff_images/';

            $complete_verified_staff_image_full_path = isset($complete_verified_staff_details->staff_image) && !empty($complete_verified_staff_details->staff_image) ? $complete_verified_staff_image_path.$complete_verified_staff_details->staff_image :'';

            $complete_verified_staff_backgrounds = '';
            $complete_verified_staff_bg_color = '';
            $complete_verified_staff_bg_text_color = '';

            if (!$complete_verified_staff_image_full_path || !file_exists(public_path($complete_verified_staff_image_full_path))) {
                $complete_verified_staff_backgrounds = isset($complete_verified_staff_details->sno) ? $this->generateAvatarColors((int)$complete_verified_staff_details->staff_sno) : null;
                $complete_verified_staff_bg_color = isset($complete_verified_staff_backgrounds['bg']) ? $complete_verified_staff_backgrounds['bg'] : null;
                $complete_verified_staff_bg_text_color = isset($complete_verified_staff_backgrounds['text']) ? $complete_verified_staff_backgrounds['text'] : null;
            }

            $complete_verified_staff_img_html = '';

            if($completed_verified_by_id >= 0){

                $complete_verified_staff_img_html .= ($complete_verified_staff_image_full_path && file_exists(public_path($complete_verified_staff_image_full_path)))
                ? '<img src="' . asset($complete_verified_staff_image_full_path) . '" class="rounded-circle w-50px h-50px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
                : '<div class="avatar">
                    <span class="avatar-initial rounded-circle" style="background-color:' . $complete_verified_staff_bg_color . ' !important;color:' . $complete_verified_staff_bg_text_color . ' !important">' . (isset($complete_verified_staff_details->staff_name) && !empty($complete_verified_staff_details->staff_name) ? strtoupper(substr(($complete_verified_staff_details->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                </div>';

            }else{
                $complete_verified_staff_img_html .= '<div class="d-flex flex-column gap-1">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                            <i class="mdi mdi-account-off fs-5"></i>
                        </div>
                        <label class="fw-semibold fs-8 text-dark mb-0">Bug Not Completed Verified</label>
                    </div>
                </div>';
            }

            $testing_staff_img_html = '';

            if($testing_verified_by_id >= 0){

                // $staff_img_html .= ($staff_image_full_path && file_exists(public_path($staff_image_full_path)))
                // ? '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle w-50px h-50px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
                // : '<div class="avatar">
                //     <span class="avatar-initial rounded-circle" style="background-color:' . $staff_bg_color . ' !important;color:' . $staff_bg_text_color . ' !important">' . (isset($staff_details->staff_name) && !empty($staff_details->staff_name) ? strtoupper(substr(($staff_details->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                // </div>';

                $testing_staff_image_path = isset($testing_verified_by_details->image) && !empty($testing_verified_by_details->image) ? $testing_verified_by_details->image :'';

    
                $testing_staff_img_html = (!empty($testing_staff_image_path))
                ? '<img class="rounded-circle w-50px h-50px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;" src="'.$testing_staff_image_path.'" alt="Avatar">'
                : '<div class="avatar">
                    <span class="avatar-initial rounded-circle" style="background-color:#eae1fc !important;color:#7239ea !important">' . (isset($testing_verified_by_details->staff_name) && !empty($testing_verified_by_details->staff_name) ? strtoupper(substr(($testing_verified_by_details->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                </div>';
                
            }else{
                $testing_staff_img_html .= '<div class="d-flex flex-column gap-1">
                    <div class="d-flex gap-2 align-items-center">
                        <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                            <i class="mdi mdi-account-off fs-5"></i>
                        </div>
                        <label class="fw-semibold fs-8 text-dark mb-0">Bug Not Testing Verifed</label>
                    </div>
                </div>';
            }

            $bug->completed_by_id = $completed_by_id ?? null;
            $bug->completed_staff_image_full_path = $staff_image_path ?? null;
            $bug->completed_staff_img_html = $staff_img_html ?? null;
            $bug->completed_staff_details = $completed_by_details;

            $bug->testing_verified_by_id = $testing_verified_by_id ?? null;
            $bug->testing_staff_image_full_path = $testing_staff_image_path ?? null;
            $bug->testing_staff_img_html = $testing_staff_img_html ?? null;
            $bug->testing_staff_details = $testing_verified_by_details;

            $bug->complete_verified_by_id = $completed_verified_by_id ?? null;
            $bug->complete_verified_staff_image_full_path = $complete_verified_staff_image_full_path ?? null;
            $bug->complete_verified_staff_img_html = $complete_verified_staff_img_html ?? null;
            $bug->complete_verified_staff_details = $complete_verified_staff_details;

            $hold_expriy_date = isset($bug->hold_end_date) && !empty($bug->hold_end_date) ? strtotime($bug->hold_end_date) : '';
            $bug_expriy_date = isset($bug->expected_date) && !empty($bug->expected_date) ? strtotime($bug->expected_date) : '';
            $hold_now_date = strtotime(date('Y-m-d'));

            $bug->bug_hold_exp_status = false;
            $bug->bug_exp_status = false;
            
            if(!empty($hold_expriy_date)){
                if($hold_now_date > $hold_expriy_date){
                    $bug->bug_hold_exp_status = true;
                }
            }

            if(isset($bug->bug_status) && ((int)$bug->bug_status == 1)){
                if(!empty($bug_expriy_date)){
                    if($hold_now_date > $bug_expriy_date){
                        $bug->bug_exp_status = true;
                    }
                }
            }

            /* =========================================
            RESPONSE
            ========================================= */

            return response([
                'status' => 200,
                'message' => 'Bug Details Fetched Successfully',
                'error_msg' => null,
                'data' => $bug,
                'bug_types_list' => self::$bug_types_list,
                'bug_priority_list' => self::$bug_priority_list,
                'bug_status_list' => self::$bug_status_list
            ], 200);

        } catch (\Exception $e) {

            return response([

                'status' => 500,

                'message' => 'Something Went Wrong',

                'error_msg' => $e->getMessage(),

                'data' => null

            ], 500);

        }
    }

    public function Update(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [

                'bug_id'          => 'required|string',

                'bug_module_id'   => 'required|integer',

                'bug_name'        => 'required|string|max:255',

                'bug_description' => 'nullable|string',

                'bug_type'        => 'required|integer',

                'bug_priority'    => 'required|integer',

            ]);

            if ($validator->fails()) {

                return response()->json([

                    'status' => false,

                    'message' => 'Validation Error',

                    'errors' => $validator->errors()

                ], 422);
            }

            DB::beginTransaction();

            $helper     = new \App\Helpers\Helpers();
            
            $branch_id = $request->user()->branch_id ?? 0;

            $staff_id = $request->user()->user_id ?? 0;

            $bug_id  = $helper->encrypt_decrypt($request->bug_id,'decrypt');

            if(empty($bug_id)){
                return response([
                    'status'=>400,
                    'message'=>'Invalid ID'
                ],200);
            }

            /*
            |--------------------------------------------------------------------------
            | GET BUG
            |--------------------------------------------------------------------------
            */

            $bug = BugsListModel::where('sno', $bug_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$bug) {

                return response()->json([

                    'status' => false,

                    'message' => 'Bug Not Found'

                ], 404);
            }


            /*
            |--------------------------------------------------------------------------
            | OLD VALUES
            |--------------------------------------------------------------------------
            */

            $old_bug_status = $bug->bug_status;

            $old_priority = $bug->priority;

            $old_assigned_to = $bug->assigned_to;


            /*
            |--------------------------------------------------------------------------
            | OLD ATTACHMENTS
            |--------------------------------------------------------------------------
            */

            $old_attachments = [];

            if (!empty($bug->attachments)) {

                $old_attachments =
                    json_decode($bug->attachments, true) ?? [];
            }


            /*
            |--------------------------------------------------------------------------
            | KEEP OLD FILES
            |--------------------------------------------------------------------------
            */

            $keep_old_files = [];

            if ($request->has('old_attachments')) {

                $keep_old_files =
                    json_decode(
                        $request->old_attachments,
                        true
                    ) ?? [];
            }


            /*
            |--------------------------------------------------------------------------
            | FILTER OLD FILES
            |--------------------------------------------------------------------------
            */

            $final_attachments = [];

            foreach ($old_attachments as $old_file) {

                $exists = collect($keep_old_files)
                    ->contains(function ($item) use ($old_file) {

                        return
                            isset($item['file_name']) &&
                            $item['file_name'] ==
                            $old_file['file_name'];
                    });

                if ($exists) {

                    $final_attachments[] = $old_file;

                } else {

                    // DELETE FILE
                    $file_path = public_path(
                        $old_file['file_path']
                    );

                    if (file_exists($file_path)) {

                        unlink($file_path);
                    }
                }
            }


            /*
            |--------------------------------------------------------------------------
            | UPDATE BUG
            |--------------------------------------------------------------------------
            */

            $credential = ModulesListModel::where(
                'sno',
                $request->bug_module_id
            )->first();

            $bug->branch_id = $branch_id;

            $bug->module_id = $request->bug_module_id;

            $bug->module_name =
                $credential->module_name ?? null;

            $bug->bug_title = $request->bug_name;

            $bug->bug_description =
                $request->bug_description;
                
            $bug->expected_date = isset($request->bug_end_date) && !empty($request->bug_end_date) ? date('Y-m-d',strtotime($request->bug_end_date)) : null;

            $bug->bug_type = $request->bug_type;

            $bug->priority = $request->bug_priority;

            $bug->updated_by = $staff_id;

            $bug->updated_at = now();


            /*
            |--------------------------------------------------------------------------
            | NEW ATTACHMENTS
            |--------------------------------------------------------------------------
            */

            if ($request->hasFile('bug_attachments')) {

                $upload_path =
                    public_path(
                        'bug_attachments/' . $bug_id
                    );

                if (!file_exists($upload_path)) {

                    mkdir($upload_path, 0777, true);
                }

                foreach (
                    $request->file('bug_attachments')
                    as $file
                ) {

                    if (!$file) {
                        continue;
                    }

                    $original_name =
                        $file->getClientOriginalName();

                    $extension =
                        $file->getClientOriginalExtension();

                    $file_name =
                        time() .
                        '_' .
                        rand(1000, 9999) .
                        '.' .
                        $extension;

                    $file->move(
                        $upload_path,
                        $file_name
                    );

                    $final_attachments[] = [

                        'file_name'      => $file_name,

                        'original_name'  => $original_name,

                        'file_extension' => $extension,

                        'file_path'      =>
                            'bug_attachments/' .
                            $bug_id .
                            '/' .
                            $file_name

                    ];
                }
            }


            /*
            |--------------------------------------------------------------------------
            | SAVE ATTACHMENTS
            |--------------------------------------------------------------------------
            */

            $bug->attachments =
                !empty($final_attachments)
                ? json_encode($final_attachments)
                : null;

            $bug->save();


            /*
            |--------------------------------------------------------------------------
            | INSERT HISTORY
            |--------------------------------------------------------------------------
            */

            /*
            |--------------------------------------------------------------------------
            | HISTORY VARIABLES
            |--------------------------------------------------------------------------
            */

            $isChanged = false;

            $actionTypes = [];

            $comments = [];


            /*
            |--------------------------------------------------------------------------
            | ASSIGNED STAFF CHANGED
            |--------------------------------------------------------------------------
            */

            if (
                $old_assigned_to !==
                $bug->assigned_to
            ) {

                $isChanged = true;

                $actionTypes[] = 3;

                $comments[] = 'Bug Assigned';

            }


            /*
            |--------------------------------------------------------------------------
            | STATUS CHANGED
            |--------------------------------------------------------------------------
            */

            if (
                (int)$old_bug_status !==
                (int)$bug->bug_status
            ) {

                $isChanged = true;

                $actionTypes[] = 4;

                $comments[] = 'Bug Status Changed';


                /*
                |--------------------------------------------------------------------------
                | COMPLETED
                |--------------------------------------------------------------------------
                */

                if ((int)$bug->bug_status === 3) {

                    $actionTypes[] = 6;

                    $comments[] = 'Bug Completed';

                }


                /*
                |--------------------------------------------------------------------------
                | HOLD
                |--------------------------------------------------------------------------
                */

                if ((int)$bug->bug_status === 4) {

                    $actionTypes[] = 7;

                    $comments[] = 'Bug Hold';

                }


                /*
                |--------------------------------------------------------------------------
                | DROPPED
                |--------------------------------------------------------------------------
                */

                if ((int)$bug->bug_status === 5) {

                    $actionTypes[] = 8;

                    $comments[] = 'Bug Dropped';

                }

            }


            /*
            |--------------------------------------------------------------------------
            | PRIORITY CHANGED
            |--------------------------------------------------------------------------
            */

            if (
                (int)$old_priority !==
                (int)$request->bug_priority
            ) {

                $isChanged = true;

                $actionTypes[] = 5;

                $comments[] = 'Bug Priority Changed';

            }


            /*
            |--------------------------------------------------------------------------
            | GENERAL UPDATE
            |--------------------------------------------------------------------------
            */

            if (

                $bug->bug_title !== $request->bug_name ||

                $bug->bug_description !==
                $request->bug_description ||

                (int)$bug->bug_type !==
                (int)$request->bug_type ||

                json_encode($old_attachments) !==
                json_encode($final_attachments)

            ) {

                $isChanged = true;

                $actionTypes[] = 2;

                $comments[] = 'Bug Updated';

            }


            /*
            |--------------------------------------------------------------------------
            | REMOVE DUPLICATES
            |--------------------------------------------------------------------------
            */

            $actionTypes = array_unique($actionTypes);

            $comments = array_unique($comments);


            /*
            |--------------------------------------------------------------------------
            | INSERT HISTORY
            |--------------------------------------------------------------------------
            */

            if ($isChanged) {

                foreach ($actionTypes as $index => $action_type) {

                    $history = new BugsListHistoryModel();

                    $history->bug_id = $bug_id;

                    $history->old_bug_status =
                        $old_bug_status;

                    $history->new_bug_status =
                        $bug->bug_status;

                    $history->old_priority =
                        $old_priority;

                    $history->new_priority =
                        $request->bug_priority;

                    $history->assigned_from =
                        $old_assigned_to;

                    $history->assigned_to =
                        $bug->assigned_to;

                    $history->action_type =
                        $action_type;

                    $history->comments =
                        $comments[$index] ?? 'Bug Updated';

                    $history->hold_start_date = null;

                    $history->hold_end_date = null;

                    $history->hold_duration_hours = 0;

                    $history->hold_duration_days = 0;

                    $history->created_by = $staff_id;

                    $history->updated_by = $staff_id;

                    $history->created_at = now();

                    $history->updated_at = now();

                    $history->save();

                }

            }

            DB::commit();

            return response()->json([

                'status' => true,

                'message' => 'Bug Updated Successfully',

                'bug_id' => $bug_id

            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([

                'status' => false,

                'message' => $e->getMessage()

            ], 500);
        }
    }

    public function CompletedBug(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'bug_id' => 'required|string'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);
            }

            DB::beginTransaction();

            $helper     = new \App\Helpers\Helpers();
            $completed_staff_id = $request->completed_staff_id ?? 0;
            $completed_staff_details = $request->completed_staff_details ?? [];
            $complete_staff_bug_url = $request->complete_staff_bug_url ?? '';
            $complete_staff_bug_description = $request->complete_staff_bug_description ?? '';
            $staff_id = $request->user()->user_id ?? 0;

            $bug_id  = $helper->encrypt_decrypt($request->bug_id,'decrypt');
            // $bug_id = $request->bug_id;

            $bug = BugsListModel::where('sno', $bug_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$bug) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Not Found'
                ], 404);
            }

            if ((int)$bug->bug_status === 3) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Already Completed'
                ], 400);
            }

            $old_bug_status = $bug->bug_status;
            $old_priority = $bug->priority;
            $old_assigned_to = $bug->assigned_to;

            $bug->bug_status = 3;
            $bug->completed_description = $complete_staff_bug_description ?? NULL;
            $bug->completed_url = $complete_staff_bug_url ?? NULL;
            $bug->completed_by = $completed_staff_id;
            $bug->completed_by_details = json_encode($completed_staff_details);
            $bug->completed_date = now();
            // $bug->updated_by = $staff_id;
            // $bug->updated_at = now();
            $bug->save();

            $history = new BugsListHistoryModel();

            $history->bug_id = $bug_id;
            $history->old_bug_status = $old_bug_status ?? NULL;
            $history->new_bug_status = 3;
            $history->old_priority = $old_priority ?? NULL;
            $history->new_priority = $bug->priority ?? NULL;
            $history->assigned_from = $old_assigned_to ?? NULL;
            $history->assigned_to = $bug->assigned_to ?? NULL;
            $history->completed_by = $completed_staff_id;
            $history->completed_by_details = json_encode($completed_staff_details);
            $history->action_type = 6;
            $history->comments = 'Bug Completed';
            $history->hold_start_date = null;
            $history->hold_end_date = null;
            $history->hold_duration_hours = 0;
            $history->hold_duration_days = 0;
            $history->created_by = $staff_id;
            $history->updated_by = $staff_id;
            $history->created_at = now();
            $history->updated_at = now();
            $history->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Bug Completed Successfully',
                'bug_id' => $bug_id
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);

        }
    }

    public function DroppedBug(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'bug_id' => 'required|string',
                'drop_status' => 'required|int'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);
            }

            DB::beginTransaction();

            $helper     = new \App\Helpers\Helpers();
            $staff_id = $request->user()->user_id ?? 0;

            $drop_status = $request->drop_status ?? 5;
            $reason_id = $request->reason_id ?? 0;
            $other_reason = $request->other_reason ?? null;

            $bug_id  = $helper->encrypt_decrypt($request->bug_id,'decrypt');
            // $bug_id = $request->bug_id;

            $bug = BugsListModel::where('sno', $bug_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$bug) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Not Found'
                ], 404);
            }

            if ((int)$bug->bug_status === 3) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Already Dropped'
                ], 400);
            }

            $old_bug_status = $bug->bug_status;
            $old_priority = $bug->priority;
            $old_assigned_to = $bug->assigned_to;

            $bug->bug_status = $drop_status;

            if(!empty($reason_id)){

                $bug->drop_reason_id = $reason_id;

                $bug_drop_reason = BugReasonsModel::where('sno', $reason_id)
                ->where('type', 1)
                ->where('status', '!=', 2)
                ->first();

                $bug->drop_reason = isset($bug_drop_reason->reason_name) && !empty($bug_drop_reason->reason_name) ? $bug_drop_reason->reason_name : '';
                $bug->drop_others_reason = null;
            }else{
                $bug->drop_reason_id = null;
                $bug->drop_reason = 'others';
                $bug->drop_others_reason = isset($other_reason) && !empty($other_reason) ? $other_reason : '';
            }

            $bug->updated_by = $staff_id;
            $bug->updated_at = now();
            $bug->save();

            $history = new BugsListHistoryModel();

            $history->bug_id = $bug_id;
            $history->old_bug_status = $old_bug_status ?? NULL;
            $history->new_bug_status = $drop_status;
            $history->old_priority = $old_priority ?? NULL;
            $history->new_priority = $bug->priority ?? NULL;
            $history->assigned_from = $old_assigned_to ?? NULL;
            $history->assigned_to = $bug->assigned_to ?? NULL;
            $history->dropped_by = $staff_id;
            $history->dropped_at = now();
            $history->action_type = 8;
            $history->comments = 'Bug Dropped';
            $history->description = isset($bug->drop_reason_id) && !empty($bug->drop_reason_id) ? $bug->drop_reason : (isset($bug->drop_others_reason) && !empty($bug->drop_others_reason) ? $bug->drop_others_reason : '');
            $history->hold_start_date = null;
            $history->hold_end_date = null;
            $history->hold_duration_hours = 0;
            $history->hold_duration_days = 0;
            $history->created_by = $staff_id;
            $history->updated_by = $staff_id;
            $history->created_at = now();
            $history->updated_at = now();
            $history->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Bug Dropped Successfully',
                'bug_id' => $bug_id
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);

        }
    }

    public function HoldedBug(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'bug_id' => 'required',
                'hold_status' => 'required|integer',
                'reason_id' => 'required|integer',
                'other_reason' => 'nullable|string',
                'hold_end_date' => 'required'
            ]);

            if ($validator->fails()) {

                return response()->json([
                    'status' => false,
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);

            }

            DB::beginTransaction();

            $staff_id = $request->user()->user_id ?? 0;

            $helper     = new \App\Helpers\Helpers();
            $bug_id  = $helper->encrypt_decrypt($request->bug_id,'decrypt');

            $hold_status = $request->hold_status ?? 5;
            $reason_id = $request->reason_id ?? 0;
            $other_reason = $request->other_reason ?? null;

            $bug = BugsListModel::where('sno', $bug_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$bug) {

                return response()->json([
                    'status' => false,
                    'message' => 'Bug Not Found'
                ], 404);

            }

            if ((int)$bug->bug_status === 6) {

                return response()->json([
                    'status' => false,
                    'message' => 'Bug Already On Hold'
                ], 400);

            }

            $old_bug_status = $bug->bug_status;

            $old_priority = $bug->priority;

            $old_assigned_to = $bug->assigned_to;

            $hold_start_date = date('Y-m-d');

            $hold_end_date = isset($request->hold_end_date) && !empty($request->hold_end_date) ? date('Y-m-d',strtotime($request->hold_end_date)) : '';

            $start = \Carbon\Carbon::parse($hold_start_date);

            $end = \Carbon\Carbon::parse($hold_end_date);

            $hold_duration_hours = $start->diffInHours($end);

            $hold_duration_days = $start->diffInDays($end);

            if(!empty($reason_id)){

                $bug->hold_reason_id = $reason_id;

                $bug_hold_reason = BugReasonsModel::where('sno', $reason_id)
                ->where('type', 2)
                ->where('status', '!=', 2)
                ->first();

                $bug->hold_reason = isset($bug_hold_reason->reason_name) && !empty($bug_hold_reason->reason_name) ? $bug_hold_reason->reason_name : '';
                $bug->hold_others_reason = null;
            }else{
                $bug->hold_reason_id = null;
                $bug->hold_reason = 'others';
                $bug->hold_others_reason = isset($other_reason) && !empty($other_reason) ? $other_reason : '';
            }

            $bug->bug_status = $hold_status;

            $bug->hold_start_date = $hold_start_date;

            $bug->hold_end_date = $hold_end_date;

            $bug->hold_duration_hours = $hold_duration_hours;

            $bug->hold_duration_days = $hold_duration_days;

            $bug->updated_by = $staff_id;

            $bug->updated_at = now();

            $bug->save();

            $history = new BugsListHistoryModel();

            $history->bug_id = $bug_id;

            $history->old_bug_status = $old_bug_status;

            $history->new_bug_status = $hold_status;

            $history->old_priority = $old_priority;

            $history->new_priority = $bug->priority;

            $history->assigned_from = $old_assigned_to;

            $history->assigned_to = $bug->assigned_to;

            $history->action_type = 7;

            $history->comments = 'Bug Hold';

            $history->hold_start_date = $hold_start_date;

            $history->hold_end_date = $hold_end_date;

            $history->hold_duration_hours = $hold_duration_hours;

            $history->hold_duration_days = $hold_duration_days;

            $history->holded_by = $staff_id;

            $history->holded_at = now();

            $history->description = isset($bug->hold_reason_id) && !empty($bug->hold_reason_id) ? $bug->hold_reason : (isset($bug->hold_others_reason) && !empty($bug->hold_others_reason) ? $bug->hold_others_reason : '');

            $history->created_by = $staff_id;

            $history->updated_by = $staff_id;

            $history->created_at = now();

            $history->updated_at = now();

            $history->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Bug Hold Successfully',
                'bug_id' => $bug_id
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);

        }
    }

    public function UnHoldedBug(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'bug_id' => 'required|string',
                'unhold_status' => 'required|integer'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);
            }

            DB::beginTransaction();

            $helper     = new \App\Helpers\Helpers();
            $staff_id = $request->user()->user_id ?? 0;
            $unhold_status = $request->unhold_status ?? 1;

            $bug_id  = $helper->encrypt_decrypt($request->bug_id,'decrypt');
            // $bug_id = $request->bug_id;

            $bug = BugsListModel::where('sno', $bug_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$bug) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Not Found'
                ], 404);
            }

            if ((int)$bug->bug_status === 3) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Already Unholded'
                ], 400);
            }

            $old_bug_status = $bug->bug_status;
            $old_priority = $bug->priority;
            $old_assigned_to = $bug->assigned_to;

            $bug->bug_status = 1;
            $bug->unhold_at = now();
            $bug->updated_by = $staff_id;
            $bug->updated_at = now();
            $bug->save();

            $history = new BugsListHistoryModel();

            $history->bug_id = $bug_id;
            $history->old_bug_status = $old_bug_status ?? NULL;
            $history->new_bug_status = 1;
            $history->old_priority = $old_priority ?? NULL;
            $history->new_priority = $bug->priority ?? NULL;
            $history->assigned_from = $old_assigned_to ?? NULL;
            $history->assigned_to = $bug->assigned_to ?? NULL;
            $history->unhold_at = now();
            $history->action_type = 9;
            $history->comments = 'Bug Unhold';
            $history->hold_start_date = null;
            $history->hold_end_date = null;
            $history->hold_duration_hours = 0;
            $history->hold_duration_days = 0;
            $history->created_by = $staff_id;
            $history->updated_by = $staff_id;
            $history->created_at = now();
            $history->updated_at = now();
            $history->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Bug Unhold Successfully',
                'bug_id' => $bug_id
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);

        }
    }

    private function generateAvatarColors(int $id = 0)
    {
        // Generate hue based on ID (0 - 360)
        $hue = ($id * 137) % 360; // 137 gives better color distribution

        // Dark background color using HSL
        $bg = "hsl($hue, 45%, 30%)";   // 30% lightness = dark
        $text = "hsl($hue, 90%, 90%)"; // Light text for contrast

        return [
        'bg'   => $bg,
        'text' => $text,
        ];
    }

    public function bugs_reasons_list(Request $request)
    {
        $assign_type = (int) ($request->type ?? 2);

        if ($assign_type === '') {
        return response()->json([
            'status'  => 400,
            'message' => 'Reason Not Found..!',
            'data'    => null
        ]);
        }

        $results = BugReasonsModel::where('status', 0)
            ->where('type', $assign_type)
            // ->limit(20)
            ->get([
                'sno',
                'reason_name'
            ]);

        return response()->json([
        'status'  => 200,
        'message' => 'Reason is Found..!',
        'data'    => $results
        ]);
    }

    public function AssignStaff(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'bug_id' => 'required|string',
                'assign_staff_ids' => 'required|array'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);
            }

            DB::beginTransaction();

            $helper     = new \App\Helpers\Helpers();
            $staff_id = $request->user()->user_id ?? 0;
            $assign_staff_ids = $request->assign_staff_ids ?? [];
            $assign_staff_details = $request->assign_staff_details ?? [];

            $bug_id  = $helper->encrypt_decrypt($request->bug_id,'decrypt');
            // $bug_id = $request->bug_id;

            $bug = BugsListModel::where('sno', $bug_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$bug) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Not Found'
                ], 404);
            }

            $old_bug_status = $bug->bug_status;
            $old_priority = $bug->priority;
            $old_assigned_to = $bug->assigned_to;
            $old_assigned_to_details = $bug->assign_staff_details;

            $bug->expected_date = isset($request->bug_end_date) && !empty($request->bug_end_date) ? date('Y-m-d',strtotime($request->bug_end_date)) : '';
            $bug->assigned_to = !empty($assign_staff_ids) ? json_encode($assign_staff_ids) : null;
            $bug->assign_staff_details = !empty($assign_staff_details) ? json_encode($assign_staff_details) : null;
            $bug->updated_by = $staff_id;
            $bug->updated_at = now();
            $bug->save();

            $history = new BugsListHistoryModel();

            $history->bug_id = $bug_id;
            $history->old_bug_status = $old_bug_status ?? NULL;
            $history->new_bug_status = NULL;
            $history->old_priority = $old_priority ?? NULL;
            $history->new_priority = $bug->priority ?? NULL;
            $history->assigned_from = $old_assigned_to ?? NULL;
            $history->assigned_from_details = $old_assigned_to_details ?? NULL;
            $history->assigned_to = $bug->assigned_to ?? NULL;
            $history->assign_to_details = $bug->assign_staff_details ?? NULL;
            $history->action_type = 3;
            $history->comments = 'Bug Staff Assigned';
            $history->hold_start_date = null;
            $history->hold_end_date = null;
            $history->hold_duration_hours = 0;
            $history->hold_duration_days = 0;
            $history->created_by = $staff_id;
            $history->updated_by = $staff_id;
            $history->created_at = now();
            $history->updated_at = now();
            $history->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Bug Staff Assigned Successfully',
                'bug_id' => $bug_id
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);

        }
    }

    public function CompletedVerifiedBug(Request $request)
    {
        try {

            // return $request;
            
            $validator = Validator::make($request->all(), [
                'bug_id' => 'required|string'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);
            }

            DB::beginTransaction();

            $helper     = new \App\Helpers\Helpers();
            $staff_id = $request->user()->user_id ?? 0;

            $bug_id  = $helper->encrypt_decrypt($request->bug_id,'decrypt');
            // $bug_id = $request->bug_id;

            $bug = BugsListModel::where('sno', $bug_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$bug) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Not Found'
                ], 404);
            }

            if ((int)$bug->bug_status === 8) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Already Completed Verified'
                ], 400);
            }

            $old_bug_status = $bug->bug_status;
            $old_priority = $bug->priority;
            $old_assigned_to = $bug->assigned_to;

            $bug->bug_status = 8;
            $bug->completed_verified_by = $staff_id;
            $bug->completed_verified_at = now();
            // $bug->updated_by = $staff_id;
            // $bug->updated_at = now();
            $bug->save();

            $history = new BugsListHistoryModel();

            $history->bug_id = $bug_id;
            $history->old_bug_status = $old_bug_status ?? NULL;
            $history->new_bug_status = 3;
            $history->old_priority = $old_priority ?? NULL;
            $history->new_priority = $bug->priority ?? NULL;
            $history->assigned_from = $old_assigned_to ?? NULL;
            $history->assigned_to = $bug->assigned_to ?? NULL;
            $history->completed_verified_by = $staff_id;
            $history->completed_verified_at = now();
            $history->action_type = 10;
            $history->comments = 'Bug Completed Verified';
            $history->hold_start_date = null;
            $history->hold_end_date = null;
            $history->hold_duration_hours = 0;
            $history->hold_duration_days = 0;
            $history->created_by = $staff_id;
            $history->updated_by = $staff_id;
            $history->created_at = now();
            $history->updated_at = now();
            $history->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Bug Completed Verified Successfully',
                'bug_id' => $bug_id
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);

        }
    }

    public function TestingVerifiedBug(Request $request)
    {
        try {

            // return $request;
            
            $validator = Validator::make($request->all(), [
                'bug_id' => 'required|string'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);
            }

            DB::beginTransaction();

            $helper     = new \App\Helpers\Helpers();
            $testing_staff_id = $request->testing_staff_id ?? 0;
            $testing_staff_description = $request->testing_staff_description ?? NULL;
            $testing_staff_details = $request->testing_staff_details ?? [];
            $staff_id = $request->user()->user_id ?? 0;

            $bug_id  = $helper->encrypt_decrypt($request->bug_id,'decrypt');
            // $bug_id = $request->bug_id;

            $bug = BugsListModel::where('sno', $bug_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$bug) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Not Found'
                ], 404);
            }

            if ((int)$bug->bug_status === 9) {
                return response()->json([
                    'status' => false,
                    'message' => 'Bug Already Completed'
                ], 400);
            }

            $old_bug_status = $bug->bug_status;
            $old_priority = $bug->priority;
            $old_assigned_to = $bug->assigned_to;

            $bug->bug_status = 9;
            $bug->testing_verified_by = $testing_staff_id;
            $bug->testing_verified_by_details = json_encode($testing_staff_details);
            $bug->testing_description = $testing_staff_description;
            $bug->testing_verified_at = now();
            // $bug->updated_by = $staff_id;
            // $bug->updated_at = now();
            $bug->save();

            $history = new BugsListHistoryModel();

            $history->bug_id = $bug_id;
            $history->old_bug_status = $old_bug_status ?? NULL;
            $history->new_bug_status = 9;
            $history->old_priority = $old_priority ?? NULL;
            $history->new_priority = $bug->priority ?? NULL;
            $history->assigned_from = $old_assigned_to ?? NULL;
            $history->assigned_to = $bug->assigned_to ?? NULL;
            $history->completed_by = $testing_staff_id;
            $history->completed_by_details = json_encode($testing_staff_details);
            $history->action_type = 11;
            $history->comments = 'Bug Testing Verified';
            $history->hold_start_date = null;
            $history->hold_end_date = null;
            $history->hold_duration_hours = 0;
            $history->hold_duration_days = 0;
            $history->created_by = $staff_id;
            $history->updated_by = $staff_id;
            $history->created_at = now();
            $history->updated_at = now();
            $history->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Bug Testing Verified Successfully',
                'bug_id' => $bug_id
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);

        }
    }
}