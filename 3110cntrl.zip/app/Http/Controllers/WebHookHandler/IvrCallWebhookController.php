<?php

namespace App\Http\Controllers\WebHookHandler;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\IvrCall;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http; // Import Http facade
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;

class IvrCallWebhookController extends Controller
{
    public function ivrCallWebhook(Request $request)
    {
        DB::beginTransaction();

        try {



            $serverToken = 'erplive4c7eIbs5a2c1d8b4e6f7ac3d1e5a7IVRb8c9d0e1f2a3b4c5d6e7f8aErp9b0c12e3';
            // return $request;

            $headerToken = $request->bearerToken(); 

            if (!$headerToken || $headerToken !== $serverToken) {

                Log::warning('Unauthorized IVR Webhook Access', [
                    'ip' => $request->ip(),
                    'data' => $request->all()
                ]);

                return response()->json([
                    'status' => false,
                    'message' => 'Unauthorized Access'
                ], 401);
            }

            Log::info('Incoming IVR Webhook', [
                'ip' => $request->ip(),
                'payload' => $request->all()
            ]);


            $validator = Validator::make($request->all(), [

                'call_id' => 'required',
                'call_status' => 'nullable',

                'call_ended_at' => 'nullable',
                'call_started_at' => 'nullable',
                'call_answered_at' => 'nullable',

                'call_ended_by' => 'nullable',
                'recording_url' => 'nullable|string',

                'call_direction' => 'nullable',
                'agent_extension' => 'nullable',

                'agent_phone_number' => 'nullable',
                'display_phone_number' => 'nullable',
                'business_phone_number' => 'nullable',
                'customer_phone_number' => 'nullable',

                'talk_duration_seconds' => 'nullable',
                'total_duration_seconds' => 'nullable',

                'custom' => 'nullable'
            ]);

            if ($validator->fails()) {

                Log::error('IVR Webhook Validation Failed', [
                    'errors' => $validator->errors(),
                    'data' => $request->all()
                ]);

                return response()->json([
                    'status' => false,
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);
            }

            $ivrCall = IvrCall::updateOrCreate(
                ['call_id' => $request->call_id],
                [
                    'call_status' => $request->call_status,
                    'call_ended_at' => $request->call_ended_at ? Carbon::parse($request->call_ended_at) : null,
                    'call_ended_by' => $request->call_ended_by,
                    'recording_url' => $request->recording_url,
                    'call_direction' => $request->call_direction,
                    'agent_extension' => $request->agent_extension,
                    'call_started_at' => $request->call_started_at ? Carbon::parse($request->call_started_at) : null,
                    'call_answered_at' => $request->call_answered_at ? Carbon::parse($request->call_answered_at) : null,
                    'agent_phone_number' => $request->agent_phone_number,
                    'display_phone_number' => $request->display_phone_number,
                    'business_phone_number' => $request->business_phone_number,
                    'customer_phone_number' => $request->customer_phone_number,
                    'talk_duration_seconds' => $request->talk_duration_seconds ?? 0,
                    'total_duration_seconds' => $request->total_duration_seconds ?? 0,
                    'custom_data' => !empty($request->custom) ? json_encode($request->custom) : null
                ]
            );

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Webhook Data Received Successfully',
                // 'data' => [
                //     'id' => $ivrCall->id,
                //     'call_id' => $ivrCall->call_id
                // ]
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('IVR Webhook Error', [
                'message' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'payload' => $request->all()
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }


    private function getMediaExtension($mimeType)
    {
        $mimeMap = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            'video/mp4' => 'mp4',
            'video/avi' => 'avi',
            'video/3gpp' => '3gp',
            'audio/mpeg' => 'mp3',
            'audio/ogg' => 'ogg',
            'audio/wav' => 'wav',
            'audio/webm' => 'webm',
            'application/pdf' => 'pdf',
            'application/msword' => 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'application/vnd.ms-excel' => 'xls',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
            'application/zip' => 'zip',
            'application/x-rar-compressed' => 'rar',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
        ];

        return $mimeMap[$mimeType] ?? 'bin'; // Default to 'bin' if no match
    }

    /**
     * Get media folder based on type.
     */
    private function getMediaFolder($messageType)
    {
        return match ($messageType) {
            'image' => 'images',
            'video' => 'videos',
            'document' => 'documents',
            'audio' => 'audios',
            'sticker' => 'stickers',
            default => 'other',
        };
    }
}
