<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use App\Models\DailyTaskModel;
use Illuminate\Http\Request;
use App\Models\ManageTaskModel;
use App\Models\ManageTaskChecklistModel;
use App\Models\ReworkReasonModel;
use App\Models\StaffpointsModel;
use App\Models\ReworkModel;
use App\Models\StaffModel;
use App\Models\TaskLogModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;

class ManageTask extends Controller
{

//   public function index(Request $request)
//   {
//     $user_id = $request->user()->user_id;
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;

//     $today = now()->toDateString();

//     $lists = DB::table('et_daily_tasks')
//       ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_daily_tasks.service_id')
//       ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
//       ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_task', 'et_task.sno', 'et_daily_tasks.task_id')
//       ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
//       ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_daily_tasks.staff_id')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->select(
//         'et_daily_tasks.*',
//         'et_customer.cus_name',
//         'et_customer.customer_id',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_product.product_name',
//         'et_product_category.product_category_name',
//         'et_customer_services.variant_variable_ids',
//         'et_customer_services.pc_id',
//         'et_customer_services.cre_id',
//         'et_product_task.task_name',
//         'et_task.task_id as task_id',
//         'et_task.pages_percentage',
//         'et_task.working_hours',
//         'et_staff.staff_name',
//         'et_staff.staff_image',
//         'et_task.task_category',
//         'et_job_position.job_position_name'
//       )
//       // ->where(function ($query) use ($today) {
//       //   // 1️⃣ Today tasks (any status)
//       //   $query->whereDate('et_daily_tasks.task_date', $today)

//       //     // 2️⃣ OR past pending tasks
//       //     ->orWhere(function ($q) use ($today) {
//       //       $q->whereDate('et_daily_tasks.task_date', '<', $today)
//       //         ->whereIn('et_daily_tasks.status', [0, 1, 3]);
//       //     });
//       // })
//       ->where('et_daily_tasks.status', '!=', 2)
//       ->orderBy('et_daily_tasks.task_date', 'desc');

//     if (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'view_self_manage_task')) {
//       // User can only view their own data
//       $userRole = auth()->user()->role_id;

//       if ($userRole == 32 || $userRole == 36) {
//         $lists = $lists->where('et_daily_tasks.staff_id', $user_id);
//       } elseif ($userRole == 15) {
//         $lists = $lists->where('et_customer_services.pc_id', $user_id);
//       }
//     } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'global_manage_task')) {
//       // User can view all data — no extra filter needed
//       $lists = $lists;
//     } else {
//       // No permission
//       abort(403, 'Unauthorized');
//     }

//     $lists = $lists->get();

//     $totalTasks = $lists->where('is_journal', 0)
//       ->where('is_correction', 0)
//       ->where('rework_check', 0)
//       ->count();

//     $inProgressCount = $lists->where('status', 1)
//       ->count();

//     $notYetStartedCount = $lists->where('status', 0)
//       ->count();

//     $completedCount = $lists->where('status', 3)
//       ->count();

//     $qcVerifiedCount = $lists->where('status', 4)
//       ->count();

//     $correctionCount = $lists->where('is_journal', 0)
//       ->where('is_correction', 1)
//       ->where('rework_check', 0)
//       ->count();

//     $reworkCount = $lists->where('is_journal', 0)
//       ->where('is_correction', 0)
//       ->where('rework_check', 1)
//       ->count();

//     $journalCount = $lists->where('is_journal', 1)
//       ->where('is_correction', 0)
//       ->where('rework_check', 0)
//       ->count();

//     foreach ($lists as $list) {
//       $variantVariableIds = json_decode($list->variant_variable_ids, true);

//       $variantName = '';
//       $variableName = '';

//       if (is_array($variantVariableIds)) {
//         foreach ($variantVariableIds as $data) {
//           $variant = DB::table('et_manage_product_variant')->where('sno', $data['variant_id'])->first();
//           $variable = DB::table('et_manage_product_variable')->where('sno', $data['variable_id'])->first();

//           if ($variant) {
//             $variantName = $variant->product_variant_name ?? '';
//           }

//           if ($variable) {
//             $variableName = $variable->variable_name ?? '';
//           }
//         }
//       }

//       $year = date('Y', strtotime($list->created_at));
//       $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
//       $list->formatted_service_id = "SR-{$id}/{$year}";

//       $list->variant_name = $variantName;
//       $list->variable_name = $variableName;
//     }

//     $staffs = DB::table('et_staff')
//       ->where('sno', $user_id)
//       ->first();

//     if ($staffs->department_id == 2  && $staffs->role_id == 15) {
//       $isProductionStaff = 1;
//     } elseif ($staffs->department_id == 2) {
//       $isProductionStaff = 2;
//     } else {
//       $isProductionStaff = 0;
//     }

//     return view('content.production_management.manage_task.list', [
//       'lists' => $lists,
//       'isStaffs' => $isProductionStaff,
//       'total_tasks' => $totalTasks,
//       'inProgressCount' => $inProgressCount,
//       'notYetStartedCount' => $notYetStartedCount,
//       'completedCount' => $completedCount,
//       'qcVerifiedCount' => $qcVerifiedCount,
//       'correctionCount' => $correctionCount,
//       'reworkCount' => $reworkCount,
//       'journalCount' => $journalCount
//     ]);
//   }

//  public function index(Request $request)
//   {
//     $user_id = $request->user()->user_id;
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $statusFilter = $request->status_filter;
//     $offset = ($page - 1) * $perpage;
 
//     $today = now()->toDateString();
 
//     $lists = DB::table('et_daily_tasks')
//       ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_daily_tasks.service_id')
//       ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
//       ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_task', 'et_task.sno', 'et_daily_tasks.task_id')
//       ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
//       ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_daily_tasks.staff_id')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->select(
//         'et_daily_tasks.*',
//         'et_customer.cus_name',
//         'et_customer.customer_id',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_product.product_name',
//         'et_product_category.product_category_name',
//         'et_customer_services.variant_variable_ids',
//         'et_customer_services.pc_id',
//         'et_customer_services.cre_id',
//         'et_product_task.task_name',
//         'et_task.task_id as task_id',
//         'et_task.pages_percentage',
//         'et_task.working_hours',
//         'et_staff.staff_name',
//         'et_staff.staff_image',
//         'et_task.task_category',
//         'et_job_position.job_position_name'
//       )
//       // ->where(function ($query) use ($today) {
//       //   // 1️⃣ Today tasks (any status)
//       //   $query->whereDate('et_daily_tasks.task_date', $today)
 
//       //     // 2️⃣ OR past pending tasks
//       //     ->orWhere(function ($q) use ($today) {
//       //       $q->whereDate('et_daily_tasks.task_date', '<', $today)
//       //         ->whereIn('et_daily_tasks.status', [0, 1, 3]);
//       //     });
//       // })
//       ->where('et_daily_tasks.status', '!=', 2)
//       ->orderBy('et_daily_tasks.task_date', 'desc');
 
//     if (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'view_self_manage_task')) {
//       // User can only view their own data
//       $userRole = auth()->user()->role_id;
 
//       if ($userRole == 32 || $userRole == 36) {
//         $lists = $lists->where('et_daily_tasks.staff_id', $user_id);
//       } elseif ($userRole == 15) {
//         $lists = $lists->where('et_customer_services.pc_id', $user_id);
//       }
//     } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'global_manage_task')) {
//       // User can view all data — no extra filter needed
//       $lists = $lists;
//     } else {
//       // No permission
//       abort(403, 'Unauthorized');
//     }
//     $countQuery = clone $lists;
//     $countLists = $countQuery->get();
//     if ($statusFilter != '') {
 
//       switch ($statusFilter) {
 
//           case 'total':
//               $lists->where('et_daily_tasks.is_journal', 0)
//                     ->where('et_daily_tasks.is_correction', 0)
//                     ->where('et_daily_tasks.rework_check', 0);
//               break;
 
//           case 'not_started':
//               $lists->where('et_daily_tasks.status', 0);
//               break;
 
//           case 'in_progress':
//               $lists->where('et_daily_tasks.status', 1);
//               break;
 
//           case 'completed':
//               $lists->where('et_daily_tasks.status', 3);
//               break;
 
//           case 'qc_verified':
//               $lists->where('et_daily_tasks.status', 4);
//               break;
 
//           case 'correction':
//               $lists->where('et_daily_tasks.is_journal', 0)
//                     ->where('et_daily_tasks.is_correction', 1)
//                     ->where('et_daily_tasks.rework_check', 0);
//               break;
 
//           case 'rework':
//               $lists->where('et_daily_tasks.is_journal', 0)
//                     ->where('et_daily_tasks.is_correction', 0)
//                     ->where('et_daily_tasks.rework_check', 1);
//               break;
 
//           case 'journal':
//               $lists->where('et_daily_tasks.is_journal', 1)
//                     ->where('et_daily_tasks.is_correction', 0)
//                     ->where('et_daily_tasks.rework_check', 0);
//               break;
//       }
//     }
//     $lists = $lists->get();
   
//     $totalTasks = $countLists->where('is_journal', 0)
//       ->where('is_correction', 0)
//       ->where('rework_check', 0)
//       ->count();
 
//     $inProgressCount = $countLists->where('status', 1)
//       ->count();
 
//     $notYetStartedCount = $countLists->where('status', 0)
//       ->count();
 
//     $completedCount = $countLists->where('status', 3)
//       ->count();
 
//     $qcVerifiedCount = $countLists->where('status', 4)
//       ->count();
 
//     $correctionCount = $countLists->where('is_journal', 0)
//       ->where('is_correction', 1)
//       ->where('rework_check', 0)
//       ->count();
 
//     $reworkCount = $countLists->where('is_journal', 0)
//       ->where('is_correction', 0)
//       ->where('rework_check', 1)
//       ->count();
 
//     $journalCount = $countLists->where('is_journal', 1)
//       ->where('is_correction', 0)
//       ->where('rework_check', 0)
//       ->count();
 
//     foreach ($lists as $list) {
//       $variantVariableIds = json_decode($list->variant_variable_ids, true);
 
//       $variantName = '';
//       $variableName = '';
 
//       if (is_array($variantVariableIds)) {
//         foreach ($variantVariableIds as $data) {
//           $variant = DB::table('et_manage_product_variant')->where('sno', $data['variant_id'])->first();
//           $variable = DB::table('et_manage_product_variable')->where('sno', $data['variable_id'])->first();
 
//           if ($variant) {
//             $variantName = $variant->product_variant_name ?? '';
//           }
 
//           if ($variable) {
//             $variableName = $variable->variable_name ?? '';
//           }
//         }
//       }
 
//       $year = date('Y', strtotime($list->created_at));
//       $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
//       $list->formatted_service_id = "SR-{$id}/{$year}";
 
//       $list->variant_name = $variantName;
//       $list->variable_name = $variableName;
//     }
 
//     $staffs = DB::table('et_staff')
//       ->where('sno', $user_id)
//       ->first();
 
//     if ($staffs->department_id == 2  && $staffs->role_id == 15) {
//       $isProductionStaff = 1;
//     } elseif ($staffs->department_id == 2) {
//       $isProductionStaff = 2;
//     } else {
//       $isProductionStaff = 0;
//     }
 
//     return view('content.production_management.manage_task.list', [
//       'lists' => $lists,
//       'isStaffs' => $isProductionStaff,
//       'total_tasks' => $totalTasks,
//       'inProgressCount' => $inProgressCount,
//       'notYetStartedCount' => $notYetStartedCount,
//       'completedCount' => $completedCount,
//       'qcVerifiedCount' => $qcVerifiedCount,
//       'correctionCount' => $correctionCount,
//       'reworkCount' => $reworkCount,
//       'journalCount' => $journalCount
//     ]);
//   }
  
//   public function index(Request $request)
//   {
//     $user_id = $request->user()->user_id;
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $statusFilter = $request->status_filter;
//     $search_filter = trim($request->input('search_filter', ''));
//     $offset = ($page - 1) * $perpage;
 
//     $today = now()->toDateString();
 
//     $lists = DB::table('et_daily_tasks')
//       ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_daily_tasks.service_id')
//       ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
//       ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_task', 'et_task.sno', 'et_daily_tasks.task_id')
//       ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
//       ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_daily_tasks.staff_id')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->select(
//         'et_daily_tasks.*',
//         'et_customer.cus_name',
//         'et_customer.customer_id',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_product.product_name',
//         'et_product_category.product_category_name',
//         'et_customer_services.variant_variable_ids',
//         'et_customer_services.pc_id',
//         'et_customer_services.cre_id',
//         'et_product_task.task_name',
//         'et_task.task_id as task_id',
//         'et_task.pages_percentage',
//         'et_task.working_hours',
//         'et_staff.staff_name',
//         'et_staff.staff_image',
//         'et_task.task_category',
//         'et_job_position.job_position_name'
//       )
//       // ->where(function ($query) use ($today) {
//       //   // 1️⃣ Today tasks (any status)
//       //   $query->whereDate('et_daily_tasks.task_date', $today)
 
//       //     // 2️⃣ OR past pending tasks
//       //     ->orWhere(function ($q) use ($today) {
//       //       $q->whereDate('et_daily_tasks.task_date', '<', $today)
//       //         ->whereIn('et_daily_tasks.status', [0, 1, 3]);
//       //     });
//       // })
//       ->where('et_daily_tasks.status', '!=', 2)
//       ->orderBy('et_daily_tasks.task_date', 'desc');
// /*
//     |--------------------------------------------------------------------------
//     | Search Filter
//     |--------------------------------------------------------------------------
//     */
 
//     if ($search_filter !== '') {
//         $lists->where(function ($q) use ($search_filter) {
 
//             $search = '%' . $search_filter . '%';
 
//             $q->where('et_customer.cus_name', 'LIKE', $search)
//                 ->orWhere('et_customer.cus_mobile', 'LIKE', $search)
//                 ->orWhere('et_customer.cus_email_id', 'LIKE', $search)
//                 ->orWhere('et_staff.staff_name', 'LIKE', $search)
//                 ->orWhere('et_staff.nick_name', 'LIKE', $search)
//                 ->orWhere('et_customer.customer_id', 'LIKE', $search)
//                 ->orWhere('et_task.task_id', 'LIKE', $search);
//         });
//     }
 
//     if (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'view_self_manage_task')) {
//       // User can only view their own data
//       $userRole = auth()->user()->role_id;
 
//       if ($userRole == 32 || $userRole == 36) {
//         $lists = $lists->where('et_daily_tasks.staff_id', $user_id);
//       } elseif ($userRole == 15) {
//         $lists = $lists->where('et_customer_services.pc_id', $user_id);
//       }
//     } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'global_manage_task')) {
//       // User can view all data — no extra filter needed
//       $lists = $lists;
//     } else {
//       // No permission
//       abort(403, 'Unauthorized');
//     }
//     $countQuery = clone $lists;
//     $countLists = $countQuery->get();
//     $totalTasks = $countLists->where('is_journal', 0)
//       ->where('is_correction', 0)
//       ->where('rework_check', 0)
//       ->count();
 
//     $inProgressCount = $countLists->where('status', 1)
//       ->count();
 
//     $notYetStartedCount = $countLists->where('status', 0)
//       ->count();
 
//     $completedCount = $countLists->where('status', 3)
//       ->count();
 
//     $qcVerifiedCount = $countLists->where('status', 4)
//       ->count();
 
//     $correctionCount = $countLists->where('is_journal', 0)
//       ->where('is_correction', 1)
//       ->where('rework_check', 0)
//       ->count();
 
//     $reworkCount = $countLists->where('is_journal', 0)
//       ->where('is_correction', 0)
//       ->where('rework_check', 1)
//       ->count();
 
//     $journalCount = $countLists->where('is_journal', 1)
//       ->where('is_correction', 0)
//       ->where('rework_check', 0)
//       ->count();
//     if ($statusFilter != '') {
 
//       switch ($statusFilter) {
 
//           case 'total':
//               $lists->where('et_daily_tasks.is_journal', 0)
//                     ->where('et_daily_tasks.is_correction', 0)
//                     ->where('et_daily_tasks.rework_check', 0);
//               break;
 
//           case 'not_started':
//               $lists->where('et_daily_tasks.status', 0);
//               break;
 
//           case 'in_progress':
//               $lists->where('et_daily_tasks.status', 1);
//               break;
 
//           case 'completed':
//               $lists->where('et_daily_tasks.status', 3);
//               break;
 
//           case 'qc_verified':
//               $lists->where('et_daily_tasks.status', 4);
//               break;
 
//           case 'correction':
//               $lists->where('et_daily_tasks.is_journal', 0)
//                     ->where('et_daily_tasks.is_correction', 1)
//                     ->where('et_daily_tasks.rework_check', 0);
//               break;
 
//           case 'rework':
//               $lists->where('et_daily_tasks.is_journal', 0)
//                     ->where('et_daily_tasks.is_correction', 0)
//                     ->where('et_daily_tasks.rework_check', 1);
//               break;
 
//           case 'journal':
//               $lists->where('et_daily_tasks.is_journal', 1)
//                     ->where('et_daily_tasks.is_correction', 0)
//                     ->where('et_daily_tasks.rework_check', 0);
//               break;
//       }
//     }
//     // $lists = $lists->get();
//     $lists = $lists
//         ->orderBy('et_daily_tasks.task_date', 'desc')
//         ->orderBy('et_daily_tasks.sno', 'desc')
//         ->paginate($perpage)
//         ->withQueryString();
//     foreach ($lists as $list) {
//       $variantVariableIds = json_decode($list->variant_variable_ids, true);
 
//       $variantName = '';
//       $variableName = '';
 
//       if (is_array($variantVariableIds)) {
//         foreach ($variantVariableIds as $data) {
//           $variant = DB::table('et_manage_product_variant')->where('sno', $data['variant_id'])->first();
//           $variable = DB::table('et_manage_product_variable')->where('sno', $data['variable_id'])->first();
 
//           if ($variant) {
//             $variantName = $variant->product_variant_name ?? '';
//           }
 
//           if ($variable) {
//             $variableName = $variable->variable_name ?? '';
//           }
//         }
//       }
 
//       $year = date('Y', strtotime($list->created_at));
//       $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
//       $list->formatted_service_id = "SR-{$id}/{$year}";
 
//       $list->variant_name = $variantName;
//       $list->variable_name = $variableName;
//     }
 
//     $staffs = DB::table('et_staff')
//       ->where('sno', $user_id)
//       ->first();
 
//     if ($staffs->department_id == 2  && $staffs->role_id == 15) {
//       $isProductionStaff = 1;
//     } elseif ($staffs->department_id == 2) {
//       $isProductionStaff = 2;
//     } else {
//       $isProductionStaff = 0;
//     }
 
//     return view('content.production_management.manage_task.list', [
//       'lists' => $lists,
//       'isStaffs' => $isProductionStaff,
//       'total_tasks' => $totalTasks,
//       'inProgressCount' => $inProgressCount,
//       'notYetStartedCount' => $notYetStartedCount,
//       'completedCount' => $completedCount,
//       'qcVerifiedCount' => $qcVerifiedCount,
//       'correctionCount' => $correctionCount,
//       'reworkCount' => $reworkCount,
//       'journalCount' => $journalCount,
//       'perpage'=>$perpage,
//       'search_filter'=>$search_filter,
//     ]);
//   }
  
  public function index(Request $request)
{
    $user_id = $request->user()->user_id;
 
    $page = (int) $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $statusFilter = $request->input('status_filter', '');
    $search_filter = trim($request->input('search_filter', ''));
 
    $today = now()->toDateString();
 
    /*
    |--------------------------------------------------------------------------
    | Base Query
    |--------------------------------------------------------------------------
    */
 
    $query = DB::table('et_daily_tasks')
        ->leftJoin(
            'et_customer_services',
            'et_customer_services.sno',
            '=',
            'et_daily_tasks.service_id'
        )
        ->leftJoin(
            'et_customer',
            'et_customer.sno',
            '=',
            'et_customer_services.customer_id'
        )
        ->leftJoin(
            'et_product',
            'et_customer_services.product_id',
            '=',
            'et_product.sno'
        )
        ->leftJoin(
            'et_product_category',
            'et_product.product_category_id',
            '=',
            'et_product_category.sno'
        )
        ->leftJoin(
            'et_task',
            'et_task.sno',
            '=',
            'et_daily_tasks.task_id'
        )
        ->leftJoin(
            'et_product_task',
            'et_product_task.sno',
            '=',
            'et_task.task_name'
        )
        ->leftJoin(
            'et_staff',
            'et_staff.sno',
            '=',
            'et_daily_tasks.staff_id'
        )
        ->leftJoin(
            'et_job_position',
            'et_job_position.sno',
            '=',
            'et_staff.position_role'
        )
        ->select(
            'et_daily_tasks.*',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_customer.cus_mobile',
            'et_customer.cus_email_id',
            'et_product.product_name',
            'et_product_category.product_category_name',
            'et_customer_services.variant_variable_ids',
            'et_customer_services.pc_id',
            'et_customer_services.cre_id',
            'et_product_task.task_name',
            'et_task.task_id as task_id',
            'et_task.pages_percentage',
            'et_task.working_hours',
            'et_task.task_category',
            'et_job_position.job_position_name'
        )
        ->where('et_daily_tasks.status', '!=', 2);
 
 
    /*
    |--------------------------------------------------------------------------
    | Search Filter
    |--------------------------------------------------------------------------
    */
 
    if ($search_filter !== '') {
        $query->where(function ($q) use ($search_filter) {
 
            $search = '%' . $search_filter . '%';
 
            $q->where('et_customer.cus_name', 'LIKE', $search)
                ->orWhere('et_customer.cus_mobile', 'LIKE', $search)
                ->orWhere('et_customer.cus_email_id', 'LIKE', $search)
                ->orWhere('et_staff.staff_name', 'LIKE', $search)
                ->orWhere('et_staff.nick_name', 'LIKE', $search)
                ->orWhere('et_customer.customer_id', 'LIKE', $search)
                ->orWhere('et_task.task_id', 'LIKE', $search);
        });
    }
 
 
    /*
    |--------------------------------------------------------------------------
    | Permission Filter
    |--------------------------------------------------------------------------
    */
 
    if (
        auth()->user()->hasPermissionradio(
            'Production Management',
            'Manage Task',
            'view_self_manage_task'
        )
    ) {
 
        $userRole = auth()->user()->role_id;
 
        if ($userRole == 32 || $userRole == 36) {
 
            $query->where(function ($q) use ($user_id) {
 
                $q->where('et_daily_tasks.staff_id', $user_id)
                    ->orWhereJsonContains(
                        'et_daily_tasks.staff_id',
                        (string) $user_id
                    )
                    ->orWhereJsonContains(
                        'et_daily_tasks.staff_id',
                        (int) $user_id
                    );
            });
 
        } elseif ($userRole == 15) {
 
            $query->where(
                'et_customer_services.pc_id',
                $user_id
            );
        }
 
    } elseif (
        auth()->user()->hasPermissionradio(
            'Production Management',
            'Manage Task',
            'global_manage_task'
        )
    ) {
 
        // Global permission - no additional filter
 
    } else {
 
        abort(403, 'Unauthorized');
    }
 
 
 
 
    /*
    |--------------------------------------------------------------------------
    | Counts
    |--------------------------------------------------------------------------
    |
    | Clone BEFORE pagination.
    |
    */
 
    $countQuery = clone $query;
 
    $countLists = $countQuery->get();
 
 
   
 
 
    /*
    |--------------------------------------------------------------------------
    | Counts
    |--------------------------------------------------------------------------
    */
 
    $totalTasks = $countLists
        ->where('is_journal', 0)
        ->where('is_correction', 0)
        ->where('rework_check', 0)
        ->count();
 
    $inProgressCount = $countLists
        ->where('status', 1)
        ->count();
 
    $notYetStartedCount = $countLists
        ->where('status', 0)
        ->count();
 
    $completedCount = $countLists
        ->where('status', 3)
        ->count();
 
    $qcVerifiedCount = $countLists
        ->where('status', 4)
        ->count();
 
    $correctionCount = $countLists
        ->where('is_journal', 0)
        ->where('is_correction', 1)
        ->where('rework_check', 0)
        ->count();
 
    $reworkCount = $countLists
        ->where('is_journal', 0)
        ->where('is_correction', 0)
        ->where('rework_check', 1)
        ->count();
 
    $journalCount = $countLists
        ->where('is_journal', 1)
        ->where('is_correction', 0)
        ->where('rework_check', 0)
        ->count();
 
   
   
    /*
    |--------------------------------------------------------------------------
    | Status Filter
    |--------------------------------------------------------------------------
    */
 
    if ($statusFilter !== '') {
 
        switch ($statusFilter) {
 
            case 'total':
 
                $query->where('et_daily_tasks.is_journal', 0)
                    ->where('et_daily_tasks.is_correction', 0)
                    ->where('et_daily_tasks.rework_check', 0);
 
                break;
 
 
            case 'not_started':
 
                $query->where('et_daily_tasks.status', 0);
 
                break;
 
 
            case 'in_progress':
 
                $query->where('et_daily_tasks.status', 1);
 
                break;
 
 
            case 'completed':
 
                $query->where('et_daily_tasks.status', 3);
 
                break;
 
 
            case 'qc_verified':
 
                $query->where('et_daily_tasks.status', 4);
 
                break;
 
 
            case 'correction':
 
                $query->where('et_daily_tasks.is_journal', 0)
                    ->where('et_daily_tasks.is_correction', 1)
                    ->where('et_daily_tasks.rework_check', 0);
 
                break;
 
 
            case 'rework':
 
                $query->where('et_daily_tasks.is_journal', 0)
                    ->where('et_daily_tasks.is_correction', 0)
                    ->where('et_daily_tasks.rework_check', 1);
 
                break;
 
 
            case 'journal':
 
                $query->where('et_daily_tasks.is_journal', 1)
                    ->where('et_daily_tasks.is_correction', 0)
                    ->where('et_daily_tasks.rework_check', 0);
 
                break;
        }
    }
    /*
    |--------------------------------------------------------------------------
    | Pagination
    |--------------------------------------------------------------------------
    |
    | Pagination MUST happen after all where conditions.
    |
    */
 
    $lists = $query
        ->orderBy('et_daily_tasks.task_date', 'desc')
        ->orderBy('et_daily_tasks.sno', 'desc')
        ->paginate($perpage)
        ->withQueryString();
 
    /*
    |--------------------------------------------------------------------------
    | Process Paginated Records
    |--------------------------------------------------------------------------
    */
 
    foreach ($lists as $list) {
 
        $list->user_id = $user_id;
 
        $staffIds = [];
 
        if (is_string($list->staff_id)) {
 
            $decodedStaffIds = json_decode(
                $list->staff_id,
                true
            );
 
            if (
                json_last_error() === JSON_ERROR_NONE &&
                is_array($decodedStaffIds)
            ) {
                $staffIds = $decodedStaffIds;
            } else {
                $staffIds = [$list->staff_id];
            }
 
        } elseif (is_array($list->staff_id)) {
 
            $staffIds = $list->staff_id;
 
        } elseif (!empty($list->staff_id)) {
 
            $staffIds = [$list->staff_id];
        }
 
 
        /*
        |--------------------------------------------------------------------------
        | Clean Staff IDs
        |--------------------------------------------------------------------------
        */
 
        $staffIds = collect($staffIds)
            ->filter(fn ($id) => !empty($id))
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values()
            ->toArray();
 
 
        /*
        |--------------------------------------------------------------------------
        | Staff Details
        |--------------------------------------------------------------------------
        */
 
        $list->staff_details = DB::table('et_staff')
            ->leftJoin(
                'et_job_position',
                'et_job_position.sno',
                '=',
                'et_staff.position_role'
            )
            ->whereIn('et_staff.sno', $staffIds)
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_job_position.job_position_name'
            )
            ->get();
 
 
        /*
        |--------------------------------------------------------------------------
        | Variant / Variable
        |--------------------------------------------------------------------------
        */
 
        $variantVariableIds = json_decode(
            $list->variant_variable_ids,
            true
        );
 
        $variantName = '';
        $variableName = '';
 
        if (is_array($variantVariableIds)) {
 
            foreach ($variantVariableIds as $data) {
 
                if (
                    !isset($data['variant_id']) ||
                    !isset($data['variable_id'])
                ) {
                    continue;
                }
 
                $variant = DB::table('et_manage_product_variant')
                    ->where('sno', $data['variant_id'])
                    ->first();
 
                $variable = DB::table('et_manage_product_variable')
                    ->where('sno', $data['variable_id'])
                    ->first();
 
                if ($variant) {
                    $variantName =
                        $variant->product_variant_name ?? '';
                }
 
                if ($variable) {
                    $variableName =
                        $variable->variable_name ?? '';
                }
            }
        }
 
 
        /*
        |--------------------------------------------------------------------------
        | Formatted Service ID
        |--------------------------------------------------------------------------
        */
 
        $year = date(
            'Y',
            strtotime($list->created_at)
        );
 
        $id = str_pad(
            $list->service_id,
            5,
            '0',
            STR_PAD_LEFT
        );
 
        $list->formatted_service_id =
            "SR-{$id}/{$year}";
 
        $list->variant_name = $variantName;
        $list->variable_name = $variableName;
    }
 
 
    /*
    |--------------------------------------------------------------------------
    | Current Staff
    |--------------------------------------------------------------------------
    */
 
    $staffs = DB::table('et_staff')
        ->where('sno', $user_id)
        ->first();
 
    if (
        $staffs &&
        $staffs->department_id == 2 &&
        $staffs->role_id == 15
    ) {
 
        $isProductionStaff = 1;
 
    } elseif (
        $staffs &&
        $staffs->department_id == 2
    ) {
 
        $isProductionStaff = 2;
 
    } else {
 
        $isProductionStaff = 0;
    }
 
 
    /*
    |--------------------------------------------------------------------------
    | Return View
    |--------------------------------------------------------------------------
    */
 
    return view(
        'content.production_management.manage_task.list',
        [
            'lists' => $lists,
            'isStaffs' => $isProductionStaff,
            'total_tasks' => $totalTasks,
            'inProgressCount' => $inProgressCount,
            'notYetStartedCount' => $notYetStartedCount,
            'completedCount' => $completedCount,
            'qcVerifiedCount' => $qcVerifiedCount,
            'correctionCount' => $correctionCount,
            'reworkCount' => $reworkCount,
            'journalCount' => $journalCount,
            'perpage' => $perpage,
            'search_filter'=>$search_filter,
        ]
    );
}

//   public function index_ajax(Request $request)
//   {
//     $user_id = $request->user()->user_id;
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;

//     $today = now()->toDateString();

//     $lists = DB::table('et_daily_tasks')
//       ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_daily_tasks.service_id')
//       ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
//       ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_task', 'et_task.sno', 'et_daily_tasks.task_id')
//       ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
//       ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_daily_tasks.staff_id')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->select(
//         'et_daily_tasks.*',
//         'et_customer.cus_name',
//         'et_customer.customer_id',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_product.product_name',
//         'et_product_category.product_category_name',
//         'et_customer_services.variant_variable_ids',
//         'et_customer_services.pc_id',
//         'et_customer_services.cre_id',
//         'et_product_task.task_name',
//         'et_task.task_id as task_id',
//         'et_task.pages_percentage',
//         'et_task.working_hours',
//         'et_staff.staff_name',
//         'et_staff.staff_image',
//         'et_task.task_category',
//         'et_job_position.job_position_name'
//       )
//       // ->where(function ($query) use ($today) {
//       //   // 1️⃣ Today tasks (any status)
//       //   $query->whereDate('et_daily_tasks.task_date', $today)

//       //     // 2️⃣ OR past pending tasks
//       //     ->orWhere(function ($q) use ($today) {
//       //       $q->whereDate('et_daily_tasks.task_date', '<', $today)
//       //         ->whereIn('et_daily_tasks.status', [0, 1, 3]);
//       //     });
//       // })
//       ->where('et_daily_tasks.status', '!=', 2)
//       ->orderBy('et_daily_tasks.task_date', 'desc');

//     if (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'view_self_manage_task')) {
//       // User can only view their own data
//       $userRole = auth()->user()->role_id;

//       if ($userRole == 32 || $userRole == 36) {
//         $lists = $lists->where('et_daily_tasks.staff_id', $user_id);
//       } elseif ($userRole == 15) {
//         $lists = $lists->where('et_customer_services.pc_id', $user_id);
//       }
//     } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'global_manage_task')) {
//       // User can view all data — no extra filter needed
//       $lists = $lists;
//     } else {
//       // No permission
//       abort(403, 'Unauthorized');
//     }

//     $lists = $lists->get();

//     $totalTasks = $lists->where('is_journal', 0)
//       ->where('is_correction', 0)
//       ->where('rework_check', 0)
//       ->count();

//     $inProgressCount = $lists->where('status', 1)
//       ->count();

//     $notYetStartedCount = $lists->where('status', 0)
//       ->count();

//     $completedCount = $lists->where('status', 3)
//       ->count();

//     $qcVerifiedCount = $lists->where('status', 4)
//       ->count();

//     $correctionCount = $lists->where('is_journal', 0)
//       ->where('is_correction', 1)
//       ->where('rework_check', 0)
//       ->count();

//     $reworkCount = $lists->where('is_journal', 0)
//       ->where('is_correction', 0)
//       ->where('rework_check', 1)
//       ->count();

//     $journalCount = $lists->where('is_journal', 1)
//       ->where('is_correction', 0)
//       ->where('rework_check', 0)
//       ->count();

//     foreach ($lists as $list) {
//       $variantVariableIds = json_decode($list->variant_variable_ids, true);

//       $variantName = '';
//       $variableName = '';

//       if (is_array($variantVariableIds)) {
//         foreach ($variantVariableIds as $data) {
//           $variant = DB::table('et_manage_product_variant')->where('sno', $data['variant_id'])->first();
//           $variable = DB::table('et_manage_product_variable')->where('sno', $data['variable_id'])->first();

//           if ($variant) {
//             $variantName = $variant->product_variant_name ?? '';
//           }

//           if ($variable) {
//             $variableName = $variable->variable_name ?? '';
//           }
//         }
//       }

//       $year = date('Y', strtotime($list->created_at));
//       $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
//       $list->formatted_service_id = "SR-{$id}/{$year}";

//       $list->variant_name = $variantName;
//       $list->variable_name = $variableName;
//     }

//     $staffs = DB::table('et_staff')
//       ->where('sno', $user_id)
//       ->first();

//     if ($staffs->department_id == 2  && $staffs->role_id == 15) {
//       $isProductionStaff = 1;
//     } elseif ($staffs->department_id == 2) {
//       $isProductionStaff = 2;
//     } else {
//       $isProductionStaff = 0;
//     }

//     $html = view('content.production_management.manage_task.list_ajax', [
//       'lists' => $lists,
//       'isStaffs' => $isProductionStaff
//     ])->render();

//     return response()->json([
//       'data' => $html
//     ]);
//   }

    public function index_ajax(Request $request)
  {
    $user_id = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = trim($request->input('search_filter', ''));
 
 
    $today = now()->toDateString();
 
    $lists = DB::table('et_daily_tasks')
      ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_daily_tasks.service_id')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->leftJoin('et_task', 'et_task.sno', 'et_daily_tasks.task_id')
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_daily_tasks.staff_id')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
      ->select(
        'et_daily_tasks.*',
        'et_customer.cus_name',
        'et_customer.customer_id',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_product.product_name',
        'et_product_category.product_category_name',
        'et_customer_services.variant_variable_ids',
        'et_customer_services.pc_id',
        'et_customer_services.cre_id',
        'et_product_task.task_name',
        'et_task.task_id as task_id',
        'et_task.pages_percentage',
        'et_task.working_hours',
        'et_staff.staff_name',
        'et_staff.staff_image',
        'et_task.task_category',
        'et_job_position.job_position_name'
      )
      // ->where(function ($query) use ($today) {
      //   // 1️⃣ Today tasks (any status)
      //   $query->whereDate('et_daily_tasks.task_date', $today)
 
      //     // 2️⃣ OR past pending tasks
      //     ->orWhere(function ($q) use ($today) {
      //       $q->whereDate('et_daily_tasks.task_date', '<', $today)
      //         ->whereIn('et_daily_tasks.status', [0, 1, 3]);
      //     });
      // })
      ->where('et_daily_tasks.status', '!=', 2)
      ->orderBy('et_daily_tasks.task_date', 'desc');
 
    if (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'view_self_manage_task')) {
      // User can only view their own data
      $userRole = auth()->user()->role_id;
 
      if ($userRole == 32 || $userRole == 36) {
        $lists = $lists->where(function ($query) use ($user_id) {
        $query->where('et_daily_tasks.staff_id', $user_id)
          ->orWhereJsonContains('et_daily_tasks.staff_id', (string) $user_id)
          ->orWhereJsonContains('et_daily_tasks.staff_id', (int) $user_id);
        });
      } elseif ($userRole == 15) {
        $lists = $lists->where('et_customer_services.pc_id', $user_id);
      }
    } elseif (auth()->user()->hasPermissionradio('Production Management', 'Manage Task', 'global_manage_task')) {
      // User can view all data — no extra filter needed
      $lists = $lists;
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }
 
    $lists = $lists->get();
 
    $totalTasks = $lists->where('is_journal', 0)
      ->where('is_correction', 0)
      ->where('rework_check', 0)
      ->count();
 
    $inProgressCount = $lists->where('status', 1)
      ->count();
 
    $notYetStartedCount = $lists->where('status', 0)
      ->count();
 
    $completedCount = $lists->where('status', 3)
      ->count();
 
    $qcVerifiedCount = $lists->where('status', 4)
      ->count();
 
    $correctionCount = $lists->where('is_journal', 0)
      ->where('is_correction', 1)
      ->where('rework_check', 0)
      ->count();
 
    $reworkCount = $lists->where('is_journal', 0)
      ->where('is_correction', 0)
      ->where('rework_check', 1)
      ->count();
 
    $journalCount = $lists->where('is_journal', 1)
      ->where('is_correction', 0)
      ->where('rework_check', 0)
      ->count();
 
    foreach ($lists as $list) {
 
    // adding user_id for $list
    $list->user_id=$user_id;
    $staffIds = [];
 
    if (is_string($list->staff_id)) {
        $decodedStaffIds = json_decode($list->staff_id, true);
 
        if (json_last_error() === JSON_ERROR_NONE && is_array($decodedStaffIds)) {
            $staffIds = $decodedStaffIds;
        } else {
            $staffIds = [$list->staff_id];
        }
    } elseif (is_array($list->staff_id)) {
        $staffIds = $list->staff_id;
    } elseif (!empty($list->staff_id)) {
        $staffIds = [$list->staff_id];
    }
 
    // Clean IDs
    $staffIds = collect($staffIds)
        ->filter(fn ($id) => !empty($id))
        ->map(fn ($id) => (int) $id)
        ->unique()
        ->values()
        ->toArray();
 
    // Get staff details
    $list->staff_details = DB::table('et_staff')
    ->leftJoin(
        'et_job_position',
        'et_job_position.sno',
        '=',
        'et_staff.position_role'
    )
    ->whereIn('et_staff.sno', $staffIds)
    ->select(
        'et_staff.sno',
        'et_staff.staff_name',
        'et_staff.staff_image',
        'et_staff.gender',
        'et_job_position.job_position_name'
    )
    ->get();
 
 
    // Existing variant logic
    $variantVariableIds = json_decode($list->variant_variable_ids, true);
 
    $variantName = '';
    $variableName = '';
 
    if (is_array($variantVariableIds)) {
        foreach ($variantVariableIds as $data) {
 
            $variant = DB::table('et_manage_product_variant')
                ->where('sno', $data['variant_id'])
                ->first();
 
            $variable = DB::table('et_manage_product_variable')
                ->where('sno', $data['variable_id'])
                ->first();
 
            if ($variant) {
                $variantName = $variant->product_variant_name ?? '';
            }
 
            if ($variable) {
                $variableName = $variable->variable_name ?? '';
            }
        }
    }
 
    $year = date('Y', strtotime($list->created_at));
    $id = str_pad($list->service_id, 5, '0', STR_PAD_LEFT);
 
    $list->formatted_service_id = "SR-{$id}/{$year}";
 
    $list->variant_name = $variantName;
    $list->variable_name = $variableName;
}
 
 
    $staffs = DB::table('et_staff')
      ->where('sno', $user_id)
      ->first();
 
    if ($staffs->department_id == 2  && $staffs->role_id == 15) {
      $isProductionStaff = 1;
    } elseif ($staffs->department_id == 2) {
      $isProductionStaff = 2;
    } else {
      $isProductionStaff = 0;
    }
 
    $html = view('content.production_management.manage_task.list_ajax', [
      'lists' => $lists,
      'isStaffs' => $isProductionStaff
    ])->render();
 
    return response()->json([
      'data' => $html
    ]);
  }
  
  public function Edit($id)
  {
    $data =  ManageTaskModel::select('et_task.*', 'et_customer_services.variant_variable_ids', 'et_customer_services.production_staffs_id', 'et_customer_services.product_id', 'et_customer_services.package_id', 'et_customer_services.product_package', 'et_customer.cus_name', 'et_customer.cus_mobile', 'et_customer.cus_email_id', 'et_customer.country_code', 'et_customer.customer_id AS cus_id', 'et_product.product_name', 'et_product_category.product_category_name')
      ->where('et_task.status', '!=', 2)
      ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->where('et_task.sno', $id)->first();

    // Decode staff IDs
    $staffIds = json_decode($data->production_staffs_id, true);
    if (!is_array($staffIds)) {
      $staffIds = explode(',', $data->production_staffs_id);
    }
    $staffIds = array_filter(array_map('intval', $staffIds));

    // Fetch staff
    $staffs = [];
    if (!empty($staffIds)) {
      $staffs = DB::table('et_staff')
        ->select('sno', 'staff_name', 'per_hour_cost')
        ->whereIn('sno', $staffIds)
        ->get();
    }

    // Attach to response
    $data->production_staffs = $staffs;

    if ($data->product_package == 1) {
      $variant_variable_data = json_decode($data->variant_variable_ids ?? '[]', true);

      $variant_name = '-';
      $variable_name = '-';
      $variable_id = 0;
      $variant_id = 0;

      // Loop through the variant_variable_data if it contains multiple variants/variables
      foreach ($variant_variable_data as $pair) {
        // Fetch variant and variable data
        $variant = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
        $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

        // If a variant or variable is found, assign them
        if ($variant) {
          $variant_id = $variant->sno;
          $variant_name = $variant->product_variant_name ?? '';
        }

        if ($variable) {
          $variable_id = $variable->sno;
          $variable_name = $variable->variable_name ?? '';
        }
      }
      $data->variant_name = $variant_name;
      $data->variable_name = $variable_name;
      // Fetch task list based on the variant and variable IDs
      $task_list = DB::table('et_product_task_mapping')
        ->leftJoin('et_product_task', 'et_product_task_mapping.sno', '=', 'et_product_task.map_id')
        ->where('et_product_task.product_id', $data->product_id)
        ->where('et_product_task_mapping.variant_id', $variant_id)
        ->where('et_product_task_mapping.variable_id', $variable_id)
        ->where('et_product_task_mapping.status', 0)
        ->get();
    } else {
      $packageProducts = DB::table('et_package_product')
        ->where('package_id', $data->package_id)
        ->where('status', 0)
        ->pluck('product_id');

      $variant_variable_data = json_decode($data->variant_variable_ids ?? '[]', true);

      $variant_name = '-';
      $variable_name = '-';
      $variable_id = 0;
      $variant_id = 0;

      // Loop through the variant_variable_data if it contains multiple variants/variables
      foreach ($variant_variable_data as $pair) {
        // Fetch variant and variable data
        $variant = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
        $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

        // If a variant or variable is found, assign them
        if ($variant) {
          $variant_id = $variant->sno;
          $variant_name = $variant->product_variant_name ?? '';
        }

        if ($variable) {
          $variable_id = $variable->sno;
          $variable_name = $variable->variable_name ?? '';
        }
      }
      $data->variant_name = $variant_name;
      $data->variable_name = $variable_name;
      // Fetch task list based on the variant and variable IDs
      $task_list = DB::table('et_product_task_mapping')
        ->leftJoin('et_product_task', 'et_product_task_mapping.sno', '=', 'et_product_task.map_id')
        ->where('et_product_task_mapping.variant_id', $variant_id)
        ->where('et_product_task_mapping.variable_id', $variable_id)
        ->whereIn('et_product_task_mapping.product_id', $packageProducts)
        ->where('et_product_task_mapping.status', 0)
        ->get();
    }
    $data->task_list = $task_list;

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Task not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Task fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Update_task(Request $request)
  {
    // return $request;
    $entity_id = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $edit_id   = $request->edit_id;

    $task_staff = $request->task_staffs ?? [];
    $staff_costs = [];

    foreach ($task_staff as $ts) {
      $staff_data = DB::table('et_staff')->where('sno', $ts)->first();
      $staff_costs[$ts] = $staff_data->per_hour_cost ?? 0;
    }

    $Add = ManageTaskModel::where('sno', $edit_id)->first();
    $Add->updated_by = $user_id;
    $Add->task_name  = $request->task_name;
    $Add->working_hours   = $request->workingHours;
    $Add->start_date_time = date('Y-m-d H:i:s', strtotime($request->task_st_dt_tm));
    $Add->end_date_time   = date('Y-m-d H:i:s', strtotime($request->assigned_end_date_hidden));
    $Add->per_hour_cost   = $request->task_per_hr_task;
    $Add->assign_staffs   = json_encode($request->task_staffs);
    $Add->staff_per_hour_cost   = json_encode($staff_costs);
    $Add->task_check_list_ids = json_encode($request->task_check_list);
    $Add->task_desc = $request->task_desc;
    $Add->billable = $request->billablle_task ?? 0;
    $Add->save();

    if ($Add) {
      $task_checklist = $request->input('task_check_list'); // array of submitted checklist IDs
      $existing = ManageTaskChecklistModel::where('task_id', $Add->sno)->where('status', 0)->get(); // fetch all current entries for this task

      $existing_ids = $existing->pluck('task_check_list_id')->toArray(); // existing checklist IDs
      $new_ids = $task_checklist ?? []; // ensure it's an array

      // 1. Insert new checklist items if not already present
      foreach ($new_ids as $task_ch_id) {
        if (!in_array($task_ch_id, $existing_ids)) {
          $Add_list = new ManageTaskChecklistModel();
          $Add_list->task_id = $Add->sno;
          $Add_list->task_check_list_id = $task_ch_id;
          $Add_list->created_by = $user_id;
          $Add_list->updated_by = $user_id;
          $Add_list->status = 0;
          $Add_list->save();
        }
      }

      // 2. Update status to 2 for checklist items that were removed
      $to_deactivate = array_diff($existing_ids, $new_ids);

      if (!empty($to_deactivate)) {
        ManageTaskChecklistModel::where('task_id', $Add->sno)
          ->whereIn('task_check_list_id', $to_deactivate)
          ->update(['status' => 2, 'updated_by' => $user_id]);
      }


      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Task Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Task!'
      ]);
    }
    return redirect()->back();
  }
  public function status_change_old(Request $request)
  {
    $sno = $request->sno;
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $status = $request->status;
    $checklist = $request->checklist ?? [];
    $delivery = $request->delivery ?? [];
    $reason = $request->reason;

    $qcCheckData = (int)$status === 6 ? json_encode($checklist) : null;
    $deliveryCheckData = (int)$status === 7 ? json_encode($delivery) : null;

    if ($status == 6) {
      $score = DB::table('et_task')->where('sno', $sno)->first();

      if ($score && !empty($score->assign_staffs)) {
        $staffIds = json_decode($score->assign_staffs, true);

        foreach ($staffIds as $staffId) {
          $helper = new \App\Helpers\Helpers();

          if ($score->rework_check == 0) {
            // No rework: award points
            $pointsData = $helper->get_points_by_id(25); // Assuming ID 25 is for the 10 points
            $point = $pointsData ? $pointsData->points : 0;
            $reason = $pointsData ? $pointsData->points_name : '';

            $newPoints = new StaffpointsModel();
            $newPoints->branch_id = $branch_id;
            $newPoints->staff_id = $staffId;
            $newPoints->points_by = $sno;
            $newPoints->points_id = 25;
            $newPoints->points = $point;
            $newPoints->reason = $reason;
            $newPoints->production_check = 1;
            $newPoints->task_id = $sno;
            $newPoints->save();
          } else {
            // Rework exists: deduct 5 points per rework
            $pointsData = $helper->get_points_by_id(26); // Assuming ID 25 is for the 10 points
            $point = $pointsData ? $pointsData->points : 0;
            $reason = $pointsData ? $pointsData->points_name : '';

            $penaltyPoints = new StaffpointsModel();
            $penaltyPoints->branch_id = $branch_id;
            $penaltyPoints->staff_id = $staffId;
            $penaltyPoints->points_by = $sno;
            $penaltyPoints->points_id = 26; // Or use a specific ID for penalty if available
            $penaltyPoints->points = $point; // Negative points
            $penaltyPoints->reason = $reason;
            $penaltyPoints->production_check = 1;
            $penaltyPoints->task_id = $sno;
            $penaltyPoints->save();
          }
        }
      }
    }

    if ($status == 8) {
      $staffScore = DB::table('et_task')->where('sno', $sno)->first();

      if ($staffScore && !empty($staffScore->assign_staffs)) {
        $scoreStaffs = json_decode($staffScore->assign_staffs, true);

        foreach ($scoreStaffs as $staffId) {
          // Sum all points for this staff on this task
          $totalPoints = StaffpointsModel::where('task_id', $sno)
            ->where('staff_id', $staffId)
            ->sum('points');

          $staff = StaffModel::where('sno', $staffId)->first();

          if ($staff) {
            $staff->avaiable_points = $totalPoints;
            $staff->save();
          }
        }
      }
    }

    if ($status == 10) {
      DB::table('et_task')
        ->where('sno', $sno)
        ->update([
          'rework_reason' => $reason,
          'task_completed_by' => 0,
          'task_completed_date_time' => null,
          'rework_check' => DB::raw('rework_check + 1'),
          'status' => 1
        ]);

      $rework = new ReworkReasonModel();
      $rework->branch_id = $branch_id;
      $rework->task_id = $sno;
      $rework->rework_reason = $reason;
      $rework->created_by = $user_id;
      $rework->updated_by = $user_id;
      $rework->save();

      return response()->json([
        'status' => true,
        'message' => 'Status Changed To Rework!',
        'data' => []
      ]);
    }

    if ($status == 5) {
      $task = DB::table('et_task')->where('sno', $sno)->first();

      if ($task && !empty($task->assign_staffs)) {
        $assignedStaffs = json_decode($task->assign_staffs, true);

        foreach ($assignedStaffs as $staff_id) {
          $taskLog = TaskLogModel::where('task_id', $sno)
            ->where('staff_id', $staff_id)
            ->where('status', 0) // running timers only
            ->latest('sno')
            ->first();

          if ($taskLog) {
            $taskLog->end_time = now();

            $durationSeconds = strtotime($taskLog->end_time) - strtotime($taskLog->start_time);
            $hours = floor($durationSeconds / 3600);
            $minutes = floor(($durationSeconds % 3600) / 60);
            $seconds = $durationSeconds % 60;
            $taskLog->duration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

            $taskLog->status = 1; // stopped
            $taskLog->updated_by = $staff_id;
            $taskLog->save();
          }
        }
      }
    }


    $update = DB::table('et_task')
      ->where('sno', $sno)
      ->update([
        'status' => $status,
        'qc_check' => $qcCheckData,
        'delivery_check' => $deliveryCheckData
      ]);

    return response()->json([
      'status' => true,
      'message' => 'Task Updated successfully.',
      'data' => $update
    ]);
  }

  public function status_change(Request $request)
  {
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $task_id = $request->task_id;
    $new_status = $request->status;

    $task = DailyTaskModel::where('sno', $task_id)->where('status', '!=', 2)->first();

    if (!$task) {
      return response([
        'status' => 404,
        'message' => 'Task not found or not eligible for status change',
        'data' => null
      ], 404);
    }

    DB::transaction(function () use ($request, $task, $user_id, $branch_id) {
      switch ($request->status) {
        case 'approved':
          $this->processApprovedStatus($request, $task, $user_id);
          break;

        case 'rework':
          $this->processReworkStatus($request, $task, $user_id, $branch_id);
          break;

        case 'rejected':
          $this->processRejectStatus($request, $task, $user_id, $branch_id);
          break;
      }
    });

    return response([
      'status' => 200,
      'message' => 'Task Updated Successfully!',
      'data' => null
    ], 200);
  }

//   private function processApprovedStatus($request, $task, $user_id)
//   {
//     $submittedItems = $request->qc_checklist;
//     $task->update([
//       'qc_checklist' => json_encode($submittedItems, true),
//       'status' => 4,
//       'updated_by' => $user_id
//     ]);
//   }

    // private function processApprovedStatus($request, $task, $user_id)
    //       {
    //           $helper = new \App\Helpers\Helpers();
    //         $submittedItems = $request->qc_checklist;
    //         $task->update([
    //           'qc_checklist' => json_encode($submittedItems, true),
    //           'status' => 4,
    //           'updated_by' => $user_id
    //         ]);
    //     $ontimeTask = false;
    //     if (!empty($task->task_date) && !empty($task->task_completed_date_time)) {
    //         $ontimeTask = \Carbon\Carbon::parse($task->task_completed_date_time)
    //             ->isBefore(
    //                 \Carbon\Carbon::parse($task->task_date)->endOfDay()
    //             );
    //     }
    //       $pointsData = $helper->get_points_by_id(25); // Assuming ID 25 is for the 10 points
    //                 $point = $pointsData ? $pointsData->points : 0;
    //                 $reason = $pointsData ? $pointsData->points_name : '';
         
    //       $onTimePoints= $ontimeTask ? 2 : (-5);
               
    //   }
  
  private function processApprovedStatus($request, $task, $user_id)
  {
      $helper = new \App\Helpers\Helpers();
    $submittedItems = $request->qc_checklist;
   
      $task->update([
         
        'qc_verified_at'=> now(),
          'status' => 4,
          'updated_by' => $user_id
        ]);
    $ontimeTask = false;
    if (!empty($task->task_date) && !empty($task->task_completed_date_time)) {
        $ontimeTask = \Carbon\Carbon::parse($task->task_completed_date_time)
            ->isBefore(
                \Carbon\Carbon::parse($task->task_date)->endOfDay()
            );
    }
       $pointsData = $helper->get_points_by_id(25); // Assuming ID 25 is for the 10 points
                $point = $pointsData ? $pointsData->points : 0;
                $reason = $pointsData ? $pointsData->points_name : '';
     
      $onTimePoints= $ontimeTask ? 2 : (-5);
       
  }
  
//   private function processReworkStatus($request, $task, $user_id, $branch_id)
//   {
//     $rework_reason = $request->rework_reason;
//     $task->update([
//       'status' => 5,
//       'updated_by' => $user_id
//     ]);

//     DailyTaskModel::create([
//       'service_id'       => $task->service_id,
//       'task_id'          => $task->task_id,
//       'staff_id' => $task->staff_id,
//       'task_date'        => now(),
//       'min_page_or_per'  => 0,
//       'max_page_or_per'  => $task->max_page_or_per,
//       'task_hours'       => $task->task_hours,
//       'rework_reason'    => $request->rework_reason,
//       'is_correction'    => 1,
//       'created_by' => $user_id,
//       'updated_by' => $user_id
//     ]);

//     // Notification
//     $task_details = DB::table('et_task')->where('sno', $task->task_id)->first();
//     $notificationData = [
//       'branch_id' => $branch_id,
//       'notification_content' =>   '<div class="d-flex align-items-center">
//                                                 <div class="me-3">
//                                                     <span class="badge bg-danger">
//                                                         <i class="mdi mdi-calendar-remove fs-3 "></i>
//                                                     </span>
//                                                 </div>
//                                                 <div class="me-2">
//                                                     <a href="javascript:;" class="fs-7 text-primary fw-bold">Rework Task</a>
//                                                     <div class="text-secondary fs-8  fw-bold">' . $task_details->task_id . '</div>
//                                                 </div>
//                                             </div>',
//       'who' => $task->staff_id,
//       'created_by' => $user_id,
//       'updated_by' => $user_id,
//       'status' => 0
//     ];
//     $notificationtype = 'Requirement';
//     $newNotification = new \App\Helpers\Helpers();
//     $newNotification->createNotificationAssessment($notificationData, $notificationtype, $task->staff_id);
//   }


private function processReworkStatus($request, $task, $user_id, $branch_id)
  {
    $rework_reason = $request->rework_reason;
    $helper = new \App\Helpers\Helpers();
   
    DailyTaskModel::create([
      'service_id'       => $task->service_id,
      'task_id'          => $task->task_id,
      'staff_id' => $task->staff_id,
      'task_date'        => now(),
      'min_page_or_per'  => 0,
      'max_page_or_per'  => $task->max_page_or_per,
      'task_hours'       => $task->task_hours,
      'rework_reason'    => $request->rework_reason,
      'is_correction'    => 1,
      'rework_check'    =>  1,
      'created_by' => $user_id,
      'updated_by' => $user_id
    ]);
      $task->update([
      'status' => 5,
      'updated_by' => $user_id
    ]);
    $helper->storeProductionNegativePoints(
        $task,
        'Task marked as Rework by PC'
    );
    // Notification
    $task_details = DB::table('et_task')->where('sno', $task->task_id)->first();
    $notificationData = [
      'branch_id' => $branch_id,
      'notification_content' =>   '<div class="d-flex align-items-center">
                                                <div class="me-3">
                                                    <span class="badge bg-danger">
                                                        <i class="mdi mdi-calendar-remove fs-3 "></i>
                                                    </span>
                                                </div>
                                                <div class="me-2">
                                                    <a href="javascript:;" class="fs-7 text-primary fw-bold">Rework Task</a>
                                                    <div class="text-secondary fs-8  fw-bold">' . $task_details->task_id . '</div>
                                                </div>
                                            </div>',
      'who' => $task->staff_id,
      'created_by' => $user_id,
      'updated_by' => $user_id,
      'status' => 0
    ];
    $notificationtype = 'Requirement';
    $newNotification = new \App\Helpers\Helpers();
    $newNotification->createNotificationAssessment($notificationData, $notificationtype, $task->staff_id);
  }
  
  private function processRejectStatus($request, $task, $user_id, $branch_id)
  {
    $reject_reason = $request->reject_reason;
    $task->update([
      'status' => 6,
      'updated_by' => $user_id
    ]);

    DailyTaskModel::create([
      'service_id'       => $task->service_id,
      'task_id'          => $task->task_id,
      'staff_id' => $task->staff_id,
      'task_date'        => now(),
      'min_page_or_per'  => 0,
      'max_page_or_per'  => $task->max_page_or_per,
      'task_hours'       => $task->task_hours,
      'reject_reason'    => $request->reject_reason,
      'rework_check'     => 1,
      'created_by' => $user_id,
      'updated_by' => $user_id
    ]);
    // Notification
    $task_details = DB::table('et_task')->where('sno', $task->task_id)->first();
    $notificationData = [
      'branch_id' => $branch_id,
      'notification_content' =>   '<div class="d-flex align-items-center">
                                                <div class="me-3">
                                                    <span class="badge bg-warning text-black">
                                                        <i class="mdi mdi-calendar-sync fs-3 "></i>
                                                    </span>
                                                </div>
                                                <div class="me-2">
                                                    <a href="javascript:;" class="fs-7 text-primary fw-bold">Correction Task</a>
                                                    <div class="text-secondary fs-8  fw-bold">' . $task_details->task_id . '</div>
                                                </div>
                                            </div>',
      'who' => $task->staff_id,
      'created_by' => $user_id,
      'updated_by' => $user_id,
      'status' => 0
    ];
    $notificationtype = 'Requirement';
    $newNotification = new \App\Helpers\Helpers();
    $newNotification->createNotificationAssessment($notificationData, $notificationtype, $task->staff_id);
  }


  public function Delete($id)
  {
    $upd_DepartmentModel = ManageTaskModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function edit_daily_task($id)
  {
    $data =  DB::table('et_daily_tasks')
      ->where('sno', $id)
      ->where('status', 0)
      ->first();

    return response([
      'status' => 200,
      'message' => 'Daily Tasks Fetched Successfully',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function update_daily_tasks(Request $request)
  {
    // return $request;
    $sno = $request->sno;
    $service_id = $request->service_id;
    $staff_id = $request->staff_id;
    $task_id = $request->task_id;

    $update = DailyTaskModel::where('sno', $sno)->where('status', 0)->first();
    $update->service_id = $service_id;
    $update->staff_id = $staff_id;
    $update->task_id = $task_id;
    $update->update();

    return response([
      'status' => 200,
      'message' => 'Task Updated Successfully',
      'error_msg' => null,
      'data' => null
    ], 200);
  }

  public function statusChangeDataFetch($id)
  {
    $data = DB::table('et_daily_tasks')
      ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_daily_tasks.service_id')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->leftJoin('et_task', 'et_task.sno', 'et_daily_tasks.task_id')
      ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_daily_tasks.staff_id')
      ->select(
        'et_daily_tasks.*',
        'et_customer.cus_name',
        'et_customer.customer_id',
        DB::raw("CASE
          WHEN et_customer_services.product_package = 1 THEN et_product.product_name
          WHEN et_customer_services.product_package = 2 THEN et_package.package_name
          ELSE NULL
        END as product_name"),
        'et_product_category.product_category_name',
        'et_customer_services.variant_variable_ids',
        'et_product_task.task_name',
        'et_task.task_id as tasks_id',
        'et_task.pages_percentage',
        'et_task.working_hours',
        'et_staff.staff_name',
        'et_staff.staff_image',
        'et_task.task_category'
      )
      ->where('et_daily_tasks.sno', $id)
      ->first();

    $task = DB::table('et_task')
      ->where('et_task.sno', $data->task_id)
      ->select('task_check_list_ids')
      ->first();

    if (!$task) {
      // No task found with that id and status=0
      return response([
        'status' => 404,
        'message' => 'Task not found or inactive',
        'error_msg' => 'No task matching given ID and status.',
        'data' => [],
      ], 404);
    }

    $checklists = json_decode($task->task_check_list_ids, true);

    if (empty($checklists) || !is_array($checklists)) {
      return response([
        'status' => 200,
        'message' => 'No checklist items found',
        'error_msg' => null,
        'data' => [],
      ]);
    }

    $checkLists = [];
    foreach ($checklists as $check) {
      $task_check = DB::table('et_task_checklist')
        ->where('sno', $check)
        ->select('task_checklist', 'sno')
        ->first();

      if ($task_check) {
        $checkLists[] = $task_check;
      }
    }

    return response([
      'status' => 200,
      'message' => 'Task Updated Successfully',
      'error_msg' => null,
      'data' => $data,
      'checklists' => $checkLists
    ], 200);
  }
   public function changeDailyTaskStaff(Request $request)
{
    $validator = Validator::make($request->all(), [
        'daily_task_id' => 'required|exists:et_daily_tasks,sno',
        'new_staff_id'  => 'required|exists:et_staff,sno',
        'reason'        => 'required|string|max:500',
        'remarks'       => 'nullable|string|max:1000',
    ]);

    if ($validator->fails()) {
        return response([
            'status' => 422,
            'message' => $validator->errors()->first(),
            'error_msg' => $validator->errors(),
            'data' => null
        ], 422);
    }

    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    DB::beginTransaction();

    try {

        $task = DailyTaskModel::where('sno', $request->daily_task_id)
            ->lockForUpdate()
            ->first();

        if (!$task) {
            return response([
                'status' => 404,
                'message' => 'Daily Task not found.',
                'error_msg' => null,
                'data' => null
            ], 404);
        }

        // Don't allow Approved task
        if ($task->status == 4) {
            return response([
                'status' => 400,
                'message' => 'Approved task cannot be reassigned.',
                'error_msg' => null,
                'data' => null
            ], 400);
        }

        // Same staff validation
        if ($task->staff_id == $request->new_staff_id) {
            return response([
                'status' => 400,
                'message' => 'Selected staff is already assigned.',
                'error_msg' => null,
                'data' => null
            ], 400);
        }

        // Running timer validation
        $runningTimer = TaskLogModel::where('task_id', $task->sno)
            ->where('staff_id', $task->staff_id)
            ->where('status', 0)
            ->first();

        if ($runningTimer) {

            DB::rollBack();

            return response([
                'status' => 400,
                'message' => 'Please stop the running timer before changing staff.',
                'error_msg' => null,
                'data' => null
            ], 400);
        }

        /*
        |--------------------------------------------------------------------------
        | History
        |--------------------------------------------------------------------------
        */

        DB::table('et_daily_task_staff_history')->insert([
            'daily_task_id' => $task->sno,
            'task_id'       => $task->task_id,
            'service_id'    => $task->service_id,

            'old_staff_id'  => $task->staff_id,
            'new_staff_id'  => $request->new_staff_id,

            'reason'        => $request->reason,
            'remarks'       => $request->remarks,

            'changed_by'    => $user_id,

            'created_at'    => now(),
            'updated_at'    => now(),
            'status'        => 0
        ]);

        $oldStaff = $task->staff_id;

        /*
        |--------------------------------------------------------------------------
        | Update Daily Task
        |--------------------------------------------------------------------------
        */

        $task->staff_id   = $request->new_staff_id;
        $task->updated_by = $user_id;
        $task->save();
        
        $proposal = DB::table('et_customer_services')
        ->where('sno', $task->service_id)
        ->select('proposal_id', 'sno')
        ->first();

    if (!$proposal) {
        throw new \Exception('Proposal not found for the selected service.');
    }
        //========================================================
        // Production Points - Old Staff (-5)
        //========================================================

        DB::table('et_production_staff_points')->insert([

            'proposal_id' => $proposal->sno, // Proposal ID
            'service_id' => $task->service_id,
            'task_id' => $task->task_id,

            'staff_id' => $oldStaff,
            'role_id' => auth()->user()->role,

            'branch_id' => $branch_id,

            'point_type' => 'task_reassigned_from',

            'service_amount' => 0,

            'worked_hours' => null,

            'point_value' => 5,

            'earned_points' => -5,

            'is_positive' => 0,

            'reference_staff_id' => $request->new_staff_id,

            'reference_point_id' => null,

            'remarks' => 'Task reassigned from '.$oldStaff.' to '. $request->new_staff_id,

            'created_by' => $user_id,

            'created_at' => now(),

            'updated_at' => now()

        ]);

        //========================================================
        // Production Points - New Staff (+5)
        //========================================================

        DB::table('et_production_staff_points')->insert([

            'proposal_id' => $proposal->sno,
            'service_id' => $task->service_id,
            'task_id' => $task->task_id,

            'staff_id' => $request->new_staff_id,

            'role_id' => auth()->user()->role,

            'branch_id' => $branch_id,

            'point_type' => 'task_reassigned_to',

            'service_amount' => 0,

            'worked_hours' => null,

            'point_value' => 5,

            'earned_points' => 5,

            'is_positive' => 1,

            'reference_staff_id' => $oldStaff,

            'reference_point_id' => null,

            'remarks' => 'Task reassigned from '.$oldStaff.' to '. $request->new_staff_id,

            'created_by' => $user_id,

            'created_at' => now(),

            'updated_at' => now()

        ]);
        /*
        |--------------------------------------------------------------------------
        | Notification
        |--------------------------------------------------------------------------
        */

        $taskDetails = DB::table('et_task')
            ->where('sno', $task->task_id)
            ->first();

        $helper = new \App\Helpers\Helpers();

        // New Staff

        $notificationData = [
            'branch_id' => $branch_id,
            'notification_content' =>
            '<div class="d-flex align-items-center">

                <div class="me-3">
                    <span class="badge bg-success">
                        <i class="mdi mdi-account-switch fs-3"></i>
                    </span>
                </div>

                <div>

                    <a href="javascript:;" class="fs-7 fw-bold text-primary">
                        Task Assigned
                    </a>

                    <div class="text-secondary fs-8 fw-bold">
                        '.$taskDetails->task_id.'
                    </div>

                </div>

            </div>',
            'who'        => $user_id,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'status'     => 0
        ];

        $helper->createNotificationAssessment(
            $notificationData,
            'Task',
            $request->new_staff_id
        );

        // Old Staff

        $notificationData['notification_content'] =
            '<div class="d-flex align-items-center">

                <div class="me-3">
                    <span class="badge bg-danger">
                        <i class="mdi mdi-account-remove fs-3"></i>
                    </span>
                </div>

                <div>

                    <a href="javascript:;" class="fs-7 fw-bold text-danger">
                        Task Reassigned
                    </a>

                    <div class="text-secondary fs-8 fw-bold">
                        '.$taskDetails->task_id.'
                    </div>

                </div>

            </div>';

        $helper->createNotificationAssessment(
            $notificationData,
            'Task',
            $oldStaff
        );

        DB::commit();

        return response([
            'status' => 200,
            'message' => 'Assigned staff changed successfully.',
            'error_msg' => null,
            'data' => $task
        ], 200);

    } catch (\Exception $e) {

        DB::rollBack();

        return response([
            'status' => 500,
            'message' => 'Something went wrong.',
            'error_msg' => $e->getMessage(),
            'data' => null
        ], 500);
    }
}

public function getDailyTaskStaff($id)
{
    $task = DB::table('et_daily_tasks')
        ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_daily_tasks.staff_id')
        ->where('et_daily_tasks.sno', $id)
        ->select(
            'et_daily_tasks.*',
            'et_staff.staff_name'
        )
        ->first();

    if (!$task) {
        return response([
            'status' => 404,
            'message' => 'Task not found.',
            'data' => null
        ], 404);
    }

    $staffs = StaffModel::where('department_id', 2)
        ->where('status', 0)
        ->where('sno', '!=', $task->staff_id)
        ->orderBy('staff_name')
        ->select('sno', 'staff_name')
        ->get();

    return response([
        'status' => 200,
        'message' => 'Success',
        'data' => [
            'task' => $task,
            'staffs' => $staffs
        ]
    ], 200);
}
public function getDailyTaskStaffHistory($id)
{
    $history = DB::table('et_daily_task_staff_history as h')

        ->leftJoin('et_staff as oldStaff','oldStaff.sno','=','h.old_staff_id')

        ->leftJoin('et_staff as newStaff','newStaff.sno','=','h.new_staff_id')

        ->leftJoin('et_staff as u','u.sno','=','h.changed_by')

        ->where('h.daily_task_id',$id)

        ->select(

            'h.*',

            'oldStaff.staff_name as old_staff',
            'oldStaff.staff_image as old_staff_image',

            'newStaff.staff_name as new_staff',
            'newStaff.staff_image as new_staff_image',

            'u.staff_name as changed_by_name',
            'u.staff_image as changed_by_image'

        )

        ->orderByDesc('h.sno')

        ->get();

    return response([
        'status'=>200,
        'message'=>'Success',
        'data'=>$history
    ]);
}

public function getStaffProductionWorkload(Request $request)
{
    $user_id = $request->user()->user_id;
 
    /*
    |--------------------------------------------------------------------------
    | Base Task Query
    |--------------------------------------------------------------------------
    */
 
    $query = DB::table('et_daily_tasks')
        ->leftJoin(
            'et_customer_services',
            'et_customer_services.sno',
            '=',
            'et_daily_tasks.service_id'
        )
        ->leftJoin(
            'et_customer',
            'et_customer.sno',
            '=',
            'et_customer_services.customer_id'
        )
        ->leftJoin(
            'et_staff',
            'et_staff.sno',
            '=',
            'et_daily_tasks.staff_id'
        )
        ->where('et_daily_tasks.status', '!=', 2);
 
 
    /*
    |--------------------------------------------------------------------------
    | Permission Filter
    |--------------------------------------------------------------------------
    */
 
    if (
        auth()->user()->hasPermissionradio(
            'Production Management',
            'Manage Task',
            'view_self_manage_task'
        )
    ) {
 
        $userRole = auth()->user()->role_id;
 
        if ($userRole == 32 || $userRole == 36) {
 
            $query->where(function ($q) use ($user_id) {
 
                $q->where(
                    'et_daily_tasks.staff_id',
                    $user_id
                )
                ->orWhereJsonContains(
                    'et_daily_tasks.staff_id',
                    (string) $user_id
                )
                ->orWhereJsonContains(
                    'et_daily_tasks.staff_id',
                    (int) $user_id
                );
            });
 
        } elseif ($userRole == 15) {
 
            $query->where(
                'et_customer_services.pc_id',
                $user_id
            );
        }
 
    } elseif (
        auth()->user()->hasPermissionradio(
            'Production Management',
            'Manage Task',
            'global_manage_task'
        )
    ) {
 
        // Global permission - no additional filter
 
    } else {
 
        abort(403, 'Unauthorized');
    }
 
 
    /*
    |--------------------------------------------------------------------------
    | Get Tasks
    |--------------------------------------------------------------------------
    |
    | We get the task records first because staff_id can be:
    |
    | 123
    | ["123", "456"]
    | [123, 456]
    |
    */
 
    $tasks = $query
        ->select(
            'et_daily_tasks.sno',
            'et_daily_tasks.staff_id',
            'et_daily_tasks.status',
            'et_daily_tasks.is_journal',
            'et_daily_tasks.is_correction',
            'et_daily_tasks.rework_check'
        )
        ->get();
 
 
    /*
    |--------------------------------------------------------------------------
    | Prepare Staff Workload
    |--------------------------------------------------------------------------
    */
 
    $staffWorkload = [];
 
 
    foreach ($tasks as $task) {
 
        /*
        |--------------------------------------------------------------------------
        | Decode Staff IDs
        |--------------------------------------------------------------------------
        */
 
        $staffIds = [];
 
        if (is_string($task->staff_id)) {
 
            $decodedStaffIds = json_decode(
                $task->staff_id,
                true
            );
 
            if (
                json_last_error() === JSON_ERROR_NONE &&
                is_array($decodedStaffIds)
            ) {
 
                $staffIds = $decodedStaffIds;
 
            } else {
 
                $staffIds = [$task->staff_id];
            }
 
        } elseif (is_array($task->staff_id)) {
 
            $staffIds = $task->staff_id;
 
        } elseif (!empty($task->staff_id)) {
 
            $staffIds = [$task->staff_id];
        }
 
 
        /*
        |--------------------------------------------------------------------------
        | Clean Staff IDs
        |--------------------------------------------------------------------------
        */
 
        $staffIds = collect($staffIds)
            ->filter(fn ($id) => !empty($id))
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values()
            ->toArray();
 
 
        /*
        |--------------------------------------------------------------------------
        | Count Task For Each Assigned Staff
        |--------------------------------------------------------------------------
        */
 
        foreach ($staffIds as $staffId) {
 
            if (!isset($staffWorkload[$staffId])) {
 
                $staffWorkload[$staffId] = [
                    'sno' => $staffId,
                    'journalCount' => 0,
                    'reworkCount' => 0,
                    'correctionCount' => 0,
                    'qcVerifiedCount' => 0,
                    'completedCount' => 0,
                    'notYetStartedCount' => 0,
                    'inProgressCount' => 0,
                    'totalTaskscount' => 0,
                ];
            }
 
 
            /*
            |--------------------------------------------------------------------------
            | Total Tasks
            |--------------------------------------------------------------------------
            |
            | Same definition as index()
            |
            */
 
            if (
                (int) $task->is_journal === 0 &&
                (int) $task->is_correction === 0 &&
                (int) $task->rework_check === 0
            ) {
 
                $staffWorkload[$staffId]['totalTaskscount']++;
            }
 
 
            /*
            |--------------------------------------------------------------------------
            | Journal
            |--------------------------------------------------------------------------
            */
 
            if (
                (int) $task->is_journal === 1 &&
                (int) $task->is_correction === 0 &&
                (int) $task->rework_check === 0
            ) {
 
                $staffWorkload[$staffId]['journalCount']++;
            }
 
 
            /*
            |--------------------------------------------------------------------------
            | Rework
            |--------------------------------------------------------------------------
            */
 
            if (
                (int) $task->is_journal === 0 &&
                (int) $task->is_correction === 0 &&
                (int) $task->rework_check === 1
            ) {
 
                $staffWorkload[$staffId]['reworkCount']++;
            }
 
 
            /*
            |--------------------------------------------------------------------------
            | Correction
            |--------------------------------------------------------------------------
            */
 
            if (
                (int) $task->is_journal === 0 &&
                (int) $task->is_correction === 1 &&
                (int) $task->rework_check === 0
            ) {
 
                $staffWorkload[$staffId]['correctionCount']++;
            }
 
 
            /*
            |--------------------------------------------------------------------------
            | QC Verified
            |--------------------------------------------------------------------------
            */
 
            if ((int) $task->status === 4) {
 
                $staffWorkload[$staffId]['qcVerifiedCount']++;
            }
 
 
            /*
            |--------------------------------------------------------------------------
            | Completed
            |--------------------------------------------------------------------------
            */
 
            if ((int) $task->status === 3) {
 
                $staffWorkload[$staffId]['completedCount']++;
            }
 
 
            /*
            |--------------------------------------------------------------------------
            | Not Yet Started
            |--------------------------------------------------------------------------
            */
 
            if ((int) $task->status === 0) {
 
                $staffWorkload[$staffId]['notYetStartedCount']++;
            }
 
 
            /*
            |--------------------------------------------------------------------------
            | In Progress
            |--------------------------------------------------------------------------
            */
 
            if ((int) $task->status === 1) {
 
                $staffWorkload[$staffId]['inProgressCount']++;
            }
        }
    }
 
 
    /*
    |--------------------------------------------------------------------------
    | Get Staff Details
    |--------------------------------------------------------------------------
    */
 
    $staffIds = array_keys($staffWorkload);
 
    $staffDetails = DB::table('et_staff')
        ->whereIn('et_staff.sno', $staffIds)
        ->select(
            'et_staff.sno',
            'et_staff.staff_name',
            'et_staff.staff_image'
        )
        ->get()
        ->keyBy('sno');
 
 
    /*
    |--------------------------------------------------------------------------
    | Merge Staff Details + Workload
    |--------------------------------------------------------------------------
    */
 
    $result = collect($staffWorkload)
        ->map(function ($workload) use ($staffDetails) {
 
            $staff = $staffDetails->get($workload['sno']);
 
            return [
                'sno' => $workload['sno'],
 
                'staffname' => $staff->staff_name ?? '',
 
                'staffimage' => $staff->staff_image ?? '',
 
                'journalCount' => $workload['journalCount'],
 
                'reworkCount' => $workload['reworkCount'],
 
                'correctionCount' => $workload['correctionCount'],
 
                'qcVerifiedCount' => $workload['qcVerifiedCount'],
 
                'completedCount' => $workload['completedCount'],
 
                'notYetStartedCount' =>
                    $workload['notYetStartedCount'],
 
                'inProgressCount' =>
                    $workload['inProgressCount'],
 
                'totalTaskscount' =>
                    $workload['totalTaskscount'],
            ];
        })
        ->values();
 
 
    return response()->json([
        'status' => true,
        'data' => $result,
    ]);
}

}
