<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use App\Models\ManageDeliverablesModel;
use Illuminate\Support\Facades\File;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;


class ManageCorrections extends Controller
{

//  public function index(Request $request)
// {
//     $branch_id = auth()->user()->branch_id;
// $perpage = max((int) $request->input('sorting_filter', 10), 1);
//  $status_fill = $request->status_fill ?? '';
//     $filter_on = $request->filter_on ?? '';
// $correctionFilter = $request->input( 'correction_filter', 'all' );
//     $staff_fill = $request->input('staff_fill', '');
//     $revert_type_fill = $request->input(
//         'revert_type_fill',
//         ''
//     );
 
//     $hold_fill = $request->input(
//         'hold_fill',
//         ''
//     );
 
//     $target_fill = $request->input(
//         'target_fill',
//         ''
//     );
 
//     $customer_fill = trim(
//         $request->input('customer_fill', '')
//     );
 
//     $product_fill = $request->input(
//         'product_fill',
//         ''
//     );
 
//     $service_fill = trim(
//         $request->input('service_fill', '')
//     );
 
//     $milestone_fill = $request->input(
//         'milestone_fill',
//         ''
//     );
 
//      /*
//     |--------------------------------------------------------------------------
//     | Correction Dashboard
//     |--------------------------------------------------------------------------
//     */
 
//     // Base correction query
//     $correctionBase = DB::table('et_milestone_history as mh')
//         ->join(
//             'et_milestone_mapping as mm',
//             'mm.sno',
//             '=',
//             'mh.milestone_id'
//         )
//         ->join(
//             'et_customer_services as cs',
//             'cs.sno',
//             '=',
//             'mm.service_id'
//         )
//         ->where('cs.branch_id', $branch_id)
//         ->where('mh.correction_tracking', 1);
 
//     /*
//     |--------------------------------------------------------------------------
//     | Total Corrections
//     |--------------------------------------------------------------------------
//     */
 
//     $totalCorrections = (clone $correctionBase)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Pending Assignment
//     |--------------------------------------------------------------------------
//     |
//     | Correction is tracking but no production staff assigned.
//     |
//     */
 
//     $pendingAssignment = (clone $correctionBase)
//         ->whereNull('mh.document_staff_id')
//         ->where('mh.correction_hold', 0)
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | In Progress
//     |--------------------------------------------------------------------------
//     |
//     | Assigned to production staff and not on hold/completed.
//     |
//     */
 
//     $inProgress = (clone $correctionBase)
//         ->whereNotNull('mh.document_staff_id')
//         ->where('mh.correction_hold', 0)
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | On Hold
//     |--------------------------------------------------------------------------
//     */
 
//     $onHold = (clone $correctionBase)
//         ->where('mh.correction_hold', 1)
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Due Today
//     |--------------------------------------------------------------------------
//     */
 
//     $dueToday = (clone $correctionBase)
//         ->whereNotNull('mh.target_completion_date')
//         ->whereDate(
//             'mh.target_completion_date',
//             now()->toDateString()
//         )
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Overdue
//     |--------------------------------------------------------------------------
//     */
 
//     $overdue = (clone $correctionBase)
//         ->whereNotNull('mh.target_completion_date')
//         ->whereDate(
//             'mh.target_completion_date',
//             '<',
//             now()->toDateString()
//         )
//         ->where('mh.correction_completed', 0)
//         ->where('mh.correction_hold', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Completed
//     |--------------------------------------------------------------------------
//     */
 
//     $completed = (clone $correctionBase)
//         ->where('mh.correction_completed', 1)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Update Required
//     |--------------------------------------------------------------------------
//     |
//     | revert_type:
//     | 1 = Correction
//     | 2 = Update Required
//     |
//     */
 
//     $updateRequired = (clone $correctionBase)
//         ->where('mh.revert_type', 2)
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     $correctionStats = [
//         'total'             => $totalCorrections,
//         'pending_assignment' => $pendingAssignment,
//         'in_progress'       => $inProgress,
//         'on_hold'           => $onHold,
//         'due_today'         => $dueToday,
//         'overdue'           => $overdue,
//         'completed'         => $completed,
//         'update_required'   => $updateRequired,
//     ];
 
 
   
//     $List = DB::table('et_milestone_history')
 
//         ->join(
//             'et_milestone_mapping',
//             'et_milestone_mapping.sno',
//             '=',
//             'et_milestone_history.milestone_id'
//         )
 
//         ->join(
//             'et_customer_services',
//             'et_customer_services.sno',
//             '=',
//             'et_milestone_mapping.service_id'
//         )
 
//         ->leftJoin(
//             'et_customer',
//             'et_customer.sno',
//             '=',
//             'et_customer_services.customer_id'
//         )
 
//         ->leftJoin(
//             'et_product',
//             'et_product.sno',
//             '=',
//             'et_customer_services.product_id'
//         )
 
//         ->leftJoin(
//           'et_product_task',
//           'et_product_task.sno',
//           '=',
//           'et_milestone_history.task_id'
//       )
 
//         ->leftJoin(
//             'et_staff as cre',
//             'cre.sno',
//             '=',
//             'et_customer_services.cre_id'
//         )
 
//         ->leftJoin(
//             'et_staff as pc',
//             'pc.sno',
//             '=',
//             'et_customer_services.pc_id'
//         )
 
//         ->leftJoin(
//             'et_staff as document_staff',
//             'document_staff.sno',
//             '=',
//             'et_milestone_history.document_staff_id'
//         )
 
//         ->leftJoin(
//             'et_proposal_pay_slot',
//             'et_proposal_pay_slot.sno',
//             '=',
//             'et_milestone_mapping.milestone_id'
//         )
 
//         ->leftJoin(
//             'et_payment_slot',
//             'et_payment_slot.sno',
//             '=',
//             'et_proposal_pay_slot.slot_id'
//         )
 
//         ->where(
//             'et_customer_services.branch_id',
//             $branch_id
//         )
 
//         ->where(function ($query) {
 
//                 $query->where(function ($q) {
 
//                     // Existing corrections
//                     $q->whereIn(
//                         'et_milestone_history.status',
//                         [8, 9]
//                     )
//                     ->where(
//                         'et_milestone_history.reverted_to_production',
//                         1
//                     );
 
//                 })
//                 ->orWhere(
//                     'et_milestone_history.correction_tracking',
//                     1
//                 );
 
//             })
 
//         ->select(
 
//             'et_milestone_history.*',
 
//             'et_milestone_mapping.service_id',
//             'et_customer_services.created_at as service_created_at',
 
//             'et_customer.cus_name',
 
//             'et_customer.customer_id',
 
//             'et_product.product_name',
 
//             'et_product_task.task_name',
 
//             'et_payment_slot.payment_slot_name',
 
//             'cre.staff_name as cre_name',
 
//             'pc.staff_name as pc_name',
 
//             'document_staff.staff_name',
 
//             'document_staff.staff_image'
 
//         )
 
//         ->orderByDesc(
//             'et_milestone_history.reverted_date'
//         );
   
// /*
// |--------------------------------------------------------------------------
// | Dashboard Filter
// |--------------------------------------------------------------------------
// */
 
// switch ($correctionFilter) {
 
//     case 'pending_assignment':
 
//         $List
//             ->whereNull(
//                 'et_milestone_history.document_staff_id'
//             )
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 0
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'in_progress':
 
//         $List
//             ->whereNotNull(
//                 'et_milestone_history.document_staff_id'
//             )
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 0
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'on_hold':
 
//         $List
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 1
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'due_today':
 
//         $List
//             ->whereNotNull(
//                 'et_milestone_history.target_completion_date'
//             )
//             ->whereDate(
//                 'et_milestone_history.target_completion_date',
//                 now()->toDateString()
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'overdue':
 
//         $List
//             ->whereNotNull(
//                 'et_milestone_history.target_completion_date'
//             )
//             ->whereDate(
//                 'et_milestone_history.target_completion_date',
//                 '<',
//                 now()->toDateString()
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             )
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 0
//             );
 
//         break;
 
 
//     case 'completed':
 
//         $List
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 1
//             );
 
//         break;
 
 
//     case 'update_required':
 
//         $List
//             ->where(
//                 'et_milestone_history.revert_type',
//                 2
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'all':
//     default:
 
//         // No additional filter
 
//         break;
// }
// // dd($List->get(), $staff_fill);
// /*
// |--------------------------------------------------------------------------
// | Assigned Staff Filter
// |--------------------------------------------------------------------------
// */
 
// if ($staff_fill !== '' && $staff_fill !== null) {
 
//     // if ($staff_fill === 'unassigned') {
 
//     //     $List->whereNull(
//     //         'et_milestone_history.document_staff_id'
//     //     );
 
//     // } else {
 
//       $List->where(
//         'et_milestone_history.document_staff_id',
//         (int) $staff_fill
//     );
   
//     // }
// }
 
 
// /*
// |--------------------------------------------------------------------------
// | Correction Type Filter
// |--------------------------------------------------------------------------
// */
// if ($revert_type_fill !== '' && $revert_type_fill != null) {
   
//         $List->where(
//             'et_milestone_history.revert_type',
//             (int) $revert_type_fill
//         );
// }
 
// /*
// |--------------------------------------------------------------------------
// | Hold Status Filter
// |--------------------------------------------------------------------------
// */
 
// if ($hold_fill !== '' && $hold_fill !== null) {
 
//     $List->where(
//         'et_milestone_history.correction_hold',
//         $hold_fill
//     );
// }
 
 
// /*
// |--------------------------------------------------------------------------
// | Target Date Filter
// |--------------------------------------------------------------------------
// */
 
// switch ($target_fill) {
 
//     case 'today':
 
//         $List->whereDate(
//             'et_milestone_history.target_completion_date',
//             today()
//         );
 
//         break;
 
 
//     case 'tomorrow':
 
//         $List->whereDate(
//             'et_milestone_history.target_completion_date',
//             today()->addDay()
//         );
 
//         break;
 
 
//     case 'this_week':
 
//         $List->whereBetween(
//             'et_milestone_history.target_completion_date',
//             [
//                 now()->startOfWeek(),
//                 now()->endOfWeek()
//             ]
//         );
 
//         break;
 
 
//     case 'overdue':
 
//         $List
//             ->whereNotNull(
//                 'et_milestone_history.target_completion_date'
//             )
//             ->whereDate(
//                 'et_milestone_history.target_completion_date',
//                 '<',
//                 today()
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             )
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 0
//             );
 
//         break;
 
 
//     case 'no_date':
 
//         $List->whereNull(
//             'et_milestone_history.target_completion_date'
//         );
 
//         break;
// }
 
 
 
// $List = $List ->paginate($perpage);
//      foreach ($List as $row) {
 
//     $year = date('Y', strtotime($row->service_created_at));
 
//     $formattedId = str_pad(
//         $row->service_id,
//         5,
//         '0',
//         STR_PAD_LEFT
//     );
 
//     $row->formatted_service_id = "SR-{$formattedId}/{$year}";
//       $row->customer_documents = DB::table('et_task_customer_documents')
//         ->where('milestone_history_id', $row->sno)
//         ->get();
 
//     $row->customer_document_count =
//         $row->customer_documents->count();
// }
//   $staffs = DB::table('et_staff')
//             ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//             ->where('et_staff.status', 0)
//             ->where('et_staff.sno', '>', 1)
//             ->where('et_staff.branch_id', $branch_id)
//             ->whereIn('et_staff.role_id', [32, 36])
//             ->select('et_staff.*', 'et_job_position.job_position_name')
//             ->get();
//             // return $List;
//     return view(
//     'content.production_management.manage_deliverables.corrections_list',
//     compact('List', 'perpage', 'status_fill', 'staffs', 'correctionStats', 'correctionFilter', 'staff_fill', 'revert_type_fill', 'hold_fill', 'target_fill')
// );
// }

//  public function index(Request $request)
// {
//     $branch_id = auth()->user()->branch_id;
// $perpage = max((int) $request->input('sorting_filter', 10), 1);
//  $status_fill = $request->status_fill ?? '';
//   $search_fill = $request->search_fill ?? '';
//     $filter_on = $request->filter_on ?? '';
// $correctionFilter = $request->input( 'correction_filter', 'all' );
//     $staff_fill = $request->input('staff_fill', '');
//     $revert_type_fill = $request->input(
//         'revert_type_fill',
//         ''
//     );
 
//     $hold_fill = $request->input(
//         'hold_fill',
//         ''
//     );
 
//     $target_fill = $request->input(
//         'target_fill',
//         ''
//     );
 
//     $customer_fill = trim(
//         $request->input('customer_fill', '')
//     );
 
//     $product_fill = $request->input(
//         'product_fill',
//         ''
//     );
 
//     $service_fill = trim(
//         $request->input('service_fill', '')
//     );
 
//     $milestone_fill = $request->input(
//         'milestone_fill',
//         ''
//     );
 
//      /*
//     |--------------------------------------------------------------------------
//     | Correction Dashboard
//     |--------------------------------------------------------------------------
//     */
 
//     // Base correction query
//     $correctionBase = DB::table('et_milestone_history as mh')
//         ->join(
//             'et_milestone_mapping as mm',
//             'mm.sno',
//             '=',
//             'mh.milestone_id'
//         )
//         ->join(
//             'et_customer_services as cs',
//             'cs.sno',
//             '=',
//             'mm.service_id'
//         )
//         ->where('cs.branch_id', $branch_id)
//         ->where('mh.correction_tracking', 1);
 
//     /*
//     |--------------------------------------------------------------------------
//     | Total Corrections
//     |--------------------------------------------------------------------------
//     */
 
//     $totalCorrections = (clone $correctionBase)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Pending Assignment
//     |--------------------------------------------------------------------------
//     |
//     | Correction is tracking but no production staff assigned.
//     |
//     */
 
//     $pendingAssignment = (clone $correctionBase)
//         ->whereNull('mh.document_staff_id')
//         ->where('mh.correction_hold', 0)
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | In Progress
//     |--------------------------------------------------------------------------
//     |
//     | Assigned to production staff and not on hold/completed.
//     |
//     */
 
//     $inProgress = (clone $correctionBase)
//         ->whereNotNull('mh.document_staff_id')
//         ->where('mh.correction_hold', 0)
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | On Hold
//     |--------------------------------------------------------------------------
//     */
 
//     $onHold = (clone $correctionBase)
//         ->where('mh.correction_hold', 1)
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Due Today
//     |--------------------------------------------------------------------------
//     */
 
//     $dueToday = (clone $correctionBase)
//         ->whereNotNull('mh.target_completion_date')
//         ->whereDate(
//             'mh.target_completion_date',
//             now()->toDateString()
//         )
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Overdue
//     |--------------------------------------------------------------------------
//     */
 
//     $overdue = (clone $correctionBase)
//         ->whereNotNull('mh.target_completion_date')
//         ->whereDate(
//             'mh.target_completion_date',
//             '<',
//             now()->toDateString()
//         )
//         ->where('mh.correction_completed', 0)
//         ->where('mh.correction_hold', 0)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Completed
//     |--------------------------------------------------------------------------
//     */
 
//     $completed = (clone $correctionBase)
//         ->where('mh.correction_completed', 1)
//         ->count('mh.sno');
 
//     /*
//     |--------------------------------------------------------------------------
//     | Update Required
//     |--------------------------------------------------------------------------
//     |
//     | revert_type:
//     | 1 = Correction
//     | 2 = Update Required
//     |
//     */
 
//     $updateRequired = (clone $correctionBase)
//         ->where('mh.revert_type', 2)
//         ->where('mh.correction_completed', 0)
//         ->count('mh.sno');
 
//     $correctionStats = [
//         'total'             => $totalCorrections,
//         'pending_assignment' => $pendingAssignment,
//         'in_progress'       => $inProgress,
//         'on_hold'           => $onHold,
//         'due_today'         => $dueToday,
//         'overdue'           => $overdue,
//         'completed'         => $completed,
//         'update_required'   => $updateRequired,
//     ];
 
 
   
//     $List = DB::table('et_milestone_history')
 
//         ->join(
//             'et_milestone_mapping',
//             'et_milestone_mapping.sno',
//             '=',
//             'et_milestone_history.milestone_id'
//         )
 
//         ->join(
//             'et_customer_services',
//             'et_customer_services.sno',
//             '=',
//             'et_milestone_mapping.service_id'
//         )
 
//         ->leftJoin(
//             'et_customer',
//             'et_customer.sno',
//             '=',
//             'et_customer_services.customer_id'
//         )
 
//         ->leftJoin(
//             'et_product',
//             'et_product.sno',
//             '=',
//             'et_customer_services.product_id'
//         )
 
//         ->leftJoin(
//           'et_product_task',
//           'et_product_task.sno',
//           '=',
//           'et_milestone_history.task_id'
//       )
 
//         ->leftJoin(
//             'et_staff as cre',
//             'cre.sno',
//             '=',
//             'et_customer_services.cre_id'
//         )
 
//         ->leftJoin(
//             'et_staff as pc',
//             'pc.sno',
//             '=',
//             'et_customer_services.pc_id'
//         )
 
//         ->leftJoin(
//             'et_staff as document_staff',
//             'document_staff.sno',
//             '=',
//             'et_milestone_history.document_staff_id'
//         )
 
//         ->leftJoin(
//             'et_proposal_pay_slot',
//             'et_proposal_pay_slot.sno',
//             '=',
//             'et_milestone_mapping.milestone_id'
//         )
 
//         ->leftJoin(
//             'et_payment_slot',
//             'et_payment_slot.sno',
//             '=',
//             'et_proposal_pay_slot.slot_id'
//         )
 
//         ->where(
//             'et_customer_services.branch_id',
//             $branch_id
//         )
 
//         ->where(function ($query) {
 
//                 $query->where(function ($q) {
 
//                     // Existing corrections
//                     $q->whereIn(
//                         'et_milestone_history.status',
//                         [8, 9]
//                     )
//                     ->where(
//                         'et_milestone_history.reverted_to_production',
//                         1
//                     );
 
//                 })
//                 ->orWhere(
//                     'et_milestone_history.correction_tracking',
//                     1
//                 );
 
//             })
 
//         ->select(
 
//             'et_milestone_history.*',
 
//             'et_milestone_mapping.service_id',
//             'et_customer_services.created_at as service_created_at',
 
//             'et_customer.cus_name',
 
//             'et_customer.customer_id',
 
//             'et_product.product_name',
 
//             'et_product_task.task_name',
 
//             'et_payment_slot.payment_slot_name',
 
//             'cre.staff_name as cre_name',
 
//             'pc.staff_name as pc_name',
 
//             'document_staff.staff_name',
 
//             'document_staff.staff_image'
 
//         )
 
//         ->orderByDesc(
//             'et_milestone_history.reverted_date'
//         );
   
// /*
// |--------------------------------------------------------------------------
// | Dashboard Filter
// |--------------------------------------------------------------------------
// */
 
// switch ($correctionFilter) {
 
//     case 'pending_assignment':
 
//         $List
//             ->whereNull(
//                 'et_milestone_history.document_staff_id'
//             )
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 0
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'in_progress':
 
//         $List
//             ->whereNotNull(
//                 'et_milestone_history.document_staff_id'
//             )
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 0
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'on_hold':
 
//         $List
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 1
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'due_today':
 
//         $List
//             ->whereNotNull(
//                 'et_milestone_history.target_completion_date'
//             )
//             ->whereDate(
//                 'et_milestone_history.target_completion_date',
//                 now()->toDateString()
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'overdue':
 
//         $List
//             ->whereNotNull(
//                 'et_milestone_history.target_completion_date'
//             )
//             ->whereDate(
//                 'et_milestone_history.target_completion_date',
//                 '<',
//                 now()->toDateString()
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             )
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 0
//             );
 
//         break;
 
 
//     case 'completed':
 
//         $List
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 1
//             );
 
//         break;
 
 
//     case 'update_required':
 
//         $List
//             ->where(
//                 'et_milestone_history.revert_type',
//                 2
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             );
 
//         break;
 
 
//     case 'all':
//     default:
 
//         // No additional filter
 
//         break;
// }
// // dd($List->get(), $staff_fill);
// /*
// |--------------------------------------------------------------------------
// | Assigned Staff Filter
// |--------------------------------------------------------------------------
// */
 
// if ($staff_fill !== '' && $staff_fill !== null) {
 
//     // if ($staff_fill === 'unassigned') {
 
//     //     $List->whereNull(
//     //         'et_milestone_history.document_staff_id'
//     //     );
 
//     // } else {
 
//       $List->where(
//         'et_milestone_history.document_staff_id',
//         (int) $staff_fill
//     );
   
//     // }
// }
 
//   // Filters
//         if ($search_fill != '') {
//             $List->where(function ($query) use ($search_fill) {
//                 $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%");
//             });
//         }
// /*
// |--------------------------------------------------------------------------
// | Correction Type Filter
// |--------------------------------------------------------------------------
// */
// if ($revert_type_fill !== '' && $revert_type_fill != null) {
   
//         $List->where(
//             'et_milestone_history.revert_type',
//             (int) $revert_type_fill
//         );
// }
 
// /*
// |--------------------------------------------------------------------------
// | Hold Status Filter
// |--------------------------------------------------------------------------
// */
 
// if ($hold_fill !== '' && $hold_fill !== null) {
 
//     $List->where(
//         'et_milestone_history.correction_hold',
//         $hold_fill
//     );
// }
 
 
// /*
// |--------------------------------------------------------------------------
// | Target Date Filter
// |--------------------------------------------------------------------------
// */
 
// switch ($target_fill) {
 
//     case 'today':
 
//         $List->whereDate(
//             'et_milestone_history.target_completion_date',
//             today()
//         );
 
//         break;
 
 
//     case 'tomorrow':
 
//         $List->whereDate(
//             'et_milestone_history.target_completion_date',
//             today()->addDay()
//         );
 
//         break;
 
 
//     case 'this_week':
 
//         $List->whereBetween(
//             'et_milestone_history.target_completion_date',
//             [
//                 now()->startOfWeek(),
//                 now()->endOfWeek()
//             ]
//         );
 
//         break;
 
 
//     case 'overdue':
 
//         $List
//             ->whereNotNull(
//                 'et_milestone_history.target_completion_date'
//             )
//             ->whereDate(
//                 'et_milestone_history.target_completion_date',
//                 '<',
//                 today()
//             )
//             ->where(
//                 'et_milestone_history.correction_completed',
//                 0
//             )
//             ->where(
//                 'et_milestone_history.correction_hold',
//                 0
//             );
 
//         break;
 
 
//     case 'no_date':
 
//         $List->whereNull(
//             'et_milestone_history.target_completion_date'
//         );
 
//         break;
// }
 
 
 
// $List = $List ->paginate($perpage);
//      foreach ($List as $row) {
 
//     $year = date('Y', strtotime($row->service_created_at));
 
//     $formattedId = str_pad(
//         $row->service_id,
//         5,
//         '0',
//         STR_PAD_LEFT
//     );
 
//     $row->formatted_service_id = "SR-{$formattedId}/{$year}";
//       $row->customer_documents = DB::table('et_task_customer_documents')
//         ->where('milestone_history_id', $row->sno)
//         ->get();
 
//     $row->customer_document_count =
//         $row->customer_documents->count();
// }
//   $staffs = DB::table('et_staff')
//             ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//             ->where('et_staff.status', 0)
//             ->where('et_staff.sno', '>', 1)
//             ->where('et_staff.branch_id', $branch_id)
//             ->whereIn('et_staff.role_id', [32, 36])
//             ->select('et_staff.*', 'et_job_position.job_position_name')
//             ->get();
//             // return $List;
//     return view(
//     'content.production_management.manage_deliverables.corrections_list',
//     compact('List', 'perpage', 'status_fill', 'staffs', 'correctionStats', 'correctionFilter', 'staff_fill', 'revert_type_fill', 'hold_fill', 'target_fill', 'search_fill')
// );
// }
 
 public function index(Request $request)
{
    $branch_id = auth()->user()->branch_id;
    $perpage = max((int) $request->input('sorting_filter', 10), 1);
    $status_fill = $request->status_fill ?? '';
    $filter_on = $request->filter_on ?? '';
    $search_fill = $request->search_fill ?? '';
    $correctionFilter = $request->input( 'correction_filter', 'all' );
    $staff_fill = $request->input('staff_fill', '');
    $revert_type_fill = $request->input(
        'revert_type_fill',
        ''
    );
 
    $hold_fill = $request->input(
        'hold_fill',
        ''
    );
 
    $target_fill = $request->input(
        'target_fill',
        ''
    );
 
    $customer_fill = trim(
        $request->input('customer_fill', '')
    );
 
    $product_fill = $request->input(
        'product_fill',
        ''
    );
 
    $service_fill = trim(
        $request->input('service_fill', '')
    );
 
    $milestone_fill = $request->input(
        'milestone_fill',
        ''
    );
 
     /*
    |--------------------------------------------------------------------------
    | Correction Dashboard
    |--------------------------------------------------------------------------
    */
 
    // Base correction query
    $correctionBase = DB::table('et_milestone_history as mh')
        ->join(
            'et_milestone_mapping as mm',
            'mm.sno',
            '=',
            'mh.milestone_id'
        )
        ->join(
            'et_customer_services as cs',
            'cs.sno',
            '=',
            'mm.service_id'
        )
        ->where('cs.branch_id', $branch_id)
        ->where('mh.correction_tracking', 1);
 
    /*
    |--------------------------------------------------------------------------
    | Total Corrections
    |--------------------------------------------------------------------------
    */
 
    $totalCorrections = (clone $correctionBase)
        ->count('mh.sno');
 
    /*
    |--------------------------------------------------------------------------
    | Pending Assignment
    |--------------------------------------------------------------------------
    |
    | Correction is tracking but no production staff assigned.
    |
    */
 
    $pendingAssignment = (clone $correctionBase)
       
        ->where(
                'mh.correction_hold',
                0
            )->where(
                'mh.correction_tracking',
                1
            )->where(
                'mh.reverted_to_production',
                1
            )
            ->where(
                'mh.correction_completed',
                0
            )->where(
                'mh.customer_ack_status',
                0
            )->whereIn(
                'mh.status',
                [8, 9]
            )
        ->count('mh.sno');
 
    /*
    |--------------------------------------------------------------------------
    | In Progress
    |--------------------------------------------------------------------------
    |
    | Assigned to production staff and not on hold/completed.
    |
    */
 
    $inProgress = (clone $correctionBase)
        ->whereNotNull('mh.document_staff_id')
        ->where('mh.correction_hold', 0)
        ->where('mh.correction_completed', 0)
        ->count('mh.sno');
 
    /*
    |--------------------------------------------------------------------------
    | On Hold
    |--------------------------------------------------------------------------
    */
 
    $onHold = (clone $correctionBase)
        ->where('mh.correction_hold', 1)
        ->where('mh.correction_completed', 0)
        ->count('mh.sno');
 
    /*
    |--------------------------------------------------------------------------
    | Due Today
    |--------------------------------------------------------------------------
    */
 
    $dueToday = (clone $correctionBase)
        ->whereNotNull('mh.target_completion_date')
        ->whereDate(
            'mh.target_completion_date',
            now()->toDateString()
        )
        ->where('mh.correction_completed', 0)
        ->count('mh.sno');
 
    /*
    |--------------------------------------------------------------------------
    | Overdue
    |--------------------------------------------------------------------------
    */
 
    $overdue = (clone $correctionBase)
        ->whereNotNull('mh.target_completion_date')
        ->whereDate(
            'mh.target_completion_date',
            '<',
            now()->toDateString()
        )
        ->where('mh.correction_completed', 0)
        ->where('mh.correction_hold', 0)
        ->count('mh.sno');
 
    /*
    |--------------------------------------------------------------------------
    | Completed
    |--------------------------------------------------------------------------
    */
 
    $completed = (clone $correctionBase)
        ->where('mh.customer_ack_status', 1)
        ->count('mh.sno');
 
    /*
    |--------------------------------------------------------------------------
    | Update Required
    |--------------------------------------------------------------------------
    |
    | revert_type:
    | 1 = Correction
    | 2 = Update Required
    |
    */
 
    $updateRequired = (clone $correctionBase)
        ->where('mh.revert_type', 2)
        ->where('mh.correction_completed', 0)
        ->count('mh.sno');
 
    $correctionStats = [
        'total'             => $totalCorrections,
        'pending_assignment' => $pendingAssignment,
        'in_progress'       => $inProgress,
        'on_hold'           => $onHold,
        'due_today'         => $dueToday,
        'overdue'           => $overdue,
        'completed'         => $completed,
        'update_required'   => $updateRequired,
    ];
 
 
   
    $List = DB::table('et_milestone_history')
 
        ->join(
            'et_milestone_mapping',
            'et_milestone_mapping.sno',
            '=',
            'et_milestone_history.milestone_id'
        )
 
        ->join(
            'et_customer_services',
            'et_customer_services.sno',
            '=',
            'et_milestone_mapping.service_id'
        )
 
        ->leftJoin(
            'et_customer',
            'et_customer.sno',
            '=',
            'et_customer_services.customer_id'
        )
 
        ->leftJoin(
            'et_product',
            'et_product.sno',
            '=',
            'et_customer_services.product_id'
        )
 
        ->leftJoin(
          'et_product_task',
          'et_product_task.sno',
          '=',
          'et_milestone_history.task_id'
      )
 
        ->leftJoin(
            'et_staff as cre',
            'cre.sno',
            '=',
            'et_customer_services.cre_id'
        )
 
        ->leftJoin(
            'et_staff as pc',
            'pc.sno',
            '=',
            'et_customer_services.pc_id'
        )
 
        ->leftJoin(
            'et_staff as document_staff',
            'document_staff.sno',
            '=',
            'et_milestone_history.document_staff_id'
        )
 
        ->leftJoin(
            'et_proposal_pay_slot',
            'et_proposal_pay_slot.sno',
            '=',
            'et_milestone_mapping.milestone_id'
        )
 
        ->leftJoin(
            'et_payment_slot',
            'et_payment_slot.sno',
            '=',
            'et_proposal_pay_slot.slot_id'
        )
 
        ->where(
            'et_customer_services.branch_id',
            $branch_id
        )
 
        ->where(function ($query) {
 
                $query->where(function ($q) {
 
                    // Existing corrections
                    $q->whereIn(
                        'et_milestone_history.status',
                        [8, 9]
                    )
                    ->where(
                        'et_milestone_history.reverted_to_production',
                        1
                    );
 
                })
                ->orWhere(
                    'et_milestone_history.correction_tracking',
                    1
                );
 
            })
 
        ->select(
 
            'et_milestone_history.*',
 
            'et_milestone_mapping.service_id',
            'et_customer_services.created_at as service_created_at',
 
            'et_customer.cus_name',
 
            'et_customer.customer_id',
 
            'et_product.product_name',
 
            'et_product_task.task_name',
 
            'et_payment_slot.payment_slot_name',
 
            'cre.staff_name as cre_name',
 
            'pc.staff_name as pc_name',
 
            'document_staff.staff_name',
 
            'document_staff.staff_image'
 
        )
 
        ->orderByDesc(
            'et_milestone_history.reverted_date'
        );
 
        // Filters
        if ($search_fill != '') {
            $List->where(function ($query) use ($search_fill) {
                $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.duration_in', 'LIKE', "%{$search_fill}%");
            });
        }
   
/*
|--------------------------------------------------------------------------
| Dashboard Filter
|--------------------------------------------------------------------------
*/
 
switch ($correctionFilter) {
 
    case 'pending_assignment':
 
        $List
           
            ->where(
                'et_milestone_history.correction_hold',
                0
            )->where(
                'et_milestone_history.correction_tracking',
                1
            )->where(
                'et_milestone_history.reverted_to_production',
                1
            )
            ->where(
                'et_milestone_history.correction_completed',
                0
            )->where(
                'et_milestone_history.customer_ack_status',
                0
            )->whereIn(
                'et_milestone_history.status',
                [8, 9]
            );
 
        break;
 
 
    case 'in_progress':
 
        $List
            ->whereNotNull(
                'et_milestone_history.document_staff_id'
            )
            ->where(
                'et_milestone_history.correction_hold',
                0
            )
            ->where(
                'et_milestone_history.correction_completed',
                0
            );
 
        break;
 
 
    case 'on_hold':
 
        $List
            ->where(
                'et_milestone_history.correction_hold',
                1
            )
            ->where(
                'et_milestone_history.correction_completed',
                0
            );
 
        break;
 
 
    case 'due_today':
 
        $List
            ->whereNotNull(
                'et_milestone_history.target_completion_date'
            )
            ->whereDate(
                'et_milestone_history.target_completion_date',
                now()->toDateString()
            )
            ->where(
                'et_milestone_history.correction_completed',
                0
            );
 
        break;
 
 
    case 'overdue':
 
        $List
            ->whereNotNull(
                'et_milestone_history.target_completion_date'
            )
            ->whereDate(
                'et_milestone_history.target_completion_date',
                '<',
                now()->toDateString()
            )
            ->where(
                'et_milestone_history.correction_completed',
                0
            )
            ->where(
                'et_milestone_history.correction_hold',
                0
            );
 
        break;
 
 
    case 'completed':
 
        $List
            ->where(
                'et_milestone_history.customer_ack_status',
                1
            );
 
        break;
 
 
    case 'update_required':
 
        $List
            ->where(
                'et_milestone_history.revert_type',
                2
            )
            ->where(
                'et_milestone_history.correction_completed',
                0
            );
 
        break;
 
 
    case 'all':
    default:
 
        // No additional filter
 
        break;
}
// dd($List->get(), $staff_fill);
/*
|--------------------------------------------------------------------------
| Assigned Staff Filter
|--------------------------------------------------------------------------
*/
 
if ($staff_fill !== '' && $staff_fill !== null) {
 
    // if ($staff_fill === 'unassigned') {
 
    //     $List->whereNull(
    //         'et_milestone_history.document_staff_id'
    //     );
 
    // } else {
 
       $List->where(
        'et_milestone_history.document_staff_id',
        (int) $staff_fill
    );
   
    // }
}
 
 
/*
|--------------------------------------------------------------------------
| Correction Type Filter
|--------------------------------------------------------------------------
*/
if ($revert_type_fill !== '' && $revert_type_fill != null) {
   
        $List->where(
            'et_milestone_history.revert_type',
            (int) $revert_type_fill
        );
}
 
/*
|--------------------------------------------------------------------------
| Hold Status Filter
|--------------------------------------------------------------------------
*/
 
if ($hold_fill !== '' && $hold_fill !== null) {
 
    $List->where(
        'et_milestone_history.correction_hold',
        $hold_fill
    );
}
 
 
/*
|--------------------------------------------------------------------------
| Target Date Filter
|--------------------------------------------------------------------------
*/
 
switch ($target_fill) {
 
    case 'today':
 
        $List->whereDate(
            'et_milestone_history.target_completion_date',
            today()
        );
 
        break;
 
 
    case 'tomorrow':
 
        $List->whereDate(
            'et_milestone_history.target_completion_date',
            today()->addDay()
        );
 
        break;
 
 
    case 'this_week':
 
        $List->whereBetween(
            'et_milestone_history.target_completion_date',
            [
                now()->startOfWeek(),
                now()->endOfWeek()
            ]
        );
 
        break;
 
 
    case 'overdue':
 
        $List
            ->whereNotNull(
                'et_milestone_history.target_completion_date'
            )
            ->whereDate(
                'et_milestone_history.target_completion_date',
                '<',
                today()
            )
            ->where(
                'et_milestone_history.correction_completed',
                0
            )
            ->where(
                'et_milestone_history.correction_hold',
                0
            );
 
        break;
 
 
    case 'no_date':
 
        $List->whereNull(
            'et_milestone_history.target_completion_date'
        );
 
        break;
}
 
 
 
$List = $List ->paginate($perpage);
     foreach ($List as $row) {
 
    $year = date('Y', strtotime($row->service_created_at));
 
    $formattedId = str_pad(
        $row->service_id,
        5,
        '0',
        STR_PAD_LEFT
    );
 
    $row->formatted_service_id = "SR-{$formattedId}/{$year}";
       $row->customer_documents = DB::table('et_task_customer_documents')
        ->where('milestone_history_id', $row->sno)
        ->get();
 
    $row->customer_document_count =
        $row->customer_documents->count();
}
  $staffs = DB::table('et_staff')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.sno', '>', 1)
            ->where('et_staff.branch_id', $branch_id)
            ->whereIn('et_staff.role_id', [32, 36])
            ->select('et_staff.*', 'et_job_position.job_position_name')
            ->get();
            // return $List;
    return view(
    'content.production_management.manage_deliverables.corrections_list',
    compact('List', 'perpage', 'status_fill', 'staffs', 'correctionStats', 'correctionFilter', 'staff_fill', 'revert_type_fill', 'hold_fill', 'target_fill', 'search_fill')
);
}

    private function getDashboardCounts($serviceIds)
{
    $dashboard = [
        'total_services'      => 0,
        'not_started'         => 0,
        'in_progress'         => 0,
        'completed'           => 0,
        'qc_pending'          => 0,
        'cre_pending'         => 0,
        'customer_pending'    => 0,
        'customer_completed'  => 0,
    ];

    if (empty($serviceIds)) {
        return $dashboard;
    }

    $dashboard['total_services'] = count($serviceIds);

    foreach ($serviceIds as $serviceId) {

        $tasks = DB::table('et_milestone_history')
            ->join(
                'et_milestone_mapping',
                'et_milestone_mapping.sno',
                '=',
                'et_milestone_history.milestone_id'
            )
            ->where('et_milestone_mapping.service_id', $serviceId)
            ->select(
                'et_milestone_history.status',
                'et_milestone_history.customer_ack_status'
            )
            ->get();

        if ($tasks->isEmpty()) {
            continue;
        }

        $totalTasks = $tasks->count();

        $completed = $tasks->where('status', 10)->count();

        $notStarted = $tasks->where('status', 0)->count();

        $production = $tasks->whereIn('status', [1,2,3,4,6,8,9,11])->count();

        $qcPending = $tasks->where('status', 4)->count();

        $crePending = $tasks->where('status', 5)->count();

        $customerPending = $tasks
            ->where('status', 10)
            ->where('customer_ack_status', 0)
            ->count();

        $customerCompleted = $tasks
            ->where('customer_ack_status', 1)
            ->count();

        if ($completed == $totalTasks) {
            $dashboard['completed']++;
        }

        if ($notStarted == $totalTasks) {
            $dashboard['not_started']++;
        }

        if ($production > 0 && $completed != $totalTasks) {
            $dashboard['in_progress']++;
        }

        if ($qcPending > 0) {
            $dashboard['qc_pending']++;
        }

        if ($crePending > 0) {
            $dashboard['cre_pending']++;
        }

        if ($customerPending > 0) {
            $dashboard['customer_pending']++;
        }

        if ($customerCompleted > 0) {
            $dashboard['customer_completed']++;
        }
    }

    return $dashboard;
}

public function assignCorrectionTask(Request $request)
{

    DB::beginTransaction();

    try{

        $history = DB::table('et_milestone_history')
            ->where('sno',$request->history_id)
            ->first();

        if(!$history){

            return response()->json([
                'status'=>404,
                'message'=>'Task not found'
            ]);

        }
      $milestone = DB::table('et_milestone_mapping')
         ->where('sno', $history->milestone_id)
         ->first();

        if (!$milestone) {
            DB::rollBack();
            return false;
        }

       $oldStaff = $history->document_staff_id;

      $newStaff = $request->staff_id;

        $targetDate = $history->target_completion_date;

        if(empty($targetDate)){

            $targetDate = $request->target_date;

        }

        DB::table('et_milestone_history')
            ->where('sno',$history->sno)
            ->update([

                'document_staff_id'=>$request->staff_id,
                'target_completion_date'=>$targetDate,
                'reverted_to_production'=>0,
                'correction_hold' => 0,
                'status'=>0,
                'updated_at'=>now()

            ]);

        /*
        |--------------------------------------------------------------------------
        | Update Task
        |--------------------------------------------------------------------------
        */

        DB::table('et_task')
            ->where('sno',$history->task_id)
            ->update([

                'assign_staffs'=>json_encode([
                    $request->staff_id
                ]),

                'updated_at'=>now()

            ]);

        /*
        |--------------------------------------------------------------------------
        | Production Log
        |--------------------------------------------------------------------------
        */

        $helper = new \App\Helpers\Helpers();

        $helper->createProductionLog([

            'service_id'=>$milestone->service_id,

            'milestone_id'=>$history->milestone_id,

            'milestone_history_id'=>$history->sno,

            'action_type'=>'correction_reassigned',

            'old_value'=>[

                'staff'=>$oldStaff

            ],

            'new_value'=>[

                'staff'=>$request->staff_id,

                'target_date'=>$targetDate

            ],

            'remarks'=>$request->remarks,

            'performed_by'=>auth()->user()->user_id

        ]);

        //production points
        $this->correctionStaffPointAdjustment(
            $history->sno,
            $oldStaff,
            $request->staff_id,
            $milestone
        );
        /*
        |--------------------------------------------------------------------------
        | Notification
        |--------------------------------------------------------------------------
        */

        // Service Details
$service = DB::table('et_customer_services')
    ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
    ->where('et_customer_services.sno', $milestone->service_id)
    ->select(
        'et_customer_services.branch_id',
        'et_customer.cus_name'
    )
    ->first();

   

$notificationData = [

    'branch_id' => $service->branch_id,

    'notification_type' => 'Task',

    'notification_content' => '

        <div class="d-flex align-items-center">

            <div class="me-3">
                <span class="badge bg-light-warning">
                    <i class="mdi mdi-account-switch fs-3 text-warning"></i>
                </span>
            </div>

            <div>

                <div class="fs-7 text-warning fw-bold">
                    Correction Task Assigned
                </div>

                <div class="text-secondary fs-8 fw-semibold">

                    '.e(auth()->user()->user_name).' has assigned a correction task to you.

                    <br>

                    Customer : '.e($service->cus_name).'

                    <br>

                    Service : '.e($service->formatted_service_id ?? $milestone->service_id).'

                    <br>

                    Task : '.e($history->task_name ?? '').'

                </div>

            </div>

        </div>

    ',

    'who' => auth()->user()->user_id,

    'whom' => $request->staff_id,

    'created_by' => auth()->user()->user_id,

    'updated_by' => auth()->user()->user_id,

    'status' => 0

];

$helper->createNotificationToStaff($notificationData);
if ($oldStaff != $request->staff_id) {

    $notificationData = [

        'branch_id' => $service->branch_id,

        'notification_type' => 'Task',

        'notification_content' => '

            <div class="d-flex align-items-center">

                <div class="me-3">
                    <span class="badge bg-light-danger">
                        <i class="mdi mdi-account-remove fs-3 text-danger"></i>
                    </span>
                </div>

                <div>

                    <div class="fs-7 text-danger fw-bold">
                        Correction Task Reassigned
                    </div>

                    <div class="text-secondary fs-8 fw-semibold">

                        Your correction task has been reassigned to another staff member.

                        <br>

                        Customer : '.e($service->cus_name).'

                    </div>

                </div>

            </div>

        ',

        'who' => auth()->user()->user_id,

        'whom' => $oldStaff,

        'created_by' => auth()->user()->user_id,

        'updated_by' => auth()->user()->user_id,

        'status' => 0

    ];

    $helper->createNotificationToStaff($notificationData);

}

        DB::commit();

        return response()->json([

            'status'=>200,

            'message'=>'Correction assigned successfully.'

        ]);

    }catch(\Exception $e){

        DB::rollBack();

        return response()->json([

            'status'=>500,

            'message'=>$e->getMessage()

        ]);

    }

}
public function correctionTaskDetails($historyId)
{

    $history = DB::table('et_milestone_history')
        ->where('sno',$historyId)
        ->select(
            'document_staff_id',
            'target_completion_date'
        )
        ->first();

    return response()->json($history);

}

// public function correctionStaffPointAdjustment($historyId, $oldStaffId, $newStaffId = null, $milestone)
// {
//     DB::beginTransaction();

//     try {

//         $history = DB::table('et_milestone_history')
//             ->where('sno', $historyId)
//             ->first();

//         if (!$history) {
//             DB::rollBack();
//             return false;
//         }

//         if (!$milestone) {
//             DB::rollBack();
//             return false;
//         }
//         $serviceId = $milestone->service_id;
       

//         /*
//         |--------------------------------------------------------------------------
//         | Deduct from old staff
//         |--------------------------------------------------------------------------
//         */

//         DB::table('et_production_staff_points')->insert([

//             'proposal_id'    => $milestone->proposal_id,

//             'service_id'     => $serviceId,

//             'task_id'        => $history->task_id,

//             'staff_id'       => $oldStaffId,

//             'role_id'        => null,

//             'branch_id'      => auth()->user()->branch_id,

//             'point_type'     => 'task_correction',

//             'earned_points'  => -5,

//             'is_positive'    => 0,

//             'remarks'        => 'Correction reassigned',

//             'created_by'     => auth()->user()->user_id,

//             'created_at'     => now(),

//             'updated_at'     => now()

//         ]);

//         /*
//         |--------------------------------------------------------------------------
//         | Reward new staff only if changed
//         |--------------------------------------------------------------------------
//         */

//         if (!empty($newStaffId) && $newStaffId != $oldStaffId) {

//             DB::table('et_production_staff_points')->insert([

//                 'proposal_id'    => $milestone->proposal_id,

//                 'service_id'     => $serviceId,

//                 'task_id'        => $history->task_id,

//                 'staff_id'       => $newStaffId,

//                 'role_id'        => null,

//                 'branch_id'      => auth()->user()->branch_id,

//                 'point_type'     => 'task_reassigned_to',

//                 'earned_points'  => 5,

//                 'is_positive'    => 1,

//                 'reference_staff_id' => $oldStaffId,

//                 'remarks'        => 'Correction reassigned',

//                 'created_by'     => auth()->user()->user_id,

//                 'created_at'     => now(),

//                 'updated_at'     => now()

//             ]);

//         }

//         DB::commit();

//         return true;

//     } catch (\Exception $e) {

//         DB::rollBack();

//         \Log::error($e->getMessage());

//         return false;
//     }
// }


public function correctionStaffPointAdjustment($historyId, $oldStaffId, $newStaffId = null, $milestone)
{
    DB::beginTransaction();
 
    try {
 
        $history = DB::table('et_milestone_history')
            ->where('sno', $historyId)
            ->first();
 
        if (!$history) {
            DB::rollBack();
            return false;
        }
 
        if (!$milestone) {
            DB::rollBack();
            return false;
        }
        $serviceId = $milestone->service_id;
       
 
        /*
        |--------------------------------------------------------------------------
        | Deduct from old staff
        |--------------------------------------------------------------------------
        */
    if ((int) $history->revert_type === 1) {
        DB::table('et_production_staff_points')->insert([
 
            'proposal_id'    => $milestone->proposal_id,
 
            'service_id'     => $serviceId,
 
            'task_id'        => $history->task_id,
 
            'staff_id'       => $oldStaffId,
 
            'role_id'        => null,
 
            'branch_id'      => auth()->user()->branch_id,
 
            'point_type'     => 'task_correction',
 
            'earned_points'  => -5,
 
            'is_positive'    => 0,
 
            'remarks'        => 'Correction reassigned',
 
            'created_by'     => auth()->user()->user_id,
 
            'created_at'     => now(),
 
            'updated_at'     => now()
 
        ]);
    }
 
        /*
        |--------------------------------------------------------------------------
        | Reward new staff only if changed
        |--------------------------------------------------------------------------
        */
 
        if (!empty($newStaffId) && $newStaffId != $oldStaffId) {
 
            DB::table('et_production_staff_points')->insert([
 
                'proposal_id'    => $milestone->proposal_id,
 
                'service_id'     => $serviceId,
 
                'task_id'        => $history->task_id,
 
                'staff_id'       => $newStaffId,
 
                'role_id'        => null,
 
                'branch_id'      => auth()->user()->branch_id,
 
                'point_type'     => 'task_reassigned_to',
 
                'earned_points'  => 5,
 
                'is_positive'    => 1,
 
                'reference_staff_id' => $oldStaffId,
 
                'remarks' => $history->revert_type == 1
                                ? 'Correction reassigned'
                                : 'Updation reassigned',
 
                'created_by'     => auth()->user()->user_id,
 
                'created_at'     => now(),
 
                'updated_at'     => now()
 
            ]);
 
        }
 
        DB::commit();
 
        return true;
 
    } catch (\Exception $e) {
 
        DB::rollBack();
 
        \Log::error($e->getMessage());
 
        return false;
    }
}

public function holdCorrection(Request $request)
{
    $request->validate([
        'history_id' => 'required|integer',
        'hold_reason' => 'required|string|max:1000',
        'hold_target_date' => 'nullable|date',
    ]);

    DB::beginTransaction();

    try {

        /*
        |--------------------------------------------------------------------------
        | Get Correction
        |--------------------------------------------------------------------------
        */

        $history = DB::table('et_milestone_history')
            ->where('sno', $request->history_id)
            ->first();

        if (!$history) {

            DB::rollBack();

            return response()->json([
                'status' => 404,
                'message' => 'Correction task not found.'
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Prevent holding completed correction
        |--------------------------------------------------------------------------
        */

        if (
            isset($history->correction_completed) &&
            $history->correction_completed == 1
        ) {

            DB::rollBack();

            return response()->json([
                'status' => 400,
                'message' => 'This correction has already been completed.'
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Prevent duplicate hold
        |--------------------------------------------------------------------------
        */

        if (
            isset($history->correction_hold) &&
            $history->correction_hold == 1
        ) {

            DB::rollBack();

            return response()->json([
                'status' => 400,
                'message' => 'This correction is already on hold.'
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Store old values for production log
        |--------------------------------------------------------------------------
        */

        $oldValue = [
            'correction_hold' =>
                $history->correction_hold ?? 0,

            'correction_hold_by' =>
                $history->correction_hold_by ?? null,

            'correction_hold_date' =>
                $history->correction_hold_date ?? null,

            'correction_hold_reason' =>
                $history->correction_hold_reason ?? null,

            'correction_hold_target_date' =>
                $history->correction_hold_target_date ?? null,
        ];

        /*
        |--------------------------------------------------------------------------
        | Update Correction
        |--------------------------------------------------------------------------
        */

        $affectedRows = DB::table('et_milestone_history')
            ->where('sno', $request->history_id)
            ->update([

                'correction_hold' => 1,

                'correction_hold_by' =>
                    auth()->user()->user_id,

                'correction_hold_date' =>
                    now(),

                'correction_hold_reason' =>
                    $request->hold_reason,

                'correction_hold_target_date' =>
                    $request->hold_target_date ?: null,

                // Keep correction active
                'correction_tracking' => 1,

                'correction_completed' => 0,

                'updated_at' => now(),
            ]);

        if ($affectedRows === 0) {

            DB::rollBack();

            return response()->json([
                'status' => 400,
                'message' => 'Correction could not be placed on hold.'
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Production Log
        |--------------------------------------------------------------------------
        */

        $helper =
            new \App\Helpers\Helpers();

        $helper->createProductionLog([

            'service_id' =>
                $request->service_id ?? null,

            'milestone_id' =>
                $history->milestone_id,

            'milestone_history_id' =>
                $history->sno,

            'action_type' =>
                'correction_hold',

            'old_value' =>
                $oldValue,

            'new_value' => [

                'correction_hold' => 1,

                'correction_hold_by' =>
                    auth()->user()->user_id,

                'correction_hold_date' =>
                    now()->toDateTimeString(),

                'correction_hold_reason' =>
                    $request->hold_reason,

                'correction_hold_target_date' =>
                    $request->hold_target_date,

            ],

            'remarks' =>
                $request->hold_reason,

            'performed_by' =>
                auth()->user()->user_id,

        ]);

        /*
        |--------------------------------------------------------------------------
        | Commit
        |--------------------------------------------------------------------------
        */

        DB::commit();

        return response()->json([

            'status' => 200,

            'message' =>
                'Correction has been placed on hold successfully.'

        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        \Log::error(
            'Hold Correction Error: ' .
            $e->getMessage(),
            [
                'history_id' =>
                    $request->history_id,

                'user_id' =>
                    auth()->user()->user_id,
            ]
        );

        return response()->json([

            'status' => 500,

            'message' =>
                'Unable to hold correction.',

            'error' =>
                $e->getMessage()

        ], 500);
    }
}

}