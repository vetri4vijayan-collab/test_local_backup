<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ProductionAnalysisController extends Controller
{
    //
    public function index(Request $request)
    {
       $month = $request->month
        ?? date('Y-m');
        $staff_id = $request->staff_id ?? '';
        $from_date = Carbon::parse($month)
            ->startOfMonth()
            ->format('Y-m-d');
        $to_date = Carbon::parse($month)
            ->endOfMonth()
            ->format('Y-m-d');

        $staffs = DB::table('et_staff')
            ->where('status', 0)
            ->whereIn('role_id', [32, 36])
            ->orderBy('staff_name')
            ->get();
$workingDays = Carbon::parse($from_date)
    ->diffInWeekdays(
        Carbon::parse($to_date)
    ) + 1;
       $production = $this->getProductionData(
        $from_date,
        $to_date,
    );

    $dashboard = $this->getDashboardData(
    $from_date,
    $to_date,
    $staff_id,
    $workingDays
);
// return($production);
    return view(
         'content.production_management.manage_task.analysis',
        compact(
            'production',
            'dashboard',
            'staffs',
            'from_date',
            'to_date',
            'month',
            'workingDays'
        )
    );
    }
    private function getProductionData($from_date, $to_date, $staff_id = '')
    {
        $query = DB::table('et_daily_tasks as dt')
            ->join('et_staff as st', 'st.sno', '=', 'dt.staff_id')

            ->leftJoin(
                DB::raw("
                    (
                        SELECT
                            staff_id,
                            task_id,
                            SUM(TIME_TO_SEC(duration))/3600 as actual_hours
                        FROM et_task_log
                        WHERE status = 1
                        GROUP BY staff_id, task_id
                    ) tl
                "),
                function ($join) {
                    $join->on('tl.staff_id', '=', 'dt.staff_id')
                        ->on('tl.task_id', '=', 'dt.task_id');
                }
            )

            ->select(
                'dt.staff_id',
                'st.staff_name',
                'st.staff_image',

                DB::raw('COUNT(DISTINCT dt.task_id) as total_tasks'),

                DB::raw('SUM(dt.task_hours) as assigned_hours'),

                DB::raw('ROUND(IFNULL(SUM(tl.actual_hours),0),2) as actual_hours'),

                DB::raw('SUM(CASE WHEN dt.rework_check = 1 THEN 1 ELSE 0 END) as reworks'),

                DB::raw('SUM(CASE WHEN dt.is_correction = 1 THEN 1 ELSE 0 END) as corrections'),

                DB::raw('SUM(CASE WHEN dt.emergency_chk = 1 THEN 1 ELSE 0 END) as emergencies'),

                DB::raw('SUM(CASE WHEN dt.critical_chk = 1 THEN 1 ELSE 0 END) as criticals')
            )

            ->whereBetween('dt.task_date', [$from_date, $to_date])
            ->where('dt.status', '!=', 2);

        if (!empty($staff_id)) {
            $query->where('dt.staff_id', $staff_id);
        }

        return $query
            ->groupBy(
                'dt.staff_id',
                'st.staff_name',
                'st.staff_image'
            )
            ->orderBy('actual_hours', 'DESC')
            ->get();
    }

private function getDashboardData(
    $from_date,
    $to_date,
    $staff_id = '',
    $workingDays = 0
)
{
    $production = $this->getProductionData(
        $from_date,
        $to_date,
        $staff_id
    );

    $totalAssignedHours =
        $production->sum('assigned_hours');

    $totalActualHours =
        $production->sum('actual_hours');

    $totalTasks =
        $production->sum('total_tasks');

    $totalStaffs =
        $production->count();

    $avgEfficiency =
        $totalAssignedHours > 0
            ? (
                $totalActualHours /
                $totalAssignedHours
            ) * 100
            : 0;

    $availableHours =
        $workingDays * 8 * $totalStaffs;

    $avgUtilization =
        $availableHours > 0
            ? (
                $totalActualHours /
                $availableHours
            ) * 100
            : 0;

    return [
        'totalTasks' => $totalTasks,
        'totalAssignedHours' => round($totalAssignedHours, 2),
        'totalActualHours' => round($totalActualHours, 2),
        'avgEfficiency' => round($avgEfficiency, 2),
        'avgUtilization' => round($avgUtilization, 2),
    ];
}
    public function filter(Request $request)
    {
        $from_date = $request->from_date;
        $to_date = $request->to_date;
        $staff_id = $request->staff_id;

        $production = $this->getProductionData(
            $from_date,
            $to_date,
            $staff_id
        );

        return view(
            'production.analysis_table',
            compact('production')
        )->render();
    }
}
