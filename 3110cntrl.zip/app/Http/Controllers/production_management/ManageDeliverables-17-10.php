<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use App\Models\ManageDeliverablesModel;
use Illuminate\Support\Facades\File;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use App\Services\WasabiFileService;

class ManageDeliverables extends Controller
{

//   public function index(Request $request)
//   {
//     $entity_id = $request->user()->entity_id;
//     $user_id = $request->user()->user_id;
//     $userRole = $request->user()->role_id;
//     $branch_id = $request->user()->branch_id;
 
//     $search_fill = $request->search_fill ?? '';
//     $cat_fill = $request->cat_fill ?? '';
//     $product_fill = $request->product_fill ?? '';
//     $status_fill = $request->status_fill ?? '';
//     $filter_on = $request->filter_on ?? '';
 
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     // dd($perpage);
//     $dashboard = [
//         'total_services' => 0,
//         'qc_verified' => 0,
//         'payment_pending' => 0,
//         'ready_customer' => 0,
//         'customer_accepted' => 0,
//         'customer_concerns' => 0,
//         'correction_pending' => 0,
//         'update_required' => 0,
//          'waiting_cre_acknowledge' => 0,
//         'waiting_bh_acknowledge' => 0,
//     ];
 
//     $dashboardQuery = DB::table('et_milestone_history as mh')
//     ->join(
//         'et_milestone_mapping as mm',
//         'mm.sno',
//         '=',
//         'mh.milestone_id'
//     )
//     ->join(
//         'et_customer_services as cs',
//         'cs.sno',
//         '=',
//         'mm.service_id'
//     )
//      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'mm.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//       ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//       ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//     ->where('cs.branch_id', $branch_id)
//     ->where('cs.work_order_check', 3)
//     ->where('mm.milestone_status', 1);
//     if ($userRole == 16) {
 
//         $dashboardQuery->where(
//             'cs.cre_id',
//             $user_id
//         );
//     }
//     $dashboard['total_services'] = (clone $dashboardQuery)
//     ->distinct('cs.sno')
//     ->count('cs.sno');
 
// $dashboard['qc_verified'] = (clone $dashboardQuery)
//     ->where('mh.status', 5)
//     ->count();
 
// $dashboard['update_required'] = (clone $dashboardQuery)
//     ->where('mh.status', 6)
//     ->count();
 
// $dashboard['customer_concerns'] = (clone $dashboardQuery)
//     ->where('mh.status', 7)
//     ->count();
 
// $dashboard['correction_pending'] = (clone $dashboardQuery)
//     ->where('mh.status', 11)
//     ->count();
 
// $dashboard['ready_customer'] = (clone $dashboardQuery)
//     ->where('mh.status', 10)
//     ->where('mh.customer_ack_status', 0)
//     ->count();
 
// $dashboard['customer_accepted'] = (clone $dashboardQuery)
//     ->where('mh.status', 10)
//     ->where('mh.customer_ack_status', 1)
//     ->count();
 
// $dashboard['payment_pending'] = (clone $dashboardQuery)
//     ->where('mh.status', 5)
//     ->where('et_transaction.payment_status', 0)
//     ->count();
 
// // ---------------------------------------------------
// // WAITING FOR CRE ACKNOWLEDGEMENT
// // ---------------------------------------------------
 
// $dashboard['waiting_cre_acknowledge'] = DB::table('et_milestone_mapping as mm')
//     ->join(
//         'et_customer_services as cs',
//         'cs.sno',
//         '=',
//         'mm.service_id'
//     )
//     ->where('cs.branch_id', $branch_id)
//     ->where('cs.work_order_check', 3)
//     ->where('mm.milestone_status', 1)
 
//     // CRE has not acknowledged
//     ->where('mm.cre_acknowledged', 0)
 
//     // BH also not acknowledged
//     ->where('mm.bh_acknowledged', 0)
 
//     // Must have at least one task
//     ->whereExists(function ($q) {
 
//         $q->select(DB::raw(1))
//             ->from('et_milestone_history as mh')
//             ->whereColumn(
//                 'mh.milestone_id',
//                 'mm.sno'
//             );
 
//     })
 
//     // There must NOT be any incomplete/unacknowledged task
//     ->whereNotExists(function ($q) {
 
//         $q->select(DB::raw(1))
//             ->from('et_milestone_history as mh2')
//             ->whereColumn(
//                 'mh2.milestone_id',
//                 'mm.sno'
//             )
//             ->where(function ($status) {
 
//                 $status
//                     ->whereNull('mh2.customer_ack_status')
//                     ->orWhere(
//                         'mh2.customer_ack_status',
//                         '!=',
//                         1
//                     );
 
//             });
 
//     });
 
// if ($userRole == 16) {
 
//     $dashboard['waiting_cre_acknowledge'] = DB::table('et_milestone_mapping as mm')
//         ->join(
//             'et_customer_services as cs',
//             'cs.sno',
//             '=',
//             'mm.service_id'
//         )
//         ->where('cs.branch_id', $branch_id)
//         ->where('cs.work_order_check', 3)
//         ->where('mm.milestone_status', 1)
//         ->where('cs.cre_id', $user_id)
//         ->where('mm.cre_acknowledged', 0)
//         ->where('mm.bh_acknowledged', 0)
 
//         ->whereExists(function ($q) {
 
//             $q->select(DB::raw(1))
//                 ->from('et_milestone_history as mh')
//                 ->whereColumn(
//                     'mh.milestone_id',
//                     'mm.sno'
//                 );
 
//         })
 
//         ->whereNotExists(function ($q) {
 
//             $q->select(DB::raw(1))
//                 ->from('et_milestone_history as mh2')
//                 ->whereColumn(
//                     'mh2.milestone_id',
//                     'mm.sno'
//                 )
//                 ->where(function ($status) {
 
//                     $status
//                         ->whereNull('mh2.customer_ack_status')
//                         ->orWhere(
//                             'mh2.customer_ack_status',
//                             '!=',
//                             1
//                         );
 
//                 });
 
//         })
//         ->distinct()
//         ->count('mm.sno');
// }
 
 
// $dashboard['waiting_bh_ack'] = (clone $dashboardQuery)
//     ->where('mm.cre_acknowledged', 1)
//     ->where('mm.bh_acknowledged', 0)
//     ->distinct()
//     ->count('mm.sno');
//     // return $ListTable;
//     // Dropdown data
//     $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
//     $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
//     $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
//     $DeliCheck_list = DB::table('et_delivery_attachment_checklist')->where('status', 0)->orderBy('delivery_attachment_checklist')->get();
//     $staffs = DB::table('et_staff')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.sno', '>', 1)
//       ->where('et_staff.branch_id', $branch_id)
//       ->select('et_staff.*', 'et_job_position.job_position_name')
//       ->get();
 
//       $paymentStatusQuery = DB::table('et_payment as ep')
//     ->join(
//         'et_transaction as et',
//         'et.payment_id',
//         '=',
//         'ep.sno'
//     )
//     ->select(
//         'ep.pay_slot_id',
//         DB::raw('MAX(et.payment_status) as payment_status')
//     )
//     ->groupBy('ep.pay_slot_id');
//     // MAIN QUERY
//     $List = DB::table('et_milestone_mapping')
//       ->select(
//         'et_customer_services.sno',
//         'et_customer_services.customer_id',
//         'et_customer_services.service_check',
//         'et_customer_services.cre_id',
//         'et_customer_services.pc_id',
//         'et_customer_services.product_id',
//         'et_customer_services.package_id',
//         'et_customer_services.product_package',
//         'et_customer_services.production_staffs_id',
//         'et_customer_services.branch_id',
//         'et_customer_services.work_order_check',
//         'et_customer_services.created_at',
//         'et_customer_services.published_status',
//         'et_customer_services.status',
//         'et_customer_services.proposal_id',
//         'et_customer_services.variant_variable_ids',
//         'et_product.product_name',
       
//         'et_customer.sno as customer_sno',
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_customer.country_code',
//         'et_customer.customer_id AS cus_id',
 
//         'et_product.duration',
//         'et_product.duration_in',
 
//         'et_customer_services.journal_check',
//         'et_package.actual_duration',
 
//         'cre.staff_name as cre_name',
//         'cre.staff_image as cre_image',
 
//         'pc.staff_name as pc_name',
//         'pc.staff_image as pc_image',
       
//         'et_proposal.journal_selection_completed',
//         'et_proposal.journal_selection_date',
 
//         'et_work_order.deliverable_date',
//         'et_work_order.customer_end_date',
 
//         'et_proposal.biography_link_sent',
//         'et_proposal.biography_link_sent_at',
//         'et_proposal.biography_link_sent_by',
//         'biosent_staff.staff_name as biography_link_sent_staff_name',
//         'biosent_staff.staff_image as biography_link_sent_staff_image',
 
//         DB::raw("GROUP_CONCAT(DISTINCT pro_staff.staff_name SEPARATOR ', ') as pro_staff_names"),
//         DB::raw("GROUP_CONCAT(DISTINCT pro_staff.staff_image SEPARATOR ', ') as pro_staff_images"),
//         DB::raw('COUNT(ab.sno) as biography_count'),
//         DB::raw("
//           EXISTS(
//               SELECT 1
//               FROM et_customer_services cs
//               INNER JOIN et_product p
//                   ON p.sno = cs.product_id
//               WHERE cs.proposal_id = et_customer_services.proposal_id
//                 AND p.journal_product = 1
//           ) as has_journal_product
//           "),
//         DB::raw('MAX(payment_status.payment_status) as payment_status'),
//         'et_product_category.product_category_name',
//         'et_product_category.sno as prd_cat_id',
//         'et_product_category.jouranal_check',
//         // 'et_transaction.payment_status'
//       )
//       ->where('et_customer_services.branch_id', $branch_id)
//       ->where('et_customer_services.work_order_check', 3)
//       ->join('et_customer_services', 'et_milestone_mapping.service_id', 'et_customer_services.sno')
//       ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
//       ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
//       ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
//       ->leftJoin('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//       ->leftJoin('et_staff as biosent_staff', 'biosent_staff.sno', '=', 'et_proposal.biography_link_sent_by')
//       ->leftJoin('et_staff as pro_staff', function ($join) {
//         $join->whereRaw("JSON_SEARCH(et_customer_services.production_staffs_id, 'one', CAST(pro_staff.sno AS CHAR)) IS NOT NULL");
//       })
//       ->leftJoin('et_package', function ($join) {
//         $join->on('et_package.sno', '=', 'et_customer_services.package_id')
//           ->where('et_customer_services.product_package', '=', 2);
//       })
//       ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//     //   ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//     //   ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//     ->leftJoinSub(
//             $paymentStatusQuery,
//             'payment_status',
//             function ($join) {
//                 $join->on(
//                     'payment_status.pay_slot_id',
//                     '=',
//                     'et_proposal_pay_slot.sno'
//                 );
//             }
//         )
//       ->join(
//             'et_work_order',
//             'et_work_order.service_id',
//             '=',
//             'et_customer_services.sno'
//         )
//       ->leftJoin('et_author_biography as ab', function ($join) {
//               $join->on('ab.service_id', '=', 'et_customer_services.sno')
//                   ->where('ab.status', 0);
//           });
//     $userRole = $request->user()->role_id;
//     if ($userRole == 16) {
//                 $List->where('et_customer_services.cre_id', $user_id);
//             }
//     // Filters
//     if ($search_fill != '') {
//       $List->where(function ($query) use ($search_fill) {
//         $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_product_category.product_category_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_product.duration_in', 'LIKE', "%{$search_fill}%");
//       });
//     }
 
//     $status_filter = $request->status_filter ?? '';
 
//   if (!empty($status_filter)) {
 
//       $List->whereExists(function ($q) use ($status_filter) {
 
//           $q->select(DB::raw(1))
//               ->from('et_milestone_history')
//               ->whereColumn(
//                   'et_milestone_history.milestone_id',
//                   'et_milestone_mapping.sno'
//               );
 
//           switch ($status_filter) {
 
//               case 'qc_verified':
 
//                   $q->where('et_milestone_history.status', 5);
 
//                   break;
 
//               case 'completed': // Ready for Delivery (CRE Verified)
 
//                   $q->where('et_milestone_history.status', 10)
//                     ->where('et_milestone_history.customer_ack_status', 0);
 
//                   break;
 
//               case 'accepted':
 
//                   $q->where('et_milestone_history.customer_ack_status', 1);
 
//                   break;
 
//               case 'concerns':
 
//                   $q->where('et_milestone_history.status', 7);
 
//                   break;
 
//               case 'correction':
 
//                   // CRE Rejected
//                   $q->where('et_milestone_history.status', 11);
 
//                   break;
 
//               case 'rework':
 
//                   // QC Rejected
//                   $q->where('et_milestone_history.status', 6);
 
//                   break;
 
//               case 'in_progress':
 
//                   // Payment Pending after QC Verification
//                   $q->where('et_milestone_history.status', 5)
//                     ->where('payment_status.payment_status', 0);
 
//                   break;
 
//               case 'waiting_cre_ack':
 
//                 $q->where('et_milestone_mapping.cre_acknowledged', 0)
//                 ->where('et_milestone_mapping.bh_acknowledged', 0)
 
//                 // At least one task must exist
//                 ->whereExists(function ($taskQuery) {
 
//                     $taskQuery->select(DB::raw(1))
//                         ->from('et_milestone_history as milestone_task')
//                         ->whereColumn(
//                             'milestone_task.milestone_id',
//                             'et_milestone_mapping.sno'
//                         );
 
//                 })
 
//                 // No incomplete task should exist
//                 ->whereNotExists(function ($taskQuery) {
 
//                     $taskQuery->select(DB::raw(1))
//                         ->from('et_milestone_history as pending_task')
//                         ->whereColumn(
//                             'pending_task.milestone_id',
//                             'et_milestone_mapping.sno'
//                         )
//                         ->where(function ($statusQuery) {
 
//                             $statusQuery
//                                 ->whereNull('pending_task.customer_ack_status')
//                                 ->orWhere(
//                                     'pending_task.customer_ack_status',
//                                     '!=',
//                                     1
//                                 );
 
//                         });
 
//                 });
 
//                 break;
 
//                 case 'waiting_bh_ack':
 
//                     $q->where('et_milestone_mapping.cre_acknowledged', 1)
//                     ->where('et_milestone_mapping.bh_acknowledged', 0);
 
//                     break;
 
//               case 'not_started':
//               default:
//                   // No additional filter
//                   break;
//           }
//       });
//   }
//     if ($cat_fill) $List->where('et_product_category.sno', $cat_fill);
//     if ($product_fill) $List->where('et_product.sno', $product_fill);
//     if ($status_fill || $status_fill === '0') {
//       $List->where('et_customer_services.status', $status_fill);
//     }
 
//     $List->groupBy(
//       'et_customer_services.sno',
//       'et_customer_services.customer_id',
//       'et_customer_services.cre_id',
//       'et_customer_services.pc_id',
//       'et_customer_services.product_id',
//       'et_customer_services.package_id',
//       'et_customer_services.product_package',
//       'et_customer_services.service_check',
//       'et_customer_services.production_staffs_id',
//       'et_customer_services.branch_id',
//       'et_customer_services.work_order_check',
//       'et_customer_services.created_at',
//       'et_customer_services.published_status',
//       'et_customer_services.status',
//       'et_customer_services.proposal_id',
//       'et_customer_services.variant_variable_ids',
 
//       'et_customer.cus_name',
//       'et_customer.cus_mobile',
//       'et_customer.cus_email_id',
//       'et_customer.country_code',
//       'et_customer.customer_id',
//       'et_customer.sno',
 
//       'et_product.duration',
//       'et_product.duration_in',
//       'et_product.product_name',
//       'et_proposal.biography_link_sent',
//     'et_proposal.biography_link_sent_at',
//     'et_proposal.biography_link_sent_by',
//     'biosent_staff.staff_name',
//     'biosent_staff.staff_image',
 
//       'et_package.actual_duration',
 
//       'et_work_order.deliverable_date',
//      'et_work_order.customer_end_date',
 
//       'et_customer_services.journal_check',
//       'cre.staff_name',
//       'cre.staff_image',
//       'pc.staff_name',
//       'pc.staff_image',
 
//       'et_product_category.product_category_name',
//       'et_product_category.sno',
//       'et_product_category.jouranal_check',
//       'et_proposal.journal_selection_completed',
//         'et_proposal.journal_selection_date',
//         // 'et_transaction.payment_status'
//     )
//       ->orderByRaw('et_work_order.deliverable_date IS NULL ASC')
//       ->orderBy('et_work_order.deliverable_date', 'ASC')
//       ->where('et_milestone_mapping.milestone_status', 1);
//       // ->where('et_milestone_mapping.delivery_status', 1);
 
 
//     // Clone query for service IDs
//     $serviceIds = (clone $List)->pluck('et_customer_services.sno')->toArray();
 
//     // If no services → show blank page
//     if (empty($serviceIds)) {
//       $emptyPaginator = new LengthAwarePaginator([], 0, $perpage, $page, [
//         'path' => $request->url(),
//         'query' => $request->query(),
//       ]);
//       return view('content.production_management.manage_deliverables.list', [
//         'ListTable' => $emptyPaginator,
//         'perpage' => $perpage,
//         'search_fill' => $search_fill,
//         'Product_cat_list' => $Product_cat_list,
//         'Product_ist' => $Product_list,
//         'DeliCheck_list' => $DeliCheck_list,
//         'staffs' => $staffs,
//         'Check_list' => $Check_list,
//         'cat_fill' => $cat_fill,
//         'product_fill' => $product_fill,
//         'status_fill' => $status_fill,
//         'dashboard'=>$dashboard
//       ]);
//     }
 
//     // Task count per service
//     $taskCounts = DB::table('et_milestone_mapping')
//       ->whereIn('service_id', $serviceIds)
//       ->where('status', '!=', 2)
//       ->select('service_id', 'task_ids')
//       ->get()
//       ->groupBy('service_id');
 
//     // Collect all task IDs
//     $allTaskIds = [];
//     foreach ($taskCounts as $serviceTasks) {
//       foreach ($serviceTasks as $m) {
//         $ids = json_decode($m->task_ids, true);
//         if (is_array($ids)) $allTaskIds = array_merge($allTaskIds, $ids);
//       }
//     }
//     $allTaskIds = array_unique($allTaskIds);
 
//     // Get task names
//     $taskNames = [];
//     if (!empty($allTaskIds)) {
//       $taskNames = DB::table('et_product_task')
//         ->whereIn('sno', $allTaskIds)
//         ->pluck('task_name', 'sno')
//         ->toArray();
//     }
 
//     // Milestone data
//     $milestoneData = DB::table('et_milestone_mapping')
//       ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//       ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//       ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//       ->select(
//         'et_milestone_mapping.service_id',
//         'et_milestone_mapping.sno',
//         'et_milestone_mapping.milestone_status',
//         'et_milestone_mapping.document_status',
//         'et_milestone_mapping.task_ids',
//         'et_payment_slot.payment_slot_name',
//         'et_proposal_pay_slot.payable_amount',
//         'et_proposal_pay_slot.paidAmount',
//         'et_transaction.payment_status',
       
//         'et_milestone_mapping.cre_acknowledged',
//         'et_milestone_mapping.cre_acknowledged_by',
//         'et_milestone_mapping.cre_acknowledged_date',
//         'et_milestone_mapping.cre_completion_notes',
 
//         'et_milestone_mapping.bh_acknowledged',
//         'et_milestone_mapping.bh_acknowledged_by',
//         'et_milestone_mapping.bh_acknowledged_date',
//         'et_milestone_mapping.bh_completion_notes',
//         'et_milestone_mapping.service_id',
//       )
//       ->whereIn('et_milestone_mapping.service_id', $serviceIds)
//       ->where('et_milestone_mapping.status', '!=', 2)
//       ->where('et_milestone_mapping.milestone_status', 1)
//       // ->where('et_milestone_mapping.services_status', '>', 0)
//       ->get()
//       ->groupBy('service_id');
   
 
//   $completedServiceIds = DB::table('et_milestone_history as mh')
//     ->join('et_milestone_mapping as mm', 'mm.sno', '=', 'mh.milestone_id')
//     ->whereIn('mh.status', [
//     5, // QC Verified
//     6, // Sent to customer
//     7, // Accepted
//     8, // Correction
//     9, // Updation
//     10, // Resubmitted
//     11 //CRE Rejected
// ]) // QC Verified
//     ->distinct()
//     ->pluck('mm.service_id')
//     ->toArray();
 
 
//   if (!empty($completedServiceIds)) {
 
//     $List->whereIn(
//         'et_customer_services.sno',
//         $completedServiceIds
//     );
 
// } else {
 
//     $List->whereRaw('1 = 0');
// }
//     // APPLY PAGINATION
//     $ListTable = $List->paginate($perpage);
// //   $dashboard['total_services'] = count($ListTable);
 
//   // ---------------------------------------------------
// // CORRECTION COUNTS
// // ---------------------------------------------------
 
// $correctionCounts = DB::table('et_production_logs')
//     ->select(
//         'milestone_history_id',
//         DB::raw('COUNT(*) as correction_count')
//     )
//     ->where('action_type', 'customer_correction')
//     ->whereNotNull('milestone_history_id')
//     ->groupBy('milestone_history_id')
//     ->pluck('correction_count', 'milestone_history_id');  // ADD task & milestone data to each row
//     foreach ($ListTable as $list) {
 
//     $list->biography_exists = $list->biography_count > 0;
//       // Total tasks
//       $serviceTaskIds = [];
//       if (isset($taskCounts[$list->sno])) {
//         foreach ($taskCounts[$list->sno] as $milestone) {
//           $ids = json_decode($milestone->task_ids, true);
//           if (is_array($ids)) $serviceTaskIds = array_merge($serviceTaskIds, $ids);
//         }
//       }
//       $list->total_task_count = count(array_unique($serviceTaskIds));
 
//       // Milestone details
//       $milestoneDataWithTasks = [];
//     //   dump([
//     //     'service_id' => $list->sno,
//     //     'milestone_exists' => isset($milestoneData[$list->sno]),
//     //     'milestone_count' => isset($milestoneData[$list->sno]) ? count($milestoneData[$list->sno]) : 0,
//     // ]);
 
//       if (isset($milestoneData[$list->sno])) {
 
//         foreach ($milestoneData[$list->sno] as $m) {
//           // 1️⃣ Get product-task IDs from milestone JSON
//           $productTaskIds = json_decode($m->task_ids, true) ?? [];
 
//           // 2️⃣ Get task names
 
//           // 3️⃣ Map to et_task IDs
//           $etTaskIds = DB::table('et_task')
//             ->where('service_id', $list->sno)
//             ->whereIn('task_name', $productTaskIds)
//             ->pluck('sno')
//             ->toArray();
 
//           // 4️⃣ Get daily tasks
//           $dailyTasks = DB::table('et_daily_tasks')
//             ->where('service_id', $list->sno)
//             ->whereIn('task_id', $etTaskIds)
//             ->get();
 
//           // ---------------------------------------------------
//           // 5️⃣ GET UNIQUE STAFF FOR THIS MILESTONE
//           // ---------------------------------------------------
//           $staffIdsRaw = DB::table('et_pro_milestone_staffs')
//             ->where('service_id', $list->sno)
//             ->where('milestone_id', $m->sno)
//             ->pluck('staff_ids')
//             ->toArray();
 
//           $staffIds = [];
 
//           foreach ($staffIdsRaw as $row) {
//             // Decode JSON array string like ["25","58"]
//             $decoded = json_decode($row, true);
 
//             if (is_array($decoded)) {
//               $staffIds = array_merge($staffIds, $decoded);
//             }
//           }
 
//           // Remove duplicates & reindex
//           $staffIds = array_unique($staffIds);
 
//           $staffDetails = [];
 
//           if (!empty($staffIds)) {
//             $staffDetails = DB::table('et_staff')
//               ->whereIn('sno', $staffIds)
//               ->where('status', 0)
//               ->select('sno', 'staff_name', 'staff_image')
//               ->get()
//               ->toArray();
//           }
 
//     $historyTasks = DB::table('et_milestone_history as mh')
//     ->leftJoin('et_product_task as pt', 'pt.sno', '=', 'mh.task_id')
//     ->leftJoin('et_staff as ds', 'ds.sno', '=', 'mh.document_staff_id')
//     ->leftJoin(
//     'et_staff as resolved_staff',
//     'resolved_staff.sno',
//     '=',
//     'mh.customer_issue_resolved_by'
//     )
//     ->leftJoin(
//         'et_staff as cre_complete_staff',
//         'cre_complete_staff.sno',
//         '=',
//         'mh.completed_by_cre_by'
//     )
//     ->where('mh.milestone_id', $m->sno)
//     ->select(
//         'mh.*',
//         'pt.task_name',
//         'ds.staff_name',
//         'ds.staff_image',
//         'resolved_staff.staff_name as resolved_staff_name',
//         'resolved_staff.staff_image as resolved_staff_image',
//         'cre_complete_staff.staff_name as completed_staff_name',
//         'cre_complete_staff.staff_image as completed_staff_image',
//     )
//     ->get();
 
//      $productTasks = [];
 
// foreach ($historyTasks as $task) {
 
//     $taskDocuments = DB::table('et_task_documents')
//     ->where('milestone_history_id', $task->sno)
//     ->orderByDesc('created_at')
//     ->get()
//     ->groupBy(function ($doc) {
//         return date('Y-m-d H:i', strtotime($doc->created_at));
//     });
//     $task->customer_documents = DB::table('et_task_customer_documents')
//       ->where('milestone_history_id', $task->sno)
//       ->get();
//     $task->customer_document_count = $task->customer_documents->count();
//     $correction_count = DB::table('et_production_logs')
//         ->where('milestone_history_id', $task->sno)
//         ->where('action_type', 'customer_correction')
//         ->count();
//     $productTasks[] = (object)[
//         'sno' => $task->sno,
//         'et_task_id' => $task->sno,
//         'milestone_id' => $task->milestone_id,
//         'task_name' => $task->task_name,
//         'percentage' => $task->percentage,
//         'status' => $task->status,
//         'reverted_remarks ' => $task->reverted_remarks ,
//         'cre_remark'=>$task->cre_remark,
//         'customer_ack_status' => $task->customer_ack_status ?? 0,
//         'customer_ack_date' => $task->customer_ack_date,
//          'customer_response' => $task->customer_response,
//         'customer_reject_remarks' => $task->customer_reject_remarks,
//         'resolved_staff_name' => $task->resolved_staff_name??'',
//         'resolved_staff_image' => $task->resolved_staff_image??'',
//         'document_staff' => (object)[
//             'sno' => $task->document_staff_id,
//             'staff_name' => $task->staff_name,
//             'staff_image' => $task->staff_image,
//         ],
//         'completion_type'=>$task->completion_type??0,
//         'documents' => $taskDocuments,
//         'document_count' => $taskDocuments->flatten()->count(),
//          'customer_documents' => $task->customer_documents,
//         'customer_document_count' => $task->customer_documents->count(),
//         'customer_ack_sent' => $task->customer_ack_sent,
//         'customer_ack_sent_by' => $task->customer_ack_sent_by,
//         'customer_ack_sent_date' => $task->customer_ack_sent_date,
//         'completed_by_cre' => $task->completed_by_cre,
 
//       'completed_by_cre_by' => $task->completed_by_cre_by,
 
//       'completed_by_cre_date' => $task->completed_by_cre_date,
 
//       'completed_by_cre_remarks' => $task->completed_by_cre_remarks,
 
//       'completed_cre_name' => $task->completed_staff_name,
//       'completed_cre_image' => $task->completed_staff_image,
//       'service_id'=> $list->sno,
//       'correction_count'=> (int) (
//     $correctionCounts[$task->sno] ?? 0
// ),
//     ];
 
   
// }
 
//       $totalTasks = count($productTasks);
 
//       $completedTasks = collect($productTasks)
//           ->where('customer_ack_status', 1) // QC Verified
//           ->count();
// $milestoneCorrectionCount = collect($productTasks)
//     ->sum(function ($task) {
//         return (int) ($task->correction_count ?? 0);
//     });
//       $percentage = $totalTasks > 0
//           ? round(($completedTasks / $totalTasks) * 100)
//           : 0;
//           // ---------------------------------------------------
//           // FINAL STRUCTURE
//           // ---------------------------------------------------
//           $milestoneDataWithTasks[] = (object)[
//             'mile_stone_name'        => $m->payment_slot_name,
//             'payable_amount'         => $m->payable_amount,
//             'paidAmount'             => $m->paidAmount,
//             'task_ids'               => $m->task_ids,
//             'mile_sno'               => $m->sno,
//             'status'                 => $m->milestone_status,
//             'document_status'        => $m->document_status,
//             'payment_status'        => $m->payment_status,
 
//             'cre_acknowledged'        => $m->cre_acknowledged,
//             'cre_acknowledged_by'        => $m->cre_acknowledged_by,
//             'cre_acknowledged_date'        => $m->cre_acknowledged_date,
//             'cre_acknowledged_notes'        => $m->cre_completion_notes,
 
//             'bh_acknowledged'        => $m->bh_acknowledged,
//             'bh_acknowledged_by'        => $m->bh_acknowledged_by,
//             'bh_acknowledged_date'        => $m->bh_acknowledged_date,
//             'bh_acknowledged_notes'        => $m->bh_completion_notes,
//             'service_id'=> $m->service_id,
           
//             // TASKS
//           'task_names' => $productTasks,
//             'task_count' => count($productTasks),
 
//             'total_daily_tasks' => $totalTasks,
//             'completed_daily_tasks' => $completedTasks,
//             'milestone_percentage' => $percentage,
//             // STAFF
//             'assigned_staff'         => $staffDetails,  // array of {sno, staff_name, staff_image}
//             'staff_count'            => count($staffDetails),
//             'correction_count' => $milestoneCorrectionCount,
//           ];
//         }
//       }
 
       
//       foreach ($milestoneDataWithTasks as $mile) {
 
//         $mile->total_tasks = DB::table('et_milestone_history')
//             ->where('milestone_id', $mile->mile_sno)
//             ->count();
 
//         $mile->accepted_tasks = DB::table('et_milestone_history')
//             ->where('milestone_id', $mile->mile_sno)
//             ->where('customer_ack_status', 1)
//             ->count();
 
//         $mile->ready_for_cre =
//             $mile->total_tasks > 0 &&
//             $mile->total_tasks == $mile->accepted_tasks;
//     }
//       $list->milestone_data = $milestoneDataWithTasks;
//       $list->correction_count = collect(
//               $milestoneDataWithTasks
//           )->sum(function ($milestone) {
 
//               return (int) (
//                   $milestone->correction_count ?? 0
//               );
 
//           });
//     }
 
 
//     // return $ListTable;
//     // Dropdown data
//     $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
//     $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
//     $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
//     $staffs = DB::table('et_staff')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.sno', '>', 1)
//       ->where('et_staff.branch_id', $branch_id)
//       ->select('et_staff.*', 'et_job_position.job_position_name')
//       ->get();
//       if($request->ajax==true){
//   return $ListTable;    
//       }
// // return $ListTable;
//     return view('content.production_management.manage_deliverables.list', [
//       'ListTable' => $ListTable,
//       'perpage' => $perpage,
//       'search_fill' => $search_fill,
//       'Product_cat_list' => $Product_cat_list,
//       'Product_ist' => $Product_list,
//       'staffs' => $staffs,
//       'Check_list' => $Check_list,
//       'DeliCheck_list' => $DeliCheck_list,
//       'cat_fill' => $cat_fill,
//       'product_fill' => $product_fill,
//       'status_fill' => $status_fill,
//       'filter_on' => $filter_on,
//       'dashboard' => $dashboard
//     ]);
//   }

//   public function index(Request $request)
//   {
//     $entity_id = $request->user()->entity_id;
//     $user_id = $request->user()->user_id;
//     $userRole = $request->user()->role_id;
//     $branch_id = $request->user()->branch_id;
 
//     $search_fill = $request->search_fill ?? '';
//     $cat_fill = $request->cat_fill ?? '';
//     $product_fill = $request->product_fill ?? '';
//     $status_fill = $request->status_fill ?? '';
//     $filter_on = $request->filter_on ?? '';
 
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     // dd($perpage);
//     $dashboard = [
//         'total_services' => 0,
//         'qc_verified' => 0,
//         'payment_pending' => 0,
//         'ready_customer' => 0,
//         'customer_accepted' => 0,
//         'customer_concerns' => 0,
//         'correction_pending' => 0,
//         'update_required' => 0,
//          'waiting_cre_acknowledge' => 0,
//         'waiting_bh_acknowledge' => 0,
//     ];
//       $paymentStatusQuery = DB::table('et_payment as ep')
//     ->join(
//         'et_transaction as et',
//         'et.payment_id',
//         '=',
//         'ep.sno'
//     )
//     ->select(
//         'ep.pay_slot_id',
//         DB::raw('MAX(et.payment_status) as payment_status')
//     )
//     ->groupBy('ep.pay_slot_id');
 
//     $dashboardQuery = DB::table('et_milestone_history as mh')
//     ->join(
//         'et_milestone_mapping as mm',
//         'mm.sno',
//         '=',
//         'mh.milestone_id'
//     )
//     ->join(
//         'et_customer_services as cs',
//         'cs.sno',
//         '=',
//         'mm.service_id'
//     )
//      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'mm.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//       ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//       ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//       ->leftJoinSub(
//             $paymentStatusQuery,
//             'payment_status',
//             function ($join) {
//                 $join->on(
//                     'payment_status.pay_slot_id',
//                     '=',
//                     'et_proposal_pay_slot.sno'
//                 );
//             }
//         )
//     ->where('cs.branch_id', $branch_id)
//     ->where('cs.work_order_check', 3)
//     ->where('mm.milestone_status', 1);
//     if ($userRole == 16) {
 
//         $dashboardQuery->where(
//             'cs.cre_id',
//             $user_id
//         );
//     }
//     $dashboard['total_services'] = (clone $dashboardQuery)
//     ->distinct('cs.sno')
//     ->count('cs.sno');
 
// $dashboard['qc_verified'] = (clone $dashboardQuery)
//     ->where('mh.status', 5)
//     ->count();
 
// $dashboard['update_required'] = (clone $dashboardQuery)
//     ->where('mh.status', 6)
//     ->count();
 
// $dashboard['customer_concerns'] = (clone $dashboardQuery)
//     ->where('mh.status', 7)
//     ->count();
 
// $dashboard['correction_pending'] = (clone $dashboardQuery)
//     ->where('mh.status', 11)
//     ->count();
 
// $dashboard['ready_customer'] = (clone $dashboardQuery)
//     ->where('mh.status', 10)
//     ->where('mh.customer_ack_status', 0)
//     ->count();
 
// $dashboard['customer_accepted'] = (clone $dashboardQuery)
//     ->where('mh.status', 10)
//     ->where('mh.customer_ack_status', 1)
//     ->count();
 
// $dashboard['payment_pending'] = (clone $dashboardQuery)
//     ->where('mh.status', 5)
//     ->where('payment_status.payment_status', 0)
//     ->count();
 
// // ---------------------------------------------------
// // WAITING FOR CRE ACKNOWLEDGEMENT
// // ---------------------------------------------------
 
// $dashboard['waiting_cre_acknowledge'] = DB::table('et_milestone_mapping as mm')
//     ->join(
//         'et_customer_services as cs',
//         'cs.sno',
//         '=',
//         'mm.service_id'
//     )
//     ->where('cs.branch_id', $branch_id)
//     ->where('cs.work_order_check', 3)
//     ->where('mm.milestone_status', 1)
 
//     // CRE has not acknowledged
//     ->where('mm.cre_acknowledged', 0)
 
//     // BH also not acknowledged
//     ->where('mm.bh_acknowledged', 0)
 
//     // Must have at least one task
//     ->whereExists(function ($q) {
 
//         $q->select(DB::raw(1))
//             ->from('et_milestone_history as mh')
//             ->whereColumn(
//                 'mh.milestone_id',
//                 'mm.sno'
//             );
 
//     })
 
//     // There must NOT be any incomplete/unacknowledged task
//     ->whereNotExists(function ($q) {
 
//         $q->select(DB::raw(1))
//             ->from('et_milestone_history as mh2')
//             ->whereColumn(
//                 'mh2.milestone_id',
//                 'mm.sno'
//             )
//             ->where(function ($status) {
 
//                 $status
//                     ->whereNull('mh2.customer_ack_status')
//                     ->orWhere(
//                         'mh2.customer_ack_status',
//                         '!=',
//                         1
//                     );
 
//             });
 
//     });
 
// if ($userRole == 16) {
 
//     $dashboard['waiting_cre_acknowledge'] = DB::table('et_milestone_mapping as mm')
//         ->join(
//             'et_customer_services as cs',
//             'cs.sno',
//             '=',
//             'mm.service_id'
//         )
//         ->where('cs.branch_id', $branch_id)
//         ->where('cs.work_order_check', 3)
//         ->where('mm.milestone_status', 1)
//         ->where('cs.cre_id', $user_id)
//         ->where('mm.cre_acknowledged', 0)
//         ->where('mm.bh_acknowledged', 0)
 
//         ->whereExists(function ($q) {
 
//             $q->select(DB::raw(1))
//                 ->from('et_milestone_history as mh')
//                 ->whereColumn(
//                     'mh.milestone_id',
//                     'mm.sno'
//                 );
 
//         })
 
//         ->whereNotExists(function ($q) {
 
//             $q->select(DB::raw(1))
//                 ->from('et_milestone_history as mh2')
//                 ->whereColumn(
//                     'mh2.milestone_id',
//                     'mm.sno'
//                 )
//                 ->where(function ($status) {
 
//                     $status
//                         ->whereNull('mh2.customer_ack_status')
//                         ->orWhere(
//                             'mh2.customer_ack_status',
//                             '!=',
//                             1
//                         );
 
//                 });
 
//         })
//         ->distinct()
//         ->count('mm.sno');
// }
 
 
// $dashboard['waiting_bh_ack'] = (clone $dashboardQuery)
//     ->where('mm.cre_acknowledged', 1)
//     ->where('mm.bh_acknowledged', 0)
//     ->distinct()
//     ->count('mm.sno');
//     // return $ListTable;
//     // Dropdown data
//     $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
//     $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
//     $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
//     $DeliCheck_list = DB::table('et_delivery_attachment_checklist')->where('status', 0)->orderBy('delivery_attachment_checklist')->get();
//     $staffs = DB::table('et_staff')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.sno', '>', 1)
//       ->where('et_staff.branch_id', $branch_id)
//       ->select('et_staff.*', 'et_job_position.job_position_name')
//       ->get();
 
   
//     // MAIN QUERY
//     $List = DB::table('et_milestone_mapping')
//       ->select(
//         'et_customer_services.sno',
//         'et_customer_services.customer_id',
//         'et_customer_services.service_check',
//         'et_customer_services.cre_id',
//         'et_customer_services.pc_id',
//         'et_customer_services.product_id',
//         'et_customer_services.package_id',
//         'et_customer_services.product_package',
//         'et_customer_services.production_staffs_id',
//         'et_customer_services.branch_id',
//         'et_customer_services.work_order_check',
//         'et_customer_services.created_at',
//         'et_customer_services.published_status',
//         'et_customer_services.status',
//         'et_customer_services.proposal_id',
//         'et_customer_services.variant_variable_ids',
//         'et_product.product_name',
       
//         'et_customer.sno as customer_sno',
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_customer.country_code',
//         'et_customer.customer_id AS cus_id',
 
//         'et_product.duration',
//         'et_product.duration_in',
 
//         'et_customer_services.journal_check',
//         'et_package.actual_duration',
 
//         'cre.staff_name as cre_name',
//         'cre.staff_image as cre_image',
 
//         'pc.staff_name as pc_name',
//         'pc.staff_image as pc_image',
       
//         'et_proposal.journal_selection_completed',
//         'et_proposal.journal_selection_date',
 
//         'et_work_order.deliverable_date',
//         'et_work_order.customer_end_date',
 
//         'et_proposal.biography_link_sent',
//         'et_proposal.biography_link_sent_at',
//         'et_proposal.biography_link_sent_by',
//         'biosent_staff.staff_name as biography_link_sent_staff_name',
//         'biosent_staff.staff_image as biography_link_sent_staff_image',
 
//         DB::raw("GROUP_CONCAT(DISTINCT pro_staff.staff_name SEPARATOR ', ') as pro_staff_names"),
//         DB::raw("GROUP_CONCAT(DISTINCT pro_staff.staff_image SEPARATOR ', ') as pro_staff_images"),
//         DB::raw('COUNT(ab.sno) as biography_count'),
//         DB::raw("
//           EXISTS(
//               SELECT 1
//               FROM et_customer_services cs
//               INNER JOIN et_product p
//                   ON p.sno = cs.product_id
//               WHERE cs.proposal_id = et_customer_services.proposal_id
//                 AND p.journal_product = 1
//           ) as has_journal_product
//           "),
//         DB::raw('MAX(payment_status.payment_status) as payment_status'),
//         'et_product_category.product_category_name',
//         'et_product_category.sno as prd_cat_id',
//         'et_product_category.jouranal_check',
//         // 'et_transaction.payment_status'
//       )
//       ->where('et_customer_services.branch_id', $branch_id)
//       ->where('et_customer_services.work_order_check', 3)
//       ->join('et_customer_services', 'et_milestone_mapping.service_id', 'et_customer_services.sno')
//       ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
//       ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
//       ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
//       ->leftJoin('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//       ->leftJoin('et_staff as biosent_staff', 'biosent_staff.sno', '=', 'et_proposal.biography_link_sent_by')
//       ->leftJoin('et_staff as pro_staff', function ($join) {
//         $join->whereRaw("JSON_SEARCH(et_customer_services.production_staffs_id, 'one', CAST(pro_staff.sno AS CHAR)) IS NOT NULL");
//       })
//       ->leftJoin('et_package', function ($join) {
//         $join->on('et_package.sno', '=', 'et_customer_services.package_id')
//           ->where('et_customer_services.product_package', '=', 2);
//       })
//       ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//     //   ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//     //   ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//     ->leftJoinSub(
//             $paymentStatusQuery,
//             'payment_status',
//             function ($join) {
//                 $join->on(
//                     'payment_status.pay_slot_id',
//                     '=',
//                     'et_proposal_pay_slot.sno'
//                 );
//             }
//         )
//       ->leftJoin(
//             'et_work_order',
//             'et_work_order.service_id',
//             '=',
//             'et_customer_services.sno'
//         )
//       ->leftJoin('et_author_biography as ab', function ($join) {
//               $join->on('ab.service_id', '=', 'et_customer_services.sno')
//                   ->where('ab.status', 0);
//           });
//     $userRole = $request->user()->role_id;
//     if ($userRole == 16) {
//                 $List->where('et_customer_services.cre_id', $user_id);
//             }
//     // Filters
//     if ($search_fill != '') {
//       $List->where(function ($query) use ($search_fill) {
//         $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_product_category.product_category_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_product.duration_in', 'LIKE', "%{$search_fill}%");
//       });
//     }
 
//     $status_filter = $request->status_filter ?? '';
 
//   if (!empty($status_filter)) {
 
//       $List->whereExists(function ($q) use ($status_filter) {
 
//           $q->select(DB::raw(1))
//               ->from('et_milestone_history')
//               ->whereColumn(
//                   'et_milestone_history.milestone_id',
//                   'et_milestone_mapping.sno'
//               );
 
//           switch ($status_filter) {
 
//               case 'qc_verified':
 
//                   $q->where('et_milestone_history.status', 5);
 
//                   break;
 
//               case 'completed': // Ready for Delivery (CRE Verified)
 
//                   $q->where('et_milestone_history.status', 10)
//                     ->where('et_milestone_history.customer_ack_status', 0);
 
//                   break;
 
//               case 'accepted':
 
//                   $q->where('et_milestone_history.customer_ack_status', 1);
 
//                   break;
 
//               case 'concerns':
 
//                   $q->where('et_milestone_history.status', 7);
 
//                   break;
 
//               case 'correction':
 
//                   // CRE Rejected
//                   $q->where('et_milestone_history.status', 11);
 
//                   break;
 
//               case 'rework':
 
//                   // QC Rejected
//                   $q->where('et_milestone_history.status', 6);
 
//                   break;
 
//              case 'in_progress':
 
//                 $q->where(
//                     'et_milestone_history.status',
//                     5
//                 );
 
//                 break;
 
//               case 'waiting_cre_ack':
 
//                 $q->where('et_milestone_mapping.cre_acknowledged', 0)
//                 ->where('et_milestone_mapping.bh_acknowledged', 0)
 
//                 // At least one task must exist
//                 ->whereExists(function ($taskQuery) {
 
//                     $taskQuery->select(DB::raw(1))
//                         ->from('et_milestone_history as milestone_task')
//                         ->whereColumn(
//                             'milestone_task.milestone_id',
//                             'et_milestone_mapping.sno'
//                         );
 
//                 })
 
//                 // No incomplete task should exist
//                 ->whereNotExists(function ($taskQuery) {
 
//                     $taskQuery->select(DB::raw(1))
//                         ->from('et_milestone_history as pending_task')
//                         ->whereColumn(
//                             'pending_task.milestone_id',
//                             'et_milestone_mapping.sno'
//                         )
//                         ->where(function ($statusQuery) {
 
//                             $statusQuery
//                                 ->whereNull('pending_task.customer_ack_status')
//                                 ->orWhere(
//                                     'pending_task.customer_ack_status',
//                                     '!=',
//                                     1
//                                 );
 
//                         });
 
//                 });
 
//                 break;
 
//                 case 'waiting_bh_ack':
 
//                     $q->where('et_milestone_mapping.cre_acknowledged', 1)
//                     ->where('et_milestone_mapping.bh_acknowledged', 0);
 
//                     break;
 
//               case 'not_started':
//               default:
//                   // No additional filter
//                   break;
//           }
//       });
//   }
//   if ($status_filter === 'in_progress') {
 
//     $List->where(
//         'payment_status.payment_status',
//         0
//     );
// }
//     if ($cat_fill) $List->where('et_product_category.sno', $cat_fill);
//     if ($product_fill) $List->where('et_product.sno', $product_fill);
//     if ($status_fill || $status_fill === '0') {
//       $List->where('et_customer_services.status', $status_fill);
//     }
 
//     $List->groupBy(
//       'et_customer_services.sno',
//       'et_customer_services.customer_id',
//       'et_customer_services.cre_id',
//       'et_customer_services.pc_id',
//       'et_customer_services.product_id',
//       'et_customer_services.package_id',
//       'et_customer_services.product_package',
//       'et_customer_services.service_check',
//       'et_customer_services.production_staffs_id',
//       'et_customer_services.branch_id',
//       'et_customer_services.work_order_check',
//       'et_customer_services.created_at',
//       'et_customer_services.published_status',
//       'et_customer_services.status',
//       'et_customer_services.proposal_id',
//       'et_customer_services.variant_variable_ids',
 
//       'et_customer.cus_name',
//       'et_customer.cus_mobile',
//       'et_customer.cus_email_id',
//       'et_customer.country_code',
//       'et_customer.customer_id',
//       'et_customer.sno',
 
//       'et_product.duration',
//       'et_product.duration_in',
//       'et_product.product_name',
//       'et_proposal.biography_link_sent',
//     'et_proposal.biography_link_sent_at',
//     'et_proposal.biography_link_sent_by',
//     'biosent_staff.staff_name',
//     'biosent_staff.staff_image',
 
//       'et_package.actual_duration',
 
//       'et_work_order.deliverable_date',
//      'et_work_order.customer_end_date',
 
//       'et_customer_services.journal_check',
//       'cre.staff_name',
//       'cre.staff_image',
//       'pc.staff_name',
//       'pc.staff_image',
 
//       'et_product_category.product_category_name',
//       'et_product_category.sno',
//       'et_product_category.jouranal_check',
//       'et_proposal.journal_selection_completed',
//         'et_proposal.journal_selection_date',
//         // 'et_transaction.payment_status'
//     )
//       ->orderByRaw('et_work_order.deliverable_date IS NULL ASC')
//       ->orderBy('et_work_order.deliverable_date', 'ASC');
//     //   ->where('et_milestone_mapping.milestone_status', 1);
//       // ->where('et_milestone_mapping.delivery_status', 1);
 
 
//     // Clone query for service IDs
//     $serviceIds = (clone $List)->pluck('et_customer_services.sno')->toArray();
 
//     // If no services → show blank page
//     if (empty($serviceIds)) {
//       $emptyPaginator = new LengthAwarePaginator([], 0, $perpage, $page, [
//         'path' => $request->url(),
//         'query' => $request->query(),
//       ]);
//       return view('content.production_management.manage_deliverables.list', [
//         'ListTable' => $emptyPaginator,
//         'perpage' => $perpage,
//         'search_fill' => $search_fill,
//         'Product_cat_list' => $Product_cat_list,
//         'Product_ist' => $Product_list,
//         'DeliCheck_list' => $DeliCheck_list,
//         'staffs' => $staffs,
//         'Check_list' => $Check_list,
//         'cat_fill' => $cat_fill,
//         'product_fill' => $product_fill,
//         'status_fill' => $status_fill,
//         'dashboard'=>$dashboard
//       ]);
//     }
 
//     // Task count per service
//     $taskCounts = DB::table('et_milestone_mapping')
//       ->whereIn('service_id', $serviceIds)
//       ->where('status', '!=', 2)
//       ->select('service_id', 'task_ids')
//       ->get()
//       ->groupBy('service_id');
 
//     // Collect all task IDs
//     $allTaskIds = [];
//     foreach ($taskCounts as $serviceTasks) {
//       foreach ($serviceTasks as $m) {
//         $ids = json_decode($m->task_ids, true);
//         if (is_array($ids)) $allTaskIds = array_merge($allTaskIds, $ids);
//       }
//     }
//     $allTaskIds = array_unique($allTaskIds);
 
//     // Get task names
//     $taskNames = [];
//     if (!empty($allTaskIds)) {
//       $taskNames = DB::table('et_product_task')
//         ->whereIn('sno', $allTaskIds)
//         ->pluck('task_name', 'sno')
//         ->toArray();
//     }
 
//     // Milestone data
//     $milestoneData = DB::table('et_milestone_mapping')
//       ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//       ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//       ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//       ->select(
//         'et_milestone_mapping.service_id',
//         'et_milestone_mapping.sno',
//         'et_milestone_mapping.milestone_status',
//         'et_milestone_mapping.document_status',
//         'et_milestone_mapping.task_ids',
//         'et_payment_slot.payment_slot_name',
//         'et_proposal_pay_slot.payable_amount',
//         'et_proposal_pay_slot.paidAmount',
//         'et_transaction.payment_status',
       
//         'et_milestone_mapping.cre_acknowledged',
//         'et_milestone_mapping.cre_acknowledged_by',
//         'et_milestone_mapping.cre_acknowledged_date',
//         'et_milestone_mapping.cre_completion_notes',
 
//         'et_milestone_mapping.bh_acknowledged',
//         'et_milestone_mapping.bh_acknowledged_by',
//         'et_milestone_mapping.bh_acknowledged_date',
//         'et_milestone_mapping.bh_completion_notes',
//         'et_milestone_mapping.service_id',
//       )
//       ->whereIn('et_milestone_mapping.service_id', $serviceIds)
//       ->where('et_milestone_mapping.status', '!=', 2)
//     //   ->where('et_milestone_mapping.milestone_status', 1)
//       // ->where('et_milestone_mapping.services_status', '>', 0)
//       ->get()
//       ->groupBy('service_id');
   
 
// // ---------------------------------------------------
// // DELIVERABLE SERVICES
// // ---------------------------------------------------
// // A service becomes a Deliverable once at least one
// // task has been submitted into et_milestone_history.
// //
// // It must remain in Deliverables permanently,
// // regardless of task/milestone/NOC/customer status.
// // ---------------------------------------------------
 
// $List->whereExists(function ($q) {
 
//     $q->select(DB::raw(1))
//         ->from('et_milestone_mapping as deliverable_mm')
//         ->join(
//             'et_milestone_history as deliverable_mh',
//             'deliverable_mh.milestone_id',
//             '=',
//             'deliverable_mm.sno'
//         )
//         ->whereColumn(
//             'deliverable_mm.service_id',
//             'et_customer_services.sno'
//         );
 
// });
//     // APPLY PAGINATION
//     $ListTable = $List->paginate($perpage);
// //   $dashboard['total_services'] = count($ListTable);
 
//   // ---------------------------------------------------
// // CORRECTION COUNTS
// // ---------------------------------------------------
 
// $correctionCounts = DB::table('et_production_logs')
//     ->select(
//         'milestone_history_id',
//         DB::raw('COUNT(*) as correction_count')
//     )
//     ->where('action_type', 'customer_correction')
//     ->whereNotNull('milestone_history_id')
//     ->groupBy('milestone_history_id')
//     ->pluck('correction_count', 'milestone_history_id');  // ADD task & milestone data to each row
//     foreach ($ListTable as $list) {
 
//     $list->biography_exists = $list->biography_count > 0;
//     $list->deliverable_completed = false;
 
//         if (!empty($list->milestone_data)) {
 
//             $allTasks = collect($list->milestone_data)
//                 ->flatMap(function ($milestone) {
//                     return $milestone->task_names ?? [];
//                 });
 
//             if ($allTasks->isNotEmpty()) {
 
//                 $list->deliverable_completed =
//                     $allTasks->every(function ($task) {
 
//                         return (int) ($task->customer_ack_status ?? 0) === 1;
 
//                     });
 
//             }
//         }
//       // Total tasks
//       $serviceTaskIds = [];
//       if (isset($taskCounts[$list->sno])) {
//         foreach ($taskCounts[$list->sno] as $milestone) {
//           $ids = json_decode($milestone->task_ids, true);
//           if (is_array($ids)) $serviceTaskIds = array_merge($serviceTaskIds, $ids);
//         }
//       }
//       $list->total_task_count = count(array_unique($serviceTaskIds));
 
//       // Milestone details
//       $milestoneDataWithTasks = [];
//     //   dump([
//     //     'service_id' => $list->sno,
//     //     'milestone_exists' => isset($milestoneData[$list->sno]),
//     //     'milestone_count' => isset($milestoneData[$list->sno]) ? count($milestoneData[$list->sno]) : 0,
//     // ]);
 
//       if (isset($milestoneData[$list->sno])) {
 
//         foreach ($milestoneData[$list->sno] as $m) {
//           // 1️⃣ Get product-task IDs from milestone JSON
//           $productTaskIds = json_decode($m->task_ids, true) ?? [];
 
//           // 2️⃣ Get task names
 
//           // 3️⃣ Map to et_task IDs
//           $etTaskIds = DB::table('et_task')
//             ->where('service_id', $list->sno)
//             ->whereIn('task_name', $productTaskIds)
//             ->pluck('sno')
//             ->toArray();
 
//           // 4️⃣ Get daily tasks
//           $dailyTasks = DB::table('et_daily_tasks')
//             ->where('service_id', $list->sno)
//             ->whereIn('task_id', $etTaskIds)
//             ->get();
 
//           // ---------------------------------------------------
//           // 5️⃣ GET UNIQUE STAFF FOR THIS MILESTONE
//           // ---------------------------------------------------
//           $staffIdsRaw = DB::table('et_pro_milestone_staffs')
//             ->where('service_id', $list->sno)
//             ->where('milestone_id', $m->sno)
//             ->pluck('staff_ids')
//             ->toArray();
 
//           $staffIds = [];
 
//           foreach ($staffIdsRaw as $row) {
//             // Decode JSON array string like ["25","58"]
//             $decoded = json_decode($row, true);
 
//             if (is_array($decoded)) {
//               $staffIds = array_merge($staffIds, $decoded);
//             }
//           }
 
//           // Remove duplicates & reindex
//           $staffIds = array_unique($staffIds);
 
//           $staffDetails = [];
 
//           if (!empty($staffIds)) {
//             $staffDetails = DB::table('et_staff')
//               ->whereIn('sno', $staffIds)
//               ->where('status', 0)
//               ->select('sno', 'staff_name', 'staff_image')
//               ->get()
//               ->toArray();
//           }
 
//     $historyTasks = DB::table('et_milestone_history as mh')
//     ->leftJoin('et_product_task as pt', 'pt.sno', '=', 'mh.task_id')
//     ->leftJoin('et_staff as ds', 'ds.sno', '=', 'mh.document_staff_id')
//     ->leftJoin(
//     'et_staff as resolved_staff',
//     'resolved_staff.sno',
//     '=',
//     'mh.customer_issue_resolved_by'
//     )
//     ->leftJoin(
//         'et_staff as cre_complete_staff',
//         'cre_complete_staff.sno',
//         '=',
//         'mh.completed_by_cre_by'
//     )
//     ->where('mh.milestone_id', $m->sno)
//     ->select(
//         'mh.*',
//         'pt.task_name',
//         'ds.staff_name',
//         'ds.staff_image',
//         'resolved_staff.staff_name as resolved_staff_name',
//         'resolved_staff.staff_image as resolved_staff_image',
//         'cre_complete_staff.staff_name as completed_staff_name',
//         'cre_complete_staff.staff_image as completed_staff_image',
//     )
//     ->get();
 
//      $productTasks = [];
 
// foreach ($historyTasks as $task) {
 
//     $taskDocuments = DB::table('et_task_documents')
//     ->where('milestone_history_id', $task->sno)
//     ->orderByDesc('created_at')
//     ->get()
//     ->groupBy(function ($doc) {
//         return date('Y-m-d H:i', strtotime($doc->created_at));
//     });
//     $task->customer_documents = DB::table('et_task_customer_documents')
//       ->where('milestone_history_id', $task->sno)
//       ->get();
//     $task->customer_document_count = $task->customer_documents->count();
//     $correction_count = DB::table('et_production_logs')
//         ->where('milestone_history_id', $task->sno)
//         ->where('action_type', 'customer_correction')
//         ->count();
//     $productTasks[] = (object)[
//         'sno' => $task->sno,
//         'et_task_id' => $task->sno,
//         'milestone_id' => $task->milestone_id,
//         'task_name' => $task->task_name,
//         'percentage' => $task->percentage,
//         'status' => $task->status,
//         'reverted_remarks ' => $task->reverted_remarks ,
//         'cre_remark'=>$task->cre_remark,
//         'customer_ack_status' => $task->customer_ack_status ?? 0,
//         'customer_ack_date' => $task->customer_ack_date,
//          'customer_response' => $task->customer_response,
//         'customer_reject_remarks' => $task->customer_reject_remarks,
//         'resolved_staff_name' => $task->resolved_staff_name??'',
//         'resolved_staff_image' => $task->resolved_staff_image??'',
//         'document_staff' => (object)[
//             'sno' => $task->document_staff_id,
//             'staff_name' => $task->staff_name,
//             'staff_image' => $task->staff_image,
//         ],
//         'completion_type'=>$task->completion_type??0,
//         'documents' => $taskDocuments,
//         'document_count' => $taskDocuments->flatten()->count(),
//          'customer_documents' => $task->customer_documents,
//         'customer_document_count' => $task->customer_documents->count(),
//         'customer_ack_sent' => $task->customer_ack_sent,
//         'customer_ack_sent_by' => $task->customer_ack_sent_by,
//         'customer_ack_sent_date' => $task->customer_ack_sent_date,
//         'completed_by_cre' => $task->completed_by_cre,
 
//       'completed_by_cre_by' => $task->completed_by_cre_by,
 
//       'completed_by_cre_date' => $task->completed_by_cre_date,
 
//       'completed_by_cre_remarks' => $task->completed_by_cre_remarks,
 
//       'completed_cre_name' => $task->completed_staff_name,
//       'completed_cre_image' => $task->completed_staff_image,
//       'service_id'=> $list->sno,
//       'correction_count'=> (int) (
//     $correctionCounts[$task->sno] ?? 0
// ),
//     ];
 
   
// }
 
//       $totalTasks = count($productTasks);
 
//       $completedTasks = collect($productTasks)
//           ->where('customer_ack_status', 1) // QC Verified
//           ->count();
// $milestoneCorrectionCount = collect($productTasks)
//     ->sum(function ($task) {
//         return (int) ($task->correction_count ?? 0);
//     });
//       $percentage = $totalTasks > 0
//           ? round(($completedTasks / $totalTasks) * 100)
//           : 0;
//           // ---------------------------------------------------
//           // FINAL STRUCTURE
//           // ---------------------------------------------------
//           $milestoneDataWithTasks[] = (object)[
//             'mile_stone_name'        => $m->payment_slot_name,
//             'payable_amount'         => $m->payable_amount,
//             'paidAmount'             => $m->paidAmount,
//             'task_ids'               => $m->task_ids,
//             'mile_sno'               => $m->sno,
//             'status'                 => $m->milestone_status,
//             'document_status'        => $m->document_status,
//             'payment_status'        => $m->payment_status,
 
//             'cre_acknowledged'        => $m->cre_acknowledged,
//             'cre_acknowledged_by'        => $m->cre_acknowledged_by,
//             'cre_acknowledged_date'        => $m->cre_acknowledged_date,
//             'cre_acknowledged_notes'        => $m->cre_completion_notes,
 
//             'bh_acknowledged'        => $m->bh_acknowledged,
//             'bh_acknowledged_by'        => $m->bh_acknowledged_by,
//             'bh_acknowledged_date'        => $m->bh_acknowledged_date,
//             'bh_acknowledged_notes'        => $m->bh_completion_notes,
//             'service_id'=> $m->service_id,
           
//             // TASKS
//           'task_names' => $productTasks,
//             'task_count' => count($productTasks),
 
//             'total_daily_tasks' => $totalTasks,
//             'completed_daily_tasks' => $completedTasks,
//             'milestone_percentage' => $percentage,
//             // STAFF
//             'assigned_staff'         => $staffDetails,  // array of {sno, staff_name, staff_image}
//             'staff_count'            => count($staffDetails),
//             'correction_count' => $milestoneCorrectionCount,
//           ];
//         }
//       }
 
       
//       foreach ($milestoneDataWithTasks as $mile) {
 
//         $mile->total_tasks = DB::table('et_milestone_history')
//             ->where('milestone_id', $mile->mile_sno)
//             ->count();
 
//         $mile->accepted_tasks = DB::table('et_milestone_history')
//             ->where('milestone_id', $mile->mile_sno)
//             ->where('customer_ack_status', 1)
//             ->count();
 
//         $mile->ready_for_cre =
//             $mile->total_tasks > 0 &&
//             $mile->total_tasks == $mile->accepted_tasks;
//     }
//       $list->milestone_data = $milestoneDataWithTasks;
//       $list->correction_count = collect(
//               $milestoneDataWithTasks
//           )->sum(function ($milestone) {
 
//               return (int) (
//                   $milestone->correction_count ?? 0
//               );
 
//           });
//     }
 
 
//     // return $ListTable;
//     // Dropdown data
//     $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
//     $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
//     $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
//     $staffs = DB::table('et_staff')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.sno', '>', 1)
//       ->where('et_staff.branch_id', $branch_id)
//       ->select('et_staff.*', 'et_job_position.job_position_name')
//       ->get();
//       if($request->ajax==true){
//   return $ListTable;    
//       }
// // return $ListTable;
//     return view('content.production_management.manage_deliverables.list', [
//       'ListTable' => $ListTable,
//       'perpage' => $perpage,
//       'search_fill' => $search_fill,
//       'Product_cat_list' => $Product_cat_list,
//       'Product_ist' => $Product_list,
//       'staffs' => $staffs,
//       'Check_list' => $Check_list,
//       'DeliCheck_list' => $DeliCheck_list,
//       'cat_fill' => $cat_fill,
//       'product_fill' => $product_fill,
//       'status_fill' => $status_fill,
//       'filter_on' => $filter_on,
//       'dashboard' => $dashboard
//     ]);
//   }
 
//   public function index(Request $request)
//   {
//     $entity_id = $request->user()->entity_id;
//     $user_id = $request->user()->user_id;
//     $userRole = $request->user()->role_id;
//     $branch_id = $request->user()->branch_id;
 
//     $search_fill = $request->search_fill ?? '';
//     $cat_fill = $request->cat_fill ?? '';
//     $product_fill = $request->product_fill ?? '';
//     $status_fill = $request->status_fill ?? '';
//     $filter_on = $request->filter_on ?? '';
 
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     // dd($perpage);
//     $dashboard = [
//         'total_services' => 0,
//         'qc_verified' => 0,
//         'payment_pending' => 0,
//         'ready_customer' => 0,
//         'customer_accepted' => 0,
//         'customer_concerns' => 0,
//         'correction_pending' => 0,
//         'update_required' => 0,
//          'waiting_cre_acknowledge' => 0,
//         'waiting_bh_acknowledge' => 0,
//     ];
//       $paymentStatusQuery = DB::table('et_payment as ep')
//     ->join(
//         'et_transaction as et',
//         'et.payment_id',
//         '=',
//         'ep.sno'
//     )
//     ->select(
//         'ep.pay_slot_id',
//         DB::raw('MAX(et.payment_status) as payment_status')
//     )
//     ->groupBy('ep.pay_slot_id');
 
//     $dashboardQuery = DB::table('et_milestone_history as mh')
//     ->join(
//         'et_milestone_mapping as mm',
//         'mm.sno',
//         '=',
//         'mh.milestone_id'
//     )
//     ->join(
//         'et_customer_services as cs',
//         'cs.sno',
//         '=',
//         'mm.service_id'
//     )
//      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'mm.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//       ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//       ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//       ->leftJoinSub(
//             $paymentStatusQuery,
//             'payment_status',
//             function ($join) {
//                 $join->on(
//                     'payment_status.pay_slot_id',
//                     '=',
//                     'et_proposal_pay_slot.sno'
//                 );
//             }
//         )
//     ->where('cs.branch_id', $branch_id)
//     ->where('cs.work_order_check', 3)
//     ->where('mm.milestone_status', 1);
//     if ($userRole == 16) {
 
//         $dashboardQuery->where(
//             'cs.cre_id',
//             $user_id
//         );
//     }
//     $dashboard['total_services'] = (clone $dashboardQuery)
//     ->distinct('cs.sno')
//     ->count('cs.sno');
 
//     $dashboard['qc_verified'] = (clone $dashboardQuery)
//         ->where('mh.status', 5)
//         ->count();
 
//     $dashboard['update_required'] = (clone $dashboardQuery)
//         ->where('mh.status', 6)
//         ->count();
 
//     $dashboard['customer_concerns'] = (clone $dashboardQuery)
//         ->where('mh.status', 7)
//         ->count();
 
//     $dashboard['correction_pending'] = (clone $dashboardQuery)
//         ->where('mh.status', 11)
//         ->count();
 
//     $dashboard['ready_customer'] = (clone $dashboardQuery)
//         ->where('mh.status', 10)
//         ->where('mh.customer_ack_status', 0)
//         ->count();
 
//     $dashboard['customer_accepted'] = (clone $dashboardQuery)
//         ->where('mh.status', 10)
//         ->where('mh.customer_ack_status', 1)
//         ->count();
 
//     $dashboard['payment_pending'] = (clone $dashboardQuery)
//         ->where('mh.status', 5)
//         ->where('payment_status.payment_status', 0)
//         ->count();
 
// // ---------------------------------------------------
// // WAITING FOR CRE ACKNOWLEDGEMENT
// // ---------------------------------------------------
 
// $dashboard['waiting_cre_acknowledge'] = DB::table('et_milestone_mapping as mm')
//     ->join(
//         'et_customer_services as cs',
//         'cs.sno',
//         '=',
//         'mm.service_id'
//     )
//     ->where('cs.branch_id', $branch_id)
//     ->where('cs.work_order_check', 3)
//     ->where('mm.milestone_status', 1)
 
//     // CRE has not acknowledged
//     ->where('mm.cre_acknowledged', 0)
 
//     // BH also not acknowledged
//     ->where('mm.bh_acknowledged', 0)
 
//     // Must have at least one task
//     ->whereExists(function ($q) {
 
//         $q->select(DB::raw(1))
//             ->from('et_milestone_history as mh')
//             ->whereColumn(
//                 'mh.milestone_id',
//                 'mm.sno'
//             );
 
//     })
 
//     // There must NOT be any incomplete/unacknowledged task
//     ->whereNotExists(function ($q) {
 
//         $q->select(DB::raw(1))
//             ->from('et_milestone_history as mh2')
//             ->whereColumn(
//                 'mh2.milestone_id',
//                 'mm.sno'
//             )
//             ->where(function ($status) {
 
//                 $status
//                     ->whereNull('mh2.customer_ack_status')
//                     ->orWhere(
//                         'mh2.customer_ack_status',
//                         '!=',
//                         1
//                     );
 
//             });
 
//     });
 
// if ($userRole == 16) {
 
//     $dashboard['waiting_cre_acknowledge'] = DB::table('et_milestone_mapping as mm')
//         ->join(
//             'et_customer_services as cs',
//             'cs.sno',
//             '=',
//             'mm.service_id'
//         )
//         ->where('cs.branch_id', $branch_id)
//         ->where('cs.work_order_check', 3)
//         ->where('mm.milestone_status', 1)
//         ->where('cs.cre_id', $user_id)
//         ->where('mm.cre_acknowledged', 0)
//         ->where('mm.bh_acknowledged', 0)
 
//         ->whereExists(function ($q) {
 
//             $q->select(DB::raw(1))
//                 ->from('et_milestone_history as mh')
//                 ->whereColumn(
//                     'mh.milestone_id',
//                     'mm.sno'
//                 );
 
//         })
 
//         ->whereNotExists(function ($q) {
 
//             $q->select(DB::raw(1))
//                 ->from('et_milestone_history as mh2')
//                 ->whereColumn(
//                     'mh2.milestone_id',
//                     'mm.sno'
//                 )
//                 ->where(function ($status) {
 
//                     $status
//                         ->whereNull('mh2.customer_ack_status')
//                         ->orWhere(
//                             'mh2.customer_ack_status',
//                             '!=',
//                             1
//                         );
 
//                 });
 
//         })
//         ->distinct()
//         ->count('mm.sno');
// }
 
 
// $dashboard['waiting_bh_ack'] = (clone $dashboardQuery)
//     ->where('mm.cre_acknowledged', 1)
//     ->where('mm.bh_acknowledged', 0)
//     ->distinct()
//     ->count('mm.sno');
//     // return $ListTable;
//     // Dropdown data
//     $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
//     $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
//     $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
//     $DeliCheck_list = DB::table('et_delivery_attachment_checklist')->where('status', 0)->orderBy('delivery_attachment_checklist')->get();
//     $staffs = DB::table('et_staff')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.sno', '>', 1)
//       ->where('et_staff.branch_id', $branch_id)
//       ->select('et_staff.*', 'et_job_position.job_position_name')
//       ->get();
 
   
//     // MAIN QUERY
//     $List = DB::table('et_milestone_mapping')
//       ->select(
//         'et_customer_services.sno',
//         'et_customer_services.customer_id',
//         'et_customer_services.service_check',
//         'et_customer_services.cre_id',
//         'et_customer_services.pc_id',
//         'et_customer_services.product_id',
//         'et_customer_services.package_id',
//         'et_customer_services.product_package',
//         'et_customer_services.production_staffs_id',
//         'et_customer_services.branch_id',
//         'et_customer_services.work_order_check',
//         'et_customer_services.created_at',
//         'et_customer_services.published_status',
//         'et_customer_services.status',
//         'et_customer_services.proposal_id',
//         'et_customer_services.variant_variable_ids',
//         'et_product.product_name',
       
//         'et_customer.sno as customer_sno',
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_customer.country_code',
//         'et_customer.customer_id AS cus_id',
 
//         'et_product.duration',
//         'et_product.duration_in',
 
//         'et_customer_services.journal_check',
//         'et_package.actual_duration',
 
//         'cre.staff_name as cre_name',
//         'cre.staff_image as cre_image',
 
//         'pc.staff_name as pc_name',
//         'pc.staff_image as pc_image',
       
//         'et_proposal.journal_selection_completed',
//         'et_proposal.journal_selection_date',
 
//         'et_work_order.deliverable_date',
//         'et_work_order.customer_end_date',
 
//         'et_proposal.biography_link_sent',
//         'et_proposal.biography_link_sent_at',
//         'et_proposal.biography_link_sent_by',
//         'biosent_staff.staff_name as biography_link_sent_staff_name',
//         'biosent_staff.staff_image as biography_link_sent_staff_image',
//         'et_proposal.noc_sent_through',
//         'et_proposal.noc_sent_at',
//         'et_proposal.noc_sent_by',
//         'et_proposal.noc_sent_status',
//         'noc_sent_staff.staff_name as noc_sent_staff_name',
 
//         DB::raw("GROUP_CONCAT(DISTINCT pro_staff.staff_name SEPARATOR ', ') as pro_staff_names"),
//         DB::raw("GROUP_CONCAT(DISTINCT pro_staff.staff_image SEPARATOR ', ') as pro_staff_images"),
//         DB::raw('COUNT(ab.sno) as biography_count'),
//         DB::raw("
//           EXISTS(
//               SELECT 1
//               FROM et_customer_services cs
//               INNER JOIN et_product p
//                   ON p.sno = cs.product_id
//               WHERE cs.proposal_id = et_customer_services.proposal_id
//                 AND p.journal_product = 1
//           ) as has_journal_product
//           "),
//         DB::raw('MAX(payment_status.payment_status) as payment_status'),
//         'et_product_category.product_category_name',
//         'et_product_category.sno as prd_cat_id',
//         'et_product_category.jouranal_check',
//         // 'et_transaction.payment_status'
//       )
//       ->where('et_customer_services.branch_id', $branch_id)
//       ->where('et_customer_services.work_order_check', 3)
//       ->join('et_customer_services', 'et_milestone_mapping.service_id', 'et_customer_services.sno')
//       ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
//       ->leftJoin('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//       ->leftJoin('et_staff as noc_sent_staff','noc_sent_staff.sno','=','et_proposal.noc_sent_by')
//       ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
//       ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
//       ->leftJoin('et_staff as biosent_staff', 'biosent_staff.sno', '=', 'et_proposal.biography_link_sent_by')
//       ->leftJoin('et_staff as pro_staff', function ($join) {
//         $join->whereRaw("JSON_SEARCH(et_customer_services.production_staffs_id, 'one', CAST(pro_staff.sno AS CHAR)) IS NOT NULL");
//       })
//       ->leftJoin('et_package', function ($join) {
//         $join->on('et_package.sno', '=', 'et_customer_services.package_id')
//           ->where('et_customer_services.product_package', '=', 2);
//       })
//       ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//     //   ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//     //   ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//     ->leftJoinSub(
//             $paymentStatusQuery,
//             'payment_status',
//             function ($join) {
//                 $join->on(
//                     'payment_status.pay_slot_id',
//                     '=',
//                     'et_proposal_pay_slot.sno'
//                 );
//             }
//         )
//       ->leftJoin(
//             'et_work_order',
//             'et_work_order.service_id',
//             '=',
//             'et_customer_services.sno'
//         )
//       ->leftJoin('et_author_biography as ab', function ($join) {
//               $join->on('ab.service_id', '=', 'et_customer_services.sno')
//                   ->where('ab.status', 0);
//           });
//     $userRole = $request->user()->role_id;
//     if ($userRole == 16) {
//                 $List->where('et_customer_services.cre_id', $user_id);
//             }
//     // Filters
//     if ($search_fill != '') {
//       $List->where(function ($query) use ($search_fill) {
//         $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_product_category.product_category_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_product.duration_in', 'LIKE', "%{$search_fill}%");
//       });
//     }
 
//     $status_filter = $request->status_filter ?? '';
 
//   if (!empty($status_filter)) {
 
//       $List->whereExists(function ($q) use ($status_filter) {
 
//           $q->select(DB::raw(1))
//               ->from('et_milestone_history')
//               ->whereColumn(
//                   'et_milestone_history.milestone_id',
//                   'et_milestone_mapping.sno'
//               );
 
//           switch ($status_filter) {
 
//               case 'qc_verified':
 
//                   $q->where('et_milestone_history.status', 5);
 
//                   break;
 
//               case 'completed': // Ready for Delivery (CRE Verified)
 
//                   $q->where('et_milestone_history.status', 10)
//                     ->where('et_milestone_history.customer_ack_status', 0);
 
//                   break;
 
//               case 'accepted':
 
//                   $q->where('et_milestone_history.customer_ack_status', 1);
 
//                   break;
 
//               case 'concerns':
 
//                   $q->where('et_milestone_history.status', 7);
 
//                   break;
 
//               case 'correction':
 
//                   // CRE Rejected
//                   $q->where('et_milestone_history.status', 11);
 
//                   break;
 
//               case 'rework':
 
//                   // QC Rejected
//                   $q->where('et_milestone_history.status', 6);
 
//                   break;
 
//              case 'in_progress':
 
//                 $q->where(
//                     'et_milestone_history.status',
//                     5
//                 );
 
//                 break;
 
//               case 'waiting_cre_ack':
 
//                 $q->where('et_milestone_mapping.cre_acknowledged', 0)
//                 ->where('et_milestone_mapping.bh_acknowledged', 0)
 
//                 // At least one task must exist
//                 ->whereExists(function ($taskQuery) {
 
//                     $taskQuery->select(DB::raw(1))
//                         ->from('et_milestone_history as milestone_task')
//                         ->whereColumn(
//                             'milestone_task.milestone_id',
//                             'et_milestone_mapping.sno'
//                         );
 
//                 })
 
//                 // No incomplete task should exist
//                 ->whereNotExists(function ($taskQuery) {
 
//                     $taskQuery->select(DB::raw(1))
//                         ->from('et_milestone_history as pending_task')
//                         ->whereColumn(
//                             'pending_task.milestone_id',
//                             'et_milestone_mapping.sno'
//                         )
//                         ->where(function ($statusQuery) {
 
//                             $statusQuery
//                                 ->whereNull('pending_task.customer_ack_status')
//                                 ->orWhere(
//                                     'pending_task.customer_ack_status',
//                                     '!=',
//                                     1
//                                 );
 
//                         });
 
//                 });
 
//                 break;
 
//                 case 'waiting_bh_ack':
 
//                     $q->where('et_milestone_mapping.cre_acknowledged', 1)
//                     ->where('et_milestone_mapping.bh_acknowledged', 0);
 
//                     break;
 
//               case 'not_started':
//               default:
//                   // No additional filter
//                   break;
//           }
//       });
//   }
//   if ($status_filter === 'in_progress') {
 
//     $List->where(
//         'payment_status.payment_status',
//         0
//     );
// }
//     if ($cat_fill) $List->where('et_product_category.sno', $cat_fill);
//     if ($product_fill) $List->where('et_product.sno', $product_fill);
//     if ($status_fill || $status_fill === '0') {
//       $List->where('et_customer_services.status', $status_fill);
//     }
 
//     $List->groupBy(
//       'et_customer_services.sno',
//       'et_customer_services.customer_id',
//       'et_customer_services.cre_id',
//       'et_customer_services.pc_id',
//       'et_customer_services.product_id',
//       'et_customer_services.package_id',
//       'et_customer_services.product_package',
//       'et_customer_services.service_check',
//       'et_customer_services.production_staffs_id',
//       'et_customer_services.branch_id',
//       'et_customer_services.work_order_check',
//       'et_customer_services.created_at',
//       'et_customer_services.published_status',
//       'et_customer_services.status',
//       'et_customer_services.proposal_id',
//       'et_customer_services.variant_variable_ids',
 
//       'et_customer.cus_name',
//       'et_customer.cus_mobile',
//       'et_customer.cus_email_id',
//       'et_customer.country_code',
//       'et_customer.customer_id',
//       'et_customer.sno',
 
//       'et_product.duration',
//       'et_product.duration_in',
//       'et_product.product_name',
//       'et_proposal.biography_link_sent',
//     'et_proposal.biography_link_sent_at',
//     'et_proposal.biography_link_sent_by',
//     'biosent_staff.staff_name',
//     'biosent_staff.staff_image',
 
//       'et_package.actual_duration',
 
//       'et_work_order.deliverable_date',
//      'et_work_order.customer_end_date',
 
//       'et_customer_services.journal_check',
//       'cre.staff_name',
//       'cre.staff_image',
//       'pc.staff_name',
//       'pc.staff_image',
 
//       'et_product_category.product_category_name',
//       'et_product_category.sno',
//       'et_product_category.jouranal_check',
//       'et_proposal.journal_selection_completed',
//         'et_proposal.journal_selection_date',
//         // 'et_transaction.payment_status',
//          'et_proposal.noc_sent_through',
//         'et_proposal.noc_sent_at',
//         'et_proposal.noc_sent_by',
//         'et_proposal.noc_sent_status',
//         'noc_sent_staff.staff_name',
//     )
//       ->orderByRaw('et_work_order.deliverable_date IS NULL ASC')
//       ->orderBy('et_work_order.deliverable_date', 'ASC');
//     //   ->where('et_milestone_mapping.milestone_status', 1);
//       // ->where('et_milestone_mapping.delivery_status', 1);
 
 
//     // Clone query for service IDs
//     $serviceIds = (clone $List)->pluck('et_customer_services.sno')->toArray();
 
//     // If no services → show blank page
//     if (empty($serviceIds)) {
//       $emptyPaginator = new LengthAwarePaginator([], 0, $perpage, $page, [
//         'path' => $request->url(),
//         'query' => $request->query(),
//       ]);
//       return view('content.production_management.manage_deliverables.list', [
//         'ListTable' => $emptyPaginator,
//         'perpage' => $perpage,
//         'search_fill' => $search_fill,
//         'Product_cat_list' => $Product_cat_list,
//         'Product_ist' => $Product_list,
//         'DeliCheck_list' => $DeliCheck_list,
//         'staffs' => $staffs,
//         'Check_list' => $Check_list,
//         'cat_fill' => $cat_fill,
//         'product_fill' => $product_fill,
//         'status_fill' => $status_fill,
//         'dashboard'=>$dashboard
//       ]);
//     }
 
//     // Task count per service
//     $taskCounts = DB::table('et_milestone_mapping')
//       ->whereIn('service_id', $serviceIds)
//       ->where('status', '!=', 2)
//       ->select('service_id', 'task_ids')
//       ->get()
//       ->groupBy('service_id');
 
//     // Collect all task IDs
//     $allTaskIds = [];
//     foreach ($taskCounts as $serviceTasks) {
//       foreach ($serviceTasks as $m) {
//         $ids = json_decode($m->task_ids, true);
//         if (is_array($ids)) $allTaskIds = array_merge($allTaskIds, $ids);
//       }
//     }
//     $allTaskIds = array_unique($allTaskIds);
 
//     // Get task names
//     $taskNames = [];
//     if (!empty($allTaskIds)) {
//       $taskNames = DB::table('et_product_task')
//         ->whereIn('sno', $allTaskIds)
//         ->pluck('task_name', 'sno')
//         ->toArray();
//     }
 
//     // Milestone data
//     $milestoneData = DB::table('et_milestone_mapping')
//       ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//       ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
//       ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
//       ->select(
//         'et_milestone_mapping.service_id',
//         'et_milestone_mapping.sno',
//         'et_milestone_mapping.milestone_status',
//         'et_milestone_mapping.document_status',
//         'et_milestone_mapping.task_ids',
//         'et_payment_slot.payment_slot_name',
//         'et_proposal_pay_slot.payable_amount',
//         'et_proposal_pay_slot.paidAmount',
//         'et_transaction.payment_status',
       
//         'et_milestone_mapping.cre_acknowledged',
//         'et_milestone_mapping.cre_acknowledged_by',
//         'et_milestone_mapping.cre_acknowledged_date',
//         'et_milestone_mapping.cre_completion_notes',
 
//         'et_milestone_mapping.bh_acknowledged',
//         'et_milestone_mapping.bh_acknowledged_by',
//         'et_milestone_mapping.bh_acknowledged_date',
//         'et_milestone_mapping.bh_completion_notes',
//         'et_milestone_mapping.service_id',
//       )
//       ->whereIn('et_milestone_mapping.service_id', $serviceIds)
//       ->where('et_milestone_mapping.status', '!=', 2)
//     //   ->where('et_milestone_mapping.milestone_status', 1)
//       // ->where('et_milestone_mapping.services_status', '>', 0)
//       ->get()
//       ->groupBy('service_id');
   
 
// // ---------------------------------------------------
// // DELIVERABLE SERVICES
// // ---------------------------------------------------
// // A service becomes a Deliverable once at least one
// // task has been submitted into et_milestone_history.
// //
// // It must remain in Deliverables permanently,
// // regardless of task/milestone/NOC/customer status.
// // ---------------------------------------------------
 
// $List->whereExists(function ($q) {
 
//     $q->select(DB::raw(1))
//         ->from('et_milestone_mapping as deliverable_mm')
//         ->join(
//             'et_milestone_history as deliverable_mh',
//             'deliverable_mh.milestone_id',
//             '=',
//             'deliverable_mm.sno'
//         )
//         ->whereColumn(
//             'deliverable_mm.service_id',
//             'et_customer_services.sno'
//         );
 
// });
//     // APPLY PAGINATION
//     $ListTable = $List->paginate($perpage);
// //   $dashboard['total_services'] = count($ListTable);
 
//   // ---------------------------------------------------
// // CORRECTION COUNTS
// // ---------------------------------------------------
 
// $correctionCounts = DB::table('et_production_logs')
//     ->select(
//         'milestone_history_id',
//         DB::raw('COUNT(*) as correction_count')
//     )
//     ->where('action_type', 'customer_correction')
//     ->whereNotNull('milestone_history_id')
//     ->groupBy('milestone_history_id')
//     ->pluck('correction_count', 'milestone_history_id');  // ADD task & milestone data to each row
//     foreach ($ListTable as $list) {
 
//     $list->biography_exists = $list->biography_count > 0;
//     $list->deliverable_completed = false;
 
//         if (!empty($list->milestone_data)) {
 
//             $allTasks = collect($list->milestone_data)
//                 ->flatMap(function ($milestone) {
//                     return $milestone->task_names ?? [];
//                 });
 
//             if ($allTasks->isNotEmpty()) {
 
//                 $list->deliverable_completed =
//                     $allTasks->every(function ($task) {
 
//                         return (int) ($task->customer_ack_status ?? 0) === 1;
 
//                     });
 
//             }
//         }
//       // Total tasks
//       $serviceTaskIds = [];
//       if (isset($taskCounts[$list->sno])) {
//         foreach ($taskCounts[$list->sno] as $milestone) {
//           $ids = json_decode($milestone->task_ids, true);
//           if (is_array($ids)) $serviceTaskIds = array_merge($serviceTaskIds, $ids);
//         }
//       }
//       $list->total_task_count = count(array_unique($serviceTaskIds));
 
//       // Milestone details
//       $milestoneDataWithTasks = [];
//     //   dump([
//     //     'service_id' => $list->sno,
//     //     'milestone_exists' => isset($milestoneData[$list->sno]),
//     //     'milestone_count' => isset($milestoneData[$list->sno]) ? count($milestoneData[$list->sno]) : 0,
//     // ]);
 
//       if (isset($milestoneData[$list->sno])) {
 
//         foreach ($milestoneData[$list->sno] as $m) {
//           // 1️⃣ Get product-task IDs from milestone JSON
//           $productTaskIds = json_decode($m->task_ids, true) ?? [];
 
//           // 2️⃣ Get task names
 
//           // 3️⃣ Map to et_task IDs
//           $etTaskIds = DB::table('et_task')
//             ->where('service_id', $list->sno)
//             ->whereIn('task_name', $productTaskIds)
//             ->pluck('sno')
//             ->toArray();
 
//           // 4️⃣ Get daily tasks
//           $dailyTasks = DB::table('et_daily_tasks')
//             ->where('service_id', $list->sno)
//             ->whereIn('task_id', $etTaskIds)
//             ->get();
 
//           // ---------------------------------------------------
//           // 5️⃣ GET UNIQUE STAFF FOR THIS MILESTONE
//           // ---------------------------------------------------
//           $staffIdsRaw = DB::table('et_pro_milestone_staffs')
//             ->where('service_id', $list->sno)
//             ->where('milestone_id', $m->sno)
//             ->pluck('staff_ids')
//             ->toArray();
 
//           $staffIds = [];
 
//           foreach ($staffIdsRaw as $row) {
//             // Decode JSON array string like ["25","58"]
//             $decoded = json_decode($row, true);
 
//             if (is_array($decoded)) {
//               $staffIds = array_merge($staffIds, $decoded);
//             }
//           }
 
//           // Remove duplicates & reindex
//           $staffIds = array_unique($staffIds);
 
//           $staffDetails = [];
 
//           if (!empty($staffIds)) {
//             $staffDetails = DB::table('et_staff')
//               ->whereIn('sno', $staffIds)
//               ->where('status', 0)
//               ->select('sno', 'staff_name', 'staff_image')
//               ->get()
//               ->toArray();
//           }
 
//     $historyTasks = DB::table('et_milestone_history as mh')
//     ->leftJoin('et_product_task as pt', 'pt.sno', '=', 'mh.task_id')
//     ->leftJoin('et_staff as ds', 'ds.sno', '=', 'mh.document_staff_id')
//     ->leftJoin(
//     'et_staff as resolved_staff',
//     'resolved_staff.sno',
//     '=',
//     'mh.customer_issue_resolved_by'
//     )
//     ->leftJoin(
//         'et_staff as cre_complete_staff',
//         'cre_complete_staff.sno',
//         '=',
//         'mh.completed_by_cre_by'
//     )
//     ->where('mh.milestone_id', $m->sno)
//     ->select(
//         'mh.*',
//         'pt.task_name',
//         'ds.staff_name',
//         'ds.staff_image',
//         'resolved_staff.staff_name as resolved_staff_name',
//         'resolved_staff.staff_image as resolved_staff_image',
//         'cre_complete_staff.staff_name as completed_staff_name',
//         'cre_complete_staff.staff_image as completed_staff_image',
//     )
//     ->get();
 
//      $productTasks = [];
 
// foreach ($historyTasks as $task) {
 
//     $taskDocuments = DB::table('et_task_documents')
//     ->where('milestone_history_id', $task->sno)
//     ->orderByDesc('created_at')
//     ->get()
//     ->groupBy(function ($doc) {
//         return date('Y-m-d H:i', strtotime($doc->created_at));
//     });
//     $task->customer_documents = DB::table('et_task_customer_documents')
//       ->where('milestone_history_id', $task->sno)
//       ->get();
//     $task->customer_document_count = $task->customer_documents->count();
//     $correction_count = DB::table('et_production_logs')
//         ->where('milestone_history_id', $task->sno)
//         ->where('action_type', 'customer_correction')
//         ->count();
//     $productTasks[] = (object)[
//         'sno' => $task->sno,
//         'et_task_id' => $task->sno,
//         'milestone_id' => $task->milestone_id,
//         'task_name' => $task->task_name,
//         'percentage' => $task->percentage,
//         'status' => $task->status,
//         'reverted_remarks ' => $task->reverted_remarks ,
//         'cre_remark'=>$task->cre_remark,
//         'customer_ack_status' => $task->customer_ack_status ?? 0,
//         'customer_ack_date' => $task->customer_ack_date,
//          'customer_response' => $task->customer_response,
//         'customer_reject_remarks' => $task->customer_reject_remarks,
//         'resolved_staff_name' => $task->resolved_staff_name??'',
//         'resolved_staff_image' => $task->resolved_staff_image??'',
//         'document_staff' => (object)[
//             'sno' => $task->document_staff_id,
//             'staff_name' => $task->staff_name,
//             'staff_image' => $task->staff_image,
//         ],
//         'completion_type'=>$task->completion_type??0,
//         'documents' => $taskDocuments,
//         'document_count' => $taskDocuments->flatten()->count(),
//          'customer_documents' => $task->customer_documents,
//         'customer_document_count' => $task->customer_documents->count(),
//         'customer_ack_sent' => $task->customer_ack_sent,
//         'customer_ack_sent_by' => $task->customer_ack_sent_by,
//         'customer_ack_sent_date' => $task->customer_ack_sent_date,
//         'completed_by_cre' => $task->completed_by_cre,
 
//       'completed_by_cre_by' => $task->completed_by_cre_by,
 
//       'completed_by_cre_date' => $task->completed_by_cre_date,
 
//       'completed_by_cre_remarks' => $task->completed_by_cre_remarks,
 
//       'completed_cre_name' => $task->completed_staff_name,
//       'completed_cre_image' => $task->completed_staff_image,
//       'service_id'=> $list->sno,
//       'correction_count'=> (int) (
//     $correctionCounts[$task->sno] ?? 0
// ),
//     ];
 
   
// }
 
//       $totalTasks = count($productTasks);
 
//       $completedTasks = collect($productTasks)
//           ->where('customer_ack_status', 1) // QC Verified
//           ->count();
// $milestoneCorrectionCount = collect($productTasks)
//     ->sum(function ($task) {
//         return (int) ($task->correction_count ?? 0);
//     });
//       $percentage = $totalTasks > 0
//           ? round(($completedTasks / $totalTasks) * 100)
//           : 0;
//           // ---------------------------------------------------
//           // FINAL STRUCTURE
//           // ---------------------------------------------------
//           $milestoneDataWithTasks[] = (object)[
//             'mile_stone_name'        => $m->payment_slot_name,
//             'payable_amount'         => $m->payable_amount,
//             'paidAmount'             => $m->paidAmount,
//             'task_ids'               => $m->task_ids,
//             'mile_sno'               => $m->sno,
//             'status'                 => $m->milestone_status,
//             'document_status'        => $m->document_status,
//             'payment_status'        => $m->payment_status,
 
//             'cre_acknowledged'        => $m->cre_acknowledged,
//             'cre_acknowledged_by'        => $m->cre_acknowledged_by,
//             'cre_acknowledged_date'        => $m->cre_acknowledged_date,
//             'cre_acknowledged_notes'        => $m->cre_completion_notes,
 
//             'bh_acknowledged'        => $m->bh_acknowledged,
//             'bh_acknowledged_by'        => $m->bh_acknowledged_by,
//             'bh_acknowledged_date'        => $m->bh_acknowledged_date,
//             'bh_acknowledged_notes'        => $m->bh_completion_notes,
//             'service_id'=> $m->service_id,
           
//             // TASKS
//           'task_names' => $productTasks,
//             'task_count' => count($productTasks),
 
//             'total_daily_tasks' => $totalTasks,
//             'completed_daily_tasks' => $completedTasks,
//             'milestone_percentage' => $percentage,
//             // STAFF
//             'assigned_staff'         => $staffDetails,  // array of {sno, staff_name, staff_image}
//             'staff_count'            => count($staffDetails),
//             'correction_count' => $milestoneCorrectionCount,
//           ];
//         }
//       }
 
       
//       foreach ($milestoneDataWithTasks as $mile) {
 
//         $mile->total_tasks = DB::table('et_milestone_history')
//             ->where('milestone_id', $mile->mile_sno)
//             ->count();
 
//         $mile->accepted_tasks = DB::table('et_milestone_history')
//             ->where('milestone_id', $mile->mile_sno)
//             ->where('customer_ack_status', 1)
//             ->count();
 
//         $mile->ready_for_cre =
//             $mile->total_tasks > 0 &&
//             $mile->total_tasks == $mile->accepted_tasks;
//     }
//       $list->milestone_data = $milestoneDataWithTasks;
//       $list->correction_count = collect(
//               $milestoneDataWithTasks
//           )->sum(function ($milestone) {
 
//               return (int) (
//                   $milestone->correction_count ?? 0
//               );
 
//           });
//     }
 
 
//     // return $ListTable;
//     // Dropdown data
//     $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
//     $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
//     $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
//     $staffs = DB::table('et_staff')
//       ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.sno', '>', 1)
//       ->where('et_staff.branch_id', $branch_id)
//       ->select('et_staff.*', 'et_job_position.job_position_name')
//       ->get();
//       if($request->ajax==true){
//   return $ListTable;    
//       }
// // return $ListTable;
//     return view('content.production_management.manage_deliverables.list', [
//       'ListTable' => $ListTable,
//       'perpage' => $perpage,
//       'search_fill' => $search_fill,
//       'Product_cat_list' => $Product_cat_list,
//       'Product_ist' => $Product_list,
//       'staffs' => $staffs,
//       'Check_list' => $Check_list,
//       'DeliCheck_list' => $DeliCheck_list,
//       'cat_fill' => $cat_fill,
//       'product_fill' => $product_fill,
//       'status_fill' => $status_fill,
//       'filter_on' => $filter_on,
//       'dashboard' => $dashboard
//     ]);
//   }
  
     public function index(Request $request)
  {
    $entity_id = $request->user()->entity_id;
    $user_id = $request->user()->user_id;
    $userRole = $request->user()->role_id;
    $branch_id = $request->user()->branch_id;
 
    $search_fill = $request->search_fill ?? '';
    $cat_fill = $request->cat_fill ?? '';
    $product_fill = $request->product_fill ?? '';
    $status_fill = $request->status_fill ?? '';
    $filter_on = $request->filter_on ?? '';
 
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    // dd($perpage);
    $dashboard = [
        'total_services' => 0,
        'qc_verified' => 0,
        'payment_pending' => 0,
        'ready_customer' => 0,
        'customer_accepted' => 0,
        'customer_concerns' => 0,
        'correction_pending' => 0,
        'update_required' => 0,
         'waiting_cre_acknowledge' => 0,
        'waiting_bh_acknowledge' => 0,
    ];
      $paymentStatusQuery = DB::table('et_payment as ep')
    ->join(
        'et_transaction as et',
        'et.payment_id',
        '=',
        'ep.sno'
    )
    ->select(
        'ep.pay_slot_id',
        DB::raw('MAX(et.payment_status) as payment_status')
    )
    ->groupBy('ep.pay_slot_id');
 
    $dashboardQuery = DB::table('et_milestone_history as mh')
    ->join(
        'et_milestone_mapping as mm',
        'mm.sno',
        '=',
        'mh.milestone_id'
    )
    ->join(
        'et_customer_services as cs',
        'cs.sno',
        '=',
        'mm.service_id'
    )
     ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'mm.milestone_id')
      ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
      ->leftJoinSub(
            $paymentStatusQuery,
            'payment_status',
            function ($join) {
                $join->on(
                    'payment_status.pay_slot_id',
                    '=',
                    'et_proposal_pay_slot.sno'
                );
            }
        )
    ->where('cs.branch_id', $branch_id)
    ->where('cs.work_order_check', 3)
    ->where('mm.milestone_status', 1);
    if ($userRole == 16) {
 
        $dashboardQuery->where(
            'cs.cre_id',
            $user_id
        );
    }
    $dashboard['total_services'] = (clone $dashboardQuery)
    ->distinct('cs.sno')
    ->count('cs.sno');
 
    $dashboard['qc_verified'] = (clone $dashboardQuery)
        ->where('mh.status', 5)
        ->count();
 
    $dashboard['update_required'] = (clone $dashboardQuery)
        ->where('mh.status', 6)
        ->count();
 
    $dashboard['customer_concerns'] = (clone $dashboardQuery)
        ->where('mh.status', 7)
        ->count();
 
    $dashboard['correction_pending'] = (clone $dashboardQuery)
        ->where('mh.status', 11)
        ->count();
 
    $dashboard['ready_customer'] = (clone $dashboardQuery)
        ->where('mh.status', 10)
        ->where('mh.customer_ack_status', 0)
        ->count();
 
    $dashboard['customer_accepted'] = (clone $dashboardQuery)
        ->where('mh.status', 10)
        ->where('mh.customer_ack_status', 1)
        ->count();
 
    $dashboard['payment_pending'] = (clone $dashboardQuery)
        ->where('mh.status', 5)
        ->where('payment_status.payment_status', 0)
        ->count();
 
// ---------------------------------------------------
// WAITING FOR CRE ACKNOWLEDGEMENT
// ---------------------------------------------------
 
$dashboard['waiting_cre_acknowledge'] = DB::table('et_milestone_mapping as mm')
    ->join(
        'et_customer_services as cs',
        'cs.sno',
        '=',
        'mm.service_id'
    )
    ->where('cs.branch_id', $branch_id)
    ->where('cs.work_order_check', 3)
    ->where('mm.milestone_status', 1)
 
    // CRE has not acknowledged
    ->where('mm.cre_acknowledged', 0)
 
    // BH also not acknowledged
    ->where('mm.bh_acknowledged', 0)
 
    // Must have at least one task
    ->whereExists(function ($q) {
 
        $q->select(DB::raw(1))
            ->from('et_milestone_history as mh')
            ->whereColumn(
                'mh.milestone_id',
                'mm.sno'
            );
 
    })
 
    // There must NOT be any incomplete/unacknowledged task
    ->whereNotExists(function ($q) {
 
        $q->select(DB::raw(1))
            ->from('et_milestone_history as mh2')
            ->whereColumn(
                'mh2.milestone_id',
                'mm.sno'
            )
            ->where(function ($status) {
 
                $status
                    ->whereNull('mh2.customer_ack_status')
                    ->orWhere(
                        'mh2.customer_ack_status',
                        '!=',
                        1
                    );
 
            });
 
    });
 
if ($userRole == 16) {
 
    $dashboard['waiting_cre_acknowledge'] = DB::table('et_milestone_mapping as mm')
        ->join(
            'et_customer_services as cs',
            'cs.sno',
            '=',
            'mm.service_id'
        )
        ->where('cs.branch_id', $branch_id)
        ->where('cs.work_order_check', 3)
        ->where('mm.milestone_status', 1)
        ->where('cs.cre_id', $user_id)
        ->where('mm.cre_acknowledged', 0)
        ->where('mm.bh_acknowledged', 0)
 
        ->whereExists(function ($q) {
 
            $q->select(DB::raw(1))
                ->from('et_milestone_history as mh')
                ->whereColumn(
                    'mh.milestone_id',
                    'mm.sno'
                );
 
        })
 
        ->whereNotExists(function ($q) {
 
            $q->select(DB::raw(1))
                ->from('et_milestone_history as mh2')
                ->whereColumn(
                    'mh2.milestone_id',
                    'mm.sno'
                )
                ->where(function ($status) {
 
                    $status
                        ->whereNull('mh2.customer_ack_status')
                        ->orWhere(
                            'mh2.customer_ack_status',
                            '!=',
                            1
                        );
 
                });
 
        })
        ->distinct()
        ->count('mm.sno');
}
 
 
$dashboard['waiting_bh_ack'] = (clone $dashboardQuery)
    ->where('mm.cre_acknowledged', 1)
    ->where('mm.bh_acknowledged', 0)
    ->distinct()
    ->count('mm.sno');
    // return $ListTable;
    // Dropdown data
    $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
    $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
    $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
    $DeliCheck_list = DB::table('et_delivery_attachment_checklist')->where('status', 0)->orderBy('delivery_attachment_checklist')->get();
    $staffs = DB::table('et_staff')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
      ->where('et_staff.status', 0)
      ->where('et_staff.sno', '>', 1)
      ->where('et_staff.branch_id', $branch_id)
      ->select('et_staff.*', 'et_job_position.job_position_name')
      ->get();
 
   
    // MAIN QUERY
    $List = DB::table('et_milestone_mapping')
      ->select(
        'et_customer_services.sno',
        'et_customer_services.customer_id',
        'et_customer_services.service_check',
        'et_customer_services.cre_id',
        'et_customer_services.pc_id',
        'et_customer_services.product_id',
        'et_customer_services.package_id',
        'et_customer_services.product_package',
        'et_customer_services.production_staffs_id',
        'et_customer_services.branch_id',
        'et_customer_services.work_order_check',
        'et_customer_services.created_at',
        'et_customer_services.published_status',
        'et_customer_services.status',
        'et_customer_services.proposal_id',
        'et_customer_services.variant_variable_ids',
        'et_product.product_name',
       
        'et_customer.sno as customer_sno',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        'et_customer.customer_id AS cus_id',
 
        'et_product.duration',
        'et_product.duration_in',
 
        'et_customer_services.journal_check',
        'et_package.actual_duration',
 
        'cre.staff_name as cre_name',
        'cre.staff_image as cre_image',
 
        'pc.staff_name as pc_name',
        'pc.staff_image as pc_image',
       
        'et_proposal.journal_selection_completed',
        'et_proposal.journal_selection_date',
 
        'et_work_order.deliverable_date',
        'et_work_order.customer_end_date',
 
        'et_proposal.biography_link_sent',
        'et_proposal.biography_link_sent_at',
        'et_proposal.biography_link_sent_by',
        'biosent_staff.staff_name as biography_link_sent_staff_name',
        'biosent_staff.staff_image as biography_link_sent_staff_image',
        'et_proposal.noc_sent_through',
        'et_proposal.noc_sent_at',
        'et_proposal.noc_sent_by',
        'et_proposal.noc_sent_status',
        'noc_sent_staff.staff_name as noc_sent_staff_name',
 
        DB::raw("GROUP_CONCAT(DISTINCT pro_staff.staff_name SEPARATOR ', ') as pro_staff_names"),
        DB::raw("GROUP_CONCAT(DISTINCT pro_staff.staff_image SEPARATOR ', ') as pro_staff_images"),
        DB::raw('COUNT(ab.sno) as biography_count'),
        DB::raw("
          EXISTS(
              SELECT 1
              FROM et_customer_services cs
              INNER JOIN et_product p
                  ON p.sno = cs.product_id
              WHERE cs.proposal_id = et_customer_services.proposal_id
                AND p.journal_product = 1
          ) as has_journal_product
          "),
        DB::raw('MAX(payment_status.payment_status) as payment_status'),
        'et_product_category.product_category_name',
        'et_product_category.sno as prd_cat_id',
        'et_product_category.jouranal_check',
        // 'et_transaction.payment_status'
      )
      ->where('et_customer_services.branch_id', $branch_id)
      ->where('et_customer_services.work_order_check', 3)
      ->join('et_customer_services', 'et_milestone_mapping.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
      ->leftJoin('et_staff as noc_sent_staff','noc_sent_staff.sno','=','et_proposal.noc_sent_by')
      ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
      ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
      ->leftJoin('et_staff as biosent_staff', 'biosent_staff.sno', '=', 'et_proposal.biography_link_sent_by')
      ->leftJoin('et_staff as pro_staff', function ($join) {
        $join->whereRaw("JSON_SEARCH(et_customer_services.production_staffs_id, 'one', CAST(pro_staff.sno AS CHAR)) IS NOT NULL");
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
      ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
    //   ->leftJoin('et_payment','et_payment.pay_slot_id','=','et_proposal_pay_slot.sno')
    //   ->leftJoin('et_transaction','et_transaction.payment_id','=','et_payment.sno')
    ->leftJoinSub(
            $paymentStatusQuery,
            'payment_status',
            function ($join) {
                $join->on(
                    'payment_status.pay_slot_id',
                    '=',
                    'et_proposal_pay_slot.sno'
                );
            }
        )
      ->leftJoin(
            'et_work_order',
            'et_work_order.service_id',
            '=',
            'et_customer_services.sno'
        )
      ->leftJoin('et_author_biography as ab', function ($join) {
              $join->on('ab.service_id', '=', 'et_customer_services.sno')
                  ->where('ab.status', 0);
          });
    $userRole = $request->user()->role_id;
    if ($userRole == 16) {
                $List->where('et_customer_services.cre_id', $user_id);
            }
    // Filters
    if ($search_fill != '') {
      $List->where(function ($query) use ($search_fill) {
        $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_product_category.product_category_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_product.duration_in', 'LIKE', "%{$search_fill}%");
      });
    }
 
    $status_filter = $request->status_filter ?? '';
 
  if (!empty($status_filter)) {
 
      $List->whereExists(function ($q) use ($status_filter) {
 
          $q->select(DB::raw(1))
              ->from('et_milestone_history')
              ->whereColumn(
                  'et_milestone_history.milestone_id',
                  'et_milestone_mapping.sno'
              );
 
          switch ($status_filter) {
 
              case 'qc_verified':
 
                  $q->where('et_milestone_history.status', 5);
 
                  break;
 
              case 'completed': // Ready for Delivery (CRE Verified)
 
                  $q->where('et_milestone_history.status', 10)
                    ->where('et_milestone_history.customer_ack_status', 0);
 
                  break;
 
              case 'accepted':
 
                  $q->where('et_milestone_history.customer_ack_status', 1);
 
                  break;
 
              case 'concerns':
 
                  $q->where('et_milestone_history.status', 7);
 
                  break;
 
              case 'correction':
 
                  // CRE Rejected
                  $q->where('et_milestone_history.status', 11);
 
                  break;
 
              case 'rework':
 
                  // QC Rejected
                  $q->where('et_milestone_history.status', 6);
 
                  break;
 
             case 'in_progress':
 
                $q->where(
                    'et_milestone_history.status',
                    5
                );
 
                break;
 
               case 'waiting_cre_ack':
 
                $q->where('et_milestone_mapping.cre_acknowledged', 0)
                ->where('et_milestone_mapping.bh_acknowledged', 0)
 
                // At least one task must exist
                ->whereExists(function ($taskQuery) {
 
                    $taskQuery->select(DB::raw(1))
                        ->from('et_milestone_history as milestone_task')
                        ->whereColumn(
                            'milestone_task.milestone_id',
                            'et_milestone_mapping.sno'
                        );
 
                })
 
                // No incomplete task should exist
                ->whereNotExists(function ($taskQuery) {
 
                    $taskQuery->select(DB::raw(1))
                        ->from('et_milestone_history as pending_task')
                        ->whereColumn(
                            'pending_task.milestone_id',
                            'et_milestone_mapping.sno'
                        )
                        ->where(function ($statusQuery) {
 
                            $statusQuery
                                ->whereNull('pending_task.customer_ack_status')
                                ->orWhere(
                                    'pending_task.customer_ack_status',
                                    '!=',
                                    1
                                );
 
                        });
 
                });
 
                break;
 
                case 'waiting_bh_ack':
 
                    $q->where('et_milestone_mapping.cre_acknowledged', 1)
                    ->where('et_milestone_mapping.bh_acknowledged', 0);
 
                    break;
 
              case 'not_started':
              default:
                  // No additional filter
                  break;
          }
      });
  }
  if ($status_filter === 'in_progress') {
 
    $List->where(
        'payment_status.payment_status',
        0
    );
}
    if ($cat_fill) $List->where('et_product_category.sno', $cat_fill);
    if ($product_fill) $List->where('et_product.sno', $product_fill);
    if ($status_fill || $status_fill === '0') {
      $List->where('et_customer_services.status', $status_fill);
    }
 
    $List->groupBy(
      'et_customer_services.sno',
      'et_customer_services.customer_id',
      'et_customer_services.cre_id',
      'et_customer_services.pc_id',
      'et_customer_services.product_id',
      'et_customer_services.package_id',
      'et_customer_services.product_package',
      'et_customer_services.service_check',
      'et_customer_services.production_staffs_id',
      'et_customer_services.branch_id',
      'et_customer_services.work_order_check',
      'et_customer_services.created_at',
      'et_customer_services.published_status',
      'et_customer_services.status',
      'et_customer_services.proposal_id',
      'et_customer_services.variant_variable_ids',
 
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      'et_customer.customer_id',
      'et_customer.sno',
 
      'et_product.duration',
      'et_product.duration_in',
      'et_product.product_name',
      'et_proposal.biography_link_sent',
    'et_proposal.biography_link_sent_at',
    'et_proposal.biography_link_sent_by',
    'biosent_staff.staff_name',
    'biosent_staff.staff_image',
 
      'et_package.actual_duration',
 
      'et_work_order.deliverable_date',
     'et_work_order.customer_end_date',
 
      'et_customer_services.journal_check',
      'cre.staff_name',
      'cre.staff_image',
      'pc.staff_name',
      'pc.staff_image',
 
      'et_product_category.product_category_name',
      'et_product_category.sno',
      'et_product_category.jouranal_check',
      'et_proposal.journal_selection_completed',
        'et_proposal.journal_selection_date',
        // 'et_transaction.payment_status',
         'et_proposal.noc_sent_through',
        'et_proposal.noc_sent_at',
        'et_proposal.noc_sent_by',
        'et_proposal.noc_sent_status',
        'noc_sent_staff.staff_name',
    )
      ->orderByRaw('et_work_order.deliverable_date IS NULL ASC')
      ->orderBy('et_work_order.deliverable_date', 'ASC');
    //   ->where('et_milestone_mapping.milestone_status', 1);
      // ->where('et_milestone_mapping.delivery_status', 1);
 
 
    // Clone query for service IDs
    $serviceIds = (clone $List)->pluck('et_customer_services.sno')->toArray();
 
    // If no services → show blank page
    if (empty($serviceIds)) {
      $emptyPaginator = new LengthAwarePaginator([], 0, $perpage, $page, [
        'path' => $request->url(),
        'query' => $request->query(),
      ]);
      return view('content.production_management.manage_deliverables.list', [
        'ListTable' => $emptyPaginator,
        'perpage' => $perpage,
        'search_fill' => $search_fill,
        'Product_cat_list' => $Product_cat_list,
        'Product_ist' => $Product_list,
        'DeliCheck_list' => $DeliCheck_list,
        'staffs' => $staffs,
        'Check_list' => $Check_list,
        'cat_fill' => $cat_fill,
        'product_fill' => $product_fill,
        'status_fill' => $status_fill,
        'dashboard'=>$dashboard
      ]);
    }
 
    // Task count per service
    $taskCounts = DB::table('et_milestone_mapping')
      ->whereIn('service_id', $serviceIds)
      ->where('status', '!=', 2)
      ->select('service_id', 'task_ids')
      ->get()
      ->groupBy('service_id');
 
    // Collect all task IDs
    $allTaskIds = [];
    foreach ($taskCounts as $serviceTasks) {
      foreach ($serviceTasks as $m) {
        $ids = json_decode($m->task_ids, true);
        if (is_array($ids)) $allTaskIds = array_merge($allTaskIds, $ids);
      }
    }
    $allTaskIds = array_unique($allTaskIds);
 
    // Get task names
    $taskNames = [];
    if (!empty($allTaskIds)) {
      $taskNames = DB::table('et_product_task')
        ->whereIn('sno', $allTaskIds)
        ->pluck('task_name', 'sno')
        ->toArray();
    }
 
    // Milestone data
    $milestoneData = DB::table('et_milestone_mapping')
      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
      ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
      ->leftJoinSub(
        $paymentStatusQuery,
        'payment_status',
        function ($join) {
          $join->on('payment_status.pay_slot_id', '=', 'et_proposal_pay_slot.sno');
        }
      )
      ->select(
        'et_milestone_mapping.service_id',
        'et_milestone_mapping.sno',
        'et_milestone_mapping.milestone_status',
        'et_milestone_mapping.document_status',
        'et_milestone_mapping.task_ids',
        'et_payment_slot.payment_slot_name',
        'et_proposal_pay_slot.payable_amount',
        'et_proposal_pay_slot.paidAmount',
        'payment_status.payment_status',
 
        'et_milestone_mapping.cre_acknowledged',
        'et_milestone_mapping.cre_acknowledged_by',
        'et_milestone_mapping.cre_acknowledged_date',
        'et_milestone_mapping.cre_completion_notes',
 
        'et_milestone_mapping.bh_acknowledged',
        'et_milestone_mapping.bh_acknowledged_by',
        'et_milestone_mapping.bh_acknowledged_date',
        'et_milestone_mapping.bh_completion_notes',
      )
      ->whereIn('et_milestone_mapping.service_id', $serviceIds)
      ->where('et_milestone_mapping.status', '!=', 2)
    //   ->where('et_milestone_mapping.milestone_status', 1)
      // ->where('et_milestone_mapping.services_status', '>', 0)
      ->get()
      ->groupBy('service_id');
   
 
// ---------------------------------------------------
// DELIVERABLE SERVICES
// ---------------------------------------------------
// A service becomes a Deliverable once at least one
// task has been submitted into et_milestone_history.
//
// It must remain in Deliverables permanently,
// regardless of task/milestone/NOC/customer status.
// ---------------------------------------------------
 
$List->whereExists(function ($q) {
 
    $q->select(DB::raw(1))
        ->from('et_milestone_mapping as deliverable_mm')
        ->join(
            'et_milestone_history as deliverable_mh',
            'deliverable_mh.milestone_id',
            '=',
            'deliverable_mm.sno'
        )
        ->whereColumn(
            'deliverable_mm.service_id',
            'et_customer_services.sno'
        );
 
});
    // APPLY PAGINATION
    $ListTable = $List->paginate($perpage);
//   $dashboard['total_services'] = count($ListTable);
 
  // ---------------------------------------------------
// CORRECTION COUNTS
// ---------------------------------------------------
 
$correctionCounts = DB::table('et_production_logs')
    ->select(
        'milestone_history_id',
        DB::raw('COUNT(*) as correction_count')
    )
    ->where('action_type', 'customer_correction')
    ->whereNotNull('milestone_history_id')
    ->groupBy('milestone_history_id')
    ->pluck('correction_count', 'milestone_history_id');  // ADD task & milestone data to each row
    foreach ($ListTable as $list) {
 
    $list->biography_exists = $list->biography_count > 0;
    $list->deliverable_completed = false;
 
        if (!empty($list->milestone_data)) {
 
            $allTasks = collect($list->milestone_data)
                ->flatMap(function ($milestone) {
                    return $milestone->task_names ?? [];
                });
 
            if ($allTasks->isNotEmpty()) {
 
                $list->deliverable_completed =
                    $allTasks->every(function ($task) {
 
                        return (int) ($task->customer_ack_status ?? 0) === 1;
 
                    });
 
            }
        }
      // Total tasks
      $serviceTaskIds = [];
      if (isset($taskCounts[$list->sno])) {
        foreach ($taskCounts[$list->sno] as $milestone) {
          $ids = json_decode($milestone->task_ids, true);
          if (is_array($ids)) $serviceTaskIds = array_merge($serviceTaskIds, $ids);
        }
      }
      $list->total_task_count = count(array_unique($serviceTaskIds));
 
      // Milestone details
      $milestoneDataWithTasks = [];
    //   dump([
    //     'service_id' => $list->sno,
    //     'milestone_exists' => isset($milestoneData[$list->sno]),
    //     'milestone_count' => isset($milestoneData[$list->sno]) ? count($milestoneData[$list->sno]) : 0,
    // ]);
 
      if (isset($milestoneData[$list->sno])) {
 
        foreach ($milestoneData[$list->sno] as $m) {
          // 1️⃣ Get product-task IDs from milestone JSON
          $productTaskIds = json_decode($m->task_ids, true) ?? [];
 
          // 2️⃣ Get task names
 
          // 3️⃣ Map to et_task IDs
          $etTaskIds = DB::table('et_task')
            ->where('service_id', $list->sno)
            ->whereIn('task_name', $productTaskIds)
            ->pluck('sno')
            ->toArray();
 
          // 4️⃣ Get daily tasks
          $dailyTasks = DB::table('et_daily_tasks')
            ->where('service_id', $list->sno)
            ->whereIn('task_id', $etTaskIds)
            ->get();
 
          // ---------------------------------------------------
          // 5️⃣ GET UNIQUE STAFF FOR THIS MILESTONE
          // ---------------------------------------------------
          $staffIdsRaw = DB::table('et_pro_milestone_staffs')
            ->where('service_id', $list->sno)
            ->where('milestone_id', $m->sno)
            ->pluck('staff_ids')
            ->toArray();
 
          $staffIds = [];
 
          foreach ($staffIdsRaw as $row) {
            // Decode JSON array string like ["25","58"]
            $decoded = json_decode($row, true);
 
            if (is_array($decoded)) {
              $staffIds = array_merge($staffIds, $decoded);
            }
          }
 
          // Remove duplicates & reindex
          $staffIds = array_unique($staffIds);
 
          $staffDetails = [];
 
          if (!empty($staffIds)) {
            $staffDetails = DB::table('et_staff')
              ->whereIn('sno', $staffIds)
              ->where('status', 0)
              ->select('sno', 'staff_name', 'staff_image')
              ->get()
              ->toArray();
          }
 
    $historyTasks = DB::table('et_milestone_history as mh')
    ->leftJoin('et_product_task as pt', 'pt.sno', '=', 'mh.task_id')
    ->leftJoin('et_staff as ds', 'ds.sno', '=', 'mh.document_staff_id')
    ->leftJoin(
    'et_staff as resolved_staff',
    'resolved_staff.sno',
    '=',
    'mh.customer_issue_resolved_by'
    )
    ->leftJoin(
        'et_staff as cre_complete_staff',
        'cre_complete_staff.sno',
        '=',
        'mh.completed_by_cre_by'
    )
    ->where('mh.milestone_id', $m->sno)
    ->select(
        'mh.*',
        'pt.task_name',
        'ds.staff_name',
        'ds.staff_image',
        'resolved_staff.staff_name as resolved_staff_name',
        'resolved_staff.staff_image as resolved_staff_image',
        'cre_complete_staff.staff_name as completed_staff_name',
        'cre_complete_staff.staff_image as completed_staff_image',
    )
    ->get();
 
     $productTasks = [];
 
foreach ($historyTasks as $task) {
 
    $taskDocuments = DB::table('et_task_documents')
    ->where('milestone_history_id', $task->sno)
    ->orderByDesc('created_at')
    ->get()
    ->groupBy(function ($doc) {
        return date('Y-m-d H:i', strtotime($doc->created_at));
    });
    $task->customer_documents = DB::table('et_task_customer_documents')
      ->where('milestone_history_id', $task->sno)
      ->get();
    $task->customer_document_count = $task->customer_documents->count();
    $correction_count = DB::table('et_production_logs')
        ->where('milestone_history_id', $task->sno)
        ->where('action_type', 'customer_correction')
        ->count();
    $productTasks[] = (object)[
        'sno' => $task->sno,
        'et_task_id' => $task->sno,
        'milestone_id' => $task->milestone_id,
        'task_name' => $task->task_name,
        'percentage' => $task->percentage,
        'status' => $task->status,
        'reverted_remarks ' => $task->reverted_remarks ,
        'cre_remark'=>$task->cre_remark,
        'customer_ack_status' => $task->customer_ack_status ?? 0,
        'customer_ack_date' => $task->customer_ack_date,
         'customer_response' => $task->customer_response,
        'customer_reject_remarks' => $task->customer_reject_remarks,
        'resolved_staff_name' => $task->resolved_staff_name??'',
        'resolved_staff_image' => $task->resolved_staff_image??'',
        'document_staff' => (object)[
            'sno' => $task->document_staff_id,
            'staff_name' => $task->staff_name,
            'staff_image' => $task->staff_image,
        ],
        'completion_type'=>$task->completion_type??0,
        'documents' => $taskDocuments,
        'document_count' => $taskDocuments->flatten()->count(),
         'customer_documents' => $task->customer_documents,
        'customer_document_count' => $task->customer_documents->count(),
        'customer_ack_sent' => $task->customer_ack_sent,
        'customer_ack_sent_by' => $task->customer_ack_sent_by,
        'customer_ack_sent_date' => $task->customer_ack_sent_date,
        'completed_by_cre' => $task->completed_by_cre,
 
      'completed_by_cre_by' => $task->completed_by_cre_by,
 
      'completed_by_cre_date' => $task->completed_by_cre_date,
 
      'completed_by_cre_remarks' => $task->completed_by_cre_remarks,
 
      'completed_cre_name' => $task->completed_staff_name,
      'completed_cre_image' => $task->completed_staff_image,
      'service_id'=> $list->sno,
      'correction_count'=> (int) (
    $correctionCounts[$task->sno] ?? 0
),
    ];
 
   
}
 
      $totalTasks = count($productTasks);
 
      $completedTasks = collect($productTasks)
          ->where('customer_ack_status', 1) // QC Verified
          ->count();
$milestoneCorrectionCount = collect($productTasks)
    ->sum(function ($task) {
        return (int) ($task->correction_count ?? 0);
    });
      $percentage = $totalTasks > 0
          ? round(($completedTasks / $totalTasks) * 100)
          : 0;
          // ---------------------------------------------------
          // FINAL STRUCTURE
          // ---------------------------------------------------
          $milestoneDataWithTasks[] = (object)[
            'mile_stone_name'        => $m->payment_slot_name,
            'payable_amount'         => $m->payable_amount,
            'paidAmount'             => $m->paidAmount,
            'task_ids'               => $m->task_ids,
            'mile_sno'               => $m->sno,
            'status'                 => $m->milestone_status,
            'document_status'        => $m->document_status,
            'payment_status'        => $m->payment_status,
 
            'cre_acknowledged'        => $m->cre_acknowledged,
            'cre_acknowledged_by'        => $m->cre_acknowledged_by,
            'cre_acknowledged_date'        => $m->cre_acknowledged_date,
            'cre_acknowledged_notes'        => $m->cre_completion_notes,
 
            'bh_acknowledged'        => $m->bh_acknowledged,
            'bh_acknowledged_by'        => $m->bh_acknowledged_by,
            'bh_acknowledged_date'        => $m->bh_acknowledged_date,
            'bh_acknowledged_notes'        => $m->bh_completion_notes,
            'service_id'=> $m->service_id,
           
            // TASKS
           'task_names' => $productTasks,
            'task_count' => count($productTasks),
 
            'total_daily_tasks' => $totalTasks,
            'completed_daily_tasks' => $completedTasks,
            'milestone_percentage' => $percentage,
            // STAFF
            'assigned_staff'         => $staffDetails,  // array of {sno, staff_name, staff_image}
            'staff_count'            => count($staffDetails),
            'correction_count' => $milestoneCorrectionCount,
          ];
        }
      }
 
       
      foreach ($milestoneDataWithTasks as $mile) {
 
        $mile->total_tasks = DB::table('et_milestone_history')
            ->where('milestone_id', $mile->mile_sno)
            ->count();
 
        $mile->accepted_tasks = DB::table('et_milestone_history')
            ->where('milestone_id', $mile->mile_sno)
            ->where('customer_ack_status', 1)
            ->count();
 
        $mile->ready_for_cre =
            $mile->total_tasks > 0 &&
            $mile->total_tasks == $mile->accepted_tasks;
    }
      $list->milestone_data = $milestoneDataWithTasks;
      $list->correction_count = collect(
              $milestoneDataWithTasks
          )->sum(function ($milestone) {
 
              return (int) (
                  $milestone->correction_count ?? 0
              );
 
          });
    }
 
 
    // return $ListTable;
    // Dropdown data
    $Product_cat_list = DB::table('et_product_category')->where('status', 0)->orderBy('product_category_name')->get();
    $Product_list = DB::table('et_product')->where('status', 0)->where('branch_id', $branch_id)->orderBy('product_name')->get();
    $Check_list = DB::table('et_task_checklist')->where('status', 0)->orderBy('task_checklist')->get();
    $staffs = DB::table('et_staff')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
      ->where('et_staff.status', 0)
      ->where('et_staff.sno', '>', 1)
      ->where('et_staff.branch_id', $branch_id)
      ->select('et_staff.*', 'et_job_position.job_position_name')
      ->get();
      if($request->ajax==true){
   return $ListTable;    
      }
// return $ListTable;
    return view('content.production_management.manage_deliverables.list', [
      'ListTable' => $ListTable,
      'perpage' => $perpage,
      'search_fill' => $search_fill,
      'Product_cat_list' => $Product_cat_list,
      'Product_ist' => $Product_list,
      'staffs' => $staffs,
      'Check_list' => $Check_list,
      'DeliCheck_list' => $DeliCheck_list,
      'cat_fill' => $cat_fill,
      'product_fill' => $product_fill,
      'status_fill' => $status_fill,
      'filter_on' => $filter_on,
      'dashboard' => $dashboard
    ]);
  }
  
//   public function delivery_documentation_data_fetch($id, $mileId)
//   {


//     $data = DB::table('et_customer_services')
//       ->where('et_customer_services.sno', $id)
//       ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
//       ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
//       ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
//       ->select(
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.customer_id',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_product.product_name',
//         'et_product_category.product_category_name',
//         'et_customer_services.sno',
//         'et_customer_services.variant_variable_ids',
//         'cre.staff_name as cre_name',
//         'pc.staff_name as pc_name',
//         'cre.staff_image as cre_image',
//         'pc.staff_image as pc_image',
//         'et_customer_services.created_at'
//       )
//       ->first();

//     $variantVariableIds = json_decode($data->variant_variable_ids, true);

//     $variantName = '';
//     $variableName = '';

//     if (is_array($variantVariableIds)) {
//       foreach ($variantVariableIds as $v) {
//         $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
//         $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

//         if ($variant) {
//           $variantName = $variant->product_variant_name ?? '';
//         }

//         if ($variable) {
//           $variableName = $variable->variable_name ?? '';
//         }
//       }
//     }

//     $year = date('Y', strtotime($data->created_at));
//     $formattedId = str_pad($data->sno, 5, '0', STR_PAD_LEFT);
//     $data->formatted_service_id = "SR-{$formattedId}/{$year}";

//     $data->variant_name = $variantName;
//     $data->variable_name = $variableName;

//     $milestoneData = DB::table('et_milestone_mapping')
//       ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//       ->select(
//         'et_milestone_mapping.service_id',
//         'et_milestone_mapping.sno',
//         'et_milestone_mapping.milestone_status',
//         'et_milestone_mapping.task_ids',
//         'et_payment_slot.payment_slot_name',
//         'et_proposal_pay_slot.payable_amount',
//         'et_proposal_pay_slot.paidAmount'
//       )
//       ->where('et_milestone_mapping.sno', $mileId)
//       ->where('et_milestone_mapping.status', '!=', 2)
//       ->where('et_milestone_mapping.milestone_status', 1)
//       ->first();



//     return response([
//       'status' => 200,
//       'message' => 'Data fetched successfully!',
//       'error_msg' => null,
//       'data' => $data,
//       'milestone_data' => $milestoneData
//     ], 200);
//   }
  
//   public function delivery_documentation_data_fetch($id, $mileId)
//   {
 
 
//     $data = DB::table('et_customer_services')
//       ->where('et_customer_services.sno', $id)
//       ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
//       ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
//       ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
//       ->select(
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.customer_id',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_product.product_name',
//         'et_product_category.product_category_name',
//         'et_customer_services.sno',
//         'et_customer_services.variant_variable_ids',
//         'cre.staff_name as cre_name',
//         'pc.staff_name as pc_name',
//         'cre.staff_image as cre_image',
//         'pc.staff_image as pc_image',
//         'et_customer_services.created_at'
//       )
//       ->first();
 
//     $variantVariableIds = json_decode($data->variant_variable_ids, true);
 
//     $variantName = '';
//     $variableName = '';
 
//     if (is_array($variantVariableIds)) {
//       foreach ($variantVariableIds as $v) {
//         $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
//         $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();
 
//         if ($variant) {
//           $variantName = $variant->product_variant_name ?? '';
//         }
 
//         if ($variable) {
//           $variableName = $variable->variable_name ?? '';
//         }
//       }
//     }
 
//     $year = date('Y', strtotime($data->created_at));
//     $formattedId = str_pad($data->sno, 5, '0', STR_PAD_LEFT);
//     $data->formatted_service_id = "SR-{$formattedId}/{$year}";
 
//     $data->variant_name = $variantName;
//     $data->variable_name = $variableName;
 
//     $milestoneData = DB::table('et_milestone_mapping')
//       ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
//       ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
//       ->select(
//         'et_milestone_mapping.service_id',
//         'et_milestone_mapping.sno',
//         'et_milestone_mapping.milestone_status',
//         'et_milestone_mapping.task_ids',
//         'et_payment_slot.payment_slot_name',
//         'et_proposal_pay_slot.payable_amount',
//         'et_proposal_pay_slot.paidAmount',
         
//         'et_milestone_mapping.cre_acknowledged',
//         'et_milestone_mapping.cre_acknowledged_by',
//         'et_milestone_mapping.cre_acknowledged_date',
//         'et_milestone_mapping.cre_completion_notes',
 
//         'et_milestone_mapping.bh_acknowledged',
//         'et_milestone_mapping.bh_acknowledged_by',
//         'et_milestone_mapping.bh_acknowledged_date',
//         'et_milestone_mapping.bh_completion_notes',
//       )
//       ->where('et_milestone_mapping.sno', $mileId)
//       ->where('et_milestone_mapping.status', '!=', 2)
//       ->where('et_milestone_mapping.milestone_status', 1)
//       ->first();
 
//     $totalTasks = DB::table('et_milestone_history')
//         ->where('milestone_id', $milestoneData->sno)
//         ->count();
 
//     $acceptedTasks = DB::table('et_milestone_history')
//         ->where('milestone_id', $milestoneData->sno)
//         ->where('customer_ack_status', 1)
//         ->count();
 
//     $milestoneData->total_tasks = $totalTasks;
//     $milestoneData->accepted_tasks = $acceptedTasks;
//     $milestoneData->ready_for_cre = $totalTasks > 0 && $totalTasks == $acceptedTasks;
   
//     return response([
//       'status' => 200,
//       'message' => 'Data fetched successfully!',
//       'error_msg' => null,
//       'data' => $data,
//       'milestone_data' => $milestoneData
//     ], 200);
//   }


public function delivery_documentation_data_fetch($id, $mileId)
{
    try {
 
        /*
        |--------------------------------------------------------------------------
        | Customer Service
        |--------------------------------------------------------------------------
        */
 
        $data = DB::table('et_customer_services')
            ->where('et_customer_services.sno', $id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin(
                'et_product_category',
                'et_product.product_category_id',
                '=',
                'et_product_category.sno'
            )
            ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_customer_services.cre_id')
            ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_customer_services.pc_id')
            ->select(
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_customer.customer_id',
                'et_customer.cus_email_id',
                'et_product.product_name',
                'et_product_category.product_category_name',
                'et_customer_services.sno',
                'et_customer_services.variant_variable_ids',
                'cre.staff_name as cre_name',
                'pc.staff_name as pc_name',
                'cre.staff_image as cre_image',
                'pc.staff_image as pc_image',
                'et_customer_services.created_at'
            )
            ->first();
 
        if (!$data) {
            return response([
                'status' => 404,
                'message' => 'Customer service not found.',
                'error_msg' => 'Customer service not found for ID: ' . $id,
                'data' => null,
                'milestone_data' => null
            ], 404);
        }
 
 
        /*
        |--------------------------------------------------------------------------
        | Milestone
        |--------------------------------------------------------------------------
        */
 
        $milestoneData = DB::table('et_milestone_mapping')
            ->leftJoin(
                'et_proposal_pay_slot',
                'et_proposal_pay_slot.sno',
                '=',
                'et_milestone_mapping.milestone_id'
            )
            ->leftJoin(
                'et_payment_slot',
                'et_payment_slot.sno',
                '=',
                'et_proposal_pay_slot.slot_id'
            )
            ->select(
                'et_milestone_mapping.service_id',
                'et_milestone_mapping.sno',
                'et_milestone_mapping.milestone_status',
                'et_milestone_mapping.task_ids',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount',
 
                'et_milestone_mapping.cre_acknowledged',
                'et_milestone_mapping.cre_acknowledged_by',
                'et_milestone_mapping.cre_acknowledged_date',
                'et_milestone_mapping.cre_completion_notes',
 
                'et_milestone_mapping.bh_acknowledged',
                'et_milestone_mapping.bh_acknowledged_by',
                'et_milestone_mapping.bh_acknowledged_date',
                'et_milestone_mapping.bh_completion_notes'
            )
            ->where('et_milestone_mapping.sno', $mileId)
            ->where('et_milestone_mapping.status', '!=', 2)
            ->first();
 
        if (!$milestoneData) {
            return response([
                'status' => 404,
                'message' => 'Milestone not found.',
                'error_msg' => 'Milestone not found for ID: ' . $mileId,
                'data' => $data,
                'milestone_data' => null
            ], 404);
        }
 
 
        /*
        |--------------------------------------------------------------------------
        | Validate Milestone belongs to Service
        |--------------------------------------------------------------------------
        */
 
        if ((int) $milestoneData->service_id !== (int) $id) {
            return response([
                'status' => 422,
                'message' => 'Milestone does not belong to this service.',
                'error_msg' => 'Service ID: ' . $id .
                    ', Milestone ID: ' . $mileId .
                    ', Milestone Service ID: ' . $milestoneData->service_id,
                'data' => $data,
                'milestone_data' => $milestoneData
            ], 422);
        }
 
 
        /*
        |--------------------------------------------------------------------------
        | Variant / Variable
        |--------------------------------------------------------------------------
        */
 
        $variantVariableIds = json_decode(
            $data->variant_variable_ids ?? '[]',
            true
        );
 
        $variantName = '';
        $variableName = '';
 
        if (is_array($variantVariableIds)) {
 
            foreach ($variantVariableIds as $v) {
 
                if (!empty($v['variant_id'])) {
 
                    $variant = DB::table('et_manage_product_variant')
                        ->where('sno', $v['variant_id'])
                        ->first();
 
                    if ($variant) {
                        $variantName = $variant->product_variant_name ?? '';
                    }
                }
 
                if (!empty($v['variable_id'])) {
 
                    $variable = DB::table('et_manage_product_variable')
                        ->where('sno', $v['variable_id'])
                        ->first();
 
                    if ($variable) {
                        $variableName = $variable->variable_name ?? '';
                    }
                }
            }
        }
 
 
        /*
        |--------------------------------------------------------------------------
        | Formatted Service ID
        |--------------------------------------------------------------------------
        */
 
        $year = date('Y', strtotime($data->created_at));
 
        $formattedId = str_pad(
            $data->sno,
            5,
            '0',
            STR_PAD_LEFT
        );
 
        $data->formatted_service_id = "SR-{$formattedId}/{$year}";
 
        $data->variant_name = $variantName;
        $data->variable_name = $variableName;
 
 
        /*
        |--------------------------------------------------------------------------
        | Task Counts
        |--------------------------------------------------------------------------
        */
 
        $totalTasks = DB::table('et_milestone_history')
            ->where('milestone_id', $milestoneData->sno)
            ->count();
 
        $acceptedTasks = DB::table('et_milestone_history')
            ->where('milestone_id', $milestoneData->sno)
            ->where('customer_ack_status', 1)
            ->count();
 
        $milestoneData->total_tasks = $totalTasks;
        $milestoneData->accepted_tasks = $acceptedTasks;
 
        $milestoneData->ready_for_cre =
            $totalTasks > 0 &&
            $totalTasks == $acceptedTasks;
 
 
        return response([
            'status' => 200,
            'message' => 'Data fetched successfully!',
            'error_msg' => null,
            'data' => $data,
            'milestone_data' => $milestoneData
        ], 200);
 
    } catch (\Exception $e) {
 
        \Log::error('delivery_documentation_data_fetch error', [
            'service_id' => $id,
            'milestone_id' => $mileId,
            'error' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile()
        ]);
 
        return response([
            'status' => 500,
            'message' => 'Something went wrong.',
            'error_msg' => $e->getMessage()
        ], 500);
    }
}
  // public function upload(Request $request)
  // {
  //   try {
  //     $request->validate([
  //       'file'      => 'required|file|max:5120',
  //       'mile_sno'  => 'required',
  //       'deli_id'   => 'required'
  //     ]);

  //     $file = $request->file('file');
  //     $folder = "delivery_temp/{$request->mile_sno}/{$request->deli_id}";
  //     $uniqueName = Str::random(20) . '.' . $file->getClientOriginalExtension();
  //     $path = $file->storeAs($folder, $uniqueName, 'public');

  //     return response()->json([
  //       'success' => true,
  //       'files' => [[
  //         'original_name' => $file->getClientOriginalName(),
  //         'unique_name'   => $uniqueName,
  //         'path'          => $path,
  //         'url'           => asset('storage/' . $path),
  //         'size'          => $file->getSize(),
  //         'type'          => $file->getMimeType()
  //       ]]
  //     ]);
  //   } catch (\Exception $e) {
  //     return response()->json([
  //       'success' => false,
  //       'message' => 'Upload failed: ' . $e->getMessage()
  //     ], 500);
  //   }
  // }



  /**
   * List existing temp files.
   */
  // public function existingFiles(Request $request)
  // {
  //   $mile = $request->input('mile_sno');
  //   $deli = $request->input('deli_id');

  //   if (!$mile || !$deli) {
  //     return response()->json(['success' => false, 'message' => 'Missing parameters']);
  //   }

  //   $folder = "delivery_temp/{$mile}/{$deli}";
  //   $files = [];

  //   if (Storage::disk('public')->exists($folder)) {
  //     foreach (Storage::disk('public')->files($folder) as $p) {
  //       $name = basename($p);
  //       $files[] = [
  //         'name'        => $name,
  //         'unique_name' => $name,
  //         'path'        => $p,
  //         'url'         => asset('storage/' . $p),
  //         'size'        => Storage::disk('public')->size($p),
  //         'type'        => mime_content_type(storage_path("app/public/{$p}"))
  //       ];
  //     }
  //   }

  //   return response()->json(['success' => true, 'files' => $files]);
  // }

  /**
   * Remove a temp file.
   */
  // public function remove(Request $request)
  // {
  //   $path = $request->input('file_path');
  //   if (!$path) return response()->json(['success' => false, 'message' => 'Missing file path']);

  //   if (Storage::disk('public')->exists($path)) {
  //     Storage::disk('public')->delete($path);
  //     return response()->json(['success' => true, 'message' => 'Deleted']);
  //   }

  //   return response()->json(['success' => false, 'message' => 'File not found']);
  // }

  /**
   * Final submission: move files from temp → live and save metadata.
   */
  public function finalSubmit(Request $request)
  {

    // return $request;
    $mileId        = $request->milestone_id;
    $user_id = $request->user()->user_id;
    $serviceId  = $request->service_id;
    $projectFiles = $request->input('project_files', []);

    $customer = DB::table('et_customer_services')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->where('et_customer_services.sno', $serviceId)
      ->select(
        'et_customer.customer_id',
        'et_customer.sno'
      )->first();

    $customerId = str_replace('/', '_', $customer->customer_id);

    $milestoneName = DB::table('et_milestone_mapping')
      ->where('et_milestone_mapping.sno', $mileId)
      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
      ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
      ->select(
        'et_payment_slot.payment_slot_name'
      )->first();

    if (!$mileId || !$customerId || empty($projectFiles)) {
      return response()->json([
        'success' => false,
        'message' => 'Missing parameters'
      ]);
    }

    $movedFiles = 0;
    $checklistDocuments = [];

    foreach ($projectFiles as $deliId => $filesJson) {

      $files = json_decode($filesJson, true);
      if (!is_array($files)) continue;

      $checklistName = DB::table('et_delivery_attachment_checklist')
        ->where('status', 0)
        ->where('sno', $deliId)
        ->first();

      /* TEMP & FINAL paths */
      $saved_attachments = $this->fileHandling($files, $user_id, $customerId, $checklistName->delivery_attachment_checklist, $milestoneName->payment_slot_name);
      $checklistDocuments[$checklistName->delivery_attachment_checklist] = $saved_attachments;
    }

    // return $checklistDocuments;

    DB::table('et_milestone_mapping')
      ->where('sno', $mileId)
      ->where('service_id', $serviceId)
      ->where('customer_id', $customer->sno)
      ->where('milestone_status', 1)
      ->where('delivery_status', 1)
      ->where('document_status', 0)
      ->update(
        [
          'document_status' => 1,
          'updated_at'      => now()
        ]
      );

    return response([
      'status' => 200,
      'message' => 'Delivery files saved successfully.',
      'data' => null
    ], 200);
  }

//   private function fileHandling($files, $user_id, $cusId, $check_id, $milename)
//   {
//     $saved_attachments = [];
//     $tempDir = public_path("{$user_id}/temp_project/{$check_id}");
//     $finalPath = public_path("service_deliverables/{$cusId}/{$milename}/{$check_id}");

//     if (!is_dir($finalPath) && !mkdir($finalPath, 0755, true)) {
//       throw new \Exception("Failed to create project directory: {$finalPath}");
//     }

//     foreach ($files as $fileName) {
//       $sourcePath = $tempDir . '/' . $fileName;
//       $safeFileName = basename($fileName);

//       if (!file_exists($sourcePath)) {
//         Log::warning("Source file not found: {$sourcePath}");
//         continue;
//       }

//       $newName = $fileName;

//       $extension = pathinfo($safeFileName, PATHINFO_EXTENSION);
//       // $newName = 'file_' . str_pad($fileIndex, 2, '0', STR_PAD_LEFT) . '.' . $extension;
//       $destinationPath = $finalPath . '/' . $newName;

//       // Move file
//       if (!rename($sourcePath, $destinationPath)) {
//         throw new \Exception("Failed to move file: {$safeFileName}");
//       }

//       $saved_attachments[] = 'service_deliverables/' . $cusId . '/' . $milename . '/' . $check_id . '/' . $newName;
//       // $fileIndex++;
//     }

//     $this->cleanup_temp_directory($tempDir);

//     return $saved_attachments;
//   }
 private function fileHandling($files, $user_id, $cusId, $check_id, $milename)
  {
    $saved_attachments = [];
    $wasabi = app(WasabiFileService::class);

    $tempPrefix = "{$user_id}/temp_project/{$check_id}/";
    $finalPrefix = "service_deliverables/{$cusId}/{$milename}/{$check_id}/";

    foreach ($files as $fileKey) {
      $safeFileName = basename($fileKey);

      // Backward compatibility: if $fileKey is just a filename (not a Wasabi key),
      # try local temp path
      if (! str_starts_with($fileKey, 'production/')) {
        $sourcePath = public_path("{$user_id}/temp_project/{$check_id}/{$safeFileName}");
        if (!file_exists($sourcePath)) {
          Log::warning("Source file not found: {$sourcePath}");
          continue;
        }

        $uploadResult = $wasabi->uploadFromPath($sourcePath, $finalPrefix, $safeFileName);
        @unlink($sourcePath);

        $saved_attachments[] = $uploadResult['key'];
        continue;
      }

      // Wasabi: copy from temp key to final key, then delete temp
      if (! $wasabi->exists($fileKey)) {
        Log::warning("Wasabi source file not found: {$fileKey}");
        continue;
      }

      // Generate a unique name for the final file
      $extension = pathinfo($safeFileName, PATHINFO_EXTENSION);
      $uniqueName = time() . '_' . uniqid() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', pathinfo($safeFileName, PATHINFO_FILENAME)) . '.' . $extension;
      $finalKey = $finalPrefix . $uniqueName;

      if (! $wasabi->copy($fileKey, $finalKey)) {
        throw new \Exception("Failed to move file to cloud storage: {$safeFileName}");
      }

      // Delete temp file from Wasabi
      $wasabi->delete($fileKey);

      $saved_attachments[] = $finalKey;
    }

    return $saved_attachments;
  }

  public function deliveryAttachmentList()
  {
    $DeliCheck_list = DB::table('et_delivery_attachment_checklist')->where('status', 0)->orderBy('delivery_attachment_checklist')->get();

    return response([
      'status' => 200,
      'message' => 'Delivery Checklist Fetched Successfully',
      'data' => $DeliCheck_list
    ], 200);
  }

//   public function FetchDropZone(Request $request)
//   {
//     $user_id = $request->user()->user_id;
//     $check_id = $request->check_id;

//     $checklistName = DB::table('et_delivery_attachment_checklist')
//       ->where('sno', $check_id)
//       ->where('status', 0)
//       ->first();

//     $request->validate(['file' => 'required']);

//     if ($request->hasFile('file')) {
//       $file = $request->file('file');
//       $filename = $file->getClientOriginalName();

//       // Move file to public/manage_project folder
//       $file->move(public_path("{$user_id}/temp_project/{$checklistName->delivery_attachment_checklist}"), $filename);

//       return response()->json(['status' => 'success', 'filename' => $filename]);
//     }

//     return response()->json(['status' => 'error'], 400);
//   }
 public function FetchDropZone(Request $request)
  {
    $user_id = $request->user()->user_id;
    $check_id = $request->check_id;

    $checklistName = DB::table('et_delivery_attachment_checklist')
      ->where('sno', $check_id)
      ->where('status', 0)
      ->first();

    $request->validate(['file' => 'required']);

    if ($request->hasFile('file')) {
      $file = $request->file('file');
      $filename = $file->getClientOriginalName();

      // Upload to Wasabi temp folder instead of local public/
      $wasabi = app(WasabiFileService::class);
      $folder = "{$user_id}/temp_project/{$checklistName->delivery_attachment_checklist}";
      $uploadResult = $wasabi->upload($file, $folder);

      return response()->json([
        'status' => 'success',
        'filename' => $filename,
        'wasabi_key' => $uploadResult['key'],
        'path' => $uploadResult['key'],
      ]);
    }

    return response()->json(['status' => 'error'], 400);
  }
//   public function remove_temp_file(Request $request)
//   {
//     $user_id = $request->user()->user_id;
//     $check_id = $request->check_id;
//     $filename = $request->input('filename');

//     $checklistName = DB::table('et_delivery_attachment_checklist')
//       ->where('sno', $check_id)
//       ->where('status', 0)
//       ->first();

//     $filePath = public_path($user_id . '/temp_project/' . $checklistName->delivery_attachment_checklist . '/' . $filename);
//     $folderPath = public_path($user_id . '/temp_project/' . $checklistName->delivery_attachment_checklist);

//     if (file_exists($filePath)) {
//       unlink($filePath);

//       $this->remove_empty_folder($folderPath);

//       return response()->json(['status' => 'success', 'message' => 'File removed successfully']);
//     }

//     return response()->json(['status' => 'error', 'message' => 'File not found'], 404);
//   }

public function remove_temp_file(Request $request)
  {
    $user_id = $request->user()->user_id;
    $check_id = $request->check_id;
    $filename = $request->input('filename');
    $wasabiKey = $request->input('wasabi_key') ?? $request->input('path');

    $checklistName = DB::table('et_delivery_attachment_checklist')
      ->where('sno', $check_id)
      ->where('status', 0)
      ->first();

    // If we have a Wasabi key, delete from Wasabi
    if ($wasabiKey) {
      $wasabi = app(WasabiFileService::class);
      if ($wasabi->exists($wasabiKey)) {
        $wasabi->delete($wasabiKey);

        return response()->json(['status' => 'success', 'message' => 'File removed successfully']);
      }

      return response()->json(['status' => 'error', 'message' => 'File not found in cloud storage'], 404);
    }

    // Fallback to local filesystem for backward compatibility
    $filePath = public_path($user_id . '/temp_project/' . $checklistName->delivery_attachment_checklist . '/' . $filename);
    $folderPath = public_path($user_id . '/temp_project/' . $checklistName->delivery_attachment_checklist);

    if (file_exists($filePath)) {
      unlink($filePath);

      $this->remove_empty_folder($folderPath);

      return response()->json(['status' => 'success', 'message' => 'File removed successfully']);
    }

    return response()->json(['status' => 'error', 'message' => 'File not found'], 404);
  }
  private function remove_empty_folder($folderPath)
  {
    if (is_dir($folderPath)) {
      $files = array_diff(scandir($folderPath), ['.', '..']);

      if (count($files) === 0) {
        rmdir($folderPath);

        $userFolderPath = dirname($folderPath);
        $userFiles = array_diff(scandir($userFolderPath), ['.', '..']);

        if (count($userFiles) === 0) {
          rmdir($userFolderPath);
        }
      }
    }
  }

  private function cleanup_temp_directory(string $tempDir): void
  {
    if (!is_dir($tempDir)) {
      return;
    }

    try {
      $files = glob($tempDir . '/*');
      foreach ($files as $file) {
        if (is_file($file)) {
          unlink($file);
        }
      }

      // Remove the directory itself
      if (is_dir($tempDir)) {
        rmdir($tempDir);
      }
    } catch (\Exception $e) {
      Log::warning("Failed to cleanup temp directory: {$tempDir} - " . $e->getMessage());
    }
  }
  public function milestoneCreAcknowledge(Request $request)
{
    $request->validate([

        'milestone_mapping_id' => 'required',

        'completion_notes' => 'required'

    ]);

    $mapping = DB::table('et_milestone_mapping')

        ->where('sno',$request->milestone_mapping_id)

        ->first();

    if(!$mapping){

        return response()->json([

            'status'=>404,

            'message'=>'Milestone not found.'

        ]);
    }

    DB::table('et_milestone_mapping')

        ->where('sno',$mapping->sno)

        ->update([

            'cre_acknowledged'      => 1,

            'cre_acknowledged_by'   => auth()->user()->user_id,

            'cre_acknowledged_date' => now(),

            'cre_completion_notes'  => $request->completion_notes

        ]);

    /*
    |--------------------------------------------------------------------------
    | Production Log
    |--------------------------------------------------------------------------
    */

    $helper = new \App\Helpers\Helpers();

    $helper->createProductionLog([

        'service_id' => $mapping->service_id,

        'milestone_id' => $mapping->milestone_id,

        'action_type' => 'milestone_cre_acknowledged',

        'remarks' => $request->completion_notes,

        'performed_by' => auth()->user()->user_id

    ]);

    return response()->json([

        'status'=>200,

        'message'=>'CRE acknowledged successfully.'

    ]);
}

// public function bhAcknowledge(Request $request)
// {
//     DB::beginTransaction();

//     try {

//         $milestone = DB::table('et_milestone_mapping')
//             ->where('sno',$request->milestone_id)
//             ->first();

//         if(!$milestone){

//             return response()->json([
//                 'status'=>404,
//                 'message'=>'Milestone not found.'
//             ]);
//         }
  
  
//         if($milestone->bh_acknowledged){

//             return response()->json([
//                 'status'=>400,
//                 'message'=>'Already acknowledged.'
//             ]);
//         }

//         DB::table('et_milestone_mapping')
//             ->where('sno',$milestone->sno)
//             ->update([

//                 'bh_acknowledged'=>1,
//                 'bh_acknowledged_by'=>auth()->user()->user_id,
//                 'bh_acknowledged_date'=>now(),
//                 'bh_completion_notes'=>$request->notes,
//                 // 'milestone_status'=>2, // Completed
//                 'updated_at'=>now()

//             ]);

//         /*
//         |--------------------------------------------------------------------------
//         | Production Points
//         |--------------------------------------------------------------------------
//         */

//         (new \App\Helpers\Helpers())->calculateMilestonePoints(

//             $milestone->sno,

//             $milestone->service_id

//         );

//         /*
//         |--------------------------------------------------------------------------
//         | Log
//         |--------------------------------------------------------------------------
//         */

//         (new \App\Helpers\Helpers())->createProductionLog([

//             'service_id'=>$milestone->service_id,

//             'milestone_id'=>$milestone->sno,

//             'action_type'=>'bh_acknowledged',

//             'performed_by'=>auth()->user()->user_id,

//             'remarks'=>$request->notes

//         ]);

//         DB::commit();

//         return response()->json([

//             'status'=>200,

//             'message'=>'Milestone acknowledged successfully.'

//         ]);

//     } catch(\Exception $e){

//         DB::rollBack();

//         return response()->json([

//             'status'=>500,

//             'message'=>$e->getMessage()

//         ]);

//     }
// }


// public function bhAcknowledge(Request $request)
// {
//     DB::beginTransaction();
 
//     try {
 
//         $milestone = DB::table('et_milestone_mapping')
//             ->where('sno',$request->milestone_id)
//             ->first();
 
//         if(!$milestone){
 
//             return response()->json([
//                 'status'=>404,
//                 'message'=>'Milestone not found.'
//             ]);
//         }
 
 
//         if($milestone->bh_acknowledged){
 
//             return response()->json([
//                 'status'=>400,
//                 'message'=>'Already acknowledged.'
//             ]);
//         }
//     $eligibleAt = Carbon::createFromFormat(
//             'Y-m',
//             $request->milestone_eligible_month
//         )->startOfMonth();
//         DB::table('et_milestone_mapping')
//             ->where('sno',$milestone->sno)
//             ->update([
 
//                 'bh_acknowledged'=>1,
//                 'bh_acknowledged_by'=>auth()->user()->user_id,
//                 'bh_acknowledged_date'=>now(),
//                 'bh_completion_notes'=>$request->notes,
//                 'milestone_status'=>2, // Completed
//                 'updated_at'=>now()
 
//             ]);
 
//         /*
//         |--------------------------------------------------------------------------
//         | Production Points
//         |--------------------------------------------------------------------------
//         */
 
//         (new \App\Helpers\Helpers())->calculateMilestonePoints(
 
//             $milestone->sno,
 
//             $milestone->service_id,
//             $eligibleAt
 
//         );
 
//         /*
//         |--------------------------------------------------------------------------
//         | Log
//         |--------------------------------------------------------------------------
//         */
 
//         (new \App\Helpers\Helpers())->createProductionLog([
 
//             'service_id'=>$milestone->service_id,
 
//             'milestone_id'=>$milestone->sno,
 
//             'action_type'=>'bh_acknowledged',
 
//             'performed_by'=>auth()->user()->user_id,
 
//             'remarks'=>$request->notes
 
//         ]);
 
//         DB::commit();
 
//         return response()->json([
 
//             'status'=>200,
 
//             'message'=>'Milestone acknowledged successfully.'
 
//         ]);
 
//     } catch(\Exception $e){
 
//         DB::rollBack();
 
//         return response()->json([
 
//             'status'=>500,
 
//             'message'=>$e->getMessage()
 
//         ]);
 
//     }
// }

public function bhAcknowledge(Request $request)
{
    DB::beginTransaction();
 
    try {
 
        $milestone = DB::table('et_milestone_mapping')
            ->where('sno',$request->milestone_id)
            ->first();
 
        if(!$milestone){
 
            return response()->json([
                'status'=>404,
                'message'=>'Milestone not found.'
            ]);
        }
 
 
        if($milestone->bh_acknowledged){
 
            return response()->json([
                'status'=>400,
                'message'=>'Already acknowledged.'
            ]);
        }
    $eligibleAt = Carbon::createFromFormat(
            'Y-m-d',
            $request->milestone_eligible_date
        )->startOfDay();
        DB::table('et_milestone_mapping')
            ->where('sno',$milestone->sno)
            ->update([
 
                'bh_acknowledged'=>1,
                'bh_acknowledged_by'=>auth()->user()->user_id,
                'bh_acknowledged_date'=>now(),
                'bh_completion_notes'=>$request->notes,
                'milestone_status'=>2, // Completed
                // Actual milestone completion/eligibility date
                 'milestone_eligible_at' => $eligibleAt->toDateString(),
                'updated_at'=>now()
 
            ]);
 
        /*
        |--------------------------------------------------------------------------
        | Production Points
        |--------------------------------------------------------------------------
        */
 
        (new \App\Helpers\Helpers())->calculateMilestonePoints(
 
            $milestone->sno,
 
            $milestone->service_id,
            $eligibleAt
 
        );
 
        /*
        |--------------------------------------------------------------------------
        | Log
        |--------------------------------------------------------------------------
        */
 
        (new \App\Helpers\Helpers())->createProductionLog([
 
            'service_id'=>$milestone->service_id,
 
            'milestone_id'=>$milestone->sno,
 
            'action_type'=>'bh_acknowledged',
 
            'performed_by'=>auth()->user()->user_id,
 
            'remarks'=>$request->notes
 
        ]);
 
        DB::commit();
 
        return response()->json([
 
            'status'=>200,
 
            'message'=>'Milestone acknowledged successfully.'
 
        ]);
 
    } catch(\Exception $e){
 
        DB::rollBack();
 
        return response()->json([
 
            'status'=>500,
 
            'message'=>$e->getMessage()
 
        ]);
 
    }
}


// public function submitExternalCustomerCorrection(
//     Request $request
// ) {
 
//     DB::beginTransaction();
 
//     try {
 
//             $request->validate([
//                 'history_id' => 'required|integer',
//                 'service_id' => 'required|integer',
//                 'milestone_id' => 'required|integer',
//                 'remarks' => 'required|string',
//                 'concern_action' => 'required|in:correction,updation',
//                 'target_completion_date' => 'nullable|date',
//                 'customer_screenshots' => 'nullable|array',
//                 'customer_screenshots.*' => 'file|mimes:jpg,jpeg,png,webp,pdf,doc,docx,xls,xlsx,zip|max:10240',
//                 'correction_documents' => 'nullable|array',
//                 'correction_documents.*' => 'file|mimes:pdf,doc,docx,xls,xlsx,jpg,jpeg,png,zip|max:10240'
//                 ]);
//         $taskStatus = $request->concern_action === 'updation' ? 9 : 8;
//         $taskRevertType = $request->concern_action === 'updation' ? 2 : 1;
//         $history = DB::table(
//             'et_milestone_history'
//         )
//         ->where(
//             'sno',
//             $request->history_id
//         )
//         ->first();
 
//         if (!$history) {
 
//             DB::rollBack();
 
//             return response()->json([
//                 'status' => 404,
//                 'message' => 'Task history not found.'
//             ]);
//         }
 
//         /*
//         |--------------------------------------------------------------------------
//         | Current User
//         |--------------------------------------------------------------------------
//         */
 
//         $userId =
//             auth()->user()->user_id;
 
//         $roleId =
//             auth()->user()->role_id;
 
//         /*
//         |--------------------------------------------------------------------------
//         | Determine source role
//         |--------------------------------------------------------------------------
//         */
 
//         $source = null;
 
//         if ($roleId==1) {
 
//             $source = 'admin';
 
//         } elseif ($roleId==16) {
 
//             $source = 'cre';
 
//         } elseif ($roleId==20) {
 
//             $source = 'bh';
 
//         } else {
 
//             DB::rollBack();
 
//             return response()->json([
//                 'status' => 403,
//                 'message' =>
//                     'Only CRE or BH can submit customer correction.'
//             ]);
//         }
//                 DB::table('et_milestone_history')
//             ->where('sno', $history->sno)
//             ->update([
 
//                 'customer_reject_remarks' =>
//                     $request->remarks,
 
//                 'revert_type' => $taskRevertType,
 
//                 'reverted_to_production' =>
//                     1,
 
//                 'reverted_by' =>
//                     $userId,
 
//                 'reverted_date' =>
//                     now(),
 
//                 'reverted_remarks' =>
//                     $request->remarks,
 
//                 'target_completion_date' =>
//                     $request->target_completion_date
//                         ?: $history->target_completion_date,
 
//                 'status' => $taskStatus,
 
//                 'external_customer_correction' =>
//                     1,
 
//                 'external_correction_by' =>
//                     $userId,
 
//                 'external_correction_role' =>
//                     $roleId,
 
//                 'external_correction_date' =>
//                     now(),
 
//                 'external_correction_remarks' =>
//                     $request->remarks,
 
//                 'updated_at' => now(),
//                 'correction_tracking' => 1,
//             ]);
//                     $uploadPath =
//             public_path('customer_task_documents');
 
//         if (!file_exists($uploadPath)) {
 
//             mkdir(
//                 $uploadPath,
//                 0755,
//                 true
//             );
//         }
 
//     if ($request->hasFile('customer_screenshots')) {
//      foreach ($request->file('customer_screenshots')as $file
//         ) {
 
//             $fileName =
//                 time().'_'.
//                 uniqid().
//                 '.'.
//                 $file->getClientOriginalExtension();
 
//             $file->move(
//                 $uploadPath,
//                 $fileName
//             );
 
//             DB::table(
//                 'et_task_customer_documents'
//             )->insert([
 
//                 'milestone_history_id' =>
//                     $history->sno,
 
//                 'service_id' =>
//                     $request->service_id,
 
//                 'uploaded_by_customer' =>
//                     null,
 
//                 'document_name' =>
//                     pathinfo(
//                         $file->getClientOriginalName(),
//                         PATHINFO_FILENAME
//                     ),
 
//                 'document_file' =>
//                     $fileName,
 
//                 'remarks' =>
//                     $request->remarks,
 
//                 'uploaded_by_role' =>
//                     $roleId,
 
//                 'upload_source' =>
//                     $source,
 
//                 'created_at' =>
//                     now(),
 
//                 'updated_at' =>
//                     now()
 
//             ]);
//         }
//     }
//     if ($request->hasFile('correction_documents')) {
//                 foreach (
//             $request->file('correction_documents')
//             as $file
//         ) {
 
//             $fileName =
//                 time().'_'.
//                 uniqid().
//                 '.'.
//                 $file->getClientOriginalExtension();
 
//             $file->move(
//                 $uploadPath,
//                 $fileName
//             );
 
//             DB::table(
//                 'et_task_customer_documents'
//             )->insert([
 
//                 'milestone_history_id' =>
//                     $history->sno,
 
//                 'service_id' =>
//                     $request->service_id,
 
//                 'uploaded_by_customer' =>
//                     null,
 
//                 'document_name' =>
//                     pathinfo(
//                         $file->getClientOriginalName(),
//                         PATHINFO_FILENAME
//                     ),
 
//                 'document_file' =>
//                     $fileName,
 
//                 'remarks' =>
//                     $request->remarks,
 
//                 'uploaded_by_role' =>
//                     $roleId,
 
//                 'upload_source' =>
//                     $source,
 
//                 'created_at' =>
//                     now(),
 
//                 'updated_at' =>
//                     now()
 
//             ]);
//         }
//     }
//         $helper =
//     new \App\Helpers\Helpers();
 
//     $helper->createProductionLog([
 
//         'service_id' =>
//             $request->service_id,
 
//         'milestone_id' =>
//             $history->milestone_id,
 
//         'milestone_history_id' =>
//             $history->sno,
 
//         'action_type' =>
//             'customer_correction',
 
//         'old_value' => [
 
//             'status' =>
//                 $history->status,
 
//             'reverted_to_production' =>
//                 $history->reverted_to_production
 
//         ],
 
//         'new_value' => [
 
//             'status' =>
//                 8,
 
//             'reverted_to_production' =>
//                 1,
 
//             'external_customer_correction' =>
//                 1
 
//         ],
 
//         'remarks' =>
//             $request->remarks,
 
//         'performed_by' =>
//             $userId
 
//     ]);
//             DB::commit();
 
//         return response()->json([
 
//             'status' => 200,
 
//             'message' =>
//                 'Customer correction submitted successfully.'
 
//         ]);
 
//     } catch (\Exception $e) {
 
//         DB::rollBack();
 
//         \Log::error(
//             'External customer correction failed',
//             [
//                 'error' =>
//                     $e->getMessage(),
 
//                 'history_id' =>
//                     $request->history_id ?? null
//             ]
//         );
 
//         return response()->json([
 
//             'status' => 500,
 
//             'message' =>
//                 $e->getMessage()
 
//         ]);
//     }
// }

public function submitExternalCustomerCorrection(
    Request $request
) {

    DB::beginTransaction();

    try {

            $request->validate([
                'history_id' => 'required|integer',
                'service_id' => 'required|integer', 
                'milestone_id' => 'required|integer', 
                'remarks' => 'required|string', 
                'concern_action' => 'required|in:correction,updation', 
                'target_completion_date' => 'nullable|date', 
                'customer_screenshots' => 'nullable|array', 
                'customer_screenshots.*' => 'file|mimes:jpg,jpeg,png,webp,pdf,doc,docx,xls,xlsx,zip|max:10240', 
                'correction_documents' => 'nullable|array', 
                'correction_documents.*' => 'file|mimes:pdf,doc,docx,xls,xlsx,jpg,jpeg,png,zip|max:10240'
                ]);
        $taskStatus = $request->concern_action === 'updation' ? 9 : 8;
        $taskRevertType = $request->concern_action === 'updation' ? 2 : 1;
        $history = DB::table(
            'et_milestone_history'
        )
        ->where(
            'sno',
            $request->history_id
        )
        ->first();

        if (!$history) {

            DB::rollBack();

            return response()->json([
                'status' => 404,
                'message' => 'Task history not found.'
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Current User
        |--------------------------------------------------------------------------
        */

        $userId =
            auth()->user()->user_id;

        $roleId =
            auth()->user()->role_id;

        /*
        |--------------------------------------------------------------------------
        | Determine source role
        |--------------------------------------------------------------------------
        */

        $source = null;

        if ($roleId==1) {

            $source = 'admin';

        } elseif ($roleId==16) {

            $source = 'cre';

        } elseif ($roleId==20) {

            $source = 'bh';

        } else {

            DB::rollBack();

            return response()->json([
                'status' => 403,
                'message' =>
                    'Only CRE or BH can submit customer correction.'
            ]);
        }
                DB::table('et_milestone_history')
            ->where('sno', $history->sno)
            ->update([

                'customer_reject_remarks' =>
                    $request->remarks,

                'revert_type' => $taskRevertType,

                'reverted_to_production' =>
                    1,

                'reverted_by' =>
                    $userId,

                'reverted_date' =>
                    now(),

                'reverted_remarks' =>
                    $request->remarks,

                'target_completion_date' =>
                    $request->target_completion_date
                        ?: $history->target_completion_date,

                'status' => $taskStatus,

                'external_customer_correction' =>
                    1,

                'external_correction_by' =>
                    $userId,

                'external_correction_role' =>
                    $roleId,

                'external_correction_date' =>
                    now(),

                'external_correction_remarks' =>
                    $request->remarks,

                'updated_at' => now(),
                'correction_tracking' => 1,
            ]);
    // Wasabi cloud upload for external customer correction documents
    $wasabi = app(WasabiFileService::class);

    if ($request->hasFile('customer_screenshots')) {
     foreach ($request->file('customer_screenshots') as $file) {

            $folder = 'customer_task_documents';
            $uploadResult = $wasabi->upload($file, $folder);

            DB::table(
                'et_task_customer_documents'
            )->insert([

                'milestone_history_id' =>
                    $history->sno,

                'service_id' =>
                    $request->service_id,

                'uploaded_by_customer' =>
                    null,

                'document_name' =>
                    pathinfo(
                        $file->getClientOriginalName(),
                        PATHINFO_FILENAME
                    ),

                'document_file' =>
                    $uploadResult['key'],

                'remarks' =>
                    $request->remarks,

                'uploaded_by_role' =>
                    $roleId,

                'upload_source' =>
                    $source,

                'created_at' =>
                    now(),

                'updated_at' =>
                    now()

            ]);
        }
    }
    if ($request->hasFile('correction_documents')) {
        foreach (
            $request->file('correction_documents')
            as $file
        ) {

            $folder = 'customer_task_documents';
            $uploadResult = $wasabi->upload($file, $folder);

            DB::table(
                'et_task_customer_documents'
            )->insert([

                'milestone_history_id' =>
                    $history->sno,

                'service_id' =>
                    $request->service_id,

                'uploaded_by_customer' =>
                    null,

                'document_name' =>
                    pathinfo(
                        $file->getClientOriginalName(),
                        PATHINFO_FILENAME
                    ),

                'document_file' =>
                    $uploadResult['key'],

                'remarks' =>
                    $request->remarks,

                'uploaded_by_role' =>
                    $roleId,

                'upload_source' =>
                    $source,

                'created_at' =>
                    now(),

                'updated_at' =>
                    now()

            ]);
        }
    }
        $helper =
    new \App\Helpers\Helpers();

    $helper->createProductionLog([

        'service_id' =>
            $request->service_id,

        'milestone_id' =>
            $history->milestone_id,

        'milestone_history_id' =>
            $history->sno,

        'action_type' =>
            'customer_correction',

        'old_value' => [

            'status' =>
                $history->status,

            'reverted_to_production' =>
                $history->reverted_to_production

        ],

        'new_value' => [

            'status' =>
                8,

            'reverted_to_production' =>
                1,

            'external_customer_correction' =>
                1

        ],

        'remarks' =>
            $request->remarks,

        'performed_by' =>
            $userId

    ]);
            DB::commit();

        return response()->json([

            'status' => 200,

            'message' =>
                'Customer correction submitted successfully.'

        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        \Log::error(
            'External customer correction failed',
            [
                'error' =>
                    $e->getMessage(),

                'history_id' =>
                    $request->history_id ?? null
            ]
        );

        return response()->json([

            'status' => 500,

            'message' =>
                $e->getMessage()

        ]);
    }
}
}