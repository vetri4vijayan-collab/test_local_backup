<?php

namespace App\Http\Controllers\customer_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\ReviewLinkModel;
use App\Models\ManageReviewModel;
use Illuminate\Support\Facades\Validator;

class ManageReview extends Controller
{

//      public function index(Request $request){
 
//         $branch_id = $request->user()->branch_id;
//         $user_id = $request->user()->user_id;
//         $customers = CustomerModel::where('branch_id', $branch_id)->where('status', '!=', 2)->get();
//         $reviews = ReviewLinkModel::where('status', '!=', 2)->get();
 
//         $query = ManageReviewModel::where('et_manage_review.status', '!=', 2)
//         ->select(
//             'et_manage_review.*',
//             'et_customer.cus_name',
//             'et_customer.customer_id',
//             'et_proposal.cre_id'
//         )
//         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_review.customer_id')
//         ->leftJoin('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->where('et_manage_review.branch_id', $branch_id);
//     if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
 
//         $query->where('et_proposal.cre_id', $user_id);
 
//     } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
 
//         abort(403, 'Unauthorized');
//     }
//     $records = $query->get();
//       $ratingCounts = ManageReviewModel::where('et_manage_review.status', 0)
//         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_review.customer_id')
//         ->leftJoin('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->when(
//             auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus'),
//             fn($q) => $q->where('et_proposal.cre_id', $user_id)
//         )
//         ->selectRaw('ratings, COUNT(*) as total')
//         ->groupBy('ratings')
//         ->pluck('total', 'ratings');
 
//     $star_5 = $ratingCounts[5] ?? 0;
//     $star_4 = $ratingCounts[4] ?? 0;
//     $star_3 = $ratingCounts[3] ?? 0;
//     $star_2 = $ratingCounts[2] ?? 0;
//     $star_1 = $ratingCounts[1] ?? 0;
//         $total_reviews = $star_1 + $star_2 + $star_3 + $star_4 + $star_5;
// // Permission filter
   
//         return view('content.customer_management.manage_review', compact('customers', 'reviews', 'records', 'star_5', 'star_4', 'star_3', 'star_2', 'star_1', 'total_reviews'));
//     }

//     public function index(Request $request){
 
//         $branch_id = $request->user()->branch_id;
//         $user_id = $request->user()->user_id;
//         $customers = CustomerModel::where('branch_id', $branch_id)->where('status', '!=', 2)->get();
//         $reviews = ReviewLinkModel::where('status', '!=', 2)->get();
 
//         $query = ManageReviewModel::where('et_manage_review.status', '!=', 2)
//         ->select(
//             'et_manage_review.*',
//             'et_customer.cus_name',
//             'et_customer.customer_id',
//             'et_proposal.cre_id'
//         )
//         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_review.customer_id')
//         ->leftJoin('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->where('et_manage_review.branch_id', $branch_id);
//     if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Review', 'view_self_cus')) {
 
//         $query->where('et_proposal.cre_id', $user_id);
 
//     } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Manage Review', 'global_cus')) {
 
//         abort(403, 'Unauthorized');
//     }
//     $records = $query->get();
//       $ratingCounts = ManageReviewModel::where('et_manage_review.status', 0)
//         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_review.customer_id')
//         ->leftJoin('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->when(
//             auth()->user()->hasPermissionradio('Customer Management', 'Manage Review', 'view_self_cus'),
//             fn($q) => $q->where('et_proposal.cre_id', $user_id)
//         )
//         ->selectRaw('ratings, COUNT(*) as total')
//         ->groupBy('ratings')
//         ->pluck('total', 'ratings');
 
//     $star_5 = $ratingCounts[5] ?? 0;
//     $star_4 = $ratingCounts[4] ?? 0;
//     $star_3 = $ratingCounts[3] ?? 0;
//     $star_2 = $ratingCounts[2] ?? 0;
//     $star_1 = $ratingCounts[1] ?? 0;
//         $total_reviews = $star_1 + $star_2 + $star_3 + $star_4 + $star_5;
// // Permission filter
   
//         return view('content.customer_management.manage_review', compact('customers', 'reviews', 'records', 'star_5', 'star_4', 'star_3', 'star_2', 'star_1', 'total_reviews'));
//     }

 
public function index(Request $request){
 
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $customers = CustomerModel::where('branch_id', $branch_id)->where('status', '!=', 2)->get();
        $reviews = ReviewLinkModel::where('status', '!=', 2)->get();
 
        $query = ManageReviewModel::where('et_manage_review.status', '!=', 2)
        ->select(
            'et_manage_review.*',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_proposal.cre_id'
        )
        ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_review.customer_id')
        ->leftJoin('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->where('et_manage_review.branch_id', $branch_id);
    if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Review', 'view_self_cus')) {
 
        $query->where('et_manage_review.created_by', $user_id);
 
    } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Manage Review', 'global_cus')) {
 
        abort(403, 'Unauthorized');
    }
    $records = $query->get();
       $ratingCounts = ManageReviewModel::where('et_manage_review.status', 0)
        ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_review.customer_id')
        ->leftJoin('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->when(
            auth()->user()->hasPermissionradio('Customer Management', 'Manage Review', 'view_self_cus'),
            fn($q) => $q->where('et_manage_review.created_by', $user_id)
        )
        ->selectRaw('ratings, COUNT(*) as total')
        ->groupBy('ratings')
        ->pluck('total', 'ratings');
 
    $star_5 = $ratingCounts[5] ?? 0;
    $star_4 = $ratingCounts[4] ?? 0;
    $star_3 = $ratingCounts[3] ?? 0;
    $star_2 = $ratingCounts[2] ?? 0;
    $star_1 = $ratingCounts[1] ?? 0;
        $total_reviews = $star_1 + $star_2 + $star_3 + $star_4 + $star_5;
// Permission filter
   
        return view('content.customer_management.manage_review', compact('customers', 'reviews', 'records', 'star_5', 'star_4', 'star_3', 'star_2', 'star_1', 'total_reviews'));
    }
    
    
    // public function Create(Request $request){

    //     $validator = Validator::make($request->all(), [
    //         'google_review' => 'required|string'
    //     ]);

    //     if ($validator->fails()) {
    //         return response([
    //             'status' => 422,
    //             'message' => 'Incorret Input Field Format',
    //             'error_msg' => $validator->messages()->get('*'),
    //             'data' => null
    //         ], 422);
    //     }

    //     $user_id = $request->user()->user_id;
    //     $branch_id = $request->user()->branch_id;


    //     $CREATE = new ManageReviewModel();
    //     $CREATE->branch_id = $branch_id;
    //     $CREATE->customer_id = $request->customer_id;
    //     $CREATE->ratings = $request->rating_value;
    //     $CREATE->review = $request->google_review;
    //     $CREATE->review_image = $request->review_image ?? 0;

    //     // Review Links
    //     $selected_links = $request->input('review_links');

    //     if(!empty($selected_links)){
    //         $links_array = array_map(function ($link_id) {
    //             return ['link' => $link_id];
    //         }, $selected_links);

    //         $linksJson = json_encode($links_array);
    //     } else {
    //         $linksJson = json_encode([]);
    //     }

    //     $CREATE->review_list = $linksJson;
    //     $CREATE->created_by = $user_id;
    //     $CREATE->updated_by = $user_id;
    //     $CREATE->save();

    //     if ($CREATE) {
    //         session()->flash('toastr', [
    //             'type' => 'success',
    //             'message' => 'Review Added Successfully'
    //         ]);
    //         return redirect()->back();
    //     } else {
    //         session()->flash('toastr', [
    //             'type' => 'error',
    //             'message' => 'Review Creation Failed'
    //         ]);
    //         return redirect()->back();
    //     }
    // }
    
     public function Create(Request $request){
 
        $validator = Validator::make($request->all(), [
            'google_review' => 'required|string',
            'review_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);
 
        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorret Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 422);
        }
 
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
 
 
        $CREATE = new ManageReviewModel();
        $CREATE->branch_id = $branch_id;
        $CREATE->customer_id = $request->customer_id;
        $CREATE->ratings = $request->rating_value;
        $CREATE->review = $request->google_review;
        if ($request->hasFile('review_image')) {
 
                $image = $request->file('review_image');
 
                $filename = time().'_'.uniqid().'.'.$image->getClientOriginalExtension();
 
                $image->move(public_path('uploads/review_images'), $filename);
 
                $CREATE->review_image = 'uploads/review_images/'.$filename;
 
            } else {
 
                $CREATE->review_image = null;
            }
 
        // Review Links
        $selected_links = $request->input('review_links');
 
        if(!empty($selected_links)){
            $links_array = array_map(function ($link_id) {
                return ['link' => $link_id];
            }, $selected_links);
 
            $linksJson = json_encode($links_array);
        } else {
            $linksJson = json_encode([]);
        }
 
        $CREATE->review_list = $linksJson;
        $CREATE->created_by = $user_id;
        $CREATE->updated_by = $user_id;
        $CREATE->save();
 
        if ($CREATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Review Added Successfully'
            ]);
            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Review Creation Failed'
            ]);
            return redirect()->back();
        }
    }

    public function Edit($id = ''){
        $data = ManageReviewModel::where('status', '!=', 2)->where('sno', $id)->first();

        if($data){
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 404,
                'message' => 'Data Fetch Unsuccess!',
                'error_msg' => null,
                'data' => null
            ], 404);
        }
    }

    // public function Update(Request $request)
    // {

    //     $validator = Validator::make($request->all(), [
    //         'upd_gogle_review' => 'required|string'
    //     ]);

    //     if ($validator->fails()) {
    //         return response([
    //             'status' => 422,
    //             'message' => 'Incorret Input Field Format',
    //             'error_msg' => $validator->messages()->get('*'),
    //             'data' => null
    //         ], 422);
    //     }

    //     $sno = $request->edit_id;
    //     $user_id = $request->user()->user_id;


    //     $UPDATE = ManageReviewModel::where('sno', $sno)->where('status', '!=', 2)->first();
    //     $UPDATE->customer_id = $request->upd_customer_id;
    //     $UPDATE->ratings = $request->upd_student_ratings_hidden;
    //     $UPDATE->review = $request->upd_gogle_review;
    //     $UPDATE->review_image = isset($request['review_image_update']) ? 1 : 0;

    //     // Review Links
    //     $selected_links = $request->input('links');

    //     if (!empty($selected_links)) {
    //         $links_array = array_map(function ($link_id) {
    //             return ['link' => $link_id];
    //         }, $selected_links);

    //         $linksJson = json_encode($links_array);
    //     } else {
    //         $linksJson = json_encode([]);
    //     }

    //     $UPDATE->review_list = $linksJson;
    //     $UPDATE->updated_by = $user_id;
    //     $UPDATE->update();

    //     if ($UPDATE) {
    //         session()->flash('toastr', [
    //             'type' => 'success',
    //             'message' => 'Review Updated Successfully'
    //         ]);
    //         return redirect()->back();
    //     } else {
    //         session()->flash('toastr', [
    //             'type' => 'error',
    //             'message' => 'Review Updation Failed'
    //         ]);
    //         return redirect()->back();
    //     }
    // }
    
    public function Update(Request $request)
    {
 
        $validator = Validator::make($request->all(), [
            'upd_gogle_review' => 'required|string',
            'review_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048'
        ]);
 
        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorret Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 422);
        }
 
        $sno = $request->edit_id;
        $user_id = $request->user()->user_id;
 
 
        $UPDATE = ManageReviewModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $UPDATE->customer_id = $request->upd_customer_id;
        $UPDATE->ratings = $request->upd_student_ratings_hidden;
        $UPDATE->review = $request->upd_gogle_review;
       if ($request->hasFile('review_image_update')) {
 
            if ($UPDATE->review_image && file_exists(public_path($UPDATE->review_image))) {
                unlink(public_path($UPDATE->review_image));
            }
 
            $image = $request->file('review_image_update');
 
            $filename = time().'_'.uniqid().'.'.$image->getClientOriginalExtension();
 
            $image->move(public_path('uploads/review_images'), $filename);
 
            $UPDATE->review_image = 'uploads/review_images/'.$filename;
        }
 
        // Review Links
        $selected_links = $request->input('links');
 
        if (!empty($selected_links)) {
            $links_array = array_map(function ($link_id) {
                return ['link' => $link_id];
            }, $selected_links);
 
            $linksJson = json_encode($links_array);
        } else {
            $linksJson = json_encode([]);
        }
 
        $UPDATE->review_list = $linksJson;
        $UPDATE->updated_by = $user_id;
        $UPDATE->update();
 
        if ($UPDATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Review Updated Successfully'
            ]);
            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Review Updation Failed'
            ]);
            return redirect()->back();
        }
    }
}