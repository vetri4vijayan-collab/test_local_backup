<?php

namespace App\Http\Controllers\customer_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Models\StaffModel;
use App\Models\TypeCredentialModel;
use App\Models\ProposalModel;
use App\Models\PreProposalModel;
use App\Models\PassLockerModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;
use App\Models\ProposalCreChangeLogModel;
use App\Models\SmsTemplateModel;
use App\Mail\ETPLMail;
use App\Models\EmailTemplateModel;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\ManageProductVariableModel;
use App\Models\ManageProductVaiantModel;
use App\Models\TempProposalModel;
use App\Models\ProductModel;
use App\Models\CustomerFeedBackQuestionModel;
use App\Models\CustomerFeedbackResponseModel;
use App\Models\ManageJournalModel;
use DateTime;
use App\Models\CustomerReferalModel;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Models\CustomerFollowUpModel;
use App\Models\FollowupReasonModel;
use App\Models\ProposalCollectionChangeLogModel;
class ManageCustomer extends Controller
{


// public function index(Request $request)
// {
//   try{
//      $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $user_id = $request->user()->user_id;
//     $branch_id = $request->user()->branch_id;
//     $search_fill = $request->search_fill ?? '';
//     $cre_filter       = $request->cre_filter;
//     $product_filter   = $request->product_filter;
//     $initialPayDate   = $request->initialPayDate;
//     $status_filter    = $request->status_filter;
//     $collection_filter = $request->collection_filter;
//     // =========================================
//     // BASE QUERY
//     // =========================================
 
//     $baseQuery = DB::table('et_customer')
//         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//         ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
//         ->where('et_customer.status', '!=', 2)
//         ->leftJoin(
//         'et_customer_services',
//         'et_customer_services.proposal_id',
//         '=',
//         'et_proposal.sno'
//         )
//         ->leftJoin(
//             'et_payment',
//             'et_payment.proposal_id',
//             '=',
//             'et_proposal.sno'
//         )
//         ->leftJoin('et_staff as sales_staff', function ($join) {
//           $join->on('sales_staff.sno', '=', DB::raw("
//               CASE
//                   WHEN et_proposal.post_sale_check = 0
//                       THEN et_lead.created_by
//                   ELSE et_proposal.created_by
//               END
//           "));
//       })
//         ->where('et_lead.status', '!=', 2)
//         // ->where('et_proposal.nda_signed',1)
//         ->whereNotIn('et_proposal.proposal_status', [0, 2])
//         ->where('et_customer.branch_id', $branch_id);
 
//   if ($request->active_customer_only) {
 
//       $request->dashboard_filter = 'active_customer';
//       $isActiveCustomerPage = true;
//   }
//         // =========================================
//     // DASHBOARD STATS
//     // =========================================
 
//     $dashboard = [];
 
//     // Total Customers
//     $dashboard['total_customers'] = (clone $baseQuery)
//         ->distinct('et_customer.sno')
//         ->count('et_customer.sno');
 
 
//       // -----------------------------------------
//       // Active Customers
//       // customer_status = 0
//       // -----------------------------------------
 
//       $dashboard['active_customers'] = (clone $baseQuery)
//           ->whereIn('et_customer.status', [0,1])
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');
 
 
//       // -----------------------------------------
//       // Inactive Customers
//       // status = 1
//       // -----------------------------------------
 
//       $dashboard['inactive_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 1)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');
 
 
//       // -----------------------------------------
//       // Completed Customers
//       // status = 4
//       // -----------------------------------------
 
//       $dashboard['completed_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 4)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');
 
 
//       // -----------------------------------------
//       // Temporary Customers
//       // status = 5
//       // -----------------------------------------
 
//       $dashboard['temporary_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 5)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');
 
 
//       // -----------------------------------------
//       // Dropped Customers
//       // status = 6
//       // -----------------------------------------
 
//       $dashboard['dropped_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 6)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');
 
 
//       // -----------------------------------------
//       // Refund & Dropped Customers
//       // status = 7
//       // -----------------------------------------
 
//       $dashboard['refund_drop_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 7)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');
 
 
//     // Total Proposals
//     $dashboard['total_proposals'] = (clone $baseQuery)
//         ->distinct('et_proposal.sno')
//         ->count('et_proposal.sno');
 
//     // Completed Proposals
//     $dashboard['completed_proposals'] = (clone $baseQuery)
//         ->where('et_proposal.proposal_status', 5)
//         ->distinct('et_proposal.sno')
//         ->count('et_proposal.sno');
 
//     // Total Products
//     $dashboard['total_products'] = DB::table('et_customer_services')
//         ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//         ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->where('et_customer.branch_id', $branch_id)
//         ->count();
 
//     //Total Services
//     $dashboard['total_services'] = DB::table('et_customer_services')
//       ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//       ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//       ->where('et_customer.branch_id', $branch_id)
//       ->count('et_customer_services.sno');
   
//       //Collection executive unassigned
//       $dashboard['unassigned_ce'] =
//       DB::table('et_proposal')
//       ->where(function($q){
//           $q->whereNull('collection_id')
//             ->orWhere('collection_id',0);
//       })
//       ->count();
 
//       //NDA unsigned
//       $dashboard['nda_unsigned'] = (clone $baseQuery)
//         ->where('et_proposal.nda_signed',0)
//         ->distinct('et_proposal.sno')
//         ->count('et_proposal.sno');
 
//     //     // Total Revenue
//     // $dashboard['total_revenue'] = DB::table('et_proposal_pay_slot')
//     //     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
//     //     ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//     //     ->where('et_customer.branch_id', $branch_id)
//     //     ->where('et_proposal_pay_slot.status', 0)
//     //     ->sum('et_proposal_pay_slot.paidAmount');
 
 
//     // Permission filter
//     if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
 
//         $baseQuery->where('et_proposal.cre_id', $user_id);
 
//     } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
 
//         abort(403, 'Unauthorized');
//     }
     
//     // Search filter
//     if (!empty($search_fill)) {
 
//         $baseQuery->where(function ($query) use ($search_fill) {
//             $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//                 ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//                 ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
//                 ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
//         });
//     }
//       //Status filter
//     if ($status_filter !== null && $status_filter !== '') {
 
//     $baseQuery->where('et_customer.status', $status_filter);
 
//   }
 
//     // CRE Filter
//       if (!empty($cre_filter)) {
 
//           $baseQuery->where('et_proposal.cre_id', $cre_filter);
 
//       }
 
//       // Product Filter
//       if (!empty($product_filter)) {
 
//           $baseQuery->where('et_customer_services.product_id', $product_filter);
 
//       }
//   //filter by collection executives
//       if (!empty($collection_filter)) {
 
//         if ($collection_filter == 'unassigned') {
 
//             $baseQuery->where(function ($q) {
//                 $q->whereNull('et_proposal.collection_id')
//                   ->orWhere('et_proposal.collection_id', "");
//             });
 
//         } else {
 
//             $baseQuery->where(
//                 'et_proposal.collection_id',
//                 $collection_filter
//             );
 
//         }
 
//     }
//       // Initial Payment Date Filter
//       if (!empty($initialPayDate)) {
 
//         $baseQuery->whereExists(function ($sub) use ($initialPayDate) {
 
//             $sub->select(DB::raw(1))
//                 ->from('et_payment as ep1')
//                 ->whereColumn('ep1.proposal_id', 'et_proposal.sno')
//                 ->whereDate('ep1.transaction_date', $initialPayDate)
//                 ->whereRaw('ep1.sno = (
//                     SELECT MIN(ep2.sno)
//                     FROM et_payment ep2
//                     WHERE ep2.proposal_id = et_proposal.sno
//                 )');
 
//         });
 
//     }
 
//     $dashboardFilter = $request->dashboard_filter;
//     // dd($dashboardFilter);
//           if($dashboardFilter == 'active_customer'){
//               $baseQuery->whereIn('et_customer.status', [0,1])
//               ->whereNot('et_proposal.proposal_status', 5);
//           }
 
//           if($dashboardFilter == 'inactive_customer'){
//               $baseQuery->where('et_customer.status', 1)
//                         ->distinct('et_customer.sno');
//           }
 
//           if($dashboardFilter == 'completed_proposals'){
//               $baseQuery->where('et_proposal.proposal_status', 5)
//                       ->distinct('et_proposal.sno');
//           }
//           if ($dashboardFilter == 'proposal_customer') {
//             $baseQuery->whereExists(function ($q) {
//                 $q->select(DB::raw(1))
//                   ->from('et_proposal')
//                   ->whereColumn('et_proposal.customer_id', 'et_customer.sno');
//               });
//           }
//          if ($dashboardFilter == 'product_customer') {
//             $baseQuery->whereExists(function ($q) {
//                 $q->select(DB::raw(1))
//                   ->from('et_product')
//                   ->whereColumn('et_product.sno', 'et_customer_services.product_id');
//             });
//         }
//          if($dashboardFilter == 'nda_unsigned'){
//               $baseQuery->where('et_proposal.nda_signed', 0)
//                       ->distinct('et_proposal.sno');
//           }
//           // else{
//           //    $baseQuery->where('et_proposal.nda_signed', 1)
//           //             ->distinct('et_proposal.sno');
//           // }
//           // dd($baseQuery->get());
   
//     // =========================================
//     // CUSTOMER LIST
//     // =========================================
 
//  $customerIdsQuery = (clone $baseQuery)
//     ->select('et_customer.sno')
//     ->groupBy('et_customer.sno');
 
// $customersQuery = DB::table('et_customer')
//     ->whereIn('et_customer.sno', $customerIdsQuery)
//     ->select('et_customer.*');
 
//     $customers = $customersQuery
//         ->orderBy('et_customer.sno', 'desc')
//         ->paginate($perpage);
 
//     // Existing foreach logic
//     foreach ($customers as $customer) {
 
//          $proposal_ids = json_decode($customer->proposal_ids, true);
//       if (empty($proposal_ids) || !is_array($proposal_ids)) {
//         $customer->proposal_data = collect();
//         continue;
//       }
//   $proposal_data = DB::table('et_proposal')
//     ->select(
//         'et_proposal.*',
//         'et_lead.created_by as lead_created_by',
//         'et_customer.customer_id as customer_code',
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id'
//     )
 
//     ->join(
//         'et_customer',
//         'et_customer.sno',
//         '=',
//         'et_proposal.customer_id'
//     )
//     ->join(
//         'et_lead',
//         'et_lead.sno',
//         '=',
//         'et_customer.lead_id'
//     )
 
//     ->whereIn('et_proposal.sno', $proposal_ids)
//     ->where('et_proposal.status', '!=', 2)
//     ->orderBy('et_proposal.sno', 'desc')
//     ->get();
//       $proposal_currency = DB::table('et_proposal')
//         ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
//         ->whereIn('et_proposal.sno', $proposal_ids)
//         ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//         ->where('et_proposal.status', '!=', 2)
//         ->orderBy('et_proposal.sno', 'desc')
//         ->first();
//       $customer->currency_code = $proposal_currency->currency_code;
//       $customer->currency_symbol = $proposal_currency->currency_symbol;
//       $customer->currency_country_name = $proposal_currency->country_name;
//       $allCres = collect();
//       $allCollections = collect();
//       $allSales = collect();
//       $allJtls = collect();
//       $allJes = collect();
//       $allPcs = collect();
//       foreach ($proposal_data as $proposal) {
 
//     $salesStaffId = $proposal->post_sale_check == 0
//         ? $proposal->lead_created_by
//         : $proposal->created_by;
 
//     $SalesStaffData = DB::table('et_staff')
//         ->where('sno', $salesStaffId)
//         ->first();
 
//     $proposal->sales_staff_id = $salesStaffId;
//     $proposal->sales_staff_name = $SalesStaffData?->staff_name ?? '';
//     $proposal->sales_staff_image = $SalesStaffData?->staff_image ?? '';
//         $service_data = DB::table('et_customer_services')
//           ->where('proposal_id', $proposal->sno)
//           ->orderBy('sno', 'desc')
//           ->first();
         
//         $CreStaffData = DB::table('et_staff')
//             ->where('sno', $proposal->cre_id)
//             ->orderBy('sno', 'desc')
//             ->first();
//         $proposal->cre_name = $CreStaffData ? $CreStaffData->staff_name : '';
 
//         $CollectionStaffData = DB::table('et_staff')
//             ->where('sno', $proposal->collection_id)
//             ->first();
 
//         $proposal->collection_name = $CollectionStaffData ? $CollectionStaffData->staff_name : '';
//         $proposal->collection_image = $CollectionStaffData ? $CollectionStaffData->staff_image : '';
       
//         $proposal->customer_service_id = $service_data->sno;
//         if ($proposal->product_package == 2) {
//           // For package type proposals
//           $package = DB::table('et_package')
//             ->where('sno', $proposal->package_id)
//             ->where('status', '!=', 2)
//             ->orderBy('sno', 'desc')
//             ->first();
 
 
//           $package_slots = DB::table('et_proposal_pay_slot')
//             ->where('proposal_sno', $proposal->sno)
//             ->where('status', 0)
//             ->get();
//           $product_slots_paid = $package_slots->sum('paidAmount');
//           $proposal->package_name = $package->package_name ?? null;
//           $proposal->package_slot = $package_slots;
//           $proposal->product_slots_paid = $product_slots_paid;
//         } else {
//           // For product type proposals
//           $products = DB::table('et_customer_services')
 
//           ->select(
 
//               'et_product.product_name',
//               'et_product_category.product_category_name',
 
//               'et_customer_services.proposal_id',
//               'et_customer_services.cre_id',
//               'et_customer_services.pc_id',
//               'et_customer_services.variant_variable_ids',
 
//               'cre.staff_name as cre_name',
//               'cre.staff_image as cre_image',
 
//               'pc.staff_name as pc_name',
//               'pc.staff_image as pc_image',
//               'jtl.staff_name as jtl_name',
//               'jtl.staff_image as jtl_image',
//               'je.staff_name as je_name',
//               'je.staff_image as je_image',
//               'et_customer_services.jc_id',
//               'et_customer_services.jc_staff',
//           )
 
//           ->join(
//               'et_product',
//               'et_product.sno',
//               '=',
//               'et_customer_services.product_id'
//           )
 
//           ->join(
//               'et_product_category',
//               'et_product_category.sno',
//               '=',
//               'et_product.product_category_id'
//           )
 
//           ->leftJoin(
//               'et_staff as cre',
//               'cre.sno',
//               '=',
//               'et_customer_services.cre_id'
//           )
 
//           ->leftJoin(
//               'et_staff as pc',
//               'pc.sno',
//               '=',
//               'et_customer_services.pc_id'
//           )
//           ->leftJoin(
//               'et_staff as jtl',
//               'jtl.sno',
//               '=',
//               'et_customer_services.jc_id'
//           )
 
//           ->leftJoin(
//               'et_staff as je',
//               'je.sno',
//               '=',
//               'et_customer_services.jc_staff'
//           )
//           ->where(
//               'et_customer_services.proposal_id',
//               $proposal->sno
//           )
 
//           ->get();
//           $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
//             ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
//             ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
//             ->where('et_proposal_pay_slot.status', 0)
//             ->get();
//           $product_slots_paid = $product_slots->sum('paidAmount');
 
//           $proposal->product_slots_paid = $product_slots_paid;
//           $proposal->services = $products;
//           $proposal->product_slot = $product_slots;
//         }
//         $customer_dropdata = DB::table('et_drop_refund')->where('sno', $customer->drop_refund_id)->where('customer_id', $customer->sno)->where('sno', '>', 0)->first();
//         $customer->customer_dropdata = $customer_dropdata;
//         if (!empty($proposal->services)) {
 
//          if ($proposal->services && count($proposal->services) > 0) {
 
//         foreach ($proposal->services as $service) {
 
//             if (!empty($service->cre_id)) {
 
//                 $allCres->push((object)[
//                     'cre_id' => $service->cre_id,
//                     'cre_name' => $service->cre_name,
//                     'cre_image' => $service->cre_image,
//                 ]);
//             }
//             if (!empty($proposal->collection_id)) {
//                   $allCollections->push((object)[
//                       'collection_id'    => $proposal->collection_id,
//                       'collection_name'  => $proposal->collection_name,
//                       'collection_image' => $proposal->collection_image,
//                   ]);
//               }
//                 if (!empty($proposal->sales_staff_id)) {
//                   $allSales->push((object)[
//                       'sales_staff_id'    => $proposal->sales_staff_id,
//                       'sales_staff_name'  => $proposal->sales_staff_name,
//                       'sales_staff_image' => $proposal->sales_staff_image,
//                   ]);
//               }
//                 if(!empty($service->jc_id))
//               {
//                   $allJtls->push((object)[
//                       'jtl_id'=>$service->jc_id,
//                       'jtl_name'=>$service->jtl_name,
//                       'jtl_image'=>$service->jtl_image
//                   ]);
//               }
 
//               if(!empty($service->jc_staff))
//               {
//                   $allJes->push((object)[
//                       'je_id'=>$service->jc_staff,
//                       'je_name'=>$service->je_name,
//                       'je_image'=>$service->je_image
//                   ]);
//               }
//                 if(!empty($service->pc_id))
//               {
//                   $allPcs->push((object)[
//                       'pc_id'=>$service->pc_id,
//                       'pc_name'=>$service->pc_name,
//                       'pc_image'=>$service->pc_image
//                   ]);
//               }
//         }
//     }
//     }
//   }
//   $customer->cre_list = $allCres
//     ->unique('cre_id')
//     ->values();
//     $customer->collection_list = $allCollections
//     ->unique('collection_id')
//     ->values();
//      $customer->sales_list = $allSales
//     ->unique('sales_staff_id')
//     ->values();
//     $customer->jtl_list = $allJtls
//         ->unique('jtl_id')
//         ->values();
 
//     $customer->je_list = $allJes
//         ->unique('je_id')
//         ->values();
//     $customer->pc_list = $allPcs
//       ->unique('pc_id')
//       ->values();
//       $ServiceCompletedCount = DB::table('et_proposal')
//         ->where('et_proposal.customer_id', $customer->sno)
//         ->where('et_proposal.proposal_status', 5)
//         ->get();
 
//       $customer->completed_proposal = $ServiceCompletedCount;
//       $customer->proposal_data = $proposal_data;
//       $customer->cre_list = $allCres
//           ->unique('cre_id')
//           ->values();
//     }
//     $types = TypeCredentialModel::where('status', 0)->get();
 
//       $branch_id = $request->user()->branch_id;
 
//     // CRE List
//     $cre_list = DB::table('et_staff')
//         ->where('branch_id', $branch_id)
//         ->where('status', 0)
//         ->where('department_id', 6)
//         ->where('et_staff.role_id', 16)
//         ->get();
//   $collectionExecutives = DB::table('et_staff')
//     ->where('status', 0)
//     ->where('role_id', 42) // adjust to your system
//     ->orderBy('staff_name')
//     ->get();
//     // Product List
//     $product_list = DB::table('et_product')
//         // ->where('branch_id', $branch_id)
//         // ->where('status', 1)
//         ->get();
//      $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.role_id', 16)
//       ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
//       ->where('et_staff.branch_id', $branch_id);
//     $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
//       ->distinct() // Ensure unique rows
//       ->get();
//       // return $customers;
//     return view('content.customer_management.manage_customer.customer_list', [
//         'customers' => $customers,
//         'search_fill' => $search_fill,
//         'types' => $types,
//         'perpage' => $perpage,
//         'dashboard' => $dashboard,
//         'product_list' => $product_list,
//         'cre_list' => $cre_list,
//         'creStaffs' => $crestaff,
//         'collectionExecutives'=> $collectionExecutives,
//         'isActiveCustomerPage' => $isActiveCustomerPage ?? false
//     ]);
// }  catch (\Exception $e) {
//       return [
//         'status' => 400,
//         'error' => $e->getMessage(),
//       ];
//     }
// }

public function index(Request $request)
{
   try{
     $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $search_fill = $request->search_fill ?? '';
    $cre_filter       = $request->cre_filter;
    $product_filter   = $request->product_filter;
    $initialPayDate   = $request->initialPayDate;
    $status_filter    = $request->status_filter;
    $collection_filter = $request->collection_filter;
    // =========================================
    // BASE QUERY
    // =========================================
    $baseQuery = DB::table('et_customer')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
        ->where('et_customer.status', '!=', 2)
        ->leftJoin(
        'et_customer_services',
        'et_customer_services.proposal_id',
        '=',
        'et_proposal.sno'
        )
        ->leftJoin(
            'et_payment',
            'et_payment.proposal_id',
            '=',
            'et_proposal.sno'
        )
        ->leftJoin('et_staff as sales_staff', function ($join) {
          $join->on('sales_staff.sno', '=', DB::raw("
              CASE
                  WHEN et_proposal.post_sale_check = 0
                      THEN et_lead.created_by
                  ELSE et_proposal.created_by
              END
          "));
      })
        ->where('et_lead.status', '!=', 2)
        // ->where('et_proposal.nda_signed',1)
        ->whereNotIn('et_proposal.proposal_status', [0, 2])
        ->where('et_customer.branch_id', $branch_id);
  if ($request->active_customer_only) {
 
      $request->dashboard_filter = 'active_customer';
      $isActiveCustomerPage = true;
  }
        // =========================================
    // DASHBOARD STATS
    // =========================================
    $dashboard = [];
    // Total Customers
    $dashboard['total_customers'] = (clone $baseQuery)
        ->distinct('et_customer.sno')
        ->count('et_customer.sno');

      // -----------------------------------------
      // Active Customers
      // customer_status = 0
      // -----------------------------------------
      $dashboard['active_customers'] = (clone $baseQuery)
          ->whereIn('et_customer.status', [0,1])
          ->distinct('et_customer.sno')
          ->count('et_customer.sno');

      // -----------------------------------------
      // Inactive Customers
      // status = 1
      // -----------------------------------------
      $dashboard['inactive_customers'] = (clone $baseQuery)
          ->where('et_customer.status', 1)
          ->distinct('et_customer.sno')
          ->count('et_customer.sno');

      // -----------------------------------------
      // Completed Customers
      // status = 4
      // -----------------------------------------
      $dashboard['completed_customers'] = (clone $baseQuery)
          ->where('et_customer.status', 4)
          ->distinct('et_customer.sno')
          ->count('et_customer.sno');

      // -----------------------------------------
      // Temporary Customers
      // status = 5
      // -----------------------------------------
      $dashboard['temporary_customers'] = (clone $baseQuery)
          ->where('et_customer.status', 5)
          ->distinct('et_customer.sno')
          ->count('et_customer.sno');

      // -----------------------------------------
      // Dropped Customers
      // status = 6
      // -----------------------------------------
      $dashboard['dropped_customers'] = (clone $baseQuery)
          ->where('et_customer.status', 6)
          ->distinct('et_customer.sno')
          ->count('et_customer.sno');

      // -----------------------------------------
      // Refund & Dropped Customers
      // status = 7
      // -----------------------------------------
      $dashboard['refund_drop_customers'] = (clone $baseQuery)
          ->where('et_customer.status', 7)
          ->distinct('et_customer.sno')
          ->count('et_customer.sno');

    // Total Proposals
    $dashboard['total_proposals'] = (clone $baseQuery)
        ->distinct('et_proposal.sno')
        ->count('et_proposal.sno');
    // Completed Proposals
    $dashboard['completed_proposals'] = (clone $baseQuery)
        ->where('et_proposal.proposal_status', 5)
        ->distinct('et_proposal.sno')
        ->count('et_proposal.sno');
    // Total Products
    $dashboard['total_products'] = DB::table('et_customer_services')
        ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
        ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->where('et_customer.branch_id', $branch_id)
        ->count();
    //Total Services
    $dashboard['total_services'] = DB::table('et_customer_services')
      ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
      ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
      ->where('et_customer.branch_id', $branch_id)
      ->count('et_customer_services.sno');
      //Collection executive unassigned
      $dashboard['unassigned_ce'] =
      DB::table('et_proposal')
      ->where(function($q){
          $q->whereNull('collection_id')
            ->orWhere('collection_id',0);
      })
      ->count();
 
      //NDA unsigned
       $dashboard['nda_unsigned'] = (clone $baseQuery)
        ->where('et_proposal.nda_signed',0)
        ->distinct('et_proposal.sno')
        ->count('et_proposal.sno');
    //     // Total Revenue
    // $dashboard['total_revenue'] = DB::table('et_proposal_pay_slot')
    //     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
    //     ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
    //     ->where('et_customer.branch_id', $branch_id)
    //     ->where('et_proposal_pay_slot.status', 0)
    //     ->sum('et_proposal_pay_slot.paidAmount');

    // Permission filter
    if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
        $baseQuery->where('et_proposal.cre_id', $user_id);
    } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
        abort(403, 'Unauthorized');
    }
    // Search filter
    if (!empty($search_fill)) {
        $baseQuery->where(function ($query) use ($search_fill) {
            $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
        });
    }
      //Status filter
    if ($status_filter !== null && $status_filter !== '') {
 
    $baseQuery->where('et_customer.status', $status_filter);
 
  }
    // CRE Filter
      if (!empty($cre_filter)) {
          $baseQuery->where('et_proposal.cre_id', $cre_filter);
      }
      // Product Filter
      if (!empty($product_filter)) {
          $baseQuery->where('et_customer_services.product_id', $product_filter);
      }
  //filter by collection executives
      if (!empty($collection_filter)) {
 
        if ($collection_filter == 'unassigned') {
 
            $baseQuery->where(function ($q) {
                $q->whereNull('et_proposal.collection_id')
                  ->orWhere('et_proposal.collection_id', "");
            });
 
        } else {
 
            $baseQuery->where(
                'et_proposal.collection_id',
                $collection_filter
            );
 
        }
 
    }
      // Initial Payment Date Filter
      if (!empty($initialPayDate)) {
        $baseQuery->whereExists(function ($sub) use ($initialPayDate) {
            $sub->select(DB::raw(1))
                ->from('et_payment as ep1')
                ->whereColumn('ep1.proposal_id', 'et_proposal.sno')
                ->whereDate('ep1.transaction_date', $initialPayDate)
                ->whereRaw('ep1.sno = (
                    SELECT MIN(ep2.sno)
                    FROM et_payment ep2
                    WHERE ep2.proposal_id = et_proposal.sno
                )');
        });
    }
 
    $dashboardFilter = $request->dashboard_filter;
    // dd($dashboardFilter);
          if($dashboardFilter == 'active_customer'){
              $baseQuery->whereIn('et_customer.status', [0,1])
              ->whereNot('et_proposal.proposal_status', 5);
          }
 
          if($dashboardFilter == 'inactive_customer'){
              $baseQuery->where('et_customer.status', 1) 
                        ->distinct('et_customer.sno');
          }
 
          if($dashboardFilter == 'completed_proposals'){
              $baseQuery->where('et_proposal.proposal_status', 5)
                      ->distinct('et_proposal.sno');
          }
          if ($dashboardFilter == 'proposal_customer') {
            $baseQuery->whereExists(function ($q) {
                $q->select(DB::raw(1))
                  ->from('et_proposal')
                  ->whereColumn('et_proposal.customer_id', 'et_customer.sno');
              });
          }
         if ($dashboardFilter == 'product_customer') {
            $baseQuery->whereExists(function ($q) {
                $q->select(DB::raw(1))
                  ->from('et_product')
                  ->whereColumn('et_product.sno', 'et_customer_services.product_id');
            });
        }
         if($dashboardFilter == 'nda_unsigned'){
              $baseQuery->where('et_proposal.nda_signed', 0)
                      ->distinct('et_proposal.sno');
          }
          // else{
          //    $baseQuery->where('et_proposal.nda_signed', 1)
          //             ->distinct('et_proposal.sno');
          // }
          // dd($baseQuery->get());
    // =========================================
    // CUSTOMER LIST
    // =========================================
$customerIdsQuery = (clone $baseQuery)
    ->select('et_customer.sno')
    ->groupBy('et_customer.sno');
 
$customersQuery = DB::table('et_customer')
    ->whereIn('et_customer.sno', $customerIdsQuery)
    ->select('et_customer.*');
    $customers = $customersQuery
        ->orderBy('et_customer.sno', 'desc')
        ->paginate($perpage);
    // Existing foreach logic
    foreach ($customers as $customer) {
         $proposal_ids = json_decode($customer->proposal_ids, true);
      if (empty($proposal_ids) || !is_array($proposal_ids)) {
        $customer->proposal_data = collect();
        continue;
      }
 
        $follow_up=DB::table('et_customer_follow_up')->select('et_customer_follow_up.*')
      ->leftjoin('et_customer', 'et_customer.sno', '=', 'et_customer_follow_up.customer_id')
      ->where('et_customer_follow_up.customer_id', $customer->sno)->orderBy('et_customer_follow_up.sno','desc')->first();

      $customer->appointment_status = $follow_up->status ?? "0";
      $chk1day         = false;
      $createdAt       = Carbon::parse($customer->created_at);
      $currentDateTime = Carbon::now();
      $customer->total_follow_up=CustomerFollowUpModel::where('customer_id', $customer->sno)->count();
    $before48Hours   = Carbon::now()->subHours(48);
      $usersWithPendingAppointments = DB::table('et_customer_follow_up')
      ->join('et_customer', 'et_customer.sno', '=', 'et_customer_follow_up.customer_id')
        ->whereIn('et_customer.status', [0])
        ->where('et_customer_follow_up.status', 1)
        // ->where('et_lead.is_dc', 1)
        ->where('et_customer_follow_up.branch_id', $branch_id)
        ->where('et_customer_follow_up.appointment_date', '<=', $before48Hours)
        ->distinct()
        ->pluck('et_customer_follow_up.created_by')
        ->toArray();
 
      if (in_array($customer->created_by, $usersWithPendingAppointments)) {
 
        $customer->not_closed = 0;
      } else {
        $customer->not_closed = 0;
      }
   $proposal_data = DB::table('et_proposal')
    ->select(
        'et_proposal.*',
        'et_lead.created_by as lead_created_by',
        'et_customer.customer_id as customer_code',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id'
    )
    ->join(
        'et_customer',
        'et_customer.sno',
        '=',
        'et_proposal.customer_id'
    )
    ->join(
        'et_lead',
        'et_lead.sno',
        '=',
        'et_customer.lead_id'
    )
    ->whereIn('et_proposal.sno', $proposal_ids)
    ->where('et_proposal.status', '!=', 2)
    ->orderBy('et_proposal.sno', 'desc')
    ->get();
      $proposal_currency = DB::table('et_proposal')
        ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
        ->whereIn('et_proposal.sno', $proposal_ids)
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->where('et_proposal.status', '!=', 2)
        ->orderBy('et_proposal.sno', 'desc')
        ->first();
      $customer->currency_code = $proposal_currency->currency_code;
      $customer->currency_symbol = $proposal_currency->currency_symbol;
      $customer->currency_country_name = $proposal_currency->country_name;
      $allCres = collect();
      $allCollections = collect();
      $allSales = collect();
      $allJtls = collect();
      $allJes = collect();
      $allPcs = collect();
      foreach ($proposal_data as $proposal) {
 
    $salesStaffId = $proposal->post_sale_check == 0
        ? $proposal->lead_created_by
        : $proposal->created_by;
 
    $SalesStaffData = DB::table('et_staff')
        ->where('sno', $salesStaffId)
        ->first();
 
    $proposal->sales_staff_id = $salesStaffId;
    $proposal->sales_staff_name = $SalesStaffData?->staff_name ?? '';
    $proposal->sales_staff_image = $SalesStaffData?->staff_image ?? '';
        $service_data = DB::table('et_customer_services')
          ->where('proposal_id', $proposal->sno)
          ->orderBy('sno', 'desc')
          ->first();
        $CreStaffData = DB::table('et_staff')
            ->where('sno', $proposal->cre_id)
            ->orderBy('sno', 'desc')
            ->first();
        $proposal->cre_name = $CreStaffData ? $CreStaffData->staff_name : '';
 
        $CollectionStaffData = DB::table('et_staff')
            ->where('sno', $proposal->collection_id)
            ->first();
 
        $proposal->collection_name = $CollectionStaffData ? $CollectionStaffData->staff_name : '';
        $proposal->collection_image = $CollectionStaffData ? $CollectionStaffData->staff_image : '';
        $proposal->customer_service_id = $service_data->sno;
        if ($proposal->product_package == 2) {
          // For package type proposals
          $package = DB::table('et_package')
            ->where('sno', $proposal->package_id)
            ->where('status', '!=', 2)
            ->orderBy('sno', 'desc')
            ->first();

          $package_slots = DB::table('et_proposal_pay_slot')
            ->where('proposal_sno', $proposal->sno)
            ->where('status', 0)
            ->get();
          $product_slots_paid = $package_slots->sum('paidAmount');
          $proposal->package_name = $package->package_name ?? null;
          $proposal->package_slot = $package_slots;
          $proposal->product_slots_paid = $product_slots_paid;
        } else {
          // For product type proposals
          $products = DB::table('et_customer_services')
          ->select(
              'et_product.product_name',
              'et_product_category.product_category_name',
              'et_customer_services.proposal_id',
              'et_customer_services.cre_id',
              'et_customer_services.pc_id',
              'et_customer_services.variant_variable_ids',
              'cre.staff_name as cre_name',
              'cre.staff_image as cre_image',
              'pc.staff_name as pc_name',
              'pc.staff_image as pc_image',
              'jtl.staff_name as jtl_name',
              'jtl.staff_image as jtl_image',
              'je.staff_name as je_name',
              'je.staff_image as je_image',
              'et_customer_services.jc_id',
              'et_customer_services.jc_staff',
          )
          ->join(
              'et_product',
              'et_product.sno',
              '=',
              'et_customer_services.product_id'
          )
          ->join(
              'et_product_category',
              'et_product_category.sno',
              '=',
              'et_product.product_category_id'
          )
          ->leftJoin(
              'et_staff as cre',
              'cre.sno',
              '=',
              'et_customer_services.cre_id'
          )
          ->leftJoin(
              'et_staff as pc',
              'pc.sno',
              '=',
              'et_customer_services.pc_id'
          )
          ->leftJoin(
              'et_staff as jtl',
              'jtl.sno',
              '=',
              'et_customer_services.jc_id'
          )
 
          ->leftJoin(
              'et_staff as je',
              'je.sno',
              '=',
              'et_customer_services.jc_staff'
          )
          ->where(
              'et_customer_services.proposal_id',
              $proposal->sno
          )
          ->get();
          $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
            ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->where('et_proposal_pay_slot.status', 0)
            ->get();
          $product_slots_paid = $product_slots->sum('paidAmount');
          $proposal->product_slots_paid = $product_slots_paid;
          $proposal->services = $products;
          $proposal->product_slot = $product_slots;
        }
        $customer_dropdata = DB::table('et_drop_refund')->where('sno', $customer->drop_refund_id)->where('customer_id', $customer->sno)->where('sno', '>', 0)->first();
        $customer->customer_dropdata = $customer_dropdata;
        if (!empty($proposal->services)) {
         if ($proposal->services && count($proposal->services) > 0) {
        foreach ($proposal->services as $service) {
            if (!empty($service->cre_id)) {
                $allCres->push((object)[
                    'cre_id' => $service->cre_id,
                    'cre_name' => $service->cre_name,
                    'cre_image' => $service->cre_image,
                ]);
            }
            if (!empty($proposal->collection_id)) {
                  $allCollections->push((object)[
                      'collection_id'    => $proposal->collection_id,
                      'collection_name'  => $proposal->collection_name,
                      'collection_image' => $proposal->collection_image,
                  ]);
              }
                if (!empty($proposal->sales_staff_id)) {
                  $allSales->push((object)[
                      'sales_staff_id'    => $proposal->sales_staff_id,
                      'sales_staff_name'  => $proposal->sales_staff_name,
                      'sales_staff_image' => $proposal->sales_staff_image,
                  ]);
              }
                if(!empty($service->jc_id))
              {
                  $allJtls->push((object)[
                      'jtl_id'=>$service->jc_id,
                      'jtl_name'=>$service->jtl_name,
                      'jtl_image'=>$service->jtl_image
                  ]);
              }
 
              if(!empty($service->jc_staff))
              {
                  $allJes->push((object)[
                      'je_id'=>$service->jc_staff,
                      'je_name'=>$service->je_name,
                      'je_image'=>$service->je_image
                  ]);
              }
                if(!empty($service->pc_id))
              {
                  $allPcs->push((object)[
                      'pc_id'=>$service->pc_id,
                      'pc_name'=>$service->pc_name,
                      'pc_image'=>$service->pc_image
                  ]);
              }
        }
    }
    }
  }
  $customer->cre_list = $allCres
    ->unique('cre_id')
    ->values();
    $customer->collection_list = $allCollections
    ->unique('collection_id')
    ->values();
     $customer->sales_list = $allSales
    ->unique('sales_staff_id')
    ->values();
    $customer->jtl_list = $allJtls
        ->unique('jtl_id')
        ->values();
 
    $customer->je_list = $allJes
        ->unique('je_id')
        ->values();
    $customer->pc_list = $allPcs
      ->unique('pc_id')
      ->values();
      $ServiceCompletedCount = DB::table('et_proposal')
        ->where('et_proposal.customer_id', $customer->sno)
        ->where('et_proposal.proposal_status', 5)
        ->get();
      $customer->completed_proposal = $ServiceCompletedCount;
      $customer->proposal_data = $proposal_data;
      $customer->cre_list = $allCres
          ->unique('cre_id')
          ->values();
    }
    $types = TypeCredentialModel::where('status', 0)->get();
 
      $branch_id = $request->user()->branch_id;
    // CRE List
    $cre_list = DB::table('et_staff')
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->where('department_id', 6)
        ->where('et_staff.role_id', 16)
        ->get();
  $collectionExecutives = DB::table('et_staff')
    ->where('status', 0)
    ->where('role_id', 42) // adjust to your system
    ->orderBy('staff_name')
    ->get();
    // Product List
    $product_list = DB::table('et_product')
        // ->where('branch_id', $branch_id)
        // ->where('status', 1)
        ->get();
     $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.role_id', 16)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();
      // return $customers;
    return view('content.customer_management.manage_customer.customer_list', [
        'customers' => $customers,
        'search_fill' => $search_fill,
        'types' => $types,
        'perpage' => $perpage,
        'dashboard' => $dashboard,
        'product_list' => $product_list,
        'cre_list' => $cre_list,
        'creStaffs' => $crestaff,
        'collectionExecutives'=> $collectionExecutives,
        'isActiveCustomerPage' => $isActiveCustomerPage ?? false
    ]);
}  catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
}

// public function index(Request $request)
// {
//   try{
//      $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $user_id = $request->user()->user_id;
//     $branch_id = $request->user()->branch_id;
//     $search_fill = $request->search_fill ?? '';
//     $cre_filter       = $request->cre_filter;
//     $product_filter   = $request->product_filter;
//     $initialPayDate   = $request->initialPayDate;
//     $status_filter    = $request->status_filter;
//     $collection_filter = $request->collection_filter;
//     // =========================================
//     // BASE QUERY
//     // =========================================
//     $baseQuery = DB::table('et_customer')
//         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//         ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
//         ->where('et_customer.status', '!=', 2)
//           ->leftJoin(
//         'et_customer_services',
//         'et_customer_services.proposal_id',
//         '=',
//         'et_proposal.sno'
//     )
//     ->leftJoin(
//     'et_payment',
//     'et_payment.proposal_id',
//     '=',
//     'et_proposal.sno'
// )
//         ->where('et_lead.status', '!=', 2)
//         // ->where('et_proposal.nda_signed',1)
//         ->whereNotIn('et_proposal.proposal_status', [0, 2])
//         ->where('et_customer.branch_id', $branch_id);
//   if ($request->active_customer_only) {
 
//       $request->dashboard_filter = 'active_customer';
//       $isActiveCustomerPage = true;
//   }
//         // =========================================
//     // DASHBOARD STATS
//     // =========================================
//     $dashboard = [];
//     // Total Customers
//     $dashboard['total_customers'] = (clone $baseQuery)
//         ->distinct('et_customer.sno')
//         ->count('et_customer.sno');

//       // -----------------------------------------
//       // Active Customers
//       // customer_status = 0
//       // -----------------------------------------
//       $dashboard['active_customers'] = (clone $baseQuery)
//           ->whereIn('et_customer.status', [0,1])
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');

//       // -----------------------------------------
//       // Inactive Customers
//       // status = 1
//       // -----------------------------------------
//       $dashboard['inactive_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 1)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');

//       // -----------------------------------------
//       // Completed Customers
//       // status = 4
//       // -----------------------------------------
//       $dashboard['completed_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 4)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');

//       // -----------------------------------------
//       // Temporary Customers
//       // status = 5
//       // -----------------------------------------
//       $dashboard['temporary_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 5)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');

//       // -----------------------------------------
//       // Dropped Customers
//       // status = 6
//       // -----------------------------------------
//       $dashboard['dropped_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 6)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');

//       // -----------------------------------------
//       // Refund & Dropped Customers
//       // status = 7
//       // -----------------------------------------
//       $dashboard['refund_drop_customers'] = (clone $baseQuery)
//           ->where('et_customer.status', 7)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');

//     // Total Proposals
//     $dashboard['total_proposals'] = (clone $baseQuery)
//         ->distinct('et_proposal.sno')
//         ->count('et_proposal.sno');
//     // Completed Proposals
//     $dashboard['completed_proposals'] = (clone $baseQuery)
//         ->where('et_proposal.proposal_status', 5)
//         ->distinct('et_proposal.sno')
//         ->count('et_proposal.sno');
//     // Total Products
//     $dashboard['total_products'] = DB::table('et_customer_services')
//         ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//         ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->where('et_customer.branch_id', $branch_id)
//         ->count();
//     //Total Services
//     $dashboard['total_services'] = DB::table('et_customer_services')
//       ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//       ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//       ->where('et_customer.branch_id', $branch_id)
//       ->count('et_customer_services.sno');
//       //Collection executive unassigned
//       $dashboard['unassigned_ce'] =
//       DB::table('et_proposal')
//       ->where(function($q){
//           $q->whereNull('collection_id')
//             ->orWhere('collection_id',0);
//       })
//       ->count();
//     //     // Total Revenue
//     // $dashboard['total_revenue'] = DB::table('et_proposal_pay_slot')
//     //     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
//     //     ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//     //     ->where('et_customer.branch_id', $branch_id)
//     //     ->where('et_proposal_pay_slot.status', 0)
//     //     ->sum('et_proposal_pay_slot.paidAmount');
// $isActiveCustomerPage = $request->active_customer_only ?? false;
//     // Permission filter
//   $menuName = $isActiveCustomerPage
//     ? 'Active Customer'
//     : 'Manage Customer'
 
// // Self permission
// if (auth()->user()->hasPermissionradio(
//     'Customer Management',
//     $menuName,
//     'view_self_cus'
// )) {
 
//     $baseQuery->where('et_proposal.cre_id', $user_id);
 
// // Global permission
// } elseif (!auth()->user()->hasPermissionradio(
//     'Customer Management',
//     $menuName,
//     'global_cus'
// )) {
 
//     abort(403, 'Unauthorized');
// }
//     // Search filter
//     if (!empty($search_fill)) {
//         $baseQuery->where(function ($query) use ($search_fill) {
//             $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//                 ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//                 ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
//                 ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
//         });
//     }
//       //Status filter
//     if ($status_filter !== null && $status_filter !== '') {
 
//     $baseQuery->where('et_customer.status', $status_filter);
 
//   }
//     // CRE Filter
//       if (!empty($cre_filter)) {
//           $baseQuery->where('et_proposal.cre_id', $cre_filter);
//       }
//       // Product Filter
//       if (!empty($product_filter)) {
//           $baseQuery->where('et_customer_services.product_id', $product_filter);
//       }
//   //filter by collection executives
//       if (!empty($collection_filter)) {
 
//         if ($collection_filter == 'unassigned') {
 
//             $baseQuery->where(function ($q) {
//                 $q->whereNull('et_proposal.collection_id')
//                   ->orWhere('et_proposal.collection_id', "");
//             });
 
//         } else {
 
//             $baseQuery->where(
//                 'et_proposal.collection_id',
//                 $collection_filter
//             );
 
//         }
 
//     }
//       // Initial Payment Date Filter
//       if (!empty($initialPayDate)) {
//         $baseQuery->whereExists(function ($sub) use ($initialPayDate) {
//             $sub->select(DB::raw(1))
//                 ->from('et_payment as ep1')
//                 ->whereColumn('ep1.proposal_id', 'et_proposal.sno')
//                 ->whereDate('ep1.transaction_date', $initialPayDate)
//                 ->whereRaw('ep1.sno = (
//                     SELECT MIN(ep2.sno)
//                     FROM et_payment ep2
//                     WHERE ep2.proposal_id = et_proposal.sno
//                 )');
//         });
//     }
 
//     $dashboardFilter = $request->dashboard_filter;
//     // dd($dashboardFilter);
//           if($dashboardFilter == 'active_customer'){
//               $baseQuery->whereIn('et_customer.status', [0,1])
//               ->whereNot('et_proposal.proposal_status', 5);
//           }
 
//           if($dashboardFilter == 'inactive_customer'){
//               $baseQuery->where('et_customer.status', 1) 
//                         ->distinct('et_customer.sno');
//           }
 
//           if($dashboardFilter == 'completed_proposals'){
//               $baseQuery->where('et_proposal.proposal_status', 5)
//                       ->distinct('et_proposal.sno');
//           }
//           if ($dashboardFilter == 'proposal_customer') {
//             $baseQuery->whereExists(function ($q) {
//                 $q->select(DB::raw(1))
//                   ->from('et_proposal')
//                   ->whereColumn('et_proposal.customer_id', 'et_customer.sno');
//               });
//           }
//          if ($dashboardFilter == 'product_customer') {
//             $baseQuery->whereExists(function ($q) {
//                 $q->select(DB::raw(1))
//                   ->from('et_product')
//                   ->whereColumn('et_product.sno', 'et_customer_services.product_id');
//             });
//         }
//           // dd($baseQuery->get());
//     // =========================================
//     // CUSTOMER LIST
//     // =========================================
//     $customersQuery = (clone $baseQuery)
//         ->select('et_customer.*')
//         ->distinct('et_customer.sno');
//     $customers = $customersQuery
//         ->orderBy('et_customer.sno', 'desc')
//         ->paginate($perpage);
//     // Existing foreach logic
//     foreach ($customers as $customer) {
//          $proposal_ids = json_decode($customer->proposal_ids, true);
//       if (empty($proposal_ids) || !is_array($proposal_ids)) {
//         $customer->proposal_data = collect();
//         continue;
//       }
//   $proposal_data = DB::table('et_proposal')
//     ->select(
//         'et_proposal.*',
//         'et_customer.customer_id as customer_code',
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id'
//     )
//     ->join(
//         'et_customer',
//         'et_customer.sno',
//         '=',
//         'et_proposal.customer_id'
//     )
//     ->whereIn('et_proposal.sno', $proposal_ids)
//     ->where('et_proposal.status', '!=', 2)
//     ->orderBy('et_proposal.sno', 'desc')
//     ->get();
//       $proposal_currency = DB::table('et_proposal')
//         ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
//         ->whereIn('et_proposal.sno', $proposal_ids)
//         ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//         ->where('et_proposal.status', '!=', 2)
//         ->orderBy('et_proposal.sno', 'desc')
//         ->first();
//       $customer->currency_code = $proposal_currency->currency_code;
//       $customer->currency_symbol = $proposal_currency->currency_symbol;
//       $customer->currency_country_name = $proposal_currency->country_name;
//       $allCres = collect();
//       $allCollections = collect();
//       $allJtls = collect();
//       $allJes = collect();
//       $allPcs = collect();
//       foreach ($proposal_data as $proposal) {
//         $service_data = DB::table('et_customer_services')
//           ->where('proposal_id', $proposal->sno)
//           ->orderBy('sno', 'desc')
//           ->first();
//         $CreStaffData = DB::table('et_staff')
//             ->where('sno', $proposal->cre_id)
//             ->orderBy('sno', 'desc')
//             ->first();
//         $proposal->cre_name = $CreStaffData ? $CreStaffData->staff_name : '';
 
//         $CollectionStaffData = DB::table('et_staff')
//             ->where('sno', $proposal->collection_id)
//             ->first();
 
//         $proposal->collection_name = $CollectionStaffData ? $CollectionStaffData->staff_name : '';
//         $proposal->collection_image = $CollectionStaffData ? $CollectionStaffData->staff_image : '';
//         $proposal->customer_service_id = $service_data->sno;
//         if ($proposal->product_package == 2) {
//           // For package type proposals
//           $package = DB::table('et_package')
//             ->where('sno', $proposal->package_id)
//             ->where('status', '!=', 2)
//             ->orderBy('sno', 'desc')
//             ->first();

//           $package_slots = DB::table('et_proposal_pay_slot')
//             ->where('proposal_sno', $proposal->sno)
//             ->where('status', 0)
//             ->get();
//           $product_slots_paid = $package_slots->sum('paidAmount');
//           $proposal->package_name = $package->package_name ?? null;
//           $proposal->package_slot = $package_slots;
//           $proposal->product_slots_paid = $product_slots_paid;
//         } else {
//           // For product type proposals
//           $products = DB::table('et_customer_services')
//           ->select(
//               'et_product.product_name',
//               'et_product_category.product_category_name',
//               'et_customer_services.proposal_id',
//               'et_customer_services.cre_id',
//               'et_customer_services.pc_id',
//               'cre.staff_name as cre_name',
//               'cre.staff_image as cre_image',
//               'pc.staff_name as pc_name',
//               'pc.staff_image as pc_image',
//               'jtl.staff_name as jtl_name',
//               'jtl.staff_image as jtl_image',
//               'je.staff_name as je_name',
//               'je.staff_image as je_image',
//               'et_customer_services.jc_id',
//               'et_customer_services.jc_staff',
//           )
//           ->join(
//               'et_product',
//               'et_product.sno',
//               '=',
//               'et_customer_services.product_id'
//           )
//           ->join(
//               'et_product_category',
//               'et_product_category.sno',
//               '=',
//               'et_product.product_category_id'
//           )
//           ->leftJoin(
//               'et_staff as cre',
//               'cre.sno',
//               '=',
//               'et_customer_services.cre_id'
//           )
//           ->leftJoin(
//               'et_staff as pc',
//               'pc.sno',
//               '=',
//               'et_customer_services.pc_id'
//           )
//           ->leftJoin(
//               'et_staff as jtl',
//               'jtl.sno',
//               '=',
//               'et_customer_services.jc_id'
//           )
 
//           ->leftJoin(
//               'et_staff as je',
//               'je.sno',
//               '=',
//               'et_customer_services.jc_staff'
//           )
//           ->where(
//               'et_customer_services.proposal_id',
//               $proposal->sno
//           )
//           ->get();
//           $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
//             ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
//             ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
//             ->where('et_proposal_pay_slot.status', 0)
//             ->get();
//           $product_slots_paid = $product_slots->sum('paidAmount');
//           $proposal->product_slots_paid = $product_slots_paid;
//           $proposal->services = $products;
//           $proposal->product_slot = $product_slots;
//         }
//         $customer_dropdata = DB::table('et_drop_refund')->where('sno', $customer->drop_refund_id)->where('customer_id', $customer->sno)->where('sno', '>', 0)->first();
//         $customer->customer_dropdata = $customer_dropdata;
//         if (!empty($proposal->services)) {
//          if ($proposal->services && count($proposal->services) > 0) {
//         foreach ($proposal->services as $service) {
//             if (!empty($service->cre_id)) {
//                 $allCres->push((object)[
//                     'cre_id' => $service->cre_id,
//                     'cre_name' => $service->cre_name,
//                     'cre_image' => $service->cre_image,
//                 ]);
//             }
//             if (!empty($proposal->collection_id)) {
//                   $allCollections->push((object)[
//                       'collection_id'    => $proposal->collection_id,
//                       'collection_name'  => $proposal->collection_name,
//                       'collection_image' => $proposal->collection_image,
//                   ]);
//               }
//                 if(!empty($service->jc_id))
//               {
//                   $allJtls->push((object)[
//                       'jtl_id'=>$service->jc_id,
//                       'jtl_name'=>$service->jtl_name,
//                       'jtl_image'=>$service->jtl_image
//                   ]);
//               }
 
//               if(!empty($service->jc_staff))
//               {
//                   $allJes->push((object)[
//                       'je_id'=>$service->jc_staff,
//                       'je_name'=>$service->je_name,
//                       'je_image'=>$service->je_image
//                   ]);
//               }
//                 if(!empty($service->pc_id))
//               {
//                   $allPcs->push((object)[
//                       'pc_id'=>$service->pc_id,
//                       'pc_name'=>$service->pc_name,
//                       'pc_image'=>$service->pc_image
//                   ]);
//               }
//         }
//     }
//     }
//   }
//   $customer->cre_list = $allCres
//     ->unique('cre_id')
//     ->values();
//     $customer->collection_list = $allCollections
//     ->unique('collection_id')
//     ->values();
//     $customer->jtl_list = $allJtls
//         ->unique('jtl_id')
//         ->values();
 
//     $customer->je_list = $allJes
//         ->unique('je_id')
//         ->values();
//     $customer->pc_list = $allPcs
//       ->unique('pc_id')
//       ->values();
//       $ServiceCompletedCount = DB::table('et_proposal')
//         ->where('et_proposal.customer_id', $customer->sno)
//         ->where('et_proposal.proposal_status', 5)
//         ->get();
//       $customer->completed_proposal = $ServiceCompletedCount;
//       $customer->proposal_data = $proposal_data;
//       $customer->cre_list = $allCres
//           ->unique('cre_id')
//           ->values();
//     }
//     $types = TypeCredentialModel::where('status', 0)->get();
 
//       $branch_id = $request->user()->branch_id;
//     // CRE List
//     $cre_list = DB::table('et_staff')
//         ->where('branch_id', $branch_id)
//         ->where('status', 0)
//         ->where('department_id', 6)
//         ->where('et_staff.role_id', 16)
//         ->get();
//   $collectionExecutives = DB::table('et_staff')
//     ->where('status', 0)
//     ->where('role_id', 42) // adjust to your system
//     ->orderBy('staff_name')
//     ->get();
//     // Product List
//     $product_list = DB::table('et_product')
//         // ->where('branch_id', $branch_id)
//         // ->where('status', 1)
//         ->get();
//      $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.role_id', 16)
//       ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
//       ->where('et_staff.branch_id', $branch_id);
//     $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
//       ->distinct() // Ensure unique rows
//       ->get();
//       // return $customers;
//     return view('content.customer_management.manage_customer.customer_list', [
//         'customers' => $customers,
//         'search_fill' => $search_fill,
//         'types' => $types,i
//         'perpage' => $perpage,
//         'dashboard' => $dashboard,
//         'product_list' => $product_list,
//         'cre_list' => $cre_list,
//         'creStaffs' => $crestaff,
//         'collectionExecutives'=> $collectionExecutives,
//         'isActiveCustomerPage' => $isActiveCustomerPage ?? false
//     ]);
// }  catch (\Exception $e) {
//       return [
//         'status' => 400,
//         'error' => $e->getMessage(),
//       ];
//     }
// }

  public function Proposaldata(Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $branch_id = $request->user()->branch_id;
    $id = $request->input('id');
    $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
      ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
      ->where('et_proposal_pay_slot.proposal_sno', $id)
      ->where('et_proposal_pay_slot.status', 0)
      ->get();
    $proposal_data = DB::table('et_proposal')
      ->where('et_proposal.sno', $id)
      ->where('et_proposal.status', 0)
      ->first();
    $paidAmount = $slots->sum('paidAmount');
    $proposal_data->paidAmount = $paidAmount;
    $proposal_data->balanceAmount = $proposal_data->grant_total_amount - $paidAmount;

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'slots' => $slots,
      'proposal' => $proposal_data,
    ], 200);
  }

//   public function customer_view($id, Request $request)
//   {
//     $helper = new \App\Helpers\Helpers();
//     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
//     if ($decryptedValue === false) {
//       return redirect()->back()->with('error', 'Invalid Entry');
//     }
//     $customer_id = $decryptedValue;

//     $customer = DB::table('et_customer')->select('et_customer.*', 'et_countries.name as country_name', 'et_states.name as state_name', 'et_cities.name as city_name')
//       ->where('et_customer.sno', $customer_id)
//       ->leftJoin('et_countries', 'et_customer.country', 'et_countries.id')
//       ->leftJoin('et_states', 'et_customer.state', 'et_states.id')
//       ->leftJoin('et_cities', 'et_customer.city', 'et_cities.id')
//       ->first();


//     $proposal_ids = json_decode($customer->proposal_ids, true);


//     $proposals = DB::table('et_proposal')
//       ->whereIn('sno', $proposal_ids)
//       ->pluck('service_title')
//       ->toArray();
//     $customer->proposal_names = implode(', ', $proposals);

//     if (empty($proposal_ids) || !is_array($proposal_ids)) {
//       $proposal_data = collect();
//     }

//     $proposal_data = DB::table('et_proposal')
//       ->whereIn('et_proposal.sno', $proposal_ids)
//       ->where('et_proposal.status', '!=', 2)
//       ->orderBy('et_proposal.sno', 'desc')
//       ->get();
//     $proposal_currency = DB::table('et_proposal')
//       ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
//       ->whereIn('et_proposal.sno', $proposal_ids)
//       ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//       ->where('et_proposal.status', '!=', 2)
//       ->orderBy('et_proposal.sno', 'desc')
//       ->first();
//     $customer->currency_code = $proposal_currency->currency_code;
//     $customer->currency_symbol = $proposal_currency->currency_symbol;
//     $customer->currency_country_name = $proposal_currency->country_name;

//     foreach ($proposal_data as $proposal) {
//       $service_data = DB::table('et_customer_services')
//         ->where('proposal_id', $proposal->sno)
//         ->orderBy('sno', 'desc')
//         ->first();
//       $proposal->customer_service_id = $service_data->sno;
//       if ($proposal->product_package == 2) {
//         // For package type proposals
//         $package = DB::table('et_package')
//           ->where('sno', $proposal->package_id)
//           ->where('status', '!=', 2)
//           ->orderBy('sno', 'desc')
//           ->first();


//         $package_slots = DB::table('et_proposal_pay_slot')
//           ->where('proposal_sno', $proposal->sno)
//           ->where('status', 0)
//           ->get();
//         $product_slots_paid = $package_slots->sum('paidAmount');
//         $proposal->package_name = $package->package_name ?? null;
//         $proposal->package_slot = $package_slots;
//         $proposal->product_slots_paid = $product_slots_paid;
//       } else {
//         // For product type proposals
//         $products = DB::table('et_customer_services')
//           ->select('et_product.product_name', 'et_product_category.product_category_name')
//           ->join('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
//           ->join('et_product_category', 'et_product_category.sno', '=', 'et_product.product_category_id')
//           ->where('et_customer_services.proposal_id', $proposal->sno)
//           ->get();

//         $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
//           ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
//           ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
//           ->where('et_proposal_pay_slot.status', 0)
//           ->get();
//         $product_slots_paid = $product_slots->sum('paidAmount');



//         foreach ($products as $product) {
//         }

//         $proposal->product_slots_paid = $product_slots_paid;
//         $proposal->services = $products;
//         $proposal->product_slot = $product_slots;
//       }
//     }



//     // payment info
//     $customer_payment = DB::table('et_proposal')->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
//       ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//       ->where('et_proposal.customer_id', $customer_id)
//       ->whereNotIn('et_proposal.proposal_status', [0, 2])
//       ->where('et_proposal.status', 0)
//       ->orderBy('et_proposal.sno', 'desc')
//       ->first();


//     $TotalPaidAmount = DB::table('et_proposal_pay_slot')
//       ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
//       ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
//       ->where('et_proposal_pay_slot.status', 0)
//       ->where('et_proposal.status', 0)
//       ->sum('et_proposal_pay_slot.paidAmount');
//     $TotalAmount = DB::table('et_proposal')
//       ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
//       ->whereIn('et_proposal.sno', $proposal_ids)
//       ->where('et_proposal.status', 0)
//       ->where('et_lead.status', '!=', 2)
//       ->sum('et_proposal.total_amount');
//     $customer_payment->TotalPaidAmount = $TotalPaidAmount;
//     $customer_payment->TotalAmount = $TotalAmount;

//     $transaction = DB::table('et_transaction')
//       ->select(
//         'et_transaction.invoice_id',
//         'et_payment.pay_slot_id as slot_id',
//         'et_payment.transaction_date',
//         'et_transaction.transaction_id',
//         'et_customer.cus_name',
//         'et_customer.sno as cus_id',
//         'et_customer.customer_id',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_proposal.nda_old_customer_check',
//         'et_proposal.nda_temp_link',
//         'et_proposal.nda_signed',
//         'et_proposal.service_title',
//         'et_proposal.sno as proposal_id',
//         'et_proposal_pay_slot.paidAmount',
//         'et_manage_nda.nda_id',
//         'et_proposal_pay_slot.total_amount',
//         'et_payment.created_at',
//         'et_payment.payment_mode',
//         'et_country_currencies.currency_code',
//         'et_country_currencies.currency_symbol'
//       )
//       ->join('et_customer', 'et_customer.sno', '=', 'et_transaction.customer_id')
//       ->join('et_payment', 'et_payment.sno', '=', 'et_transaction.payment_id')
//       ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
//       ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//       ->leftJoin('et_manage_nda', 'et_proposal.sno', '=', 'et_manage_nda.proposal_id')
//       ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
//       ->where('et_transaction.customer_type', 0)
//       ->where('et_transaction.customer_id', $customer_id)
//       ->where('et_transaction.status', 0)
//       ->orderBy('et_transaction.sno', 'desc')
//       ->get();

//     foreach ($transaction as $pay) {
//       $sloData = DB::table('et_proposal_pay_slot')
//         ->where('sno', '!=', $pay->slot_id)
//         ->where('proposal_sno', $pay->proposal_id)
//         ->where('status', 0)
//         ->get();
//       $previousPaid = $sloData->sum('paidAmount');
//       $pay->previousPaidAmount = $previousPaid;
//     }
//     $customer_payment->transaction = $transaction;

//     // journal List
//     //  $journals = DB::table('et_journal_monitor')
//     // //   ->leftJoin('et_journal_history', 'et_journal_history.sno', '=', 'et_journal_monitor.journal_history_id')
//     // //   ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_history.customer_id')
//     //   ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.customer_services_id')
//     //   ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_journal_history.journal_booklet_id')
//     //   // Conditionally join et_product if product_package = 1
//     //   ->leftJoin('et_product', function ($join) {
//     //     $join->on('et_product.sno', '=', 'et_customer_services.product_package')
//     //       ->where('et_customer_services.product_package', '=', 1);
//     //   })

//     //   // Conditionally join et_product_category if product_package = 1
//     //   ->leftJoin('et_product_category', function ($join) {
//     //     $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
//     //       ->where('et_customer_services.product_package', '=', 1);
//     //   })

//     //   // Conditionally join et_package if product_package = 2
//     //   ->leftJoin('et_package', function ($join) {
//     //     $join->on('et_package.sno', '=', 'et_customer_services.package_id')
//     //       ->where('et_customer_services.product_package', '=', 2);
//     //   })
//     //   ->select(
//     //     'et_journal_monitor.*',
//     //     'et_customer.cus_name',
//     //     // 'et_journal_history.paper_name',
//     //     'et_journal_booklet.journal_name',
//     //     'et_customer.customer_id',
//     //     'et_journal_booklet.domain_id',
//     //     'et_customer_services.product_package',
//     //     DB::raw("CASE 
//     //                     WHEN et_customer_services.product_package = 1 THEN et_product.product_name
//     //                     WHEN et_customer_services.product_package = 2 THEN et_package.package_name
//     //                     ELSE NULL
//     //                 END as service_name"),
//     //     DB::raw("CASE 
//     //                     WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
//     //                     ELSE NULL
//     //                 END as category_name")
//     //   )
//     //   ->where('et_journal_monitor.branch_id', $customer->branch_id)
//     //   ->where('et_journal_history.customer_id', $customer->sno)
//     //   ->get();
//     $journals = [];
//     foreach ($journals as $journal) {
//       $domainIds = json_decode($journal->domain_id, true);
//       if (is_array($domainIds)) {
//         $domains = Db::table('et_domain')->whereIn('sno', $domainIds)->pluck('domain_name')->toArray();
//         $journal->domain_names = $domains;
//       } else {
//         $journal->domain_names = [];
//       }
//     }

//     // Appointment List

//     $appointments = DB::table('et_manage_appointments')->where('et_manage_appointments.status', '!=', 2)
//       ->select('et_manage_appointments.*', 'et_customer.cus_name as name', 'et_customer.customer_id as id', 'et_connecting_way.connecting_way_name as con_name', 'et_appointment_mode.appointment_mode_name', 'et_staff.staff_image', 'et_staff.staff_name', 'et_staff.nick_name', 'et_staff.gender')
//       ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_appointments.customer_id')
//       ->leftJoin('et_connecting_way', 'et_connecting_way.sno', '=', 'et_manage_appointments.connecting_way_id')
//       ->leftJoin('et_appointment_mode', 'et_appointment_mode.sno', '=', 'et_manage_appointments.appointment_mode_id')
//       ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_manage_appointments.staff_id')
//       ->where('et_manage_appointments.branch_id', $customer->branch_id)
//       ->where('et_manage_appointments.customer_id', $customer->sno)
//       ->orderBy('et_manage_appointments.sno', 'desc')
//       ->get();

//     $requirements = DB::table('et_lead_requirement_doc')->where('lead_id', $customer->lead_id)->where('status', '!=', 2)->get();

//     $tasks = Db::table('et_task')->select(
//       'et_task.*',
//       'et_customer.cus_name',
//       'et_customer.cus_mobile',
//       'et_customer.cus_email_id',
//       'et_customer.country_code',
//       'et_customer.customer_id AS cus_id',
//       'et_product.duration',
//       'et_product.duration_in',
//       'et_product_category.product_category_name',
//       'et_product_category.jouranal_check',
//       DB::raw("CASE 
//             WHEN et_customer_services.product_package = 1 THEN et_product.product_name
//             WHEN et_customer_services.product_package = 2 THEN et_package.package_name
//             ELSE NULL
//         END as product_name")
//     )
//       ->where('et_task.branch_id', $customer->branch_id)
//       ->where('et_task.status', '!=', 2)
//       ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
//       ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
//       ->leftJoin('et_product', function ($join) {
//         $join->on('et_product.sno', '=', 'et_customer_services.product_id')
//           ->where('et_customer_services.product_package', '=', 1);
//       })
//       ->leftJoin('et_package', function ($join) {
//         $join->on('et_package.sno', '=', 'et_customer_services.package_id')
//           ->where('et_customer_services.product_package', '=', 2);
//       })
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->where('et_customer_services.customer_id', $customer->sno)
//       ->orderBy('et_task.sno', 'desc')
//       ->get();

//     //  Deliverables List

//     $delivarables = [];
    
//     // $delivarables = DB::table('et_deliverables')->select(
//     //   'et_deliverables.*',
//     //   'et_customer.cus_name',
//     //   'et_customer.cus_mobile',
//     //   'et_customer.cus_email_id',
//     //   'et_customer.country_code',
//     //   'et_customer.customer_id as cus_id',
//     //   'et_product.duration',
//     //   'et_product.duration_in',
//     //   'et_product_category.product_category_name',
//     //   'et_product_category.jouranal_check',
//     //   'et_payment_slot.payment_slot_name',
//     //   DB::raw("CASE 
//     //               WHEN et_customer_services.product_package = 1 THEN et_product.product_name
//     //               WHEN et_customer_services.product_package = 2 THEN et_package.package_name
//     //               ELSE NULL
//     //           END as product_name")
//     // )
//     //   ->where('et_deliverables.status', '!=', 2)
//     //   ->leftJoin('et_payment_slot', 'et_deliverables.slot_id', 'et_payment_slot.sno')
//     //   ->leftJoin('et_customer_services', 'et_deliverables.service_id', 'et_customer_services.sno')
//     //   ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
//     //   ->leftJoin('et_product', function ($join) {
//     //     $join->on('et_product.sno', '=', 'et_customer_services.product_id')
//     //       ->where('et_customer_services.product_package', '=', 1);
//     //   })
//     //   ->leftJoin('et_package', function ($join) {
//     //     $join->on('et_package.sno', '=', 'et_customer_services.package_id')
//     //       ->where('et_customer_services.product_package', '=', 2);
//     //   })
//     //   ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//     //   ->where('et_deliverables.customer_id', $customer->sno)
//     //   ->where('et_deliverables.branch_id', $customer->branch_id)
//     //   ->orderBy('et_deliverables.sno', 'desc')->get();

//     //  Task List

//     $staffs = DB::table('et_task')->select(
//       'et_task.*',
//       'et_customer.cus_name',
//       'et_customer.cus_mobile',
//       'et_customer.cus_email_id',
//       'et_customer.country_code',
//       'et_customer.customer_id AS cus_id',
//       'et_product.duration',
//       'et_product.duration_in',
//       'et_product_category.product_category_name',
//       'et_product_category.jouranal_check',
//       DB::raw("CASE 
//                 WHEN et_customer_services.product_package = 1 THEN et_product.product_name
//                 WHEN et_customer_services.product_package = 2 THEN et_package.package_name
//                 ELSE NULL
//             END as product_name")
//     )
//       ->where('et_task.branch_id', $customer->branch_id)
//       ->where('et_task.status', '!=', 2)
//       ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
//       ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
//       ->leftJoin('et_product', function ($join) {
//         $join->on('et_product.sno', '=', 'et_customer_services.product_id')
//           ->where('et_customer_services.product_package', '=', 1);
//       })
//       ->leftJoin('et_package', function ($join) {
//         $join->on('et_package.sno', '=', 'et_customer_services.package_id')
//           ->where('et_customer_services.product_package', '=', 2);
//       })
//       ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
//       ->where('et_customer_services.customer_id', $customer->sno)
//       ->orderBy('et_task.sno', 'desc')
//       ->get();

//     $list_page = [];

//     foreach ($staffs as $task) {
//       $assignStaffArray = json_decode($task->assign_staffs, true) ?? [];

//       foreach ($assignStaffArray as $staffId) {
//         $staff_details = StaffModel::select('et_staff.nick_name', 'et_staff.staff_image', 'et_staff.staff_name', 'et_job_position.job_position_name')
//           ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
//           ->where('et_staff.status', 0)
//           ->where('et_staff.sno', $staffId)
//           ->orderBy('et_staff.staff_name', "ASC")->first();
//         $list_page[] = [
//           'sno'                   => $task->sno,
//           'branch_id'             => $task->branch_id,
//           'service_id'            => $task->service_id,
//           'task_id'               => $task->task_id,
//           'task_name'             => $task->task_name,
//           'working_hours'         => $task->working_hours,
//           'start_date_time'       => $task->start_date_time,
//           'end_date_time'         => $task->end_date_time,
//           'usage_hours'           => $task->usage_hours,
//           'task_completed_date_time' => $task->task_completed_date_time,
//           'task_completed_by'     => $task->task_completed_by,
//           'per_hour_cost'         => $task->per_hour_cost,
//           'billable'              => $task->billable,
//           'assign_staff_id'       => $staffId,
//           'staff_name'            => $staff_details->staff_name,
//           'nick_name'             => $staff_details->nick_name,
//           'staff_image'             => $staff_details->staff_image,
//           'gender'             => $staff_details->gender,
//           'task_check_list_ids'   => $task->task_check_list_ids,
//           'task_desc'             => $task->task_desc,
//           'created_by'            => $task->created_by,
//           'created_at'            => $task->created_at,
//           'updated_by'            => $task->updated_by,
//           'updated_at'            => $task->updated_at,
//           'status'                => $task->status,
//           // Joined customer & product info
//           'cus_name'              => $task->cus_name,
//           'cus_mobile'            => $task->cus_mobile,
//           'cus_email_id'          => $task->cus_email_id,
//           'country_code'          => $task->country_code,
//           'cus_id'                => $task->cus_id,
//           'product_name'          => $task->product_name,
//           'duration'              => $task->duration,
//           'duration_in'           => $task->duration_in,
//           'product_category_name' => $task->product_category_name,
//           'jouranal_check'        => $task->jouranal_check
//         ];
//       }
//     }

//     // Manual Pagination
//     $collection = collect($list_page);


//     return view('content.customer_management.manage_customer.customer_view', [
//       'customer' => $customer,
//       'proposal_data' => $proposal_data,
//       'journals' => $journals,
//       'appointments' => $appointments,
//       'requirements' => $requirements,
//       'tasks' => $tasks,
//       'delivarables' => $delivarables,
//       'staffs' => $collection,
//       'payment_list' => $customer_payment,
//       'transaction' => $transaction,
//     ]);
//   }

public function customer_view($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $customer_id = $decryptedValue;
 
    $customer = DB::table('et_customer')->select('et_customer.*', 'et_countries.name as country_name', 'et_states.name as state_name', 'et_cities.name as city_name')
      ->where('et_customer.sno', $customer_id)
      ->leftJoin('et_countries', 'et_customer.country', 'et_countries.id')
      ->leftJoin('et_states', 'et_customer.state', 'et_states.id')
      ->leftJoin('et_cities', 'et_customer.city', 'et_cities.id')
      ->first();
 
 
    $proposal_ids = json_decode($customer->proposal_ids, true);
 
 
    $proposals = DB::table('et_proposal')
      ->whereIn('sno', $proposal_ids)
      ->pluck('service_title')
      ->toArray();
    $customer->proposal_names = implode(', ', $proposals);
 
    if (empty($proposal_ids) || !is_array($proposal_ids)) {
      $proposal_data = collect();
    }
 
    $proposal_data = DB::table('et_proposal')
      ->whereIn('et_proposal.sno', $proposal_ids)
      ->where('et_proposal.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->get();
    $proposal_currency = DB::table('et_proposal')
      ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
      ->whereIn('et_proposal.sno', $proposal_ids)
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->first();
    $customer->currency_code = $proposal_currency->currency_code;
    $customer->currency_symbol = $proposal_currency->currency_symbol;
    $customer->currency_country_name = $proposal_currency->country_name;
 
    foreach ($proposal_data as $proposal) {
      $service_data = DB::table('et_customer_services')
        ->where('proposal_id', $proposal->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $proposal->customer_service_id = $service_data->sno;
      if ($proposal->product_package == 2) {
        // For package type proposals
        $package = DB::table('et_package')
          ->where('sno', $proposal->package_id)
          ->where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();
 
 
        $package_slots = DB::table('et_proposal_pay_slot')
          ->where('proposal_sno', $proposal->sno)
          ->where('status', 0)
          ->get();
        $product_slots_paid = $package_slots->sum('paidAmount');
        $proposal->package_name = $package->package_name ?? null;
        $proposal->package_slot = $package_slots;
        $proposal->product_slots_paid = $product_slots_paid;
      } else {
        // For product type proposals
        $products = DB::table('et_customer_services')
          ->select('et_product.product_name', 'et_product_category.product_category_name')
          ->join('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
          ->join('et_product_category', 'et_product_category.sno', '=', 'et_product.product_category_id')
          ->where('et_customer_services.proposal_id', $proposal->sno)
          ->get();
 
        $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
          ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
          ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
          ->where('et_proposal_pay_slot.status', 0)
          ->get();
        $product_slots_paid = $product_slots->sum('paidAmount');
 
 
 
        foreach ($products as $product) {
        }
 
        $proposal->product_slots_paid = $product_slots_paid;
        $proposal->services = $products;
        $proposal->product_slot = $product_slots;
      }
    }
 
 
 
    // payment info
    $customer_payment = DB::table('et_proposal')->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal.customer_id', $customer_id)
      ->whereNotIn('et_proposal.proposal_status', [0, 2])
      ->where('et_proposal.status', 0)
      ->orderBy('et_proposal.sno', 'desc')
      ->first();
 
 
    $TotalPaidAmount = DB::table('et_proposal_pay_slot')
      ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
      ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
      ->where('et_proposal_pay_slot.status', 0)
      ->where('et_proposal.status', 0)
      ->sum('et_proposal_pay_slot.paidAmount');
    $TotalAmount = DB::table('et_proposal')
      ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
      ->whereIn('et_proposal.sno', $proposal_ids)
      ->where('et_proposal.status', 0)
      ->where('et_lead.status', '!=', 2)
      ->sum('et_proposal.total_amount');
    $customer_payment->TotalPaidAmount = $TotalPaidAmount;
    $customer_payment->TotalAmount = $TotalAmount;
 
    $transaction = DB::table('et_transaction')
      ->select(
        'et_transaction.invoice_id',
        'et_payment.pay_slot_id as slot_id',
        'et_payment.transaction_date',
        'et_transaction.transaction_id',
        'et_customer.cus_name',
        'et_customer.sno as cus_id',
        'et_customer.customer_id',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_proposal.nda_old_customer_check',
        'et_proposal.nda_temp_link',
        'et_proposal.nda_signed',
        'et_proposal.service_title',
        'et_proposal.sno as proposal_id',
        'et_proposal_pay_slot.paidAmount',
        'et_manage_nda.nda_id',
        'et_proposal_pay_slot.total_amount',
        'et_payment.created_at',
        'et_payment.payment_mode',
        'et_country_currencies.currency_code',
        'et_country_currencies.currency_symbol'
      )
      ->join('et_customer', 'et_customer.sno', '=', 'et_transaction.customer_id')
      ->join('et_payment', 'et_payment.sno', '=', 'et_transaction.payment_id')
      ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->leftJoin('et_manage_nda', 'et_proposal.sno', '=', 'et_manage_nda.proposal_id')
      ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
      ->where('et_transaction.customer_type', 0)
      ->where('et_transaction.customer_id', $customer_id)
      ->where('et_transaction.status', 0)
      ->orderBy('et_transaction.sno', 'desc')
      ->get();
 
    foreach ($transaction as $pay) {
      $sloData = DB::table('et_proposal_pay_slot')
        ->where('sno', '!=', $pay->slot_id)
        ->where('proposal_sno', $pay->proposal_id)
        ->where('status', 0)
        ->get();
      $previousPaid = $sloData->sum('paidAmount');
      $pay->previousPaidAmount = $previousPaid;
    }
    $customer_payment->transaction = $transaction;
 
    // journal List
    //  $journals = DB::table('et_journal_monitor')
    // //   ->leftJoin('et_journal_history', 'et_journal_history.sno', '=', 'et_journal_monitor.journal_history_id')
    // //   ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_history.customer_id')
    //   ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.customer_services_id')
    //   ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_journal_history.journal_booklet_id')
    //   // Conditionally join et_product if product_package = 1
    //   ->leftJoin('et_product', function ($join) {
    //     $join->on('et_product.sno', '=', 'et_customer_services.product_package')
    //       ->where('et_customer_services.product_package', '=', 1);
    //   })
 
    //   // Conditionally join et_product_category if product_package = 1
    //   ->leftJoin('et_product_category', function ($join) {
    //     $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
    //       ->where('et_customer_services.product_package', '=', 1);
    //   })
 
    //   // Conditionally join et_package if product_package = 2
    //   ->leftJoin('et_package', function ($join) {
    //     $join->on('et_package.sno', '=', 'et_customer_services.package_id')
    //       ->where('et_customer_services.product_package', '=', 2);
    //   })
    //   ->select(
    //     'et_journal_monitor.*',
    //     'et_customer.cus_name',
    //     // 'et_journal_history.paper_name',
    //     'et_journal_booklet.journal_name',
    //     'et_customer.customer_id',
    //     'et_journal_booklet.domain_id',
    //     'et_customer_services.product_package',
    //     DB::raw("CASE
    //                     WHEN et_customer_services.product_package = 1 THEN et_product.product_name
    //                     WHEN et_customer_services.product_package = 2 THEN et_package.package_name
    //                     ELSE NULL
    //                 END as service_name"),
    //     DB::raw("CASE
    //                     WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
    //                     ELSE NULL
    //                 END as category_name")
    //   )
    //   ->where('et_journal_monitor.branch_id', $customer->branch_id)
    //   ->where('et_journal_history.customer_id', $customer->sno)
    //   ->get();
    $journals = [];
    foreach ($journals as $journal) {
      $domainIds = json_decode($journal->domain_id, true);
      if (is_array($domainIds)) {
        $domains = Db::table('et_domain')->whereIn('sno', $domainIds)->pluck('domain_name')->toArray();
        $journal->domain_names = $domains;
      } else {
        $journal->domain_names = [];
      }
    }
 
    // Appointment List
 
    $appointments = DB::table('et_manage_appointments')->where('et_manage_appointments.status', '!=', 2)
      ->select('et_manage_appointments.*', 'et_customer.cus_name as name', 'et_customer.customer_id as id', 'et_connecting_way.connecting_way_name as con_name', 'et_appointment_mode.appointment_mode_name', 'et_staff.staff_image', 'et_staff.staff_name', 'et_staff.nick_name', 'et_staff.gender')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_appointments.customer_id')
      ->leftJoin('et_connecting_way', 'et_connecting_way.sno', '=', 'et_manage_appointments.connecting_way_id')
      ->leftJoin('et_appointment_mode', 'et_appointment_mode.sno', '=', 'et_manage_appointments.appointment_mode_id')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_manage_appointments.staff_id')
      ->where('et_manage_appointments.branch_id', $customer->branch_id)
      ->where('et_manage_appointments.customer_id', $customer->sno)
      ->orderBy('et_manage_appointments.sno', 'desc')
      ->get();
 
    $requirements = DB::table('et_lead_requirement_doc')->where('lead_id', $customer->lead_id)->where('status', '!=', 2)->get();
 
    $tasks = Db::table('et_task')->select(
      'et_task.*',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      'et_customer.customer_id AS cus_id',
      'et_product.duration',
      'et_product.duration_in',
      'et_product_category.product_category_name',
      'et_product_category.jouranal_check',
      DB::raw("CASE
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as product_name")
    )
      ->where('et_task.branch_id', $customer->branch_id)
      ->where('et_task.status', '!=', 2)
      ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->where('et_customer_services.customer_id', $customer->sno)
      ->orderBy('et_task.sno', 'desc')
      ->get();
 
    //  Deliverables List
 
    $delivarables = [];
   
    // $delivarables = DB::table('et_deliverables')->select(
    //   'et_deliverables.*',
    //   'et_customer.cus_name',
    //   'et_customer.cus_mobile',
    //   'et_customer.cus_email_id',
    //   'et_customer.country_code',
    //   'et_customer.customer_id as cus_id',
    //   'et_product.duration',
    //   'et_product.duration_in',
    //   'et_product_category.product_category_name',
    //   'et_product_category.jouranal_check',
    //   'et_payment_slot.payment_slot_name',
    //   DB::raw("CASE
    //               WHEN et_customer_services.product_package = 1 THEN et_product.product_name
    //               WHEN et_customer_services.product_package = 2 THEN et_package.package_name
    //               ELSE NULL
    //           END as product_name")
    // )
    //   ->where('et_deliverables.status', '!=', 2)
    //   ->leftJoin('et_payment_slot', 'et_deliverables.slot_id', 'et_payment_slot.sno')
    //   ->leftJoin('et_customer_services', 'et_deliverables.service_id', 'et_customer_services.sno')
    //   ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
    //   ->leftJoin('et_product', function ($join) {
    //     $join->on('et_product.sno', '=', 'et_customer_services.product_id')
    //       ->where('et_customer_services.product_package', '=', 1);
    //   })
    //   ->leftJoin('et_package', function ($join) {
    //     $join->on('et_package.sno', '=', 'et_customer_services.package_id')
    //       ->where('et_customer_services.product_package', '=', 2);
    //   })
    //   ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
    //   ->where('et_deliverables.customer_id', $customer->sno)
    //   ->where('et_deliverables.branch_id', $customer->branch_id)
    //   ->orderBy('et_deliverables.sno', 'desc')->get();
 
    //  Task List
 
    $staffs = DB::table('et_task')->select(
      'et_task.*',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      'et_customer.customer_id AS cus_id',
      'et_product.duration',
      'et_product.duration_in',
      'et_product_category.product_category_name',
      'et_product_category.jouranal_check',
      DB::raw("CASE
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as product_name")
    )
      ->where('et_task.branch_id', $customer->branch_id)
      ->where('et_task.status', '!=', 2)
      ->leftJoin('et_customer_services', 'et_task.service_id', 'et_customer_services.sno')
      ->leftJoin('et_customer', 'et_customer_services.customer_id', 'et_customer.sno')
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
      ->where('et_customer_services.customer_id', $customer->sno)
      ->orderBy('et_task.sno', 'desc')
      ->get();
 
    $list_page = [];
 
    foreach ($staffs as $task) {
      $assignStaffArray = json_decode($task->assign_staffs, true) ?? [];
 
      foreach ($assignStaffArray as $staffId) {
        $staff_details = StaffModel::select('et_staff.nick_name', 'et_staff.staff_image', 'et_staff.staff_name', 'et_job_position.job_position_name')
          ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
          ->where('et_staff.status', 0)
          ->where('et_staff.sno', $staffId)
          ->orderBy('et_staff.staff_name', "ASC")->first();
        $list_page[] = [
          'sno'                   => $task->sno,
          'branch_id'             => $task->branch_id,
          'service_id'            => $task->service_id,
          'task_id'               => $task->task_id,
          'task_name'             => $task->task_name,
          'working_hours'         => $task->working_hours,
          'start_date_time'       => $task->start_date_time,
          'end_date_time'         => $task->end_date_time,
          'usage_hours'           => $task->usage_hours,
          'task_completed_date_time' => $task->task_completed_date_time,
          'task_completed_by'     => $task->task_completed_by,
          'per_hour_cost'         => $task->per_hour_cost,
          'billable'              => $task->billable,
          'assign_staff_id'       => $staffId,
          'staff_name'            => $staff_details->staff_name,
          'nick_name'             => $staff_details->nick_name,
          'staff_image'             => $staff_details->staff_image,
          'gender'             => $staff_details->gender,
          'task_check_list_ids'   => $task->task_check_list_ids,
          'task_desc'             => $task->task_desc,
          'created_by'            => $task->created_by,
          'created_at'            => $task->created_at,
          'updated_by'            => $task->updated_by,
          'updated_at'            => $task->updated_at,
          'status'                => $task->status,
          // Joined customer & product info
          'cus_name'              => $task->cus_name,
          'cus_mobile'            => $task->cus_mobile,
          'cus_email_id'          => $task->cus_email_id,
          'country_code'          => $task->country_code,
          'cus_id'                => $task->cus_id,
          'product_name'          => $task->product_name,
          'duration'              => $task->duration,
          'duration_in'           => $task->duration_in,
          'product_category_name' => $task->product_category_name,
          'jouranal_check'        => $task->jouranal_check
        ];
      }
    }
 
    // Manual Pagination
    $collection = collect($list_page);
 
    $timeline = $this->getMilestone1Timeline(
        $customer->sno,
        $proposal_data
    );
    $journalTimeline = $this->getJournalTimeline(
        $customer->sno
    );
    // return $timeline;
   $chatHistory = DB::table('et_chat')
    ->leftJoin('et_staff', 'et_chat.staff_id', '=', 'et_staff.sno')
    ->where('et_chat.customer_id', $customer->sno)
    ->where('et_chat.status', 0)
    ->select(
        'et_chat.*',
        'et_staff.staff_name',
        'et_staff.staff_image'
    )
    ->orderBy('et_chat.created_at', 'asc')
    ->get();
 
    return view('content.customer_management.manage_customer.customer_view', [
      'customer' => $customer,
      'proposal_data' => $proposal_data,
      'journals' => $journals,
      'appointments' => $appointments,
      'requirements' => $requirements,
      'tasks' => $tasks,
      'delivarables' => $delivarables,
      'staffs' => $collection,
      'payment_list' => $customer_payment,
      'transaction' => $transaction,
      'timeline' => $timeline,
      'chatHistory' => $chatHistory,
      'journalTimeline' => $journalTimeline,
    ]);
  }
 
  // new Prposal Add 
//   public function customer_add_service($id, Request $request)
//   {
//     $helper = new \App\Helpers\Helpers();
//     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

//     // Check if decryption failed
//     if ($decryptedValue === false) {
//       return redirect()->back()->with('error', 'Invalid Entry');
//     }
//     $lead_id = $decryptedValue;
//     $branch_id = $request->user()->branch_id;
//     $user_id = $request->user()->user_id;
//     $lead = DB::table('et_customer')->where('et_customer.sno', $decryptedValue)->first();
//     //  $lead=DB::table('et_lead')->where('et_lead.sno',$decryptedValue)->first();

//     $proposal = ProposalModel::orderBy('sno', 'desc')->first();
//     $package_list = DB::table('et_package')->where('et_package.status', 0)->orderBy('sno', 'desc')->get();
//     $additional_charges_list = DB::table('et_additional_charges')->where('et_additional_charges.status', 0)->orderBy('sno', 'desc')->get();

//     $currencyList = DB::table('et_country_currencies')->where('et_country_currencies.status', 0)->get();
//     $domainList = DB::table('et_domain')->where('et_domain.status', 0)->get();

//     $Product_cat_list = DB::table('et_product_category')
//       ->select(
//         'et_product_category.sno',
//         'et_product_category.product_category_name',
//         DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
//       )
//       ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
//       ->where('et_product_category.status', 0)
//       ->where('et_product.branch_id', $branch_id)
//       ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
//       ->orderBy('et_product_category.product_category_name', 'ASC')
//       ->get();

//     $addOnProductList = DB::table('et_manage_addon')
//       ->select(
//         'et_manage_addon.sno',
//         'et_manage_addon.addon_name'
//       )
//       ->where('et_manage_addon.status', 0)
//       ->where('et_manage_addon.branch_id', $branch_id)
//       ->get();

//     foreach ($addOnProductList as $addOn) {
//       $manageVarient = DB::table('et_manage_addon_variant')
//         ->select(
//           'et_manage_addon_variant.sno',
//           'et_manage_addon_variant.amount',
//           'et_manage_addon_variant.free_paid',
//           'et_addon_variable.addon_variablename'
//         )
//         ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
//         ->where('et_manage_addon_variant.addon_id', $addOn->sno)
//         ->get();

//       $addOn->add_varients = $manageVarient;
//     }

//     $branch_data = DB::table('et_branch')->where('sno', $request->user()->branch_id)->first();

//     // return $addOnProductList;

//     $create_chk = PreProposalModel::where('customer_id', $lead_id)->where('status', 0)->first();

//     if ($create_chk) {
//       $Inserted_id = $create_chk->sno;
//       $cus_proposal_id = $create_chk->proposal_id;
//     } else {
//       $category_check = PreProposalModel::orderBy('sno', 'desc')->first();

//       if (!$category_check) {
//         $year = date('Y');
//         $month = date('m');
//         $proposal_id = 'PRO-00001/' . $month . '/' . $year;
//       } else {
//         $year = date('Y');
//         $month = date('m');
//         $Inserted_id = $category_check->sno + 1;
//         $data = $category_check->proposal_id;
//         $slice = explode('/', $data);
//         $result = preg_replace('/[^0-9]/', '', $slice[0]);
//         $next_number = (int) $result + 1;
//         $request_id = sprintf('PRO-%05d', $next_number);
//         $proposal_id = $request_id . '/' . $month . '/' . $year;
//       }
//       $new_proposal_create = new PreProposalModel();
//       $new_proposal_create->proposal_id = $proposal_id;
//       $new_proposal_create->lead_id = $lead->lead_id;
//       $new_proposal_create->customer_id = $lead_id;
//       $new_proposal_create->created_by = $user_id;
//       $new_proposal_create->updated_by = $user_id;
//       $new_proposal_create->save();
//       $Inserted_id = $new_proposal_create->sno;
//       $cus_proposal_id = $new_proposal_create->proposal_id;
//     }
//     $packageSlot = DB::table('et_proposal_pay_slot')->where('proposal_id', $cus_proposal_id)->where('status', 0)->where('package_id', '!=', 0)->orderBy('sno', 'desc')->first();
//     // return $proposal_id;
//     $preProposal = DB::table('et_pre_proposal')->where('proposal_id', $cus_proposal_id)->first();

//     $couponCode = null;

//     if ($preProposal->discount_id > 0) {
//       $coupon = DB::table('et_manage_coupon')->where('sno', $preProposal->discount_id)->first();

//       if ($coupon) {
//         $couponCode = $coupon->coupon_code;
//       }
//     }

//     $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.role_id', 16)
//       ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
//       ->where('et_staff.branch_id', $branch_id);
//     $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
//       ->distinct() // Ensure unique rows
//       ->get();
//     $collectionStaff = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.role_id', 42)
//       ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
//       ->where('et_staff.branch_id', $branch_id);
//     $collectionStaff = $collectionStaff->orderBy('et_staff.staff_name', 'asc')
//       ->distinct() // Ensure unique rows
//       ->get();
//     $postSaleStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.department_id', 15)
//       ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
//       ->where('et_staff.branch_id', $branch_id);
//     $postSaleStaff = $postSaleStaff->orderBy('et_staff.staff_name', 'asc')
//       ->distinct() // Ensure unique rows
//       ->get();
//     $referalStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
//       ->where('et_staff.status', 0)
//       ->where('et_staff.role_id', '>', 1)
//       // ->where('et_staff.department_id', 3)
//       // ->where('et_staff.sub_department_id', 6)
//       ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
//       ->where('et_staff.branch_id', $branch_id);
//     $referalStaff = $referalStaff->orderBy('et_staff.staff_name', 'asc')
//       ->distinct() // Ensure unique rows
//       ->get();
//     $packageData = DB::table('et_proposal_package_cart')->where('proposal_id', $cus_proposal_id)->where('status', 0)->orderBy('sno', 'asc')->get();
//     return view('content.customer_management.manage_customer.customer_add_service', [

//       'customer' => $lead,
//       'proposal' => $proposal,
//       'currencyList' => $currencyList,
//       'Product_cat_list' => $Product_cat_list,
//       'Inserted_id' => $Inserted_id,
//       'addOnProductList' => $addOnProductList,
//       'branch_data' => $branch_data,
//       'proposal_id' => $cus_proposal_id,
//       'package_list' => $package_list,
//       'additional_charges_list' => $additional_charges_list,
//       'packageSlot' => $packageSlot,
//       'couponCode' => $couponCode,
//       'preProposal' => $preProposal,
//       'domainList' => $domainList,
//       'crestaff' => $crestaff,
//       'collectionStaff'=> $collectionStaff,
//       'referalStaff' => $referalStaff,
//       'postSaleStaff' => $postSaleStaff,
//       'packageData' => $packageData,
//     ]);
//   }

 public function customer_add_service($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
 
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $lead_id = $decryptedValue;
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $lead = DB::table('et_customer')->where('et_customer.sno', $decryptedValue)->first();
    //  $lead=DB::table('et_lead')->where('et_lead.sno',$decryptedValue)->first();
    // get customer referal details and cre details
    $referals=DB::table('et_customer_referal')
              ->where('et_customer_referal.customer_id', $decryptedValue)
              ->where('et_customer_referal.expiry_date','>', now())
              ->first();
    if ($lead) {
    // Assign the referral object to a new property inside $lead
      $lead->referals = $referals;
    }
 
    $proposal = ProposalModel::orderBy('sno', 'desc')->first();
    $package_list = DB::table('et_package')->where('et_package.status', 0)->orderBy('sno', 'desc')->get();
    $additional_charges_list = DB::table('et_additional_charges')->where('et_additional_charges.status', 0)->orderBy('sno', 'desc')->get();
 
    $currencyList = DB::table('et_country_currencies')->where('et_country_currencies.status', 0)->get();
    $domainList = DB::table('et_domain')->where('et_domain.status', 0)->get();
 
    $Product_cat_list = DB::table('et_product_category')
      ->select(
        'et_product_category.sno',
        'et_product_category.product_category_name',
        DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
      )
      ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
      ->where('et_product_category.status', 0)
      ->where('et_product.branch_id', $branch_id)
      ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
      ->orderBy('et_product_category.product_category_name', 'ASC')
      ->get();
 
    $addOnProductList = DB::table('et_manage_addon')
      ->select(
        'et_manage_addon.sno',
        'et_manage_addon.addon_name'
      )
      ->where('et_manage_addon.status', 0)
      ->where('et_manage_addon.branch_id', $branch_id)
      ->get();
 
    foreach ($addOnProductList as $addOn) {
      $manageVarient = DB::table('et_manage_addon_variant')
        ->select(
          'et_manage_addon_variant.sno',
          'et_manage_addon_variant.amount',
          'et_manage_addon_variant.free_paid',
          'et_addon_variable.addon_variablename'
        )
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_manage_addon_variant.addon_id', $addOn->sno)
        ->get();
 
      $addOn->add_varients = $manageVarient;
    }
 
    $branch_data = DB::table('et_branch')->where('sno', $request->user()->branch_id)->first();
 
    // return $addOnProductList;
 
    $create_chk = PreProposalModel::where('customer_id', $lead_id)->where('status', 0)->first();
 
    if ($create_chk) {
      $Inserted_id = $create_chk->sno;
      $cus_proposal_id = $create_chk->proposal_id;
    } else {
      $category_check = PreProposalModel::orderBy('sno', 'desc')->first();
 
      if (!$category_check) {
        $year = date('Y');
        $month = date('m');
        $proposal_id = 'PRO-00001/' . $month . '/' . $year;
      } else {
        $year = date('Y');
        $month = date('m');
        $Inserted_id = $category_check->sno + 1;
        $data = $category_check->proposal_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int) $result + 1;
        $request_id = sprintf('PRO-%05d', $next_number);
        $proposal_id = $request_id . '/' . $month . '/' . $year;
      }
      $new_proposal_create = new PreProposalModel();
      $new_proposal_create->proposal_id = $proposal_id;
      $new_proposal_create->lead_id = $lead->lead_id;
      $new_proposal_create->customer_id = $lead_id;
      $new_proposal_create->created_by = $user_id;
      $new_proposal_create->updated_by = $user_id;
      $new_proposal_create->save();
      $Inserted_id = $new_proposal_create->sno;
      $cus_proposal_id = $new_proposal_create->proposal_id;
    }
    $packageSlot = DB::table('et_proposal_pay_slot')->where('proposal_id', $cus_proposal_id)->where('status', 0)->where('package_id', '!=', 0)->orderBy('sno', 'desc')->first();
    // return $proposal_id;
    $preProposal = DB::table('et_pre_proposal')->where('proposal_id', $cus_proposal_id)->first();
 
    $couponCode = null;
 
    if ($preProposal->discount_id > 0) {
      $coupon = DB::table('et_manage_coupon')->where('sno', $preProposal->discount_id)->first();
 
      if ($coupon) {
        $couponCode = $coupon->coupon_code;
      }
    }
 
    $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.role_id', 16)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();
    $collectionStaff = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.role_id', 42)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $collectionStaff = $collectionStaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();
    $postSaleStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.department_id', 15)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $postSaleStaff = $postSaleStaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();
    $referalStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.role_id', '>', 1)
      // ->where('et_staff.department_id', 3)
      // ->where('et_staff.sub_department_id', 6)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $referalStaff = $referalStaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();
    $packageData = DB::table('et_proposal_package_cart')->where('proposal_id', $cus_proposal_id)->where('status', 0)->orderBy('sno', 'asc')->get();
    return view('content.customer_management.manage_customer.customer_add_service', [
 
      'customer' => $lead,
      'proposal' => $proposal,
      'currencyList' => $currencyList,
      'Product_cat_list' => $Product_cat_list,
      'Inserted_id' => $Inserted_id,
      'addOnProductList' => $addOnProductList,
      'branch_data' => $branch_data,
      'proposal_id' => $cus_proposal_id,
      'package_list' => $package_list,
      'additional_charges_list' => $additional_charges_list,
      'packageSlot' => $packageSlot,
      'couponCode' => $couponCode,
      'preProposal' => $preProposal,
      'domainList' => $domainList,
      'crestaff' => $crestaff,
      'collectionStaff'=> $collectionStaff,
      'referalStaff' => $referalStaff,
      'postSaleStaff' => $postSaleStaff,
      'packageData' => $packageData,
    ]);
  }
  
  
  public function customer_referals(Request $request){
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user = auth()->user();
        // Filter
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $pageConfigs = ['myLayout' => 'default'];
        $referer_type=$request->referrer_id;
        // Data Fetching Variables
        $query = CustomerReferalModel::where('et_customer_referal.status', '!=', 2)
        ->select(
            'et_customer_referal.*',
            'et_customer.cus_name',
            'et_customer.cus_email_id',
            'et_customer.cus_gender',
            'et_customer.customer_id',
            'et_product.product_name',
        )
        ->leftJoin(
            'et_customer',
            'et_customer.sno',
            '=',
            'et_customer_referal.customer_id'
        )
        ->leftJoin(
            'et_product',
            'et_product.sno',
            '=',
            'et_customer_referal.product_id'
        );
        $customers = $query->paginate($perpage);
        foreach($customers as $customer){
          if($customer->referer_type==0){
            $staff= DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', 16)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id)
                        ->where('et_staff.sno', $customer->referer_id)->first();
          }else{
            $staff = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', 42)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id)
                        ->where('et_staff.sno', $customer->referer_id)->first();
          }
          $customer->staff_details=$staff;
          // parse data
          // Assuming $record has your created_at and expiry_date
         $targetTime = Carbon::parse($customer->expiry_date);
          $now = Carbon::now();
          // 1. If the target time is already in the past
          if ($now->greaterThan($targetTime)) {
              $customer->days_left = "Expired";
          } else {
              $hoursMore = $now->diffInHours($targetTime);
              // 2. If it's 24 hours or more, show days
              if ($hoursMore >= 24) {
                  $daysMore = $now->diffInDays($targetTime);
                  $customer->days_left = "{$daysMore} " . Str::plural('day', $daysMore) . " left";
              } else {
                  // 3. If it's less than a day, show hours (or 1 hour minimum)
                  $hoursMore = max(1, $hoursMore);
                  $customer->days_left = "{$hoursMore} " . Str::plural('hour', $hoursMore) . " left";
              }
          }
        }
        // Returning View
        // fetching dropdown for cre and ce staff
         $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', 16)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();
          $collectionStaff = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', 42)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $collectionStaff = $collectionStaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();
          $productList = DB::table('et_product')->select('et_product.*', 'et_product.product_name')
                        ->where('et_product.status', 0)
                        ->where('et_product.branch_id', $branch_id);
          $productList=$productList->orderBy('et_product.product_name', 'asc')
                        ->distinct() // Ensure unique rows
                        ->get();
        $search_fill = $request->search_fill ?? '';
        if (! empty($search_fill)) {
            $query->where(function ($q) use ($search_fill) {
               $columns = [
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer_services.service_name',
                'et_journal.journal_name',
                'et_journal.journal_id',
                'et_connecting_way.connecting_way_name',
                'et_appointment_mode.appointment_mode_name',
                'normal_staff.staff_name',
                'pc_staff.staff_name',
            ];
                foreach ($columns as $column) {
                    $q->orWhere($column, 'LIKE', "%{$search_fill}%");
                }
            });
        }
         if (auth()->user()->hasPermissionradio('Journal Management', 'Journal Appointments', 'view_self_cus')) {
             if ($user->role_id == 16) {
                $query = $query->where('et_journal_appointments.created_by', $user_id);
             }else if($user->role_id == 34){
                 $query = $query->where('et_journal_appointments.assigned_je_id', $user_id);
             }else if($user->role_id == 33 || $user->role_id == 15 ){
                 $query = $query->where('et_journal_appointments.staff_id', $user_id);
             }else if($user->role_id == 42 ){
                 $query = $query->where('et_proposal.collection_id', $user_id);
             }
            } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Journal Appointments', 'global_cus')) {
                // $query = $query;
            } else {
                abort(403, 'Unauthorized');
            }
            return view('content.customer_management.manage_customer.customers_referals_list', compact(
                'customers',
                'perpage',
                'pageConfigs',
                'search_fill',
                'collectionStaff',
                'crestaff',
                'productList',
            ));
  }
  
  public function getReferer(Request $request){
     $branch_id = $request->user()->branch_id;
    // fetching dropdown for cre and ce staff
         $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', 16)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();
          $collectionStaff = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', 42)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $collectionStaff = $collectionStaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();
    if($request->referer_id == 0){
      $list=$crestaff;
    }else{
      $list=$collectionStaff;
    }
 
    return response()->json([
        'status' => 200,
        'message' => 'Fetched successfully',
        'error_msg' => 'Error',
        'data' => $list,
      ], 200);
  }
 
 
 
public function add_referal(Request $request){
 
    $user_id = $request->user_id;
    $expiry_date=Carbon::now()->addDays(30);
    $addReferal = new CustomerReferalModel();
 
    $addReferal->customer_id=$request->customer_id;
    $addReferal->product_id=$request->product_name_id;
    $addReferal->referer_id=$request->referer_id;
    $addReferal->referer_type=$request->referer_type;
    $addReferal->description=$request->description;
    $addReferal->expiry_date=$expiry_date;
    $addReferal->created_by=$user_id;
 
 
    $addReferal->save();
   
 
    return response()->json([
        'status' => 200,
        'message' => 'Fetched successfully',
        'error_msg' => 'Error',
        'data' => $addReferal,
      ], 200);
  }
  
  
  public function GenerateProposalCustomer(Request $request)
  {

    // return $request;

    $branch_id = $request->user()->branch_id;
    $entity_id = $request->user()->entity_id;
    $user_id = $request->user()->user_id;



    $proposal_id = $request->input('proposal_hidden_id');

    $customer_id = $request->input('proposal_lead_id');
    $service_title = $request->input('prposal_service_title');
    $domain_ids = $request->input('proposal_domain');
    $milestone_count = $request->input('milestone_count');
    $topic = $request->input('proposal_topic');
    $cre_id = $request->input('proposal_cre');
    $collection_id = $request->input('collection_id');
    $due_date = $request->input('prposal_due_date') ? date('Y-m-d', strtotime($request->input('prposal_due_date'))) : null;
    $estimate_date = $request->input('estimate_date') ? date('Y-m-d', strtotime($request->input('estimate_date'))) : null;
    $currency_id = $request->input('prposal_currency');
    $proposal_date = date('Y-m-d');
    $package_check = $request->input('serv_prod_pckg_chk');
    $sub_total = $request->input('sub_total_amount');
    $discount_id = $request->input('discount_id_hidden');
    $discount_amount = $request->input('discounted_amount_hidden');
    $gst_amount = $request->input('gst_amount_hidden');
    $gst_perc = $request->input('gst_perc_hidden');
    $additional_charge_perc = $request->input('additional_charge_perc');
    $additional_charge_amount = $request->input('additional_charge_amount');
    $addtional_charges_id = $request->input('addtional_charges_id');
    $delivery_duration = $request->input('delivery_duration');
    $delivery_duration_end = $request->input('delivery_duration_end');
    $total_amount = $request->input('proposal_total_amount');
    $grant_total_amount = $request->input('grant_total_amount');
    $package_id = $request->input('package_id');
    $gst_inclusive = $request->input('gst_inclusive');
    $send_communication = $request->input('send_communication');
    $page_word = $request->input('page_word');
    $page_word_count = $request->input('page_word_count');
    $referral_id = $request->input('proposal_referral_staff');
    $created_by = $request->input('post_sale_staff') ?? $user_id;
    $old_customer_check = $request->input('old_customer_check') ?? 0;

    $customer = DB::table('et_customer')->where('et_customer.sno', $customer_id)->first();

    $addtional_charges_ids = $addtional_charges_id ? json_encode($addtional_charges_id) : null;
    $domain_ids = $domain_ids ? json_encode($domain_ids) : null;
    $lead_id = $customer->lead_id;
    // 1. Insert into et_proposal
    $add_category = DB::table('et_proposal')->insertGetId([
      'proposal_id' => $proposal_id,
      'lead_id' => $lead_id,
      'service_title' => $service_title,
      'domain_ids' => $domain_ids,
      'topic' => $topic,
      'cre_id' => $cre_id,
      'collection_id'=>$collection_id,
      'milestone_count' => $milestone_count,
      'product_package' => $package_check,
      'package_id' => $package_id,
      'due_date' => $due_date,
      'estimate_date' => $estimate_date,
      'currency_id' => $currency_id,
      'propsal_date' => $proposal_date,
      'package_id' => $package_id ?? 0,
      'sub_total' => $sub_total,
      'discount_id' => $discount_id,
      'discount_amount' => $discount_amount,
      'gst_amount' => $gst_amount,
      'total_amount' => $total_amount,
      'grant_total_amount' => $grant_total_amount,
      'created_by' => $created_by,
      'updated_by' => $user_id,
      'branch_id' => $branch_id,
      'delivery_duration' => $delivery_duration,
      'delivery_duration_end' => $delivery_duration_end,
      'gst_perc' => $gst_perc,
      'gst_inclusive' => $gst_inclusive ?? 0,
      'parent_id' => $proposal_id,
      'additional_charge_perc' => $additional_charge_perc,
      'additional_charge_amount' => $additional_charge_amount,
      'addtional_charges_ids' => $addtional_charges_ids,
      'send_status' => $send_communication == 1 ? 1 : 0,
      'verify_status' => $send_communication == 1 ? 1 : 0,
      'page_word' => $page_word,
      'page_word_count' => $page_word_count ?? 0,
      'customer_id' => $customer_id,
      'post_sale_check' => 1,
      'post_sale_date' => date('Y-m-d'),
      'referral_id' => $referral_id ?? 0,
      'old_customer_check' => $old_customer_check ?? 0,
    ]);

    DB::table('et_pre_proposal')
      ->where('proposal_id', $proposal_id)
      ->update(['status' => 2]);

    DB::table('et_proposal_pay_slot')
      ->where('proposal_id', $proposal_id)
      ->where('status', 0)
      ->update(['proposal_sno' => $add_category]);

    if ($package_check == 1) {

      if ($request->has('addOn_chk')) {
        foreach ($request->input('addOn_chk') as $addOnId) {
          $variant_key = "addOn_varient_$addOnId";
          $variant_id = $request->input($variant_key);

          if ($currency_id != 70) {
            // If currency_id is not 70, fetch amount from et_price_book
            $priceDataAddon = DB::table('et_price_book')
              ->where('currency_id', $currency_id)
              ->where('status', 3)
              ->get();

            $addon_data = DB::table('et_manage_addon_variant')
              ->where('sno', $variant_id)
              ->first();

            // Find the addon amount from varient_details where variant_id matches
            $addon_amount = 0; // Default to 0 if no match found
            foreach ($priceDataAddon as $addon) {
              $variantDetails = json_decode($addon->varient_details);
              foreach ($variantDetails as $variant) {
                if ($variant->variant_id == $variant_id) {
                  $addon_amount = $variant->amount; // Get the amount from varient_details
                  break 2; // Exit both loops once the matching variant is found
                }
              }
            }
          } else {
            // If currency_id is 70, fetch data from et_manage_addon_variant table
            $addon_data = DB::table('et_manage_addon_variant')
              ->where('sno', $variant_id)
              ->first();

            // Set the addon_amount based on the fetched data
            $addon_amount = $addon_data ? $addon_data->amount : 0;
          }

          // Insert into et_proposal_addon_product table
          DB::table('et_proposal_addon_product')->insert([
            'proposal_id' => $proposal_id,
            'proposal_sno' => $add_category,
            'add_on_id' => $addOnId,
            'free_paid' => isset($addon_data) ? $addon_data->free_paid : null,
            'addon_variant_id' => $variant_id,
            'addon_amount' => $addon_amount,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'branch_id' => $branch_id,
          ]);
        }
      }

      // 3. Insert into et_proposal_product_cart
      $temp_id = $request->input('Inserted_id_product');
      $product_cart_data = DB::table('et_temp_proposal_cart')
        ->where('temp_proposal_id', $temp_id)
        ->where('status', 0)
        ->get();

      foreach ($product_cart_data as $cart) {
        DB::table('et_proposal_product_cart')->insert([
          'proposal_id' => $proposal_id,
          'proposal_sno' => $add_category,
          'product_id' => $cart->product_id,
          'product_amount' => $cart->cust_product_amount,
          'original_amount' => $cart->product_amount,
          'cart_id' => $cart->sno,
          'variant_variable_ids' => $cart->variant_variable_ids,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'branch_id' => $branch_id,
        ]);
      }
    } else {

      if ($request->has('addOn_chk')) {
        foreach ($request->input('addOn_chk') as $addOnId) {
          $variant_key = "addOn_varient_$addOnId";
          $variant_id = $request->input($variant_key);

          if ($currency_id != 70) {
            // If currency_id is not 70, fetch amount from et_price_book
            $priceDataAddon = DB::table('et_price_book')
              ->where('currency_id', $currency_id)
              ->where('status', 3)
              ->get();

            $addon_data = DB::table('et_manage_addon_variant')
              ->where('sno', $variant_id)
              ->first();

            // Find the addon amount from varient_details where variant_id matches
            $addon_amount = 0; // Default to 0 if no match found
            foreach ($priceDataAddon as $addon) {
              $variantDetails = json_decode($addon->varient_details);
              foreach ($variantDetails as $variant) {
                if ($variant->variant_id == $variant_id) {
                  $addon_amount = $variant->amount; // Get the amount from varient_details
                  break 2; // Exit both loops once the matching variant is found
                }
              }
            }
          } else {
            // If currency_id is 70, fetch data from et_manage_addon_variant table
            $addon_data = DB::table('et_manage_addon_variant')
              ->where('sno', $variant_id)
              ->first();

            // Set the addon_amount based on the fetched data
            $addon_amount = $addon_data ? $addon_data->amount : 0;
          }

          // Insert into et_proposal_addon_product table
          DB::table('et_proposal_addon_product')->insert([
            'proposal_id' => $proposal_id,
            'proposal_sno' => $add_category,
            'add_on_id' => $addOnId,
            'free_paid' => isset($addon_data) ? $addon_data->free_paid : null,
            'addon_variant_id' => $variant_id,
            'addon_amount' => $addon_amount,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'branch_id' => $branch_id,
          ]);
        }
      }

      $temp_id = $request->input('Inserted_id_product');
      DB::table('et_temp_proposal_cart')
        ->where('temp_proposal_id', $temp_id)
        ->where('status', 0)
        ->update(['status' => 2]);


      $packageTemp = DB::table('et_package')->where('status', 0)
        ->where('sno', $package_id)
        ->first();

      $packageData = DB::table('et_package_product')->where('status', 0)
        ->where('package_id', $package_id)
        ->orderBy('sno', 'asc')
        ->get();

      DB::table('et_proposal_package_cart')
        ->where('proposal_id', $proposal_id)
        ->where('status', 0)
        ->update(['proposal_sno' => $add_category]);
    }

    // 2. Insert into et_proposal_addon_product


    DB::commit();
    // send Communication
    if ($send_communication == 1) {
      $proposalData = DB::table('et_proposal')->where('et_proposal.sno', $add_category)->first();
      $leadData = DB::table('et_lead')->where('et_lead.sno', $lead_id)->first();
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($proposalData->sno, 'encrypt');

      $Link = url('manage_proposal/send_proposal/' . $encrypted_values);


      //  communication Proposal
      $communicationStatus = DB::table('et_communication_handle')->where('module_name', 'Proposal Send')->first();
      $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id', $proposalData->cre_id)->first();
      if ($communicationStatus && $communicationStatus->status == 0) {

        if (!$proposalData->temp_send_link) {
          $channelId = 4;
          $shortUrlData = $this->shortenUrl($Link, $channelId);
          $shortUrl = $shortUrlData['shorturl'];
          $urlId = $shortUrlData['id'];
          if ($shortUrl) {
            DB::table('et_proposal')
              ->where('sno', $proposalData->sno)
              ->update(['temp_send_link' => $shortUrl]);

            DB::table('et_chotta_links')->insert([
              'branch_id' => $branch_id,
              'chotta_link_id' => $urlId,
              'chotta_short_link' => $shortUrl,
              'large_encrypt_link' => $Link,
              'link_type' => 'Proposal Send',
              'proposal_id' => $proposalData->sno,
              'created_by' => $user_id,
              'updated_by' => $user_id,
            ]);
          }
        }

        $proposalUrl = DB::table('et_proposal')->where('et_proposal.sno', $add_category)->first();

        $shortsendUrl = $proposalUrl->temp_send_link;

        $proposal_key = basename($shortsendUrl);


        $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

        $cre = StaffModel::where('sno', $proposalData->created_by)->orderBy('sno', 'desc')->first();


        $cre_mobile = $cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;

        $lead_name = $customer->cus_name ?? $leadData->lead_name;
        $lead_email_id = $customer->cus_email_id ?? $leadData->lead_email_id;
        $lead_mobile = $customer->cus_mobile ?? $leadData->lead_mobile;
        // // sms proposal send
        if ($communicationStatus->sms == 0) {
          if ($lead_mobile) {

            $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', 'PhDiZone_Enquiry_Thankyou_Message')->first();
            $authkey = $result_sms ? $result_sms->authkey : '';
            $sender_id = $result_sms ? $result_sms->sender_id : '';
            $template_id = $result_sms ? $result_sms->template_id : '';
            $country_code = $result_sms ? $result_sms->country_code : '';
            $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
            $mobile_number = $country_code . $lead_mobile;


            $proposal_sms_id = $proposalData->proposal_id ?? 'PRO-00001/06/2025';

            // Replace placeholders with actual values
            $replacement_values = [$lead_name, $proposal_sms_id, $shortsendUrl, $cre_mobile];
            $message_content = preg_replace_callback(
              '/\{#var#\}/',
              function () use (&$replacement_values) {
                return array_shift($replacement_values);
              },
              $message_content
            );

            $route = "default";
            $postData = array(
              'authkey' => $authkey,
              'mobiles' => $mobile_number,
              'message' => $message_content,
              'sender' => $sender_id,
              'route' => $route,
            );

            // API URL
            $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

            // Initialize the resource
            $ch = curl_init();
            curl_setopt_array($ch, array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_POST => true,
              CURLOPT_POSTFIELDS => $postData,
              CURLOPT_SSL_VERIFYHOST => 0,
              CURLOPT_SSL_VERIFYPEER => 0,
            ));

            // Get response
            $response = curl_exec($ch);
            // return $response;
            $err = curl_error($ch);
            curl_close($ch);
          }
        }

        // email proposal Send
        if ($communicationStatus->email == 0) {
          if ($lead_email_id) {
            $emailTemplate_id = 1; // proposal send Template Id
            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();

            // Gender condition
            $genderPrefix = 'Mr/Ms'; // Default value
            if ($leadData->lead_gender == 1) {
              $genderPrefix = 'Mr';
            } elseif ($leadData->lead_gender == 2) {
              $genderPrefix = 'Ms';
            }




            $content = $emailTemplate->email_subject;

            $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);

            $content = str_replace('#customer_name', $lead_name, $content);
            $content = str_replace('#proposal_id', $proposalData->proposal_id ?? 'PRO-00001/06/2025', $content);
            $content = str_replace('#link', $shortsendUrl, $content);
            $content = str_replace('#entity_name',  $entityData ? $entityData->entity_name :  'Elysium Technology', $content);
            $content = str_replace('#CREname', $cre->nick_name ?? "Alex", $content);
            $content = str_replace('#customer_care_no',  $cre_mobile ?? '8220011465', $content);
            $branchNo = $branch->mobile;
            $branchemail = $branch->mail;
            $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone/';
            $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
            $url = 'phdizone.com';

            $mailData = [
              'url'         => $url,
              'subject'     => $dynamicSubject,
              'content'     => $content,
              'branchNo'    => $branchNo,
              'branchemail' => $branchemail, // Use the message content from the request
              'fbLink'      => $fbLink,      // Use the message content from the request
              'instaLink'   => $instaLink,   // Use the message content from the request
              'salesMobile' => $cre_mobile ?? '8220011465',
            ];

            $to_address = $lead_email_id;
            $from_address = 'elysiumtechnology@elysium.community';
            $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';


            Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
          }
        }
        // whatsapp proposal send
        if ($communicationStatus->whatsapp == 0) {
          if ($lead_mobile) {


            // $templateName  = "hello_world";
            $templateName  = "proposal_phdizone";

            $hasHeader  = false; // Example flag: set based on template
            $hasBody    = false; // Example flag: set based on template
            $hasFooter  = false; // Example flag: set based on template
            $hasButton  = false;
            $components = [];
            $couponCode = " ";
            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
            // $currentHour = date('H'); // Get current hour in 24-hour format
            if ($currentHour >= 5 && $currentHour < 12) {
              $greeting = 'Good Morning';
            } elseif ($currentHour >= 12 && $currentHour < 18) {
              $greeting = 'Good Afternoon';
            } else {
              $greeting = 'Good Evening';
            }

            if ($templateName == 'proposal_phdizone') {
              $headerImage = url('public/assets/phdizone_images/OnBoard.jpg');
              $couponCode  = 'NOOFFER';
              $buttonIndex = 1;
              $bodyText    = [
                [
                  'type'           => 'text',
                  'text'           => $lead_name,
                  'parameter_name' => 'customer_name',
                ],
                [
                  'type'           => 'text',
                  'text'           => $proposalData->proposal_id,
                  'parameter_name' => 'proposal_id',
                ],
                [
                  'type'           => 'text',
                  'text'           => $proposal_key,
                  'parameter_name' => 'proposal_key',
                ],
                [
                  'type'           => 'text',
                  'text'           => $cre_mobile ?? '8220011465',
                  'parameter_name' => 'customercare_number',
                ],
              ];
              $hasHeader = true;
              $hasBody   = true;
              $hasButton = true;
            }

            // Add Header if required
            if ($hasHeader) {
              $components[] = [
                'type'       => 'header',
                'parameters' => [
                  [
                    'type'  => 'image',
                    'image' => [
                      'link' => $headerImage, // Dynamically set header image
                    ],
                  ],
                ],
              ];
            }

            // Add Body if required
            if ($hasBody) {
              $components[] = [
                'type'       => 'body',
                'parameters' => $bodyText,
              ];
            }

            // Add Footer if required
            if ($hasButton) {
              $components[] = [
                'type'       => 'button',
                'sub_type'   => 'url',
                'index'      => 0,
                'parameters' => [
                  [
                    'type' => 'text',
                    'text' => $proposal_key,
                  ],
                ],
              ];
            }


            $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id', $entity_id)->orderBy('sno', 'desc')->first();
            $dynamicParameters         = $templateParameters[$templateName] ?? [];
            $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
            $accessToken               = $whatsappApi->access_tokken ?? '';
            $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';

            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

            $countryCode  = $leadData->inter_calls ? ($leadData->inter_calls == 0 ? '+91' : '+' . $leadData->inter_calls) : '+91';
            $to           = $lead_mobile;
            $languageCode = 'en';

            if (strpos($to, $countryCode) !== 0) {
              $to = $countryCode . $to;
            }

            $message = 'test~message';
            if (empty($components)) {
              $payload = [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'template',
                'template'          => [
                  'name'     => $templateName,
                  'language' => [
                    'code' => $languageCode,
                  ],
                ],
              ];
            } else {
              $payload = [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'template',
                'template'          => [
                  'name'       => $templateName,
                  'language'   => [
                    'code' => $languageCode,
                  ],
                  'components' => $components,
                ],
              ];
            }

            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            if ($response['status'] == 200) {
            } else {
              return response([
                'status' => 404,
                'message' => 'Failed to send message',
                'error_msg' => $response['error'],
              ], 400);
            }
          }
        }
      } else {
        $old_customer_check = 1;
        if (!$proposalData->temp_send_link) {
          //  Skip Communication For Old Customer
          DB::table('et_proposal')
            ->where('sno', $add_category)
            ->update([
              'temp_send_link' => $Link,
              'old_customer_check' => $old_customer_check,
            ]);
        }
      }
    }

    if ($add_category) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Proposal Created Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Create the Proposal!'
      ]);
    }
    return redirect('customer_management/manage_proposal');
  }

//   public function CustomerProposal(Request $request)
//   {
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;
//     $user_id   = $request->user()->user_id;
//     $branch_id = $request->user()->branch_id;
//     $entity_id = $request->user()->entity_id;

//     $startTime = microtime(true);

//     $lead_fill           = $request->lead_fill ?? '';

//     $latestProposalPerLead = DB::table('et_proposal')
//       ->select(DB::raw('MAX(sno) as latest_sno'))
//       ->where('branch_id', $branch_id)
//       ->where('post_sale_check', 1)
//       ->where('status', '!=', 2)
//       ->groupBy('parent_id');

//     // Main query: join with et_proposal again to get full rows
//     $proposal_list = DB::table('et_proposal')
//       ->joinSub($latestProposalPerLead, 'latest', function ($join) {
//         $join->on('et_proposal.sno', '=', 'latest.latest_sno');
//       })
//       ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
//       // ->leftJoin('et_chotta_links', 'et_chotta_links.proposal_id', '=', 'et_proposal.sno')
//       ->select('et_proposal.*', 'et_lead.lead_name', 'et_lead.lead_mobile', 'et_lead.lead_email_id', 'et_lead.registered_date', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
//       ->where('et_proposal.status', '!=', 2)
//       ->where('et_proposal.post_sale_check', 1)
//       ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//       ->where('et_lead.status', '!=', 2)
//       ->orderBy('et_proposal.sno', 'desc')
//       ->distinct('et_proposal.sno');

//     if ($lead_fill != '') {
//       $proposal_list->where(function ($query) use ($lead_fill) {
//         $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
//           ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
//           ->orWhere('et_proposal.proposal_id', 'LIKE', "%{$lead_fill}%")
//           ->orWhere('et_proposal.service_title', 'LIKE', "%{$lead_fill}%")
//           ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
//       });
//     }
//     if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
//       // User can only view their own data
//       $proposal_list = $proposal_list->where('et_proposal.cre_id', $user_id);
//       // return "view_self_lead";
//     } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
//       // User can view all data
//       $proposal_list = $proposal_list;
//       // return "global_lead";
//     } else {
//       // No permission
//       abort(403, 'Unauthorized');
//     }


//     $proposal_list = $proposal_list->paginate($perpage);

//     // return $proposal_list;

//     foreach ($proposal_list as $list) {

//       $customer = DB::table('et_customer')
//         ->select(
//           'et_customer.*',
//           'et_cities.name as city_name',
//           'et_countries.name as country_name',
//           'et_states.name as state_name'
//         )
//         ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
//         ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
//         ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
//         ->where('et_customer.sno', $list->customer_id)
//         ->where('et_customer.status', '!=', 2)
//         ->orderBy('et_customer.sno', 'desc')
//         ->first();

//       $list->lead_name         = $customer->cus_name        ?? $list->lead_name        ?? '';
//       $list->lead_door_no      = $customer->door_no         ?? $list->door_no          ?? '';
//       $list->lead_address      = $customer->address         ?? $list->address          ?? '';
//       $list->lead_city_name    = $customer->city_name       ?? $list->city_name        ?? '';
//       $list->lead_state_name   = $customer->state_name      ?? $list->state_name       ?? '';
//       $list->lead_country_name = $customer->country_name    ?? $list->country_name     ?? '';
//       $list->lead_pincode      = $customer->pincode         ?? $list->pincode          ?? '';
//       $list->lead_email_id         = $customer->cus_email_id    ?? $list->lead_email_id    ?? '';
//       $list->lead_mobile       = $customer->cus_mobile      ?? $list->lead_mobile      ?? '';

//       $proposal_payment = DB::table('et_proposal_pay_slot')
//         ->where('et_proposal_pay_slot.proposal_sno', $list->sno)
//         ->where('et_proposal_pay_slot.status', '!=', 2)
//         ->where('et_proposal_pay_slot.paid_status', 1)
//         ->get();
//       $paid_amount = $proposal_payment->sum('paidAmount');

//       $list->total_paidAmount = $paid_amount ?? 0;

//       $proposal_data = DB::table('et_proposal')
//         ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
//         ->select('et_proposal.*', 'et_lead.lead_name', 'et_lead.lead_mobile', 'et_lead.registered_date', 'et_lead.lead_email_id', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
//         ->where('et_proposal.parent_id', $list->parent_id)
//         ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//         ->where('et_proposal.status', '!=', 2)
//         ->where('et_lead.status', '!=', 2)
//         ->where('et_proposal.post_sale_check', 1)
//         ->orderBy('et_proposal.sno', 'desc')
//         ->get();
//       foreach ($proposal_data as $prlist) {
//         if ($prlist->discount_id > 0) {
//           $discount = DB::table('et_manage_coupon')->where('et_manage_coupon.sno', $prlist->discount_id)->first();

//           $prlist->discount_value = $discount->coupon_value;
//           $prlist->coupon_code = $discount->coupon_code;
//           $prlist->discount_type = $discount->coupon_type == 'percentage' ? '1' : '2';
//         } else {
//           $prlist->discount_value = null;
//           $prlist->discount_type = null;
//           $prlist->coupon_code = null;
//         }
//       }
//       $list->proposal_data = $proposal_data;
//     }

// $dashboardQuery = DB::table('et_proposal')
//     ->joinSub($latestProposalPerLead, 'latest', function ($join) {
//         $join->on('et_proposal.sno', '=', 'latest.latest_sno');
//     })
//     ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
//     ->where('et_proposal.status', 0)
//     ->where('et_proposal.post_sale_check', 1)
//     ->where('et_lead.status', '!=', 2)
//     ->where('et_lead.created_by', '>', 1);

//     if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {

//     $dashboardQuery->where('et_proposal.cre_id', $user_id);

// } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {

//     abort(403, 'Unauthorized');
// }

//     $dashboardData = (clone $dashboardQuery)
//     ->selectRaw("
//         COUNT(*) as total_proposals,
//         SUM(CASE WHEN proposal_status = 0 THEN 1 ELSE 0 END) as pending_proposals,
//         SUM(CASE WHEN proposal_status IN (1,3) THEN 1 ELSE 0 END) as accepted_proposals,
//         SUM(CASE WHEN proposal_status = 2 THEN 1 ELSE 0 END) as rejected_proposals,
//         SUM(CASE WHEN proposal_status = 5 THEN 1 ELSE 0 END) as completed_proposals,
//       SUM(
//           CASE
//               WHEN MONTH(et_proposal.created_at) = MONTH(CURDATE())
//               AND YEAR(et_proposal.created_at) = YEAR(CURDATE())
//               THEN 1
//               ELSE 0
//           END
//       ) as this_month_proposals
//     ")
//     ->first();
//     return view('content.customer_management.manage_proposal.proposal_list', [
//       'proposal_list' => $proposal_list,
//       'lead_fill' => $lead_fill,
//       'perpage' => $perpage,
//       'dashboardData' => $dashboardData,

//     ]);
//   }

public function CustomerProposal(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $entity_id = $request->user()->entity_id;
  $status_filter = $request->status_filter ?? '';
    $startTime = microtime(true);
 
    $lead_fill           = $request->lead_fill ?? '';
 
    $latestProposalPerLead = DB::table('et_proposal')
      ->select(DB::raw('MAX(sno) as latest_sno'))
      ->where('branch_id', $branch_id)
      ->where('post_sale_check', 1)
      ->where('status', '!=', 2)
      ->groupBy('parent_id');
 
    // Main query: join with et_proposal again to get full rows
    $proposal_list = DB::table('et_proposal')
      ->joinSub($latestProposalPerLead, 'latest', function ($join) {
        $join->on('et_proposal.sno', '=', 'latest.latest_sno');
      })
      ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
      // ->leftJoin('et_chotta_links', 'et_chotta_links.proposal_id', '=', 'et_proposal.sno')
      ->select('et_proposal.*', 'et_lead.lead_name', 'et_lead.lead_mobile', 'et_lead.lead_email_id', 'et_lead.registered_date', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
      ->where('et_proposal.status', '!=', 2)
      ->where('et_proposal.post_sale_check', 1)
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_lead.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->distinct('et_proposal.sno');
 
    if ($lead_fill != '') {
      $proposal_list->where(function ($query) use ($lead_fill) {
        $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_proposal.proposal_id', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_proposal.service_title', 'LIKE', "%{$lead_fill}%")
          ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
      // User can only view their own data
      $proposal_list = $proposal_list->where('et_proposal.cre_id', $user_id);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
      // User can view all data
      // $proposal_list = $proposal_list;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }
      if ($status_filter != '') {
 
                switch ($status_filter) {
 
                    case 'pending':
                        $proposal_list->where('et_proposal.proposal_status', 0);
                        break;
 
                    case 'accepted':
                        $proposal_list->whereIn('et_proposal.proposal_status', [1, 3]);
                        break;
 
                    case 'rejected':
                        $proposal_list->where('et_proposal.proposal_status', 2);
                        break;
 
                    case 'completed':
                        $proposal_list->where('et_proposal.proposal_status', 5);
                        break;
 
                    case 'converted':
                        $proposal_list->where('et_proposal.proposal_status', '>', 3);
                        break;
 
                    case 'this_month':
                        $proposal_list
                            ->whereMonth('et_proposal.created_at', now()->month)
                            ->whereYear('et_proposal.created_at', now()->year);
                        break;
                }
            }
 
    $proposal_list = $proposal_list->paginate($perpage);
 
    // return $proposal_list;
 
    foreach ($proposal_list as $list) {
 
      $customer = DB::table('et_customer')
        ->select(
          'et_customer.*',
          'et_cities.name as city_name',
          'et_countries.name as country_name',
          'et_states.name as state_name'
        )
        ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
        ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
        ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
        ->where('et_customer.sno', $list->customer_id)
        ->where('et_customer.status', '!=', 2)
        ->orderBy('et_customer.sno', 'desc')
        ->first();
 
      $list->lead_name         = $customer->cus_name        ?? $list->lead_name        ?? '';
      $list->lead_door_no      = $customer->door_no         ?? $list->door_no          ?? '';
      $list->lead_address      = $customer->address         ?? $list->address          ?? '';
      $list->lead_city_name    = $customer->city_name       ?? $list->city_name        ?? '';
      $list->lead_state_name   = $customer->state_name      ?? $list->state_name       ?? '';
      $list->lead_country_name = $customer->country_name    ?? $list->country_name     ?? '';
      $list->lead_pincode      = $customer->pincode         ?? $list->pincode          ?? '';
      $list->lead_email_id         = $customer->cus_email_id    ?? $list->lead_email_id    ?? '';
      $list->lead_mobile       = $customer->cus_mobile      ?? $list->lead_mobile      ?? '';
 
      $proposal_payment = DB::table('et_proposal_pay_slot')
        ->where('et_proposal_pay_slot.proposal_sno', $list->sno)
        ->where('et_proposal_pay_slot.status', '!=', 2)
        ->where('et_proposal_pay_slot.paid_status', 1)
        ->get();
      $paid_amount = $proposal_payment->sum('paidAmount');
 
      $list->total_paidAmount = $paid_amount ?? 0;
 
      $proposal_data = DB::table('et_proposal')
        ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
        ->select('et_proposal.*', 'et_lead.lead_name', 'et_lead.lead_mobile', 'et_lead.registered_date', 'et_lead.lead_email_id', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
        ->where('et_proposal.parent_id', $list->parent_id)
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->where('et_proposal.status', '!=', 2)
        ->where('et_lead.status', '!=', 2)
        ->where('et_proposal.post_sale_check', 1)
        ->orderBy('et_proposal.sno', 'desc')
        ->get();
      foreach ($proposal_data as $prlist) {
        if ($prlist->discount_id > 0) {
          $discount = DB::table('et_manage_coupon')->where('et_manage_coupon.sno', $prlist->discount_id)->first();
 
          $prlist->discount_value = $discount->coupon_value;
          $prlist->coupon_code = $discount->coupon_code;
          $prlist->discount_type = $discount->coupon_type == 'percentage' ? '1' : '2';
        } else {
          $prlist->discount_value = null;
          $prlist->discount_type = null;
          $prlist->coupon_code = null;
        }
      }
      $list->proposal_data = $proposal_data;
    }
 
$dashboardQuery = DB::table('et_proposal')
    ->joinSub($latestProposalPerLead, 'latest', function ($join) {
        $join->on('et_proposal.sno', '=', 'latest.latest_sno');
    })
    ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
    ->where('et_proposal.status', 0)
    ->where('et_proposal.post_sale_check', 1)
    ->where('et_lead.status', '!=', 2)
    ->where('et_lead.created_by', '>', 1);
 
    if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
 
    $dashboardQuery->where('et_proposal.cre_id', $user_id);
 
} elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
 
    abort(403, 'Unauthorized');
}
 
    $dashboardData = (clone $dashboardQuery)
    ->selectRaw("
        COUNT(*) as total_proposals,
        SUM(CASE WHEN proposal_status = 0 THEN 1 ELSE 0 END) as pending_proposals,
        SUM(CASE WHEN proposal_status IN (1,3) THEN 1 ELSE 0 END) as accepted_proposals,
        SUM(CASE WHEN proposal_status = 2 THEN 1 ELSE 0 END) as rejected_proposals,
        SUM(CASE WHEN proposal_status = 5 THEN 1 ELSE 0 END) as completed_proposals,
       SUM(
          CASE
              WHEN MONTH(et_proposal.created_at) = MONTH(CURDATE())
              AND YEAR(et_proposal.created_at) = YEAR(CURDATE())
              THEN 1
              ELSE 0
          END
      ) as this_month_proposals
    ")
    ->first();
    return view('content.customer_management.manage_proposal.proposal_list', [
      'proposal_list' => $proposal_list,
      'lead_fill' => $lead_fill,
      'perpage' => $perpage,
       'dashboardData' => $dashboardData,
 
    ]);
  }


  public function customer_add()
  {
    return view('content.customer_management.manage_customer.customer_add');
  }

  public function customer_edit()
  {
    return view('content.customer_management.manage_customer.customer_edit');
  }

  public function payment()
  {
    return view('content.customer_management.manage_customer.payment');
  }
  public function customer_quotation()
  {
    return view('content.customer_management.manage_customer.customer_quotation');
  }
  public function customer_invoice($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $customer_id = $decryptedValue;

    $customer = DB::table('et_customer')->where('et_customer.sno', $customer_id)->first();

    $proposal_ids = json_decode($customer->proposal_ids);

    $proposal_list = DB::table('et_proposal')
      ->select('et_proposal.*')
      ->whereIn('et_proposal.sno', $proposal_ids)
      ->where('et_proposal.status', '!=', 2)
      ->get();



    return view('content.customer_management.manage_customer.customer_invoice', [
      'customer' => $customer,
      'proposal_list' => $proposal_list,
    ]);
  }

  public function PaymentSlotByProposalId(Request $request)
  {

    $prps_id = $request->id;

    $proposal = DB::table('et_proposal')
      ->select('et_proposal.*', 'et_staff.nick_name', 'et_staff.nick_name', 'et_entity.entity_name', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
      ->where('et_proposal.sno', $prps_id)
      ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
      ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
      ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->first();


    $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
      ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
      ->where('et_proposal_pay_slot.proposal_id', $proposal->proposal_id)
      ->where('et_proposal_pay_slot.status', 0)
      ->get();
    $slot_total = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
      ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
      ->where('et_proposal_pay_slot.proposal_id', $proposal->proposal_id)
      ->where('et_proposal_pay_slot.status', 0)
      ->first();
    $firstNotPaidFound = false;
    foreach ($slots as $slt) {

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($slt->sno, 'encrypt');
      $slt->encrypt_slot_id = $encrypted_values;

      $slt->generate_status = 0;
      if ($slt->paid_status == 1) {
        $slt->generate_status = 0;
        continue;
      }

      if (!$firstNotPaidFound) {
        // Mark first unpaid slot
        $slt->generate_status = 1;
        $firstNotPaidFound = true;
      } else {
        $slt->generate_status = 0;
      }
    }

    $PaidAmount = $slots->sum('paidAmount');
    $total_balance = $slot_total->total_amount ? $slot_total->total_amount - $PaidAmount : 0;
    $branch_data = DB::table('et_branch')
      ->select(
        'et_branch.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
      ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
      ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
      ->where('et_branch.sno', $proposal->branch_id)
      ->first();



    $lead = DB::table('et_customer_services')->select('et_customer.*')
      ->join('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
      ->where('et_customer_services.proposal_id', $proposal->sno)
      ->first();

    return response()->json([
      'status' => 200,
      'message' => 'package Slot details Successfull',
      'error_msg' => null,
      'data' => $slots,
      'proposal' => $proposal,
      'total_balance' => $total_balance,
      'total_paid' => $PaidAmount,
      'branch_data' => $branch_data,
      'cus' => $lead,
    ]);
  }

  public function customer_invoice_add()
  {
    return view('content.customer_management.manage_customer.customer_invoice_add');
  }
  public function Edit($id = '')
  {
    $data = CustomerModel::where('sno', $id)->where('status', '!=', 2)->first();

    if ($data) {
      return response([
        'status' => 200,
        'message' => 'Data Fetched Successfully!',
        'error_msg' => null,
        'data' => $data
      ], 200);
    } else {
      return response([
        'status' => 401,
        'message' => 'No Records Found!',
        'error_msg' => null,
        'data' => null
      ], 401);
    }
  }

  public function Update(Request $request)
  {
      
    $validator = Validator::make($request->all(), [
      'edit_cus_name' => 'required|string'
    ]);

    if ($validator->fails()) {
      return response([
        'status' => 422,
        'message' => 'Incorrect Input Field Format',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null
      ], 422);
    }
   
    $name = $request->edit_cus_name;
    $sno = $request->edit_id;

    $check = CustomerModel::where('cus_name', $name)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();
    // return $request;
    
    
    $UPDATE = CustomerModel::where('status', '!=', 2)->where('sno', $sno)->first();
    // return $UPDATE;
    $UPDATE->cus_name = $name;
    $UPDATE->cus_gender = $request->edit_cus_gender;
    $UPDATE->cus_dob = $request->edit_cus_dob;
    $UPDATE->country_code = $request->country_code_name_edit;
    $UPDATE->cus_mobile = $request->cus_edit_mobile;
    $UPDATE->cus_email_id = $request->edit_cus_email;
    $UPDATE->cus_alternate_mobile = $request->cus_edit_alt_mobile;
    $UPDATE->country = $request->country_edit;
    $UPDATE->state = $request->state_edit;
    $UPDATE->city = $request->city_edit;
    $UPDATE->door_no = $request->door_no;
    $UPDATE->address = $request->address;
    $UPDATE->pincode = $request->pincode;
    $UPDATE->update();

    if ($UPDATE) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Customer Updated Successfully'
      ]);

      return redirect()->back();
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Customer Updation Failed'
      ]);

      return redirect()->back();
    }
  }
  public function CustomerCredentials($id = '')
  {
    $credentials = DB::table('et_pass_locker')
      ->select('et_pass_locker.user_name', 'et_pass_locker.password', 'et_pass_locker.status', 'et_pass_locker.link', 'et_type.type_name')
      ->leftJoin('et_type', 'et_type.sno', '=', 'et_pass_locker.type_id')
      ->where('et_pass_locker.customer_id', $id)
      ->get();

    $customer = CustomerModel::select('sno', 'cus_name', 'cus_mobile', 'cus_email_id')->where('sno', $id)->first();

    if ($customer) {
      return response([
        'status' => 200,
        'message' => 'Credentials Fetched Successfully',
        'error_msg' => null,
        'data' => [
          'credentials' => $credentials,
          'customer' => $customer
        ]
      ], 200);
    } else {
      return response([
        'status' => 302,
        'message' => 'No Records Found!',
        'error_msg' => null,
        'data' => null
      ], 302);
    }
  }

//   public function AddCredentials(Request $request)
//   {
//     $validator = Validator::make($request->all(), [
//       'link' => 'required|array'
//     ]);

//     if ($validator->fails()) {
//       return response([
//         'status' => 404,
//         'message' => 'Incorrect Input Field Format',
//         'error_msg' => $validator->messages()->get('*'),
//         'data' => null
//       ], 404);
//     }

//     $user_id = $request->user()->user_id;
//     $emails = $request->input('email', []);
//     $passwords = $request->input('password', []);
//     $links = $request->input('link', []);
//     $types = $request->input('type', []);

//     if (is_array($emails) && is_array($passwords) && is_array($links) && is_array($types)) {
//       foreach ($emails as $index => $email) {
//         $password = $passwords[$index] ?? null;
//         $link  = $links[$index] ?? null;
//         $type = $types[$index] ?? null;
//         if (empty($email) || empty($password) || empty($link) || empty($type)) {
//           continue;
//         }

//         $credential = new PassLockerModel();
//         $credential->customer_id = $request->customer_id;
//         $credential->user_name = $email;
//         $credential->link = $link;
//         $credential->type_id = $type;
//         $credential->password = $password;
//         $credential->created_by = $user_id;
//         $credential->updated_by = $user_id;
//         $credential->save();
//       }
//     }

//     if ($credential) {
//       session()->flash('toastr', [
//         'type' => 'success',
//         'message' => 'Credentials Added Successfully !'
//       ]);

//       return redirect()->back();
//     }
//   }

public function AddCredentials(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'link' => 'required|array'
    ]);
 
    if ($validator->fails()) {
      return response([
        'status' => 404,
        'message' => 'Incorrect Input Field Format',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null
      ], 404);
    }
  $credential = null;
    $user_id = $request->user()->user_id;
    $emails = $request->input('email', []);
    $passwords = $request->input('password', []);
    $links = $request->input('link', []);
    $types = $request->input('type', []);
    if (is_array($emails) && is_array($passwords) && is_array($links) && is_array($types)) {
      foreach ($emails as $index => $email) {
        $password = $passwords[$index] ?? null;
        $link  = $links[$index] ?? null;
        $type = $types[$index] ?? null;
        if (empty($email) || empty($password) || empty($link) || empty($type)) {
          continue;
        }
 
        $credential = new PassLockerModel();
        $credential->customer_id = $request->customer_id;
        $credential->user_name = $email;
        $credential->link = $link;
        $credential->type_id = $type;
        $credential->password = $password;
        $credential->created_by = $user_id;
        $credential->updated_by = $user_id;
        $credential->save();
      }
    }
 
    if ($credential) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Credentials Added Successfully !'
      ]);
 
      return redirect()->back();
    }else{
       session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Oops! Creating Credentials Failed'
      ]);
 
      return redirect()->back();
    }
  }
  
  public function NotStartedCustomerList(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $entity_id = $request->user()->entity_id;

    $search_fill = $request->search_fill ?? '';

    // Base query for customers joined with lead, excluding status=2
    $customersQuery = DB::table('et_customer')
      ->select('et_customer.*')
      ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->leftJoin('et_customer_services', function ($join) {
        $join->on('et_customer_services.customer_id', '=', 'et_customer.sno');
      })
      ->whereRaw('et_customer_services.status = ?', [0])
      ->where('et_customer.status', '!=', 2)
      ->where('et_lead.status', '!=', 2)
      ->whereNot('et_proposal.proposal_status', [0, 2])
      ->where('et_customer.branch_id', $branch_id)->distinct('et_proposal.customer_id');;


    if (!empty($search_fill)) {
      $customersQuery->where(function ($query) use ($search_fill) {
        $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
      });
    }

    if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
      // User can only view their own data
      $customersQuery = $customersQuery->where('et_proposal.cre_id', $user_id);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
      // User can view all data
      $customersQuery = $customersQuery;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }

    $customers = $customersQuery->orderBy('et_customer.sno', 'desc')
      ->paginate($perpage);

    foreach ($customers as $customer) {
      $proposal_ids = json_decode($customer->proposal_ids, true);

      if (empty($proposal_ids) || !is_array($proposal_ids)) {
        $customer->proposal_data = collect();
        continue;
      }

      $proposal_data = DB::table('et_proposal')
        ->whereIn('et_proposal.sno', $proposal_ids)
        ->where('et_proposal.status', '!=', 2)
        ->orderBy('et_proposal.sno', 'desc')
        ->get();

      foreach ($proposal_data as $proposal) {
        $service_data = DB::table('et_customer_services')
          ->where('proposal_id', $proposal->sno)
          ->orderBy('sno', 'desc')
          ->first();
        $proposal->customer_service_id = $service_data->sno;
        if ($proposal->product_package == 2) {
          // For package type proposals
          $package = DB::table('et_package')
            ->where('sno', $proposal->package_id)
            ->where('status', '!=', 2)
            ->orderBy('sno', 'desc')
            ->first();


          $package_slots = DB::table('et_proposal_pay_slot')
            ->where('proposal_sno', $proposal->sno)
            ->where('status', 0)
            ->get();
          $product_slots_paid = $package_slots->sum('paidAmount');
          $proposal->package_name = $package->package_name ?? null;
          $proposal->package_slot = $package_slots;
          $proposal->product_slots_paid = $product_slots_paid;
        } else {
          // For product type proposals
          $products = DB::table('et_proposal_product_cart')
            ->select('et_product.product_name', 'et_product_category.product_category_name', 'et_proposal_product_cart.cart_id')
            ->join('et_product', 'et_product.sno', '=', 'et_proposal_product_cart.product_id')
            ->join('et_product_category', 'et_product_category.sno', '=', 'et_product.product_category_id')
            ->where('et_proposal_product_cart.proposal_sno', $proposal->sno)
            ->where('et_proposal_product_cart.status', 0)
            ->get();
          $product_slots_paid = 0;
          foreach ($products as $product) {
            $product_slots = DB::table('et_proposal_pay_slot')
              ->where('et_proposal_pay_slot.product_cart_id', $product->cart_id)
              ->where('et_proposal_pay_slot.status', 0)
              ->get();
            $product_slots_paid += $product_slots->sum('paidAmount');
            $product->product_slot = $product_slots;
          }

          $proposal->product_slots_paid = $product_slots_paid;
          $proposal->services = $products;
        }
      }

      $customer->proposal_data = $proposal_data;
    }

    // return $customers;

    return view('content.customer_management.manage_customer.notstarted_customer', [
      'customers' => $customers,
      'search_fill' => $search_fill,
      'perpage' => $perpage,
    ]);
  }

  //   public function PostSaleCustomerList(Request $request)
  //   {
  //     $page = $request->input('page', 1);
  //     $perpage = (int) $request->input('sorting_filter', 25);
  //     $offset = ($page - 1) * $perpage;

  //     $user_id = $request->user()->user_id;
  //     $branch_id = $request->user()->branch_id;
  //     $entity_id = $request->user()->entity_id;

  //     $search_fill = $request->search_fill ?? '';

  //     // Base query for customers joined with lead, excluding status=2
  //     $customersQuery = DB::table('et_customer')
  //       ->select('et_customer.*')
  //       ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
  //       ->where('et_customer.post_sale_check', 1)
  //       ->where('et_customer.status', '!=', 2)
  //       ->where('et_customer.branch_id', $branch_id);

  //     if (!empty($search_fill)) {
  //       $customersQuery->where(function ($query) use ($search_fill) {
  //         $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
  //           ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
  //           ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
  //           ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
  //       });
  //     }

  //     $customers = $customersQuery->orderBy('et_customer.sno', 'desc')
  //       ->paginate($perpage);

  //     foreach ($customers as $customer) {
  //       $proposal_ids = json_decode($customer->proposal_ids, true);

  //       if (empty($proposal_ids) || !is_array($proposal_ids)) {
  //         $customer->proposal_data = collect();
  //         continue;
  //       }

  //       $proposal_data = DB::table('et_proposal')
  //         ->whereIn('et_proposal.sno', $proposal_ids)
  //         ->where('et_proposal.status', '!=', 2)
  //         ->orderBy('et_proposal.sno', 'desc')
  //         ->get();

  //       foreach ($proposal_data as $proposal) {
  //         $service_data = DB::table('et_customer_services')
  //           ->where('proposal_id', $proposal->sno)
  //           ->orderBy('sno', 'desc')
  //           ->first();
  //         $proposal->customer_service_id = $service_data->sno;
  //         if ($proposal->product_package == 2) {
  //           // For package type proposals
  //           $package = DB::table('et_package')
  //             ->where('sno', $proposal->package_id)
  //             ->where('status', '!=', 2)
  //             ->orderBy('sno', 'desc')
  //             ->first();


  //           $package_slots = DB::table('et_proposal_pay_slot')
  //             ->where('proposal_sno', $proposal->sno)
  //             ->where('status', 0)
  //             ->get();
  //           $product_slots_paid = $package_slots->sum('paidAmount');
  //           $proposal->package_name = $package->package_name ?? null;
  //           $proposal->package_slot = $package_slots;
  //           $proposal->product_slots_paid = $product_slots_paid;
  //         } else {
  //           // For product type proposals
  //           $products = DB::table('et_proposal_product_cart')
  //             ->select('et_product.product_name', 'et_product_category.product_category_name', 'et_proposal_product_cart.cart_id')
  //             ->join('et_product', 'et_product.sno', '=', 'et_proposal_product_cart.product_id')
  //             ->join('et_product_category', 'et_product_category.sno', '=', 'et_product.product_category_id')
  //             ->where('et_proposal_product_cart.proposal_sno', $proposal->sno)
  //             ->where('et_proposal_product_cart.status', 0)
  //             ->get();
  //           $product_slots_paid = 0;
  //           foreach ($products as $product) {
  //             $product_slots = DB::table('et_proposal_pay_slot')
  //               ->where('et_proposal_pay_slot.product_cart_id', $product->cart_id)
  //               ->where('et_proposal_pay_slot.status', 0)
  //               ->get();
  //             $product_slots_paid += $product_slots->sum('paidAmount');
  //             $product->product_slot = $product_slots;
  //           }

  //           $proposal->product_slots_paid = $product_slots_paid;
  //           $proposal->services = $products;
  //         }
  //       }

  //       $customer->proposal_data = $proposal_data;
  //     }

  //     // return $customers;

  //     return view('content.customer_management.manage_customer.post_sale_customer', [
  //       'customers' => $customers,
  //       'search_fill' => $search_fill,
  //       'perpage' => $perpage,
  //     ]);
  //   }

//   public function PostSaleCustomerList(Request $request)
//   {
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;

//     $user_id = $request->user()->user_id;
//     $branch_id = $request->user()->branch_id;
//     $entity_id = $request->user()->entity_id;

//     $search_fill = $request->search_fill ?? '';

//     // Base query for customers joined with lead, excluding status=2
//     $customersQuery = DB::table('et_customer')
//       ->select('et_customer.*')
//       ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//       ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
//       ->where('et_customer.status', '!=', 2)
//       ->where('et_customer.post_sale_check', 1)
//       ->whereNot('et_proposal.proposal_status', [0, 2])
//       ->where('et_lead.status', '!=', 2)
//       ->where('et_customer.branch_id', $branch_id)->distinct('et_proposal.customer_id');

//     if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
//       // User can only view their own data
//       $customersQuery = $customersQuery->where('et_proposal.cre_id', $user_id);
//       // return "view_self_lead";
//     } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
//       // User can view all data
//       $customersQuery = $customersQuery;
//       // return "global_lead";
//     } else {
//       // No permission
//       abort(403, 'Unauthorized');
//     }


//     if (!empty($search_fill)) {
//       $customersQuery->where(function ($query) use ($search_fill) {
//         $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
//           ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
//       });
//     }




//     $customers = $customersQuery->orderBy('et_customer.sno', 'desc')
//       ->paginate($perpage);

//     foreach ($customers as $customer) {
//       $proposal_ids = json_decode($customer->proposal_ids, true);

//       if (empty($proposal_ids) || !is_array($proposal_ids)) {
//         $customer->proposal_data = collect();
//         continue;
//       }

//       $proposal_data = DB::table('et_proposal')
//         ->whereIn('et_proposal.sno', $proposal_ids)
//         ->where('et_proposal.status', '!=', 2)
//         ->orderBy('et_proposal.sno', 'desc')
//         ->get();
//       $proposal_currency = DB::table('et_proposal')
//         ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
//         ->whereIn('et_proposal.sno', $proposal_ids)
//         ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//         ->where('et_proposal.status', '!=', 2)
//         ->orderBy('et_proposal.sno', 'desc')
//         ->first();
//       $customer->currency_code = $proposal_currency->currency_code;
//       $customer->currency_symbol = $proposal_currency->currency_symbol;
//       $customer->currency_country_name = $proposal_currency->country_name;

//       foreach ($proposal_data as $proposal) {
//         $service_data = DB::table('et_customer_services')
//           ->where('proposal_id', $proposal->sno)
//           ->orderBy('sno', 'desc')
//           ->first();
//         $proposal->customer_service_id = $service_data->sno;
//         if ($proposal->product_package == 2) {
//           // For package type proposals
//           $package = DB::table('et_package')
//             ->where('sno', $proposal->package_id)
//             ->where('status', '!=', 2)
//             ->orderBy('sno', 'desc')
//             ->first();


//           $package_slots = DB::table('et_proposal_pay_slot')
//             ->where('proposal_sno', $proposal->sno)
//             ->where('status', 0)
//             ->get();
//           $product_slots_paid = $package_slots->sum('paidAmount');
//           $proposal->package_name = $package->package_name ?? null;
//           $proposal->package_slot = $package_slots;
//           $proposal->product_slots_paid = $product_slots_paid;
//         } else {
//           // For product type proposals
//           $products = DB::table('et_customer_services')
//             ->select('et_product.product_name', 'et_product_category.product_category_name', 'et_customer_services.proposal_id')
//             ->join('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
//             ->join('et_product_category', 'et_product_category.sno', '=', 'et_product.product_category_id')
//             ->where('et_customer_services.proposal_id', $proposal->sno)
//             ->get();

//           $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
//             ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
//             ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
//             ->where('et_proposal_pay_slot.status', 0)
//             ->get();
//           $product_slots_paid = $product_slots->sum('paidAmount');



//           foreach ($products as $product) {
//           }

//           $proposal->product_slots_paid = $product_slots_paid;
//           $proposal->services = $products;
//           $proposal->product_slot = $product_slots;
//         }
//       }

//       $ServiceCompletedCount = DB::table('et_proposal')
//         ->where('et_proposal.customer_id', $customer->sno)
//         ->where('et_proposal.proposal_status', 5)
//         ->get();

//       $customer->completed_proposal = $ServiceCompletedCount;
//       $customer->proposal_data = $proposal_data;
//     }



//     // return $customers;
//     $types = TypeCredentialModel::where('status', 0)->get();


//     return view('content.customer_management.manage_customer.post_sale_customer', [
//       'customers' => $customers,
//       'search_fill' => $search_fill,
//       'types' => $types,
//       'perpage' => $perpage,
//     ]);
//   }

public function PostSaleCustomerList(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
 
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $entity_id = $request->user()->entity_id;
 
    $search_fill = $request->search_fill ?? '';
 
    // Base query for customers joined with lead, excluding status=2
    $customersQuery = DB::table('et_customer')
      ->select('et_customer.*')
      ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
      ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->where('et_customer.status', '!=', 2)
      ->where('et_customer.post_sale_check', 1)
      ->whereNot('et_proposal.proposal_status', [0, 2])
      ->where('et_lead.status', '!=', 2)
      ->where('et_customer.branch_id', $branch_id)->distinct('et_proposal.customer_id');
 
    if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
      // User can only view their own data
      $customersQuery = $customersQuery->where('et_proposal.cre_id', $user_id);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
      // User can view all data
      $customersQuery = $customersQuery;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }
 
 
    if (!empty($search_fill)) {
      $customersQuery->where(function ($query) use ($search_fill) {
        $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
      });
    }
 
 
 
    // -----------------------------------------
      // followupReasonList
      //
      // -----------------------------------------
      $followupReasonList = FollowupReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();
    $customers = $customersQuery->orderBy('et_customer.sno', 'desc')
      ->paginate($perpage);
 
    foreach ($customers as $customer) {
      $proposal_ids = json_decode($customer->proposal_ids, true);
 
      if (empty($proposal_ids) || !is_array($proposal_ids)) {
        $customer->proposal_data = collect();
        continue;
      }
 
      $follow_up=DB::table('et_customer_follow_up')->select('et_customer_follow_up.*')
      ->leftjoin('et_customer', 'et_customer.sno', '=', 'et_customer_follow_up.customer_id')
      ->where('et_customer_follow_up.customer_id', $customer->sno)->orderBy('et_customer_follow_up.sno','desc')->first();
     
     
      $customer->appointment_status = $follow_up->status ?? "0";
      $chk1day         = false;
      $createdAt       = Carbon::parse($customer->created_at);
      $currentDateTime = Carbon::now();
      // if ($createdAt->diffInHours($currentDateTime) >= 24) {
      //   $chk1day = true;
      // } else {
      //   $chk1day = false;
      // }
      // $customerall = DB::table('et_customer')
      // ->select(
      //   'et_customer.created_at',
      //   'et_customer.sno',
       
      // )
      // ->leftJoin(
      //   DB::raw('(
      //           SELECT
      //               customer_id,
      //               COUNT(*) as total_appointments
      //           FROM et_customer_follow_up
      //           GROUP BY customer_id
      //       ) AS appointment_counts'),
      //   'et_lead.sno',
      //   '=',
      //   'appointment_counts.customer_id'
      // );
 
      // ------------------------
      // total appointment count
      // ------------------------
      $customer->total_follow_up=CustomerFollowUpModel::where('customer_id', $customer->sno)->count();
 
      $before48Hours   = Carbon::now()->subHours(48);
      $usersWithPendingAppointments = DB::table('et_customer_follow_up')
      ->join('et_customer', 'et_customer.sno', '=', 'et_customer_follow_up.customer_id')
        ->whereIn('et_customer.status', [0])
       
        ->where('et_customer_follow_up.status', 1)
        // ->where('et_lead.is_dc', 1)
        ->where('et_customer_follow_up.branch_id', $branch_id)
        ->where('et_customer_follow_up.appointment_date', '<=', $before48Hours)
        ->distinct()
        ->pluck('et_customer_follow_up.created_by')
        ->toArray();
 
      if (in_array($customer->created_by, $usersWithPendingAppointments)) {
 
        $customer->not_closed = 0;
      } else {
        $customer->not_closed = 0;
      }
 
      $proposal_data = DB::table('et_proposal')
        ->whereIn('et_proposal.sno', $proposal_ids)
        ->where('et_proposal.status', '!=', 2)
        ->orderBy('et_proposal.sno', 'desc')
        ->get();
      $proposal_currency = DB::table('et_proposal')
        ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
        ->whereIn('et_proposal.sno', $proposal_ids)
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->where('et_proposal.status', '!=', 2)
        ->orderBy('et_proposal.sno', 'desc')
        ->first();
      $customer->currency_code = $proposal_currency->currency_code;
      $customer->currency_symbol = $proposal_currency->currency_symbol;
      $customer->currency_country_name = $proposal_currency->country_name;
 
      foreach ($proposal_data as $proposal) {
        $service_data = DB::table('et_customer_services')
          ->where('proposal_id', $proposal->sno)
          ->orderBy('sno', 'desc')
          ->first();
        $proposal->customer_service_id = $service_data->sno;
        if ($proposal->product_package == 2) {
          // For package type proposals
          $package = DB::table('et_package')
            ->where('sno', $proposal->package_id)
            ->where('status', '!=', 2)
            ->orderBy('sno', 'desc')
            ->first();
 
 
          $package_slots = DB::table('et_proposal_pay_slot')
            ->where('proposal_sno', $proposal->sno)
            ->where('status', 0)
            ->get();
          $product_slots_paid = $package_slots->sum('paidAmount');
          $proposal->package_name = $package->package_name ?? null;
          $proposal->package_slot = $package_slots;
          $proposal->product_slots_paid = $product_slots_paid;
        } else {
          // For product type proposals
          $products = DB::table('et_customer_services')
            ->select('et_product.product_name', 'et_product_category.product_category_name', 'et_customer_services.proposal_id')
            ->join('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->join('et_product_category', 'et_product_category.sno', '=', 'et_product.product_category_id')
            ->where('et_customer_services.proposal_id', $proposal->sno)
            ->get();
 
          $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
            ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->where('et_proposal_pay_slot.status', 0)
            ->get();
          $product_slots_paid = $product_slots->sum('paidAmount');
 
 
 
          foreach ($products as $product) {
          }
 
          $proposal->product_slots_paid = $product_slots_paid;
          $proposal->services = $products;
          $proposal->product_slot = $product_slots;
        }
      }
 
      $ServiceCompletedCount = DB::table('et_proposal')
        ->where('et_proposal.customer_id', $customer->sno)
        ->where('et_proposal.proposal_status', 5)
        ->get();
 
      $customer->completed_proposal = $ServiceCompletedCount;
      $customer->proposal_data = $proposal_data;
    }
 
 
 
    // return $customers;
    $types = TypeCredentialModel::where('status', 0)->get();
 
    return view('content.customer_management.manage_customer.post_sale_customer', [
      'customers' => $customers,
      'search_fill' => $search_fill,
      'types' => $types,
      'perpage' => $perpage,
      'followupReasonList' => $followupReasonList,
    ]);
}

  public function PrintProposal($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $prps_id = $decryptedValue;

    $proposal = DB::table('et_proposal')
      ->select('et_proposal.*', 'et_staff.nick_name', 'et_staff.staff_name', 'et_entity.entity_name', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
      ->where('et_proposal.sno', $prps_id)
      ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
      ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
      ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal.status', '!=', 2)
      ->where('et_lead.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->first();

    if ($proposal) {
      if ($proposal->post_sale_check == 1) {
        $staff_data = DB::table('et_staff')->where('et_staff.sno', $proposal->created_by)->first();
        $proposal->nick_name = $staff_data ? $staff_data->nick_name : $proposal->nick_name;
        $proposal->staff_name = $staff_data ? $staff_data->staff_name : $proposal->staff_name;
      }
    }

    $branch_data = DB::table('et_branch')
      ->select(
        'et_branch.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
      ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
      ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
      ->where('et_branch.sno', $proposal->branch_id)
      ->first();

    $exchange_quote = 1;
    // if ($proposal->currency_code !== 'INR') {
    //     $response= $helper->convertFromINR($proposal->currency_code);   
    //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
    // }

    $proposal->door_no = $branch_data->door_no;
    $proposal->area_street = $branch_data->area_street;
    $proposal->city_name =  $branch_data->city_name;
    $proposal->state_name =  $branch_data->state_name;
    $proposal->country_name =  $branch_data->country_name;
    $proposal->pincode =  $branch_data->pincode;
    $proposal->branch_mail =  $branch_data->mail;
    $proposal->branch_mobile =  $branch_data->mobile;
    $proposal->gst_no =  $branch_data->gst_no ?? "-";


    $lead_data = DB::table('et_lead')
      ->select(
        'et_lead.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
      ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
      ->where('et_lead.sno', $proposal->lead_id)
      ->first();

    $customer = DB::table('et_customer')
      ->select(
        'et_customer.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
      ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
      ->where('et_customer.sno', $proposal->customer_id)
      ->where('et_customer.status', '!=', 2)
      ->orderBy('et_customer.sno', 'desc')
      ->first();

    $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
    $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
    $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
    $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
    $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
    $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
    $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
    $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
    $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';



    if ($proposal->discount_id > 0) {
      $discount = DB::table('et_manage_coupon')->where('et_manage_coupon.sno', $proposal->discount_id)->first();

      $proposal->discount_value = $discount->coupon_value;
      $proposal->discount_type = $discount->coupon_type == 'percentage' ? '1' : '2';
    }

    $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

    $domain_names = DB::table('et_domain')
      ->where('et_domain.status', 0)
      ->whereIn('sno', $domain_ids)
      ->pluck('domain_name')  // Get only domain_name column
      ->toArray();            // Convert Collection to array

    $domain_list = implode(', ', $domain_names);


    $proposal->domain_names = $domain_list;

    // return $proposal;
    $proposal->products = [];
    $packages = '';

    if ($proposal->product_package == 1) {

      $proposalProduct = DB::table('et_proposal_product_cart')
        ->select('et_proposal_product_cart.*', 'et_product.product_name', 'et_product_category.product_category_name')
        ->where('et_proposal_product_cart.status', 0)
        ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->where('et_proposal_product_cart.proposal_id', $proposal->proposal_id)
        ->orderBy('et_proposal_product_cart.sno', 'ASC')
        ->get();

      $groupedProducts = [];
      $allSlotIds = [];
      $slotCount = 0;
      foreach ($proposalProduct as $product) {
        $product_id = $product->product_id;
        $cart_id = $product->cart_id;

        // Shared data fetched once per product_id
        if (!isset($groupedProducts[$product_id])) {
          $product_data = ProductModel::select('et_product.*')
            ->where('et_product.sno', $product_id)->first();

          $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
          $tools_ids = is_array($tools_ids) ? $tools_ids : [];

          $tools = DB::table('et_product_tools')
            ->whereIn('sno', $tools_ids)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->pluck('product_tools_name')
            ->toArray();

          $base_product = clone $product; // Copy to modify
          $base_product->tools_name = $tools;
          $base_product->product_name = $product->product_name;
          $base_product->product_category_name = $product->product_category_name;
          $base_product->cart_variants = [];
          $base_product->cart_slots = [];
          $base_product->total_amount_cart = 0;
          $base_product->product_amount = 0;

          $groupedProducts[$product_id] = $base_product;
        }

        // Compute variant data per cart
        $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
        $variable_amount = 0;
        $variant_names = [];
        $product_variant_name = '';
        $variable_name = '';

        foreach ($variant_variable_ids as $pair) {
          $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
          $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;

          if ($variant_id) {
            $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
            $product_variant_name = $get_variant->product_variant_name ?? '';
          }

          if ($variable_id) {
            $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
            if ($get_variables) {
              $variable_name = $get_variables->variable_name;
              $variable_amount += $get_variables->variable_amount;
            }
          }

          if ($product_variant_name && $variable_name) {
            $variant_names[] = "{$product_variant_name} - {$variable_name}";
          } elseif ($product_variant_name) {
            $variant_names[] = $product_variant_name;
          }
        }

        // $cart_total = $variable_amount + $product_data->base_price;
        $cart_total = $product->product_amount;
        $groupedProducts[$product_id]->total_amount_cart += $cart_total;

        // Add cart-specific variant names
        $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
        $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;


        // Fetch slots for this cart
        $slots = DB::table('et_proposal_pay_slot')
          ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
          ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
          ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
          ->where('et_proposal_pay_slot.status', 0)
          ->get();

        $slotCount = count($slots);

        foreach ($slots as $slot) {
          $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
          if (!in_array($cart_id, $slot_cart_ids)) {
            continue;
          }

          $groupedProducts[$product_id]->product_amount += $slot->slot_amount;

          $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
          $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);

          $deliverable_items = $deliverables_map[$cart_id] ?? [];
          $slot_notes_items = $slot_notes_map[$cart_id] ?? [];

          $deliverable_ids = [];
          foreach ($deliverable_items as $d) {
            if (($d['status'] ?? '0') == '0') {
              $deliverable_ids[] = $d['value'];
            }
          }

          $slot_notes_ids = [];
          foreach ($slot_notes_items as $s) {
            if (($s['status'] ?? '0') == '0') {
              $slot_notes_ids[] = $s['value'];
            }
          }

          $deliverable_ids = array_filter($deliverable_ids); // Ensure no empty values

          if (count($deliverable_ids) > 0) {
            $deliverables = DB::table('et_product_delivarables')
              ->whereIn('sno', $deliverable_ids)
              ->where('status', 0)
              ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
              ->pluck('delivarable_name', 'sno');
          } else {
            // Handle case where $deliverable_ids is empty
            $deliverables = collect(); // Return an empty collection or handle accordingly
          }

          $slot_notes = DB::table('et_slot_notes')
            ->whereIn('sno', $slot_notes_ids)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->pluck('slot_notes_name');

          // Assign deliverables and notes for this cart
          $slot->deliverables = $deliverables;
          $slot->slot_notes = $slot_notes;

          if (!isset($groupedProducts[$product_id]->cart_slots)) {
            $groupedProducts[$product_id]->cart_slots = [];
          }

          // Find if the slot already exists in the array
          $existingIndex = null;
          foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
            if ($existingSlot['sno'] === $slot->sno) {
              $existingIndex = $index;
              break;
            }
          }

          if ($existingIndex === null) {
            // Add new slot entry
            $groupedProducts[$product_id]->cart_slots[] = [
              'sno' => $slot->sno,
              'propo_pay_slot_id' => $slot->propo_pay_slot_id,
              'branch_id' => $slot->branch_id,
              'lead_id' => $slot->lead_id,
              'proposal_id' => $slot->proposal_id,
              'proposal_sno' => $slot->proposal_sno,
              'product_cart_id' => $slot->product_cart_id,
              'package_id' => $slot->package_id,
              'slot_id' => $slot->slot_id,
              'slot_amount' => $slot->slot_amount,
              'payable_amount' => $slot->payable_amount,
              'paidAmount' => $slot->paidAmount,
              'gst_amount' => $slot->gst_amount,
              'balance_amount' => $slot->balance_amount,
              'total_amount' => $slot->total_amount,
              'slot_description' => $slot->slot_description,
              'created_by' => $slot->created_by,
              'created_at' => $slot->created_at,
              'updated_by' => $slot->updated_by,
              'updated_at' => $slot->updated_at,
              'status' => $slot->status,
              'due_date' => $slot->due_date,
              'link_status' => $slot->link_status,
              'paid_status' => $slot->paid_status,
              'invoice_id' => $slot->invoice_id,
              'temp_send_link' => $slot->temp_send_link,
              'old_customer_check' => $slot->old_customer_check,
              'send_status' => $slot->send_status,
              'receipt_temp_link' => $slot->receipt_temp_link,
              'receipt_send_status' => $slot->receipt_send_status,
              'payment_slot_name' => $slot->payment_slot_name,
              'start_deliver_work' => $slot->start_deliver_work,
              'deliverables' => [
                (string)$cart_id => $deliverables->toArray()
              ],
              'slot_notes' => [
                (string)$cart_id => $slot_notes->toArray()
              ]
            ];
          } else {
            // Slot already exists — just append deliverables and slot_notes for this cart
            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
          }
        }

        //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

      }

      // Set the grouped products
      $proposal->products = array_values($groupedProducts);
      $proposal->slotCount = $slotCount;
    } else {

      $package_data = DB::table('et_package')
        ->select('et_package.*')
        ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
        ->where('et_package.status', 0)
        ->where('et_package.sno', $proposal->package_id)
        ->first();



      $package_product_name = DB::table('et_package_product')
        ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
        ->where('et_package_product.status', 0)
        ->where('et_package_product.package_id', $proposal->package_id)
        ->pluck('et_product.product_name');

      $package_data->product_name = $package_product_name;



      $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
        ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
        ->where('et_proposal_pay_slot.status', 0)
        ->get();
      $productSlot_amount = 0;
      foreach ($slots as $slot) {
        $productSlot_amount += $slot->slot_amount;
        $deliverables_ids = $slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
        $slot_notes_ids = $slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
        $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status', 0)->orderBy('sno', 'desc')->pluck('delivarable_name');
        $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status', 0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
        $slot->deliverables = $deliverables;
        $slot->slot_notes = $slot_notes;
      }
      $package_data->slots = $slots;

      $package_data->package_amount = $productSlot_amount;

      $packages = $package_data;
    }

    // return  $packages;

    $proposalAddonProduct = DB::table('et_proposal_addon_product')
      ->select('et_manage_addon.addon_name', 'et_proposal_addon_product.*', 'et_addon_variable.addon_variablename')
      ->where('et_proposal_addon_product.status', 0)
      ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
      ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
      ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
      ->get();

    $freeAddonProduct = DB::table('et_proposal_addon_product')
      ->select(
        'et_manage_addon.addon_name',
        'et_proposal_addon_product.*',
        'et_addon_variable.addon_variablename'
      )
      ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
      ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
      ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
      ->where('et_proposal_addon_product.status', 0)
      ->where('et_proposal_addon_product.free_paid', 0)
      ->get();

    $paidAddonProduct = DB::table('et_proposal_addon_product')
      ->select(
        'et_manage_addon.addon_name',
        'et_proposal_addon_product.*',
        'et_addon_variable.addon_variablename'
      )
      ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
      ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
      ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
      ->where('et_proposal_addon_product.status', 0)
      ->where('et_proposal_addon_product.free_paid', 1)
      ->get();

    $proposal->freeAddonProducts = $freeAddonProduct;
    $proposal->paidAddonProducts = $paidAddonProduct;
    $proposal->productAddon = $proposalAddonProduct;


    $lead = DB::table('et_lead')->where('et_lead.sno', $proposal->lead_id)->first();




    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status', 0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status', 0)->orderBy('sno', 'desc')->first();

    $proposal_terms = [];
    if ($terms) {
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature = $terms->signature;


    // return $proposal;

    return view('content.customer_management.manage_proposal.proposal_print', [
      'lead' => $lead,
      'proposal' => $proposal,
      'branch_data' => $branch_data,
      'proposal_note' => $proposal_note,
      'proposal_terms' => $proposal_terms,
      'signature' => $signature,
      'packages' => $packages,
      'exchange_quote' => $exchange_quote,
    ]);
  }


  public function CreateInvoice($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $prps_id = $decryptedValue;

    $proposal = DB::table('et_proposal')
      ->select('et_proposal.*', 'et_staff.nick_name', 'et_staff.staff_name', 'et_entity.entity_name', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
      ->where('et_proposal.sno', $prps_id)
      ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
      ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
      ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal.status', '!=', 2)
      ->where('et_lead.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->first();


    $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
      ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
      ->where('et_proposal_pay_slot.proposal_id', $proposal->proposal_id)
      ->where('et_proposal_pay_slot.status', 0)
      ->get();
    $slot_total = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
      ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
      ->where('et_proposal_pay_slot.proposal_id', $proposal->proposal_id)
      ->where('et_proposal_pay_slot.status', 0)
      ->first();

    $PaidAmount = $slots->sum('paidAmount');
    $total_balance = $slot_total->total_amount ? $slot_total->total_amount - $PaidAmount : 0;
    $branch_data = DB::table('et_branch')
      ->select(
        'et_branch.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
      ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
      ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
      ->where('et_branch.sno', $proposal->branch_id)
      ->first();



    $lead = DB::table('et_lead')->where('et_lead.sno', $proposal->lead_id)->first();

    return view('content.customer_management.manage_proposal.create_invoice', [
      'lead' => $lead,
      'proposal' => $proposal,
      'slots' => $slots,
      'total_balance' => $total_balance,
      'PaidAmount' => $PaidAmount,
      'branch_data' => $branch_data,
    ]);
  }

  public function manage_proposal_view($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');



    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }


    $proposaldata = DB::table('et_proposal')
      ->select('et_proposal.*', 'et_lead.lead_name', 'et_lead.registered_date', 'et_lead.lead_mobile', 'et_lead.lead_email_id', 'et_staff.nick_name', 'et_staff.staff_name', 'et_entity.entity_name', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name as currency_country_name')
      ->where('et_proposal.sno', $decryptedValue)
      ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
      ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
      ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal.status', '!=', 2)
      ->where('et_lead.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->first();

    $customer = DB::table('et_customer')
      ->select(
        'et_customer.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
      ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
      ->where('et_customer.sno', $proposaldata->customer_id)
      ->where('et_customer.status', '!=', 2)
      ->orderBy('et_customer.sno', 'desc')
      ->first();

    $proposaldata->lead_name         = $customer->cus_name        ?? $proposaldata->lead_name        ?? '';
    $proposaldata->lead_email_id         = $customer->cus_email_id    ?? $proposaldata->lead_email_id    ?? '';
    $proposaldata->lead_mobile       = $customer->cus_mobile      ?? $proposaldata->lead_mobile      ?? '';

    if ($proposaldata) {
      if ($proposaldata->post_sale_check == 1) {
        $staff_data = DB::table('et_staff')->where('et_staff.sno', $proposaldata->created_by)->first();
        $proposaldata->nick_name = $staff_data ? $staff_data->nick_name : $proposaldata->nick_name;
        $proposaldata->staff_name = $staff_data ? $staff_data->staff_name : $proposaldata->staff_name;
      }
    }
    $proposalList = DB::table('et_proposal')
      ->select('et_proposal.*', 'et_staff.nick_name', 'et_staff.staff_name', 'et_entity.entity_name', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name as currency_country_name')
      ->where('et_proposal.parent_id', $proposaldata->parent_id)
      ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
      ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
      ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal.status', '!=', 2)
      ->where('et_lead.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->get();
    $packages = '';
    foreach ($proposalList as $proposal) {
      $proposal->discount_value = '';
      $proposal->coupon_code = '';
      $proposal->discount_type = '';
      if ($proposal->discount_id > 0) {
        $discount = DB::table('et_manage_coupon')->where('et_manage_coupon.sno', $proposal->discount_id)->first();

        $proposal->discount_value = $discount->coupon_value;
        $proposal->coupon_code = $discount->coupon_code;
        $proposal->discount_type = $discount->coupon_type == 'percentage' ? '1' : '2';
      }

      if ($proposal) {
        if ($proposal->post_sale_check == 1) {
          $staffdata = DB::table('et_staff')->where('et_staff.sno', $proposal->created_by)->first();
          $proposal->nick_name = $staffdata ? $staffdata->nick_name : $proposal->nick_name;
          $proposal->staff_name = $staffdata ? $staffdata->staff_name : $proposal->staff_name;
        }
      }

      $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

      $domain_names = DB::table('et_domain')
        ->where('et_domain.status', 0)
        ->whereIn('sno', $domain_ids)
        ->pluck('domain_name')  // Get only domain_name column
        ->toArray();            // Convert Collection to array

      $domain_list = implode(', ', $domain_names);


      $proposal->domain_names = $domain_list;

      $proposal->products = [];

      $proposal->slotCount = 0;
      if ($proposal->product_package == 1) {

        $proposalProduct = DB::table('et_proposal_product_cart')
          ->select('et_proposal_product_cart.*', 'et_product.product_name', 'et_product_category.product_category_name')
          ->where('et_proposal_product_cart.status', 0)
          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
          ->where('et_proposal_product_cart.proposal_id', $proposal->proposal_id)
          ->orderBy('et_proposal_product_cart.sno', 'ASC')
          ->get();


        $groupedProducts = [];
        $allSlotIds = [];
        $slotCount = 0;
        foreach ($proposalProduct as $product) {
          $product_id = $product->product_id;
          $cart_id = $product->cart_id;

          // Shared data fetched once per product_id
          if (!isset($groupedProducts[$product_id])) {
            $product_data = ProductModel::select('et_product.*')
              ->where('et_product.sno', $product_id)->first();

            $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
            $tools_ids = is_array($tools_ids) ? $tools_ids : [];

            $tools = DB::table('et_product_tools')
              ->whereIn('sno', $tools_ids)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->pluck('product_tools_name')
              ->toArray();

            $base_product = clone $product; // Copy to modify
            $base_product->tools_name = $tools;
            $base_product->product_name = $product->product_name;
            $base_product->product_category_name = $product->product_category_name;
            $base_product->cart_variants = [];
            $base_product->cart_slots = [];
            $base_product->total_amount_cart = 0;
            $base_product->product_amount = 0;

            $groupedProducts[$product_id] = $base_product;
          }

          // Compute variant data per cart
          $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
          $variable_amount = 0;
          $variant_names = [];
          $product_variant_name = '';
          $variable_name = '';

          foreach ($variant_variable_ids as $pair) {
            $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
            $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;

            if ($variant_id) {
              $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
              $product_variant_name = $get_variant->product_variant_name ?? '';
            }

            if ($variable_id) {
              $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
              if ($get_variables) {
                $variable_name = $get_variables->variable_name;
                $variable_amount += $get_variables->variable_amount;
              }
            }

            if ($product_variant_name && $variable_name) {
              $variant_names[] = "{$product_variant_name} - {$variable_name}";
            } elseif ($product_variant_name) {
              $variant_names[] = $product_variant_name;
            }
          }

          $cart_total = $product->product_amount;
          // $cart_total = $variable_amount + $product_data->base_price;
          $groupedProducts[$product_id]->total_amount_cart += $cart_total;

          // Add cart-specific variant names
          $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
          $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;


          // Fetch slots for this cart
          $slots = DB::table('et_proposal_pay_slot')
            ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
            ->where('et_proposal_pay_slot.status', 0)
            ->get();
          $slotCount = count($slots);

          foreach ($slots as $slot) {
            $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);

            if (!in_array($cart_id, $slot_cart_ids)) {
              continue;
            }

            $groupedProducts[$product_id]->product_amount += $slot->slot_amount;

            $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
            $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);

            $deliverable_items = $deliverables_map[$cart_id] ?? [];
            $slot_notes_items = $slot_notes_map[$cart_id] ?? [];

            $deliverable_ids = [];
            foreach ($deliverable_items as $d) {
              if (($d['status'] ?? '0') == '0') {
                $deliverable_ids[] = $d['value'];
              }
            }

            $slot_notes_ids = [];
            foreach ($slot_notes_items as $s) {
              if (($s['status'] ?? '0') == '0') {
                $slot_notes_ids[] = $s['value'];
              }
            }
            // return $deliverable_ids;
            $deliverable_ids = array_filter($deliverable_ids); // Ensure no empty values

            if (count($deliverable_ids) > 0) {
              $deliverables = DB::table('et_product_delivarables')
                ->whereIn('sno', $deliverable_ids)
                ->where('status', 0)
                ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
                ->pluck('delivarable_name', 'sno');
            } else {

              // Handle case where $deliverable_ids is empty
              $deliverables = collect(); // Return an empty collection or handle accordingly
            }


            $slot_notes = DB::table('et_slot_notes')
              ->whereIn('sno', $slot_notes_ids)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->pluck('slot_notes_name');

            // Assign deliverables and notes for this cart
            $slot->deliverables = $deliverables;
            $slot->slot_notes = $slot_notes;

            if (!isset($groupedProducts[$product_id]->cart_slots)) {
              $groupedProducts[$product_id]->cart_slots = [];
            }

            // Find if the slot already exists in the array
            $existingIndex = null;
            foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
              if ($existingSlot['sno'] === $slot->sno) {
                $existingIndex = $index;
                break;
              }
            }

            if ($existingIndex === null) {
              // Add new slot entry
              $groupedProducts[$product_id]->cart_slots[] = [
                'sno' => $slot->sno,
                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                'branch_id' => $slot->branch_id,
                'lead_id' => $slot->lead_id,
                'proposal_id' => $slot->proposal_id,
                'proposal_sno' => $slot->proposal_sno,
                'product_cart_id' => $slot->product_cart_id,
                'package_id' => $slot->package_id,
                'slot_id' => $slot->slot_id,
                'slot_amount' => $slot->slot_amount,
                'payable_amount' => $slot->payable_amount,
                'paidAmount' => $slot->paidAmount,
                'gst_amount' => $slot->gst_amount,
                'balance_amount' => $slot->balance_amount,
                'total_amount' => $slot->total_amount,
                'slot_description' => $slot->slot_description,
                'created_by' => $slot->created_by,
                'created_at' => $slot->created_at,
                'updated_by' => $slot->updated_by,
                'updated_at' => $slot->updated_at,
                'status' => $slot->status,
                'due_date' => $slot->due_date,
                'link_status' => $slot->link_status,
                'paid_status' => $slot->paid_status,
                'invoice_id' => $slot->invoice_id,
                'temp_send_link' => $slot->temp_send_link,
                'old_customer_check' => $slot->old_customer_check,
                'send_status' => $slot->send_status,
                'receipt_temp_link' => $slot->receipt_temp_link,
                'receipt_send_status' => $slot->receipt_send_status,
                'payment_slot_name' => $slot->payment_slot_name,
                'start_deliver_work' => $slot->start_deliver_work,
                'deliverables' => [
                  (string)$cart_id => $deliverables->toArray()
                ],
                'slot_notes' => [
                  (string)$cart_id => $slot_notes->toArray()
                ]
              ];
            } else {
              // Slot already exists — just append deliverables and slot_notes for this cart
              $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
              $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
            }
          }

          //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

        }

        // Set the grouped products
        $proposal->products = array_values($groupedProducts);
        $proposal->slotCount = $slotCount;
      } else {

        $package_data = DB::table('et_package')
          ->select('et_package.*')
          ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
          ->where('et_package.status', 0)
          ->where('et_package.sno', $proposal->package_id)
          ->first();



        $package_product_name = DB::table('et_package_product')
          ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
          ->where('et_package_product.status', 0)
          ->where('et_package_product.package_id', $proposal->package_id)
          ->pluck('et_product.product_name');

        $package_data->product_name = $package_product_name;



        $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
          ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
          ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
          ->where('et_proposal_pay_slot.status', 0)
          ->get();
        $productSlot_amount = 0;
        foreach ($slots as $slot) {
          $productSlot_amount += $slot->slot_amount;
          $deliverables_ids = $slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
          $slot_notes_ids = $slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
          $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status', 0)->orderByRaw('FIELD(sno, ' . implode(',', $deliverables_ids) . ')')->pluck('delivarable_name');
          $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status', 0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
          $slot->deliverables = $deliverables;
          $slot->slot_notes = $slot_notes;
        }
        $package_data->slots = $slots;

        $package_data->package_amount = $productSlot_amount;

        $packages = $package_data;
        $proposal->package_name = $packages->package_name;
        $proposal->package_amount = $productSlot_amount;
        $proposal->package_slots = $slots;
        $proposal->product_package_name = $package_product_name;
      }


      $additional_charges_ids = $proposal->addtional_charges_ids ? json_decode($proposal->addtional_charges_ids) : [];

      $additional_charges = DB::table('et_additional_charges')->whereIn('et_additional_charges.sno', $additional_charges_ids)->get();
      $proposal->additional_charge_list = $additional_charges;

      $proposalAddonProduct = DB::table('et_proposal_addon_product')
        ->select('et_manage_addon.addon_name', 'et_proposal_addon_product.*', 'et_addon_variable.addon_variablename')
        ->where('et_proposal_addon_product.status', 0)
        ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
        ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
        ->get();

      $freeAddonProduct = DB::table('et_proposal_addon_product')
        ->select(
          'et_manage_addon.addon_name',
          'et_proposal_addon_product.*',
          'et_addon_variable.addon_variablename'
        )
        ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
        ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
        ->where('et_proposal_addon_product.status', 0)
        ->where('et_proposal_addon_product.free_paid', 0)
        ->get();

      $paidAddonProduct = DB::table('et_proposal_addon_product')
        ->select(
          'et_manage_addon.addon_name',
          'et_proposal_addon_product.*',
          'et_addon_variable.addon_variablename'
        )
        ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
        ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
        ->where('et_proposal_addon_product.status', 0)
        ->where('et_proposal_addon_product.free_paid', 1)
        ->get();

      $proposal->freeAddonProducts = $freeAddonProduct;
      $proposal->paidAddonProducts = $paidAddonProduct;
      $proposal->productAddon = $proposalAddonProduct;
    }
    // return $proposalList;
    return view('content.customer_management.manage_proposal.proposal_view', [
      "proposal" => $proposaldata,
      "proposalList" => $proposalList,
      'packages' => $packages,
    ]);
  }

  public function shortenUrl($longUrl, $channelId)
  {
    $response = Http::withToken('aFLQFlykraqpANsi')
      ->post('https://chotta.link/api/url/add', [
        'url' => $longUrl
      ]);

    if ($response->successful() && isset($response['shorturl'])) {

      $shortUrl = $response['shorturl'];
      $urlId = $response['id'];

      $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

      $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);

      if ($assignResponse->successful()) {
        return $response; // success
      }
    }


    return null;
  }

  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }

  // public function LeadDetails(Request $request)
  // {
  //   $search = $request->get('term');

  //   if (!$search) {
  //     return response()->json(['message' => 'Phone Number is required'], 400);
  //   }

  //   $cus = CustomerModel::select(
  //     'et_customer.cus_name',
  //     'et_customer.cus_mobile',
  //     'et_customer.created_by',
  //     'et_customer.cus_email_id',
  //     DB::raw("CASE 
  //               WHEN et_customer_services.product_package = 1 THEN et_product.product_name
  //               WHEN et_customer_services.product_package = 2 THEN et_package.package_name
  //               ELSE NULL
  //           END as product_name"),
  //     'et_product_category.product_category_name',
  //     'et_customer_services.proposal_id',
  //     'et_staff.staff_name'
  //   )
  //     ->leftJoin('et_customer_services', 'et_customer_services.customer_id', '=', 'et_customer.sno')
  //     ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
  //     ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
  //     ->leftJoin('et_product', function ($join) {
  //       $join->on('et_product.sno', '=', 'et_customer_services.product_id')
  //         ->where('et_customer_services.product_package', '=', 1);
  //     })
  //     ->leftJoin('et_package', function ($join) {
  //       $join->on('et_package.sno', '=', 'et_customer_services.package_id')
  //         ->where('et_customer_services.product_package', '=', 2);
  //     })
  //     ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
  //     ->where('et_customer.cus_mobile', 'LIKE', "%{$search}%")
  //     ->where('et_customer.status', 0)
  //     ->first();


  //   $results = [];

  //   if ($cus) {
  //     $data = DB::table('et_proposal_product_cart')
  //       ->select('et_proposal_product_cart.*', 'et_product.product_name', 'et_product_category.product_category_name')
  //       ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
  //       ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
  //       ->where('et_proposal_product_cart.status', 0)
  //       ->where('et_proposal_product_cart.proposal_sno', $cus->proposal_id)
  //       ->get();

  //     foreach ($data as $item) {
  //       $variant_variable_data = json_decode($item->variant_variable_ids ?? '[]', true);
  //       $variantVariableDetails = [];

  //       foreach ($variant_variable_data as $pair) {
  //         $variant = DB::table('et_manage_product_variant')->where('sno', $pair['variant_id'])->first();
  //         $variable = DB::table('et_manage_product_variable')->where('sno', $pair['variable_id'])->first();

  //         $variantVariableDetails[] = [
  //           'variant' => $variant->product_variant_name ?? null,
  //           'variable' => $variable->variable_name ?? null,
  //         ];
  //       }

  //       $results[] = [
  //         'product_cart' => $item,
  //         'variant_variable_data' => $variantVariableDetails
  //       ];
  //     }
  //   }


  //   $lead = DB::table('et_lead')->select('et_lead.lead_name', 'et_lead.lead_mobile', 'et_lead.lead_email_id', 'et_lead.status', 'et_lead.created_by', 'et_lead.lead_group', 'et_lead_source.lead_source_name', 'et_staff.staff_name')
  //     ->leftJoin('et_lead_source', 'et_lead_source.sno', '=', 'et_lead.lead_source_id')
  //     ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
  //     ->where('et_lead.lead_mobile', 'LIKE', "%{$search}%")
  //     ->first();

  //   return response()->json([
  //     'status' => 200,
  //     'cus' => $cus,
  //     'lead' => $lead,
  //     'results' => $results
  //   ]);

  //   return response()->json(['message' => 'No customer or lead found'], 404);
  // }

  public function LeadDetails(Request $request)
{
  $branch_id = $request->user()->branch_id;
  $search = $request->get('term');

  if (!$search) {
    return response()->json(['message' => 'Phone Number is required'], 400);
  }

  $results = [];
  $timeline = [];
  $summary = [
    'total_records' => 0,
    'raw_lead' => 0,
    'lead' => 0,
    'customer' => 0,
    'event_participant' => 0,
    'intern' => 0,
    'appointment' => 0,
    'lead_appointment' => 0,
    'daily_call' => 0,
  ];

  // 1. Check za_raw_lead
  $raw_lead = DB::table('et_raw_lead')
    ->select(
      'et_raw_lead.sno',
      'et_raw_lead.lead_mobile as mobile',
      'et_raw_lead.lead_name as name',
      'et_raw_lead.status',
      'et_raw_lead.created_at',
      'et_branch.branch_name'
    )
    ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_raw_lead.branch_id')
    ->where('et_raw_lead.lead_mobile', 'LIKE', "%{$search}%")
    // ->where('et_raw_lead.branch_id', $branch_id)
    ->orderBy('et_raw_lead.created_at', 'desc')
    ->get();

  if ($raw_lead->isNotEmpty()) {
    $results['raw_lead'] = $raw_lead;
    $summary['raw_lead'] = $raw_lead->count();
    $summary['total_records'] += $raw_lead->count();
    foreach ($raw_lead as $item) {
      $timeline[] = [
        'table' => 'Raw Lead',
        'icon' => 'mdi mdi-account-plus',
        'color' => 'primary',
        'name' => $item->name ?? 'N/A',
        'mobile' => $item->mobile,
        'status' => $item->status,
        'branch' => $item->branch_name ?? 'N/A',
        'created_at' => $item->created_at,
        'sno' => $item->sno,
      ];
    }
  }

  // 2. Check za_lead
  $lead = DB::table('et_lead')
    ->select(
      'et_lead.sno',
      'et_lead.lead_mobile as mobile',
      'et_lead.lead_name as name',
      'et_lead.lead_email_id as email',
      'et_lead.lead_group',
      'et_lead.status',
      'et_lead.created_at',
      'et_branch.branch_name',
      'et_lead_source.lead_source_name',
      'et_staff.staff_name'
    )
    ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_lead.branch_id')
    ->leftJoin('et_lead_source', 'et_lead_source.sno', '=', 'et_lead.lead_source_id')
    ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
    ->where('et_lead.lead_mobile', 'LIKE', "%{$search}%")
    // ->where('et_lead.branch_id', $branch_id)
    ->orderBy('et_lead.created_at', 'desc')
    ->get();

  if ($lead->isNotEmpty()) {
    $results['lead'] = $lead;
    $summary['lead'] = $lead->count();
    $summary['total_records'] += $lead->count();
    foreach ($lead as $item) {
      $timeline[] = [
        'table' => 'Lead',
        'icon' => 'mdi mdi-account-star',
        'color' => 'info',
        'name' => $item->name ?? 'N/A',
        'mobile' => $item->mobile,
        'email' => $item->email,
        'status' => $item->status,
        'branch' => $item->branch_name ?? 'N/A',
        'source' => $item->lead_source_name,
        'group' => $item->lead_group,
        'staff' => $item->staff_name,
        'created_at' => $item->created_at,
        'sno' => $item->sno,
      ];
    }
  }

  // 3. Check za_customer
  $customer = DB::table('et_customer')
    ->select(
      'et_customer.sno',
      'et_customer.cus_mobile as mobile',
      'et_customer.cus_name as name',
      'et_customer.cus_email_id as email',
      'et_customer.status',
      'et_customer.created_at',
      'et_branch.branch_name',
      'et_proposal.service_title as course_name',
      'et_staff.staff_name'
    )
    ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_customer.branch_id')
    ->leftJoin('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_proposal.created_by')
    ->where('et_customer.cus_mobile', 'LIKE', "%{$search}%")
    // ->where('et_customer.branch_id', $branch_id)
    ->orderBy('et_customer.created_at', 'desc')
    ->get();

  if ($customer->isNotEmpty()) {
    $results['customer'] = $customer;
    $summary['customer'] = $customer->count();
    $summary['total_records'] += $customer->count();
    foreach ($customer as $item) {
      $timeline[] = [
        'table' => 'Customer',
        'icon' => 'mdi mdi-account-check',
        'color' => 'success',
        'name' => $item->name ?? 'N/A',
        'mobile' => $item->mobile,
        'email' => $item->email,
        'status' => $item->status,
        'branch' => $item->branch_name ?? 'N/A',
        'course' => $item->course_name,
        'batch' => '',
        'staff' => $item->staff_name,
        'created_at' => $item->created_at,
        'sno' => $item->sno,
      ];
    }
  }

  // 4. Check za_event_participant
  $event_participant = DB::table('et_event_participant')
    ->select(
      'et_event_participant.sno',
      'et_event_participant.mobile_no as mobile',
      'et_event_participant.participant_name as name',
      'et_event_participant.status',
      'et_event_participant.created_at',
      'et_branch.branch_name',
      'et_event.event_name'
    )
    ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_event_participant.branch_id')
    ->leftJoin('et_event', 'et_event.sno', '=', 'et_event_participant.event_id')
    ->where('et_event_participant.mobile_no', 'LIKE', "%{$search}%")
    // ->where('et_event_participant.branch_id', $branch_id)
    ->orderBy('et_event_participant.created_at', 'desc')
    ->get();

  if ($event_participant->isNotEmpty()) {
    $results['event_participant'] = $event_participant;
    $summary['event_participant'] = $event_participant->count();
    $summary['total_records'] += $event_participant->count();
    foreach ($event_participant as $item) {
      $timeline[] = [
        'table' => 'Event Participant',
        'icon' => 'mdi mdi-calendar-account',
        'color' => 'warning',
        'name' => $item->name ?? 'N/A',
        'mobile' => $item->mobile,
        'status' => $item->status,
        'branch' => $item->branch_name ?? 'N/A',
        'event' => $item->event_name,
        'created_at' => $item->created_at,
        'sno' => $item->sno,
      ];
    }
  }

  // 5. Check za_intern
  $intern = DB::table('et_intern')
    ->select(
      'et_intern.sno',
      'et_intern.intern_mobile as mobile',
      'et_intern.intern_name as name',
      'et_intern.status',
      'et_intern.created_at',
      'et_branch.branch_name'
    )
    ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_intern.branch_id')
    ->where('et_intern.intern_mobile', 'LIKE', "%{$search}%")
    // ->where('et_intern.branch_id', $branch_id)
    ->orderBy('et_intern.created_at', 'desc')
    ->get();

  if ($intern->isNotEmpty()) {
    $results['intern'] = $intern;
    $summary['intern'] = $intern->count();
    $summary['total_records'] += $intern->count();
    foreach ($intern as $item) {
      $timeline[] = [
        'table' => 'Intern',
        'icon' => 'mdi mdi-badge-account',
        'color' => 'dark',
        'name' => $item->name ?? 'N/A',
        'mobile' => $item->mobile,
        'status' => $item->status,
        'branch' => $item->branch_name ?? 'N/A',
        'created_at' => $item->created_at,
        'sno' => $item->sno,
      ];
    }
  }

  // 6. Check za_appointment (followup) - via lead_id
  $appointment = DB::table('et_appointment')
    ->select(
      'et_appointment.sno',
      'et_appointment.appointment_date',
      'et_appointment.appointment_time',
      'et_appointment.status',
      'et_appointment.created_at',
      'et_branch.branch_name',
      'et_lead.lead_name',
      'et_lead.lead_mobile as mobile'
    )
    ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_appointment.branch_id')
    ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
    ->where('et_lead.lead_mobile', 'LIKE', "%{$search}%")
    // ->where('et_appointment.branch_id', $branch_id)
    ->orderBy('et_appointment.created_at', 'desc')
    ->get();

  if ($appointment->isNotEmpty()) {
    $results['appointment'] = $appointment;
    $summary['appointment'] = $appointment->count();
    $summary['total_records'] += $appointment->count();
    foreach ($appointment as $item) {
      $timeline[] = [
        'table' => 'Appointment',
        'icon' => 'mdi mdi-calendar-clock',
        'color' => 'danger',
        'name' => $item->lead_name ?? 'N/A',
        'mobile' => $item->mobile,
        'status' => $item->status,
        'branch' => $item->branch_name ?? 'N/A',
        'appointment_date' => $item->appointment_date,
        'appointment_time' => $item->appointment_time,
        'created_at' => $item->created_at,
        'sno' => $item->sno,
      ];
    }
  }

  // 7. Check za_lead_appointment - via lead_id
  $lead_appointment = DB::table('et_lead_appointment')
    ->select(
      'et_lead_appointment.sno',
      'et_lead_appointment.status',
      'et_lead_appointment.created_at',
      'et_branch.branch_name',
      'et_lead.lead_name',
      'et_lead.lead_mobile as mobile'
    )
    ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_lead_appointment.branch_id')
    ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_lead_appointment.lead_id')
    ->where('et_lead.lead_mobile', 'LIKE', "%{$search}%")
    // ->where('et_lead_appointment.branch_id', $branch_id)
    ->orderBy('et_lead_appointment.created_at', 'desc')
    ->get();

  if ($lead_appointment->isNotEmpty()) {
    $results['lead_appointment'] = $lead_appointment;
    $summary['lead_appointment'] = $lead_appointment->count();
    $summary['total_records'] += $lead_appointment->count();
    foreach ($lead_appointment as $item) {
      $timeline[] = [
        'table' => 'Lead Appointment',
        'icon' => 'mdi mdi-calendar-check',
        'color' => 'secondary',
        'name' => $item->lead_name ?? 'N/A',
        'mobile' => $item->mobile,
        'status' => $item->status,
        'branch' => $item->branch_name ?? 'N/A',
        'intern_name' => $item->lead_name,
        'created_at' => $item->created_at,
        'sno' => $item->sno,
      ];
    }
  }

  // 8. Check za_schedule_daily_call - via lead_id (resolved from mobile)
  //    status: 0 -> Schedule, 1 -> Follow-up Complete, 2 -> Reschedule
  $daily_call = DB::table('et_schedule_daily_call as sdc')
    ->select(
      'sdc.sno',
      'sdc.lead_id',
      'sdc.sch_date',
      'sdc.status',
      'sdc.created_at',
      'et_branch.branch_name',
      'et_lead.lead_name',
      'et_lead.lead_mobile as mobile',
      'prev_staff.staff_name as previous_staff_name',
      'curr_staff.staff_name as current_staff_name'
    )
    ->leftJoin('et_branch', 'et_branch.sno', '=', 'sdc.branch_id')
    ->leftJoin('et_lead', 'et_lead.sno', '=', 'sdc.lead_id')
    ->leftJoin('et_staff as prev_staff', 'prev_staff.sno', '=', 'sdc.previous_staff')
    ->leftJoin('et_staff as curr_staff', 'curr_staff.sno', '=', 'sdc.current_staff')
    ->whereIn('sdc.lead_id', function ($q) use ($search) {
      $q->select('sno')
        ->from('et_lead')
        ->where('lead_mobile', 'LIKE', "%{$search}%");
    })
    // ->where('sdc.branch_id', $branch_id)
    ->orderBy('sdc.created_at', 'desc')
    ->get();

  if ($daily_call->isNotEmpty()) {
    $results['daily_call'] = $daily_call;
    $summary['daily_call'] = $daily_call->count();
    $summary['total_records'] += $daily_call->count();

    // status mapping for this table (0/1/2)
    $dailyCallStatusMap = [
      0 => 'Schedule',
      1 => 'Follow-up Complete',
      2 => 'Reschedule',
    ];

    foreach ($daily_call as $item) {
      $timeline[] = [
        'table'        => 'Daily Call',
        'icon'         => 'mdi mdi-phone-log',
        'color'        => 'info',
        'name'         => $item->lead_name ?? 'N/A',
        'mobile'       => $item->mobile,
        'status'       => $item->status,
        'status_label' => $dailyCallStatusMap[(int) $item->status] ?? 'Unknown',
        'branch'       => $item->branch_name ?? 'N/A',
        'sch_date'     => $item->sch_date,
        'previous_staff' => $item->previous_staff_name,
        'current_staff'  => $item->current_staff_name,
        'created_at'   => $item->created_at,
        'sno'          => $item->sno,
        'lead_id'      => $item->lead_id,
      ];
    }
  }

  // Sort timeline by created_at descending
  usort($timeline, function ($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
  });

  return response()->json([
    'status' => 200,
    'summary' => $summary,
    'results' => $results,
    'timeline' => $timeline,
  ]);
}

  //   Proposal revised functions
  public function ReviseProposal(Request $request)
  {

    $lead_id = $request->proposal_lead_id ?? 0;

    $values = $request->input('proposal_id');
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');

    // Return the encrypted value as JSON
    return response()->json($encrypted_values);
  }

  public function manage_proposal_revise($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $prps_id = $decryptedValue;
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;



    // Get the latest proposal by ID and make sure it's not rejected (status != 2)
    $proposalLast = DB::table('et_proposal')
      ->where('sno', $prps_id)
      ->where('status', '!=', 2)
      ->orderByDesc('sno')
      ->first();

    if (!$proposalLast) {
      return redirect()->back()->with('error', 'Proposal not found or already rejected.');
    }

    // Check if a revised proposal already exists
    $category_check = DB::table('et_proposal')
      ->where('revised_from', $prps_id)
      ->where('revised', 1)
      ->orderByDesc('sno')
      ->first();



    if (!$category_check) {
      // Create a new revised proposal
      DB::beginTransaction();

      $proposal = new ProposalModel();

      $proposal->lead_id = $proposalLast->lead_id;
      $proposal->service_title = $proposalLast->service_title;
      $proposal->domain_ids = $proposalLast->domain_ids;
      $proposal->topic = $proposalLast->topic;
      $proposal->cre_id = $proposalLast->cre_id;
      $proposal->milestone_count = $proposalLast->milestone_count;
      $proposal->product_package = $proposalLast->product_package;
      $proposal->package_id = $proposalLast->package_id ?? 0;
      $proposal->due_date = $proposalLast->due_date;
      $proposal->estimate_date = $proposalLast->estimate_date;
      $proposal->currency_id = $proposalLast->currency_id;
      $proposal->propsal_date = date('Y-m-d');
      $proposal->sub_total = $proposalLast->sub_total;
      $proposal->gst_amount = $proposalLast->gst_amount;
      $proposal->total_amount = $proposalLast->total_amount;
      $proposal->grant_total_amount = $proposalLast->grant_total_amount;
      $proposal->created_by = $user_id;
      $proposal->updated_by = $user_id;
      $proposal->branch_id = $branch_id;
      $proposal->delivery_duration = $proposalLast->delivery_duration;
      $proposal->delivery_duration_end = $proposalLast->delivery_duration_end;
      $proposal->gst_perc = $proposalLast->gst_perc;
      $proposal->gst_inclusive = $proposalLast->gst_inclusive;
      $proposal->parent_id = $proposalLast->parent_id;
      $proposal->additional_charge_perc = $proposalLast->additional_charge_perc;
      $proposal->additional_charge_amount = $proposalLast->additional_charge_amount;
      $proposal->addtional_charges_ids = $proposalLast->addtional_charges_ids;
      $proposal->page_word = $proposalLast->page_word;
      $proposal->page_word_count = $proposalLast->page_word_count;
      $proposal->referral_id = $proposalLast->referral_id;
      $proposal->old_customer_check = $proposalLast->old_customer_check;
      $proposal->post_sale_check = $proposalLast->post_sale_check;
      $proposal->customer_id = $proposalLast->customer_id;
      $proposal->created_by = $proposalLast->created_by;
      $proposal->updated_by = $proposalLast->updated_by;
      $proposal->revised = 1;
      $proposal->status = 2;
      $proposal->revised_from = $prps_id;

      $proposal->save();

      $ProposalRevisedId = $proposal->sno; // assuming 'id' is the primary key

      DB::commit();


      // 3. Insert into et_proposal_product_cart
      $product_cart_data = DB::table('et_proposal_product_cart')
        ->where('proposal_sno', $proposalLast->sno)
        ->where('status', 0)
        ->get();

      foreach ($product_cart_data as $cart) {
        DB::table('et_temp_proposal_cart')->insert([
          'temp_revised_id' => $ProposalRevisedId,
          'product_id' => $cart->product_id,
          'variant_variable_ids' => $cart->variant_variable_ids,
          'currency_id' => $proposalLast->currency_id,
          'product_amount' => $cart->original_amount,
          'cust_product_amount' => $cart->product_amount,
          'created_by' => $user_id,
          'updated_by' => $user_id,
        ]);
      }

      $product_addOn_data = DB::table('et_proposal_addon_product')
        ->where('proposal_sno', $proposalLast->sno)
        ->where('status', 0)
        ->get();

      foreach ($product_addOn_data as $addOn) {
        DB::table('et_proposal_addon_product')->insert([
          'proposal_sno' => $ProposalRevisedId,
          'add_on_id' => $addOn->add_on_id,
          'free_paid' => $addOn->free_paid,
          'addon_variant_id' => $addOn->addon_variant_id,
          'addon_amount' => $addOn->addon_amount,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'branch_id' => $branch_id,
        ]);
      }

      if ($proposalLast->product_package == 2) {

        $package_cart_data = DB::table('et_proposal_package_cart')
          ->where('proposal_sno', $proposalLast->sno)
          ->where('status', 0)
          ->get();

        if (isset($package_cart_data)) {
          foreach ($package_cart_data as $package) {
            $add_package_cart = DB::table('et_proposal_package_cart')->insert([
              'proposal_sno' => $ProposalRevisedId,
              'package_id' => $package->package_id,
              'product_id' => $package->product_id,
              'product_amount' => $package->product_amount,
              'variant_variable_ids' => $package->variant_variable_ids,
              'cust_product_amount' => $package->cust_product_amount,
              'original_product_amount' => $package->original_product_amount,
              'total_package_amount' => $package->total_package_amount,
              'created_by' => $user_id,
              'updated_by' => $user_id,
              'branch_id'   => $branch_id,
            ]);
          }
        }
      }








      // Fetch the newly created revised proposal
      $proposal = DB::table('et_proposal')
        ->where('sno', $ProposalRevisedId)
        ->first();
    } else {
      // Revised proposal already exists
      $proposal = DB::table('et_proposal')
        ->where('sno', $category_check->sno)
        ->first();
    }


    $lead = DB::table('et_lead')->where('et_lead.sno', $proposal->lead_id)->first();

    $customer = DB::table('et_customer')->where('et_customer.lead_id', $proposal->lead_id)->first();
    if ($customer) {
      $lead->lead_name = $customer->cus_name ?? $lead->lead_name;
      $lead->lead_email_id = $customer->cus_email_id ?? $lead->lead_email_id;
      $lead->lead_mobile = $customer->cus_mobile ?? $lead->lead_mobile;
      $lead->customer_id = $customer->customer_id ?? '';
    }

    $lead_id = $lead->sno;

    $package_list = DB::table('et_package')->where('et_package.status', 0)->orderBy('sno', 'desc')->get();
    $additional_charges_list = DB::table('et_additional_charges')->where('et_additional_charges.status', 0)->orderBy('sno', 'desc')->get();

    $currencyList = DB::table('et_country_currencies')->where('et_country_currencies.status', 0)->get();
    $domainList = DB::table('et_domain')->where('et_domain.status', 0)->get();

    $Product_cat_list = DB::table('et_product_category')
      ->select(
        'et_product_category.sno',
        'et_product_category.product_category_name',
        DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
      )
      ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
      ->where('et_product_category.status', 0)
      ->where('et_product.branch_id', $branch_id)
      ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
      ->orderBy('et_product_category.product_category_name', 'ASC')
      ->get();

    $addOnProductList = DB::table('et_manage_addon')
      ->select(
        'et_manage_addon.sno',
        'et_manage_addon.addon_name'
      )
      ->where('et_manage_addon.status', 0)
      ->where('et_manage_addon.branch_id', $branch_id)
      ->get();

    foreach ($addOnProductList as $addOn) {
      $manageVarient = DB::table('et_manage_addon_variant')
        ->select(
          'et_manage_addon_variant.sno',
          'et_manage_addon_variant.amount',
          'et_manage_addon_variant.free_paid',
          'et_addon_variable.addon_variablename',
        )
        ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
        ->where('et_manage_addon_variant.addon_id', $addOn->sno)
        ->get();

      $addOn->add_varients = $manageVarient;
    }

    $branch_data = DB::table('et_branch')->where('sno', $branch_id)->first();

    // return $addOnProductList;

    $packageSlot = DB::table('et_proposal_pay_slot')->where('proposal_sno', $proposal->sno)->where('status', 0)->where('package_id', '!=', 0)->orderBy('sno', 'desc')->first();
    // return $proposal_id;
    //  $preProposal = DB::table('et_pre_proposal')->where('proposal_id', $proposal_id_lead)->first();

    $couponCode = null;

    if ($proposal->discount_id > 0) {
      $coupon = DB::table('et_manage_coupon')->where('sno', $proposal->discount_id)->first();

      if ($coupon) {
        $couponCode = $coupon->coupon_code;
      }
    }
    $Inserted_id = $proposal->sno;
    $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)->where('et_staff.role_id', 16)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();

    $collectionStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)->where('et_staff.role_id', 42)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $collectionStaff = $collectionStaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();
    $ProposalAddOnProduct = DB::table('et_proposal_addon_product')
      ->where('et_proposal_addon_product.status', 0)
      ->where('et_proposal_addon_product.proposal_sno', $proposal->sno)
      ->get();

    $packageData = DB::table('et_proposal_package_cart')->where('proposal_sno', $proposal->sno)->where('status', 0)->orderBy('sno', 'asc')->get();

    $postSaleStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.department_id', 15)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $postSaleStaff = $postSaleStaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();

    $referalStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.role_id', '>', 1)
      // ->where('et_staff.department_id', 3)
      // ->where('et_staff.sub_department_id', 6)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $referalStaff = $referalStaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();


    // return $preProposal;

    return view('content.customer_management.manage_proposal.proposal_revise', [
      'lead' => $lead,
      'proposal' => $proposal,
      'currencyList' => $currencyList,
      'Product_cat_list' => $Product_cat_list,
      'Inserted_id' => $Inserted_id,
      'addOnProductList' => $addOnProductList,
      'branch_data' => $branch_data,
      'package_list' => $package_list,
      'additional_charges_list' => $additional_charges_list,
      'packageSlot' => $packageSlot,
      'couponCode' => $couponCode,
      'preProposal' => $proposal,
      'domainList' => $domainList,
      'crestaff' => $crestaff,
      'collectionStaff'=>$collectionStaff,
      'ProposalAddOnProduct' => $ProposalAddOnProduct,
      'referalStaff' => $referalStaff,
      'packageData' => $packageData,
      'postSaleStaff' => $postSaleStaff,
    ]);
  }

  public function ProposalRevised(Request $request)
  {



    $branch_id = $request->user()->branch_id;
    $entity_id = $request->user()->entity_id;
    $user_id = $request->user()->user_id;


    $created_By = $request->input('post_sale_staff') ?? $user_id;


    $proposal_edit_id = $request->input('proposal_edit_id');
    $proposal_id = $request->input('proposal_hidden_id');
    $lead_id = $request->input('proposal_lead_id');
    $service_title = $request->input('prposal_service_title');
    $domain_ids = $request->input('proposal_domain');
    $milestone_count = $request->input('milestone_count');
    $topic = $request->input('proposal_topic');
    $cre_id = $request->input('proposal_cre');
     $collection_id = $request->input('collection_id');
    $due_date = $request->input('prposal_due_date') ? date('Y-m-d', strtotime($request->input('prposal_due_date'))) : null;
    $estimate_date = $request->input('estimate_date') ? date('Y-m-d', strtotime($request->input('estimate_date'))) : null;
    $currency_id = $request->input('prposal_currency');
    $proposal_date = date('Y-m-d');
    $package_check = $request->input('serv_prod_pckg_chk');
    $sub_total = $request->input('sub_total_amount');
    $discount_id = $request->input('discount_id_hidden');
    $discount_amount = $request->input('discounted_amount_hidden');
    $gst_amount = $request->input('gst_amount_hidden');
    $gst_perc = $request->input('gst_perc_hidden');
    $additional_charge_perc = $request->input('additional_charge_perc');
    $additional_charge_amount = $request->input('additional_charge_amount');
    $addtional_charges_id = $request->input('addtional_charges_id');
    $delivery_duration = $request->input('delivery_duration');
    $delivery_duration_end = $request->input('delivery_duration_end');
    $total_amount = $request->input('proposal_total_amount');
    $grant_total_amount = $request->input('grant_total_amount');
    $package_id = $request->input('package_id');
    $gst_inclusive = $request->input('gst_inclusive');
    $send_communication = $request->input('send_communication');
    $page_word = $request->input('page_word');
    $page_word_count = $request->input('page_word_count');
    $referral_id = $request->input('proposal_referral_staff');
    $old_customer_check = $request->input('old_customer_check') ?? 0;

    $CurrentProposal = DB::table('et_proposal')->where('et_proposal.sno', $proposal_edit_id)->first();

    $category_check = DB::table('et_proposal')->orderBy('sno', 'desc')->where('parent_id', $CurrentProposal->parent_id)->where('status', '!=', 2)->where('revised', 1)->first();

    if (!$category_check) {
      $proposal_id = $CurrentProposal->parent_id . '-01';
    } else {
      $last_id = $category_check->proposal_id; // e.g., PRO-00002/05/2025-02
      $parts = explode('-', $last_id);
      $last_number = array_pop($parts);

      $new_number = str_pad((int)$last_number + 1, 2, '0', STR_PAD_LEFT);
      $proposal_id = implode('-', $parts) . '-' . $new_number;
    }
    //  return $send_communication ;

    $addtional_charges_ids = $addtional_charges_id ? json_encode($addtional_charges_id) : null;
    $domain_ids = $domain_ids ? json_encode($domain_ids) : null;

    DB::beginTransaction();

    $proposal = ProposalModel::where('sno', $proposal_edit_id)->first();

    if ($proposal) {
      $proposal->proposal_id = $proposal_id;
      $proposal->lead_id = $lead_id;
      $proposal->service_title = $service_title;
      $proposal->domain_ids = $domain_ids;
      $proposal->topic = $topic;
      $proposal->cre_id = $cre_id;
      $proposal->collection_id = $collection_id;
      $proposal->milestone_count = $milestone_count;
      $proposal->product_package = $package_check;
      $proposal->package_id = $package_id ?? 0;
      $proposal->due_date = $due_date;
      $proposal->estimate_date = $estimate_date;
      $proposal->currency_id = $currency_id;
      $proposal->propsal_date = $proposal_date;
      $proposal->sub_total = $sub_total;
      $proposal->discount_id = $discount_id;
      $proposal->discount_amount = $discount_amount;
      $proposal->gst_amount = $gst_amount;
      $proposal->total_amount = $total_amount;
      $proposal->grant_total_amount = $grant_total_amount;
      $proposal->created_by = $user_id;
      $proposal->updated_by = $user_id;
      $proposal->branch_id = $branch_id;
      $proposal->delivery_duration = $delivery_duration;
      $proposal->delivery_duration_end = $delivery_duration_end;
      $proposal->gst_perc = $gst_perc;
      $proposal->gst_inclusive = $gst_inclusive ?? 0;
      $proposal->additional_charge_perc = $additional_charge_perc;
      $proposal->additional_charge_amount = $additional_charge_amount;
      $proposal->addtional_charges_ids = $addtional_charges_ids;
      $proposal->send_status = ($send_communication == 1) ? 1 : 0;
      $proposal->verify_status = ($send_communication == 1) ? 1 : 0;
      $proposal->page_word = $page_word;
      $proposal->page_word_count = $page_word_count ?? 0;
      $proposal->status = 0;
      $proposal->created_By = $created_By;
      $proposal->proposal_status = 0;
      $proposal->referral_id = $referral_id ?? 0;
      $proposal->old_customer_check = $old_customer_check ?? 0;

      $proposal->update();
    }

    DB::table('et_proposal_pay_slot')
      ->where('proposal_sno', $proposal_edit_id)
      ->where('status', 0)
      ->update(['proposal_id' => $proposal_id]);

    if ($package_check == 1) {
      DB::table('et_proposal_addon_product')
        ->where('proposal_sno', $proposal_edit_id)
        ->where('status', 0)
        ->update(['proposal_id' => $proposal_id]);


      //   if ($request->has('addOn_chk')) {
      //     foreach ($request->input('addOn_chk') as $addOnId) {
      //         $variant_key = "addOn_varient_$addOnId";
      //         $variant_id = $request->input($variant_key);

      //         // Get amount from DB or default to 0

      //           $addon_data = DB::table('et_manage_addon_variant')
      //             ->where('sno', $variant_id)
      //             ->first();

      //         DB::table('et_proposal_addon_product')->insert([
      //             'proposal_id' => $proposal_id,
      //             'proposal_sno' => $proposal_edit_id,
      //             'add_on_id' => $addOnId,
      //             'free_paid' => $addon_data ? $addon_data->free_paid :null ,
      //             'addon_variant_id' => $variant_id,
      //             'addon_amount' => $addon_data ? $addon_data->amount :0 ,
      //              'created_by' => $user_id,
      //               'updated_by' => $user_id,
      //               'branch_id' => $branch_id,
      //         ]);
      //     }
      //   }

      // 3. Insert into et_proposal_product_cart
      $temp_id = $request->input('Inserted_id_product');
      $product_cart_data = DB::table('et_temp_proposal_cart')
        ->where('temp_revised_id', $temp_id)
        ->where('status', 0)
        ->get();

      foreach ($product_cart_data as $cart) {
        DB::table('et_proposal_product_cart')->insert([
          'proposal_id' => $proposal_id,
          'proposal_sno' => $proposal_edit_id,
          'product_id' => $cart->product_id,
          'product_amount' => $cart->cust_product_amount,
          'original_amount' => $cart->product_amount,
          'cart_id' => $cart->sno,
          'variant_variable_ids' => $cart->variant_variable_ids,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'branch_id' => $branch_id,
        ]);
      }

      DB::table('et_proposal_package_cart')
        ->where('proposal_sno', $proposal_edit_id)
        ->where('status', 0)
        ->update(['status' => 2]);
    } else {
      DB::table('et_proposal_addon_product')
        ->where('proposal_sno', $proposal_edit_id)
        ->where('status', 0)
        ->update(['proposal_id' => $proposal_id]);

      DB::table('et_proposal_package_cart')
        ->where('proposal_sno', $proposal_edit_id)
        ->where('status', 0)
        ->update(['proposal_id' => $proposal_id]);

      $temp_id = $request->input('Inserted_id_product');

      DB::table('et_temp_proposal_cart')
        ->where('temp_revised_id', $proposal_edit_id)
        ->where('status', 0)
        ->update(['status' => 2]);

      DB::table('et_proposal_product_cart')
        ->where('proposal_sno', $proposal_edit_id)
        ->where('status', 0)
        ->update(['status' => 2]);
    }

    // 2. Insert into et_proposal_addon_product




    DB::commit();
    // send Communication
    if ($send_communication == 1) {
      $proposalData = DB::table('et_proposal')->where('et_proposal.sno', $proposal_edit_id)->first();
      $leadData = DB::table('et_lead')->where('et_lead.sno', $lead_id)->first();
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($proposalData->sno, 'encrypt');

      //   $Link ='https://dev.erp.elysiumtechnologies.com/manage_proposal/send_proposal/'.$encrypted_values;
      $Link = url('manage_proposal/send_proposal/' . $encrypted_values);

      //  communication Proposal
      $communicationStatus = DB::table('et_communication_handle')->where('module_name', 'Proposal Send')->first();
      $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id', $proposalData->cre_id)->first();
      if ($communicationStatus && $communicationStatus->status == 0) {

        if (!$proposalData->temp_send_link) {
          $channelId = 4;
          $shortUrlData = $this->shortenUrl($Link, $channelId);
          $shortUrl = $shortUrlData['shorturl'];
          $urlId = $shortUrlData['id'];
          if ($shortUrl) {
            DB::table('et_proposal')
              ->where('sno', $proposalData->sno)
              ->update(['temp_send_link' => $shortUrl]);

            DB::table('et_chotta_links')->insert([
              'branch_id' => $branch_id,
              'chotta_link_id' => $urlId,
              'chotta_short_link' => $shortUrl,
              'large_encrypt_link' => $Link,
              'link_type' => 'Proposal Send',
              'proposal_id' => $proposalData->sno,
              'created_by' => $user_id,
              'updated_by' => $user_id,
            ]);
          }
        }

        $proposalUrl = DB::table('et_proposal')->where('et_proposal.sno', $proposal_edit_id)->first();

        $shortsendUrl = $proposalUrl->temp_send_link;

        $proposal_key = basename($shortsendUrl);


        $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

        $cre = StaffModel::where('sno', $proposalData->created_by)->orderBy('sno', 'desc')->first();


        $cre_mobile = $cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;

        $lead_name = $leadData->lead_name;
        $lead_email_id = $leadData->lead_email_id;
        $lead_mobile = $leadData->lead_mobile;
        // // sms proposal send
        if ($communicationStatus->sms == 0) {
          if ($lead_mobile) {

            $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '4_PhDiZone_Proposal_Template')->first();
            $authkey = $result_sms ? $result_sms->authkey : '';
            $sender_id = $result_sms ? $result_sms->sender_id : '';
            $template_id = $result_sms ? $result_sms->template_id : '';
            $country_code = $result_sms ? $result_sms->country_code : '';
            $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
            $mobile_number = $country_code . $lead_mobile;


            $proposal_sms_id = $proposalData->proposal_id ?? 'PRO-00001/06/2025';

            // Replace placeholders with actual values
            $replacement_values = [$lead_name, $proposal_sms_id, $shortsendUrl, $cre_mobile];
            $message_content = preg_replace_callback(
              '/\{#var#\}/',
              function () use (&$replacement_values) {
                return array_shift($replacement_values);
              },
              $message_content
            );

            $route = "default";
            $postData = array(
              'authkey' => $authkey,
              'mobiles' => $mobile_number,
              'message' => $message_content,
              'sender' => $sender_id,
              'route' => $route,
            );

            // API URL
            $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

            // Initialize the resource
            $ch = curl_init();
            curl_setopt_array($ch, array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_POST => true,
              CURLOPT_POSTFIELDS => $postData,
              CURLOPT_SSL_VERIFYHOST => 0,
              CURLOPT_SSL_VERIFYPEER => 0,
            ));

            // Get response
            $response = curl_exec($ch);
            // return $response;
            $err = curl_error($ch);
            curl_close($ch);
          }
        }

        // email proposal Send
        if ($communicationStatus->email == 0) {
          if ($lead_email_id) {
            $emailTemplate_id = 1; // proposal send Template Id
            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();

            // Gender condition
            $genderPrefix = 'Mr/Ms'; // Default value
            if ($leadData->lead_gender == 1) {
              $genderPrefix = 'Mr';
            } elseif ($leadData->lead_gender == 2) {
              $genderPrefix = 'Ms';
            }




            $content = $emailTemplate->email_subject;

            $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);

            $content = str_replace('#customer_name', $lead_name, $content);
            $content = str_replace('#proposal_id', $proposalData->proposal_id ?? 'PRO-00001/06/2025', $content);
            $content = str_replace('#link', $shortsendUrl, $content);
            $content = str_replace('#entity_name',  $entityData ? $entityData->entity_name :  'Elysium Technology', $content);
            $content = str_replace('#CREname', $cre->nick_name ?? "Alex", $content);
            $content = str_replace('#customer_care_no',  $cre_mobile ?? '8220011465', $content);
            $branchNo = $branch->mobile;
            $branchemail = $branch->mail;
            $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone/';
            $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
            $url = 'phdizone.com';

            $mailData = [
              'url'         => $url,
              'subject'     => $dynamicSubject,
              'content'     => $content,
              'branchNo'    => $branchNo,
              'branchemail' => $branchemail, // Use the message content from the request
              'fbLink'      => $fbLink,      // Use the message content from the request
              'instaLink'   => $instaLink,   // Use the message content from the request
              'salesMobile' => $cre_mobile ?? '8220011465',
            ];

            $to_address = $lead_email_id;
            $from_address = 'elysiumtechnology@elysium.community';
            $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';


            Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
          }
        }
        // whatsapp proposal send
        if ($communicationStatus->whatsapp == 0) {
          if ($lead_mobile) {


            // $templateName  = "hello_world";
            $templateName  = "proposal_phdizone";

            $hasHeader  = false; // Example flag: set based on template
            $hasBody    = false; // Example flag: set based on template
            $hasFooter  = false; // Example flag: set based on template
            $hasButton  = false;
            $components = [];
            $couponCode = " ";
            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
            // $currentHour = date('H'); // Get current hour in 24-hour format
            if ($currentHour >= 5 && $currentHour < 12) {
              $greeting = 'Good Morning';
            } elseif ($currentHour >= 12 && $currentHour < 18) {
              $greeting = 'Good Afternoon';
            } else {
              $greeting = 'Good Evening';
            }

            if ($templateName == 'proposal_phdizone') {
              // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
              $headerImage =  url('public/assets/phdizone_images/OnBoard.jpg');
              $couponCode  = 'NOOFFER';
              $buttonIndex = 1;
              $bodyText    = [
                [
                  'type'           => 'text',
                  'text'           => $lead_name,
                  'parameter_name' => 'customer_name',
                ],
                [
                  'type'           => 'text',
                  'text'           => $proposalData->proposal_id,
                  'parameter_name' => 'proposal_id',
                ],
                [
                  'type'           => 'text',
                  'text'           => $proposal_key,
                  'parameter_name' => 'proposal_key',
                ],
                [
                  'type'           => 'text',
                  'text'           => $cre_mobile ?? '8220011465',
                  'parameter_name' => 'customercare_number',
                ],
              ];
              $hasHeader = true;
              $hasBody   = true;
              $hasButton = true;
            }

            // Add Header if required
            if ($hasHeader) {
              $components[] = [
                'type'       => 'header',
                'parameters' => [
                  [
                    'type'  => 'image',
                    'image' => [
                      'link' => $headerImage, // Dynamically set header image
                    ],
                  ],
                ],
              ];
            }

            // Add Body if required
            if ($hasBody) {
              $components[] = [
                'type'       => 'body',
                'parameters' => $bodyText,
              ];
            }

            // Add Footer if required
            if ($hasButton) {
              $components[] = [
                'type'       => 'button',
                'sub_type'   => 'url',
                'index'      => 0,
                'parameters' => [
                  [
                    'type' => 'text',
                    'text' => $proposal_key,
                  ],
                ],
              ];
            }


            $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id', $entity_id)->orderBy('sno', 'desc')->first();
            $dynamicParameters         = $templateParameters[$templateName] ?? [];
            $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
            $accessToken               = $whatsappApi->access_tokken ?? '';
            $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';

            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

            $countryCode  = $leadData->inter_calls ? ($leadData->inter_calls == 0 ? '+91' : '+' . $leadData->inter_calls) : '+91';
            $to           = $lead_mobile;
            $languageCode = 'en';

            if (strpos($to, $countryCode) !== 0) {
              $to = $countryCode . $to;
            }

            $message = 'test~message';
            if (empty($components)) {
              $payload = [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'template',
                'template'          => [
                  'name'     => $templateName,
                  'language' => [
                    'code' => $languageCode,
                  ],
                ],
              ];
            } else {
              $payload = [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'template',
                'template'          => [
                  'name'       => $templateName,
                  'language'   => [
                    'code' => $languageCode,
                  ],
                  'components' => $components,
                ],
              ];
            }

            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            if ($response['status'] == 200) {
            } else {
              return response([
                'status' => 404,
                'message' => 'Failed to send message',
                'error_msg' => $response['error'],
              ], 400);
            }
          }
        }
      } else {
        $old_customer_check = 1;
        if (!$proposalData->temp_send_link) {
          //  Skip Communication For Old Customer
          DB::table('et_proposal')
            ->where('sno', $proposal_edit_id)
            ->update([
              'temp_send_link' => $Link,
              'old_customer_check' => $old_customer_check,
            ]);
        }
      }
    }

    if ($proposal) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Proposal Created Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Create the Proposal!'
      ]);
    }
    return redirect('customer_management/manage_proposal');
  }


  public function paymentSlotDetailsRevised($id, Request $request)
  {

    $data = DB::table('et_temp_proposal_cart')
      ->select(
        'et_product.*',
        'et_product_category.product_category_name',
        'et_temp_proposal_cart.sno as cart_id',
        DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
        DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_revised_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->get();

    $productCart = DB::table('et_temp_proposal_cart')
      ->select(
        'et_product.*',
        'et_product_category.product_category_name',
        'et_temp_proposal_cart.sno as cart_id',
        DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
        DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_revised_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->first();
    if ($productCart === null) {
      $productCart = (object) [
        'product_names' => '',
        'product_category_names' => ''
      ];
    }
    $product_names = [];
    $product_Category_names = [];
    $slot_amount = 0;
    $seen_product_ids = [];
    $seen_category_ids = [];

    $propsal_data = DB::table('et_proposal')->where('sno', $id)->first();

    $slotUpdate = 0;
    $slotCount = 0;

    foreach ($data as $single) {
      $slot = DB::table('et_proposal_pay_slot')
        ->where('proposal_sno', $propsal_data->sno)
        ->where('status', 0)
        ->get();

      if (!in_array($single->sno, $seen_product_ids)) {
        $product_names[] = $single->product_name;
        $seen_product_ids[] = $single->sno;
      }
      if (!in_array($single->product_category_id, $seen_category_ids)) {
        $product_Category_names[] = $single->product_category_name;
        $seen_category_ids[] = $single->product_category_id;
      }

      $slot_amount = $slot->sum('slot_amount');

      $slot_ids = $slot->pluck('sno')->toArray();
      $single->update_slot = $slot;

      if (count($slot) > 0) {
        $slotUpdate = 1;
        $slotCount = count($slot);
      }
    }

    $productCart->product_names = implode(', ', $product_names);
    $productCart->product_category_names = implode(', ', $product_Category_names);

    $slot_amount = $slot_amount;
    return response()->json([
      'status' => 200,
      'message' => $data->isNotEmpty() ? 'Products fetched successfully.' : 'No products found for this package.',
      'error_msg' => null,
      'data' => $data,
      'slot_amount' => $slot_amount,
      'productCart' => $productCart,
      'slotUpdate' => $slotUpdate,
      'slotCount' => $slotCount,
    ]);
  }

  public function product_list_proposal_revised($id)
  {
    $data = DB::table('et_temp_proposal_cart')->where('status', 0)
      ->where('temp_revised_id', $id)
      ->orderBy('sno', 'asc')
      ->get();
    $product_cart_count = count($data);
    //   $currency_id=$request->currency_id;
    //   return $currency_id;
    $productCounts = $data->groupBy('product_id')->map(function ($group) {
      return $group->count();
    });
    $html = '';
    $over_all_total = 0;
    $totalMinutes = 0;



    foreach ($data as $inx => $list) {
      $product_id = $list->product_id;
      $currency_id = $list->currency_id;
      $product_count = $productCounts[$product_id];
      $product_data =  ProductModel::select('et_product.*', 'et_product_category.product_category_name')
        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
        ->where('et_product.sno', $product_id)->first();
      $duration    = $product_data->duration ?? 0;
      $duration_in = $product_data->duration_in;
      $count = $list->count ?? 1; // If count is available
      // Convert everything to minutes
      $durationInMinutes = match ($duration_in) {
        0 => $duration,            // Already in Minutes
        1 => $duration * 60,       // Hours → Minutes
        2 => $duration * 1440,     // Days → Minutes
        default => 0,
      };

      $priceData = DB::table('et_price_book')->select('et_price_book.*', 'et_country_currencies.currency_symbol')
        ->join('et_country_currencies', 'et_price_book.currency_id', '=', 'et_country_currencies.sno')
        ->where('et_price_book.currency_id', $currency_id)
        ->where('et_price_book.product_id', $product_id)
        ->first();



      $totalMinutes += $durationInMinutes * $count;

      // Set unit
      $in = match ($duration_in) {
        0 => 'Minute',
        1 => 'Hours',
        2 => 'Days',
        default => '',
      };

      $dura = $duration . ' ' . $in;
      $variant = '';
      $variable_amount = 0;
      $variant_variable_ids = json_decode($list->variant_variable_ids ?? '[]', true);

      // If json_decode returns a string instead of an array, ensure it defaults to an empty array
      if (!is_array($variant_variable_ids)) {
        $variant_variable_ids = [];
      }

      $selected_pairs = [];
      foreach ($variant_variable_ids as $v) {
        // Ensure that $v is an array and has the keys you expect
        if (is_array($v) && isset($v['variant_id']) && isset($v['variable_id'])) {
          $selected_pairs[$v['variant_id']] = $v['variable_id'];
        }
      }

      $selected_variants = array_column($variant_variable_ids, 'variant_id');



      if (!empty($variant_variable_ids)) {
        $variant .= '
                  <div class="border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 mb-2"></div>
                  <div class="d-flex align-items-center justify-content-between">
                      <div class="text-black fw-semibold fs-7 mb-2"><u>Variants</u></div>
                      <a href="javascript:;" class="fw-semibold fs-5 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '">
                          <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Variants">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" id="Edit">
                                  <path fill="#888888" fill-rule="evenodd" d="M20.12,1 L17.309,3.86 L20.14,6.69 L22.95,3.83 L20.12,1 Z M1,2 L1,23 L21.999,23 L21.999,9.07 L19,12.07 L19,20 L3.999,20 L3.999,5 L11.93,5 L14.93,2 L1,2 Z M6,15.171 L6,17.999 L8.828,17.999 L18.728,8.1 L15.899,5.272 L6,15.171 Z"></path>
                              </svg>
                          </span>
                      </a>
                  </div>
                  <!-- Modal -->
                   <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" id="kt_modal_choose_me_triger_edit' . htmlspecialchars($product_id) . '">
                  <div class="modal fade" id="kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                      <div class="modal-dialog modal-lg">
                          <div class="modal-content rounded">
                              <div class="modal-header justify-content-end border-0 pb-0">
                                  <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                      <span class="svg-icon svg-icon-1">
                                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                                              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                          </svg>
                                      </span>
                                  </div>
                              </div>

                              <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                                  <div class="mb-8 text-center">
                                      <h3 class="text-center mb-4 text-black">Update Product</h3>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_name) . '</div>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_category_name) . '</div>
                                  </div>

                                  <div class="divider mt-1 mb-1">
                                      <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                                  </div>
                                  <input type="hidden"id="Inserted_id_product_edit" name="Inserted_id_product_edit" value="' . htmlspecialchars($list->temp_proposal_id) . '">
                                  <input type="hidden" name="product_id_edit" value="' . htmlspecialchars($product_id) . '">
                                  <div class="row">
                                      <div class="col-lg-12 mb-1">
                                          <div class="bg-gray-200i rounded">
                                              <div class="scroll-y max-h-400px py-2 px-3">';

        $get_variants_loop = ManageProductVaiantModel::where('product_id', $product_id)->get();

        if ($get_variants_loop->count()) {
          foreach ($get_variants_loop as $vari) {
            $variant_checked = in_array($vari->sno, $selected_variants);
            $show_div = $variant_checked ? 'block' : 'none';
            $get_variables_loop = ManageProductVariableModel::where('product_variant_id', $vari->sno)->get();
            $variant .= '<div class="px-3 pt-1">
                                                                    <div class="form-check form-check-inline mb-1 mt-1">
                                                                        <input class="form-check-input" type="checkbox" id="variant_check_box_edit' . htmlspecialchars($vari->sno) . '" onclick="variant_check_func_edit(' . htmlspecialchars($vari->sno) . ');" ' . ($variant_checked ? 'checked' : '') . ' />
                                                                        <label class="text-black mb-1 fs-6 fw-semibold">' . htmlspecialchars($vari->product_variant_name) . '</label>
                                                                    </div>
                                                                    <div id="variant_check_div_edit' . htmlspecialchars($vari->sno) . '" style="display: ' . $show_div . ';">
                                                                        <div class="row mt-2">';

            foreach ($get_variables_loop as $vrlist) {
              $is_selected = (isset($selected_pairs[$vari->sno]) && $selected_pairs[$vari->sno] == $vrlist->sno);
              $variant .= '<div class="col-lg-4 mb-1">
                                                                      <div class="form-check">
                                                                          <input class="form-check-input me-0 variable_radio_edit' . htmlspecialchars($vari->sno) . '" type="radio" name="variable_radio_[' . htmlspecialchars($vari->sno) . ']" value="' . htmlspecialchars($vrlist->sno) . '" ' . ($variant_checked ? '' : 'disabled') . ' ' . ($is_selected ? 'checked' : '') . ' />
                                                                          <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                              <span>' . htmlspecialchars($vrlist->variable_name) . '</span>
                                                                              <span class="ms-1 me-1">-</span>
                                                                              <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; ' . number_format($vrlist->variable_amount) . '</span>
                                                                          </label>
                                                                      </div>
                                                                  </div>';
            }

            $variant .= '</div>
                                                                  <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                                              </div>
                                                          </div>';
          }
        } else {
          $variant .= '<label class="row text-center">
                                                                <span class="text-danger fs-5">No Variant found for this <b class="text-black">' . htmlspecialchars($product_data->product_name) . '</b> Product</span>
                                                            </label>';
        }

        $variant .= '
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                  <div class="d-flex justify-content-center align-items-center mt-8">
                                      <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                      <button type="button" class="btn btn-primary" onclick="edit_product(' . htmlspecialchars($product_id) . ')" id="product_button_edit_' . htmlspecialchars($product_id) . '">Update Product</button>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>';
      }



      foreach ($variant_variable_ids as $pair) {
        $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
        $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;

        if ($variant_id && $variable_id) {
          $get_variants = ManageProductVaiantModel::where('sno', $variant_id)->first();
          $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();


          $priceBookAmount = $get_variables->variable_amount; // Default amount from loop
          if ($currency_id != 70) {
            $variant_details = json_decode($priceData->varient_details, true);
            // Check if $variant_details is an array and loop through it to find the correct amount
            if (is_array($variant_details)) {
              foreach ($variant_details as $variant_detail) {
                if ($variant_detail['variable_id'] == $variable_id) {
                  $priceBookAmount = $variant_detail['amount'];
                  break;
                }
              }
            }
          }
          if ($get_variants && $get_variables) {
            $variable_amount += $get_variables->variable_amount;

            $variant .= '
              <div class="d-flex align-items-center justify-content-between flex-wrap">
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variants->product_variant_name) . '">' . htmlspecialchars($get_variants->product_variant_name) . '</label>
                      <div class="d-block">
                          <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variables->variable_name) . '">' . htmlspecialchars($get_variables->variable_name) . '</label>
                      </div>
                  </div>
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-6">'
              . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;')
              . ' ' . number_format($priceBookAmount) . '</label>
                  </div>
              </div>';
          }
        }
      }


      $total_amount = $list->cust_product_amount ?? $variable_amount + $product_data->base_price;
      $over_all_total += $total_amount;
      $productBasePrice = $product_data->base_price;
      if ($currency_id != 70) {
        $productBasePrice = $priceData->base_price;
      }

      $html .= '<div class="mb-1" id="cal_prod_az_' . $inx . '">
                      <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 cal_btt rounded px-1 py-1" id="cal_prod_hd_' . $inx . '">
                        <div class="d-flex align-items-center">
                          <div class="me-2 cursor-pointer">
                            <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="cal_prod_on_of(' . $inx . ');" id="cal_prod_tlp_' . $inx . '">
                              <i class="mdi mdi-plus fs-4" id="cal_prod_plus_btton_' . $inx . '"></i>
                            </a>
                          </div>
                          <div class="mb-0">
                            <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_name) . '">' . htmlspecialchars($product_data->product_name) . '</div>
                            <div class="d-block">
                              <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_category_name) . '">' . htmlspecialchars($product_data->product_category_name) . '</label>
                            </div>
                          </div>
                        </div>
                        <div class="mb-0">
                          <label class="fs-4 fw-semibold text-black">'
        . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;')
        . ' ' . number_format($total_amount) . '</label>
                          <input type="hidden" class="cart_product_amount" value="' . $total_amount . '">
                          <a href=" javascript:;" class="ms-1 fw-semibold fs-5" onclick="remove_product(' . intval($list->sno) . ',' . $product_id . ')">
                            <span title="Remove">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" width="20" height="20" id="X">
                                <g id="Page-1" fill="none" fill-rule="evenodd" stroke="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1">
                                  <g id="Artboard" stroke="#999999" stroke-width="2" transform="translate(-1447 -2191)">
                                    <g id="x-circle" transform="translate(1448 2192)" fill="none" class="color000000 svgShape">
                                      <circle id="Oval" cx="10" cy="10" r="10" fill="none" class="color000000 svgShape"></circle>
                                      <path id="Shape" d="m13 7-6 6M7 7l6 6" fill="none" class="color000000 svgShape"></path>
                                    </g>
                                  </g>
                                </g>
                              </svg>
                            </span>
                          </a>
                        </div>
                      </div>
                      <div class="px-3 py-1 mb-0" id="cal_prod_tbox_' . $inx . '" style="display: none;">
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Products</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">'
        . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;')
        . ' ' . number_format($productBasePrice) . '</label>
                          </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Durations</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">' . htmlspecialchars($dura) . '</label>
                          </div>
                        </div>
                        ' . $variant . '
                      </div>
                    </div>';
    }
    // Time unit conversions
    $minutesInMonth = 30 * 1440; // 43,200
    $minutesInDay = 1440;
    $minutesInHour = 60;

    // Breakdown
    $months = floor($totalMinutes / $minutesInMonth);
    $remainingAfterMonths = $totalMinutes % $minutesInMonth;

    $days = floor($remainingAfterMonths / $minutesInDay);
    $remainingAfterDays = $remainingAfterMonths % $minutesInDay;

    $hours = floor($remainingAfterDays / $minutesInHour);
    $minutes = round($remainingAfterDays % $minutesInHour);

    // Build result string conditionally
    $durationParts = [];

    if ($months > 0) {
      $durationParts[] = "{$months} Month" . ($months != 1 ? 's' : '');
    }
    if ($days > 0 || $months > 0) {
      $durationParts[] = "{$days} Day" . ($days != 1 ? 's' : '');
    }
    if ($hours > 0 || $days > 0 || $months > 0) {
      if ($hours > 0) {
        $durationParts[] = "{$hours} Hour" . ($hours != 1 ? 's' : '');
      }
    }

    if ($minutes > 0 || empty($durationParts)) {
      $durationParts[] = "{$minutes} Minute" . ($minutes != 1 ? 's' : '');
    }

    $totalDuration = implode(' ', $durationParts);
    $overall_totalDuration = $totalDuration ?: '0';



    $product_ids = $data->pluck('product_id')->toArray();
    return response()->json([
      'status' => 200,
      'message' => $data->isNotEmpty() ? 'Products fetched successfully.' : 'No products found for this package.',
      'error_msg' => null,
      'data' => $html,
      'product_ids' => $product_ids,
      'over_all_total' => $over_all_total,
      'overall_totalDuration' => $overall_totalDuration,
      'productCounts' => $productCounts,
      'product_cart_count' => $product_cart_count,
    ]);
  }

  public function product_cart_List_revised(Request $request)
  {

    $id = $request->id;
    $data = DB::table('et_temp_proposal_cart')
      ->select(
        'et_product.*',
        'et_product_category.product_category_name',
        'et_temp_proposal_cart.sno as cart_id',
        DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
        DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_revised_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }

  public function proposal_product_add_revised(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    // Get raw JSON input
    $payload = $request->all(); // use $request->getContent() and json_decode if content-type is not handled automatically

    $Inserted_id = $payload['inserted_id'] ?? null;
    $product_id  = $payload['product_id'] ?? null;
    $variants    = $payload['variants'] ?? [];
    $currency_id    = $payload['currency_id'] ?? [];
    $product_amount  = $payload['product_amount'] ?? null;
    $product_edit_amount  = $payload['product_edit_amount'] ?? null;

    if (!$Inserted_id || !$product_id) {
      return response()->json([
        'status' => false,
        'message' => 'Missing required data.',
        'data' => null
      ]);
    }

    // Store variants as JSON for now (you can normalize later if needed)
    $variant_variable_ids = !empty($variants) ? json_encode($variants) : null;

    // Check if record already exists
    // $existing = TempProposalModel::where('temp_revised_id', $Inserted_id)
    //   ->where('product_id', $product_id)
    //   ->first();

    // if ($existing) {
    //   $existing->variant_variable_ids = $variant_variable_ids;
    //   $existing->updated_by = $user_id;
    //   $existing->status = 0;
    //   $existing->save();
    //   $record = $existing;
    // } else {
    $record = new TempProposalModel();
    $record->temp_revised_id = $Inserted_id;
    $record->product_id = $product_id;
    $record->currency_id = $currency_id;
    $record->cust_product_amount = $product_edit_amount;
    $record->product_amount = $product_amount;
    $record->variant_variable_ids = $variant_variable_ids;
    $record->created_by = $user_id;
    $record->updated_by = $user_id;
    $record->status = 0;
    $record->save();
    // }

    $proposalPackageCart = DB::table('et_proposal_package_cart')->where('status', 0)
      ->where('proposal_sno', $Inserted_id)
      ->get();

    if ($proposalPackageCart) {
      DB::table('et_proposal_package_cart')
        ->where('proposal_sno', $Inserted_id)
        ->update(['status' => 2]);
    }


    return response()->json([
      'status' => true,
      'message' => 'Product variant(s) added to package successfully.',
      'data' => $record
    ]);
  }


  public function AddPaymentSlotRevised(Request $request)
  {

    // return $request;
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;

    $pay_proposal_id = $request->input('pay_proposal_id');
    $proposal_data = DB::table('et_proposal')->where('sno', $pay_proposal_id)->first();


    $total_amount_hidden = $request->input('payment_slot_total_hidden');
    $total_amount = $request->input('payment_slot_total_amt');
    $product_id = $request->input('payment_slot_product_id');
    $package = $request->input('package_payment_slot');
    $package_id = $request->input('payment_slot_package_id');
    $curency_format = $request->input('curency_format');

    $branch_data = DB::table('et_branch')->where('sno', $branch_id)->first();

    $gstPercentage = $branch_data->gst_percentage;

    if ($package == 1) {
      // $cart_ids=   DB::table('et_proposal_pay_slot')
      //     ->where('proposal_id', $pay_proposal_id)
      //     ->where('status', 0)
      //     ->where('product_cart_id' ,'!=',0)->pluck('product_cart_id');

      DB::table('et_proposal_pay_slot')
        ->where('proposal_sno', $pay_proposal_id)
        ->where('status', 0)
        ->where('product_cart_id', '!=', 0)
        ->update(['status' => 2]);

      //   if($cart_ids){
      //         TempProposalModel::whereIn('sno', $cart_ids)->update(['status' => 2]);
      //     }

      $slots = [];
      foreach ($request->all() as $key => $value) {
        if (preg_match('/^payment_slot_id_packg_(\d+)$/', $key, $matches)) {
          $slots[] = (int)$matches[1];
        }
      }
      // return $slots;
      if ($slots) {
        $firstMilestoneSet = false;
        foreach ($slots as $index) {

          $category_check = DB::table('et_proposal_pay_slot')->orderBy('sno', 'desc')->first();


          $propo_pay_slot_id = '';
          if (!$category_check) {
            $year = date('Y');
            $month = date('m');
            $propo_pay_slot_id = 'PSLT-00001/' . $month . '/' . $year;
          } else {
            $year = date('Y');
            $month = date('m');
            $Inserted_id = $category_check->sno + 1;
            $data = $category_check->propo_pay_slot_id;
            $slice = explode('/', $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int) $result + 1;
            $request_id = sprintf('PSLT-%05d', $next_number);
            $propo_pay_slot_id = $request_id . '/' . $month . '/' . $year;
          }

          $lastData = DB::table('et_proposal_pay_slot')->where('proposal_sno', $pay_proposal_id)->where('status', 0)->orderBy('sno', 'desc')->first();

          if ($lastData) {
            $total_amount = $lastData->balance_amount;
          } else {
            $total_amount = $request->input('payment_slot_total_amt');
          }
          $slot_id = $request->input("payment_slot_id_packg_{$index}");
          $slot_amount = $request->input("payment_slot_amount_packg_{$index}");

          $slot_description = $request->input("slot_description_packg_{$index}");
          $to_start_deliver = $request->input("to_start_deliver_packg_{$index}");




          $base_amount = ($slot_amount * 100) / (100 + $gstPercentage);
          $gst_amount = $slot_amount - $base_amount;

          $balance_amount = $total_amount > 0 ? $total_amount - $slot_amount : 0;
          // Get deliverables and notes as arrays and JSON encode them
          $slot_deliverables = $request->input("slot_deliverables_packg_{$index}", []);
          $slot_notes = $request->input("slot_notes_packg_{$index}", []);

          $json_deliverables = json_encode($slot_deliverables);
          $json_notes = json_encode($slot_notes);

          $first_milestone = $firstMilestoneSet ? 0 : 1;
          $firstMilestoneSet = true; // After first insert, all others become 0

          DB::table('et_proposal_pay_slot')->insert([
            'propo_pay_slot_id' => $propo_pay_slot_id,
            'proposal_sno' => $pay_proposal_id,
            'lead_id' => $proposal_data->lead_id,
            'package_id' => $package_id,
            'slot_id' => $slot_id,
            'slot_amount' => $slot_amount,
            'slot_balance' => $slot_amount,
            'payable_amount' => $slot_amount,
            'start_deliver_work' => $to_start_deliver,
            'total_amount' => $total_amount_hidden ?? $total_amount,
            'balance_amount' => $balance_amount,
            'slot_description' => $slot_description,
            'deliverable_ids' => $json_deliverables,
            'slot_notes_ids' => $json_notes,
            'gst_amount' => $gst_amount ?? 0,
            'branch_id' => $branch_id,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'first_milestone' => $first_milestone
          ]);
        }
      }
    } else {

      DB::table('et_proposal_pay_slot')
        ->where('proposal_sno', $pay_proposal_id)
        ->where('status', 0)
        ->where('package_id', '!=', 0)
        ->update(['status' => 2]);

      // Count how many slots are in the request
      $slots = [];
      foreach ($request->all() as $key => $value) {
        if (preg_match('/^payment_slot_id_(\d+)$/', $key, $matches)) {
          $slots[] = (int)$matches[1];
        }
      }

      if ($proposal_data) {
        $firstMilestoneSet = false;
        foreach ($slots as $index) {

          $category_check = DB::table('et_proposal_pay_slot')->orderBy('sno', 'desc')->first();

          if (!$category_check) {
            $year = date('Y');
            $month = date('m');
            $propo_pay_slot_id = 'PSLT-00001/' . $month . '/' . $year;
          } else {
            $year = date('Y');
            $month = date('m');
            $Inserted_id = $category_check->sno + 1;
            $data = $category_check->propo_pay_slot_id;
            $slice = explode('/', $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int) $result + 1;
            $request_id = sprintf('PSLT-%05d', $next_number);
            $propo_pay_slot_id = $request_id . '/' . $month . '/' . $year;
          }

          $lastData = DB::table('et_proposal_pay_slot')->where('proposal_sno', $pay_proposal_id)->where('status', 0)->orderBy('sno', 'desc')->first();

          if ($lastData) {
            $total_amount = $lastData->balance_amount;
          } else {
            $total_amount = $request->input('payment_slot_total_hidden');
          }

          $slot_id = $request->input("payment_slot_id_{$index}");
          $slot_amount = $request->input("payment_slot_amount_{$index}");

          $to_start_deliver = $request->input("to_start_deliver_{$index}");
          $slot_description = $request->input("slot_description_{$index}");




          $base_amount = ($slot_amount * 100) / (100 + $gstPercentage);
          $gst_amount = $slot_amount - $base_amount;

          $balance_amount = $total_amount > 0 ? $total_amount - $slot_amount : 0;

          $slot_deliverables_raw = $request->input("slot_deliverables_{$index}", []);
          $deliverables_grouped = [];

          foreach ($slot_deliverables_raw as $item) {
            if (strpos($item, '-') !== false) {
              [$productIndex, $value] = explode('-', $item);
              $deliverables_grouped[$productIndex][] = [
                'value' => $value,
                'status' => "0"
              ];
            }
          }

          // Same for notes
          $slot_notes_raw = $request->input("slot_notes_{$index}", []);
          $notes_grouped = [];

          foreach ($slot_notes_raw as $item) {
            if (strpos($item, '-') !== false) {
              [$productIndex, $value] = explode('-', $item);
              $notes_grouped[$productIndex][] = [
                'value' => $value,
                'status' => "0"
              ];
            }
          }

          // Convert to JSON
          $json_deliverables = json_encode($deliverables_grouped);
          $json_notes = json_encode($notes_grouped);

          $first_milestone = $firstMilestoneSet ? 0 : 1;
          $firstMilestoneSet = true; // After first insert, all others become 0

          DB::table('et_proposal_pay_slot')->insert([
            'propo_pay_slot_id' => $propo_pay_slot_id,
            'proposal_sno' => $pay_proposal_id,
            'lead_id' => $proposal_data->lead_id,
            'product_cart_id' => $product_id,
            'cart_ids' => json_encode($request->input("product_cart_id_{$index}", [])),
            'slot_id' => $slot_id,
            'slot_amount' => $slot_amount,
            'slot_balance' => $slot_amount,
            'payable_amount' => $slot_amount,
            'start_deliver_work' => $to_start_deliver,
            'total_amount' => $total_amount_hidden,
            'balance_amount' => $balance_amount,
            'slot_description' => $slot_description,
            'deliverable_ids' => $json_deliverables,
            'slot_notes_ids' => $json_notes,
            'gst_amount' => $gst_amount ?? 0,
            'branch_id' => $branch_id,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'first_milestone' => $first_milestone
          ]);
        }

        // Example: Insert into DB (assuming you have a model or DB table for it)

      }
    }

    return redirect()->back();
  }

  public function updateProposalRevised(Request $request)
  {

    $request->validate([
      'proposal_id' => 'required',
    ]);
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $preProposal = DB::table('et_proposal')
      ->where('sno', $request->proposal_id)
      ->first();

    if (!$preProposal) {
      return response()->json(['status' => 'error', 'message' => 'Proposal not found'], 404);
    }
    $created_By = $request->post_sale_staff ?? $user_id;
    DB::table('et_proposal')
      ->where('sno', $request->proposal_id)
      ->update([
        'addtional_charges_ids' => json_encode($request->additional_charges_ids),
        'discount_id' => $request->discount_id_hidden,
        'service_title' => $request->service_title,
        'estimate_date' => $request->estimate_date ? date('Y-m-d', strtotime($request->estimate_date)) : '',
        'due_date' => $request->prposal_due_date ? date('Y-m-d', strtotime($request->prposal_due_date)) : '',
        'currency_id' => $request->prposal_currency,
        'cre_id' => $request->proposal_cre,
        'milestone_count' => $request->milestone_count,
        'delivery_duration' => $request->delivery_duration,
        'delivery_duration_end' => $request->delivery_duration_end,
        'topic' => $request->proposal_topic,
        'domain_ids' => json_encode($request->proposal_domain),
        'package_id' => $request->package_id ?? 0,
        'referral_id' => $request->proposal_referral_staff ?? 0,
        'old_customer_check' => $request->old_customer_check ?? 0,
        'page_word' => $request->page_word,
        'page_word_count' => $request->page_word_count ?? 0,
        'created_by' => $created_By ?? $user_id,
        'updated_by' => $user_id,
      ]);


    $proposal = DB::table('et_proposal')
      ->where('sno', $request->proposal_id)
      ->first();

    if ($request->has('add_ons')) {

      DB::table('et_proposal_addon_product')
        ->where('proposal_sno', $request->proposal_id)
        ->update(['status' => 2]);


      foreach ($request->input('add_ons') as $addOnId) {
        $variant_id = $addOnId['varient_id'];
        $add_on_id = $addOnId['add_on_id'];
        $addon_amount = $addOnId['amount'];


        if ($proposal->currency_id != 70) {
          // If currency_id is not 70, fetch amount from et_price_book
          $priceDataAddon = DB::table('et_price_book')
            ->where('currency_id', $proposal->currency_id)
            ->where('status', 3)
            ->get();

          $addon_data = DB::table('et_manage_addon_variant')
            ->where('sno', $variant_id)
            ->first();

          // Find the addon amount from varient_details where variant_id matches
          $addon_amount = 0; // Default to 0 if no match found
          foreach ($priceDataAddon as $addon) {
            $variantDetails = json_decode($addon->varient_details);
            foreach ($variantDetails as $variant) {
              if ($variant->variant_id == $variant_id) {
                $addon_amount = $variant->amount; // Get the amount from varient_details
                break 2; // Exit both loops once the matching variant is found
              }
            }
          }
        } else {
          // If currency_id is 70, fetch data from et_manage_addon_variant table
          $addon_data = DB::table('et_manage_addon_variant')
            ->where('sno', $variant_id)
            ->first();

          // Set the addon_amount based on the fetched data
          $addon_amount = $addon_data ? $addon_data->amount : 0;
        }

        //  return $addon_amount;
        // Insert into et_proposal_addon_product table
        DB::table('et_proposal_addon_product')->insert([
          'proposal_sno' => $request->proposal_id,
          'add_on_id' => $add_on_id,
          'free_paid' => isset($addon_data) ? $addon_data->free_paid : null,
          'addon_variant_id' => $variant_id,
          'addon_amount' => $addon_amount,
          'created_by' => $user_id ?? 0,
          'updated_by' => $user_id ?? 0,
          'branch_id' => $branch_id ?? 0,
        ]);
      }
    }


    if ($request->package_id > 0) {

      $proposalPackageCart = DB::table('et_proposal_package_cart')
        ->where('status', 0)
        ->where('proposal_sno', $request->proposal_id)
        ->pluck('product_id')
        ->toArray();

      $packageData = DB::table('et_package_product')
        ->where('status', 0)
        ->where('package_id', $request->package_id)
        ->orderBy('sno', 'asc')
        ->get();

      $packageTemp = DB::table('et_package')
        ->where('status', 0)
        ->where('sno', $request->package_id)
        ->first();

      if ($packageData->isNotEmpty()) {
        foreach ($packageData as $package) {
          $product_id = $package->product_id;

          $cust_product_amount = $request->cust_product_amounts[$product_id] ?? $package->product_amount;
          $original_product_amount = $request->original_product_amounts[$product_id] ?? $package->product_amount;
          $total_amount = $request->package_actual_price_hidden ?? $packageTemp->actual_amount;

          $data = [
            'package_id' => $request->package_id,
            'product_id' => $product_id,
            'product_amount' => $package->product_amount,
            'variant_variable_ids' => $package->variant_variable_ids,
            'cust_product_amount' => $cust_product_amount,
            'original_product_amount' => $original_product_amount,
            'total_package_amount' => $total_amount,
            'updated_by' => $user_id,
          ];

          if (in_array($product_id, $proposalPackageCart)) {
            // Update existing row
            DB::table('et_proposal_package_cart')
              ->where('proposal_sno', $request->proposal_id)
              ->where('product_id', $product_id)
              ->update($data);
          } else {
            // Insert new row
            $data['proposal_sno'] = $request->proposal_id;
            $data['created_by'] = $user_id;
            $data['branch_id'] = $branch_id;

            DB::table('et_proposal_package_cart')->insert($data);
          }
        }
      }
    }

    return response()->json(['status' => 'success']);
  }

  public function RejectProposal($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $prps_id = $decryptedValue;

    $proposal = DB::table('et_proposal')
      ->select('et_proposal.*', 'et_staff.nick_name', 'et_staff.staff_name', 'et_entity.entity_name', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol')
      ->where('et_proposal.sno', $prps_id)
      ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
      ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
      ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
      ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
      ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
      ->where('et_proposal.status', '!=', 2)
      ->where('et_lead.status', '!=', 2)
      ->orderBy('et_proposal.sno', 'desc')
      ->first();

    if (!$proposal) {
      $content = "This proposal is no longer accessible because User Not Found!";
      return view('errors.link_expired', ['content' => $content,]);
    }



    DB::table('et_proposal')
      ->where('sno', $prps_id)
      ->update(['send_status' => 1]);

    $exchange_quote = 1;
    // if ($proposal->currency_code !== 'INR') {
    //     $response= $helper->convertFromINR($proposal->currency_code);   
    //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
    // }


    $branch_data = DB::table('et_branch')
      ->select(
        'et_branch.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
      ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
      ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
      ->where('et_branch.sno', $proposal->branch_id)
      ->first();



    $proposal->door_no = $branch_data->door_no;
    $proposal->area_street = $branch_data->area_street;
    $proposal->city_name =  $branch_data->city_name;
    $proposal->state_name =  $branch_data->state_name;
    $proposal->country_name =  $branch_data->country_name;
    $proposal->pincode =  $branch_data->pincode;
    $proposal->branch_mail =  $branch_data->mail;
    $proposal->branch_mobile =  $branch_data->mobile;
    $proposal->gst_no =  $branch_data->gst_no ?? "-";


    $lead_data = DB::table('et_lead')
      ->select(
        'et_lead.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
      ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
      ->where('et_lead.sno', $proposal->lead_id)
      ->first();

    $customer = DB::table('et_customer')
      ->select(
        'et_customer.*',
        'et_cities.name as city_name',
        'et_countries.name as country_name',
        'et_states.name as state_name'
      )
      ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
      ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
      ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
      ->where('et_customer.sno', $proposal->customer_id)
      ->where('et_customer.status', '!=', 2)
      ->orderBy('et_customer.sno', 'desc')
      ->first();

    $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
    $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
    $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
    $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
    $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
    $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
    $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
    $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
    $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';


    if ($proposal->discount_id > 0) {
      $discount = DB::table('et_manage_coupon')->where('et_manage_coupon.sno', $proposal->discount_id)->first();

      $proposal->discount_value = $discount->coupon_value;
      $proposal->discount_type = $discount->coupon_type == 'percentage' ? '1' : '2';
    }

    $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

    $domain_names = DB::table('et_domain')
      ->where('et_domain.status', 0)
      ->whereIn('sno', $domain_ids)
      ->pluck('domain_name')  // Get only domain_name column
      ->toArray();            // Convert Collection to array

    $domain_list = implode(', ', $domain_names);


    $proposal->domain_names = $domain_list;

    // return $proposal;
    $proposal->products = [];
    $packages = '';

    if ($proposal->product_package == 1) {

      $proposalProduct = DB::table('et_proposal_product_cart')
        ->select('et_proposal_product_cart.*', 'et_product.product_name', 'et_product_category.product_category_name')
        ->where('et_proposal_product_cart.status', 0)
        ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
        ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->where('et_proposal_product_cart.proposal_id', $proposal->proposal_id)
        ->get();

      $groupedProducts = [];
      $allSlotIds = [];
      $slotCount = 0;
      foreach ($proposalProduct as $product) {
        $product_id = $product->product_id;
        $cart_id = $product->cart_id;

        // Shared data fetched once per product_id
        if (!isset($groupedProducts[$product_id])) {
          $product_data = ProductModel::select('et_product.*')
            ->where('et_product.sno', $product_id)->first();

          $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
          $tools_ids = is_array($tools_ids) ? $tools_ids : [];

          $tools = DB::table('et_product_tools')
            ->whereIn('sno', $tools_ids)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->pluck('product_tools_name')
            ->toArray();

          $base_product = clone $product; // Copy to modify
          $base_product->tools_name = $tools;
          $base_product->product_name = $product->product_name;
          $base_product->product_category_name = $product->product_category_name;
          $base_product->cart_variants = [];
          $base_product->cart_slots = [];
          $base_product->total_amount_cart = 0;
          $base_product->product_amount = 0;

          $groupedProducts[$product_id] = $base_product;
        }

        // Compute variant data per cart
        $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
        $variable_amount = 0;
        $variant_names = [];
        $product_variant_name = '';
        $variable_name = '';

        foreach ($variant_variable_ids as $pair) {
          $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
          $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;

          if ($variant_id) {
            $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
            $product_variant_name = $get_variant->product_variant_name ?? '';
          }

          if ($variable_id) {
            $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
            if ($get_variables) {
              $variable_name = $get_variables->variable_name;
              $variable_amount += $get_variables->variable_amount;
            }
          }

          if ($product_variant_name && $variable_name) {
            $variant_names[] = "{$product_variant_name} - {$variable_name}";
          } elseif ($product_variant_name) {
            $variant_names[] = $product_variant_name;
          }
        }

        // $cart_total = $variable_amount + $product_data->base_price;
        $cart_total = $product->product_amount;
        $groupedProducts[$product_id]->total_amount_cart += $cart_total;

        // Add cart-specific variant names
        $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
        $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;


        // Fetch slots for this cart
        $slots = DB::table('et_proposal_pay_slot')
          ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
          ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
          ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
          ->where('et_proposal_pay_slot.status', 0)
          ->get();
        $slotCount = count($slots);

        // foreach ($slots as $slot) {
        //   $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
        //   if (!in_array($cart_id, $slot_cart_ids)) {
        //     continue;
        //   }

        //   $groupedProducts[$product_id]->product_amount += $slot->slot_amount;

        //   $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
        //   $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);

        //   $deliverable_items = $deliverables_map[$cart_id] ?? [];
        //   $slot_notes_items = $slot_notes_map[$cart_id] ?? [];

        //   $deliverable_ids = [];
        //   foreach ($deliverable_items as $d) {
        //     if (($d['status'] ?? '0') == '0') {
        //       $deliverable_ids[] = $d['value'];
        //     }
        //   }

        //   $slot_notes_ids = [];
        //   foreach ($slot_notes_items as $s) {
        //     if (($s['status'] ?? '0') == '0') {
        //       $slot_notes_ids[] = $s['value'];
        //     }
        //   }

        //   $deliverables = DB::table('et_product_delivarables')
        //     ->whereIn('sno', $deliverable_ids)
        //     ->where('status', 0)
        //     ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
        //     ->pluck('delivarable_name');

        //   $slot_notes = DB::table('et_slot_notes')
        //     ->whereIn('sno', $slot_notes_ids)
        //     ->where('status', 0)
        //     ->orderBy('sno', 'desc')
        //     ->pluck('slot_notes_name');

        //   // Assign deliverables and notes for this cart
        //   $slot->deliverables = $deliverables;
        //   $slot->slot_notes = $slot_notes;

        //   if (!isset($groupedProducts[$product_id]->cart_slots)) {
        //     $groupedProducts[$product_id]->cart_slots = [];
        //   }

        //   // Find if the slot already exists in the array
        //   $existingIndex = null;
        //   foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
        //     if ($existingSlot['sno'] === $slot->sno) {
        //       $existingIndex = $index;
        //       break;
        //     }
        //   }

        //   if ($existingIndex === null) {
        //     // Add new slot entry
        //     $groupedProducts[$product_id]->cart_slots[] = [
        //       'sno' => $slot->sno,
        //       'propo_pay_slot_id' => $slot->propo_pay_slot_id,
        //       'branch_id' => $slot->branch_id,
        //       'lead_id' => $slot->lead_id,
        //       'proposal_id' => $slot->proposal_id,
        //       'proposal_sno' => $slot->proposal_sno,
        //       'product_cart_id' => $slot->product_cart_id,
        //       'package_id' => $slot->package_id,
        //       'slot_id' => $slot->slot_id,
        //       'slot_amount' => $slot->slot_amount,
        //       'payable_amount' => $slot->payable_amount,
        //       'paidAmount' => $slot->paidAmount,
        //       'gst_amount' => $slot->gst_amount,
        //       'balance_amount' => $slot->balance_amount,
        //       'total_amount' => $slot->total_amount,
        //       'slot_description' => $slot->slot_description,
        //       'created_by' => $slot->created_by,
        //       'created_at' => $slot->created_at,
        //       'updated_by' => $slot->updated_by,
        //       'updated_at' => $slot->updated_at,
        //       'status' => $slot->status,
        //       'due_date' => $slot->due_date,
        //       'link_status' => $slot->link_status,
        //       'paid_status' => $slot->paid_status,
        //       'invoice_id' => $slot->invoice_id,
        //       'temp_send_link' => $slot->temp_send_link,
        //       'old_customer_check' => $slot->old_customer_check,
        //       'send_status' => $slot->send_status,
        //       'receipt_temp_link' => $slot->receipt_temp_link,
        //       'receipt_send_status' => $slot->receipt_send_status,
        //       'payment_slot_name' => $slot->payment_slot_name,
        //       'start_deliver_work' => $slot->start_deliver_work,
        //       'deliverables' => [
        //         (string)$cart_id => $deliverables->toArray()
        //       ],
        //       'slot_notes' => [
        //         (string)$cart_id => $slot_notes->toArray()
        //       ]
        //     ];
        //   } else {
        //     // Slot already exists — just append deliverables and slot_notes for this cart
        //     $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
        //     $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
        //   }
        // }

        foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                    $deliverables = DB::table('et_product_delivarables')
                        ->whereIn('sno', $deliverable_ids)
                        ->where('status', 0)
                        ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
                        ->pluck('delivarable_name');
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
        //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

      }

      // Set the grouped products
      $proposal->products = array_values($groupedProducts);
      $proposal->slotCount = $slotCount;
    } else {

      $package_data = DB::table('et_package')
        ->select('et_package.*')
        ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
        ->where('et_package.status', 0)
        ->where('et_package.sno', $proposal->package_id)
        ->first();

      $package_cart = DB::table('et_proposal_package_cart')
        ->select('variant_variable_ids', 'cust_product_amount')
        ->where('status', 0)
        ->where('proposal_sno', $proposal->sno)
        ->get();

      $packageTotal = 0;
      $packageTotalCart = 0;

      foreach ($package_cart as $item) {
        $variants = json_decode($item->variant_variable_ids, true); // decode as array
        $packageTotalCart += $item->cust_product_amount;
        if (is_array($variants)) {
          foreach ($variants as $variant) {
            if (isset($variant['amount'])) {
              $packageTotal += $variant['amount'];
            }
          }
        }
      }



      $package_product_name = DB::table('et_package_product')
        ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
        ->where('et_package_product.status', 0)
        ->where('et_package_product.package_id', $proposal->package_id)
        ->pluck('et_product.product_name');

      $package_data->product_name = $package_product_name;



      $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
        ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
        ->where('et_proposal_pay_slot.status', 0)
        ->get();
      $productSlot_amount = 0;
      foreach ($slots as $slot) {
        $productSlot_amount += $slot->slot_amount;
        $deliverables_ids = $slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
        $slot_notes_ids = $slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
        $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status', 0)->orderBy('sno', 'desc')->pluck('delivarable_name');
        $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status', 0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
        $slot->deliverables = $deliverables;
        $slot->slot_notes = $slot_notes;
      }
      $package_data->slots = $slots;

      $package_data->package_amount = $packageTotal;
      $package_data->packageTotalCart = $packageTotalCart;

      $packages = $package_data;
    }

    // return  $packages;

    $proposalAddonProduct = DB::table('et_proposal_addon_product')
      ->select('et_manage_addon.addon_name', 'et_proposal_addon_product.*', 'et_addon_variable.addon_variablename')
      ->where('et_proposal_addon_product.status', 0)
      ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
      ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
      ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
      ->get();

    $freeAddonProduct = DB::table('et_proposal_addon_product')
      ->select(
        'et_manage_addon.addon_name',
        'et_proposal_addon_product.*',
        'et_addon_variable.addon_variablename'
      )
      ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
      ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
      ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
      ->where('et_proposal_addon_product.status', 0)
      ->where('et_proposal_addon_product.free_paid', 0)
      ->get();

    $paidAddonProduct = DB::table('et_proposal_addon_product')
      ->select(
        'et_manage_addon.addon_name',
        'et_proposal_addon_product.*',
        'et_addon_variable.addon_variablename'
      )
      ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
      ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
      ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
      ->where('et_proposal_addon_product.status', 0)
      ->where('et_proposal_addon_product.free_paid', 1)
      ->get();

    $proposal->freeAddonProducts = $freeAddonProduct;
    $proposal->paidAddonProducts = $paidAddonProduct;
    $proposal->productAddon = $proposalAddonProduct;


    $lead = DB::table('et_lead')->where('et_lead.sno', $proposal->lead_id)->first();




    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status', 0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status', 0)->orderBy('sno', 'desc')->first();

    $proposal_terms = [];
    if ($terms) {
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature = $terms->signature;

    $reasonList_reject = DB::table('et_proposal_reject_reason')->select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();
    // return $proposal;

    return view('content.customer_management.manage_proposal.proposal_reject', [
      'lead' => $lead,
      'proposal' => $proposal,
      'exchange_quote' => $exchange_quote,
      'branch_data' => $branch_data,
      'proposal_note' => $proposal_note,
      'proposal_terms' => $proposal_terms,
      'signature' => $signature,
      'packages' => $packages,
      'reasonList_reject' => $reasonList_reject,
    ]);
  }

  public function ConfirmRejectProposal(Request $request)
  {
    $proposal_status = $request->input('proposal_status');
    $id = $request->input('proposal_id');
    $proposal_reason = $request->input('proposal_reason');
    $proposal_reason_other = $request->input('proposal_reason_other');
    $reason_comments = $request->input('reason_comments');
    $user_id   = $request->user()->user_id;
    // Update the proposal
    $update = DB::table('et_proposal')
      ->where('sno', $id)
      ->where('status', 0)
      ->update([
        'proposal_status' => 2,
        'link_status' => 1,
        'reject_reason' => $proposal_reason ?? null,
        'reject_reason_other' => $proposal_reason_other ?? null,
        'reason_comments' => $reason_comments ?? null,
        'rejected_by' => $user_id ?? 0,
      ]);

    $Proposal_data = DB::table('et_proposal')
      ->where('sno', $id)
      ->where('status', 0)
      ->orderBy('sno', 'asc')
      ->first();

    $slot_first = DB::table('et_proposal_pay_slot')
      ->where('proposal_sno', $id)
      ->where('status', 0)
      ->orderBy('sno', 'asc')
      ->first();

    if ($slot_first) {
      DB::table('et_proposal_pay_slot')
        ->where('proposal_sno', $id)
        ->where('status', 0)
        ->update([
          'link_status'     => 1,
          'paid_status'     => 3,
        ]);
    }

    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($id, 'encrypt');
    return response()->json([
      'status' => 200,
      'message' => 'Proposal Confirmation Submitted',
      'error_msg' => null,
      'data' => $encrypted_values,
      'proposal_status' => $proposal_status
    ]);
  }
  //----------------------CUSTOMER JOURNAL STARTS------------------------//

  public function fetch_journal_customer($id)
  {
    $data = DB::table('et_customer')
      ->where('sno', $id)
      ->select(
        'cus_name',
        'customer_id'
      )
      ->first();

    return response([
      'status' => 200,
      'message' => 'Customer data fetched...',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function fetch_customer_journal_service($id)
  {
    $data = DB::table('et_customer_services')
      ->where('et_customer_services.customer_id', $id)
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->where('et_customer_services.journal_check', 0)
      ->where('et_customer_services.published_status', 0)
      ->select(
        DB::raw("CASE 
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
        END as product_name"),
        'et_customer_services.sno',
        'et_customer_services.created_at'
      )
      ->get();

    foreach ($data as $d) {
      $year = date('Y', strtotime($d->created_at));
      $id = str_pad($d->sno, 5, '0', STR_PAD_LEFT);
      $d->service_id = "SR-{$id}/{$year}";
    }

    return response([
      'status' => 200,
      'message' => 'Customer Service Fetched...',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function temp_customer_journal_attachments(Request $request)
  {
    $user_id = $request->user()->user_id;

    $request->validate([
      'file' => 'required|file|max:10240' // Changed to match frontend
    ]);

    if ($request->hasFile('file')) {
      $file = $request->file('file');

      // Create user directory if it doesn't exist
      $userDirectory = public_path($user_id . '/temp_project');
      if (!file_exists($userDirectory)) {
        mkdir($userDirectory, 0755, true);
      }

      $timestamp = now()->format('Ymd_His');
      $extension = $file->getClientOriginalExtension();
      $fileName = $timestamp . '_' . uniqid() . '.' . $extension;

      // Move to user-specific directory (matching frontend expectation)
      $file->move($userDirectory, $fileName);

      return response()->json([
        'status' => 'success', // Consistent with frontend expectation
        'file_name' => $fileName
      ]);
    }

    return response()->json([
      'status' => 'error'
    ], 400);
  }

  public function create_customer_journal(Request $request)
  {
    try {

      // return $request;

      $user_id = $request->user()->user_id;
      $service_id = $request->service_id;

      DB::beginTransaction();

      $get_service = DB::table('et_customer_services')
        ->where('sno', $service_id)
        ->where('journal_check', 0)
        ->first();

      if (!$get_service) {
        throw new \Exception('No Service Available...');
      }

      $update_data = [
        'journal_check' => 1,
        'jc_id' => $request->coordinator_id,
        'journal_index' => $request->index_id,
        'journal_paper_name' => $request->paper_name,
        'journal_paper_desc' => $request->paper_desc,
        'updated_by' => $user_id
      ];

      // return $request->filled('uploaded_files');

      // Handle file attachments - move from temp to permanent location
      if ($request->filled('attachments')) {
        $files = json_decode($request->attachments, true);
        $permanentFiles = [];

        foreach ($files as $tempFileName) {
          $tempPath = public_path($user_id . '/temp_project/' . $tempFileName);
          $permanentDir = public_path('journal_services/');
          $permanentPath = $permanentDir . $tempFileName;

          // Create journal_services directory if it doesn't exist
          if (!file_exists($permanentDir)) {
            mkdir($permanentDir, 0755, true);
          }

          // Move file from temp to permanent location
          if (file_exists($tempPath)) {
            rename($tempPath, $permanentPath);
            $permanentFiles[] = $tempFileName;
          }
        }

        // Add file references to update data
        $update_data['journal_documents'] = json_encode($permanentFiles);
      }

      $update_service = DB::table('et_customer_services')
        ->where('sno', $service_id)
        ->update($update_data);

      if (!$update_service) {
        throw new \Exception('Something Went Wrong...');
      }

      // Get the updated service record to return
      $updated_service = DB::table('et_customer_services')
        ->where('sno', $service_id)
        ->first();

      DB::commit();

      return response()->json([
        'status' => 200,
        'message' => 'Journal Submitted Successfully!',
        'data' => $updated_service
      ]);
    } catch (\Exception $e) {
      DB::rollBack();
      return response()->json([
        'status' => 500,
        'message' => $e->getMessage(),
        'data' => null
      ], 500);
    }
  }

  public function get_journal_team_lead(Request $request)
  {
    $branch_id = $request->user()->branch_id;

    $data = StaffModel::where('status', 0)->where('sno', '>', 1)->where('branch_id', $branch_id)->whereIn('role_id', [33, 20, 45])->get();

    if (!$data) {
      return response([
        'status' => 302,
        'message' => 'No Such Staffs !',
        'error_msg' => null,
        'data' => null
      ], 302);
    } else {
      return response([
        'status' => 200,
        'message' => 'Staff Fetched Successfully !',
        'error_msg' => null,
        'data' => $data
      ], 200);
    }
  }
  public function fetch_journal_index()
  {
    $data = DB::table('et_journal_index')
      ->where('status', 0)
      ->get();

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }
  
  
  //----------------------CUSTOMER JOURNAL ENDS------------------------//

    public function feedback($id)
  {
    // Decrypt the ID
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
 
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $feedback = DB::table('et_customer_feedback_response')->where('reference_id', $decryptedValue)->first();
    if ($feedback) {
      return redirect()->route('thank.you.page');
    }
    // Fetch active slider questions
    $questions = CustomerFeedBackQuestionModel::where('question_type', 'slider')
      ->where('status', 0) // Only active questions
      ->orderBy('sno', 'asc')
      ->get();
 
 
    return view('content.customer_management.customer_feedback.customer_feedback_list', [
      'questions' => $questions,
      'reference_id' => $decryptedValue // Pass the decrypted ID if needed
    ]);
  }
 
  public function storeFeedback(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'reference_id' => 'required',
      'questions.*.id' => 'required|exists:et_customer_feedback_question,sno',
      'questions.*.rating' => 'required|integer',
      'suggestions' => 'nullable|string|max:1000',
    ]);
 
    if ($validator->fails()) {
      return redirect()->back()
        ->withErrors($validator)
        ->withInput()
        ->with('toastr', [
          'type' => 'error',
          'message' => 'Please provide ratings for all questions.'
        ]);
    }
 
    $feedback = DB::table('et_customer_feedback_response')->where('reference_id', $request->reference_id)->first();
    if ($feedback) {
      return redirect()->route('thank.you.page');
    }
 
    try {
      $user_id = $request->user() ? $request->user()->user_id : null;
 
      foreach ($request->questions as $questionData) {
        $feedback = new CustomerFeedbackResponseModel(); // Create this model if needed
        $feedback->question_id = $questionData['id'];
        $feedback->rating = $questionData['rating'];
        $feedback->reference_id = $request->reference_id;
        $feedback->suggestions = $request->suggestions;
        $feedback->submitted_by = $user_id;
        $feedback->save();
      }
 
      return redirect()->route('thank.you.page')
        ->with('toastr', [
          'type' => 'success',
          'message' => 'Thank you for your feedback!'
        ]);
    } catch (\Exception $e) {
      return redirect()->back()
        ->withInput()
        ->with('toastr', [
          'type' => 'error',
          'message' => 'Error submitting feedback. Please try again.'
        ]);
    }
  }
  public function thankyou()
  {
    return view('content.customer_management.customer_feedback.thankyou_screen');
  }
  
  public function getCustomerCreDetails($id)
  {
      $customer = CustomerModel::where('sno',$id)->first();
 
      $proposals = ProposalModel::where('et_proposal.customer_id', $id)
                  ->join('et_staff','et_staff.sno','=','et_proposal.cre_id')
                  ->whereNotIn('et_proposal.proposal_status',[0,2])
                  ->where('et_proposal.status',0)
                  ->select('et_proposal.*','et_staff.staff_name as cre_name')
                  ->get();
 
      return response()->json([
          'status' => true,
          'customer' => $customer,
          'proposals' => $proposals
      ]);
  }
 
 
//   public function changeCustomerCre(Request $request)
//   {
//       $request->validate([
//           'customer_id' => 'required',
//           'proposal_id' => 'required',
//           'new_cre_id' => 'required',
//       ]);
//       $user_id = $request->user()->user_id;
 
//       DB::beginTransaction();
 
//       try {
 
//           $proposal = ProposalModel::findOrFail(
//               $request->proposal_id
//           );
 
//           $oldCreId = $proposal->cre_id;
 
//           // update proposal cre
//           $proposal->cre_id = $request->new_cre_id;
//           $proposal->save();
 
//           // log save
//           ProposalCreChangeLogModel::create([
//               'branch_id' => $proposal->branch_id,
//               'proposal_id' => $proposal->sno,
//               'customer_id' => $request->customer_id,
//               'old_cre_id' => $oldCreId,
//               'new_cre_id' => $request->new_cre_id,
//               'changed_by' => $user_id,
//               'created_by' => $user_id,
//               'updated_by' => $user_id,
//               'remarks' => $request->remarks,
//           ]);
 
//           DB::commit();
 
//           return response()->json([
//               'status' => true,
//               'message' => 'CRE changed successfully'
//           ]);
 
//       } catch (\Exception $e) {
 
//           DB::rollback();
 
//           return response()->json([
//               'status' => false,
//               'message' => $e->getMessage()
//           ], 500);
//       }
//   }

public function changeCustomerCre(Request $request)
  {
      $request->validate([
          'customer_id' => 'required',
          'proposal_id' => 'required',
          'new_cre_id' => 'required',
      ]);
      $user_id = $request->user()->user_id;
 
      DB::beginTransaction();
 
      try {
 
          $proposal = ProposalModel::findOrFail(
              $request->proposal_id
          );
 
          $oldCreId = $proposal->cre_id;
 
          // update proposal cre
          $proposal->cre_id = $request->new_cre_id;
          $proposal->save();
 
          // update all services under this proposal
          DB::table('et_customer_services')
              ->where('proposal_id', $proposal->sno)
              ->update([
                  'cre_id' => $request->new_cre_id,
                  'updated_by' => $user_id,
                  'updated_at' => now()
              ]);
          // log save
          ProposalCreChangeLogModel::create([
              'branch_id' => $proposal->branch_id,
              'proposal_id' => $proposal->sno,
              'customer_id' => $request->customer_id,
              'old_cre_id' => $oldCreId,
              'new_cre_id' => $request->new_cre_id,
              'changed_by' => $user_id,
              'created_by' => $user_id,
              'updated_by' => $user_id,
              'remarks' => $request->remarks,
          ]);
 
          DB::commit();
 
          return response()->json([
              'status' => true,
              'message' => 'CRE changed successfully'
          ]);
 
      } catch (\Exception $e) {
 
          DB::rollback();
 
          return response()->json([
              'status' => false,
              'message' => $e->getMessage()
          ], 500);
      }
  }
  

   public function markProposalCompleted(Request $request)
{
    $request->validate([
        'proposal_id' => 'required|integer',
        'completed_slots' => 'required|array',
    ]);

    DB::beginTransaction();

    try {

        $proposal = DB::table('et_proposal')
            ->where('sno', $request->proposal_id)
            ->first();

        if (!$proposal) {

            return response()->json([
                'status' => false,
                'message' => 'Proposal not found'
            ], 404);
        }

        // Prevent duplicate completion
        if ($proposal->proposal_status == 5) {

            return response()->json([
                'status' => false,
                'message' => 'Proposal already completed'
            ]);
        }

        // Completion object
        $completionData = [
            'completed_at' => now(),
            'completed_by' => $request->user()->user_id,
            'completed_slots' => $request->completed_slots,
        ];

        // Update proposal
        DB::table('et_proposal')
            ->where('sno', $request->proposal_id)
            ->update([
                'proposal_status' => 5,
                'completion_data' => json_encode($completionData),
                'updated_at' => now(),
                'updated_by' => $request->user()->user_id,
            ]);

        // Update services
        DB::table('et_customer_services')
            ->where('proposal_id', $request->proposal_id)
            ->update([
                'status' => 8,
                'updated_at' => now(),
                'updated_by' => $request->user()->user_id,
            ]);

        // Optional customer completion
        // DB::table('et_customer')
        //     ->where('sno', $proposal->customer_id)
        //     ->update([
        //         'customer_status' => 4,
        //         'updated_at' => now(),
        //         'updated_by' => $request->user()->user_id,
        //     ]);

        DB::commit();

        return response()->json([
            'status' => true,
            'message' => 'Proposal completed successfully'
        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([
            'status' => false,
            'message' => $e->getMessage()
        ], 500);
    }
}
  
  public function fetch_customer_journal_service_assign($id)
{
   
$service = DB::table('et_customer_services')
    ->where('sno', $id)
    ->first();
 
if ($service) {
 
    if ($service->product_package == 1) {
 
        $service->product_name = DB::table('et_product')
            ->where('sno', $service->product_id)
            ->value('product_name');
 
    } elseif ($service->product_package == 2) {
 
        $service->product_name = DB::table('et_package')
            ->where('sno', $service->package_id)
            ->value('package_name');
 
    }
 
    $year = date('Y', strtotime($service->created_at));
 
    $service->service_id =
        'SR-' . str_pad($service->sno, 5, '0', STR_PAD_LEFT) . '/' . $year;
}
 
    return response([
        'status'    => 200,
        'message'   => 'Service Fetched',
        'error_msg' => null,
        'data'      => $service
    ], 200);
}

//  public function create_customer_journal_check1(Request $request)
//   {
//     try {
 
//       // return $request;
 
//       $user_id = $request->user()->user_id;
//       $service_id = $request->service_id;
//  $branch_id = $request->user()->branch_id;
//       DB::beginTransaction();
 
//       $get_service = DB::table('et_customer_services')
//         ->where('sno', $service_id)
//         ->where('journal_check', 1)
//         ->first();
 
//       if (!$get_service) {
//         throw new \Exception('No Service Available...');
//       }
 
     
//       $update_data = [
//         'journal_check' => 1,
//         'jc_id' => $request->coordinator_id,
//         'journal_index' => $request->index_id,
//         'journal_paper_name' => $request->paper_name,
//         'journal_paper_desc' => $request->paper_desc,
//         'updated_by' => $user_id
//       ];
     
 
//       // return $request->filled('uploaded_files');
 
//       // Handle file attachments - move from temp to permanent location
//       if ($request->filled('attachments')) {
//         $files = json_decode($request->attachments, true);
//         $permanentFiles = [];
 
//         foreach ($files as $tempFileName) {
//           $tempPath = public_path($user_id . '/temp_project/' . $tempFileName);
//           $permanentDir = public_path('journal_services/');
//           $permanentPath = $permanentDir . $tempFileName;
 
//           // Create journal_services directory if it doesn't exist
//           if (!file_exists($permanentDir)) {
//             mkdir($permanentDir, 0755, true);
//           }
 
//           // Move file from temp to permanent location
//           if (file_exists($tempPath)) {
//             rename($tempPath, $permanentPath);
//             $permanentFiles[] = $tempFileName;
//           }
//         }
 
//         // Add file references to update data
//         $update_data['journal_documents'] = json_encode($permanentFiles);
//       }
 
//      $update_service = DB::table('et_customer_services')
//     ->where('sno', $service_id)
//     ->update($update_data);
 
// if (!$update_service) {
//     throw new \Exception('Something Went Wrong...');
// }
 
// /*
// |--------------------------------------------------------------------------
// | Create Journal Record
// |--------------------------------------------------------------------------
// */
 
//  $latest_journal = DB::table('et_manage_journal')
//                 ->where('status', '!=', 2)
//                 ->orderBy('sno', 'desc')
//                 ->first();
 
//             $year = date('Y');
 
//             if (! $latest_journal) {
//                 $journal_id = 'JOR0001'.'/'.$year;
//             } else {
//                 $latest_journal_id = $latest_journal->journal_id;
//                 $parts = explode('/', $latest_journal_id);
//                 $numericPart = preg_replace('/[^0-9]/', '', $parts[0]);
//                 $nextNumber = (int) $numericPart + 1; // 8
//                 $journal_id = sprintf('JOR%04d/%s', $nextNumber, $year);
//             }
// $journalExists = DB::table('et_manage_journal')
//     ->where('service_id', $service_id)
//     ->exists();
 
// if (!$journalExists) {
 
//     DB::table('et_manage_journal')->insert([
//         'customer_id'       => $get_service->customer_id,
//         'service_id'        => $service_id,
//         'paper_name'=> $request->paper_name,
//         'journal_id'=>$journal_id,
//          'booklet_id' => $request->booklet_id,
//         'branch_id'=>$branch_id,
//         'submited_date'=>now(),
//         'created_by'        => $user_id,
//         'updated_by'        => $user_id,
//         'created_at'        => now(),
//         'updated_at'        => now()
//     ]);
// }
   
//       // Get the updated service record to return
//       $updated_service = DB::table('et_customer_services')
//         ->where('sno', $service_id)
//         ->first();
 
//       DB::commit();
 
//       return response()->json([
//         'status' => 200,
//         'message' => 'Journal Submitted Successfully!',
//         'data' => $updated_service
//       ]);
//     } catch (\Exception $e) {
//       DB::rollBack();
//       return response()->json([
//         'status' => 500,
//         'message' => $e->getMessage(),
//         'data' => null
//       ], 500);
//     }
//   }

public function create_customer_journal_check1(Request $request)
  {
    try {
 
      // return $request;
 
      $user_id = $request->user()->user_id;
      $service_id = $request->service_id;
 $branch_id = $request->user()->branch_id;
      DB::beginTransaction();
 
      $get_service = DB::table('et_customer_services')
        ->where('sno', $service_id)
        ->where('journal_check', 1)
        ->first();
 
      if (!$get_service) {
        throw new \Exception('No Service Available...');
      }
 
     
      $update_data = [
        'journal_check' => 1,
        'jc_id' => $request->coordinator_id,
        'journal_index' => $request->index_id,
        'journal_paper_name' => $request->paper_name,
        'journal_paper_desc' => $request->paper_desc,
        'updated_by' => $user_id
      ];
     
 
      // return $request->filled('uploaded_files');
 
      // Handle file attachments - move from temp to permanent location
      if ($request->filled('attachments')) {
        $files = json_decode($request->attachments, true);
        $permanentFiles = [];
 
        foreach ($files as $tempFileName) {
          $tempPath = public_path($user_id . '/temp_project/' . $tempFileName);
          $permanentDir = public_path('journal_services/');
          $permanentPath = $permanentDir . $tempFileName;
 
          // Create journal_services directory if it doesn't exist
          if (!file_exists($permanentDir)) {
            mkdir($permanentDir, 0755, true);
          }
 
          // Move file from temp to permanent location
          if (file_exists($tempPath)) {
            rename($tempPath, $permanentPath);
            $permanentFiles[] = $tempFileName;
          }
        }
 
        // Add file references to update data
        $update_data['journal_documents'] = json_encode($permanentFiles);
      }
 
     $update_service = DB::table('et_customer_services')
    ->where('sno', $service_id)
    ->update($update_data);
 
if (!$update_service) {
    throw new \Exception('Something Went Wrong...');
}
 
// /*
// |--------------------------------------------------------------------------
// | Create Journal Record
// |--------------------------------------------------------------------------
// */
 
//  $latest_journal = DB::table('et_manage_journal')
//                 ->where('status', '!=', 2)
//                 ->orderBy('sno', 'desc')
//                 ->first();
 
//             $year = date('Y');
 
//             if (! $latest_journal) {
//                 $journal_id = 'JOR0001'.'/'.$year;
//             } else {
//                 $latest_journal_id = $latest_journal->journal_id;
//                 $parts = explode('/', $latest_journal_id);
//                 $numericPart = preg_replace('/[^0-9]/', '', $parts[0]);
//                 $nextNumber = (int) $numericPart + 1; // 8
//                 $journal_id = sprintf('JOR%04d/%s', $nextNumber, $year);
//             }
// $journalExists = DB::table('et_manage_journal')
//     ->where('service_id', $service_id)
//     ->exists();
 
// if (!$journalExists) {
 
//     DB::table('et_manage_journal')->insert([
//         'customer_id'       => $get_service->customer_id,
//         'service_id'        => $service_id,
//         'paper_name'=> $request->paper_name,
//         'journal_id'=>$journal_id,
//          'booklet_id' => $request->booklet_id,
//         'branch_id'=>$branch_id,
//         'submited_date'=>now(),
//         'created_by'        => $user_id,
//         'updated_by'        => $user_id,
//         'created_at'        => now(),
//         'updated_at'        => now()
//     ]);
// }
   
      // Get the updated service record to return
      $updated_service = DB::table('et_customer_services')
        ->where('sno', $service_id)
        ->first();
 
      DB::commit();
 
      return response()->json([
        'status' => 200,
        'message' => 'Journal Submitted Successfully!',
        'data' => $updated_service
      ]);
    } catch (\Exception $e) {
      DB::rollBack();
      return response()->json([
        'status' => 500,
        'message' => $e->getMessage(),
        'data' => null
      ], 500);
    }
  }
  
  

// get collection exe unassigned proposals
// public function collectionAssignmentList()
// {
//     $data = DB::table('et_proposal')
//         ->join('et_customer','et_customer.sno','=','et_proposal.customer_id')
//         ->leftJoin('et_staff as cre','cre.sno','=','et_proposal.cre_id')

//         ->where(function($q){
//             $q->whereNull('et_proposal.collection_id')
//               ->orWhere('et_proposal.collection_id',0);
//         })

//         ->select(
//             'et_proposal.sno',
//             'et_proposal.proposal_id',
//             'et_customer.cus_name',
//             'cre.staff_name as cre_name',
//             'cre.staff_image as cre_image',
//             'et_proposal.service_title as service_name'
//         )
//         ->paginate(25);

//     $collectionStaffs = DB::table('et_staff')
//         ->where('status',0)
//         ->where('role_id', 42)
//         ->get();

//     return response()->json([
//         'status' => 200,
//         'data' => $data,
//         'collectionStaffs' => $collectionStaffs
//     ]);
// }
  
//   public function collectionAssignmentList(Request $request)
// {
//     $search = $request->search_fill ?? '';
 
//     $query = DB::table('et_proposal')
//         ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_proposal.cre_id')
 
//         ->where(function ($q) {
//             $q->whereNull('et_proposal.collection_id')
//               ->orWhere('et_proposal.collection_id', 0);
//         });
 
//     // Search Filter
//     if (!empty($search)) {
//         $query->where(function ($q) use ($search) {
//             $q->where('et_proposal.proposal_id', 'LIKE', "%{$search}%")
//               ->orWhere('et_customer.cus_name', 'LIKE', "%{$search}%")
//               ->orWhere('et_proposal.service_title', 'LIKE', "%{$search}%")
//               ->orWhere('cre.staff_name', 'LIKE', "%{$search}%");
//         });
//     }
//     if($request->filled('cre_id'))
//       {
//           $query->where('et_proposal.cre_id',$request->cre_id);
//       }
//     $data = $query
//         ->select(
//             'et_proposal.sno',
//             'et_proposal.proposal_id',
//             'et_customer.cus_name',
//             'cre.staff_name as cre_name',
//             'cre.staff_image as cre_image',
//             'et_proposal.service_title as service_name'
//         )
//         ->orderBy('et_proposal.sno', 'desc')
//         ->paginate(25);
 
//     $collectionStaffs = DB::table('et_staff')
//         ->where('status', 0)
//         ->where('role_id', 42)
//         ->get();
 
//     return response()->json([
//         'status' => 200,
//         'data' => $data,
//         'collectionStaffs' => $collectionStaffs
//     ]);
// }

// get collection exe unassigned proposals
public function collectionAssignmentList(Request $request)
{
    $search = $request->search_fill ?? '';
 
    $query = DB::table('et_proposal')
        ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->leftJoin('et_staff as cre', 'cre.sno', '=', 'et_proposal.cre_id')
        ->leftJoin('et_staff as ce', 'ce.sno', '=', 'et_proposal.collection_id');
 
    // Search Filter
    if (!empty($search)) {
        $query->where(function ($q) use ($search) {
            $q->where('et_proposal.proposal_id', 'LIKE', "%{$search}%")
              ->orWhere('et_customer.cus_name', 'LIKE', "%{$search}%")
              ->orWhere('et_proposal.service_title', 'LIKE', "%{$search}%")
              ->orWhere('cre.staff_name', 'LIKE', "%{$search}%");
        });
    }
    if($request->assignment_status == 'assigned'){
    $query->whereNotNull('et_proposal.collection_id')
          ->where('et_proposal.collection_id','!=',0);
    }
 
    if($request->assignment_status == 'unassigned'){
        $query->where(function($q){
            $q->whereNull('et_proposal.collection_id')
              ->orWhere('et_proposal.collection_id',0);
        });
    }
    if($request->filled('cre_id'))
      {
          $query->where('et_proposal.cre_id',$request->cre_id);
      }
    $data = $query
        ->select(
          'et_proposal.sno',
          'et_proposal.proposal_id',
          'et_customer.cus_name',
          'cre.staff_name as cre_name',
          'cre.staff_image as cre_image',
 
          'ce.sno as collection_id',
          'ce.staff_name as collection_name',
          'ce.staff_image as collection_image',
 
          'et_proposal.service_title as service_name'
      )
        ->orderBy('et_proposal.sno', 'desc')
        ->paginate(25);
 
    $collectionStaffs = DB::table('et_staff')
        ->where('status', 0)
        ->where('role_id', 42)
        ->get();
 
    return response()->json([
        'status' => 200,
        'data' => $data,
        'collectionStaffs' => $collectionStaffs
    ]);
}
 


  public function bulkAssignCollection(Request $request)
    {
        DB::beginTransaction();

        try {

            foreach ($request->assignments as $row) {

                $proposal = DB::table('et_proposal')
                    ->select('sno', 'customer_id', 'collection_id')
                    ->where('sno', $row['proposal_id'])
                    ->first();

                if (!$proposal) {
                    continue;
                }

                // Skip if same CE already assigned
                if ($proposal->collection_id == $row['collection_id']) {
                    continue;
                }

                // Insert Log
                ProposalCollectionChangeLogModel::create([
                    'branch_id'         => auth()->user()->branch_id,
                    'proposal_id'       => $proposal->sno,
                    'customer_id'       => $proposal->customer_id,
                    'old_collection_id' => $proposal->collection_id ?? $row['collection_id'],
                    'new_collection_id' => $row['collection_id'],
                    'changed_by'        => $request->user()->user_id,
                    'remarks'           => 'Bulk Collection Executive Assignment',
                    'created_by'        => $request->user()->user_id,
                    'updated_by'        => $request->user()->user_id,
                    'status'            => 0,
                ]);

                // Update Proposal
                DB::table('et_proposal')
                    ->where('sno', $proposal->sno)
                    ->update([
                        'collection_id' => $row['collection_id'],
                        'updated_by'    => $request->user()->user_id,
                        'updated_at'    => now(),
                    ]);
            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Collection Executives assigned successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => $e->getMessage()
            ]);
        }
    }
//      //Bulk assign CRE
//   public function creAssignmentList(Request $request)
// {
//     $query = DB::table('et_proposal')
//         ->join(
//             'et_customer',
//             'et_customer.sno',
//             '=',
//             'et_proposal.customer_id'
//         )
//         ->leftJoin(
//             'et_staff as cre',
//             'cre.sno',
//             '=',
//             'et_proposal.cre_id'
//         )
//         ->leftJoin(
//             'et_staff as ce',
//             'ce.sno',
//             '=',
//             'et_proposal.collection_id'
//         );
//     if($request->filled('search'))
//     {
//         $search = $request->search;
 
//         $query->where(function($q) use($search){
 
//             $q->where(
//                 'et_customer.cus_name',
//                 'like',
//                 "%{$search}%"
//             )
//             ->orWhere(
//                 'et_proposal.proposal_id',
//                 'like',
//                 "%{$search}%"
//             );
 
//         });
//     }
//     if($request->filled('cre_id'))
//     {
//         $query->where(
//             'et_proposal.cre_id',
//             $request->cre_id
//         );
//     }
//     if ($request->cre_assignment_status == 'assigned') {
//         $query->whereNotNull('et_proposal.cre_id')
//               ->where('et_proposal.cre_id', '!=', 0);
//     }
 
//     if ($request->cre_assignment_status == 'unassigned') {
//         $query->where(function ($q) {
//             $q->whereNull('et_proposal.cre_id')
//               ->orWhere('et_proposal.cre_id', 0);
//         });
//     }
//     $data = $query
//         ->select(
//             'et_proposal.sno',
//             'et_proposal.proposal_id',
//             'et_customer.cus_name',
 
//             'et_proposal.cre_id',
//             'cre.staff_name as cre_name',
//             'cre.staff_image as cre_image',
 
//             'ce.staff_name as collection_name',
//             'ce.staff_image as collection_image',
 
//             'et_proposal.service_title as service_name'
//         )
//         ->paginate(25);
 
//     $creStaffs = DB::table('et_staff')
//         ->where('status',0)
//         ->where('role_id',16)
//         ->get();
 
//     return response()->json([
//         'status' => 200,
//         'data' => $data,
//         'creStaffs' => $creStaffs
//     ]);
// }

private function getMilestone1Timeline($customerId, $proposalData)
  {
      $timeline = [];
 
      try {
 
          // Customer
          $customer = DB::table('et_customer')
              ->where('sno', $customerId)
              ->first();
 
         
      /*
      |--------------------------------------------------------------------------
      | Created As Lead
      |--------------------------------------------------------------------------
      */
     
 
      if ($customer) {
 
          $lead = DB::table('et_lead')
              ->where('sno', $customer->lead_id)
              ->where('status', '!=', 2)
              ->orderBy('sno', 'desc')
              ->first();
 
          if ($lead) {
 
              $timeline[] = [
                  'date' => $lead->created_at,
                  'title' => 'Created As Lead',
                  'description' => $lead->lead_id ?? '',
                  'type' => 'info'
              ];
          }
 
          $timeline[] = [
              'date' => $customer->created_at,
              'title' => 'Converted As Customer',
              'description' => $customer->customer_id ?? '',
              'type' => 'info',
          ];
      }
     
          foreach ($proposalData as $proposal) {
 
              /*
              |--------------------------------------------------------------------------
              | Proposal Generated
              |--------------------------------------------------------------------------
              */
              $timeline[] = [
                  'date' => $proposal->created_at,
                  'title' => 'Proposal Generated',
                  'description' => $proposal->service_title,
                  'type' => 'info',
              ];
 
              /*
              |--------------------------------------------------------------------------
              | Payment Paid
              |--------------------------------------------------------------------------
              */
           $payments = DB::table('et_transaction')
                ->join('et_payment', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->where('et_payment.proposal_id', $proposal->sno)
                ->where('et_transaction.status', 0)
                ->select(
                    'et_transaction.*',
                    'et_payment.created_at as payment_date'
                )
                ->get();
 
            foreach ($payments as $payment) {
 
                $timeline[] = [
                    'date' => $payment->payment_date ?? $payment->created_at,
                    'title' => 'Payment Paid',
                    'description' => $payment->transaction_id,
                    'type' => 'payment',
                ];
            }
              /*
              |--------------------------------------------------------------------------
              | Customer Service
              |--------------------------------------------------------------------------
              */
              $service = DB::table('et_customer_services')
                  ->where('proposal_id', $proposal->sno)
                  ->where('customer_id', $customerId)
                  ->where('status', 0)
                  ->first();
 
              if (!$service) {
                  continue;
              }
 
              /*
              |--------------------------------------------------------------------------
              | CRE Assigned
              |--------------------------------------------------------------------------
              */
              if (!empty($service->cre_id)) {
 
                  $cre = DB::table('et_staff')
                      ->where('sno', $service->cre_id)
                      ->first();
 
                  $timeline[] = [
                      'date' => $service->updated_at,
                      'title' => 'CRE Assigned',
                      'description' => $cre->staff_name ?? '',
                      'type' => 'staff',
                      'staff_name' => $cre->staff_name ?? '',
                      'designation' => 'CRE',
                      'image' => $cre->staff_image ?? '',
                  ];
              }
 
              /*
              |--------------------------------------------------------------------------
              | PC Assigned
              |--------------------------------------------------------------------------
              */
              if (!empty($service->pc_id)) {
 
                  $pc = DB::table('et_staff')
                      ->where('sno', $service->pc_id)
                      ->first();
 
                  $timeline[] = [
                      'date' => $service->updated_at,
                      'title' => 'PC Assigned',
                      'description' => $pc->staff_name ?? '',
                      'type' => 'staff',
                       'staff_name' => $pc->staff_name ?? '',
                      'designation' => 'Project Co-ordinator',
                      'image' => $pc->staff_image ?? '',
                  ];
              }
 
              /*
              |--------------------------------------------------------------------------
              | Product Added
              |--------------------------------------------------------------------------
              */
              if ($service->product_package == 1) {
 
                  $product = DB::table('et_product')
                      ->where('sno', $service->product_id)
                      ->first();
 
                  $timeline[] = [
                      'date' => $service->created_at,
                      'title' => 'Product Added',
                      'description' => $product->product_name ?? '',
                      'type' => 'info'
                  ];
              }
 
              /*
              |--------------------------------------------------------------------------
              | Assigned Production Staffs
              |--------------------------------------------------------------------------
              */
              if (!empty($service->production_staffs_id)) {
 
                  $staffIds = json_decode(
                      $service->production_staffs_id,
                      true
                  );
 
                  if (!empty($staffIds)) {
 
                      $staffNames = DB::table('et_staff')
                          ->whereIn('sno', $staffIds)
                          ->pluck('staff_name')
                          ->implode(', ');
 
                      $timeline[] = [
                          'date' => $service->updated_at,
                          'title' => 'Assigned Production Staffs',
                          'description' => $staffNames,
                          'type' => 'staff'
                      ];
                  }
              }
 
              /*
              |--------------------------------------------------------------------------
              | Work Order Verified
              |--------------------------------------------------------------------------
              */
              if ($service->work_order_check == 1) {
 
                  $timeline[] = [
                      'date' => $service->updated_at,
                      'title' => 'Verified Work Order',
                      'description' => '',
                      'type' => 'info'
                  ];
              }
 
              /*
              |--------------------------------------------------------------------------
              | Task Assigned
              |--------------------------------------------------------------------------
              */
              $tasks = DB::table('et_task')
                  ->where('service_id', $service->sno)
                  ->where('status', '!=', 2)
                  ->get();
 
              foreach ($tasks as $task) {
 
                  $timeline[] = [
                      'date' => $task->created_at,
                      'title' => 'Task Assigned',
                      'description' => $task->task_name,
                      'type' => 'info',
                  ];
 
                  if (!empty($task->start_date_time)) {
 
                      $timeline[] = [
                          'date' => $task->start_date_time,
                          'title' => 'Scheduled Dates',
                          'description' => $task->task_name,
                          'type' => 'info',
                      ];
                  }
 
                  if ($task->task_status == 1) {
 
                      $timeline[] = [
                          'date' => $task->updated_at,
                          'title' => 'Service In Progress',
                          'description' => $task->task_name,
                          'type' => 'info',
                      ];
                  }
 
                  if (!empty($task->task_completed_date_time)) {
 
                      $timeline[] = [
                          'date' => $task->task_completed_date_time,
                          'title' => 'Verify Completion',
                          'description' => $task->task_name,
                          'type' => 'info',
                      ];
                  }
              }
 
              /*
              |--------------------------------------------------------------------------
              | Documents Attached
              |--------------------------------------------------------------------------
              */
              if (!empty($service->journal_documents)) {
 
                $documents = json_decode($service->journal_documents, true);
 
                $files = [];
 
                if (is_array($documents)) {
 
                    foreach ($documents as $file) {
 
                        $files[] = [
                            'name' => pathinfo($file, PATHINFO_FILENAME),
                            'extension' => '.' . strtolower(pathinfo($file, PATHINFO_EXTENSION)),
                            'path' => $file
                        ];
                    }
                }
 
                $timeline[] = [
                    'date' => $service->updated_at,
                    'title' => 'Documents Attached',
                    'description' => '',
                    'type' => 'document',
                    'documents' => $files
                ];
            }
 
              /*
              |--------------------------------------------------------------------------
              | Moved To Delivery
              |--------------------------------------------------------------------------
              */
              if ($service->service_check == 1) {
 
                  $timeline[] = [
                      'date' => $service->updated_at,
                      'title' => 'Moved To Delivery',
                      'description' => '',
                      'type' => 'info',
                  ];
              }
          }
 
      } catch (\Exception $e) {
 
          \Log::error(
              'Milestone Timeline Error : ' .
              $e->getMessage()
          );
      }
 
      return collect($timeline)
        ->filter(fn($row) => !empty($row['date']))
        ->sortBy('date')
        ->values();
  }
 
 //Bulk assign CRE
  public function creAssignmentList(Request $request)
{
    $query = DB::table('et_proposal')
        ->join(
            'et_customer',
            'et_customer.sno',
            '=',
            'et_proposal.customer_id'
        )
        ->leftJoin(
            'et_staff as cre',
            'cre.sno',
            '=',
            'et_proposal.cre_id'
        )
        ->leftJoin(
            'et_staff as ce',
            'ce.sno',
            '=',
            'et_proposal.collection_id'
        );
    if($request->filled('search'))
    {
        $search = $request->search;
       
        $query->where(function($q) use($search){
 
            $q->where(
                'et_customer.cus_name',
                'like',
                "%{$search}%"
            )
            ->orWhere(
                'et_proposal.proposal_id',
                'like',
                "%{$search}%"
            );
 
        });
    }
    if($request->filled('cre_id'))
    {
        $query->where(
            'et_proposal.cre_id',
            $request->cre_id
        );
    }
    if ($request->cre_assignment_status == 'assigned') {
        $query->whereNotNull('et_proposal.cre_id')
              ->where('et_proposal.cre_id', '!=', 0);
    }
 
    if ($request->cre_assignment_status == 'unassigned') {
        $query->where(function ($q) {
            $q->whereNull('et_proposal.cre_id')
              ->orWhere('et_proposal.cre_id', 0);
        });
    }
    $data = $query
        ->select(
            'et_proposal.sno',
            'et_proposal.proposal_id',
            'et_customer.cus_name',
 
            'et_proposal.cre_id',
            'cre.staff_name as cre_name',
            'cre.staff_image as cre_image',
 
            'ce.staff_name as collection_name',
            'ce.staff_image as collection_image',
 
            'et_proposal.service_title as service_name'
        )
        ->paginate(25);
 $branch_id = $request->user()->branch_id;
    $creStaffs = DB::table('et_staff')
        ->where('status',0)
        ->where('role_id',16)
        ->where('et_staff.branch_id', $branch_id)
        ->get();
 
    return response()->json([
        'status' => 200,
        'data' => $data,
        'creStaffs' => $creStaffs
    ]);
}

//   public function bulkAssignCre(Request $request)
//     {
//         foreach($request->assignments as $row)
//         {
//             $proposal = DB::table('et_proposal')
//                 ->where('sno',$row['proposal_id'])
//                 ->first();
 
//             if(!$proposal){
//                 continue;
//             }
 
//             ProposalCreChangeLogModel::create([
 
//                 'branch_id' => auth()->user()->branch_id,
 
//                 'proposal_id' => $proposal->sno,
 
//                 'customer_id' => $proposal->customer_id,
 
//                 'old_cre_id' => $proposal->cre_id,
 
//                 'new_cre_id' => $row['cre_id'],
 
//                 'remarks'           => 'Bulk CRE Assignment',
//                 'created_by'        => $request->user()->user_id,
//                 'updated_by'        => $request->user()->user_id,
//                 'changed_by'        => $request->user()->user_id,
 
//                 'status' => 0
//             ]);
 
//             DB::table('et_proposal')
//                 ->where('sno',$proposal->sno)
//                 ->update([
//                     'cre_id' => $row['cre_id']
//                 ]);
//         }
 
//         return response()->json([
//             'status' => 200,
//             'message' => 'CRE Updated Successfully'
//         ]);
//     }
    
    public function bulkAssignCre(Request $request)
    {
        foreach($request->assignments as $row)
        {
            $proposal = DB::table('et_proposal')
                ->where('sno',$row['proposal_id'])
                ->first();
 
            if(!$proposal){
                continue;
            }
 
            ProposalCreChangeLogModel::create([
 
                'branch_id' => auth()->user()->branch_id,
 
                'proposal_id' => $proposal->sno,
 
                'customer_id' => $proposal->customer_id,
 
                'old_cre_id' => $proposal->cre_id,
 
                'new_cre_id' => $row['cre_id'],
 
                'remarks'           => 'Bulk CRE Assignment',
                'created_by'        => $request->user()->user_id,
                'updated_by'        => $request->user()->user_id,
                'changed_by'        => $request->user()->user_id,
 
                'status' => 0
            ]);
 
            DB::table('et_proposal')
                ->where('sno',$proposal->sno)
                ->update([
                    'cre_id' => $row['cre_id']
                ]);
           DB::table('et_customer_services')
            ->where('proposal_id', $proposal->sno)
            ->update([
                'cre_id' => $row['cre_id']
            ]);
        }
 
        return response()->json([
            'status' => 200,
            'message' => 'CRE Updated Successfully'
        ]);
    }
    
    private function getJournalTimeline($customerId)
      {
          $timeline = [];
 
          $histories = DB::table('et_journal_history as jh')
              ->leftJoin('et_journal_booklet as jb', 'jb.sno', '=', 'jh.journal_id')
              ->where('jh.customer_id', $customerId)
              ->select(
                  'jh.*',
                  'jb.journal_name'
              )
              ->get();
              // dd($histories);
 
          foreach ($histories as $history) {
 
              // Submitted
              if (!empty($history->submitted_date)) {
 
                  $timeline[] = [
                      'date' => $history->submitted_date,
                      'title' => 'Paper Submitted',
                      'type' => 'journal_status',
                      'status_name' => 'Submitted',
                      'color' => '#0d6efd',
                      'journal_name' => $history->journal_name,
                      'description' => $history->with_editor_comment,
                      'documents' => $this->prepareDocuments($history->submitted_documents),
                  ];
              }
 
              // With Editor
              if (!empty($history->with_editor_date)) {
 
                  $timeline[] = [
                      'date' => $history->with_editor_date,
                      'title' => 'With Editor',
                      'type' => 'journal_status',
                      'status_name' => 'With Editor',
                      'color' => '#6f42c1',
                      'journal_name' => $history->journal_name,
                      'description' => $history->with_editor_comment,
                      'documents' => $this->prepareDocuments($history->with_editor_documents),
                  ];
              }
 
              // Under Reviewer
              if (!empty($history->under_reviewer_date)) {
 
                  $timeline[] = [
                      'date' => $history->under_reviewer_date,
                      'title' => 'Under Reviewer',
                      'type' => 'journal_status',
                      'status_name' => 'Under Reviewer',
                      'color' => '#fd7e14',
                      'journal_name' => $history->journal_name,
                      'description' => $history->under_reviewer_comment,
                      'documents' => $this->prepareDocuments($history->under_reviewer_documents),
                  ];
              }
 
              // Reviewed
              if (!empty($history->reviewed_date)) {
 
                  $timeline[] = [
                      'date' => $history->reviewed_date,
                      'title' => 'Reviewer Comments Received',
                      'type' => 'journal_status',
                      'status_name' => 'Reviewed',
                      'color' => '#0f4daa',
                      'journal_name' => $history->journal_name,
                      'description' => $history->reviewer_comment,
                      'documents' => $this->prepareDocuments($history->reviewer_document),
                  ];
              }
 
              // Accepted
              if (!empty($history->accepted_date)) {
 
                  $timeline[] = [
                      'date' => $history->accepted_date,
                      'title' => 'Paper Accepted',
                      'type' => 'journal_status',
                      'status_name' => 'Accepted',
                         'color' => '#198754',
                      'journal_name' => $history->journal_name,
                      'description' => $history->accepted_comment,
                      'documents' => $this->prepareDocuments($history->accepted_document),
                  ];
              }
 
              // Rejected
              if (!empty($history->rejected_date)) {
 
                  $timeline[] = [
                      'date' => $history->rejected_date,
                      'title' => 'Paper Rejected',
                      'type' => 'journal_status',
                      'status_name' => 'Rejected',
                       'color' => '#dc3545',
                      'journal_name' => $history->journal_name,
                      'description' => $history->rejected_reason,
                  ];
              }
 
              // Resubmitted
              if (!empty($history->resubmitted_date)) {
 
                  $timeline[] = [
                      'date' => $history->resubmitted_date,
                      'title' => 'Paper Resubmitted',
                      'type' => 'journal_status',
                      'status_name' => 'Resubmitted',
                      'color' => '#3b14eb',
                      'journal_name' => $history->journal_name,
                  ];
              }
 
              // E-Proofing
              if (!empty($history->e_proofing_date)) {
 
                  $timeline[] = [
                      'date' => $history->e_proofing_date,
                      'title' => 'E-Proofing',
                      'type' => 'journal_status',
                      'status_name' => 'E-Proofing',
                      'color' => '#0ea0cc',
                      'journal_name' => $history->journal_name,
                      'description' => $history->e_proofing_comments,
                      'documents' => $this->prepareDocuments($history->e_proofing_documents),
                  ];
              }
 
              // Published
              if (!empty($history->published_date)) {
 
                  $timeline[] = [
                      'date' => $history->published_date,
                      'title' => 'Paper Published',
                      'type' => 'journal_status',
                      'status_name' => 'Published',
                      'color' => '#20c997',
                      'journal_name' => $history->journal_name,
                      'description' => $history->published_url,
                      'documents' => $this->prepareDocuments($history->published_files),
                  ];
              }
          }
 
          return collect($timeline)
              ->sortBy('date')
              ->values()
              ->toArray();
      }
 
      //helper function for journaltimeline
  private function prepareDocuments($documents)
  {
      if (empty($documents)) {
          return [];
      }
 
      $files = json_decode($documents, true);
 
      if (!is_array($files)) {
          return [];
      }
 
      $result = [];
 
      foreach ($files as $file) {
 
          // If stored as string
          if (is_string($file)) {
 
              $result[] = [
                  'name' => pathinfo($file, PATHINFO_FILENAME),
                  'extension' => '.' . pathinfo($file, PATHINFO_EXTENSION),
                  'path' => $file,
              ];
          }
 
          // If stored as array/object
          elseif (is_array($file)) {
 
              $path = $file['path']
                  ?? $file['file']
                  ?? $file['document']
                  ?? reset($file);
 
              if ($path) {
 
                  $result[] = [
                      'name' => pathinfo($path, PATHINFO_FILENAME),
                      'extension' => '.' . pathinfo($path, PATHINFO_EXTENSION),
                      'path' => $path,
                  ];
              }
          }
      }
 
      return $result;
  }
  

// public function activeCustomers(Request $request)
//   { 
//       try{
//       $page = $request->input('page', 1);
//       $perpage = (int) $request->input('sorting_filter', 25);
//       $user_id = $request->user()->user_id;
//       $branch_id = $request->user()->branch_id;
//       $search_fill = $request->search_fill ?? '';
//       $cre_filter       = $request->cre_filter;
//       $product_filter   = $request->product_filter;
//       $initialPayDate   = $request->initialPayDate;
//       $status_filter    = $request->status_filter;
//       $collection_filter = $request->collection_filter;
//       // =========================================
//       // BASE QUERY
//       // =========================================
//       $baseQuery = DB::table('et_customer')
//           ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//           ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
//           ->where('et_customer.status', '!=', 2)
//             ->leftJoin(
//           'et_customer_services',
//           'et_customer_services.proposal_id',
//           '=',
//           'et_proposal.sno'
//       )
//       ->leftJoin(
//       'et_payment',
//       'et_payment.proposal_id',
//       '=',
//       'et_proposal.sno'
//   )
//             ->whereIn('et_customer.status', [0,1])
//             ->whereNot('et_proposal.proposal_status', 5)
//           ->where('et_lead.status', '!=', 2)
//           // ->where('et_proposal.nda_signed',1)
//           ->whereNotIn('et_proposal.proposal_status', [0, 2])
//           ->where('et_customer.branch_id', $branch_id);
//           // Permission filter
//       if (auth()->user()->hasPermissionradio('Customer Management', 'Active Customers', 'view_self_cus')) {
//           $baseQuery->where('et_proposal.cre_id', $user_id);
//       } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Active Customers', 'global_cus')) {
//           abort(403, 'Unauthorized');
//       }

//           // =========================================
//       // DASHBOARD STATS
//       // =========================================
//       $dashboard = [];
//       // Total Customers
//       $dashboard['total_customers'] = (clone $baseQuery)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');

//         // -----------------------------------------
//         // Active Customers
//         // customer_status = 0
//         // -----------------------------------------
//         $dashboard['active_customers'] = (clone $baseQuery)
//             ->whereIn('et_customer.status', [0,1])
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');

//         // -----------------------------------------
//         // Inactive Customers
//         // status = 1
//         // -----------------------------------------
//         $dashboard['inactive_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 1)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');

//         // -----------------------------------------
//         // Completed Customers
//         // status = 4
//         // -----------------------------------------
//         $dashboard['completed_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 4)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');

//         // -----------------------------------------
//         // Temporary Customers
//         // status = 5
//         // -----------------------------------------
//         $dashboard['temporary_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 5)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');

//         // -----------------------------------------
//         // Dropped Customers
//         // status = 6
//         // -----------------------------------------
//         $dashboard['dropped_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 6)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');

//         // -----------------------------------------
//         // Refund & Dropped Customers
//         // status = 7
//         // -----------------------------------------
//         $dashboard['refund_drop_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 7)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');

//       // Total Proposals
//       $dashboard['total_proposals'] = (clone $baseQuery)
//           ->distinct('et_proposal.sno')
//           ->count('et_proposal.sno');
//       // Completed Proposals
//       $dashboard['completed_proposals'] = (clone $baseQuery)
//           ->where('et_proposal.proposal_status', 5)
//           ->distinct('et_proposal.sno')
//           ->count('et_proposal.sno');
//       // Total Products
//       $dashboard['total_products'] = DB::table('et_customer_services')
//           ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//           ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//           ->where('et_customer.branch_id', $branch_id)
//           ->count();
//       //Total Services
//       $dashboard['total_services'] = DB::table('et_customer_services')
//         ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//         ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->where('et_customer.branch_id', $branch_id)
//         ->count('et_customer_services.sno');
//         //Collection executive unassigned
//         $dashboard['unassigned_ce'] =
//         DB::table('et_proposal')
//         ->where(function($q){
//             $q->whereNull('collection_id')
//               ->orWhere('collection_id',0);
//         })
//         ->count();
//       //     // Total Revenue
//       // $dashboard['total_revenue'] = DB::table('et_proposal_pay_slot')
//       //     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
//       //     ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//       //     ->where('et_customer.branch_id', $branch_id)
//       //     ->where('et_proposal_pay_slot.status', 0)
//       //     ->sum('et_proposal_pay_slot.paidAmount');

//       // Search filter
//       if (!empty($search_fill)) {
//           $baseQuery->where(function ($query) use ($search_fill) {
//               $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//                   ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//                   ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
//                   ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
//           });
//       }
//         //Status filter
//       if ($status_filter !== null && $status_filter !== '') {
 
//       $baseQuery->where('et_customer.status', $status_filter);
 
//     }
//       // CRE Filter
//         if (!empty($cre_filter)) {
//             $baseQuery->where('et_proposal.cre_id', $cre_filter);
//         }
//         // Product Filter
//         if (!empty($product_filter)) {
//             $baseQuery->where('et_customer_services.product_id', $product_filter);
//         }
//     //filter by collection executives
//         if (!empty($collection_filter)) {
 
//           if ($collection_filter == 'unassigned') {
 
//               $baseQuery->where(function ($q) {
//                   $q->whereNull('et_proposal.collection_id')
//                     ->orWhere('et_proposal.collection_id', "");
//               });
 
//           } else {
 
//               $baseQuery->where(
//                   'et_proposal.collection_id',
//                   $collection_filter
//               );
 
//           }
 
//       }
//         // Initial Payment Date Filter
//         if (!empty($initialPayDate)) {
//           $baseQuery->whereExists(function ($sub) use ($initialPayDate) {
//               $sub->select(DB::raw(1))
//                   ->from('et_payment as ep1')
//                   ->whereColumn('ep1.proposal_id', 'et_proposal.sno')
//                   ->whereDate('ep1.transaction_date', $initialPayDate)
//                   ->whereRaw('ep1.sno = (
//                       SELECT MIN(ep2.sno)
//                       FROM et_payment ep2
//                       WHERE ep2.proposal_id = et_proposal.sno
//                   )');
//           });
//       }
 
//       $dashboardFilter = $request->dashboard_filter;
//       // dd($dashboardFilter);
//             if($dashboardFilter == 'inactive_customer'){
//                 $baseQuery->where('et_customer.status', 1) 
//                           ->distinct('et_customer.sno');
//             }
 
//             if($dashboardFilter == 'completed_proposals'){
//                 $baseQuery->where('et_proposal.proposal_status', 5)
//                         ->distinct('et_proposal.sno');
//             }
//             if ($dashboardFilter == 'proposal_customer') {
//               $baseQuery->whereExists(function ($q) {
//                   $q->select(DB::raw(1))
//                     ->from('et_proposal')
//                     ->whereColumn('et_proposal.customer_id', 'et_customer.sno');
//                 });
//             }
//           if ($dashboardFilter == 'product_customer') {
//               $baseQuery->whereExists(function ($q) {
//                   $q->select(DB::raw(1))
//                     ->from('et_product')
//                     ->whereColumn('et_product.sno', 'et_customer_services.product_id');
//               });
//           }
//             // dd($baseQuery->get());
//       // =========================================
//       // CUSTOMER LIST
//       // =========================================
//       $customersQuery = (clone $baseQuery)
//           ->select('et_customer.*')
//           ->distinct('et_customer.sno');
//       $customers = $customersQuery
//           ->orderBy('et_customer.sno', 'desc')
//           ->paginate($perpage);
//       // Existing foreach logic
//       foreach ($customers as $customer) {
//           $proposal_ids = json_decode($customer->proposal_ids, true);
//         if (empty($proposal_ids) || !is_array($proposal_ids)) {
//           $customer->proposal_data = collect();
//           continue;
//         }
//     $proposal_data = DB::table('et_proposal')
//       ->select(
//           'et_proposal.*',
//           'et_customer.customer_id as customer_code',
//           'et_customer.cus_name',
//           'et_customer.cus_mobile',
//           'et_customer.cus_email_id'
//       )
//       ->join(
//           'et_customer',
//           'et_customer.sno',
//           '=',
//           'et_proposal.customer_id'
//       )
//       ->whereIn('et_proposal.sno', $proposal_ids)
//       ->where('et_proposal.status', '!=', 2)
//       ->orderBy('et_proposal.sno', 'desc')
//       ->get();
//         $proposal_currency = DB::table('et_proposal')
//           ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
//           ->whereIn('et_proposal.sno', $proposal_ids)
//           ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//           ->where('et_proposal.status', '!=', 2)
//           ->orderBy('et_proposal.sno', 'desc')
//           ->first();
//         $customer->currency_code = $proposal_currency->currency_code;
//         $customer->currency_symbol = $proposal_currency->currency_symbol;
//         $customer->currency_country_name = $proposal_currency->country_name;
//         $allCres = collect();
//         $allCollections = collect();
//         $allJtls = collect();
//         $allJes = collect();
//         $allPcs = collect();
//         foreach ($proposal_data as $proposal) {
//           $service_data = DB::table('et_customer_services')
//             ->where('proposal_id', $proposal->sno)
//             ->orderBy('sno', 'desc')
//             ->first();
//           $CreStaffData = DB::table('et_staff')
//               ->where('sno', $proposal->cre_id)
//               ->orderBy('sno', 'desc')
//               ->first();
//           $proposal->cre_name = $CreStaffData ? $CreStaffData->staff_name : '';
 
//           $CollectionStaffData = DB::table('et_staff')
//               ->where('sno', $proposal->collection_id)
//               ->first();
 
//           $proposal->collection_name = $CollectionStaffData ? $CollectionStaffData->staff_name : '';
//           $proposal->collection_image = $CollectionStaffData ? $CollectionStaffData->staff_image : '';
//           $proposal->customer_service_id = $service_data->sno;
//           if ($proposal->product_package == 2) {
//             // For package type proposals
//             $package = DB::table('et_package')
//               ->where('sno', $proposal->package_id)
//               ->where('status', '!=', 2)
//               ->orderBy('sno', 'desc')
//               ->first();

//             $package_slots = DB::table('et_proposal_pay_slot')
//               ->where('proposal_sno', $proposal->sno)
//               ->where('status', 0)
//               ->get();
//             $product_slots_paid = $package_slots->sum('paidAmount');
//             $proposal->package_name = $package->package_name ?? null;
//             $proposal->package_slot = $package_slots;
//             $proposal->product_slots_paid = $product_slots_paid;
//           } else {
//             // For product type proposals
//             $products = DB::table('et_customer_services')
//             ->select(
//                 'et_product.product_name',
//                 'et_product_category.product_category_name',
//                 'et_customer_services.proposal_id',
//                 'et_customer_services.cre_id',
//                 'et_customer_services.pc_id',
//                 'cre.staff_name as cre_name',
//                 'cre.staff_image as cre_image',
//                 'pc.staff_name as pc_name',
//                 'pc.staff_image as pc_image',
//                 'jtl.staff_name as jtl_name',
//                 'jtl.staff_image as jtl_image',
//                 'je.staff_name as je_name',
//                 'je.staff_image as je_image',
//                 'et_customer_services.jc_id',
//                 'et_customer_services.jc_staff',
//             )
//             ->join(
//                 'et_product',
//                 'et_product.sno',
//                 '=',
//                 'et_customer_services.product_id'
//             )
//             ->join(
//                 'et_product_category',
//                 'et_product_category.sno',
//                 '=',
//                 'et_product.product_category_id'
//             )
//             ->leftJoin(
//                 'et_staff as cre',
//                 'cre.sno',
//                 '=',
//                 'et_customer_services.cre_id'
//             )
//             ->leftJoin(
//                 'et_staff as pc',
//                 'pc.sno',
//                 '=',
//                 'et_customer_services.pc_id'
//             )
//             ->leftJoin(
//                 'et_staff as jtl',
//                 'jtl.sno',
//                 '=',
//                 'et_customer_services.jc_id'
//             )
 
//             ->leftJoin(
//                 'et_staff as je',
//                 'je.sno',
//                 '=',
//                 'et_customer_services.jc_staff'
//             )
//             ->where(
//                 'et_customer_services.proposal_id',
//                 $proposal->sno
//             )
//             ->get();
//             $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
//               ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
//               ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
//               ->where('et_proposal_pay_slot.status', 0)
//               ->get();
//             $product_slots_paid = $product_slots->sum('paidAmount');
//             $proposal->product_slots_paid = $product_slots_paid;
//             $proposal->services = $products;
//             $proposal->product_slot = $product_slots;
//           }
//           $customer_dropdata = DB::table('et_drop_refund')->where('sno', $customer->drop_refund_id)->where('customer_id', $customer->sno)->where('sno', '>', 0)->first();
//           $customer->customer_dropdata = $customer_dropdata;
//           if (!empty($proposal->services)) {
//           if ($proposal->services && count($proposal->services) > 0) {
//           foreach ($proposal->services as $service) {
//               if (!empty($service->cre_id)) {
//                   $allCres->push((object)[
//                       'cre_id' => $service->cre_id,
//                       'cre_name' => $service->cre_name,
//                       'cre_image' => $service->cre_image,
//                   ]);
//               }
//               if (!empty($proposal->collection_id)) {
//                     $allCollections->push((object)[
//                         'collection_id'    => $proposal->collection_id,
//                         'collection_name'  => $proposal->collection_name,
//                         'collection_image' => $proposal->collection_image,
//                     ]);
//                 }
//                   if(!empty($service->jc_id))
//                 {
//                     $allJtls->push((object)[
//                         'jtl_id'=>$service->jc_id,
//                         'jtl_name'=>$service->jtl_name,
//                         'jtl_image'=>$service->jtl_image
//                     ]);
//                 }
 
//                 if(!empty($service->jc_staff))
//                 {
//                     $allJes->push((object)[
//                         'je_id'=>$service->jc_staff,
//                         'je_name'=>$service->je_name,
//                         'je_image'=>$service->je_image
//                     ]);
//                 }
//                   if(!empty($service->pc_id))
//                 {
//                     $allPcs->push((object)[
//                         'pc_id'=>$service->pc_id,
//                         'pc_name'=>$service->pc_name,
//                         'pc_image'=>$service->pc_image
//                     ]);
//                 }
//           }
//       }
//       }
//     }
//     $customer->cre_list = $allCres
//       ->unique('cre_id')
//       ->values();
//       $customer->collection_list = $allCollections
//       ->unique('collection_id')
//       ->values();
//       $customer->jtl_list = $allJtls
//           ->unique('jtl_id')
//           ->values();
 
//       $customer->je_list = $allJes
//           ->unique('je_id')
//           ->values();
//       $customer->pc_list = $allPcs
//         ->unique('pc_id')
//         ->values();
//         $ServiceCompletedCount = DB::table('et_proposal')
//           ->where('et_proposal.customer_id', $customer->sno)
//           ->where('et_proposal.proposal_status', 5)
//           ->get();
//         $customer->completed_proposal = $ServiceCompletedCount;
//         $customer->proposal_data = $proposal_data;
//         $customer->cre_list = $allCres
//             ->unique('cre_id')
//             ->values();
//       }
//       $types = TypeCredentialModel::where('status', 0)->get();
 
//         $branch_id = $request->user()->branch_id;
//       // CRE List
//       $cre_list = DB::table('et_staff')
//           ->where('branch_id', $branch_id)
//           ->where('status', 0)
//           ->where('department_id', 6)
//           ->where('et_staff.role_id', 16)
//           ->get();
//     $collectionExecutives = DB::table('et_staff')
//       ->where('status', 0)
//       ->where('role_id', 42) // adjust to your system
//       ->orderBy('staff_name')
//       ->get();
//       // Product List
//       $product_list = DB::table('et_product')
//           // ->where('branch_id', $branch_id)
//           // ->where('status', 1)
//           ->get();
//       $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
//         ->where('et_staff.status', 0)
//         ->where('et_staff.role_id', 16)
//         ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
//         ->where('et_staff.branch_id', $branch_id);
//       $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
//         ->distinct() // Ensure unique rows
//         ->get();
//         // return $customers;
//       return view('content.customer_management.manage_customer.active_customer_list', [
//           'customers' => $customers,
//           'search_fill' => $search_fill,
//           'types' => $types,
//           'perpage' => $perpage,
//           'dashboard' => $dashboard,
//           'product_list' => $product_list,
//           'cre_list' => $cre_list,
//           'creStaffs' => $crestaff,
//           'collectionExecutives'=> $collectionExecutives
//       ]);
//   }  catch (\Exception $e) {
//         return [
//           'status' => 400,
//           'error' => $e->getMessage(),
//         ];
//       }
//   }
  
//   public function activeCustomers(Request $request)
//   {
//       try{
//       $page = $request->input('page', 1);
//       $perpage = (int) $request->input('sorting_filter', 25);
//       $user_id = $request->user()->user_id;
//       $branch_id = $request->user()->branch_id;
//       $search_fill = $request->search_fill ?? '';
//       $cre_filter       = $request->cre_filter;
//       $product_filter   = $request->product_filter;
//       $initialPayDate   = $request->initialPayDate;
//       $status_filter    = $request->status_filter;
//       $collection_filter = $request->collection_filter;
//       // =========================================
//       // BASE QUERY
//       // =========================================
 
//       $baseQuery = DB::table('et_customer')
//           ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
//           ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
//           ->where('et_customer.status', '!=', 2)
//             ->leftJoin(
//           'et_customer_services',
//           'et_customer_services.proposal_id',
//           '=',
//           'et_proposal.sno'
//       )
//       ->leftJoin(
//       'et_payment',
//       'et_payment.proposal_id',
//       '=',
//       'et_proposal.sno'
//   )
//             ->whereIn('et_customer.status', [0,1])
//             ->whereNot('et_proposal.proposal_status', 5)
//           ->where('et_lead.status', '!=', 2)
//           // ->where('et_proposal.nda_signed',1)
//           ->whereNotIn('et_proposal.proposal_status', [0, 2])
//           ->where('et_customer.branch_id', $branch_id);
 
//           // Permission filter
//       if (auth()->user()->hasPermissionradio('Customer Management', 'Active Customers', 'view_self_cus')) {
 
//           $baseQuery->where('et_proposal.cre_id', $user_id);
 
//       } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Active Customers', 'global_cus')) {
 
//           abort(403, 'Unauthorized');
//       }
       
 
//           // =========================================
//       // DASHBOARD STATS
//       // =========================================
 
//       $dashboard = [];
 
//       // Total Customers
//       $dashboard['total_customers'] = (clone $baseQuery)
//           ->distinct('et_customer.sno')
//           ->count('et_customer.sno');
 
 
//         // -----------------------------------------
//         // Active Customers
//         // customer_status = 0
//         // -----------------------------------------
 
//         $dashboard['active_customers'] = (clone $baseQuery)
//             ->whereIn('et_customer.status', [0,1])
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');
 
 
//         // -----------------------------------------
//         // Inactive Customers
//         // status = 1
//         // -----------------------------------------
 
//         $dashboard['inactive_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 1)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');
 
 
//         // -----------------------------------------
//         // Completed Customers
//         // status = 4
//         // -----------------------------------------
 
//         $dashboard['completed_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 4)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');
 
 
//         // -----------------------------------------
//         // Temporary Customers
//         // status = 5
//         // -----------------------------------------
 
//         $dashboard['temporary_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 5)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');
 
 
//         // -----------------------------------------
//         // Dropped Customers
//         // status = 6
//         // -----------------------------------------
 
//         $dashboard['dropped_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 6)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');
 
 
//         // -----------------------------------------
//         // Refund & Dropped Customers
//         // status = 7
//         // -----------------------------------------
 
//         $dashboard['refund_drop_customers'] = (clone $baseQuery)
//             ->where('et_customer.status', 7)
//             ->distinct('et_customer.sno')
//             ->count('et_customer.sno');
 
 
//       // Total Proposals
//       $dashboard['total_proposals'] = (clone $baseQuery)
//           ->distinct('et_proposal.sno')
//           ->count('et_proposal.sno');
 
//       // Completed Proposals
//       $dashboard['completed_proposals'] = (clone $baseQuery)
//           ->where('et_proposal.proposal_status', 5)
//           ->distinct('et_proposal.sno')
//           ->count('et_proposal.sno');
 
//       // Total Products
//       $dashboard['total_products'] = DB::table('et_customer_services')
//           ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//           ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//           ->where('et_customer.branch_id', $branch_id)
//           ->count();
 
//       //Total Services
//       $dashboard['total_services'] = DB::table('et_customer_services')
//         ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
//         ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//         ->where('et_customer.branch_id', $branch_id)
//         ->count('et_customer_services.sno');
     
//         //Collection executive unassigned
//         $dashboard['unassigned_ce'] =
//         DB::table('et_proposal')
//         ->where(function($q){
//             $q->whereNull('collection_id')
//               ->orWhere('collection_id',0);
//         })
//         ->count();
 
//             //NDA unsigned
//       $dashboard['nda_unsigned'] = (clone $baseQuery)
//         ->where('et_proposal.nda_signed',0)
//         ->distinct('et_proposal.sno')
//         ->count('et_proposal.sno');
//       //     // Total Revenue
//       // $dashboard['total_revenue'] = DB::table('et_proposal_pay_slot')
//       //     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
//       //     ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
//       //     ->where('et_customer.branch_id', $branch_id)
//       //     ->where('et_proposal_pay_slot.status', 0)
//       //     ->sum('et_proposal_pay_slot.paidAmount');
 
 
     
//       // Search filter
//       if (!empty($search_fill)) {
 
//           $baseQuery->where(function ($query) use ($search_fill) {
//               $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//                   ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
//                   ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
//                   ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
//           });
//       }
//         //Status filter
//       if ($status_filter !== null && $status_filter !== '') {
 
//       $baseQuery->where('et_customer.status', $status_filter);
 
//     }
 
//       // CRE Filter
//         if (!empty($cre_filter)) {
 
//             $baseQuery->where('et_proposal.cre_id', $cre_filter);
 
//         }
 
//         // Product Filter
//         if (!empty($product_filter)) {
 
//             $baseQuery->where('et_customer_services.product_id', $product_filter);
 
//         }
//     //filter by collection executives
//         if (!empty($collection_filter)) {
 
//           if ($collection_filter == 'unassigned') {
 
//               $baseQuery->where(function ($q) {
//                   $q->whereNull('et_proposal.collection_id')
//                     ->orWhere('et_proposal.collection_id', "");
//               });
 
//           } else {
 
//               $baseQuery->where(
//                   'et_proposal.collection_id',
//                   $collection_filter
//               );
 
//           }
 
//       }
//         // Initial Payment Date Filter
//         if (!empty($initialPayDate)) {
 
//           $baseQuery->whereExists(function ($sub) use ($initialPayDate) {
 
//               $sub->select(DB::raw(1))
//                   ->from('et_payment as ep1')
//                   ->whereColumn('ep1.proposal_id', 'et_proposal.sno')
//                   ->whereDate('ep1.transaction_date', $initialPayDate)
//                   ->whereRaw('ep1.sno = (
//                       SELECT MIN(ep2.sno)
//                       FROM et_payment ep2
//                       WHERE ep2.proposal_id = et_proposal.sno
//                   )');
 
//           });
 
//       }
 
//       $dashboardFilter = $request->dashboard_filter;
//       // dd($dashboardFilter);
       
//             if($dashboardFilter == 'inactive_customer'){
//                 $baseQuery->where('et_customer.status', 1)
//                           ->distinct('et_customer.sno');
//             }
 
//             if($dashboardFilter == 'completed_proposals'){
//                 $baseQuery->where('et_proposal.proposal_status', 5)
//                         ->distinct('et_proposal.sno');
//             }
//             if ($dashboardFilter == 'proposal_customer') {
//               $baseQuery->whereExists(function ($q) {
//                   $q->select(DB::raw(1))
//                     ->from('et_proposal')
//                     ->whereColumn('et_proposal.customer_id', 'et_customer.sno');
//                 });
//             }
//           if ($dashboardFilter == 'product_customer') {
//               $baseQuery->whereExists(function ($q) {
//                   $q->select(DB::raw(1))
//                     ->from('et_product')
//                     ->whereColumn('et_product.sno', 'et_customer_services.product_id');
//               });
//           }
//           if($dashboardFilter == 'nda_unsigned'){
//               $baseQuery->where('et_proposal.nda_signed', 0)
//                       ->distinct('et_proposal.sno');
//           }
     
//             // dd($baseQuery->get());
     
//       // =========================================
//       // CUSTOMER LIST
//       // =========================================
 
//       $customersQuery = (clone $baseQuery)
//           ->select('et_customer.*')
//           ->distinct('et_customer.sno');
 
//       $customers = $customersQuery
//           ->orderBy('et_customer.sno', 'desc')
//           ->paginate($perpage);
 
//       // Existing foreach logic
//       foreach ($customers as $customer) {
 
//           $proposal_ids = json_decode($customer->proposal_ids, true);
//         if (empty($proposal_ids) || !is_array($proposal_ids)) {
//           $customer->proposal_data = collect();
//           continue;
//         }
//     $proposal_data = DB::table('et_proposal')
//       ->select(
//           'et_proposal.*',
 
//           'et_customer.customer_id as customer_code',
//           'et_customer.cus_name',
//           'et_customer.cus_mobile',
//           'et_customer.cus_email_id'
//       )
 
//       ->join(
//           'et_customer',
//           'et_customer.sno',
//           '=',
//           'et_proposal.customer_id'
//       )
 
//       ->whereIn('et_proposal.sno', $proposal_ids)
//       ->where('et_proposal.status', '!=', 2)
//       ->orderBy('et_proposal.sno', 'desc')
//       ->get();
//         $proposal_currency = DB::table('et_proposal')
//           ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
//           ->whereIn('et_proposal.sno', $proposal_ids)
//           ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//           ->where('et_proposal.status', '!=', 2)
//           ->orderBy('et_proposal.sno', 'desc')
//           ->first();
//         $customer->currency_code = $proposal_currency->currency_code;
//         $customer->currency_symbol = $proposal_currency->currency_symbol;
//         $customer->currency_country_name = $proposal_currency->country_name;
//         $allCres = collect();
//         $allCollections = collect();
//         $allJtls = collect();
//         $allJes = collect();
//         $allPcs = collect();
//         foreach ($proposal_data as $proposal) {
//           $service_data = DB::table('et_customer_services')
//             ->where('proposal_id', $proposal->sno)
//             ->orderBy('sno', 'desc')
//             ->first();
           
//           $CreStaffData = DB::table('et_staff')
//               ->where('sno', $proposal->cre_id)
//               ->orderBy('sno', 'desc')
//               ->first();
//           $proposal->cre_name = $CreStaffData ? $CreStaffData->staff_name : '';
 
//           $CollectionStaffData = DB::table('et_staff')
//               ->where('sno', $proposal->collection_id)
//               ->first();
 
//           $proposal->collection_name = $CollectionStaffData ? $CollectionStaffData->staff_name : '';
//           $proposal->collection_image = $CollectionStaffData ? $CollectionStaffData->staff_image : '';
         
//           $proposal->customer_service_id = $service_data->sno;
//           if ($proposal->product_package == 2) {
//             // For package type proposals
//             $package = DB::table('et_package')
//               ->where('sno', $proposal->package_id)
//               ->where('status', '!=', 2)
//               ->orderBy('sno', 'desc')
//               ->first();
 
 
//             $package_slots = DB::table('et_proposal_pay_slot')
//               ->where('proposal_sno', $proposal->sno)
//               ->where('status', 0)
//               ->get();
//             $product_slots_paid = $package_slots->sum('paidAmount');
//             $proposal->package_name = $package->package_name ?? null;
//             $proposal->package_slot = $package_slots;
//             $proposal->product_slots_paid = $product_slots_paid;
//           } else {
//             // For product type proposals
//             $products = DB::table('et_customer_services')
 
//             ->select(
 
//                 'et_product.product_name',
//                 'et_product_category.product_category_name',
 
//                 'et_customer_services.proposal_id',
//                 'et_customer_services.cre_id',
//                 'et_customer_services.pc_id',
 
//                 'cre.staff_name as cre_name',
//                 'cre.staff_image as cre_image',
 
//                 'pc.staff_name as pc_name',
//                 'pc.staff_image as pc_image',
//                 'jtl.staff_name as jtl_name',
//                 'jtl.staff_image as jtl_image',
//                 'je.staff_name as je_name',
//                 'je.staff_image as je_image',
//                 'et_customer_services.jc_id',
//                 'et_customer_services.jc_staff',
//             )
 
//             ->join(
//                 'et_product',
//                 'et_product.sno',
//                 '=',
//                 'et_customer_services.product_id'
//             )
 
//             ->join(
//                 'et_product_category',
//                 'et_product_category.sno',
//                 '=',
//                 'et_product.product_category_id'
//             )
 
//             ->leftJoin(
//                 'et_staff as cre',
//                 'cre.sno',
//                 '=',
//                 'et_customer_services.cre_id'
//             )
 
//             ->leftJoin(
//                 'et_staff as pc',
//                 'pc.sno',
//                 '=',
//                 'et_customer_services.pc_id'
//             )
//             ->leftJoin(
//                 'et_staff as jtl',
//                 'jtl.sno',
//                 '=',
//                 'et_customer_services.jc_id'
//             )
 
//             ->leftJoin(
//                 'et_staff as je',
//                 'je.sno',
//                 '=',
//                 'et_customer_services.jc_staff'
//             )
//             ->where(
//                 'et_customer_services.proposal_id',
//                 $proposal->sno
//             )
 
//             ->get();
//             $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
//               ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
//               ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
//               ->where('et_proposal_pay_slot.status', 0)
//               ->get();
//             $product_slots_paid = $product_slots->sum('paidAmount');
 
//             $proposal->product_slots_paid = $product_slots_paid;
//             $proposal->services = $products;
//             $proposal->product_slot = $product_slots;
//           }
//           $customer_dropdata = DB::table('et_drop_refund')->where('sno', $customer->drop_refund_id)->where('customer_id', $customer->sno)->where('sno', '>', 0)->first();
//           $customer->customer_dropdata = $customer_dropdata;
//           if (!empty($proposal->services)) {
 
//           if ($proposal->services && count($proposal->services) > 0) {
 
//           foreach ($proposal->services as $service) {
 
//               if (!empty($service->cre_id)) {
 
//                   $allCres->push((object)[
//                       'cre_id' => $service->cre_id,
//                       'cre_name' => $service->cre_name,
//                       'cre_image' => $service->cre_image,
//                   ]);
//               }
//               if (!empty($proposal->collection_id)) {
//                     $allCollections->push((object)[
//                         'collection_id'    => $proposal->collection_id,
//                         'collection_name'  => $proposal->collection_name,
//                         'collection_image' => $proposal->collection_image,
//                     ]);
//                 }
//                   if(!empty($service->jc_id))
//                 {
//                     $allJtls->push((object)[
//                         'jtl_id'=>$service->jc_id,
//                         'jtl_name'=>$service->jtl_name,
//                         'jtl_image'=>$service->jtl_image
//                     ]);
//                 }
 
//                 if(!empty($service->jc_staff))
//                 {
//                     $allJes->push((object)[
//                         'je_id'=>$service->jc_staff,
//                         'je_name'=>$service->je_name,
//                         'je_image'=>$service->je_image
//                     ]);
//                 }
//                   if(!empty($service->pc_id))
//                 {
//                     $allPcs->push((object)[
//                         'pc_id'=>$service->pc_id,
//                         'pc_name'=>$service->pc_name,
//                         'pc_image'=>$service->pc_image
//                     ]);
//                 }
//           }
//       }
//       }
//     }
//     $customer->cre_list = $allCres
//       ->unique('cre_id')
//       ->values();
//       $customer->collection_list = $allCollections
//       ->unique('collection_id')
//       ->values();
//       $customer->jtl_list = $allJtls
//           ->unique('jtl_id')
//           ->values();
 
//       $customer->je_list = $allJes
//           ->unique('je_id')
//           ->values();
//       $customer->pc_list = $allPcs
//         ->unique('pc_id')
//         ->values();
//         $ServiceCompletedCount = DB::table('et_proposal')
//           ->where('et_proposal.customer_id', $customer->sno)
//           ->where('et_proposal.proposal_status', 5)
//           ->get();
 
//         $customer->completed_proposal = $ServiceCompletedCount;
//         $customer->proposal_data = $proposal_data;
//         $customer->cre_list = $allCres
//             ->unique('cre_id')
//             ->values();
//       }
//       $types = TypeCredentialModel::where('status', 0)->get();
 
//         $branch_id = $request->user()->branch_id;
 
//       // CRE List
//       $cre_list = DB::table('et_staff')
//           ->where('branch_id', $branch_id)
//           ->where('status', 0)
//           ->where('department_id', 6)
//           ->where('et_staff.role_id', 16)
//           ->get();
//     $collectionExecutives = DB::table('et_staff')
//       ->where('status', 0)
//       ->where('role_id', 42) // adjust to your system
//       ->orderBy('staff_name')
//       ->get();
//       // Product List
//       $product_list = DB::table('et_product')
//           // ->where('branch_id', $branch_id)
//           // ->where('status', 1)
//           ->get();
//       $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
//         ->where('et_staff.status', 0)
//         ->where('et_staff.role_id', 16)
//         ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
//         ->where('et_staff.branch_id', $branch_id);
//       $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
//         ->distinct() // Ensure unique rows
//         ->get();
//         // return $customers;
//       return view('content.customer_management.manage_customer.active_customer_list', [
//           'customers' => $customers,
//           'search_fill' => $search_fill,
//           'types' => $types,
//           'perpage' => $perpage,
//           'dashboard' => $dashboard,
//           'product_list' => $product_list,
//           'cre_list' => $cre_list,
//           'creStaffs' => $crestaff,
//           'collectionExecutives'=> $collectionExecutives
//       ]);
//   }  catch (\Exception $e) {
//         return [
//           'status' => 400,
//           'error' => $e->getMessage(),
//         ];
//       }
//   }
  
   public function activeCustomers(Request $request)

  {

      try{

      $page = $request->input('page', 1);

      $perpage = (int) $request->input('sorting_filter', 25);

      $user_id = $request->user()->user_id;

      $branch_id = $request->user()->branch_id;

      $search_fill = $request->search_fill ?? '';

      $cre_filter       = $request->cre_filter;

      $product_filter   = $request->product_filter;

      $initialPayDate   = $request->initialPayDate;

      $status_filter    = $request->status_filter;

      $collection_filter = $request->collection_filter;

      // =========================================

      // BASE QUERY

      // =========================================

 

      $baseQuery = DB::table('et_customer')

          ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')

          ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')

          ->where('et_customer.status', '!=', 2)

            ->leftJoin(

          'et_customer_services',

          'et_customer_services.proposal_id',

          '=',

          'et_proposal.sno'

      )

      ->leftJoin(

      'et_payment',

      'et_payment.proposal_id',

      '=',

      'et_proposal.sno'

  )

            ->whereIn('et_customer.status', [0,1])

            ->whereNot('et_proposal.proposal_status', 5)

          ->where('et_lead.status', '!=', 2)

          // ->where('et_proposal.nda_signed',1)

          ->whereNotIn('et_proposal.proposal_status', [0, 2])

          ->where('et_customer.branch_id', $branch_id);

 

           // Permission filter

      if (auth()->user()->hasPermissionradio('Customer Management', 'Active Customers', 'view_self_cus')) {

 

          $baseQuery->where('et_proposal.cre_id', $user_id);

 

      } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Active Customers', 'global_cus')) {

 

          abort(403, 'Unauthorized');

      }

       

 

          // =========================================

      // DASHBOARD STATS

      // =========================================

 

      $dashboard = [];

 

      // Total Customers

      $dashboard['total_customers'] = (clone $baseQuery)

          ->distinct('et_customer.sno')

          ->count('et_customer.sno');

 

 

        // -----------------------------------------

        // Active Customers

        // customer_status = 0

        // -----------------------------------------

 

        $dashboard['active_customers'] = (clone $baseQuery)

            ->whereIn('et_customer.status', [0,1])

            ->distinct('et_customer.sno')

            ->count('et_customer.sno');

 

 

        // -----------------------------------------

        // Inactive Customers

        // status = 1

        // -----------------------------------------

 

        $dashboard['inactive_customers'] = (clone $baseQuery)

            ->where('et_customer.status', 1)

            ->distinct('et_customer.sno')

            ->count('et_customer.sno');

 

 

        // -----------------------------------------

        // Completed Customers

        // status = 4

        // -----------------------------------------

 

        $dashboard['completed_customers'] = (clone $baseQuery)

            ->where('et_customer.status', 4)

            ->distinct('et_customer.sno')

            ->count('et_customer.sno');

 

 

        // -----------------------------------------

        // Temporary Customers

        // status = 5

        // -----------------------------------------

 

        $dashboard['temporary_customers'] = (clone $baseQuery)

            ->where('et_customer.status', 5)

            ->distinct('et_customer.sno')

            ->count('et_customer.sno');

 

 

        // -----------------------------------------

        // Dropped Customers

        // status = 6

        // -----------------------------------------

 

        $dashboard['dropped_customers'] = (clone $baseQuery)

            ->where('et_customer.status', 6)

            ->distinct('et_customer.sno')

            ->count('et_customer.sno');

 

 

        // -----------------------------------------

        // Refund & Dropped Customers

        // status = 7

        // -----------------------------------------

 

        $dashboard['refund_drop_customers'] = (clone $baseQuery)

            ->where('et_customer.status', 7)

            ->distinct('et_customer.sno')

            ->count('et_customer.sno');

 

 

      // Total Proposals

      $dashboard['total_proposals'] = (clone $baseQuery)

          ->distinct('et_proposal.sno')

          ->count('et_proposal.sno');

 

      // Completed Proposals

      $dashboard['completed_proposals'] = (clone $baseQuery)

          ->where('et_proposal.proposal_status', 5)

          ->distinct('et_proposal.sno')

          ->count('et_proposal.sno');

 

      // Total Products

      $dashboard['total_products'] = DB::table('et_customer_services')

          ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')

          ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')

          ->where('et_customer.branch_id', $branch_id)

          ->count();

 

      //Total Services

      $dashboard['total_services'] = DB::table('et_customer_services')

        ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')

        ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')

        ->where('et_customer.branch_id', $branch_id)

        ->count('et_customer_services.sno');

     

        //Collection executive unassigned

        $dashboard['unassigned_ce'] =

        DB::table('et_proposal')

        ->where(function($q){

            $q->whereNull('collection_id')

              ->orWhere('collection_id',0);

        })

        ->count();

 

            //NDA unsigned

       $dashboard['nda_unsigned'] = (clone $baseQuery)

        ->where('et_proposal.nda_signed',0)

        ->distinct('et_proposal.sno')

        ->count('et_proposal.sno');

      //     // Total Revenue

      // $dashboard['total_revenue'] = DB::table('et_proposal_pay_slot')

      //     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')

      //     ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')

      //     ->where('et_customer.branch_id', $branch_id)

      //     ->where('et_proposal_pay_slot.status', 0)

      //     ->sum('et_proposal_pay_slot.paidAmount');

 

 

     

      // Search filter

      if (!empty($search_fill)) {

 

          $baseQuery->where(function ($query) use ($search_fill) {

              $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")

                  ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")

                  ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")

                  ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");

          });

      }

        //Status filter

      if ($status_filter !== null && $status_filter !== '') {

 

      $baseQuery->where('et_customer.status', $status_filter);

 

    }

 

      // CRE Filter

        if (!empty($cre_filter)) {

 

            $baseQuery->where('et_proposal.cre_id', $cre_filter);

 

        }

 

        // Product Filter

        if (!empty($product_filter)) {

 

            $baseQuery->where('et_customer_services.product_id', $product_filter);

 

        }

    //filter by collection executives

        if (!empty($collection_filter)) {

 

          if ($collection_filter == 'unassigned') {

 

              $baseQuery->where(function ($q) {

                  $q->whereNull('et_proposal.collection_id')

                    ->orWhere('et_proposal.collection_id', "");

              });

 

          } else {

 

              $baseQuery->where(

                  'et_proposal.collection_id',

                  $collection_filter

              );

 

          }

 

      }

        // Initial Payment Date Filter

        if (!empty($initialPayDate)) {

 

          $baseQuery->whereExists(function ($sub) use ($initialPayDate) {

 

              $sub->select(DB::raw(1))

                  ->from('et_payment as ep1')

                  ->whereColumn('ep1.proposal_id', 'et_proposal.sno')

                  ->whereDate('ep1.transaction_date', $initialPayDate)

                  ->whereRaw('ep1.sno = (

                      SELECT MIN(ep2.sno)

                      FROM et_payment ep2

                      WHERE ep2.proposal_id = et_proposal.sno

                  )');

 

          });

 

      }

 

      $dashboardFilter = $request->dashboard_filter;

      // dd($dashboardFilter);

       

            if($dashboardFilter == 'inactive_customer'){

                $baseQuery->where('et_customer.status', 1)

                          ->distinct('et_customer.sno');

            }

 

            if($dashboardFilter == 'completed_proposals'){

                $baseQuery->where('et_proposal.proposal_status', 5)

                        ->distinct('et_proposal.sno');

            }

            if ($dashboardFilter == 'proposal_customer') {

              $baseQuery->whereExists(function ($q) {

                  $q->select(DB::raw(1))

                    ->from('et_proposal')

                    ->whereColumn('et_proposal.customer_id', 'et_customer.sno');

                });

            }

          if ($dashboardFilter == 'product_customer') {

              $baseQuery->whereExists(function ($q) {

                  $q->select(DB::raw(1))

                    ->from('et_product')

                    ->whereColumn('et_product.sno', 'et_customer_services.product_id');

              });

          }

          if($dashboardFilter == 'nda_unsigned'){

              $baseQuery->where('et_proposal.nda_signed', 0)

                      ->distinct('et_proposal.sno');

          }

     

            // dd($baseQuery->get());

     

      // =========================================

      // CUSTOMER LIST

      // =========================================

 

      $customersQuery = (clone $baseQuery)

          ->select('et_customer.*')

          ->distinct('et_customer.sno');

 

      $customers = $customersQuery

          ->orderBy('et_customer.sno', 'desc')

          ->paginate($perpage);

 

      // Existing foreach logic

      foreach ($customers as $customer) {

 

          $proposal_ids = json_decode($customer->proposal_ids, true);

        if (empty($proposal_ids) || !is_array($proposal_ids)) {

          $customer->proposal_data = collect();

          continue;

        }

           $follow_up=DB::table('et_customer_follow_up')->select('et_customer_follow_up.*')

      ->leftjoin('et_customer', 'et_customer.sno', '=', 'et_customer_follow_up.customer_id')

      ->where('et_customer_follow_up.customer_id', $customer->sno)->orderBy('et_customer_follow_up.sno','desc')->first();

     

     

      $customer->appointment_status = $follow_up->status ?? "0";

      $chk1day         = false;

      $createdAt       = Carbon::parse($customer->created_at);

      $currentDateTime = Carbon::now();

      $customer->total_follow_up=CustomerFollowUpModel::where('customer_id', $customer->sno)->count();

     

    $before48Hours   = Carbon::now()->subHours(48);

      $usersWithPendingAppointments = DB::table('et_customer_follow_up')

      ->join('et_customer', 'et_customer.sno', '=', 'et_customer_follow_up.customer_id')

        ->whereIn('et_customer.status', [0])

       

        ->where('et_customer_follow_up.status', 1)

        // ->where('et_lead.is_dc', 1)

        ->where('et_customer_follow_up.branch_id', $branch_id)

        ->where('et_customer_follow_up.appointment_date', '<=', $before48Hours)

        ->distinct()

        ->pluck('et_customer_follow_up.created_by')

        ->toArray();

 

      if (in_array($customer->created_by, $usersWithPendingAppointments)) {

 

        $customer->not_closed = 0;

      } else {

        $customer->not_closed = 0;

      }

    $proposal_data = DB::table('et_proposal')

      ->select(

          'et_proposal.*',

 

          'et_customer.customer_id as customer_code',

          'et_customer.cus_name',

          'et_customer.cus_mobile',

          'et_customer.cus_email_id'

      )

 

      ->join(

          'et_customer',

          'et_customer.sno',

          '=',

          'et_proposal.customer_id'

      )

 

      ->whereIn('et_proposal.sno', $proposal_ids)

      ->where('et_proposal.status', '!=', 2)

      ->orderBy('et_proposal.sno', 'desc')

      ->get();

        $proposal_currency = DB::table('et_proposal')

          ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')

          ->whereIn('et_proposal.sno', $proposal_ids)

          ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')

          ->where('et_proposal.status', '!=', 2)

          ->orderBy('et_proposal.sno', 'desc')

          ->first();

        $customer->currency_code = $proposal_currency->currency_code;

        $customer->currency_symbol = $proposal_currency->currency_symbol;

        $customer->currency_country_name = $proposal_currency->country_name;

        $allCres = collect();

        $allCollections = collect();

        $allJtls = collect();

        $allJes = collect();

        $allPcs = collect();

        foreach ($proposal_data as $proposal) {

          $service_data = DB::table('et_customer_services')

            ->where('proposal_id', $proposal->sno)

            ->orderBy('sno', 'desc')

            ->first();

           

          $CreStaffData = DB::table('et_staff')

              ->where('sno', $proposal->cre_id)

              ->orderBy('sno', 'desc')

              ->first();

          $proposal->cre_name = $CreStaffData ? $CreStaffData->staff_name : '';

 

          $CollectionStaffData = DB::table('et_staff')

              ->where('sno', $proposal->collection_id)

              ->first();

 

          $proposal->collection_name = $CollectionStaffData ? $CollectionStaffData->staff_name : '';

          $proposal->collection_image = $CollectionStaffData ? $CollectionStaffData->staff_image : '';

         

          $proposal->customer_service_id = $service_data->sno;

          if ($proposal->product_package == 2) {

            // For package type proposals

            $package = DB::table('et_package')

              ->where('sno', $proposal->package_id)

              ->where('status', '!=', 2)

              ->orderBy('sno', 'desc')

              ->first();

 

 

            $package_slots = DB::table('et_proposal_pay_slot')

              ->where('proposal_sno', $proposal->sno)

              ->where('status', 0)

              ->get();

            $product_slots_paid = $package_slots->sum('paidAmount');

            $proposal->package_name = $package->package_name ?? null;

            $proposal->package_slot = $package_slots;

            $proposal->product_slots_paid = $product_slots_paid;

          } else {

            // For product type proposals

            $products = DB::table('et_customer_services')

 

            ->select(

 

'et_product.product_name',

              'et_product_category.product_category_name',

 

              'et_customer_services.proposal_id',

              'et_customer_services.cre_id',

'et_customer_services.pc_id',

 

                'cre.staff_name as cre_name',

                'cre.staff_image as cre_image',

 

                'pc.staff_name as pc_name',

                'pc.staff_image as pc_image',

                'jtl.staff_name as jtl_name',

                'jtl.staff_image as jtl_image',

                'je.staff_name as je_name',

                'je.staff_image as je_image',

                'et_customer_services.jc_id',

                'et_customer_services.jc_staff',

            )

 

            ->join(

                'et_product',

                'et_product.sno',

                '=',

                'et_customer_services.product_id'

            )

 

            ->join(

                'et_product_category',

                'et_product_category.sno',

                '=',

                'et_product.product_category_id'

            )

 

            ->leftJoin(

                'et_staff as cre',

                'cre.sno',

                '=',

                'et_customer_services.cre_id'

            )

 

            ->leftJoin(

                'et_staff as pc',

                'pc.sno',

                '=',

                'et_customer_services.pc_id'

            )

            ->leftJoin(

                'et_staff as jtl',

                'jtl.sno',

                '=',

                'et_customer_services.jc_id'

            )

 

            ->leftJoin(

                'et_staff as je',

                'je.sno',

                '=',

                'et_customer_services.jc_staff'

            )

            ->where(

                'et_customer_services.proposal_id',

                $proposal->sno

            )

 

            ->get();

            $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')

              ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)

              ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')

              ->where('et_proposal_pay_slot.status', 0)

              ->get();

            $product_slots_paid = $product_slots->sum('paidAmount');

 

            $proposal->product_slots_paid = $product_slots_paid;

            $proposal->services = $products;

            $proposal->product_slot = $product_slots;

          }

          $customer_dropdata = DB::table('et_drop_refund')->where('sno', $customer->drop_refund_id)->where('customer_id', $customer->sno)->where('sno', '>', 0)->first();

          $customer->customer_dropdata = $customer_dropdata;

          if (!empty($proposal->services)) {

 

          if ($proposal->services && count($proposal->services) > 0) {

 

          foreach ($proposal->services as $service) {

 

              if (!empty($service->cre_id)) {

 

                  $allCres->push((object)[

                      'cre_id' => $service->cre_id,

                      'cre_name' => $service->cre_name,

                      'cre_image' => $service->cre_image,

                  ]);

              }

              if (!empty($proposal->collection_id)) {

                    $allCollections->push((object)[

                        'collection_id'    => $proposal->collection_id,

                        'collection_name'  => $proposal->collection_name,

                        'collection_image' => $proposal->collection_image,

                    ]);

                }

                  if(!empty($service->jc_id))

                {

                    $allJtls->push((object)[

                        'jtl_id'=>$service->jc_id,

                        'jtl_name'=>$service->jtl_name,

                        'jtl_image'=>$service->jtl_image

                    ]);

                }

 

                if(!empty($service->jc_staff))

                {

                    $allJes->push((object)[

                        'je_id'=>$service->jc_staff,

                        'je_name'=>$service->je_name,

                        'je_image'=>$service->je_image

                    ]);

                }

                  if(!empty($service->pc_id))

                {

                    $allPcs->push((object)[

                        'pc_id'=>$service->pc_id,

                        'pc_name'=>$service->pc_name,

                        'pc_image'=>$service->pc_image

                    ]);

                }

          }

      }

      }

    }

    $customer->cre_list = $allCres

      ->unique('cre_id')

      ->values();

      $customer->collection_list = $allCollections

      ->unique('collection_id')

      ->values();

      $customer->jtl_list = $allJtls

          ->unique('jtl_id')

          ->values();

 

      $customer->je_list = $allJes

          ->unique('je_id')

          ->values();

      $customer->pc_list = $allPcs

        ->unique('pc_id')

        ->values();

        $ServiceCompletedCount = DB::table('et_proposal')

          ->where('et_proposal.customer_id', $customer->sno)

          ->where('et_proposal.proposal_status', 5)

          ->get();

 

        $customer->completed_proposal = $ServiceCompletedCount;

        $customer->proposal_data = $proposal_data;

        $customer->cre_list = $allCres

            ->unique('cre_id')

            ->values();

      }

      $types = TypeCredentialModel::where('status', 0)->get();

 

        $branch_id = $request->user()->branch_id;

 

      // CRE List

      $cre_list = DB::table('et_staff')

          ->where('branch_id', $branch_id)

          ->where('status', 0)

          ->where('department_id', 6)

          ->where('et_staff.role_id', 16)

          ->get();

    $collectionExecutives = DB::table('et_staff')

      ->where('status', 0)

      ->where('role_id', 42) // adjust to your system

      ->orderBy('staff_name')

      ->get();

      // Product List

      $product_list = DB::table('et_product')

          // ->where('branch_id', $branch_id)

          // ->where('status', 1)

          ->get();

      $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')

        ->where('et_staff.status', 0)

        ->where('et_staff.role_id', 16)

        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")

        ->where('et_staff.branch_id', $branch_id);

      $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')

        ->distinct() // Ensure unique rows

        ->get();

        // return $customers;

      return view('content.customer_management.manage_customer.active_customer_list', [

          'customers' => $customers,

          'search_fill' => $search_fill,

          'types' => $types,

          'perpage' => $perpage,

          'dashboard' => $dashboard,

          'product_list' => $product_list,

          'cre_list' => $cre_list,

          'creStaffs' => $crestaff,

          'collectionExecutives'=> $collectionExecutives

      ]);

  }  catch (\Exception $e) {

        return [

          'status' => 400,

          'error' => $e->getMessage(),

        ];

      }

  }

  public function completedCustomers(Request $request)
{
   try{
     $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $search_fill = $request->search_fill ?? '';
    $cre_filter       = $request->cre_filter;
    $product_filter   = $request->product_filter;
    $initialPayDate   = $request->initialPayDate;
    $status_filter    = $request->status_filter;
    $collection_filter = $request->collection_filter;
    // =========================================
    // BASE QUERY
    // =========================================
   $baseQuery = DB::table('et_customer')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->leftJoin('et_customer_services', 'et_customer_services.proposal_id', '=', 'et_proposal.sno')
    ->where('et_customer.branch_id', $branch_id)
    ->where('et_proposal.proposal_status', 5)
    ->Where('et_customer_services.status', 8);

    // Permission filter
    if (auth()->user()->hasPermissionradio('Customer Management', 'Completed Customers', 'view_self_cus')) {
        $baseQuery->where('et_proposal.cre_id', $user_id);
    } elseif (!auth()->user()->hasPermissionradio('Customer Management', 'Completed Customers', 'global_cus')) {
        abort(403, 'Unauthorized');
    }

        // =========================================
    // DASHBOARD STATS
    // =========================================
    $dashboard = [];
    // Total Customers
    $dashboard['total_customers'] = (clone $baseQuery)
        ->distinct('et_customer.sno')
        ->count('et_customer.sno');
 

     $dashboard['completed_proposals'] =(clone $baseQuery)
    // ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
    // ->where('et_customer.branch_id', $branch_id)
    ->where('et_proposal.proposal_status', 5)
    ->distinct('et_proposal.sno')
    ->count();

    $dashboard['completed_services'] = DB::table('et_customer_services')
    ->join('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
    ->join('et_proposal', 'et_proposal.sno', '=', 'et_customer_services.proposal_id')
    ->where('et_customer.branch_id', $branch_id)
     ->where('et_proposal.proposal_status', 5)
    ->where('et_customer_services.status', 8)
    ->count();
    $dashboard['completed_today'] = DB::table('et_proposal')
        ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_proposal.proposal_status', 5)
        ->whereDate('et_proposal.updated_at', today())
        ->count();
    $dashboard['completed_this_month'] = DB::table('et_proposal')
        ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_proposal.proposal_status', 5)
        ->whereMonth('et_proposal.updated_at', now()->month)
        ->whereYear('et_proposal.updated_at', now()->year)
        ->count();

    // Total Proposals
    $dashboard['total_proposals'] =  DB::table('et_proposal')
    ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
    ->where('et_customer.branch_id', $branch_id)
        ->distinct('et_proposal.sno')
        ->count('et_proposal.sno');

      //Collection executive unassigned
      $dashboard['unassigned_ce'] =
      DB::table('et_proposal')
      ->where(function($q){
          $q->whereNull('collection_id')
            ->orWhere('collection_id',0);
      })
      ->count();
    //     // Total Revenue
    // $dashboard['total_revenue'] = DB::table('et_proposal_pay_slot')
    //     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
    //     ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
    //     ->where('et_customer.branch_id', $branch_id)
    //     ->where('et_proposal_pay_slot.status', 0)
    //     ->sum('et_proposal_pay_slot.paidAmount');

    // Search filter
    if (!empty($search_fill)) {
        $baseQuery->where(function ($query) use ($search_fill) {
            $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
        });
    }
      //Status filter
    if ($status_filter !== null && $status_filter !== '') {
 
    $baseQuery->where('et_customer.status', $status_filter);
 
  }
    // CRE Filter
      if (!empty($cre_filter)) {
          $baseQuery->where('et_proposal.cre_id', $cre_filter);
      }
      // Product Filter
      if (!empty($product_filter)) {
          $baseQuery->where('et_customer_services.product_id', $product_filter);
      }
  //filter by collection executives
      if (!empty($collection_filter)) {
 
        if ($collection_filter == 'unassigned') {
 
            $baseQuery->where(function ($q) {
                $q->whereNull('et_proposal.collection_id')
                  ->orWhere('et_proposal.collection_id', "");
            });
 
        } else {
 
            $baseQuery->where(
                'et_proposal.collection_id',
                $collection_filter
            );
 
        }
 
    }
      // Initial Payment Date Filter
      if (!empty($initialPayDate)) {
        $baseQuery->whereExists(function ($sub) use ($initialPayDate) {
            $sub->select(DB::raw(1))
                ->from('et_payment as ep1')
                ->whereColumn('ep1.proposal_id', 'et_proposal.sno')
                ->whereDate('ep1.transaction_date', $initialPayDate)
                ->whereRaw('ep1.sno = (
                    SELECT MIN(ep2.sno)
                    FROM et_payment ep2
                    WHERE ep2.proposal_id = et_proposal.sno
                )');
        });
    }
 
  $dashboardFilter = $request->dashboard_filter;
 
// Total Completed Customers
if ($dashboardFilter == 'total_customers') {
 
    // Base query already contains only completed customers.
    // No extra condition required.
 
}
 
// Completed Proposals
if ($dashboardFilter == 'completed_proposals') {
 
    $baseQuery->where('et_proposal.proposal_status', 5);
 
}
 
// Completed Services
if ($dashboardFilter == 'completed_services') {
 
    $baseQuery->whereExists(function ($q) {
 
        $q->select(DB::raw(1))
            ->from('et_customer_services')
            ->whereColumn(
                'et_customer_services.customer_id',
                'et_customer.sno'
            )
            ->where('et_customer_services.status', 8);
 
    });
 
}
 
// Completed Today
if ($dashboardFilter == 'completed_today') {
 
    $baseQuery->where('et_proposal.proposal_status', 5)
              ->whereDate('et_proposal.updated_at', today());
 
}
 
// Completed This Month
if ($dashboardFilter == 'completed_this_month') {
 
    $baseQuery->where('et_proposal.proposal_status', 5)
              ->whereMonth('et_proposal.updated_at', now()->month)
              ->whereYear('et_proposal.updated_at', now()->year);
 
}
 
// Total Proposals
if ($dashboardFilter == 'total_proposals') {
 
    // No additional condition.
    // If your base query already filters completed customers,
    // this will show all proposals belonging to completed customers.
 
}
          // dd($baseQuery->get());
    // =========================================
    // CUSTOMER LIST
    // =========================================
    $customersQuery = (clone $baseQuery)
        ->select('et_customer.*')
        ->distinct('et_customer.sno');
    $customers = $customersQuery
        ->orderBy('et_customer.sno', 'desc')
        ->paginate($perpage);
    // Existing foreach logic
    foreach ($customers as $customer) {
         $proposal_ids = json_decode($customer->proposal_ids, true);
      if (empty($proposal_ids) || !is_array($proposal_ids)) {
        $customer->proposal_data = collect();
        continue;
      }
   $proposal_data = DB::table('et_proposal')
    ->select(
        'et_proposal.*',
        'et_customer.customer_id as customer_code',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id'
    )
    ->join(
        'et_customer',
        'et_customer.sno',
        '=',
        'et_proposal.customer_id'
    )
    ->whereIn('et_proposal.sno', $proposal_ids)
    ->where('et_proposal.status', '!=', 2)
    ->where('et_proposal.proposal_status', 5)
    ->orderBy('et_proposal.sno', 'desc')
    ->get();
      $proposal_currency = DB::table('et_proposal')
        ->select('et_proposal.*', 'et_country_currencies.currency_code', 'et_country_currencies.currency_symbol', 'et_country_currencies.country_name')
        ->whereIn('et_proposal.sno', $proposal_ids)
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->where('et_proposal.status', '!=', 2)
        ->orderBy('et_proposal.sno', 'desc')
        ->first();
      $customer->currency_code = $proposal_currency->currency_code;
      $customer->currency_symbol = $proposal_currency->currency_symbol;
      $customer->currency_country_name = $proposal_currency->country_name;
      $allCres = collect();
      $allCollections = collect();
      $allJtls = collect();
    $allJes = collect();
    $allJtls = collect();
    $allJes = collect();
      foreach ($proposal_data as $proposal) {
        $service_data = DB::table('et_customer_services')
          ->where('proposal_id', $proposal->sno)
          ->orderBy('sno', 'desc')
          ->first();
        $CreStaffData = DB::table('et_staff')
            ->where('sno', $proposal->cre_id)
            ->orderBy('sno', 'desc')
            ->first();
        $proposal->cre_name = $CreStaffData ? $CreStaffData->staff_name : '';
 
        $CollectionStaffData = DB::table('et_staff')
            ->where('sno', $proposal->collection_id)
            ->first();
 
        $proposal->collection_name = $CollectionStaffData ? $CollectionStaffData->staff_name : '';
        $proposal->collection_image = $CollectionStaffData ? $CollectionStaffData->staff_image : '';
        $proposal->customer_service_id = $service_data->sno;
        if ($proposal->product_package == 2) {
          // For package type proposals
          $package = DB::table('et_package')
            ->where('sno', $proposal->package_id)
            ->where('status', '!=', 2)
            ->orderBy('sno', 'desc')
            ->first();

          $package_slots = DB::table('et_proposal_pay_slot')
            ->where('proposal_sno', $proposal->sno)
            ->where('status', 0)
            ->get();
          $product_slots_paid = $package_slots->sum('paidAmount');
          $proposal->package_name = $package->package_name ?? null;
          $proposal->package_slot = $package_slots;
          $proposal->product_slots_paid = $product_slots_paid;
        } else {
          // For product type proposals
          $products = DB::table('et_customer_services')
          ->select(
              'et_product.product_name',
              'et_product_category.product_category_name',
              'et_customer_services.proposal_id',
              'et_customer_services.cre_id',
              'et_customer_services.pc_id',
              'cre.staff_name as cre_name',
              'cre.staff_image as cre_image',
              'pc.staff_name as pc_name',
              'pc.staff_image as pc_image',
              'jtl.staff_name as jtl_name',
              'jtl.staff_image as jtl_image',
 
              'je.staff_name as je_name',
              'je.staff_image as je_image',
          )
          ->join(
              'et_product',
              'et_product.sno',
              '=',
              'et_customer_services.product_id'
          )
          ->join(
              'et_product_category',
              'et_product_category.sno',
              '=',
              'et_product.product_category_id'
          )
          ->leftJoin(
              'et_staff as cre',
              'cre.sno',
              '=',
              'et_customer_services.cre_id'
          )
          ->leftJoin(
              'et_staff as pc',
              'pc.sno',
              '=',
              'et_customer_services.pc_id'
          )
          ->leftJoin(
              'et_staff as jtl',
              'jtl.sno',
              '=',
              'et_customer_services.jc_id'
          )
 
          ->leftJoin(
              'et_staff as je',
              'je.sno',
              '=',
              'et_customer_services.jc_staff'
          )
          ->where(
              'et_customer_services.proposal_id',
              $proposal->sno
          )
           ->where('et_customer_services.proposal_id', $proposal->sno)
          ->where('et_customer_services.status', 8)
          ->get();
          $product_slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
            ->where('et_proposal_pay_slot.proposal_sno', $proposal->sno)
            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
            ->where('et_proposal_pay_slot.status', 0)
            ->get();
          $product_slots_paid = $product_slots->sum('paidAmount');
          $proposal->product_slots_paid = $product_slots_paid;
          $proposal->services = $products;
          $proposal->product_slot = $product_slots;
        }
        $customer_dropdata = DB::table('et_drop_refund')->where('sno', $customer->drop_refund_id)->where('customer_id', $customer->sno)->where('sno', '>', 0)->first();
        $customer->customer_dropdata = $customer_dropdata;
        if (!empty($proposal->services)) {
         if ($proposal->services && count($proposal->services) > 0) {
        foreach ($proposal->services as $service) {
            if (!empty($service->cre_id)) {
                $allCres->push((object)[
                    'cre_id' => $service->cre_id,
                    'cre_name' => $service->cre_name,
                    'cre_image' => $service->cre_image,
                ]);
            }
            if (!empty($proposal->collection_id)) {
                  $allCollections->push((object)[
                      'collection_id'    => $proposal->collection_id,
                      'collection_name'  => $proposal->collection_name,
                      'collection_image' => $proposal->collection_image,
                  ]);
              }
              if(!empty($service->jc_id))
              {
                  $allJtls->push((object)[
                      'jtl_id'=>$service->jc_id,
                      'jtl_name'=>$service->jtl_name,
                      'jtl_image'=>$service->jtl_image
                  ]);
              }
 
              if(!empty($service->jc_staff))
              {
                  $allJes->push((object)[
                      'je_id'=>$service->jc_staff,
                      'je_name'=>$service->je_name,
                      'je_image'=>$service->je_image
                  ]);
              }
        }
    }
    }
  }
  $customer->cre_list = $allCres
    ->unique('cre_id')
    ->values();
    $customer->collection_list = $allCollections
    ->unique('collection_id')
    ->values();
    $customer->jtl_list = $allJtls
        ->unique('jtl_id')
        ->values();
 
    $customer->je_list = $allJes
        ->unique('je_id')
        ->values();
      $ServiceCompletedCount = DB::table('et_proposal')
        ->where('et_proposal.customer_id', $customer->sno)
        ->where('et_proposal.proposal_status', 5)
        ->get();
      $customer->completed_proposal = $ServiceCompletedCount;
      $customer->proposal_data = $proposal_data;
      $customer->cre_list = $allCres
          ->unique('cre_id')
          ->values();
    }
    $types = TypeCredentialModel::where('status', 0)->get();
  // return( [
  //       'customers' => $customers,
  //       'search_fill' => $search_fill,
  //       'types' => $types,
  //       'perpage' => $perpage,
  //       'dashboard' => $dashboard,
  //   ]);
      $branch_id = $request->user()->branch_id;
    // CRE List
    $cre_list = DB::table('et_staff')
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->where('department_id', 6)
        ->get();
  $collectionExecutives = DB::table('et_staff')
    ->where('status', 0)
    ->where('role_id', 42) // adjust to your system
    ->orderBy('staff_name')
    ->get();
    // Product List
    $product_list = DB::table('et_product')
        // ->where('branch_id', $branch_id)
        // ->where('status', 1)
        ->get();
     $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
      ->where('et_staff.status', 0)
      ->where('et_staff.role_id', 16)
      ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
      ->where('et_staff.branch_id', $branch_id);
    $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();
      // return $dashboard;
    return view('content.customer_management.manage_customer.completed_customer_list', [
        'customers' => $customers,
        'search_fill' => $search_fill,
        'types' => $types,
        'perpage' => $perpage,
        'dashboard' => $dashboard,
        'product_list' => $product_list,
        'cre_list' => $cre_list,
        'creStaffs' => $crestaff,
        'collectionExecutives'=> $collectionExecutives,
        'isActiveCustomerPage' => $isActiveCustomerPage ?? false
    ]);
}  catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
}


public function getCreDashboard(Request $request)
{
    $branch_id = $request->user()->branch_id;
 
    $baseQuery = DB::table('et_customer')
    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
    ->leftJoin(
        'et_customer_services',
        'et_customer_services.proposal_id',
        '=',
        'et_proposal.sno'
    )
    ->leftJoin(
        'et_payment',
        'et_payment.proposal_id',
        '=',
        'et_proposal.sno'
    )
    ->leftJoin(
        'et_staff',
        'et_staff.sno',
        '=',
        'et_proposal.cre_id'
    )
 
    ->where('et_customer.status','!=',2)
    ->where('et_lead.status','!=',2)
    ->where('et_staff.status',0)
    ->where('et_staff.role_id',16)
    ->whereNotIn('et_proposal.proposal_status',[0,2])
    ->where('et_customer.branch_id',$branch_id);
   $creDashboard = (clone $baseQuery)
 
    ->groupBy(
        'et_staff.sno',
        'et_staff.staff_name',
        'et_staff.staff_image'
    )
 
    ->select(
 
        'et_staff.sno',
 
        'et_staff.staff_name',
 
        'et_staff.staff_image',
 
        DB::raw('COUNT(DISTINCT et_customer.sno) total_customers'),
 
        DB::raw("
            COUNT(DISTINCT CASE
                WHEN et_customer.status IN (0,1)
                THEN et_customer.sno
            END) active_customers
        "),
 
        DB::raw("
            COUNT(DISTINCT CASE
                WHEN et_customer.status=4
                THEN et_customer.sno
            END) completed_customers
        "),
 
        DB::raw("
            COUNT(DISTINCT CASE
                WHEN et_customer.status=5
                THEN et_customer.sno
            END) temporary_customers
        "),
 
        DB::raw("
            COUNT(DISTINCT CASE
                WHEN et_customer.status=6
                THEN et_customer.sno
            END) dropped_customers
        "),
 
        DB::raw("
            COUNT(DISTINCT CASE
                WHEN et_customer.status=7
                THEN et_customer.sno
            END) refund_customers
        "),
 
        DB::raw("
            COUNT(DISTINCT et_proposal.sno)
            total_proposals
        "),
 
        DB::raw("
            COUNT(et_customer_services.sno)
            total_services
        ")
 
    )
 
    ->get();
 
    return response()->json([
        'status'=>true,
        'data'=>$creDashboard
    ]);
}
  
  public function updateMobileAppAccess(Request $request)
{
    $request->validate([
        'customer_id' => 'required|integer',
        'mobile_app_access' => 'required|boolean',
    ]);
 
    try {
 
        $customer = DB::table('et_customer')
            ->where('sno', $request->customer_id)
            ->first();
 
        if (!$customer) {
            return response()->json([
                'status' => false,
                'message' => 'Customer not found.'
            ], 404);
        }
 
        DB::table('et_customer')
            ->where('sno', $request->customer_id)
            ->update([
                'mobile_app_access' => $request->mobile_app_access,
                'updated_at' => now(),
            ]);
 
        return response()->json([
            'status' => true,
            'message' => $request->mobile_app_access
                ? 'Mobile app access enabled.'
                : 'Mobile app access disabled.'
        ]);
 
    } catch (\Exception $e) {
 
        return response()->json([
            'status' => false,
            'message' => $e->getMessage()
        ], 500);
    }
}

public function Appointment(Request $request)
  {
   
   
   
 
    $validator = Validator::make($request->all(), [
      'appointment_date' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
 
      // return $request;
      // assigning is_active_customer from the request
      $is_active_cus            =$request->is_active_cus;
      $cus_id                  = $request->customer_id;
      // $appointment_date         = $request->appointment_date;
      $appointment_time         = $request->appointment_time;
 
      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
 
      $user_id            = $request->user()->user_id;
      $branch_id          = $request->user()->branch_id;
      // $chk = LeadModel::where('lead_id', $lead_id)->where('status', '!=', 2)->first();
 
      // if ($chk) {
      //   session()->flash('toastr', [
      //     'type' => 'error',
      //     'message' => 'Name has been  already created!'
      //   ]);
      // } else {
      // return $request;
     
      $category_check = CustomerFollowUpModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
 
 
      if (!$category_check) {
 
        $year = substr(date("y"), -2);
        $appointment_id = "CFU-0001/" . $year;
      } else {
 
        $data = $category_check->customer_follow_up_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
 
        $next_number = (int)$result + 1;
        $request = sprintf("CFU-%04d", $next_number);
 
        $year = substr(date("y"), -2);
        $appointment_id = $request . '/' . $year;
      }
     
 
 
      $add_category = new CustomerFollowUpModel();
      $add_category->customer_follow_up_id   = $appointment_id;
      $add_category->customer_id             = $cus_id;
      $add_category->appointment_date        = $appointment_date;
      $add_category->appointment_time        = $appointment_time;
      $add_category->branch_id               = $branch_id;
      $add_category->status                  = 1;
      $add_category->created_by              = $user_id;
      $add_category->updated_by              = $user_id;
 
 
      $add_category->save();
      // if ($add_category) {
      //   $customer =  CustomerModel::where('sno', $cus_id)->first();
      //   $customer->cust_status_id          = 2; //followup lead
      //   $customer->update();
 
        // Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(3);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $lead_id;
        // $newPoints->points_id = 3;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();
 
        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
      // }
 
      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Appointment added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Appointment!'
        ]);
      }
      // }
      // return $result;
      if($is_active_cus ==1){
        return redirect('active-customers');
      }
      return redirect('manage_customer');
    }
  }
  
  public function AppointmentEdit($id)
  {
    // Fetch the latest appointment details for a specific customer_id
    $latestAppointment = CustomerFollowUpModel::select('et_customer_follow_up.*', 'et_customer.cus_name', 'et_customer.sno as cus_id')
      ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
      ->whereNotIn('et_customer_follow_up.status', [2])
      ->where('et_customer_follow_up.customer_id', $id)
      ->orderBy('et_customer_follow_up.sno', 'desc')
      ->first();
 
    $appointmentCount = CustomerFollowUpModel::where('customer_id', $id)
      ->whereNotIn('status', [2])
      ->count();
 
    // Fetch historical lead_id values excluding the current $id
    // $historicalLeadIds = AppointmentModel::select('et_appointment.*')
    //   ->where('lead_id', $id)
    //     ->whereNotIn('status', [2])
    //   ->orderBy('et_appointment.sno', 'desc')
    //   ->get();
 
    $historicalLeadIds = CustomerFollowUpModel::select('et_customer_follow_up.*', 'et_staff.staff_name')
      ->join('et_staff', 'et_customer_follow_up.created_by', '=', 'et_staff.sno')
      ->where('et_customer_follow_up.customer_id', $id)
      ->where('et_customer_follow_up.status', '!=', 2)
      ->orderBy('et_customer_follow_up.sno', 'desc')
      ->get();
 
    // Extract appointment_date and appointment_time from the latest appointment
    $appointment_date = null;
    $appointment_time = null;
    if ($latestAppointment) {
      $appointment_date = $latestAppointment->appointment_date;
      $appointment_time = $latestAppointment->appointment_time;
    }
 
    // Include previous appointment date and time in historicalLeadIds
    $historicalLeadIds = $historicalLeadIds->map(function ($appointment, $key) use ($id) {
      // Fetch the previous appointment by skipping the current one
      $previousAppointment = CustomerFollowUpModel::select('et_customer_follow_up.*')
        ->where('customer_id', $id)
        ->whereNotIn('status', [2])
        ->where('sno', '<', $appointment->sno)
        ->orderBy('sno', 'desc')
        ->first();
 
      $appointment->previous_appointment_date = $previousAppointment ? $previousAppointment->appointment_date : null;
      $appointment->previous_appointment_time = $previousAppointment ? $previousAppointment->appointment_time : null;
 
      return $appointment;
    });
 
    $lead_reschedule_count  = DB::table('et_customer_follow_up')
      ->where('customer_id', $id)
      ->where('status', 1)
      ->count();
 
   
    return response()->json([
      'status'    => 200,
      'message'   => 'Appointment details fetched successfully',
      'data'      => [
        'appointment_date' => $appointment_date,
        'appointment_time' => $appointment_time,
        'appointmentCount' => $appointmentCount,
        'latestAppointment' => $latestAppointment,
        'historicalLeadIds' => $historicalLeadIds,
        'lead_reschedule_count' => $lead_reschedule_count,
      ]
    ], 200);
  }
 
  public function AppointmentUpdate($id, Request $request)
  {
 
    $validator = Validator::make($request->all(), [
      'progressed' => 'required|max:255',
 
    ]);
 
    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
 
      //   return $request;
      $progressed       = $request->progressed;
      $reason_appt      = $request->reason;
      $appointment_time       = $request->appointment_time;
      $app_score          = $request->app_score;
      $follow_through            = $request->follow_through ?? 0;
 
      $hot_lead            = $request->hot_lead;
      $pb                 = $request->pb ?? 0;
      $user_id            = $request->user()->user_id;
      $branch_id            = $request->user()->branch_id;
      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
      if ($progressed == 1) {
        $upd_lead =  CustomerFollowUpModel::where('customer_id', $id)->orderBy('sno', 'desc')->first();
 
        $upd_lead->progressed                 = $progressed;
        $upd_lead->app_score                  = $request->app_score;
        $upd_lead->follow_through                  = $request->follow_through;
 
        $upd_lead->convo_message              = $request->convo_message;
        $upd_lead->status                     = 4;
        // return $upd_lead;
        $upd_lead->update();
 
        if ($pb == 1) {
          $LeadData = CustomerModel::where('sno', $upd_lead->customer_id)->first();
          if ($LeadData) {
            // $LeadData->drop_verified = 0;
            // $LeadData->drop_tl_verified = 0;
            // $LeadData->spam_verified = 0;
            // $LeadData->spam_tl_verified = 0;
            // $LeadData->internal_status  = 0;
            // $LeadData->transfer_status  = 1;
            // $LeadData->potential_verify = 0;
            // $LeadData->is_potential = 0;
            // $LeadData->created_by   = $user_id;
            // $LeadData->save();
          }
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $LeadData->sno;
          $add_history->branch_id = $LeadData->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($LeadData->created_at));
          $add_history->current_staff_id = $LeadData->created_by;
          $add_history->change_staff_id = 0;
          $add_history->transferred_from = 17; // from Bulk transfer  
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();
        }
        //****************** */ Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(4);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $id;
        // $newPoints->points_id = 4;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();
 
        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
        //****************** */ Update Staff Sales Person Points
        // if ($hot_lead == 1) {
        //   $lead =  LeadModel::where('sno', $id)->first();
        //   $lead->lead_status_id          = 3; //Hot lead
        //   $lead->update();
        // }
      } else {
        $category_check = CustomerFollowUpModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
 
 
      if (!$category_check) {
 
        $year = substr(date("y"), -2);
        $appointment_id = "CFU-0001/" . $year;
      } else {
 
        $data = $category_check->customer_follow_up_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
 
        $next_number = (int)$result + 1;
        $request = sprintf("CFU-%04d", $next_number);
 
        $year = substr(date("y"), -2);
        $appointment_id = $request . '/' . $year;
      }
     
       
 
        $upd_app = CustomerFollowUpModel::where('customer_id', $id)
          ->where('status', 1)
          ->where(function ($query) {
            $query->where('progressed', 0)
              ->orWhere('progressed', 2);
          })
          ->orderBy('sno', 'desc')
          ->first();
 
        if ($upd_app) {
          $upd_app->status = 4;
          $upd_app->update();
        }
 
 
 
        $upd_lead = new CustomerFollowUpModel();
        $upd_lead->customer_follow_up_id    = $appointment_id;
        $upd_lead->customer_id              = $id;
        $upd_lead->branch_id                = $branch_id;
        $upd_lead->progressed               = $progressed;
        $upd_lead->app_score                = $app_score;
        $upd_lead->follow_through           = $follow_through;
        $upd_lead->reason                   = $reason_appt;
        $upd_lead->appointment_date         = $appointment_date;
        $upd_lead->appointment_time         = $appointment_time;
        $upd_lead->status                   = 1;
        $upd_lead->created_by               = $user_id;
        $upd_lead->updated_by               = $user_id;
        //  return $upd_lead;
        $upd_lead->save();
 
 
 
        // $upd_app =  AppointmentModel::where('lead_id', $id)->whereIN('progressed', [null,2])->where('status', 1)->orderBy('sno', 'desc')->first();
        // if($upd_app){
        //     $upd_app->status = 5;
        //     $upd_app->update();
        // // }
 
        //****************** */ Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(3);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $id;
        // $newPoints->points_id = 3;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();
 
        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
        //****************** */ Update Staff Sales Person Points
 
        // if ($hot_lead == 1) {
        //   $lead =  LeadModel::where('sno', $id)->first();
        //   $lead->lead_status_id          = 3; //Hot lead
        //   $lead->update();
        // }
      }
      //   if ($upd_lead) {
      //         // Embed the lead_name directly in notification content
      //         $notificationData = [
      //             'branch_id' => $branch_id,
      //             'notification_content' => '
      //                 <div class="d-flex align-items-center">
      //                     <div class="me-3">
      //                         <span class="badge bg-gray-300">
      //                             <i class="mdi mdi-account-multiple-outline fs-3 text-black"></i>
      //                         </span>
      //                     </div>
      //                     <div class="me-2">
      //                         <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
      //                         <div class="text-secondary fs-8 fw-semibold">' . $upd_lead->lead_name . ' - Checklist Not Completed</div>
      //                     </div>
      //                 </div>',
      //             'who' => $user_id,
      //             'created_by' => $user_id,
      //             'updated_by' => $user_id,
      //             'status' => 0
      //         ];
      //         $notificationtype = 'CheckList';
      //         $newNotification = new \App\Helpers\Helpers();
 
      //         $newNotification->createNotification($notificationData, $notificationtype);
      //     }
      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }
  
}
