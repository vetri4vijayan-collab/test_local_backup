<?php

namespace App\Http\Controllers\customer_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\FollowupReasonModel;
use Carbon\Carbon;
class ManageCustomerFollowup extends Controller
{
    
    public function index(Request $request) {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        $currentMonth = date('m');
        $currentYear = date('Y');
        // Filters

        $search_filter  = $request->input('search_filter', '');
        $staff_fill = $request->input('staff_fill', '');

        $customer_flw_list = DB::table('et_customer_follow_up')
            ->select(
                'et_customer_follow_up.sno',
                'et_customer_follow_up.customer_id as cus_name_id',
                'et_customer_follow_up.appointment_date',
                'et_customer_follow_up.appointment_time',
                'et_customer_follow_up.status as appointment_status',
                'et_customer_follow_up.progressed as progressed_status',
                'et_customer_follow_up.reason as appointment_reason',
                'et_customer_follow_up.created_by as staff_id',
                'et_customer.cus_name',
                'et_customer.cus_email_id',
                'et_customer.cus_gender',
                'et_customer.customer_id',
                'et_customer.status as customer_status',
                'et_staff.staff_name'
            )
            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            ->join('et_staff', 'et_customer_follow_up.created_by', '=', 'et_staff.sno')
            
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            
            
            ->where('et_customer_follow_up.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $customer_flw_list = $customer_flw_list->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        // filter record
        if ($search_filter != '') {
            $customer_flw_list->where(function ($query) use ($search_filter) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$search_filter}%");
            });
        }

        $customer_flw_list      = $customer_flw_list->orderBy('et_customer_follow_up.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id)
                            ->where('et_customer_follow_up.appointment_date', date('Y-m-d'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        // closed followup count
        $closedFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 4)
                            ->where('et_customer_follow_up.progressed', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        // reschedule followup count
        $rescheduleFollowupCount = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        // unfollowup count
        $unFollowupCount         = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
                                ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // completed count
        $completedCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 4)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCounts = $completedCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCounts = $completedCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCounts = $completedCounts->count();
        // cancelled counts

        $cancelledCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 1)
                        ->where('et_customer_follow_up.progressed', 2)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCounts = $cancelledCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCounts = $cancelledCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCounts = $cancelledCounts->count();
        // pending counts 

        $pendingCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
                        ->where('et_customer_follow_up.status', 1)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id)
                        ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCounts = $pendingCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCounts = $pendingCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCounts = $pendingCounts->count();

        // total counts
        $TotalCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_customer.status', [0, 4])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCounts = $TotalCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCounts = $TotalCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCounts = $TotalCounts->count();


        // completed counts months
        $completedCountsMonth =  DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 4)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCountsMonth = $completedCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCountsMonth = $completedCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCountsMonth = $completedCountsMonth->count();

        // cancelled countsmonth
        $cancelledCountsMonth = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->where('et_customer_follow_up.progressed', 2)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCountsMonth = $cancelledCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCountsMonth = $cancelledCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCountsMonth = $cancelledCountsMonth->count();

        // pending coutns month
        $pendingCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
            ->where('et_customer_follow_up.status', 1)
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.branch_id', $branch_id)
            ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
            ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'))
            ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCountsMonth = $pendingCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCountsMonth = $pendingCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCountsMonth = $pendingCountsMonth->count();

        // total counts month 
        $TotalCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')->whereIn('et_customer.status', [0, 4])->where('et_customer_follow_up.branch_id', $branch_id)->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCountsMonth = $TotalCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCountsMonth = $TotalCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCountsMonth = $TotalCountsMonth->count();

        $successAppointmentRate = $TotalCounts > 0 ? ($completedCounts / $TotalCounts) * 100 : 0;
        $failAppointmentRate = $TotalCounts > 0 ? ($cancelledCounts / $TotalCounts) * 100 : 0;

        // month
        $successAppointmentRateMonth = $TotalCountsMonth > 0 ? ($completedCountsMonth / $TotalCountsMonth) * 100 : 0;
        $failAppointmentRateMonth = $TotalCountsMonth > 0 ? ($cancelledCountsMonth / $TotalCountsMonth) * 100 : 0;

        if($request->ajax()){
            return response()->json([
            'customer_flw_list'       => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,
            
            ]);
        }
       
        return view('content.customer_management.manage_followup.followup_list', [
            'customer_flw_list'           => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,

        ]);
    }
    public function todayFollowUp(Request $request){
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        $currentMonth = date('m');
        $currentYear = date('Y');
        // Filters

        $search_filter  = $request->input('search_filter', '');
        $staff_fill = $request->input('staff_fill', '');

        $customer_flw_list = DB::table('et_customer_follow_up')
            ->select(
                'et_customer_follow_up.sno',
                'et_customer_follow_up.customer_id as cus_name_id',
                'et_customer_follow_up.appointment_date',
                'et_customer_follow_up.appointment_time',
                'et_customer_follow_up.status as appointment_status',
                'et_customer_follow_up.reason as appointment_reason',
                'et_customer_follow_up.created_by as staff_id',
                'et_customer.cus_name',
                'et_customer.cus_email_id',
                'et_customer.cus_gender',
                'et_customer.customer_id',
                'et_customer.status as customer_status',
                'et_staff.staff_name'
            )
            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            ->join('et_staff', 'et_customer_follow_up.created_by', '=', 'et_staff.sno')
            
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.status', 1)
            ->where('et_customer_follow_up.appointment_date', date('y-m-d'))
            ->where('et_customer_follow_up.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $customer_flw_list = $customer_flw_list->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        // filter record
        if ($search_filter != '') {
            $customer_flw_list->where(function ($query) use ($search_filter) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$search_filter}%");
            });
        }

        $customer_flw_list      = $customer_flw_list->orderBy('et_customer_follow_up.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id)
                            ->where('et_customer_follow_up.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        // closed followup count
        $closedFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 4)
                            ->where('et_customer_follow_up.progressed', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        // reschedule followup count
        $rescheduleFollowupCount = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->where('et_customer_follow_up.progressed', 2)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        // unfollowup count
        $unFollowupCount         = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
                                ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // completed count
        $completedCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 4)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCounts = $completedCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCounts = $completedCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCounts = $completedCounts->count();
        // cancelled counts

        $cancelledCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 1)
                        ->where('et_customer_follow_up.progressed', 2)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCounts = $cancelledCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCounts = $cancelledCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCounts = $cancelledCounts->count();
        // pending counts 

        $pendingCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
                        ->where('et_customer_follow_up.status', 1)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id)
                        ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCounts = $pendingCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCounts = $pendingCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCounts = $pendingCounts->count();

        // total counts
        $TotalCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_customer.status', [0, 4])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCounts = $TotalCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCounts = $TotalCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCounts = $TotalCounts->count();


        // completed counts months
        $completedCountsMonth =  DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 4)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCountsMonth = $completedCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCountsMonth = $completedCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCountsMonth = $completedCountsMonth->count();

        // cancelled countsmonth
        $cancelledCountsMonth = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->where('et_customer_follow_up.progressed', 2)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCountsMonth = $cancelledCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCountsMonth = $cancelledCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCountsMonth = $cancelledCountsMonth->count();

        // pending coutns month
        $pendingCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
            ->where('et_customer_follow_up.status', 1)
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.branch_id', $branch_id)
            ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
            ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'))
            ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCountsMonth = $pendingCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCountsMonth = $pendingCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCountsMonth = $pendingCountsMonth->count();

        // total counts month 
        $TotalCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')->whereIn('et_customer.status', [0, 4])->where('et_customer_follow_up.branch_id', $branch_id)->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCountsMonth = $TotalCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCountsMonth = $TotalCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCountsMonth = $TotalCountsMonth->count();

        $successAppointmentRate = $TotalCounts > 0 ? ($completedCounts / $TotalCounts) * 100 : 0;
        $failAppointmentRate = $TotalCounts > 0 ? ($cancelledCounts / $TotalCounts) * 100 : 0;

        // month
        $successAppointmentRateMonth = $TotalCountsMonth > 0 ? ($completedCountsMonth / $TotalCountsMonth) * 100 : 0;
        $failAppointmentRateMonth = $TotalCountsMonth > 0 ? ($cancelledCountsMonth / $TotalCountsMonth) * 100 : 0;

        if($request->ajax()){
            return response()->json([
            'customer_flw_list'       => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,
            ]);
        }
        return view('content.customer_management.manage_followup.today_followup_list', [
            'customer_flw_list'           => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,

        ]);
    }
    public function closedFollowup(Request $request) {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        $currentMonth = date('m');
        $currentYear = date('Y');
        // Filters

        $search_filter  = $request->input('search_filter', '');
        $staff_fill = $request->input('staff_fill', '');

        $customer_flw_list = DB::table('et_customer_follow_up')
            ->select(
                'et_customer_follow_up.sno',
                'et_customer_follow_up.customer_id as cus_name_id',
                'et_customer_follow_up.appointment_date',
                'et_customer_follow_up.appointment_time',
                'et_customer_follow_up.status as appointment_status',
                'et_customer_follow_up.reason as appointment_reason', 
                'et_customer_follow_up.convo_message', 
                'et_customer_follow_up.created_by as staff_id',
                'et_customer.cus_name',
                'et_customer.cus_email_id',
                'et_customer.cus_gender',
                'et_customer.customer_id',
                
                'et_customer.status as customer_status',
                'et_staff.staff_name'
            )
            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            ->join('et_staff', 'et_customer_follow_up.created_by', '=', 'et_staff.sno')
            
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.status', 4)
            ->where('et_customer_follow_up.progressed', 1)
            ->where('et_customer_follow_up.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $customer_flw_list = $customer_flw_list->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        // filter record
        if ($search_filter != '') {
            $customer_flw_list->where(function ($query) use ($search_filter) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$search_filter}%");
            });
        }

        $customer_flw_list      = $customer_flw_list->orderBy('et_customer_follow_up.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id)
                            ->where('et_customer_follow_up.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        // closed followup count
        $closedFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 4)
                            ->where('et_customer_follow_up.progressed', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        // reschedule followup count
        $rescheduleFollowupCount = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        // unfollowup count
        $unFollowupCount         = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
                                ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // completed count
        $completedCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 4)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCounts = $completedCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCounts = $completedCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCounts = $completedCounts->count();
        // cancelled counts

        $cancelledCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 1)
                        ->where('et_customer_follow_up.progressed', 2)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCounts = $cancelledCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCounts = $cancelledCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCounts = $cancelledCounts->count();
        // pending counts 

        $pendingCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
                        ->where('et_customer_follow_up.status', 1)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id)
                        ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCounts = $pendingCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCounts = $pendingCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCounts = $pendingCounts->count();

        // total counts
        $TotalCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_customer.status', [0, 4])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCounts = $TotalCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCounts = $TotalCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCounts = $TotalCounts->count();


        // completed counts months
        $completedCountsMonth =  DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 4)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCountsMonth = $completedCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCountsMonth = $completedCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCountsMonth = $completedCountsMonth->count();

        // cancelled countsmonth
        $cancelledCountsMonth = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->where('et_customer_follow_up.progressed', 2)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCountsMonth = $cancelledCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCountsMonth = $cancelledCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCountsMonth = $cancelledCountsMonth->count();

        // pending coutns month
        $pendingCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
            ->where('et_customer_follow_up.status', 1)
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.branch_id', $branch_id)
            ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
            ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'))
            ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCountsMonth = $pendingCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCountsMonth = $pendingCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCountsMonth = $pendingCountsMonth->count();

        // total counts month 
        $TotalCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')->whereIn('et_customer.status', [0, 4])->where('et_customer_follow_up.branch_id', $branch_id)->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCountsMonth = $TotalCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCountsMonth = $TotalCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCountsMonth = $TotalCountsMonth->count();

        $successAppointmentRate = $TotalCounts > 0 ? ($completedCounts / $TotalCounts) * 100 : 0;
        $failAppointmentRate = $TotalCounts > 0 ? ($cancelledCounts / $TotalCounts) * 100 : 0;

        // month
        $successAppointmentRateMonth = $TotalCountsMonth > 0 ? ($completedCountsMonth / $TotalCountsMonth) * 100 : 0;
        $failAppointmentRateMonth = $TotalCountsMonth > 0 ? ($cancelledCountsMonth / $TotalCountsMonth) * 100 : 0;
        

        if($request->ajax()){
            return response()->json([
            'customer_flw_list'       => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,
            ]);
        }
       
        return view('content.customer_management.manage_followup.closed_followup_list', [
            'customer_flw_list'           => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,

        ]);
    }

    public function RescheduleFollowup(Request $request) {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        $currentMonth = date('m');
        $currentYear = date('Y');
        // Filters

        $search_filter  = $request->input('search_filter', '');
        $staff_fill = $request->input('staff_fill', '');

        $customer_flw_list = DB::table('et_customer_follow_up')
            ->select(
                'et_customer_follow_up.sno',
                'et_customer_follow_up.customer_id as cus_name_id',
                'et_customer_follow_up.appointment_date',
                'et_customer_follow_up.appointment_time',
                'et_customer_follow_up.status as appointment_status',
                'et_customer_follow_up.reason as appointment_reason',
                'et_customer_follow_up.created_by as staff_id',
                'et_customer.cus_name',
                'et_customer.cus_email_id',
                'et_customer.cus_gender',
                'et_customer.customer_id',
                'et_customer.status as customer_status',
                'et_staff.staff_name'
            )
            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            ->join('et_staff', 'et_customer_follow_up.created_by', '=', 'et_staff.sno')
            
            ->where('et_customer_follow_up.status', 1)
            
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.branch_id', $branch_id);
            

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $customer_flw_list = $customer_flw_list->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        // filter record
        if ($search_filter != '') {
            $customer_flw_list->where(function ($query) use ($search_filter) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$search_filter}%");
            });
        }

        $customer_flw_list      = $customer_flw_list->orderBy('et_customer_follow_up.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id)
                            ->where('et_customer_follow_up.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        // closed followup count
        $closedFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 4)
                            ->where('et_customer_follow_up.progressed', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        // reschedule followup count
        $rescheduleFollowupCount = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        // unfollowup count
        $unFollowupCount         = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
                                ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // completed count
        $completedCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 4)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCounts = $completedCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCounts = $completedCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCounts = $completedCounts->count();
        // cancelled counts

        $cancelledCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 1)
                        ->where('et_customer_follow_up.progressed', 2)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCounts = $cancelledCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCounts = $cancelledCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCounts = $cancelledCounts->count();
        // pending counts 

        $pendingCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
                        ->where('et_customer_follow_up.status', 1)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id)
                        ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCounts = $pendingCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCounts = $pendingCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCounts = $pendingCounts->count();

        // total counts
        $TotalCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_customer.status', [0, 4])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCounts = $TotalCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCounts = $TotalCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCounts = $TotalCounts->count();


        // completed counts months
        $completedCountsMonth =  DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 4)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCountsMonth = $completedCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCountsMonth = $completedCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCountsMonth = $completedCountsMonth->count();

        // cancelled countsmonth
        $cancelledCountsMonth = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->where('et_customer_follow_up.progressed', 2)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCountsMonth = $cancelledCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCountsMonth = $cancelledCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCountsMonth = $cancelledCountsMonth->count();

        // pending coutns month
        $pendingCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
            ->where('et_customer_follow_up.status', 1)
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.branch_id', $branch_id)
            ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
            ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'))
            ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCountsMonth = $pendingCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCountsMonth = $pendingCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCountsMonth = $pendingCountsMonth->count();

        // total counts month 
        $TotalCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')->whereIn('et_customer.status', [0, 4])->where('et_customer_follow_up.branch_id', $branch_id)->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCountsMonth = $TotalCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCountsMonth = $TotalCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCountsMonth = $TotalCountsMonth->count();

        $successAppointmentRate = $TotalCounts > 0 ? ($completedCounts / $TotalCounts) * 100 : 0;
        $failAppointmentRate = $TotalCounts > 0 ? ($cancelledCounts / $TotalCounts) * 100 : 0;

        // month
        $successAppointmentRateMonth = $TotalCountsMonth > 0 ? ($completedCountsMonth / $TotalCountsMonth) * 100 : 0;
        $failAppointmentRateMonth = $TotalCountsMonth > 0 ? ($cancelledCountsMonth / $TotalCountsMonth) * 100 : 0;

        if($request->ajax()){
            return response()->json([
            'customer_flw_list'       => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,
            ]);
        }
        return view('content.customer_management.manage_followup.reschedule_followup', [
            'customer_flw_list'           => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,

        ]);
    }

    public function unfollowup(Request $request) {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        $currentMonth = date('m');
        $currentYear = date('Y');
        // Filters

        $search_filter  = $request->input('search_filter', '');
        $staff_fill = $request->input('staff_fill', '');

        $customer_flw_list = DB::table('et_customer_follow_up')
            ->select(
                'et_customer_follow_up.sno',
                'et_customer_follow_up.customer_id as cus_name_id',
                'et_customer_follow_up.appointment_date',
                'et_customer_follow_up.appointment_time',
                'et_customer_follow_up.status as appointment_status',
                'et_customer_follow_up.reason as appointment_reason',
                'et_customer_follow_up.created_by as staff_id',
                'et_customer.cus_name',
                'et_customer.cus_email_id',
                'et_customer.cus_gender',
                'et_customer.customer_id',
                'et_customer.cus_mobile',
                
                'et_customer.status as customer_status',
                'et_staff.staff_name'
            )
            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            ->join('et_staff', 'et_customer_follow_up.created_by', '=', 'et_staff.sno')
            // if the customer appointment date is overdue and check the customer latest appointment
            // if exists check the appointment date with today
            ->where('et_customer_follow_up.status', 1)
            
            // ->where('et_lead.is_dc', 0)
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
            ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'))
            ->where('et_customer_follow_up.branch_id', $branch_id);

        $followupReasonList = FollowupReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get(); 

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $customer_flw_list = $customer_flw_list->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        // filter record
        if ($search_filter != '') {
            $customer_flw_list->where(function ($query) use ($search_filter) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$search_filter}%");
            });
        }

        $customer_flw_list      = $customer_flw_list->orderBy('et_customer_follow_up.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id)
                            ->where('et_customer_follow_up.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        // closed followup count
        $closedFollowupCount = DB::table('et_customer_follow_up')
                            ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                            ->where('et_customer_follow_up.status', 4)
                            ->where('et_customer_follow_up.progressed', 1)
                            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                            ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        // reschedule followup count
        $rescheduleFollowupCount = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        // unfollowup count
        $unFollowupCount         = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
                                ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_customer_follow_up.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // completed count
        $completedCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 4)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCounts = $completedCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCounts = $completedCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCounts = $completedCounts->count();
        // cancelled counts

        $cancelledCounts = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->where('et_customer_follow_up.status', 1)
                        ->where('et_customer_follow_up.progressed', 2)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCounts = $cancelledCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCounts = $cancelledCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCounts = $cancelledCounts->count();
        // pending counts 

        $pendingCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
                        ->where('et_customer_follow_up.status', 1)
                        ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                        ->where('et_customer_follow_up.branch_id', $branch_id)
                        ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCounts = $pendingCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCounts = $pendingCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCounts = $pendingCounts->count();

        // total counts
        $TotalCounts   = DB::table('et_customer_follow_up')
                        ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_customer.status', [0, 4])
                        ->where('et_customer_follow_up.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCounts = $TotalCounts->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCounts = $TotalCounts;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCounts = $TotalCounts->count();


        // completed counts months
        $completedCountsMonth =  DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 4)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $completedCountsMonth = $completedCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $completedCountsMonth = $completedCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCountsMonth = $completedCountsMonth->count();

        // cancelled countsmonth
        $cancelledCountsMonth = DB::table('et_customer_follow_up')
                                ->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
                                ->where('et_customer_follow_up.status', 1)
                                ->where('et_customer_follow_up.progressed', 2)
                                ->whereNotIn('et_customer.status', [2, 5, 6, 7])
                                ->where('et_customer_follow_up.branch_id', $branch_id)
                                ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $cancelledCountsMonth = $cancelledCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $cancelledCountsMonth = $cancelledCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCountsMonth = $cancelledCountsMonth->count();

        // pending coutns month
        $pendingCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')
            // ->where('et_customer_follow_up.progressed', null)
            ->where('et_customer_follow_up.status', 1)
            ->whereNotIn('et_customer.status', [2, 5, 6, 7])
            ->where('et_customer_follow_up.branch_id', $branch_id)
            ->where('et_customer_follow_up.appointment_date', '<=', date('y-m-d'))
            ->where('et_customer_follow_up.appointment_time', '<=', now()->format('H:i'))
            ->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);

        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $pendingCountsMonth = $pendingCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $pendingCountsMonth = $pendingCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCountsMonth = $pendingCountsMonth->count();

        // total counts month 
        $TotalCountsMonth   = DB::table('et_customer_follow_up')->join('et_customer', 'et_customer_follow_up.customer_id', '=', 'et_customer.sno')->whereIn('et_customer.status', [0, 4])->where('et_customer_follow_up.branch_id', $branch_id)->whereMonth('et_customer_follow_up.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'view_self_cus')) {
            // User can only view their own data
            $TotalCountsMonth = $TotalCountsMonth->where('et_customer_follow_up.created_by', $user_id);
            // return "view_self_cus";
        } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Post Customer Followup', 'global_cus')) {
            // User can view all data
            $TotalCountsMonth = $TotalCountsMonth;
            // return "global_cus";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCountsMonth = $TotalCountsMonth->count();

        $successAppointmentRate = $TotalCounts > 0 ? ($completedCounts / $TotalCounts) * 100 : 0;
        $failAppointmentRate = $TotalCounts > 0 ? ($cancelledCounts / $TotalCounts) * 100 : 0;

        // month
        $successAppointmentRateMonth = $TotalCountsMonth > 0 ? ($completedCountsMonth / $TotalCountsMonth) * 100 : 0;
        $failAppointmentRateMonth = $TotalCountsMonth > 0 ? ($cancelledCountsMonth / $TotalCountsMonth) * 100 : 0;

       if($request->ajax()){
            return response()->json([
            'customer_flw_list'       => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,
            ]);
        }
        return view('content.customer_management.manage_followup.unfollowup', [
            'customer_flw_list'           => $customer_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'search_filter'               => $search_filter,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,
            'followupReasonList' => $followupReasonList,

        ]);
    }


   
}
