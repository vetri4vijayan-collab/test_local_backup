<?php

namespace App\Http\Controllers\settings\bug_fixes;

use App\Http\Controllers\Controller;
use App\Models\ModulesListModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ModulesList extends Controller
{
    public function index()
    {
        $feedbacknavHtml = $this->generateNavHtml();

        $level = ModulesListModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.modules_list.list', compact('level', 'pageConfigs','feedbacknavHtml'));
    }

    public function list()
    {
       $container = ModulesListModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $container,
        ], 200);
    }

    public function Edit($id)
    {
        $credential = ModulesListModel::where('sno', $id)->first();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $credential,
        ], 200);
    }

    public function Add(Request $request)
    {
        // return $request;

        $validator = Validator::make($request->all(), [
            'module_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {


            $module_name = $request->module_name;
            $module_desc = $request->module_desc;
            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
            $chk = ModulesListModel::where('module_name', strtolower($module_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Module Name is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = ModulesListModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $module_id = "Module-0001/" . $year;
                } else {

                    $data = $category_check->module_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf("Module-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $module_id = $request . '/' . $year;
                }


                $add = new ModulesListModel();
                $add->module_id = $module_id;
                $add->module_name = Ucfirst($module_name);
                $add->description = $module_desc;
                $add->created_at = now();
                $add->created_by = $user_id;
                // return $add;
                $add->save();

                if ($add) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Module Name is added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Module Name!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Update(Request $request)
    {
        // return $request;

        $validator = Validator::make($request->all(), [
            'edit_module_id' => 'required',
            'edit_module_name' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $edit_module_id = $request->edit_module_id;
            $edit_module_name = $request->edit_module_name;
            $edit_module_desc = $request->edit_module_desc;

            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
            // return $user_id;

            $upd_IndustryTypeModel = ModulesListModel::where('sno', $edit_module_id)->first();

            $chk = ModulesListModel::where('module_name', ucwords($edit_module_name))
                ->where('sno', '!=', $edit_module_id)
                ->where('status', '!=', 2)
                ->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Module Name is exist!'
                ]);
                return redirect()->back();
            } else {


                $upd_IndustryTypeModel->module_name = Ucfirst($edit_module_name);
                $upd_IndustryTypeModel->description = $edit_module_desc;
                $upd_IndustryTypeModel->updated_by = $user_id;
                $upd_IndustryTypeModel->updated_at = now();
                $upd_IndustryTypeModel->update();


                if ($upd_IndustryTypeModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Module Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Module!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel = ModulesListModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        $upd_CourseCategoryModel = ModulesListModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    private function generateNavHtml()
    {
        $menus =  [
            [
                'title' => 'Modules',
                'url' => url('/settings/modulename'),
                'is_active' => request()->is([
                    'settings/modulename*'
                ]),
            ],
            [
                'title' => 'Drop Reasons',
                'url' => url('/settings/bug_fixes/drop_reasons'),
                'is_active' => request()->is([
                    'settings/bug_fixes/drop_reasons*'
                ]),
            ],
            [
                'title' => 'Hold Reasons',
                'url' => url('/settings/bug_fixes/hold_reasons'),
                'is_active' => request()->is([
                    'settings/bug_fixes/hold_reasons*'
                ]),
            ],
        ];

        /* ---------- AUTO WIDTH CALCULATION ---------- */

        $html = '<div class="nav-align-top mb-2">
            <ul class="nav nav-pills flex-nowrap" style="background-color: #dfdfdf;" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="scroll-container" id="scrollContainer">';
                        
                            foreach ($menus as $menu) {

                                $active = $menu['is_active'] ? 'active' : '';

                                $html .= "<div class='item'>
                                    <li class='nav-item rounded' style='border: 1px solid #099dda;'>
                                        <a href='{$menu['url']}' class='nav-link text-capitalize {$active}'>
                                            {$menu['title']}
                                        </a>
                                    </li>
                                </div>";
                            }

                            $html .= '
                        </div>
                    <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>';

        return $html;
    }

}