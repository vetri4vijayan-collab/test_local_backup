<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductDelivarablesModel;
use Illuminate\Support\Facades\Validator;
use App\Models\JournalHistoryModel;
use App\Models\ManageJournalModel;
use Illuminate\Support\Facades\DB;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\SmsTemplateModel;
use App\Models\EmailTemplateModel;
use App\Mail\ETPLMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;
use App\Services\WasabiFileService;

class Product_delivarables extends Controller
{
    public function index()
    {
        $delivarables = ProductDelivarablesModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.product_settings.delivarables', compact('delivarables'));
    }

    public function create(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'delivarable_name' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Format input field',
                'error-msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $delivarable_name = $request->input('delivarable_name');

        foreach ($delivarable_name as $delivarable_names) {
            $check = ProductDelivarablesModel::where('delivarable_name', ucwords($delivarable_names))->where('status', '!=', 2)->first();


        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Already Name is exist!'
            ]);
           continue;
        }

        $delivarables = new ProductDelivarablesModel();
        $delivarables->delivarable_name = $delivarable_names;
            $delivarables->created_by = $user_id;
            $delivarables->updated_by = $user_id;
            $delivarables->save();


        if ($delivarables) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Product Delivarable added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Product Delivarable!'
                    ]);
                }
    }
         
       return redirect()->back();
}

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_delivarable' => 'required|max:255|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Format Input Field',
                'error-msg' => $validator->messages()->get('*'),
                'data' => null,
            ]);
        } else {
            $edit_delivarable = $request->edit_delivarable;
            $sno = $request->edit_id;

            $check = ProductDelivarablesModel::where('delivarable_name', ucwords($edit_delivarable))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($check) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Alreaady Name Exists'
                ]);
                return redirect()->back();
            } else {
                $upd_DelivarableModel = ProductDelivarablesModel::where('sno', $sno)->first();
                $upd_DelivarableModel->delivarable_name = Ucfirst($edit_delivarable);


                $upd_DelivarableModel->update();

                if ($upd_DelivarableModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Delivarable Updated Succesfully',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Delivarable '
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {

        $upd_DelivarableModel = ProductDelivarablesModel::where('sno', $id)->first();
        $upd_DelivarableModel->status = $request->input('status', 0);
        $upd_DelivarableModel->update();
        if ($upd_DelivarableModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }


    public function Delete($id)
    {
        $upd_DelivarableModel = ProductDelivarablesModel::where('sno', $id)->first();
        $upd_DelivarableModel->status = 2;
        $upd_DelivarableModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    
    //noc url generate
  public function product_noc_generate($id)
    {
        try {


            // Fetch journal details
            $journal_details = DB::table('et_manage_journal')
                ->where('sno', $id)
                ->first();

            if (!$journal_details) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Journal not found',
                    'error_msg' => 'No journal record exists for this ID'
                ], 404);
            }

            // Fetch customer details
            $customer_details = DB::table('et_customer_services')
                ->select(
                    'et_customer.cus_name',
                    'et_customer.customer_id',
                    'et_customer_services.sno',
                    'et_customer_services.created_at',
                    'et_customer_services.journal_index',
                    'et_customer_services.proposal_id',
                    'et_customer.sno as journal_customer_id',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff',
                    'journal_staff.staff_name as journal_staff_name',
                    'journal_coordinator.staff_name as journal_coordinator_name',
                    'journal_staff.staff_image as journal_staff_image',
                    'journal_coordinator.staff_image as journal_coordinator_image',
                    DB::raw("
            CASE
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as service_name
        ")
                )
                ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
                ->leftJoin('et_staff as journal_staff', 'journal_staff.sno', '=', 'et_customer_services.jc_staff')
                ->leftJoin('et_staff as journal_coordinator', 'journal_coordinator.sno', '=', 'et_customer_services.jc_id')
                ->leftJoin('et_product', function ($join) {
                    $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                        ->where('et_customer_services.product_package', 1);
                })
                ->leftJoin('et_package', function ($join) {
                    $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                        ->where('et_customer_services.product_package', 2);
                })
                ->where('et_customer_services.journal_check', 1)
                ->where('et_customer_services.sno', $journal_details->service_id ?? null)
                ->first();

            if (!$customer_details) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Customer not found',
                    'error_msg' => 'No customer linked to this journal'
                ], 404);
            } else {
                $helper = new \App\Helpers\Helpers();

                $customer_details->domain_names = $helper->get_domain_by_proposalId($customer_details->proposal_id);

                // Journal Data
                // Journal Data
                $journalData = DB::table('et_manage_journal')
                    ->where('et_manage_journal.sno', $journal_details->booklet_id)
                    ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
                    ->select(
                        'et_journal_booklet.journal_name',
                        'et_journal_booklet.domain_id',
                        'et_manage_journal.status',
                        'et_manage_journal.paper_name',
                        'et_manage_journal.journal_id',
                        'et_manage_journal.submited_date',
                        'et_manage_journal.sno',
                        'et_manage_journal.publish_author',
                        'et_manage_journal.published_paper_name',
                        'et_manage_journal.publish_url',
                        'et_manage_journal.publish_date'
                    )
                    ->first();

                $customer_details->journal_data = $journalData;

                // ✅ Domain Mapping FIX
                $domain_ids = json_decode($journalData->domain_id ?? '[]', true);

                if (is_array($domain_ids) && !empty($domain_ids)) {
                    $domainNames = DB::table('et_domain')
                        ->whereIn('sno', $domain_ids)
                        ->where('status', 0)
                        ->pluck('domain_name')
                        ->toArray();

                    // ✅ Convert to comma-separated string
                    $customer_details->journal_data->domain_names = implode(', ', $domainNames);
                } else {
                    $customer_details->journal_data->domain_names = '';
                }

                // Service ID
                $year = date('Y', strtotime($customer_details->created_at));
                $id = str_pad($customer_details->sno, 5, '0', STR_PAD_LEFT);
                $customer_details->service_id = "SR-{$id}/{$year}";
            }

            return response()->json([
                'status' => 200,
                'message' => 'Product fetched successfully',
                'error_msg' => null,
                'data' => [
                    'journal_id' => $id,
                    'journal_details' => $journal_details,
                    'customer_details' => $customer_details,
                ],
            ], 200);
        } catch (\Exception $e) {
            // \Log::error('Journal NOC Error: ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => $e->getMessage() // optional: hide in production
            ], 500);
        }
    }

 public function product_noc($id)
    {
        try {
          
            $helper = new \App\Helpers\Helpers();
            $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
            // Check if decryption failed
            if ($decryptedValue === false || empty($decryptedValue)) {
                return redirect()->back()->with('error', 'Invalid Entry');
            }
            $encryptIDs = $id;
            $id = $decryptedValue;

            // Validate that $id is numeric
            if (!is_numeric($id)) {
                return redirect()->back()->with('error', 'Invalid Entry ID');
            }

            $proposal_details = DB::table('et_proposal')->where('sno', $id)->first();
            // Check if journal exists
            if (!$proposal_details) {
                return redirect()->back()->with('error', 'Product not found');
            }
            // return $proposal_details;
            //  elseif ($proposal_details->noc_approved == 1) {
            //     return view('content.journal_management.manage_journal.thankyou_screen');
            // }
            // Fetch customer details
           $customer_details =  DB::table('et_customer_services')
                ->select(
                    'et_customer.cus_name',
                    'et_customer.customer_id',
                    'et_customer_services.sno',
                    'et_customer_services.created_at',
                    'et_customer_services.journal_index',
                    'et_customer_services.proposal_id',
                    'et_customer.sno as journal_customer_id',
                    'et_customer_services.jc_id',
                    'et_customer_services.jc_staff',
                     DB::raw("
                        CASE
                                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                                    ELSE NULL
                                END as service_name
                            ")
                                    )
                                ->leftJoin(
                                        'et_customer',
                                        'et_customer.sno',
                                        '=',
                                        'et_customer_services.customer_id'
                                    )

                                    ->leftJoin('et_product', function ($join) {
                                        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                                            ->where('et_customer_services.product_package', 1);
                                    })

                                    ->leftJoin('et_package', function ($join) {
                                        $join->on('et_package.sno', '=', 'et_customer_services.product_id')
                                            ->where('et_customer_services.product_package', 2);
                                    })
                            ->where('et_customer_services.journal_check', 1)
                            ->where('et_customer.sno', $proposal_details->customer_id)
                            ->first();

            if (!$customer_details) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Customer not found',
                    'error_msg' => 'No customer linked to this service'
                ], 404);
            } 

            //  return view('content.production_management.manage_deliverables.noc_preview', compact(
            //     'id'
            // ));
            // Pass data to view
            return view('content.production_management.manage_deliverables.noc_preview', compact(
                'customer_details',
                'proposal_details',
                'encryptIDs',
            ));
        } catch (\Exception $e) {
            // Log the error for debugging
            // \Log::error('Journal NOC Error: ' . $e->getMessage());

            // Return user-friendly error
            return redirect()->back()->with('error', 'An error occurred while processing your request');
        }
    }

//noc send message 
//  public function SendNocMessage(Request $request)
//     {
//       // Validate the incoming request data
//       $validator = Validator::make($request->all(), [
//         'proposal_id' => 'required', 
//         'email'    => 'boolean',
//         'sms'     => 'boolean',
//         'whatsapp' => 'boolean'
//       ]);
//       // If validation fails, return a response with errors
//       if ($validator->fails()) {
//         return response([
//           'status'    => 401,
//           'message'   => 'Incorrect format input fields',
//           'error_msg' => $validator->messages()->get('*'),
//           'data'      => null,
//         ], 200);
//       }
          
//       $proposal_id = $request -> proposal_id;
//       $service_id  = $request -> service_id;
//       $customer_id = $request -> customer_id;
//       $branch_id = $request->user()->branch_id;
//       $entity_id = $request->user()->entity_id;
//       $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
//       $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

//       $branch_name = " ";
//       if ($branchData->branch_type == 1) {
//         $branch_name = $branchData->branch_name;
//       } elseif ($branchData->branch_type == 2) {
//         $branch_name = $branchData->franchise_name;
//       }

     
//       $customer_id  = $request->customer_id;
//       $old_customer_check  = $request->old_customer_check;

    

//     $proposal =DB::table('et_proposal')
//              ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
//              ->where('et_proposal.sno',$proposal_id)
//               ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
//               ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
//               ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
//               ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
//               ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//              ->where('et_proposal.status','!=',2)
//              ->where('et_lead.status','!=',2)
//              ->orderBy('et_proposal.sno', 'desc')
//              ->first();
//             if($proposal){
//                 if($proposal->post_sale_check==1){
//                     $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
//                     $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
//                     $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
//                 }
//             }
//          $proposal_id  = $proposal->sno;
//       $customer=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
//       // Extract the validated data
//       $lead_id=$proposal->lead_id ?? 0;
//       $email     = $request->email;
//       $sms      = $request->sms;
//       $whatsapp = $request->whatsapp;
//       $message  = $request->message;
//       $user_id  = $request->user()->user_id;


//       // return $request;
//       // Find the lead based on lead_id
//       $lead = LeadModel::where('sno', $lead_id)
//         ->first();

//       // If the lead is not found, return an error response
//       if (!$lead) {
//         return response([
//           'status'    => 404,
//           'message'   => 'Lead not found',
//           'error_msg' => 'The lead with the given ID does not exist',
//           'data'      => null,
//         ], 200);
//       }
      
      

//       $helper = new \App\Helpers\Helpers();
//       $encrypted_values = $helper->encrypt_decrypt($service_id, 'encrypt');

//       $ReceiptLink ='https://erp.elysiumtechnologies.com/manage_product_noc/'.$encrypted_values;
      
//          //  communication Receipt
//          $communicationStatus=DB::table('et_communication_handle')->where('module_name','Receipt Send')->first();
//          $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
         
//         if($communicationStatus && $communicationStatus->status == 0){
      
     
//               // Receipt Communication 
              
//                   $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                  
//                       $lead_name =$lead->lead_name;
//                       $lead_email_id =$customer->cus_email_id ??$lead->lead_email_id;
//                       $lead_mobile =$lead->lead_mobile;
                  
//                         $TargetCurrency = $proposal->currency_code ?? 'INR';
//                         $endpoint = 'convert';
//                         $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                
//                         $helper = new \App\Helpers\Helpers();
//                         //   if ($TargetCurrency !== 'INR') {
//                         //     $response= $helper->convertFromINR($TargetCurrency);   
//                         //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
//                         //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
//                         //     $converted_amount = ($exchange_quote != 0) ? $slots->paidAmount * $exchange_quote : 0;
//                         //   }else{
//                         //     $converted_amount =$slots->paidAmount;
//                         //   }
//               $exchange_quote=1;
                          
//                          $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
//                          $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
//                           $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile;
                       
                          
//                       // sms Receipt send
//                       if($communicationStatus->sms ==0){
//                         if ($sms == 1) {
            
//                               $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
//                               $authkey = $result_sms ? $result_sms->authkey : '';
//                               $sender_id = $result_sms ? $result_sms->sender_id : '';
//                               $template_id = $result_sms ? $result_sms->template_id : '';
//                               $country_code = $result_sms ? $result_sms->country_code : '';
//                               $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
//                               $mobile_number = $country_code . $lead_mobile;
                    
                             
                           
                    
//                               // Replace placeholders with actual values
//                               $replacement_values = [$lead_name,$cre_mobile];
//                               $message_content = preg_replace_callback(
//                                 '/\{#var#\}/',
//                                 function () use (&$replacement_values) {
//                                   return array_shift($replacement_values);
//                                 },
//                                 $message_content
//                               );
                    
//                               $route = "default";
//                               $postData = array(
//                                 'authkey' => $authkey,
//                                 'mobiles' => $mobile_number,
//                                 'message' => $message_content,
//                                 'sender' => $sender_id,
//                                 'route' => $route,
//                               );
                    
//                               // API URL
//                               $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                    
//                               // Initialize the resource
//                               $ch = curl_init();
//                               curl_setopt_array($ch, array(
//                                 CURLOPT_URL => $url,
//                                 CURLOPT_RETURNTRANSFER => true,
//                                 CURLOPT_POST => true,
//                                 CURLOPT_POSTFIELDS => $postData,
//                                 CURLOPT_SSL_VERIFYHOST => 0,
//                                 CURLOPT_SSL_VERIFYPEER => 0,
//                               ));
                    
//                               // Get response
//                               $response = curl_exec($ch);
//                               // return $response;
//                               $err = curl_error($ch);
//                               curl_close($ch);
//                             }
//                     }
                    
//                     // Email Receipt Send
//                       if($communicationStatus->email ==1){ 
//                           if ($email == 1) {
//                         if ($lead_email_id) {
//                             $emailTemplate_id =7; // proposal send Template Id
//                             $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
//                             // Gender condition
//                             $genderPrefix = 'Mr/Ms'; // Default value
//                             if ($lead->lead_gender == 1) {
//                               $genderPrefix = 'Mr';
//                             } elseif ($lead->lead_gender == 2) {
//                               $genderPrefix = 'Ms';
//                             }
                        
                      
                        
//                         $content = $emailTemplate->email_subject;
                
//                         $dynamicSubject = str_replace('#entity_name',   'Elysium Technology NOC for Product Delivery', $emailTemplate->email_name);
                
//                         $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                    
//                         $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
//                         $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
//                         $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
//                         $branchNo = $branch->mobile;
//                         $branchemail = $branch->mail;
//                         $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
//                         $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
//                         $url= 'phdizone.com';
                
//                         $mailData = [
//                               'url'         => $url,
//                               'subject'     => "Elysium Technology NOC for Product Delivery",
//                               'content'     => $content,
//                               'branchNo'    => $branchNo,
//                               'branchemail' => $branchemail, // Use the message content from the request
//                               'fbLink'      => $fbLink,      // Use the message content from the request
//                               'instaLink'   => $instaLink,   // Use the message content from the request
//                               'salesMobile' => $cre_mobile ?? '8220011465',
//                           ];
//                         $to_address = $lead_email_id;
//                         $from_address = 'elysiumtechnology@elysium.community';
//                         $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
//                         Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
//                      }
//                           }
//                       }
                      
//                     //  Whatsapp Receipt Send
//                       if($communicationStatus->whatsapp ==0){
                           
//                           if ($whatsapp == 1) {
//                                 if ($lead_mobile) {
                          
                           
//                                 // $templateName  = "hello_world";
//                                 $templateName  = "payment_recept_phdizone";
                
//                                 $hasHeader  = false; // Example flag: set based on template
//                                 $hasBody    = false; // Example flag: set based on template
//                                 $hasFooter  = false; // Example flag: set based on template
//                                 $hasButton  = false;
//                                 $components = [];
//                                 $couponCode = " ";
//                                 date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
//                                 $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
//                                                                           // $currentHour = date('H'); // Get current hour in 24-hour format
//                                 if ($currentHour >= 5 && $currentHour < 12) {
//                                     $greeting = 'Good Morning';
//                                 } elseif ($currentHour >= 12 && $currentHour < 18) {
//                                     $greeting = 'Good Afternoon';
//                                 } else {
//                                     $greeting = 'Good Evening';
//                                 }
                
//                                 if ($templateName == 'payment_recept_phdizone') {
//                                     $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
//                                     $couponCode  = 'NOOFFER';
//                                     $buttonIndex = 1;
//                                     $bodyText    = [
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $customer ? $customer->cus_name : $lead_name,
//                                             'parameter_name' => 'customer_name',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $paymentData->payment_id ?? '',
//                                             'parameter_name' => 'recept_number',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $transaction_date ?? date('d-M-Y'),
//                                             'parameter_name' => 'payment_date',
//                                         ],
//                                          [
//                                             'type'           => 'text',
//                                             'text'           => $slotAmount ?? '',
//                                             'parameter_name' => 'payment',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $proposal->service_title ?? '',
//                                             'parameter_name' => 'service_name',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $slot_url_key_receipt?? "",
//                                             'parameter_name' => 'link_key',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $cre_mobile ?? '8220011465',
//                                             'parameter_name' => 'cre_number',
//                                         ],
//                                     ];
//                                     $hasHeader = true;
//                                     $hasBody   = true;
//                                     $hasButton = true;
//                                 }
                
//                                 // Add Header if required
//                                 if ($hasHeader) {
//                                     $components[] = [
//                                         'type'       => 'header',
//                                         'parameters' => [
//                                             [
//                                                 'type'  => 'image',
//                                                 'image' => [
//                                                     'link' => $headerImage, // Dynamically set header image
//                                                 ],
//                                             ],
//                                         ],
//                                     ];
//                                 }
                
//                                 // Add Body if required
//                                 if ($hasBody) {
//                                     $components[] = [
//                                         'type'       => 'body',
//                                         'parameters' => $bodyText,
//                                     ];
//                                 }
                
//                                 // Add Footer if required
//                                 if ($hasButton) {
//                                     $components[] = [
//                                         'type'       => 'button',
//                                         'sub_type'   => 'url',
//                                         'index'      => 0,
//                                         'parameters' => [
//                                             [
//                                                 'type' => 'text',
//                                                 'text' => $slot_url_key_receipt ?? "",
//                                             ],
//                                         ],
//                                     ];
//                                 }
                                
                                
//                                 $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
//                                 $dynamicParameters         = $templateParameters[$templateName] ?? [];
//                                 $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
//                                 $accessToken               = $whatsappApi->access_tokken ?? '';
//                                 $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
//                                 $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
//                                 $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
//                                 $to           = $lead_mobile;
//                                 $languageCode = 'en';
                    
//                                 if (strpos($to, $countryCode) !== 0) {
//                                     $to = $countryCode . $to;
//                                 }
                
//                                 $message = 'test~message';
//                                 if (empty($components)) {
//                                     $payload = [
//                                         'messaging_product' => 'whatsapp',
//                                         'to'                => $to,
//                                         'type'              => 'template',
//                                         'template'          => [
//                                             'name'     => $templateName,
//                                             'language' => [
//                                                 'code' => $languageCode,
//                                             ],
//                                         ],
//                                     ];
//                                 } else {
//                                     $payload = [
//                                         'messaging_product' => 'whatsapp',
//                                         'to'                => $to,
//                                         'type'              => 'template',
//                                         'template'          => [
//                                             'name'       => $templateName,
//                                             'language'   => [
//                                                 'code' => $languageCode,
//                                             ],
//                                             'components' => $components,
//                                         ],
//                                     ];
//                                 }
                
//                                 $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                
                               
//                              if ($response['status'] == 200) {}
//                              else{
//                                  return response([
//                                       'status' => 404,
//                                       'message' => 'Failed to send message',
//                                       'error_msg' => $response['error'],
//                                     ], 400);
//                                 }
                            
//                       }
//                           }
//                       }
                    
                 
                      
//         }else{
//             return $communicationStatus;
//         }
//       // If the operation was successful, return a success response
//       return response([
//         'status'    => 200,
//         'message'   => "Message sent successfully",
//         'error_msg' => null,
//         'data'      => null,
//       ], 200);
//     }

///Noc Agreement
//  public function agreeDeliveryNoc(Request $request)
//     {
//         $customer_id = $request->user_id;
//         $proposal_id = $request->proposal_id;
      

//         if (! $customer_id || ! $proposal_id) {
//             return response()->json([
//                 'status' => 404,
//                 'status_code' => 404,
//                 'message' => 'ID Not Found !',
//             ], 404);
//         }

//         $proposalData = DB::table('et_proposal')
//             ->where('customer_id', $customer_id)
//             ->where('sno', $proposal_id)
//             ->where('noc_approved', 0)
//             ->where('status', '!=', 2)
//             ->orderBy('sno', 'asc')
//             ->get();

//         if ($proposalData->isEmpty()) {
//             return response()->json([
//                 'status' => 404,
//                 'status_code' => 404,
//                 'message' => 'No History Found !',
//             ], 404);
//         }

//     // $journal = DB::table('et_manage_journal')
//     //         ->where('sno', $journal_id)
//     //         ->where('status', 8)
//     //         ->get();

//     $count = $proposalData->count();
//             if($count<1){
//                   return response()->json([
//                     'status_code' => 404,
//                     'message' => 'No published journal found!',
//                 ], 404);
//             }
//               $updated = DB::table('et_proposal')
//                     ->where('sno', $proposal_id)
//                     ->where('customer_id', $customer_id)
//                     ->update([
//                             'noc_approved' => '1',
//                             'updated_at' => now()
//                         ]);

//                 if ($updated) {
//                     return response()->json([
//                         'status' => 200,
//                         'status_code' => 200,
//                         'message' => 'Updated successfully',
//                     ]);
//                 }

//                 return response()->json([
//                     'status' => $updated,
//                     'status_code' => 404,
//                     'message' => 'No records updated',
//                 ], 404);
//         }

public function agreeDeliveryNoc(Request $request)
    {
   
      $helper = new \App\Helpers\Helpers();
        $customer_id = $request->user_id;
        $proposal_id = $request->proposal_id;
        if (! $customer_id || ! $proposal_id) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'ID Not Found !',
            ], 404);
        }
 
        $proposalData = DB::table('et_proposal')
            ->where('customer_id', $customer_id)
            ->where('sno', $proposal_id)
            ->where('noc_approved', 0)
            ->where('status', '!=', 2)
            ->orderBy('sno', 'asc')
            ->get();
 
        if ($proposalData->isEmpty()) {
            return response()->json([
                'status' => 404,
                'status_code' => 404,
                'message' => 'No History Found !',
            ], 404);
        }
 
    // $journal = DB::table('et_manage_journal')
    //         ->where('sno', $journal_id)
    //         ->where('status', 8)
    //         ->get();
 
    $count = $proposalData->count();
            if($count<1){
                  return response()->json([
                    'status_code' => 404,
                    'message' => 'No published journal found!',
                ], 404);
            }
               $updated = DB::table('et_proposal')
                    ->where('sno', $proposal_id)
                    ->where('customer_id', $customer_id)
                    ->update([
                            'noc_approved' => '1',
                            'noc_approved_at' => now(),
                            'updated_at' => now()
                        ]);
               
                 $helper->calculateProductionPoints($proposal_id);
 
                if ($updated) {
                    return response()->json([
                        'status' => 200,
                        'status_code' => 200,
                        'message' => 'Updated successfully',
                    ]);
                }
 
                return response()->json([
                    'status' => $updated,
                    'status_code' => 404,
                    'message' => 'No records updated',
                ], 404);
        }
    
    // public function task_acknowledge($id)
    // {
    //     $helper = new \App\Helpers\Helpers();
    //     $historyId = $helper->encrypt_decrypt($id,'decrypt');
    //     // return $historyId;
 
    //     if(!$historyId){
    //         abort(404);
    //     }
 
    //     $taskDetails = DB::table('et_milestone_history as mh')
 
    //         ->join(
    //             'et_milestone_mapping as mm',
    //             'mm.sno',
    //             '=',
    //             'mh.milestone_id'
    //         )
 
    //         ->join(
    //             'et_customer_services as cs',
    //             'cs.sno',
    //             '=',
    //             'mm.service_id'
    //         )
 
    //         ->join(
    //             'et_customer as c',
    //             'c.sno',
    //             '=',
    //             'cs.customer_id'
    //         )
 
    //         ->join(
    //             'et_product_task as t',
    //             't.sno',
    //             '=',
    //             'mh.task_id'
    //         )
 
    //         ->select(
    //             'mh.*',
    //             'mm.service_id',
    //             'c.cus_name',
    //             'c.customer_id',
    //             't.task_name'
    //         )
 
    //         ->where('mh.sno',$historyId)
    //         ->first();
    //     if(!$taskDetails){
    //         abort(404);
    //     }
 
    //     $documents = DB::table('et_task_documents')
    //         ->where('milestone_history_id',$historyId)
    //         ->where('status', 0)
    //         ->get();
    //     $milestone_history = DB::table('et_milestone_history')
    //         ->where('sno', $historyId)
    //         ->first();
 
    //     return view(
    //         'content.production_management.manage_deliverables.task_acknowledge',
    //         compact(
    //             'taskDetails',
    //             'documents',
    //             'milestone_history',
    //             'id'
    //         )
    //     );
    // }
    
    public function task_acknowledge($id)
    {
        $helper = new \App\Helpers\Helpers();
        $historyId = $helper->encrypt_decrypt($id,'decrypt');
        // return $historyId;
 
        if(!$historyId){
            abort(404);
        }
 
       $taskDetails = DB::table('et_milestone_history as mh')
 
    ->join(
        'et_milestone_mapping as mm',
        'mm.sno',
        '=',
        'mh.milestone_id'
    )
 
    ->join(
        'et_customer_services as cs',
        'cs.sno',
        '=',
        'mm.service_id'
    )
 
    ->join(
        'et_customer as c',
        'c.sno',
        '=',
        'cs.customer_id'
    )
 
    ->join(
        'et_product_task as t',
        't.sno',
        '=',
        'mh.task_id'
    )
 
    ->leftJoin(
        'et_proposal as p',
        'p.sno',
        '=',
        'cs.proposal_id'
    )
 
    ->leftJoin(
        'et_cug_management as cm',
        'cm.staff_id',
        '=',
        'p.cre_id'
    )
 
    ->select(
        'mh.*',
        'mm.service_id',
        'c.cus_name',
        'c.customer_id',
        't.task_name',
        'p.cre_id',
        'cm.cre_mobile as cre_mobile'
    )
 
    ->where('mh.sno', $historyId)
    ->first();
        if(!$taskDetails){
            abort(404);
        }
 
        $documents = DB::table('et_task_documents')
            ->where('milestone_history_id',$historyId)
            ->where('status', 0)
            ->get();
        $milestone_history = DB::table('et_milestone_history')
            ->where('sno', $historyId)
            ->first();
 
        return view(
            'content.production_management.manage_deliverables.task_acknowledge',
            compact(
                'taskDetails',
                'documents',
                'milestone_history',
                'id'
            )
        );
    }


public function agree_task_acknowledgement(Request $request)
    {
        try{
            $request->validate([
                'milestone_history_id' => 'required',
                'response' => 'required', 
                'remarks' => 'nullable', 
                'documents.*' => 'mimes:pdf,doc,docx,xls,xlsx,jpg,jpeg,png,zip|max:10240' 
                ]);
        $milestone = DB::table('et_milestone_history')
            ->where('sno', $request->milestone_history_id)
            ->first();
 
        if (!$milestone) {
            return response()->json([
                'status'=>404
            ]);
        }
 
        $history =$milestone ;
        $oldAckStatus = $history->customer_ack_status;
        $oldResponse  = $history->customer_response;
 
    $milestonemapping = DB::table('et_milestone_mapping')
        ->where('sno', $history->milestone_id)
        ->first();
 
    $task = DB::table('et_product_task')
        ->where('sno', $milestone->task_id)
        ->first();
 
    $service = DB::table('et_customer_services')
        ->where('sno', $milestonemapping->service_id)
        ->first();
    if ($request->hasFile('documents')) {
         $wasabi = app(WasabiFileService::class);

        foreach ($request->file('documents') as $file) {
            $folder = 'customer_task_documents';
            $uploadResult = $wasabi->upload($file, $folder);

            DB::table( 'et_task_customer_documents' )->insert([ 
                'milestone_history_id' => $request->milestone_history_id,
                'service_id' => $milestonemapping->service_id,
                'uploaded_by_customer' => $milestonemapping->customer_id,
                'document_name' => pathinfo( $file->getClientOriginalName(), PATHINFO_FILENAME ), 
                'document_file' => $uploadResult['key'], 
                'remarks' => $request->remarks
            ]); 
        }
                }
    $customer = DB::table('et_customer')
        ->where('sno', $service->customer_id)
        ->first();
        if ($request->response == 1) {
 
            DB::table('et_milestone_history')
                ->where('sno', $milestone->sno)
                ->update([
 
                    'customer_ack_status'=>1,
                    'customer_response'=>1,
                    'customer_ack_date'=>now(),
                    'customer_ack_ip'=>$request->ip()
                ]);
 
               $helper = new \App\Helpers\Helpers();
 
            $notificationData = [
 
                'branch_id' => $service->branch_id,
 
                'notification_type' => 'Task',
 
                'notification_content' => '
<div class="d-flex align-items-center">
 
                        <div class="me-3">
<span class="badge bg-light-success">
<i class="mdi mdi-check-circle-outline fs-3 text-success"></i>
</span>
</div>
 
                        <div>
 
                            <div class="fs-7 text-success fw-bold">
                                Customer Accepted Task
</div>
 
                            <div class="text-secondary fs-8 fw-semibold">
                                Customer <b>'.e($customer->cus_name).'</b> accepted
<b>'.e($task->task_name).'</b>.
</div>
 
                        </div>
 
                    </div>
                ',
 
                'who'        => $customer->sno,
                'whom'       => $service->cre_id,
                'created_by' => $customer->sno,
                'updated_by' => $customer->sno,
                'status'     => 0
            ];
 
            $helper->createNotificationToStaff($notificationData);
            $helper->createProductionLog([
 
            'service_id' => $milestonemapping->service_id,
 
            'milestone_id' => $history->milestone_id,
 
            'milestone_history_id' => $history->sno,
 
            'action_type' => 'customer_accepted',
 
            'old_value' => [
 
                'customer_ack_status' => $oldAckStatus,
                'customer_response'   => $oldResponse
 
            ],
 
            'new_value' => [
 
                'customer_ack_status' => 1,
                'customer_response'   => 1
 
            ],
 
            'remarks' => 'Customer acknowledged the completed task.',
 
            'performed_by' => $customer->sno
 
        ]);
 
            return response()->json([
                'status'=>200,
                'message'=>'Acknowledged successfully.'
            ]);
        }
 
        DB::table('et_milestone_history')
            ->where('sno', $milestone->sno)
            ->update([
 
                'customer_response'=>2,
                'customer_reject_remarks'=>$request->remarks,
                'customer_reject_date'=>now()
            ]);
            $helper = new \App\Helpers\Helpers();
 
            $notificationData = [
 
                'branch_id' => $service->branch_id,
 
                'notification_type' => 'Task',
 
                'notification_content' => '
<div class="d-flex align-items-center">
 
                        <div class="me-3">
<span class="badge bg-light-danger">
<i class="mdi mdi-comment-alert-outline fs-3 text-danger"></i>
</span>
</div>
 
                        <div>
 
                            <div class="fs-7 text-danger fw-bold">
                                Customer Requested Changes
</div>
 
                            <div class="text-secondary fs-8 fw-semibold">
                                Customer <b>'.e($customer->cus_name).'</b> requested changes for
<b>'.e($task->task_name).'</b>.
<br>
<b>Remarks :</b> '.e($request->remarks).'
</div>
 
                        </div>
 
                    </div>
                ',
 
                'who'        => $customer->sno,
                'whom'       => $service->cre_id,
                'created_by' => $customer->sno,
                'updated_by' => $customer->sno,
                'status'     => 0
            ];
 
            $helper->createNotificationToStaff($notificationData);
 
            $helper->createProductionLog([
 
                'service_id' => $milestonemapping->service_id,
 
                'milestone_id' => $history->milestone_id,
 
                'milestone_history_id' => $history->sno,
 
                'action_type' => 'customer_changes_requested',
 
                'old_value' => [
 
                    'customer_ack_status' => $oldAckStatus,
                    'customer_response'   => $oldResponse
 
                ],
 
                'new_value' => [
 
                    'customer_response' => 2
 
                ],
 
                'remarks' => $request->remarks,
 
                'performed_by' => $customer->sno
 
            ]);
        return response()->json([
            'status'=>200,
            'message'=>'Your change request has been submitted.'
        ]);
        } catch (\Exception $e){
 
            DB::rollBack();
 
            return response()->json([
                'status'=>500,
                'message'=>$e->getMessage()
            ]);
        }
    }

// public function revertTaskProduction(Request $request)
// {
//     DB::beginTransaction();
 
//     try {
//         $history = DB::table('et_milestone_history')
//             ->where('sno', $request->history_id)
//             ->first();
//         if($request->action_type == 'resolved')
//         {
//             // return $request->history_id;
             
//             $oldCustomerResponse = $history->customer_response;
//             $oldIssueResolved = $history->customer_issue_resolved;
//            $affectedRows =  DB::table('et_milestone_history')
//                 ->where('sno',$request->history_id)
//                 ->update([
 
//                     'customer_issue_resolved' => 1,
//                     'customer_issue_resolved_by' => auth()->user()->user_id,
//                     'customer_issue_resolved_date' => now(),
//                     'customer_issue_resolution_remarks'
//                         => $request->resolution_remarks,
 
//                     'customer_response' => 0,
//                     'customer_ack_status' => 0,
//                     'customer_ack_date' => null,
//                     'customer_ack_ip' => null,
 
//                     'updated_at' => now()
//                 ]);
//                 $helper = new \App\Helpers\Helpers();
 
//                 $helper->createProductionLog([
 
//                     'service_id' => $request->service_id,
 
//                     'milestone_id' => $history->milestone_id,
 
//                     'milestone_history_id' => $history->sno,
 
//                     'action_type' => 'customer_issue_resolved',
 
//                     'old_value' => [
 
//                         'customer_response' => $oldCustomerResponse,
//                         'customer_issue_resolved' => $oldIssueResolved,
 
//                     ],
 
//                     'new_value' => [
 
//                         'customer_response' => 0,
//                         'customer_issue_resolved' => 1,
 
//                     ],
 
//                     'remarks' => $request->resolution_remarks,
 
//                     'performed_by' => auth()->user()->user_id,
 
//                 ]);
//                 $service = DB::table('et_customer_services')
//                     ->where('sno', $request->service_id)
//                     ->first();
 
//                 $notificationUsers = [];
 
//                 // PC
//                 if (!empty($service->pc_id)) {
//                     $notificationUsers[] = $service->pc_id;
//                 }
 
//                 // Production Staff
//                 if (!empty($service->production_staffs_id)) {
 
//                     $staffs = json_decode($service->production_staffs_id, true);
 
//                     if (is_array($staffs)) {
 
//                         $notificationUsers = array_merge(
//                             $notificationUsers,
//                             $staffs
//                         );
 
//                     }
//                 }
 
//                 $notificationUsers = array_unique($notificationUsers);
//                 foreach ($notificationUsers as $userId) {
 
//                     DB::table('et_notifications')->insert([
 
//                         'user_id'       => $userId,
 
//                         'title'         => 'Task Reverted',
 
//                         'message'       => 'Task has been reverted by CRE. Please review and take necessary action.',
 
//                         'reference_id'  => $history->sno,
 
//                         'reference_type'=> 'milestone_history',
 
//                         'is_read'       => 0,
 
//                         'created_at'    => now(),
 
//                         'updated_at'    => now()
 
//                     ]);
 
//                 }
//                 DB::commit();
               
//             if ($affectedRows > 0) {
//                 return response()->json([
//                 'status'=>200,
//                 'message'=>'Issue resolved successfully.'
//             ]);
//             }
//             else{
//                  return response()->json([
//                 'status'=>400,
//                 'message'=>'Issue resolve failed.'
//             ]);
//             }
//         }
//         $oldStatus = $history->status;
//         $oldRevertType = $history->revert_type;
//         $request->validate([
//             'history_id' => 'required',
//             'remarks' => 'required',
//             'revert_type' => 'required|in:1,2'
//         ]);
//         $history = DB::table('et_milestone_history')
//             ->where('sno',$request->history_id)
//             ->first();
 
//         if(!$history){
//             return response()->json([
//                 'status'=>404,
//                 'message'=>'Task not found'
//             ]);
//         }
// $status = $request->revert_type == 1
//             ? 8 // Correction
//             : 9; // Update Required
//         DB::table('et_milestone_history')
//             ->where('sno',$request->history_id)
//             ->update([
//                 'status' => $status,
//                 'revert_type' => $request->revert_type,
//                 'reverted_to_production' => 1,
//                 'reverted_by' => auth()->user()->user_id,
//                 'reverted_date' => now(),
//                 'reverted_remarks' => $request->remarks,
//                 'customer_response' => 0,
//                 'customer_ack_status' => 0,
//                 'customer_ack_date' => null,
//                 'customer_ack_ip' => null,
//                 'updated_at' => now(),
//             ]);
 
//             $helper = new \App\Helpers\Helpers();
 
//             $helper->createProductionLog([
 
//                 'service_id' => $request->service_id,
 
//                 'milestone_id' => $history->milestone_id,
 
//                 'milestone_history_id' => $history->sno,
 
//                 'action_type' => $request->revert_type == 1
//                     ? 'customer_correction'
//                     : 'customer_update_required',
 
//                 'old_value' => [
 
//                     'status' => $oldStatus,
//                     'revert_type' => $oldRevertType,
 
//                 ],
 
//                 'new_value' => [
 
//                     'status' => $status,
//                     'revert_type' => $request->revert_type,
 
//                 ],
 
//                 'remarks' => $request->remarks,
 
//                 'performed_by' => auth()->user()->user_id,
 
//             ]);
//         DB::table('et_task_revert_logs')->insert([
//             'milestone_history_id' => $history->sno,
//             'service_id' => $history->service_id ?? 0,
//             'customer_remarks' => $history->customer_reject_remarks,
//             'revert_type' => $request->revert_type,
//             'reverted_by' => auth()->user()->user_id,
//             'remarks' => $request->remarks,
//             'created_at' => now(),
//             'updated_at' => now(),
//         ]);
 
//          $service = DB::table('et_customer_services')
//                     ->where('sno', $request->service_id)
//                     ->first();
 
//                 $notificationUsers = [];
 
//                 // PC
//                 if (!empty($service->pc_id)) {
//                     $notificationUsers[] = $service->pc_id;
//                 }
 
//                 // Production Staff
//                 if (!empty($service->production_staffs_id)) {
 
//                     $staffs = json_decode($service->production_staffs_id, true);
 
//                     if (is_array($staffs)) {
 
//                         $notificationUsers = array_merge(
//                             $notificationUsers,
//                             $staffs
//                         );
 
//                     }
//                 }
 
//                 $notificationUsers = array_unique($notificationUsers);
//                 foreach ($notificationUsers as $userId) {
 
//                     DB::table('et_notifications')->insert([
 
//                         'user_id'       => $userId,
 
//                         'title'         => 'Task Reverted',
 
//                         'message'       => 'Task has been reverted by CRE. Please review and take necessary action.',
 
//                         'reference_id'  => $history->sno,
 
//                         'reference_type'=> 'milestone_history',
 
//                         'is_read'       => 0,
 
//                         'created_at'    => now(),
 
//                         'updated_at'    => now()
 
//                     ]);
 
//                 }
//         DB::commit();
       
//         return response()->json([
//             'status'=>200,
//             'message'=>'Task reverted successfully.'
//         ]);
 
//     } catch (\Exception $e){
 
//         DB::rollBack();
 
//         return response()->json([
//             'status'=>500,
//             'message'=>$e->getMessage()
//         ]);
//     }
// }

// public function revertTaskProduction(Request $request)
// {
//     DB::beginTransaction();

//     try {
//         $history = DB::table('et_milestone_history')
//             ->where('sno', $request->history_id)
//             ->first();
//         if($request->action_type == 'resolved')
//         {
//             // return $request->history_id;
              
//             $oldCustomerResponse = $history->customer_response;
//             $oldIssueResolved = $history->customer_issue_resolved;
//           $affectedRows =  DB::table('et_milestone_history')
//                 ->where('sno',$request->history_id)
//                 ->update([

//                     'customer_issue_resolved' => 1,
//                     'customer_issue_resolved_by' => auth()->user()->user_id,
//                     'customer_issue_resolved_date' => now(),
//                     'customer_issue_resolution_remarks'
//                         => $request->resolution_remarks,

//                     'customer_response' => 0,
//                     'customer_ack_status' => 0,
//                     'customer_ack_date' => null,
//                     'customer_ack_ip' => null,

//                     'updated_at' => now()
//                 ]);
//                 $helper = new \App\Helpers\Helpers();

//                 $helper->createProductionLog([

//                     'service_id' => $request->service_id,

//                     'milestone_id' => $history->milestone_id,

//                     'milestone_history_id' => $history->sno,

//                     'action_type' => 'customer_issue_resolved',

//                     'old_value' => [

//                         'customer_response' => $oldCustomerResponse,
//                         'customer_issue_resolved' => $oldIssueResolved,

//                     ],

//                     'new_value' => [

//                         'customer_response' => 0,
//                         'customer_issue_resolved' => 1,

//                     ],

//                     'remarks' => $request->resolution_remarks,

//                     'performed_by' => auth()->user()->user_id,

//                 ]);
//                 $service = DB::table('et_customer_services')
//                     ->where('sno', $request->service_id)
//                     ->first();

//                 $notificationUsers = [];

//                 // PC
//                 if (!empty($service->pc_id)) {
//                     $notificationUsers[] = $service->pc_id;
//                 }

//                 // Production Staff
//                 if (!empty($service->production_staffs_id)) {

//                     $staffs = json_decode($service->production_staffs_id, true);

//                     if (is_array($staffs)) {

//                         $notificationUsers = array_merge(
//                             $notificationUsers,
//                             $staffs
//                         );

//                     }
//                 }

//                 $notificationUsers = array_unique($notificationUsers);
//                 foreach ($notificationUsers as $userId) {

//                     DB::table('et_notifications')->insert([

//                         'user_id'       => $userId,

//                         'title'         => 'Task Reverted',

//                         'message'       => 'Task has been reverted by CRE. Please review and take necessary action.',

//                         'reference_id'  => $history->sno,

//                         'reference_type'=> 'milestone_history',

//                         'is_read'       => 0,

//                         'created_at'    => now(),

//                         'updated_at'    => now()

//                     ]);

//                 }
//                 DB::commit();
                
//             if ($affectedRows > 0) {
//                 return response()->json([
//                 'status'=>200,
//                 'message'=>'Issue resolved successfully.'
//             ]);
//             }
//             else{
//                  return response()->json([
//                 'status'=>400,
//                 'message'=>'Issue resolve failed.'
//             ]);
//             }
//         }
//         $oldStatus = $history->status;
//         $oldRevertType = $history->revert_type;
//         $request->validate([
//             'history_id' => 'required',
//             'remarks' => 'required',
//             'revert_type' => 'required|in:1,2'
//         ]);
//         $history = DB::table('et_milestone_history')
//             ->where('sno',$request->history_id)
//             ->first();

//         if(!$history){
//             return response()->json([
//                 'status'=>404,
//                 'message'=>'Task not found'
//             ]);
//         }
// $status = $request->revert_type == 1
//             ? 8 // Correction
//             : 9; // Update Required
//         DB::table('et_milestone_history')
//             ->where('sno',$request->history_id)
//             ->update([
//                 'status' => $status,
//                 'revert_type' => $request->revert_type,
//                 'reverted_to_production' => 1,
//                 'reverted_by' => auth()->user()->user_id,
//                 'reverted_date' => now(),
//                 'reverted_remarks' => $request->remarks,
//                 'customer_response' => 0,
//                 'customer_ack_status' => 0,
//                 'customer_ack_date' => null,
//                 'customer_ack_ip' => null,
//                 'updated_at' => now(),
//                  'target_completion_date' => $request->target_completion_date ?? '',
//                 'target_completion_by'=> auth()->user()->user_id,
//             ]);

//             $helper = new \App\Helpers\Helpers();

//             $helper->createProductionLog([

//                 'service_id' => $request->service_id,

//                 'milestone_id' => $history->milestone_id,

//                 'milestone_history_id' => $history->sno,

//                 'action_type' => $request->revert_type == 1
//                     ? 'customer_correction'
//                     : 'customer_update_required',

//                 'old_value' => [

//                     'status' => $oldStatus,
//                     'revert_type' => $oldRevertType,
//                     'target_completion_date' => $history->target_completion_date
//                 ],

//                 'new_value' => [

//                     'status' => $status,
//                     'revert_type' => $request->revert_type,
//                     'target_completion_date' => $history->target_completion_date
//                 ],

//                 'remarks' => $request->remarks,

//                 'performed_by' => auth()->user()->user_id,

//             ]);
//         DB::table('et_task_revert_logs')->insert([
//             'milestone_history_id' => $history->sno,
//             'service_id' => $history->service_id ?? 0,
//             'customer_remarks' => $history->customer_reject_remarks,
//             'revert_type' => $request->revert_type,
//             'reverted_by' => auth()->user()->user_id,
//             'remarks' => $request->remarks,
//             'created_at' => now(),
//             'updated_at' => now(),
//         ]);

//          $service = DB::table('et_customer_services')
//                     ->where('sno', $request->service_id)
//                     ->first();

//                 $notificationUsers = [];

//                 // PC
//                 if (!empty($service->pc_id)) {
//                     $notificationUsers[] = $service->pc_id;
//                 }

//                 // Production Staff
//                 if (!empty($service->production_staffs_id)) {

//                     $staffs = json_decode($service->production_staffs_id, true);

//                     if (is_array($staffs)) {

//                         $notificationUsers = array_merge(
//                             $notificationUsers,
//                             $staffs
//                         );

//                     }
//                 }

//                 $notificationUsers = array_unique($notificationUsers);
//                 foreach ($notificationUsers as $userId) {

//                     DB::table('et_notifications')->insert([

//                         'user_id'       => $userId,

//                         'title'         => 'Task Reverted',

//                         'message'       => 'Task has been reverted by CRE. Please review and take necessary action.',

//                         'reference_id'  => $history->sno,

//                         'reference_type'=> 'milestone_history',

//                         'is_read'       => 0,

//                         'created_at'    => now(),

//                         'updated_at'    => now()

//                     ]);

//                 }
//         DB::commit();
       
//         return response()->json([
//             'status'=>200,
//             'message'=>'Task reverted successfully.'
//         ]);

//     } catch (\Exception $e){

//         DB::rollBack();

//         return response()->json([
//             'status'=>500,
//             'message'=>$e->getMessage()
//         ]);
//     }
// }

public function revertTaskProduction(Request $request)
{
    DB::beginTransaction();
 
    try {
        $history = DB::table('et_milestone_history')
            ->where('sno', $request->history_id)
            ->first();
        if($request->action_type == 'resolved')
        {
            // return $request->history_id;
            $oldCustomerResponse = $history->customer_response;
            $oldIssueResolved = $history->customer_issue_resolved;
           $affectedRows =  DB::table('et_milestone_history')
                ->where('sno',$request->history_id)
                ->update([
 
                    'customer_issue_resolved' => 1,
                    'customer_issue_resolved_by' => auth()->user()->user_id,
                    'customer_issue_resolved_date' => now(),
                    'customer_issue_resolution_remarks'
                        => $request->resolution_remarks,
 
                    'customer_response' => 0,
                    'customer_ack_status' => 0,
                    'customer_ack_date' => null,
                    'customer_ack_ip' => null,
 
                    'updated_at' => now()
                ]);
                $helper = new \App\Helpers\Helpers();
 
                $helper->createProductionLog([
 
                    'service_id' => $request->service_id,
 
                    'milestone_id' => $history->milestone_id,
 
                    'milestone_history_id' => $history->sno,
 
                    'action_type' => 'customer_issue_resolved',
 
                    'old_value' => [
 
                        'customer_response' => $oldCustomerResponse,
                        'customer_issue_resolved' => $oldIssueResolved,
                    ],
 
                    'new_value' => [
 
                        'customer_response' => 0,
                        'customer_issue_resolved' => 1,
 
                    ],
 
                    'remarks' => $request->resolution_remarks,
 
                    'performed_by' => auth()->user()->user_id,
 
                ]);
                $service = DB::table('et_customer_services')
                    ->where('sno', $request->service_id)
                    ->first();
 
                $notificationUsers = [];
 
                // PC
                if (!empty($service->pc_id)) {
                    $notificationUsers[] = $service->pc_id;
                }
 
                // Production Staff
                if (!empty($service->production_staffs_id)) {
 
                    $staffs = json_decode($service->production_staffs_id, true);
 
                    if (is_array($staffs)) {
 
                        $notificationUsers = array_merge(
                            $notificationUsers,
                            $staffs
                        );
 
                    }
                }
 
                $notificationUsers = array_unique($notificationUsers);
                foreach ($notificationUsers as $userId) {
 
                    DB::table('et_notifications')->insert([
 
                        'user_id'       => $userId,
 
                        'title'         => 'Task Reverted',
 
                        'message'       => 'Task has been reverted by CRE. Please review and take necessary action.',
 
                        'reference_id'  => $history->sno,
 
                        'reference_type'=> 'milestone_history',
 
                        'is_read'       => 0,
 
                        'created_at'    => now(),
 
                        'updated_at'    => now()
 
                    ]);
 
                }
                DB::commit();
            if ($affectedRows > 0) {
                return response()->json([
                'status'=>200,
                'message'=>'Issue resolved successfully.'
            ]);
            }
            else{
                 return response()->json([
                'status'=>400,
                'message'=>'Issue resolve failed.'
            ]);
            }
        }
        $oldStatus = $history->status;
        $oldRevertType = $history->revert_type;
        $request->validate([
            'history_id' => 'required',
            'remarks' => 'required',
            'revert_type' => 'required|in:1,2'
        ]);
        $history = DB::table('et_milestone_history')
            ->where('sno',$request->history_id)
            ->first();
 
        if(!$history){
            return response()->json([
                'status'=>404,
                'message'=>'Task not found'
            ]);
        }
$status = $request->revert_type == 1
            ? 8 // Correction
            : 9; // Update Required
        DB::table('et_milestone_history')
            ->where('sno',$request->history_id)
            ->update([
                'status' => $status,
                'revert_type' => $request->revert_type,
                'reverted_to_production' => 1,
                'reverted_by' => auth()->user()->user_id,
                'reverted_date' => now(),
                'reverted_remarks' => $request->remarks,
                'customer_response' => 0,
                'customer_ack_status' => 0,
                'customer_ack_date' => null,
                'customer_ack_ip' => null,
                'updated_at' => now(),
                'target_completion_date' => $request->target_completion_date ?? '',
                'target_completion_by'=> auth()->user()->user_id,
                'correction_tracking' => 1,
            ]);
 
            $helper = new \App\Helpers\Helpers();
 
            $helper->createProductionLog([
 
                'service_id' => $request->service_id,
 
                'milestone_id' => $history->milestone_id,
 
                'milestone_history_id' => $history->sno,
 
                'action_type' => $request->revert_type == 1
                    ? 'customer_correction'
                    : 'customer_update_required',
 
                'old_value' => [
 
                    'status' => $oldStatus,
                    'revert_type' => $oldRevertType,
                    'target_completion_date' => $history->target_completion_date
 
                ],
 
                'new_value' => [
 
                    'status' => $status,
                    'revert_type' => $request->revert_type,
                    'target_completion_date' => $history->target_completion_date
 
                ],
 
                'remarks' => $request->remarks,
 
                'performed_by' => auth()->user()->user_id,
 
            ]);
        DB::table('et_task_revert_logs')->insert([
            'milestone_history_id' => $history->sno,
            'service_id' => $history->service_id ?? 0,
            'customer_remarks' => $history->customer_reject_remarks,
            'revert_type' => $request->revert_type,
            'reverted_by' => auth()->user()->user_id,
            'remarks' => $request->remarks,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
 
         $service = DB::table('et_customer_services')
                    ->where('sno', $request->service_id)
                    ->first();
 
                $notificationUsers = [];
 
                // PC
                if (!empty($service->pc_id)) {
                    $notificationUsers[] = $service->pc_id;
                }
 
                // Production Staff
                if (!empty($service->production_staffs_id)) {
 
                    $staffs = json_decode($service->production_staffs_id, true);
 
                    if (is_array($staffs)) {
 
                        $notificationUsers = array_merge(
                            $notificationUsers,
                            $staffs
                        );
 
                    }
                }
 
                $notificationUsers = array_unique($notificationUsers);
                foreach ($notificationUsers as $userId) {
 
                    DB::table('et_notifications')->insert([
 
                        'user_id'       => $userId,
 
                        'title'         => 'Task Reverted',
 
                        'message'       => 'Task has been reverted by CRE. Please review and take necessary action.',
 
                        'reference_id'  => $history->sno,
 
                        'reference_type'=> 'milestone_history',
 
                        'is_read'       => 0,
 
                        'created_at'    => now(),
 
                        'updated_at'    => now()
 
                    ]);
 
                }
        DB::commit();
        return response()->json([
            'status'=>200,
            'message'=>'Task reverted successfully.'
        ]);
 
    } catch (\Exception $e){
 
        DB::rollBack();
 
        return response()->json([
            'status'=>500,
            'message'=>$e->getMessage()
        ]);
    }
}

//  public function sendTaskAckMessage(Request $request)
//     {
//     try{
//     // Validate the incoming request data
//       $validator = Validator::make($request->all(), [
//         'proposal_id' => 'required', 
//         'email'    => 'boolean',
//         'sms'     => 'boolean',
//         'whatsapp' => 'boolean'
//       ]);
//       // If validation fails, return a response with errors
//       if ($validator->fails()) {
//         return response([
//           'status'    => 401,
//           'message'   => 'Incorrect format input fields',
//           'error_msg' => $validator->messages()->get('*'),
//           'data'      => null,
//         ], 200);
//       }
//       $history = DB::table('et_milestone_history')
//     ->where('sno', $request->history_id)
//     ->first();

//  $taskData = DB::table('et_product_task')
//         ->where('sno', $history->task_id)
//         ->first();
//       $proposal_id = $request -> proposal_id;
//       $service_id  = $request -> service_id;
//       $customer_id = $request -> customer_id;
//       $branch_id = $request->user()->branch_id;
//       $entity_id = $request->user()->entity_id;
//       $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
//       $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

//       $branch_name = " ";
//       if ($branchData->branch_type == 1) {
//         $branch_name = $branchData->branch_name;
//       } elseif ($branchData->branch_type == 2) {
//         $branch_name = $branchData->franchise_name;
//       }

     
//       $customer_id  = $request->customer_id;
//       $old_customer_check  = $request->old_customer_check;

    

//     $proposal =DB::table('et_proposal')
//              ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
//              ->where('et_proposal.sno',$proposal_id)
//               ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
//               ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
//               ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
//               ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
//               ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//              ->where('et_proposal.status','!=',2)
//              ->where('et_lead.status','!=',2)
//              ->orderBy('et_proposal.sno', 'desc')
//              ->first();
//             if($proposal){
//                 if($proposal->post_sale_check==1){
//                     $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
//                     $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
//                     $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
//                 }
//             }
//          $proposal_id  = $proposal->sno;
//       $customer=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
//       // Extract the validated data
//       $lead_id=$proposal->lead_id ?? 0;
//       $email     = $request->email;
//       $sms      = $request->sms;
//       $whatsapp = $request->whatsapp;
//       $message  = $request->message;
//       $user_id  = $request->user()->user_id;


//       // return $request;
//       // Find the lead based on lead_id
//       $lead = LeadModel::where('sno', $lead_id)
//         ->first();

//       // If the lead is not found, return an error response
//       if (!$lead) {
//         return response([
//           'status'    => 404,
//           'message'   => 'Lead not found',
//           'error_msg' => 'The lead with the given ID does not exist',
//           'data'      => null,
//         ], 200);
//       }
      
      

//       $helper = new \App\Helpers\Helpers();
//       $encrypted_values = $helper->encrypt_decrypt($history->sno,'encrypt');
//   $ReceiptLink ='https://erp.elysiumtechnologies.com/task_acknowledge/'.$encrypted_values;
      
//          //  communication Receipt
//          $communicationStatus=DB::table('et_communication_handle')->where('module_name','NDA Send')->first();
//          $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
//         //  return $communicationStatus;

//         $response = [ 'email' => false, 'sms' => false, 'whatsapp' => false, 'errors' => [] ];
//         if($communicationStatus && $communicationStatus->status == 0){
     
//               // Receipt Communication 
              
//                   $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                  
//                       $lead_name =$lead->lead_name;
//                       $lead_email_id =$lead->lead_email_id;
//                       $lead_mobile =$lead->lead_mobile;
                  
//                         $TargetCurrency = $proposal->currency_code ?? 'INR';
//                         $endpoint = 'convert';
//                         $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                
//                         $helper = new \App\Helpers\Helpers();
//                         //   if ($TargetCurrency !== 'INR') {
//                         //     $response= $helper->convertFromINR($TargetCurrency);   
//                         //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
//                         //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
//                         //     $converted_amount = ($exchange_quote != 0) ? $slots->paidAmount * $exchange_quote : 0;
//                         //   }else{
//                         //     $converted_amount =$slots->paidAmount;
//                         //   }
//               $exchange_quote=1;
                          
//                          $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
//                          $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
//                           $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;
                       
                          
//                       // sms Receipt send
//                       if($communicationStatus->sms ==0){
//                         try {
//                             if ($sms == 1) {
            
//                               $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
//                               $authkey = $result_sms ? $result_sms->authkey : '';
//                               $sender_id = $result_sms ? $result_sms->sender_id : '';
//                               $template_id = $result_sms ? $result_sms->template_id : '';
//                               $country_code = $result_sms ? $result_sms->country_code : '';
//                               $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
//                               $mobile_number = $country_code . $lead_mobile;
                    
                             
                           
                    
//                               // Replace placeholders with actual values
//                               $replacement_values = [$lead_name,$cre_mobile];
//                               $message_content = preg_replace_callback(
//                                 '/\{#var#\}/',
//                                 function () use (&$replacement_values) {
//                                   return array_shift($replacement_values);
//                                 },
//                                 $message_content
//                               );
                    
//                               $route = "default";
//                               $postData = array(
//                                 'authkey' => $authkey,
//                                 'mobiles' => $mobile_number,
//                                 'message' => $message_content,
//                                 'sender' => $sender_id,
//                                 'route' => $route,
//                               );
                    
//                               // API URL
//                               $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                    
//                               // Initialize the resource
//                               $ch = curl_init();
//                               curl_setopt_array($ch, array(
//                                 CURLOPT_URL => $url,
//                                 CURLOPT_RETURNTRANSFER => true,
//                                 CURLOPT_POST => true,
//                                 CURLOPT_POSTFIELDS => $postData,
//                                 CURLOPT_SSL_VERIFYHOST => 0,
//                                 CURLOPT_SSL_VERIFYPEER => 0,
//                               ));
                    
//                               // Get response
//                               $response = curl_exec($ch);
//                               // return $response;
//                               $err = curl_error($ch);
//                               curl_close($ch);
//                               $response['sms'] = true;
//                             }
//                             } catch (\Exception $e) { $response['errors'][] = 'SMS : '.$e->getMessage(); }

//                     }
                    
//                     // Email Receipt Send
//                       if($communicationStatus->email ==0){ 
//                           if ($email == 1) {
//                         if ($lead_email_id) {
//                             $emailTemplate_id =13; // proposal send Template Id
//                             $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
//                             // Gender condition
//                             $genderPrefix = 'Mr/Ms'; // Default value
//                             if ($lead->lead_gender == 1) {
//                               $genderPrefix = 'Mr';
//                             } elseif ($lead->lead_gender == 2) {
//                               $genderPrefix = 'Ms';
//                             }
                        
                      
           
                      
//                         $content = $emailTemplate->email_subject;
                
//                         $dynamicSubject = str_replace('#entity_name',   'Elysium Technology Acknowledgement for Product Delivery', $emailTemplate->email_name);
                
//                         $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
//                         $content = str_replace('#link',$customer ? $ReceiptLink : "phdizone.com", $content);
                    
//                         $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
//                         $content = str_replace('#task_name', $taskData->task_name ?? '', $content);
//                         $content = str_replace('#task_date', now()->format('F j, Y') ?? '', $content);
//                         $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
//                         $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
//                         $content = str_replace('#customer_care',  $cre_mobile ?? '8220011465', $content);
//                         $branchNo = $branch->mobile;
//                         $branchemail = $branch->mail;
//                         $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
//                         $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
//                         $url= 'phdizone.com';
                
//                         $mailData = [
//                               'url'         => $url,
//                               'subject'     => "Elysium Technology Acknowledge for Product Delivery",
//                               'content'     => $content,
//                               'branchNo'    => $branchNo,
//                               'branchemail' => $branchemail, // Use the message content from the request
//                               'fbLink'      => $fbLink,      // Use the message content from the request
//                               'instaLink'   => $instaLink,   // Use the message content from the request
//                               'salesMobile' => $cre_mobile ?? '8220011465'
//                           ];
//                         $from_address = 'elysiumtechnology@elysium.community';
//                         $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
//                 try { 
//                     if ($request->email == 1) {
//                         Mail::to($customer->cus_email_id)->send(new ETPLMail($mailData, $from_address, $from_name));
//                                     $response['email'] = true;
//                                 }
//                             } catch (\Exception $e) {
//                                 $response['errors'][] = 'Email : ' . $e->getMessage();
//                             }
//                      }
//                           }
//                       }
                      
//                     //  Whatsapp Receipt Send
//                       if($communicationStatus->whatsapp ==0){
//                           try {
//                           if ($whatsapp == 1) {
//                                 if ($lead_mobile) {
                          
                           
//                                 // $templateName  = "hello_world";
//                                 $templateName  = "payment_recept_phdizone";
                
//                                 $hasHeader  = false; // Example flag: set based on template
//                                 $hasBody    = false; // Example flag: set based on template
//                                 $hasFooter  = false; // Example flag: set based on template
//                                 $hasButton  = false;
//                                 $components = [];
//                                 $couponCode = " ";
//                                 date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
//                                 $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
//                                                                           // $currentHour = date('H'); // Get current hour in 24-hour format
//                                 if ($currentHour >= 5 && $currentHour < 12) {
//                                     $greeting = 'Good Morning';
//                                 } elseif ($currentHour >= 12 && $currentHour < 18) {
//                                     $greeting = 'Good Afternoon';
//                                 } else {
//                                     $greeting = 'Good Evening';
//                                 }
                
//                                 if ($templateName == 'payment_recept_phdizone') {
//                                     $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
//                                     $couponCode  = 'NOOFFER';
//                                     $buttonIndex = 1;
//                                     $bodyText    = [
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $customer ? $customer->cus_name : $lead_name,
//                                             'parameter_name' => 'customer_name',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $paymentData->payment_id ?? '',
//                                             'parameter_name' => 'recept_number',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $transaction_date ?? date('d-M-Y'),
//                                             'parameter_name' => 'payment_date',
//                                         ],
//                                          [
//                                             'type'           => 'text',
//                                             'text'           => $slotAmount ?? '',
//                                             'parameter_name' => 'payment',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $proposal->service_title ?? '',
//                                             'parameter_name' => 'service_name',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $slot_url_key_receipt?? "",
//                                             'parameter_name' => 'link_key',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $cre_mobile ?? '8220011465',
//                                             'parameter_name' => 'cre_number',
//                                         ],
//                                     ];
//                                     $hasHeader = true;
//                                     $hasBody   = true;
//                                     $hasButton = true;
//                                 }
                
//                                 // Add Header if required
//                                 if ($hasHeader) {
//                                     $components[] = [
//                                         'type'       => 'header',
//                                         'parameters' => [
//                                             [
//                                                 'type'  => 'image',
//                                                 'image' => [
//                                                     'link' => $headerImage, // Dynamically set header image
//                                                 ],
//                                             ],
//                                         ],
//                                     ];
//                                 }
                
//                                 // Add Body if required
//                                 if ($hasBody) {
//                                     $components[] = [
//                                         'type'       => 'body',
//                                         'parameters' => $bodyText,
//                                     ];
//                                 }
                
//                                 // Add Footer if required
//                                 if ($hasButton) {
//                                     $components[] = [
//                                         'type'       => 'button',
//                                         'sub_type'   => 'url',
//                                         'index'      => 0,
//                                         'parameters' => [
//                                             [
//                                                 'type' => 'text',
//                                                 'text' => $slot_url_key_receipt ?? "",
//                                             ],
//                                         ],
//                                     ];
//                                 }
                                
                                
//                                 $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
//                                 $dynamicParameters         = $templateParameters[$templateName] ?? [];
//                                 $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
//                                 $accessToken               = $whatsappApi->access_tokken ?? '';
//                                 $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
//                                 $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
//                                 $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
//                                 $to           = $lead_mobile;
//                                 $languageCode = 'en';
                    
//                                 if (strpos($to, $countryCode) !== 0) {
//                                     $to = $countryCode . $to;
//                                 }
                
//                                 $message = 'test~message';
//                                 if (empty($components)) {
//                                     $payload = [
//                                         'messaging_product' => 'whatsapp',
//                                         'to'                => $to,
//                                         'type'              => 'template',
//                                         'template'          => [
//                                             'name'     => $templateName,
//                                             'language' => [
//                                                 'code' => $languageCode,
//                                             ],
//                                         ],
//                                     ];
//                                 } else {
//                                     $payload = [
//                                         'messaging_product' => 'whatsapp',
//                                         'to'                => $to,
//                                         'type'              => 'template',
//                                         'template'          => [
//                                             'name'       => $templateName,
//                                             'language'   => [
//                                                 'code' => $languageCode,
//                                             ],
//                                             'components' => $components,
//                                         ],
//                                     ];
//                                 }
                
//                                 $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                
                               
//                              if ($response['status'] == 200) {}
//                              else{
//                                  return response([
//                                       'status' => 404,
//                                       'message' => 'Failed to send message',
//                                       'error_msg' => $response['error'],
//                                     ], 400);
//                                 }
                            
//                       }
//                       $response['whatsapp'] = true;
//                           }
//                           } catch (\Exception $e) { $response['errors'][] = 'Whatsapp : '.$e->getMessage(); }
//                       }
                    
                 
                      
//         }else{
//             return $communicationStatus;
//         }
//       // If the operation was successful, return a success response
//      $successCount =
//         collect($response)
//             ->only(['email','sms','whatsapp'])
//             ->filter()
//             ->count();

//     if ($successCount == 0) {

//         return response()->json([
//             'status' => 500,
//             'message' => 'No communication was sent.',
//             'data' => $response
//         ]);
//     }

//     if (count($response['errors']) > 0) {

//         return response()->json([
//             'status' => 207,
//             'message' => 'Partially sent.',
//             'data' => $response
//         ]);
//     }
//     $helper = new \App\Helpers\Helpers();

//         $helper->createProductionLog([

//             'service_id' => $request->service_id,

//             'milestone_id' => $request->milestone_id,

//             'milestone_history_id' => $request->history_id,

//             'action_type' => 'task_ack_sent',

//             'old_value' => null,

//             'new_value' => [

//                 'email' => (bool)$request->email,

//                 'sms' => (bool)$request->sms,

//                 'whatsapp' => (bool)$request->whatsapp,

//             ],

//             'remarks' => 'Task acknowledgement sent to customer.',

//             'performed_by' => auth()->user()->user_id

//         ]);
//     return response()->json([
//         'status' => 200,
//         'message' => 'All communications sent successfully.',
//         'data' => $response
//     ]);
//       } catch (\Exception $e){

//             DB::rollBack();

//             return response()->json([
//                 'status'=>500,
//                 'message'=>$e->getMessage()
//             ]);
//         }
//     }

public function sendTaskAckMessage(Request $request)
    {
    try{
    // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required', 
        'email'    => 'boolean',
        'sms'     => 'boolean',
        'whatsapp' => 'boolean'
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
      $history = DB::table('et_milestone_history')
    ->where('sno', $request->history_id)
    ->first();

 $taskData = DB::table('et_product_task')
        ->where('sno', $history->task_id)
        ->first();
      $proposal_id = $request -> proposal_id;
      $service_id  = $request -> service_id;
      $customer_id = $request -> customer_id;
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }

     
      $customer_id  = $request->customer_id;
      $old_customer_check  = $request->old_customer_check;

    

    $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
             ->where('et_proposal.sno',$proposal_id)
              ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
              ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
              ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
              ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
              ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->where('et_proposal.status','!=',2)
             ->where('et_lead.status','!=',2)
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
            if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }
         $proposal_id  = $proposal->sno;
      $customer=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
      // Extract the validated data
      $lead_id=$proposal->lead_id ?? 0;
      $email     = $request->email;
      $sms      = $request->sms;
      $whatsapp = $request->whatsapp;
      $message  = $request->message;
      $user_id  = $request->user()->user_id;


      // return $request;
      // Find the lead based on lead_id
      $lead = LeadModel::where('sno', $lead_id)
        ->first();

      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }
      
      

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($history->sno,'encrypt');
  $ReceiptLink ='https://erp.elysiumtechnologies.com/task_acknowledge/'.$encrypted_values;
      
         //  communication Receipt
         $communicationStatus=DB::table('et_communication_handle')->where('module_name','NDA Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
        //  return $communicationStatus;

        $response = [ 'email' => false, 'sms' => false, 'whatsapp' => false, 'errors' => [] ];
        if($communicationStatus && $communicationStatus->status == 0){
     
              // Receipt Communication 
              
                  $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                  
                       $lead_name =$lead->lead_name;
                       $lead_email_id =$customer->cus_email_id ??$lead->lead_email_id;
                       $lead_mobile =$lead->lead_mobile;
                  
                        $TargetCurrency = $proposal->currency_code ?? 'INR';
                        $endpoint = 'convert';
                        $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                
                        $helper = new \App\Helpers\Helpers();
                        //   if ($TargetCurrency !== 'INR') {
                        //     $response= $helper->convertFromINR($TargetCurrency);   
                        //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                        //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                        //     $converted_amount = ($exchange_quote != 0) ? $slots->paidAmount * $exchange_quote : 0;
                        //   }else{
                        //     $converted_amount =$slots->paidAmount;
                        //   }
               $exchange_quote=1;
                          
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                          $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;
                       
                          
                      // sms Receipt send
                      if($communicationStatus->sms ==0){
                        try {
                            if ($sms == 1) {
            
                              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
                              $authkey = $result_sms ? $result_sms->authkey : '';
                              $sender_id = $result_sms ? $result_sms->sender_id : '';
                              $template_id = $result_sms ? $result_sms->template_id : '';
                              $country_code = $result_sms ? $result_sms->country_code : '';
                              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                              $mobile_number = $country_code . $lead_mobile;
                    
                             
                           
                    
                              // Replace placeholders with actual values
                              $replacement_values = [$lead_name,$cre_mobile];
                              $message_content = preg_replace_callback(
                                '/\{#var#\}/',
                                function () use (&$replacement_values) {
                                  return array_shift($replacement_values);
                                },
                                $message_content
                              );
                    
                              $route = "default";
                              $postData = array(
                                'authkey' => $authkey,
                                'mobiles' => $mobile_number,
                                'message' => $message_content,
                                'sender' => $sender_id,
                                'route' => $route,
                              );
                    
                              // API URL
                              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                    
                              // Initialize the resource
                              $ch = curl_init();
                              curl_setopt_array($ch, array(
                                CURLOPT_URL => $url,
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => $postData,
                                CURLOPT_SSL_VERIFYHOST => 0,
                                CURLOPT_SSL_VERIFYPEER => 0,
                              ));
                    
                              // Get response
                              $response = curl_exec($ch);
                              // return $response;
                              $err = curl_error($ch);
                              curl_close($ch);
                              $response['sms'] = true;
                            }
                            } catch (\Exception $e) { $response['errors'][] = 'SMS : '.$e->getMessage(); }

                    }
                    
                    // Email Receipt Send
                      if($communicationStatus->email ==0){ 
                           if ($email == 1) {
                        if ($lead_email_id) {
                            $emailTemplate_id =13; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                        
                      
           
                      
                        $content = $emailTemplate->email_subject;
                
                        $dynamicSubject = str_replace('#entity_name',   'Elysium Technology Acknowledgement for Product Delivery', $emailTemplate->email_name);
                
                        $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                        $content = str_replace('#link',$customer ? $ReceiptLink : "phdizone.com", $content);
                    
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#task_name', $taskData->task_name ?? '', $content);
                        $content = str_replace('#task_date', now()->format('F j, Y') ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
                        $content = str_replace('#customer_care',  $cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
                
                        $mailData = [
                              'url'         => $url,
                              'subject'     => "Elysium Technology Acknowledge for Product Delivery",
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $cre_mobile ?? '8220011465'
                          ];
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                try { 
                    if ($request->email == 1) {
                        Mail::to($customer->cus_email_id)->send(new ETPLMail($mailData, $from_address, $from_name));
                                    $response['email'] = true;
                                }
                            } catch (\Exception $e) {
                                $response['errors'][] = 'Email : ' . $e->getMessage();
                            }
                     }
                           }
                      }
                      
                    //  Whatsapp Receipt Send
                      if($communicationStatus->whatsapp ==0){
                           try {
                          if ($whatsapp == 1) {
                                if ($lead_mobile) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "payment_recept_phdizone";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'payment_recept_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $customer ? $customer->cus_name : $lead_name,
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $paymentData->payment_id ?? '',
                                            'parameter_name' => 'recept_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $transaction_date ?? date('d-M-Y'),
                                            'parameter_name' => 'payment_date',
                                        ],
                                         [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'payment',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key_receipt?? "",
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $cre_mobile ?? '8220011465',
                                            'parameter_name' => 'cre_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key_receipt ?? "",
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                
                               
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
                      $response['whatsapp'] = true;
                          }
                          } catch (\Exception $e) { $response['errors'][] = 'Whatsapp : '.$e->getMessage(); }
                      }
                    
                 
                      
        }else{
            return $communicationStatus;
        }
      // If the operation was successful, return a success response
     $successCount =
        collect($response)
            ->only(['email','sms','whatsapp'])
            ->filter()
            ->count();

    if ($successCount == 0) {

        return response()->json([
            'status' => 500,
            'message' => 'No communication was sent.',
            'data' => $response
        ]);
    }

    if (count($response['errors']) > 0) {

        return response()->json([
            'status' => 207,
            'message' => 'Partially sent.',
            'data' => $response
        ]);
    }
    $helper = new \App\Helpers\Helpers();

        $helper->createProductionLog([

            'service_id' => $request->service_id,

            'milestone_id' => $request->milestone_id,

            'milestone_history_id' => $request->history_id,

            'action_type' => 'task_ack_sent',

            'old_value' => null,

            'new_value' => [

                'email' => (bool)$request->email,

                'sms' => (bool)$request->sms,

                'whatsapp' => (bool)$request->whatsapp,

            ],

            'remarks' => 'Task acknowledgement sent to customer.',

            'performed_by' => auth()->user()->user_id

        ]);
        DB::table('et_milestone_history')
        ->where('sno', $request->history_id)
        ->update([
            'customer_ack_sent' => 1,
            'customer_ack_sent_by' => auth()->user()->user_id,
            'customer_ack_sent_date' => now()
        ]);
    return response()->json([
        'status' => 200,
        'message' => 'All communications sent successfully.',
        'data' => $response
    ]);
      } catch (\Exception $e){

            DB::rollBack();

            return response()->json([
                'status'=>500,
                'message'=>$e->getMessage()
            ]);
        }
    }
    
    
    public function verifyTaskPayment(Request $request)
    {
        DB::beginTransaction();

        try {

            $history = DB::table(
                'et_milestone_history'
            )
            ->where('sno', $request->history_id)
            ->first();

            if (!$history) {

                return response()->json([
                    'status' => 404,
                    'message' => 'Task not found.'
                ]);
            }

            DB::table('et_milestone_history')
                ->where('sno', $request->history_id)
                ->update([

                    'status' => 10,

                    'payment_verified_by'
                        => auth()->user()->user_id,

                    'payment_verified_date'
                        => now(),

                    'updated_at'
                        => now()
                ]);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message'
                    => 'Payment verified successfully.'
            ]);
        }
        catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => $e->getMessage()
            ]);
        }
    }
    public function verifyCreTask(Request $request)
    {
        DB::beginTransaction();

        try{
            $history = DB::table('et_milestone_history')
            ->where('sno', $request->history_id)
            ->first();

        $oldStatus = $history->status ?? 0;

            DB::table('et_milestone_history')
                ->where('sno',$request->history_id)
                ->update([

                    'status'=>10,

                    'updated_at'=>now()

                ]);

    // Service details
    $service = DB::table('et_customer_services')
        ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
        ->where('et_customer_services.sno', $request->service_id)
        ->select(
            'et_customer_services.branch_id',
            'et_customer_services.pc_id',
            'et_customer.cus_name'
        )
        ->first();

    // Task details
    $task = DB::table('et_milestone_history')
        ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_milestone_history.task_id')
        ->where('et_milestone_history.sno', $request->history_id)
        ->select('et_product_task.task_name')
        ->first();

    // CRE Name
    $creName = DB::table('et_staff')
        ->where('sno', auth()->user()->user_id)
        ->value('staff_name');

    if ($service && !empty($service->pc_id)) {

        $notificationData = [

            'branch_id' => $service->branch_id,

            'notification_type' => 'Task',

            'notification_content' => '
            <div class="d-flex align-items-center">

                <div class="me-3">
                    <span class="badge bg-light-success">
                        <i class="mdi mdi-check-decagram-outline fs-3 text-success"></i>
                    </span>
                </div>

                <div>

                    <div class="fs-7 text-success fw-bold">
                        CRE Verified Task
                    </div>

                    <div class="text-secondary fs-8 fw-semibold">
                        '.e($creName).' verified <b>'.e($task->task_name).'</b>.
                        <br>
                        Customer : '.e($service->cus_name).'
                    </div>

                </div>

            </div>
            ',

            'who' => auth()->user()->user_id,

            'whom' => $service->pc_id,

            'created_by' => auth()->user()->user_id,

            'updated_by' => auth()->user()->user_id,

            'status' => 0

        ];

        $notification = new \App\Helpers\Helpers();
        $notification->createNotificationToStaff($notificationData);
        $notification->createProductionLog([

            'service_id' => $request->service_id,

            'milestone_id' => $request->milestone_id,

            'milestone_history_id' => $request->history_id,

            'action_type' => 'cre_verified',

            'old_value' => [
                'status' => $oldStatus
            ],

            'new_value' => [
                'status' => 10
            ],

            'remarks' => 'Task verified by CRE.',

            'performed_by' => auth()->user()->user_id

        ]);
    }
    DB::commit();
            return response()->json([

                'status'=>200,

                'message'=>'Task verified successfully.'

            ]);

        }catch(\Exception $e){

            DB::rollBack();

            return response()->json([

                'status'=>500,

                'message'=>$e->getMessage()

            ]);

        }
    }
    public function rejectCreTask(Request $request)
    {
        DB::beginTransaction();

        try {

            $request->validate([
                'history_id' => 'required',
                'cre_remark' => 'required|string|max:1000'
            ]);
        $history = DB::table('et_milestone_history')
            ->where('sno', $request->history_id)
            ->first();

        $oldStatus = $history->status ?? 0;
            DB::table('et_milestone_history')
                ->where('sno', $request->history_id)
                ->update([
                    'status' => 11,
                    'cre_remark' => $request->cre_remark,
                    'cre_verified_by' => auth()->user()->user_id,
                    'cre_verified_at' => now(),
                    'updated_at' => now()
                ]);

            // Notify PC
            // Notify Document Staff
            // Fetch service details
        $service = DB::table('et_customer_services')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
            ->where('et_customer_services.sno', $request->service_id)
            ->select(
                'et_customer_services.branch_id',
                'et_customer_services.pc_id',
                'et_customer.cus_name'
            )
            ->first();

        // Fetch task details
        $task = DB::table('et_milestone_history')
            ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_milestone_history.task_id')
            ->where('et_milestone_history.sno', $request->history_id)
            ->select(
                'et_product_task.task_name',
                'et_milestone_history.document_staff_id'
            )
            ->first();

        // CRE Name
        $creName = DB::table('et_staff')
            ->where('sno', auth()->user()->user_id)
            ->value('staff_name');

        $notification = new \App\Helpers\Helpers();

        $receivers = array_filter([
            $service->pc_id ?? null,
            $task->document_staff_id ?? null,
        ]);

        foreach (array_unique($receivers) as $receiverId) {

            $notificationData = [

                'branch_id' => $service->branch_id,

                'notification_type' => 'Task',

                'notification_content' => '
                    <div class="d-flex align-items-center">

                        <div class="me-3">
                            <span class="badge bg-light-danger">
                                <i class="mdi mdi-close-circle-outline fs-3 text-danger"></i>
                            </span>
                        </div>

                        <div>

                            <div class="fs-7 text-danger fw-bold">
                                CRE Rejected Task
                            </div>

                            <div class="text-secondary fs-8 fw-semibold">
                                '.e($creName).' rejected <b>'.e($task->task_name).'</b>.
                                <br>
                                Customer : '.e($service->cus_name).'
                                <br>
                                <b>Reason :</b> '.e($request->cre_remark).'
                            </div>

                        </div>

                    </div>
                ',

                'who' => auth()->user()->user_id,

                'whom' => $receiverId,

                'created_by' => auth()->user()->user_id,

                'updated_by' => auth()->user()->user_id,

                'status' => 0

            ];

            $notification->createNotificationToStaff($notificationData);
        }
        $notification->createProductionLog([

            'service_id' => $request->service_id,

            'milestone_id' => $request->milestone_id,

            'milestone_history_id' => $request->history_id,

            'action_type' => 'cre_rejected',

            'old_value' => [

                'status' => $oldStatus

            ],

            'new_value' => [

                'status' => 11

            ],

            'remarks' => $request->cre_remark,

            'performed_by' => auth()->user()->user_id

        ]);
            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Task rejected successfully.'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ],500);
        }
    }
    public function taskHistory($historyId)
    {
        $helper = new \App\Helpers\Helpers();
        $logs = DB::table('et_production_logs')
            ->leftJoin('et_staff','et_staff.sno','=','et_production_logs.performed_by')
            ->where('milestone_history_id',$historyId)
            ->select(
                'et_production_logs.*',
                'et_staff.staff_name'
            )
            ->orderByDesc('created_at')
            ->get();
            foreach ($logs as $log) {

            $log->old_value = json_decode($log->old_value, true);
            $log->new_value = json_decode($log->new_value, true);

            // Staff actions
            if (in_array($log->action_type, [
                'assign_staff',
                'change_staff',
                'assign_document_staff',
                'change_document_staff'
            ])) {

                $oldStaffId = $log->old_value['document_staff'] ?? null;
                $newStaffId = $log->new_value['document_staff'] ?? null;

                $log->old_staff = $oldStaffId
                    ? DB::table('et_staff')
                        ->select('staff_name','staff_image')
                        ->where('sno',$oldStaffId)
                        ->first()
                    : null;

                $log->new_staff = $newStaffId
                    ? DB::table('et_staff')
                        ->select('staff_name','staff_image')
                        ->where('sno',$newStaffId)
                        ->first()
                    : null;
            }
        }
    $statusActions = [
    'task_uploaded',
    'task_completed_without_document',
    'qc_verified',
    'qc_rejected',
    'cre_verified',
    'cre_rejected',
    'customer_accepted',
    'customer_changes_requested',
    'customer_issue_resolved'
];

    foreach ($logs as $log){

        if(in_array($log->action_type,$statusActions)){

            $oldStatus = $log->old_value['status'] ?? null;
            $newStatus = $log->new_value['status'] ?? null;

            $log->old_status = $helper->productionStatusBadge($oldStatus);
            $log->new_status = $helper->productionStatusBadge($newStatus);

        }

    }
        return response()->json([
            'status' => true,
            'logs' => $logs
        ]);
    }
    
        //bibliography
   public function authorBiography($id)
{
    $helper = new \App\Helpers\Helpers();

    $serviceId = $helper->encrypt_decrypt($id, 'decrypt');

    if (!$serviceId) {
        abort(404);
    }
    $alreadySubmitted = DB::table('et_author_biography')
    ->where('service_id', $serviceId)
    ->where('status', 0)
    ->exists();
    $service = DB::table('et_customer_services as cs')

        ->join(
            'et_customer as c',
            'c.sno',
            '=',
            'cs.customer_id'
        )

        ->leftJoin(
            'et_product as p',
            'p.sno',
            '=',
            'cs.product_id'
        )

        ->select(
            'cs.*',
            'c.cus_name',
            'c.customer_id',
            'c.cus_email_id',
            'c.cus_mobile',
            'c.sno as customer_sno',
            'p.product_name as service_name'
        )

        ->where('cs.sno', $serviceId)

        ->first();

    if (!$service) {
        abort(404);
    }

    return view(
        'content.production_management.manage_deliverables.author_biography',
        compact('service', 'alreadySubmitted')
    );
}

    //  public function saveAuthorBiography(Request $request)
    // {
    //     $request->validate([
 
    //         'service_id' => 'required|exists:et_customer_services,sno',
 
    //         'customer_id' => 'required',
 
    //         'corresponding_name' => 'required',
 
    //         'corresponding_bio' => 'required',
 
    //         'corresponding_photo' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
 
    //         'co_name' => 'nullable|array',
    //         'co_name.*' => 'nullable|string|max:255',
 
    //         'co_bio' => 'nullable|array',
    //         'co_bio.*' => 'nullable|string',
 
    //         'co_photo' => 'nullable|array',
    //         'co_photo.*' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
 
    //         'manuscript_file' => 'required|file|mimes:doc,docx,pdf|max:20480',
 
    //     ]);
 
    //     DB::beginTransaction();
 
    //     try {
 
    //         /*
    //         |--------------------------------------------------------------------------
    //         | Save Master
    //         |--------------------------------------------------------------------------
    //         */
 
           
    //     $manuscript = null;
 
    //     if($request->hasFile('manuscript_file')){
 
    //         $file = $request->file('manuscript_file');
 
    //         $manuscript = time().'_'.$file->getClientOriginalName();
 
    //         $file->move(public_path('manuscripts'), $manuscript);
 
    //     }
 
    //         $biographyId = DB::table('et_author_biography')
    //             ->insertGetId([
 
    //                 'service_id' => $request->service_id,
 
    //                 'customer_id' => $request->customer_id,
 
    //                 'created_by' => 0,
    //                 'manuscript_file'=>$manuscript,
 
    //                 'created_at' => now(),
 
    //                 'updated_at' => now(),
 
    //                 'status' => 0
 
    //             ]);
 
    //         /*
    //         |--------------------------------------------------------------------------
    //         | Corresponding Photo
    //         |--------------------------------------------------------------------------
    //         */
 
    //         $correspondingPhoto = null;
 
    //         if($request->hasFile('corresponding_photo')){
 
    //             $file = $request->file('corresponding_photo');
 
    //             $correspondingPhoto =
    //                 time().'_corresponding.'.$file->getClientOriginalExtension();
 
    //             $file->move(
    //                 public_path('author_biography'),
    //                 $correspondingPhoto
    //             );
 
    //         }
 
    //         /*
    //         |--------------------------------------------------------------------------
    //         | Save Corresponding Author
    //         |--------------------------------------------------------------------------
    //         */
 
    //         DB::table('et_author_biography_members')
    //             ->insert([
 
    //                 'biography_id' => $biographyId,
 
    //                 'author_type' => 1,
 
    //                 'author_name' => $request->corresponding_name,
 
    //                 'biography' => $request->corresponding_bio,
 
    //                 'photo' => $correspondingPhoto,
 
    //                 'created_at' => now(),
 
    //                 'updated_at' => now(),
 
    //                 'status' => 0
 
    //             ]);
 
    //         /*
    //         |--------------------------------------------------------------------------
    //         | Save Co Authors
    //         |--------------------------------------------------------------------------
    //         */
    //         if(!empty($request->co_name)){
 
    //             $coNames = $request->co_name ?? [];
    //             $coBios = $request->co_bio ?? [];
    //             $coPhotos = $request->file('co_photo') ?? [];
 
    //             foreach($coNames as $index => $name){
 
    //                 if(empty(trim($name))){
    //                     continue;
    //                 }
 
    //                 $coPhoto = null;
 
    //                 if(isset($coPhotos[$index])){
 
    //                     $file = $coPhotos[$index];
 
    //                     $coPhoto =
    //                         time().'_'.$index.'_co.'.
    //                         $file->getClientOriginalExtension();
 
    //                     $file->move(
    //                         public_path('author_biography'),
    //                         $coPhoto
    //                     );
    //                 }
 
    //                 DB::table('et_author_biography_members')
    //                     ->insert([
 
    //                         'biography_id' => $biographyId,
 
    //                         'author_type' => 2,
 
    //                         'author_name' => $name,
 
    //                         'biography' => $coBios[$index] ?? null,
 
    //                         'photo' => $coPhoto,
 
    //                         'created_at' => now(),
 
    //                         'updated_at' => now(),
 
    //                         'status' => 0
 
    //                     ]);
    //             }
    //         }
    //         DB::commit();
 
    //         return response()->json([
 
    //             'status' => 200,
 
    //             'message' => 'Author biography submitted successfully.'
 
    //         ]);
 
    //     } catch (\Exception $e) {
 
    //         DB::rollBack();
 
    //         return response()->json([
 
    //             'status' => 500,
 
    //             'message' => $e->getMessage()
 
    //         ],500);
 
    //     }
 
    // }
    
      public function saveAuthorBiography(Request $request)
    {
        $request->validate([
 
            'service_id' => 'required|exists:et_customer_services,sno',
 
            'customer_id' => 'required',
            'proposal_id' => 'required',
 
            'corresponding_name' => 'required',
 
            'corresponding_bio' => 'required',
 
            'corresponding_photo' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
 
            'co_name' => 'nullable|array',
            'co_name.*' => 'nullable|string|max:255',
 
            'co_bio' => 'nullable|array',
            'co_bio.*' => 'nullable|string',
 
            'co_photo' => 'nullable|array',
            'co_photo.*' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
 
            'manuscript_file' => 'required|file|mimes:doc,docx,pdf|max:20480',
 
        ]);
 
        DB::beginTransaction();
 
        try {
 
            /*
            |--------------------------------------------------------------------------
            | Save Master
            |--------------------------------------------------------------------------
            */
 
           
        $manuscript = null;
 
        if($request->hasFile('manuscript_file')){
 
            $file = $request->file('manuscript_file');
 
            $manuscript = time().'_'.$file->getClientOriginalName();
 
            $file->move(public_path('manuscripts'), $manuscript);
 
        }
 
            $biographyId = DB::table('et_author_biography')
                ->insertGetId([
 
                    'service_id' => $request->service_id,
 
                    'customer_id' => $request->customer_id,
 
                    'created_by' => 0,
                    'manuscript_file'=>$manuscript,
 
                    'created_at' => now(),
 
                    'updated_at' => now(),
 
                    'status' => 0
 
                ]);
 
            /*
            |--------------------------------------------------------------------------
            | Corresponding Photo
            |--------------------------------------------------------------------------
            */
 
            $correspondingPhoto = null;
 
            if($request->hasFile('corresponding_photo')){
 
                $file = $request->file('corresponding_photo');
 
                $correspondingPhoto =
                    time().'_corresponding.'.$file->getClientOriginalExtension();
 
                $file->move(
                    public_path('author_biography'),
                    $correspondingPhoto
                );
 
            }
 
            /*
            |--------------------------------------------------------------------------
            | Save Corresponding Author
            |--------------------------------------------------------------------------
            */
 
            DB::table('et_author_biography_members')
                ->insert([
 
                    'biography_id' => $biographyId,
 
                    'author_type' => 1,
 
                    'author_name' => $request->corresponding_name,
 
                    'biography' => $request->corresponding_bio,
 
                    'photo' => $correspondingPhoto,
 
                    'created_at' => now(),
 
                    'updated_at' => now(),
 
                    'status' => 0
 
                ]);
 
            /*
            |--------------------------------------------------------------------------
            | Save Co Authors
            |--------------------------------------------------------------------------
            */
            if(!empty($request->co_name)){
 
                $coNames = $request->co_name ?? [];
                $coBios = $request->co_bio ?? [];
                $coPhotos = $request->file('co_photo') ?? [];
 
                foreach($coNames as $index => $name){
 
                    if(empty(trim($name))){
                        continue;
                    }
 
                    $coPhoto = null;
 
                    if(isset($coPhotos[$index])){
 
                        $file = $coPhotos[$index];
 
                        $coPhoto =
                            time().'_'.$index.'_co.'.
                            $file->getClientOriginalExtension();
 
                        $file->move(
                            public_path('author_biography'),
                            $coPhoto
                        );
                    }
 
                    DB::table('et_author_biography_members')
                        ->insert([
 
                            'biography_id' => $biographyId,
 
                            'author_type' => 2,
 
                            'author_name' => $name,
 
                            'biography' => $coBios[$index] ?? null,
 
                            'photo' => $coPhoto,
 
                            'created_at' => now(),
 
                            'updated_at' => now(),
 
                            'status' => 0
 
                        ]);
                }
            }
            /*
            |--------------------------------------------------------------------------
            | Save passlocker
            |--------------------------------------------------------------------------
            */
            $customer_id=$request->customer_id;
            $proposal_id=$request->proposal_id;
            if(!empty($request->email)){
 
                $pass_link = $request->link ?? [];
                $pass_email = $request->email ?? [];
                $pass_password = $request->password ?? [];
 
                foreach($pass_email as $index => $name){
 
                    if(empty(trim($name))){
                        continue;
                    }
 
                   
 
                    DB::table('et_biography_pass_locker')
                        ->insert([
 
                            'email_id' => $name,
 
                            'password' => $pass_password[$index],
 
                            'link' => $pass_link[$index],
 
                            'customer_id' => $customer_id,
 
                            'proposal_id' => $proposal_id,
 
                            'created_at' => now(),
 
                            'updated_at' => now(),
 
                            'created_by' => $customer_id,
 
                            'updated_by' => $customer_id,
 
                            'status' => 0
 
                        ]);
                }
            }
            DB::commit();
 
            return response()->json([
 
                'status' => 200,
 
                'message' => 'Author biography submitted successfully.'
 
            ]);
 
        } catch (\Exception $e) {
 
            DB::rollBack();
 
            return response()->json([
 
                'status' => 500,
 
                'message' => $e->getMessage()
 
            ],500);
 
        }
 
    }
    
    public function viewAuthorBiography($id)
    {
        $helper = new \App\Helpers\Helpers();

        $serviceId = $helper->encrypt_decrypt($id,'decrypt');

        $biography = DB::table('et_author_biography as ab')

            ->join(
                'et_customer_services as cs',
                'cs.sno',
                '=',
                'ab.service_id'
            )

            ->join(
                'et_customer as c',
                'c.sno',
                '=',
                'ab.customer_id'
            )

            ->leftJoin(
                'et_product as p',
                'p.sno',
                '=',
                'cs.product_id'
            )

            ->select(
                'ab.*',
                'c.cus_name',
                'c.customer_id',
                'p.product_name'
            )

            ->where('ab.service_id',$serviceId)

            ->first();

        if(!$biography){
            abort(404);
        }

        $authors = DB::table('et_author_biography_members')

            ->where('biography_id',$biography->sno)

            ->where('status',0)

            ->orderBy('author_type')

            ->get();

        return view(
            'content.production_management.manage_deliverables.view_author_biography',
            compact(
                'biography',
                'authors'
            )
        );
    }

    //send bibligraphy message
     public function sendAuthorBiographyLink(Request $request)
    {
            try{
            // Validate the incoming request data
            $validator = Validator::make($request->all(), [
                'service_id' => 'required', 
                'email'    => 'boolean',
                'sms'     => 'boolean',
                'whatsapp' => 'boolean'
            ]);
            // If validation fails, return a response with errors
            if ($validator->fails()) {
                return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
                ], 200);
            }
            $helper = new \App\Helpers\Helpers();

            $service = DB::table('et_customer_services as cs')

                ->join('et_customer as c', 'c.sno', '=', 'cs.customer_id')

                ->select(
                    'cs.sno',
                    'cs.proposal_id',
                    'c.cus_name',
                    'c.cus_email_id',
                    'c.cus_mobile',
                    'cs.customer_id'
                )

                ->where('cs.sno', $request->service_id)

                ->first();

            if (!$service) {

                return response()->json([
                    'status' => 404,
                    'message' => 'Service not found.'
                ]);

            }
            $proposal =DB::table('et_proposal')
                    ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                    ->where('et_proposal.sno',$service->proposal_id)
                    ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                    ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                    ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                    ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->where('et_proposal.status','!=',2)
                    ->where('et_lead.status','!=',2)
                    ->orderBy('et_proposal.sno', 'desc')
                    ->first();
                    if($proposal){
                        if($proposal->post_sale_check==1){
                            $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                            $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                            $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                        }
                    }
                $proposal_id  = $proposal->sno;
            $customer=DB::table('et_customer')->where('et_customer.sno',$service->customer_id)->first();
            // Extract the validated data
            $lead_id=$proposal->lead_id ?? 0;
            $email     = $request->send_email;
            $sms      = $request->send_sms;
            $whatsapp = $request->send_whatsapp;
            $message  = $request->message;
            $user_id  = $request->user()->user_id;


            // return $request;
            // Find the lead based on lead_id
            $lead = LeadModel::where('sno', $lead_id)
                ->first();

            // If the lead is not found, return an error response
            if (!$lead) {
                return response([
                'status'    => 404,
                'message'   => 'Lead not found',
                'error_msg' => 'The lead with the given ID does not exist',
                'data'      => null,
                ], 200);
            }

            $encryptedId = $helper->encrypt_decrypt(
                $service->sno,
                'encrypt'
            );

            $BioLink = url('author-biography/' . $encryptedId);
            
                //  communication Receipt
                $communicationStatus=DB::table('et_communication_handle')->where('module_name','NDA Send')->first();
                $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
                //  return $communicationStatus;

                $response = [ 'email' => false, 'sms' => false, 'whatsapp' => false, 'errors' => [] ];
                if($communicationStatus && $communicationStatus->status == 0){
            
                    // Receipt Communication 
                    
                        $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                        
                            $lead_name =$lead->lead_name;
                            $lead_email_id =$customer->cus_email_id ??$lead->lead_email_id;
                            $lead_mobile =$lead->lead_mobile;
                        
                                $TargetCurrency = $proposal->currency_code ?? 'INR';
                                $endpoint = 'convert';
                                $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                        
                                $helper = new \App\Helpers\Helpers();
                                //   if ($TargetCurrency !== 'INR') {
                                //     $response= $helper->convertFromINR($TargetCurrency);   
                                //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                                //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                                //     $converted_amount = ($exchange_quote != 0) ? $slots->paidAmount * $exchange_quote : 0;
                                //   }else{
                                //     $converted_amount =$slots->paidAmount;
                                //   }
                    $exchange_quote=1;
                                
                                $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                                $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                                $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;
                            
                                
                            // sms Receipt send
                            if($communicationStatus->sms ==0){
                                try {
                                    if ($sms == 1) {
                    
                                    $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
                                    $authkey = $result_sms ? $result_sms->authkey : '';
                                    $sender_id = $result_sms ? $result_sms->sender_id : '';
                                    $template_id = $result_sms ? $result_sms->template_id : '';
                                    $country_code = $result_sms ? $result_sms->country_code : '';
                                    $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                                    $mobile_number = $country_code . $lead_mobile;
                            
                                    
                                
                            
                                    // Replace placeholders with actual values
                                    $replacement_values = [$lead_name,$cre_mobile];
                                    $message_content = preg_replace_callback(
                                        '/\{#var#\}/',
                                        function () use (&$replacement_values) {
                                        return array_shift($replacement_values);
                                        },
                                        $message_content
                                    );
                            
                                    $route = "default";
                                    $postData = array(
                                        'authkey' => $authkey,
                                        'mobiles' => $mobile_number,
                                        'message' => $message_content,
                                        'sender' => $sender_id,
                                        'route' => $route,
                                    );
                            
                                    // API URL
                                    $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                            
                                    // Initialize the resource
                                    $ch = curl_init();
                                    curl_setopt_array($ch, array(
                                        CURLOPT_URL => $url,
                                        CURLOPT_RETURNTRANSFER => true,
                                        CURLOPT_POST => true,
                                        CURLOPT_POSTFIELDS => $postData,
                                        CURLOPT_SSL_VERIFYHOST => 0,
                                        CURLOPT_SSL_VERIFYPEER => 0,
                                    ));
                            
                                    // Get response
                                    $response = curl_exec($ch);
                                    // return $response;
                                    $err = curl_error($ch);
                                    curl_close($ch);
                                    $response['sms'] = true;
                                    }
                                    } catch (\Exception $e) { $response['errors'][] = 'SMS : '.$e->getMessage(); }

                            }
                            
                            // Email Receipt Send
                            if($communicationStatus->email ==0){ 
                                if ($email == 1) {
                                if ($lead_email_id) {
                                    $emailTemplate_id =15; // Bio send Template Id
                                    $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                        
                                    // Gender condition
                                    $genderPrefix = 'Mr/Ms'; // Default value
                                    if ($lead->lead_gender == 1) {
                                    $genderPrefix = 'Mr';
                                    } elseif ($lead->lead_gender == 2) {
                                    $genderPrefix = 'Ms';
                                    }
                                
                            
                
                                $content = $emailTemplate->email_subject;
                        
                                $dynamicSubject = str_replace('#entity_name',   'Elysium Technology Acknowledgement for Product Delivery', $emailTemplate->email_name);
                        
                                $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                                $content = str_replace('#BioLink',$customer ? $BioLink : "phdizone.com", $content);
                            
                                $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                                $content = str_replace('#date', now()->format('F j, Y') ?? '', $content);
                                $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                                $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
                                $content = str_replace('#customer_care',  $cre_mobile ?? '8220011465', $content);
                                $branchNo = $branch->mobile;
                                $branchemail = $branch->mail;
                                $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                                $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                                $url= 'phdizone.com';
                        
                                $mailData = [
                                    'url'         => $url,
                                    'subject'     => "Elysium Technology Author Biography Request",
                                    'content'     => $content,
                                    'branchNo'    => $branchNo,
                                    'branchemail' => $branchemail, // Use the message content from the request
                                    'fbLink'      => $fbLink,      // Use the message content from the request
                                    'instaLink'   => $instaLink,   // Use the message content from the request
                                    'salesMobile' => $cre_mobile ?? '8220011465'
                                ];
                                $from_address = 'elysiumtechnology@elysium.community';
                                $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                        try { 
                            if ($email == 1) {
                                Mail::to($customer->cus_email_id)->send(new ETPLMail($mailData, $from_address, $from_name));
                                            $response['email'] = true;
                                        }
                                    } catch (\Exception $e) {
                                        $response['errors'][] = 'Email : ' . $e->getMessage();
                                    }
                            }
                                }
                            }
                            
                            //  Whatsapp Receipt Send
                            if($communicationStatus->whatsapp ==0){
                                try {
                                if ($whatsapp == 1) {
                                        if ($lead_mobile) {
                                
                                
                                        // $templateName  = "hello_world";
                                        $templateName  = "payment_recept_phdizone";
                        
                                        $hasHeader  = false; // Example flag: set based on template
                                        $hasBody    = false; // Example flag: set based on template
                                        $hasFooter  = false; // Example flag: set based on template
                                        $hasButton  = false;
                                        $components = [];
                                        $couponCode = " ";
                                        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                                // $currentHour = date('H'); // Get current hour in 24-hour format
                                        if ($currentHour >= 5 && $currentHour < 12) {
                                            $greeting = 'Good Morning';
                                        } elseif ($currentHour >= 12 && $currentHour < 18) {
                                            $greeting = 'Good Afternoon';
                                        } else {
                                            $greeting = 'Good Evening';
                                        }
                        
                                        if ($templateName == 'payment_recept_phdizone') {
                                            $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                            $couponCode  = 'NOOFFER';
                                            $buttonIndex = 1;
                                            $bodyText    = [
                                                [
                                                    'type'           => 'text',
                                                    'text'           => $customer ? $customer->cus_name : $lead_name,
                                                    'parameter_name' => 'customer_name',
                                                ],
                                                [
                                                    'type'           => 'text',
                                                    'text'           => $paymentData->payment_id ?? '',
                                                    'parameter_name' => 'recept_number',
                                                ],
                                                [
                                                    'type'           => 'text',
                                                    'text'           => $transaction_date ?? date('d-M-Y'),
                                                    'parameter_name' => 'payment_date',
                                                ],
                                                [
                                                    'type'           => 'text',
                                                    'text'           => $slotAmount ?? '',
                                                    'parameter_name' => 'payment',
                                                ],
                                                [
                                                    'type'           => 'text',
                                                    'text'           => $proposal->service_title ?? '',
                                                    'parameter_name' => 'service_name',
                                                ],
                                                [
                                                    'type'           => 'text',
                                                    'text'           => $slot_url_key_receipt?? "",
                                                    'parameter_name' => 'link_key',
                                                ],
                                                [
                                                    'type'           => 'text',
                                                    'text'           => $cre_mobile ?? '8220011465',
                                                    'parameter_name' => 'cre_number',
                                                ],
                                            ];
                                            $hasHeader = true;
                                            $hasBody   = true;
                                            $hasButton = true;
                                        }
                        
                                        // Add Header if required
                                        if ($hasHeader) {
                                            $components[] = [
                                                'type'       => 'header',
                                                'parameters' => [
                                                    [
                                                        'type'  => 'image',
                                                        'image' => [
                                                            'link' => $headerImage, // Dynamically set header image
                                                        ],
                                                    ],
                                                ],
                                            ];
                                        }
                        
                                        // Add Body if required
                                        if ($hasBody) {
                                            $components[] = [
                                                'type'       => 'body',
                                                'parameters' => $bodyText,
                                            ];
                                        }
                        
                                        // Add Footer if required
                                        if ($hasButton) {
                                            $components[] = [
                                                'type'       => 'button',
                                                'sub_type'   => 'url',
                                                'index'      => 0,
                                                'parameters' => [
                                                    [
                                                        'type' => 'text',
                                                        'text' => $slot_url_key_receipt ?? "",
                                                    ],
                                                ],
                                            ];
                                        }
                                        
                                        
                                        $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                        $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                        $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                        $accessToken               = $whatsappApi->access_tokken ?? '';
                                        $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                        
                                        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                        
                                        $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                        $to           = $lead_mobile;
                                        $languageCode = 'en';
                            
                                        if (strpos($to, $countryCode) !== 0) {
                                            $to = $countryCode . $to;
                                        }
                        
                                        $message = 'test~message';
                                        if (empty($components)) {
                                            $payload = [
                                                'messaging_product' => 'whatsapp',
                                                'to'                => $to,
                                                'type'              => 'template',
                                                'template'          => [
                                                    'name'     => $templateName,
                                                    'language' => [
                                                        'code' => $languageCode,
                                                    ],
                                                ],
                                            ];
                                        } else {
                                            $payload = [
                                                'messaging_product' => 'whatsapp',
                                                'to'                => $to,
                                                'type'              => 'template',
                                                'template'          => [
                                                    'name'       => $templateName,
                                                    'language'   => [
                                                        'code' => $languageCode,
                                                    ],
                                                    'components' => $components,
                                                ],
                                            ];
                                        }
                        
                                        $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                        
                                    
                                    if ($response['status'] == 200) {}
                                    else{
                                        return response([
                                            'status' => 404,
                                            'message' => 'Failed to send message',
                                            'error_msg' => $response['error'],
                                            ], 400);
                                        }
                                    
                            }
                            $response['whatsapp'] = true;
                                }
                                } catch (\Exception $e) { $response['errors'][] = 'Whatsapp : '.$e->getMessage(); }
                            }
                            
                        
                            
                }else{
                    return $communicationStatus;
                }
            // If the operation was successful, return a success response
            $successCount =
                collect($response)
                    ->only(['email','sms','whatsapp'])
                    ->filter()
                    ->count();

            if ($successCount == 0) {

                return response()->json([
                    'status' => 500,
                    'message' => 'No communication was sent.',
                    'data' => $response
                ]);
            }

            if (count($response['errors']) > 0) {

                return response()->json([
                    'status' => 207,
                    'message' => 'Partially sent.',
                    'data' => $response
                ]);
            }
            
            DB::table('et_proposal')
            ->where('sno', $service->proposal_id)
            ->update([
                'biography_link_sent' => 1,
                'biography_link_sent_at' => now(),
                'biography_link_sent_by' => auth()->user()->user_id,
            ]);
         
 
            return response()->json([
                'status' => 200,
                'message' => 'All communications sent successfully.',
                'data' => $response
            ]);
        } catch (\Exception $e){

            DB::rollBack();

            return response()->json([
                'status'=>500,
                'message'=>$e->getMessage()
            ]);
        }
    }
      private function sendRequestToWhatsApp($url, $token, $data)
      {
        try {
          $client = new \GuzzleHttp\Client();
          $response = $client->post($url, [
            'headers' => [
              'Authorization' => 'Bearer ' . $token,
              'Content-Type' => 'application/json',
            ],
            'json' => $data,
          ]);
    
          return [
            'status' => $response->getStatusCode(),
            'data' => json_decode($response->getBody(), true),
          ];
        } catch (\Exception $e) {
          return [
            'status' => 400,
            'error' => $e->getMessage(),
          ];
        }
      }
    
 public function completeTaskByCre(Request $request)
        {
            DB::beginTransaction();
 
            try {
 
              $milestone = DB::table('et_milestone_history')
            ->where('sno', $request->history_id)
            ->first();
 
        if (!$milestone) {
            return response()->json([
                'status'=>404
            ]);
        }
 
        $history =$milestone ;
        // Already completed by CRE
        if ($history->completed_by_cre == 1) {
            return response()->json([
                'status' => 409,
                'message' => 'This task has already been completed by CRE.'
            ]);
        }
 
        // Already acknowledged by customer
        if ($history->customer_ack_status == 1 && $history->completed_by_cre == 0) {
            return response()->json([
                'status' => 409,
                'message' => 'This task has already been acknowledged by the customer.'
            ]);
        }
        $oldAckStatus = $history->customer_ack_status;
        $oldResponse  = $history->customer_response;
                DB::table('et_milestone_history')
                    ->where('sno', $request->history_id)
                    ->update([
 
                        'customer_ack_status' => 1,
 
                        'customer_response' => 1,
 
                        'completed_by_cre' => 1,
 
                        'completed_by_cre_by' => auth()->user()->user_id,
 
                        'completed_by_cre_date' => now(),
 
                        'completed_by_cre_method' => $request->complete_method,
 
                        'completed_by_cre_remarks' => $request->remarks,
 
                        'updated_at' => now()
 
                    ]);
 
                DB::table('et_production_logs')->insert([
 
                    'service_id' => $request->service_id,
                    'milestone_id' => $history->milestone_id,
                    'milestone_history_id' => $history->sno,
                    'action_type' => 'customer_accepted',
 
                    'remarks' => 'Task completed by CRE after customer confirmation via '.$request->complete_method,
                    'old_value' => json_encode([
                        'customer_ack_status' => $oldAckStatus,
                        'customer_response'   => $oldResponse
                    ], JSON_UNESCAPED_UNICODE),
 
                    'new_value' => json_encode([
                        'customer_ack_status' => 1,
                        'customer_response'   => 1,
                        'completed_by_cre'    => 1
                    ], JSON_UNESCAPED_UNICODE),
                    'performed_by' => auth()->user()->user_id
 
                ]);
 
                DB::commit();
 
                return response()->json([
                    'status' => 200
                ]);
 
            } catch (\Exception $e) {
 
                DB::rollBack();
 
                return response()->json([
                    'status' => 500,
                    'message' => $e->getMessage()
                ]);
 
            }
        }
 
public function sendJournalLink(Request $request)
{
    try {
 
        $helper = new \App\Helpers\Helpers();
 
        $customer = DB::table('et_customer')
                        ->where('sno', $request->customer_id)
                        ->first();
 
        if (!$customer) {
 
            return response()->json([
                'status' => 404,
                'message' => 'Customer not found.'
            ]);
        }
          $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
             ->where('et_proposal.sno',$request->proposal_id)
              ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
              ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
              ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
              ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
              ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->where('et_proposal.status','!=',2)
             ->where('et_lead.status','!=',2)
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
        $lead_id=$proposal->lead_id ?? 0;
        $email     = $request->send_email;
        $sms      = $request->send_sms;
        $whatsapp = $request->send_whatsapp;
        $message  = $request->message;
        $user_id  = $request->user()->user_id;
 
 
        // return $request;
        // Find the lead based on lead_id
        $lead = LeadModel::where('sno', $lead_id)
            ->first();
 
        // If the lead is not found, return an error response
        if (!$lead) {
            return response([
            'status'    => 404,
            'message'   => 'Lead not found',
            'error_msg' => 'The lead with the given ID does not exist',
            'data'      => null,
            ], 200);
        }
        $encrypted = $helper->encrypt_decrypt(
            $proposal->sno,
            'encrypt'
        );
 
        $link = url('/customer-journal-selection/'.$encrypted);
 
        //  communication Receipt
         $communicationStatus=DB::table('et_communication_handle')->where('module_name','NDA Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
        //  return $communicationStatus;
 
        $response = [ 'email' => false, 'sms' => false, 'whatsapp' => false, 'errors' => [] ];
        if($communicationStatus && $communicationStatus->status == 0){
              // Receipt Communication 
                  $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                       $lead_name =$lead->lead_name;
                       $lead_email_id =$customer->cus_email_id ??$lead->lead_email_id;
                       $lead_mobile =$lead->lead_mobile;
                        $helper = new \App\Helpers\Helpers();
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                          $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;

                      // sms Receipt send
                      if($communicationStatus->sms ==0){
                        try {
                            if ($sms == 1) {
                              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
                              $authkey = $result_sms ? $result_sms->authkey : '';
                              $sender_id = $result_sms ? $result_sms->sender_id : '';
                              $template_id = $result_sms ? $result_sms->template_id : '';
                              $country_code = $result_sms ? $result_sms->country_code : '';
                              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                              $mobile_number = $country_code . $lead_mobile;


                              // Replace placeholders with actual values
                              $replacement_values = [$lead_name,$cre_mobile];
                              $message_content = preg_replace_callback(
                                '/\{#var#\}/',
                                function () use (&$replacement_values) {
                                  return array_shift($replacement_values);
                                },
                                $message_content
                              );
                              $route = "default";
                              $postData = array(
                                'authkey' => $authkey,
                                'mobiles' => $mobile_number,
                                'message' => $message_content,
                                'sender' => $sender_id,
                                'route' => $route,
                              );
                              // API URL
                              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                              // Initialize the resource
                              $ch = curl_init();
                              curl_setopt_array($ch, array(
                                CURLOPT_URL => $url,
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => $postData,
                                CURLOPT_SSL_VERIFYHOST => 0,
                                CURLOPT_SSL_VERIFYPEER => 0,
                              ));
                              // Get response
                              $response = curl_exec($ch);
                              // return $response;
                              $err = curl_error($ch);
                              curl_close($ch);
                              $response['sms'] = true;
                            }
                            } catch (\Exception $e) { $response['errors'][] = 'SMS : '.$e->getMessage(); }
 
                    }
                    // Email Receipt Send
                      if($communicationStatus->email ==0){ 
                           if ($email == 1) {
                        if ($lead_email_id) {
                            $emailTemplate_id =16; // Bio send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }

                        $content = $emailTemplate->email_subject;
                        $dynamicSubject = str_replace('#entity_name',   'Elysium Technology Acknowledgement for Product Delivery', $emailTemplate->email_name);
                        $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                        $content = str_replace('#BioLink',$customer ? $link : "phdizone.com", $content);
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#date', now()->format('F j, Y') ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
                        $content = str_replace('#customer_care',  $cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
                        $mailData = [
                              'url'         => $url,
                              'subject'     => "Elysium Technology Author Biography Request",
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $cre_mobile ?? '8220011465'
                          ];
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                try { 
                    if ($email == 1) {
                        Mail::to($customer->cus_email_id)->send(new ETPLMail($mailData, $from_address, $from_name));
                                    $response['email'] = true;
                                }
                            } catch (\Exception $e) {
                                $response['errors'][] = 'Email : ' . $e->getMessage();
                            }
                     }
                           }
                      }
                    //  Whatsapp Receipt Send
                      if($communicationStatus->whatsapp ==0){
                           try {
                          if ($whatsapp == 1) {
                                if ($lead_mobile) {

                                // $templateName  = "hello_world";
                                $templateName  = "payment_recept_phdizone";
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                                if ($templateName == 'payment_recept_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $customer ? $customer->cus_name : $lead_name,
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $paymentData->payment_id ?? '',
                                            'parameter_name' => 'recept_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $transaction_date ?? date('d-M-Y'),
                                            'parameter_name' => 'payment_date',
                                        ],
                                         [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'payment',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key_receipt?? "",
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $cre_mobile ?? '8220011465',
                                            'parameter_name' => 'cre_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key_receipt ?? "",
                                            ],
                                        ],
                                    ];
                                }

                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead_mobile;
                                $languageCode = 'en';
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                      }
                      $response['whatsapp'] = true;
                          }
                          } catch (\Exception $e) { $response['errors'][] = 'Whatsapp : '.$e->getMessage(); }
                      }

        }else{
            return $communicationStatus;
        }
      // If the operation was successful, return a success response
     $successCount =
        collect($response)
            ->only(['email','sms','whatsapp'])
            ->filter()
            ->count();
 
    if ($successCount == 0) {
 
        return response()->json([
            'status' => 500,
            'message' => 'No communication was sent.',
            'data' => $response
        ]);
    }
 
    if (count($response['errors']) > 0) {
 
        return response()->json([
            'status' => 207,
            'message' => 'Partially sent.',
            'data' => $response
        ]);
    }

 
    return response()->json([
        'status' => 200,
        'message' => 'All communications sent successfully.',
        'data' => $response
    ]);
      } catch (\Exception $e){
 
            DB::rollBack();
 
            return response()->json([
                'status'=>500,
                'message'=>$e->getMessage()
            ]);
        }
    }
    
    public function customerJournalSelection($id)
{
    $helper = new \App\Helpers\Helpers();
 
    $proposalId = $helper->encrypt_decrypt($id,'decrypt');
 
    if(!$proposalId){
        abort(404);
    }
 
    $proposal = DB::table('et_proposal')
        ->where('sno',$proposalId)
        ->first();
 
    if(!$proposal){
        abort(404);
    }
 
    $services = DB::table('et_customer_services as cs')
 
        ->join('et_product as p','p.sno','=','cs.product_id')
 
        ->leftJoin('et_customer as c','c.sno','=','cs.customer_id')
 
        ->where('cs.proposal_id',$proposalId)
 
        ->where('p.journal_product',1)
 
        ->where('cs.status',0)
 
        ->select(
 
            'cs.sno',
 
            'cs.proposal_id',
 
            'cs.product_id',
 
            'cs.journal_check',
 
            'p.product_name',
 
            'c.cus_name',
 
            'c.customer_id'
 
        )
 
        ->get();
        // return $services;
    $isJournalSubmitted = $proposal->journal_selection_completed == 1;
    return view(
 
        'content.production_management.manage_deliverables.journal_selection',
 
        compact(
 
            'proposal',
 
            'services',
            'isJournalSubmitted'
 
        )
 
    );
}
public function saveJournalSelection(Request $request)
{
    DB::beginTransaction();
 
    try{
 
        if(empty($request->services)){
 
            return response()->json([
 
                'status'=>422,
 
                'message'=>'Please select at least one journal.'
 
            ]);
 
        }
 
        DB::table('et_customer_services')
 
            ->whereIn('sno',$request->services)
 
            ->update([
 
                'journal_check'=>1,
 
                'updated_at'=>now()
 
            ]);
 
        DB::table('et_proposal')
        ->where('sno', $request->proposal_id)
        ->update([
            'journal_selection_completed' => 1,
            'journal_selection_date' => now()
        ]);
 
        DB::commit();
 
        return response()->json([
 
            'status'=>200,
 
            'message'=>'Journal selection submitted successfully.'
 
        ]);
 
    }catch(\Exception $e){
 
        DB::rollBack();
 
        return response()->json([
 
            'status'=>500,
 
            'message'=>$e->getMessage()
 
        ]);
 
    }
 
}
 
public function getSelectedJournals(Request $request)
{
    try {
        $customer_sno = $request->customer_sno;
        $proposal_id = $request->proposal_id;
 
        // Get selected journals (where journal_check = 1) for the given proposal
        $selectedJournals = DB::table('et_customer_services')
            ->select(
                'et_customer_services.sno',
                'et_product.product_name as product_name',
                'et_customer_services.journal_check',
                'et_product.product_name as product_full_name'
            )
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', 1);
            })
            ->where('et_customer_services.customer_id', $customer_sno)
            ->where('et_customer_services.proposal_id', $proposal_id)
            ->where('et_customer_services.journal_check', 1)
            ->where('et_customer_services.status', '!=', 2)
            ->get();
 
        return response()->json([
            'status' => 200,
            'message' => 'Selected journals fetched successfully',
            'data' => $selectedJournals
        ]);
 
    } catch (\Exception $e) {
        return response()->json([
            'status' => 500,
            'message' => $e->getMessage()
        ]);
    }
}

public function shortenUrl($longUrl, $channelId)
  {
    $response = Http::withToken('aFLQFlykraqpANsi')
      ->post('https://chotta.link/api/url/add', [
        'url' => $longUrl
      ]);

    if ($response->successful() && isset($response['shorturl'])) {

      $shortUrl = $response['shorturl'];
      $urlId = $response['id'];

      $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

      $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);

      if ($assignResponse->successful()) {
        return $response; // success
      }
    }


    return null;
  }

//noc send message 
//  public function SendNocMessage(Request $request)
//     {
    
//     // Validate the incoming request data
//       $validator = Validator::make($request->all(), [
//         'proposal_id' => 'required', 
//         'email'    => 'boolean',
//         'sms'     => 'boolean',
//         'whatsapp' => 'boolean'
//       ]);
//       // If validation fails, return a response with errors
//       if ($validator->fails()) {
//         return response([
//           'status'    => 401,
//           'message'   => 'Incorrect format input fields',
//           'error_msg' => $validator->messages()->get('*'),
//           'data'      => null,
//         ], 200);
//       }
          
//       $proposal_id = $request -> proposal_id;
//       $service_id  = $request -> service_id;
//       $customer_id = $request -> customer_id;
//       $branch_id = $request->user()->branch_id;
//       $entity_id = $request->user()->entity_id;
//       $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
//       $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

//       $branch_name = " ";
//       if ($branchData->branch_type == 1) {
//         $branch_name = $branchData->branch_name;
//       } elseif ($branchData->branch_type == 2) {
//         $branch_name = $branchData->franchise_name;
//       }

     
//       $customer_id  = $request->customer_id;
//       $old_customer_check  = $request->old_customer_check;

    

//     $proposal =DB::table('et_proposal')
//              ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
//              ->where('et_proposal.sno',$proposal_id)
//               ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
//               ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
//               ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
//               ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
//               ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
//              ->where('et_proposal.status','!=',2)
//              ->where('et_lead.status','!=',2)
//              ->orderBy('et_proposal.sno', 'desc')
//              ->first();
//             if($proposal){
//                 if($proposal->post_sale_check==1){
//                     $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
//                     $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
//                     $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
//                 }
//             }
//             if (!$proposal) {
//                 return response()->json([
//                     'status'=>404,
//                     'message'=>'Proposal not found.',
//                     'error_msg'=>null,
//                     'data'=>null
//                 ],404);
//             }
//          $proposal_id  = $proposal->sno;
//       $customer=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
//       if(!$customer){
//                 return response()->json([
//                     'status'=>404,
//                     'message'=>'Customer not found.',
//                     'error_msg'=>null,
//                     'data'=>null
//                 ],404);
//             }
//       // Extract the validated data
//       $lead_id=$proposal->lead_id ?? 0;
//       $email     = $request->email;
//       $sms      = $request->sms;
//       $whatsapp = $request->whatsapp;
//       $message  = $request->message;
//       $user_id  = $request->user()->user_id;


//       // return $request;
//       // Find the lead based on lead_id
//       $lead = LeadModel::where('sno', $lead_id)
//         ->first();

//       // If the lead is not found, return an error response
//       if (!$lead) {
//         return response([
//           'status'    => 404,
//           'message'   => 'Lead not found',
//           'error_msg' => 'The lead with the given ID does not exist',
//           'data'      => null,
//         ], 200);
//       }
      
      

//       $helper = new \App\Helpers\Helpers();
//       $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');

//       $ReceiptLink ='https://erp.elysiumtechnologies.com/manage_product_noc/'.$encrypted_values;
      
//          //  communication Receipt
//          $communicationStatus=DB::table('et_communication_handle')->where('module_name','Receipt Send')->first();
//          $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();

//           $channelId = 4;
//           $shortUrlData = $this->shortenUrl($ReceiptLink, $channelId);
//           $shortUrl = $shortUrlData['shorturl'];
//           $urlId = $shortUrlData['id'];
//           if ($shortUrl) {
//             DB::table('et_proposal')
//               ->where('sno', $proposal->sno)
//               ->update(['temp_send_link' => $shortUrl]);

//             DB::table('et_chotta_links')->insert([
//               'branch_id' => $branch_id,
//               'chotta_link_id' => $urlId,
//               'chotta_short_link' => $shortUrl,
//               'large_encrypt_link' => $ReceiptLink,
//               'link_type' => 'NOC Send',
//               'proposal_id' => $proposal->sno,
//               'created_by' => $user_id,
//               'updated_by' => $user_id,
//             ]);
//           }

//               $response = [ 'email' => false, 'sms' => false, 'whatsapp' => false, 'errors' => [] ];
//         if($communicationStatus && $communicationStatus->status == 0){
      
     
//               // Receipt Communication 
              
//                   $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                  
//                       $lead_name =$lead->lead_name;
//                       $lead_email_id =$customer->cus_email_id ??$lead->lead_email_id;
//                       $lead_mobile =$lead->lead_mobile;
                  
//                         $TargetCurrency = $proposal->currency_code ?? 'INR';
//                         $endpoint = 'convert';
//                         $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                
//                         $helper = new \App\Helpers\Helpers();
//                         //   if ($TargetCurrency !== 'INR') {
//                         //     $response= $helper->convertFromINR($TargetCurrency);   
//                         //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
//                         //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
//                         //     $converted_amount = ($exchange_quote != 0) ? $slots->paidAmount * $exchange_quote : 0;
//                         //   }else{
//                         //     $converted_amount =$slots->paidAmount;
//                         //   }
//                     $exchange_quote=1;
                          
//                          $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
//                          $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
//                           $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;
                       
                          
//                       // sms Receipt send
//                       if($communicationStatus->sms ==0){
//                         if ($sms == 1) {
//                             try{
//                               $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
//                               $authkey = $result_sms ? $result_sms->authkey : '';
//                               $sender_id = $result_sms ? $result_sms->sender_id : '';
//                               $template_id = $result_sms ? $result_sms->template_id : '';
//                               $country_code = $result_sms ? $result_sms->country_code : '';
//                               $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
//                               $mobile_number = $country_code . $lead_mobile;
                    
                             
                           
                    
//                               // Replace placeholders with actual values
//                               $replacement_values = [$lead_name,$cre_mobile];
//                               $message_content = preg_replace_callback(
//                                 '/\{#var#\}/',
//                                 function () use (&$replacement_values) {
//                                   return array_shift($replacement_values);
//                                 },
//                                 $message_content
//                               );
                    
//                               $route = "default";
//                               $postData = array(
//                                 'authkey' => $authkey,
//                                 'mobiles' => $mobile_number,
//                                 'message' => $message_content,
//                                 'sender' => $sender_id,
//                                 'route' => $route,
//                               );
                    
//                               // API URL
//                               $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                    
//                               // Initialize the resource
//                               $ch = curl_init();
//                               curl_setopt_array($ch, array(
//                                 CURLOPT_URL => $url,
//                                 CURLOPT_RETURNTRANSFER => true,
//                                 CURLOPT_POST => true,
//                                 CURLOPT_POSTFIELDS => $postData,
//                                 CURLOPT_SSL_VERIFYHOST => 0,
//                                 CURLOPT_SSL_VERIFYPEER => 0,
//                               ));
                    
//                               // Get response
//                               $response = curl_exec($ch);
//                               // return $response;
//                               $err = curl_error($ch);
//                               curl_close($ch);
//                             $response['sms'] = true;
//                             }catch (\Exception $e) { $response['errors'][] = 'SMS : '.$e->getMessage(); }
//                         }
//                     }
                    
//                     // Email Receipt Send
//                       if($communicationStatus->email ==0){ 
//                           if ($email == 1) {
//                               if (!$lead_email_id) {
//                                 throw new \Exception("Customer email not found.");
//                             }

//                         if ($lead_email_id) {
//                             $emailTemplate_id =13; // proposal send Template Id
//                             $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
//                             // Gender condition
//                             $genderPrefix = 'Mr/Ms'; // Default value
//                             if ($lead->lead_gender == 1) {
//                               $genderPrefix = 'Mr';
//                             } elseif ($lead->lead_gender == 2) {
//                               $genderPrefix = 'Ms';
//                             }
                        
                      
                        
//                         $content = $emailTemplate->email_subject;
                
//                         $dynamicSubject = str_replace('#entity_name',   'Elysium Technology NOC for Product Delivery', $emailTemplate->email_name);
                
//                         $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                    
//                         $content = str_replace('#link', $ReceiptLink ?? '', $content);
//                         $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
//                         $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
//                         $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
//                         $branchNo = $branch->mobile;
//                         $branchemail = $branch->mail;
//                         $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
//                         $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
//                         $url= 'phdizone.com';
                
//                         $mailData = [
//                               'url'         => $url,
//                               'subject'     => "Elysium Technology NOC for Product Delivery",
//                               'content'     => $content,
//                               'branchNo'    => $branchNo,
//                               'branchemail' => $branchemail, // Use the message content from the request
//                               'fbLink'      => $fbLink,      // Use the message content from the request
//                               'instaLink'   => $instaLink,   // Use the message content from the request
//                               'salesMobile' => $cre_mobile ?? '8220011465',
//                           ];
//                         $to_address = $lead_email_id;
//                         $from_address = 'elysiumtechnology@elysium.community';
//                         $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
//                         try{
//                         Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
//                          $response['email'] = true;
//                         }catch(\Exception $e){
//                          $response['errors'][] = 'Email : ' . $e->getMessage();
//                             \Log::error("Email Send Failed",[
//                                 'email'=>$to_address,
//                                 'message'=>$e->getMessage()
//                             ]);


//                             throw new \Exception("Unable to send email.");
//                         }
//                      }
//                           }
//                       }
                      
//                     //  Whatsapp Receipt Send
//                       if($communicationStatus->whatsapp ==0){
                           
//                           if ($whatsapp == 1) {
//                                 if ($lead_mobile) {
                          
                           
//                                 // $templateName  = "hello_world";
//                                 $templateName  = "payment_recept_phdizone";
                
//                                 $hasHeader  = false; // Example flag: set based on template
//                                 $hasBody    = false; // Example flag: set based on template
//                                 $hasFooter  = false; // Example flag: set based on template
//                                 $hasButton  = false;
//                                 $components = [];
//                                 $couponCode = " ";
//                                 date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
//                                 $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
//                                                                           // $currentHour = date('H'); // Get current hour in 24-hour format
//                                 if ($currentHour >= 5 && $currentHour < 12) {
//                                     $greeting = 'Good Morning';
//                                 } elseif ($currentHour >= 12 && $currentHour < 18) {
//                                     $greeting = 'Good Afternoon';
//                                 } else {
//                                     $greeting = 'Good Evening';
//                                 }
                
//                                 if ($templateName == 'payment_recept_phdizone') {
//                                     $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
//                                     $couponCode  = 'NOOFFER';
//                                     $buttonIndex = 1;
//                                     $bodyText    = [
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $customer ? $customer->cus_name : $lead_name,
//                                             'parameter_name' => 'customer_name',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $paymentData->payment_id ?? '',
//                                             'parameter_name' => 'recept_number',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $transaction_date ?? date('d-M-Y'),
//                                             'parameter_name' => 'payment_date',
//                                         ],
//                                          [
//                                             'type'           => 'text',
//                                             'text'           => $slotAmount ?? '',
//                                             'parameter_name' => 'payment',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $proposal->service_title ?? '',
//                                             'parameter_name' => 'service_name',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $slot_url_key_receipt?? "",
//                                             'parameter_name' => 'link_key',
//                                         ],
//                                         [
//                                             'type'           => 'text',
//                                             'text'           => $cre_mobile ?? '8220011465',
//                                             'parameter_name' => 'cre_number',
//                                         ],
//                                     ];
//                                     $hasHeader = true;
//                                     $hasBody   = true;
//                                     $hasButton = true;
//                                 }
                
//                                 // Add Header if required
//                                 if ($hasHeader) {
//                                     $components[] = [
//                                         'type'       => 'header',
//                                         'parameters' => [
//                                             [
//                                                 'type'  => 'image',
//                                                 'image' => [
//                                                     'link' => $headerImage, // Dynamically set header image
//                                                 ],
//                                             ],
//                                         ],
//                                     ];
//                                 }
                
//                                 // Add Body if required
//                                 if ($hasBody) {
//                                     $components[] = [
//                                         'type'       => 'body',
//                                         'parameters' => $bodyText,
//                                     ];
//                                 }
                
//                                 // Add Footer if required
//                                 if ($hasButton) {
//                                     $components[] = [
//                                         'type'       => 'button',
//                                         'sub_type'   => 'url',
//                                         'index'      => 0,
//                                         'parameters' => [
//                                             [
//                                                 'type' => 'text',
//                                                 'text' => $slot_url_key_receipt ?? "",
//                                             ],
//                                         ],
//                                     ];
//                                 }
                                
                                
//                                 $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
//                                 $dynamicParameters         = $templateParameters[$templateName] ?? [];
//                                 $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
//                                 $accessToken               = $whatsappApi->access_tokken ?? '';
//                                 $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
//                                 $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
//                                 $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
//                                 $to           = $lead_mobile;
//                                 $languageCode = 'en';
                    
//                                 if (strpos($to, $countryCode) !== 0) {
//                                     $to = $countryCode . $to;
//                                 }
                
//                                 $message = 'test~message';
//                                 if (empty($components)) {
//                                     $payload = [
//                                         'messaging_product' => 'whatsapp',
//                                         'to'                => $to,
//                                         'type'              => 'template',
//                                         'template'          => [
//                                             'name'     => $templateName,
//                                             'language' => [
//                                                 'code' => $languageCode,
//                                             ],
//                                         ],
//                                     ];
//                                 } else {
//                                     $payload = [
//                                         'messaging_product' => 'whatsapp',
//                                         'to'                => $to,
//                                         'type'              => 'template',
//                                         'template'          => [
//                                             'name'       => $templateName,
//                                             'language'   => [
//                                                 'code' => $languageCode,
//                                             ],
//                                             'components' => $components,
//                                         ],
//                                     ];
//                                 }
                
//                                 $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                                
                               
//                              if ($response['status'] == 200) {}
//                              else{
//                                  return response([
//                                       'status' => 404,
//                                       'message' => 'Failed to send message',
//                                       'error_msg' => $response['error'],
//                                     ], 400);
//                                 }
                            
//                       }
//                           }
//                       }
                    
                      
                      
//         }else{
//             return $communicationStatus;
//         }
//       // If the operation was successful, return a success response
//       // If the operation was successful, return a success response
//      $successCount =
//         collect($response)
//             ->only(['email','sms','whatsapp'])
//             ->filter()
//             ->count();
//     if ($successCount == 0) {

//         return response()->json([
//             'status' => 500,
//             'message' => 'No communication was sent.',
//             'data' => $response
//         ]);
//     }

//     if (count($response['errors']) > 0) {

//         return response()->json([
//             'status' => 207,
//             'message' => 'Partially sent.',
//             'data' => $response
//         ]);
//     }   
//     DB::table('et_proposal')
//     ->where('sno', $proposal_id)
//     ->update([
//         'noc_sent_status' => 1,      // Optional
//         'noc_sent_at'     => now(),
//         'noc_sent_through'=> $send_through,
//         'noc_sent_by'      => $user_id,
//         'noc_url'         => $ReceiptLink,
//         'updated_at'      => now(),
//     ]);
//      return response()->json([
//         'status' => 200,
//         'message' => 'All communications sent successfully.',
//         'data' => $response
//     ]); 
//     }
   
   public function SendNocMessage(Request $request)
    {
   
    // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required',
        'email'    => 'boolean',
        'sms'     => 'boolean',
        'whatsapp' => 'boolean'
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
         
      $proposal_id = $request -> proposal_id;
      $service_id  = $request -> service_id;
      $customer_id = $request -> customer_id;
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
 
      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }
 
     
      $customer_id  = $request->customer_id;
      $old_customer_check  = $request->old_customer_check;
 
   
 
    $proposal =DB::table('et_proposal')
             ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
             ->where('et_proposal.sno',$proposal_id)
              ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
              ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
              ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
              ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
              ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->where('et_proposal.status','!=',2)
             ->where('et_lead.status','!=',2)
             ->orderBy('et_proposal.sno', 'desc')
             ->first();
            if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }
            if (!$proposal) {
                return response()->json([
                    'status'=>404,
                    'message'=>'Proposal not found.',
                    'error_msg'=>null,
                    'data'=>null
                ],404);
            }
         $proposal_id  = $proposal->sno;
      $customer=DB::table('et_customer')->where('et_customer.sno',$customer_id)->first();
      if(!$customer){
                return response()->json([
                    'status'=>404,
                    'message'=>'Customer not found.',
                    'error_msg'=>null,
                    'data'=>null
                ],404);
            }
      // Extract the validated data
      $lead_id=$proposal->lead_id ?? 0;
      $email     = $request->email;
      $sms      = $request->sms;
      $whatsapp = $request->whatsapp;
      $message  = $request->message;
      $user_id  = $request->user()->user_id;
     if($email){
        $send_through='Email';
      }elseif($sms){
        $send_through='SMS';
      }else{
        $send_through= 'Message';
      }
 
      // return $request;
      // Find the lead based on lead_id
      $lead = LeadModel::where('sno', $lead_id)
        ->first();
 
      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }
     
     
 
      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');
 
      $ReceiptLink ='https://erp.elysiumtechnologies.com/manage_product_noc/'.$encrypted_values;
     
         //  communication Receipt
         $communicationStatus=DB::table('et_communication_handle')->where('module_name','Receipt Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
 
          $channelId = 4;
          $shortUrlData = $this->shortenUrl($ReceiptLink, $channelId);
          $shortUrl = $shortUrlData['shorturl'];
          $urlId = $shortUrlData['id'];
          if ($shortUrl) {
            DB::table('et_proposal')
              ->where('sno', $proposal->sno)
              ->update(['temp_send_link' => $shortUrl]);
 
            DB::table('et_chotta_links')->insert([
              'branch_id' => $branch_id,
              'chotta_link_id' => $urlId,
              'chotta_short_link' => $shortUrl,
              'large_encrypt_link' => $ReceiptLink,
              'link_type' => 'NOC Send',
              'proposal_id' => $proposal->sno,
              'created_by' => $user_id,
              'updated_by' => $user_id,
            ]);
          }
 
               $response = [ 'email' => false, 'sms' => false, 'whatsapp' => false, 'errors' => [] ];
        if($communicationStatus && $communicationStatus->status == 0){
     
     
              // Receipt Communication
             
                  $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                 
                       $lead_name =$lead->lead_name;
                       $lead_email_id =$customer->cus_email_id ??$lead->lead_email_id;
                       $lead_mobile =$lead->lead_mobile;
                 
                        $TargetCurrency = $proposal->currency_code ?? 'INR';
                        $endpoint = 'convert';
                        $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
               
                        $helper = new \App\Helpers\Helpers();
                        //   if ($TargetCurrency !== 'INR') {
                        //     $response= $helper->convertFromINR($TargetCurrency);  
                        //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                        //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                        //     $converted_amount = ($exchange_quote != 0) ? $slots->paidAmount * $exchange_quote : 0;
                        //   }else{
                        //     $converted_amount =$slots->paidAmount;
                        //   }
                    $exchange_quote=1;
                         
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                          $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;
                       
                         
                      // sms Receipt send
                      if($communicationStatus->sms ==0){
                        if ($sms == 1) {
                            try{
                              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
                              $authkey = $result_sms ? $result_sms->authkey : '';
                              $sender_id = $result_sms ? $result_sms->sender_id : '';
                              $template_id = $result_sms ? $result_sms->template_id : '';
                              $country_code = $result_sms ? $result_sms->country_code : '';
                              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                              $mobile_number = $country_code . $lead_mobile;
                   
                             
                           
                   
                              // Replace placeholders with actual values
                              $replacement_values = [$lead_name,$cre_mobile];
                              $message_content = preg_replace_callback(
                                '/\{#var#\}/',
                                function () use (&$replacement_values) {
                                  return array_shift($replacement_values);
                                },
                                $message_content
                              );
                   
                              $route = "default";
                              $postData = array(
                                'authkey' => $authkey,
                                'mobiles' => $mobile_number,
                                'message' => $message_content,
                                'sender' => $sender_id,
                                'route' => $route,
                              );
                   
                              // API URL
                              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                   
                              // Initialize the resource
                              $ch = curl_init();
                              curl_setopt_array($ch, array(
                                CURLOPT_URL => $url,
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => $postData,
                                CURLOPT_SSL_VERIFYHOST => 0,
                                CURLOPT_SSL_VERIFYPEER => 0,
                              ));
                   
                              // Get response
                              $response = curl_exec($ch);
                              // return $response;
                              $err = curl_error($ch);
                              curl_close($ch);
                            $response['sms'] = true;
                            }catch (\Exception $e) { $response['errors'][] = 'SMS : '.$e->getMessage(); }
                        }
                    }
                   
                    // Email Receipt Send
                      if($communicationStatus->email ==0){
                           if ($email == 1) {
                              if (!$lead_email_id) {
                                throw new \Exception("Customer email not found.");
                            }
 
                        if ($lead_email_id) {
                            $emailTemplate_id =13; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                       
                     
                       
                        $content = $emailTemplate->email_subject;
               
                        $dynamicSubject = str_replace('#entity_name',   'Elysium Technology NOC for Product Delivery', $emailTemplate->email_name);
               
                        $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                   
                        $content = str_replace('#link', $ReceiptLink ?? '', $content);
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
               
                        $mailData = [
                              'url'         => $url,
                              'subject'     => "Elysium Technology NOC for Product Delivery",
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $cre_mobile ?? '8220011465',
                          ];
                        $to_address = $lead_email_id;
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
               
                        try{
                        Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                         $response['email'] = true;
                        }catch(\Exception $e){
                         $response['errors'][] = 'Email : ' . $e->getMessage();
                            \Log::error("Email Send Failed",[
                                'email'=>$to_address,
                                'message'=>$e->getMessage()
                            ]);
 
 
                            throw new \Exception("Unable to send email.");
                        }
                     }
                           }
                      }
                     
                    //  Whatsapp Receipt Send
                      if($communicationStatus->whatsapp ==0){
                           
                          if ($whatsapp == 1) {
                                if ($lead_mobile) {
                         
                           
                                // $templateName  = "hello_world";
                                $templateName  = "payment_recept_phdizone";
               
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
               
                                if ($templateName == 'payment_recept_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $customer ? $customer->cus_name : $lead_name,
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $paymentData->payment_id ?? '',
                                            'parameter_name' => 'recept_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $transaction_date ?? date('d-M-Y'),
                                            'parameter_name' => 'payment_date',
                                        ],
                                         [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'payment',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key_receipt?? "",
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $cre_mobile ?? '8220011465',
                                            'parameter_name' => 'cre_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
               
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
               
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
               
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key_receipt ?? "",
                                            ],
                                        ],
                                    ];
                                }
                               
                               
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
               
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
               
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead_mobile;
                                $languageCode = 'en';
                   
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
               
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
               
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                               
                               
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                           
                      }
                          }
                      }
                   
                     
                     
        }else{
            return $communicationStatus;
        }
      // If the operation was successful, return a success response
       // If the operation was successful, return a success response
     $successCount =
        collect($response)
            ->only(['email','sms','whatsapp'])
            ->filter()
            ->count();
    if ($successCount == 0) {
 
        return response()->json([
            'status' => 500,
            'message' => 'No communication was sent.',
            'data' => $response
        ]);
    }
 
    if (count($response['errors']) > 0) {
 
        return response()->json([
            'status' => 207,
            'message' => 'Partially sent.',
            'data' => $response
        ]);
    }  
    DB::table('et_proposal')
    ->where('sno', $proposal_id)
    ->update([
        'noc_sent_status' => 1,      // Optional
        'noc_sent_at'     => now(),
        'noc_url'         => $ReceiptLink,
        'updated_at'      => now(),
        'noc_sent_through'=> $send_through,
        'noc_sent_by'      => $user_id,
    ]);
     return response()->json([
        'status' => 200,
        'message' => 'All communications sent successfully.',
        'data' => $response
    ]);
    }
    
   public function sendJournalConfirmation(Request $request)
{
    try {
 
        $helper = new \App\Helpers\Helpers();
 
        $bio = DB::table('et_author_biography')
        ->where('sno', $request->biography_id)
        ->first();
 
        if(!$bio){
            return response()->json([
                'status' => 404,
                'message' => 'Biography not found.'
            ]);
        }
 
        $customer = DB::table('et_customer')
            ->where('sno', $bio->customer_id)
            ->first();
    $service = DB::table('et_customer_services')
            ->where('sno', $bio->service_id)
            ->first();
        $proposal = DB::table('et_proposal')
            ->select(
                'et_proposal.*',
                'et_staff.nick_name',
                'et_staff.staff_name',
                'et_entity.entity_name',
                'et_country_currencies.currency_code',
                'et_country_currencies.currency_symbol'
            )
            ->join('et_lead','et_lead.sno','=','et_proposal.lead_id')
            ->join('et_staff','et_lead.created_by','=','et_staff.sno')
            ->join('et_branch','et_proposal.branch_id','=','et_branch.sno')
            ->join('et_entity','et_branch.entity_id','=','et_entity.sno')
            ->join('et_country_currencies','et_proposal.currency_id','=','et_country_currencies.sno')
            ->where('et_proposal.sno',$service->proposal_id)
            ->first();
        $lead_id=$proposal->lead_id ?? 0;
        $email     = $request->email;
        $sms      = $request->sms;
        $whatsapp = $request->whatsapp;
        $message  = $request->message;
        $user_id  = $request->user()->user_id;
 
 
        // return $request;
        // Find the lead based on lead_id
        $lead = LeadModel::where('sno', $lead_id)
            ->first();
 
        // If the lead is not found, return an error response
        if (!$lead) {
            return response([
            'status'    => 404,
            'message'   => 'Lead not found',
            'error_msg' => 'The lead with the given ID does not exist',
            'data'      => null,
            ], 200);
        }
       $encrypted = $helper->encrypt_decrypt(
            $bio->sno,
            'encrypt'
        );
 
        $link = url('/journal-confirmation/'.$encrypted);
        //  communication Receipt
         $communicationStatus=DB::table('et_communication_handle')->where('module_name','NDA Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
        //  return $communicationStatus;
 
        $response = [ 'email' => false, 'sms' => false, 'whatsapp' => false, 'errors' => [] ];
        if($communicationStatus && $communicationStatus->status == 0){
              // Receipt Communication
             
                  $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
                 
                       $lead_name =$lead->lead_name;
                       $lead_email_id =$customer->cus_email_id ??$lead->lead_email_id;
                       $lead_mobile =$lead->lead_mobile;
                        $helper = new \App\Helpers\Helpers();
                     
                         $branch = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                         $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch->entity_id)->first();
                          $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;
                       
                         
                      // sms Receipt send
                      if($communicationStatus->sms ==0){
                       
                        try {
                            if ($sms == 1) {
           
                              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '7_PhDiZone_Receipt_Template')->first();
                              $authkey = $result_sms ? $result_sms->authkey : '';
                              $sender_id = $result_sms ? $result_sms->sender_id : '';
                              $template_id = $result_sms ? $result_sms->template_id : '';
                              $country_code = $result_sms ? $result_sms->country_code : '';
                              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                              $mobile_number = $country_code . $lead_mobile;
                   
                             
                           
                   
                              // Replace placeholders with actual values
                              $replacement_values = [$lead_name,$cre_mobile];
                              $message_content = preg_replace_callback(
                                '/\{#var#\}/',
                                function () use (&$replacement_values) {
                                  return array_shift($replacement_values);
                                },
                                $message_content
                              );
                   
                              $route = "default";
                              $postData = array(
                                'authkey' => $authkey,
                                'mobiles' => $mobile_number,
                                'message' => $message_content,
                                'sender' => $sender_id,
                                'route' => $route,
                              );
                   
                              // API URL
                              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                   
                              // Initialize the resource
                              $ch = curl_init();
                              curl_setopt_array($ch, array(
                                CURLOPT_URL => $url,
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => $postData,
                                CURLOPT_SSL_VERIFYHOST => 0,
                                CURLOPT_SSL_VERIFYPEER => 0,
                              ));
                   
                              // Get response
                              $response = curl_exec($ch);
                              // return $response;
                              $err = curl_error($ch);
                              curl_close($ch);
                              $response['sms'] = true;
                            }
                            } catch (\Exception $e) { $response['errors'][] = 'SMS : '.$e->getMessage(); }
 
                    }
                   
                    // Email Receipt Send
                      if($communicationStatus->email ==0){
 
                           if ($email == 1) {
                        if ($lead_email_id) {
                            $emailTemplate_id =16; // Bio send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
               
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                       
                     
           
                        $content = $emailTemplate->email_subject;
               
                        $dynamicSubject = str_replace('#entity_name',   'Elysium Technology Acknowledgement for Product Delivery', $emailTemplate->email_name);
               
                        $content = str_replace('#customer_name',$customer ? $customer->cus_name : $lead_name, $content);
                        $content = str_replace('#JournalConfirmationLink',$link,$content);
                   
                        $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                        $content = str_replace('#date', now()->format('F j, Y') ?? '', $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#cre_number',  $cre_mobile ?? '8220011465', $content);
                        $content = str_replace('#customer_care',  $cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $url= 'phdizone.com';
               
                        $mailData = [
                              'url'         => $url,
                              'subject'     => "Elysium Technology Journal Confirmation Required",
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $cre_mobile ?? '8220011465'
                          ];
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                try {
                    if ($email == 1) {
                        Mail::to($customer->cus_email_id)->send(new ETPLMail($mailData, $from_address, $from_name));
                                    $response['email'] = true;
                                }
                            } catch (\Exception $e) {
                                $response['errors'][] = 'Email : ' . $e->getMessage();
                            }
                     }
                           }
                      }
                     
                    //  Whatsapp Receipt Send
                      if($communicationStatus->whatsapp ==0){
                           try {
                          if ($whatsapp == 1) {
                                if ($lead_mobile) {
                         
                           
                                // $templateName  = "hello_world";
                                $templateName  = "payment_recept_phdizone";
               
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
               
                                if ($templateName == 'payment_recept_phdizone') {
                                    $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Payment.jpg';
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $customer ? $customer->cus_name : $lead_name,
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $paymentData->payment_id ?? '',
                                            'parameter_name' => 'recept_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $transaction_date ?? date('d-M-Y'),
                                            'parameter_name' => 'payment_date',
                                        ],
                                         [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'payment',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key_receipt?? "",
                                            'parameter_name' => 'link_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $cre_mobile ?? '8220011465',
                                            'parameter_name' => 'cre_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
               
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
               
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
               
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key_receipt ?? "",
                                            ],
                                        ],
                                    ];
                                }
                               
                               
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
               
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
               
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead_mobile;
                                $languageCode = 'en';
                   
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
               
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
               
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                               
                               
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                           
                      }
                      $response['whatsapp'] = true;
                          }
                          } catch (\Exception $e) { $response['errors'][] = 'Whatsapp : '.$e->getMessage(); }
                      }
                   
                 
                     
        }else{
            return $communicationStatus;
        }
      // If the operation was successful, return a success response
     $successCount =
        collect($response)
            ->only(['email','sms','whatsapp'])
            ->filter()
            ->count();
 
    if ($successCount == 0) {
 
        return response()->json([
            'status' => 500,
            'message' => 'No communication was sent.',
            'data' => $response
        ]);
    }
 
    if (count($response['errors']) > 0) {
 
        return response()->json([
            'status' => 207,
            'message' => 'Partially sent.',
            'data' => $response
        ]);
    }
   
 
    return response()->json([
        'status' => 200,
        'message' => 'All communications sent successfully.',
        'data' => $response
    ]);
      } catch (\Exception $e){
 
            DB::rollBack();
 
            return response()->json([
                'status'=>500,
                'message'=>$e->getMessage()
            ]);
        }
    }
    
   
}
