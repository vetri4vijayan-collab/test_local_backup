<?php

namespace App\Http\Controllers\revision_management;

use App\Http\Controllers\Controller;
use App\Models\DailyTaskModel;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ManageRequirementModel;
use App\Models\ManageRequirementDocs;
use App\Models\RequirementReasonModel;
use App\Models\RequirementDocModel;
use Illuminate\Support\Facades\Validator;
use Throwable;

class ManageRevision extends Controller
{

    //  public function index(Request $request)
    // {
 
    // try{
    //     $user_id = $request->user()->user_id;
    //     $page = $request->input('page', 1);
    //     $perpage = (int) $request->input('sorting_filter', 25);
    //     $offset = ($page - 1) * $perpage;
 
    //     $search_fill = $request->search_fill ?? '';
    //     $status_fill = $request->status ?? '';
    //     $journal_coordinator_fill = $request->journal_coordinator_fill ?? '';
    //     $journal_team_lead_fill = $request->journal_team_lead_fill ?? '';
    //     $journal_status_fill = $request->journal_status_fill ?? '';
    //     $pc_fill = $request->pc_fill ?? '';
    //     $staffs_fill = $request->staffs_fill ?? '';
 
    //     $latestRevision = DB::table('et_journal_revision as jr')
    //         ->select(
    //             'jr.journal_id',
    //             'jr.jc_id',
    //             'jr.jtl_id',
    //             'jr.sno'
    //         )
    //         ->whereRaw('jr.sno = (
    //             SELECT MAX(jr2.sno)
    //             FROM et_journal_revision as jr2
    //             WHERE jr2.journal_id = jr.journal_id
    //         )');
    //     $lists = DB::table('et_journal_revision')
    //         ->leftJoinSub($latestRevision, 'latest_revision', function ($join) {
    //                 $join->on(
    //                     'latest_revision.journal_id',
    //                     '=',
    //                     'et_journal_revision.journal_id'
    //                 );
    //             })
    //         ->leftJoin('et_staff as jc_staff', 'jc_staff.sno', '=', 'latest_revision.jc_id')
    //         ->leftJoin('et_staff as jtl_staff', 'jtl_staff.sno', '=', 'latest_revision.jtl_id')
    //         ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
    //         ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
    //         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_revision.customer_id')
    //         ->leftJoin('et_proposal','et_proposal.sno','=','et_customer_services.proposal_id')
    //         ->leftJoin('et_staff as collection_staff','collection_staff.sno','=','et_proposal.collection_id')
    //         ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
    //         ->select(
    //             'jc_staff.staff_image as jc_staff_image',
    //             'jc_staff.staff_name as jc_staff_name',
 
    //             'et_journal_revision.journal_id',
 
    //             'latest_revision.jc_id as jc_id',
    //             'latest_revision.jtl_id as jtl_id',
 
    //             'jtl_staff.staff_image as jtl_staff_image',
    //             'jtl_staff.staff_name as jtl_staff_name',
    //             'et_journal_booklet.journal_name',
    //             'et_manage_journal.paper_name',
    //             'et_manage_journal.journal_id as manage_journal_id',
    //             'et_product.product_name',
    //             'et_customer_services.sno',
    //             'et_customer_services.created_at',
    //             'et_customer.cus_name',
    //             'et_customer.customer_id',
    //             'collection_staff.sno as collection_id',
    //             'collection_staff.staff_name as collection_staff_name',
    //             'collection_staff.staff_image as collection_staff_image',
    //         );
 
    //     if ($status_fill != '') {
    //         $lists->where('et_journal_revision.status', $status_fill);
    //     }
 
    //     if ($journal_coordinator_fill != '') {
    //         $lists->where('et_journal_revision.jc_id', $journal_coordinator_fill);
    //     }
 
    //     if ($journal_team_lead_fill != '') {
    //         $lists->where('et_journal_revision.jtl_id', $journal_team_lead_fill);
    //     }
 
    //     if (! empty($search_fill)) {
    //         $lists->where(function ($query) use ($search_fill) {
    //             $query->where('jc_staff.staff_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('jtl_staff.staff_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_manage_journal.paper_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_journal_booklet.journal_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_manage_journal.journal_id', 'LIKE', "%{$search_fill}%")
    //                 ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%");
    //         });
    //     }
    //     if ($pc_fill != '') {
    //         $lists->where('et_journal_revision.pc_id', $pc_fill);
    //     }
 
    //     if ($staffs_fill != '') {
    //         $lists->where('et_journal_revision.staff_id', $staffs_fill);
    //     }
 
    //     // return $journal_status_fill;
    //     if ($journal_status_fill != '') {
    //         $lists->where('et_journal_revision.journal_status', $journal_status_fill);
    //     }
 
    //     if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'view_self_revision')) {
    //         // User can only view their own data
    //         $userRole = auth()->user()->role_id;
 
    //         if ($userRole == 33) {
    //             $lists = $lists->where('et_journal_revision.jtl_id', $user_id);
    //         } elseif ($userRole == 34) {
    //             $lists = $lists->where('et_journal_revision.jc_id', $user_id);
    //         } elseif ($userRole === 15) {
    //             $lists = $lists->where('et_journal_revision.pc_id', $user_id);
    //         } elseif ($userRole === 32 || $userRole === 36) {
    //             $lists = $lists->where('et_journal_revision.staff_id', $user_id);
    //         } elseif ($userRole === 42) {
    //             $lists = $lists->where('et_proposal.collection_id', $user_id);
    //         }
    //     } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'global_revision')) {
    //         // User can view all data — no extra filter needed
    //         $lists = $lists;
    //     } else {
    //         // No permission
    //         abort(403, 'Unauthorized');
    //     }
    //     $lists->whereColumn(
    //         'et_journal_revision.sno',
    //         'latest_revision.sno'
    //     );
    //   $lists = $lists->groupBy(
    //             'et_journal_revision.journal_id',
 
    //             'jc_staff.staff_image',
    //             'jc_staff.staff_name',
    //             'latest_revision.jc_id',
    //             'latest_revision.jtl_id',
    //             'jtl_staff.staff_image',
    //             'jtl_staff.staff_name',
 
    //             'et_journal_booklet.journal_name',
    //             'et_manage_journal.paper_name',
    //             'et_manage_journal.journal_id',
    //             'et_product.product_name',
    //             'et_customer_services.sno',
    //             'et_customer_services.created_at',
    //             'et_customer.cus_name',
    //             'et_customer.customer_id',
 
    //             'collection_staff.sno',
    //             'collection_staff.staff_name',
    //             'collection_staff.staff_image'
    //         )->paginate($perpage);
 
    //     foreach ($lists as $list) {
    //         $year = date('Y', strtotime($list->created_at));
    //         $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
    //         $list->formatted_service_id = "SR-{$id}/{$year}";
 
    //         $revisions = DB::table('et_journal_revision')
    //             ->where('et_journal_revision.journal_id', $list->journal_id)
    //             ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_journal_revision.pc_id')
    //             ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_journal_revision.staff_id')
    //              ->leftJoin('et_manage_requirement', function ($join) {
    //                     $join->on('et_manage_requirement.revision_id', '=', 'et_journal_revision.sno')
    //                         ->on('et_manage_requirement.journal_status', '=', 'et_journal_revision.journal_status');
    //                 })
    //             ->select(
    //                 'et_journal_revision.journal_status',
    //                 'et_journal_revision.documents',
    //                 'et_journal_revision.staff_documents',
    //                 'et_journal_revision.comments',
    //                 'et_journal_revision.pc_id',
    //                 'et_journal_revision.staff_id',
    //                 'pc_staff.staff_image as pc_image',
    //                 'pc_staff.staff_name as pc_name',
    //                 'staff.staff_image as staff_image',
    //                 'staff.staff_name as staff_name',
    //                 'et_journal_revision.status',
    //                 'et_journal_revision.sno',
    //                 'et_journal_revision.journal_status',
    //                 'et_journal_revision.created_at',
    //                 'et_manage_requirement.revision_id',
    //                  'et_manage_requirement.journal_status as req_status',
    //                 'et_manage_requirement.requirement_type',
    //                 'et_manage_requirement.status as req_row_status',
    //                 'et_manage_requirement.sno as requirement_id'
    //             );
 
    //         if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'view_self_revision')) {
    //             // User can only view their own data
    //             $userRole = auth()->user()->role_id;
 
    //             if ($userRole == 15) {
    //                 $revisions = $revisions->where('et_journal_revision.pc_id', $user_id);
    //             } elseif ($userRole == 32 || $userRole == 36) {
    //                 $revisions = $revisions->where('et_journal_revision.staff_id', $user_id);
    //             }
    //         } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'global_revision')) {
    //             // User can view all data — no extra filter needed
    //             $revisions = $revisions;
    //         } else {
    //             // No permission
    //             abort(403, 'Unauthorized');
    //         }
 
    //         if ($journal_status_fill != '') {
    //             $revisions->where('et_journal_revision.journal_status', $journal_status_fill);
    //         }
 
    //         if ($pc_fill != '') {
    //             $revisions->where('et_journal_revision.pc_id', $pc_fill);
    //         }
 
    //         if ($staffs_fill != '') {
    //             $revisions->where('et_journal_revision.staff_id', $staffs_fill);
    //         }
 
    //         $revisions = $revisions->distinct('et_journal_revision.sno')->get();
 
    //         foreach ($revisions as $rv) {
    //             $rv->journal_history = DB::table('et_journal_history')
    //                 ->where('journal_id', $list->journal_id)
    //                 ->where('status', $rv->journal_status)
    //                 ->first();
    //         }
 
    //         $list->revisions = $revisions;
    //     }
 
    //     // return $lists;
 
    //     $journalCoordinators = DB::table('et_staff')
    //         ->where('status', 0)
    //         ->where('role_id', 34)
    //         ->get();
 
    //     $journalTeamLead = DB::table('et_staff')
    //         ->where('status', 0)
    //         ->where('role_id', 33)
    //         ->get();
 
    //     $pc = DB::table('et_staff')
    //         ->where('status', 0)
    //         ->where('role_id', 15)
    //         ->get();
 
    //     $productionStaffs = DB::table('et_staff')
    //         ->where('status', 0)
    //         ->whereIn('role_id', [32, 36])
    //         ->get();
 
    //     // ************** MINI DASHBOARD ************* //
    //     $jtlVerification = 0;
    //     $staffAssigned = 0;
    //     $inProgress = 0;
    //     $waitingForDocumentation = 0;
    //     $pcNotAssign = 0;
    //     $staffNotAssign = 0;
    //     $completed = 0;
    //     $jtlPendingVerification = 0;
    //     $pcPendingVerification = 0;
    //     $rework = 0;
 
    //     $jtlVerification = DB::table('et_journal_revision')
    //         ->where('status', 0)
    //         ->count();
 
    //     $pcNotAssign = DB::table('et_journal_revision')
    //         ->where('status', 1)
    //         ->whereNotNull('documents')
    //         ->where('documents', '!=', '')
    //         ->count();
 
    //     $staffNotAssign = DB::table('et_journal_revision')
    //         ->where('status', 3)
    //         ->count();
 
    //     $staffAssigned = DB::table('et_journal_revision')
    //         ->where('status', 4)
    //         ->count();
 
    //     $inProgress = DB::table('et_journal_revision')
    //         ->where('status', 5)
    //         ->count();
 
    //     $waitingForDocumentation = DB::table('et_journal_revision')
    //         ->where('status', 6)
    //         ->count();
 
    //     $pcPendingVerification = DB::table('et_journal_revision')
    //         ->where('status', 7)
    //         ->count();
 
    //     $jtlPendingVerification = DB::table('et_journal_revision')
    //         ->where('status', 8)
    //         ->count();
 
    //     $completed = DB::table('et_journal_revision')
    //         ->where('status', 9)
    //         ->count();
 
    //     $rework = DB::table('et_journal_revision')
    //         ->where('status', '>', 9)
    //         ->count();
    //         // dd($lists->first()->revisions);
    // // return $lists;
    //     return view('content.revision_management.manage_revision.list', [
    //         'lists' => $lists,
    //         'perpage' => $perpage,
    //         'search_fill' => $search_fill,
    //         'journal_coordinators' => $journalCoordinators,
    //         'journal_coordinator_fill' => $journal_coordinator_fill,
    //         'journal_team_lead' => $journalTeamLead,
    //         'journal_team_lead_fill' => $journal_team_lead_fill,
    //         'journalStatusFill' => $journal_status_fill,
    //         'pc' => $pc,
    //         'pc_fill' => $pc_fill,
    //         'productionStaffs' => $productionStaffs,
    //         'staffs_fill' => $staffs_fill,
    //         'jtlVerification' => $jtlVerification,
    //         'staffAssigned' => $staffAssigned,
    //         'inProgress' => $inProgress,
    //         'waitingForDocumentation' => $waitingForDocumentation,
    //         'pcNotAssign' => $pcNotAssign,
    //         'staffNotAssign' => $staffNotAssign,
    //         'completed' => $completed,
    //         'jtlPendingVerification' => $jtlPendingVerification,
    //         'pcPendingVerification' => $pcPendingVerification,
    //         'rework' => $rework,
    //         'status_fill' => $status_fill,
    //     ]);
    //       } catch (\Exception $e) {
 
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => $e->getMessage(),
    //         ], 500);
    //     }
    // }
 
//  public function index(Request $request)
//     {
 
//     try{
//         $user_id = $request->user()->user_id;
//         $page = $request->input('page', 1);
//         $perpage = (int) $request->input('sorting_filter', 25);
//         $offset = ($page - 1) * $perpage;
 
//         $search_fill = $request->search_fill ?? '';
//         $status_fill = $request->status ?? '';
//         $journal_coordinator_fill = $request->journal_coordinator_fill ?? '';
//         $journal_team_lead_fill = $request->journal_team_lead_fill ?? '';
//         $journal_status_fill = $request->journal_status_fill ?? '';
//         $pc_fill = $request->pc_fill ?? '';
//         $staffs_fill = $request->staffs_fill ?? '';
 
//         $latestRevision = DB::table('et_journal_revision as jr')
//             ->select(
//                 'jr.journal_id',
//                 'jr.jc_id',
//                 'jr.jtl_id',
//                 'jr.sno'
//             )
//             ->whereRaw('jr.sno = (
//                 SELECT MAX(jr2.sno)
//                 FROM et_journal_revision as jr2
//                 WHERE jr2.journal_id = jr.journal_id
//             )');
//         $lists = DB::table('et_journal_revision')
//             ->leftJoinSub($latestRevision, 'latest_revision', function ($join) {
//                     $join->on(
//                         'latest_revision.journal_id',
//                         '=',
//                         'et_journal_revision.journal_id'
//                     );
//                 })
//             ->leftJoin('et_staff as jc_staff', 'jc_staff.sno', '=', 'latest_revision.jc_id')
//             ->leftJoin('et_staff as jtl_staff', 'jtl_staff.sno', '=', 'latest_revision.jtl_id')
//             ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
//             ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
//             ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
//             ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_revision.customer_id')
//             ->leftJoin('et_proposal','et_proposal.sno','=','et_customer_services.proposal_id')
//             ->leftJoin('et_staff as collection_staff','collection_staff.sno','=','et_proposal.collection_id')
//             ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
//             ->select(
//                 'jc_staff.staff_image as jc_staff_image',
//                 'jc_staff.staff_name as jc_staff_name',
 
//                 'et_journal_revision.journal_id',
 
//                 'latest_revision.jc_id as jc_id',
//                 'latest_revision.jtl_id as jtl_id',
 
//                 'jtl_staff.staff_image as jtl_staff_image',
//                 'jtl_staff.staff_name as jtl_staff_name',
//                 'et_journal_booklet.journal_name',
//                 'et_manage_journal.paper_name',
//                 'et_manage_journal.journal_id as manage_journal_id',
//                 'et_product.product_name',
//                 'et_customer_services.sno',
//                 'et_customer_services.created_at',
//                 'et_customer.cus_name',
//                 'et_customer.customer_id',
//                 'collection_staff.sno as collection_id',
//                 'collection_staff.staff_name as collection_staff_name',
//                 'collection_staff.staff_image as collection_staff_image',
//             );
 
//         if ($status_fill != '') {
//             $lists->where('et_journal_revision.status', $status_fill);
//         }
 
//         if ($journal_coordinator_fill != '') {
//           $lists->where('latest_revision.jc_id',$journal_coordinator_fill);
//         }
 
//         if ($journal_team_lead_fill != '') {
//             $lists->where('et_journal_revision.jtl_id', $journal_team_lead_fill);
//         }
 
//         if (! empty($search_fill)) {
//             $lists->where(function ($query) use ($search_fill) {
//                 $query->where('jc_staff.staff_name', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('jtl_staff.staff_name', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_manage_journal.paper_name', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_journal_booklet.journal_name', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_manage_journal.journal_id', 'LIKE', "%{$search_fill}%")
//                     ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%");
//             });
//         }
//         if ($pc_fill != '') {
//             $lists->where('et_journal_revision.pc_id', $pc_fill);
//         }
 
//         if ($staffs_fill != '') {
//             $lists->where('et_journal_revision.staff_id', $staffs_fill);
//         }
 
//         // return $journal_status_fill;
//         if ($journal_status_fill != '') {
//             $lists->where('et_journal_revision.journal_status', $journal_status_fill);
//         }
 
//         if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'view_self_revision')) {
//             // User can only view their own data
//             $userRole = auth()->user()->role_id;
 
//             if ($userRole == 33) {
//                 $lists = $lists->where('latest_revision.jtl_id',$user_id);
//             } elseif ($userRole == 34) {
//                 $lists = $lists->where('et_journal_revision.jc_id', $user_id);
//             } elseif ($userRole === 15) {
//                 $lists = $lists->where('et_journal_revision.pc_id', $user_id);
//             } elseif ($userRole === 32 || $userRole === 36) {
//                 $lists = $lists->where('et_journal_revision.staff_id', $user_id);
//             } elseif ($userRole === 42) {
//                 $lists = $lists->where('et_proposal.collection_id', $user_id);
//             }
//         } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'global_revision')) {
//             // User can view all data — no extra filter needed
//             $lists = $lists;
//         } else {
//             // No permission
//             abort(403, 'Unauthorized');
//         }
//         $lists->whereColumn(
//             'et_journal_revision.sno',
//             'latest_revision.sno'
//         );
//       $lists = $lists->groupBy(
//                 'et_journal_revision.journal_id',
 
//                 'jc_staff.staff_image',
//                 'jc_staff.staff_name',
//                 'latest_revision.jc_id',
//                 'latest_revision.jtl_id',
//                 'jtl_staff.staff_image',
//                 'jtl_staff.staff_name',
 
//                 'et_journal_booklet.journal_name',
//                 'et_manage_journal.paper_name',
//                 'et_manage_journal.journal_id',
//                 'et_product.product_name',
//                 'et_customer_services.sno',
//                 'et_customer_services.created_at',
//                 'et_customer.cus_name',
//                 'et_customer.customer_id',
 
//                 'collection_staff.sno',
//                 'collection_staff.staff_name',
//                 'collection_staff.staff_image'
//             )->paginate($perpage);
 
//         foreach ($lists as $list) {
//             $year = date('Y', strtotime($list->created_at));
//             $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
//             $list->formatted_service_id = "SR-{$id}/{$year}";
 
//             $revisions = DB::table('et_journal_revision')
//                 ->where('et_journal_revision.journal_id', $list->journal_id)
//                 ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_journal_revision.pc_id')
//                 ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_journal_revision.staff_id')
//                  ->leftJoin('et_manage_requirement', function ($join) {
//                         $join->on('et_manage_requirement.revision_id', '=', 'et_journal_revision.sno')
//                             ->on('et_manage_requirement.journal_status', '=', 'et_journal_revision.journal_status');
//                     })
//                 ->select(
//                     'et_journal_revision.journal_status',
//                     'et_journal_revision.documents',
//                     'et_journal_revision.staff_documents',
//                     'et_journal_revision.comments',
//                     'et_journal_revision.pc_id',
//                     'et_journal_revision.staff_id',
//                     'pc_staff.staff_image as pc_image',
//                     'pc_staff.staff_name as pc_name',
//                     'staff.staff_image as staff_image',
//                     'staff.staff_name as staff_name',
//                     'et_journal_revision.status',
//                     'et_journal_revision.sno',
//                     'et_journal_revision.journal_status',
//                     'et_journal_revision.created_at',
//                     'et_manage_requirement.revision_id',
//                      'et_manage_requirement.journal_status as req_status',
//                     'et_manage_requirement.requirement_type',
//                     'et_manage_requirement.status as req_row_status',
//                     'et_manage_requirement.sno as requirement_id'
//                 );
 
//             if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'view_self_revision')) {
//                 // User can only view their own data
//                 $userRole = auth()->user()->role_id;
 
//                 if ($userRole == 15) {
//                     $revisions = $revisions->where('et_journal_revision.pc_id', $user_id);
//                 } elseif ($userRole == 32 || $userRole == 36) {
//                     $revisions = $revisions->where('et_journal_revision.staff_id', $user_id);
//                 }
//             } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'global_revision')) {
//                 // User can view all data — no extra filter needed
//                 $revisions = $revisions;
//             } else {
//                 // No permission
//                 abort(403, 'Unauthorized');
//             }
 
//             if ($journal_status_fill != '') {
//                 $revisions->where('et_journal_revision.journal_status', $journal_status_fill);
//             }
 
//             if ($pc_fill != '') {
//                 $revisions->where('et_journal_revision.pc_id', $pc_fill);
//             }
 
//             if ($staffs_fill != '') {
//                 $revisions->where('et_journal_revision.staff_id', $staffs_fill);
//             }
 
//             $revisions = $revisions->distinct('et_journal_revision.sno')->get();
 
//             foreach ($revisions as $rv) {
//                 $rv->journal_history = DB::table('et_journal_history')
//                     ->where('journal_id', $list->journal_id)
//                     ->where('status', $rv->journal_status)
//                     ->first();
//             }
 
//             $list->revisions = $revisions;
//         }
 
//         // return $lists;
 
//         $journalCoordinators = DB::table('et_staff')
//             ->where('status', 0)
//             ->where('role_id', 34)
//             ->get();
 
//         $journalTeamLead = DB::table('et_staff')
//             ->where('status', 0)
//             ->where('role_id', 33)
//             ->get();
 
//         $pc = DB::table('et_staff')
//             ->where('status', 0)
//             ->where('role_id', 15)
//             ->get();
 
//         $productionStaffs = DB::table('et_staff')
//             ->where('status', 0)
//             ->whereIn('role_id', [32, 36])
//             ->get();
 
//       // ************** MINI DASHBOARD ************* //
 
//     $dashboardBase = DB::table('et_journal_revision')
//         ->joinSub($latestRevision, 'latest_revision', function ($join) {
//             $join->on(
//                 'latest_revision.sno',
//                 '=',
//                 'et_journal_revision.sno'
//             );
//         })
//         ->leftJoin('et_proposal', 'et_proposal.sno', '=', 'et_journal_revision.service_id');
//         if (auth()->user()->hasPermissionradio(
//             'Journal Management',
//             'Manage Revision',
//             'view_self_revision'
//         )) {
 
//             $userRole = auth()->user()->role_id;
 
//             if ($userRole == 33) {
 
//                 $dashboardBase->where(
//                     'et_journal_revision.jtl_id',
//                     $user_id
//                 );
 
//             } elseif ($userRole == 34) {
 
//                 $dashboardBase->where(
//                     'et_journal_revision.jc_id',
//                     $user_id
//                 );
 
//             } elseif ($userRole == 15) {
 
//                 $dashboardBase->where(
//                     'et_journal_revision.pc_id',
//                     $user_id
//                 );
 
//             } elseif ($userRole == 32 || $userRole == 36) {
 
//                 $dashboardBase->where(
//                     'et_journal_revision.staff_id',
//                     $user_id
//                 );
 
//             } elseif ($userRole == 42) {
 
//                 $dashboardBase->where(
//                     'et_proposal.collection_id',
//                     $user_id
//                 );
//             }
 
//         } elseif (auth()->user()->hasPermissionradio(
//             'Journal Management',
//             'Manage Revision',
//             'global_revision'
//         )) {
 
//             // No additional restriction
 
//         } else {
 
//             abort(403, 'Unauthorized');
//         }
//         $jtlVerification = 0;
//         $staffAssigned = 0;
//         $inProgress = 0;
//         $waitingForDocumentation = 0;
//         $pcNotAssign = 0;
//         $staffNotAssign = 0;
//         $completed = 0;
//         $jtlPendingVerification = 0;
//         $pcPendingVerification = 0;
//         $rework = 0;
 
//       $jtlVerification = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 0)
//     ->count();
 
// $pcNotAssign = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 1)
//     ->whereNotNull('et_journal_revision.documents')
//     ->where('et_journal_revision.documents', '!=', '')
//     ->count();
 
// $staffNotAssign = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 3)
//     ->count();
 
// $staffAssigned = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 4)
//     ->count();
 
// $inProgress = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 5)
//     ->count();
 
// $waitingForDocumentation = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 6)
//     ->count();
 
// $pcPendingVerification = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 7)
//     ->count();
 
// $jtlPendingVerification = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 8)
//     ->count();
 
// $completed = (clone $dashboardBase)
//     ->where('et_journal_revision.status', 9)
//     ->count();
 
// $rework = (clone $dashboardBase)
//     ->where('et_journal_revision.status', '>', 9)
//     ->count();
//             // dd($lists->first()->revisions);
//     // return $lists;
//         return view('content.revision_management.manage_revision.list', [
//             'lists' => $lists,
//             'perpage' => $perpage,
//             'search_fill' => $search_fill,
//             'journal_coordinators' => $journalCoordinators,
//             'journal_coordinator_fill' => $journal_coordinator_fill,
//             'journal_team_lead' => $journalTeamLead,
//             'journal_team_lead_fill' => $journal_team_lead_fill,
//             'journalStatusFill' => $journal_status_fill,
//             'pc' => $pc,
//             'pc_fill' => $pc_fill,
//             'productionStaffs' => $productionStaffs,
//             'staffs_fill' => $staffs_fill,
//             'jtlVerification' => $jtlVerification,
//             'staffAssigned' => $staffAssigned,
//             'inProgress' => $inProgress,
//             'waitingForDocumentation' => $waitingForDocumentation,
//             'pcNotAssign' => $pcNotAssign,
//             'staffNotAssign' => $staffNotAssign,
//             'completed' => $completed,
//             'jtlPendingVerification' => $jtlPendingVerification,
//             'pcPendingVerification' => $pcPendingVerification,
//             'rework' => $rework,
//             'status_fill' => $status_fill,
//         ]);
//           } catch (\Exception $e) {
 
//             return response()->json([
//                 'status' => 'error',
//                 'message' => $e->getMessage(),
//             ], 500);
//         }
//     }

 public function index(Request $request)
    {
 
    try{
        $user_id = $request->user()->user_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
 
        $search_fill = $request->search_fill ?? '';
        $status_fill = $request->status ?? '';
        $journal_coordinator_fill = $request->journal_coordinator_fill ?? '';
        $journal_team_lead_fill = $request->journal_team_lead_fill ?? '';
        $journal_status_fill = $request->journal_status_fill ?? '';
        $pc_fill = $request->pc_fill ?? '';
        $staffs_fill = $request->staffs_fill ?? '';
 
        $latestRevision = DB::table('et_journal_revision as jr')
            ->select(
                'jr.journal_id',
                'jr.jc_id',
                'jr.jtl_id',
                'jr.sno'
            )
            ->whereRaw('jr.sno = (
                SELECT MAX(jr2.sno)
                FROM et_journal_revision as jr2
                WHERE jr2.journal_id = jr.journal_id
            )');
        $lists = DB::table('et_journal_revision')
            ->leftJoinSub($latestRevision, 'latest_revision', function ($join) {
                    $join->on(
                        'latest_revision.journal_id',
                        '=',
                        'et_journal_revision.journal_id'
                    );
                })
            ->leftJoin('et_staff as jc_staff', 'jc_staff.sno', '=', 'latest_revision.jc_id')
            ->leftJoin('et_staff as jtl_staff', 'jtl_staff.sno', '=', 'latest_revision.jtl_id')
            ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_revision.customer_id')
            ->leftJoin('et_proposal','et_proposal.sno','=','et_customer_services.proposal_id')
            ->leftJoin('et_staff as collection_staff','collection_staff.sno','=','et_proposal.collection_id')
            ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
            ->select(
                'jc_staff.staff_image as jc_staff_image',
                'jc_staff.staff_name as jc_staff_name',
 
                'et_journal_revision.journal_id',
                'et_journal_revision.staff_id as production_staff_id',
 
                'latest_revision.jc_id as jc_id',
                'latest_revision.jtl_id as jtl_id',
 
                'jtl_staff.staff_image as jtl_staff_image',
                'jtl_staff.staff_name as jtl_staff_name',
                'et_journal_booklet.journal_name',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id as manage_journal_id',
                'et_product.product_name',
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'collection_staff.sno as collection_id',
                'collection_staff.staff_name as collection_staff_name',
                'collection_staff.staff_image as collection_staff_image',
            );
 
        if ($status_fill != '') {
            $lists->where('et_journal_revision.status', $status_fill);
        }
 
        if ($journal_coordinator_fill != '') {
           $lists->where('latest_revision.jc_id',$journal_coordinator_fill);
        }
 
        if ($journal_team_lead_fill != '') {
            $lists->where('et_journal_revision.jtl_id', $journal_team_lead_fill);
        }
 
        if (! empty($search_fill)) {
            $lists->where(function ($query) use ($search_fill) {
                $query->where('jc_staff.staff_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('jtl_staff.staff_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_journal.paper_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_journal_booklet.journal_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_journal.journal_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%");
            });
        }
        if ($pc_fill != '') {
            $lists->where('et_journal_revision.pc_id', $pc_fill);
        }
 
        if ($staffs_fill != '') {
            $lists->where('et_journal_revision.staff_id', $staffs_fill);
        }
 
        // return $journal_status_fill;
        if ($journal_status_fill != '') {
            $lists->where('et_journal_revision.journal_status', $journal_status_fill);
        }
 
        if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'view_self_revision')) {
            // User can only view their own data
            $userRole = auth()->user()->role_id;
            
            if ($userRole == 33) {
                $lists = $lists->where('latest_revision.jtl_id',$user_id);
            } elseif ($userRole == 34) {
                $lists = $lists->where('et_journal_revision.jc_id', $user_id);
            } elseif ($userRole === 15) {
                $lists = $lists->where('et_journal_revision.pc_id', $user_id);
            } elseif ($userRole === 32 || $userRole === 36) {
                // $lists = $lists->where('et_journal_revision.staff_id', $user_id);
                $lists->where(function ($query) use ($user_id) {
                    $query->where('et_journal_revision.staff_id', (string) $user_id)
                        ->orWhereJsonContains(
                            'et_journal_revision.staff_id',
                            (string) $user_id
                        )
                        ->orWhereJsonContains(
                            'et_journal_revision.staff_id',
                            (int) $user_id
                        );
                });
                
            } elseif ($userRole === 42) {
                $lists = $lists->where('et_proposal.collection_id', $user_id);
               
            }
            return "end";
        } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'global_revision')) {
            // User can view all data — no extra filter needed
            $lists = $lists;
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $lists->whereColumn(
            'et_journal_revision.sno',
            'latest_revision.sno'
        );
       $lists = $lists->groupBy(
                'et_journal_revision.journal_id',
 
                'jc_staff.staff_image',
                'jc_staff.staff_name',
                'latest_revision.jc_id',
                'latest_revision.jtl_id',
                'jtl_staff.staff_image',
                'jtl_staff.staff_name',
 
                'et_journal_booklet.journal_name',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id',
                'et_product.product_name',
                'et_customer_services.sno',
                'et_customer_services.created_at',
                'et_customer.cus_name',
                'et_customer.customer_id',
 
                'collection_staff.sno',
                'collection_staff.staff_name',
                'collection_staff.staff_image'
            )->paginate($perpage);
 
        foreach ($lists as $list) {
            $year = date('Y', strtotime($list->created_at));
            $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
            $list->formatted_service_id = "SR-{$id}/{$year}";
 
            $revisions = DB::table('et_journal_revision')
                ->where('et_journal_revision.journal_id', $list->journal_id)
                ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_journal_revision.pc_id')
                ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_journal_revision.staff_id')
                 ->leftJoin('et_manage_requirement', function ($join) {
                        $join->on('et_manage_requirement.revision_id', '=', 'et_journal_revision.sno')
                            ->on('et_manage_requirement.journal_status', '=', 'et_journal_revision.journal_status');
                    })
                ->select(
                    'et_journal_revision.journal_status',
                    'et_journal_revision.documents',
                    'et_journal_revision.staff_documents',
                    'et_journal_revision.comments',
                    'et_journal_revision.pc_id',
                    'et_journal_revision.staff_id',
                    'pc_staff.staff_image as pc_image',
                    'pc_staff.staff_name as pc_name',
                    'staff.staff_image as staff_image',
                    'staff.staff_name as staff_name',
                    'et_journal_revision.status',
                    'et_journal_revision.sno',
                    'et_journal_revision.journal_status',
                    'et_journal_revision.created_at',
                    'et_manage_requirement.revision_id',
                     'et_manage_requirement.journal_status as req_status',
                    'et_manage_requirement.requirement_type',
                    'et_manage_requirement.status as req_row_status',
                    'et_manage_requirement.sno as requirement_id'
                );
 
            if (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'view_self_revision')) {
                // User can only view their own data
                $userRole = auth()->user()->role_id;
 
                if ($userRole == 15) {
                    $revisions = $revisions->where('et_journal_revision.pc_id', $user_id);
                } elseif ($userRole == 32 || $userRole == 36) {
                    $revisions = $revisions->where('et_journal_revision.staff_id', $user_id);
                }
            } elseif (auth()->user()->hasPermissionradio('Journal Management', 'Manage Revision', 'global_revision')) {
                // User can view all data — no extra filter needed
                $revisions = $revisions;
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
 
            if ($journal_status_fill != '') {
                $revisions->where('et_journal_revision.journal_status', $journal_status_fill);
            }
 
            if ($pc_fill != '') {
                $revisions->where('et_journal_revision.pc_id', $pc_fill);
            }
 
            if ($staffs_fill != '') {
                $revisions->where('et_journal_revision.staff_id', $staffs_fill);
            }
 
            $revisions = $revisions->distinct('et_journal_revision.sno')->get();
 
            foreach ($revisions as $rv) {
                $rv->journal_history = DB::table('et_journal_history')
                    ->where('journal_id', $list->journal_id)
                    ->where('status', $rv->journal_status)
                    ->first();
             if (is_null($rv->staff_id) || $rv->staff_id === '') {
 
                $staffIds = [];
 
            } else {
 
                $staffIds = json_decode($rv->staff_id, true);
 
                // Old record: staff_id = 12
                if (!is_array($staffIds)) {
                    $staffIds = [$rv->staff_id];
                }
 
                // Convert to integers and remove invalid values
                $staffIds = array_values(array_filter(
                    array_map('intval', $staffIds),
                    fn ($id) => $id > 0
                ));
            }
 
            // If no staff assigned
            if (empty($staffIds)) {
 
                $rv->staff_details = collect();
 
            } else {
 
                $rv->staff_details = DB::table('et_staff')
                    ->whereIn('sno', $staffIds)
                    ->select(
                        'sno',
                        'staff_name',
                        'staff_image',
                        'gender'
                    )
                    ->get();
            }
            }
 
            $list->revisions = $revisions;
        }
 
        // return $lists;
 
        $journalCoordinators = DB::table('et_staff')
            ->where('status', 0)
            ->where('role_id', 34)
            ->get();
 
        $journalTeamLead = DB::table('et_staff')
            ->where('status', 0)
            ->where('role_id', 33)
            ->get();
 
        $pc = DB::table('et_staff')
            ->where('status', 0)
            ->where('role_id', 15)
            ->get();
 
        $productionStaffs = DB::table('et_staff')
            ->where('status', 0)
            ->whereIn('role_id', [32, 36])
            ->get();
 
       // ************** MINI DASHBOARD ************* //
 
    $dashboardBase = DB::table('et_journal_revision')
        ->joinSub($latestRevision, 'latest_revision', function ($join) {
            $join->on(
                'latest_revision.sno',
                '=',
                'et_journal_revision.sno'
            );
        })
        ->leftJoin('et_proposal', 'et_proposal.sno', '=', 'et_journal_revision.service_id');
        if (auth()->user()->hasPermissionradio(
            'Journal Management',
            'Manage Revision',
            'view_self_revision'
        )) {
 
            $userRole = auth()->user()->role_id;
 
            if ($userRole == 33) {
 
                $dashboardBase->where(
                    'et_journal_revision.jtl_id',
                    $user_id
                );
 
            } elseif ($userRole == 34) {
 
                $dashboardBase->where(
                    'et_journal_revision.jc_id',
                    $user_id
                );
 
            } elseif ($userRole == 15) {
 
                $dashboardBase->where(
                    'et_journal_revision.pc_id',
                    $user_id
                );
 
            } elseif ($userRole == 32 || $userRole == 36) {
 
                $dashboardBase->where(
                    'et_journal_revision.staff_id',
                    $user_id
                );
 
            } elseif ($userRole == 42) {
 
                $dashboardBase->where(
                    'et_proposal.collection_id',
                    $user_id
                );
            }
 
        } elseif (auth()->user()->hasPermissionradio(
            'Journal Management',
            'Manage Revision',
            'global_revision'
        )) {
 
            // No additional restriction
 
        } else {
 
            abort(403, 'Unauthorized');
        }
        $jtlVerification = 0;
        $staffAssigned = 0;
        $inProgress = 0;
        $waitingForDocumentation = 0;
        $pcNotAssign = 0;
        $staffNotAssign = 0;
        $completed = 0;
        $jtlPendingVerification = 0;
        $pcPendingVerification = 0;
        $rework = 0;
 
       $jtlVerification = (clone $dashboardBase)
    ->where('et_journal_revision.status', 0)
    ->count();
 
$pcNotAssign = (clone $dashboardBase)
    ->where('et_journal_revision.status', 1)
    ->whereNotNull('et_journal_revision.documents')
    ->where('et_journal_revision.documents', '!=', '')
    ->count();
 
$staffNotAssign = (clone $dashboardBase)
    ->where('et_journal_revision.status', 3)
    ->count();
 
$staffAssigned = (clone $dashboardBase)
    ->where('et_journal_revision.status', 4)
    ->count();
 
$inProgress = (clone $dashboardBase)
    ->where('et_journal_revision.status', 5)
    ->count();
 
$waitingForDocumentation = (clone $dashboardBase)
    ->where('et_journal_revision.status', 6)
    ->count();
 
$pcPendingVerification = (clone $dashboardBase)
    ->where('et_journal_revision.status', 7)
    ->count();
 
$jtlPendingVerification = (clone $dashboardBase)
    ->where('et_journal_revision.status', 8)
    ->count();
 
$completed = (clone $dashboardBase)
    ->where('et_journal_revision.status', 9)
    ->count();
 
$rework = (clone $dashboardBase)
    ->where('et_journal_revision.status', '>', 9)
    ->count();
            // dd($lists->first()->revisions);
    // return $lists;
        return view('content.revision_management.manage_revision.list', [
            'lists' => $lists,
            'perpage' => $perpage,
            'search_fill' => $search_fill,
            'journal_coordinators' => $journalCoordinators,
            'journal_coordinator_fill' => $journal_coordinator_fill,
            'journal_team_lead' => $journalTeamLead,
            'journal_team_lead_fill' => $journal_team_lead_fill,
            'journalStatusFill' => $journal_status_fill,
            'pc' => $pc,
            'pc_fill' => $pc_fill,
            'productionStaffs' => $productionStaffs,
            'staffs_fill' => $staffs_fill,
            'jtlVerification' => $jtlVerification,
            'staffAssigned' => $staffAssigned,
            'inProgress' => $inProgress,
            'waitingForDocumentation' => $waitingForDocumentation,
            'pcNotAssign' => $pcNotAssign,
            'staffNotAssign' => $staffNotAssign,
            'completed' => $completed,
            'jtlPendingVerification' => $jtlPendingVerification,
            'pcPendingVerification' => $pcPendingVerification,
            'rework' => $rework,
            'status_fill' => $status_fill,
        ]);
          } catch (\Exception $e) {
 
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage(),
            ], 500);
        }
    }
 
    public function JTLVerificationDataFetch($id)
    {
        $data = DB::table('et_journal_revision')
            ->where('et_journal_revision.sno', $id)
            ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
            ->leftJoin('et_staff as jc_staff', 'jc_staff.sno', '=', 'et_journal_revision.jc_id')
            ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_journal_revision.pc_id')
            ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_journal_revision.staff_id')
            ->leftJoin('et_product', 'et_customer_services.product_id', 'et_product.sno')
            ->select(
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id',
                'et_journal_revision.journal_status',
                'et_journal_revision.comments',
                'et_product.product_name',
                'jc_staff.staff_name as jc_name',
                'staff.staff_name as staff_name',
                'pc.staff_name as pc_name',
                'et_customer_services.created_at',
                'et_customer_services.sno'
            )
            ->where('et_journal_revision.status', '!=', 2)
            ->first();

        $year = date('Y', strtotime($data->created_at));
        $id = str_pad($data->sno, 5, '0', STR_PAD_LEFT);
        $data->formatted_service_id = "SR-{$id}/{$year}";

        return response([
            'status' => 200,
            'message' => 'Data fetched successfully!',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function verifyJTL($id, Request $request)
    {
        $user_id = $request->user()->user_id;

        $query = DB::table('et_journal_revision')
            ->where('sno', $id)
            ->where('status', '!=', 2);

        $data = $query->first();

        if (! $data) {
            return response([
                'status' => 404,
                'message' => 'Record not found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $query->update([
            'status' => 1,
            'updated_by' => $user_id,
        ]);

        return response([
            'status' => 200,
            'message' => 'Data updated successfully!',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function assignPC($id, Request $request)
    {
        $user_id = $request->user()->user_id;
        $pc_id = $request->pc_id;

        $query = DB::table('et_journal_revision')
            ->where('sno', $id)
            ->where('status', '!=', 2);

        $data = $query->first();

        if (! $data) {
            return response([
                'status' => 404,
                'message' => 'Record not found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $query->update([
            'pc_id' => $pc_id,
            'status' => 3,
            'updated_by' => $user_id,
        ]);

        return response([
            'status' => 200,
            'message' => 'Data updated successfully!',
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    // public function assignRevisionStaff(Request $request)
    // {
    //     $request->validate([
    //         'id' => 'required|integer',
    //         'staff_id' => 'required|integer',
    //     ]);

    //     $id = $request->id;
    //     $staffId = $request->staff_id;
    //     $branch_id = $request->user()->branch_id;
    //     $user_id = $request->user()->user_id;
    //     $task_date = $request->task_date;
    //     $task_hours = $request->task_hours;

    //     $query = DB::table('et_journal_revision')
    //         ->where('sno', $id)
    //         ->where('status', '!=', 2);

    //     $data = $query->first();

    //     if (! $data) {
    //         return response()->json([
    //             'status' => 'error',
    //             'message' => 'Record Not Found!',
    //         ]);
    //     }

    //     DB::beginTransaction();

    //     try {
    //         $updated = $query->update([
    //             'staff_id' => $staffId,
    //             'status' => 4,
    //             'updated_by' => $user_id,
    //         ]);

    //         if ($updated > 0) {
    //             $task = new DailyTaskModel;
    //             $task->service_id = $data->service_id;
    //             $task->task_id = $data->sno;
    //             $task->staff_id = $staffId;
    //             $task->task_date = $task_date;
    //             $task->task_hours = $task_hours;
    //             $task->is_journal = 1;
    //             $task->created_by = $user_id;
    //             $task->updated_by = $user_id;
    //             $task->save();

    //             $journal = DB::table('et_manage_journal')->where('sno', $data->journal_id)->first();
    //             $customer = DB::table('et_customer')->where('sno', $journal->customer_id)->first();

    //             // Notification
    //             $notificationData = [
    //                 'branch_id' => $branch_id,
    //                 'notification_content' => '<div class="d-flex align-items-center">
    //                                         <div class="me-3">
    //                                             <span class="badge bg-info">
    //                                                 <i class="mdi mdi-calendar-sync fs-3 "></i>
    //                                             </span>
    //                                         </div>
    //                                         <div class="me-2">
    //                                             <a href="javascript:;" class="fs-7 text-primary fw-bold">Revision Task Assigned</a>
    //                                             <div class="text-secondary fs-8  fw-bold">'.$customer->cus_name.'</div>
    //                                             <div class="text-secondary fs-8  fw-bold">'.$customer->customer_id.'</div>
    //                                         </div>
    //                                     </div>',
    //                 'who' => $task->staff_id,
    //                 'created_by' => $user_id,
    //                 'updated_by' => $user_id,
    //                 'status' => 0,
    //             ];
    //             $notificationtype = 'Requirement';
    //             $newNotification = new \App\Helpers\Helpers;
    //             $newNotification->createNotificationAssessment($notificationData, $notificationtype, $task->staff_id);
    //         }

    //         DB::commit();

    //         return response()->json([
    //             'status' => 'success',
    //             'message' => 'Staff Assigned Successfully!',
    //         ]);
    //     } catch (\Exception $e) {
    //         DB::rollBack();

    //         return response()->json([
    //             'status' => 'error',
    //             'message' => 'Something went wrong!',
    //         ], 500);
    //     }
    // }

     public function assignRevisionStaff(Request $request)
    {
        $request->validate([
            'id' => 'required|integer',
            'staff_id' => 'required|string',
        ]);
 
        $id = $request->id;
        $raw_staff_ids= $request->staff_id;
       
        $staff_array = array_map('trim', explode(',', $raw_staff_ids));
       
        $staffId = json_encode($staff_array);
       
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $task_date = $request->task_date;
        $task_hours = $request->task_hours;
 
        $query = DB::table('et_journal_revision')
            ->where('sno', $id)
            ->where('status', '!=', 2);
 
        $data = $query->first();
 
        if (! $data) {
            return response()->json([
                'status' => 'error',
                'message' => 'Record Not Found!',
            ]);
        }
 
        DB::beginTransaction();
 
        try {
            $updated = $query->update([
                'staff_id' => $staffId,
                'status' => 4,
                'updated_by' => $user_id,
            ]);
 
            if ($updated > 0) {
                $task = new DailyTaskModel;
                $task->service_id = $data->service_id;
                $task->task_id = $data->sno;
                $task->staff_id = $staffId;
                $task->task_date = $task_date;
                $task->task_hours = $task_hours;
                $task->is_journal = 1;
                $task->created_by = $user_id;
                $task->updated_by = $user_id;
                $task->save();
 
                $journal = DB::table('et_manage_journal')->where('sno', $data->journal_id)->first();
                $customer = DB::table('et_customer')->where('sno', $journal->customer_id)->first();
 
                // Notification
                $notificationData = [
                    'branch_id' => $branch_id,
                    'notification_content' => '<div class="d-flex align-items-center">
                                            <div class="me-3">
                                                <span class="badge bg-info">
                                                    <i class="mdi mdi-calendar-sync fs-3 "></i>
                                                </span>
                                            </div>
                                            <div class="me-2">
                                                <a href="javascript:;" class="fs-7 text-primary fw-bold">Revision Task Assigned</a>
                                                <div class="text-secondary fs-8  fw-bold">'.$customer->cus_name.'</div>
                                                <div class="text-secondary fs-8  fw-bold">'.$customer->customer_id.'</div>
                                            </div>
                                        </div>',
                    'who' => $task->staff_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'status' => 0,
                ];
                $notificationtype = 'Requirement';
                $newNotification = new \App\Helpers\Helpers;
                // $newNotification->createNotificationAssessment($notificationData, $notificationtype, $task->staff_id);
            }
 
            DB::commit();
 
            return response()->json([
                'status' => 'success',
                'message' => 'Staff Assigned Successfully!',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
 
            return response()->json([
                'status' => 'error',
                'message' => 'Something went wrong!',
            ], 500);
        }
    }
 
 public function reassignRevisionStaff(Request $request)
    {
        $request->validate([
            'id' => 'required|integer',
            'staff_id' => 'required|string',
        ]);
 
        $id = $request->id;
        $raw_staff_ids= $request->staff_id;
       
        $staff_array = array_map('trim', explode(',', $raw_staff_ids));
       
        $staffId = json_encode($staff_array);
       
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
       
 
        $query = DB::table('et_journal_revision')
            ->where('sno', $id)
            ->where('status', '!=', 2);
 
        $data = $query->first();
 
        if (! $data) {
            return response()->json([
                'status' => 'error',
                'message' => 'Record Not Found!',
            ]);
        }
 
        DB::beginTransaction();
 
        try {
            $updated = $query->update([
                'staff_id' => $staffId,
                'status' => 4,
                'updated_by' => $user_id,
            ]);
 
            if ($updated > 0) {
                $task = new DailyTaskModel;
                $task->service_id = $data->service_id;
                $task->task_id = $data->sno;
                $task->staff_id = $staffId;
               
                $task->is_journal = 1;
                $task->created_by = $user_id;
                $task->updated_by = $user_id;
                $task->save();
 
                $journal = DB::table('et_manage_journal')->where('sno', $data->journal_id)->first();
                $customer = DB::table('et_customer')->where('sno', $journal->customer_id)->first();
 
                // Notification
                $notificationData = [
                    'branch_id' => $branch_id,
                    'notification_content' => '<div class="d-flex align-items-center">
                                            <div class="me-3">
                                                <span class="badge bg-info">
                                                    <i class="mdi mdi-calendar-sync fs-3 "></i>
                                                </span>
                                            </div>
                                            <div class="me-2">
                                                <a href="javascript:;" class="fs-7 text-primary fw-bold">Revision Task Assigned</a>
                                                <div class="text-secondary fs-8  fw-bold">'.$customer->cus_name.'</div>
                                                <div class="text-secondary fs-8  fw-bold">'.$customer->customer_id.'</div>
                                            </div>
                                        </div>',
                    'who' => $task->staff_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'status' => 0,
                ];
                $notificationtype = 'Requirement';
                $newNotification = new \App\Helpers\Helpers;
                // $newNotification->createNotificationAssessment($notificationData, $notificationtype, $task->staff_id);
            }
 
            DB::commit();
 
            return response()->json([
                'status' => 'success',
                'message' => 'Staff Assigned Successfully!',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
 
            return response()->json([
                'status' => 'error',
                'message' => 'Something went wrong!',
            ], 500);
        }
    }
    
    // public function jtlAccepted($id, Request $request)
    // {
    //     $user_id = $request->user()->user_id;

    //     $query = DB::table('et_journal_revision')
    //         ->where('sno', $id)
    //         ->where('status', '!=', 2);

    //     $data = $query->first();

    //     if (! $data) {
    //         return response([
    //             'status' => 404,
    //             'message' => 'Record Not Found !',
    //         ]);
    //     }

    //     $query->update([
    //         'status' => 9,
    //         'updated_by' => $user_id,
    //     ]);

    //     return response([
    //         'status' => 200,
    //         'message' => 'Revision Marked as Complete !',
    //     ], 200);
    // }
    
    public function jtlAccepted($id, Request $request)

    {

        $user_id = $request->user()->user_id;

 

        $query = DB::table('et_journal_revision')

            ->where('sno', $id)

            ->where('status', '!=', 2);

 

        $data = $query->first();

 

        if (! $data) {

            return response([

                'status' => 404,

                'message' => 'Record Not Found !',

            ]);

        }

 

        $query->update([

            'status' => 9,

            'updated_by' => $user_id,

        ]);

        $serviceData =  DB::table('et_customer_services')

            ->where('sno', $data->service_id)

            ->first();

 

        $productionStaff =  DB::table('et_staff')

            ->where('sno', $data->staff_id)

             ->first();

        //incentive points

        DB::table('et_production_staff_points')->insert([

            'proposal_id'        => $serviceData->proposal_id,

            'service_id'         => $data->service_id,

            'task_id'            => null,

            'milestone_id'       => null,

 

            'staff_id'           =>  $data->staff_id,

            'role_id'            => $productionStaff->role_id,

            'branch_id'          => $productionStaff->branch_id,

 

            'point_type'         => 'revision_comments',

 

            'service_amount'     => null,

            'point_value'       => null,

            'earned_points'     => 5,

 

            'is_positive'        => 1,

 

            'reference_staff_id' => null,

            'reference_point_id' => null,

 

            'remarks'            => 'Revision comments approved by JTL.',

 

            'created_by'         => $user_id,

            'created_at'         => now(),

            'updated_at'         => now(),

        ]);

        return response([

            'status' => 200,

            'message' => 'Revision Marked as Complete !',

        ], 200);

    }




    public function jtlRejected($id, Request $request)
    {
        $user_id = $request->user()->user_id;

        DB::beginTransaction();

        try {
            $query = DB::table('et_journal_revision')
                ->where('status', '!=', 2)
                ->where('sno', $id);

            $data = $query->first();

            if (! $data) {
                return response([
                    'status' => 404,
                    'message' => 'Record Not Found !',
                ]);
            }

            $query->update([
                'status' => 10,
                'updated_by' => $user_id,
            ]);

            $inserted = DB::table('et_journal_revision')->insert([
                'journal_id' => $data->journal_id,
                'service_id' => $data->service_id,
                'customer_id' => $data->customer_id,
                'jc_id' => $data->jc_id,
                'jtl_id' => $data->jtl_id,
                'journal_status' => $data->journal_status,
                'documents' => $data->documents,
                'comments' => $request->reject_reason,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);

            if (! $inserted) {
                throw new Exception('Insert Failed');
            }

            DB::commit();

            return response([
                'status' => 200,
                'message' => 'Revision Rejected Successfully !',
            ]);
        } catch (Throwable $e) {
            DB::rollBack();

            return response([
                'status' => 500,
                'message' => 'Something Went Wrong',
                'error' => $e->getMessage(),
            ]);
        }
    }

    public function pcJournalAccepted(Request $request, $id)
    {
        $user_id = $request->user()->user_id;

        $query = DB::table('et_journal_revision')
            ->where('status', '!=', 2)
            ->where('sno', $id);

        $data = $query->first();

        if (! $data) {
            return response([
                'status' => 404,
                'message' => 'Record Not Found !',
            ]);
        }

        $query->update([
            'status' => 8,
            'updated_by' => $user_id,
        ]);

        return response([
            'status' => 200,
            'message' => 'Revision Accepted Successfully !',
        ]);
    }

    public function pcJournalReject(Request $request, $id)
    {
        $user_id = $request->user()->user_id;

        DB::beginTransaction();

        try {
            $query = DB::table('et_journal_revision')
                ->where('sno', $id)
                ->where('status', '!=', 2);

            $data = $query->first();

            if (! $data) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Record Not Found !',
                ]);
            }

            DB::table('et_daily_tasks')
                ->where('status', '!=', 2)
                ->where('is_journal', 1)
                ->where('task_id', $data->sno)
                ->update([
                    'status' => 5,
                    'updated_by' => $user_id,
                ]);

            $query->update([
                'status' => 10,
                'updated_by' => $user_id,
            ]);

            $insertedId = DB::table('et_journal_revision')
                ->insertGetId([
                    'journal_id' => $data->journal_id,
                    'service_id' => $data->service_id,
                    'customer_id' => $data->customer_id,
                    'jc_id' => $data->jc_id,
                    'jtl_id' => $data->jtl_id,
                    'pc_id' => $data->pc_id,
                    'staff_id' => $request->staff_id ?? $data->staff_id,
                    'journal_status' => $data->journal_status,
                    'documents' => $data->documents,
                    'comments' => $request->reject_reason,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'status' => 4,
                ]);

            DB::table('et_daily_tasks')
                ->insert([
                    'service_id' => $data->service_id,
                    'task_id' => $insertedId,
                    'staff_id' => $request->staff_id ?? $data->staff_id,
                    'task_date' => now(),
                    'description' => $request->reject_reason,
                    'is_journal' => 1,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);

            if (! $insertedId) {
                throw new Exception('Unable to insert the record.');
            }

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Revision Rejected Successfully !',
            ]);
        } catch (Throwable $e) {
            DB::rollBack();

            return response([
                'status' => 500,
                'message' => 'Something Went Wrong',
                'error' => $e->getMessage(),
            ]);
        }
    }

    public function commentsView($id)
    {
        $data = DB::table('et_journal_revision')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_revision.customer_id')
            ->leftJoin('et_manage_journal', 'et_manage_journal.sno', '=', 'et_journal_revision.journal_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_revision.service_id')
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
            ->leftJoin('et_staff as jtl', 'jtl.sno', '=', 'et_journal_revision.jtl_id')
            ->leftJoin('et_staff as pc', 'pc.sno', '=', 'et_journal_revision.pc_id')
            ->leftJoin('et_staff as staff', 'staff.sno', '=', 'et_journal_revision.staff_id')
            ->where('et_journal_revision.status', '!=', 2)
            ->where('et_journal_revision.sno', $id)
            ->select(
                'et_journal_revision.journal_status',
                'et_journal_revision.created_at',
                'et_journal_revision.comments',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'jtl.staff_name as jtl_name',
                'jtl.staff_image as jtl_image',
                'pc.staff_name as pc_name',
                'pc.staff_image as pc_image',
                'staff.staff_name',
                'staff.staff_image',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id',
                'et_product.product_name',
                'et_customer_services.sno as service_sno',
                'et_customer_services.created_at as service_created_at'
            )
            ->first();

        $journalStatus = $data->journal_status;

        switch ($journalStatus) {
            case 0:
                $data->journalStatus = 'Submitted';
                break;
            case 1:
                $data->journalStatus = 'With Editor';
                break;
            case 3:
                $data->journalStatus = 'Under Reviewer';
                break;
            case 4:
                $data->journalStatus = 'Revision';
                break;
            case 5:
                $data->journalStatus = 'Accepted';
                break;
            case 6:
                $data->journalStatus = 'Rejected';
                break;
            case 7:
                $data->journalStatus = 'E-Proofing';
                break;
            case 8:
                $data->journalStatus = 'Published';
                break;
        }

        $year = date('Y', strtotime($data->service_created_at));
        $formattedId = str_pad($data->service_sno, 5, '0', STR_PAD_LEFT);
        $data->formatted_service_id = "SR-{$formattedId}/{$year}";

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully !',
            'data' => $data,
        ], 200);
    }
    
//     public function addOrUpdateRequirement_jnlcustomer(Request $request)
//  {
 
//     // return $request;
//     $rules = [
//     'requirement_lead_id' => 'required|integer',
//     ];
 
//     foreach ($request->require_doc_id ?? [] as $docId) {
//         $rules["requirement_name_{$docId}"] = 'nullable|array';
//         $rules["requirement_name_{$docId}.*"] = 'nullable|string';
//     }
 
//     $validator = Validator::make($request->all(), $rules);
 
//     $data = $validator->validated();
 
//     if ($validator->fails()) {
//                 return response()->json([
//                     'status'  => 401,
//                     'message' => 'Validator Error',
//                 ], 401);
//     }
 
//     $data = $validator->validated();
//     DB::beginTransaction();
//     try {
//       $leadId      = $data['requirement_lead_id'];
//       $leaddata = DB::table('et_customer')->where('sno', $leadId)->select('sno', 'lead_id')->first();
//       $branch_id   = $request->user()->branch_id ?? 1;
//       $user_id     = $request->user()->user_id ?? 1;
//       $entity_id   = $request->user()->entity_id ?? 1;
 
//       // -------- CREATE MAIN REQUIREMENT -------- //
//   $leadRequirement = ManageRequirementModel::where('revision_id', $request->revision_id)
//     ->where('journal_status', $request->journal_status)
//     ->first();
 
//         if (!$leadRequirement) {
//             $leadRequirement = new ManageRequirementModel();
//             $leadRequirement->created_by = $user_id;
//         }
 
//         $leadRequirement->requirement_type = 3;
//         $leadRequirement->lead_id          = $leaddata->lead_id ?? 0;
//         $leadRequirement->deparment_id     = 1;
//         $leadRequirement->customer_id      = $leadId;
//         $leadRequirement->jtl_id           = $request->pc_staff;
//         $leadRequirement->service_id       = $request->requirement_service_id;
//         $leadRequirement->rc_chk           = $request->rc_chk ?? 0;
//         $leadRequirement->journal_id       = $request->journal_id ?? 0;
//         $leadRequirement->journal_status   = $request->journal_status ?? 0;
//         $leadRequirement->revision_id      = $request->revision_id ?? 0;
//         $leadRequirement->branch_id        = $branch_id;
//         $leadRequirement->entity_id        = $entity_id;
//         $leadRequirement->updated_by       = $user_id;
//         $leadRequirement->save();
 
//       // Soft delete existing active documents
//         ManageRequirementDocs::where('requirement_id', $leadRequirement->sno)
//         ->where('status', 0)
//         ->update([
//             'status' => 2,
//             'updated_by' => $user_id
//         ]);
 
//         /*
//         |--------------------------------------------------------------------------
//         | UPDATE EXISTING DOCUMENTS
//         |--------------------------------------------------------------------------
//         */
//         if (!empty($request->require_doc_id)) {
 
//             foreach ($request->require_doc_id as $docId) {
 
//                 $requirementNameKey = "requirement_name_{$docId}";
//                 $documentUploadKey  = "document_upload_{$docId}";
//                 $oldDocumentKey     = "old_document{$docId}";
 
//                 $requirementName = $data[$requirementNameKey][0] ?? null;
 
//                 $documentUrl = $request->input($oldDocumentKey . '.0');
 
//                 if (
//                     $request->hasFile($documentUploadKey) &&
//                     isset($request->file($documentUploadKey)[0])
//                 ) {
 
//                     $file = $request->file($documentUploadKey)[0];
 
//                     $extension = $file->getClientOriginalExtension();
//                     $filename = 'requirement_doc_' . time() . '_' . $docId . '.' . $extension;
 
//                     $file->move(public_path('requirement_documents'), $filename);
 
//                     $documentUrl = $filename;
//                 }
 
//                 ManageRequirementDocs::create([
//                     'requirement_id'   => $leadRequirement->sno,
//                     'requirement_name' => $requirementName,
//                     'document_url'     => $documentUrl,
//                     'status'           => 0,
//                     'created_by'       => $user_id,
//                     'updated_by'       => $user_id,
//                 ]);
//             }
//         }
 
//         /*
//         |--------------------------------------------------------------------------
//         | CREATE NEW DOCUMENTS
//         |--------------------------------------------------------------------------
//         */
//         elseif (!empty($request->requirement_name)) {
 
//             foreach ($request->requirement_name as $index => $reqName) {
 
//                 $documentUrl = null;
 
//                 if (!empty($request->document_upload[$index])) {
 
//                     $file = $request->document_upload[$index];
 
//                     $extension = $file->getClientOriginalExtension();
//                     $filename = 'requirement_doc_' . time() . '_' . ($index + 1) . '.' . $extension;
 
//                     $file->move(public_path('requirement_documents'), $filename);
 
//                     $documentUrl = $filename;
//                 }
 
//                 ManageRequirementDocs::create([
//                     'requirement_id'   => $leadRequirement->sno,
//                     'requirement_name' => $reqName,
//                     'document_url'     => $documentUrl,
//                     'status'           => 0,
//                     'created_by'       => $user_id,
//                     'updated_by'       => $user_id,
//                 ]);
//             }
//         }
//             DB::commit();
//             //  return 'if';
//             //  return $leadRequirement;
           
//             session()->flash('toastr', [
//                 'type' => 'success',
//                 'message' => 'Requirement added successfully!'
//             ]);
           
//             return response()->json([
//                 'status'  => 200,
//                 'message' => 'Requirement added successfully',
//             ]);
 
     
//     } catch (Exception $e) {
 
//       DB::rollBack();
     
//       session()->flash('toastr', [
//         'type' => 'error',
//         'message' => 'Error: ' . $e->getMessage()
//       ]);
//             return response()->json([
//                 'status'  => 401,
//                 'message' => 'Error'. $e->getMessage(),
//             ], 401);
     
//     }
//   }
  
  
   public function addOrUpdateRequirement_jnlcustomer(Request $request)
 {
 
    // return $request;
    $rules = [
    'requirement_lead_id' => 'required|integer',
    ];
 
    foreach ($request->require_doc_id ?? [] as $docId) {
        $rules["requirement_name_{$docId}"] = 'nullable|array';
        $rules["requirement_name_{$docId}.*"] = 'nullable|string';
    }
 
    $validator = Validator::make($request->all(), $rules);
 
    $data = $validator->validated();
 
    if ($validator->fails()) {
                return response()->json([
                    'status'  => 401,
                    'message' => 'Validator Error',
                ], 401);
    }
 
    $data = $validator->validated();
    DB::beginTransaction();
    try {
      $leadId      = $data['requirement_lead_id'];
      $leaddata = DB::table('et_customer')->where('sno', $leadId)->select('sno', 'lead_id')->first();
      $branch_id   = $request->user()->branch_id ?? 1;
      $user_id     = $request->user()->user_id ?? 1;
      $entity_id   = $request->user()->entity_id ?? 1;
 
      // -------- CREATE MAIN REQUIREMENT -------- //
   $leadRequirement = ManageRequirementModel::where('revision_id', $request->revision_id)
    ->where('journal_status', $request->journal_status)
    ->first();
 
        if (!$leadRequirement) {
            $leadRequirement = new ManageRequirementModel();
            $leadRequirement->created_by = $user_id;
        }
 
        $leadRequirement->requirement_type = 3;
        $leadRequirement->lead_id          = $leaddata->lead_id ?? 0;
        $leadRequirement->deparment_id     = 1;
        $leadRequirement->customer_id      = $leadId;
        $leadRequirement->jtl_id           = $request->pc_staff;
        $leadRequirement->service_id       = $request->requirement_service_id;
        $leadRequirement->rc_chk           = $request->rc_chk ?? 0;
        $leadRequirement->journal_id       = $request->journal_id ?? 0;
        $leadRequirement->journal_status   = $request->journal_status ?? 0;
        $leadRequirement->revision_id      = $request->revision_id ?? 0;
        $leadRequirement->branch_id        = $branch_id;
        $leadRequirement->entity_id        = $entity_id;
        $leadRequirement->updated_by       = $user_id;
        $leadRequirement->save();
 
       // Soft delete existing active documents
        ManageRequirementDocs::where('requirement_id', $leadRequirement->sno)
        ->where('status', 0)
        ->update([
            'status' => 2,
            'updated_by' => $user_id
        ]);
 
        /*
        |--------------------------------------------------------------------------
        | UPDATE EXISTING DOCUMENTS
        |--------------------------------------------------------------------------
        */
        if (!empty($request->require_doc_id)) {
 
            foreach ($request->require_doc_id as $docId) {
 
                $requirementNameKey = "requirement_name_{$docId}";
                $documentUploadKey  = "document_upload_{$docId}";
                $oldDocumentKey     = "old_document{$docId}";
 
                $requirementName = $data[$requirementNameKey][0] ?? null;
 
                $documentUrl = $request->input($oldDocumentKey . '.0');
 
                if (
                    $request->hasFile($documentUploadKey) &&
                    isset($request->file($documentUploadKey)[0])
                ) {
 
                    $file = $request->file($documentUploadKey)[0];
 
                    $extension = $file->getClientOriginalExtension();
                    $filename = 'requirement_doc_' . time() . '_' . $docId . '.' . $extension;
 
                    $file->move(public_path('requirement_documents'), $filename);
 
                    $documentUrl = $filename;
                }
 
                ManageRequirementDocs::create([
                    'requirement_id'   => $leadRequirement->sno,
                    'requirement_name' => $requirementName,
                    'document_url'     => $documentUrl,
                    'status'           => 0,
                    'created_by'       => $user_id,
                    'updated_by'       => $user_id,
                ]);
            }
        }
 
        /*
        |--------------------------------------------------------------------------
        | CREATE NEW DOCUMENTS
        |--------------------------------------------------------------------------
        */
        elseif (!empty($request->requirement_name)) {
 
            foreach ($request->requirement_name as $index => $reqName) {
 
                $documentUrl = null;
 
                if (!empty($request->document_upload[$index])) {
 
                    $file = $request->document_upload[$index];
 
                    $extension = $file->getClientOriginalExtension();
                    $filename = 'requirement_doc_' . time() . '_' . ($index + 1) . '.' . $extension;
 
                    $file->move(public_path('requirement_documents'), $filename);
 
                    $documentUrl = $filename;
                }
 
                ManageRequirementDocs::create([
                    'requirement_id'   => $leadRequirement->sno,
                    'requirement_name' => $reqName,
                    'document_url'     => $documentUrl,
                    'status'           => 0,
                    'created_by'       => $user_id,
                    'updated_by'       => $user_id,
                ]);
            }
        }
 
         // Notification
                $notificationData = [
                    'branch_id' => $branch_id,
                    'notification_content' => '<div class="d-flex align-items-center">
                                            <div class="me-3">
                                                <span class="badge bg-info">
                                                    <i class="mdi mdi-calendar-sync fs-3 "></i>
                                                </span>
                                            </div>
                                            <div class="me-2">
                                                <a href="javascript:;" class="fs-7 text-primary fw-bold">Revision Requirement Assigned</a>
                                                <div class="text-secondary fs-8  fw-bold">'.$request->requirement_name[0].'</div>
                                                <div class="text-secondary fs-8  fw-bold">'.$leadId.'</div>
                                            </div>
                                        </div>',
                    'who' => $user_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'status' => 0,
                ];
                $notificationtype = 'Requirement';
                $newNotification = new \App\Helpers\Helpers;
                $newNotification->createNotificationAssessment($notificationData, $notificationtype, $request->pc_staff);
            DB::commit();
            //  return 'if';
            //  return $leadRequirement;
           
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Requirement added successfully!'
            ]);
           
            return response()->json([
                'status'  => 200,
                'message' => 'Requirement added successfully',
            ]);
 
     
    } catch (Exception $e) {
 
      DB::rollBack();
     
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Error: ' . $e->getMessage()
      ]);
            return response()->json([
                'status'  => 401,
                'message' => 'Error'. $e->getMessage(),
            ], 401);
     
    }
  }
  
   public function journalStaffWorkload($staffId)
{
    try {
 
        $workload = DB::table('et_journal_revision')
            ->leftJoin(
                'et_manage_journal',
                'et_manage_journal.sno',
                '=',
                'et_journal_revision.journal_id'
            )
            ->leftJoin(
                'et_journal_booklet',
                'et_journal_booklet.sno',
                '=',
                'et_manage_journal.booklet_id'
            )
            ->leftJoin(
                'et_customer_services',
                'et_customer_services.sno',
                '=',
                'et_journal_revision.service_id'
            )
            ->leftJoin(
                'et_product',
                'et_product.sno',
                '=',
                'et_customer_services.product_id'
            )
            ->where('et_journal_revision.staff_id', $staffId)
 
            // Current journal work
            ->whereIn('et_journal_revision.status', [
                4,
                5,
                6,
                7,
                8
            ])
 
            ->select(
                'et_journal_revision.sno',
                'et_manage_journal.journal_id',
                'et_journal_revision.journal_status',
                'et_journal_revision.status',
                'et_journal_revision.created_at',
                'et_manage_journal.paper_name',
                'et_journal_booklet.journal_name',
                'et_product.product_name',
                'et_customer_services.sno as service_id',
                'et_customer_services.created_at as service_created_at'
            )
            ->orderBy('et_journal_revision.created_at', 'desc')
            ->get();
 
            foreach ($workload as $row) {
 
    $year = date('Y', strtotime($row->service_created_at));
    $id = str_pad($row->service_id, 5, '0', STR_PAD_LEFT);
 
    $row->formatted_service_id = "SR-{$id}/{$year}";
}
 
        return response()->json([
            'status' => 200,
            'data' => $workload
        ]);
 
    } catch (\Exception $e) {
 
        return response()->json([
            'status' => 500,
            'message' => $e->getMessage()
        ], 500);
    }
}

}
