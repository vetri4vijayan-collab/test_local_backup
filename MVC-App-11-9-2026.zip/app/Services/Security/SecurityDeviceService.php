<?php

namespace App\Services\Security;

use App\Models\SecurityDeviceModel;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Exception;

class SecurityDeviceService
{
    /**
     * Register Device
     */
    public function register(
        int $staffId,
        array $device
    ): SecurityDeviceModel {

        $row = SecurityDeviceModel::query()
            ->where('staff_id', $staffId)
            ->where('device_uuid', $device['device_uuid'])
            ->first();

        if ($row) {

            $row->update([
                'device_name' => $device['device_name'],
                'device_model' => $device['device_model'],
                'manufacturer' => $device['manufacturer'],
                'android_version' => $device['android_version'],
                'app_version' => $device['app_version'],
                'firebase_token' => $device['firebase_token'],
                'last_login_at' => now(),
                'status' => 1
            ]);

            return $row->fresh();

        }

        return SecurityDeviceModel::create([

            'staff_id' => $staffId,

            'device_uuid' => $device['device_uuid'],

            'device_name' => $device['device_name'],

            'device_model' => $device['device_model'],

            'manufacturer' => $device['manufacturer'],

            'android_version' => $device['android_version'],

            'app_version' => $device['app_version'],

            'firebase_token' => $device['firebase_token'],

            'last_login_at' => now(),

            'status' => 1

        ]);
    }

    /**
     * Authenticate Device
     */
    public function authenticate(
        int $staffId,
        string $deviceUuid
    ): SecurityDeviceModel {

        $device = SecurityDeviceModel::query()

            ->where('staff_id', $staffId)

            ->where('device_uuid', $deviceUuid)

            ->where('status', 1)

            ->first();

        if (!$device) {

            throw new Exception(
                'Device not registered.'
            );

        }

        $device->update([

            'last_login_at' => now()

        ]);

        return $device;
    }

    /**
     * Get Device
     */
    public function get(
        int $staffId,
        string $deviceUuid
    ): ?SecurityDeviceModel {

        return SecurityDeviceModel::query()

            ->where('staff_id', $staffId)

            ->where('device_uuid', $deviceUuid)

            ->first();

    }

    /**
     * Active
     */
    public function isActive(
        SecurityDeviceModel $device
    ): bool {

        return $device->status == 1;

    }

    /**
     * Deactivate
     */
    public function deactivate(
        SecurityDeviceModel $device
    ): bool {

        return $device->update([

            'status' => 0

        ]);

    }

    /**
     * Update Firebase Token
     */
    public function updateFirebase(
        SecurityDeviceModel $device,
        string $token
    ): bool {

        return $device->update([

            'firebase_token' => $token

        ]);

    }

}