<?php

namespace App\Services\Security;

use App\Models\SecurityModuleModel;
use App\Models\SecurityModuleSettingModel;
use App\Models\SecuritySessionModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Exception;

class SecuritySessionService
{
    /**
     * Create Security Session
     */
    public function createSession(
        int $moduleId,
        int $recordId,
        int $requestedStaffId
    ): SecuritySessionModel {

        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | Module Validation
            |--------------------------------------------------------------------------
            */

            $module = SecurityModuleModel::query()
                ->where('sno', $moduleId)
                ->where('status', 1)
                ->first();

            if (!$module) {
                throw new Exception('Security module not found.');
            }

            /*
            |--------------------------------------------------------------------------
            | Module Settings
            |--------------------------------------------------------------------------
            */

            $setting = SecurityModuleSettingModel::query()
                ->where('module_id', $moduleId)
                ->where('status', 1)
                ->first();

            if (!$setting) {
                throw new Exception('Security module settings not found.');
            }

            /*
            |--------------------------------------------------------------------------
            | Expire Old Sessions
            |--------------------------------------------------------------------------
            */

            SecuritySessionModel::query()
                ->where('module_id', $moduleId)
                ->where('record_id', $recordId)
                ->where('requested_staff_id', $requestedStaffId)
                ->whereIn('status', [
                    'CREATED',
                    'SCANNED',
                    'PIN_GENERATED',
                    'VERIFIED'
                ])
                ->update([
                    'status' => 'EXPIRED',
                    'closed_at' => now()
                ]);

            /*
            |--------------------------------------------------------------------------
            | Generate Session
            |--------------------------------------------------------------------------
            */

            $sessionUuid = (string) Str::uuid();

            $qrToken = hash(
                'sha256',
                Str::random(80) .
                microtime(true) .
                random_int(100000, 999999)
            );

            $generatedAt = now();

            $qrExpiresAt = Carbon::now()
                ->addSeconds($setting->qr_expiry_seconds);

            /*
            |--------------------------------------------------------------------------
            | Save Session
            |--------------------------------------------------------------------------
            */

            $session = SecuritySessionModel::create([

                'session_uuid' => $sessionUuid,

                'module_id' => $moduleId,

                'record_id' => $recordId,

                'requested_staff_id' => $requestedStaffId,

                'verified_staff_id' => null,

                'device_id' => null,

                'qr_token' => $qrToken,

                'pin_hash' => null,

                'pin_attempts' => 0,

                'generated_at' => $generatedAt,

                'qr_expires_at' => $qrExpiresAt,

                'pin_generated_at' => null,

                'pin_expires_at' => null,

                'verified_at' => null,

                'access_expires_at' => null,

                'closed_at' => null,

                'status' => 'CREATED',

                'ip_address' => request()->ip(),

                'user_agent' => request()->userAgent()
            ]);

            DB::commit();

            return $session;

        } catch (Exception $e) {

            DB::rollBack();

            Log::error('Security Session Create Error', [

                'message' => $e->getMessage(),

                'line' => $e->getLine(),

                'file' => $e->getFile()
            ]);

            throw $e;
        }
    }

    /**
     * Get Session
     */
    public function getSession(
        int $sessionId
    ): ?SecuritySessionModel {

        return SecuritySessionModel::query()
            ->where('sno', $sessionId)
            ->first();
    }

    /**
     * Find Session by UUID
     */
    public function findByUuid(
        string $uuid
    ): ?SecuritySessionModel {

        return SecuritySessionModel::query()
            ->where('session_uuid', $uuid)
            ->first();
    }

    /**
     * Validate Session
     */
    public function validateSession(
        SecuritySessionModel $session
    ): bool {

        if (!$session) {
            return false;
        }

        if ($session->status == 'EXPIRED') {
            return false;
        }

        if ($session->status == 'FAILED') {
            return false;
        }

        if ($session->status == 'CLOSED') {
            return false;
        }

        if (Carbon::now()->gt($session->qr_expires_at)) {

            $this->expireSession($session);

            return false;
        }

        return true;
    }

        /**
     * Mark QR Scanned
     */
    public function markScanned(
        SecuritySessionModel $session,
        int $deviceId
    ): SecuritySessionModel {

        if (!$this->validateSession($session)) {
            throw new Exception('Session expired or invalid.');
        }

        $session->device_id = $deviceId;
        $session->status = 'SCANNED';
        $session->save();

        return $session;
    }

    /**
     * Save Generated PIN
     */
    public function markPinGenerated(
        SecuritySessionModel $session,
        string $pinHash,
        Carbon $pinExpiresAt
    ): SecuritySessionModel {

        if (!$this->validateSession($session)) {
            throw new Exception('Session expired.');
        }

        $session->pin_hash = $pinHash;
        $session->pin_generated_at = now();
        $session->pin_expires_at = $pinExpiresAt;
        $session->status = 'PIN_GENERATED';
        $session->save();

        return $session;
    }

    /**
     * Mark PIN Verified
     */
    public function markVerified(
        SecuritySessionModel $session,
        int $verifiedStaffId,
        Carbon $accessExpiresAt
    ): SecuritySessionModel {

        if (!$this->validateSession($session)) {
            throw new Exception('Session expired.');
        }

        $session->verified_staff_id = $verifiedStaffId;
        $session->verified_at = now();
        $session->access_expires_at = $accessExpiresAt;
        $session->status = 'VERIFIED';
        $session->save();

        return $session;
    }

    /**
     * Expire Session
     */
    public function expireSession(
        SecuritySessionModel $session
    ): SecuritySessionModel {

        $session->status = 'EXPIRED';
        $session->closed_at = now();
        $session->save();

        return $session;
    }

    /**
     * Close Session
     */
    public function closeSession(
        SecuritySessionModel $session
    ): SecuritySessionModel {

        $session->status = 'CLOSED';
        $session->closed_at = now();
        $session->save();

        return $session;
    }

    /**
     * Check Session Expiry
     */
    public function isExpired(
        SecuritySessionModel $session
    ): bool {

        if ($session->status == 'EXPIRED') {
            return true;
        }

        if ($session->status == 'CLOSED') {
            return true;
        }

        if ($session->qr_expires_at &&
            now()->greaterThan($session->qr_expires_at)) {

            return true;
        }

        if ($session->access_expires_at &&
            now()->greaterThan($session->access_expires_at)) {

            return true;
        }

        return false;
    }
}