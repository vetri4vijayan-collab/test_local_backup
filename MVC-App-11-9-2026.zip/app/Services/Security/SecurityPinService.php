<?php

namespace App\Services\Security;

use App\Models\SecurityModuleSettingModel;
use App\Models\SecuritySessionModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;

class SecurityPinService
{
    /**
     * Generate PIN
     */
    public function generatePin(
        SecuritySessionModel $session
    ): string {

        $setting = SecurityModuleSettingModel::query()

            ->where(
                'module_id',
                $session->module_id
            )

            ->firstOrFail();

        $length = max(
            4,
            (int)$setting->pin_length
        );

        $min = pow(10, $length - 1);

        $max = pow(10, $length) - 1;

        $pin = (string) random_int($min, $max);

        $session->pin_hash = Hash::make($pin);

        $session->pin_generated_at = now();

        $session->pin_expires_at = now()

            ->addSeconds(
                $setting->pin_expiry_seconds
            );

        $session->status = 'PIN_GENERATED';

        $session->save();

        return $pin;
    }

    /**
     * Verify PIN
     */
    public function verifyPin(
        SecuritySessionModel $session,
        string $pin
    ): bool {

        if (!$session->pin_hash) {

            return false;

        }

        if ($session->pin_expires_at < now()) {

            return false;

        }

        if (

            !Hash::check(
                $pin,
                $session->pin_hash
            )

        ) {

            $session->increment(
                'pin_attempts'
            );

            return false;

        }

        return true;
    }

    /**
     * Remaining Seconds
     */
    public function remainingSeconds(
        SecuritySessionModel $session
    ): int {

        if (!$session->pin_expires_at) {

            return 0;

        }

        return max(

            0,

            now()->diffInSeconds(
                $session->pin_expires_at,
                false
            )

        );

    }

    /**
     * Is PIN Expired
     */
    public function pinExpired(
        SecuritySessionModel $session
    ): bool {

        if (!$session->pin_expires_at) {

            return true;

        }

        return now()->greaterThan(
            $session->pin_expires_at
        );

    }

    /**
     * Reset Attempts
     */
    public function resetAttempts(
        SecuritySessionModel $session
    ): void {

        $session->pin_attempts = 0;

        $session->save();

    }

}