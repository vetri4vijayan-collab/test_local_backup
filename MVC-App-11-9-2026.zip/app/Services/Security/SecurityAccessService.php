<?php

namespace App\Services\Security;

use App\Models\SecurityAccessModel;
use App\Models\SecurityModuleSettingModel;
use App\Models\SecuritySessionModel;

class SecurityAccessService
{
    /**
     * Grant Temporary Access
     */
    public function grant(
        SecuritySessionModel $session,
        int $staffId
    ): SecurityAccessModel {

        /*
        |--------------------------------------------------------------------------
        | Expire Old Access
        |--------------------------------------------------------------------------
        */

        SecurityAccessModel::query()

            ->where('staff_id', $staffId)

            ->where('module_id', $session->module_id)

            ->where('record_id', $session->record_id)

            ->update([

                'status' => 'EXPIRED'

            ]);

        /*
        |--------------------------------------------------------------------------
        | Module Settings
        |--------------------------------------------------------------------------
        */

        $setting = SecurityModuleSettingModel::query()

            ->where('module_id', $session->module_id)

            ->firstOrFail();

        /*
        |--------------------------------------------------------------------------
        | Create Access
        |--------------------------------------------------------------------------
        */

        $access = SecurityAccessModel::create([

            'session_id' => $session->sno,

            'staff_id' => $staffId,

            'module_id' => $session->module_id,

            'record_id' => $session->record_id,

            'expires_at' => now()

                ->addSeconds(

                    $setting->access_expiry_seconds

                ),

            'status' => 'ACTIVE'

        ]);

        /*
        |--------------------------------------------------------------------------
        | Update Session
        |--------------------------------------------------------------------------
        */

        $session->verified_staff_id = $staffId;

        $session->verified_at = now();

        $session->access_expires_at = $access->expires_at;

        $session->status = 'VERIFIED';

        $session->save();

        return $access;
    }

    /**
     * Check Access
     */
    public function hasAccess(

        int $staffId,

        int $moduleId,

        int $recordId

    ): bool {

        $access = SecurityAccessModel::query()

            ->where('staff_id', $staffId)

            ->where('module_id', $moduleId)

            ->where('record_id', $recordId)

            ->where('status', 'ACTIVE')

            ->first();

        if (!$access) {

            return false;

        }

        if ($access->expires_at < now()) {

            $access->status = 'EXPIRED';

            $access->save();

            return false;

        }

        return true;
    }

    /**
     * Remaining Seconds
     */
    public function remaining(

        int $staffId,

        int $moduleId,

        int $recordId

    ): int {

        $access = SecurityAccessModel::query()

            ->where('staff_id', $staffId)

            ->where('module_id', $moduleId)

            ->where('record_id', $recordId)

            ->where('status', 'ACTIVE')

            ->first();

        if (!$access) {

            return 0;

        }

        return max(

            0,

            now()->diffInSeconds(

                $access->expires_at,

                false

            )

        );

    }

    /**
     * Revoke Access
     */
    public function revoke(

        int $staffId,

        int $moduleId,

        int $recordId

    ): bool {

        return SecurityAccessModel::query()

            ->where('staff_id', $staffId)

            ->where('module_id', $moduleId)

            ->where('record_id', $recordId)

            ->update([

                'status' => 'EXPIRED'

            ]);

    }

    /**
     * Cleanup Expired Access
     */
    public function cleanup(): void
    {

        SecurityAccessModel::query()

            ->where('status', 'ACTIVE')

            ->where('expires_at', '<', now())

            ->update([

                'status' => 'EXPIRED'

            ]);

    }
}