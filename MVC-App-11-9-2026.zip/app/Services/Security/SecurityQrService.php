<?php

namespace App\Services\Security;

use App\Models\SecuritySessionModel;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\URL;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class SecurityQrService
{
    /**
     * Generate QR Payload
     */
    public function generatePayload(
        SecuritySessionModel $session
    ): array {

        return [

            'session_uuid' => $session->session_uuid,

            'token' => encrypt($session->qr_token),

            'generated_at' => now()->timestamp

        ];
    }

    /**
     * Encrypt Payload
     */
    public function encryptPayload(
        array $payload
    ): string {

        return Crypt::encryptString(
            json_encode($payload)
        );
    }

    /**
     * Generate QR Image
     */
    public function generateQrImage(
        SecuritySessionModel $session,
        int $size = 300
    ): string {

        $payload = $this->generatePayload($session);

        $encrypted = $this->encryptPayload($payload);

        return base64_encode(

            QrCode::format('png')

                ->size($size)

                ->margin(2)

                ->generate($encrypted)

        );

    }

    /**
     * Decode Payload
     */
    public function decodePayload(
        string $encrypted
    ): array {

        return json_decode(

            Crypt::decryptString($encrypted),

            true

        );

    }

    /**
     * Verify Payload
     */
    public function verifyPayload(
        array $payload
    ): SecuritySessionModel {

        $session = SecuritySessionModel::query()

            ->where(
                'session_uuid',
                $payload['session_uuid']
            )

            ->first();

        if (!$session) {

            throw new \Exception(
                'Invalid QR Session.'
            );

        }

        if ($session->qr_token != decrypt($payload['token'])) {

            throw new \Exception(
                'QR Token Invalid.'
            );

        }

        return $session;
       
    }

    public function generate(
        SecuritySessionModel $session,
        int $size = 300
    ): string {

        // return base64_encode(

        //     QrCode::format('png')
        //         ->size($size)
        //         ->margin(1)
        //         ->generate(
        //             $session->session_uuid
        //         )

        // );

        return base64_encode(

            QrCode::format('svg')
                ->size($size)
                ->margin(1)
                ->generate(
                    $session->session_uuid
                )

        );

    }

    /**
     * Read QR
     */
    public function getSession(
        string $sessionUuid
    ): ?SecuritySessionModel {

        return SecuritySessionModel::query()

            ->where(
                'session_uuid',
                $sessionUuid
            )

            ->first();

    }
}