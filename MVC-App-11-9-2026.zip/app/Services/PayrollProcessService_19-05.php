<?php

namespace App\Services;

use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;
use App\Helpers\PayrollFormulaHelper;

class PayrollProcessService
{
    protected $previewService;

    public function __construct(
        PayrollPreviewService $previewService
    ) {
        $this->previewService = $previewService;
    }

    public function process($month, $year)
    {
        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | CREATE PROCESS
            |--------------------------------------------------------------------------
            */

            $processId = DB::table('egc_payroll_processes')
                ->insertGetId([

                    'payroll_month' => $month,

                    'payroll_year' => $year,

                    'payroll_name' =>
                    'Payroll ' .
                        Carbon::create($year, $month)
                        ->format('F Y'),

                    'payroll_start_date' =>
                    Carbon::create($year, $month, 1),

                    'payroll_end_date' =>
                    Carbon::create($year, $month, 1)
                        ->endOfMonth(),

                    'process_status' => 'processing',

                    'processed_at' => now(),

                    'created_at' => now(),

                    'updated_at' => now(),
                ]);

            /*
            |--------------------------------------------------------------------------
            | EMPLOYEES
            |--------------------------------------------------------------------------
            */

            $employees = DB::table('egc_staff')
                ->where('status', 0)
                ->where('role_id', '>', 0)
                ->get();

            $totalEmployees = $employees->count();

            DB::table('egc_payroll_processes')
                ->where('sno', $processId)
                ->update([
                    'total_employees' => $totalEmployees
                ]);

            $processedCount = 0;

            $totalGross = 0;
            $totalDeduction = 0;
            $totalNet = 0;
            foreach ($employees as $employee) {

                /*
                |--------------------------------------------------------------------------
                | LIVE ENGINE
                |--------------------------------------------------------------------------
                */

                $payroll =
                    $this->previewService
                    ->calculateLivePayroll(
                        $employee,
                        $month,
                        $year
                    );

                /*
                |--------------------------------------------------------------------------
                | SAVE ATTENDANCE SUMMARY
                |--------------------------------------------------------------------------
                */

                DB::table(
                    'egc_payroll_attendance_summaries'
                )->insert([

                    'payroll_month' => $month,

                    'employee_sno' => $employee->sno,

                    'present_days' =>
                    $payroll['present_days'],

                    'absent_days' =>
                    $payroll['absent_days'],

                    'paid_leave_days' =>
                    $payroll['leave_days'],

                    'weekoff_days' =>
                    $payroll['weekoff_days'],

                    'holiday_days' =>
                    $payroll['holiday_days'],

                    'payable_days' =>
                    $payroll['earning_days'],

                    'lop_days' =>
                    $payroll['lop_days'],

                    'late_mark_count' =>
                    $payroll['late_count'],

                    'created_at' => now(),

                    'updated_at' => now(),
                ]);

                /*
                |--------------------------------------------------------------------------
                | SAVE EMPLOYEE PAYROLL
                |--------------------------------------------------------------------------
                */

                $employeePayrollId =
                    DB::table(
                        'egc_payroll_employee_payrolls'
                    )->insertGetId([

                        'payroll_process_sno' =>
                        $processId,

                        'payroll_month' => $month,

                        'payroll_year' => $year,

                        'staff_id' =>
                        $employee->sno,

                        'gross_earnings' =>
                        $payroll['earnings'],

                        'gross_deductions' =>
                        $payroll['deductions'],

                        'net_payable' =>
                        $payroll['net_salary'],

                        'payable_days' =>
                        $payroll['earning_days'],

                        'lop_days' =>
                        $payroll['lop_days'],

                        'paid_days' =>
                        $payroll['present_days'],

                        'processed_at' => now(),

                        'created_at' => now(),

                        'updated_at' => now(),
                    ]);

                /*
                |--------------------------------------------------------------------------
                | SAVE COMPONENTS
                |--------------------------------------------------------------------------
                */

                foreach (
                    $payroll['components']
                    as $component
                ) {

                    DB::table(
                        'egc_payroll_employee_payroll_details'
                    )->insert([

                        'payroll_employee_sno' =>
                        $employeePayrollId,
                        'payroll_component_sno' =>
                        $component['sno'] ?? null,

                        'component_name' =>
                        $component['component'],

                        'component_category' =>
                        $component['type'],

                        'calculation_type' =>
                        $component['calculation_type']
                            ?? 'fixed',

                        'percentage_value' =>
                        $component['percentage']
                            ?? 0,

                        'actual_amount' =>
                        $component['amount'],

                        'calculated_amount' =>
                        $component['amount'],

                        'created_at' => now(),

                        'updated_at' => now(),
                    ]);
                }

                /*
                |--------------------------------------------------------------------------
                | TOTALS
                |--------------------------------------------------------------------------
                */

                $totalGross +=
                    $payroll['earnings'];

                $totalDeduction +=
                    $payroll['deductions'];

                $totalNet +=
                    $payroll['net_salary'];

                $processedCount++;

                /*
                |--------------------------------------------------------------------------
                | UPDATE LIVE PROCESS
                |--------------------------------------------------------------------------
                */

                DB::table('egc_payroll_processes')
                    ->where('sno', $processId)
                    ->update([

                        'processed_employees' =>
                        $processedCount,

                        'total_gross' =>
                        round($totalGross, 2),

                        'total_deduction' =>
                        round($totalDeduction, 2),

                        'total_netpay' =>
                        round($totalNet, 2),
                    ]);

                DB::table('egc_payroll_payslips')
                    ->insert([
                        'payroll_employee_sno' => $employeePayrollId,
                        'payroll_process_sno' => $processId,
                        'employee_sno' => $employee->sno,
                        'payroll_month' =>  $month,
                        'payslip_no' => 'PSLIP-' . $employee->sno . '-' . $month,
                        'generated_date' => now(),
                        'pdf_path' => null,
                    ]);
            }
            /*
            |--------------------------------------------------------------------------
            | COMPLETE
            |--------------------------------------------------------------------------
            */
            DB::table('egc_payroll_processes')
                ->where('sno', $processId)
                ->update([
                    'process_status' => 'completed',
                    'updated_at' => now()
                ]);
            DB::commit();

            return [
                'status' => true,
                'process_id' => $processId
            ];
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }
}
