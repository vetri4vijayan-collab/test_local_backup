<?php

namespace App\Services;

class PromptBuilderService
{
    /**
     * Build Prompt for Role Matching
     */
    public function roleMatching(
        string $resume,
        array $roles
    ): string {

        $roles = json_encode(
            $roles,
            JSON_UNESCAPED_UNICODE
        );

        $resume = trim(
            mb_substr($resume,0,6000)
        );

        return <<<PROMPT
You are an advanced AI Recruitment ATS.

You are NOT allowed to create your own roles.

Match the candidate ONLY against the supplied roles.

Rules:

1. Use ONLY role_id values provided.
2. Never invent a role.
3. Return maximum 3 roles.
4. Sort by confidence descending.
5. Confidence must be between 0 and 100.
6. Consider:
   - Job Titles
   - Skills
   - Technologies
   - Responsibilities
   - Experience
   - Domain
7. Ignore formatting mistakes.
8. Return JSON ONLY.

Available Roles

$roles

Candidate Resume

$resume

Output

{
    "matches":[
        {
            "role_id":1,
            "confidence":97,
            "reason":"Primary skills strongly match this role."
        },
        {
            "role_id":5,
            "confidence":88,
            "reason":"Secondary match."
        }
    ]
}
PROMPT;

    }

    /**
     * Resume Summary
     */
    public function resumeSummary(
        string $resume
    ): string {

        return <<<PROMPT
Summarize this resume.

Return JSON only.

{
    "summary":"",
    "experience_years":"",
    "education":"",
    "strengths":[]
}

Resume

$resume
PROMPT;

    }

    /**
     * Skill Extraction
     */
    public function skillExtraction(
        string $resume
    ): string {

        return <<<PROMPT
Extract all technical and non-technical skills.

Return JSON only.

{
    "technical_skills":[],
    "soft_skills":[]
}

Resume

$resume
PROMPT;

    }

    /**
     * Experience Extraction
     */
    public function experienceExtraction(
        string $resume
    ): string {

        return <<<PROMPT
Extract work experience.

Return JSON only.

{
   "experience":[
      {
         "company":"",
         "designation":"",
         "duration":"",
         "skills":[]
      }
   ]
}

Resume

$resume
PROMPT;

    }

    /**
     * Interview Questions
     */
    public function interviewQuestions(
        string $resume,
        string $role
    ): string {

        return <<<PROMPT
Generate 10 interview questions.

Role

$role

Resume

$resume

Return JSON only.

{
    "questions":[]
}
PROMPT;

    }

    /**
     * Resume Score
     */
    public function resumeScore(
        string $resume
    ): string {

        return <<<PROMPT
Score the resume out of 100.

Return JSON only.

{
    "score":0,
    "remarks":""
}

Resume

$resume
PROMPT;

    }
/**
 * Batch Role Matching + ATS Resume Evaluation
 */
// public function batchRoleMatching(
//     array $applicants,
//     array $roles
// ): string {


//     /*
//     |--------------------------------------------------------------------------
//     | Prepare Applicants
//     |--------------------------------------------------------------------------
//     */

//     $resumeData = [];


//     foreach ($applicants as $row) {


//         $resumeData[] = [

//             "applicant_id"=>$row['sno'],

//             "resume"=>trim(
//                 mb_substr(
//                     $row['resume'],
//                     0,
//                     5000
//                 )
//             )

//         ];

//     }



//     /*
//     |--------------------------------------------------------------------------
//     | Roles JSON
//     |--------------------------------------------------------------------------
//     */

//     $rolesJson = json_encode(

//         $roles,

//         JSON_PRETTY_PRINT |
//         JSON_UNESCAPED_UNICODE

//     );



//     /*
//     |--------------------------------------------------------------------------
//     | Resume JSON
//     |--------------------------------------------------------------------------
//     */

//     $resumeJson = json_encode(

//         $resumeData,

//         JSON_PRETTY_PRINT |
//         JSON_UNESCAPED_UNICODE

//     );



//     return <<<PROMPT

//     You are an Enterprise AI Recruitment ATS System.

//     SYSTEM MESSAGE:

//     You are a JSON API service.

//     Your output is consumed by PHP json_decode().

//     You MUST never talk to the user.

//     You MUST never explain your answer.

//     Only return machine readable JSON.

//     You act as both:

//     1. ATS Resume Screening Engine
//     2. Senior HR Recruiter


//     Your task:

//     For every applicant:

//     A) Match the resume with suitable job roles.

//     B) Generate overall resume ATS evaluation.



//     ===========================
//     ROLE MATCHING RULES
//     ===========================


//     1. Use ONLY supplied role_id.
//     2. Never create new roles.
//     3. Never modify role_id.
//     4. Maximum 3 role matches.
//     5. Sort confidence highest first.
//     6. Confidence must be 0-100.
//     7. Every applicant must return matches.



//     ===========================
//     ATS EVALUATION RULES
//     ===========================


//     Evaluate the COMPLETE resume.

//     Do NOT evaluate separately for each role.


//     Generate:


//     1. Overall Match Score
//     2. ATS Keyword Match Score
//     3. Skills Alignment Score
//     4. Experience Relevance Score
//     5. Impact & Achievement Score

//     (Check measurable achievements:
//     %, numbers, revenue, efficiency, growth)

//     6. Role Responsibility Match Score


//     Also identify:

//     - Missing keywords
//     - Candidate strengths
//     - Candidate weaknesses
//     - Resume improvements
//     - Achievement focused bullet rewrites
//     - Professional summary



//     ===========================
//     CRITICAL OUTPUT RULES
//     ===========================


//     FOLLOW THESE RULES STRICTLY:


//     1. RETURN ONLY ONE JSON OBJECT.

//     2. DO NOT RETURN MULTIPLE JSON OBJECTS.

//     3. DO NOT CREATE SEPARATE OUTPUT FOR EACH APPLICANT.

//     4. DO NOT WRITE:
//     Applicant 1:
//     Applicant 2:
//     Candidate 1:
//     Candidate 2:

//     5. DO NOT ADD:
//     - explanations
//     - notes
//     - comments
//     - markdown
//     - ```json blocks

//     6. The entire response must start with {

//     7. The entire response must end with }

//     8. Every applicant must be inside the SAME "results" array.

//     9. Maintain applicant_id exactly as provided.

//     10. If any applicant has no suitable role, still return:

//     {
//     "matches":[]
//     }

//     11. Never remove any applicant from results.

//     12. JSON keys must remain exactly:
//         results
//         applicant_id
//         matches
//         role_id
//         confidence
//         reason
//         ai_response


//     YOUR RESPONSE WILL BE PARSED DIRECTLY USING JSON DECODER.
//     ANY TEXT OUTSIDE JSON WILL CAUSE FAILURE.


//     AVAILABLE ROLES:


//     $rolesJson



//     APPLICANTS:


//     $resumeJson



//     OUTPUT FORMAT:


//     {
//     "results":[

//     {

//     "applicant_id":"11",


//     "matches":[

//     {
//     "role_id":1,
//     "confidence":95,
//     "reason":"Strong skill match"
//     }

//     ],



//     "ai_response":{

//     "overall_match_score":0,

//     "ats_keyword_match_score":0,

//     "skills_alignment_score":0,

//     "experience_relevance_score":0,

//     "impact_metrics_score":0,

//     "role_responsibility_match_score":0,


//     "missing_keywords":[],

//     "strengths":[],

//     "weaknesses":[],

//     "resume_improvements":[],

//     "rewritten_bullets":[],

//     "optimized_summary":""

//     }

//     }

//     ]

//     }


//     PROMPT;

// }

public function batchRoleMatching(
    array $applicants,
    array $roles
): string {


    /*
    |--------------------------------------------------------------------------
    | Prepare Applicants
    |--------------------------------------------------------------------------
    */

    $resumeData = [];


    foreach ($applicants as $row) {


        $resumeData[] = [

            "applicant_id"=>$row['sno'],

            "resume"=>trim(
                mb_substr(
                    $row['resume'],
                    0,
                    5000
                )
            )

        ];

    }



    /*
    |--------------------------------------------------------------------------
    | Roles JSON
    |--------------------------------------------------------------------------
    */

    $rolesJson = json_encode(

        $roles,

        JSON_PRETTY_PRINT |
        JSON_UNESCAPED_UNICODE

    );



    /*
    |--------------------------------------------------------------------------
    | Resume JSON
    |--------------------------------------------------------------------------
    */

    $resumeJson = json_encode(

        $resumeData,

        JSON_PRETTY_PRINT |
        JSON_UNESCAPED_UNICODE

    );



        return <<<PROMPT

        You are Enterprise Recruitment ATS AI Version 1.

        SYSTEM ROLE

        You are an internal Recruitment Intelligence Engine.
        Your output is consumed directly by a Laravel backend using json_decode().
        You MUST return ONLY one valid JSON object.
        Never return markdown.
        Never return explanations.
        Never return comments.
        Never return notes.
        Never return code fences.
        Never return additional text.
        Your first character MUST be {
        Your last character MUST be }

        ==================================================
        PRIMARY OBJECTIVE
        ==================================================

        For EVERY applicant:

        1. Analyse the complete resume.
        2. Match ONLY against the supplied company job roles.
        3. Produce a detailed ATS recruiter evaluation.

        ==================================================
        IMPORTANT ROLE MATCHING RULES
        ==================================================

        The supplied roles represent ALL available roles in the company.
        You are NOT allowed to invent roles.
        You are NOT allowed to modify role_id.
        You are NOT allowed to guess a role.
        If none of the supplied roles are suitable,

        Return

        "matches":[]

        This is a VALID response.

        Never assign an unrelated role simply because it is the closest one.
        Match ONLY when the resume clearly satisfies the role.

        Evaluate using

        • Current Job Title
        • Previous Job Titles
        • Skills
        • Programming Languages
        • Frameworks
        • Databases
        • Cloud Platforms
        • DevOps
        • Certifications
        • Responsibilities
        • Domain Knowledge
        • Industry Experience
        • Seniority
        • Education
        • Years of Experience

        Confidence Rules

        95-100
        Outstanding fit

        85-94
        Strong fit

        70-84
        Good fit

        40-69
        Possible fit

        Below 40
        Do NOT return the role.

        Maximum 1 role.

        If confidence is below 40

        Return

        "matches":[]

        Reason must be less than 30 words.

        ==================================================
        ATS EVALUATION
        ==================================================

        Evaluate the entire resume.
        Do NOT evaluate against a specific role.
        Generate objective recruiter feedback.
        Scores must be between 0 and 100.
        Generate
        overall_match_score
        ats_keyword_match_score
        skills_alignment_score
        experience_relevance_score
        impact_metrics_score
        role_responsibility_match_score

        ==================================================
        IMPACT ANALYSIS
        ==================================================

        Check whether the resume contains measurable achievements.

        Examples

        Reduced costs
        Increased revenue
        Improved performance
        Improved productivity
        Automation
        Leadership
        Team size
        KPIs
        Awards
        Percentages
        Metrics

        ==================================================
        MISSING KEYWORDS
        ==================================================

        Return only important missing technical or domain keywords.
        Do not invent irrelevant keywords.
        Maximum 15 keywords.

        ==================================================
        STRENGTHS
        ==================================================

        Return 5 to 8 recruiter observations.

        Examples

        Strong backend experience
        Leadership
        Enterprise projects
        Cloud exposure
        Problem solving
        Team collaboration
        Architecture knowledge

        ==================================================
        WEAKNESSES
        ==================================================

        Return factual weaknesses only.

        Do not insult the candidate.

        Examples

        No cloud exposure
        No testing experience
        No measurable achievements
        Short employment duration
        Missing certifications

        ==================================================
        RESUME IMPROVEMENTS
        ==================================================

        Return practical recruiter recommendations.

        Maximum 8 items.

        Examples

        Add measurable achievements
        Improve project descriptions
        Include GitHub
        Add certifications
        Improve ATS keywords

        ==================================================
        REWRITTEN BULLETS
        ==================================================

        Rewrite ONLY weak resume bullets.

        Convert them into strong ATS-friendly statements.

        Maximum 5 bullets.

        ==================================================
        OPTIMIZED SUMMARY
        ==================================================

        Generate a professional ATS summary.

        Maximum 120 words.

        ==================================================
        GENERAL RULES
        ==================================================

        Do NOT hallucinate.
        Do NOT invent companies.
        Do NOT invent projects.
        Do NOT invent skills.
        Do NOT invent experience.
        If information is missing,
        State it as a weakness.
        Never assume.

        ==================================================
        JSON RULES
        ==================================================

        Return EXACTLY

        {
        "results":[]
        }

        Every applicant MUST appear.
        Never skip applicants.
        Maintain applicant_id exactly.
        Maintain role_id exactly.
        Use EXACT key names.

        results

        applicant_id
        matches
        role_id
        confidence
        reason
        ai_response
        overall_match_score
        ats_keyword_match_score
        skills_alignment_score
        experience_relevance_score
        impact_metrics_score
        role_responsibility_match_score
        missing_keywords
        strengths
        weaknesses
        resume_improvements
        rewritten_bullets
        optimized_summary

        ==================================================
        AVAILABLE COMPANY ROLES
        ==================================================
        $rolesJson

        ==================================================
        APPLICANTS
        ==================================================
        $resumeJson

        ==================================================
        OUTPUT FORMAT
        ==================================================
        {
        "results":[
            {
            "applicant_id":"11",
            "matches":[
                {
                "role_id":5,
                "confidence":91,
                "reason":"Strong Laravel, PHP and MySQL enterprise development experience."
                }
            ],
            "ai_response":{
                "overall_match_score":91,
                "ats_keyword_match_score":87,
                "skills_alignment_score":93,
                "experience_relevance_score":90,
                "impact_metrics_score":74,
                "role_responsibility_match_score":89,
                "missing_keywords":[
                    "Docker",
                    "Redis",
                    "CI/CD"
                ],
                "strengths":[
                    "...",
                    "...",
                    "..."
                ],
                "weaknesses":[
                    "...",
                    "...",
                    "..."
                ],
                "resume_improvements":[
                    "...",
                    "...",
                    "..."
                ],
                "rewritten_bullets":[
                    "...",
                    "...",
                    "..."
                ],
                "optimized_summary":"..."
            }

            }
        ]
        }


        PROMPT;

}


}