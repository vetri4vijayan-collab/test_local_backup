<?php

namespace App\Services;

use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;
use App\Helpers\PayrollFormulaHelper;

class PayrollProcessService
{
    protected $previewService;

    public function __construct(
        PayrollPreviewService $previewService
    ) {
        $this->previewService = $previewService;
    }

    public function process($month, $year, $user_id)
    {
        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | CREATE PROCESS
            |--------------------------------------------------------------------------
            */
            $endOfMonth = date('Y-m-t', strtotime("$year-$month-01"));
            $processId = DB::table('egc_payroll_processes')
                ->insertGetId([
                    'payroll_month' => $month,
                    'payroll_year' => $year,
                    'payroll_name' =>
                    'Payroll ' .
                        Carbon::create($year, $month)
                        ->format('F Y'),

                    'payroll_start_date' =>
                    Carbon::create($year, $month, 1),

                    'payroll_end_date' =>
                    Carbon::create($year, $month, 1)
                        ->endOfMonth(),

                    'process_status' => 'processing',

                    'processed_at' => now(),
                    'processed_by' => $user_id,

                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'created_at' => now(),

                    'updated_at' => now(),
                ]);

            /*
            |--------------------------------------------------------------------------
            | EMPLOYEES
            |--------------------------------------------------------------------------
            */

            $employees = DB::table('egc_staff')
                ->where('egc_staff.status','!=', 2)
                ->where(function ($q) use ($month, $year) {
                    /*
                    |--------------------------------------------------------------------------
                    | ACTIVE STAFF
                    |--------------------------------------------------------------------------
                    */
                    $q->whereIn('egc_staff.status', [0, 1]);
                    /*
                    |--------------------------------------------------------------------------
                    | NOTICE PERIOD STAFF
                    |--------------------------------------------------------------------------
                    */
                    $q->orWhere(function ($notice) use ($month, $year) {
                        $notice->where('status', 4)
                            ->whereNotNull('notice_end_date')
                            ->whereMonth(
                                'notice_end_date',
                                $month
                            )
                            ->whereYear(
                                'notice_end_date',
                                $year
                            );
                    });
                    /*
                    |--------------------------------------------------------------------------
                    | EXITED STAFF
                    |--------------------------------------------------------------------------
                    */
                     $q->orWhere(function ($exit) use ($month, $year) {
                        $exit->whereIn('egc_staff.status', [5, 6, 7])
                            ->whereNotNull('egc_staff.staff_last_date')
                            ->whereMonth('egc_staff.staff_last_date', $month)
                            ->whereYear('egc_staff.staff_last_date', $year)
                            ->whereNotIn('egc_staff.sno', [211,212, 94,77]) // exclude special staff
                            ->whereRaw(
                                'DATEDIFF(egc_staff.staff_last_date, egc_staff.date_of_joining) > ?',
                                [3]
                            );
                    })

                    ->orWhere(function ($special) use ($month, $year) {

                        $payrollMonth = sprintf('%04d-%02d', $year, $month);

                        $special->whereIn('egc_staff.sno', [211,212,94,77])
                            ->whereIn('egc_staff.status', [5, 6, 7])
                            ->whereNotNull('egc_staff.staff_last_date')
                            ->whereRaw(
                                "? BETWEEN DATE_FORMAT(egc_staff.date_of_joining, '%Y-%m')
                                AND DATE_FORMAT(DATE_SUB(egc_staff.staff_last_date, INTERVAL 1 MONTH), '%Y-%m')",
                                [$payrollMonth]
                            )
                            ->whereRaw(
                                'DATEDIFF(egc_staff.staff_last_date, egc_staff.date_of_joining) > ?',
                                [3]
                            );
                    });
                })
                ->whereDate('date_of_joining', '<=', $endOfMonth)
                ->where('sno', '>', 0)
                // ->where('role_id', '!=', 1)
                ->get();

            $totalEmployees = $employees->count();

            DB::table('egc_payroll_processes')
                ->where('sno', $processId)
                ->update([
                    'total_employees' => $totalEmployees,
                    'updated_by' => $user_id,
                ]);

            $processedCount = 0;

            $totalGross = 0;
            $totalDeduction = 0;
            $totalNet = 0;

            /*
            |--------------------------------------------------------------------------
            | PROCESS EACH EMPLOYEE
            |--------------------------------------------------------------------------
            */

            foreach ($employees as $employee) {

                /*
                |--------------------------------------------------------------------------
                | LIVE ENGINE
                |--------------------------------------------------------------------------
                */

                $payroll =
                    $this->previewService
                    ->calculateLivePayroll(
                        $employee,
                        $month,
                        $year
                    );

                /*
                |--------------------------------------------------------------------------
                | SAVE ATTENDANCE SUMMARY
                |--------------------------------------------------------------------------
                */

                DB::table(
                    'egc_payroll_attendance_summaries'
                )->insert([

                    'payroll_month' => $month,

                    'payroll_process_sno' => $processId,
                    'employee_sno' => $employee->sno,

                    'present_days' =>
                    $payroll['present_days'],

                    'absent_days' =>
                    $payroll['absent_days'],

                    'paid_leave_days' =>
                    $payroll['leave_days'],

                    'weekoff_days' =>
                    $payroll['weekoff_days'],

                    'holiday_days' =>
                    $payroll['holiday_days'],

                    'payable_days' =>
                    $payroll['earning_days'],

                    'lop_days' =>
                    $payroll['lop_days'],

                    'late_mark_count' =>
                    $payroll['late_count'],

                    'created_at' => now(),

                    'updated_at' => now(),
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);

                /*
                |--------------------------------------------------------------------------
                | SAVE EMPLOYEE PAYROLL
                |--------------------------------------------------------------------------
                */

                $employeePayrollId =
                    DB::table(
                        'egc_payroll_employee_payrolls'
                    )->insertGetId([

                        'payroll_process_sno' =>
                        $processId,

                        'payroll_month' => $month,

                        'payroll_year' => $year,

                        'staff_id' =>
                        $employee->sno,

                        'employee_structure_sno' =>
                        $employee->employee_structure_sno ?? null,

                        'department_sno' =>
                        $employee->department_id ?? null,

                        'designation_sno' =>
                        $employee->job_role_id ?? null,

                        /*
                            |------------------------------------------------------------------
                            | SALARY
                            |------------------------------------------------------------------
                            */
                        'fixed_salary' =>  $employee->basic_salary ?? 0,
                        'gross_earnings' =>
                        round($payroll['earnings'], 2),

                        'gross_deductions' =>
                        round($payroll['deductions'], 2),

                        'employer_contribution' =>
                        round($payroll['employer_contribution'], 2),

                        'net_payable' =>
                        round($payroll['net_salary'], 2),

                        'ctc_amount' =>
                        round($payroll['monthly_ctc'], 2),

                        /*
                            |------------------------------------------------------------------
                            | DAYS
                            |------------------------------------------------------------------
                            */

                        'payable_days' =>
                        round($payroll['earning_days'], 2),

                        'lop_days' =>
                        round($payroll['lop_days'], 2),

                        'paid_days' =>
                        round($payroll['present_days'], 2),

                        /*
                            |------------------------------------------------------------------
                            | EXTRA
                            |------------------------------------------------------------------
                            */

                        'total_ot_hours' => 0,
                        'total_ot_amount' => 0,
                        'total_reimbursement' => 0,
                        'total_bonus' => 0,
                        'total_arrear' => 0,

                        /*
                            |------------------------------------------------------------------
                            | STATUS
                            |------------------------------------------------------------------
                            */

                        'payroll_status' => 'processed',

                        'salary_lock' => 0,

                        'processed_at' => now(),

                        'status' => 0,



                        'created_at' => now(),

                        'updated_at' => now(),
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]);

                /*
                |--------------------------------------------------------------------------
                | SAVE COMPONENTS
                |--------------------------------------------------------------------------
                */

                foreach (
                    $payroll['components']
                    as $component
                ) {

                    DB::table(
                        'egc_payroll_employee_payroll_details'
                    )->insert([

                        'payroll_employee_sno' =>
                        $employeePayrollId,
                        'payroll_component_sno' =>
                        $component['sno'] ?? null,

                        'component_name' =>
                        $component['component'],

                        'component_category' =>
                        $component['type'],

                        'calculation_type' =>
                        $component['calculation_type']
                            ?? 'fixed',

                        'percentage_value' =>
                        $component['percentage']
                            ?? 0,

                        'actual_amount' =>
                        $component['amount'],

                        'calculated_amount' =>
                        $component['amount'],

                        'created_at' => now(),

                        'updated_at' => now(),
                    ]);
                }

                /*
                |--------------------------------------------------------------------------
                | TOTALS
                |--------------------------------------------------------------------------
                */

                $totalGross +=
                    $payroll['earnings'];

                $totalDeduction +=
                    $payroll['deductions'];

                $totalNet +=
                    $payroll['net_salary'];

                $processedCount++;

                /*
                |--------------------------------------------------------------------------
                | UPDATE LIVE PROCESS
                |--------------------------------------------------------------------------
                */

                DB::table('egc_payroll_processes')
                    ->where('sno', $processId)
                    ->update([

                        'processed_employees' =>
                        $processedCount,

                        'total_gross' =>
                        round($totalGross, 2),

                        'total_deduction' =>
                        round($totalDeduction, 2),

                        'total_netpay' =>
                        round($totalNet, 2),
                        'updated_by' => $user_id,
                    ]);

                DB::table('egc_payroll_payslips')
                    ->insert([
                        'payroll_employee_sno' => $employeePayrollId,
                        'payroll_process_sno' => $processId,
                        'employee_sno' => $employee->sno,
                        'payroll_month' =>  $month,
                        'payslip_no' => 'PSLIP-' . $employee->sno . '-' . $month,
                        'generated_date' => now(),
                        'pdf_path' => null,
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]);
            }

            /*
            |--------------------------------------------------------------------------
            | COMPLETE
            |--------------------------------------------------------------------------
            */

            DB::table('egc_payroll_processes')
                ->where('sno', $processId)
                ->update([
                    'process_status' => 'completed',
                    'updated_by' => $user_id,
                    'updated_at' => now()
                ]);

            DB::commit();

            return [
                'status' => true,
                'process_id' => $processId
            ];
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }
}
