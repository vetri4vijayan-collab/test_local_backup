<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;


class RoleCandidateService
{

    protected ResumeFeatureExtractorService $feature;

    public function __construct(
        ResumeFeatureExtractorService $feature
    ){

        $this->feature=$feature;

    }

    /**
     * Return top candidate roles
     */
    public function getCandidateRoles(
        string $resume,
        int $limit = 20
    ): array {

        $features=$this->feature->extract($resume);

        $roles = Cache::rememberForever(
            'recruitment_roles',
            function () {

                return DB::table('egc_recruitment_roles')
                    ->where('status', 0)
                    ->get([
                        'sno',
                        'jobrole_name'
                    ]);

            }
        );

        $scores = [];

        foreach ($roles as $role) {

            $this->feature->scoreRole(

                $features['tokens'],

                $role->jobrole_name

            );

            $scores[] = [

                'role_id' => $role->sno,

                'role_name' => $role->jobrole_name,

                'score' => $score

            ];

        }

        usort($scores, function ($a, $b) {

            return $b['score'] <=> $a['score'];

        });

        return array_slice(
            $scores,
            0,
            $limit
        );

    }

    /**
     * Calculate Similarity
     */
    private function calculateScore(
        string $resume,
        string $role
    ): float {

        $role = strtolower($role);

        similar_text(
            $resume,
            $role,
            $percent
        );

        $tokenScore = 0;

        $words = preg_split(
            '/\s+/',
            $role
        );

        foreach ($words as $word) {

            if (strlen($word) < 3) {
                continue;
            }

            if (str_contains(
                $resume,
                $word
            )) {

                $tokenScore += 15;

            }

        }

        return $percent + $tokenScore;

    }

    /**
     * Clear Cache
     */
    public function clearCache()
    {

        Cache::forget(
            'recruitment_roles'
        );

    }

}