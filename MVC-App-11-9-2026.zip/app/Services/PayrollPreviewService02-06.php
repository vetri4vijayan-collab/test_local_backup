<?php

namespace App\Services;

use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;
use App\Helpers\PayrollFormulaHelper;

class PayrollPreviewService
{

    public function calculateLivePayroll($staff, $month, $year)
    {

    
        /*
|--------------------------------------------------------------------------
| PAYROLL PERIOD
|--------------------------------------------------------------------------
*/

$payrollStart =
    Carbon::create($year,$month,1)
    ->startOfMonth();

$payrollEnd =
    Carbon::create($year,$month,1)
    ->endOfMonth();

/*
|--------------------------------------------------------------------------
| JOINING MONTH
|--------------------------------------------------------------------------
*/

$joiningDate =
    Carbon::parse(
        $staff->date_of_joining
    );

if(
    $joiningDate->month==$month &&
    $joiningDate->year==$year
){

    $payrollStart=$joiningDate;

}

/*
|--------------------------------------------------------------------------
| NOTICE PERIOD
|--------------------------------------------------------------------------
*/

if(
    !empty($staff->notice_end_date) &&
    $staff->status==4
){

    $noticeEnd=
        Carbon::parse(
            $staff->notice_end_date
        );

    if(
        $noticeEnd->month==$month &&
        $noticeEnd->year==$year
    ){

        $payrollEnd=$noticeEnd;

    }

}

/*
|--------------------------------------------------------------------------
| EXIT STAFF
|--------------------------------------------------------------------------
*/

if(
    !empty($staff->staff_last_date) &&
    in_array($staff->status,[5,6,7])
){

    $exitDate=
        Carbon::parse(
            $staff->staff_last_date
        );

    if(
        $exitDate->month==$month &&
        $exitDate->year==$year
    ){

        $payrollEnd=$exitDate;

    }

}

/*
|--------------------------------------------------------------------------
| CURRENT MONTH LIMIT
|--------------------------------------------------------------------------
*/

if(
    $month==date('m') &&
    $year==date('Y')
){

    $today=Carbon::today();

    if($today < $payrollEnd){

        $payrollEnd=$today;

    }

}

/*
|--------------------------------------------------------------------------
| ATTENDANCE FETCH
|--------------------------------------------------------------------------
*/

$attendance =
DB::table('egc_staff_attendance')

->where(
    'staff_id',
    $staff->sno
)

->whereBetween(
    'date',
    [
        $payrollStart->format('Y-m-d'),
        $payrollEnd->format('Y-m-d')
    ]
)

->where(
    'status',
    0
)

->get();

        $holidayDates = $this->getHolidayDates(
            $payrollStart,
            $payrollEnd
        );

        $presentDays     = 0;
        $absentDays      = 0;
        $leaveDays       = 0;
        $permissionDays  = 0;
        $ondutyDays      = 0;

        foreach ($attendance as $att) {

            if ($holidayDates->contains($att->date)) {
                continue;
            }


            if ($att->attendance == 'P') {
                $presentDays += 1;
            }


            if ($att->attendance == 'OD') {
                $ondutyDays += 1;
                $presentDays += 1;
            }

            if ($att->attendance == 'PR') {
                $permissionDays += 1;
                $presentDays += 1;
            }


            if ($att->attendance == 'A') {
                $absentDays += 1;
            }

            /*
            |--------------------------------------------------------------------------
            | LEAVE
            |--------------------------------------------------------------------------
            */

            if ($att->attendance == 'L') {

                if ($att->leave_type == 'full') {

                    $leaveDays += 1;
                    $absentDays += 1;
                }

                if (
                    in_array(
                        $att->leave_type,
                        ['first_half', 'second_half']
                    )
                ) {

                    $leaveDays += 0.5;
                    $absentDays += 0.5;
                }
            }
        }


        $lateCount = $this->getLateCount(
            $staff->sno,
            $month,
            $year
        );


        $weekOffCount = $this->getWeekOffCount(
            $month,
            $year
        );



        $holidayCount = $holidayDates->count();

        $basicSalary = (float)($staff->basic_salary ?? 0);

        $perDaySalary = (float)($staff->per_day_salary ?? 0);

 

       $joiningDate = Carbon::parse($staff->date_of_joining);

        $payrollStart = Carbon::create($year, $month, 1)->startOfMonth();
        $payrollEnd   = Carbon::create($year, $month, 1)->endOfMonth();

        /*
        |--------------------------------------------------------------------------
        | JOINING MONTH
        |--------------------------------------------------------------------------
        */
        if (
            $joiningDate->month == $month &&
            $joiningDate->year == $year
        ) {
            $payrollStart = $joiningDate;
        }

        /*
        |--------------------------------------------------------------------------
        | NOTICE PERIOD MONTH
        |--------------------------------------------------------------------------
        */
        if (
            !empty($staff->notice_end_date) &&
            $staff->status == 4
        ) {

            $noticeEndDate = Carbon::parse($staff->notice_end_date);

            if (
                $noticeEndDate->month == $month &&
                $noticeEndDate->year == $year
            ) {
                $payrollEnd = $noticeEndDate;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | EXIT MONTH
        |--------------------------------------------------------------------------
        */
        if (
            !empty($staff->staff_last_date) &&
            in_array($staff->status, [5,6,7])
        ) {

            $exitDate = Carbon::parse($staff->staff_last_date);

            if (
                $exitDate->month == $month &&
                $exitDate->year == $year
            ) {
                $payrollEnd = $exitDate;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | CURRENT MONTH LIMIT
        |--------------------------------------------------------------------------
        */
        if (
            (int)$month == (int)date('m') &&
            (int)$year == (int)date('Y')
        ) {

            $today = Carbon::today();

            if ($today < $payrollEnd) {
                $payrollEnd = $today;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | RECALCULATE EARNING DAYS
        |--------------------------------------------------------------------------
        */
        $earningDays = 0;

        foreach (
            CarbonPeriod::create($payrollStart, $payrollEnd)
            as $date
        ) {

            $dateKey = $date->format('Y-m-d');

            // Holiday
            if ($holidayDates->contains($dateKey)) {
                $earningDays++;
                continue;
            }

            // Weekoff
            if ($date->isSunday()) {
                $earningDays++;
                continue;
            }

            // Attendance
            $att = $attendance->firstWhere('date', $dateKey);

            if (!$att) {
                continue;
            }

            if (in_array($att->attendance, ['P','PR','OD'])) {
                $earningDays++;
            }

            if (
                $att->attendance == 'L' &&
                in_array($att->leave_type, ['first_half','second_half'])
            ) {
                $earningDays += 0.5;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | BASIC EARNED
        |--------------------------------------------------------------------------
        */
        $isPartialMonth =
            $payrollStart->day != 1 ||
            $payrollEnd->day != $payrollEnd->copy()->endOfMonth()->day;

        $isProrated =
            ($joiningDate->month == $month &&
            $joiningDate->year == $year)
            ||
            (!empty($staff->staff_last_date) &&
            Carbon::parse($staff->staff_last_date)->month == $month &&
            Carbon::parse($staff->staff_last_date)->year == $year)
            ||
            (!empty($staff->notice_end_date) &&
            Carbon::parse($staff->notice_end_date)->month == $month &&
            Carbon::parse($staff->notice_end_date)->year == $year);

        if ($isProrated) {
            $basicEarned = round($earningDays * $perDaySalary, 2);
        } else {
            $allowedLeave =$staff->casual_leave_count_per_month ?? 0;
            $earningDays = 30 - max(0, $absentDays - $allowedLeave);
            $basicEarned = $basicSalary;
        }

       
        $payrollDate = Carbon::create($year, $month, 1)->endOfMonth();
        

        $structure = DB::table('egc_payroll_employee_structures')
            ->where('employee_sno', $staff->sno)
            ->where('status', 0)
            ->whereDate('effective_from', '<=', $payrollDate)
            ->orderByDesc('effective_from')
            ->first();

        if (!$structure) {

            return [
                'staff_id' => $staff->sno,
                'staff_name' => $staff->staff_name,
                'basic_salary' => 0,
                'gross_salary' =>0,
                'earnings' => 0,
                'deductions' => 0,
                'net_salary' => 0,
                'lop_days' => 0,
                'lop_amount' => 0,
                'present_days' => 0,
                'absent_days' => 0,
                'leave_days' => 0,
                'permission_days' => 0,
                'onduty_days' => 0,
                'late_count' => 0,
                'weekoff_days' => 0,
                'holiday_days' => 0,
                'earning_days' => 0,
                'components' => [],
                'employer_contribution' =>0,
                'monthly_ctc' =>0
            ];
        }

        $salaryComponents = DB::table(
            'egc_payroll_employee_structure_details as esd'
        )
            ->join(
                'egc_payroll_components as pc',
                'pc.sno',
                '=',
                'esd.payroll_component_sno'
            )
            ->where(
                'esd.payroll_employee_structure_sno',
                $structure->sno
            )
            ->where('esd.status', 0)
            ->orderBy('esd.display_order')
            ->select(
                'pc.sno',
                'pc.component_name',
                'pc.category as component_type',
                'pc.calculation_type',
                'pc.component_code',
                'esd.percentage_value',
                'esd.fixed_amount',
                'esd.calculated_amount',
                'esd.calculation_type as structure_calculation_type'
            )
            ->get();

            // return $structure;

        $grossSalary      = 0;
        $totalEarnings    = 0;
        $totalDeductions  = 0;

        $componentBreakdown = [];






        $componentVariables = [

            'basic' => $basicEarned,
            'basic_salary' => $basicEarned,
            'gross_salary' => $grossSalary,
        ];


        $totalEmployerContribution = 0;

        $basic = 0;
        $da = 0;
        foreach ($salaryComponents as $component) {

            $amount = 0;

            $calculationType =
                $component->structure_calculation_type
                ?? $component->calculation_type;

            /*
            |--------------------------------------------------------------------------
            | PERCENTAGE
            |--------------------------------------------------------------------------
            */

            if ($calculationType == 'percentage') {

                $percentage =
                    (float)$component->percentage_value;

                $componentCode = strtoupper($component->component_code);

                /*
                |--------------------------------------------------------------------------
                | PF = BASIC + DA
                |--------------------------------------------------------------------------
                */

                if ($componentCode == 'PF') {

                    $pfBase = $basic + $da;

                    $amount =
                    $pfBase > 15000
                    ? 1800
                    : ($pfBase * $percentage) / 100;

                    
                }

                /*
                |--------------------------------------------------------------------------
                | ESI = GROSS
                |--------------------------------------------------------------------------
                */ 
                else if ($componentCode == 'ESI') {

                    $esiBase = $basic + $da;

                    // $amount =
                    //     $basicEarned <= 21000
                    //     ? ($basicEarned * $percentage) / 100
                    //     : 0;

                    $amount =
                        $esiBase <= 21000
                        ? ($esiBase * $percentage) / 100
                        : 0;
                }

                /*
                |--------------------------------------------------------------------------
                | DEFAULT PERCENTAGE
                |--------------------------------------------------------------------------
                */
                else {

                    $amount =
                        ($basicEarned * $percentage) / 100;
                }
            }

            /*
            |--------------------------------------------------------------------------
            | FIXED
            |--------------------------------------------------------------------------
            */

            if ($calculationType == 'fixed') {
                $amount = (float)$component->fixed_amount;
            }

            /*
            |--------------------------------------------------------------------------
            | FORMULA
            |--------------------------------------------------------------------------
            */

            if ($calculationType == 'formula') {

                $componentCode = strtoupper($component->component_code);

                if ($componentCode == 'LOP') {

                    $lopRule = DB::table('egc_payroll_rules')
                        ->where('rule_category', 'lop')
                        ->where('is_active', 1)
                        ->where('status', 0)
                        ->first();

                    if ($lopRule) {

                        $allowedLeave =
                            $staff->casual_leave_count_per_month ?? 0;

                        $lopDays =
                            max(0, $absentDays - $allowedLeave);

                        $variables = [

                            'lop_days' =>
                            $lopDays,

                            'per_day_salary' =>
                            (float)$staff->per_day_salary,

                            'basic' =>
                            $basic,

                            'da' =>
                            $da,

                            'gross_salary' =>
                            $grossSalary,
                        ];

                        $amount =
                            PayrollFormulaHelper::evaluate(
                                $lopRule->rule_expression,
                                $variables
                            );
                    }
                } else {

                    $formula =
                        $component->formula_expression
                        ?? '';

                    $amount =
                        PayrollFormulaHelper::evaluate(
                            $formula,
                            $componentVariables
                        );
                }
            }

            /*
        |--------------------------------------------------------------------------
        | MANUAL INPUT
        |--------------------------------------------------------------------------
        */

            // if ($calculationType == 'manual_input') {

            //     $amount =
            //         (float)$component->calculated_amount;
            // }
            if ($calculationType == 'manual_input') {



                if (
                    strtoupper($component->component_code)
                    == 'VARIABLE'
                ) {

                    $currentMonth =
                        Carbon::create($year, $month, 1)
                        ->format('Y-m-01');


                    $variableAmount =
                        DB::table('egc_payroll_variable_amounts')

                        ->where('employee_sno', $staff->sno)

                        ->where('status', 0)

                        ->where('is_expired', 0)

                        ->whereDate(
                            'start_month',
                            '<=',
                            $currentMonth
                        )

                        ->whereDate(
                            'end_month',
                            '>=',
                            $currentMonth
                        )

                        ->orderByDesc('sno')

                        ->first();



                    if ($variableAmount) {

                        $amount =
                            (float)$variableAmount->amount;
                    } else {

                        $amount = 0;
                    }
                }elseif (
                    strtoupper($component->component_code)
                    == 'ONDUTY'
                ) {

                    $currentMonthCheck =
                        Carbon::create($year, $month, 1)
                        ->format('M-Y');


                    $OtAmount =
                        DB::table('egc_payroll_ot_transactions')
                        ->where('employee_sno', $staff->sno)
                        ->where('status','!=', 2)
                        ->whereDate(
                            'payroll_month',
                            $currentMonthCheck
                        )
                        ->orderByDesc('sno')
                        ->sum('ot_amount');
                    if ($OtAmount) {

                        $amount = (float)$OtAmount;
                    } else {

                        $amount = 0;
                    }
                } else {

                    $amount =
                        (float)$component->calculated_amount;
                }
            }

            /*
            |--------------------------------------------------------------------------
            | EMPLOYER PF
            |--------------------------------------------------------------------------
            */

            if (
                strtoupper($component->component_code)
                == 'EMPLOYER_PF'
            ) {

                $pfBase = $basic + $da;

                $amount =
                    $pfBase > 15000
                    ? 1800
                    : ($pfBase * 0.12);
            }

            /*
        |--------------------------------------------------------------------------
        | EMPLOYER ESI
        |--------------------------------------------------------------------------
        */

            if (
                strtoupper($component->component_code)
                == 'EMPLOYER_ESI'
            ) {
                
                    if ($calculationType == 'fixed') {

                        $amount = $basicEarned <= 21000 ? $component->fixed_amount : 0;
                    }else{
                        $esiBase = $basic + $da;

                        $amount =
                            $esiBase <= 21000
                            ? ($esiBase * 0.0325)
                            : 0;
                    }

             
            }

            /*
            |--------------------------------------------------------------------------
            | ROUND
            |--------------------------------------------------------------------------
            */

            $amount = round($amount, 2);

            /*
        |--------------------------------------------------------------------------
        | EARNINGS
        |--------------------------------------------------------------------------
        */

            if ($component->component_type == 'earning') {

                $grossSalary += $amount;

                $totalEarnings += $amount;
            }

            /*
        |--------------------------------------------------------------------------
        | DEDUCTIONS
        |--------------------------------------------------------------------------
        */

            if ($component->component_type == 'deduction') {

                $totalDeductions += $amount;
            }


            /*
                |--------------------------------------------------------------------------
                | EMPLOYER CONTRIBUTION
                |--------------------------------------------------------------------------
                */

            if (
                $component->component_type
                == 'employer_contribution'
            ) {

                $totalEmployerContribution += $amount;
            }

            /*
        |--------------------------------------------------------------------------
        | FORMULA VARIABLES
        |--------------------------------------------------------------------------
        */

            $componentCode =
                strtolower($component->component_code);

            $componentVariables[$componentCode] = $amount;

            if (strtoupper($component->component_code) == 'BASIC') {
                $basic = $amount;
            }

            if (strtoupper($component->component_code) == 'DA') {
                $da = $amount;
            }

            /*
        |--------------------------------------------------------------------------
        | BREAKDOWN
        |--------------------------------------------------------------------------
        */

            $componentBreakdown[] = [
                'sno' =>
                $component->sno,
                'component' =>
                $component->component_name,

                'code' =>
                $component->component_code,

                'type' =>
                $component->component_type,

                'calculation_type' =>
                $calculationType,

                'percentage' =>
                $component->percentage_value,

                'amount' =>
                round($amount, 2)
            ];
        }




        $netSalary =
            $grossSalary - $totalDeductions;

        $monthlyCTC =
            $grossSalary + $totalEmployerContribution;


        return [

            'staff_id' => $staff->sno,

            'staff_name' => $staff->staff_name,

            'basic_salary' => round($basicSalary, 2),

            'gross_salary' => round($grossSalary, 2),

            'earnings' => round($totalEarnings, 2),

            'deductions' => round($totalDeductions, 2),

            'net_salary' => round($netSalary, 2),

            'lop_days' => round(
                $lopDays ?? 0,
                2
            ),

            'lop_amount' => round(
                $amount ?? 0,
                2
            ),

            'present_days' => round($presentDays, 2),

            'absent_days' => round($absentDays, 2),

            'leave_days' => round($leaveDays, 2),

            'permission_days' => round($permissionDays, 2),

            'onduty_days' => round($ondutyDays, 2),

            'late_count' => round($lateCount, 2),

            'weekoff_days' => round($weekOffCount, 2),

            'holiday_days' => round($holidayCount, 2),

            'earning_days' => round($earningDays, 2),

            'components' => $componentBreakdown,

            'employer_contribution' =>
            round($totalEmployerContribution, 2),

            'monthly_ctc' =>
            round($monthlyCTC, 2),
        ];
    }


    private function applyRules(
        $staff,
        $month,
        $year,
        $grossSalary,
        $basicSalary,
        $absentDays,
        $lateCount
    ) {

        $rules = DB::table('egc_payroll_rules')
            ->where('is_active', 1)
            ->where('status', 0)
            ->where(function ($q) use ($year, $month) {

                $currentDate =
                    Carbon::create($year, $month, 1)
                    ->format('Y-m-d');

                $q->whereNull('effective_from')
                    ->orWhere('effective_from', '<=', $currentDate);
            })
            ->where(function ($q) use ($year, $month) {

                $currentDate =
                    Carbon::create($year, $month, 1)
                    ->format('Y-m-d');

                $q->whereNull('effective_to')
                    ->orWhere('effective_to', '>=', $currentDate);
            })
            ->orderBy('priority_order')
            ->get();


        $totalDeductions = 0;

        $lopDays = 0;

        $lopAmount = 0;

        $breakdown = [];



        $variables = [

            'basic' => $basicSalary,

            'basic_salary' => $basicSalary,

            'gross_salary' => $grossSalary,

            'late_count' => $lateCount,

            'lop_days' => 0,

            'per_day_salary' =>
            (float)$staff->per_day_salary,

            'month' => (int)$month,
        ];

        foreach ($rules as $rule) {


            if ($rule->rule_category == 'lop') {

                $allowedLeave =
                    $staff->casual_leave_count_per_month ?? 0;

                $lopDays = max(0, $absentDays - $allowedLeave);

                $variables['lop_days'] = $lopDays;
            }



            $amount = PayrollFormulaHelper::evaluate($rule->rule_expression, $variables);

            if ($amount <= 0) {
                continue;
            }


            if ($rule->rule_category == 'lop') {
                $lopAmount = $amount;
            }


            $totalDeductions += $amount;


            $breakdown[] = [

                'rule_name' =>
                $rule->rule_name,

                'rule_code' =>
                $rule->rule_code,

                'rule_category' =>
                $rule->rule_category,

                'amount' =>
                round($amount, 2)
            ];
        }

        return [

            'total_deductions' =>
            round($totalDeductions, 2),

            'lop_days' =>
            round($lopDays, 2),

            'lop_amount' =>
            round($lopAmount, 2),

            'breakdown' => $breakdown
        ];
    }



    private function getHolidayDates(
        $startDate,
        $endDate
    ) {

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use (
                $startDate,
                $endDate
            ) {

                $q->whereBetween(
                    'hol_date',
                    [$startDate, $endDate]
                )
                    ->orWhereBetween(
                        'hol_end_date',
                        [$startDate, $endDate]
                    );
            })
            ->get();

        $holidayDates = collect();

        foreach ($holidays as $holiday) {

            $start =
                Carbon::parse($holiday->hol_date);

            $end =
                $holiday->hol_end_date
                ? Carbon::parse(
                    $holiday->hol_end_date
                )
                : $start;

            foreach (
                CarbonPeriod::create($start, $end)
                as $d
            ) {

                $holidayDates->push(
                    $d->format('Y-m-d')
                );
            }
        }

        return $holidayDates->unique();
    }

    private function getLateCount(
        $staffId,
        $month,
        $year
    ) {

        $lateCount = DB::table('egc_staff_attendance as att')
            ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')

            ->join('egc_shift_time_log as stl', function ($join) {
                $join->on('stl.staff_id', '=', 'att.staff_id');
            })

            ->join('egc_shift_day_times as sd', function ($join) {
                $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                    ->where('sd.status', 0);
            })
            ->where('att.staff_id', $staffId)
            // 👉 Month filter
            ->whereMonth('att.date', $month)
            ->whereYear('att.date', $year)
            ->where('att.status', 0)
            ->whereNotNull('att.in_time')
            // ✅ JOINING DATE CHECK
            ->whereRaw("DATE(att.date) >= DATE(s.date_of_joining)")
            // ✅ SHIFT DATE RANGE CHECK
            ->whereRaw("
                        DATE(att.date) BETWEEN stl.start_date 
                        AND IFNULL(stl.end_date, '9999-12-31')
                    ")
            // ✅ DAY MATCH (Mon, Tue...)
            ->whereRaw("
                        LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))
                    ")
            // ✅ LATE CHECK
            // ->whereRaw("
            //     TIME(att.in_time) > TIME(sd.time_from)
            // ")
            ->whereRaw("TIME(att.in_time) > ADDTIME(sd.time_from, '00:16:00')")
            ->count();

        return $lateCount;
    }



    private function getWeekOffCount(
        $month,
        $year
    ) {

        $startDate =
            Carbon::create($year, $month, 1);

        $endDate =
            Carbon::create($year, $month, 1)
            ->endOfMonth();

        if (
            (int)$month == (int)date('m') &&
            (int)$year == (int)date('Y')
        ) {

            $endDate = Carbon::today();
        }

        $count = 0;

        foreach (
            CarbonPeriod::create(
                $startDate,
                $endDate
            ) as $date
        ) {

            if ($date->isSunday()) {
                $count++;
            }
        }

        return $count;
    }
}