<?php

namespace App\Services;

use App\Models\ApplicantModel;
use Smalot\PdfParser\Parser;
use PhpOffice\PhpWord\IOFactory;
use Illuminate\Support\Facades\Log;
use Exception;

class ResumeParserService
{

    protected GoogleDriveService $googleDriveService;

    public function __construct(
        GoogleDriveService $googleDriveService
    ){
        $this->googleDriveService = $googleDriveService;
    }

    /**
     * Get Resume Text
     */
    public function getResumeText(ApplicantModel $applicant)
    {

        // Already available
        if (!empty($applicant->resume_text)) {
            return trim($applicant->resume_text);
        }

        $resumeText = '';

        $driveData = $applicant->drive_data
            ? json_decode($applicant->drive_data)
            : null;

        /**
         * Google Drive File
         */
        if (
            $driveData &&
            !isset($driveData->errors) &&
            !empty($driveData->file_id)
        ) {

            $resumeText = $this->extractResumeTextFromDrive(
                $driveData->file_id
            );

        }

        /**
         * Local Attachment
         */
        if (
            empty($resumeText) &&
            !empty($applicant->attachment)
        ) {

            $path = public_path(
                'job_applications/resume_files/' .
                $applicant->attachment
            );

            $resumeText = $this->extractResumeText($path);

        }

        /**
         * Save extracted text
         */
        if (!empty($resumeText)) {

            $applicant->resume_text = $resumeText;

            $applicant->save();

        }

        return trim($resumeText);

    }

    /**
     * Extract Resume
     */
    public function extractResumeText($filePath)
    {

        if (!file_exists($filePath)) {
            return '';
        }

        $extension = strtolower(
            pathinfo($filePath, PATHINFO_EXTENSION)
        );

        switch ($extension) {

            case 'pdf':
                return $this->parsePdf($filePath);

            case 'docx':
                return $this->parseDocx($filePath);

            case 'txt':
                return file_get_contents($filePath);

            default:
                return '';

        }

    }

    /**
     * PDF
     */
    private function parsePdf($file)
    {

        try {

            $parser = new Parser();

            $pdf = $parser->parseFile($file);

            return $pdf->getText();

        } catch (\Exception $e) {

            Log::error($e->getMessage());

            return '';

        }

    }

    /**
     * DOCX
     */
    private function parseDocx($file)
    {

        try {

            $phpWord = IOFactory::load($file);

            $text = '';

            foreach ($phpWord->getSections() as $section) {

                foreach ($section->getElements() as $element) {

                    if (method_exists($element, 'getText')) {

                        $text .= $element->getText() . " ";

                    }

                }

            }

            return $text;

        } catch (\Exception $e) {

            Log::error($e->getMessage());

            return '';

        }

    }

    /**
     * Google Drive
     *
     * Reuse your existing function here.
     */
    private function extractResumeTextFromDrive($fileId)
    {

        /**
         * Move your existing
         * extractResumeTextFromDrive()
         * code here.
         */
        try {
            $filePath = $this->googleDriveService->downloadFile($fileId);

            $mime = mime_content_type($filePath);

            $extension = match ($mime) {
                'application/pdf' => 'pdf',
                'application/msword' => 'doc',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
                default => throw new Exception("Unsupported MIME type: {$mime}")
            };

            $finalPath = $filePath . '.' . $extension;
            rename($filePath, $finalPath);

            $text = $this->extractResumeText($finalPath);

            unlink($finalPath);

            return $text;
        } catch (Exception $e) {
            Log::error('Resume extraction failed', [
                'file_id' => $fileId,
                'error' => $e->getMessage()
            ]);
            return '';
        }
    }

}