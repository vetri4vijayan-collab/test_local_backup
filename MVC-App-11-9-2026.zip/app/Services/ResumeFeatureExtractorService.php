<?php

namespace App\Services;

class ResumeFeatureExtractorService
{
    /**
     * Extract Resume Features
     */
    public function extract(string $resume): array
    {
        $resume = strtolower(strip_tags($resume));

        // remove special characters
        $resume = preg_replace('/[^a-z0-9\s]/', ' ', $resume);

        // multiple spaces
        $resume = preg_replace('/\s+/', ' ', $resume);

        $words = explode(' ', $resume);

        $words = array_filter($words,function($word){

            return strlen($word)>=3;

        });

        $words = array_unique($words);

        return [

            'tokens'=>array_values($words),

            'text'=>$resume

        ];
    }

    /**
     * Token Matching Score
     */
    public function scoreRole(
        array $tokens,
        string $roleName
    ): float
    {

        $role = strtolower($roleName);

        $score = 0;

        foreach($tokens as $token){

            if(str_contains($role,$token)){

                $score += 20;

            }

        }

        similar_text(

            implode(' ',$tokens),

            $role,

            $percent

        );

        return $score+$percent;

    }

}