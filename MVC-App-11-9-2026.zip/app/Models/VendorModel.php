<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VendorModel extends Model
{
  use HasFactory;

  protected $table = 'egc_vendors';
  protected $primaryKey = 'sno';
  public $timestamps = true;
 

  protected $fillable = [
    'vendor_code',
    'legal_name',
    'erp_staff_id',
    'trade_name',
    'contact_person',
    'mobile',
    'email',
    'gstin',
    'pan',
    'category_id',
    'tier_id',
    'payment_mode_id',
    'credit_term_id',
    'vendor_status_id',
    'address',
    'city_id',
    'state_id',
    'country_id',
    'pincode',
    'sla_percentage',
    'rating',
    'ytd_spend',
    'remarks',
    'description',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
   
  ];
   


}