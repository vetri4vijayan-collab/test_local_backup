<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendanceLogModel extends Model
{
    use HasFactory;
    public $table = "egc_attendance_log";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'staff_id',
        'type',
        'latitude',
        'longitude',
        'face_id',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'created_by',
        'status',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_at = now()->timezone('Asia/Kolkata')->format('Y-m-d H:i:s');
            $model->updated_at = now()->timezone('Asia/Kolkata')->format('Y-m-d H:i:s');
        });

        static::updating(function ($model) {
            $model->updated_at = now()->timezone('Asia/Kolkata')->format('Y-m-d H:i:s');
        });
    }
}
