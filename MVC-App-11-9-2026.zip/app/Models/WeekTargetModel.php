<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WeekTargetModel extends Model
{
    use HasFactory;
    public $table = 'egc_entity_week_targets';
    public $primaryKey = 'id';

    protected $fillable = [
        'month_id',
        'week',
        'percentage',
        'target_amount',
        'pre_sale',
        'post_sale',
        'week_start_date',
        'week_end_date',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];

    public function month()
    {
        return $this->belongsTo(MonthTargetModel::class, 'month_id');
    }
}
