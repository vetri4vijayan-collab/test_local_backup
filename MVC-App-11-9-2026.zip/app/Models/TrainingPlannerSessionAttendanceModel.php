<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingPlannerSessionAttendanceModel extends Model
{
    protected $table = 'egc_training_planner_session_attendance';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'training_session_id',
        'training_planner_id',
        'staff_id',
        'attendance_status',
        'attendance_marked_at',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'attendance_marked_at' => 'datetime',
    ];

    public function session()
    {
        return $this->belongsTo(TrainingPlannerSessionModel::class, 'training_session_id', 'sno');
    }

    public function training()
    {
        return $this->belongsTo(TrainingPlannerModel::class, 'training_planner_id', 'sno');
    }

    public function staff()
    {
        return $this->belongsTo(StaffModel::class, 'staff_id', 'sno');
    }
}
