<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SecurityDeviceModel extends Model
{
    protected $table = 'egc_security_devices';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [
        'staff_id',
        'device_uuid',
        'device_name',
        'device_model',
        'manufacturer',
        'android_version',
        'app_version',
        'firebase_token',
        'last_login_at',
        'status'
    ];
}