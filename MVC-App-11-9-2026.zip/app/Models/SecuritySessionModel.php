<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SecuritySessionModel extends Model
{
    protected $table = 'egc_security_sessions';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [

        'session_uuid',

        'module_id',

        'record_id',

        'requested_staff_id',

        'verified_staff_id',

        'device_id',

        'qr_token',

        'pin_hash',

        'pin_attempts',

        'generated_at',

        'qr_expires_at',

        'pin_generated_at',

        'pin_expires_at',

        'verified_at',

        'access_expires_at',

        'closed_at',

        'status',

        'ip_address',

        'user_agent'
    ];

    protected $casts = [

        'generated_at' => 'datetime',

        'qr_expires_at' => 'datetime',

        'pin_generated_at' => 'datetime',

        'pin_expires_at' => 'datetime',

        'verified_at' => 'datetime',

        'access_expires_at' => 'datetime',

        'closed_at' => 'datetime',
    ];

    public function module()
    {
        return $this->belongsTo(
            SecurityModuleModel::class,
            'module_id',
            'sno'
        );
    }

    public function access()
    {
        return $this->hasOne(
            SecurityAccessModel::class,
            'session_id',
            'sno'
        );
    }

    public function logs()
    {
        return $this->hasMany(
            SecurityLogModel::class,
            'session_id',
            'sno'
        );
    }
}