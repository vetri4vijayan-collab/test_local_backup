<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrainingSubCategoryModel extends Model
{
    use HasFactory;
    public $table = 'egc_training_sub_category';
    public $primaryKey = 'sno';

    protected $fillable = [
        'category_id',
        'sub_cat_name',
        'sub_cat_desc',
        'created_by',
        'updated_by',
        'updated_at',
        'created_at',
        'status',
    ];
}
