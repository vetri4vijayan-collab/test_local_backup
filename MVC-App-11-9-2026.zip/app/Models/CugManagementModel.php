<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CugManagementModel extends Model
{
    use HasFactory;
    public $table      = "egc_cug_assignments";
    public $primaryKey = 'sno';

    protected $fillable = [
        'cug_id ',
        'staff_id',
        'start_date',
        'end_date',
        'reason',
        'remarks',
        'is_current',
        'status',
        'created_by',
        'fcm_token',
        'online_status',
        'last_online_at',
        'last_terminate_at',
        'build_number',
        'app_version',
        'staff_email',
        'live_status',
        'last_checking',
        'created_by',
        'updated_by',
        'status',
    ];
}
