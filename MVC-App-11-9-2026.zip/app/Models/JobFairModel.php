<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobFairModel extends Model
{
    use HasFactory;

    protected $table = 'egc_job_fair';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'job_fair_name',
        'job_fair_id',
        'job_fair_date',
        'address',
        'location_url',
        'skill_requirements',
        'description',
        'status',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
    ];

  
    public function company()
    {
        return $this->belongsTo(CompanyModel::class, 'company_id', 'sno');
    }
 
    public function entity()
    {
        return $this->belongsTo(ManageEntityModel::class, 'entity_id', 'sno');
    }

}
