<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BuildingAmenityModel extends Model
{
    use HasFactory;

    protected $table = 'egc_building_amenities';

    protected $primaryKey = 'sno';

    protected $fillable = [
        'building_id',
        'amenity_name',
        'description',
        'available_from',
        'amenity_status',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];
}