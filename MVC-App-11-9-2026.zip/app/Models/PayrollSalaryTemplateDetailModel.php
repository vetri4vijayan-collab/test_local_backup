<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayrollSalaryTemplateDetailModel extends Model
{
    use HasFactory;

    protected $table = 'egc_payroll_salary_template_details';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [

        'template_sno',
        'component_sno',
        'component_name',
        'component_type',
        'calculation_type',
        'percentage',
        'payroll_rule_sno',
        'amount',
        'created_by',
        'updated_by',
    ];

    protected $casts = [

        'percentage' => 'float',
        'amount'     => 'float',
    ];

    // =====================================================
    // RELATIONS
    // =====================================================

    public function template()
    {
        return $this->belongsTo(
            PayrollComponentVersModel::class,
            'template_sno',
            'sno'
        );
    }

    public function component()
    {
        return $this->belongsTo(
            PayrollComponentVersModel::class,
            'component_sno',
            'sno'
        );
    }
}
