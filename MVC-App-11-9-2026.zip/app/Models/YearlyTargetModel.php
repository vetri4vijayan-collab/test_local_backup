<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class YearlyTargetModel extends Model
{
    use HasFactory;
    public $table = 'egc_entity_yearly_targets';
    public $primaryKey = 'id';

    protected $fillable = [
        'entity_id',
        'branch_id',
        'year',
        'total_target',
        'total_pre_sale',
        'total_post_sale',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];

    public function quarters()
    {
        return $this->hasMany(QuarterTargetModel::class, 'yearly_id');
    }
}
