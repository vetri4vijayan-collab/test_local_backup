<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BuildingAgreementModel extends Model
{
    use HasFactory;

    protected $table = 'egc_building_agreements';

    protected $primaryKey = 'sno';

    protected $fillable = [
        'building_id',
        'floor_id',
        'agreement_name',
        'agreement_no',
        'agreement_start_date',
        'agreement_end_date',
        'renewal_date',
        'agreement_amount',
        'agreement_status',
        'remarks',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];
}