<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BuildingFloorModel extends Model
{
    use HasFactory;

    protected $table = 'egc_building_floors';

    protected $primaryKey = 'sno';

    protected $fillable = [
        'building_id',
        'floor_no',
        'floor_name',
        'purpose',
        'entity_id',
        'branch_id',
        'floor_area',
        'area_unit',
        'occupancy_status',
        'cabins',
        'meeting_rooms',
        'workstations',
        'remarks',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];
}