<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SecurityLogModel extends Model
{
    protected $table = 'egc_security_logs';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'session_id',

        'staff_id',

        'module_id',

        'action',

        'remarks',

        'ip_address',

        'device_name'
    ];

    public function session()
    {
        return $this->belongsTo(
            SecuritySessionModel::class,
            'session_id',
            'sno'
        );
    }
}