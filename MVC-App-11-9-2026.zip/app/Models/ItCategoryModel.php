<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItCategoryModel extends Model
{
    use HasFactory;

    protected $table = 'egc_it_support_category';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'category_name',
        'code',
        'sla_hours',
        'created_by',
        'created_at',
        'updated_by',
        'status',
        'updated_at'
    ];


}
