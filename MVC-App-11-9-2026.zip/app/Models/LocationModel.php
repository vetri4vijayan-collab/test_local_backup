<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LocationModel extends Model {
    use HasFactory;
    public $table      = 'egc_locations';
    public $primaryKey = 'sno';

    protected $fillable = [
        'location_code',
        'country_id',
        'state_id',
        'city_id',
        'area',
        'pincode',
        'region_id',
        'latitude',
        'longitude',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}