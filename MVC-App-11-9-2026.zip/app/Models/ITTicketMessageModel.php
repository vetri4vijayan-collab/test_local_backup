<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ITTicketMessageModel extends Model
{
    use HasFactory;

    protected $table = 'egc_it_ticket_messages';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'sender_id',
        'ticket_id',
        'sender_type',
        'message',
        'attachment',
        'is_read',
        'created_by',
        'created_at',
        'updated_by',
        'status',
        'updated_at'
    ];


     public function ticket()
    {
        return $this->belongsTo(ITTicketModel::class, 'ticket_id', 'sno');
    }

}
