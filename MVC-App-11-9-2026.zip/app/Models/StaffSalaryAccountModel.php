<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffSalaryAccountModel extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_salary_accounts';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'salary_company_id',
        'salary_bank_id',
        'gross_salary',
        'per_hour_cost',
        'per_day_salary',
        'salary_type',
        'effective_from',
        'effective_to',
        'is_primary',
        'remarks',
        'is_payslip',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];

}
