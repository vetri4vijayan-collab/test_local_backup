<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TargetWeekSettingModel extends Model
{
    use HasFactory;
    public $table      = 'egc_target_week_settings';
    public $primaryKey = 'sno';

    protected $fillable = [
        'week_no',
        'week_name',
        'start_day',
        'end_day',
        'percentage',
        'created_by',
        'updated_by',
        'status',
    ];
}
