<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ITTicketModel extends Model
{
    use HasFactory;

    protected $table = 'egc_it_tickets';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'ticket_no',
        'system_ip',
        'category_id',
        'attachments',
        'subject',
        'description',
        'priority',
        'assigned_to',
        'closed_at',
        'sla_due_at',
        'created_by',
        'created_at',
        'updated_by',
        'status',
        'updated_at'
    ];

    public function category()
    {
        return $this->belongsTo(ItCategoryModel::class, 'category_id', 'sno');
    }

}
