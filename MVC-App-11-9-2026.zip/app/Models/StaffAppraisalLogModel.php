<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffAppraisalLogModel extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_appraisal_logs';
    protected $primaryKey = 'sno';

    public $timestamps = true;

     protected $fillable = [

        'staff_id',
        'salary_account_id',
        'payroll_employee_structure_sno',
        'appraisal_date',
        'appraisal_type',
        'appraisal_reason',
        'appraisal_unit_type',
        'appraisal_value',
        'old_gross_salary',
        'new_gross_salary',
        'salary_difference',
        'effective_from',
        'effective_to',
        'remarks',
        'status',
        'created_by',
        'updated_by'
    ];
}
