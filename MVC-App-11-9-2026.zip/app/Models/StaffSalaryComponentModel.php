<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffSalaryComponentModel extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_salary_components_new';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'component_id',
        'amount',
        'calculation_type',
        'is_active',
        'created_by',
        'updated_by',
        'updated_at',
        'created_at',
        'status',
    ];

}
