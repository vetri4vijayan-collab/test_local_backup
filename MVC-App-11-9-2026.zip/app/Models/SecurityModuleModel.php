<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SecurityModuleModel extends Model
{
    protected $table = 'egc_security_modules';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [
        'module_code',
        'module_name',
        'description',
        'icon',
        'status',
        'created_by',
        'updated_by'
    ];

    public function setting()
    {
        return $this->hasOne(
            SecurityModuleSettingModel::class,
            'module_id',
            'sno'
        );
    }

    public function sessions()
    {
        return $this->hasMany(
            SecuritySessionModel::class,
            'module_id',
            'sno'
        );
    }
}