<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NotificationMobileModel extends Model
{
    use HasFactory;
    public $table      = 'egc_notification_mobile';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'staff_id',
        'app',
        'notification_content',
        'notification_date',
        'created_by',
        'updated_by',
        'status',
    ];
}
