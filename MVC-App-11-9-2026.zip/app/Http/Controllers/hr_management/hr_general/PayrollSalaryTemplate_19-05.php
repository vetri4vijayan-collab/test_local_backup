<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\PayrollStaffStructureDetailModel;
use App\Models\PayrollStaffStructureModel;
use App\Models\PayrollComponentVersModel;
use App\Models\PayrollSalaryTemplateModel;
use App\Models\PayrollSalaryTemplateDetailModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Log;

class PayrollSalaryTemplate extends Controller
{



    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $templates = DB::table('egc_payroll_salary_templates')
            ->where('status', '!=', 2);

        if ($search_filter != '') {

            $templates->where(function ($q) use ($search_filter) {

                $q->where('template_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('template_code', 'LIKE', "%{$search_filter}%")
                    ->orWhere('gross_salary', 'LIKE', "%{$search_filter}%");
            });
        }

        $templates = $templates
            ->orderBy('sno', 'DESC')
            ->paginate($perpage);

        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $templates->map(function ($item) use ($helper) {
                // return $interview_schedule;
                return [
                    'sno' => $item->sno,
                    'template_name' => $item->template_name,
                    'template_code' => $item->template_code,
                    'gross_salary' => number_format($item->gross_salary, 2),
                    'monthly_ctc' => number_format($item->monthly_ctc, 2),
                    'effective_from' => $item->effective_from,
                    'status' => $item->status,
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $templates->currentPage(),
                'last_page' => $templates->lastPage(),
                'total' => $templates->total(),
            ]);
        }
        $components = DB::table('egc_payroll_components')
            ->select('egc_payroll_components.*', 'egc_payroll_rules.rule_code', 'egc_payroll_rules.rule_category', 'egc_payroll_rules.rule_expression')
            ->leftJoin('egc_payroll_rules', 'egc_payroll_rules.id', '=', 'egc_payroll_components.rule_id')
            ->where('egc_payroll_components.status', 0)
            ->orderBy('egc_payroll_components.component_name')
            ->get();

        return view('content.hr_management.hr_general.payroll_template.payroll_template_list', [
            'templates' => $templates,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'components' => $components,
        ]);
    }


    public function Status($id, Request $request)
    {
        $last_apply_date = $request->input('last_apply_date');
        $last_apply_date = $last_apply_date ? date('Y-m-d', strtotime($last_apply_date)) : null;
        $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
        $upd_LedgerCategoryModel->status = $request->input('status', 0);
        $upd_LedgerCategoryModel->last_apply_date = $last_apply_date;
        $upd_LedgerCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function saveTemplate(Request $request)
    {
        DB::beginTransaction();

        try {

            // =====================================================
            // VALIDATION
            // =====================================================

            $validator = Validator::make($request->all(), [

                'sno'               => 'nullable|integer',

                'template_name'     => 'required|string|max:255',

                'gross_salary'      => 'required|numeric|min:0',

                'effective_from'    => 'nullable',

                'template_type'     => 'required|string|max:100',

                'description'       => 'nullable|string',

                'details'           => 'required|array|min:1',

                'details.*.component_sno' => 'required|integer',

                'details.*.component_type' => 'required|in:earning,deduction',

                'details.*.calculation_type' => 'nullable|string',

                'details.*.percentage' => 'nullable|numeric|min:0|max:100',

                'details.*.amount' => 'nullable|numeric|min:0',

            ]);

            if ($validator->fails()) {

                return response()->json([

                    'status'  => false,

                    'message' => $validator->errors()->first(),

                    'errors'  => $validator->errors()

                ], 422);
            }

            // =====================================================
            // PREPARE VALUES
            // =====================================================

            $grossSalary = (float) $request->gross_salary;

            $earningPercentage = 0;

            $totalEarnings = 0;

            $totalDeductions = 0;

            $preparedDetails = [];

            $usedComponents = [];

            // =====================================================
            // VALIDATE COMPONENTS
            // =====================================================

            foreach ($request->details as $detail) {

                // -----------------------------
                // Duplicate Check
                // -----------------------------

                if (in_array($detail['component_sno'], $usedComponents)) {

                    DB::rollBack();

                    return response()->json([

                        'status' => false,

                        'message' => 'Duplicate salary component selected.'

                    ], 422);
                }

                $usedComponents[] = $detail['component_sno'];

                // -----------------------------
                // Fetch Component
                // -----------------------------

                $component = PayrollComponentVersModel::where(
                    'sno',
                    $detail['component_sno']
                )->first();

                if (!$component) {

                    DB::rollBack();

                    return response()->json([

                        'status' => false,

                        'message' => 'Invalid salary component selected.'

                    ], 422);
                }

                // -----------------------------
                // Calculation
                // -----------------------------

                $percentage = (float) ($detail['percentage'] ?? 0);

                $amount = (float) ($detail['amount'] ?? 0);

                if ($component->calculation_type == 'percentage') {

                    $amount = ($grossSalary * $percentage) / 100;
                }

                // -----------------------------
                // Earnings Total
                // -----------------------------

                if ($detail['component_type'] == 'earning') {

                    $earningPercentage += $percentage;

                    $totalEarnings += $amount;
                }

                // -----------------------------
                // Deductions Total
                // -----------------------------

                if ($detail['component_type'] == 'deduction') {

                    $totalDeductions += $amount;
                }

                // -----------------------------
                // Prepared Data
                // -----------------------------

                $preparedDetails[] = [

                    'component_sno'     => $component->sno,

                    'component_name'    => $component->component_name,

                    'component_type'    => $detail['component_type'],

                    'calculation_type'  => $component->calculation_type,

                    'percentage'        => $percentage,

                    'amount'            => round($amount, 2),
                    'payroll_rule_sno'            => $component->rule_id ?? null
                ];
            }

            // =====================================================
            // VALIDATE EARNING %
            // =====================================================

            if (round($earningPercentage, 2) != 100) {

                DB::rollBack();

                return response()->json([

                    'status' => false,

                    'message' => 'Total earnings percentage must equal exactly 100%.'

                ], 422);
            }

            // =====================================================
            // FINAL CALCULATION
            // =====================================================

            $netSalary = $totalEarnings - $totalDeductions;

            $monthlyCTC = $totalEarnings;

            // =====================================================
            // CREATE / UPDATE TEMPLATE
            // =====================================================

            if ($request->sno) {

                $template = PayrollSalaryTemplateModel::where(
                    'sno',
                    $request->sno
                )->first();

                if (!$template) {

                    DB::rollBack();

                    return response()->json([

                        'status' => false,

                        'message' => 'Salary template not found.'

                    ], 404);
                }

                $message = 'Salary template updated successfully.';
            } else {

                $template = new PayrollSalaryTemplateModel();

                $message = 'Salary template created successfully.';
            }

            // =====================================================
            // SAVE TEMPLATE
            // =====================================================

            $template->template_name      = $request->template_name;

            $template->template_code      = strtoupper($request->template_code);

            $template->gross_salary       = $grossSalary;

            $template->effective_from     = $request->effective_from
                ? Carbon::parse($request->effective_from)->format('Y-m-d')
                : null;

            $template->template_type      = $request->template_type;

            $template->description        = $request->description;

            $template->total_earnings     = round($totalEarnings, 2);

            $template->total_deductions   = round($totalDeductions, 2);

            $template->net_salary         = round($netSalary, 2);

            $template->monthly_ctc        = round($monthlyCTC, 2);

            $template->status             = 0;

            $template->save();

            // =====================================================
            // DELETE OLD DETAILS
            // =====================================================

            PayrollSalaryTemplateDetailModel::where(
                'template_sno',
                $template->sno
            )->delete();

            // =====================================================
            // INSERT DETAILS
            // =====================================================

            foreach ($preparedDetails as $detail) {

                PayrollSalaryTemplateDetailModel::create([

                    'template_sno'      => $template->sno,

                    'component_sno'     => $detail['component_sno'],

                    'component_name'    => $detail['component_name'],

                    'component_type'    => $detail['component_type'],

                    'calculation_type'  => $detail['calculation_type'],

                    'percentage'        => $detail['percentage'],

                    'amount'            => $detail['amount'],
                    'payroll_rule_sno'            => $detail['payroll_rule_sno'],
                ]);
            }

            DB::commit();

            return response()->json([

                'status' => true,

                'message' => $message,

                'data' => [

                    'template_sno' => $template->sno,

                    'template_name' => $template->template_name,

                    'net_salary' => $template->net_salary,
                ]
            ]);
        } catch (\Exception $e) {

            DB::rollBack();

            Log::error('Payroll Template Save Error', [

                'message' => $e->getMessage(),

                'line' => $e->getLine(),

                'file' => $e->getFile(),
            ]);

            return response()->json([

                'status' => false,

                'message' => 'Unable to save salary template.',

                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null

            ], 500);
        }
    }




    public function staffSalaryMappingSave(Request $r)
    {

        $r->validate([
            'employee_sno' => 'required',
            'salary_structure_sno' => 'required',
            'effective_from' => 'required'
        ]);

        DB::transaction(function () use ($r) {

            // close previous active structure
            DB::table('egc_staff_salary_mapping')
                ->where('staff_id', $r->employee_sno)
                ->whereNull('effective_to')
                ->update([
                    'effective_to' => date('Y-m-d', strtotime($r->effective_from . ' -1 day')),
                    'updated_by' => $r->user()->user_id ?? 1
                ]);

            // insert new mapping
            DB::table('egc_staff_salary_mapping')
                ->insert([
                    'staff_id' => $r->employee_sno,
                    'salary_structure_sno' => $r->salary_structure_sno,
                    'effective_from' => $r->effective_from ? date('Y-m-d', strtotime($r->effective_from)) : null,
                    'change_reason' => $r->change_reason,
                    'created_by' => $r->user()->user_id ?? 1
                ]);
        });

        return response()->json([
            'status' => true
        ]);
    }

    public function edit($id)
    {
        try {

            // =====================================================
            // FETCH TEMPLATE
            // =====================================================

            $template = PayrollSalaryTemplateModel::with([

                'details.component'

            ])->where('sno', $id)->first();

            // =====================================================
            // NOT FOUND
            // =====================================================

            if (!$template) {

                return response()->json([

                    'status' => false,

                    'message' => 'Salary template not found.'

                ], 404);
            }

            // =====================================================
            // FORMAT DETAILS
            // =====================================================

            $details = [];

            if ($template->details->count() > 0) {

                foreach ($template->details as $detail) {

                    $details[] = [

                        'sno' => $detail->sno,

                        'component_sno' => $detail->component_sno,

                        'component_name' => $detail->component_name,

                        'component_type' => $detail->component_type,

                        'calculation_type' => $detail->calculation_type,

                        'percentage' => (float) $detail->percentage,

                        'amount' => (float) $detail->amount,

                        'component' => [

                            'sno' => $detail->component?->sno,

                            'component_name' => $detail->component?->component_name,

                            'component_code' => $detail->component?->component_code,

                            'category' => $detail->component?->category,

                            'calculation_type' => $detail->component?->calculation_type,
                        ]
                    ];
                }
            }

            // =====================================================
            // RESPONSE
            // =====================================================

            return response()->json([

                'status' => true,

                'message' => 'Salary template fetched successfully.',

                'data' => [

                    'sno' => $template->sno,

                    'template_name' => $template->template_name,

                    'template_code' => $template->template_code,

                    'gross_salary' => (float) $template->gross_salary,

                    'effective_from' => $template->effective_from
                        ? \Carbon\Carbon::parse($template->effective_from)
                        ->format('d-M-Y')
                        : null,

                    'template_type' => $template->template_type,

                    'description' => $template->description,

                    'total_earnings' => (float) $template->total_earnings,

                    'total_deductions' => (float) $template->total_deductions,

                    'net_salary' => (float) $template->net_salary,

                    'monthly_ctc' => (float) $template->monthly_ctc,

                    'details' => $details
                ]

            ], 200);
        } catch (\Exception $e) {

            \Log::error('Payroll Template Edit Fetch Error', [

                'message' => $e->getMessage(),

                'line' => $e->getLine(),

                'file' => $e->getFile(),
            ]);

            return response()->json([

                'status' => false,

                'message' => 'Unable to fetch salary template.',

                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null

            ], 500);
        }
    }


    public function saveEmployeeStructure(Request $request)
    {
        DB::beginTransaction();

        try {

            $request->validate([

                'employee_sno' => 'required|integer',

                'gross_salary' => 'required|numeric|min:0',

                'effective_from' => 'required',

                'details' => 'required|array|min:1',
            ]);

            // OLD CURRENT STRUCTURE DISABLE

            PayrollStaffStructureModel::where(
                'employee_sno',
                $request->employee_sno
            )
                ->where('is_current', 1)
                ->update([

                    'is_current' => 0,
                    'effective_to' => date('Y-m-d', strtotime($request->effective_from . ' -1 day')),
                ]);

            $earnings = 0;
            $deductions = 0;

            foreach ($request->details as $detail) {

                if ($detail['component_type'] == 'earning') {

                    $earnings += $detail['calculated_amount'];
                } else {

                    $deductions += $detail['calculated_amount'];
                }
            }

            $netSalary = $earnings - $deductions;

            $structure = PayrollStaffStructureModel::create([

                'employee_sno' => $request->employee_sno,

                'payroll_template_sno' => $request->payroll_template_sno,

                'structure_code' => 'SAL-' . time(),

                'structure_name' => 'Employee Salary Structure',

                'gross_salary' => $request->gross_salary,

                'total_earnings' => $earnings,

                'total_deductions' => $deductions,

                'net_salary' => $netSalary,

                'ctc_amount' => $earnings,

                'revision_reason' => $request->revision_reason,

                'effective_from' => Carbon::parse(
                    $request->effective_from
                )->format('Y-m-d'),

                'is_current' => 1,

                'status' => 0,

                'created_by' => auth()->id(),
            ]);

            foreach ($request->details as $index => $detail) {

                PayrollStaffStructureDetailModel::create([

                    'payroll_employee_structure_sno' => $structure->sno,

                    'payroll_component_sno' => $detail['payroll_component_sno'],

                    'component_type' => $detail['component_type'],

                    'calculation_type' => $detail['calculation_type'],

                    'percentage_value' => $detail['percentage_value'] ?? 0,

                    'fixed_amount' => $detail['calculated_amount'],

                    'calculated_amount' => $detail['calculated_amount'],

                    'display_order' => $index + 1,

                    'status' => 0,
                ]);
            }

            StaffModel::where(
                'sno',
                $request->employee_sno
            )
                ->update([
                    'basic_salary' => $request->gross_salary,
                ]);

            DB::commit();

            return response()->json([

                'status' => true,

                'message' => 'Employee salary structure saved successfully'
            ]);
        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([

                'status' => false,

                'message' => $e->getMessage()
            ], 500);
        }
    }




    public function GetEmployeeStructure($id)
    {
        try {
           
            $employee = DB::table('egc_staff')
                ->where('sno', $id)
                ->select(
                    'sno',
                    'staff_name as employee_name',
                    'staff_id as employee_code',
                    'basic_salary as gross_salary',
                )

                ->first();

            if (!$employee) {

                return response()->json([

                    'status' => false,

                    'message' => 'Employee not found'

                ], 404);
            }


            $structure = DB::table('egc_payroll_employee_structures as es')

                ->leftJoin(
                    'egc_payroll_salary_templates as st',
                    'st.sno',
                    '=',
                    'es.payroll_template_sno'
                )

                ->where('es.employee_sno', $id)

                ->where('es.is_current', 1)

                ->select(
                    'es.*',
                    'st.template_name',
                    'st.template_code'
                )

                ->first();

            /*
            |--------------------------------------------------------------------------
            | DEFAULT RESPONSE
            |--------------------------------------------------------------------------
            */

            $details = collect([]);

            /*
            |--------------------------------------------------------------------------
            | DETAILS
            |--------------------------------------------------------------------------
            */

            if ($structure) {

                $details = DB::table(
                    'egc_payroll_employee_structure_details as d'
                )

                    ->join(
                        'egc_payroll_components as c',
                        'c.sno',
                        '=',
                        'd.payroll_component_sno'
                    )

                    ->leftJoin(
                        'egc_payroll_rules as r',
                        'r.id',
                        '=',
                        'd.payroll_rule_sno'
                    )

                    ->where(
                        'd.payroll_employee_structure_sno',
                        $structure->sno
                    )

                    ->orderBy('d.display_order', 'ASC')

                    ->select(

                        'd.sno',

                        'd.payroll_component_sno',

                        'd.payroll_rule_sno',

                        'd.component_type',

                        'd.calculation_type',

                        'd.calculated_on',

                        'd.percentage_value',

                        'd.fixed_amount',

                        'd.calculated_amount',

                        'd.monthly_variable',

                        'd.include_in_gross',

                        'd.include_in_ctc',

                        'd.include_in_payslip',

                        'd.display_order',

                        'd.remarks',

                        'c.component_name',

                        'c.component_code',

                        'r.rule_name',
                        'r.rule_expression',

                    )

                    ->get();
            }

            /*
            |--------------------------------------------------------------------------
            | RESPONSE
            |--------------------------------------------------------------------------
            */

            return response()->json([

                'status' => true,

                'message' => 'Employee salary structure fetched successfully',

                'data' => [

                    'employee' => $employee,

                    'structure' => $structure,

                    'details' => $details

                ]

            ]);
        } catch (\Exception $e) {

            return response()->json([

                'status' => false,

                'message' => 'Failed to fetch employee salary structure',

                'error' => $e->getMessage()

            ], 500);
        }
    }

    public function GetTemplateComponents($id)
    {
        try {

            $template = DB::table('egc_payroll_salary_templates')

                ->where('sno', $id)

                ->first();

            if (!$template) {

                return response()->json([

                    'status' => false,

                    'message' => 'Salary template not found'

                ], 404);
            }

            $details = DB::table(
                'egc_payroll_salary_template_details as d'
            )

                ->join(
                    'egc_payroll_components as c',
                    'c.sno',
                    '=',
                    'd.component_sno'
                )

                ->leftJoin(
                    'egc_payroll_rules as r',
                    'r.id',
                    '=',
                    'd.payroll_rule_sno'
                )

                ->where(
                    'd.template_sno',
                    $id
                )

                ->orderBy('c.display_order', 'ASC')

                ->select(

                    'd.*',

                    'c.component_name',

                    'c.component_code',

                    'r.rule_name',
                    'r.rule_expression',

                )

                ->get();

            return response()->json([

                'status' => true,

                'message' => 'Template fetched successfully',

                'data' => [

                    'template' => $template,

                    'details' => $details

                ]

            ]);
        } catch (\Exception $e) {

            return response()->json([

                'status' => false,

                'message' => 'Failed to fetch template',

                'error' => $e->getMessage()

            ], 500);
        }
    }

    //     public function saveEmployeeStructure(Request $request)
    // {
    //     DB::beginTransaction();

    //     try {

    //         /*
    //         |--------------------------------------------------------------------------
    //         | VALIDATION
    //         |--------------------------------------------------------------------------
    //         */

    //         $request->validate([

    //             'employee_sno' => 'required|integer',

    //             'payroll_template_sno' => 'nullable|integer',

    //             'gross_salary' => 'required|numeric|min:0',

    //             'effective_from' => 'required',

    //             'details' => 'required|array|min:1',

    //             'details.*.payroll_component_sno' => 'required|integer',

    //             'details.*.component_type' => 'required',

    //             'details.*.calculation_type' => 'required',

    //             'details.*.calculated_amount' => 'required|numeric|min:0',

    //         ]);

    //         /*
    //         |--------------------------------------------------------------------------
    //         | EMPLOYEE CHECK
    //         |--------------------------------------------------------------------------
    //         */

    //         $employee = DB::table('egc_staff')

    //             ->where('sno', $request->employee_sno)

    //             ->first();

    //         if (!$employee) {

    //             return response()->json([

    //                 'status' => false,

    //                 'message' => 'Employee not found'

    //             ], 404);
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | OLD CURRENT STRUCTURE
    //         |--------------------------------------------------------------------------
    //         */

    //         $oldStructure = PayrollStaffStructureModel::where(
    //             'employee_sno',
    //             $request->employee_sno
    //         )
    //             ->where('is_current', 1)
    //             ->first();

    //         /*
    //         |--------------------------------------------------------------------------
    //         | CLOSE OLD STRUCTURE
    //         |--------------------------------------------------------------------------
    //         */

    //         if ($oldStructure) {

    //             $oldStructure->update([

    //                 'is_current' => 0,

    //                 'effective_to' => Carbon::now()
    //                     ->format('Y-m-d'),

    //                 'updated_by' => auth()->id()

    //             ]);
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | REVISION NUMBER
    //         |--------------------------------------------------------------------------
    //         */

    //         $revisionNo = 1;

    //         if ($oldStructure) {

    //             $revisionNo =
    //                 ($oldStructure->revision_no ?? 1) + 1;
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | CALCULATE TOTALS
    //         |--------------------------------------------------------------------------
    //         */

    //         $earnings = 0;

    //         $deductions = 0;

    //         $employerContribution = 0;

    //         foreach ($request->details as $detail) {

    //             $amount = (float)
    //                 $detail['calculated_amount'];

    //             if (
    //                 $detail['component_type']
    //                 == 'earning'
    //             ) {

    //                 $earnings += $amount;
    //             }

    //             else if (
    //                 $detail['component_type']
    //                 == 'deduction'
    //             ) {

    //                 $deductions += $amount;
    //             }

    //             else if (
    //                 $detail['component_type']
    //                 == 'employer_contribution'
    //             ) {

    //                 $employerContribution += $amount;
    //             }
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | FINAL CALCULATIONS
    //         |--------------------------------------------------------------------------
    //         */

    //         $netSalary =
    //             $earnings - $deductions;

    //         $ctc =
    //             $earnings + $employerContribution;

    //         /*
    //         |--------------------------------------------------------------------------
    //         | CREATE STRUCTURE
    //         |--------------------------------------------------------------------------
    //         */

    //         $structure =
    //             PayrollStaffStructureModel::create([

    //                 'employee_sno' =>
    //                     $request->employee_sno,

    //                 'payroll_template_sno' =>
    //                     $request->payroll_template_sno,

    //                 'structure_code' =>
    //                     'SAL-' .
    //                     strtoupper(Str::random(8)),

    //                 'structure_name' =>
    //                     'Employee Salary Structure',

    //                 'gross_salary' =>
    //                     $request->gross_salary,

    //                 'total_earnings' =>
    //                     $earnings,

    //                 'total_deductions' =>
    //                     $deductions,

    //                 'net_salary' =>
    //                     $netSalary,

    //                 'employer_contribution' =>
    //                     $employerContribution,

    //                 'ctc_amount' =>
    //                     $ctc,

    //                 'revision_no' =>
    //                     $revisionNo,

    //                 'revision_reason' =>
    //                     $request->revision_reason,

    //                 'effective_from' =>
    //                     Carbon::parse(
    //                         $request->effective_from
    //                     )->format('Y-m-d'),

    //                 'is_current' => 1,

    //                 'payroll_lock' => 0,

    //                 'status' => 1,

    //                 'remarks' =>
    //                     $request->remarks,

    //                 'created_by' =>
    //                     auth()->id(),

    //                 'updated_by' =>
    //                     auth()->id(),

    //             ]);

    //         /*
    //         |--------------------------------------------------------------------------
    //         | SAVE COMPONENT DETAILS
    //         |--------------------------------------------------------------------------
    //         */

    //         foreach (
    //             $request->details as $index => $detail
    //         ) {

    //             PayrollStaffStructureDetailModel::create([

    //                 'payroll_employee_structure_sno' =>
    //                     $structure->sno,

    //                 'payroll_component_sno' =>
    //                     $detail['payroll_component_sno'],

    //                 'payroll_rule_sno' =>
    //                     $detail['payroll_rule_sno'] ?? null,

    //                 'component_type' =>
    //                     $detail['component_type'],

    //                 'calculation_type' =>
    //                     $detail['calculation_type'],

    //                 'calculated_on' =>
    //                     $detail['calculated_on'] ?? null,

    //                 'percentage_value' =>
    //                     $detail['percentage_value'] ?? 0,

    //                 /*
    //                 |--------------------------------------------------------------------------
    //                 | FIXED AMOUNT
    //                 |--------------------------------------------------------------------------
    //                 */

    //                 'fixed_amount' =>

    //                     $detail['calculation_type']
    //                     == 'fixed'

    //                     ? $detail['calculated_amount']

    //                     : 0,

    //                 /*
    //                 |--------------------------------------------------------------------------
    //                 | FINAL CALCULATED AMOUNT
    //                 |--------------------------------------------------------------------------
    //                 */

    //                 'calculated_amount' =>
    //                     $detail['calculated_amount'],

    //                 'monthly_variable' =>
    //                     $detail['monthly_variable'] ?? 0,

    //                 'include_in_gross' =>
    //                     $detail['include_in_gross'] ?? 1,

    //                 'include_in_ctc' =>
    //                     $detail['include_in_ctc'] ?? 1,

    //                 'include_in_payslip' =>
    //                     $detail['include_in_payslip'] ?? 1,

    //                 'display_order' =>
    //                     $index + 1,

    //                 'remarks' =>
    //                     $detail['remarks'] ?? null,

    //                 'status' => 1,

    //             ]);
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | UPDATE STAFF GROSS SALARY
    //         |--------------------------------------------------------------------------
    //         */

    //         DB::table('egc_staff')

    //             ->where('sno', $request->employee_sno)

    //             ->update([

    //                 'gross_salary' =>
    //                     $request->gross_salary
    //             ]);

    //         DB::commit();

    //         return response()->json([

    //             'status' => true,

    //             'message' =>
    //                 'Employee salary structure saved successfully',

    //             'data' => [

    //                 'structure_sno' =>
    //                     $structure->sno,

    //                 'net_salary' =>
    //                     $netSalary,

    //                 'ctc_amount' =>
    //                     $ctc

    //             ]

    //         ]);

    //     } catch (\Illuminate\Validation\ValidationException $e) {

    //         DB::rollBack();

    //         return response()->json([

    //             'status' => false,

    //             'message' => 'Validation failed',

    //             'errors' => $e->errors()

    //         ], 422);

    //     } catch (\Exception $e) {

    //         DB::rollBack();

    //         return response()->json([

    //             'status' => false,

    //             'message' =>
    //                 'Failed to save employee salary structure',

    //             'error' => $e->getMessage()

    //         ], 500);
    //     }
    // }

    public function calculateTemplatePreview(Request $request)
    {
        $grossSalary = $request->gross_salary;

        $details = $request->details;

        $earnings = [];
        $deductions = [];

        $basic = 0;
        $da = 0;

        /*
    |--------------------------------------------------------------------------
    | EARNINGS
    |--------------------------------------------------------------------------
    */

        foreach ($details as $detail) {

            $component = DB::table('egc_payroll_components')
                ->where('sno', $detail['component_sno'])
                ->first();

            $amount = 0;

            if ($component->calculation_type == 'percentage') {

                $amount =
                    ($grossSalary * $component->percentage_value) / 100;
            }

            if ($component->calculation_type == 'fixed') {

                $amount = $detail['amount'];
            }

            if ($component->component_code == 'BASIC') {
                $basic = $amount;
            }

            if ($component->component_code == 'DA') {
                $da = $amount;
            }

            if ($component->category == 'earning') {

                $earnings[] = [
                    'component' => $component->component_name,
                    'amount' => round($amount, 2)
                ];
            }
        }

        $grossEarnings =
            collect($earnings)->sum('amount');

        /*
    |--------------------------------------------------------------------------
    | DEDUCTIONS
    |--------------------------------------------------------------------------
    */

        foreach ($details as $detail) {

            $component = DB::table('egc_payroll_components')
                ->where('sno', $detail['component_sno'])
                ->first();

            if ($component->category != 'deduction') {
                continue;
            }

            $amount = 0;

            /*
        |--------------------------------------------------------------------------
        | PF
        |--------------------------------------------------------------------------
        */

            if ($component->component_code == 'PF') {

                $pfBase = $basic + $da;

                $amount =
                    $pfBase > 15000
                    ? 1800
                    : ($pfBase * 0.12);
            }

            /*
        |--------------------------------------------------------------------------
        | ESI
        |--------------------------------------------------------------------------
        */ else if ($component->component_code == 'ESI') {

                $amount =
                    $grossEarnings <= 21000
                    ? ($grossEarnings * 0.0075)
                    : 0;
            }

            /*
        |--------------------------------------------------------------------------
        | FIXED
        |--------------------------------------------------------------------------
        */ else if ($component->calculation_type == 'fixed') {

                $amount = $detail['amount'];
            }

            $deductions[] = [

                'component' =>
                $component->component_name,

                'amount' =>
                round($amount, 2)
            ];
        }

        $totalDeduction =
            collect($deductions)->sum('amount');

        return response()->json([

            'earnings' => $earnings,

            'deductions' => $deductions,

            'gross' => round($grossEarnings, 2),

            'deduction_total' => round($totalDeduction, 2),

            'net' =>
            round(
                $grossEarnings - $totalDeduction,
                2
            )
        ]);
    }

    public function SaveVariableAmount(Request $request)
    {
        DB::beginTransaction();
        try {

            $request->validate([
                'employee_sno' => 'required',
                'payroll_component_sno' => 'required',
                'amount' => 'required|numeric|min:0',
                'start_month' => 'required',
            ]);


            $startMonth = Carbon::createFromFormat(
                'M-Y',
                $request->start_month
            )->startOfMonth();

            $endMonth = $startMonth
                ->copy()
                ->addMonths(2)
                ->endOfMonth();
            $activeVariable = DB::table('egc_payroll_variable_amounts')
                ->where('employee_sno', $request->employee_sno)
                ->where('payroll_component_sno', $request->payroll_component_sno)
                ->whereDate('end_month', '>=', now())
                ->where('status', 0)
                ->first();

            if ($activeVariable) {
                DB::table('egc_payroll_variable_amounts')
                    ->where('sno', $activeVariable->sno)
                    ->update([
                        'amount' => $request->amount,
                        'remarks' => $request->remarks,
                        'updated_by' => session('sno'),
                        'updated_at' => now(),
                    ]);
                DB::commit();
                return response()->json([
                    'status' => true,
                    'message' => 'Variable amount updated successfully'
                ]);
            }

            DB::table(
                'egc_payroll_variable_amounts'
            )->insert([
                'employee_sno' => $request->employee_sno,
                'payroll_component_sno' => $request->payroll_component_sno,
                'amount' => $request->amount,
                'start_month' => $startMonth->format('Y-m-d'),
                'end_month' => $endMonth->format('Y-m-d'),
                'remarks' => $request->remarks,
                'status' => 0,
                'created_by' => session('sno'),
                'updated_by' => session('sno'),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            DB::commit();
            return response()->json([
                'status' => true,
                'message' =>
                'Variable amount saved successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => false,
                'message' => $e->getMessage()

            ], 500);
        }
    }

    public function GetVariableAmount($employeeId)
    {
        try {

            $data = DB::table(
                'egc_payroll_variable_amounts'
            )

                ->where('employee_sno', $employeeId)

                ->where('status', 0)

                ->whereDate('end_month', '>=', now())

                ->latest('sno')

                ->first();

            return response()->json([

                'status' => true,

                'data' => $data
            ]);
        } catch (\Exception $e) {

            return response()->json([

                'status' => false,

                'message' => $e->getMessage()

            ], 500);
        }
    }

    public function bulkPreview()
    {
        $employees = DB::table('egc_staff as s')

            ->leftJoin(
                'egc_payroll_employee_structures as es',
                function ($join) {
                    $join->on(
                        'es.employee_sno',
                        '=',
                        's.sno'
                    )
                        ->where('es.is_current', 1);
                }
            )
            ->whereNull('es.sno')
            ->where('s.status', '!=', 2)
            ->whereIn('s.salary_type', [1, 2])
            ->select(
                's.sno',
                's.staff_name',
                's.staff_id',
                's.salary_type',
                's.basic_salary',
                DB::raw("
                CASE
                    WHEN s.salary_type = 1
                    THEN 'Template 1'
                    ELSE 'Template 2'
                END as template_name
            ")
            )
            ->get();

        return response()->json([
            'status' => true,
            'data' => $employees

        ]);
    }

    public function bulkSave(Request $request)
    {
        DB::beginTransaction();

        try {

            $request->validate([
                'template_type_1' => 'required|integer',
                'template_type_2' => 'required|integer',
                'effective_from' => 'required|date',
            ]);

            /*
        |--------------------------------------------------------------------------
        | STAFF LIST
        |--------------------------------------------------------------------------
        */
            $employees = StaffModel::where('status', '!=', 2)
                ->whereIn('salary_type', [1, 2])
                ->select(
                    'sno',
                    'staff_name',
                    'salary_type',
                    'basic_salary'
                )
                ->get();

            /*
        |--------------------------------------------------------------------------
        | LOAD TEMPLATE DETAILS ONCE
        |--------------------------------------------------------------------------
        */
            $template1Details = DB::table('egc_payroll_salary_template_details as d')
                ->join('egc_payroll_components as c','c.sno','=', 'd.component_sno')
                ->leftJoin('egc_payroll_rules as r','r.id', '=', 'd.payroll_rule_sno')
                ->where( 'd.template_sno',$request->template_type_1)
                ->orderBy('c.display_order')
                ->select(
                    'd.*',
                    'c.component_code',
                    'r.rule_expression'
                )
                ->get();
            $template2Details = DB::table('egc_payroll_salary_template_details as d')
                ->join('egc_payroll_components as c','c.sno', '=', 'd.component_sno')
                ->leftJoin( 'egc_payroll_rules as r','r.id','=', 'd.payroll_rule_sno')
                ->where('d.template_sno',$request->template_type_2)
                ->orderBy('c.display_order')
                ->select(
                    'd.*',
                    'c.component_code',
                    'r.rule_expression'
                )
                ->get();
            $createdCount = 0;

            foreach ($employees as $employee) {
                /*
            |--------------------------------------------------------------------------
            | SKIP IF CURRENT STRUCTURE EXISTS
            |--------------------------------------------------------------------------
            */
                $exists = PayrollStaffStructureModel::where(
                    'employee_sno',
                    $employee->sno
                )
                    ->where('is_current', 1)
                    ->exists();

                if ($exists) {
                    continue;
                }
                $templateId = $employee->salary_type == 1 ? $request->template_type_1 : $request->template_type_2;

                $templateDetails =$employee->salary_type == 1? $template1Details: $template2Details;
                $earnings = 0;
                $deductions = 0;
                $componentAmounts = [];
                /*
            |--------------------------------------------------------------------------
            | CALCULATE EARNINGS FIRST
            |--------------------------------------------------------------------------
            */
                foreach ($templateDetails as $detail) {
                    $amount = 0;
                    if ( $detail->calculation_type == 'percentage') {
                        $amount = ($employee->basic_salary * $detail->percentage) / 100;
                    } elseif ( $detail->calculation_type == 'fixed') {
                        $amount = $detail->amount;
                    }
                    if ($detail->component_type == 'earning') {
                        $earnings += $amount;
                    }
                    $componentAmounts[$detail->component_code] = $amount;
                }

                /*
            |--------------------------------------------------------------------------
            | DEDUCTIONS
            |--------------------------------------------------------------------------
            */
                foreach ($templateDetails as $detail) {
                    $amount = 0;
                    if ( $detail->component_type != 'deduction') {
                        continue;
                    }
                    /*
                |--------------------------------------------------------------------------
                | PF
                |--------------------------------------------------------------------------
                */
                    if ( $detail->component_code == 'PF') {
                        $basic = $componentAmounts['BASIC'] ?? 0;
                        $da = $componentAmounts['DA'] ?? 0;
                        $pfBase = $basic + $da;
                        $amount = $pfBase > 15000 ? 1800 : ($pfBase * 0.12);
                    }

                    /*
                |--------------------------------------------------------------------------
                | ESI
                |--------------------------------------------------------------------------
                */  elseif ( $detail->component_code == 'ESI' ) {
                        $amount = $earnings <= 21000 ? ($earnings * 0.0075) : 0;
                    }
                    elseif ( $detail->calculation_type == 'percentage' ) {
                        $amount =( $employee->basic_salary * $detail->percentage ) / 100;
                    } elseif ( $detail->calculation_type == 'fixed') {
                        $amount = $detail->amount;
                    }
                    $deductions += $amount;
                    $componentAmounts[$detail->component_code] = $amount;
                }
                $net = $earnings - $deductions;

                $structure =
                    PayrollStaffStructureModel::create([
                        'employee_sno' => $employee->sno,
                        'payroll_template_sno' => $templateId,
                        'structure_code' =>'SAL-' . time() . rand(1000, 9999),
                        'structure_name' => 'Employee Salary Structure',
                        'gross_salary' =>$employee->basic_salary,
                        'total_earnings' => round($earnings, 2),
                        'total_deductions' => round($deductions, 2),
                        'net_salary' =>round($net, 2),
                        'ctc_amount' =>round($earnings, 2),
                        'revision_reason' =>$request->revision_reason,
                        'effective_from' => Carbon::parse($request->effective_from)->format('Y-m-d'),
                        'is_current' => 1,
                        'status' => 0,
                        'created_by' => auth()->id(),
                    ]);
                foreach ($templateDetails as $index => $detail) {
                    PayrollStaffStructureDetailModel::create([
                        'payroll_employee_structure_sno' => $structure->sno,
                        'payroll_component_sno' => $detail->component_sno,
                        'component_type' => $detail->component_type,
                        'calculation_type' =>$detail->calculation_type,
                        'percentage_value' => $detail->percentage,
                        'fixed_amount' => $componentAmounts[$detail->component_code] ?? 0,
                        'calculated_amount' => $componentAmounts[$detail->component_code] ?? 0,
                        'display_order' => $index + 1,
                        'status' => 0,
                    ]);
                }
                $createdCount++;
            }
            DB::commit();
            return response()->json([
                'status' => true,
                'message' =>$createdCount . ' employee salary structures created successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => false,
                'message' => $e->getMessage()

            ], 500);
        }
    }
}
