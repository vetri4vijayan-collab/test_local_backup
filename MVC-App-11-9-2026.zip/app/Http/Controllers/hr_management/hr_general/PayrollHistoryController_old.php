<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use PDF;
class PayrollHistoryController extends Controller
{


public function index()
{
return view('content.hr_management.hr_general.manage_payroll.history');
}


public function getRuns()
{

$runs = DB::table('egc_payroll_runs')
->where('status',0)
->orderByDesc('sno')
->get();

return response()->json($runs);

}


public function getRunDetails($runId)
{

$data = DB::table('egc_payroll_entries as e')

->join('egc_staff as s','s.sno','=','e.staff_id')

->where('e.payroll_run_sno',$runId)

->select(

's.staff_name as name',
's.staff_id as staff_code',

'e.basic_salary',
'e.present_days',
'e.absent_days',

'e.lop_amount',
'e.pf_amount',
'e.pt_amount',
'e.esi_amount',
'e.net_salary'

)

->get();

return response()->json($data);

}


public function getPayslip($entryId)
{

$data = DB::table('egc_payroll_entries as e')

->join('egc_staff as s','s.sno','=','e.staff_id')

->leftJoin('egc_staff_bank_details as b','b.staff_id','=','s.sno')

->where('e.sno',$entryId)

->select(

's.staff_name as name',
's.staff_id as staff_code',

'b.bank_name',
'b.bank_account_no as account_number',

'e.basic_salary',

'e.present_days',
'e.absent_days',

'e.lop_amount',
'e.pf_amount',
'e.pt_amount',
'e.esi_amount',
'e.created_at',

'e.net_salary'

)

->first();


return response()->json($data);

}



public function downloadPDF($entryId)
{

$data = $this->getPayslip($entryId)->getData();
// return $data;
    return View('content.hr_management.hr_general.manage_payroll.payslip_print',['data'=>$data]);

// $pdf = PDF::loadView('content.hr_management.hr_general.manage_payroll.payslip_print',['data'=>$data]);
// $pdf = PDF::loadView('content.hr_management.hr_general.manage_payroll.payslip_print', $data)
//           ->setPaper('a4', 'portrait')
//           ->setOptions([
//               'isHtml5ParserEnabled' => true,
//               'isRemoteEnabled' => true
//           ]);
// return $pdf->download('Payslip.pdf');

}

// public function downloadPDF($entryId)
// {
//     $data = $this->getPayslip($entryId)->getData();

//     $pdf = PDF::loadView(
//         'content.hr_management.hr_general.manage_payroll.payslip_print',
//         ['data' => $data]
//     )
//     ->setPaper('a4', 'portrait')
//     ->setOptions([
//         'isHtml5ParserEnabled' => true,
//         'isRemoteEnabled' => true,
//         'defaultFont' => 'DejaVu Sans'
//     ]);

//     return $pdf->download('Payslip.pdf');
// }

public function PaySlipPrint($entryId){
    $decrypt_entryId = decrypt($entryId);
    $data = $this->getPayslip($decrypt_entryId)->getData();
//    return $data;
    return View('content.hr_management.hr_general.manage_payroll.payslip_print',['data'=>$data]);

}

}