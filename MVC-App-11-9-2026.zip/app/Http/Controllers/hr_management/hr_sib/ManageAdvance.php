<?php

namespace App\Http\Controllers\hr_management\hr_sib;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffTimestampModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\ShiftTimeModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use Carbon\Carbon;
use App\Models\WhatsappTemplateLogModel;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\StaffBankDetailsModel;
use App\Models\StaffPayrollProfileModel;
use App\Models\StaffStatutoryDetailsModel;
use App\Models\StaffSalaryComponentModel;
use App\Models\StaffExistReasonModel;
use App\Models\StaffTransferLogModel;
use App\Models\StaffSalaryAccountModel;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\Client\Response;

use App\Models\PayrollStaffStructureModel;
use App\Models\PayrollStaffStructureDetailModel;
use App\Models\StaffAdvanceModel;
use App\Services\AdvanceService;

class ManageAdvance extends Controller
{

public function __construct(AdvanceService $service)
    {
        $this->service = $service;
    }

  public function index(Request $request)
  {
    $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $company_fill = $request->company_fill ?? '';
        $entity_fill = $request->entity_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $division_fill = $request->division_fill ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';

        
        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $entity_list  = ManageEntityModel::where('status', 0)->orderBy('sno', 'ASC')->get();

    return view('content.hr_management.hr_sib.manage_advance.staff_advance_list', [
      'company_list' => $company_list,
      'perpage' => $perpage,
      'entity_list' => $entity_list,
    ]);
  }

   public function list(Request $request)
    {
        return response()->json(
            $this->service->list($request)
        );
    }

     public function staffAdvanceProfile(Request $request)
    {

      $monthFilter = $request->get('month_year', now()->format('M-Y'));

        try {
            // Parse month-year safely
            $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        } catch (\Exception $e) {
            $parsedDate = now()->startOfMonth();
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        }

        $staff = StaffModel::query()
            ->leftJoin('egc_company','egc_staff.company_id','=','egc_company.sno')
            ->leftJoin('egc_entity','egc_staff.entity_id','=','egc_entity.sno')
            ->leftJoin('egc_branch','egc_staff.branch_id','=','egc_branch.sno')
            ->leftJoin('egc_job_role','egc_staff.job_role_id','=','egc_job_role.sno')
            ->where('egc_staff.sno',$request->staff_id)
            ->select(
                'egc_staff.*',
                'egc_company.company_name',
                'egc_entity.entity_name',
                'egc_entity.entity_base_color',
                'egc_branch.branch_name',
                'egc_job_role.job_position_name as job_role_name'
            )
            ->first();

        if (!$staff) {
            return response()->json([
                'status'=>404
            ]);
        }

        $lastAdvance = DB::table('egc_staff_advance_amount_log')
          ->where('staff_id', $staff->sno)
          ->where('status', 0)
          ->orderByDesc('year')
          ->orderByDesc('month')
          ->first();

        $advanceData = DB::table('egc_staff_advance_amount_log')
          ->where('staff_id', $staff->sno)
          ->where('year', $year)
          ->where('month', $month)
          ->where('status', 0)
          ->first();

        return response()->json([
            'status'=>200,
            'staff'=>[
                'sno'=>$staff->sno,
                'staff_name'=>$staff->staff_name,
                'nick_name'=>$staff->nick_name,
                'staff_code'=>$staff->staff_id,
                'date_of_joining'=>date('d-M-Y',strtotime($staff->date_of_joining)),
                'profile_image'=>$staff->profile_image_url,
                'company_name'=>$staff->company_name,
                'entity_name'=>$staff->entity_name,
                'entity_base_color'=>$staff->entity_base_color ?? '#ab2b22',
                'branch_name'=>$staff->branch_name,
                'job_role_name'=>$staff->job_role_name,
                'last_advance'=>$lastAdvance
                    ? date('M-Y',strtotime(
                        $lastAdvance->year.'-'.$lastAdvance->month.'-01'
                    ))
                    : '',

                'last_advance_amount'=>$lastAdvance
                    ? $lastAdvance->total_amount : 'No Advance'
            ],
            'data'=>$advanceData ??NULL
        ]);
    }


    public function updateAdvanceLog(Request $request)
    {
        $request->validate([
            'staff_id'   => 'required',
            'month_year' => 'required',
            'amount'     => 'required',
            'remarks'    => 'nullable'
        ]);

        DB::beginTransaction();
        $user_id = $request->user()->user_id ;

        try {

            [$monthName, $year] = explode('-', $request->month_year);

            $month =Carbon::parse(
                '01-'.$monthName.'-'.$year
            )->month;

            $staff =DB::table('egc_staff')->where('sno',$request->staff_id)->first();

            DB::table('egc_staff_advance_amount_log')
                ->updateOrInsert(

                    [
                        'staff_id' => $request->staff_id,
                        'month'    => $month,
                        'year'     => $year,
                    ],

                    [
                        'entity_id'   => $staff->entity_id ?? 0,
                        'job_role_id'   => $staff->job_role_id ?? 0,
                        'role_id'      => $staff->role_id ?? NULL,
                        'total_amount'        => $request->amount,
                        'remarks'       => $request->remarks,
                        'status'        => 0,
                        'updated_at'    => Carbon::now('Asia/Kolkata'),
                        'updated_by'    => $user_id,
                        'created_at'    => Carbon::now('Asia/Kolkata'),
                        'created_by'    => $user_id,
                    ]
                );

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Advance Amount updated successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Unable to update Advance Amount',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null
            ], 500);
        }
    }
  
}
