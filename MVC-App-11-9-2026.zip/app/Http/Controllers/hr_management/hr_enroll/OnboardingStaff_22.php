<?php

namespace App\Http\Controllers\hr_management\hr_enroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CompanyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\OnboardingStaffModel;

class OnboardingStaff extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

    // $staffData = StaffModel::where('egc_staff.status', '!=', 2)
    //   ->select('egc_staff.*',
    //   'egc_entity.entity_name',
    //   'egc_entity.entity_short_name',
    //   'egc_company.company_name',
    //   'egc_company.company_base_color',
    //   'egc_department.department_name',
    //   'egc_division.division_name',
    //   'egc_job_role.job_position_name as job_role_name',
    //   )
    //   ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
    //   ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
    //   ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
    //   ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
    //   ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
    //   ->where('egc_staff.sno', '>', 1)
    //   ->whereIn('egc_staff.status', [0,1]);
    //    if ($search_filter != '') {
    //         $staffData->where(function ($subquery) use ($search_filter) {
    //             $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
    //                 ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
    //                 ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%")
    //                 ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
    //                 ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
    //                 ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%")
    //                 ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
    //                 ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
    //                 ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%");
                    
    //         });
    //     }

    //     if($company_fill != ''){
    //       if($company_fill == 'egc'){
    //          $staffData->where('egc_staff.company_type',1);
    //       }else{
    //         $staffData->where('egc_staff.company_id', 'LIKE', $company_fill);
    //       }
            
    //     }

    //     if ($entity_fill) {
    //       $staffData->where('egc_staff.entity_id', $entity_fill);
    //     }

        
    //     if ($department_fill) {
    //         $staffData->where('egc_staff.department_id', $department_fill);
    //     }

    //     if ($division_fill) {
    //         $staffData->where('egc_staff.division_id', $division_fill);
    //     }

    //     if ($job_role_fill) {
    //       $staffData->where('egc_staff.job_role_id', $job_role_fill);
    //     }

    //      if ($date_filter == "today") {
    //         $todayDate = date("Y-m-d");
    //         $staffData->whereDate('egc_staff.date_of_joining', $todayDate);
    //       } elseif ($date_filter == "week") {
    //         $today = date('l');
    //         if ($today == "Sunday") {
    //           $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
    //           $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
    //         } else {
    //           $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
    //           $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
    //         }
    //         $staffData->whereBetween('egc_staff.date_of_joining', [$weekFromDate, $weekToDate]);
    //       } elseif ($date_filter == "monthly") {
    //         $firstDayOfMonth = date('Y-m-01');
    //         $lastDayOfMonth = date('Y-m-t');
    //         $staffData->whereBetween('egc_staff.date_of_joining', [$firstDayOfMonth, $lastDayOfMonth]);
    //       } elseif ($date_filter == "custom_date") {
    //         if ($from_date_filter && $to_date_filter) {
    //           $fromDate = date('Y-m-d', strtotime($from_date_filter));
    //           $toDate = date('Y-m-d', strtotime($to_date_filter));
    //           $staffData->whereBetween('egc_staff.date_of_joining', [$fromDate, $toDate]);
    //         } elseif ($from_date_filter) {
    //           $fromDate = date('Y-m-d', strtotime($from_date_filter));
    //           $staffData->where('egc_staff.date_of_joining', '>=', $fromDate);
    //         } elseif ($to_date_filter) {
    //           $toDate = date('Y-m-d', strtotime($to_date_filter));
    //           $staffData->where('egc_staff.date_of_joining', '<=', $toDate);
    //         }
    //       }

    //     $staffData=$staffData->orderBy('egc_staff.sno', 'desc')->paginate($perpage);
        
    //     foreach($staffData as $staff){
    //         if($staff->company_type == 1){
    //               $staff->company_name=$general_setting->title;
    //               $staff->company_base_color ='#ab2b22';
    //         }
            
    //        $educations = DB::table('egc_staff_education_info')
    //         ->select('egc_education.education')
    //         ->join('egc_education', 'egc_education.sno', '=', 'egc_staff_education_info.qualification_type')
    //         ->where('egc_staff_education_info.staff_id', $staff->sno) 
    //         ->where('egc_staff_education_info.status', 0)
    //         ->pluck('egc_education.education');
    //         $staff->education=$educations;
    //     }

       

    //     if ($request->ajax()) {
    //         $data = $staffData->map(function ($item) use ($helper) {
    //             return [
    //                 'sno' => $item->sno,
    //                 'status' => $item->status,
    //                 'staff_name' => $item->staff_name,
    //                 'nick_name' => $item->nick_name,
    //                 'gender' => $item->gender,
    //                 'company_id' => $item->company_id,
    //                 'entity_id' => $item->entity_id,
    //                 'company_type' => $item->company_type,
    //                 'department_name' => $item->department_name,
    //                 'division_name' => $item->division_name,
    //                 'job_role_name' => $item->job_role_name,
    //                 'exp_type' => $item->exp_type,
    //                 'basic_salary' => $item->basic_salary,
    //                 'completion_percentage' => $item->completion_percentage,
    //                 'company_base_color' => $item->company_base_color,
    //                 'company_name' => $item->company_name,
    //                 'entity_name' => $item->entity_name,
    //                 'department_desc' => $item->department_desc,
    //                 'data' => $item,
    //                 'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
    //             ];
    //         });

    //         return response()->json([
    //             'data' => $data,
    //             'current_page' => $staffData->currentPage(),
    //             'last_page' => $staffData->lastPage(),
    //             'total' => $staffData->total(),
    //         ]);
    //     }

        $data = OnboardingStaffModel::with([
            'department',
            'division',
            'jobRole',
            'reportingStaff',
            'entity'
        ])
        ->where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->paginate($perpage);

        if ($request->ajax()) {
            return response()->json([
                'data' => $data->map(fn($item) => [
                    'id' => $item->sno,
                    'candidate_name' => $item->candidate_name,
                    'personal_email' => $item->personal_email,
                    'mobile' => $item->mobile,
                    'entity_name' => $item->entity->entity_name,
                    'entity_base_color' => $item->entity->entity_base_color,
                    'job_role' => $item->jobRole->job_position_name ?? '-',
                    'department' => $item->department->department_name ?? '-',
                    'division' => $item->division->division_name ?? '-',
                    'doj' => optional($item->doj)->format('d-M-Y'),
                    'basic_salary' => number_format($item->basic_salary, 2),
                    'reporting_staff' => $item->reportingStaff->staff_name ?? '-',
                    'onboarding_step' => $item->onboarding_step,
                    'document_status' => ucfirst($item->document_status),
                    'status' => $item->status,
                    'status_label' => $item->status == 0 ? 'Active' : 'Pending',
                ]),
                'current_page' => $data->currentPage(),
                'last_page' => $data->lastPage(),
                'total' => $data->total(),
            ]);
        }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.hr_management.hr_enroll.onboarding_staff.staff_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }
}
