<?php

namespace App\Http\Controllers\hr_management\hr_enroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CompanyModel;
use App\Models\DepartmentModel;
use App\Models\StaffAttendanceModel;
use App\Models\StaffEsslModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\Crypt;
use DateTime;
use App\Models\Batch_staff_swap_Model;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\View;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\SubErpWebhookModel;
use App\Models\ManageEntityModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use App\Models\AttendanceQRModel;
use App\Services\BiometricService;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class ManageAttendance extends Controller
{


// public function index(Request $request)
// {
//     $page = $request->input('page', 1);
//     $perpage = (int) ($request->sorting_filter ?? 100);

//     $company_fill = $request->company_fill ?? 'egc';
//     $entity_fill = $request->entity_fill ?? '0';
//     $search_filter = $request->search_filter ?? '';

//     $helper = new \App\Helpers\Helpers();
//     $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

//     // ------------------ MONTH PARSING ------------------
//     $month_filter = $request->get('month_filter', date('M-Y'));
//     // return  $month_filter;
//     $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
//     // $month_filter = $request->get('month_filter', date('m-Y'));  // Default to numeric month (11-2025)
//     // $parsedDate = Carbon::createFromFormat('m-Y', $month_filter);

//     $month = $parsedDate->month;
//     $year  = $parsedDate->year;

//     $startDate = Carbon::create($year, $month, 1)->startOfMonth();
//     $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
//     $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
//     $today = Carbon::today();

//     // Limit end date to today if month is current
//     if ($today->between($startDate, $endDate)) {
//         $endDate = $today;
//     }

   

//     // ------------------ HOLIDAY RECORDS ------------------
//         $holidays = DB::table('egc_holiday')
//             ->where('status', 0)
//             ->where(function ($q) use ($startDate, $endDate) {
//                 $q->whereBetween('hol_date', [$startDate, $endDate])
//                 ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
//             })
//             ->get();

//         $holidayDates = collect();

//         foreach ($holidays as $hol) {
//             $start = Carbon::parse($hol->hol_date);
//             $end   = $hol->hol_end_date ? Carbon::parse($hol->hol_end_date) : $start;

//             foreach (CarbonPeriod::create($start, $end) as $d) {
//                 $holidayDates->push($d->format('Y-m-d'));
//             }
//         }

//         $holidayDates = $holidayDates->unique();
    
//     $dayCount = collect(CarbonPeriod::create($startDate, $endDate))
//         ->filter(function ($d) use ($holidayDates) {
//             return $d->dayOfWeek !== Carbon::SUNDAY
//                 && !$holidayDates->contains($d->format('Y-m-d'));
//         })
//         ->count();
    
//     // ------------------ STAFF QUERY ------------------
//     $query = StaffModel::select(
//         'egc_staff.sno as staff_id',
//         'egc_staff.staff_id as employee_id',
//         'egc_staff.staff_name',
//         'egc_staff.nick_name',
//         'egc_staff.gender',
//         'egc_staff.company_type',
//         'egc_staff.company_id',
//         'egc_staff.entity_id',
//         'egc_staff.staff_image',
//         'egc_department.department_name'
//     )
//     ->join('egc_department','egc_department.sno','=','egc_staff.department_id')
//     ->where('egc_staff.status',0)
//     ->where('egc_staff.sno','>',1);


//     if ($search_filter != '') {
//             $query->where(function ($subquery) use ($search_filter) {
//                 $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
//                     ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
//                     ->orWhere('egc_staff.staff_id', 'LIKE', "%{$search_filter}%")
//                     ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%");
                    
//             });
//         }

//     if($company_fill !== ""){
//         if($company_fill == 'egc'){
//             $query->where('egc_staff.company_type',1);
//         } else {
//             if($entity_fill !== ""){
//                 $query->where('egc_staff.entity_id', $entity_fill);
//             }
//         }
//     }

 
//     $total_staff= $query->count();

//     // paginated for ajax
//     $staffs = $query->paginate($perpage);

//     // ------------------ ATTENDANCE RECORDS ------------------
//     $attendanceRecords = StaffAttendanceModel::select('egc_staff_attendance.staff_id','egc_staff_attendance.date','egc_staff_attendance.attendance')
//        ->join('egc_staff','egc_staff.sno','=','egc_staff_attendance.staff_id')
//        ->where('egc_staff.status',0)
//         ->where('egc_staff.sno','>',1)
//         ->whereBetween('egc_staff_attendance.date', [$startDate, $endDate]);
//         if($company_fill !== ""){
//             if($company_fill == 'egc'){
//                 $attendanceRecords->where('egc_staff.company_type',1);
//             } else {
//                 if($entity_fill !== ""){
//                     $attendanceRecords->where('egc_staff.entity_id', $entity_fill);
//                 }
//             }
//         }

//         $attendanceRecords=$attendanceRecords->get()->groupBy('staff_id');

//         $totalAttendanceRecords = $attendanceRecords->flatMap(function($records) {
//             return $records->where('status', 0); // Filter out other attendance types
//         })->count();

//         $totalPresentCount = $attendanceRecords->flatMap(function($records) {
//             return $records->whereIn('attendance', ['P','HD']); // Filter out other attendance types
//         })->count();

//         $totalAbsentCount = $attendanceRecords->flatMap(function($records) {
//             return $records->where('attendance', 'A'); // Filter out other attendance types
//         })->count();

//         $totalLeaveCount = $attendanceRecords->flatMap(function($records) {
//             return $records->where('attendance', 'L'); // Filter out other attendance types
//         })->count();

//         $totalPRMCount = $attendanceRecords->flatMap(function($records) {
//             return $records->where('attendance', 'PR'); // Filter out other attendance types
//         })->count();

//         $totalODCount = $attendanceRecords->flatMap(function($records) {
//             return $records->where('attendance', 'OD'); // Filter out other attendance types
//         })->count();
        

//         $AvgTotalPresent=$total_staff > 0 ? $totalPresentCount/$total_staff : 0;
//         $totalPresentPercentage =$dayCount > 0 ? ($AvgTotalPresent/$dayCount)*100 :0;
//         $totalPresentPercentage = $totalPresentPercentage >= 100 ? 100 : round($totalPresentPercentage,1);
//         $totalPresentPercentage = $totalPresentPercentage <= 0 ?'00' : round($totalPresentPercentage,1);

//         $AvgTotalAbsent=$total_staff > 0 ? $totalAbsentCount/$total_staff : 0;
//         $totalAbsentPercentage =$dayCount > 0 ? ($AvgTotalAbsent/$dayCount)*100 :0;
//         $totalAbsentPercentage = $totalAbsentPercentage >= 100 ? 100 : round($totalAbsentPercentage,1);
//         $totalAbsentPercentage = $totalAbsentPercentage <= 0 ?'00' : round($totalAbsentPercentage,1);

//         $AvgTotalLeave=$total_staff > 0 ? $totalLeaveCount/$total_staff : 0;
//         $totalLeavePercentage =$dayCount > 0 ? ($AvgTotalLeave/$dayCount)*100 :0;
//         $totalLeavePercentage = $totalLeavePercentage >= 100 ? 100 : round($totalLeavePercentage,1);
//         $totalLeavePercentage = $totalLeavePercentage <= 0 ?'00' : round($totalLeavePercentage,1);

//         $AvgTotalPRM=$total_staff > 0 ? $totalPRMCount/$total_staff : 0;
//         $totalPRMPercentage =$dayCount > 0 ? ($AvgTotalPRM/$dayCount)*100 :0;
//         $totalPRMPercentage = $totalPRMPercentage >= 100 ? 100 : round($totalPRMPercentage,1);
//         $totalPRMPercentage = $totalPRMPercentage <= 0 ?'00' : round($totalPRMPercentage,1);

//         $AvgTotalOD=$total_staff > 0 ? $totalODCount/$total_staff : 0;
//         $totalODPercentage =$dayCount > 0 ? ($AvgTotalOD/$dayCount)*100 :0;
//         $totalODPercentage = $totalODPercentage >= 100 ? 100 : round($totalODPercentage,1);
//         $totalODPercentage = $totalODPercentage <= 0 ?'00' : round($totalODPercentage,1);

//         // $EsslData = $helper->get_staff_essl('EGC03075') ?? collect();
//         // return $EsslData;

//          // ------------------ NORMAL (NON-AJAX) VIEW ------------------
//     $company_list = CompanyModel::where('status',0)->get();
//     $entity_names = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('entity_name')->prepend('Elysium Groups');
//     $entity_colors = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('entity_base_color')->prepend('#ab2b22');
//     $entity_ids = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('sno')->prepend('0');

   
//     $monthName=Carbon::parse($month_filter)->format('F');

//     // ------------------ AJAX RESPONSE ------------------
//     if ($request->ajax()) {

//         $data = $staffs->map(function($row) use ($dates, $attendanceRecords,$dayCount,$helper, $holidayDates){

//             $attendanceData = [];
//             $InTimeData = [];
//             $shiftData = [];
//             $OutTimeData = [];
//             $totalPresent = 0; 
//             $totalAbsent = 0; 
//             $totalLeave = 0; 
//             $EsslData = $helper->get_staff_essl($row->employee_id) ?? collect();
//             foreach($dates as $d){
//                 $dateKey = $d->format('Y-m-d');
//                 $isSunday = $d->dayOfWeek === Carbon::SUNDAY;
//                 $isHoliday = $holidayDates->contains($dateKey);

//                 $record = optional(
//                     $attendanceRecords[$row->staff_id] ?? collect()
//                 )
//                 ->where('date', $dateKey)
//                 ->first();

//                 if ($isSunday) {
//                     $attendanceData[$dateKey] = 'WK';
//                     $InTimeData[$dateKey] = '';
//                     $OutTimeData[$dateKey] = '';
//                     continue;
                    
//                 }if ($isHoliday) {
//                     $attendanceData[$dateKey] = 'HD';
//                     $InTimeData[$dateKey] = '';
//                     $OutTimeData[$dateKey] = '';
//                     continue;
//                 }else {
//                    $attendance = $record->attendance ?? "-";
//                    $attendanceData[$dateKey] = $attendance;

//                     // Count types
//                     if (in_array($attendance, ['P','PR','HD'])) $totalPresent++;
//                     if ($attendance == 'A') $totalAbsent++;
//                     if ($attendance == 'L') $totalLeave++;
                    
//                     // ESSL — only map if exists
//                     if (isset($EsslData[$dateKey])) {
//                         $InTimeData[$dateKey]  = $EsslData[$dateKey]->in_time ? date("h:i A", strtotime($EsslData[$dateKey]->in_time)) :'';
//                         $OutTimeData[$dateKey] = $EsslData[$dateKey]->out_time ? date("h:i A", strtotime($EsslData[$dateKey]->out_time)) :'';;
//                     } else {
//                         $InTimeData[$dateKey]  = '';
//                         $OutTimeData[$dateKey] = '';
//                     }
//                     $shiftData[$dateKey] = $helper->getStaffShiftTime($row->staff_id,$dateKey);
//                 }
//             }
            
//             return [
//                 'staff_id' => $row->staff_id,
//                 'staff_name' => $row->staff_name,
//                 'nick_name' => $row->nick_name,
//                 'department_name' => $row->department_name,
//                 'gender' => $row->gender,
//                 'staff_image' => $row->staff_image,
//                 'company_id' => $row->company_id,
//                 'company_type' => $row->company_type,
//                 'entity_id' => $row->entity_id,
//                 'employee_id' => $row->employee_id,
//                 'shift_data' => $shiftData,
//                 'attendance' => $attendanceData,
//                 'in_time' => $InTimeData,
//                 'out_time' => $OutTimeData,
//                 'dayCount' => $dayCount,
//                 'totalPresent' => $totalPresent,
//                 'totalAbsent' => $totalAbsent,
//                 'totalLeave' => $totalLeave,
//             ];
//         });

//         return response()->json([
//             'data' => $data,
//             'totalPresentCount' => $totalPresentCount,
//             'totalAbsentCount' => $totalAbsentCount,
//             '$totalAttendanceRecords' => $totalAttendanceRecords,
//             'totalPresentPercentage' => round($totalPresentPercentage,1),
//             'totalODPercentage' => round($totalODPercentage,1),
//             'totalLeavePercentage' => round($totalLeavePercentage,1),
//             'totalAbsentPercentage' => round($totalAbsentPercentage,1),
//             'totalPRMPercentage' => round($totalPRMPercentage,1),
//             'dates' => array_map(fn($d)=>$d->format('Y-m-d'), $dates),
//             'current_page' => $staffs->currentPage(),
//             'last_page' => $staffs->lastPage(),
//             'total' => $staffs->total(),
//             'month' => $month,
//             'monthName' => $monthName,
//             'year' => $year,
//             'entity_names' => $entity_names,
//             'entity_colors' => $entity_colors ,
//         ]);
//     }

   
  
//     return view('content.hr_management.hr_enroll.manage_attendance.manage_attendance',[
//         'staffs' => $staffs,
//         'company_list' => $company_list,
//         'dates' => $dates,
//         'month' => $month,
//         'monthName' => $monthName,
//         'year' => $year,
//         'month_filter' => $month_filter,
//         'company_fill' => $company_fill,
//         'entity_names' => $entity_names,
//         'entity_colors' => $entity_colors ,
//         'perpage' => $perpage
//     ]);
// }

public function index_01_04(Request $request)
{
    $page = $request->input('page', 1);
    $perpage = (int) ($request->sorting_filter ?? 100);

    $company_fill = $request->company_fill ?? 'egc';
    $entity_fill = $request->entity_fill ?? '0';
    $search_filter = $request->search_filter ?? '';

    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

    // ------------------ MONTH PARSING ------------------
    $month_filter = $request->get('month_filter', date('M-Y'));
    // return  $month_filter;
    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
    // $month_filter = $request->get('month_filter', date('m-Y'));  // Default to numeric month (11-2025)
    // $parsedDate = Carbon::createFromFormat('m-Y', $month_filter);

    $month = $parsedDate->month;
    $year  = $parsedDate->year;

    $startDate = Carbon::create($year, $month, 1)->startOfMonth();
    $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
    $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
    $today = Carbon::today();

    // Limit end date to today if month is current
    if ($today->between($startDate, $endDate)) {
        $endDate = $today;
    }

   

    // ------------------ HOLIDAY RECORDS ------------------
        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('hol_date', [$startDate, $endDate])
                ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->get();

        $holidayDates = collect();

        foreach ($holidays as $hol) {
            $start = Carbon::parse($hol->hol_date);
            $end   = $hol->hol_end_date ? Carbon::parse($hol->hol_end_date) : $start;

            foreach (CarbonPeriod::create($start, $end) as $d) {
                $holidayDates->push($d->format('Y-m-d'));
            }
        }

        $holidayDates = $holidayDates->unique();
        $dayCount = collect(CarbonPeriod::create($startDate, $endDate))->count();
    
    // $dayCount = collect(CarbonPeriod::create($startDate, $endDate))
    //     ->filter(function ($d) use ($holidayDates) {
    //         return $d->dayOfWeek !== Carbon::SUNDAY
    //             && !$holidayDates->contains($d->format('Y-m-d'));
    //     })
    //     ->count();

    $total_staff_count = StaffModel::join('egc_department','egc_department.sno','=','egc_staff.department_id')
                        ->where('egc_staff.status',0)
                        ->where('egc_staff.sno','>',0)->count();

     if ($company_fill !== "" && $company_fill == 'egc') {
        $Entity_name = 'Elysium Groups';
        $Entity_short_name = 'EGC';
        $base_color_name = '#ab2b22';

    } else {

        $EntityData = DB::table('egc_entity')->where('status', 0);

        if ($entity_fill !== "") {
            $EntityData->where('sno', $entity_fill);
        }

        $EntityData = $EntityData->first();

        if ($EntityData) {
            $Entity_name = $EntityData->entity_name;
            $Entity_short_name = $EntityData->entity_short_name;
            $base_color_name = $EntityData->entity_base_color;
        } else {
            $Entity_name = 'Elysium Groups';
            $Entity_short_name = 'EGC';
            $base_color_name = '#ab2b22';
        }
    }
    
    // ------------------ STAFF QUERY ------------------
    $query = StaffModel::select(
        'egc_staff.sno as staff_id',
        'egc_staff.staff_id as employee_id',
        'egc_staff.staff_name',
        'egc_staff.nick_name',
        'egc_staff.gender',
        'egc_staff.company_type',
        'egc_staff.company_id',
        'egc_staff.entity_id',
        'egc_staff.date_of_joining',
        'egc_staff.staff_image',
        'egc_department.department_name'
    )
    ->join('egc_department','egc_department.sno','=','egc_staff.department_id')
    ->where('egc_staff.status',0)
    //  ->where('egc_staff.sno',122)
    ->where('egc_staff.sno','>',0)
    ->orderBy('egc_staff.date_of_joining','asc');


    if ($search_filter != '') {
            $query->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.staff_id', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%");
                    
            });
        }

    if($company_fill !== ""){
        if($company_fill == 'egc'){
            $query->where('egc_staff.company_type',1);
        } else {
            if($entity_fill !== ""){
                $query->where('egc_staff.entity_id', $entity_fill);
            }
        }
    }

 
    $total_staff= $query->count();

    // paginated for ajax
    $staffs = $query->paginate($perpage);

    $company_staff_count =$total_staff;

    $allStaffIds = $staffs->pluck('staff_id');

     $allShiftLogs = DB::table('egc_shift_time_log as stl')
        ->join('egc_shift_day_times as sdt', 'stl.change_shift_id', '=', 'sdt.shift_id')
        ->whereIn('stl.staff_id', $allStaffIds)
        ->whereNull('stl.end_date') // current active shift log
        ->where('sdt.status', 0)
        ->select('stl.staff_id', 'sdt.day_name', 'sdt.time_from', 'sdt.time_to')
        ->get()
        ->groupBy('staff_id');

    $totalWorkingDays = 0;

    foreach($staffs as $staff){

        $staffShiftLogs = $allShiftLogs[$staff->staff_id] ?? collect();

        foreach($dates as $d){

            if($d->gt(Carbon::today())) continue;

            $dayName = strtolower($d->format('D'));

             $shift = $staffShiftLogs->where('day_name', $dayName)->first();

            if($shift){

                $dateKey = $d->format('Y-m-d');

                if(!$holidayDates->contains($dateKey)){
                    $totalWorkingDays++;
                }

            }

        }

    }

    $dayCount = $total_staff > 0 ? $totalWorkingDays / $total_staff : 0;

    // ------------------ ATTENDANCE RECORDS ------------------
    $attendanceRecords = StaffAttendanceModel::select('egc_staff_attendance.staff_id','egc_staff_attendance.date','egc_staff_attendance.attendance','egc_staff_attendance.leave_type','egc_staff_attendance.status')
       ->join('egc_staff','egc_staff.sno','=','egc_staff_attendance.staff_id')
       ->where('egc_staff.status',0)
        ->where('egc_staff.sno','>',0)
        ->whereBetween('egc_staff_attendance.date', [$startDate, $endDate]);
        if($company_fill !== ""){
            if($company_fill == 'egc'){
                $attendanceRecords->where('egc_staff.company_type',1);
            } else {
                if($entity_fill !== ""){
                    $attendanceRecords->where('egc_staff.entity_id', $entity_fill);
                }
            }
        }

        $attendanceRecords=$attendanceRecords->get()->groupBy('staff_id');

        $attendanceRecords = $attendanceRecords->map(function($items){
            return $items->keyBy('date');
        });

        $totalAttendanceRecords = $attendanceRecords->flatMap(function($records) {
            return $records->where('status', 0); // Filter out other attendance types
        })->count();

        $totalPresentCount = $attendanceRecords->flatMap(function($records) {
            return $records->whereIn('attendance', ['P','HD']); // Filter out other attendance types
        })->count();

        $totalAbsentCount = $attendanceRecords->flatMap(function($records) {
            return $records->where('attendance', 'A'); // Filter out other attendance types
        })->count();

        $totalLeaveCount = $attendanceRecords->flatMap(function($records) {
            return $records->where('attendance', 'L'); // Filter out other attendance types
        })->count();

        $totalPRMCount = $attendanceRecords->flatMap(function($records) {
            return $records->where('attendance', 'PR'); // Filter out other attendance types
        })->count();

        $totalODCount = $attendanceRecords->flatMap(function($records) {
            return $records->where('attendance', 'OD'); // Filter out other attendance types
        })->count();
        
        
        $AvgTotalPresent=$total_staff > 0 ? $totalPresentCount/$total_staff : 0;
        $totalPresentPercentage =$dayCount > 0 ? ($AvgTotalPresent/$dayCount)*100 :0;
        $totalPresentPercentage = $totalPresentPercentage >= 100 ? 100 : round($totalPresentPercentage,1);
        $totalPresentPercentage = $totalPresentPercentage <= 0 ?'00' : round($totalPresentPercentage,1);

        $AvgTotalAbsent=$total_staff > 0 ? $totalAbsentCount/$total_staff : 0;
        $totalAbsentPercentage =$dayCount > 0 ? ($AvgTotalAbsent/$dayCount)*100 :0;
        $totalAbsentPercentage = $totalAbsentPercentage >= 100 ? 100 : round($totalAbsentPercentage,1);
        $totalAbsentPercentage = $totalAbsentPercentage <= 0 ?'00' : round($totalAbsentPercentage,1);

        $AvgTotalLeave=$total_staff > 0 ? $totalLeaveCount/$total_staff : 0;
        $totalLeavePercentage =$dayCount > 0 ? ($AvgTotalLeave/$dayCount)*100 :0;
        $totalLeavePercentage = $totalLeavePercentage >= 100 ? 100 : round($totalLeavePercentage,1);
        $totalLeavePercentage = $totalLeavePercentage <= 0 ?'00' : round($totalLeavePercentage,1);

        $AvgTotalPRM=$total_staff > 0 ? $totalPRMCount/$total_staff : 0;
        $totalPRMPercentage =$dayCount > 0 ? ($AvgTotalPRM/$dayCount)*100 :0;
        $totalPRMPercentage = $totalPRMPercentage >= 100 ? 100 : round($totalPRMPercentage,1);
        $totalPRMPercentage = $totalPRMPercentage <= 0 ?'00' : round($totalPRMPercentage,1);

        $AvgTotalOD=$total_staff > 0 ? $totalODCount/$total_staff : 0;
        $totalODPercentage =$dayCount > 0 ? ($AvgTotalOD/$dayCount)*100 :0;
        $totalODPercentage = $totalODPercentage >= 100 ? 100 : round($totalODPercentage,1);
        $totalODPercentage = $totalODPercentage <= 0 ?'00' : round($totalODPercentage,1);

        // $EsslData = $helper->get_staff_essl('EGC03075') ?? collect();
        // return $EsslData;

         // ------------------ NORMAL (NON-AJAX) VIEW ------------------
    $company_list = CompanyModel::where('status',0)->get();
    $entity_names = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('entity_name')->prepend('Elysium Groups');
    $entity_colors = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('entity_base_color')->prepend('#ab2b22');
    $entity_ids = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('sno')->prepend('0');

   
    $monthName=Carbon::parse($month_filter)->format('F');
    $staffIds = $staffs->pluck('staff_id');

    // $shiftTimes = DB::table('egc_staff as s')
    //     ->join('egc_shift_day_times as sd', 'sd.shift_id','=','s.shift_time_id')
    //     ->whereIn('s.sno',$staffIds)
    //     ->where('sd.status',0)
    //     ->select(
    //         's.sno as staff_id',
    //         'sd.day_name',
    //         'sd.time_from',
    //         'sd.time_to'
    //     )
    //     ->get()
    //     ->groupBy('staff_id');

        $shiftTimes = DB::table('egc_shift_time_log as stl')
            ->join('egc_shift_day_times as sdt', 'stl.change_shift_id', '=', 'sdt.shift_id')
            ->whereIn('stl.staff_id', $staffIds)
            ->where('sdt.status', 0)
            ->select(
                'stl.staff_id',
                'stl.start_date',
                'stl.end_date',
                'sdt.day_name',
                'sdt.time_from',
                'sdt.time_to'
            )
            ->orderBy('stl.start_date')
            ->get()
            ->groupBy('staff_id');

        $esslRecords = DB::table('egc_staff_essl')
            ->whereBetween('date',[$startDate,$endDate])
            ->whereIn('employee_id',$staffs->pluck('employee_id'))
            ->get()
            ->groupBy('employee_id');

            $esslRecords = $esslRecords->map(function($items){
                return $items->keyBy('date');
            });
        
    // ------------------ AJAX RESPONSE ------------------
    if ($request->ajax()) {
        $overAllPercent=0;
        $overAllAbsent=0;
        $overAllLeave=0;
        $overAllPR=0;
        $overAllOD=0;

        $data = $staffs->map(function($row) use ($dates, $attendanceRecords, $holidayDates,$shiftTimes,$esslRecords,&$overAllPercent,&$overAllAbsent,&$overAllLeave,&$overAllPR,&$overAllOD){

            $attendanceData = [];
            $leaveTypeData = [];
            $shiftData = [];
            $InTimeData  = [];
            $OutTimeData = [];
            $CheckInTimeData  = [];
            $CheckOutTimeData = [];
            $totalPresent = 0; 
            $totalOriginalPresent = 0; 
            $totalAbsent = 0; 
            $PresentCount = 0; 
            $totalLeave = 0; 
            $totalOD = 0; 
            $totalPR = 0; 
            // $EsslData = $helper->get_staff_essl($row->employee_id) ?? collect();
            $EsslData = $esslRecords[$row->employee_id] ?? collect();
            
            $dayCount = 0;

            // foreach($dates as $d){
            //     $dateKey = $d->format('Y-m-d');
            //     $isSunday = $d->dayOfWeek === Carbon::SUNDAY;
            //     $isHoliday = $holidayDates->contains($dateKey);

            //     $record = optional(
            //         $attendanceRecords[$row->staff_id] ?? collect()
            //     )
            //     ->where('date', $dateKey)
            //     ->first();

            //     if ($isSunday) {
            //         $attendanceData[$dateKey] = 'WK';
            //         $InTimeData[$dateKey] = '';
            //         $OutTimeData[$dateKey] = '';
            //         continue;
                    
            //     }if ($isHoliday) {
            //         $attendanceData[$dateKey] = 'HD';
            //         $InTimeData[$dateKey] = '';
            //         $OutTimeData[$dateKey] = '';
            //         continue;
            //     }else {
            //        $attendance = $record->attendance ?? "-";
            //        $attendanceData[$dateKey] = $attendance;

            //         // Count types
            //         if (in_array($attendance, ['P','PR','HD'])) $totalPresent++;
            //         if ($attendance == 'A') $totalAbsent++;
            //         if ($attendance == 'L') $totalLeave++;
                    
            //         // ESSL — only map if exists
            //         if (isset($EsslData[$dateKey])) {
            //             $InTimeData[$dateKey]  = $EsslData[$dateKey]->in_time ? date("h:i A", strtotime($EsslData[$dateKey]->in_time)) :'';
            //             $OutTimeData[$dateKey] = $EsslData[$dateKey]->out_time ? date("h:i A", strtotime($EsslData[$dateKey]->out_time)) :'';;
            //         } else {
            //             $InTimeData[$dateKey]  = '';
            //             $OutTimeData[$dateKey] = '';
            //         }

            //        $shiftData[$dateKey] = $helper->getStaffShiftTime($row->staff_id,$dateKey);
            //     }
            // }
            
            foreach($dates as $d){
                $dateKey = $d->format('Y-m-d');
                
                // Skip future dates
                if($d->gt(Carbon::today())){
                    $attendanceData[$dateKey] = '-';
                    $InTimeData[$dateKey] = '';
                    $OutTimeData[$dateKey] = '';
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';
                    continue;
                }

                // Skip before joining date
                if($row->date_of_joining && $dateKey < $row->date_of_joining){
                    $attendanceData[$dateKey] = '-';
                    $InTimeData[$dateKey] = '';
                    $OutTimeData[$dateKey] = '';
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';
                    continue;
                }

                // $record = optional(
                //     $attendanceRecords[$row->staff_id] ?? collect()
                // )->where('date',$dateKey)->first();
                $record = $attendanceRecords[$row->staff_id][$dateKey] ?? null;

                $leaveType = $record->leave_type ?? null;
                $leaveTypeData[$dateKey] = $leaveType;

                // Get shift for that day
                // $dayName = strtolower(Carbon::parse($dateKey)->format('D'));
                $dayName = strtolower($d->format('D'));
                $staffShift = $shiftTimes[$row->staff_id] ?? collect();

                $hasShiftConfig = $staffShift->count() > 0;

                // $shift = $staffShift
                //             ->where('day_name',$dayName)
                //             ->first();
                $shift = $staffShift
                    ->filter(function($s) use ($dateKey,$dayName){

                        $start = $s->start_date;
                        $end   = $s->end_date ?? '9999-12-31';

                        return $dateKey >= $start 
                            && $dateKey <= $end
                            && $s->day_name == $dayName;

                    })
                    ->first();

                $shiftData[$dateKey] = $shift;

               

                // If no shift → Weekoff
                if($hasShiftConfig){

                    if(!$shift){

                        if($record){
                            $attendance = $record->attendance;
                            $leaveType = $record->leave_type ?? null; 
                            $leaveTypeData[$dateKey] = $leaveType;
                            if($attendance == 'P') $totalOriginalPresent++;
                            $essl = $EsslData[$dateKey] ?? null;
                            if($essl){
                                $InTimeData[$dateKey]  = $essl->in_time ? date("h:i A", strtotime($essl->in_time)) : '';
                                $OutTimeData[$dateKey] = $essl->out_time ? date("h:i A", strtotime($essl->out_time)) : '';
                                $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                                $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                                
                            }else{
                                $InTimeData[$dateKey]  = '';
                                $OutTimeData[$dateKey] = '';
                                $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                                $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                            }
                        }else{
                            $attendance = 'WK';
                            $InTimeData[$dateKey]  = '';
                            $OutTimeData[$dateKey] = '';
                             $leaveTypeData[$dateKey] = null;
                             $CheckInTimeData[$dateKey] = '';
                            $CheckOutTimeData[$dateKey] = '';
                        }

                        $attendanceData[$dateKey] = $attendance;
                        continue;
                    }

                }else{

                    // No shift config → Sunday weekoff
                    if($d->dayOfWeek === Carbon::SUNDAY){

                        if($record){
                            $attendance = $record->attendance;
                            $leaveType = $record->leave_type ?? null; 
                            $leaveTypeData[$dateKey] = $leaveType;
                             if($attendance == 'P') $totalOriginalPresent++;

                                $essl = $EsslData[$dateKey] ?? null;
                                if($essl){
                                    $InTimeData[$dateKey]  = $essl->in_time ? date("h:i A", strtotime($essl->in_time)) : '';
                                    $OutTimeData[$dateKey] = $essl->out_time ? date("h:i A", strtotime($essl->out_time)) : '';
                                    $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                                    $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                                }else{
                                    $InTimeData[$dateKey]  = '';
                                    $OutTimeData[$dateKey] = '';
                                    $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                                    $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                                }
                        }else{
                            $attendance = 'WK';
                            $InTimeData[$dateKey]  = '';
                            $OutTimeData[$dateKey] = '';
                             $leaveTypeData[$dateKey] = null;
                             $CheckInTimeData[$dateKey] = '';
                            $CheckOutTimeData[$dateKey] = '';
                        }

                        $attendanceData[$dateKey] = $attendance;
                        continue;
                    }

                }

                // Working day
                $dayCount++;

                // Attendance exists
                if($record){
                    $attendance = $record->attendance;
                     $leaveType = $record->leave_type ?? null; 
                    $leaveTypeData[$dateKey] = $leaveType;
                    $essl = $EsslData[$dateKey] ?? null;
                    if($essl){
                        $InTimeData[$dateKey]  = $essl->in_time ? date("h:i A", strtotime($essl->in_time)) : '';
                        $OutTimeData[$dateKey] = $essl->out_time ? date("h:i A", strtotime($essl->out_time)) : '';
                        $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                        $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                    }else{
                        $InTimeData[$dateKey]  = '';
                        $OutTimeData[$dateKey] = '';
                        $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                        $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                    }
                }elseif($holidayDates->contains($dateKey)){
                    $attendance = 'HD';
                    $InTimeData[$dateKey]  = '';
                    $OutTimeData[$dateKey] = '';
                    $leaveTypeData[$dateKey] = null;
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';
                }else{
                    $attendance = '-';
                    $InTimeData[$dateKey]  = '';
                    $OutTimeData[$dateKey] = '';
                    $leaveTypeData[$dateKey] = null;
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';
                }

                $attendanceData[$dateKey] = $attendance;

                // Count stats
                if(in_array($attendance,['P','PR','HD','OD'])) $totalPresent++;
                if($attendance == 'P') $totalOriginalPresent++;
                if($attendance == 'P') $PresentCount++;
                if($attendance == 'OD') $totalOD++;
                if($attendance == 'PR') $totalPR++;
                if($attendance == 'A') $totalAbsent++;
                if($attendance == 'L') $totalLeave++;

                // ESSL
                // $essl = $EsslData->where('attendance_date',$dateKey)->first();
                $essl = $EsslData[$dateKey] ?? null;
                if($essl){
                    $InTimeData[$dateKey]  = $essl->in_time ? date("h:i A", strtotime($essl->in_time)) : '';
                    $OutTimeData[$dateKey] = $essl->out_time ? date("h:i A", strtotime($essl->out_time)) : '';

                }else{
                    $InTimeData[$dateKey]  = '';
                    $OutTimeData[$dateKey] = '';
                }
                
            }
            
            $overAllPercent +=$PresentCount;
            $overAllOD +=$totalOD;
            $overAllPR +=$totalPR;
            $overAllAbsent +=$totalAbsent;
            $overAllLeave +=$totalLeave;
            
            return [
                'staff_id' => $row->staff_id,
                'staff_name' => $row->staff_name,
                'nick_name' => $row->nick_name,
                'department_name' => $row->department_name,
                'gender' => $row->gender,
                'staff_image' => $row->staff_image,
                'company_id' => $row->company_id,
                'company_type' => $row->company_type,
                'entity_id' => $row->entity_id,
                'employee_id' => $row->employee_id,

                'attendance' => $attendanceData,
                'leave_type' => $leaveTypeData,
                'in_time' => $InTimeData,
                'shift_data' => $shiftData,
                'out_time' => $OutTimeData,
                'check_in_time' => $CheckInTimeData,
                'check_out_time' => $CheckOutTimeData,
                'dayCount' => $dayCount,
                'totalPresent' => $totalPresent,
                'totalOriginalPresent' => $totalOriginalPresent,
                'totalOD' => $totalOD,
                'totalPR' => $totalPR,
                'totalAbsent' => $totalAbsent,
                'totalLeave' => $totalLeave,
            ];
        });

        $overAllCount = $overAllPercent + $overAllAbsent +$overAllLeave + $overAllPR + $overAllOD ;

        $overAllPercentPercent =$overAllCount > 0 ? ($overAllPercent/$overAllCount)*100 :0;
        $overAllPercentPercent = $overAllPercentPercent >= 100 ? 100 : round($overAllPercentPercent,1);
        
        $overAllAbsentPercent =$overAllCount > 0 ? ($overAllAbsent/$overAllCount)*100 :0;
        $overAllAbsentPercent = $overAllAbsentPercent >= 100 ? 100 : round($overAllAbsentPercent,1);
        
        $overAllLeavePercentage =$overAllCount > 0 ? ($overAllLeave/$overAllCount)*100 :0;
        $overAllLeavePercentage = $overAllLeavePercentage >= 100 ? 100 : round($overAllLeavePercentage,1);
        
        $overAllPermPercent =$overAllCount > 0 ? ($overAllPR/$overAllCount)*100 :0;
        $overAllPermPercent = $overAllPermPercent >= 100 ? 100 : round($overAllPermPercent,1);
        
        $overAllODPercentage =$overAllCount > 0 ? ($overAllOD/$overAllCount)*100 :0;
        $overAllODPercentage = $overAllODPercentage >= 100 ? 100 : round($overAllODPercentage,1);
        

        return response()->json([
            'data' => $data,
            'totalPresentCount' => $totalPresentCount,
            'totalAttendanceRecords' => $totalAttendanceRecords,
            'totalPresentPercentage' => round($totalPresentPercentage,1),
            'totalODPercentage' => round($totalODPercentage,1),
            'totalLeavePercentage' => round($totalLeavePercentage,1),
            'totalAbsentPercentage' => round($totalAbsentPercentage,1),
            'totalPRMPercentage' => round($totalPRMPercentage,1),
            'dates' => array_map(fn($d)=>$d->format('Y-m-d'), $dates),
            'current_page' => $staffs->currentPage(),
            'last_page' => $staffs->lastPage(),
            'total' => $staffs->total(),
            'month' => $month,
            'monthName' => $monthName,
            'year' => $year,
            'entity_names' => $entity_names,
            'entity_colors' => $entity_colors ,
            'dayCount'=>$dayCount,
            'overAllPercent'=>$overAllPercent,
            'overAllPercentPercent'=>$overAllPercentPercent,
            'overAllODPercentage'=>$overAllODPercentage,
            'overAllLeavePercentage'=>$overAllLeavePercentage,
            'overAllPermPercent'=>$overAllPermPercent,
            'overAllAbsentPercent'=>$overAllAbsentPercent,
            'total_staff_count'=>$total_staff_count,
            'base_color_name'=>$base_color_name,
            'entity_short_name'=>$Entity_short_name,
            'entity_name'=>$Entity_name,
            'company_staff_count'=>$company_staff_count,
        ]);
    }

    $leave_reason_list = DB::table('egc_leave_reason')->where('status', 0)->get();
    $permission_reason_list = DB::table('egc_permission_reason')->where('status', 0)->get();
    $onduty_reason_list = DB::table('egc_onduty_reason')->where('status', 0)->get();
  
    return view('content.hr_management.hr_enroll.manage_attendance.manage_attendance',[
        'staffs' => $staffs,
        'company_list' => $company_list,
        'dates' => $dates,
        'month' => $month,
        'monthName' => $monthName,
        'year' => $year,
        'month_filter' => $month_filter,
        'company_fill' => $company_fill,
        'entity_names' => $entity_names,
        'entity_colors' => $entity_colors ,
        'leave_reason_list' => $leave_reason_list,
        'permission_reason_list' => $permission_reason_list,
        'onduty_reason_list' => $onduty_reason_list,
        'perpage' => $perpage
    ]);
}

public function index(Request $request)
{
    $page = $request->input('page', 1);
    $perpage = (int) ($request->sorting_filter ?? 100);

    $company_fill = $request->company_fill ?? 'egc';
    $entity_fill = $request->entity_fill ?? '0';
    $search_filter = $request->search_filter ?? '';

    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

    // ------------------ MONTH PARSING ------------------
    $month_filter = $request->get('month_filter', date('M-Y'));
    // return  $month_filter;
    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
    // $month_filter = $request->get('month_filter', date('m-Y'));  // Default to numeric month (11-2025)
    // $parsedDate = Carbon::createFromFormat('m-Y', $month_filter);

    $month = $parsedDate->month;
    $year  = $parsedDate->year;

    $startDate = Carbon::create($year, $month, 1)->startOfMonth();
    $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
    $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
    $today = Carbon::today();

    // Limit end date to today if month is current
    if ($today->between($startDate, $endDate)) {
        $endDate = $today;
    }

   

    // ------------------ HOLIDAY RECORDS ------------------
        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('hol_date', [$startDate, $endDate])
                ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->get();

        $holidayDates = collect();

        foreach ($holidays as $hol) {
            $start = Carbon::parse($hol->hol_date);
            $end   = $hol->hol_end_date ? Carbon::parse($hol->hol_end_date) : $start;

            foreach (CarbonPeriod::create($start, $end) as $d) {
                $holidayDates->push($d->format('Y-m-d'));
            }
        }

        $holidayDates = $holidayDates->unique();
        $dayCount = collect(CarbonPeriod::create($startDate, $endDate))->count();
    
    // $dayCount = collect(CarbonPeriod::create($startDate, $endDate))
    //     ->filter(function ($d) use ($holidayDates) {
    //         return $d->dayOfWeek !== Carbon::SUNDAY
    //             && !$holidayDates->contains($d->format('Y-m-d'));
    //     })
    //     ->count();

    $total_staff_count = StaffModel::join('egc_department','egc_department.sno','=','egc_staff.department_id')
                        ->where('egc_staff.status',0)
                        ->where('egc_staff.sno','>',0)
                        ->where(function ($q) use ($month, $year) {
                            $q->whereIn('egc_staff.status', [0, 1]);
                            $q->orWhere(function ($notice) use ($month, $year) {
                                $payrollMonth = sprintf('%04d-%02d', $year, $month);
                                $notice->where('egc_staff.status', 4)
                                    ->whereNotNull('egc_staff.notice_end_date')
                                    ->whereRaw("
                                        ? BETWEEN DATE_FORMAT(egc_staff.date_of_joining,'%Y-%m')
                                        AND DATE_FORMAT(egc_staff.notice_end_date,'%Y-%m')
                                    ", [$payrollMonth]);
                            });
                            $q->orWhere(function ($exit) use ($month, $year) {
                                $payrollMonth = sprintf('%04d-%02d', $year, $month);
                                $exit->whereIn('egc_staff.status',[5,6,7])
                                    ->whereNotNull('egc_staff.staff_last_date')
                                    ->whereNotIn('egc_staff.sno',[211,212,94,77])
                                    ->whereRaw("
                                        ? BETWEEN DATE_FORMAT(egc_staff.date_of_joining,'%Y-%m')
                                        AND DATE_FORMAT(egc_staff.staff_last_date,'%Y-%m')
                                    ", [$payrollMonth]);
                                    // ->whereRaw('DATEDIFF(egc_staff.staff_last_date, egc_staff.date_of_joining) > ?',[3]);
                            });
                            // ->orWhere(function ($special) use ($month, $year) {
                            //     $payrollMonth = sprintf('%04d-%02d', $year, $month);
                            //     $special->whereIn('egc_staff.sno', [211,212,94,77])
                            //         ->whereIn('egc_staff.status', [5, 6, 7])
                            //         ->whereNotNull('egc_staff.staff_last_date')
                            //         ->whereRaw(
                            //             "? BETWEEN DATE_FORMAT(egc_staff.date_of_joining, '%Y-%m')
                            //             AND DATE_FORMAT(DATE_SUB(egc_staff.staff_last_date, INTERVAL 1 MONTH), '%Y-%m')",
                            //             [$payrollMonth]
                            //         );
                            //         // ->whereRaw('DATEDIFF(egc_staff.staff_last_date, egc_staff.date_of_joining) > ?',[3]);
                            // });
                        });
                     $total_staff_count =$total_staff_count->count();

     if ($company_fill !== "" && $company_fill == 'egc') {
        $Entity_name = 'Elysium Groups';
        $Entity_short_name = 'EGC';
        $base_color_name = '#ab2b22';

    } else {

        $EntityData = DB::table('egc_entity')->where('status', 0);

        if ($entity_fill !== "") {
            $EntityData->where('sno', $entity_fill);
        }

        $EntityData = $EntityData->first();

        if ($EntityData) {
            $Entity_name = $EntityData->entity_name;
            $Entity_short_name = $EntityData->entity_short_name;
            $base_color_name = $EntityData->entity_base_color;
        } else {
            $Entity_name = 'Elysium Groups';
            $Entity_short_name = 'EGC';
            $base_color_name = '#ab2b22';
        }
    }

    $endOfMonth = date('Y-m-t', strtotime("$year-$month-01"));
    
    // ------------------ STAFF QUERY ------------------
    $query = StaffModel::select(
        'egc_staff.sno as staff_id',
        'egc_staff.staff_id as employee_id',
        'egc_staff.staff_name',
        'egc_staff.status as staff_status',
        'egc_staff.staff_last_date',
        'egc_staff.notice_start_date',
        'egc_staff.notice_end_date',
        'egc_staff.nick_name',
        'egc_staff.gender',
        'egc_staff.company_type',
        'egc_staff.company_id',
        'egc_staff.entity_id',
        'egc_staff.date_of_joining',
        'egc_staff.staff_image',
        'egc_department.department_name'
    )
    ->join('egc_department','egc_department.sno','=','egc_staff.department_id')
    // ->where('egc_staff.status',0)
    // ->whereDate('egc_staff.date_of_joining', '<=', $endOfMonth)
    //  ->where('egc_staff.sno',122)
    ->where('egc_staff.sno','>',0)
    ->orderBy('egc_staff.date_of_joining','asc')
    ->where(function ($q) use ($month, $year) {
        $q->whereIn('egc_staff.status', [0, 1]);
        $q->orWhere(function ($notice) use ($month, $year) {
            $payrollMonth = sprintf('%04d-%02d', $year, $month);
            $notice->where('egc_staff.status', 4)
                ->whereNotNull('egc_staff.notice_end_date')
                ->whereRaw("
                    ? BETWEEN DATE_FORMAT(egc_staff.date_of_joining,'%Y-%m')
                    AND DATE_FORMAT(egc_staff.notice_end_date,'%Y-%m')
                ", [$payrollMonth]);
        });
        $q->orWhere(function ($exit) use ($month, $year) {
            $payrollMonth = sprintf('%04d-%02d', $year, $month);
            $exit->whereIn('egc_staff.status',[5,6,7])
                ->whereNotNull('egc_staff.staff_last_date')
                ->whereNotIn('egc_staff.sno',[211,212,94,77])
                ->whereRaw("
                    ? BETWEEN DATE_FORMAT(egc_staff.date_of_joining,'%Y-%m')
                    AND DATE_FORMAT(egc_staff.staff_last_date,'%Y-%m')
                ", [$payrollMonth]);
                // ->whereRaw('DATEDIFF(egc_staff.staff_last_date, egc_staff.date_of_joining) > ?',[3]);
        });
        // ->orWhere(function ($special) use ($month, $year) {
        //     $payrollMonth = sprintf('%04d-%02d', $year, $month);
        //     $special->whereIn('egc_staff.sno', [211,212,94,77])
        //         ->whereIn('egc_staff.status', [5, 6, 7])
        //         ->whereNotNull('egc_staff.staff_last_date')
        //         ->whereRaw(
        //             "? BETWEEN DATE_FORMAT(egc_staff.date_of_joining, '%Y-%m')
        //             AND DATE_FORMAT(DATE_SUB(egc_staff.staff_last_date, INTERVAL 1 MONTH), '%Y-%m')",
        //             [$payrollMonth]
        //         );
        //         // ->whereRaw('DATEDIFF(egc_staff.staff_last_date, egc_staff.date_of_joining) > ?',[3]);
        // });
    });


    if ($search_filter != '') {
            $query->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.staff_id', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%");
                    
            });
        }

    if($company_fill !== ""){
        if($company_fill == 'egc'){
            $query->where('egc_staff.company_type',1);
        } else {
            if($entity_fill !== ""){
                $query->where('egc_staff.entity_id', $entity_fill);
            }
        }
    }

 
    $total_staff= $query->count();

    // paginated for ajax
    $staffs = $query->paginate($perpage);

    $company_staff_count =$total_staff;

    $allStaffIds = $staffs->pluck('staff_id');

     $allShiftLogs = DB::table('egc_shift_time_log as stl')
        ->join('egc_shift_day_times as sdt', 'stl.change_shift_id', '=', 'sdt.shift_id')
        ->whereIn('stl.staff_id', $allStaffIds)
        ->whereNull('stl.end_date') // current active shift log
        ->where('sdt.status', 0)
        ->select('stl.staff_id', 'sdt.day_name', 'sdt.time_from', 'sdt.time_to')
        ->get()
        ->groupBy('staff_id');

    $totalWorkingDays = 0;

    foreach($staffs as $staff){

        $staffShiftLogs = $allShiftLogs[$staff->staff_id] ?? collect();

        foreach($dates as $d){

            if($d->gt(Carbon::today())) continue;

            $dayName = strtolower($d->format('D'));

             $shift = $staffShiftLogs->where('day_name', $dayName)->first();

            if($shift){

                $dateKey = $d->format('Y-m-d');

                if(!$holidayDates->contains($dateKey)){
                    $totalWorkingDays++;
                }

            }

        }

    }

    $dayCount = $total_staff > 0 ? $totalWorkingDays / $total_staff : 0;

    // ------------------ ATTENDANCE RECORDS ------------------
    $attendanceRecords = StaffAttendanceModel::select('egc_staff_attendance.staff_id','egc_staff_attendance.date','egc_staff_attendance.attendance','egc_staff_attendance.leave_type','egc_staff_attendance.status','egc_staff_attendance.reason','egc_staff_attendance.time_start','egc_staff_attendance.time_end','egc_staff_attendance.check_in_time','egc_staff_attendance.check_out_time')
       ->join('egc_staff','egc_staff.sno','=','egc_staff_attendance.staff_id')
    //    ->where('egc_staff.status',0)
        ->where('egc_staff.sno','>',0)
        ->whereBetween('egc_staff_attendance.date', [$startDate, $endDate]);
        if($company_fill !== ""){
            if($company_fill == 'egc'){
                $attendanceRecords->where('egc_staff.company_type',1);
            } else {
                if($entity_fill !== ""){
                    $attendanceRecords->where('egc_staff.entity_id', $entity_fill);
                }
            }
        }

        $attendanceRecords=$attendanceRecords->get()->groupBy('staff_id');

        $attendanceRecords = $attendanceRecords->map(function($items){
            return $items->keyBy('date');
        });

        $totalAttendanceRecords = $attendanceRecords->flatMap(function($records) {
            return $records->where('status', 0); // Filter out other attendance types
        })->count();

        $totalPresentCount = $attendanceRecords->flatMap(function($records) {
            return $records->whereIn('attendance', ['P','HD']); // Filter out other attendance types
        })->count();

        $totalAbsentCount = $attendanceRecords->flatMap(function($records) {
            return $records->where('attendance', 'A'); // Filter out other attendance types
        })->count();

        $totalLeaveCount = $attendanceRecords->flatMap(function($records) {
            return $records->where('attendance', 'L'); // Filter out other attendance types
        })->count();

        $totalPRMCount = $attendanceRecords->flatMap(function($records) {
            return $records->where('attendance', 'PR'); // Filter out other attendance types
        })->count();

        $totalODCount = $attendanceRecords->flatMap(function($records) {
            return $records->where('attendance', 'OD'); // Filter out other attendance types
        })->count();
        
        
        $AvgTotalPresent=$total_staff > 0 ? $totalPresentCount/$total_staff : 0;
        $totalPresentPercentage =$dayCount > 0 ? ($AvgTotalPresent/$dayCount)*100 :0;
        $totalPresentPercentage = $totalPresentPercentage >= 100 ? 100 : round($totalPresentPercentage,1);
        $totalPresentPercentage = $totalPresentPercentage <= 0 ?'00' : round($totalPresentPercentage,1);

        $AvgTotalAbsent=$total_staff > 0 ? $totalAbsentCount/$total_staff : 0;
        $totalAbsentPercentage =$dayCount > 0 ? ($AvgTotalAbsent/$dayCount)*100 :0;
        $totalAbsentPercentage = $totalAbsentPercentage >= 100 ? 100 : round($totalAbsentPercentage,1);
        $totalAbsentPercentage = $totalAbsentPercentage <= 0 ?'00' : round($totalAbsentPercentage,1);

        $AvgTotalLeave=$total_staff > 0 ? $totalLeaveCount/$total_staff : 0;
        $totalLeavePercentage =$dayCount > 0 ? ($AvgTotalLeave/$dayCount)*100 :0;
        $totalLeavePercentage = $totalLeavePercentage >= 100 ? 100 : round($totalLeavePercentage,1);
        $totalLeavePercentage = $totalLeavePercentage <= 0 ?'00' : round($totalLeavePercentage,1);

        $AvgTotalPRM=$total_staff > 0 ? $totalPRMCount/$total_staff : 0;
        $totalPRMPercentage =$dayCount > 0 ? ($AvgTotalPRM/$dayCount)*100 :0;
        $totalPRMPercentage = $totalPRMPercentage >= 100 ? 100 : round($totalPRMPercentage,1);
        $totalPRMPercentage = $totalPRMPercentage <= 0 ?'00' : round($totalPRMPercentage,1);

        $AvgTotalOD=$total_staff > 0 ? $totalODCount/$total_staff : 0;
        $totalODPercentage =$dayCount > 0 ? ($AvgTotalOD/$dayCount)*100 :0;
        $totalODPercentage = $totalODPercentage >= 100 ? 100 : round($totalODPercentage,1);
        $totalODPercentage = $totalODPercentage <= 0 ?'00' : round($totalODPercentage,1);

        // $EsslData = $helper->get_staff_essl('EGC03075') ?? collect();
        // return $EsslData;

         // ------------------ NORMAL (NON-AJAX) VIEW ------------------
    $company_list = CompanyModel::where('status',0)->get();
    $entity_names = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('entity_name')->prepend('Elysium Groups');
    $entity_colors = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('entity_base_color')->prepend('#ab2b22');
    $entity_ids = ManageEntityModel::where('status',0)->orderBy('sno','asc')->pluck('sno')->prepend('0');

   
    $monthName=Carbon::parse($month_filter)->format('F');
    $staffIds = $staffs->pluck('staff_id');

    // $shiftTimes = DB::table('egc_staff as s')
    //     ->join('egc_shift_day_times as sd', 'sd.shift_id','=','s.shift_time_id')
    //     ->whereIn('s.sno',$staffIds)
    //     ->where('sd.status',0)
    //     ->select(
    //         's.sno as staff_id',
    //         'sd.day_name',
    //         'sd.time_from',
    //         'sd.time_to'
    //     )
    //     ->get()
    //     ->groupBy('staff_id');

        $shiftTimes = DB::table('egc_shift_time_log as stl')
            ->join('egc_shift_day_times as sdt', 'stl.change_shift_id', '=', 'sdt.shift_id')
            ->whereIn('stl.staff_id', $staffIds)
            ->where('sdt.status', 0)
            ->select(
                'stl.staff_id',
                'stl.start_date',
                'stl.end_date',
                'sdt.day_name',
                'sdt.time_from',
                'sdt.time_to'
            )
            ->orderBy('stl.start_date')
            ->get()
            ->groupBy('staff_id');

        $esslRecords = DB::table('egc_staff_essl')
            ->whereBetween('date',[$startDate,$endDate])
            ->whereIn('employee_id',$staffs->pluck('employee_id'))
            ->get()
            ->groupBy('employee_id');

            $esslRecords = $esslRecords->map(function($items){
                return $items->keyBy('date');
            });
        
    // ------------------ AJAX RESPONSE ------------------
    if ($request->ajax()) {
        $overAllPercent=0;
        $overAllAbsent=0;
        $overAllLeave=0;
        $overAllPR=0;
        $overAllOD=0;

        $data = $staffs->map(function($row) use ($dates, $attendanceRecords, $holidayDates,$shiftTimes,$esslRecords,&$overAllPercent,&$overAllAbsent,&$overAllLeave,&$overAllPR,&$overAllOD){

            $attendanceData = [];
            $leaveTypeData = [];
            $reasonData = [];
            $timeStartData = [];
            $timeEndData = [];
            $shiftData = [];
            $InTimeData  = [];
            $OutTimeData = [];
            $CheckInTimeData  = [];
            $CheckOutTimeData = [];
            $totalPresent = 0; 
            $totalOriginalPresent = 0; 
            $totalAbsent = 0; 
            $PresentCount = 0; 
            $totalLeave = 0; 
            $totalOD = 0; 
            $totalPR = 0; 
            // $EsslData = $helper->get_staff_essl($row->employee_id) ?? collect();
            $EsslData = $esslRecords[$row->employee_id] ?? collect();
            
            $dayCount = 0;

           
            
            foreach($dates as $d){
                $dateKey = $d->format('Y-m-d');
        
                if($holidayDates->contains($dateKey)){
                    $attendanceData[$dateKey] = 'HD';
                    $InTimeData[$dateKey] = '';
                    $OutTimeData[$dateKey] = '';
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';
                    continue;
                }
                
                // Skip future dates
                if($d->gt(Carbon::today())){
                    $attendanceData[$dateKey] = '-';
                    $InTimeData[$dateKey] = '';
                    $OutTimeData[$dateKey] = '';
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';
                    continue;
                }

                // Skip before joining date
                if($row->date_of_joining && $dateKey < $row->date_of_joining){
                    $attendanceData[$dateKey] = '-';
                    $InTimeData[$dateKey] = '';
                    $OutTimeData[$dateKey] = '';
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';
                    continue;
                }

                // $record = optional(
                //     $attendanceRecords[$row->staff_id] ?? collect()
                // )->where('date',$dateKey)->first();
                $record = $attendanceRecords[$row->staff_id][$dateKey] ?? null;

                $leaveType = $record->leave_type ?? null;
                $leaveTypeData[$dateKey] = $leaveType;

                $reason = $record->reason ?? null;
                $reasonData[$dateKey] = $reason;

                $timeStart = $record->time_start ?? null;
                $timeStartData[$dateKey] = $timeStart;

                $timeEnd = $record->time_end ?? null;
                $timeEndData[$dateKey] = $timeEnd;

                // Get shift for that day
                // $dayName = strtolower(Carbon::parse($dateKey)->format('D'));
                $dayName = strtolower($d->format('D'));
                $staffShift = $shiftTimes[$row->staff_id] ?? collect();

                $hasShiftConfig = $staffShift->count() > 0;

                // $shift = $staffShift
                //             ->where('day_name',$dayName)
                //             ->first();
                $shift = $staffShift
                    ->filter(function($s) use ($dateKey,$dayName){

                        $start = $s->start_date;
                        $end   = $s->end_date ?? '9999-12-31';

                        return $dateKey >= $start 
                            && $dateKey <= $end
                            && $s->day_name == $dayName;

                    })
                    ->first();

                $shiftData[$dateKey] = $shift;

               

                // If no shift → Weekoff
                if($hasShiftConfig){

                    if(!$shift){

                        if($record){
                            $rawAttendance = $record->attendance;
                            if(in_array($rawAttendance, ['P','OD','PR'])){
                                $attendance = $rawAttendance; // allow working on weekoff
                            } else {
                                $attendance = 'WK'; // everything else becomes weekoff
                            }
                            // $attendance = $record->attendance;
                            $leaveType = $record->leave_type ?? null; 
                            $leaveTypeData[$dateKey] = $leaveType;

                            $reason = $record->reason ?? null; 
                            $reasonData[$dateKey] = $reason;

                            $timeStart = $record->time_start ?? null; 
                            $timeStartData[$dateKey] = $timeStart;

                            $timeEnd = $record->time_end ?? null; 
                            $timeEndData[$dateKey] = $timeEnd;

                            if($attendance == 'P') $totalOriginalPresent++;
                            $essl = $EsslData[$dateKey] ?? null;
                            if($essl){
                                $InTimeData[$dateKey]  = $essl->in_time ? date("h:i A", strtotime($essl->in_time)) : '';
                                $OutTimeData[$dateKey] = $essl->out_time ? date("h:i A", strtotime($essl->out_time)) : '';
                                $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                                $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                            }else{
                                $InTimeData[$dateKey]  = '';
                                $OutTimeData[$dateKey] = '';
                                $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                                $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                            }
                        }else{
                            $attendance = 'WK';
                            $InTimeData[$dateKey]  = '';
                            $OutTimeData[$dateKey] = '';
                            $leaveTypeData[$dateKey] = null;
                            $CheckInTimeData[$dateKey] = '';
                            $CheckOutTimeData[$dateKey] = '';

                            $reasonData[$dateKey] = null;
                            $timeStartData[$dateKey] = null;
                            $timeEndeData[$dateKey] = null;
                        }

                        $attendanceData[$dateKey] = $attendance;
                        continue;
                    }

                }else{

                    // No shift config → Sunday weekoff
                    if($d->dayOfWeek === Carbon::SUNDAY){

                        if($record){
                            $attendance = $record->attendance;
                                $leaveType = $record->leave_type ?? null; 
                                $leaveTypeData[$dateKey] = $leaveType;

                                $reason = $record->reason ?? null; 
                                $reasonData[$dateKey] = $reason;

                                $timeStart = $record->time_start ?? null; 
                                $timeStartData[$dateKey] = $timeStart;

                                $timeEnd = $record->time_end ?? null; 
                                $timeEndData[$dateKey] = $timeEnd;

                             if($attendance == 'P') $totalOriginalPresent++;

                                $essl = $EsslData[$dateKey] ?? null;
                                if($essl){
                                    $InTimeData[$dateKey]  = $essl->in_time ? date("h:i A", strtotime($essl->in_time)) : '';
                                    $OutTimeData[$dateKey] = $essl->out_time ? date("h:i A", strtotime($essl->out_time)) : '';
                                    $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                                    $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                                }else{
                                    $InTimeData[$dateKey]  = '';
                                    $OutTimeData[$dateKey] = '';
                                    $CheckInTimeData[$dateKey] = '';
                                    $CheckOutTimeData[$dateKey] = '';
                                }
                        }else{
                            $attendance = 'WK';
                            $InTimeData[$dateKey]  = '';
                            $OutTimeData[$dateKey] = '';
                            $leaveTypeData[$dateKey] = null;
                            $CheckInTimeData[$dateKey] = '';
                            $CheckOutTimeData[$dateKey] = '';

                            $reasonData[$dateKey] = null;
                            $timeStartData[$dateKey] = null;
                            $timeEndeData[$dateKey] = null;

                        }

                        $attendanceData[$dateKey] = $attendance;
                        continue;
                    }

                }

                // Working day
                $dayCount++;

                // Attendance exists
                if($record){
                    $attendance = $record->attendance;
                     $leaveType = $record->leave_type ?? null; 
                    $leaveTypeData[$dateKey] = $leaveType;

                    $reason = $record->reason ?? null; 
                    $reasonData[$dateKey] = $reason;

                    $timeStart = $record->time_start ?? null; 
                    $timeStartData[$dateKey] = $timeStart;

                    $timeEnd = $record->time_end ?? null; 
                    $timeEndData[$dateKey] = $timeEnd;

                    $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                    $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';

                    $essl = $EsslData[$dateKey] ?? null;

                    if($essl){
                        $InTimeData[$dateKey]  = $essl->in_time ? date("h:i A", strtotime($essl->in_time)) : '';
                        $OutTimeData[$dateKey] = $essl->out_time ? date("h:i A", strtotime($essl->out_time)) : '';
                        $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                        $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                    }else{
                        $InTimeData[$dateKey]  = '';
                        $OutTimeData[$dateKey] = '';
                        $CheckInTimeData[$dateKey]  = $record->check_in_time  ? date("h:i A", strtotime($record->check_in_time)) : '';
                        $CheckOutTimeData[$dateKey] = $record->check_out_time  ? date("h:i A", strtotime($record->check_out_time )) : '';
                    }
                }elseif($holidayDates->contains($dateKey)){
                    $attendance = 'HD';
                    $InTimeData[$dateKey]  = '';
                    $OutTimeData[$dateKey] = '';
                    $leaveTypeData[$dateKey] = null;
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';

                    $reasonData[$dateKey] = null;
                    $timeStartData[$dateKey] = null;
                    $timeEndeData[$dateKey] = null;
                }else{
                    $attendance = '-';
                    $InTimeData[$dateKey]  = '';
                    $OutTimeData[$dateKey] = '';
                    $leaveTypeData[$dateKey] = null;
                    $CheckInTimeData[$dateKey] = '';
                    $CheckOutTimeData[$dateKey] = '';

                    $reasonData[$dateKey] = null;
                    $timeStartData[$dateKey] = null;
                    $timeEndeData[$dateKey] = null;
                }

                $attendanceData[$dateKey] = $attendance;

                // Count stats
                // if(in_array($attendance,['P','PR','HD','OD'])) $totalPresent++;
                if(in_array($attendance,['P','PR','HD','OD'])){
                    $totalPresent += 1;
                }
                if($attendance == 'P'){
                    $totalOriginalPresent += 1;
                    $PresentCount += 1;
                }

                // if($attendance == 'P') $totalOriginalPresent++;
                // if($attendance == 'P') $PresentCount++;
                if($attendance == 'OD') $totalOD++;
                if($attendance == 'PR') $totalPR++;
                if($attendance == 'A') $totalAbsent++;
                // if($attendance == 'L') $totalLeave++;
                if($attendance == 'L'){
                    if($leaveType == 'first_half' || $leaveType == 'second_half'){
                        // Half leave
                        $totalLeave += 0.5;
                        $totalPresent += 0.5;   // 👈 important
                        $totalOriginalPresent += 0.5;   // 👈 important
                        $PresentCount += 0.5;   // 👈 for percentage
                    }else{
                        // Full leave
                        $totalLeave += 1;
                    }
                }

                // ESSL
                // $essl = $EsslData->where('attendance_date',$dateKey)->first();
                $essl = $EsslData[$dateKey] ?? null;
                if($essl){
                    $InTimeData[$dateKey]  = $essl->in_time ? date("h:i A", strtotime($essl->in_time)) : '';
                    $OutTimeData[$dateKey] = $essl->out_time ? date("h:i A", strtotime($essl->out_time)) : '';
                }else{
                    $InTimeData[$dateKey]  = '';
                    $OutTimeData[$dateKey] = '';
                }
            }
            
            $overAllPercent +=$PresentCount;
            $overAllOD +=$totalOD;
            $overAllPR +=$totalPR;
            $overAllAbsent +=$totalAbsent;
            $overAllLeave +=$totalLeave;
            
            return [
                'staff_id' => $row->staff_id,
                'staff_name' => $row->staff_name,
                'nick_name' => $row->nick_name,
                'department_name' => $row->department_name,
                'gender' => $row->gender,
                'staff_image' => $row->staff_image,
                'company_id' => $row->company_id,
                'company_type' => $row->company_type,
                'entity_id' => $row->entity_id,
                'employee_id' => $row->employee_id,

                'attendance' => $attendanceData,
                'leave_type' => $leaveTypeData,
                'reason_data' => $reasonData,
                'start_time' => $timeStartData,
                'end_time' => $timeEndData,
                'check_in_time' => $CheckInTimeData,
                'check_out_time' => $CheckOutTimeData,
                'in_time' => $InTimeData,
                'shift_data' => $shiftData,
                'out_time' => $OutTimeData,
                'dayCount' => $dayCount,
                'totalPresent' => $totalPresent,
                'totalOriginalPresent' => $totalOriginalPresent,
                'totalOD' => $totalOD,
                'totalPR' => $totalPR,
                'totalAbsent' => $totalAbsent,
                'totalLeave' => $totalLeave,
            ];
        });

        $overAllCount = $overAllPercent + $overAllAbsent +$overAllLeave + $overAllPR + $overAllOD ;

        $overAllPercentPercent =$overAllCount > 0 ? ($overAllPercent/$overAllCount)*100 :0;
        $overAllPercentPercent = $overAllPercentPercent >= 100 ? 100 : round($overAllPercentPercent,1);
        
        $overAllAbsentPercent =$overAllCount > 0 ? ($overAllAbsent/$overAllCount)*100 :0;
        $overAllAbsentPercent = $overAllAbsentPercent >= 100 ? 100 : round($overAllAbsentPercent,1);
        
        $overAllLeavePercentage =$overAllCount > 0 ? ($overAllLeave/$overAllCount)*100 :0;
        $overAllLeavePercentage = $overAllLeavePercentage >= 100 ? 100 : round($overAllLeavePercentage,1);
        
        $overAllPermPercent =$overAllCount > 0 ? ($overAllPR/$overAllCount)*100 :0;
        $overAllPermPercent = $overAllPermPercent >= 100 ? 100 : round($overAllPermPercent,1);
        
        $overAllODPercentage =$overAllCount > 0 ? ($overAllOD/$overAllCount)*100 :0;
        $overAllODPercentage = $overAllODPercentage >= 100 ? 100 : round($overAllODPercentage,1);
        

        return response()->json([
            'data' => $data,
            'totalPresentCount' => $totalPresentCount,
            'totalAttendanceRecords' => $totalAttendanceRecords,
            'totalPresentPercentage' => round($totalPresentPercentage,1),
            'totalODPercentage' => round($totalODPercentage,1),
            'totalLeavePercentage' => round($totalLeavePercentage,1),
            'totalAbsentPercentage' => round($totalAbsentPercentage,1),
            'totalPRMPercentage' => round($totalPRMPercentage,1),
            'dates' => array_map(fn($d)=>$d->format('Y-m-d'), $dates),
            'current_page' => $staffs->currentPage(),
            'last_page' => $staffs->lastPage(),
            'total' => $staffs->total(),
            'month' => $month,
            'monthName' => $monthName,
            'year' => $year,
            'entity_names' => $entity_names,
            'entity_colors' => $entity_colors ,
            'dayCount'=>$dayCount,
            'overAllPercent'=>$overAllPercent,
            'overAllPercentPercent'=>$overAllPercentPercent,
            'overAllODPercentage'=>$overAllODPercentage,
            'overAllLeavePercentage'=>$overAllLeavePercentage,
            'overAllPermPercent'=>$overAllPermPercent,
            'overAllAbsentPercent'=>$overAllAbsentPercent,
            'total_staff_count'=>$total_staff_count,
            'base_color_name'=>$base_color_name,
            'entity_short_name'=>$Entity_short_name,
            'entity_name'=>$Entity_name,
            'company_staff_count'=>$company_staff_count,
        ]);
    }

   $leave_reason_list = DB::table('egc_leave_reason')->where('status', 0)->get();
    $permission_reason_list = DB::table('egc_permission_reason')->where('status', 0)->get();
    $onduty_reason_list = DB::table('egc_onduty_reason')->where('status', 0)->get();
  
    return view('content.hr_management.hr_enroll.manage_attendance.manage_attendance',[
        'staffs' => $staffs,
        'company_list' => $company_list,
        'dates' => $dates,
        'month' => $month,
        'monthName' => $monthName,
        'year' => $year,
        'month_filter' => $month_filter,
        'company_fill' => $company_fill,
        'entity_names' => $entity_names,
        'entity_colors' => $entity_colors ,
         'leave_reason_list' => $leave_reason_list,
        'permission_reason_list' => $permission_reason_list,
        'onduty_reason_list' => $onduty_reason_list,
        'perpage' => $perpage
    ]);
}

public function getStaff(Request $request)
{
    $branchId = $request->user()->branch_id;
    $departmentId = $request->department_id;
    $type = $request->type;
    
    // return $type;
    // $currentDate = now()->format('Y-m-d'); // Get the current date in 'Y-m-d' format
    $currentDate = now()->format('Y-m-d'); // Get the current date in 'Y-m-d' format
    if($type){
        if($type === 'today'){
                $currentDate = now()->format('Y-m-d');
        }elseif ($type === 'tomorrow') {
            $currentDate = now()->modify('+1 day')->format('Y-m-d');
        }elseif ($type === 'custom'){
            $currentDate =  date('Y-m-d', strtotime($request->date));
        }
    }else{
        $currentDate =  date('Y-m-d', strtotime($request->date));
    }
    //   return  $currentDate;
    
    // Get staff members based on branch and department
    $staffQuery = StaffModel::query();
    $staff = $staffQuery
        // ->where('branch_id', $branchId)
        ->where('department_id', $departmentId)
        ->where('status', 0)
        ->where('role_id','>',1)
        ->get(['sno', 'staff_name', 'nick_name']);

    // Get staff IDs who have attendance records for the current date
    $attendanceRecords = StaffAttendanceModel::whereIn('staff_id', $staff->pluck('sno'))
        ->whereDate('date', $currentDate) // Filter by current date
        ->pluck('staff_id'); // Get only the staff IDs

    // Filter out staff members who have attendance records for today and reset keys
    $filteredStaff = $staff->whereNotIn('sno', $attendanceRecords)->values();

    return response()->json(['status' => 200, 'data' => $filteredStaff]);
}

public function Add(Request $request)
{

    
    $request->validate([
        'staff_id' => 'required',
        'entry_select' => 'required',
    ]);

    $branch_id = $request->user()->branch_id;
    $staffIds = $request->input('staff_id', []);
    $attendanceType = $request->input('entry_select');
    $attendanceTypes = ['1' => 'P', '2' => 'A', '3' => 'OD', '4' => 'PR', '5' => 'L', '6' => 'WO'];
    $att = $attendanceTypes[$attendanceType] ?? 'NA';

    if (in_array('all', $staffIds)) {
        $staffIds = StaffModel::where('department_id', $request->department_id)
            ->pluck('sno')
            ->toArray();
    }


    $currentDate =  date('Y-m-d', strtotime($request->date));
    $attendanceDate = '';
    $startTime = null;
    $endTime = null;
    $reason = $request->reason ?? '';

    // OD or PR => With Time
    if (in_array($attendanceType, ['3', '4'])) {
        try {
            $startTime = (new DateTime($request->input('st_time')))->format('H:i:s');
            $endTime = (new DateTime($request->input('end_time')))->format('H:i:s');
            $reason = $request->reason;
        } catch (\Exception $e) {
            return response()->json(['status' => 400, 'message' => 'Invalid time format.']);
        }
        $attendanceDate = now()->format('Y-m-d'); // ← Set date!
    }

    // Tomorrow case
    elseif ($request->input('attendance_type_add') === 'tomorrow') {
        $attendanceDate = now()->modify('+1 day')->format('Y-m-d');
    }

    // Custom range
    elseif ($request->input('attendance_type_add') === 'custom') {
    $attendanceDate=    date('Y-m-d', strtotime($request->input('attendance_date_range_add'))) ;
        // $dates = $request->input('attendance_date_range_add', []);
        // if (is_string($dates)) {
        //     $dates = explode(',', $dates);
        // }

        // foreach ($dates as $date) {
        //     $dateTime = DateTime::createFromFormat('Y-m-d', trim($date));
        //     if (!$dateTime) {
        //         return response()->json(['status' => 400, 'message' => 'Invalid date format: ' . $date]);
        //     }

        //     $formattedDate = $dateTime->format('Y-m-d');
        //     $lastStaffAttendanceId = $this->processAttendanceForDate($request, $staffIds, $att, $formattedDate, $startTime, $endTime, $reason);
        // }

        // $staff_attendance_id = Crypt::encryptString($lastStaffAttendanceId);
        // return response()->json([
        //     'status' => 200,
        //     'message' => 'Attendance marked successfully'
        // ]);
    }

    // P or A => Present or Absent
    elseif (in_array($attendanceType, ['1', '2', '6', '3', '4'])) {
        // $attendanceDate = now()->format('Y-m-d');
        $attendanceDate =  date('Y-m-d', strtotime($request->attend_date));
    }

    // Fallback in case none of above sets date
    if (empty($attendanceDate)) {
        $attendanceDate = now()->format('Y-m-d');
        //   $attendanceDate =  date('Y-m-d', strtotime($request->attend_date));
    }

    $lastStaffAttendanceId = $this->processAttendanceForDate($request, $staffIds, $att, $attendanceDate, $startTime, $endTime, $reason);
    $staff_attendance_id = Crypt::encryptString($lastStaffAttendanceId);

    return response()->json([
        'status' => 200,
        'message' => 'Attendance marked successfully',
        'redirectUrl' => url('/hr_enroll/manage_attendance')
    ]);
}

private function processAttendanceForDate(Request $request, array $staffIds, string $attendanceType, string $attendanceDate, $startTime, $endTime, $reason)
{
    $branchId = $request->user()->branch_id;
    $userId = auth()->user()->user_id;
    $category_checks = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    $year = date("Y");
    $month = date("m");
 

    foreach ($staffIds as $staffId) {
        // Check if attendance already exists for the staff, date, and type
        $alreadyExists = StaffAttendanceModel::where([
            ['staff_id', '=', $staffId],
            ['date', '=', $attendanceDate],
            ['attendance', '=', $attendanceType],
            ['status', '!=', 2], // Exclude soft-deleted or inactive records
        ])->exists();

        if ($alreadyExists) {
            continue; // Skip this staff ID if attendance already exists
        }

        // Generate unique staff attendance ID
        $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $year,$month);
        
        // Save attendance
       $addStaff = StaffAttendanceModel::create([
            'staff_attendance_id' => $staff_attendance_id,
            'branch_id'           => $branchId,
            'staff_id'            => $staffId,
            'date'                => $attendanceDate,
            'attendance'          => $attendanceType,
            'type'                => $request->type_select ?? null,
            'time_start'          => $startTime ?? null,
            'time_end'            => $endTime ?? null,
            'reason'              => $reason ?? null,
            'created_by'          => $userId,
            'updated_by'          => $userId,
        ]);

        if($addStaff){
            $staffData = StaffModel::where('sno', $staffId)
            ->first();
            if($staffData->company_type == 2){
                $payload=[
                    'sno' => $addStaff->sno,
                    'staff_id' => $addStaff->staff_id,
                    'entity_id' => $staffData->entity_id,
                    'date' => $addStaff->date ?? null,
                    'attendance' => $addStaff->attendance ?? null,
                    'type' => $addStaff->type ?? null,
                    'time_start'    => $addStaff->time_start ?? null,
                    'time_end' => $addStaff->time_end ?? null,
                    'reason' =>  $addStaff->reason ?? null,
                    
                ];
                $this->dispatchUpdateWebhooks($payload, 1,'Attendance_Add_Hook');
            }
            
        }

        
    }

    return $staff_attendance_id;
}
private function generateStaffAttendanceId($category_check, $month, $year)
{
    if (!$category_check) {
        return 'ATT0001/' . $month . '/' . $year;
    }

    // Extract the current staff attendance ID (e.g., "ATT0001/11/2025")
    $data = $category_check->staff_attendance_id;
    $slice = explode("/", $data);

    // Extract the numeric part of the attendance ID (e.g., 0001 from "ATT0001")
    $resultcus = preg_replace('/[^0-9]/', '', $slice[0]);
    $next_number = (int)$resultcus + 1;

    // Return the formatted ID (e.g., "ATT0002/11/2025")
    return 'ATT' . sprintf("%04d", $next_number) . '/' . $month . '/' . $year;
}

    public function UploadEssl(Request $request)
    {
         $userId = auth()->user()->user_id;
         $groupedPayload = [];
        try {

            if (!$request->hasFile('file_upload')) {
                return response()->json([
                    'success' => false,
                    'message' => 'No file uploaded.'
                ]);
            }

            $file = $request->file('file_upload');
            $rows = Excel::toArray([], $file)[0];

            $companyName = null;      // <== Actually Department
            $attendanceDate = null;
            $headerFound = false;

            foreach ($rows as $row) {

                // -----------------------------
                // DEPARTMENT = CompanyName
                // -----------------------------
                if (isset($row[1]) && $row[1] === "Department") {
                    $companyName = trim($row[4] ?? null);   // "CMP", "EAPL" etc.
                }

                // -----------------------------
                // Attendance Date
                // -----------------------------
                if (isset($row[1]) && $row[1] === "Attendance Date") {
                    $attendanceDate = Carbon::parse($row[4])->format('Y-m-d');
                }

                // -----------------------------
                // Header row of table
                // -----------------------------
                if (isset($row[1]) && $row[1] === "SNo" && isset($row[2]) && $row[2] === "E. Code") {
                    $headerFound = true;
                    continue;
                }

                // -----------------------------
                // Process employee rows
                // -----------------------------
                if ($headerFound) {

                    // empty row means next block
                    if ($row[2] === null) {
                        $headerFound = false;
                        continue;
                    }

                    // -------- Extract Columns --------
                    $employeeCode  = trim($row[2]);
                    $inTime        = $row[7] ?? null;
                    $outTime       = $row[8] ?? null;
                    $workDuration  = $row[10] ?? null;
                    $otDuration    = $row[11] ?? null;
                    $totalDuration = $row[12] ?? null;
                    $status        = $row[13] ?? null;

                    if (!$employeeCode || !$attendanceDate) {
                        continue;
                    }

                    // ---- Insert / Update ESSL Table ----
                    StaffEsslModel::updateOrCreate(
                        [
                            'employee_id' => $employeeCode,
                            'date'        => $attendanceDate
                        ],
                        [
                            'essl_status'   => $status,
                            'staff_id'      => 0,
                            'ot_duration'   => $otDuration,
                            'in_time'       => $inTime,
                            'out_time'      => $outTime,
                            'company'       => $companyName,     // department
                            'work_duration' => $workDuration,
                            'total_duration'=> $totalDuration,
                            'created_by'    => $userId,
                            'updated_by'    => $userId,
                        ]
                    );

                    // ---- Update Main Attendance ----
                    // $this->UpdateEsslAttendance($employeeCode, $attendanceDate, $status, $request,$inTime,$outTime);
                    $payload = $this->UpdateEsslAttendance(
                        $employeeCode,
                        $attendanceDate,
                        $status,
                        $request,
                        $inTime,
                        $outTime
                    );

                    if ($payload && isset($payload['entity_id'])) {
                        $entityId = $payload['entity_id'];

                        $groupedPayload[$entityId][] = $payload;
                    }
                    
                }
            }

            if (!empty($groupedPayload)) {
                foreach ($groupedPayload as $entityId => $records) {
                    $finalPayload = [
                        'batch_uuid' => (string) \Str::uuid(),
                        'entity_id'  => $entityId,   
                        'records'    => $records,
                    ];
                    $this->dispatchUpdateWebhooksMultiple(
                        $finalPayload,
                        $userId,
                        'Attendance_Add_Hook_ESSL'
                    );
                }
            }

            return response()->json([
                'success' => true,
                'message' => 'Attendance imported successfully!'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => "Error: " . $e->getMessage()
            ]);
        }
    }


    private function UpdateEsslAttendance($employeeId, $date, $status, Request $request, $inTime, $outTime)
    {
        $branchId = $request->user()->branch_id;
        $userId = auth()->user()->user_id;

        // Get staff row from master
        $StaffData = StaffModel::where('staff_id', $employeeId)->first();

        if (!$StaffData) {
            return; // employee not found in master
        }

        $year = date("Y");
        $month = date("m");

        // Check if attendance already exists
        $attendanceRow = StaffAttendanceModel::where([
            ['staff_id', '=', $StaffData->sno],
            ['date', '=', $date],
            ['status', '!=', 2]
        ])->first();

        if ($attendanceRow) {
            // Attendance already exists
            if (in_array($attendanceRow->attendance, ['OD', 'PR', 'L','P'])) {

                $attendanceRow->update([
                    'in_time'   => $inTime,
                    'out_time'  => $outTime,
                    'updated_by'=> $userId,
                ]);
                return [
                    'sno'        => $attendanceRow->sno,
                    'staff_id'   => $attendanceRow->staff_id,
                    'entity_id'  => $StaffData->entity_id,
                    'date'       => $attendanceRow->date,
                    'attendance' => $attendanceRow->attendance,
                    'in_time'    => $attendanceRow->in_time,
                    'out_time'   => $attendanceRow->out_time,
                ];
            } else {
                $staff_attendance_id = $attendanceRow->staff_attendance_id;
            }
        } else {
            // Generate new attendance ID
            $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
            $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $month, $year);
        }

        // Check for Absent or Present status
        $attendanceType = null;

        // Check if the status contains 'Absent'
        if (stripos($status, 'Absent') !== false) {
            $attendanceType = 'A'; // Mark as Absent
        }
        // Check if the status contains 'Present'
        elseif (stripos($status, 'Present') !== false) {
            $attendanceType = 'P'; // Mark as Present
        }else{
            return true;
        }

        // If the attendanceType is not set, skip the save process
        if ($attendanceType === null) {
            return true; // Skip saving if status is neither 'Absent' nor 'Present'
        }

        // Insert/Update attendance record
        $addStaff=StaffAttendanceModel::updateOrCreate(
            [
                'staff_id' => $StaffData->sno,
                'date'     => $date
            ],
            [
                'staff_attendance_id' => $staff_attendance_id,
                'attendance'          => $attendanceType,
                'in_time'          => $inTime,
                'out_time'            => $outTime,
                'updated_by'          => $userId,
                'branch_id'           => $branchId,
            ]
        );

        // if($addStaff){
        //     $staffData = StaffModel::where('sno', $StaffData->sno)
        //     ->first();
        //     // if($staffData->company_type == 2){
        //     //     $payload=[
        //     //         'sno' => $addStaff->sno,
        //     //         'staff_id' => $addStaff->staff_id,
        //     //         'entity_id' => $staffData->entity_id,
        //     //         'date' => $addStaff->date ?? null,
        //     //         'attendance' => $addStaff->attendance ?? null,
        //     //         'type' => $addStaff->type ?? null,
        //     //         'in_time'    => $addStaff->in_time ?? null,
        //     //         'out_time' => $addStaff->out_time ?? null,
        //     //         'reason' =>  $addStaff->reason ?? null,
                    
        //     //     ];
        //     //     $this->dispatchUpdateWebhooks($payload, 1,'Attendance_Add_Hook');
        //     // }
        // }

        if($addStaff){
            $staffData = StaffModel::where('sno', $StaffData->sno)->first();

            if($staffData->company_type == 2){
                return [
                    'sno'        => $addStaff->sno,
                    'staff_id'   => $addStaff->staff_id ?? $staffData->sno,
                    'entity_id'  => $staffData->entity_id,
                    'date'       => $addStaff->date ?? null,
                    'attendance' => $addStaff->attendance ?? null,
                    'type'       => $addStaff->type ?? null,
                    'in_time'    => $addStaff->in_time ?? null,
                    'out_time'   => $addStaff->out_time ?? null,
                    'reason'     => $addStaff->reason ?? null,
                ];
            }
        }

        return null;
    }


    function getStaffAttendanceByDate(Request $request){
        $date =  date('Y-m-d', strtotime($request->date));
        $staff_id = $request->staff_id;

        $attendanceRow = StaffAttendanceModel::where([
            ['staff_id', '=', $staff_id],
            ['date', '=', $date],
            ['status', '!=', 2]
        ])->first();
        $wkoff =false;
        if (date('l', strtotime($date)) === 'Sunday') {
            $wkoff = true;
        }
      return response()->json([
          'status' => 200,
          'wkoff' => $wkoff,
          'data' => $attendanceRow
      ]);
  }

public function Update(Request $request)
{
    // Validate the input fields
    $request->validate([
        'staff_id' => 'required',
        'entry_select' => 'required',
        'attendance_date_edit' => 'required', // Ensure date format is d-m-Y
    ]);

    // Get input data
    $branch_id = $request->user()->branch_id;
    $staffIds = $request->input('staff_id');
    $attendanceType = $request->input('entry_select');
     $is_paid_leave = $request->input('is_paid_leave') ?? 0;
    $attendanceTypes = [
        '1' => 'P',   // Present
        '2' => 'A',   // Absent
        '3' => 'OD',  // On Duty
        '4' => 'PR',  // Permission
        '5' => 'L',   // Leave
        '6' => 'WO',  // Weekly Off
    ];
    $att = $attendanceTypes[$attendanceType] ?? 'NA'; // Default to 'NA' if not found

    // Convert the date format from 'DD-MM-YYYY' to 'YYYY-MM-DD'

    $attendanceDate = date('Y-m-d', strtotime($request->attendance_date_edit));

    $startTime = null;
    $endTime = null;
    
    $leave_type = null;

    if ($attendanceType == '2') {
        $reason_id = $request->leave_reason_edit ?? null;
        $reason = $request->leave_comments_text ?? null;
    } elseif ($attendanceType == '3') {
        $reason_id = $request->onduty_reason_edit ?? null;
        $reason = $request->onduty_comments_text ?? null;
    } elseif ($attendanceType == '4') {
        $reason_id = $request->permission_reason_edit ?? null;
        $reason = $request->permission_comments_text ?? null;
    } elseif ($attendanceType == '5') {
        $reason_id = $request->leave_reason_edit ?? null;
        $reason = $request->leave_comments_text ?? null;
    } else {
        $reason_id =  null;
        $reason = null;
    }

    if ($attendanceType == '5') { // Leave
        $leave_type = $request->leave_type ?? 'full';
    }

    // Handle On Duty (OD) or Permission (PR) with time
    if (in_array($attendanceType, ['3', '4'])) {
        try {
            $startTime = (new DateTime($request->input('st_time')))->format('H:i:s');
            $endTime = (new DateTime($request->input('end_time')))->format('H:i:s');
            
        } catch (\Exception $e) {
            return response()->json(['status' => 400, 'message' => 'Invalid time format.']);
        }
        // Set attendance date to today for OD/PR
        // $attendanceDate = now()->format('Y-m-d');
    }

    // Handle custom range or tomorrow case
    if ($request->input('attendance_type_add') === 'tomorrow') {
        $attendanceDate = now()->modify('+1 day')->format('Y-m-d');
    } elseif ($request->input('attendance_type_add') === 'custom') {
        $attendanceDate = date('Y-m-d', strtotime($request->input('attendance_date_range_add')));
    }

    // Set default date if not set
    if (empty($attendanceDate)) {
        $attendanceDate = now()->format('Y-m-d');
    }

    // Process the attendance
    $lastStaffAttendanceId = $this->processAttendance($request, $staffIds, $att, $attendanceDate, $startTime, $endTime,$reason_id, $reason,$leave_type,$is_paid_leave);

    // Encrypt the staff attendance ID before returning it in the response
    $staff_attendance_id = Crypt::encryptString($lastStaffAttendanceId);

    // Return success response
    return response()->json([
        'status' => 200,
        'message' => 'Attendance marked successfully',
        'redirectUrl' => url('/hr_enroll/manage_attendance'),
    ]);
}

private function processAttendance(Request $request, $staffId, $attendanceType, $attendanceDate, $startTime, $endTime,$reason_id, $reason,$leave_type,$is_paid_leave)
{
    $branchId = $request->user()->branch_id;
    $userId = auth()->user()->user_id;
    $category_checks = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    $year = date("Y");
    $month = date("m");

    // Check if attendance already exists for the staff on this date
    $alreadyExists = StaffAttendanceModel::where([
        ['staff_id', '=', $staffId],
        ['date', '=', $attendanceDate],
        ['status', '!=', 2], // Exclude soft-deleted or inactive records
    ])->first();

    // If attendance already exists, update it
    if ($alreadyExists) {
        $alreadyExists->attendance = $attendanceType;
        $alreadyExists->time_start = $startTime ?? null;
        $alreadyExists->time_end = $endTime ?? null;
        $alreadyExists->reason_id = $reason_id ?? null;
        $alreadyExists->reason = $reason ?? null;
        $alreadyExists->leave_type = $leave_type ?? null;
        $alreadyExists->paid_leave = $attendanceType == 'L' ? ($is_paid_leave ?? 0) : 0;
        $alreadyExists->update();
        if($alreadyExists){
            $staffData = StaffModel::where('sno', $alreadyExists->staff_id)
            ->first();
            if($staffData->company_type == 2){
                $payload=[
                    'sno' => $alreadyExists->sno,
                    'staff_id' => $alreadyExists->staff_id,
                    'entity_id' => $staffData->entity_id,
                    'date' => $alreadyExists->date ?? null,
                    'attendance' => $alreadyExists->attendance ?? null,
                    'type' => $alreadyExists->type ?? null,
                    'time_start'    => $alreadyExists->time_start ?? null,
                    'time_end' => $alreadyExists->time_end ?? null,
                    'reason_id' =>  $alreadyExists->reason_id ?? null,
                    'reason' =>  $alreadyExists->reason ?? null,
                    'leave_type' =>  $alreadyExists->leave_type ?? null,
                    
                ];
                $this->dispatchUpdateWebhooks($payload, 1,'Attendance_Add_Hook');
            }
        }
    } else {
        // Generate a new staff attendance ID
        $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $year, $month);

        // Save new attendance record
       $addStaff= StaffAttendanceModel::create([
            'staff_attendance_id' => $staff_attendance_id,
            'branch_id'           => $branchId,
            'staff_id'            => $staffId,
            'date'                => $attendanceDate,
            'attendance'          => $attendanceType,
            'type'                => $request->type_select ?? null,
            'time_start'          => $startTime ?? null,
            'time_end'            => $endTime ?? null,
            'reason_id'              => $reason_id ?? null,
            'reason'              => $reason ?? null,
            'leave_type'              => $leave_type ?? null,
            'paid_leave'              => $attendanceType == 'L' ? ($is_paid_leave ?? 0) : 0,
            'created_by'          => $userId,
            'updated_by'          => $userId,
        ]);
        if($addStaff){
            $staffData = StaffModel::where('sno', $staffId)
            ->first();
            if($staffData->company_type == 2){
                $payload=[
                    'sno' => $addStaff->sno,
                    'staff_id' => $staffId,
                    'entity_id' => $staffData->entity_id,
                    'date' => $addStaff->date ?? null,
                    'attendance' => $addStaff->attendance ?? null,
                    'type' => $addStaff->type ?? null,
                    'time_start'    => $addStaff->time_start ?? null,
                    'time_end' => $addStaff->time_end ?? null,
                    'reason_id' =>  $addStaff->reason_id ?? null,
                    'reason' =>  $addStaff->reason ?? null,
                    'leave_type' =>  $addStaff->leave_type ?? null,
                    
                ];
                $this->dispatchUpdateWebhooks($payload, 1,'Attendance_Add_Hook');
            }
        }
    }

    // Return the staff ID
    return $staffId;
}

public function getMonthStaffAttendanceById(Request $request)
{
    $staff_id = $request->staff_id;

        $staff = StaffModel::select(
            'egc_staff.*',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name'
        )
        ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
        ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
        ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
        ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
        ->where('egc_staff.sno', $staff_id)
        ->first();
      
        $month_filter = $request->get('month_filter', date('M-Y'));
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);

        $month = $parsedDate->month;
        $year  = $parsedDate->year;
        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
        $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
        $today = Carbon::today();

        // Limit end date to today if month is current
        if ($today->between($startDate, $endDate)) {
            $endDate = $today;
        }

        $dayCount = collect(CarbonPeriod::create($startDate, $endDate))
            ->filter(fn($d) => $d->dayOfWeek !== Carbon::SUNDAY)
            ->count();

        $attendanceRecords = StaffAttendanceModel::select(
            'egc_staff_attendance.staff_id',
            'egc_staff_attendance.date',
            'egc_staff_attendance.attendance',
            'egc_staff_attendance.time_start',
            'egc_staff_attendance.time_end',
            'egc_staff_attendance.leave_type',
            'egc_staff_attendance.reason'
        )
        ->where('egc_staff_attendance.staff_id', $staff_id)
        ->whereYear('egc_staff_attendance.date', $year)
        ->whereMonth('egc_staff_attendance.date', $month)
        ->orderBy('egc_staff_attendance.date', 'desc')
        ->get();
 
         $totalPresentCount = StaffAttendanceModel::select('egc_staff_attendance.sno')
        ->where('egc_staff_attendance.staff_id', $staff_id)
        ->whereYear('egc_staff_attendance.date', $year)
        ->whereMonth('egc_staff_attendance.date', $month)
        ->whereIn('egc_staff_attendance.attendance', ['P','PR','HD'])
        ->orderBy('egc_staff_attendance.date', 'asc')
        ->count();

        $overAllPercentage=0;
  
       $overAllPercentage = $dayCount > 0 ? ($totalPresentCount / $dayCount )*100 : 0;
      
       $overAllPercentage = $overAllPercentage >100 ? 100 :round($overAllPercentage,1);
        
       $overAllPercentage = $overAllPercentage < 0 ? 0 :round($overAllPercentage,1);
       

    $staff->overAllPercentage = $overAllPercentage;
    
    
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    
     
    $EsslData = $helper->get_staff_essl_Month($staff->staff_id, $year, $month) ?? collect();
    foreach ($attendanceRecords as $attend) {
        $rawDateKey = $attend->date;
        $attend->day = date('l', strtotime($attend->date));
        $attend->date = date($common_date_format, strtotime($attend->date));
        $attend->time_start = $attend->time_start ? date("h:i A", strtotime($attend->time_start)) : null;
        $attend->time_end   = $attend->time_end   ? date("h:i A", strtotime($attend->time_end))   : null;
        if (isset($EsslData[$rawDateKey])) {
            $attend->in_time  = $EsslData[$rawDateKey]->in_time ?? null;
            $attend->out_time = $EsslData[$rawDateKey]->out_time ?? null;
        } else {
            $attend->in_time  = null;
            $attend->out_time = null;
        }
    }

    return response()->json([
        'status' => 200,
        'message' => 'Attendance loaded successfully',
        'staff' => $staff,
        'attendance' => $attendanceRecords,
    ]);
}



 protected function dispatchUpdateWebhooks( $broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',$broadcast['entity_id'])->first();
          if($webhook){
              $dispatch = WebhookDispatchModel::create([
                'sub_erp_webhook_sno' => $webhook->sno,
                'dispatchable_type' => 'App\Models\StaffAttendanceModel',
                'dispatchable_id' => $broadcast['sno'],
                'message_uuid' => $broadcast['sno'],
                'payload' => json_encode($broadcast),
                // 'payload' => json_encode($broadcast, JSON_UNESCAPED_UNICODE),
                'status' => 0,
                'attempts' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            // broadcast creation once
            // broadcast(new WebhookDispatchedEvent($dispatch));

            // enqueue the job
            try {
              $result = $this->sendWebhookNow($dispatch, $webhook);
                \Log::info("send result : " . json_encode($result));

                    // if (!$result['success']) {
                    //     // If fails, dispatch to queue
                    //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                    // }
                } catch (\Throwable $e) {
                    // On any exception, fallback to queue
                    SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                    \Log::error("Webhook fallback to queue: " . $e->getMessage());
                }
            
          }
     
  }

//  protected function dispatchUpdateWebhooksMultiple( $broadcast, $userId = 1,$dispatchHook)
//   {
//       $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',$broadcast['entity_id'])->first();
//           if($webhook){
//               $dispatch = WebhookDispatchModel::create([
//                 'sub_erp_webhook_sno' => $webhook->sno,
//                 'dispatchable_type' => 'App\Models\StaffAttendanceModel',
//                 'dispatchable_id' => $broadcast['sno'] ?? null,
//                 'message_uuid' => $broadcast['sno'] ?? null,
//                 // 'payload' => json_encode($broadcast),
//                 'payload' => json_encode($broadcast, JSON_UNESCAPED_UNICODE),
//                 'status' => 0,
//                 'attempts' => 0,
//                 'created_by' => $userId,
//                 'updated_by' => $userId,
//             ]);

//             // broadcast creation once
//             // broadcast(new WebhookDispatchedEvent($dispatch));

//             // enqueue the job
//             try {
//               $result = $this->sendWebhookNow($dispatch, $webhook);
//                 \Log::info("send result : " . json_encode($result));

//                     // if (!$result['success']) {
//                     //     // If fails, dispatch to queue
//                     //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
//                     // }
//                 } catch (\Throwable $e) {
//                     // On any exception, fallback to queue
//                     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
//                     \Log::error("Webhook fallback to queue: " . $e->getMessage());
//                 }
            
//           }
     
//   }


protected function dispatchUpdateWebhooksMultiple($broadcast, $userId = 1, $dispatchHook)
{
    $entityId = $broadcast['entity_id'] ?? null;

    if (!$entityId) {
        \Log::error('Webhook skipped: entity_id missing.');
        return;
    }

    $webhook = SubErpWebhookModel::where('status', 0)
        ->where('webhook_module', $dispatchHook)
        ->where('entity_id', $entityId)
        ->first();

    if (!$webhook) {
        \Log::error("Webhook not found for entity_id: $entityId");
        return;
    }

    $dispatch = WebhookDispatchModel::create([
        'sub_erp_webhook_sno' => $webhook->sno,
        'dispatchable_type'   => 'App\Models\StaffAttendanceModel',
        'dispatchable_id'     => null,
        'message_uuid'        => $broadcast['batch_uuid'],
        'payload'             => json_encode($broadcast, JSON_UNESCAPED_UNICODE),
        'status'              => 0,
        'attempts'            => 0,
        'created_by'          => $userId,
        'updated_by'          => $userId,
    ]);

    try {
        $result = $this->sendWebhookNow($dispatch, $webhook);
        \Log::info("Batch webhook result: " . json_encode($result));
    } catch (\Throwable $e) {
        // SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
        \Log::error("Webhook fallback to queue: " . $e->getMessage());
    }
}

  protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return ['success' => false];
        }
    }

    // public function GetAttendanceChartData(Request $request)
    // {
    //     $month_filter = $request->get('month_filter', date('M-Y'));
    //     $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);

    //     $month = $parsedDate->month;
    //     $year  = $parsedDate->year;

    //     $startDate = Carbon::create($year, $month, 1);
    //     $endDate   = $startDate->copy()->endOfMonth();

    //     if (now()->between($startDate, $endDate)) {
    //         $endDate = now();
    //     }

    //     // Days excluding Sundays
    //     $days = collect(CarbonPeriod::create($startDate, $endDate))
    //         ->filter(fn($d) => $d->dayOfWeek !== Carbon::SUNDAY)
    //         ->map(fn($d) => $d->day)
    //         ->values();

    //     // Entities
    //     $entities = ManageEntityModel::where('status', 0)
    //         ->orderBy('sno', 'asc')
    //         ->get(['sno', 'entity_name', 'entity_base_color']);

    //     $resultEntities = [];

    //     foreach ($entities as $entity) {

    //         $dailyPercentages = [];

    //         foreach ($days as $day) {

    //             $date = Carbon::create($year, $month, $day)->toDateString();

    //             $totalStaff = DB::table('egc_staff')
    //                 ->where('entity_id', $entity->sno)
    //                 ->count();

    //             $presentCount = StaffAttendanceModel::whereDate('date', $date)
    //                 ->whereIn('attendance', ['P', 'PR', 'HD'])
    //                 ->whereIn('staff_id', function ($q) use ($entity) {
    //                     $q->select('sno')
    //                     ->from('egc_staff')
    //                     ->where('entity_id', $entity->sno);
    //                 })
    //                 ->count();

    //             $percentage = $totalStaff > 0
    //                 ? round(($presentCount / $totalStaff) * 100, 1)
    //                 : 0;

    //             $dailyPercentages[] = $percentage;
    //         }

    //         $totalPresent = array_sum($dailyPercentages);

    //         $resultEntities[] = [
    //             'id'               => $entity->sno,
    //             'name'             => $entity->entity_name,
    //             'color'            => $entity->entity_base_color,
    //             'daily_percentage' => $dailyPercentages,
    //             'total_present'    => round($totalPresent, 1)
    //         ];
    //     }

    //     return response()->json([
    //         'status'   => 200,
    //         'days'     => $days,
    //         'entities' => $resultEntities
    //     ]);
    // }


  public function GetAttendanceChartData(Request $request)
{
    $month_filter = $request->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);

    $month = $parsedDate->month;
    $year  = $parsedDate->year;

    $startDate = Carbon::create($year, $month, 1);
    $endDate   = $startDate->copy()->endOfMonth();

    if (now()->between($startDate, $endDate)) {
        $endDate = now();
    }

    // Days excluding Sundays
    $days = collect(CarbonPeriod::create($startDate, $endDate))
        ->filter(fn($d) => $d->dayOfWeek !== Carbon::SUNDAY)
        ->map(fn($d) => $d->day)
        ->values();

    // Entities including company level
    $entities = collect([
        [
            'id'    => 0,
            'name'  => 'Elysium Groups',
            'color' => '#ab2b22'
        ]
    ])->merge(
        ManageEntityModel::where('status', 0)
            ->orderBy('sno', 'asc')
            ->get()
            ->map(fn($e) => [
                'id'    => $e->sno,
                'name'  => $e->entity_name,
                'color' => $e->entity_base_color
            ])
    );

    $resultEntities = [];

    foreach ($entities as $entity) {
        $dailyPercentages = [];

        foreach ($days as $day) {
            $date = Carbon::create($year, $month, $day)->toDateString();

            if ($entity['id'] == 0) {
                // Company level (all staff)
                $totalStaff = DB::table('egc_staff')
                    ->where('sno','>',1)
                    ->where('company_type',1)
                    ->where('status',0)
                    ->count();

                $presentCount = StaffAttendanceModel::whereDate('date', $date)
                    ->whereIn('attendance', ['P','HD'])
                    ->whereIn('staff_id', function ($q) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('company_type',1);
                    })
                    ->where('status','!=',2)
                    ->count();

                $absentCount = StaffAttendanceModel::whereDate('date', $date)
                    ->where('attendance','A')
                    ->whereIn('staff_id', function ($q) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('company_type',1);
                    })
                    ->where('status','!=',2)
                    ->count();

                $leaveCount = StaffAttendanceModel::whereDate('date', $date)
                    ->where('attendance','L')
                    ->whereIn('staff_id', function ($q) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('company_type',1);
                    })
                    ->where('status','!=',2)
                    ->count();

                $permissionCount = StaffAttendanceModel::whereDate('date', $date)
                    ->where('attendance','PR')
                    ->whereIn('staff_id', function ($q) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('company_type',1);
                    })
                    ->where('status','!=',2)
                    ->count();

                $onDutyCount = StaffAttendanceModel::whereDate('date', $date)
                    ->where('attendance','OD')
                    ->whereIn('staff_id', function ($q) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('company_type',1);
                    })
                    ->where('status','!=',2)
                    ->count();

            } else {
                // Entity level
                $totalStaff = DB::table('egc_staff')
                    ->where('entity_id', $entity['id'])
                    ->where('sno','>',1)
                    ->where('status',0)
                    ->count();

                $presentCount = StaffAttendanceModel::whereDate('date', $date)
                    ->whereIn('attendance', ['P','HD'])
                    ->where('status','!=',2)
                    ->whereIn('staff_id', function ($q) use ($entity) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('entity_id', $entity['id']);
                    })
                    ->count();

                $absentCount = StaffAttendanceModel::whereDate('date', $date)
                    ->where('attendance','A')
                    ->where('status','!=',2)
                    ->whereIn('staff_id', function ($q) use ($entity) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('entity_id', $entity['id']);
                    })
                    ->count();

                $leaveCount = StaffAttendanceModel::whereDate('date', $date)
                    ->where('attendance','L')
                    ->where('status','!=',2)
                    ->whereIn('staff_id', function ($q) use ($entity) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('entity_id', $entity['id']);
                    })
                    ->count();

                $permissionCount = StaffAttendanceModel::whereDate('date', $date)
                    ->where('attendance','PR')
                    ->where('status','!=',2)
                    ->whereIn('staff_id', function ($q) use ($entity) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('entity_id', $entity['id']);
                    })
                    ->count();

                $onDutyCount = StaffAttendanceModel::whereDate('date', $date)
                    ->where('attendance','OD')
                    ->where('status','!=',2)
                    ->whereIn('staff_id', function ($q) use ($entity) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('entity_id', $entity['id']);
                    })
                    ->count();
            }

            // Calculate percentages
            $dailyPercentages[] = [
                'present'    => $totalStaff > 0 ? round(($presentCount / $totalStaff) * 100, 1) : 0,
                'absent'     => $totalStaff > 0 ? round(($absentCount / $totalStaff) * 100, 1) : 0,
                'leave'      => $totalStaff > 0 ? round(($leaveCount / $totalStaff) * 100, 1) : 0,
                'permission' => $totalStaff > 0 ? round(($permissionCount / $totalStaff) * 100, 1) : 0,
                'on_duty'    => $totalStaff > 0 ? round(($onDutyCount / $totalStaff) * 100, 1) : 0
            ];
        }

        $resultEntities[] = [
            'id'               => $entity['id'],
            'name'             => $entity['name'],
            'color'            => $entity['color'],
            'daily_percentage' => $dailyPercentages
        ];
    }

    return response()->json([
        'status'   => 200,
        'days'     => $days,
        'entities' => $resultEntities
    ]);
}


  public function GetAttendanceChartDataPresnt(Request $request)
{
    $month_filter = $request->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);

    $month = $parsedDate->month;
    $year  = $parsedDate->year;

    $startDate = Carbon::create($year, $month, 1);
    $endDate   = $startDate->copy()->endOfMonth();

    if (now()->between($startDate, $endDate)) {
        $endDate = now();
    }

    // Days excluding Sundays
    $days = collect(CarbonPeriod::create($startDate, $endDate))
        ->filter(fn($d) => $d->dayOfWeek !== Carbon::SUNDAY)
        ->map(fn($d) => $d->day)
        ->values();

    // Entities (including "Elysium Groups")
    $entities = collect([
        [
            'id'    => 0,
            'name'  => 'Elysium Groups',
            'color' => '#ab2b22'
        ]
    ])->merge(
        ManageEntityModel::where('status', 0)
            ->orderBy('sno', 'asc')
            ->get()
            ->map(fn($e) => [
                'id'    => $e->sno,
                'name'  => $e->entity_name,
                'color' => $e->entity_base_color
            ])
    );

    $resultEntities = [];

    foreach ($entities as $entity) {

        $dailyPercentages = [];

        foreach ($days as $day) {
            $date = Carbon::create($year, $month, $day)->toDateString();

            if ($entity['id'] == 0) {
                // Company level (all staff)
                $totalStaff = DB::table('egc_staff')->where('sno','>',1)->where('company_type', 1)->where('status',0)->count();
            
                $presentCount = StaffAttendanceModel::whereDate('date', $date)
                    ->whereIn('attendance', ['A'])
                    ->whereIn('staff_id', function ($q) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('company_type', 1);
                    })
                    ->where('status','!=',2)
                    ->count();
                    
            } else {
                // Entity level
                $totalStaff = DB::table('egc_staff')
                    ->where('entity_id', $entity['id'])->where('sno','>',1)->where('status',0)
                    ->count();

                $presentCount = StaffAttendanceModel::whereDate('date', $date)
                    ->whereIn('attendance', ['A'])
                    ->where('status','!=',2)
                    ->whereIn('staff_id', function ($q) use ($entity) {
                        $q->select('sno')
                            ->from('egc_staff')
                            ->where('status',0)
                            ->where('entity_id', $entity['id']);
                    })
                    ->count();
            }

            $percentage = $totalStaff > 0
                ? round(($presentCount / $totalStaff) * 100, 1)
                : 0;

            $dailyPercentages[] = $percentage;
        }

        $totalPresent = array_sum($dailyPercentages);

        $resultEntities[] = [
            'id'               => $entity['id'],
            'name'             => $entity['name'],
            'color'            => $entity['color'],
            'daily_percentage' => $dailyPercentages,
            'total_present'    => round($totalPresent, 1)
        ];
    }

    return response()->json([
        'status'   => 200,
        'days'     => $days,
        'entities' => $resultEntities
    ]);
}


public function fetchStaffMonthlyAttendance(Request $request)
    {
        $staffId = $request->input('staff_id');
        $month = $request->input('month');
        $year = $request->input('year');

        // Fetch attendance data for the specified staff, month, and year
        $attendanceData = StaffAttendanceModel::select('staff_id', 'date', 'attendance')
            ->where('staff_id', $staffId)
            ->whereMonth('date', $month)
            ->whereYear('date', $year)
            ->get();
        $staff = DB::table('egc_staff')->select('company_id')->where('sno', $staffId)->first();

        // Initialize summary counts for the staff member
        $summary = [
            'present' => 0,
            'absent' => 0,
            'leave' => 0,
            'permission' => 0,
            'onduty' => 0,
            'workoff' => 0,
            'total_days' => 0, // Total working days in the month
        ];

        // Initialize array to hold attendance for each day of the week
        $formattedAttendance = [
            'monday_status' => '',
            'tuesday_status' => '',
            'wednesday_status' => '',
            'thursday_status' => '',
            'friday_status' => '',
            'saturday_status' => '',
            'sunday_status' => ''
        ];

        $holidays = DB::table('egc_holiday')
            ->whereJsonContains('company_ids', $staff->company_id)
            ->where('status', 0) // Active holidays
            ->where(function($q) use ($month, $year) {
                $q->whereMonth('hol_date', $month)
                ->whereYear('hol_date', $year);
            })
            ->get();

        $holidayDates = collect();
        foreach ($holidays as $holiday) {
            $start = Carbon::parse($holiday->hol_date);
            $end = $holiday->hol_end_date ? Carbon::parse($holiday->hol_end_date) : $start;

            foreach (CarbonPeriod::create($start, $end) as $d) {
                $holidayDates->push($d->format('Y-m-d'));
            }
        }

        // Check if attendance data is empty
        if ($attendanceData->isEmpty()) {
            return response()->json([
                'summary' => $summary,
                'formattedAttendance' => $formattedAttendance,
                'attendanceData' => $attendanceData,
            ]);
        }

        $attendanceByDate = $attendanceData->keyBy(function ($item) {
            return Carbon::parse($item->date)->format('Y-m-d');
        });

        foreach ($attendanceData as $record) {
            $date = Carbon::parse($record->date);
            $dayOfWeek = $date->format('l'); // Day of the week
            $dateKey = $date->format('Y-m-d');

            // Count attendance status
            switch ($record->attendance) {
                case 'P':
                    $summary['present']++;
                    break;
                case 'A':
                    $summary['absent']++;
                    break;
                case 'L':
                    $summary['leave']++;
                    break;
                case 'PR':
                    $summary['permission']++;
                    break;
                case 'OD':
                    $summary['onduty']++;
                    break;
                case 'WO':
                    $summary['workoff']++;
                    break;
            }
            // Increment total working days
            $summary['total_days']++;
        }

        $finalAttendanceData = [];

       

            $startOfMonth = Carbon::create($year, $month, 1);
            $endOfMonth = $startOfMonth->copy()->endOfMonth();

        foreach (CarbonPeriod::create($startOfMonth, $endOfMonth) as $date) {

            $dateKey = $date->format('Y-m-d');
            $dayKey = strtolower($date->format('l'));

            // HOLIDAY
            if ($holidayDates->contains($dateKey)) {
                $finalAttendanceData[] = [
                    'staff_id' => $staffId,
                    'date' => $dateKey,
                    'attendance' => 'HD',
                ];
                continue;
            }

            // WEEK OFF (Sunday)
            if ($date->isSunday()) {
                $finalAttendanceData[] = [
                    'staff_id' => $staffId,
                    'date' => $dateKey,
                    'attendance' => 'WK',
                ];
                continue;
            }

            // DB Attendance
            if (isset($attendanceByDate[$dateKey])) {
                $finalAttendanceData[] = [
                    'staff_id' => $staffId,
                    'date' => $dateKey,
                    'attendance' => $attendanceByDate[$dateKey]->attendance,
                ];
            } else {
                // Optional: mark missing working day
                $finalAttendanceData[] = [
                    'staff_id' => $staffId,
                    'date' => $dateKey,
                    'attendance' => '',
                ];
            }
        }

        

        // Calculate percentages
        $summary['present_percentage'] = $summary['total_days'] > 0 ? round(($summary['present'] / $summary['total_days']) * 100, 2) : 0;
        $summary['absent_percentage'] = $summary['total_days'] > 0 ? round(($summary['absent'] / $summary['total_days']) * 100, 2) : 0;
        $summary['leave_percentage'] = $summary['total_days'] > 0 ? round(($summary['leave'] / $summary['total_days']) * 100, 2) : 0;
        $summary['permission_percentage'] = $summary['total_days'] > 0 ? round(($summary['permission'] / $summary['total_days']) * 100, 2) : 0;
        $summary['onduty_percentage'] = $summary['total_days'] > 0 ? round(($summary['onduty'] / $summary['total_days']) * 100, 2) : 0;
        $summary['workoff_percentage'] = $summary['total_days'] > 0 ? round(($summary['workoff'] / $summary['total_days']) * 100, 2) : 0;

        // Format the final response
        $response = [
            'summary' => $summary,
            'formattedAttendance' => $formattedAttendance,
            'attendanceData' => $finalAttendanceData,
        ];

        return response()->json($response);
    }

    public function fetchIndividualStaffAttendance(Request $request)
    {
        $staffId = $request->input('staff_id');

        $response = StaffModel::select(
            'egc_staff.sno as staff_id',
            'egc_staff.staff_name',
            'egc_staff.company_type',
            'egc_staff.company_id',
            'egc_staff.entity_id',
            'egc_staff.nick_name',
            'egc_staff.gender',
            'egc_staff.staff_image',
            'egc_staff.mobile_no',
            'egc_staff.email_id',
            'egc_department.department_name',
            'egc_branch.branch_name',
            'egc_branch.franchise_name',
        )
            ->join('egc_department', 'egc_department.sno', '=', 'egc_staff.department_id')
            ->leftJoin('egc_branch', 'egc_branch.sno', '=', 'egc_staff.branch_id')
            ->where('egc_staff.status', 0)
            ->where('egc_staff.sno', $staffId)
            ->first();


        return response()->json($response);
    }


     public function ViewAttendanceDate(Request $request)
    {
        $date = $request->input('date');
        $entity_id = $request->input('entity_id') ?? 0;

        // Validate the incoming date
        if (!$date) {
            return response()->json([
                'status' => 400,
                'message' => 'Date is required.',
                'error_msg' => 'Invalid date provided.',
                'data' => [],
            ]);
        }

        // Get the selected date
        $selectedDate = Carbon::parse($date);

        // Fetch staff attendance data for the selected date
        $viewAttendance = StaffAttendanceModel::select(
            'egc_staff_attendance.*',
            'egc_staff.staff_name',
            'egc_staff.staff_image',
            'egc_staff.gender',
            'egc_staff.nick_name',
            'egc_staff.mobile_no',
            'egc_staff.company_type',
            'egc_staff.company_id',
            'egc_staff.entity_id',
            'egc_staff.department_id',
            'egc_staff.division_id',
            'egc_department.department_name',
            'egc_division.division_name as sub_department_name',
            'egc_staff.job_role_id',
            'egc_job_role.job_position_name as job_roll_name'
        )
            ->join('egc_staff', 'egc_staff_attendance.staff_id', '=', 'egc_staff.sno')
            ->join('egc_department', 'egc_staff.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 'egc_staff.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 'egc_staff.job_role_id', '=', 'egc_job_role.sno')
            ->where('egc_staff_attendance.date', $selectedDate)
            ->where('egc_staff.entity_id', $entity_id)
            ->get();

        if ($viewAttendance->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'No attendance data found for the selected date.',
                'error_msg' => null,
                'data' => [],
            ]);
        }

        // Calculate the attendance summary
        $attendanceSummaryMonth = [
            'present' => 0,
            'absent' => 0,
            'leave' => 0,
            'other' => 0,
            'permission' => 0,
            'onduty' => 0,
            'workoff' => 0,
            'total_staff' => count($viewAttendance),
        ];

        // Loop through staff attendance records to calculate summary
        foreach ($viewAttendance as $attendance) {
            switch ($attendance->attendance) {
                case 'P': // Present
                    $attendanceSummaryMonth['present']++;
                    break;
                case 'A': // Absent
                    $attendanceSummaryMonth['absent']++;
                    break;
                case 'L': // Leave
                    $attendanceSummaryMonth['leave']++;
                    break;
                case 'PR': // Permission
                    $attendanceSummaryMonth['permission']++;
                    break;
                case 'OD': // On Duty
                    $attendanceSummaryMonth['onduty']++;
                    break;
                case 'WO': // On Duty
                        $attendanceSummaryMonth['workoff']++;
                        break;
                default:
                    $attendanceSummaryMonth['other']++;
                    break;
            }
        }

        // Calculate percentages for each attendance category
        $totalStaff = $attendanceSummaryMonth['total_staff'];
        $attendanceSummaryMonth['present_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['present'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['absent_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['absent'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['leave_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['leave'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['permission_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['permission'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['onduty_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['onduty'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['workoff_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['workoff'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['other_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['other'] / $totalStaff) * 100, 2) : 0;

        return response()->json([
            'status' => 200,
            'message' => 'Attendance data retrieved successfully.',
            'error_msg' => null,
            'data' => $viewAttendance,
            'summary' => $attendanceSummaryMonth, // Return attendance summary as well
        ]);
    }

     public function ViewAttendanceDashboard(Request $request)
    {
        $monthFilter = $request->input('monthFilter');
        $attendance = $request->input('attendance');
        $month_filter = $request->get('monthFilter', date('M-Y'));
        // return  $month_filter;
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
        // $month_filter = $request->get('month_filter', date('m-Y'));  // Default to numeric month (11-2025)
        // $parsedDate = Carbon::createFromFormat('m-Y', $month_filter);

        $month = $parsedDate->month;
        $year  = $parsedDate->year;
        $entity_id = $request->input('entity_id') ?? 0;

        // Validate the incoming date
        if (!$monthFilter) {
            return response()->json([
                'status' => 400,
                'message' => 'Date is required.',
                'error_msg' => 'Invalid date provided.',
                'data' => [],
            ]);
        }

        $total_staff_count = StaffModel::select(
            'egc_staff.sno as staff_id',
            'egc_staff.staff_id as employee_id',
            'egc_staff.staff_name',
            'egc_staff.nick_name',
            'egc_staff.gender',
            'egc_staff.company_type',
            'egc_staff.company_id',
            'egc_staff.entity_id',
            'egc_staff.staff_image',
            'egc_department.department_name'
        )
        ->join('egc_department','egc_department.sno','=','egc_staff.department_id')
        ->where('egc_staff.status',0)
        ->where('egc_staff.entity_id', $entity_id)
        ->where('egc_staff.sno','>',0)
        ->count();

 

        // Fetch staff attendance data for the selected date
        $viewAttendance = StaffAttendanceModel::select(
            'egc_staff_attendance.*',
            'egc_staff.staff_name',
            'egc_staff.staff_image',
            'egc_staff.staff_id as employee_id',
            'egc_staff.gender',
            'egc_staff.nick_name',
            'egc_staff.mobile_no',
            'egc_staff.company_type',
            'egc_staff.company_id',
            'egc_staff.entity_id',
            'egc_staff.department_id',
            'egc_staff.division_id',
            'egc_department.department_name',
            'egc_division.division_name as sub_department_name',
            'egc_staff.job_role_id',
            'egc_job_role.job_position_name as job_roll_name'
        )
            ->join('egc_staff', 'egc_staff_attendance.staff_id', '=', 'egc_staff.sno')
            ->join('egc_department', 'egc_staff.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 'egc_staff.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 'egc_staff.job_role_id', '=', 'egc_job_role.sno')
            ->whereMonth('egc_staff_attendance.date', $month)
            ->whereYear('egc_staff_attendance.date', $year)
            ->where('egc_staff_attendance.attendance', $attendance)
            ->where('egc_staff.entity_id', $entity_id)
            ->orderBy('egc_staff_attendance.date','desc')
            ->get();
        

        if ($viewAttendance->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'No attendance data found for the selected date.',
                'error_msg' => null,
                'data' => [],
            ]);
        }

        $staffIds = $viewAttendance->pluck('staff_id')->unique()->toArray();

          $shiftTimes = DB::table('egc_shift_time_log as stl')
            ->join('egc_shift_day_times as sdt', 'stl.change_shift_id', '=', 'sdt.shift_id')
            ->whereIn('stl.staff_id', $staffIds)
            ->where('sdt.status', 0)
            ->select(
                'stl.staff_id',
                'stl.start_date',
                'stl.end_date',
                'sdt.day_name',
                'sdt.time_from',
                'sdt.time_to'
            )
            ->get()
            ->groupBy('staff_id');

        // Calculate the attendance summary
        $attendanceSummaryMonth = [
            'present' => 0,
            'absent' => 0,
            'leave' => 0,
            'other' => 0,
            'permission' => 0,
            'onduty' => 0,
            'workoff' => 0,
            'total_attendance' => count($viewAttendance),
            'total_staff' => $total_staff_count,
        ];

        // Loop through staff attendance records to calculate summary
        foreach ($viewAttendance as $attendance) {
            switch ($attendance->attendance) {
                case 'P': // Present
                    $attendanceSummaryMonth['present']++;
                    break;
                case 'A': // Absent
                    $attendanceSummaryMonth['absent']++;
                    break;
                case 'L': // Leave
                    $attendanceSummaryMonth['leave']++;
                    break;
                case 'PR': // Permission
                    $attendanceSummaryMonth['permission']++;
                    break;
                case 'OD': // On Duty
                    $attendanceSummaryMonth['onduty']++;
                    break;
                case 'WO': // On Duty
                        $attendanceSummaryMonth['workoff']++;
                        break;
                default:
                    $attendanceSummaryMonth['other']++;
                    break;
            }

            $dateKey = Carbon::parse($attendance->date)->format('Y-m-d');
            $dayName = strtolower(Carbon::parse($attendance->date)->format('D'));

            $staffShift = $shiftTimes[$attendance->staff_id] ?? collect();

            $shift = $staffShift->filter(function ($s) use ($dateKey, $dayName) {

                $start = $s->start_date;
                $end   = $s->end_date ?? '9999-12-31';

                return $dateKey >= $start
                    && $dateKey <= $end
                    && strtolower($s->day_name) == $dayName;

            })->first();

            // ✅ Attach shift to response
            $attendance->shift_data = [
                $dateKey => $shift
                    ? [
                        'time_from' => $shift->time_from,
                        'time_to' => $shift->time_to
                    ]
                    : null
            ];
            
        }

        

        // return $total_staff_count;

        // Calculate percentages for each attendance category
        $totalStaff = $attendanceSummaryMonth['total_attendance'];
        $attendanceSummaryMonth['present_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['present'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['absent_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['absent'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['leave_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['leave'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['permission_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['permission'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['onduty_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['onduty'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['workoff_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['workoff'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['other_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['other'] / $totalStaff) * 100, 2) : 0;

        return response()->json([
            'status' => 200,
            'message' => 'Attendance data retrieved successfully.',
            'error_msg' => null,
            'data' => $viewAttendance,
            'summary' => $attendanceSummaryMonth, // Return attendance summary as well
        ]);
    }


    // public function generateQrCheckIN(Request $request)
    // {
    //     $date = Carbon::now()->format('Y-m-d');
    //     $expiresAt = Carbon::now()->addMinutes(10); // ⏱ QR valid for 10 mins

    //     $payload = [
    //         'date' => $date,
    //         'exp'  => $expiresAt->timestamp
    //     ];

    //     $encrypted = encrypt(json_encode($payload));

    //     $qrContent = url("/api/daily_staff_checkin_qr?token=" . urlencode($encrypted));


    //     // Generate QR as base64 image
    //     $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=1000x1000";
    //     $qrImageData = @file_get_contents($qrServerUrl);
    //     $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;

    //     return response()->json([
    //         'status' => 200,
    //         'qr_base64' => $qrBase64,
    //         'link' => $qrContent,
    //         'expires_at' => $expiresAt->toDateTimeString()
    //     ]);
    // }

    public function DailyQRIndex(){
        return view('content.hr_management.hr_enroll.manage_attendance.daily_qr');
    }

    public function generateQrCheckIN(Request $request)
    {
        try {

            /* Current Time */
            $now = Carbon::now();

            /*QR Validity */
            $expiresAt = $now->copy()->addMinutes(10);

            /* Unique QR ID */
            $qrId = (string) Str::uuid();

            /* Payload */
            $payload = [
                'qr_id' => $qrId,
                'type'  => 'daily_attendance',
                'date'  => $now->format('Y-m-d'),
                'iat'   => $now->timestamp,
                'exp'   => $expiresAt->timestamp,
            ];

            /*Encrypt Payload */
            $encrypted = encrypt(json_encode($payload));

            /*QR URL */
            $qrContent = url('/api/daily_staff_checkin_qr?token=' .urlencode($encrypted));
            //  $qrBase64 = 'data:image/svg+xml;base64,' . base64_encode($qrSvg);                
            // Generate QR as base64 image
            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=1000x1000";
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;

            /* Generate QR Locally */
            //  $qrSvg = QrCode::format('svg')
            //     ->size(1000)
            //     ->margin(2)
            //     ->errorCorrection('H')
            //     ->generate($qrContent);

            /*Convert To Base64 */
        //    $qrBase64 = 'data:image/svg+xml;base64,' . base64_encode($qrSvg);

            /* Response */
            return response()->json([

                'status' => 200,
                'message' => 'Attendance QR generated successfully',
                'qr_base64' => $qrBase64,
                'link' => $qrContent,
                'qr_id' => $qrId,
                'date' => $now->format('Y-m-d'),
                'date_formatted' => $now->format('d M Y'),
                'generated_at' =>  $now->toIso8601String(),
                'generated_at_formatted' => $now->format('h:i:s A'),
                'expires_at' => $expiresAt->toIso8601String(),
                'expires_at_formatted' => $expiresAt->format('h:i:s A'),
                'validity_seconds' => $now->diffInSeconds( $expiresAt ),
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'status' => 500,
                'message' =>'Unable to generate attendance QR',
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'error' =>  $e->getMessage(),
            ], 500);
        }
    }

    public function DailyAttendanceCheckQr(Request $request)
    {
        try {
            $token = $request->query('token');

            if (!$token) {
                return response()->json([
                    'status' => 400,
                    'message' => 'Invalid QR'
                ]);
            }

            $decoded = json_decode(decrypt($token), true);

            $date = $decoded['date'];
            $expiry = $decoded['exp'];

            //  Save scan log
            $this->saveScanDetails($date, $request);

            //  Expiry check
            if (Carbon::now()->timestamp > $expiry) {
                return response()->json([
                    'status' => 410,
                    'message' => 'QR Code Expired'
                ]);
            }

            // $user = $request->user();

            // if (!$user) {
            //     return response()->json([
            //         'status' => 401,
            //         'message' => 'Unauthorized'
            //     ]);
            // }

            // //  Prevent duplicate check-in
            // $alreadyChecked = StaffAttendanceModel::where('staff_id', $user->user_id)
            //     ->where('checkin_verified', 1)
            //     ->where('date', $date)
            //     ->exists();

            // if ($alreadyChecked) {
            //     return response()->json([
            //         'status' => 409,
            //         'message' => 'Already Checked In'
            //     ]);
            // }

            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();

            $formatedDate = date('d-M-Y', strtotime($date));
            return response()->json([
                'status' => 200,
                'message' => 'QR Verified',
                'date' => $formatedDate,
                'data' => [
                    'office_location' => [
                        "latitude" => $general_setting->latitude ?? '',
                        "longitude" => $general_setting->longitude ?? '',
                    ],
                    'expires_at' => date('Y-m-d H:i:s', $expiry)
                ]
            ]);
        } catch (\Exception $e) {

            \Log::error('QR Scan Error', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong'
            ]);
        }
    }

    private function saveScanDetails($date, Request $request)
    {
        $device = $this->getDeviceInfo($request);

        AttendanceQRModel::create([
            'date'        => $date,
            'user_id'     => optional($request->user())->user_id,
            'ipaddress'   => $request->ip(),
            'latitude'    => $request->input('latitude'),
            'longitude'   => $request->input('longitude'),
            'device_type' => $device['device_type'],
            'os'          => $device['os'],
            'browser'     => $device['browser'],
            'user_agent'  => $device['user_agent'],
            'scanned_at'  => now(),
        ]);
    }


    private function getDeviceInfo(Request $request)
    {
        $agent = $request->header('User-Agent');

        $deviceType = 'Desktop';
        if (preg_match('/Mobile|Android|iPhone/i', $agent)) {
            $deviceType = 'Mobile';
        } elseif (preg_match('/iPad|Tablet/i', $agent)) {
            $deviceType = 'Tablet';
        }

        $os = 'Unknown';
        if (preg_match('/Android/i', $agent)) {
            $os = 'Android';
        } elseif (preg_match('/iPhone|iPad/i', $agent)) {
            $os = 'iOS';
        } elseif (preg_match('/Windows/i', $agent)) {
            $os = 'Windows';
        } elseif (preg_match('/Mac/i', $agent)) {
            $os = 'MacOS';
        }

        $browser = 'Unknown';
        if (preg_match('/Chrome/i', $agent)) {
            $browser = 'Chrome';
        } elseif (preg_match('/Safari/i', $agent)) {
            $browser = 'Safari';
        } elseif (preg_match('/Firefox/i', $agent)) {
            $browser = 'Firefox';
        }

        return [
            'device_type' => $deviceType,
            'os' => $os,
            'browser' => $browser,
            'user_agent' => $agent
        ];
    }


    public function leaveMatrix(Request $request)
    {
        $year = $request->year ?? date('Y');
        $search = $request->search;
        $entity_id = $request->entity_id ?? '';

        $startDate = $year . '-01-01';
        $endDate = $year . '-12-31';

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {

                $q->whereBetween('hol_date', [$startDate, $endDate])
                    ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->select('hol_date', 'hol_end_date')
            ->get();

        $holidayDates = [];

        foreach ($holidays as $holiday) {

            $from = \Carbon\Carbon::parse($holiday->hol_date);
            $to = \Carbon\Carbon::parse($holiday->hol_end_date ?? $holiday->hol_date);

            while ($from->lte($to)) {

                $holidayDates[] = $from->format('Y-m-d');

                $from->addDay();
            }
        }

        $holidayDates = array_unique($holidayDates);

        $staffs = StaffModel::where('egc_staff.status', 0)
            ->select(
                'egc_staff.sno as staff_id',
                'egc_staff.staff_name',
                'egc_staff.nick_name',
                'egc_staff.staff_id as employee_id',
                'egc_staff.staff_image',
                'egc_staff.gender',
                'egc_staff.company_type',
                'egc_staff.company_id',
                'egc_staff.entity_id',

                'egc_entity.entity_base_color',
                'egc_entity.entity_name',
                'egc_department.department_name',
                'egc_job_role.job_position_name as job_role_name'
            )
            ->where('egc_staff.sno', '>', 0)
            ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
            ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
            ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')

            ->when($search, function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('egc_staff.staff_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_staff.staff_id', 'LIKE', "%{$search}%")
                        ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_department.department_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search}%");
                });
            });
            if ($entity_id != '') {
                if ($entity_id == 'egc') {
                    $staffs->where('egc_staff.entity_id', 0);
                } else {
                    $staffs->where('egc_staff.entity_id', $entity_id);
                }
            }
            $staffs = $staffs->distinct('egc_staff.sno')
                ->paginate(20);

        $staffIds = $staffs->pluck('staff_id');

        $attendance = DB::table('egc_staff_attendance as a')
            ->leftJoin('egc_leave_reason as r', 'r.sno', '=', 'a.reason_id')
            ->whereIn('a.staff_id', $staffIds)
            ->whereIn('a.attendance', ['L', 'A'])
            ->whereYear('a.date', $year)
            ->whereNotIn('a.date', $holidayDates)
            ->select(
                'a.staff_id',
                DB::raw('MONTH(a.date) as month'),
                'a.date',
                'a.leave_type',
                'a.attendance',
                'a.reason',
                'r.reason_name'
            )
            ->orderBy('a.date')
            ->get();

        $attendanceMap = [];

        foreach ($attendance as $row) {

            $month = $row->month;

            if (!isset($attendanceMap[$row->staff_id][$month])) {

                $attendanceMap[$row->staff_id][$month] = [
                    'count' => 0,
                    'leaves' => []
                ];
            }

            $attendanceMap[$row->staff_id][$month]['count']++;

            $attendanceMap[$row->staff_id][$month]['leaves'][] = [
                'date' => date('d-M', strtotime($row->date)),
                'leave_type' => $row->attendance == 'A'
                    ? 'Absent'
                    : ucfirst(str_replace('_', ' ', $row->leave_type)),
                'reason' => $row->reason ?? $row->reason_name ?? '-'
            ];
        }

        $data = [];

        foreach ($staffs as $emp) {

            // IMAGE

            if ($emp->gender == 1) {
                $defaultPath = asset('assets/egc_images/auth/user_2.png');
            } else {
                $defaultPath = asset('assets/egc_images/auth/user_7.png');
            }

            if ($emp->company_type == 1) {
                $relativePath = 'staff_images/Management/' . $emp->staff_image;
            } else {
                $relativePath = 'staff_images/Buisness/' . $emp->company_id . '/' . $emp->entity_id . '/' . $emp->staff_image;
            }

            $fullPath = public_path($relativePath);
            $filePath = asset($relativePath);

            $staffImage = ($emp->staff_image && file_exists($fullPath))
                ? $filePath
                : $defaultPath;

            $months = [];

            for ($i = 1; $i <= 12; $i++) {
                $months[$i] = [
                    'count' => $attendanceMap[$emp->staff_id][$i]['count'] ?? 0,
                    'leaves' => $attendanceMap[$emp->staff_id][$i]['leaves'] ?? []
                ];
            }
            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();


            $data[] = [
                'staff_name' => $emp->staff_name,
                'nick_name' => $emp->nick_name,
                'employee_id' => $emp->employee_id,
                'staff_image' => $staffImage,
                'entity_name' => $emp->entity_name ?? $general_setting->title,
                'entity_base_color' => $emp->entity_base_color ?? '#ab2b22',
                'department_name' => $emp->department_name,
                'job_role_name' => $emp->job_role_name,
                'months' => $months
            ];
        }

        return response()->json([
            'data' => $data,
            'next_page' => $staffs->hasMorePages()
        ]);
    }

    public function leaveHistory(Request $request)
    {
        $year = $request->year ?? date('Y');
        $search = $request->search;

        $startDate = $year . '-01-01';
        $endDate = $year . '-12-31';

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {

                $q->whereBetween('hol_date', [$startDate, $endDate])
                    ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->select('hol_date', 'hol_end_date')
            ->get();

        $holidayDates = [];

        foreach ($holidays as $holiday) {

            $from = \Carbon\Carbon::parse($holiday->hol_date);
            $to = \Carbon\Carbon::parse($holiday->hol_end_date ?? $holiday->hol_date);

            while ($from->lte($to)) {

                $holidayDates[] = $from->format('Y-m-d');

                $from->addDay();
            }
        }

        $holidayDates = array_unique($holidayDates);

        $history = DB::table('egc_staff_attendance as a')
            ->join('egc_staff as s', 's.sno', '=', 'a.staff_id')
            ->leftJoin('egc_leave_reason as r', 'r.sno', '=', 'a.reason_id')
            ->whereIn('a.attendance', ['L', 'A'])
            ->where('s.status', 0)
            ->where('s.sno', '>', 0)
            ->whereYear('a.date', $year)
            ->whereNotIn('a.date', $holidayDates)
            ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
            ->join('egc_department', 's.department_id', 'egc_department.sno')
            ->join('egc_job_role', 's.job_role_id', 'egc_job_role.sno')
            ->select(
                'a.date',
                'a.attendance',
                's.staff_name',
                'a.leave_type',
                's.sno as staff_id',
                's.nick_name',
                's.staff_id as employee_id',
                's.staff_image',
                's.gender',
                's.company_type',
                's.company_id',
                's.entity_id',
                'egc_entity.entity_base_color',
                'egc_entity.entity_name',
                'egc_department.department_name',
                'egc_job_role.job_position_name as job_role_name',
                'a.reason as comment_reason',
                'a.reason_id',
                'r.reason_name',
            )->when($search, function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('s.staff_name', 'LIKE', "%{$search}%")
                        ->orWhere('s.staff_id', 'LIKE', "%{$search}%")
                        ->orWhere('s.nick_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_department.department_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search}%");
                });
            });
        $history = $history->orderBy('a.date', 'desc')
            ->paginate(20);

        foreach ($history as $emp) {

            // IMAGE

            if ($emp->gender == 1) {
                $defaultPath = asset('assets/egc_images/auth/user_2.png');
            } else {
                $defaultPath = asset('assets/egc_images/auth/user_7.png');
            }

            if ($emp->company_type == 1) {
                $relativePath = 'staff_images/Management/' . $emp->staff_image;
            } else {
                $relativePath = 'staff_images/Buisness/' . $emp->company_id . '/' . $emp->entity_id . '/' . $emp->staff_image;
            }

            $fullPath = public_path($relativePath);
            $filePath = asset($relativePath);

            $staffImage = ($emp->staff_image && file_exists($fullPath))
                ? $filePath
                : $defaultPath;

            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();
            $emp->entity_name = $emp->entity_name ??  $general_setting->title;
            $emp->entity_base_color = $emp->entity_base_color ?? '#ab2b22';
            $emp->staff_image_url = $staffImage;
        }

        return response()->json([
            'data' => $history,
            'next_page' => $history->hasMorePages()
        ]);
    }

    public function LateMatrix(Request $request)
    {
        $year = $request->year ?? date('Y');
        $search = $request->search;
        $entity_id = $request->entity_id ?? '';


        $startDate = $year . '-01-01';
        $endDate = $year . '-12-31';

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {

                $q->whereBetween('hol_date', [$startDate, $endDate])
                    ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->select('hol_date', 'hol_end_date')
            ->get();

        $holidayDates = [];

        foreach ($holidays as $holiday) {

            $from = \Carbon\Carbon::parse($holiday->hol_date);
            $to = \Carbon\Carbon::parse($holiday->hol_end_date ?? $holiday->hol_date);

            while ($from->lte($to)) {

                $holidayDates[] = $from->format('Y-m-d');

                $from->addDay();
            }
        }

        $holidayDates = array_unique($holidayDates);

        $staffs = StaffModel::where('egc_staff.status', 0)
            ->select(
                'egc_staff.sno as staff_id',
                'egc_staff.staff_name',
                'egc_staff.nick_name',
                'egc_staff.staff_id as employee_id',
                'egc_staff.staff_image',
                'egc_staff.gender',
                'egc_staff.company_type',
                'egc_staff.company_id',
                'egc_staff.entity_id',

                'egc_entity.entity_base_color',
                'egc_entity.entity_name',
                'egc_department.department_name',
                'egc_job_role.job_position_name as job_role_name'
            )
            ->where('egc_staff.sno', '>', 0)
            ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
            ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
            ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')

            ->when($search, function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('egc_staff.staff_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_staff.staff_id', 'LIKE', "%{$search}%")
                        ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_department.department_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search}%");
                });
            });
        if ($entity_id != '') {
            if ($entity_id == 'egc') {
                $staffs->where('egc_staff.entity_id', 0);
            } else {
                $staffs->where('egc_staff.entity_id', $entity_id);
            }
        }
        $staffs = $staffs->distinct('egc_staff.sno')
            ->paginate(20);

        $staffIds = $staffs->pluck('staff_id');

        $attendance = DB::table('egc_staff_attendance as a')
            ->leftJoin('egc_leave_reason as r', 'r.sno', '=', 'a.reason_id')
            ->join('egc_shift_time_log as stl', function ($join) {
                $join->on('stl.staff_id', '=', 'a.staff_id');
            })
            ->join('egc_shift_day_times as sd', function ($join) {
                $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                    ->where('sd.status', 0);
            })
            ->whereIn('a.staff_id', $staffIds)
            ->whereNotIn('a.attendance', ['L', 'A', 'PR', 'OD'])
            ->whereYear('a.date', $year)
            ->whereNotIn('a.date', $holidayDates)
            ->whereRaw("DATE(a.date) BETWEEN stl.start_date AND IFNULL(stl.end_date, '9999-12-31')")
            //  Match day (Mon, Tue...)
            ->whereRaw("LOWER(sd.day_name) = LOWER(DATE_FORMAT(a.date, '%a'))")
            //  Late condition
            // ->whereRaw("TIME(a.in_time) > TIME(sd.time_from)")
            ->whereRaw("TIME(a.in_time) > ADDTIME(sd.time_from, '00:12:00')")
            ->select(
                'a.staff_id',
                DB::raw('MONTH(a.date) as month'),
                'a.date',
                'a.in_time',
                'a.attendance',
                'a.out_time',
                'sd.time_from',
                'sd.time_to',
            )
            ->orderBy('a.date', 'desc')
            ->get();


        $attendanceMap = [];

        foreach ($attendance as $row) {

            $month = $row->month;

            if (!isset($attendanceMap[$row->staff_id][$month])) {

                $attendanceMap[$row->staff_id][$month] = [
                    'count' => 0,
                    'lates' => []
                ];
            }

            $latesMinutes = 0;

            if ($row->in_time && $row->time_from) {

                $shiftStart = \Carbon\Carbon::parse($row->time_from);
                $inTime = \Carbon\Carbon::parse($row->in_time);

                if ($inTime->gt($shiftStart)) {

                    $latesMinutes = $shiftStart->diffInMinutes($inTime);
                }
            }

            $workDuration = '-';

            if ($row->in_time && $row->out_time) {

                $in = \Carbon\Carbon::parse($row->in_time);
                $out = $row->out_time ? \Carbon\Carbon::parse($row->out_time) : NULL;

                $minutes = $out ? $in->diffInMinutes($out) : 0;

                $hours = floor($minutes / 60);
                $mins = $minutes % 60;

                $workDuration = $hours . 'h ' . $mins . 'm';
            }


            $attendanceMap[$row->staff_id][$month]['count']++;

            $attendanceMap[$row->staff_id][$month]['lates'][] = [

                'date' => date('d-M', strtotime($row->date)),

                'shift_from' => date('h:i A', strtotime($row->time_from)),
                'shift_to' => date('h:i A', strtotime($row->time_to)),

                'in_time' => $row->in_time
                    ? date('h:i A', strtotime($row->in_time))
                    : '-',

                'out_time' => $row->out_time
                    ? date('h:i A', strtotime($row->out_time))
                    : '-',

                'late_minutes' => $latesMinutes < 15 ? 0 : $latesMinutes - 15,

                'duration' => $workDuration
            ];

            // $attendanceMap[$row->staff_id][$month]['lates'][] = [
            //     'date' => date('d-M', strtotime($row->date)),
            //     'shift_from' => $row->time_from,
            //     'shift_to' => $row->time_to,
            //     'in_time' => $row->in_time,
            //     'out_time' => $row->out_time,
            // ];
        }

        $data = [];

        foreach ($staffs as $emp) {

            // IMAGE

            if ($emp->gender == 1) {
                $defaultPath = asset('assets/egc_images/auth/user_2.png');
            } else {
                $defaultPath = asset('assets/egc_images/auth/user_7.png');
            }

            if ($emp->company_type == 1) {
                $relativePath = 'staff_images/Management/' . $emp->staff_image;
            } else {
                $relativePath = 'staff_images/Buisness/' . $emp->company_id . '/' . $emp->entity_id . '/' . $emp->staff_image;
            }

            $fullPath = public_path($relativePath);
            $filePath = asset($relativePath);

            $staffImage = ($emp->staff_image && file_exists($fullPath))
                ? $filePath
                : $defaultPath;

            $months = [];

            for ($i = 1; $i <= 12; $i++) {
                $months[$i] = [
                    'count' => $attendanceMap[$emp->staff_id][$i]['count'] ?? 0,
                    'lates' => $attendanceMap[$emp->staff_id][$i]['lates'] ?? []
                ];
            }
            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();


            $data[] = [
                'staff_name' => $emp->staff_name,
                'nick_name' => $emp->nick_name,
                'employee_id' => $emp->employee_id,
                'staff_image' => $staffImage,
                'entity_name' => $emp->entity_name ?? $general_setting->title,
                'entity_base_color' => $emp->entity_base_color ?? '#ab2b22',
                'department_name' => $emp->department_name,
                'job_role_name' => $emp->job_role_name,
                'months' => $months
            ];
        }

        return response()->json([
            'data' => $data,
            'next_page' => $staffs->hasMorePages()
        ]);
    }

    public function LateHistory(Request $request)
    {
        $year = $request->year ?? date('Y');
        $search = $request->search;
        $entity_id = $request->entity_id ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->from_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_dt_iss_rpt ?? '';


        $startDate = $year . '-01-01';
        $endDate = $year . '-12-31';

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {

                $q->whereBetween('hol_date', [$startDate, $endDate])
                    ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->select('hol_date', 'hol_end_date')
            ->get();

        $holidayDates = [];

        foreach ($holidays as $holiday) {

            $from = \Carbon\Carbon::parse($holiday->hol_date);
            $to = \Carbon\Carbon::parse($holiday->hol_end_date ?? $holiday->hol_date);

            while ($from->lte($to)) {

                $holidayDates[] = $from->format('Y-m-d');

                $from->addDay();
            }
        }

        $holidayDates = array_unique($holidayDates);




        $history = DB::table('egc_staff_attendance as a')
            ->join('egc_staff as s', 's.sno', '=', 'a.staff_id')
            ->leftJoin('egc_leave_reason as r', 'r.sno', '=', 'a.reason_id')
            ->whereNotIn('a.attendance', ['L', 'A', 'PR', 'OD'])
            ->whereYear('a.date', $year)
            ->whereNotIn('a.date', $holidayDates)
            ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
            ->join('egc_department', 's.department_id', 'egc_department.sno')
            ->join('egc_job_role', 's.job_role_id', 'egc_job_role.sno')
            ->where('s.status', 0)
            ->where('s.sno', '>', 0)
            ->join('egc_shift_time_log as stl', function ($join) {
                $join->on('stl.staff_id', '=', 'a.staff_id');
            })
            ->join('egc_shift_day_times as sd', function ($join) {
                $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                    ->where('sd.status', 0);
            })
            ->whereRaw("DATE(a.date) BETWEEN stl.start_date AND IFNULL(stl.end_date, '9999-12-31')")
            // ✅ Match day (Mon, Tue...)
            ->whereRaw("LOWER(sd.day_name) = LOWER(DATE_FORMAT(a.date, '%a'))")
            // ✅ Late condition
            // ->whereRaw("TIME(a.in_time) > TIME(sd.time_from)")
            ->whereRaw("TIME(a.in_time) > ADDTIME(sd.time_from, '00:12:00')")
            ->select(
                'a.date',
                'a.attendance',
                's.staff_name',
                'a.in_time',
                'sd.time_from',
                'sd.time_to',
                'a.out_time',
                's.sno as staff_id',
                's.nick_name',
                's.staff_id as employee_id',
                's.staff_image',
                's.gender',
                's.company_type',
                's.company_id',
                's.entity_id',
                'egc_entity.entity_base_color',
                'egc_entity.entity_name',
                'egc_department.department_name',
                'egc_job_role.job_position_name as job_role_name',
                'a.reason as comment_reason',
                'a.reason_id',
                'r.reason_name',
            )->when($search, function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('s.staff_name', 'LIKE', "%{$search}%")
                        ->orWhere('s.staff_id', 'LIKE', "%{$search}%")
                        ->orWhere('s.nick_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_department.department_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search}%")
                        ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search}%");
                });
            });

            if ($entity_id != '') {
            if ($entity_id == 'egc') {
                $history->where('s.entity_id', 0);
            } else {
                $history->where('s.entity_id', $entity_id);
            }
        }

            $today = date('Y-m-d');
        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $history->whereDate('a.date', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $history->whereBetween('a.date', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $history->whereBetween('a.date', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $history->whereBetween('a.date', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $history->where('a.date', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $history->where('a.date', '<=', $toDate);
            }
        }
        $history = $history->orderBy('a.date', 'desc')
            ->paginate(20);

        foreach ($history as $emp) {
            // IMAGE
            if ($emp->gender == 1) {
                $defaultPath = asset('assets/egc_images/auth/user_2.png');
            } else {
                $defaultPath = asset('assets/egc_images/auth/user_7.png');
            }

            if ($emp->company_type == 1) {
                $relativePath = 'staff_images/Management/' . $emp->staff_image;
            } else {
                $relativePath = 'staff_images/Buisness/' . $emp->company_id . '/' . $emp->entity_id . '/' . $emp->staff_image;
            }

            $fullPath = public_path($relativePath);
            $filePath = asset($relativePath);

            $staffImage = ($emp->staff_image && file_exists($fullPath))
                ? $filePath
                : $defaultPath;

            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();
            $emp->entity_name = $emp->entity_name ??  $general_setting->title;
            $emp->entity_base_color = $emp->entity_base_color ?? '#ab2b22';
            $emp->staff_image_url = $staffImage;

            $latesMinutes = 0;
            $workDuration = '-';

            $in = \Carbon\Carbon::parse($emp->in_time);
            $out = $emp->out_time ? \Carbon\Carbon::parse($emp->out_time) : NULL;

            $no_out_punch = 0;
            if ($emp->date != date('Y-m-d')) {
                $no_out_punch = $out ? 0 : 1;
            }
            $emp->no_out_punch = $no_out_punch;

            $minutes = $out ? $in->diffInMinutes($out) : 0;

            $hours = $minutes > 0 ?  floor($minutes / 60) : 0;
            $mins = $minutes > 0 ? $minutes % 60 : 0;

            $workDuration = $hours . 'h ' . $mins . 'm';



            $emp->shift_from = date('h:i A', strtotime($emp->time_from));
            $emp->shift_to = date('h:i A', strtotime($emp->time_to));

            $emp->in_time = $emp->in_time
                ? date('h:i A', strtotime($emp->in_time))
                : '-';

            $emp->out_time = $emp->out_time
                ? date('h:i A', strtotime($emp->out_time))
                : '-';

            $emp->late_minutes = $latesMinutes < 15 ? 0 : $latesMinutes - 15;

            $emp->duration = $workDuration;
        }

        return response()->json([
            'data' => $history,
            'next_page' => $history->hasMorePages()
        ]);
    }

}
