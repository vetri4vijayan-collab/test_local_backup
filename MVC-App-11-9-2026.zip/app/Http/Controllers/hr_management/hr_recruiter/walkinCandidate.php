<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobFairModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\WhatsappTemplateLogModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Illuminate\Support\Facades\File;
use Google\Client;
use Carbon\Carbon;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use Illuminate\Support\Facades\Log;
use thiagoalessio\TesseractOCR\TesseractOCR;
use Illuminate\Support\Facades\Cache;

class walkinCandidate extends Controller
{

   protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
         date_default_timezone_set('Asia/Kolkata');
    }
    
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest = JobFairModel::where('status','!=',2);
      if($search_filter != '') {
          $jobRequest->where(function ($subquery) use ($search_filter) {
              $subquery->where('job_fair_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('job_fair_date', 'LIKE', "%{$search_filter}%")
                  ->orWhere('address', 'LIKE', "%{$search_filter}%");
          });
      }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $jobRequest->whereDate('created_at', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $jobRequest->whereBetween('created_at', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $jobRequest->whereBetween('created_at', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->whereBetween('created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $jobRequest->where('created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->where('created_at', '<=', $toDate);
            }
          }
        $jobRequest=$jobRequest->orderBy('created_at', 'desc')
                ->paginate($perpage);

      $helper = new \App\Helpers\Helpers();

      if ($request->ajax()) {
          $data = $jobRequest->map(function ($item) use ($helper) {

            $applicants_count = ApplicantModel::where('job_fair_id', $item->sno)
                    ->where('status', '!=', 2)
                    ->where('email','!=','vetri4vijayan@gmail.com')
                        ->orderBy('sno','desc')
                    ->count();



            // return $interview_schedule;
              return [
                  'sno' => $item->sno,
                  'status' => $item->status,
                  'job_fair_name' => $item->job_fair_name ?? '-',
                  'job_fair_date' => $item->job_fair_date,
                  'skill_requirements' => $item->skill_requirements,
                  'location_url' => $item->location_url,
                  'address' => $item->address,
                  'description' => $item->description,
                   'applicants_count' => $applicants_count,
                  'data' => $item,
                  'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                  'base_encrypt' => encrypt($item->sno),
                  'qr_encrypt' => encrypt('EGCJOBQR'),
                  'short_encrypt_id' => base64_encode($item->sno),
              ];
          });

          return response()->json([
              'data' => $data,
              'current_page' => $jobRequest->currentPage(),
              'last_page' => $jobRequest->lastPage(),
              'total' => $jobRequest->total(),
          ]);
      }
     $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      return view('content.hr_management.hr_recruiter.job_fair.job_fair', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
          'source_list' => $source_list,
      ]);
  }


  public function Add(Request $request)
    {
        // return $request;
         // --- VALIDATION ---
          $validator = Validator::make($request->all(), [
              'job_fair_name' => 'required|max:255',
          ]);

          if ($validator->fails()) {
              return response([
                  'status'    => 400,
                  'message'   => 'Incorrect format input fields',
                  'error_msg' => $validator->errors(),
                  'data'      => null
              ], 400);
          }

           

            $job_fair_name = $request->job_fair_name;
            $job_fair_date = $request->job_fair_date ? date('Y-m-d', strtotime($request->job_fair_date)) : null;
            $skill_tag = $request->skill_KnowledgeTag ? json_encode($request->skill_KnowledgeTag) : null;
            $address = $request->address ?? null;
            $location_url = $request->location_url ?? null;
            $description = $request->job_description_generate ?? null;

            $user_id = $request->user()->user_id;
            // Check if a job request already exists with the same job role name and closing date
            $chk = JobFairModel::where('job_fair_name', $job_fair_name)
                ->where('job_fair_date', $job_fair_date)
                ->where('status', '!=', 2)
                ->first();

            if ($chk) {
                return response([
                    'status' => 401,
                    'message' => 'Job Fair already exists!',
                    'error_msg' => 'Job Fair with this name and Date already exists!',
                    'data' => null,
                ], 401);
            } else {
                // Generate job request ID
                $category_check = JobFairModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {
                    $year = substr(date('y'), -2);
                    $job_fair_id = 'JOBFR-0001/' . $year;
                } else {
                    $data = $category_check->job_fair_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $job_fair_id = sprintf('JOBFR-%04d', $next_number) . '/' . substr(date('y'), -2);
                }

                // Create a new job request entry
                $add_job_request = new JobFairModel();
                $add_job_request->job_fair_id = $job_fair_id;
                $add_job_request->job_fair_name = $job_fair_name;
                $add_job_request->location_url = $location_url;
                $add_job_request->address = $address;
                $add_job_request->job_fair_date = $job_fair_date;
                $add_job_request->skill_requirements = $skill_tag;
                $add_job_request->description = $description;
                $add_job_request->created_by = $user_id;
                $add_job_request->updated_by = $user_id;

                if ($add_job_request->save()) {

                    return response([
                        'status' => 200,
                        'message' => 'Job Fair created successfully.',
                        'error_msg' => null,
                        // 'data' => $add_job_request,
                    ], 200);
                } else {
                    return response([
                        'status' => 500,
                        'message' => 'Could not create Job Fair.',
                        'error_msg' => 'There was an error while saving the Job Request.',
                        'data' => null,
                    ], 500);
                }
            }
       
    }
 

    public function Status($id, Request $request)
    {
        $last_apply_date = $request->input('last_apply_date');
        $last_apply_date = $last_apply_date ? date('Y-m-d', strtotime($last_apply_date)) : null;
        $upd_LedgerCategoryModel =  JobFairModel::where('sno', $id)->first();
        $upd_LedgerCategoryModel->status = $request->input('status', 0);
        $upd_LedgerCategoryModel->last_apply_date = $last_apply_date;
        $upd_LedgerCategoryModel->update();

        return response([
        'status'    => 200,
        'message'   => 'Successfully Status Updated!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }



    public function Scanner_view(Request $request)
    {
            $search_fill = $request->search_fill ?? '';
            $user_id     = $request->user()->user_id;
            $branch_id   = $request->user()->branch_id;
            $role_id   = $request->user()->role_id;
            $sno = $request->sno ?? '';
            $List_table = JobQRScannerModel::where('egc_job_qr_scanner.job_fair_id',$sno)->select('egc_job_qr_scanner.*','egc_applicant.applicant_name')
            ->leftJoin('egc_applicant', function($join) use ($sno) {
                                $join->on('egc_applicant.ipaddress', '=', 'egc_job_qr_scanner.ipaddress')
                                    ->where('egc_applicant.job_fair_id', '=', $sno); // subquery-like condition
                            })
                    ->orderBy('egc_job_qr_scanner.sno','desc')->get();
        // return $ListTable;
        return view('content.hr_management.hr_recruiter.job_fair.qr_scannerTable', compact('List_table'));
    }


    public function MultiMap(Request $request){
        $sno = $request->sno ?? '';
        $locations = JobQRScannerModel::where('egc_job_qr_scanner.job_fair_id', $sno)
                         ->leftJoin('egc_applicant', function($join) use ($sno) {
                                $join->on('egc_applicant.ipaddress', '=', 'egc_job_qr_scanner.ipaddress')
                                     ->where('egc_applicant.job_fair_id', '=', $sno); // subquery-like condition
                            })
                        ->where('egc_job_qr_scanner.latitude','!=',NULL)
                        ->where('egc_job_qr_scanner.longitude','!=',NULL)
                        ->select('egc_job_qr_scanner.latitude', 'egc_job_qr_scanner.longitude', 'egc_job_qr_scanner.ipaddress as name','egc_applicant.applicant_name') // adjust columns
                        ->get();
        return response()->json($locations);
    }

    public function submitJobApplication(Request $request)
    {
      

       $request->validate([
            'fullName' => 'required',
            'mobile' => 'required',
            'email' => 'required',
            'gender'   => 'required|integer',
            'resume' => 'nullable|max:51200'
        ]);
        try {
        DB::beginTransaction();
            $resumeFile = null;
            $resumeUrl = null;
            $fullName        = $request->fullName;
            $mobile_no       = $request->mobile;
            $email_id        = $request->email;
            $gender          = $request->gender;
            $qualification   = $request->qualification;
            $major           = $request->major;
            $exper_type      = $request->exper_type;
            $exper_count     = $request->exper_count ?? 0;
            $source = 6;

            $ipAddress = $request->ip();
            $resumePath = null;
            $driveData = null;
            $drive_data = null;
            //    return $resumeText;

            // ✅ Candidate check
            $candidate = InterviewCandidateModel::where('mobile', $mobile_no)->first();

            // Check if already applied (active applications only)
            $alreadyApplied = ApplicantModel::where('mobile', $mobile_no)
                ->whereDate('created_at', date('Y-m-d'))
                ->where('status', '!=', 2)
                ->exists();

            if ($alreadyApplied) {
                return response()->json([
                    'status'  => 409,
                    'message' => 'You have already applied Today using this mobile number.',
                ], 409);
            }

            if ($candidate) {
                $candidate_id = $candidate->sno;
            } else {

                $newCandidate = InterviewCandidateModel::create([
                    'full_name' => $fullName,
                    'mobile'    => $mobile_no,
                    'email'     => $email_id,
                ]);

                

                $candidate_id = $newCandidate->sno;
            }

            // ✅ Applicant ID generation
            $lastApplicant = ApplicantModel::orderBy('sno', 'desc')->first();
            $year = date('y');

            if (!$lastApplicant) {
                $applicant_id = "EGCJA-0001-{$year}";
            } else {
                preg_match('/EGCJA-(\d+)/', $lastApplicant->applicant_id, $matches);
                $nextNumber = isset($matches[1]) ? ((int)$matches[1] + 1) : 1;
                $applicant_id = 'EGCJA-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $year;
            }

            if ($request->hasFile('resume')) {

                $file = $request->file('resume');
                $extension = $file->getClientOriginalExtension();

                $folderPath = public_path('job_applications/resume_files/');

                if (!File::exists($folderPath)) {
                    File::makeDirectory($folderPath, 0777, true);
                }

                // Unique filename
                $resumeFile = $applicant_id . '.' . $extension;

                $file->move($folderPath, $resumeFile);
                $filePath = $folderPath . $resumeFile;
                

                if (file_exists($filePath)) {
                    $drive_data = $this->UploadFileInDrive($resumeFile);
                }else{
                    $drive_data = null;
                }
            
                if (file_exists($filePath)) {
                  
                    $resumeText = $this->extractResumeText($filePath);
                }
                else
                {
                    
                    $resumeText = null;
                }

               

                
            }
                    

            // ✅ Save Applicant
            $applicant=ApplicantModel::create([
                'applicant_id'      => $applicant_id,
                'source_id'      => $source,
                'candidate_id'      => $candidate_id,
                'applicant_name'    => $fullName,
                'mobile'            => $mobile_no,
                'email'             => $email_id,
                'attachment'        => $resumeFile,
                'ipaddress'         => $ipAddress ?? null,
                'gender'            => $gender,
                'qualification_id'  => $qualification,
                'major'             => $major,
                'experience_id'     => $exper_type,
                'experience_count'  => $exper_count,
                'resume_text'  => $resumeText,
                'drive_data'        => $drive_data ? json_encode($drive_data) : NULL,
            ]);

                if($applicant){
                    $payload = [
                        'applicant_id'=>$applicant->sno,
                        'stage'=>'Applied',
                        'job_fair_id'=>$applicant->job_fair_id,
                        'interview_stage_id'=> 0,
                        'interview_session_id'=> 0,
                        'staff_id'=> 0,
                        'created_by'=>0,
                        'updated_by'=>0,
                        
                    ];
                    $saveLog = $this->applicantLogCreate($payload);
                }
        
            // ✅ Redirect URL
            $thankScreenUrl = url('/job_application_submitted/' . encrypt($applicant->sno));
            
            DB::commit();

            $whatsappApi = DB::table('egc_api_integration')->where('api_key','egc_whatsapp_meta_api_1')->where('status',0)->orderBy('sno', 'desc')->first();
            if($whatsappApi){
                $apiFields = json_decode($whatsappApi->api_fields, true);
                $WhatsAppBusinessAccountId = '';
                $accessToken = '';
                $fromPhoneNumberId = '';
                foreach ($apiFields as $field) {
                    if ($field['key'] === 'waba_id') {
                        $WhatsAppBusinessAccountId = $field['value'];
                    } elseif ($field['key'] === 'access_token') {
                        $accessToken = $field['value'];
                    } elseif ($field['key'] === 'phone_number_id') {
                        $fromPhoneNumberId = $field['value'];
                    }
                }
                
            }else{
                $WhatsAppBusinessAccountId = '';
                $accessToken = '';
                $fromPhoneNumberId = '';
            }

            if ($applicant->mobile && ($WhatsAppBusinessAccountId && $accessToken && $fromPhoneNumberId)) {
            
              
                  $templateName  = "application_submit";
  
                  $hasHeader  = false; // Example flag: set based on template
                  $hasBody    = false; // Example flag: set based on template
                  $hasFooter  = false; // Example flag: set based on template
                  $hasButton  = false;
                  $components = [];
                  $couponCode = " ";
                  date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                  $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                            // $currentHour = date('H'); // Get current hour in 24-hour format
                  if ($currentHour >= 5 && $currentHour < 12) {
                      $greeting = 'Good Morning';
                  } elseif ($currentHour >= 12 && $currentHour < 18) {
                      $greeting = 'Good Afternoon';
                  } else {
                      $greeting = 'Good Evening';
                  }
  
                  if ($templateName == 'application_submit') {
                      $headerText  = [
                          [
                              'type'           => 'text',
                              'text'           => ',',
                              'parameter_name' => 'com_name',
                          ]
                      ];
                      // $headerImage =  url('public/assets/egc_images/OnBoard.jpg');
                      $couponCode  = 'NOOFFER';
                      $buttonIndex = 1;
                      $bodyText    = [
                          [
                              'type'           => 'text',
                              'text'           => $applicant->applicant_name ?? 'Candidate',
                              'parameter_name' => 'name',
                          ],
                          [
                              'type'           => 'text',
                              'text'           =>  $applicant->applicant_id ?? 'EGCJA-0001-2026',
                              'parameter_name' => 'application_id',
                          ]
                         
                      ];
                      $hasHeader = false;
                      $hasBody   = true;
                      $hasButton = false;
                  }else{
                    // $templateName  = "hello_world";
                    $bodyText = [];
                    $headerText = [];
                    $hasHeader = false;
                    $hasBody = false;
                    $hasFooter = false;
                    $hasButton = false;
                  }

                  
  
                  // Add Header if required
                  if ($hasHeader) {
                      $components[] = [
                          'type'       => 'header',
                          'parameters' => $headerText,
                      ];
                  }
  
                  // Add Body if required
                  if ($hasBody) {
                      $components[] = [
                          'type'       => 'body',
                          'parameters' => $bodyText,
                      ];
                  }
  
                  // Add Footer if required
                  if ($hasButton) {
                      $components[] = [
                          'type'       => 'button',
                          'sub_type'   => 'url',
                          'index'      => 0,
                          'parameters' => [
                              [
                                  'type' => 'text',
                                  'text' => $proposal_key,
                              ],
                          ],
                      ];
                  }
                  
                  
                  $whatsappApi = DB::table('egc_whatsapp_api_configure')->orderBy('sno', 'desc')->first();
                  $dynamicParameters         = $templateParameters[$templateName] ?? [];
                  // $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                  // $accessToken               = $whatsappApi->access_tokken ?? '';
                  // $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                  //  return $dynamicParameters;
                  $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
  
                  $countryCode  =  '+91';
                  $to           = $applicant->mobile;
                  $languageCode = 'en';
                //   $languageCode = 'en';
      
                  if (strpos($to, $countryCode) !== 0) {
                      $to = $countryCode . $to;
                  }
  
                  $message = 'test~message';
                  if (empty($components)) {
                      $payload = [
                          'messaging_product' => 'whatsapp',
                          'to'                => $to,
                          'type'              => 'template',
                          'template'          => [
                              'name'     => $templateName,
                              'language' => [
                                  'code' => $languageCode,
                              ],
                          ],
                      ];
                  } else {
                      $payload = [
                          'messaging_product' => 'whatsapp',
                          'to'                => $to,
                          'type'              => 'template',
                          'template'          => [
                              'name'       => $templateName,
                              'language'   => [
                                  'code' => $languageCode,
                              ],
                              'components' => $components,
                          ],
                      ];
                  }
                  // return $accessToken;
                  $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                if ($response['status'] == 200) {
                        $log_branch_id = 0;
                        $unique_id =$applicant->sno ?? 0;
                        $source ='Candidate';
                        $module_name ='Job Fair';
                        $log_phone_no =$to;
                        $log_template_name =$templateName;

                        $save_log = $this->WhatsappSendLog(
                            $response,
                            $payload,
                            $log_phone_no,
                            $log_template_name,
                            0,
                            $log_branch_id,
                            $unique_id,
                            $source,
                            $module_name
                        );
                }
                else{
                     
                  }
              
            }

            if ($applicant->email) {
                $emailTemplate_id =6; 
                $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
    
                // Gender condition
                $genderPrefix = 'Mr/Ms'; // Default value
                // if ($lead->lead_gender == 1) {
                //   $genderPrefix = 'Mr';
                // } elseif ($lead->lead_gender == 2) {
                //   $genderPrefix = 'Ms';
                // }
                $helper = new \App\Helpers\Helpers();
                $branch = $helper->general_setting_data();
                $baseURL= url('/');
                $content = $emailTemplate->email_subject;
                $hr_mobile = $branch->hr_head_no;
                $hr_email = $branch->hr_head_mail_id;
                $socialMediaDetails = json_decode($branch->social_media_details, true);
                $socialMediaList = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();

                $facebook_link = null;
                $instagram_link = null;
                $twitter_link = null;
                $linkedin_link = null;
                $youtube_link = null;
                $pinterest_link = null;

                foreach ($socialMediaList as $socialMedia) {
                  $sno = $socialMedia->sno;

                  if (isset($socialMediaDetails[$sno])) {
                      $url = $socialMediaDetails[$sno];
                      switch ($socialMedia->social_media_name) {
                          case 'Instagram':
                              $instagram_link = $url;
                              break;
                          case 'Facebook':
                              $facebook_link = $url;
                              break;
                          case 'Twitter':
                              $twitter_link = $url;
                              break;
                          case 'LinkedIn':
                              $linkedin_link = $url;
                              break;
                          case 'YouTube':
                              $youtube_link = $url;
                              break;
                          case 'Pinterest':
                              $pinterest_link = $url;
                              break;
                      }
                  }
                }
                $interview_date = date('d-M-Y', strtotime('+3 days'));
                $dynamicSubject = str_replace('#com_name', 'Elysium Groups', $emailTemplate->email_name);

                $content = str_replace('#name', $applicant->applicant_name ?? 'Candidate', $content);
                $content = str_replace('#application_id', $applicant->applicant_id ?? 'EGCJA-0001-2026', $content);
                $content = str_replace('#company_name',  'Elysium Groups', $content);
                $branchNo = $branch->hr_head_no;
                $branchemail = $branch->hr_head_mail_id;
                $fbLink = $facebook_link ?? 'https://www.facebook.com/PhDiZone/';
                $instaLink = $instagram_link ?? 'https://www.instagram.com/phdizoneresearch/';
                $url= 'www.elysiumgroup.com';
        
                $mailData = [
                      'url'         => $url,
                      'subject'     => $dynamicSubject,
                      'content'     => $content,
                      'branchNo'    => $hr_mobile,
                      'branchemail' => $hr_email, // Use the message content from the request
                      'fbLink'      => $fbLink,      // Use the message content from the request
                      'instaLink'   => $instaLink,   // Use the message content from the request
                      'salesMobile' => $hr_mobile ?? '8220011465',
                  ];
        
                $to_address = $applicant->email;
                $from_address = 'elysiumgroups@elysium.community';
                $from_name =  'Elysium Groups';
        
                  // return $mailData;
                Mail::to($to_address)->send(new EGCMail($mailData, $from_address, $from_name));
               

            }

            
            return response()->json([
                'status'         => 200,
                'message'        => 'Registration submitted successfully!',
                'redirect'       => $thankScreenUrl,
                'application_id' => encrypt($applicant->sno),
            ]);
        } catch (\Exception $e) {

            DB::rollBack();
            Log::error('Job Application Error: ' . $e->getMessage());

            return response()->json([
                'status'  => 500,
                'error' => $e->getMessage(),
                'message' => 'Something went wrong. Please try again later.',
            ], 500);
        }
    }


    public function submitJobApplicationg(Request $request)
    {
        $validated = $request->validate([
            'fullName'       => 'required|string|max:255',
            'mobile'         => 'required|digits_between:8,15',
            'email'          => 'required|email|max:255',
            'gender'         => 'required|integer',
            'job_fair_id'    => 'required|integer',
            'qualification'  => 'nullable|integer',
            'major'          => 'nullable|string|max:255',
            'exper_type'     => 'nullable|integer',
            'exper_count'    => 'nullable|integer|min:0|max:50',
            'resume'         => 'nullable|file|mimes:pdf,doc,docx|max:5120', // 5MB
        ]);

        try {
            DB::beginTransaction();

            $alreadyApplied = ApplicantModel::where('mobile', $validated['mobile'])
                ->where('job_fair_id', $validated['job_fair_id'])
                ->where('status', '!=', 2)
                ->lockForUpdate()
                ->exists();

            if ($alreadyApplied) {
                return response()->json([
                    'status'  => 409,
                    'message' => 'You have already applied for this job.',
                ], 409);
            }

            // ✅ Create or fetch candidate
            $candidate = InterviewCandidateModel::firstOrCreate(
                ['mobile' => $validated['mobile']],
                [
                    'full_name' => $validated['fullName'],
                    'email'     => $validated['email']
                ]
            );

            // ✅ Generate Applicant ID safely
            $year = date('y');
            $lastApplicant = ApplicantModel::lockForUpdate()->orderByDesc('sno')->first();

            $nextNumber = 1;
            if ($lastApplicant && preg_match('/EGCJA-(\d+)-/', $lastApplicant->applicant_id, $matches)) {
                $nextNumber = (int)$matches[1] + 1;
            }

            $applicant_id = 'EGCJA-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $year;

            // ✅ Handle Resume Upload (local storage)
            $resumePath = null;
            $driveData = null;

            if ($request->hasFile('resume')) {

                $resumePath = $request->file('resume')
                    ->storeAs(
                        'job_applications/resumes',
                        $applicant_id . '.' . $request->file('resume')->getClientOriginalExtension(),
                        'private' // use private disk
                    );

                try {
                    $driveData = $this->UploadFileInDrive(basename($resumePath));
                } catch (\Exception $e) {
                    Log::error('Drive upload failed: ' . $e->getMessage());
                }
            }

            // ✅ Save Applicant
            $applicant = ApplicantModel::create([
                'applicant_id'      => $applicant_id,
                'candidate_id'      => $candidate->sno,
                'applicant_name'    => $validated['fullName'],
                'job_fair_id'       => $validated['job_fair_id'],
                'mobile'            => $validated['mobile'],
                'email'             => $validated['email'],
                'attachment'        => $resumePath,
                'ipaddress'         => $request->ip(),
                'gender'            => $validated['gender'],
                'qualification_id'  => $validated['qualification'] ?? null,
                'major'             => $validated['major'] ?? null,
                'experience_id'     => $validated['exper_type'] ?? null,
                'experience_count'  => $validated['exper_count'] ?? 0,
                'drive_data'        => $driveData ? json_encode($driveData) : null,
            ]);
            if($applicant){
                $payload = [
                    'applicant_id'=>$applicant->sno,
                    'stage'=>'Applied',
                    'job_fair_id'=>$applicant->job_fair_id,
                    'interview_stage_id'=> 0,
                    'interview_session_id'=> 0,
                    'staff_id'=> 0,
                    'created_by'=>0,
                    'updated_by'=>0,
                    
                ];
                $saveLog = $this->applicantLogCreate($payload);
            }
             

            DB::commit();


           
            if ($applicant->email) {
                $stages = InterviewScheduleStageModel::select(
                            'egc_interview_schedule_stage.*',
                            'egc_interview_category.interview_category_name',
                            'egc_interview_mode.interview_mode_name',
                    )
                    ->join('egc_interview_schedule', 'egc_interview_schedule_stage.interview_schedule_id', 'egc_interview_schedule.sno')
                    ->where('egc_interview_schedule.job_request_id', $applicant->job_request_id)
                    ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
                    ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
                    ->orderBy('stage_order','asc')
                    ->first();

                $emailTemplate_id =3; 
                $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
    
                // Gender condition
                $genderPrefix = 'Mr/Ms'; // Default value
                // if ($lead->lead_gender == 1) {
                //   $genderPrefix = 'Mr';
                // } elseif ($lead->lead_gender == 2) {
                //   $genderPrefix = 'Ms';
                // }
                $helper = new \App\Helpers\Helpers();
                $branch = $helper->general_setting_data();
                $baseURL= url('/');
                $content = $emailTemplate->email_subject;
                $hr_mobile = $branch->hr_head_no;
                $hr_email = $branch->hr_head_mail_id;
                $socialMediaDetails = json_decode($branch->social_media_details, true);
                $socialMediaList = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();

                $facebook_link = null;
                $instagram_link = null;
                $twitter_link = null;
                $linkedin_link = null;
                $youtube_link = null;
                $pinterest_link = null;

                foreach ($socialMediaList as $socialMedia) {
                  $sno = $socialMedia->sno;

                  if (isset($socialMediaDetails[$sno])) {
                      $url = $socialMediaDetails[$sno];
                      switch ($socialMedia->social_media_name) {
                          case 'Instagram':
                              $instagram_link = $url;
                              break;
                          case 'Facebook':
                              $facebook_link = $url;
                              break;
                          case 'Twitter':
                              $twitter_link = $url;
                              break;
                          case 'LinkedIn':
                              $linkedin_link = $url;
                              break;
                          case 'YouTube':
                              $youtube_link = $url;
                              break;
                          case 'Pinterest':
                              $pinterest_link = $url;
                              break;
                      }
                  }
                }
                $interview_date = date('d-M-Y', strtotime('+3 days'));
                $dynamicSubject = str_replace('#otp', '000000', $emailTemplate->email_name);

                $content = str_replace('#candidate_name', $applicant->applicant_name ?? 'Candidate', $content);
                $content = str_replace('#interview_type', $stages->interview_category_name ?? 'Preliminary', $content);
                $content = str_replace('#interview_mode', $stages->interview_mode_name ?? 'Video', $content);
                $content = str_replace('#interview_date',$interview_date ?? '-' , $content);
                $content = str_replace('#interview_link',$stages->shareLink ?? '#', $content);
                $content = str_replace('#hr_contact',  $hr_mobile ?? '8220011465', $content);
                $content = str_replace('#hr_email',  $hr_email ?? 'hrelysiumgroups@gmail.com', $content);
                $branchNo = $branch->hr_head_no;
                $branchemail = $branch->hr_head_mail_id;
                $fbLink = $facebook_link ?? 'https://www.facebook.com/PhDiZone/';
                $instaLink = $instagram_link ?? 'https://www.instagram.com/phdizoneresearch/';
                $url= 'www.elysiumgroup.com';
        
                $mailData = [
                      'url'         => $url,
                      'subject'     => $dynamicSubject,
                      'content'     => $content,
                      'branchNo'    => $hr_mobile,
                      'branchemail' => $hr_email, // Use the message content from the request
                      'fbLink'      => $fbLink,      // Use the message content from the request
                      'instaLink'   => $instaLink,   // Use the message content from the request
                      'salesMobile' => $hr_mobile ?? '8220011465',
                  ];
        
                $to_address = $applicant->email;
                $from_address = 'elysiumgroups@elysium.community';
                $from_name =  'Elysium Groups ';
        
                  // return $mailData;
                Mail::to($to_address)->send(new EGCMail($mailData, $from_address, $from_name));
               

            }

            return response()->json([
                'status'         => 200,
                'message'        => 'Your application has been submitted successfully!',
                'redirect'       => route('job.application.submitted', encrypt($applicant->sno)),
                'application_id' => encrypt($applicant->sno),
            ]);

        } catch (\Exception $e) {

            DB::rollBack();
            Log::error('Job Application Error: ' . $e->getMessage());

            return response()->json([
                'status'  => 500,
                'error' => $e->getMessage(),
                'message' => 'Something went wrong. Please try again later.',
            ], 500);
        }
    }



    public function applicationSubmitted($id)
    {
        try {
            $decodeId = decrypt($id);

           $applicant = ApplicantModel::orderBy('sno', 'desc')->where('sno', $decodeId)->first();
           $jobfair = JobFairModel::where('status','!=',2)->where('sno',$applicant->job_fair_id)->first();

            return view(
                'content.hr_management.hr_recruiter.job_fair.form_submit_thanku',
                [
                    'jobfair'   => $jobfair,
                    'applicant' => $applicant
                ]
            );

        } catch (\Exception $e) {
            abort(404);
        }
    }

    private function UploadFileInDrive($attachment)
    {
        $uploadedFiles = [];
        $errors = [];

        if (!$attachment) {
            return ['error' => 'No attachment provided'];
        }

        $filePath = public_path('job_applications/resume_files/' . $attachment);

        // Check if the file exists on the server
        if (!file_exists($filePath)) {
            $errors[] = [
                'attachment' => $attachment,
                'error' => 'File not found on server'
            ];
            return ['errors' => $errors];  // Return errors in case file is not found
        }

        try {
            $uploadedFile = new UploadedFile(
                $filePath,
                $attachment,
                mime_content_type($filePath),
                null,
                true
            );

            // Upload the file to Google Drive
            $driveFile = $this->googleDriveService->upload(
                $uploadedFile,
                env('GOOGLE_DRIVE_FOLDER_ID') // Folder ID is taken from .env
            );

            // Check if the file was uploaded successfully
            if ($driveFile) {
                $uploadedFiles = [
                    'file_name' => $driveFile->name,
                    'file_id' => $driveFile->id,
                    'webViewLink' => $driveFile->webViewLink ?? null
                ];
            } else {
                $errors[] = ['error' => 'Google Drive upload failed'];
            }
        } catch (\Exception $e) {
            // Catch any exception during the upload process
            $errors[] = ['error' => 'Error uploading file to Google Drive: ' . $e->getMessage()];
        }

        // If there are errors, return them; otherwise, return the uploaded file details
        if (!empty($errors)) {
            return ['errors' => $errors];
        }

        return $uploadedFiles;
    }




     public function generateQrJob(Request $request)
  {
      // Encode sno in base64 (shorter than Crypt)
     
      $encodedcode = encrypt('EGCJOBQR');
  
      
      $qrContent = url("/job_resume_application/{$encodedcode}");
      // 'https://erp.elysium.community/job_application_qr';
  
      // Generate QR as base64 image
      $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=1000x1000";
      $qrImageData = @file_get_contents($qrServerUrl);
      $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
      // Save scan details
      
  
      return response()->json([
          'status'    => $qrBase64 ? 200 : 500,
          'qr_base64' => $qrBase64,
          'link'      => $qrContent,
      ]);
  }
    
  private function saveScanDetails($job_request_id,Request $request)
  {
      // Get the user's IP address
      $ipAddress = $request->ip();
  
      // Get latitude and longitude if provided by frontend (JavaScript geolocation)
      $latitude = $request->input('latitude', null);
      $longitude = $request->input('longitude', null);
  
      // Get area from IP address (you can use any IP geolocation API)
      // $area = $this->getAreaByIp($ipAddress);
      $area="";
      // Get device information (User-Agent string)
      $deviceInfo = $request->header('User-Agent');
      $isMobile = preg_match('/Mobile|Android|iP(hone|od|ad)|IEMobile|BlackBerry|Opera Mini/i', $deviceInfo);
              
      $deviceType = $isMobile ? 'Mobile' : 'Desktop';
  
      // Insert the scan data into the database
      JobQRScannerModel::create([
          'job_fair_id'      => $job_request_id,
          'ipaddress' => $ipAddress,
          'latitude'   => $latitude,
          'longitude'  => $longitude,
          'area'       => $area,
          'device'=> $deviceType,
      ]);
  }


  
   

   public function jobCommonApplication($id=null,Request $request)
  {
        $decodeId = decrypt($id);
        $isfrom_qr = 0; 

        $scanTracked = session('job_common_scan_tracked_' . $decodeId);
        // if (!$scanTracked) {
           
        //     $this->saveScanDetails($decodeId, $request);

        //     session(['job_common_scan_tracked_' . $decodeId => true]);
        // }
   

      $jobfair = Null;

    return view('content.hr_management.hr_recruiter.walkin_candidate.job_application_form',compact('jobfair','isfrom_qr'));
  }

   


    public function shortenUrl($longUrl,$channelId)
    {
        $response = Http::withToken('aFLQFlykraqpANsi')
            ->post('https://chotta.link/api/url/add', [
                'url' => $longUrl
            ]);
    
        if ($response->successful() && isset($response['shorturl'])) {
            
            $shortUrl = $response['shorturl'];
            $urlId =$response['id'];
            
            $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

            $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
    
            if ($assignResponse->successful()) {
                return $response; // success
            }
        }
        
    
        return null;
    }

    

    public function preview(Request $request, string $fileId)
    {
        return $this->googleDriveService->streamFile($fileId);
    }

    private function applicantLogCreate($payload){

            $applicant=ApplicantLogModel::create([
                'applicant_id'      => $payload['applicant_id'],
                'stage'      => $payload['stage'],
                'job_fair_id'    => $payload['job_fair_id'],
                'interview_stage_id'       => $payload['interview_stage_id'],
                'interview_session_id'       => $payload['interview_session_id'],
                'staff_id'            => $payload['staff_id'],
                'updated_by'             => $payload['updated_by'],
                'created_by'        => $payload['created_by'],
            ]);
    }


     public function ApplyCandidateListByJob(Request $request){

        $job_request_id = $request->input('request_id');
        $decodeId = base64_decode($job_request_id);

        $applicants = ApplicantModel::where('egc_applicant.job_fair_id', $decodeId)
                        ->join('egc_major', 'egc_applicant.major', 'egc_major.sno')
                        ->where('egc_applicant.status', '!=', 2)
                        ->where('egc_applicant.email','!=','vetri4vijayan@gmail.com')
                        ->select(
                            'egc_applicant.*',
                            'egc_major.major_name',
                        )
                        ->orderBy('egc_applicant.sno','desc')
                        ->get();

        return response([
        'status'    => 200,
        'message'   => 'Successfully Fetched!',
        'error_msg' => null,
        'data'      => $applicants,
        ], 200);
    }


    private function WhatsappSendLog(
            array $response,
            array $payload,
            string $phone_no,
            string $template_name,
            int $user_id,
            int $branch_id = 0,
            int $unique_id = 0,
            ?string $source = null,
            ?string $module_name = null,
        ) {
            $messageId = $response['data']['messages'][0]['id'] ?? null;

            return WhatsappTemplateLogModel::create([
                'phone_no' => $phone_no,
                'entity_id' => $branch_id,
                'unique_id' => $unique_id,
                'id_source' => $source,
                'module_name' => $module_name,
                'template_name' => $template_name,
                'message_date_time' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                'type' => 'template',
                'from' => 1,
                'wama_id' => $messageId,
                'payload' => json_encode($payload),
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'message_status' => 'sent',
            ]);
        }

         private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }

  private function extractResumeText(string $filePath): string
    {

        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

        $text = '';
        // return $extension;
        try {

            /* ===== PDF ===== */
            if ($extension === 'pdf') {
                $parser = new PdfParser();
                $pdf = $parser->parseFile($filePath);
                $text = $pdf->getText();

                // 🔥 If empty → OCR fallback
                if (strlen(trim($text)) < 50) {
                    $text = $this->extractPdfWithOCR($filePath);
                }
            }

            /* ===== DOC / DOCX ===== */
            if (in_array($extension, ['doc', 'docx'])) {

                $phpWord = IOFactory::load($filePath);

                foreach ($phpWord->getSections() as $section) {
                    foreach ($section->getElements() as $element) {

                        if (method_exists($element, 'getText')) {
                            $text .= $element->getText() . ' ';
                        }

                        if (method_exists($element, 'getElements')) {
                            foreach ($element->getElements() as $child) {
                                if (method_exists($child, 'getText')) {
                                    $text .= $child->getText() . ' ';
                                }
                            }
                        }
                    }
                }
            }
            if (in_array($extension, ['jpg', 'jpeg', 'png',])) {
                $text = $this->extractTextWithOCR($path);
            }
        } catch (\Exception $e) {
            \Log::error('Resume extraction failed: ' . $e->getMessage());
        }

        // Cleanup text
        return trim(preg_replace('/\s+/', ' ', $text));
    }
   
    private function extractTextWithOCR($filePath)
    {
        try {
            return (new TesseractOCR($filePath))
                ->lang('eng')
                ->psm(6) // 🔥 Better layout detection
                ->run();
        } catch (\Exception $e) {
            \Log::error('OCR Error: ' . $e->getMessage());
            return '';
        }
    }

    private function pdfToImages($path)
    {
        $images = [];
        $outputDir = storage_path('app/ocr/');

        if (!file_exists($outputDir)) {
            mkdir($outputDir, 0777, true);
        }

        $output = $outputDir . uniqid();

        // Convert PDF to PNG images
        shell_exec("pdftoppm -png " . escapeshellarg($path) . " $output");

        foreach (glob($output . "*.png") as $img) {
            $images[] = $img;
        }

        return $images;
    }
    private function extractPdfWithOCR($path)
    {
        $text = '';

        $images = $this->pdfToImages($path);

        foreach ($images as $img) {
            $text .= ' ' . $this->extractTextWithOCR($img);
            unlink($img);
        }

        return $text;
    }

}