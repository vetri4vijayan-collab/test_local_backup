<?php
namespace App\Http\Controllers\control_panel\cug_management;

use App\Http\Controllers\Controller;
use App\Models\ManageTeamModel;
use App\Models\LeadModel;
use App\Models\BranchModel;
use App\Models\LeadTransferLogModel;
use App\Models\SpamReasonModel;
use App\Models\CallTrackerModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use Illuminate\Support\Facades\Cache;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Log;

class CallerPilotMoniter extends Controller
{

    public function index(Request $request){

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $branch_id = $request->user()->branch_id ;
        $user_id = $request->user()->user_id;

        $call_fill        = $request->input('search_filter', '');
        $staff_fill       = $request->input('staff_fill', '');
        $status_fill      = $request->input('status_fill', '');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');

        $monthFilter = $request->get('month_filter', now()->format('M-Y'));
        try {
            $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        } catch (\Exception $e) {
            $parsedDate = now()->startOfMonth();
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        }


        $helper = new \App\Helpers\Helpers();
    
        if ($request->ajax()) {

            $idQuery = DB::table('egc_call_tracker as ct')
                    ->select('ct.sno')
                    ->whereIn('ct.call_status',[0,1,2,3,4]);

            if (!$from_date_filter && !$to_date_filter) {
                $start = Carbon::create($year,$month,1)->startOfMonth();
                $end = Carbon::create($year,$month,1)->endOfMonth();
                $idQuery->whereBetween('ct.call_start_date',[$start,$end]);
            }else{
                $idQuery->whereBetween('ct.call_start_date', [$from_date_filter,$to_date_filter]);
            }

            // if(auth()->user()->hasPermissionradio('Lead Management','Manage Calls','view_self_lead')){
            //     $idQuery->where('ct.branch_staff_id',$user_id);
            // }

            if($staff_fill!=''){
                $idQuery->where('ct.branch_staff_id', $staff_fill );
            }

            if ($status_fill) {
                $idQuery->where('ct.call_status', $status_fill);
            }elseif ($status_fill === '0') {
                $idQuery->where('ct.call_status', $status_fill);
            }

            if($call_fill!=''){
                $idQuery->where(function($q)use($call_fill){
                    $q->where('ct.customer_phone_no','like',"%{$call_fill}%")
                    ->orWhere('ct.staff_phone_no','like', "%{$call_fill}%")
                    ->orWhere('ct.customer_name','like',"%{$call_fill}%");
                });
            }

            $ids=$idQuery
                ->orderByDesc('ct.call_start_date')
                ->orderByDesc('ct.call_start_time')
                ->paginate($perpage,['ct.sno']);

           

            $callIds=$ids->pluck('sno')->toArray();

            //  return $callIds;


            $calls = DB::table('egc_call_tracker as ct')
                    ->select(
                        'ct.sno',
                        'ct.call_status',
                        'ct.staff_phone_no',
                        'ct.customer_name',
                        'ct.customer_phone_no',
                        'ct.call_start_date',
                        'ct.call_start_time',
                        'ct.call_end_time',
                        'ct.call_duration',
                        'ct.latitude',
                        'ct.longitude',
                        'ct.audio_file',

                        'commun_staff.staff_name as communicator_staff_name',
                        'commun_staff.status as staff_status',

                        's.staff_name',
                        'cug_staff.staff_name as internal_user_name'
                    )
                    ->join('egc_staff as s','s.sno','=','ct.branch_staff_id')
                    ->leftJoin('egc_call_contacts','egc_call_contacts.sno','=','ct.contact_id')
                    ->leftJoin('egc_staff as commun_staff', function ($join) {
                        $join->on(
                            DB::raw('BINARY commun_staff.mobile_no'),
                            '=',
                            DB::raw('BINARY RIGHT(ct.customer_phone_no, 10)')
                        );
                    })

                    ->leftJoin('egc_cug_numbers as ic', function ($join) {
                        $join->on(
                            DB::raw('BINARY ic.cug_number'),
                            '=',
                            DB::raw('BINARY RIGHT(ct.customer_phone_no, 10)')
                        );
                    })
                    ->leftJoin('egc_cug_assignments as cuga', function ($join) {
                        $join->on('cuga.cug_id', '=', 'ic.sno');
                    })
                    ->leftJoin('egc_staff as cug_staff', function ($join) {
                        $join->on('cug_staff.sno', '=', 'cuga.staff_id');
                    })
                    ->whereIn('ct.sno',$callIds )
                    ->orderByDesc('ct.call_start_date')
                    ->orderByDesc('ct.call_start_time')
                    ->get();

                $calls = new LengthAwarePaginator(
                            $calls,
                            $ids->total(),
                            $ids->perPage(),
                            $ids->currentPage(),
                            [
                                'path'=>request()->url(),
                                'query'=>request()->query()
                            ]
                        );

            
                
        
            $staffPhones = $calls->pluck('staff_phone_no')->filter()->unique()->values();

             $monthStart = Carbon::create($year, $month, 1)->startOfMonth();
            $monthEnd   = Carbon::create($year, $month, 1)->endOfMonth();

            $cacheKey = 'manage_calls_dashboard_' .
            $branch_id . '_' .
            $user_id . '_' .
            $month . '_' .
            $year . '_' .
            $staff_fill . '_' .
            $status_fill;

            $call_counts = Cache::remember(
                $cacheKey,
                now()->addMinutes(2),
                function () use (
                    $branch_id,
                    $user_id,
                    $staff_fill,
                    $status_fill,
                    $from_date_filter,
                    $to_date_filter,
                    $monthStart,
                    $monthEnd
                ) {

                    $query = DB::table('egc_call_tracker')
                        ->selectRaw("
                            COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                            COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                            COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                            COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                            COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                        ");

                    if (!$from_date_filter && !$to_date_filter) {

                        $query->whereBetween(
                            'call_start_date',
                            [$monthStart, $monthEnd]
                        );

                    } else {

                        $query->whereBetween(
                            'call_start_date',
                            [$from_date_filter, $to_date_filter]
                        );

                    }

                    if (auth()->user()->hasPermissionradio('Lead Management','Manage Calls','view_self_lead')) {
                        $query->where('branch_staff_id',$user_id);
                    }

                    if ($staff_fill != '') {
                        $query->where('branch_staff_id',$staff_fill);
                    }

                    if ($status_fill) {
                        $query->where('call_status', $status_fill);
                    }elseif ($status_fill === '0') {
                        $query->where('call_status', $status_fill);
                    }

                    

                    return $query->first();
                }
            );
        
            $incoming_call_count = (int) ($call_counts->incoming_call_count ?? 0);
            $outgoingcall_count  = (int) ($call_counts->outgoing_call_count ?? 0);
            $missedcall_count    = (int) ($call_counts->missedcall_count ?? 0);
            $rejected_call_count = (int) ($call_counts->rejected_call_count ?? 0);
            $dialedcall_count    = (int) ($call_counts->dialedcall_count ?? 0);
        
            $missed_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count > 0)
                ? ($missedcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count)) * 100
                : 0;
        
            $outgoing_call_ratio = ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count > 0)
                ? ($outgoingcall_count / ($incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count + $dialedcall_count)) * 100
                : 0;
        
                //  $loginData = DB::connection('mysql_secondary')
                //     ->table('user as u')
                //     ->select('u.phone_no', 'u.last_sync_date', 'u.last_sync_time')
                //     ->whereIn('u.phone_no', $staffPhones)
                //     ->get()
                //     ->keyBy('phone_no');
            $lastLoginDataMap = [];

            if (!empty($staffPhones)) {

                $lastLoginDataMap = DB::table('mobile_user_login_logs as l')
                    ->select(
                        'l.mobile_no',
                        'l.login_at'
                    )
                    ->join(
                        DB::raw("
                            (
                                SELECT
                                    mobile_no,
                                    MAX(login_at) AS last_login
                                FROM mobile_user_login_logs
                                WHERE type = 0
                                GROUP BY mobile_no
                            ) latest
                        "),
                        function ($join) {
                            $join->on('latest.mobile_no', '=', 'l.mobile_no')
                                ->on('latest.last_login', '=', 'l.login_at');
                        }
                    )
                    ->whereIn('l.mobile_no', $staffPhones)
                    ->get()
                    ->keyBy('mobile_no');
            }

            $data = $calls->map(function ($item) use ($helper) {

                // Call icon
                switch ($item->call_status) {
                    case 0:
                        $bgColor = "";
                        $img = "outgoing_call.png";
                        break;
                    case 1:
                        $bgColor = "";
                        $img = "incoming_call.png";
                        break;
                    case 2:
                        $bgColor = "#ffcf9f";
                        $img = "missed_call.png";
                        break;

                    case 3:
                        $bgColor = "#FF7979";
                        $img = "rejected_call.png";
                        break;
                    default:
                        $bgColor = "";
                        $img = "dialed_call.png";
                }

               $lastLogin = $lastLoginDataMap[$item->staff_phone_no] ?? null;

                $lastLoginDate = null;
                $lastLoginTime = null;
                $duration = '';

                if ($lastLogin && $lastLogin->login_at) {

                    $loginAt = Carbon::parse($lastLogin->login_at);

                    $lastLoginDate = $loginAt->format('Y-m-d');

                    $lastLoginTime = $loginAt->format('H:i:s');

                    $duration = $loginAt->diffForHumans([
                        'parts' => 2,
                        'short' => true,
                    ]);
                }

                $audioSize = '';

                if (!empty($item->audio_file)) {
                    $path = public_path('call_audios/'.$item->audio_file);
                    if (file_exists($path)) {
                        $bytes = filesize($path);
                        if ($bytes >= 1048576) {
                            $audioSize = round($bytes / 1048576, 2).' MB';
                        } else {
                            $audioSize = round($bytes / 1024, 2).' KB';
                        }
                    }
                }

                return [
                    'sno' => $item->sno,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),

                    'bgColor' => $bgColor,
                    'img' => $img,
                    'audio_size' => $audioSize,
                    'last_login_date' => optional($lastLogin)->last_sync_date,
                    'last_login_time' => optional($lastLogin)->last_sync_time,
                    // 'duration' => $this->getDuration(optional($lastLogin)->last_sync_date, optional($lastLogin)->last_sync_time),
                    'duration' => '',

                    'data' => $item,
                ];
            });

            $month_name=Carbon::createFromFormat('m', $month)->format('F');

            return response()->json([
                'data' => $data,
                'current_page' => $calls->currentPage(),
                'last_page' => $calls->lastPage(),
                'total' => $calls->total(),
                'incoming_call_count' => $incoming_call_count,
                'outgoingcall_count'  => $outgoingcall_count,
                'missedcall_count'    => $missedcall_count,
                'rejected_call_count' => $rejected_call_count,
                'dialedcall_count'    => $dialedcall_count,
                'missed_call_ratio'   => $missed_call_ratio,
                'outgoing_call_ratio' => $outgoing_call_ratio,
                'month_name' => $month_name,
            ]);
        }

    
            $staff_list = Cache::remember("staff_list_branch", 300, function () use($branch_id){
                return DB::table('egc_cug_assignments')
                    ->select(
                        'egc_cug_assignments.staff_id',
                        'egc_staff.staff_name',
                        'egc_staff.nick_name',
                        'egc_staff.staff_image',
                        'egc_staff.gender',
                        'egc_cug_numbers.cug_number',
                        'egc_department.department_name'
                    )
                    ->join('egc_cug_numbers', 'egc_cug_numbers.sno', '=', 'egc_cug_assignments.cug_id')
                    ->join('egc_staff', 'egc_staff.sno', '=', 'egc_cug_assignments.staff_id')
                    ->leftJoin('egc_department', 'egc_department.sno', '=', 'egc_staff.department_id')
                    ->where('egc_staff.status', '!=', 2)
                    ->where('egc_cug_assignments.status', 0)
                    ->distinct()
                    ->get();
            });
        
       

        return view('content.control_panel.cug_management.callerpilot_moniter.call_list',[
            'perpage' => $perpage,
            'staff_list' => $staff_list,
        ]);
    }

    //staff_list
    public function StaffList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $dept_id   = $request->input('dept_id');
        $staff     = StaffModel::where('egc_staff.status', '!=', 2)->join('egc_team', 'egc_staff.sno', '=', 'egc_team.', 'left');
        // ->where('branch_id', $branch_id)
        if ($branch_id != 0) {
            $staff->where('egc_staff.branch_id', $branch_id);
        }
        $staff = $staff->orderBy('egc_staff.staff_name', 'asc')
            ->distinct() // Ensure unique rows
            ->get();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $staff,
        ], 200);
    }

    public function getCallHistory(Request $request)
    {
        $leadId = $request->lead_id;
        $status = $request->status;


        $caller = DB::table('egc_lead')->select('egc_lead.*')
        ->where('egc_lead.sno', $leadId)
        ->first();

        $lead_mobile =$caller->lead_mobile;
        $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;
        // return $phoneWithCountryCode ;

       $calls = DB::table('egc_call_tracker')
                ->select('egc_call_tracker.*', 'egc_staff.staff_name')
                ->join('egc_staff', 'egc_staff.sno', '=', 'egc_call_tracker.branch_staff_id')
                ->where(function($query) use ($lead_mobile, $phoneWithCountryCode) {
                    $query->where('customer_phone_no', $lead_mobile)
                          ->orWhere('customer_phone_no', $phoneWithCountryCode);
                })
                ->where('count_status', 1);

                if ($status == "Incoming") {
                    $calls->where('egc_call_tracker.call_status', 1);
                } elseif ($status == "Outgoing") {
                    $calls->where('egc_call_tracker.call_status', 0);
                } elseif ($status == "Dialed") {
                    $calls->where('egc_call_tracker.call_status', 4);
                } elseif ($status == "Missed & Rejected") {
                    $calls->whereIn('egc_call_tracker.call_status', [2, 3]);
                }
                
                $calls = $calls->orderBy('egc_call_tracker.sno', 'desc')->get();
          

        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
            'status'=> $status,
        ]);
    }

    public function staffCallHistory(Request $request)
    {
        $staff_id = $request->staff_id;
        $year = $request->year;
        $month = $request->month;
    

        $caller = DB::table('egc_staff')->select('egc_staff.*')
        ->where('egc_staff.sno', $staff_id)
        ->first();

        $calls = DB::table('egc_call_tracker')->select('egc_call_tracker.*')
            ->where('egc_call_tracker.branch_staff_id', $staff_id)
            ->whereYear('egc_call_tracker.call_start_date', $year)
            ->whereMonth('egc_call_tracker.call_start_date', $month)
            ->orderBy('egc_call_tracker.sno', 'desc')->get();  

        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
        ]);
    }
    

    public function getCallHistoryCustomer(Request $request)
    {
        $customerId = $request->lead_id;
        $status = $request->status;

        $caller = DB::table('egc_customer')->select('egc_customer.*')
        ->where('egc_customer.sno', $customerId)
        ->first();
        $cus_mobile =$caller->cus_mobile;
        $normalizedPhoneNo    = ltrim($cus_mobile, '0');   // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;
        // return $phoneWithCountryCode ;
          $cug_numbers = DB::table('egc_cug_management')
            ->select('egc_cug_management.*')
            ->join('egc_staff', 'egc_staff.sno', '=', 'egc_cug_management.staff_id')
            ->where('egc_staff.department_id', 2)
            ->orderBy('egc_cug_management.sno', 'desc')
            ->get();
            
                    // Get only mobile numbers as array
                $cugMobiles = $cug_numbers->pluck('staff_mobile')->toArray();
        // return $cugMobiles;
        $calls = DB::table('egc_call_tracker')
            ->select('egc_call_tracker.*', 'egc_staff.staff_name')
            ->join('egc_staff', 'egc_staff.sno', '=', 'egc_call_tracker.branch_staff_id')
            ->where(function ($query) use ($cus_mobile, $phoneWithCountryCode) {
                $query->where('customer_phone_no', $cus_mobile)
                    ->orWhere('customer_phone_no', $phoneWithCountryCode);
            })
            ->where('count_status', 1)
            ->whereIn('egc_call_tracker.staff_phone_no', $cugMobiles);

            if ($status == "Incoming") {
                $calls->where('egc_call_tracker.call_status', 1);
            } elseif ($status == "Outgoing") {
                $calls->where('egc_call_tracker.call_status', 0);
            } elseif ($status == "Dialed") {
                $calls->where('egc_call_tracker.call_status', 4);
            } elseif ($status == "Missed & Rejected") {
                $calls->whereIn('egc_call_tracker.call_status', [2, 3]);
            }

            $calls = $calls->orderBy('egc_call_tracker.sno', 'desc')->get();
          

        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
            'status'=> $status,
        ]);
    }

    public function cugDepartments(Request $request)
{
    $helper = new \App\Helpers\Helpers();
    $general_setting = $helper->general_setting_data();

    $mainCompanyName  = $general_setting->title;
    $mainCompanyColor = '#ab2b22';

    $departments = Cache::remember(
        'cug_departments_v3',
        now()->addMinutes(10),
        function () use ($mainCompanyName, $mainCompanyColor) {

            return DB::table('egc_staff as s')
                ->join('egc_cug_assignments as cug', function ($join) {
                    $join->on('cug.staff_id', '=', 's.sno')
                        ->where('cug.status', 0)
                        ->where('cug.is_current', 1);
                })
                ->leftJoin('egc_company as d', 'd.sno', '=', 's.company_id')
                ->where('s.status', 0)
                ->select(
                    's.company_id as department_id',

                    DB::raw("
                        CASE
                            WHEN s.company_id = 0 THEN ?
                            ELSE d.company_name
                        END as department_name
                    "),

                    DB::raw("
                        CASE
                            WHEN s.company_id = 0 THEN ?
                            ELSE d.company_base_color
                        END as company_base_color
                    "),

                    DB::raw('COUNT(s.sno) as staff_count'),

                    DB::raw("
                        SUM(
                            CASE
                                WHEN cug.online_status = 1 THEN 1
                                ELSE 0
                            END
                        ) as online_count
                    ")
                )
                ->addBinding([
                    $mainCompanyName,
                    $mainCompanyColor
                ], 'select')
                ->groupBy(
                    's.company_id',
                    'd.company_name',
                    'd.company_base_color'
                )
                ->orderByRaw('CASE WHEN s.company_id = 0 THEN 0 ELSE 1 END')
                ->orderBy('s.company_id', 'asc')
                ->get();
        }
    );

    return response()->json([
        'status' => true,
        'data'   => $departments
    ]);
}


    // public function cugStaffList(Request $request)
    // {
    //     /* Month / Year */

    //     $monthFilter = $request->get('month_filter', now()->format('M-Y'));
    //     try {
    //         $parsedDate = Carbon::createFromFormat('!M-Y',$monthFilter );
    //     } catch (\Throwable $e) {
    //         $parsedDate = now()->startOfMonth();
    //     }

    //     $month = $parsedDate->month;
    //     $year  = $parsedDate->year;
    //     $branch_id = $request->user()->branch_id;

    //     /* Pagination */

    //     $limit = min( max((int) $request->get('limit', 50), 10), 100 );
    //     $page = max((int) $request->get('page', 1),1);

    //     /* Call Summary */

    //     $callSummary = DB::table('egc_call_tracker')
    //         ->select(
    //             'staff_phone_no',
    //             DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming"),
    //             DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoing"),
    //             DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missed"),
    //             DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected"),
    //             DB::raw("SUM(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialed"),
    //              DB::raw("MAX(CONCAT( call_start_date, ' ', call_start_time)) AS last_call_at")
    //         )
    //         ->whereYear('call_start_date',$year)
    //         ->whereMonth('call_start_date',$month)
    //         ->groupBy('staff_phone_no');

    //     /* Staff Query */

    //     $query = DB::table('egc_staff as s')
    //         ->join('egc_cug_assignments as cug', function ($join) {
    //             $join->on('cug.staff_id','=','s.sno')
    //             ->where('cug.status', 0);
    //         })
    //         ->join('egc_cug_numbers as cug_number','cug_number.sno', '=','cug.cug_id')
    //         ->leftJoin('egc_job_role as jp','jp.sno', '=','s.job_role_id')
    //         ->leftJoinSub($callSummary,'calls',
    //             function ($join) {
    //                 $join->on('calls.staff_phone_no','=', 'cug_number.cug_number');
    //             }
    //         )
    //         ->where('s.status', 0);
    //     return $query->get();

    //     /* Department */

    //     $query->when(
    //         $request->filled('company_id'),
    //         function ($q) use ($request) {
    //             $q->where('s.company_id', $request->department_id);
    //         }
    //     );

    //     /* Online / Offline */
    //     $query->when(
    //         $request->filled('online'),
    //         function ($q) use ($request) {
    //             $q->where('cug.online_status', $request->online);
    //         }
    //     );

    //     /* Search */
    //     $query->when(
    //         $request->filled('search'),
    //         function ($q) use ($request) {
    //             $search = trim($request->search);
    //             $q->where(
    //                 function ($sub) use ($search) {
    //                     $sub->where( 's.staff_name', 'LIKE',"%{$search}%")
    //                     ->orWhere('cug_number.cug_number','LIKE',"%{$search}%" );
    //                 }
    //             );
    //         }
    //     );

    //     /* Summary */
    //     $summary = (clone $query)
    //         ->selectRaw(
    //             "COUNT(*) AS total_staff,
    //             SUM(
    //                 CASE
    //                     WHEN cug.online_status = 1
    //                     THEN 1
    //                     ELSE 0
    //                 END
    //             ) AS online,
    //             SUM(
    //                 CASE
    //                     WHEN cug.online_status = 0
    //                     THEN 1
    //                     ELSE 0
    //                 END
    //             ) AS offline,
    //             COALESCE(
    //                 SUM(
    //                     COALESCE(calls.incoming, 0) +
    //                     COALESCE(calls.outgoing, 0) +
    //                     COALESCE(calls.missed, 0) +
    //                     COALESCE(calls.rejected, 0) +
    //                     COALESCE(calls.dialed, 0)
    //                 ),
    //                 0
    //             ) AS total_calls,

    //             COALESCE(
    //                 SUM(
    //                     COALESCE(calls.missed, 0)
    //                 ),
    //                 0
    //             ) AS missed,

    //             COALESCE(
    //                 SUM(
    //                     COALESCE(calls.incoming, 0)
    //                 ),
    //                 0
    //             ) AS incoming,
    //             COALESCE(
    //                 SUM(
    //                     COALESCE(calls.outgoing, 0)
    //                 ),
    //                 0
    //             ) AS outgoing,

    //             COALESCE(
    //                 SUM(
    //                     COALESCE(calls.rejected, 0)
    //                 ),
    //                 0
    //             ) AS rejected,

    //             COALESCE(
    //                 SUM(
    //                     COALESCE(calls.dialed, 0)
    //                 ),
    //                 0
    //             ) AS dialed
    //         ")
    //         ->first();


    //     /* Staff List */

    //     $staff = $query
    //         ->select(
    //             's.sno as staff_id',
    //             's.staff_name',
    //             'users.id as user_id',
    //             's.staff_image',
    //             's.gender',
    //             's.status as staff_status',
    //             'cug_number.cug_number as cug_mobile',
    //             'cug.online_status',
    //             'cug.last_online_at',
    //             'cug.last_terminate_at',
    //             'cug.last_checking',
    //             'cug.live_status',
    //             'jp.job_position_name',
    //             DB::raw("COALESCE(calls.incoming, 0) AS incoming"),
    //             DB::raw("COALESCE(calls.outgoing, 0) AS outgoing"),
    //             DB::raw("COALESCE(calls.missed, 0) AS missed"),
    //             DB::raw("
    //                 COALESCE(
    //                     calls.rejected,
    //                     0
    //                 ) AS rejected
    //             "),

    //             DB::raw("
    //                 COALESCE(
    //                     calls.dialed,
    //                     0
    //                 ) AS dialed
    //             "),
    //             DB::raw("
    //                 calls.last_call_at AS last_call_at
    //             "),
    //             DB::raw("
    //                 CASE
    //                     WHEN cug.live_status = 1
    //                         AND cug.last_checking IS NOT NULL
    //                         AND cug.last_checking >= DATE_SUB(NOW(), INTERVAL 20 MINUTE)
    //                     THEN 1
    //                     ELSE 0
    //                 END AS last_checking_status
    //             "),

    //         )

    //         ->orderByDesc(
    //             'cug.online_status'
    //         )

    //         ->orderBy(
    //             's.staff_name'
    //         )

    //         ->paginate(
    //             $limit,
    //             ['*'],
    //             'page',
    //             $page
    //         );


    //     /*
    //     |--------------------------------------------------------------------------
    //     | Last Login - ONE QUERY
    //     |
    //     | Avoid N+1 query inside transform()
    //     |--------------------------------------------------------------------------
    //     */

    //     $userIds = $staff
    //         ->getCollection()
    //         ->pluck('user_id')
    //         ->filter()
    //         ->values()
    //         ->toArray();


    //     $lastLogins = collect();


    //     if (!empty($userIds)) {

    //         $lastLogins = DB::table(
    //             'mobile_user_login_logs'
    //         )

    //         ->select(
    //             'user_id',
    //             'login_at'
    //         )

    //         ->whereIn(
    //             'user_id',
    //             $userIds
    //         )

    //         ->where(
    //             'type',
    //             0
    //         )

    //         ->orderByDesc(
    //             'login_at'
    //         )

    //         ->get()

    //         ->unique(
    //             'user_id'
    //         )

    //         ->keyBy(
    //             'user_id'
    //         );

    //     }


    //     /*
    //     |--------------------------------------------------------------------------
    //     | Transform
    //     |--------------------------------------------------------------------------
    //     */

        
    //             $startDate = Carbon::create($year, $month, 1);
    //                 $currentDate = Carbon::now();
    //                 $endDate = ($currentDate->year == $year && $currentDate->month == $month)
    //                     ? $currentDate
    //                     : $startDate->copy()->endOfMonth();
    //                 $dayCount = $startDate->diffInDays($endDate) + 1;

    //     $staff->getCollection()->transform(
    //         function ($row) use ($lastLogins,$dayCount) {

    //             $row->encrypted_id = $row->cug_mobile ? encrypt($row->cug_mobile) : NULL;

    //             /*
    //             |--------------------------------------------------------------------------
    //             | Last Login
    //             |--------------------------------------------------------------------------
    //             */

    //             $login = $lastLogins->get(
    //                 $row->user_id
    //             );

    //             if ($login && $login->login_at) {

    //                 $loginAt = Carbon::parse(
    //                     $login->login_at
    //                 );

    //                 $row->last_login_date =
    //                     $loginAt->format('Y-m-d');

    //                 $row->last_login_time =
    //                     $loginAt->format('h:i:s A');

    //             } else {

    //                 $row->last_login_date = null;

    //                 $row->last_login_time = null;

    //             }

    //             $lastOnlineDate =NULL;
    //             $lastOnlineTime =NULL;
    //             $lastOnlineDuration =NULL;
                
    //             $lastOfflineDate = null;
    //             $lastOfflineTime = null;
    //             $lastOfflineDuration = null;

    //             $lastLiveDate = null;
    //             $lastLiveTime = null;
    //             $lastLiveDuration = null;

    //             if ($row->last_online_at) {
    //                 $lastOnlineAt = Carbon::parse($row->last_online_at);
    //                 $lastOnlineDate = $lastOnlineAt->format('Y-m-d');
    //                 $lastOnlineTime = $lastOnlineAt->format('H:i:s');
    //                 $lastOnlineDuration = $lastOnlineAt->diffForHumans([
    //                     'parts' => 2,
    //                     'short' => true,
    //                 ]);
    //             }
                
    //             if ($row->last_terminate_at) {
    //                 $lastOfflineAt = Carbon::parse($row->last_terminate_at);
    //                 $lastOfflineDate = $lastOfflineAt->format('Y-m-d');
    //                 $lastOfflineTime = $lastOfflineAt->format('H:i:s');
    //                 $lastOfflineDuration = $lastOfflineAt->diffForHumans([
    //                     'parts' => 2,
    //                     'short' => true,
    //                 ]);
    //             }

    //             $row->last_checking_status =0;

    //             if ($row->last_checking) {
    //                 $lastLiveAt = Carbon::parse($row->last_checking);
    //                 $row->last_checking_status = (
    //                     (int) $row->live_status === 1
    //                     && $row->last_checking
    //                     && Carbon::parse($row->last_checking)->gte(
    //                         Carbon::now()->subMinutes(20)
    //                     )
    //                 ) ? 1 : 0;
    //                 $lastLiveDate = $lastLiveAt->format('Y-m-d');
    //                 $lastLiveTime = $lastLiveAt->format('H:i:s');
    //                 $lastLiveDuration = $lastLiveAt->diffForHumans([
    //                     'parts' => 2,
    //                     'short' => true,
    //                 ]);
 
    //             }

                

    //                 $row->last_live_date = $lastLiveDate;
    //                 $row->last_live_time = $lastLiveTime;
    //                 $row->last_live_duration = $lastLiveDuration;


    //               $row->last_online_date = $lastOnlineDate;
    //               $row->last_online_time = $lastOnlineTime;
    //               $row->last_online_duration = $lastOnlineDuration;

    //                 $row->last_offline_date = $lastOfflineDate;
    //                 $row->last_offline_time = $lastOfflineTime;
    //                 $row->last_offline_duration = $lastOfflineDuration;

    //             /*
    //             |--------------------------------------------------------------------------
    //             | Last Call
    //             |--------------------------------------------------------------------------
    //             */

    //             if ($row->last_call_at) {

    //                 $lastCallAt = Carbon::parse( $row->last_call_at);
    //                 $row->last_call_date = $lastCallAt->format('Y-m-d');
    //                 $row->last_call_time =  $lastCallAt->format('h:i:s A');
    //                 $row->last_call_duration =
    //                     $lastCallAt->diffForHumans([
    //                         'parts' => 2,
    //                         'short' => true,
    //                     ]);

    //             } else {
    //                 $row->last_call_date = null;
    //                 $row->last_call_time = null;
    //                 $row->last_call_duration = null;

    //             }

               

    //             /*
    //             |--------------------------------------------------------------------------
    //             | Call Counts
    //             |--------------------------------------------------------------------------
    //             */

    //             $row->incoming = (int) $row->incoming;

    //             $row->outgoing = (int) $row->outgoing;

    //             $row->missed = (int) $row->missed;

    //             $row->rejected = (int) $row->rejected;

    //             $row->dialed = (int) $row->dialed;


    //             /*
    //             |--------------------------------------------------------------------------
    //             | Total Calls
    //             |--------------------------------------------------------------------------
    //             */

    //             $totalCalls =
    //                 $row->incoming +
    //                 $row->outgoing +
    //                 $row->missed +
    //                 $row->rejected +
    //                 $row->dialed;


    //             $row->total_calls =
    //                 $totalCalls;


    //             /*
    //             |--------------------------------------------------------------------------
    //             | Call Percentage
    //             |--------------------------------------------------------------------------
    //             |
    //             | Same concept used by your CUG table.
    //             |--------------------------------------------------------------------------
    //             */


    //                 $row->ocr = $dayCount > 0 ? round($row->outgoing / $dayCount) : 0;

    //                 $row->rcr= $dayCount > 0 ? round($row->incoming / $dayCount) : 0;
                    
    //                 $row->mcr = $dayCount > 0 ? round($row->missed / $dayCount) : 0;

                
    //             /*
    //             |--------------------------------------------------------------------------
    //             | Missed Call Ratio
    //             |
    //             | Match your TeamCall() calculation:
    //             | incoming + missed + rejected
    //             |--------------------------------------------------------------------------
    //             */

    //             $missedRatioTotal =
    //                 $row->incoming +
    //                 $row->missed +
    //                 $row->rejected;


    //             $row->missed_call_ratio =
    //                 $missedRatioTotal > 0
    //                     ? round(
    //                         ($row->missed / $missedRatioTotal) * 100,
    //                         1
    //                     )
    //                     : 0;


    //             return $row;

    //         }
    //     );


    //     /*
    //     |--------------------------------------------------------------------------
    //     | Response
    //     |--------------------------------------------------------------------------
    //     */

    //     return response()->json([

    //         'status' => true,

    //         'summary' => [
    //             'total_staff' => (int) ($summary->total_staff ?? 0),
    //             'online' => (int) ($summary->online ?? 0),
    //             'offline' =>  (int) ($summary->offline ?? 0),
    //             'total_calls' => (int) ($summary->total_calls ?? 0),
    //             'incoming' =>  (int) ($summary->incoming ?? 0),
    //             'outgoing' => (int) ($summary->outgoing ?? 0),
    //             'missed' => (int) ($summary->missed ?? 0),
    //             'rejected' => (int) ($summary->rejected ?? 0),
    //             'dialed' => (int) ($summary->dialed ?? 0),
    //         ],

    //         'data' => $staff->items(),
    //         'pagination' => [
    //             'current_page' =>  $staff->currentPage(),
    //             'last_page' => $staff->lastPage(),
    //             'per_page' => $staff->perPage(),
    //             'total' => $staff->total(),
    //             'has_more' => $staff->hasMorePages(),
    //         ],

    //     ]);
    // }

    public function cugStaffList(Request $request)
    {
        /* --------------------------------------------------------------------------
        | Month / Year
        | -------------------------------------------------------------------------- */

        $monthFilter = $request->get('month_filter', now()->format('M-Y'));

        try {
            $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
        } catch (\Throwable $e) {
            $parsedDate = now()->startOfMonth();
        }

        $month = $parsedDate->month;
        $year  = $parsedDate->year;

        $branch_id = $request->user()->branch_id;


        /* --------------------------------------------------------------------------
        | Pagination
        | -------------------------------------------------------------------------- */

        $limit = min(
            max((int) $request->get('limit', 50), 10),
            100
        );

        $page = max(
            (int) $request->get('page', 1),
            1
        );


        /* --------------------------------------------------------------------------
        | Call Summary
        | -------------------------------------------------------------------------- */

        $callSummary = DB::table('egc_call_tracker')
            ->select(
                'staff_phone_no',
                DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming"),
                DB::raw("SUM( CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoing"),
                DB::raw("SUM( CASE WHEN call_status = 2 THEN 1 ELSE 0 END ) AS missed "),
                DB::raw("SUM( CASE WHEN call_status = 3 THEN 1 ELSE 0 END ) AS rejected"),
                DB::raw("SUM( CASE WHEN call_status = 4 THEN 1  ELSE 0 END) AS dialed"),
                DB::raw("MAX(CONCAT( call_start_date,' ',call_start_time)) AS last_call_at")
            )
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->groupBy('staff_phone_no');


        /* --------------------------------------------------------------------------
        | Staff Query
        | -------------------------------------------------------------------------- */

        $query = DB::table('egc_staff as s')
            ->join('egc_cug_assignments as cug', function ($join) {
                $join->on('cug.staff_id','=','s.sno')
                ->where('cug.status', 0)
                ->where('cug.is_current', 1);
            })
            ->join('egc_cug_numbers as cug_number','cug_number.sno', '=', 'cug.cug_id')
            ->leftJoin('egc_job_role as jp','jp.sno','=', 's.job_role_id')
            ->leftJoinSub(
                $callSummary,
                'calls',
                function ($join) {
                    $join->on(
                        DB::raw( "calls.staff_phone_no COLLATE utf8mb4_unicode_ci"),
                        '=',
                        DB::raw("cug_number.cug_number COLLATE utf8mb4_unicode_ci")
                    );
                }
            )
            ->where('s.status', 0);
    


        /* Department  */
        $query->when( $request->filled('department_id'),
            function ($q) use ($request) {
                $departmentId = (int) $request->department_id;
                $q->where('s.company_id', $departmentId);
            }
        );


        /* Online / Offline */
        $query->when(
            $request->filled('online'),
            function ($q) use ($request) {
                $q->where('cug.online_status',(int) $request->online);
            }
        );

        /* Search */
        $query->when(
            $request->filled('search'),
            function ($q) use ($request) {
                $search = trim($request->search);
                $q->where(function ($sub) use ($search) {
                    $sub->where('s.staff_name','LIKE',"%{$search}%" )
                    ->orWhere('cug_number.cug_number','LIKE',"%{$search}%");
                });
            }
        );

        /* Summary */
        $summary = (clone $query)
            ->selectRaw("
                COUNT(*) AS total_staff,
                SUM(
                    CASE
                        WHEN cug.online_status = 1
                        THEN 1
                        ELSE 0
                    END
                ) AS online,
                SUM(
                    CASE
                        WHEN cug.online_status = 0
                        THEN 1
                        ELSE 0
                    END
                ) AS offline,
                COALESCE(
                    SUM(
                        COALESCE(calls.incoming, 0) +
                        COALESCE(calls.outgoing, 0) +
                        COALESCE(calls.missed, 0) +
                        COALESCE(calls.rejected, 0) +
                        COALESCE(calls.dialed, 0)
                    ),
                    0
                ) AS total_calls,

                COALESCE(
                    SUM(COALESCE(calls.missed, 0)),
                    0
                ) AS missed,

                COALESCE(
                    SUM(COALESCE(calls.incoming, 0)),
                    0
                ) AS incoming,

                COALESCE(
                    SUM(COALESCE(calls.outgoing, 0)),
                    0
                ) AS outgoing,

                COALESCE(
                    SUM(COALESCE(calls.rejected, 0)),
                    0
                ) AS rejected,

                COALESCE(
                    SUM(COALESCE(calls.dialed, 0)),
                    0
                ) AS dialed
            ")
            ->first();


        /* Staff List */
        $staff = $query
            ->select(
                's.sno as staff_id',
                's.staff_name',
                's.staff_image',
                's.gender',
                's.status as staff_status',
                'cug_number.cug_number as cug_mobile',
                'cug.online_status',
                'cug.last_online_at',
                'cug.last_terminate_at',
                'cug.last_checking',
                'cug.live_status',
                'jp.job_position_name',
                DB::raw("COALESCE(calls.incoming, 0) AS incoming "),
                DB::raw("COALESCE(calls.outgoing, 0) AS outgoing"),
                DB::raw("COALESCE(calls.missed, 0) AS missed"),
                DB::raw("COALESCE(calls.rejected, 0) AS rejected"),
                DB::raw("COALESCE(calls.dialed, 0) AS dialed"),
                DB::raw("calls.last_call_at AS last_call_at"),
                DB::raw("
                    CASE
                        WHEN cug.live_status = 1
                        AND cug.last_checking IS NOT NULL
                        AND cug.last_checking >= DATE_SUB(
                            NOW(),
                            INTERVAL 20 MINUTE
                        )
                        THEN 1
                        ELSE 0
                    END AS last_checking_status
                ")
            )
            ->orderByDesc('last_checking_status')
            ->orderBy('s.staff_name')
            ->paginate($limit,['*'],'page',$page);

        /*  Last Login   */
        $userIds = $staff
            ->getCollection()
            ->pluck('staff_id')
            ->filter()
            ->values()
            ->toArray();
        

        $lastLogins = collect();

        if (!empty($userIds)) {

            $lastLogins = DB::table('mobile_user_login_logs')
                ->select('user_id','login_at')
                ->whereIn('user_id', $userIds)
                ->where('type', 0)
                ->orderByDesc('login_at')
                ->get()
                ->unique('user_id')
                ->keyBy('user_id');
        }


        /* Day Count */

        $startDate = Carbon::create( $year, $month,1);
        $currentDate = Carbon::now();

        $endDate = ( $currentDate->year == $year && $currentDate->month == $month)
            ? $currentDate
            : $startDate->copy()->endOfMonth();

        $dayCount = $startDate->diffInDays($endDate) + 1;


        /* Transform  */

        $staff->getCollection()->transform(
            function ($row) use ($lastLogins, $dayCount) {

                $row->encrypted_id = $row->cug_mobile ? encrypt($row->cug_mobile) : null;

                /* Last Login */
                $login = $lastLogins->get($row->staff_id);
            
                $staffData=StaffModel::where('sno',$row->staff_id)->first();
                
                $row->staff_image_url= $staffData->profile_image_url;

                if ($login && $login->login_at) {

                    $loginAt = Carbon::parse($login->login_at , 'Asia/Kolkata');

                    $row->last_login_date =
                        $loginAt->format('Y-m-d');

                    $row->last_login_time =
                        $loginAt->format('h:i:s A');

                } else {
                    $row->last_login_date = null;
                    $row->last_login_time = null;
                }


                /* Last Online */

                $row->last_online_date = null;
                $row->last_online_time = null;
                $row->last_online_duration = null;

                if ($row->last_online_at) {
                    $lastOnlineAt = Carbon::parse( $row->last_online_at , 'Asia/Kolkata');
                    $row->last_online_date = $lastOnlineAt->format('Y-m-d');
                    $row->last_online_time = $lastOnlineAt->format('H:i:s');

                    $row->last_online_duration =
                        $lastOnlineAt->diffForHumans([
                            'parts' => 2,
                            'short' => true,
                        ]);
                }


                /* Last Offline */

                $row->last_offline_date = null;
                $row->last_offline_time = null;
                $row->last_offline_duration = null;

                if ($row->last_terminate_at) {

                    $lastOfflineAt = Carbon::parse($row->last_terminate_at , 'Asia/Kolkata');

                    $row->last_offline_date =
                        $lastOfflineAt->format('Y-m-d');

                    $row->last_offline_time =
                        $lastOfflineAt->format('H:i:s');

                    $row->last_offline_duration =
                        $lastOfflineAt->diffForHumans([
                            'parts' => 2,
                            'short' => true,
                        ]);
                }


                /* Last Live / Checking */

                $row->last_live_date = null;
                $row->last_live_time = null;
                $row->last_live_duration = null;
                $row->last_checking_status = 0;

                if ($row->last_checking) {

                    $lastLiveAt = Carbon::parse($row->last_checking , 'Asia/Kolkata');

                    $row->last_checking_status =
                        (
                            (int) $row->live_status === 1 &&
                            $lastLiveAt->gte(
                                Carbon::now()->subMinutes(20)
                            )
                        )
                        ? 1
                        : 0;

                    $row->last_live_date =
                        $lastLiveAt->format('Y-m-d');

                    $row->last_live_time =
                        $lastLiveAt->format('H:i:s');

                    $row->last_live_duration =
                        $lastLiveAt->diffForHumans([
                            'parts' => 2,
                            'short' => true,
                        ]);
                }


                /* Last Call */

                if ($row->last_call_at) {

                    $lastCallAt = Carbon::parse($row->last_call_at, 'Asia/Kolkata');
                    $row->last_call_date = $lastCallAt->format('Y-m-d');
                    $row->last_call_time = $lastCallAt->format('h:i:s A');

                    $row->last_call_duration =
                        $lastCallAt->diffForHumans([
                            'parts' => 2,
                            'short' => true,
                        ]);

                } else {

                    $row->last_call_date = null;
                    $row->last_call_time = null;
                    $row->last_call_duration = null;
                }


                /* Call Counts */

                $row->incoming = (int) $row->incoming;
                $row->outgoing = (int) $row->outgoing;
                $row->missed = (int) $row->missed;
                $row->rejected = (int) $row->rejected;
                $row->dialed = (int) $row->dialed;


                /* Total Calls */

                $row->total_calls =
                    $row->incoming +
                    $row->outgoing +
                    $row->missed +
                    $row->rejected +
                    $row->dialed;


                /* Calls Per Day */

                $row->ocr = $dayCount > 0
                    ? round($row->outgoing / $dayCount)
                    : 0;

                $row->rcr = $dayCount > 0
                    ? round($row->incoming / $dayCount)
                    : 0;

                $row->mcr = $dayCount > 0
                    ? round($row->missed / $dayCount)
                    : 0;


                /* Missed Call Ratio */

                $missedRatioTotal =
                    $row->incoming +
                    $row->missed +
                    $row->rejected;

                $row->missed_call_ratio =
                    $missedRatioTotal > 0
                        ? round(
                            ($row->missed / $missedRatioTotal) * 100,
                            1
                        )
                        : 0;


                return $row;
            }
        );


        /* --------------------------------------------------------------------------
        | Response
        | -------------------------------------------------------------------------- */

        return response()->json([

            'status' => true,

            'summary' => [

                'total_staff' => (int) ($summary->total_staff ?? 0),
                'online' => (int) ($summary->online ?? 0),
                'offline' => (int) ($summary->offline ?? 0),
                'total_calls' => (int) ($summary->total_calls ?? 0),
                'incoming' => (int) ($summary->incoming ?? 0),
                'outgoing' => (int) ($summary->outgoing ?? 0),
                'missed' => (int) ($summary->missed ?? 0),
                'rejected' => (int) ($summary->rejected ?? 0),
                'dialed' => (int) ($summary->dialed ?? 0),
            ],

            'data' => $staff->items(),

            'pagination' => [
                'current_page' => $staff->currentPage(),
                'last_page' => $staff->lastPage(),
                'per_page' => $staff->perPage(),
                'total' => $staff->total(),
                'has_more' => $staff->hasMorePages(),
            ],
        ]);
    }


    public function cugIndex(Request $request){

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $branch_id = $request->user()->branch_id ;
        $user_id = $request->user()->user_id;

        $call_fill        = $request->input('call_fill', '');
        $staff_fill       = $request->input('staff_fill', '');
        $status_fill      = $request->input('status_fill', '');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');

        $monthFilter = $request->get('month_filter', now()->format('M-Y'));
        try {
            $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        } catch (\Exception $e) {
            $parsedDate = now()->startOfMonth();
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        }


        $helper = new \App\Helpers\Helpers();
    
       

        return view('content.control_panel.cug_management.callerpilot_moniter.cug_list',[
        ]);
    }
    
     public function getMonthStaffLocations($id, Request $request)
    {
        
        $staffCug = $id ? decrypt($id) : NULL;
        // return $staffCug;
        $branch_id = $request->user()->branch_id;

        if (!$staffCug) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid staff Mobile.',
                'data'    => [],
            ], 422);
        }

            $monthFilter = $request->get('month_filter', now()->format('M-Y'));

            try {

                $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);

                $month = $parsedDate->month;
                $year  = $parsedDate->year;

                $startDate = $parsedDate->copy()->startOfMonth()->startOfDay();
                $endDate   = $parsedDate->copy()->endOfMonth()->endOfDay();

            } catch (\Throwable $e) {

                return response()->json([
                    'status'  => false,
                    'message' => 'Invalid month format. Use M-Y.',
                    'data'    => [],
                ], 422);
            }

        if ($startDate->gt($endDate)) {

            return response()->json([
                'status'  => false,
                'message' => 'Start date cannot be greater than end date.',
                'data'    => [],
            ], 422);

        }

        if ($startDate->diffInDays($endDate) > 31) {

            return response()->json([
                'status'  => false,
                'message' => 'Maximum location date range is 31 days.',
                'data'    => [],
            ], 422);

        }

        $staff = DB::table('egc_staff as s')
            ->leftJoin('egc_department as d','d.sno','=','s.department_id')
            ->leftJoin('egc_job_role as jp','jp.sno','=','s.job_role_id')
            ->join('egc_cug_assignments as cug',
                function ($join) {
                    $join->on('cug.staff_id', '=','s.sno' )
                    ->where('cug.status', 0);
                }
            )
            ->join( 'egc_cug_numbers as num','num.sno','=', 'cug.cug_id')
            ->where('num.cug_number', $staffCug)
            ->select(
                's.sno as staff_id',
                's.staff_name',
                's.staff_image',
                's.gender',
                's.mobile_no',
                'd.department_name',
                'jp.job_position_name',
                'num.cug_number as cug_mobile',
                'cug.online_status'

            )
            ->first();


        if (!$staff) {
            return response()->json([
                'status'  => false,
                'message' => 'Staff not found.',
                'data'    => [],
            ], 404);

        }

        $rawMobile = preg_replace(
            '/\D+/',
            '',
            (string) $staff->cug_mobile
        );

        $phoneNumbers = collect([
            $rawMobile,
            '+91' . $rawMobile,
            '91' . $rawMobile,
        ])
            ->filter()
            ->unique()
            ->values()
            ->toArray();

        $callsQuery = DB::table('egc_call_tracker')
            ->whereBetween( 'call_start_date',[ $startDate, $endDate])
            ->where(function ($query) use ($phoneNumbers) {
                foreach ($phoneNumbers as $phone) {
                    $query->orWhere('staff_phone_no', $phone );
                }
            });

        $totalCalls = (clone $callsQuery)->count();

        $maxLocations = min( max((int) $request->input('limit', 2000 ), 100 ), 5000 );

        $calls = $callsQuery
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->whereNot('latitude',0)
            ->whereNot('longitude',0)
            ->orderBy('call_start_date','desc' )
            ->orderBy('call_start_time', 'desc')
            ->limit($maxLocations)
            ->get();


        $locations = [];

        foreach ($calls as $call) {

            /* Coordinates */
            $latitude = filter_var( $call->latitude, FILTER_VALIDATE_FLOAT );
            $longitude = filter_var( $call->longitude, FILTER_VALIDATE_FLOAT );

            /* Validate Coordinates */
            if ($latitude === false || $longitude === false ) {
                continue;
            }

            if ($latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180) {
                continue;
            }

            /* Call Status */

            $status = (int) ($call->status ?? $call->call_status ?? 3);

            switch ($status) {
                case 0:
                    $statusText  = 'Outgoing';
                    $statusClass = 'outgoing';
                    $statusIcon  = 'mdi-phone-outgoing';
                    break;
                case 1:
                    $statusText  = 'Incoming';
                    $statusClass = 'incoming';
                    $statusIcon  = 'mdi-phone-incoming';
                    break;
                case 2:
                    $statusText  = 'Missed';
                    $statusClass = 'missed';
                    $statusIcon  = 'mdi-phone-missed';
                    break;
                case 3:
                    $statusText  = 'Rejected';
                    $statusClass = 'rejected';
                    $statusIcon  = 'mdi-phone-cancel';
                    break;
                case 4:
                    $statusText  = 'Dialed';
                    $statusClass = 'dialed';
                    $statusIcon  = 'mdi-phone-dial';
                    break;
                default:
                    $statusText  = 'Unknown';
                    $statusClass = 'unknown';
                    $statusIcon  = 'mdi-phone-outline';
                    break;

            }

            $callDate = null;
            $callTime = null;
            $callDateTime = null;

            if ($call->call_start_date) {
                try {
                    $callDateTimeObject = Carbon::parse($call->call_start_date);

                    if ($call->call_start_time && !str_contains((string) $call->call_start_date,':') ) {

                        $callDateTimeObject = Carbon::parse( $call->call_start_date . ' ' . $call->call_start_time);

                    }
                    $callDate = $callDateTimeObject->format('Y-m-d');
                    $callTime = $callDateTimeObject->format('h:i:s A');
                    $callDateTime = $callDateTimeObject->format('Y-m-d H:i:s' );
                } catch (\Throwable $e) {
                    $callDate = (string) $call->call_start_date;
                    $callTime = $call->call_start_time ? (string) $call->call_start_time  : null;
                }
            }

            $duration = $call->call_duration ?? null;
            if (!$duration && isset($call->duration) ) {
                $duration = $call->duration;
            }

            $customerName =  $call->customer_name ?? $call->user ?? null;
            $customerPhone = $call->customer_phone_no ?? $call->contact ?? null;

            $customerName = $customerName ? trim((string) $customerName)  : 'Unknown Contact';
            $customerPhone = $customerPhone ? trim((string) $customerPhone)  : '';
            /*Location Key */
            $locationKey = number_format($latitude, 7,'.','') . ',' . number_format($longitude, 7, '.', '' );

            $locations[] = [
                'id' => $call->sno ?? null,

                'latitude' => (float) $latitude,
                'longitude' => (float) $longitude,

                'location_key' => $locationKey,

                'user' => $staff->staff_name ?? 'Unknown Staff',

                'staff_id' => $staff->staff_id ?? null,

                'cug_mobile' => $call->staff_phone_no,
                'cug_key' => preg_replace(
                    '/\D+/',
                    '',
                    (string) $call->staff_phone_no
                ),

                'staff_image' => $staff->staff_image ?? null,
                'department_name' => $staff->department_name ?? null,
                'job_position_name' => $staff->job_position_name ?? null,

                'contact' => $call->contact_name ?? 'Unknown Contact',
                'phone' => $call->phone_no ?? '',

                'date' => $callDate,
                'time' => $callTime,
                'datetime' => $callDateTime,

                'duration' => $duration ?: '00:00:00',

                'status' => $status,
                'status_text' => $statusText,
                'status_class' => $statusClass,
                'status_icon' => $statusIcon,

                'audio_file' => $call->audio_file ?? null,
                'audio_url' => $call->audio_url ?? null,
                'audio_size' => $call->audio_size ?? null,
            ];
        }

        $statusCounts = [
            'incoming' => 0,
            'outgoing' => 0,
            'missed'   => 0,
            'rejected' => 0,
            'dialed'   => 0,
        ];

        foreach ($locations as $location) {
            switch ($location['status']) {
                case 0:
                    $statusCounts['outgoing']++;
                    break;
                case 1:
                    $statusCounts['incoming']++;
                    break;
                case 2:
                    $statusCounts['missed']++;
                    break;
                case 3:
                    $statusCounts['rejected']++;
                    break;
                case 4:
                    $statusCounts['dialed']++;
                    break;
            }
        }

        $uniqueLocations = collect($locations)
            ->pluck('location_key')
            ->unique()
            ->count();

        $staffImage = null;
        if (!empty($staff->staff_image)) {
            $staffImage = asset( 'staff_images/' . $staff->staff_image);
        }
        return response()->json([
            'status' => true,
            'message' => 'Call locations loaded successfully.',
            'staff' => [
                'staff_id' =>(int) $staff->staff_id,
                'name' => $staff->staff_name,
                'image' => $staffImage,
                'gender' => $staff->gender,
                'mobile' => $staff->cug_mobile,
                'department' =>  $staff->department_name,
                'position' => $staff->job_position_name,
                'online' => (int) $staff->online_status,
            ],
            'filter' => [
                'start_date' => $startDate->format('Y-m-d'),
                'end_date' => $endDate->format('Y-m-d'),
            ],
            'summary' => [
                'total_calls' => (int) $totalCalls,
                'mapped_calls' => count($locations),
                'unique_locations' => (int) $uniqueLocations,
                'incoming' => $statusCounts['incoming'],
                'outgoing' => $statusCounts['outgoing'],
                'missed' => $statusCounts['missed'],
                'rejected' => $statusCounts['rejected'],
                'dialed' => $statusCounts['dialed'],
            ],
            'data' => $locations,

        ]);
    }
    
     // Tracker Location
    public function locationTrackerIndex(Request $request){

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $branch_id = $request->user()->branch_id ;
            $user_id = $request->user()->user_id;

        $call_fill        = $request->input('call_fill', '');
        $staff_fill       = $request->input('staff_fill', '');
        $status_fill      = $request->input('status_fill', '');
        $from_date_filter = $request->input('from_date_fillter_textbox');
        $to_date_filter   = $request->input('to_date_fillter_textbox');

        $monthFilter = $request->get('month_filter', now()->format('M-Y'));
        try {
            $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        } catch (\Exception $e) {
            $parsedDate = now()->startOfMonth();
            $month = $parsedDate->month;
            $year  = $parsedDate->year;
        }


        $helper = new \App\Helpers\Helpers();
    
       

        return view('content.control_panel.cug_management.callerpilot_moniter.cug_location',[
        ]);
    }

    public function locationTrackerStaff(Request $request)
    {
        try {

            $branch_id = $request->user()->branch_id;

            $staff = DB::table('egc_staff as s')
                ->where('s.status', 0)

                ->join('egc_cug_assignments as cug', function ($join) {
                    $join->on('cug.staff_id', '=', 's.sno')
                        ->where('cug.status', 0);
                })

                ->join( 'egc_cug_numbers as num','num.sno','=', 'cug.cug_id')
                ->leftJoin( 'egc_job_role as jp','jp.sno','=', 's.job_role_id')

                ->select([
                    's.sno as staff_id',
                    's.staff_name',
                    's.staff_image',
                    'jp.job_position_name',
                    'num.cug_number as cug_mobile',
                    'cug.online_status',
                ])

                ->orderBy('s.staff_name')
                ->orderBy('num.cug_number')
                ->get();

            $staff->transform(function ($row) {

                $staffImage= StaffModel::where('sno',$row->staff_id)->first();
                $staff_image_url= $staffImage->profile_image_url;
                $row->staff_image = $staff_image_url ?? '';

                $row->encrypted_id = $row->cug_mobile
                    ? encrypt($row->cug_mobile)
                    : null;

                return $row;
            });

            return response()->json([
                'status'  => true,
                'message' => 'Staff loaded successfully.',
                'data'    => $staff,
            ]);

        } catch (\Throwable $e) {

            Log::error(
                'Location Tracker Staff Error',
                [
                    'message' => $e->getMessage(),
                    'file'    => $e->getFile(),
                    'line'    => $e->getLine(),
                ]
            );

            return response()->json([
                'status'  => false,
                'message' => 'Unable to load staff.',
                'data'    => [],
                'err' => $e->getMessage(),
                'file'    => $e->getFile(),
                'line'    => $e->getLine(),
            ], 500);
        }
    }

    public function locationTrackerData(Request $request)
    {
        try {

            $branch_id = $request->user()->branch_id;
            $filterType = $request->input( 'filter_type', 'month' );


            if ($filterType === 'today') {
                $startDate = now()->startOfDay();
                $endDate   = now()->endOfDay();
            }else if ($filterType === 'custom') {
                $startDate = $request->filled('start_date') ? Carbon::parse($request->input('start_date'))->startOfDay() : now()->startOfMonth();
                $endDate = $request->filled('end_date') ? Carbon::parse($request->input('end_date'))->endOfDay()  : now()->endOfDay();
            } else {
            $monthFilter = $request->get('month_filter', now()->format('M-Y'));
            try {
                $parsedDate = Carbon::createFromFormat('!M-Y', $monthFilter);
                $month = $parsedDate->month;
                $year  = $parsedDate->year;
            } catch (\Exception $e) {
                $parsedDate = now()->startOfMonth();
                $month = $parsedDate->month;
                $year  = $parsedDate->year;
            }

                $startDate = $parsedDate->copy()->startOfMonth();
                $endDate   = $parsedDate->copy()->endOfMonth();
            }


            if ($startDate->greaterThan($endDate)) {
                return response()->json([
                    'status'  => false,
                    'message' => 'Start date cannot be greater than end date.',
                ], 422);
            }

           $decrypted_cug = null;

            if ($request->filled('staff_id')) {
                try {
                    $decrypted_cug = decrypt($request->input('staff_id'));
                } catch (\Throwable $e) {

                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid CUG mobile.',
                        'data'   => [],
                    ], 422);
                }
            }

            $query = DB::table('egc_call_tracker as ct');

            $query->whereBetween('ct.call_start_date',
                    [$startDate->toDateString(),$endDate->toDateString()]);

            if ($decrypted_cug) {
                $query->where('ct.staff_phone_no',$decrypted_cug);
            }

            if ($request->filled('status') && $request->input('status') !== 'all') {

                $statuses = $request->input('status');

                if (!is_array($statuses)) {
                    $statuses = explode(
                        ',',
                        $statuses
                    );
                }

                $statuses = collect($statuses)
                    ->filter(function ($status) {
                        return $status !== ''
                            && $status !== null;
                    })
                    ->map(function ($status) {
                        return (int) $status;
                    })
                    ->unique()
                    ->values()
                    ->toArray();


                if (!empty($statuses)) {
                    $query->whereIn('ct.call_status',$statuses);
                }
            }

            

            

            $calls = $query
                ->select([
                    'ct.sno',
                    'ct.branch_staff_id',
                    'ct.contact_id',

                    'ct.customer_phone_no as phone_no',
                    'ct.staff_phone_no',

                    'ct.call_start_date',
                    'ct.call_start_time',
                    'ct.call_end_time',
                    'ct.call_duration',
                    'ct.call_status',

                    'ct.latitude',
                    'ct.longitude',

                    'ct.audio_file',
                ])
                ->orderByDesc('ct.call_start_date' )
                ->orderByDesc('ct.call_start_time' )
                ->get();

            $contactNameMap = $this->resolveLocationContactNames($calls);

            $calls = $calls->map(function ($call) use ($contactNameMap) {

                $call->contact_name =
                    $contactNameMap[$call->sno]
                    ?? 'Unknown Contact';

                $rawPhone = preg_replace(
                    '/\D+/',
                    '',
                    (string) $call->staff_phone_no
                );

                /*
                * Canonical phone key.
                * This is the identifier used by frontend grouping/routes.
                */
                if (strlen($rawPhone) > 10) {
                    $rawPhone = substr($rawPhone, -10);
                }

                $call->cug_mobile = $call->staff_phone_no;
                $call->cug_key = $rawPhone ?: null;

                /*
                * Audio
                */
                $call->audio_url = null;
                $call->audio_size = null;

                if (!empty($call->audio_file)) {

                    $audioName = basename($call->audio_file);

                    $audioPath = public_path(
                        'call_audios/' . $audioName
                    );

                    if (is_file($audioPath)) {

                        $call->audio_url = asset(
                            'call_audios/' . rawurlencode($audioName)
                        );

                        $bytes = filesize($audioPath);

                        if ($bytes >= 1048576) {
                            $call->audio_size =
                                round($bytes / 1048576, 2) . ' MB';
                        } else {
                            $call->audio_size =
                                round($bytes / 1024, 2) . ' KB';
                        }
                    }
                }

                return $call;
            });


            if ($request->filled('search')) {

                $search =
                    trim(
                        $request->input('search')
                    );

                if ($search !== '') {

                    $calls = $calls
                        ->filter(function ($call) use (
                            $search,
                            $contactNameMap
                        ) {

                            $contactName =
                                $contactNameMap[
                                    $call->sno
                                ] ?? 'Unknown Contact';


                            return
                                stripos(
                                    (string) $contactName,
                                    $search
                                ) !== false

                                ||

                                stripos(
                                    (string) $call->phone_no,
                                    $search
                                ) !== false

                                ||

                                stripos(
                                    (string) $call->staff_phone_no,
                                    $search
                                ) !== false;
                        })
                        ->values();
                }
            }


            $totalCalls = $calls->count();


                $mappedCalls =
                    $calls->filter(function ($call) {

                        return $call->latitude !== null
                            && $call->longitude !== null;

                    })->count();


                $uniqueLocations =
                    $calls
                        ->filter(function ($call) {

                            return $call->latitude !== null
                                && $call->longitude !== null;

                        })
                        ->map(function ($call) {

                            return number_format(
                                (float) $call->latitude,
                                7,
                                '.',
                                ''
                            )
                            . ','
                            .
                            number_format(
                                (float) $call->longitude,
                                7,
                                '.',
                                ''
                            );

                        })
                        ->unique()
                        ->count();


                $incoming =
                    $calls
                        ->where('call_status', 1)
                        ->count();


                $outgoing =
                    $calls
                        ->filter(function ($call) {

                            return (int) $call->call_status === 0
                                && $call->call_duration !== '00:00:00';

                        })
                        ->count();


                $missed =
                    $calls
                        ->where('call_status', 2)
                        ->count();


                $rejected =
                    $calls
                        ->where('call_status', 3)
                        ->count();


                $dialed =
                    $calls
                        ->where('call_status', 4)
                        ->count();

            $staffPhones = $calls
                ->pluck('staff_phone_no')
                ->filter()
                ->map(function ($phone) {
                    return preg_replace('/\D+/', '', (string) $phone);
                })
                ->filter()
                ->unique()
                ->values()
                ->toArray();

            $staffCollection = collect();

            


            if (!empty($staffPhones)) {

                $staffCollection = DB::table('egc_staff as s')
                    ->where('s.status', 0)

                    ->join('egc_cug_assignments as cug', function ($join) {
                        $join->on('cug.staff_id', '=', 's.sno')
                            ->where('cug.status', 0);
                    })
                    ->join( 'egc_cug_numbers as num','num.sno','=', 'cug.cug_id')
                    ->leftJoin(
                        'egc_job_role as jp',
                        'jp.sno',
                        '=',
                        's.job_role_id'
                    )

                    ->where(function ($query) use ($staffPhones) {

                        foreach ($staffPhones as $phone) {

                            $query->orWhere(
                                DB::raw("REPLACE(REPLACE(REPLACE(num.cug_number, '+', ''), ' ', ''), '-', '')"),
                                $phone
                            );
                        }
                    })

                    ->select([
                        's.sno as staff_id',
                        's.staff_name',
                        's.staff_image',
                        's.gender',
                        's.department_id',
                        'jp.job_position_name',
                        'num.cug_number as cug_mobile',
                    ])

                    ->get()
                    ->mapWithKeys(function ($staff) {

                        $phone = preg_replace(
                            '/\D+/',
                            '',
                            (string) $staff->cug_mobile
                        );

                        return [$phone => $staff];
                    });
            }

            

            $data = $calls->map(function ($call) use ( $staffCollection ) {

                $callPhone = preg_replace(
                    '/\D+/',
                    '',
                    (string) $call->staff_phone_no
                );

                $staff = $staffCollection->get($callPhone);

                $latitude = is_numeric($call->latitude ) ? (float) $call->latitude : null;
                $longitude = is_numeric($call->longitude ) ? (float) $call->longitude : null;

                if ($latitude !== null && ($latitude < -90 || $latitude > 90 )) {
                    $latitude = null;
                }
                if ( $longitude !== null && ( $longitude < -180 || $longitude > 180)) {
                    $longitude = null;
                }

                $locationKey = null;

                if ( $latitude !== null && $longitude !== null ) {
                    $locationKey =
                        number_format(
                            $latitude,
                            7,
                            '.',
                            ''
                        )
                        . ',' .
                        number_format(
                            $longitude,
                            7,
                            '.',
                            ''
                        );
                }

                $status = (int) $call->call_status;


                $statusData = $this->getCallLocationStatus( $status );

                $datetime = null;

                if (!empty($call->call_start_date) && !empty($call->call_start_time) ) {
                    try {
                        $datetime = Carbon::parse(
                            $call->call_start_date
                            . ' '
                            . $call->call_start_time
                        );

                    } catch (\Throwable $e) {
                        $datetime = null;
                    }
                }

                $staffImage=StaffModel::where('sno',$staff->staff_id)->first();
                $staff_image_url= $staffImage->profile_image_url;

                return [
                    'id' => $call->sno,
                    'latitude' => $latitude,
                    'longitude' => $longitude,
                    'location_key' => $locationKey,
                    'user' =>  $staff->staff_name ?? 'Unknown Staff',
                    'cug_mobile' => $call->staff_phone_no,
                    'staff_id' => $staff->staff_id ?? null,
                    'staff_image' => $staff_image_url ?? null,
                    'department_id' => $staff->department_id ?? null,
                    'job_position_name' => $staff->job_position_name ?? null,
                    'contact' => $call->contact_name ?? 'Unknown Contact',
                    'phone' => $call->phone_no ?? '',
                    'date' => $call->call_start_date,
                    'time' => $call->call_start_time,
                    'end_time' => $call->call_end_time,
                    'datetime' => $datetime ? $datetime->format('Y-m-d H:i:s') : null,
                    'duration' => $call->call_duration ?? '00:00:00',
                    'status' => $status,
                    'status_text' => $statusData['text'],
                    'status_class' => $statusData['class'],
                    'status_icon' => $statusData['icon'],
                    'has_location' => $latitude !== null && $longitude !== null,
                     
                    'audio_file' => $call->audio_file ?? null,
                    'audio_url' => $call->audio_url ?? null,
                    'audio_size' => $call->audio_size ?? null,
                ];

            })->values();

            $latestCall = $data->first();

            // $groupedLocations = $data
            //     ->filter(function ($call) {
            //         return $call['has_location'];
            //     })
            //     ->groupBy('location_key')
            //     ->map(function ($locationCalls,$locationKey ) {

            //         $first = $locationCalls->first();

            //         return [
            //             'location_key' =>$locationKey,
            //             'latitude' => $first['latitude'],
            //             'longitude' => $first['longitude'],
            //             'call_count' => $locationCalls->count(),
            //             'latest_call' => $first,
            //             'calls' => $locationCalls->values(),
            //         ];

            //     })
            //     ->values();

            // $groupedLocations = $data
            //         ->filter(function ($call) {
            //             return $call['has_location'];
            //         })
            //         ->sortBy(function ($call) {
            //             return ($call['call_start_date'] ?? '') . ' ' .
            //                 ($call['call_start_time'] ?? '');
            //         })
            //         ->groupBy('location_key')
            //         ->map(function ($locationCalls, $locationKey) {

            //             $locationCalls = $locationCalls->values();

            //             $first = $locationCalls->first();

            //             return [
            //                 'location_key' => $locationKey,
            //                 'latitude' => $first['latitude'],
            //                 'longitude' => $first['longitude'],
            //                 'call_count' => $locationCalls->count(),
            //                 'latest_call' => $locationCalls->last(),
            //                 'calls' => $locationCalls,
            //             ];
            //         })
            //         ->values();

            $groupedLocations = $data
                ->filter(function ($call) {
                    return $call['has_location'];
                })
                ->sortBy(function ($call) {
                    return $call['datetime'] ?? (
                        ($call['date'] ?? '') . ' ' . ($call['time'] ?? '')
                    );
                })
                ->groupBy('location_key')
                ->map(function ($locationCalls, $locationKey) {

                    // Make sure calls inside each location are oldest -> newest
                    $locationCalls = $locationCalls
                        ->sortBy(function ($call) {
                            return $call['datetime'] ?? (
                                ($call['date'] ?? '') . ' ' . ($call['time'] ?? '')
                            );
                        })
                        ->values();

                    // First = oldest call
                    $firstCall = $locationCalls->first();

                    // Last = latest call
                    $latestCall = $locationCalls->last();

                    return [
                        'location_key' => $locationKey,

                        'latitude' => $firstCall['latitude'],
                        'longitude' => $firstCall['longitude'],

                        'call_count' => $locationCalls->count(),

                        // IMPORTANT:
                        // latest_call really means latest call
                        'latest_call' => $latestCall,

                        // Oldest -> newest
                        'calls' => $locationCalls,
                    ];
                })
                ->sortBy(function ($location) {

                    // Sort LOCATION markers by their first/oldest call
                    return $location['calls']->first()['datetime'] ?? '';
                })
                ->values();

            return response()->json([
                'status' => true,
                'message' => 'Call locations loaded successfully.',

                'filter' => [
                    'type' =>  $filterType,
                    'start_date' =>  $startDate->toDateString(),
                    'end_date' => $endDate->toDateString(),
                    'month' => $filterType === 'month' ? $startDate->format('M-Y') : null,
                    'staff_id' => $request->input('staff_id'),
                    'status' => $request->input('status', 'all' ),
                    'search' => $request->input('search'),
                ],

                'summary' => [
                    'total_calls' => $totalCalls,
                    'mapped_calls' => $mappedCalls,
                    'unmapped_calls' => $totalCalls -  $mappedCalls,
                    'unique_locations' => $uniqueLocations,
                    'incoming' => $incoming,
                    'outgoing' => $outgoing,
                    'missed' => $missed,
                    'rejected' => $rejected,
                    'dialed' => $dialed,
                ],

                'latest_call' => $latestCall,
                'data' => $data,
                'locations' => $groupedLocations,
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {

            return response()->json([
                'status' => false,
                'message' => 'Invalid filter parameters.',
                'errors' => $e->errors(),
                'data' => [],
            ], 422);

        } catch (\Throwable $e) {
            return response()->json([
                'status' => false,
                'message' =>'Unable to load location tracker data.',
                'error' =>$e->getMessage(),
                'data' => [],
            ], 500);
        }
    }

    private function getCallLocationStatus(int $status): array
    {
        return match ($status) {

            0 => [
                'text'  => 'Outgoing',
                'class' => 'outgoing',
                'icon'  => 'mdi-phone-outgoing',
            ],

            1 => [
                'text'  => 'Incoming',
                'class' => 'incoming',
                'icon'  => 'mdi-phone-incoming',
            ],

            2 => [
                'text'  => 'Rejected',
                'class' => 'rejected',
                'icon'  => 'mdi-phone-cancel',
            ],

            3 => [
                'text'  => 'Missed',
                'class' => 'missed',
                'icon'  => 'mdi-phone-missed',
            ],

            4 => [
                'text'  => 'Dialed',
                'class' => 'dialed',
                'icon' => 'mdi-phone-dial',
            ],

            default => [
                'text'  => 'Unknown',
                'class' => 'dialed',
                'icon'  => 'mdi-phone-outline',
            ],
        };
    }

    private function resolveLocationContactNames($calls)
    {
        if ($calls->isEmpty()) {
            return collect();
        }


        $phones = $calls
            ->pluck('phone_no')
            ->filter(function ($phone) {
                return $phone !== null
                    && $phone !== '';
            })
            ->map(function ($phone) {
                return substr(
                    (string) $phone,
                    -10
                );
            })
            ->filter()
            ->unique()
            ->values()
            ->toArray();


        if (empty($phones)) {
            return collect();
        }


        $internalMap =
            $this->getLatestContactSource(
                'egc_internal_cugs',
                'cug_mobile_no',
                'user_name',
                $phones
            );

        $customerMap = $this->getLatestContactSource( 'egc_staff','mobile_no','staff_name', $phones);

        $leadMap =
            $this->getLatestContactSource(
                'egc_applicant',
                'mobile',
                'applicant_name',
                $phones
            );

        $contactIds = $calls
            ->pluck('contact_id')
            ->filter()
            ->unique()
            ->values()
            ->toArray();


        $contactMap = collect();


        if (!empty($contactIds)) {

            $contactMap = DB::table(
                    'egc_call_contacts'
                )
                ->whereIn(
                    'sno',
                    $contactIds
                )
                ->select([
                    'sno',
                    'name'
                ])
                ->get()
                ->keyBy('sno');
        }

        return $calls->mapWithKeys(
            function ($call) use (
                $internalMap,
                $customerMap,
                $leadMap,
                $contactMap
            ) {

                $phone = substr(
                    (string) $call->phone_no,
                    -10
                );

                $name = null;

                if (
                    isset($internalMap[$phone]) &&
                    trim((string) $internalMap[$phone]) !== ''
                ) {
                    $name =
                        $internalMap[$phone];
                }

                if (
                    $name === null &&
                    isset($customerMap[$phone]) &&
                    trim((string) $customerMap[$phone]) !== ''
                ) {
                    $name =
                        $customerMap[$phone];
                }

                if (
                    $name === null &&
                    isset($leadMap[$phone]) &&
                    trim((string) $leadMap[$phone]) !== ''
                ) {
                    $name =
                        $leadMap[$phone];
                }

                if (
                    $name === null &&
                    $call->contact_id &&
                    isset($contactMap[$call->contact_id])
                ) {
                    $contactName =
                        $contactMap[
                            $call->contact_id
                        ]->name ?? null;

                    if (
                        trim((string) $contactName) !== ''
                    ) {
                        $name =
                            $contactName;
                    }
                }


                return [
                    $call->sno =>
                        $name ?: 'Unknown Contact'
                ];
            }
        );
    }

    private function getLatestContactSource( string $table, string $mobileColumn, string $nameColumn,  array $phones ) {
        $result = collect();

        

        foreach (array_chunk($phones, 1000) as $phoneChunk) {

            $rows = DB::table($table)
                ->whereIn(
                    $mobileColumn,
                    $phoneChunk
                )
                ->select([
                    'sno',
                    $mobileColumn,
                    $nameColumn,
                ])
                ->orderByDesc('sno')
                ->get();

            /*
            |--------------------------------------------------------------------------
            | First row = latest sno for that mobile
            |--------------------------------------------------------------------------
            */

            foreach ($rows as $row) {

                $mobile =
                    (string) $row->{$mobileColumn};

                if (
                    $mobile === '' ||
                    $result->has($mobile)
                ) {
                    continue;
                }

                $result->put(
                    $mobile,
                    $row->{$nameColumn}
                );
            }
        }

        return $result->all();
    }
    
    
}
