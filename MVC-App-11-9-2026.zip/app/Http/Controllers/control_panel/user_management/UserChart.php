<?php

namespace App\Http\Controllers\control_panel\user_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\UserRoleExport;
use Maatwebsite\Excel\Facades\Excel;

class UserChart extends Controller
{
  public function index()
  {

    // $userRole = UserRoleModel::where('eibs_user_role.status', '!=', 2)
    //   ->leftJoin('eibs_user_role as parent_role', 'eibs_user_role.user_role_id', '=', 'parent_role.sno')
    //   ->select(
    //     'eibs_user_role.sno',
    //     'eibs_user_role.role_id',
    //     'eibs_user_role.role_name',
    //     'eibs_user_role.map_under',
    //     'eibs_user_role.user_role_id',
    //     'eibs_user_role.status',
    //     'parent_role.role_name as parent_role_name'
    //   )
    //   ->orderBy('eibs_user_role.sno', 'desc')
    //   ->get();
    // $pageConfigs = ['myLayout' => 'default'];
    // return view('content.user_management.user_role.list', compact('userRole', 'pageConfigs'));
    return view('content.control_panel.user_management.user_chart.chart_list');
  }
  public function ExportExcel()
  {
    return Excel::download(new UserRoleExport, 'user-role-export.xlsx'); // Adjust filename and extension as needed
  }
  public function List()
  {
    $user = UserRoleModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $user
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'role_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $role_name          = $request->role_name;
      $map_under = $request->has('map_under') ? 1 : 0;
      $user_role_id       = $request->user_role_id;
      // $user_id            = $request->user()->id;
      $user_id            = $request->user()->user_id;
      $chk = UserRoleModel::where('role_name', ucwords($role_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        return redirect()->back();
      } else {
        $category_check = UserRoleModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $role_id = "UR-0001/" . $year;
        } else {

          $data = $category_check->role_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("UR-%04d", $next_number);

          $year = substr(date("y"), -2);
          $role_id = $request . '/' . $year;
        }


        $add_user = new UserRoleModel();
        $add_user->role_id           = $role_id;
        $add_user->role_name         = Ucfirst($role_name);
        $add_user->map_under         = $map_under;
        $add_user->user_role_id      = $user_role_id;
        $add_user->created_by        = $user_id;
        $add_user->updated_by        = $user_id;

        $add_user->save();

        if ($add_user) {
            // Flash a success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'User Role added Successfully!'
            ]);
        
            // Store role_id and current time in the session
            session([
                'role_id' => $add_user->sno,
                'role_id_set_time' => now(),
            ]);
        
            // Redirect to the users manage add page
            return redirect()->route('users-manage-users_add');
        } else {
            // Flash an error message
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the User Role!'
            ]);
        
            // Redirect back to the previous page
            return redirect()->back();
        }

      }
      
    }
  }

  public function Edit($id)
  {
    $role = UserRoleModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'role_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $role_name          = $request->role_name;
      $map_under          = $request->map_under;
      $user_role_id       = $request->user_role_id;

      $upd_user =  UserRoleModel::where('sno', $id)->first();

      $chk = UserRoleModel::where('role_name', ucwords($role_name))->where('status', '!=', 2)->first();

      if ($chk) {
        if ($chk->sno != $id) {
          $result = response([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has been  already assigned!',
            'data'      => null,

          ], 200);
          return redirect()->back();
        } else {
            $upd_user->role_name         = Ucfirst($role_name);
              $upd_user->map_under         = $map_under;
              $upd_user->user_role_id      = $user_role_id;
              $upd_user->update();
        
        
              if ($upd_user) {
                $result = response([
                  'status'    => 200,
                  'message'   => 'Successfully Updated!',
                  'error_msg' => null,
                  'data'      => null,
                ], 200);
              } else {
                $result = response([
                  'status'    => 401,
                  'message'   => 'Incorrect format input feilds',
                  'error_msg' => 'Incorrect format input feilds',
                  'data'      => null,
                ], 401);
              }
              return $result;
        }
      }
      
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}