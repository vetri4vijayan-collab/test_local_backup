<?php

namespace App\Http\Controllers\accounts_finance;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Validation\Rule;

use App\Exports\ExpenseExport;

class ExpenseController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Expenditure Management
    |--------------------------------------------------------------------------
    */

    public function index(): View
    {
        $expenseCategories =  DB::table('egc_acc_expense_categories')->where('status', 0)->get();
        return view('content.accounts_finance.expenditure.expense_log',['expenseCategories'=>$expenseCategories]);
    }

    /*
    |--------------------------------------------------------------------------
    | Dashboard
    |--------------------------------------------------------------------------
    */

    public function dashboard(Request $request): JsonResponse
    {
        //
    }

    public function dashboardCards(Request $request): JsonResponse
{
    $query = DB::table('egc_acc_expense_logs')
        ->where('status',0);

    /*
    |--------------------------------------------------------------------------
    | Filters
    |--------------------------------------------------------------------------
    */

    if($request->filled('company')){

        $query->where('company_id',$request->company);

    }

    if($request->filled('entity')){

        $query->where('entity_id',$request->entity);

    }

    /*
    |--------------------------------------------------------------------------
    | Cards
    |--------------------------------------------------------------------------
    */

    $totalExpense=(clone $query)

        ->sum('amount');

    $monthlyExpense=(clone $query)

        ->whereYear('date',now()->year)

        ->whereMonth('date',now()->month)

        ->sum('amount');

    $todayExpense=(clone $query)

        ->whereDate('date',today())

        ->sum('amount');

    $dailyAverage=(clone $query)

        ->avg('amount');

    return response()->json([

        'status'=>true,

        'data'=>[

            'total_expense'=>

                round($totalExpense,2),

            'monthly_expense'=>

                round($monthlyExpense,2),

            'today_expense'=>

                round($todayExpense,2),

            'daily_average'=>

                round($dailyAverage,2)

        ]

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Charts
    |--------------------------------------------------------------------------
    */

    public function monthlyChart(Request $request): JsonResponse
{

    $year=$request->year ?? now()->year;

    $rows=DB::table('egc_acc_expense_logs')

        ->selectRaw(

            'MONTH(date) month,

            SUM(amount) total'

        )

        ->where('status',0)

        ->whereYear('date',$year)

        ->groupByRaw('MONTH(date)')

        ->orderByRaw('MONTH(date)')

        ->get();

    $months=[

        'Jan','Feb','Mar',

        'Apr','May','Jun',

        'Jul','Aug','Sep',

        'Oct','Nov','Dec'

    ];

    $values=array_fill(0,12,0);

    foreach($rows as $row){

        $values[$row->month-1]=(double)

            $row->total;

    }

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$months,

            'values'=>$values

        ]

    ]);

}

    public function categoryChart(Request $request): JsonResponse
{

    $rows=DB::table('egc_acc_expense_logs as el')

        ->join(

            'egc_acc_expense_categories as ec',

            'ec.sno',

            '=',

            'el.category_id'

        )

        ->selectRaw(

            'ec.category_name,

            SUM(el.amount) total'

        )

        ->where('el.status',0)

        ->groupBy(

            'ec.sno',

            'ec.category_name'

        )

        ->orderByDesc('total')

        ->get();

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$rows->pluck('category_name'),

            'values'=>$rows->pluck('total'),

            'total'=>$rows->sum('total')

        ]

    ]);

}

    public function productChart(Request $request): JsonResponse
{

    $limit=$request->limit ?? 10;

    $rows=DB::table('egc_acc_expense_logs as el')

        ->join(

            'egc_acc_expense_products as ep',

            'ep.sno',

            '=',

            'el.product_id'

        )

        ->selectRaw(

            'ep.product_name,

            SUM(el.amount) total'

        )

        ->where('el.status',0)

        ->groupBy(

            'ep.sno',

            'ep.product_name'

        )

        ->orderByDesc('total')

        ->limit($limit)

        ->get();

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$rows->pluck('product_name'),

            'values'=>$rows->pluck('total')

        ]

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Timeline
    |--------------------------------------------------------------------------
    */

    public function timeline(Request $request): JsonResponse
{
    $limit = $request->input('limit', 10);

    $query = DB::table('egc_acc_expense_logs as el')

        ->leftJoin('egc_acc_expense_categories as ec', 'ec.sno', '=', 'el.category_id')

        ->leftJoin('egc_acc_expense_products as ep', 'ep.sno', '=', 'el.product_id')

        ->leftJoin('egc_acc_tiderc_drac as cc', 'cc.sno', '=', 'el.tiderc_id')

        ->leftJoin('egc_company as c', 'c.sno', '=', 'el.company_id')

        ->leftJoin('egc_staff as st', 'st.sno', '=', 'el.created_by')

        ->where('el.status',0);

        $query->select([

    'el.sno',

    'el.date',

    'el.amount',

    'ep.product_name',

    'ec.category_name',

    'ec.icon',

    'c.company_name',

    'cc.b_name',

    'st.staff_name',

    'el.created_at'

]);
$rows = $query

    ->orderByDesc('el.created_at')

    ->limit($limit)

    ->get();
    $data = $rows->map(function($row){

    return [

        'id' => $row->sno,

        'product' => $row->product_name,

        'category' => $row->category_name,

        'amount' => (double)$row->amount,

        'company' => $row->company_name ?? 'Elysium Groups',

        'credit_card' => $row->b_name,

        'time' => Carbon::parse($row->created_at)

            ->diffForHumans(),

        'icon' => $this->timelineIcon($row->icon),

        'color' => $this->timelineColor($row->category_name)

    ];

});
return response()->json([

    'status'=>true,

    'data'=>$data

]);
}
private function timelineIcon(?string $icon): string
{
    if(!empty($icon)){

        return $icon;

    }

    return 'ti ti-wallet';

}
private function timelineColor(?string $category): string
{
    return match(strtolower($category ?? '')){

        'software' => '#B12A1F',

        'marketing' => '#F59E0B',

        'travel' => '#10B981',

        'office' => '#3B82F6',

        default => '#6B7280'

    };
}

    /*
    |--------------------------------------------------------------------------
    | DataTable
    |--------------------------------------------------------------------------
    */

    public function datatable(Request $request)
    {
        $query = DB::table('egc_acc_expense_logs as el')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'el.company_id')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 'el.entity_id')
            ->leftJoin('egc_acc_expense_categories as ec','ec.sno','=','el.category_id')
            ->leftJoin('egc_acc_expense_products as ep','ep.sno','=','el.product_id')
            ->leftJoin('egc_acc_tiderc_drac as cc','cc.sno','=','el.tiderc_id')
            ->leftJoin('egc_staff as st','st.sno','=','el.created_by')
            ->where('el.status', 0);

            if ($request->filled('search')) {
                $search = trim($request->input('search'));
                $query->where(function ($q) use ($search) {
                    $q->where('ep.product_name','like',"%{$search}%")
                    ->orWhere( 'ec.category_name','like',"%{$search}%")
                    ->orWhere('c.company_name','like', "%{$search}%")
                    ->orWhere('e.entity_name','like',"%{$search}%")
                    ->orWhere('cc.b_name','like',"%{$search}%")
                    ->orWhere('el.reference_no', 'like',"%{$search}%")
                    ->orWhere('st.staff_name','like',"%{$search}%");
                });
            }

            if ($request->filled('company')) {
                $query->where('el.company_id',$request->input('company'));
            }
            if ($request->filled('entity')) {
                $query->where( 'el.entity_id',$request->input('entity'));
            }
            if ($request->filled('category')) {
                $query->where('el.category_id',$request->input('category'));
            }
            if ($request->filled('product')) {
                $query->where('el.product_id',$request->input('product'));
            }
            if ($request->filled('credit_card')) {
                $query->where('el.tiderc_id',$request->input('credit_card'));
            }
            if ($request->filled('date')) {
                $query->whereDate('el.date',$request->input('date'));
            }
            // return $request->filled('financial_year');
            // if ($request->filled('financial_year')) {
            //     $financialYear = $request->input('financial_year');
            //     if (preg_match( '/^(\d{4})-(\d{4})$/', $financialYear,$matches)) {
            //         $startYear = (int) $matches[1];
            //         $endYear   = (int) $matches[2];
            //         $query>whereBetween('el.date',[ $startYear . '-04-01',$endYear . '-03-31']);
            //     }
            // }
      
            if ($request->filled('month')) {
                $query->whereMonth('el.date', $request->input('month') );
            }
            if ($request->filled('amount')) {
                $amount = $request->input('amount');
                if (is_numeric($amount)) {
                    $query->where('el.amount',$amount);
                }
            }

            if ($request->filled('reference')) {
                $reference =trim($request->input('reference'));
                $query->where('el.reference_no','like',"%{$reference}%");
            }

          
           
            if ($request->filled('status')) {
                $query->where('el.status',$request->input('status'));
            }

            $total = (clone $query)->count();

            $page = max(1, (int) $request->input('page', 1));

            $perPage = (int) $request->input( 'per_page',25);

        if (!in_array($perPage,[10, 25, 50, 100,500], true)) {
            $perPage = 25;
        }

        $offset =($page - 1) * $perPage;

        $expenses = $query
            ->select([
                'el.sno as id',
                'el.date as expense_date',
                'el.reference_no',
                'el.amount',

                'el.expense_frequency',
                'el.next_payment_date',
                'el.custom_start_date',

                'el.custom_end_date',

                'c.company_name',
                'c.company_short_name',
                'c.company_base_color',

                'e.entity_name',
                'e.entity_short_name',
                'e.entity_base_color',

                'ec.category_name',
                'ec.icon',

                'ep.product_name',
                'ep.product_code',

                'cc.b_name as credit_card',
                'cc.rd_prt1',
                'cc.rd_prt2',
                'cc.rd_prt3',
                'cc.rd_prt4',
                'cc.rd_prt5',

                'st.staff_name'
            ])
            ->orderBy('el.date','desc')
            ->orderBy('el.sno','desc')
            ->skip($offset)
            ->take($perPage)
            ->get();

        
   

        $data = $expenses->map(
            function ($row) {

                $companyName =
                    $row->company_name ?? 'Elysium Groups';

                $companyShort =
                    $row->entity_short_name
                    ?: 'EGC';
                $companyBaseColor =
                    $row->company_base_color
                    ?: '#B12A1F';
                $entityBaseColor =
                    $row->entity_base_color
                    ?: '#B12A1F';


                $staffName =
                    $row->staff_name ?? '';


                return [

                    'id' => (int) $row->id,

                    'expense_date' =>
                        $row->expense_date,

                    'company' =>
                        $companyName,

                    'company_short' =>
                        strtoupper($companyShort,),

                    'company_code' => '',
                    'company_base_color' => $companyBaseColor,
                    'entity_base_color' => $entityBaseColor,

                    'entity' =>
                        $row->entity_name ?? '',

                    'category' =>
                        $row->category_name ?? '',

                    'category_icon' =>
                        $row->icon ?? '',

                    'category_color' =>
                        '#B12A1F',

                    'product' =>
                        $row->product_name ?? '',

                    'product_code' =>
                        $row->product_code ?? '',

                    'credit_card' =>
                        $row->credit_card ?? '',

                    'card_last_four' =>
                        $this->getCreditCardLastFour($row),

                    'reference' =>
                        $row->reference_no ?? '',

                    'amount' =>
                        (float) ($row->amount ?? 0),

                    'frequency' =>
                        $this->formatExpenseFrequency(
                            $row->expense_frequency ?? 'one_time'
                        ),

                    'frequency_key' =>
                        $row->expense_frequency ?? 'one_time',

                    'next_payment_date' =>
                        $row->next_payment_date,

                    'custom_start_date' =>
                        $row->custom_start_date,

                    'custom_end_date' =>
                        $row->custom_end_date,

                    'created_by' =>
                        $staffName,

                    'created_initial' =>
                        $staffName
                            ? strtoupper(
                                substr(
                                    $staffName,
                                    0,
                                    1
                                )
                            )
                            : ''
                ];

            }
        )->values();


        /*
        |--------------------------------------------------------------------------
        | Custom table response
        |--------------------------------------------------------------------------
        */

        return response()->json([

            'data' =>
                $data,

            'total' =>
                $total,

            'page' =>
                $page,

            'per_page' =>
                $perPage,

            'total_pages' =>
                $perPage > 0
                    ? (int) ceil(
                        $total / $perPage
                    )
                    : 1

        ]);
    }

    private function formatExpenseFrequency(?string $frequency): string
    {
        return match ($frequency) {

            'daily' =>
                'Daily',

            'weekly' =>
                'Weekly',

            'monthly' =>
                'Monthly',

            'quarterly' =>
                'Quarterly',

            'yearly' =>
                'Yearly',

            'custom' =>
                'Custom Schedule',

            default =>
                'One Time',
        };
    }

    private function getCreditCardLastFour($row)
    {
        if (
            isset($row->rd_prt4) &&
            $row->rd_prt4 !== null &&
            $row->rd_prt4 !== ''
        ) {

            return str_pad(
                (string) $row->rd_prt4,
                4,
                '0',
                STR_PAD_LEFT
            );

        }

        return '';
    }

    /*
    |--------------------------------------------------------------------------
    | CRUD
    |--------------------------------------------------------------------------
    */

    public function store(Request $request): JsonResponse
{
    $validator = Validator::make(
        $request->all(),
        [
            'company_id' => [
                'required',
                'integer',
            ],

            'entity_id' => [
                'nullable',
                'integer',
            ],

            'tiderc_id' => [
                'required',
                'integer',
            ],

            'date' => [
                'required',
                'date',
            ],

            'category_id' => [
                'required',
                'integer',
            ],

            'product_id' => [
                'required',
                'integer',
            ],

            'reference_no' => [
                'required',
                'string',
                'max:250',
            ],

            'amount' => [
                'required',
                'numeric',
                'min:0.01',
            ],

            'expense_frequency' => [
                'required',
                Rule::in([
                    'one_time',
                    'daily',
                    'weekly',
                    'monthly',
                    'quarterly',
                    'yearly',
                    'custom',
                ]),
            ],

            'custom_start_date' => [
                'nullable',
                'date',
                'required_if:expense_frequency,custom',
            ],

            'custom_end_date' => [
                'nullable',
                'date',
                'required_if:expense_frequency,custom',
                'after_or_equal:custom_start_date',
            ],

            'remarks' => [
                'nullable',
                'string',
                'max:500',
            ],
        ],
        [
            'company_id.required' =>
                'Please select a company.',

            'entity_id.required' =>
                'Please select an entity.',

            'tiderc_id.required' =>
                'Please select a credit card.',

            'date.required' =>
                'Please select the expense date.',

            'category_id.required' =>
                'Please select an expense category.',

            'product_id.required' =>
                'Please select an expense product.',

            'reference_no.required' =>
                'Transaction name is required.',

            'amount.required' =>
                'Expense amount is required.',

            'amount.numeric' =>
                'Expense amount must be a valid number.',

            'amount.min' =>
                'Expense amount must be greater than zero.',

            'expense_frequency.required' =>
                'Please select an expense frequency.',

            'custom_start_date.required_if' =>
                'Custom start date is required.',

            'custom_end_date.required_if' =>
                'Custom end date is required.',

            'custom_end_date.after_or_equal' =>
                'Custom end date must be on or after the start date.',
        ]
    );

     $validator->sometimes(
        'entity_id',
        ['required'],
        function ($input) {
            return (int) $input->company_id !== 0;
        }
    );

    /*
    |--------------------------------------------------------------------------
    | Validate entity when supplied
    |--------------------------------------------------------------------------
    */

    $validator->sometimes(
        'entity_id',
        ['exists:egc_entity,sno'],
        function ($input) {
            return !empty($input->entity_id);
        }
    );

    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $validator->errors(),
        ], 422);
    }

    DB::beginTransaction();

    try{
        $user_id = $request->user()->user_id;

        $expenseDate = Carbon::parse($request->date);

        $frequency = $request->expense_frequency ?? 'one_time';

        $nextPaymentDate = null;

        $customStartDate = null;
        $customEndDate = null;

        switch ($frequency) {

            case 'daily':

                $nextPaymentDate = $expenseDate->copy()->addDay();

                break;


            case 'weekly':

                $nextPaymentDate = $expenseDate->copy()->addWeek();

                break;


            case 'monthly':

                $nextPaymentDate = $expenseDate->copy()->addMonth();

                break;


            case 'quarterly':

                $nextPaymentDate = $expenseDate->copy()->addMonths(3);

                break;


            case 'yearly':

                $nextPaymentDate = $expenseDate->copy()->addYear();

                break;


            case 'custom':

                /*
                |--------------------------------------------------------------------------
                | Custom Payment Range
                |--------------------------------------------------------------------------
                |
                | Custom does NOT use interval/unit.
                |
                | Start date = first possible payment date
                | End date   = last allowed payment date
                |
                */

                if (
                    !$request->filled('custom_start_date') ||
                    !$request->filled('custom_end_date')
                ) {
                    $nextPaymentDate = null;
                    break;
                }


                $customStartDate = Carbon::parse(
                    $request->custom_start_date
                );

                $customEndDate = Carbon::parse(
                    $request->custom_end_date
                );


                /*
                |--------------------------------------------------------------------------
                | Validate date range
                |--------------------------------------------------------------------------
                */

                if ($customEndDate->lt($customStartDate)) {

                    return response()->json([
                        'success' => false,
                        'message' => 'Custom end date cannot be before the start date.',
                        'errors' => [
                            'custom_end_date' => [
                                'Custom end date cannot be before the start date.'
                            ],
                        ],
                    ], 422);
                }


                /*
                |--------------------------------------------------------------------------
                | Determine Next Payment
                |--------------------------------------------------------------------------
                |
                | Start date must be AFTER the expense date.
                |
                */

                if ($customStartDate->gt($expenseDate)) {

                    $nextPaymentDate = $customStartDate->copy();

                } else {

                    /*
                    * Start date is already reached/passed.
                    *
                    * Since custom has no interval/unit,
                    * another occurrence cannot be calculated.
                    */

                    $nextPaymentDate = null;
                }


                /*
                |--------------------------------------------------------------------------
                | Never allow payment after custom end date
                |--------------------------------------------------------------------------
                */

                if (
                    $nextPaymentDate &&
                    $nextPaymentDate->gt($customEndDate)
                ) {
                    $nextPaymentDate = null;
                }

                break;


            case 'one_time':
            default:

                $nextPaymentDate = null;

                break;
        }

        $id = DB::table('egc_acc_expense_logs')

            ->insertGetId([

                'company_id'   => $request->company_id,

                'entity_id'    => $request->entity_id,

                'branch_id'    => $request->branch_id,

                'category_id'  => $request->category_id,

                'product_id'   => $request->product_id,

                'tiderc_id'    => $request->tiderc_id,

                'reference_no' =>

                    $request->reference_no,

                'amount'       =>

                    $request->amount,

                'remarks'      =>

                    $request->remarks,

                'date'         =>

                    $request->date,
                
                'next_payment_date' => $nextPaymentDate
                    ? $nextPaymentDate->toDateString()
                    : null,

                'recurring_status' => $nextPaymentDate ? 1 : 0,

                'expense_frequency' => $frequency,

                'custom_start_date' => $customStartDate
                    ? $customStartDate->toDateString()
                    : null,

                'custom_end_date' => $customEndDate
                    ? $customEndDate->toDateString()
                    : null,

                'created_by'   =>

                    $user_id,

                'updated_by'   =>

                    $user_id,

                'created_at'   => now(),

                'updated_at'   => now(),

                'status'       => 0

            ]);

        DB::commit();

        return response()->json([

            'status'=>true,

            'id'=>$id,

            'message'=>'Expense Added Successfully.'

        ]);

    }

    catch(\Throwable $e){

        DB::rollBack();

        return response()->json([

            'status'=>false,

            'message'=>$e->getMessage()

        ],500);

    }

}

    public function show(int $expense): JsonResponse
{
    return $this->edit($expense);
}

   public function edit(int $expense): JsonResponse
{
    $expense = DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->first();

    if(!$expense){

        return response()->json([

            'status'=>false,

            'message'=>'Expense Not Found.'

        ],404);

    }

    return response()->json([

        'status'=>true,

        'data'=>$expense

    ]);

}

    public function update(
    Request $request,
    int $expense
): JsonResponse
{

    $validator = Validator::make($request->all(),[

        'company_id'=>'required',

        'entity_id'=>'required',

        'category_id'=>'required',

        'product_id'=>'required',

        'tiderc_id'=>'required',

        'amount'=>'required|numeric',

        'date'=>'required'

    ]);

    if($validator->fails()){

        return response()->json([

            'status'=>false,

            'errors'=>$validator->errors()

        ],422);

    }

    DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->update([

            'company_id'=>$request->company_id,

            'entity_id'=>$request->entity_id,

            'branch_id'=>$request->branch_id,

            'category_id'=>$request->category_id,

            'product_id'=>$request->product_id,

            'tiderc_id'=>$request->tiderc_id,

            'reference_no'=>$request->reference_no,

            'amount'=>$request->amount,

            'remarks'=>$request->remarks,

            'date'=>$request->date,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Expense Updated Successfully.'

    ]);

}

    public function destroy(int $expense): JsonResponse
{

    DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->update([

            'status'=>2,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Expense Deleted Successfully.'

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Duplicate
    |--------------------------------------------------------------------------
    */

    public function duplicate(int $expense): JsonResponse
{
    $expenseData = DB::table('egc_acc_expense_logs')
        ->where('sno', $expense)
        ->where('status', 0)
        ->first();

    if (!$expenseData) {

        return response()->json([
            'status' => false,
            'message' => 'Expense not found.'
        ], 404);

    }

    $newExpense = (array) $expenseData;

    unset($newExpense['sno']);

    $newExpense['reference_no'] = null;

    $newExpense['created_by'] = session('staff_id');

    $newExpense['updated_by'] = session('staff_id');

    $newExpense['created_at'] = now();

    $newExpense['updated_at'] = now();

    $id = DB::table('egc_acc_expense_logs')->insertGetId($newExpense);

    return response()->json([

        'status' => true,

        'id' => $id,

        'message' => 'Expense duplicated successfully.'

    ]);
}

    /*
    |--------------------------------------------------------------------------
    | History
    |--------------------------------------------------------------------------
    */

   public function history(int $expense): JsonResponse
{
    $expense = DB::table('egc_acc_expense_logs')

        ->leftJoin('egc_staff','egc_staff.sno','=','egc_acc_expense_logs.created_by')

        ->where('egc_acc_expense_logs.sno',$expense)

        ->select(

            'egc_acc_expense_logs.created_at',

            'egc_acc_expense_logs.updated_at',

            'egc_staff.staff_name'

        )

        ->first();

    return response()->json([

        'status'=>true,

        'data'=>$expense

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Bulk
    |--------------------------------------------------------------------------
    */

    public function bulkDelete(Request $request): JsonResponse
{

    $ids = $request->ids;

    if(empty($ids)){

        return response()->json([

            'status'=>false,

            'message'=>'No expense selected.'

        ]);

    }

    DB::table('egc_acc_expense_logs')

        ->whereIn('sno',$ids)

        ->update([

            'status'=>2,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Selected expenses deleted successfully.'

    ]);

}

    public function bulkExport(Request $request)
{

    $ids = explode(',',$request->ids);

    return Excel::download(

        new ExpenseExport($ids),

        'Expense.xlsx'

    );

}

    /*
    |--------------------------------------------------------------------------
    | Dropdown APIs
    |--------------------------------------------------------------------------
    */

    public function companies(): JsonResponse
{

    return response()->json([
        'status'=>true,
        'data'=>DB::table('egc_company')
            ->where('status',0)
            ->orderBy('sno')
            ->select(
                'sno',
                'company_name'
            )
            ->get()
    ]);

}

    public function entities(Request $request): JsonResponse
{

    $query=DB::table('egc_entity')

        ->where('status',0);

    if($request->company_id){

        $query->where(

            'company_id',

            $request->company_id

        );

    }

    return response()->json([

        'status'=>true,

        'data'=>$query

            ->orderBy('sno')

            ->select(

                'sno',

                'entity_name'

            )

            ->get()

    ]);

}

    public function categories(): JsonResponse
{

    return response()->json([

        'status'=>true,
        'success' => true,

        'data'=>DB::table(

            'egc_acc_expense_categories'

        )

        ->where('status',0)

        ->orderBy('category_name')

        ->get()

    ]);

}

    public function products(Request $request): JsonResponse
{

    $query=DB::table('egc_acc_expense_products')
    ->where('status',0);

    if($request->category_id){
        $query->where('category_id', $request->category_id);
    }

    return response()->json([

        'status'=>true,

        'data'=>$query

            ->orderBy('product_name')

            ->get()

    ]);

}

    public function creditCards(Request $request): JsonResponse
{

    $query=DB::table(

        'egc_acc_tiderc_drac'

    )

    ->where('status',0);

    // if($request->company_id){

    //     $query->where(

    //         'company_id',

    //         $request->company_id

    //     );

    // }

    // if($request->entity_id){

    //     $query->where(

    //         'entity_id',

    //         $request->entity_id

    //     );

    // }

    return response()->json([

        'status'=>true,

        'data'=>$query

            ->orderBy('b_name')

            ->get()

    ]);

}


// Category 
public function categoryStore(Request $request)
{
    $validator = Validator::make(
        $request->all(),
        [
            // 'category_code' => [
            //     'required',
            //     'string',
            //     'max:200',
            // ],

            'category_name' => [
                'required',
                'string',
                'max:250',
            ],

            'icon' => [
                'required',
                'string',
                'max:200',
            ],
        ],
        [
            // 'category_code.required' => 'Category code is required.',
            'category_name.required' => 'Category name is required.',
            'icon.required' => 'Please select a category icon.',
        ]
    );


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $validator->errors(),
        ], 422);

    }

     $categoryName = trim($request->category_name);


     $categoryCode = strtoupper($categoryName);

    // Replace anything other than letters/numbers with -
    $categoryCode = preg_replace('/[^A-Z0-9]+/', '-', $categoryCode);

    // Remove - from beginning/end
    $categoryCode = trim($categoryCode, '-');

    // Fallback in case the name contains no usable characters
    if ($categoryCode === '') {
        $categoryCode = 'CATEGORY';
    }

    /*
    |--------------------------------------------------------------------------
    | Make Code Unique
    |--------------------------------------------------------------------------
    */

    $baseCode = $categoryCode;
    $counter = 1;

    while (
        DB::table('egc_acc_expense_categories')
            ->where('category_code', $categoryCode)
            ->where('status', 0)
            ->exists()
    ) {
        $counter++;

        $categoryCode = $baseCode . '-' . $counter;
    }


    $exists = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'category_code',
            $categoryCode
        )
        ->where(
            'status',
            0
        )
        ->exists();


    if ($exists) {

        return response()->json([
            'success' => false,
            'message' => 'Category code already exists.',
            'errors' => [
                'category_code' => [
                    'Category code already exists.'
                ]
            ],
        ], 422);

    }


    $id = DB::table(
        'egc_acc_expense_categories'
    )->insertGetId([

        'category_code' => $categoryCode,

        'category_name' => $categoryName,

        'icon' => $request->icon,

        'created_by' => $request->user()->user_id ?? 0,

        'updated_by' => $request->user()->user_id ?? 0,

        'created_at' => now(),

        'updated_at' => now(),

        'status' => 0,

    ]);


    return response()->json([

        'success' => true,

        'message' => 'Expense category created successfully.',

        'data' => [
            'sno' => $id,
        ],

    ]);
}

public function categoryShow($id)
{
    $category = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->where(
            'status',
            0
        )
        ->first();


    if (!$category) {

        return response()->json([
            'success' => false,
            'message' => 'Expense category not found.',
        ], 404);

    }


    return response()->json([

        'success' => true,

        'data' => $category,

    ]);
}

public function categoryUpdate(
    Request $request,
    $id
) {

    $validator = Validator::make(
        $request->all(),
        [
            // 'category_code' => [
            //     'required',
            //     'string',
            //     'max:200',
            // ],

            'category_name' => [
                'required',
                'string',
                'max:250',
            ],

            'icon' => [
                'required',
                'string',
                'max:200',
            ],
        ],
        [
            // 'category_code.required' => 'Category code is required.',
            'category_name.required' => 'Category name is required.',
            'icon.required' => 'Please select a category icon.',
        ]
    );


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $validator->errors(),
        ], 422);

    }


    $category = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->where(
            'status',
            0
        )
        ->first();


    if (!$category) {

        return response()->json([
            'success' => false,
            'message' => 'Expense category not found.',
        ], 404);

    }


    $categoryCode = strtoupper(
        trim($request->category_code)
    );


    $categoryName = trim(
        $request->category_name
    );


    $exists = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'category_code',
            $categoryCode
        )
        ->where(
            'sno',
            '!=',
            $id
        )
        ->where(
            'status',
            0
        )
        ->exists();


    if ($exists) {

        return response()->json([
            'success' => false,
            'message' => 'Category code already exists.',
            'errors' => [
                'category_code' => [
                    'Category code already exists.'
                ]
            ],
        ], 422);

    }


    DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->update([

            // 'category_code' => $categoryCode,

            'category_name' => $categoryName,

            'icon' => $request->icon,

            'updated_by' => $request->user()->user_id ?? 0,

            'updated_at' => now(),

        ]);


    return response()->json([

        'success' => true,

        'message' => 'Expense category updated successfully.',

        'data' => [
            'sno' => $id,
        ],

    ]);
}

public function categoryDestroy($id,Request $request)
{
    $category = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->where(
            'status',
            0
        )
        ->first();


    if (!$category) {

        return response()->json([
            'success' => false,
            'message' => 'Expense category not found.',
        ], 404);

    }


    DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->update([

            'status' => 2,

            'updated_by' => $request->user()->user_id ?? 0,

            'updated_at' => now(),

        ]);


    return response()->json([

        'success' => true,

        'message' => 'Expense category deleted successfully.',

    ]);
}

// expense Product

/**
 * Store Expense Product
 */
public function storeProduct(Request $request)
{
    $validator = Validator::make(
        $request->all(),
        [
            // 'product_code' => [
            //     'required',
            //     'string',
            //     'max:200',
            //     'regex:/^[A-Za-z0-9_-]+$/',
            //     // Rule::unique('egc_acc_expense_products', 'product_code')
            //     //     ->where(function ($query) {
            //     //         return $query->where('status', 0);
            //     //     }),
            // ],

            'product_name' => [
                'required',
                'string',
                'max:250',
            ],

            'category_id' => [
                'required',
                'integer',
                'exists:egc_acc_expense_categories,sno',
            ],

            // 'default_amount' => [
            //     'nullable',
            //     'numeric',
            //     'min:0',
            // ],
        ],
        [
            // 'product_code.required' =>
            //     'Product code is required.',

            'product_code.unique' =>
                'This product code already exists.',

            'product_code.regex' =>
                'Product code may contain only letters, numbers, hyphens and underscores.',

            'product_name.required' =>
                'Product name is required.',

            'category_id.required' =>
                'Please select an expense category.',

            // 'category_id.exists' =>
            //     'Selected expense category is invalid.',

            // 'default_amount.numeric' =>
            //     'Default amount must be a valid number.',

            // 'default_amount.min' =>
                // 'Default amount cannot be negative.',
        ]
    );


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors'  => $validator->errors(),
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Verify Active Category
    |--------------------------------------------------------------------------
    */

    // $categoryExists = DB::table(
    //     'egc_acc_expense_categories'
    // )
    //     ->where('sno', $request->category_id)
    //     ->where('status', 0)
    //     ->exists();


    // if (!$categoryExists) {

    //     return response()->json([
    //         'success' => false,
    //         'message' => 'Selected expense category is not active.',
    //         'errors' => [
    //             'category_id' => [
    //                 'Selected expense category is not active.'
    //             ],
    //         ],
    //     ], 422);
    // }

    $categoryExists = DB::table(
        'egc_acc_expense_products'
    )
        ->where('product_name', trim($request->product_name))
        ->where('category_id',$request->category_id)
        ->where('status','!=', 2)
        ->first();


    if ($categoryExists) {

        return response()->json([
            'success' => false,
            'message' => 'Expense Product is Already Exists.',
            'errors' => 'Expense Product is Already Exists',
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Current User
    |--------------------------------------------------------------------------
    */

    $userId = $request->user()->user_id ?? 0;
    $productName =trim($request->product_name);

     $productCode = strtoupper($productName);

        /*
        | Convert spaces and special characters to -
        |
        | Example:
        | "Office Laptop"       -> OFFICE-LAPTOP
        | "ChatGPT Subscription" -> CHATGPT-SUBSCRIPTION
        | "Travel & Hotel"      -> TRAVEL-HOTEL
        */

        $productCode = preg_replace(
            '/[^A-Z0-9]+/',
            '-',
            $productCode
        );

        /*
        | Remove leading/trailing hyphens
        */

        $productCode = trim(
            $productCode,
            '-'
        );


        /*
        | Fallback if product name contains
        | no usable characters.
        */

        if ($productCode === '') {

            $productCode = 'PRODUCT';
        }


        /*
        |--------------------------------------------------------------------------
        | Make Product Code Unique
        |--------------------------------------------------------------------------
        */

        $baseProductCode = $productCode;

        $counter = 1;


        while (
            DB::table('egc_acc_expense_products')
                ->where('product_code', $productCode)
                ->where('status', '!=', 2)
                ->exists()
        ) {

            $counter++;

            $productCode =
                $baseProductCode . '-' . $counter;
        }


    /*
    |--------------------------------------------------------------------------
    | Insert
    |--------------------------------------------------------------------------
    */

    $productId = DB::table(
        'egc_acc_expense_products'
    )->insertGetId([

        'product_code' =>$productCode,

        'product_name' =>
            trim($request->product_name),

        'default_amount' =>
            $request->filled('default_amount')
                ? (float) $request->default_amount
                : 0,

        'category_id' =>
            (int) $request->category_id,

        'created_by' =>
            $userId,

        'updated_by' =>
            $userId,

        'created_at' =>
            now(),

        'updated_at' =>
            now(),

        'status' =>
            0,
    ]);


    /*
    |--------------------------------------------------------------------------
    | Return Created Product
    |--------------------------------------------------------------------------
    */

    $product = DB::table(
        'egc_acc_expense_products as p'
    )
        ->leftJoin(
            'egc_acc_expense_categories as c',
            'c.sno',
            '=',
            'p.category_id'
        )
        ->select(
            'p.sno',
            'p.product_code',
            'p.product_name',
            'p.default_amount',
            'p.category_id',
            'c.category_name',
            'c.icon'
        )
        ->where('p.sno', $productId)
        ->first();


    return response()->json([
        'success' => true,
        'message' => 'Expense product created successfully.',
        'data' => $product,
    ]);
}
/**
 * Get Expense Product
 */
public function showProduct($id)
{
    $product = DB::table(
        'egc_acc_expense_products as p'
    )
        ->leftJoin(
            'egc_acc_expense_categories as c',
            'c.sno',
            '=',
            'p.category_id'
        )
        ->select(
            'p.sno',
            'p.product_code',
            'p.product_name',
            'p.default_amount',
            'p.category_id',
            'c.category_name',
            'c.icon'
        )
        ->where('p.sno', $id)
        ->where('p.status', 0)
        ->first();


    if (!$product) {

        return response()->json([
            'success' => false,
            'message' => 'Expense product not found.',
        ], 404);
    }


    return response()->json([
        'success' => true,
        'data' => $product,
    ]);
}

/**
 * Update Expense Product
 */
public function updateProduct(
    Request $request,
    $id
) {

    $product = DB::table(
        'egc_acc_expense_products'
    )
        ->where('sno', $id)
        ->where('status', 0)
        ->first();


    if (!$product) {

        return response()->json([
            'success' => false,
            'message' => 'Expense product not found.',
        ], 404);
    }


    $validator = Validator::make(
        $request->all(),
        [
            // 'product_code' => [
            //     'required',
            //     'string',
            //     'max:200',
            //     'regex:/^[A-Za-z0-9_-]+$/',

            //     Rule::unique(
            //         'egc_acc_expense_products',
            //         'product_code'
            //     )
            //         ->ignore(
            //             $id,
            //             'sno'
            //         )
            //         ->where(function ($query) {
            //             return $query->where(
            //                 'status',
            //                 0
            //             );
            //         }),
            // ],

            'product_name' => [
                'required',
                'string',
                'max:250',
            ],

            'category_id' => [
                'required',
                'integer',
                'exists:egc_acc_expense_categories,sno',
            ],

            // 'default_amount' => [
            //     'nullable',
            //     'numeric',
            //     'min:0',
            // ],
        ],
        [
            // 'product_code.required' =>
            //     'Product code is required.',

            // 'product_code.unique' =>
            //     'This product code already exists.',

            // 'product_code.regex' =>
            //     'Product code may contain only letters, numbers, hyphens and underscores.',

            'product_name.required' =>
                'Product name is required.',

            'category_id.required' =>
                'Please select an expense category.',

            'category_id.exists' =>
                'Selected expense category is invalid.',

            // 'default_amount.numeric' =>
            //     'Default amount must be a valid number.',

            // 'default_amount.min' =>
            //     'Default amount cannot be negative.',
        ]
    );


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors'  => $validator->errors(),
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Verify Active Category
    |--------------------------------------------------------------------------
    */

    $categoryExists = DB::table(
        'egc_acc_expense_categories'
    )
        ->where('sno', $request->category_id)
        ->where('status', 0)
        ->exists();


    if (!$categoryExists) {

        return response()->json([
            'success' => false,
            'message' => 'Selected expense category is not active.',
            'errors' => [
                'category_id' => [
                    'Selected expense category is not active.'
                ],
            ],
        ], 422);
    }


    $userId = $request->user()->user_id ?? 0;


    /*
    |--------------------------------------------------------------------------
    | Update
    |--------------------------------------------------------------------------
    */

    DB::table(
        'egc_acc_expense_products'
    )
        ->where('sno', $id)
        ->update([

            // 'product_code' =>
            //     strtoupper(
            //         trim($request->product_code)
            //     ),

            'product_name' =>
                trim($request->product_name),

            // 'default_amount' =>
            //     $request->filled('default_amount')
            //         ? (float) $request->default_amount
            //         : 0,

            'category_id' =>
                (int) $request->category_id,

            'updated_by' =>
                $userId,

            'updated_at' =>
                now(),
        ]);


    /*
    |--------------------------------------------------------------------------
    | Return Updated Product
    |--------------------------------------------------------------------------
    */

    $updatedProduct = DB::table(
        'egc_acc_expense_products as p'
    )
        ->leftJoin(
            'egc_acc_expense_categories as c',
            'c.sno',
            '=',
            'p.category_id'
        )
        ->select(
            'p.sno',
            'p.product_code',
            'p.product_name',
            'p.default_amount',
            'p.category_id',
            'c.category_name',
            'c.icon'
        )
        ->where('p.sno', $id)
        ->first();


    return response()->json([
        'success' => true,
        'message' => 'Expense product updated successfully.',
        'data' => $updatedProduct,
    ]);
}

/**
 * Deactivate Expense Product
 */
public function destroyProduct($id,Request $request)
{
    $product = DB::table(
        'egc_acc_expense_products'
    )
        ->where('sno', $id)
        ->where('status', 0)
        ->first();


    if (!$product) {

        return response()->json([
            'success' => false,
            'message' => 'Expense product not found.',
        ], 404);
    }


    $userId = $request->user()->user_id ?? 0;


    DB::table(
        'egc_acc_expense_products'
    )
        ->where('sno', $id)
        ->update([

            'status' => 2,

            'updated_by' =>
                $userId,

            'updated_at' =>
                now(),
        ]);


    return response()->json([
        'success' => true,
        'message' => 'Expense product deactivated successfully.',
    ]);
}

    public function productList(Request $request)
    {
        $products = DB::table(
            'egc_acc_expense_products as p'
        )
            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'p.category_id'
            )
            ->where(
                'p.status',
                0
            )
            ->select([
                'p.sno',
                'p.product_code',
                'p.product_name',
                'p.default_amount',
                'p.category_id',

                'c.category_name',
                'c.icon',
            ])
            ->orderBy(
                'p.sno',
                'desc'
            )
            ->get();


        return response()->json([

            'success' => true,

            'data' => $products,

        ]);
    }
}