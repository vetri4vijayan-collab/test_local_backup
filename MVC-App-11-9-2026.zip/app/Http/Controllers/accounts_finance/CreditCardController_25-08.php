<?php

namespace App\Http\Controllers\accounts_finance;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;

use App\Exports\ExpenseExport;

class CreditCardController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Expenditure Management
    |--------------------------------------------------------------------------
    */

    // public function index(Request $request): View
    // {

    //     $page = $request->input('page', 1);
    //     $perpage = (int) $request->input('sorting_filter', 25);
    //     $offset = ($page - 1) * $perpage;
    //     $search_filter = $request->search_filter ?? '';

    //     $Company = DB::table('egc_acc_tiderc_drac')->where('egc_acc_tiderc_drac.status', '!=', 2);

    //     if ($search_filter != '') {
    //     $Company->where(function ($subquery) use ($search_filter) {
    //         $subquery->where('egc_acc_tiderc_drac.b_name', 'LIKE', "%{$search_filter}%")
    //         ->orWhere('egc_acc_tiderc_drac.rd_prsn_name', 'LIKE', "%{$search_filter}%")
    //         ->orWhere('egc_acc_tiderc_drac.rd_prt1', 'LIKE', "%{$search_filter}%")
    //         ->orWhere('egc_acc_tiderc_drac.rd_prt2', 'LIKE', "%{$search_filter}%")
    //         ->orWhere('egc_acc_tiderc_drac.rd_prt3', 'LIKE', "%{$search_filter}%")
    //         ->orWhere('egc_acc_tiderc_drac.rd_prt4', 'LIKE', "%{$search_filter}%")
    //         ->orWhere('egc_acc_tiderc_drac.rd_prt5', 'LIKE', "%{$search_filter}%")
    //         ->orWhere('egc_acc_tiderc_drac.rd_name', 'LIKE', "%{$search_filter}%");
    //     });
    //     }

    //     $Company = $Company->orderBy('egc_acc_tiderc_drac.sno', 'asc')->paginate($perpage);

    //     $helper = new \App\Helpers\Helpers();

    //     if ($request->ajax()) {
    //     $data = $Company->map(function ($item) use ($helper) {
           
    //         return [
    //         'sno' => $item->sno,
    //         'status' => $item->status,
            
    //         'data' => $item,
    //         'company_encode' => base64_encode($item->sno),
    //         'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
    //         ];
    //     });

    //     return response()->json([
    //         'data' => $data,
    //         'current_page' => $Company->currentPage(),
    //         'last_page' => $Company->lastPage(),
    //         'total' => $Company->total(),
    //     ]);
    //     }




    //     return view('content.accounts_finance.credit_card.card_list',[
    //                  'perpage' => $perpage, 
    //     ]);
    // }

  
    public function index(Request $request)
    {

        if (!auth()->user()->hasPermission('Accounts & Finance', 'Manage Credit Card', null,  null)) {
           return redirect()->route('role_permission_error');
        }
        $page = max((int) $request->input('page', 1), 1);

        $perpage = (int) $request->input('sorting_filter', 25);

        // Prevent unreasonable pagination values
        $allowedPerPage = [10, 25, 50, 100];

        if (!in_array($perpage, $allowedPerPage, true)) {
            $perpage = 25;
        }

        $searchFilter = trim((string) $request->input('search_filter', ''));

        $query = DB::table('egc_acc_tiderc_drac')
            ->where('status', '!=', 2);


        /*
        |--------------------------------------------------------------------------
        | Search
        |--------------------------------------------------------------------------
        */

        if ($searchFilter !== '') {

            $query->where(function ($q) use ($searchFilter) {

                $q->where('b_name', 'LIKE', '%' . $searchFilter . '%')
                    ->orWhere('rd_prsn_name', 'LIKE', '%' . $searchFilter . '%')
                    ->orWhere('rd_name', 'LIKE', '%' . $searchFilter . '%')
                    ->orWhere('type', 'LIKE', '%' . $searchFilter . '%')
                    ->orWhere('rd_prt1', 'LIKE', '%' . $searchFilter . '%')
                    ->orWhere('rd_prt2', 'LIKE', '%' . $searchFilter . '%')
                    ->orWhere('rd_prt3', 'LIKE', '%' . $searchFilter . '%')
                    ->orWhere('rd_prt4', 'LIKE', '%' . $searchFilter . '%');

            });
        }


        /*
        |--------------------------------------------------------------------------
        | Pagination
        |--------------------------------------------------------------------------
        */

        $cards = $query
            ->select([
                'sno',
                'company_id',
                'entity_id',
                'b_name',
                'rd_prsn_name',
                'rd_name',
                'rd_prt1',
                'rd_prt2',
                'rd_prt3',
                'rd_prt4',
                'type',
                'due',
                'status',
                'created_at',
                'updated_at',
            ])
            ->orderBy('sno', 'desc')
            ->paginate(
                $perpage,
                ['*'],
                'page',
                $page
            );


        /*
        |--------------------------------------------------------------------------
        | AJAX Response
        |--------------------------------------------------------------------------
        */

        if ($request->ajax()) {

            $data = $cards->getCollection()->map(function ($item) {

                /*
                |--------------------------------------------------------------------------
                | Card masking
                |
                | Do NOT send complete card number to listing page.
                |--------------------------------------------------------------------------
                */

                $lastFour = (string) $item->rd_prt4;

                $maskedCard = '•••• •••• •••• ' .
                    str_pad(
                        substr($lastFour, -4),
                        4,
                        '•',
                        STR_PAD_LEFT
                    );


                /*
                |--------------------------------------------------------------------------
                | Due date formatting
                |--------------------------------------------------------------------------
                */

                $dueDate = null;

                if (!empty($item->due)) {

                    try {

                        $dueDate = \Carbon\Carbon::parse($item->due)
                            ->format('d M Y');

                    } catch (\Throwable $e) {

                        $dueDate = $item->due;
                    }
                }


                return [
                    'sno' => $item->sno,

                    'company_id' => $item->company_id,

                    'entity_id' => $item->entity_id,

                    'bank_name' => $item->b_name,

                    'card_holder' => $item->rd_prsn_name,

                    'reference_name' => $item->rd_name,

                    'card_type' => $item->type,

                    'masked_card' => $maskedCard,

                    'last_four' => substr(
                        (string) $item->rd_prt4,
                        -4
                    ),

                    'due_date' => $dueDate,

                    'status' => (int) $item->status,

                    'company_encode' => base64_encode(
                        (string) $item->sno
                    ),
                ];
            })->values();


            return response()->json([
                'success' => true,

                'data' => $data,

                'current_page' => $cards->currentPage(),

                'last_page' => $cards->lastPage(),

                'per_page' => $cards->perPage(),

                'total' => $cards->total(),

                'from' => $cards->firstItem(),

                'to' => $cards->lastItem(),
            ]);
        }


        /*
        |--------------------------------------------------------------------------
        | Initial Blade View
        |--------------------------------------------------------------------------
        */

        return view(
            'content.accounts_finance.credit_card.card_list',
            [
                'perpage' => $perpage,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Dashboard
    |--------------------------------------------------------------------------
    */

    public function dashboard(Request $request): JsonResponse
    {
        //
    }

    public function dashboardCards(Request $request): JsonResponse
{
    $query = DB::table('egc_acc_expense_logs')
        ->where('status',0);

    /*
    |--------------------------------------------------------------------------
    | Filters
    |--------------------------------------------------------------------------
    */

    if($request->filled('company')){

        $query->where('company_id',$request->company);

    }

    if($request->filled('entity')){

        $query->where('entity_id',$request->entity);

    }

    /*
    |--------------------------------------------------------------------------
    | Cards
    |--------------------------------------------------------------------------
    */

    $totalExpense=(clone $query)

        ->sum('amount');

    $monthlyExpense=(clone $query)

        ->whereYear('date',now()->year)

        ->whereMonth('date',now()->month)

        ->sum('amount');

    $todayExpense=(clone $query)

        ->whereDate('date',today())

        ->sum('amount');

    $dailyAverage=(clone $query)

        ->avg('amount');

    return response()->json([

        'status'=>true,

        'data'=>[

            'total_expense'=>

                round($totalExpense,2),

            'monthly_expense'=>

                round($monthlyExpense,2),

            'today_expense'=>

                round($todayExpense,2),

            'daily_average'=>

                round($dailyAverage,2)

        ]

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Charts
    |--------------------------------------------------------------------------
    */

    public function monthlyChart(Request $request): JsonResponse
{

    $year=$request->year ?? now()->year;

    $rows=DB::table('egc_acc_expense_logs')

        ->selectRaw(

            'MONTH(date) month,

            SUM(amount) total'

        )

        ->where('status',0)

        ->whereYear('date',$year)

        ->groupByRaw('MONTH(date)')

        ->orderByRaw('MONTH(date)')

        ->get();

    $months=[

        'Jan','Feb','Mar',

        'Apr','May','Jun',

        'Jul','Aug','Sep',

        'Oct','Nov','Dec'

    ];

    $values=array_fill(0,12,0);

    foreach($rows as $row){

        $values[$row->month-1]=(double)

            $row->total;

    }

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$months,

            'values'=>$values

        ]

    ]);

}

    public function categoryChart(Request $request): JsonResponse
{

    $rows=DB::table('egc_acc_expense_logs as el')

        ->join(

            'egc_acc_expense_categories as ec',

            'ec.sno',

            '=',

            'el.category_id'

        )

        ->selectRaw(

            'ec.category_name,

            SUM(el.amount) total'

        )

        ->where('el.status',0)

        ->groupBy(

            'ec.sno',

            'ec.category_name'

        )

        ->orderByDesc('total')

        ->get();

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$rows->pluck('category_name'),

            'values'=>$rows->pluck('total'),

            'total'=>$rows->sum('total')

        ]

    ]);

}

    public function productChart(Request $request): JsonResponse
{

    $limit=$request->limit ?? 10;

    $rows=DB::table('egc_acc_expense_logs as el')

        ->join(

            'egc_acc_expense_products as ep',

            'ep.sno',

            '=',

            'el.product_id'

        )

        ->selectRaw(

            'ep.product_name,

            SUM(el.amount) total'

        )

        ->where('el.status',0)

        ->groupBy(

            'ep.sno',

            'ep.product_name'

        )

        ->orderByDesc('total')

        ->limit($limit)

        ->get();

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$rows->pluck('product_name'),

            'values'=>$rows->pluck('total')

        ]

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Timeline
    |--------------------------------------------------------------------------
    */

    public function timeline(Request $request): JsonResponse
{
    $limit = $request->input('limit', 10);

    $query = DB::table('egc_acc_expense_logs as el')

        ->leftJoin('egc_acc_expense_categories as ec', 'ec.sno', '=', 'el.category_id')

        ->leftJoin('egc_acc_expense_products as ep', 'ep.sno', '=', 'el.product_id')

        ->leftJoin('egc_acc_tiderc_drac as cc', 'cc.sno', '=', 'el.tiderc_id')

        ->leftJoin('egc_company as c', 'c.sno', '=', 'el.company_id')

        ->leftJoin('egc_staff as st', 'st.sno', '=', 'el.created_by')

        ->where('el.status',0);

        $query->select([

    'el.sno',

    'el.date',

    'el.amount',

    'ep.product_name',

    'ec.category_name',

    'ec.icon',

    'c.company_name',

    'cc.b_name',

    'st.staff_name',

    'el.created_at'

]);
$rows = $query

    ->orderByDesc('el.created_at')

    ->limit($limit)

    ->get();
    $data = $rows->map(function($row){

    return [

        'id' => $row->sno,

        'product' => $row->product_name,

        'category' => $row->category_name,

        'amount' => (double)$row->amount,

        'company' => $row->company_name,

        'credit_card' => $row->b_name,

        'time' => Carbon::parse($row->created_at)

            ->diffForHumans(),

        'icon' => $this->timelineIcon($row->icon),

        'color' => $this->timelineColor($row->category_name)

    ];

});
return response()->json([

    'status'=>true,

    'data'=>$data

]);
}
private function timelineIcon(?string $icon): string
{
    if(!empty($icon)){

        return $icon;

    }

    return 'ti ti-wallet';

}
private function timelineColor(?string $category): string
{
    return match(strtolower($category ?? '')){

        'software' => '#B12A1F',

        'marketing' => '#F59E0B',

        'travel' => '#10B981',

        'office' => '#3B82F6',

        default => '#6B7280'

    };
}

    /*
    |--------------------------------------------------------------------------
    | DataTable
    |--------------------------------------------------------------------------
    */

    public function datatable(Request $request)
{
    $query = DB::table('egc_acc_expense_logs as el')

        ->leftJoin('egc_company as c', 'c.sno', '=', 'el.company_id')

        ->leftJoin('egc_entity as e', 'e.sno', '=', 'el.entity_id')

        ->leftJoin('egc_acc_expense_categories as ec', 'ec.sno', '=', 'el.category_id')

        ->leftJoin('egc_acc_expense_products as ep', 'ep.sno', '=', 'el.product_id')

        ->leftJoin('egc_acc_tiderc_drac as cc', 'cc.sno', '=', 'el.tiderc_id')

        ->leftJoin('egc_staff as st', 'st.sno', '=', 'el.created_by')

        ->where('el.status', 0);
        if ($request->filled('search')) {

    $search = trim($request->search);

    $query->where(function ($q) use ($search) {

        $q->where('ep.product_name', 'like', "%{$search}%")

            ->orWhere('ec.category_name', 'like', "%{$search}%")

            ->orWhere('c.company_name', 'like', "%{$search}%")

            ->orWhere('e.entity_name', 'like', "%{$search}%")

            ->orWhere('cc.b_name', 'like', "%{$search}%")

            ->orWhere('el.reference_no', 'like', "%{$search}%");

    });

}if ($request->filled('company')) {

    $query->where('el.company_id', $request->company);

}if ($request->filled('company')) {

    $query->where('el.company_id', $request->company);

}if ($request->filled('entity')) {

    $query->where('el.entity_id', $request->entity);

}if ($request->filled('category')) {

    $query->where('el.category_id', $request->category);

}if ($request->filled('product')) {

    $query->where('el.product_id', $request->product);

}if ($request->filled('credit_card')) {

    $query->where('el.tiderc_id', $request->credit_card);

}if ($request->filled('date')) {

    $query->whereDate('el.date', $request->date);

}
$query->select([

    'el.sno as id',

    'el.date as expense_date',

    'el.reference_no',

    'el.amount',

    'c.company_name',

    'c.company_short_name',

    'e.entity_name',

    'ec.category_name',

    'ec.icon',

    'ep.product_name',

    'ep.product_code',

    'cc.b_name as credit_card',

    'cc.rd_prt1',

    'cc.rd_prt2',

    'cc.rd_prt3',

    'cc.rd_prt4',

    'cc.rd_prt5',

    'st.staff_name'

]);
$total = (clone $query)->count();
$start = $request->input('start', 0);

$length = $request->input('length', 25);

$query->skip($start)

      ->take($length);
      $query->orderBy('el.date', 'desc')

      ->orderBy('el.sno', 'desc');
      $expenses = $query->get();
      $data = $expenses->map(function ($row) {

    return [

        'id' => $row->id,

        'expense_date' => $row->expense_date,

        'company' => $row->company_name,

        'company_short' => strtoupper(substr($row->company_short_name ?? $row->company_name, 0, 2)),

        'company_code' => '',

        'entity' => $row->entity_name,

        'category' => $row->category_name,

        'category_color' => '#B12A1F',

        'product' => $row->product_name,

        'product_code' => $row->product_code,

        'credit_card' => $row->credit_card,

        'card_last_four' => sprintf(
            '%04d',
            (int) ($row->rd_prt5 ?? 0)
        ),

        'reference' => $row->reference_no,

        'amount' => (double) $row->amount,

        'created_by' => $row->staff_name,

        'created_initial' => strtoupper(substr($row->staff_name, 0, 1))

    ];

});
return response()->json([

    'draw' => intval($request->draw),

    'recordsTotal' => $total,

    'recordsFiltered' => $total,

    'data' => $data

]);
}

    /*
    |--------------------------------------------------------------------------
    | CRUD
    |--------------------------------------------------------------------------
    */

    public function store(Request $request): JsonResponse
{
    $validator = Validator::make($request->all(), [

        'company_id'  => 'required|integer',
        'entity_id'   => 'required|integer',
        'category_id' => 'required|integer',
        'product_id'  => 'required|integer',
        'tiderc_id'   => 'required|integer',

        'date'        => 'required|date',

        'amount'      => 'required|numeric|min:0.01',

        'reference_no'=> 'nullable|max:120',

        'remarks'     => 'nullable|max:5000'

    ]);

    if($validator->fails()){

        return response()->json([

            'status'=>false,

            'message'=>'Validation Failed',

            'errors'=>$validator->errors()

        ],422);

    }

    DB::beginTransaction();

    try{

        $id = DB::table('egc_acc_expense_logs')

            ->insertGetId([

                'company_id'   => $request->company_id,

                'entity_id'    => $request->entity_id,

                'branch_id'    => $request->branch_id,

                'category_id'  => $request->category_id,

                'product_id'   => $request->product_id,

                'tiderc_id'    => $request->tiderc_id,

                'reference_no' =>

                    $request->reference_no,

                'amount'       =>

                    $request->amount,

                'remarks'      =>

                    $request->remarks,

                'date'         =>

                    $request->date,

                'created_by'   =>

                    session('staff_id'),

                'updated_by'   =>

                    session('staff_id'),

                'created_at'   => now(),

                'updated_at'   => now(),

                'status'       => 0

            ]);

        DB::commit();

        return response()->json([

            'status'=>true,

            'id'=>$id,

            'message'=>'Expense Added Successfully.'

        ]);

    }

    catch(\Throwable $e){

        DB::rollBack();

        return response()->json([

            'status'=>false,

            'message'=>$e->getMessage()

        ],500);

    }

}

    public function show(int $expense): JsonResponse
{
    return $this->edit($expense);
}

   public function edit(int $expense): JsonResponse
{
    $expense = DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->first();

    if(!$expense){

        return response()->json([

            'status'=>false,

            'message'=>'Expense Not Found.'

        ],404);

    }

    return response()->json([

        'status'=>true,

        'data'=>$expense

    ]);

}

    public function update(
    Request $request,
    int $expense
): JsonResponse
{

    $validator = Validator::make($request->all(),[

        'company_id'=>'required',

        'entity_id'=>'required',

        'category_id'=>'required',

        'product_id'=>'required',

        'tiderc_id'=>'required',

        'amount'=>'required|numeric',

        'date'=>'required'

    ]);

    if($validator->fails()){

        return response()->json([

            'status'=>false,

            'errors'=>$validator->errors()

        ],422);

    }

    DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->update([

            'company_id'=>$request->company_id,

            'entity_id'=>$request->entity_id,

            'branch_id'=>$request->branch_id,

            'category_id'=>$request->category_id,

            'product_id'=>$request->product_id,

            'tiderc_id'=>$request->tiderc_id,

            'reference_no'=>$request->reference_no,

            'amount'=>$request->amount,

            'remarks'=>$request->remarks,

            'date'=>$request->date,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Expense Updated Successfully.'

    ]);

}


    public function destroy(int $expense): JsonResponse
{

    DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->update([

            'status'=>2,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Expense Deleted Successfully.'

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Duplicate
    |--------------------------------------------------------------------------
    */

    public function duplicate(int $expense): JsonResponse
{
    $expenseData = DB::table('egc_acc_expense_logs')
        ->where('sno', $expense)
        ->where('status', 0)
        ->first();

    if (!$expenseData) {

        return response()->json([
            'status' => false,
            'message' => 'Expense not found.'
        ], 404);

    }

    $newExpense = (array) $expenseData;

    unset($newExpense['sno']);

    $newExpense['reference_no'] = null;

    $newExpense['created_by'] = session('staff_id');

    $newExpense['updated_by'] = session('staff_id');

    $newExpense['created_at'] = now();

    $newExpense['updated_at'] = now();

    $id = DB::table('egc_acc_expense_logs')->insertGetId($newExpense);

    return response()->json([

        'status' => true,

        'id' => $id,

        'message' => 'Expense duplicated successfully.'

    ]);
}

    /*
    |--------------------------------------------------------------------------
    | History
    |--------------------------------------------------------------------------
    */

   public function history(int $expense): JsonResponse
{
    $expense = DB::table('egc_acc_expense_logs')

        ->leftJoin('egc_staff','egc_staff.sno','=','egc_acc_expense_logs.created_by')

        ->where('egc_acc_expense_logs.sno',$expense)

        ->select(

            'egc_acc_expense_logs.created_at',

            'egc_acc_expense_logs.updated_at',

            'egc_staff.staff_name'

        )

        ->first();

    return response()->json([

        'status'=>true,

        'data'=>$expense

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Bulk
    |--------------------------------------------------------------------------
    */

    public function bulkDelete(Request $request): JsonResponse
{

    $ids = $request->ids;

    if(empty($ids)){

        return response()->json([

            'status'=>false,

            'message'=>'No expense selected.'

        ]);

    }

    DB::table('egc_acc_expense_logs')

        ->whereIn('sno',$ids)

        ->update([

            'status'=>2,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Selected expenses deleted successfully.'

    ]);

}

    public function bulkExport(Request $request)
{

    $ids = explode(',',$request->ids);

    return Excel::download(

        new ExpenseExport($ids),

        'Expense.xlsx'

    );

}

    /*
    |--------------------------------------------------------------------------
    | Dropdown APIs
    |--------------------------------------------------------------------------
    */

    public function companies(): JsonResponse
{

    return response()->json([
        'status'=>true,
        'data'=>DB::table('egc_company')
            ->where('status',0)
            ->orderBy('company_name')
            ->select(
                'sno',
                'company_name'
            )
            ->get()
    ]);

}

    public function entities(Request $request): JsonResponse
{

    $query=DB::table('egc_entity')

        ->where('status',0);

    if($request->company_id){

        $query->where(

            'company_id',

            $request->company_id

        );

    }

    return response()->json([

        'status'=>true,

        'data'=>$query

            ->orderBy('entity_name')

            ->select(

                'sno',

                'entity_name'

            )

            ->get()

    ]);

}

    public function categories(): JsonResponse
{

    return response()->json([

        'status'=>true,

        'data'=>DB::table(

            'egc_acc_expense_categories'

        )

        ->where('status',0)

        ->orderBy('category_name')

        ->get()

    ]);

}

    public function products(Request $request): JsonResponse
{

    $query=DB::table(

        'egc_acc_expense_products'

    )

    ->where('status',0);

    if($request->category_id){

        $query->where(

            'category_id',

            $request->category_id

        );

    }

    return response()->json([

        'status'=>true,

        'data'=>$query

            ->orderBy('product_name')

            ->get()

    ]);

}

    public function creditCards(Request $request): JsonResponse
{

    $query=DB::table(

        'egc_acc_tiderc_drac'

    )

    ->where('status',0);

    if($request->company_id){

        $query->where(

            'company_id',

            $request->company_id

        );

    }

    if($request->entity_id){

        $query->where(

            'entity_id',

            $request->entity_id

        );

    }

    return response()->json([

        'status'=>true,

        'data'=>$query

            ->orderBy('b_name')

            ->get()

    ]);

}


public function creditCardIndex(Request $request)
{
    $query = DB::table('egc_acc_tiderc_drac')
        ->where('status', 0);

    if ($request->filled('company_id')) {
        $query->where('company_id', $request->company_id);
    }

    if ($request->filled('entity_id')) {
        $query->where('entity_id', $request->entity_id);
    }

    $cards = $query
        ->orderByDesc('sno')
        ->get();

    return response()->json([
        'success' => true,
        'data' => $cards,
    ]);
}

public function creditCardStore(Request $request)
{
    $validator = Validator::make($request->all(), [

        // 'company_id' => [
        //     'required',
        //     'integer',
        // ],

        // 'entity_id' => [
        //     'required',
        //     'integer',
        // ],

        'b_name' => [
            'required',
            'string',
            'max:150',
        ],

        'credit_limit' => [
            'required',
            'numeric',
            'gt:0',
            'decimal:0,2',
        ],
        'rd_prsn_name' => [
            'required',
            'string',
            'max:150',
        ],

        'rd_name' => [
            'nullable',
            'string',
            'max:150',
        ],

        'rd_prt1' => [
            'required',
            'digits:4',
        ],

        'rd_prt2' => [
            'required',
            'digits:4',
        ],

        'rd_prt3' => [
            'required',
            'digits:4',
        ],

        'rd_prt4' => [
            'required',
            'digits:4',
        ],

        // 'rd_prt5' => [
        //     'required',
        //     'digits:4',
        // ],

        'type' => [
            'required',
            'string',
            'max:250',
        ],

        'due' => [
            'required',
            'string',
            'regex:/^(0[1-9]|1[0-2])\/\d{2}$/',
        ],

        'vv_no' => [
            'nullable',
            'string',
            'max:50',
        ],

    ]);

    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $validator->errors(),
        ], 422);
    }


    $userId = $request->user()->user_id ?? 0;
    
    $alreadyExist =DB::table('egc_acc_tiderc_drac')
    ->where('rd_prt1',$request->rd_prt1)
    ->where('rd_prt2',$request->rd_prt2)
    ->where('rd_prt3',$request->rd_prt3)
    ->where('rd_prt4',$request->rd_prt4)
    ->where('status','!=', 2)->first();

    if($alreadyExist){
        return response()->json([
            'success' => false,
            'message' => 'Credit Card Already Exist',
            'errors' => 'Credit Card Already Exist',
        ], 422);
    }


    $expiryDate = null;

    if ($request->filled('due')) {

        try {
            $expiryDate = \Carbon\Carbon::createFromFormat('m/y', $request->input('due'))->startOfMonth()->format('Y-m-d');
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid card expiry date.',
            ], 422);
        }
    }



    $id = DB::table('egc_acc_tiderc_drac')
        ->insertGetId([

            'company_id' => $request->integer('company_id'),

            'entity_id' => $request->integer('entity_id'),

            'b_name' => trim($request->b_name),

            'rd_prsn_name' => trim($request->rd_prsn_name),

            'rd_name' => $request->filled('rd_name')
                ? trim($request->rd_name)
                : null,

            'rd_prt1' => $request->rd_prt1,

            'rd_prt2' => $request->rd_prt2,

            'rd_prt3' => $request->rd_prt3,

            'rd_prt4' => $request->rd_prt4,

            'rd_prt5' => $request->rd_prt5,

            'type' => trim($request->type),

            'due' =>$expiryDate ,
            'value' => $request->input('credit_limit'),

            'vv_no' => $request->filled('vv_no')
                ? trim($request->vv_no)
                : null,

            'created_by' => $userId,

            'updated_by' => $userId,

            'status' => 0,

            'created_at' => now(),

            'updated_at' => now(),

        ]);


    return response()->json([

        'success' => true,

        'message' => 'Credit card created successfully.',

        'data' => [
            'id' => $id,
        ],

    ], 201);
}

public function creditCardShow($id)
{
    $card = DB::table('egc_acc_tiderc_drac')
        ->where('sno', $id)
        ->where('status', 0)
        ->first();

    if (!$card) {

        return response()->json([
            'success' => false,
            'message' => 'Credit card not found.',
        ], 404);
    }


    /*
     * Do NOT return the five card reference parts
     * to the browser during edit.
     */

    $card->rd_prt1 = null;
    $card->rd_prt2 = null;
    $card->rd_prt3 = null;
    $card->rd_prt4 = null;
    $card->rd_prt5 = null;


    return response()->json([

        'success' => true,

        'data' => $card,

    ]);
}

public function creditCardUpdate(Request $request, $id)
{
    $card = DB::table('egc_acc_tiderc_drac')
        ->where('sno', $id)
        ->where('status', 0)
        ->first();

    if (!$card) {

        return response()->json([
            'success' => false,
            'message' => 'Credit card not found.',
        ], 404);
    }


    $validator = Validator::make($request->all(), [

        'company_id' => [
            'required',
            'integer',
        ],

        'entity_id' => [
            'required',
            'integer',
        ],

        'b_name' => [
            'required',
            'string',
            'max:150',
        ],

        'rd_prsn_name' => [
            'required',
            'string',
            'max:150',
        ],

        'rd_name' => [
            'nullable',
            'string',
            'max:150',
        ],

        'type' => [
            'required',
            'string',
            'max:250',
        ],

        'due' => [
            'nullable',
            'date',
        ],

        'vv_no' => [
            'nullable',
            'string',
            'max:50',
        ],

        /*
         * Card parts are optional on update.
         * Empty = retain existing card reference.
         */

        'rd_prt1' => [
            'nullable',
            'digits:4',
        ],

        'rd_prt2' => [
            'nullable',
            'digits:4',
        ],

        'rd_prt3' => [
            'nullable',
            'digits:4',
        ],

        'rd_prt4' => [
            'nullable',
            'digits:4',
        ],

        'rd_prt5' => [
            'nullable',
            'digits:4',
        ],

    ]);


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $validator->errors(),
        ], 422);
    }


    $userId = auth()->id() ?? 0;


    $update = [

        'company_id' => $request->integer('company_id'),

        'entity_id' => $request->integer('entity_id'),

        'b_name' => trim($request->b_name),

        'rd_prsn_name' => trim($request->rd_prsn_name),

        'rd_name' => $request->filled('rd_name')
            ? trim($request->rd_name)
            : null,

        'type' => trim($request->type),

        'due' => $request->filled('due')
            ? $request->due
            : null,

        'vv_no' => $request->filled('vv_no')
            ? trim($request->vv_no)
            : null,

        'updated_by' => $userId,

        'updated_at' => now(),

    ];


    /*
     * Only replace card reference when ALL five
     * parts are supplied.
     */

    $parts = [

        $request->rd_prt1,

        $request->rd_prt2,

        $request->rd_prt3,

        $request->rd_prt4,

        $request->rd_prt5,

    ];


    $hasAnyPart = collect($parts)
        ->contains(fn ($value) => filled($value));


    if ($hasAnyPart) {

        if (
            !preg_match('/^\d{4}$/', (string) $request->rd_prt1) ||
            !preg_match('/^\d{4}$/', (string) $request->rd_prt2) ||
            !preg_match('/^\d{4}$/', (string) $request->rd_prt3) ||
            !preg_match('/^\d{4}$/', (string) $request->rd_prt4) ||
            !preg_match('/^\d{4}$/', (string) $request->rd_prt5)
        ) {

            return response()->json([

                'success' => false,

                'message' =>
                    'All five card reference parts are required when changing the card reference.',

                'errors' => [

                    'rd_prt1' => [
                        'All five card reference parts must contain 4 digits.'
                    ],

                ],

            ], 422);
        }


        $update['rd_prt1'] = $request->rd_prt1;
        $update['rd_prt2'] = $request->rd_prt2;
        $update['rd_prt3'] = $request->rd_prt3;
        $update['rd_prt4'] = $request->rd_prt4;
        $update['rd_prt5'] = $request->rd_prt5;
    }


    DB::table('egc_acc_tiderc_drac')
        ->where('sno', $id)
        ->update($update);


    return response()->json([

        'success' => true,

        'message' => 'Credit card updated successfully.',

    ]);
}

public function Status($id, Request $request)
{

    $staff =  DB::table('egc_acc_tiderc_drac')
    ->where('sno', $id)
    ->update([
        'status' => $request->input('status', 0),
        'updated_by' => $request->user()->user_id ?? 0,
        'updated_at' => now(),
    ]);


    if ($staff) {
        return response([
        'status'    => 200,
        'message'   => 'credit Card Status Successfully Updated!',
        'error_msg' => 'Could not, update  credit Card Status!',
        'data'      => null,
        ], 200);
    } else {
        return response([
        'status'    => 200,
        'message'   => 'Could not update credit Card Status!',
        'error_msg' => 'Could not, update  credit Card Status!',
        'data'      => null,
        ], 200);
    }
}
  public function Delete($id, Request $request)
  {
    $exit_log  = DB::table('egc_acc_expense_logs')->where('tiderc_id', $id)->where('status','!=',2)->first();
    if ($exit_log) {
      return response([
        'status'    => 302,
        'message'   => 'Deletion not allowed: This Card Already has Expense Log',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

     $staff =  DB::table('egc_acc_tiderc_drac')
        ->where('sno', $id)
        ->update([
            'status' => 2,
            'updated_by' => $request->user()->user_id ?? 0,
            'updated_at' => now(),
        ]);
   
    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Credit Card Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Company ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }


public function creditCardDestroy($id)
{
    $card = DB::table('egc_acc_tiderc_drac')
        ->where('sno', $id)
        ->where('status', 0)
        ->first();

    if (!$card) {

        return response()->json([
            'success' => false,
            'message' => 'Credit card not found.',
        ], 404);
    }


    DB::table('egc_acc_tiderc_drac')
        ->where('sno', $id)
        ->update([

            'status' => 2,

            'updated_by' => auth()->id() ?? 0,

            'updated_at' => now(),

        ]);


    return response()->json([

        'success' => true,

        'message' => 'Credit card deleted successfully.',

    ]);
}

public function creditCardCompanies()
{
    $companies = DB::table('egc_company')
        ->select([
            'sno',
            'company_id',
            'company_name',
        ])
        ->where('status', 0)
        ->orderBy('company_name')
        ->get();

    return response()->json([
        'success' => true,
        'data' => $companies,
    ]);
}public function creditCardEntities(Request $request)
{
    $request->validate([
        'company_id' => [
            'required',
            'integer',
        ],
    ]);


    $entities = DB::table('egc_entity')
        ->select([
            'sno',
            'entity_id',
            'entity_name',
            'company_id',
        ])
        ->where('company_id', $request->integer('company_id'))
        ->where('status', 0)
        ->orderBy('entity_name')
        ->get();


    return response()->json([
        'success' => true,
        'data' => $entities,
    ]);
}
}