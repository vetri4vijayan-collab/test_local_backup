<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ShiftTimeModel;
use Illuminate\Support\Facades\DB;

use App\Models\ShiftDayTimeModel;
use Illuminate\Support\Facades\Validator;

class ShiftTime extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = ShiftTimeModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('shift_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->with('days')->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                 $days = [];
                $times = [];

                foreach($item->days as $d){

                    $days[] = ucfirst($d->day_name);

                    $times[] =
                        date('H:i',strtotime($d->time_from))
                        .' - '.
                        date('H:i',strtotime($d->time_to));

                }
                return [
                    'sno' => $item->sno,
                    'shift_name' => $item->shift_name,
                'status' => $item->status,

                'days' => implode(', ',$days),

                'time' => count($times) ? $times[0] : '-',
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.hrm.shift_time.shift_time',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = ShiftTimeModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add(Request $request)
{

    $validator = Validator::make($request->all(),[
        'shift_name' => 'required|max:255'
    ]);

    if($validator->fails()){

        return redirect()->back()
            ->withErrors($validator)
            ->withInput();

    }

    DB::beginTransaction();

    // try{

        $shiftName = $request->shift_name;

        $exists = ShiftTimeModel::where('shift_name',$shiftName)
                    ->where('status','!=',2)
                    ->first();

        if($exists){

            session()->flash('toastr',[
                'type'=>'error',
                'message'=>'Shift already exists'
            ]);

            return redirect()->back();

        }

        /* -----------------------------
           Create Shift
        ------------------------------ */

        $shift = ShiftTimeModel::create([
            'shift_name' => $shiftName,
            'created_at' => now()
        ]);

        /* -----------------------------
           Save Day Times
        ------------------------------ */

        if($request->days){

            foreach($request->days as $day => $value){

                if(isset($value['checked'])){

                    if(empty($value['from']) || empty($value['to'])){
                        continue;
                    }

                    $from = $value['from'];
                    $to   = $value['to'];

                    $duration = (strtotime($to) - strtotime($from)) / 60;

                    if($duration < 0){
                        $duration = 0;
                    }

                    ShiftDayTimeModel::create([
                        'shift_id'          => $shift->sno,
                        'day_name'          => $day,
                        'time_from'         => $from,
                        'time_to'           => $to,
                        'duration_minutes'  => $duration,
                        'created_at'        => now()
                    ]);

                }

            }

        }

        DB::commit();

        session()->flash('toastr',[
            'type'=>'success',
            'message'=>'Shift created successfully'
        ]);

        return redirect()->back();

    // }
    // catch(\Throwable $e){

    //     DB::rollBack();

    //     session()->flash('toastr',[
    //         'type'=>'error',
    //         'message'=>'Failed to create shift'
    //     ]);

    //     return redirect()->back();

    // }

}


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'document_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $document_name       = $request->document_name;
            $document_desc       = $request->document_desc;
            $document_id       = $request->edit_id;

            $upd_ShiftTimeModel =  ShiftTimeModel::where( 'sno', $document_id )->first();

            $chk = ShiftTimeModel::where( 'document_name', $document_name )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Document is exist!'
                ] );
                return redirect()->back();
            }

            $upd_ShiftTimeModel->document_name  = $document_name;
            $upd_ShiftTimeModel->document_desc  = $document_desc;
            $upd_ShiftTimeModel->update();

             $duration = (strtotime($request->time_to) - strtotime($request->time_from)) / 60;
            $shift = ShiftTimeSetting::findOrFail($id);
            $shift->update([
                'shift_name'=>$request->shift_name,
                'time_from'=>$request->time_from,
                'time_to'=>$request->time_to,
                'duration_minutes'=>$duration,

                'monday'=>$request->monday ? 1 : 0,
                'tuesday'=>$request->tuesday ? 1 : 0,
                'wednesday'=>$request->wednesday ? 1 : 0,
                'thursday'=>$request->thursday ? 1 : 0,
                'friday'=>$request->friday ? 1 : 0,
                'saturday'=>$request->saturday ? 1 : 0,
                'sunday'=>$request->sunday ? 1 : 0,
            ]);

            if ( $upd_ShiftTimeModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Document Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Document!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_ShiftTimeModel = ShiftTimeModel::where( 'sno', $id )->first();
        $upd_ShiftTimeModel->status  = 2;
        $upd_ShiftTimeModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Document Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_ShiftTimeModel =  ShiftTimeModel::where( 'sno', $id )->first();
        $upd_ShiftTimeModel->status = $request->input( 'status', 0 );
        $upd_ShiftTimeModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
//     public function getShiftDetail($id)
// {

// $shift = ShiftTimeModel::with('days')
//             ->where('sno',$id)
//             ->first();

// if(!$shift){
// return response()->json(['status'=>false]);
// }

// return response()->json([
// 'status'=>true,
// 'shift'=>$shift
// ]);

// }

public function getShiftDetail($id)
{

    $shift = ShiftTimeModel::with('days')
        ->where('sno',$id)
        ->first();

    if(!$shift){
        return response()->json(['status'=>false]);
    }

    $totalMinutes = 0;

    foreach($shift->days as $day){
        $totalMinutes += $day->duration_minutes;
    }

    return response()->json([
        'status'=>true,
        'shift'=>$shift,
        'total_duration'=>$totalMinutes
    ]);

}

// public function assignShift(Request $request)
// {

// $request->validate([
// 'staff_id'=>'required',
// 'shift_id'=>'required'
// ]);

// DB::table('egc_staff')
// ->where('sno',$request->staff_id)
// ->update([
// 'shift_time_id'=>$request->shift_id,
// 'updated_at'=>now()
// ]);

// return response()->json([
// 'status'=>true,
// 'message'=>'Shift assigned successfully'
// ]);

// }

   public function assignShift(Request $request)
{

    $request->validate([
        'staff_id'   => 'required|integer',
        'shift_id'   => 'required|integer',
        'start_date' => 'required|date',
        'end_date'   => 'nullable|date'
    ]);

    DB::beginTransaction();

    try{

        $staffId   = $request->staff_id;
        $shiftId   = $request->shift_id;
        $startDate = $request->start_date ? date('Y-m-d',strtotime($request->start_date)) : NULL;
        $endDate   = $request->end_date ? date('Y-m-d',strtotime($request->end_date)) : NULL;;

        $staff = DB::table('egc_staff')->where('sno',$staffId)->first();

        if(!$staff){
            return response()->json([
                'status'=>false,
                'message'=>'Staff not found'
            ]);
        }

        $oldShift = $staff->shift_time_id;

        /*
        ============================
        FIND ACTIVE SHIFT LOG
        ============================
        */

        $lastLog = DB::table('egc_shift_time_log')
                    ->where('staff_id',$staffId)
                    ->whereNull('end_date')
                    ->orderByDesc('sno')
                    ->first();


        /*
        ============================
        UPDATE PREVIOUS SHIFT
        ============================
        */

        if($lastLog && $endDate){

            DB::table('egc_shift_time_log')
            ->where('sno',$lastLog->sno)
            ->update([
                'end_date'   => $endDate,
                'updated_at' => now(),
                'updated_by' => auth()->id() ?? 0
            ]);

        }


        /*
        ============================
        INSERT NEW SHIFT LOG
        ============================
        */

        DB::table('egc_shift_time_log')->insert([
            'staff_id'         => $staffId,
            'start_date'       => $startDate,
            'end_date'         => null,
            'current_shift_id' => $oldShift ?? 0,
            'change_shift_id'  => $shiftId,
            'created_at'       => now(),
            'created_by'       => auth()->id() ?? 0,
            'updated_at'       => now(),
            'updated_by'       => auth()->id() ?? 0,
            'status'           => 0
        ]);


        /*
        ============================
        UPDATE STAFF SHIFT
        ============================
        */

        DB::table('egc_staff')
        ->where('sno',$staffId)
        ->update([
            'shift_time_id'=>$shiftId,
            'updated_at'=>now()
        ]);

        DB::commit();

        return response()->json([
            'status'=>true,
            'message'=>'Shift assigned successfully'
        ]);

    }catch(\Throwable $e){

        DB::rollBack();

        return response()->json([
            'status'=>false,
            'message'=>'Failed to assign shift'
        ]);
    }
}
}
