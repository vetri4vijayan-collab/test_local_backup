<?php

namespace App\Http\Controllers\settings\management;

use App\Http\Controllers\Controller;
use App\Models\JobRoleModel;
use App\Models\DepartmentModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class JobRole extends Controller
{

  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $startTime = microtime(true);
    $job_position = JobRoleModel::select(
        'egc_job_role.*',
        'egc_department.department_name',
        'egc_division.division_name',
    )
      ->join('egc_department', 'egc_department.sno', '=' , 'egc_job_role.department_id')
      ->join('egc_division', 'egc_division.sno', '=' , 'egc_job_role.division_id')
      ->where('egc_job_role.status', '!=', 2)
      ->where('egc_job_role.company_type', 1);
        if ($search_filter != '') {
          $job_position->where(function ($subquery) use ($search_filter) {
              $subquery->where('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%");
                  
          });
      }
      $job_position =$job_position->orderBy('egc_job_role.sno', 'desc')
      ->paginate($perpage);

   $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $job_position->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'job_role_name' => $item->job_position_name,
                    'department_name' => $item->department_name,
                    'department_id' => $item->department_id,
                    'division_name' => $item->division_name,
                    'division_id' => $item->division_id,
                    'per_hour_cost' => $item->per_hour_cost,
                    'job_position_desc' => $item->job_position_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $job_position->currentPage(),
                'last_page' => $job_position->lastPage(),
                'total' => $job_position->total(),
            ]);
        }
      $Department = DepartmentModel::where('egc_department.status',  0)->orderBy('sno', 'asc')
            ->where('egc_department.company_type',1)->get();
      

    // return $job_position;

    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return view('content.settings.management.job_role.job_role_list',[
      'job_position' => $job_position,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
      'Department' => $Department
    ]);
  }

  public function list()
  {

    // $dept_id = 5;
    $dept_id = $_GET['id'] ?? '';
    $startTime = microtime(true);
    $job_position = JobRoleModel::where('sub_department_id', $dept_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }
  public function JobPostionList()
  {
    // $dept_id = 5;
    $dept_id = $_GET['id'] ?? '';
    $startTime = microtime(true);
    $job_position = JobRoleModel::
    where('department_id', $dept_id)
    // where('division_id', $dept_id)
    ->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }


  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_role_name' => 'required|max:255',

    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $job_position_name = $request->job_role_name;
      $department_id = $request->department_id;
      $division_id = $request->division_id;
      $per_hour_cost = $request->per_hour_cost;
      $job_position_desc = $request->job_position_desc;

      // dd($request);

     
      $user_id = $request->user()->user_id;
      $chk = JobRoleModel::where('job_position_name', $job_position_name)->where('division_id',$division_id)->where('company_type', 1)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Job Position has been  already created!',
        ]);
      } else {
        $category_check = JobRoleModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_position_id = "JP-0001/" . $year;
        } else {

          $data = $category_check->job_position_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf("JP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_position_id = $request . '/' . $year;
        }

        $add_category = new JobRoleModel();
        $add_category->job_position_id = $job_position_id;
        $add_category->job_position_name = $job_position_name;
        $add_category->department_id = $department_id;
        $add_category->division_id = $division_id;
        $add_category->per_hour_cost = $per_hour_cost;
        $add_category->job_position_desc = $job_position_desc;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'job position added Successfully!',
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the job position!',
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'knowledge Created successfully!');
    }
  }

  public function Edit($id)
  {
    $job_position = JobRoleModel::where('sno', $id)->first();

    // return $job_position;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
    ], 200);
  }


  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_role_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
       $id = $request->edit_id;
      $job_position_name = $request->job_role_name;
      $per_hour_cost = $request->per_hour_cost;
      $job_position_desc = $request->job_position_desc;
      $department_id = $request->department_id;
      $division_id = $request->division_id;

      $upd_CourseCategoryModel = JobRoleModel::where('sno', $id)->first();

      $chk = JobRoleModel::where('job_position_name', $job_position_name)->where('division_id',$division_id)->where('company_type', 1)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->job_position_name = $job_position_name;
        $upd_CourseCategoryModel->per_hour_cost = $per_hour_cost;
        $upd_CourseCategoryModel->job_position_desc = $job_position_desc;
        $upd_CourseCategoryModel->department_id = $department_id;
        $upd_CourseCategoryModel->division_id = $division_id;
        $upd_CourseCategoryModel->update();
       if ($upd_CourseCategoryModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Division updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Division!'
          ]);
        }
      }
      return redirect()->back();
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel = JobRoleModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel = JobRoleModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
