<?php

namespace App\Http\Controllers\settings\assessment;

use App\Http\Controllers\Controller;
use App\Models\ExamScheduleModel;
use App\Models\UserRoleModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class JobRoleSchedule extends Controller
{
    

    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Department = ExamScheduleModel::where('egc_exam_schedule.status', '!=', 2)->orderBy('egc_exam_schedule.sno', 'desc');
        
            if ($search_filter != '') {
                $Department->where(function ($subquery) use ($search_filter) {
                    $subquery->where('egc_exam_schedule.schedule_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('egc_exam_schedule.duration', 'LIKE', "%{$search_filter}%")
                        ->orWhere('egc_exam_schedule.unit', 'LIKE', "%{$search_filter}%");
                        
                });
            }

            $Department=$Department->paginate($perpage);
            $helper = new \App\Helpers\Helpers();

            if ($request->ajax()) {
                $data = $Department->map(function ($item) use ($helper) {
                    return [
                        'sno' => $item->sno,
                        'status' => $item->status,
                        'duration' => $item->duration,
                        'unit' => $item->unit,
                        'schedule_name' => $item->schedule_name,
                        'item' => $item,
                        'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                    ];
                });

                return response()->json([
                    'data' => $data,
                    'current_page' => $Department->currentPage(),
                    'last_page' => $Department->lastPage(),
                    'total' => $Department->total(),
                ]);
            }
        
        return view('content.settings.assessment.exam_schedule.exam_schedule', compact('perpage','search_filter'));
    }

    public function Create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'schedule' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->schedule;

        $check = ExamScheduleModel::where('status', '!=', 2)->where('schedule_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Schedule Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = new ExamScheduleModel();
        $create->schedule_name = $name;
        $create->duration = $request->duration;
        $create->unit = $request->unit;
        // $create->job_role_id = $request->job_role;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Schedule Created Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Schedule Creation Failed!'
            ]);
        }
    }

    public function Status($id, Request $request)
    {
        $status = ExamScheduleModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = ExamScheduleModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Exam Section Deleted Succesfully',
            'error_msg' => 'Exam Section Deletion Failed !',
            'data' => null,
        ]);
    }

    public function Edit($id) {
        $data = ExamScheduleModel::where('sno', $id)->where('status', '!=', 2)->first();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => 'No Such Data !',
                'data' => $data,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'No Such Data',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'sch_name_edit' => 'required|string'
        ]);
        // return $request;
        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->sch_name_edit;
        $sno = $request->edit_id;

        $check = ExamScheduleModel::where('status', '!=', 2)->where('sno', '!=', $sno)->where('schedule_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Job Role Schedule Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = ExamScheduleModel::where('status', '!=', 2)->where('sno', $sno)->first();
        $create->schedule_name = $name;
        $create->duration = $request->duration_edit;
        // $create->job_role_id = $request->role_id_edit;
        $create->unit = $request->unit_edit;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->update();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Job Role Schedule Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Job Role Schedule Updation Failed!'
            ]);
        }
    }

    public function list() {
        $data = ExamScheduleModel::where('status', 0)->where('job_role_id', 0)->orderBy('sno','ASC')->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => 'No Such Data !',
                'data' => $data,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'No Such Data',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

}
