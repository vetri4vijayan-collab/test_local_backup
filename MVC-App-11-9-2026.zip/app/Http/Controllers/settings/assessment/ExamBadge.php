<?php

namespace App\Http\Controllers\settings\assessment;

use App\Http\Controllers\Controller;
use App\Models\ExamBadgeModel;
use App\Models\ExamCategoryModel;
use App\Models\JobRoleModel;
use App\Models\UserRoleModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ExamBadge extends Controller
{
   

    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $roles = UserRoleModel::where('status', 0)->get();
        $job_position = JobRoleModel::where('status', 0)->where('sno', '!=', 46)->orderBy('job_position_name', 'ASC')->get();
        $Department = ExamBadgeModel::where('egc_exam_badge.status', '!=', 2)->orderBy('egc_exam_badge.sno', 'desc')
        ->select(
            'egc_exam_badge.*',
            'egc_user_role.role_name',
            'egc_exam_category.category_name'
        )
            ->leftJoin('egc_user_role', 'egc_user_role.sno', '=', 'egc_exam_badge.job_id')
            ->leftJoin('egc_exam_category', 'egc_exam_category.sno', '=', 'egc_exam_badge.exam_cat_id');
        
            if ($search_filter != '') {
                $Department->where(function ($subquery) use ($search_filter) {
                    $subquery->where('egc_exam_badge.section_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('egc_user_role.role_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('egc_exam_category.category_name', 'LIKE', "%{$search_filter}%");
                        
                });
            }

            $Department=$Department->paginate($perpage);
            $helper = new \App\Helpers\Helpers();

            if ($request->ajax()) {
                $data = $Department->map(function ($item) use ($helper) {
                    return [
                        'sno' => $item->sno,
                        'status' => $item->status,
                        'category_name' => $item->category_name,
                        'role_name' => $item->role_name,
                        'badge_image' => $item->badge_image,
                        'badge_name' => $item->badge_name,
                        'job_id' => $item->job_id,
                        'exam_cat_id' => $item->exam_cat_id,
                        'prize_id' => $item->prize_id,
                        'gift' => $item->gift,
                        'points' => $item->points,
                        'promotion_id' => $item->promotion_id,
                        'badge_desc' => $item->badge_desc,
                        'item' => $item,
                        'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                    ];
                });

                return response()->json([
                    'data' => $data,
                    'current_page' => $Department->currentPage(),
                    'last_page' => $Department->lastPage(),
                    'total' => $Department->total(),
                ]);
            }
        
        return view('content.settings.assessment.exam_badge.exam_badge', compact('perpage','search_filter','job_position'));
    }

    public function Create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'exam_badge_name' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->exam_badge_name;
        $cat_id = $request->exam_cat_id;
        $prize_type = $request->prize_id;

        $check = ExamBadgeModel::where('status', '!=', 2)->where('badge_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Badge Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = new ExamBadgeModel();
        $create->badge_name = $name;
        $create->badge_desc = $request->badge_desc;
        $create->job_id = $request->role_id ?? 0;
        $create->prize_id = $prize_type;

        // Badge Image Upload
        if ($request->hasFile('logo')) {
            // Generate a unique filename
            $imageName = time() . '_' . uniqid() . '.' . $request->file('logo')->extension();

            // Define destination path
            $destinationPath = public_path('exam/badges');

            // Move file
            $request->file('logo')->move($destinationPath, $imageName);

            $logo = $imageName;
        } else {
            $logo = $create->badge_image ?? null;
        }

        if ($prize_type == 1) {
            $create->gift = $request->exam_gift;
        } else if ($prize_type == 2) {
            $create->points = $request->exam_points;
        } else if ($prize_type == 3) {
            $create->promotion_id = $request->promotion_id;
        }
        $create->badge_image = $logo;
        $create->exam_cat_id = $cat_id;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Badge Created Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Badge Creation Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {
        $status = ExamBadgeModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = ExamBadgeModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Exam Category Deleted Succesfully',
            'error_msg' => 'Exam Category Deletion Failed !',
            'data' => null,
        ]);
    }

    public function Edit($id)
    {
        $data = ExamBadgeModel::where('status', '!=', 2)
            ->where('sno', $id)
            ->first();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => 'No Such Records!',
                'data' => null
            ], 402);
        }
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'exam_badge_name_edit' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $sno = $request->edit_id;
        $user_id = $request->user()->user_id;
        $name = $request->exam_badge_name_edit;
        $cat_id = $request->exam_cat_id_edit;
        $prize_type = $request->edit_prize_id;

        $check = ExamBadgeModel::where('status', '!=', 2)->where('sno', '!=', $sno)->where('badge_name', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Badge Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = ExamBadgeModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $create->badge_name = $name;
        $create->badge_desc = $request->badge_desc_edit;
        $create->job_id = $request->role_id_edit ?? 0;
        $create->exam_cat_id = $cat_id;
        $create->prize_id = $prize_type;

        if ($prize_type == 1) {
            $create->gift = $request->exam_gift_edit;
        } else if ($prize_type == 2) {
            $create->points = $request->exam_points_edit;
        } else if ($prize_type == 3) {
            $create->promotion_id = $request->promotion_id_edit;
        }

        // Badge Image Upload
        if ($request->hasFile('logo_edit')) {
            // Generate a unique filename
            $imageName = time() . '_' . uniqid() . '.' . $request->file('logo_edit')->extension();

            // Define destination path
            $destinationPath = public_path('exam/badges');

            // Move file
            $request->file('logo_edit')->move($destinationPath, $imageName);

            $logo = $imageName;
        } else {
            $logo = $create->badge_image ?? null;
        }

        $create->badge_image = $logo;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->update();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Badge Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Badge Updation Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function list()
    {
        $data = ExamBadgeModel::where('status', 0)->orderBy('sno', 'desc')->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => 'No Such Records!',
                'data' => null
            ], 402);
        }
    }
}
