<?php

namespace App\Http\Controllers\settings\recruitment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\QualificationModel;
use Illuminate\Support\Facades\Validator;

class Qualification extends Controller
{
    

     public function index(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = QualificationModel::where('egc_education.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_education.*');
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_education.education', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_education.education_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Department=$Department->orderBy('egc_education.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'education' => $item->education,
                    'education_desc' => $item->education_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
 
    return view('content.settings.recruitment.qualification.qualification_list', [
      'ListTable' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
    ]);
  }

 

  public function List(Request $request)
  {
    
    $Department = QualificationModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }


  public function Status($id, Request $request)
  {

    $staff =  QualificationModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Qualification Updated Successfully!',
        'error_msg' => 'Could not, update Qualification!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Qualification!',
        'error_msg' => 'Could not, update Qualification!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_QualificationModel = QualificationModel::where('sno', $id)->first();
    $upd_QualificationModel->status = 2;
    $upd_QualificationModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'education' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $education = $request->education;
      $education_desc = $request->education_desc;
      $user_id = $request->user()->user_id;
      $chk = QualificationModel::where('education', $education)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Aplpicant Status Already Exists!'
        ]);
        return redirect()->back();
      } else {
        $category_check = QualificationModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

       
        $add_department = new QualificationModel();
        $add_department->education = $education;
        $add_department->education_desc = $education_desc;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Qualification added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Qualification!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editdepartment = QualificationModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Qualification not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Qualification fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

   public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'education' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $education = $request->education;
      $education_desc = $request->education_desc;
      $user_id = $request->user()->user_id;
      $chk = QualificationModel::where('education', $education)->where('sno', '!=', $sno)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Qualification Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = QualificationModel::where('sno', $sno)->first();
        $up_department->education = $education;
        $up_department->education_desc = $education_desc;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Qualification updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Qualification!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

}
