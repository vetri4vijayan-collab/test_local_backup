<?php

namespace App\Http\Controllers\settings\payroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RuleCategoryModel;
use Illuminate\Support\Facades\Validator;

class RuleCategory extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = RuleCategoryModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('rule_category', 'LIKE', "%{$search_filter}%")
                    ->orWhere('category_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'rule_category' => $item->rule_category,
                    'category_desc' => $item->category_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.payroll.rule_category.rule_category_list',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = RuleCategoryModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'rule_category' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $rule_category       = $request->rule_category;
            $category_desc          = $request->category_desc;
            $user_id                    = 1;
            $chk = RuleCategoryModel::where( 'rule_category', $rule_category )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already  Interview Mode is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = RuleCategoryModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                

                $add_branchtype = new RuleCategoryModel();
                $add_branchtype->rule_category       = $rule_category;
                $add_branchtype->category_desc       = $category_desc;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Interview Mode added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Interview Mode!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'rule_category' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $rule_category       = $request->rule_category;
            $category_desc       = $request->category_desc;
            $document_id       = $request->edit_id;

            $upd_RuleCategoryModel =  RuleCategoryModel::where( 'sno', $document_id )->first();

            $chk = RuleCategoryModel::where( 'rule_category', $rule_category )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already  Interview Mode is exist!'
                ] );
                return redirect()->back();
            }

            $upd_RuleCategoryModel->rule_category  = $rule_category;
            $upd_RuleCategoryModel->category_desc  = $category_desc;
            $upd_RuleCategoryModel->update();

            if ( $upd_RuleCategoryModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Interview Mode Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Interview Mode!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_RuleCategoryModel = RuleCategoryModel::where( 'sno', $id )->first();
        $upd_RuleCategoryModel->status  = 2;
        $upd_RuleCategoryModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Interview Mode Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_RuleCategoryModel =  RuleCategoryModel::where( 'sno', $id )->first();
        $upd_RuleCategoryModel->status = $request->input( 'status', 0 );
        $upd_RuleCategoryModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}
