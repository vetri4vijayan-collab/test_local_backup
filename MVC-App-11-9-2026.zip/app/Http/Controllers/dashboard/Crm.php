<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\StaffModel;
use Carbon\Carbon;
use Carbon\CarbonPeriod;

class Crm extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();
        $user_id = $request->user()->user_id ?? 1;
        $startOfWeek = Carbon::now()->startOfWeek(Carbon::SUNDAY);
        $endOfWeek   = Carbon::now()->endOfWeek(Carbon::SATURDAY);

        if ($user_id == 0) {
            return view('content.dashboard.dashboards', [
                'companies' => DB::table('egc_company')->where('status', 0)->get(),
                'startOfWeek' => $startOfWeek,
                'endOfWeek' => $endOfWeek,
            ]);
        } else {
            return view('content.dashboard.dashboards-crm');
        }

        // return view('content.dashboard.dashboards', [
        //     'companies' => DB::table('egc_company')->where('status', 0)->get(),
        //     'startOfWeek' => $startOfWeek,
        //     'endOfWeek' => $endOfWeek,
        // ]);
        //   return view('content.dashboard.hr_ultra',[
        //      'companies' => DB::table('egc_company')->where('status',0)->get(),
        //   ]);
        //   return view('content.dashboard.dashboards-crm');
    }

    public function EysiumOne(Request $request)
    {
        $user = Auth::user();
        $user_id = $request->user()->user_id ?? 1;
        $startOfWeek = Carbon::now()->startOfWeek(Carbon::SUNDAY);
        $endOfWeek   = Carbon::now()->endOfWeek(Carbon::SATURDAY);

   
        return view('content.dashboard.elysiumone_lunched');
        

        
    }
    public function HREnrollDashboard(Request $request)
    {
        $user = Auth::user();
        $user_id = $request->user()->user_id ?? 1;
        $startOfWeek = Carbon::now()->startOfWeek(Carbon::SUNDAY);
        $endOfWeek   = Carbon::now()->endOfWeek(Carbon::SATURDAY);

        return view('content.dashboard.dashboards', [
            'companies' => DB::table('egc_company')->where('status', 0)->get(),
            'startOfWeek' => $startOfWeek,
            'endOfWeek' => $endOfWeek,
        ]);
        

        // return view('content.dashboard.dashboards', [
        //     'companies' => DB::table('egc_company')->where('status', 0)->get(),
        //     'startOfWeek' => $startOfWeek,
        //     'endOfWeek' => $endOfWeek,
        // ]);
        //   return view('content.dashboard.hr_ultra',[
        //      'companies' => DB::table('egc_company')->where('status',0)->get(),
        //   ]);
        //   return view('content.dashboard.dashboards-crm');
    }


    public function getDashboardData(Request $request)
    {
        try {

            $month = date('m');

            $year  = date('Y');

            $today = now()->toDateString();
            $company = $request->company_id ?? '';
            $entity = $request->entity_id ?? '';
            $department = $request->department_id ?? '';
            $startDate = Carbon::create($year, $month, 1)->startOfMonth();
            $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
            $endOfMonth = date('Y-m-t', strtotime("$year-$month-01"));

            $lastMonthStart = Carbon::now()->subMonth()->startOfMonth();
            $lastMonthEnd   = Carbon::now()->subMonth()->endOfMonth();

            $lastMonth = $lastMonthStart->month;
            $lastYear  = $lastMonthStart->year;


            // 👨‍💼 STAFF
            // $totalStaff = DB::table('egc_staff')->where('status',0)->count() ?? 0;

            $staffQuery = DB::table('egc_staff')->where('status', 0);

            if ($company != '') {
                if ($company == 'egc') {
                    $staffQuery->where('egc_staff.company_type', 1);
                } else {
                    $staffQuery->where('egc_staff.company_id', 'LIKE', $company);
                }
            }
            if ($entity) {
                $staffQuery->where('egc_staff.entity_id', $entity);
            }


            if ($department) {
                $staffQuery->where('egc_staff.department_id', $department);
            }


            $staffIds = $staffQuery->pluck('sno');

            // ✅ PRESENT
            $presentCurrent = DB::table('egc_staff_attendance')
                // ->whereDate('date', $today)
                ->whereMonth('date',  $month)
                ->whereYear('date',  $year)
                ->whereIn('staff_id', $staffIds)
                ->where('attendance', 'P')
                ->where('status', 0)
                ->count() ?? 0;

            $ondutyCurrent = DB::table('egc_staff_attendance')
                // ->whereDate('date', $today)
                ->whereMonth('date',  $month)
                ->whereYear('date',  $year)
                ->whereIn('staff_id', $staffIds)
                ->where('attendance', 'OD')
                ->where('status', 0)
                ->count() ?? 0;


            $lateQuery  = DB::table('egc_staff_attendance as att')
                ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')
                ->leftJoin('egc_company', 's.company_id', 'egc_company.sno')
                ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
                ->join('egc_shift_time_log as stl', function ($join) {
                    $join->on('stl.staff_id', '=', 'att.staff_id');
                })
                ->join('egc_shift_day_times as sd', function ($join) {
                    $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                        ->where('sd.status', 0);
                })
                // ->whereDate('att.date', $today)
                ->whereMonth('att.date',  $month)
                ->whereYear('att.date',  $year)
                ->whereIn('att.staff_id', $staffIds)
                ->where('att.status', 0)

                ->whereRaw("DATE(att.date) BETWEEN stl.start_date AND IFNULL(stl.end_date, '9999-12-31')")
                // ✅ Match day (Mon, Tue...)
                ->whereRaw("LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))")
                // ✅ Late condition
                // ->whereRaw("TIME(att.in_time) > TIME(sd.time_from)")
                ->whereRaw("TIME(att.in_time) > ADDTIME(sd.time_from, '00:15:00')");
            // ->whereRaw("
            //     TIME_FORMAT(att.in_time, '%H:%i') > TIME_FORMAT(sd.time_from, '%H:%i')
            // ")
            $late = $lateQuery->count();

            $absentQury  = DB::table('egc_staff_attendance as att')
                ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')
                ->leftJoin('egc_company', 's.company_id', 'egc_company.sno')
                ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
                // ->whereDate('att.date', $today)
                ->whereMonth('att.date',  $month)
                ->whereYear('att.date',  $year)
                ->whereIn('att.staff_id', $staffIds)
                ->whereIn('att.attendance', ['L', 'A'])
                ->where('att.status', 0);
            $absentCurrent = $absentQury->count();
            $absentDetails = $absentQury
                ->select('s.staff_name', 'egc_entity.entity_base_color', 'att.in_time')
                ->limit(10)
                ->get();
            // ✅ LATE DETAILS
            $lateDetails = $lateQuery
                ->select('s.staff_name', 'att.in_time', 'sd.time_from', 'egc_entity.entity_base_color')
                ->get();

            $permissionQuery  = DB::table('egc_staff_attendance as att')
                ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')
                ->leftJoin('egc_company', 's.company_id', 'egc_company.sno')
                ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
                // ->whereDate('att.date', $today)
                ->whereMonth('att.date',  $month)
                ->whereYear('att.date',  $year)
                ->where('att.attendance', 'PR')
                ->whereIn('att.staff_id', $staffIds)
                ->where('att.status', 0);
            $permissionCurrent = $permissionQuery->count();

            $permissionDetails = $permissionQuery
                ->select('s.staff_name', 'egc_entity.entity_base_color', 'att.in_time')
                ->limit(10)
                ->get();

            $totalStaff = $staffIds->count();

            $total_attendance = $presentCurrent + $absentCurrent + $permissionCurrent + $ondutyCurrent;
            $total_presentCurrent = $presentCurrent + $permissionCurrent + $ondutyCurrent;
            $attendance_rate = $total_attendance > 0 ? ($total_presentCurrent / $total_attendance) * 100  : 0;
            $attendance_rate = round($attendance_rate);

            // ✅ ALERTS
            $alerts = [];

            if ($late > 10) {
                $alerts[] = [
                    'title' => '⚠️ High Late Attendance',
                    'time' => now()->format('H:i')
                ];
            }

            if ($absentCurrent > ($totalStaff * 0.2)) {
                $alerts[] = [
                    'title' => '🚨 High Absenteeism',
                    'time' => now()->format('H:i')
                ];
            }
            //  EMPLOYEES (SAFE FIELDS)
            $employees = DB::table('egc_staff')->where('egc_staff.status', '!=', 2)
                ->select(
                    'egc_staff.*',
                    'egc_entity.entity_name',
                    'egc_entity.entity_short_name',
                    'egc_company.company_name',
                    'egc_company.company_base_color',
                    'egc_company.company_logo',
                    'egc_department.department_name',
                    'egc_division.division_name',
                    'egc_shift_time.shift_name',
                    'egc_job_role.job_position_name as job_role_name',
                )
                ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
                ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
                ->leftJoin('egc_shift_time', 'egc_staff.shift_time_id', 'egc_shift_time.sno')
                ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
                ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
                ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
                ->whereIn('egc_staff.status', [0, 1])
                ->latest()
                ->limit(5)
                ->get();

            $totalGrossSalary = 0;
            $totalDeduction = 0;
            $totalNetSalary = 0;

            $today = Carbon::today();

            // Limit end date to today if month is current
            if ($today->between($startDate, $endDate)) {
                $endDate = $today;
            }


            $holidays = DB::table('egc_holiday')
                ->where('status', 0)
                ->where(function ($q) use ($startDate, $endDate) {
                    $q->whereBetween('hol_date', [$startDate, $endDate])
                        ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
                })->get();

            $holidayDates = collect();
            foreach ($holidays as $hol) {
                $start = Carbon::parse($hol->hol_date);
                $end = $hol->hol_end_date ? Carbon::parse($hol->hol_end_date) : $start;
                foreach (CarbonPeriod::create($start, $end) as $d) {
                    $holidayDates->push($d->format('Y-m-d'));
                }
            }
            $holidayDates = $holidayDates->unique();
            $startOfWeek = Carbon::now()->startOfWeek(Carbon::SUNDAY);
            $endOfWeek   = Carbon::now()->endOfWeek(Carbon::SATURDAY);

            $payrollProcess = DB::table('egc_payroll_processes')
                ->where('payroll_month', $month)
                ->where('payroll_year', $year)
                ->where('status', 0)
                ->first();

            $isLiveMode = !$payrollProcess;

            $attendanceSummary = DB::table('egc_staff_attendance')
                ->select(
                    'staff_id',
                    DB::raw("SUM(CASE WHEN attendance='A' THEN 1 ELSE 0 END) as absent_days"),
                    DB::raw("SUM(CASE WHEN attendance IN ('P','OD','PR') THEN 1 ELSE 0 END) as present_days"),
                    DB::raw("SUM(CASE WHEN attendance='L' THEN 1 ELSE 0 END) as leave_days"),
                    DB::raw("SUM(CASE WHEN attendance='PR' THEN 1 ELSE 0 END) as permission_days"),
                    DB::raw("SUM(CASE WHEN attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
                )
                ->whereMonth('date', $month)
                ->whereYear('date', $year)
                ->where('status', 0)
                ->groupBy('staff_id');

            $staffQuery = $this->getPayrollStaffQuery($month, $year);
            $allStaffIds = $staffQuery->pluck('s.sno');
            $staff = $staffQuery->get();

            $totalGrossSalary = 0;
            $totalDeduction = 0;
            $totalNetSalary = 0;

            $earningComponents = [];
            $deductionComponents = [];

            // ------------------ SHIFT LOGS & ATTENDANCE ------------------
            $allShiftLogs = DB::table('egc_shift_time_log as stl')
                ->join('egc_shift_day_times as sdt', 'stl.change_shift_id', '=', 'sdt.shift_id')
                ->whereIn('stl.staff_id', $allStaffIds)
                ->where('sdt.status', 0)
                ->select('stl.staff_id', 'stl.start_date', 'stl.end_date', 'sdt.day_name')
                ->orderBy('stl.start_date')
                ->get()
                ->groupBy('staff_id');

            $attendanceRecords = DB::table('egc_staff_attendance')
                ->whereIn('staff_id', $allStaffIds)
                ->whereBetween('date', [$startDate, $endDate])
                ->where('status', 0)
                ->get()
                ->groupBy('staff_id')
                ->map(fn($items) => $items->keyBy('date'));

           

                $CurrentMonthsummary = $this->getMonthlySalarySummary($month,$year,$isLiveMode);
                // return $CurrentMonthsummary;
                $totalGrossSalary = round($CurrentMonthsummary['gross']);
                $totalNetSalary = round($CurrentMonthsummary['net']);
                $totalDeduction =round($CurrentMonthsummary['deduction']);

               

              



            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();

            $entityCounts = StaffModel::select(
                DB::raw('COUNT(*) as total'),
                'egc_staff.company_id',
                'egc_company.company_short_name',
                DB::raw('CASE 
                    WHEN egc_staff.company_type = 1 THEN "' . $general_setting->title . '" 
                    ELSE egc_entity.entity_name 
                END as entity_name'),
                DB::raw('CASE 
                    WHEN egc_staff.company_type = 1 THEN "' . $general_setting->company_short_name . '" 
                    ELSE egc_entity.entity_short_name 
                END as entity_short_name'),
                DB::raw('CASE 
                    WHEN egc_staff.company_type = 1 THEN "' . $general_setting->title . '" 
                    ELSE egc_company.company_name 
                END as company_name'),
                DB::raw('CASE 
                    WHEN egc_staff.company_type = 1 THEN "' . $general_setting->logo . '" 
                    ELSE egc_company.company_logo 
                END as company_logo'),
                DB::raw('CASE 
                    WHEN egc_staff.company_type = 1 THEN "#ab2b22" 
                    ELSE egc_company.company_base_color 
                END as company_base_color'),
                DB::raw('CASE 
                    WHEN egc_staff.company_type = 1 THEN "#ab2b22" 
                    ELSE egc_entity.entity_base_color 
                END as entity_base_color')
            )
                ->leftJoin('egc_company', 'egc_staff.company_id', '=', 'egc_company.sno')
                ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
                ->where('egc_staff.status', '!=', 2)
                ->where('egc_staff.sno', '>', 1)
                ->whereIn('egc_staff.status', [0, 1])
                ->groupBy('company_name', 'company_logo', 'company_base_color', 'entity_base_color', 'egc_staff.company_type', 'egc_staff.company_id', 'egc_company.company_short_name', 'egc_entity.entity_short_name', 'egc_entity.entity_name')
                ->orderBy('egc_staff.company_id', 'asc')
                ->get();

            $attendanceChart = DB::table('egc_staff_attendance')
                ->select(
                    DB::raw("DATE(date) as day"),
                    DB::raw("SUM(CASE WHEN attendance IN ('P','OD','PR') THEN 1 ELSE 0 END) as present"),
                    DB::raw("SUM(CASE WHEN attendance IN ('A','L') THEN 1 ELSE 0 END) as absent")
                )
                // ->whereBetween('date', [$startDate, $endDate])
                ->whereBetween('date', [$startOfWeek, $endOfWeek])
                ->whereIn('staff_id', $staffIds)
                ->where('status', 0)
                ->groupBy(DB::raw("DATE(date)"))
                ->orderBy('day')
                ->get();
            $categories = [];
            $presentData = [];
            $absentData = [];
            $presentRatio = [];

            foreach ($attendanceChart as $row) {
                $categories[] = Carbon::parse($row->day)->format('D');

                $present = (int) $row->present;
                $absent = (int) $row->absent;

                $presentData[] = $present;
                $absentData[] = $absent;

                $ratio = ($present + $absent) > 0
                    ? round(($present / ($present + $absent)) * 100, 1)
                    : 0;

                $presentRatio[] = $ratio;
            }

            $enrollmentData = DB::table('egc_staff')
                ->select(
                    DB::raw("MONTH(date_of_joining) as month"),
                    DB::raw("COUNT(*) as total")
                )
                ->whereYear('date_of_joining', $year)
                ->whereIn('sno', $staffIds) // respect filters
                ->where('status', '!=', 2)
                ->groupBy(DB::raw("MONTH(date_of_joining)"))
                ->pluck('total', 'month'); // key = month, value = count

            $months = [
                1 => 'Jan',
                2 => 'Feb',
                3 => 'Mar',
                4 => 'Apr',
                5 => 'May',
                6 => 'Jun',
                7 => 'Jul',
                8 => 'Aug',
                9 => 'Sep',
                10 => 'Oct',
                11 => 'Nov',
                12 => 'Dec'
            ];

            $enrollCategories = [];
            $enrollmentSeries = [];

            foreach ($months as $num => $name) {
                $enrollCategories[] = $name;
                $enrollmentSeries[] = $enrollmentData[$num] ?? 0;
            }


            $lastGross = 0;
            $lastNet = 0;

            $lastStaff = DB::table('egc_staff')
                ->whereMonth('date_of_joining', $lastMonth)
                ->whereYear('date_of_joining', $lastYear)
                ->where('status', '!=', 2)
                ->count();
            $currentStaff = DB::table('egc_staff')
                ->whereMonth('date_of_joining',  $month)
                ->whereYear('date_of_joining',  $year)
                ->where('status', '!=', 2)
                ->count();
            $currentExit = DB::table('egc_staff')
                ->whereNotIn('status', [0, 1, 2]) // only exited users
                ->where(function ($query) use ($year, $month) {

                    //  Notice period employees
                    $query->where(function ($q) use ($year, $month) {
                        $q->where('status', 4)
                            ->whereNotNull('notice_end_date')
                            ->whereYear('notice_end_date', $year)
                            ->whereMonth('notice_end_date', $month);
                    })

                        //  Other exited employees
                        ->orWhere(function ($q) use ($year, $month) {
                            $q->where('status', '!=', 4)
                                ->whereNotNull('staff_last_date')
                                ->whereYear('staff_last_date', $year)
                                ->whereMonth('staff_last_date', $month);
                        });
                })
                ->count();
            $lastMonthExit = DB::table('egc_staff')
                ->whereMonth('staff_last_date',  $lastMonth)
                ->whereYear('staff_last_date',  $lastYear)
                ->whereNotIn('status', [0, 1, 2])
                ->where(function ($query) use ($lastYear, $lastMonth) {

                    //  Notice period employees
                    $query->where(function ($q) use ($lastYear, $lastMonth) {
                        $q->where('status', 4)
                            ->whereNotNull('notice_end_date')
                            ->whereYear('notice_end_date', $lastYear)
                            ->whereMonth('notice_end_date', $lastMonth);
                    })

                        // Other exited employees
                        ->orWhere(function ($q) use ($lastYear, $lastMonth) {
                            $q->where('status', '!=', 4)
                                ->whereNotNull('staff_last_date')
                                ->whereYear('staff_last_date', $lastYear)
                                ->whereMonth('staff_last_date', $lastMonth);
                        });
                })
                ->count();

            $lastMonthStaff = DB::table('egc_staff as s')
                ->whereMonth('s.date_of_joining', $lastMonth)
                ->whereYear('s.date_of_joining', $lastYear)
                ->where('s.status', 0)
                ->get();

            $lastGross = 0;
            $lastNet   = 0;

            $lastsummary = $this->getMonthlySalarySummary($lastMonth,$lastYear,$isLiveMode);
            $lastGross = round($lastsummary['gross']);
            $lastNet = round($lastsummary['net']);
            

            $grossChange = $this->calcPercentage($totalGrossSalary, $lastGross);
            $netChange   = $this->calcPercentage($totalNetSalary, $lastNet);
            $staffChange = $this->calcPercentage($currentStaff, $lastStaff);
            $staffExitChange = $this->calcPercentage($currentExit, $lastMonthExit);

            $salaryMonths = [];
            $grossSeries = [];
            $netSeries = [];

            for ($i = 2; $i >= 0; $i--) {

                $date = Carbon::create($year, $month, 1)
                    ->subMonths($i);

                $salaryMonths[] = $date->format('M');

                $summary = $this->getMonthlySalarySummary(
                    $date->month,
                    $date->year,
                    $isLiveMode
                );

                $grossSeries[] = round($summary['gross'], 2);

                $netSeries[] = round($summary['net'], 2);
            }



            return response()->json([
                'status' => true,
                'data' => [
                    'totalStaff' => $totalStaff,
                    'attendance_rate' => $attendance_rate,
                    'present' => $presentCurrent,
                    'late' => $late,
                    'permission' => $permissionCurrent,
                    'absent' => $absentCurrent,
                    'lateDetails' => $lateDetails,
                    'entityCounts' => $entityCounts,
                    'absentDetails' => $absentDetails,
                    'permissionDetails' => $permissionDetails,
                    'totalNetSalary' => $totalNetSalary,
                    'totalDeduction' => $totalDeduction,
                    'totalGrossSalary' => $totalGrossSalary,
                    'chart' => [
                        'categories' => $categories,
                        'present' => $presentData,
                        'absent' => $absentData,
                        'ratio' => $presentRatio
                    ],
                    'enrollment_chart' => [
                        'categories' => $enrollCategories,
                        'data' => $enrollmentSeries
                    ],
                    'changes' => [
                        'gross' => $grossChange,
                        'net' => $netChange,
                        'staff' => $staffChange,
                        'exitStaff' => $staffExitChange,

                    ],
                    'lastGross' => $lastGross,
                    'lastNet' => $lastNet,
                    'lastStaff' => $lastStaff,
                    'currentStaff' => $currentStaff,
                    'currentExit' => $currentExit,
                    'salary_variation' => [
                        'months' => $salaryMonths,
                        'gross' => $grossSeries,
                        'net' => $netSeries
                    ],
                ]
            ]);
        } catch (\Exception $e) {

            \Log::error('Dashboard Error: ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'data' => [],
                'message' => 'Something went wrong' . $e->getMessage()
            ]);
        }
    }

    private function applyRules($staff, $month, $year, $basic)
    {

        // return $month;
        // 👉 load rules
        $rules = DB::table('egc_payroll_rules')
            ->where('status', 0)
            ->get();


        // attendance
        $attendance = DB::table('egc_staff_attendance')
            ->where('staff_id', $staff->sno)
            ->whereMonth('date', $month)
            ->whereYear('date', $year)
            ->where('status', 0)
            ->get();

        // return $staff->sno;

        $lateCount = DB::table('egc_staff_attendance as att')
            ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')

            ->join('egc_shift_time_log as stl', function ($join) {
                $join->on('stl.staff_id', '=', 'att.staff_id');
            })

            ->join('egc_shift_day_times as sd', function ($join) {
                $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                    ->where('sd.status', 0);
            })

            ->where('att.staff_id', $staff->sno)

            // 👉 Month filter
            ->whereMonth('att.date', $month)
            ->whereYear('att.date', $year)

            ->where('att.status', 0)
            ->whereNotNull('att.in_time')

            // ✅ JOINING DATE CHECK
            ->whereRaw("DATE(att.date) >= DATE(s.date_of_joining)")

            // ✅ SHIFT DATE RANGE CHECK
            ->whereRaw("
                DATE(att.date) BETWEEN stl.start_date 
                AND IFNULL(stl.end_date, '9999-12-31')
            ")

            // ✅ DAY MATCH (Mon, Tue...)
            ->whereRaw("
                LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))
            ")

            // ✅ LATE CHECK
            // ->whereRaw("
            //     TIME(att.in_time) > TIME(sd.time_from)
            // ")
            ->whereRaw("TIME(att.in_time) > ADDTIME(sd.time_from, '00:11:00')")

            ->count();

        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
        $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
        $today = Carbon::today();

        // Limit end date to today if month is current
        if ($today->between($startDate, $endDate)) {
            $endDate = $today;
        }

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('hol_date', [$startDate, $endDate])
                    ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->get();

        $holidayDates = collect();

        foreach ($holidays as $hol) {
            $start = Carbon::parse($hol->hol_date);
            $end   = $hol->hol_end_date ? Carbon::parse($hol->hol_end_date) : $start;

            foreach (CarbonPeriod::create($start, $end) as $d) {
                $holidayDates->push($d->format('Y-m-d'));
            }
        }

        $holidayDates = $holidayDates->unique();


        $present = 0;
        $absent = 0;
        $late = $lateCount;


        foreach ($attendance as $a) {
            $dateKey = $a->date;

            if ($holidayDates->contains($dateKey)) {
                continue;
            }
            if ($a->attendance == 'P') $present++;
            if ($a->attendance == 'OD') $present++;
            if ($a->attendance == 'PR') $present++;
            if ($a->attendance == 'A') $absent++;
            if ($a->attendance == 'L') {
                if ($a->leave_type == 'full') {
                    $absent += 1;
                } elseif (in_array($a->leave_type, ['first_half', 'second_half'])) {
                    $absent += 0.5;
                }
            }
            // if($a->attendance == 'L') $absent++; 25-03-26
            // if($a->in_time && $a->in_time > '09:30:00') $late++;
        }



        $totalDeduction = 0;
        $lopDays = 0;
        $lopAmount = 0;

        $ruleBreakdown = [];

        foreach ($rules as $rule) {

            $condition = json_decode($rule->condition_json, true);
            $action = json_decode($rule->action_json, true);

            // =====================
            //  LOP RULE
            // =====================
            if ($rule->rule_type == 'lop') {

                $allowedLeave = $staff->casual_leave_count_per_month ?? 0;

                // return $absent;

                $lopDays = max(0, $absent - $allowedLeave);

                $perDay = $staff->per_day_salary;

                $lopAmount = $lopDays * $perDay;

                $totalDeduction += $lopAmount;

                $ruleBreakdown[] = [
                    'rule' => 'LOP',
                    'days' => $lopDays,
                    'amount' => $lopAmount
                ];
            }

            // =====================
            //  LATE RULE
            // =====================
            if ($rule->rule_type == 'late') {

                $allowed = $condition['allowed_per_month'] ?? 0;
                $lopPerLate = $action['lop_per_late'] ?? 0;



                $extraLate = max(0, $late - $allowed);


                $lateLopDays = $extraLate * $lopPerLate;

                $amount = $lateLopDays * $staff->per_day_salary;

                $totalDeduction += $amount;

                $ruleBreakdown[] = [
                    'rule' => 'Late',
                    'days' => $lateLopDays,
                    'total_late_Count' => $late,
                    'allowed_late_Count' => $allowed,
                    'lopPerLate' => $lopPerLate,
                    'amount' => $amount
                ];
            }

            // =====================
            //  Permission RULE
            // =====================

            if ($rule->rule_type == 'permission') {

                $condition = json_decode($rule->condition_json, true);
                $action = json_decode($rule->action_json, true);

                $allowedHours = $condition['max_hours'] ?? 0;
                $deductionPerDay = $action['deduction'] ?? 0; // usually 0.5 or 1

                // 👉 GET TOTAL PERMISSION MINUTES
                $permissionMinutes = DB::table('egc_staff_attendance')
                    ->where('staff_id', $staff->sno)
                    ->whereMonth('date', $month)
                    ->whereYear('date', $year)
                    ->where('attendance', 'PR')
                    ->where('status', 0)
                    ->selectRaw("
                    SUM(
                        TIMESTAMPDIFF(MINUTE, start_time, end_time)
                    ) as total_minutes
                ")
                    ->value('total_minutes');

                $permissionMinutes = $permissionMinutes ?? 0;

                // 👉 Convert to hours
                $permissionHours = $permissionMinutes / 60;

                // 👉 Calculate excess
                $extraHours = max(0, $permissionHours - $allowedHours);

                // 👉 Convert hours → days
                // assume 8 hours = 1 day (you can make dynamic later)
                $workingHoursPerDay = 8;

                $deductionDays = ($extraHours / $workingHoursPerDay) * $deductionPerDay;

                $amount = $deductionDays * $staff->per_day_salary;

                $totalDeduction += $amount;

                $ruleBreakdown[] = [
                    'rule' => 'Permission',
                    'total_hours' => round($permissionHours, 2),
                    'allowed_hours' => $allowedHours,
                    'extra_hours' => round($extraHours, 2),
                    'deduction_days' => round($deductionDays, 2),
                    'amount' => round($amount, 2)
                ];
            }

            // =====================
            //  ESI RULE
            // =====================
            // if($rule->rule_type == 'esi'){

            //     $limit = $condition['salary_limit'] ?? 0;
            //     $percent = $action['percentage'] ?? 0;

            //     if($basic <= $limit){
            //         $esi = ($basic * $percent)/100;
            //         $totalDeduction += $esi;

            //         $ruleBreakdown[] = [
            //             'rule'=>'ESI',
            //             'amount'=>$esi
            //         ];
            //     }
            // }

            if ($rule->rule_type == 'esi') {

                $limit = $condition['salary_limit'] ?? 0;

                if ($basic > $limit) {

                    $ruleBreakdown[] = [
                        'rule' => 'ESI',
                        'amount' => 0,
                        'note' => 'Not applicable (salary > limit)'
                    ];

                    //  DO NOT CALCULATE HERE
                }
            }

            // =====================
            //  PF RULE
            // =====================
            // if($rule->rule_type == 'pf'){

            //     $percent = $condition['percentage'] ?? 0;
            //     $max = $action['max_limit'] ?? 0;

            //     $pf = ($basic * $percent)/100;

            //     if($max > 0){
            //         $pf = min($pf,$max);
            //     }

            //     $totalDeduction += $pf;

            //     $ruleBreakdown[] = [
            //         'rule'=>'PF',
            //         'amount'=>$pf
            //     ];
            // }

        }

        return [
            'total_deductions' => $totalDeduction,
            'lop_days' => $lopDays,
            'lop_amount' => $lopAmount,
            'breakdown' => $ruleBreakdown
        ];
    }

    private function calculatePayroll($staff, $month, $year, $holidayDates, $allShiftLogs, $attendanceRecords)
    {
        $basic = $staff->basic_salary;

        $components = DB::table('egc_staff_salary_components_new as sc')
            ->join('egc_salary_components as c', 'c.sno', '=', 'sc.component_id')
            ->where('sc.staff_id', $staff->sno)
            ->where('sc.status', 0)
            ->where('sc.is_active', 1)
            ->select('sc.*', 'c.type', 'c.component_name', 'c.rule_type')
            ->get();

        $isDateOfJoiningPast = Carbon::parse($staff->date_of_joining)->lte(Carbon::create($year, $month, 1));




        // $presentDays = ($staff->salary_earning_days ?? 0);25-03-26
        // $perDaySalary = $staff->per_day_salary ?? 0;
        // $basicEarned = $presentDays * $perDaySalary;
        // $earnings = $basicEarned;

        $deductions = 0;
        $breakdown = [];

        // $earnings += $basic;

        // if(!$isDateOfJoiningPast){
        //     $presentDays = ($staff->salary_earning_days_not_wk ?? 0);
        //     $perDaySalary = $staff->per_day_salary ?? 0;
        //     $basicEarned = $presentDays * $perDaySalary;
        //     $earnings = round($basicEarned, 1);

        //      $breakdown[] = [  //25-03-26
        //         'name' => 'Basic Salary',
        //         'amount' => round($basicEarned, 1),
        //         'type' => 'earning'
        //     ];
        // }
        if (!$isDateOfJoiningPast) {
            $perDaySalary = $staff->per_day_salary ?? 0;
            $start = Carbon::parse($staff->date_of_joining);
            $end   = Carbon::create($year, $month, 1)->endOfMonth();
            $earningDays = 0;
            $staffShift = $allShiftLogs[$staff->sno] ?? collect();
            foreach (CarbonPeriod::create($start, $end) as $d) {
                $dateKey = $d->format('Y-m-d');
                // ✅ HOLIDAY → count as present
                if ($holidayDates->contains($dateKey)) {
                    $earningDays++;
                    continue;
                }
                // ✅ CHECK WEEKOFF
                $dayName = strtolower($d->format('D'));
                $shift = $staffShift->firstWhere('day_name', $dayName);
                if (!$shift) {
                    // 👉 NO SHIFT → default Sunday as weekoff
                    if ($d->isSunday()) {
                        $earningDays++;
                        continue;
                    }
                } else {
                    // 👉 SHIFT EXISTS → this day is weekoff
                    $earningDays++;
                    continue;
                }

                // ✅ ATTENDANCE CHECK
                $attendance = $attendanceRecords[$staff->sno][$dateKey] ?? null;
                if ($attendance) {
                    if (in_array($attendance->attendance, ['P', 'PR', 'OD'])) {
                        $earningDays++;
                    }

                    if ($attendance->attendance == 'L') {
                        if ($attendance->leave_type == 'full') {
                            // no add
                        } elseif (in_array($attendance->leave_type, ['first_half', 'second_half'])) {
                            $earningDays += 0.5;
                        }
                    }
                }
            }

            $basicEarned = $earningDays * $perDaySalary;
            $earnings = round($basicEarned, 1);

            $breakdown[] = [
                'name' => 'Basic Salary',
                'amount' => round($basicEarned, 1),
                'type' => 'earning'
            ];
        } else {
            $earnings = $basic;
            $breakdown[] = [
                'name' => 'Basic Salary',
                'amount' => round($basic, 1),
                'type' => 'earning'
            ];
        }

        // $breakdown[] = [25-03-26
        //     'name' => 'Basic Salary',
        //     'amount' => $basicEarned,
        //     'type' => 'earning'
        // ];

        foreach ($components as $c) {
            $amount = $c->amount;

            if ($c->calculation_type == 'percentage' && $c->rule_type != 'esi' && $c->rule_type != 'pf') {
                $amount = ($basic * $c->amount) / 100;
            }

            if ($c->calculation_type == 'fixed' && $c->rule_type != 'esi' && $c->rule_type != 'pf') {
                $amount = $c->amount;
            }

            if ($c->rule_type == 'esi') {
                $esiRule = $this->getRule('esi');

                if ($esiRule) {
                    $limit = $esiRule['condition']['salary_limit'] ?? 0;

                    if ($basic > $limit) {
                        $amount = 0;
                    } else {
                        if ($c->calculation_type == 'percentage') {
                            $amount = ($basic * $c->amount) / 100;
                        } else {
                            $amount = $c->amount;
                        }
                    }
                }
            }

            if ($c->rule_type == 'pf') {
                $pfRule = $this->getRule('pf');

                if ($pfRule) {
                    $max = $pfRule['action']['max_limit'] ?? 0;

                    if ($max > 0) {
                        $amount = min($amount, $max);
                    }
                }
            }

            if ($c->type == 'earning') {
                $earnings += $amount;
            } else {
                $deductions += $amount;
            }

            $breakdown[] = [
                'name' => $c->component_name,
                'amount' => round($amount, 1),
                'type' => $c->type
            ];
        }


        // APPLY RULE ENGINE
        $rules = $this->applyRules($staff, $month, $year, $basic);


        $lopFound = false;

        foreach ($breakdown as &$comp) {
            if ($comp['name'] == 'Loss of Pay') {
                $comp['amount'] = round($rules['lop_amount'], 2);
                $lopFound = true;
            }
        }
        unset($comp);

        // If not found → add manually
        if (!$lopFound && $rules['lop_amount'] > 0) {
            $breakdown[] = [
                'component_id' => 8,
                'name' => 'Loss of Pay',
                'amount' => round($rules['lop_amount'], 2),
                'type' => 'deduction'
            ];
        }


        $deductions += round($rules['total_deductions'], 1);
        $net = $earnings - $deductions;



        return [
            'staff_id' => $staff->sno,
            'name' => $staff->staff_name,
            'basic' => $basic,
            'earnings' => $earnings,
            'deductions' => $deductions,
            'net' => $net,
            'lop_days' => $rules['lop_days'],
            'lop_amount' => $rules['lop_amount'],
            'components' => $breakdown,
            'rules' => $rules['breakdown'],

            // ADD THESE 👇
            'present_days' => $present ?? 0,
            'absent_days' => $absent ?? 0,
            'late_count' => $late ?? 0
        ];
    }

    private function getRule($type)
    {
        static $rules = null;

        if ($rules === null) {
            $rules = DB::table('egc_payroll_rules')
                ->where('status', 0)
                ->get()
                ->keyBy('rule_type');
        }

        if (!isset($rules[$type])) return null;

        return [
            'condition' => json_decode($rules[$type]->condition_json, true),
            'action' => json_decode($rules[$type]->action_json, true)
        ];
    }

    function calcPercentage($current, $previous)
    {
        if ($previous == 0) return 0;
        return round((($current - $previous) / $previous) * 100, 1);
    }

    private function getPayrollStaffQuery($month, $year)
    {
        $endOfMonth = date('Y-m-t', strtotime("$year-$month-01"));

        return DB::table('egc_staff_salary_accounts')
            ->join('egc_staff as s','s.sno','=','egc_staff_salary_accounts.staff_id')
            ->leftJoin('egc_company as salary_company', 'egc_staff_salary_accounts.salary_company_id', '=', 'salary_company.sno')
            ->leftJoin('egc_company', 's.company_id', '=', 'egc_company.sno')
            ->leftJoin('egc_entity', 's.entity_id', '=', 'egc_entity.sno')
            ->leftJoin('egc_department', 's.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 's.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 's.job_role_id', '=', 'egc_job_role.sno')
            ->where('s.status','!=', 2)
            ->where('egc_staff_salary_accounts.status',0)
            ->where(function ($q) use ($month, $year) {
                /*
                |--------------------------------------------------------------------------
                | ACTIVE STAFF
                |--------------------------------------------------------------------------
                */
                $q->whereIn('s.status', [0, 1]);
                /*
                |--------------------------------------------------------------------------
                | NOTICE PERIOD STAFF
                |--------------------------------------------------------------------------
                */
                $q->orWhere(function ($notice) use ($month, $year) {
                    $notice->where('s.status', 4)
                        ->whereNotNull('s.notice_end_date')
                        ->whereMonth(
                            's.notice_end_date',
                            $month
                        )
                        ->whereYear(
                            's.notice_end_date',
                            $year
                        );
                });
                /*
                |--------------------------------------------------------------------------
                | EXITED STAFF
                |--------------------------------------------------------------------------
                */
                 $q->orWhere(function ($exit) use ($month, $year) {
                    $exit->whereIn('s.status', [5, 6, 7])
                        ->whereNotNull('s.staff_last_date')
                        ->whereMonth('s.staff_last_date', $month)
                        ->whereYear('s.staff_last_date', $year)
                        ->whereNotIn('s.sno', [211,212, 94,77]) // exclude special staff
                        ->whereRaw(
                            'DATEDIFF(s.staff_last_date, s.date_of_joining) > ?',
                            [3]
                        );
                })

                ->orWhere(function ($special) use ($month, $year) {

                    $payrollMonth = sprintf('%04d-%02d', $year, $month);

                    $special->whereIn('s.sno', [211,212,94,77])
                        ->whereIn('s.status', [5, 6, 7])
                        ->whereNotNull('s.staff_last_date')
                        ->whereRaw(
                            "? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                            AND DATE_FORMAT(DATE_SUB(s.staff_last_date, INTERVAL 1 MONTH), '%Y-%m')",
                            [$payrollMonth]
                        )
                        ->whereRaw(
                            'DATEDIFF(s.staff_last_date, s.date_of_joining) > ?',
                            [3]
                        );
                });
            })
            ->whereDate('s.date_of_joining', '<=', $endOfMonth)
            ->where('s.sno', '>', 0)
            // ->where('s.sno', 200)
            ->select(
                's.*',
                's.sno',
                's.staff_name',
                's.staff_id as staff_code',
                'egc_staff_salary_accounts.sno as salary_account_id',
                'egc_staff_salary_accounts.gross_salary as basic_salary',
                'egc_staff_salary_accounts.per_day_salary',
                's.company_id',
                's.entity_id',
                's.nick_name',
                's.mobile_no',
                's.staff_image',
                's.company_type',
                's.gender',
                's.salary_type',
                's.salary_date',
                's.staff_last_date',
                's.notice_start_date',
                's.notice_end_date',
                's.date_of_joining',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'salary_company.company_base_color as salary_company_base_color',
                'salary_company.company_name as salary_company_name',
                'egc_company.company_base_color',
                'egc_company.company_name',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name'
            );
    }

    private function getMonthlySalarySummary($month, $year, $isLiveMode)
    {
        $staffQuery = $this->getPayrollStaffQuery($month, $year);
        $staff = $staffQuery->get();
        $allStaffAccountIds = $staffQuery->pluck('egc_staff_salary_accounts.sno');
        if ($staff->isEmpty()) {
            return [
                'gross' => 0,
                'net' => 0,
            ];
        }

        if (!$isLiveMode) {
            $staffIds = $staff->pluck('sno');
            $summary = DB::table('egc_payroll_employee_payrolls')
                ->whereIn('staff_id', $staffIds)
                ->where('payroll_month', $month)
                ->where('payroll_year', $year)
                ->where('status', 0)
                ->selectRaw("
                    COALESCE(SUM(gross_earnings),0) as gross,
                    COALESCE(SUM(net_payable),0) as net
                ")
                ->first();
            return [
                'gross' => (float) $summary->gross,
                'net'   => (float) $summary->net,
            ];
        }

        $gross = 0;
        $net = 0;
        $deduction = 0;
        $payrollData[] =[];
        foreach ($staff as $employee) {
            $payroll = app(
                \App\Services\PayrollPreviewService::class
            )->calculateLivePayroll(
                $employee,
                $month,
                $year,
                0
            );
       
            $gross += $payroll['gross_salary'] ?? 0;
            $net += $payroll['net_salary'] ?? 0;
            $deduction += $payroll['deductions'] ?? 0;
        }

        $payrollDate = Carbon::create($year, $month, 1)->endOfMonth();

        $overallFixedGrossSalary = DB::table('egc_payroll_employee_structures')
            ->whereIn('salary_account_id', $allStaffAccountIds)
            ->where('status', 0)
            ->whereDate('effective_from', '<=', $payrollDate)
            ->where(function ($q) use ($payrollDate) {
                $q->whereNull('effective_to')
                ->orWhereDate('effective_to', '>=', $payrollDate);
            })
            ->sum('gross_salary');

        return [
            'gross' => round($overallFixedGrossSalary),
            'net'   => round($net),
            'deduction' => round($deduction),
            'staff_count' => $staff->count(),
        ];
    }
}
