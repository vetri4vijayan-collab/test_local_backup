<?php

namespace App\Http\Controllers\corporate_admin\stock_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageStock extends Controller
{
    public function index()
    {
        return view('content.corporate_admin.stock_management.manage_stock');
    }
    public function cycle_count()
    {
        return view('content.corporate_admin.stock_management.cycle_count');
    }
    public function damage()
    {
        return view('content.corporate_admin.stock_management.damage');
    }
    public function movements()
    {
        return view('content.corporate_admin.stock_management.movements');
    }
    public function expiry()
    {
        return view('content.corporate_admin.stock_management.expiry');
    }
}