<?php

namespace App\Http\Controllers\corporate_admin\stock_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageItems extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.stock_management.items_list');
  }

}
