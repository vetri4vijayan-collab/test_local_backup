<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LocationModel;
use App\Models\BuildingModel;
use App\Models\LessorModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ManageBuilding extends Controller
{

public function index(Request $request)
{
    try {

            $page       = $request->page ?? 1;
            $perPage    = $request->per_page ?? 10;
            $search     = trim($request->search);
            $status     = $request->status;
            $ownership  = $request->ownership_type;
            $location   = $request->location_id;


        if ($request->ajax()) {

            

            /*
            |--------------------------------------------------------------------------
            | Base Query
            |--------------------------------------------------------------------------
            */

            $query = BuildingModel::select(
                        'egc_buildings.*',
                        'egc_locations.location_code',
                        'egc_locations.area as location_name',
                        'egc_lessor.lessor_name'
                    )
                    ->leftJoin(
                        'egc_locations',
                        'egc_locations.sno',
                        '=',
                        'egc_buildings.location_id'
                    )
                    ->leftJoin(
                        'egc_lessor',
                        'egc_lessor.sno',
                        '=',
                        'egc_buildings.lessor_id'
                    );

                            /*
            |--------------------------------------------------------------------------
            | Search Filter
            |--------------------------------------------------------------------------
            */

            if (!empty($search)) {

                $query->where(function ($q) use ($search) {

                    $q->where('egc_buildings.building_name', 'LIKE', "%{$search}%")
                      ->orWhere('egc_buildings.building_code', 'LIKE', "%{$search}%")
                      ->orWhere('egc_buildings.door_no', 'LIKE', "%{$search}%")
                      ->orWhere('egc_buildings.street', 'LIKE', "%{$search}%")
                      ->orWhere('egc_locations.location_code', 'LIKE', "%{$search}%")
                      ->orWhere('egc_locations.area', 'LIKE', "%{$search}%")
                      ->orWhere('egc_lessor.lessor_name', 'LIKE', "%{$search}%");

                });

            }

            /*
            |--------------------------------------------------------------------------
            | Status Filter
            |--------------------------------------------------------------------------
            */

            if ($status !== null && $status !== '') {

                $query->where('egc_buildings.status', $status);

            }

            /*
            |--------------------------------------------------------------------------
            | Ownership Filter
            |--------------------------------------------------------------------------
            */

            if (!empty($ownership)) {

                $query->where(
                    'egc_buildings.ownership_type',
                    $ownership
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Location Filter
            |--------------------------------------------------------------------------
            */

            if (!empty($location)) {

                $query->where(
                    'egc_buildings.location_id',
                    $location
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Sorting
            |--------------------------------------------------------------------------
            */

            $query->orderBy(
                'egc_buildings.sno',
                'DESC'
            );
                        /*
            |--------------------------------------------------------------------------
            | Dashboard Counts
            |--------------------------------------------------------------------------
            */

            $dashboard = [
                'total' => BuildingModel::count(),

                'active' => BuildingModel::where('status', 1)->count(),

                'inactive' => BuildingModel::where('status', 0)->count(),

                'owned' => BuildingModel::where('ownership_type', 'Owned')->count(),

                'rented' => BuildingModel::where('ownership_type', 'Rented')->count(),
            ];

            /*
            |--------------------------------------------------------------------------
            | Pagination
            |--------------------------------------------------------------------------
            */

            $totalRecords = (clone $query)->count();

            $buildings = $query
                            ->skip(($page - 1) * $perPage)
                            ->take($perPage)
                            ->get();

            /*
            |--------------------------------------------------------------------------
            | Format Table Data
            |--------------------------------------------------------------------------
            */

            $data = [];

            foreach ($buildings as $building) {

                $data[] = [

                    'id'                => $building->sno,

                    'building_code'     => $building->building_code,

                    'building_name'     => $building->building_name,

                    'location'          => $building->location_name,

                    'location_code'     => $building->location_code,

                    'lessor_name'       => $building->lessor_name,

                    'ownership_type'    => $building->ownership_type,

                    'door_no'           => $building->door_no,

                    'street'            => $building->street,

                    'status'            => $building->status,

                    'created_at'        => optional($building->created_at)
                                            ->format('d-m-Y'),

                ];

            }
                    /*
            |--------------------------------------------------------------------------
            | Return AJAX Response
            |--------------------------------------------------------------------------
            */

            return response()->json([

                'status' => true,

                'message' => 'Building list fetched successfully.',

                'dashboard' => $dashboard,

                'pagination' => [

                    'current_page' => (int)$page,

                    'per_page' => (int)$perPage,

                    'total' => $totalRecords,

                    'last_page' => ceil($totalRecords / $perPage),

                ],

                'data' => $data

            ]);

        }

        /*
        |--------------------------------------------------------------------------
        | Initial Page Load
        |--------------------------------------------------------------------------
        */

        $locations = LocationModel::where('status', 0)
                        ->orderBy('area')
                        ->get([
                            'sno',
                            'location_code',
                            'area'
                        ]);

        $lessors = LessorModel::where('status', 0)
                        ->orderBy('lessor_name')
                        ->get([
                            'sno',
                            'lessor_name'
                        ]);

        $ownershipTypes = [

            'Owned',

            'Rented',

            'Lease',

            'Shared'

        ];

        /*
        |--------------------------------------------------------------------------
        | Dashboard Cards
        |--------------------------------------------------------------------------
        */

        $dashboard = [

            'total' => BuildingModel::count(),

            'active' => BuildingModel::where('status',0)->count(),

            'inactive' => BuildingModel::where('status',0)->count(),

            'owned' => BuildingModel::where('ownership_type','Owned')->count(),

            'rented' => BuildingModel::where('ownership_type','Rented')->count(),

        ];

        /*
        |--------------------------------------------------------------------------
        | Return View
        |--------------------------------------------------------------------------
        */

        return view('content.corporate_admin.manage_maintanence.manage_building.building_set',[

            'page_title'       => 'Manage Building',

            'location_list'        => $locations,

            'lessors'          => $lessors,

            'ownershipTypes'   => $ownershipTypes,

            'dashboard'        => $dashboard,

        ]);

    }

    catch (\Exception $e) {
        if(request()->ajax()){

            return response()->json([

                'status' => false,

                'message' => 'Something went wrong.' . $e->getMessage(),

            ],500);

        }

        return back()->with('error','Something went wrong.');

    }

}
    

        public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'building_name'      => 'required|max:200',
            'location_id'        => 'required',
            'ownership_type'     => 'required',
            'door_no'            => 'required|max:100',
            'street'             => 'required|max:255',
            'total_floors'       => 'required|numeric|min:1',
            'builtup_area'       => 'required|numeric|min:1',
            'builtup_area_unit'  => 'required',

        ], [

            'building_name.required'     => 'Building Name is required.',
            'location_id.required'       => 'Location is required.',
            'ownership_type.required'    => 'Ownership is required.',
            'door_no.required'           => 'Door No is required.',
            'street.required'            => 'Street is required.',
            'total_floors.required'      => 'Total Floors is required.',
            'builtup_area.required'      => 'Built-up Area is required.',
            'builtup_area_unit.required' => 'Area Unit is required.',

        ]);

        if ($validator->fails()) {

            return response()->json([
                'status'  => 422,
                'errors'  => $validator->errors()
            ]);

        }

        try {

            DB::beginTransaction();

            /*
            |--------------------------------------------------------------------------
            | Duplicate Check
            |--------------------------------------------------------------------------
            */

            $exists = BuildingModel::where('building_name', $request->building_name)
                        ->where('location_id', $request->location_id)
                        ->where('status','!=',2)
                        ->exists();

            if($exists){

                return response()->json([
                    'status'=>409,
                    'message'=>'Building already exists.'
                ]);

            }

            /*
            |--------------------------------------------------------------------------
            | Generate Building Code
            |--------------------------------------------------------------------------
            */

            $location = LocationModel::find($request->location_id);

            $prefix = 'BLD';

            if($location){

                $locationCode = $location->location_code;

                $last = BuildingModel::where('location_id',$request->location_id)
                            ->orderBy('sno','DESC')
                            ->first();

                if($last){

                    $lastCode = explode('-',$last->building_code);

                    $running = intval(end($lastCode)) + 1;

                }else{

                    $running = 1;

                }

                $buildingCode = $prefix.'-'.$locationCode.'-'.str_pad($running,4,'0',STR_PAD_LEFT);

            }else{

                $buildingCode = 'BLD-0001';

            }

            /*
            |--------------------------------------------------------------------------
            | Save Building
            |--------------------------------------------------------------------------
            */

            $building = new BuildingModel();

            $building->building_code       = $buildingCode;
            $building->building_name       = $request->building_name;
            $building->location_id         = $request->location_id;
            $building->ownership_type      = $request->ownership_type;
            $building->lessor_id           = $request->lessor_id;
            $building->door_no             = $request->door_no;
            $building->street              = $request->street;
            $building->landmark            = $request->landmark;
            $building->google_map_link     = $request->google_map_link;
            $building->address             = trim(
                                                $request->door_no.', '.
                                                $request->street.', '.
                                                $request->landmark
                                            );
            $building->total_floors        = $request->total_floors;
            $building->builtup_area        = $request->builtup_area;
            $building->builtup_area_unit   = $request->builtup_area_unit;
            $building->latitude            = $request->latitude;
            $building->longitude           = $request->longitude;
            $building->remarks             = $request->remarks;
            $building->created_by          = session('user_id') ?? 0;
            $building->updated_by          = session('user_id') ?? 0;
            $building->status              = 0;

            $building->save();

            DB::commit();

            return response()->json([

                'status'  => 200,
                'message' => 'Building added successfully.'

            ]);

        }
        catch(\Exception $e){

            DB::rollBack();

            return response()->json([

                'status'  => 500,
                'message' => 'Something went wrong.',
                'error'   => $e->getMessage()

            ]);

        }

    }


    public function SaveFloor(Request $request)
    {
        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | Validation
            |--------------------------------------------------------------------------
            */

            $validator = Validator::make($request->all(), [

                'building_id'       => 'required|exists:egc_building,sno',

                'floor_no'          => 'required|max:50',

                'floor_name'        => 'nullable|max:150',

                'purpose'           => 'required|max:100',

                'entity_id'         => 'required',

                'branch_id'         => 'required',

                'floor_area'        => 'nullable|numeric',

                'area_unit'         => 'nullable|max:20',

                'occupancy_status'  => 'nullable',

                'workstations'      => 'nullable|integer',

                'meeting_rooms'     => 'nullable|integer',

                'cabins'            => 'nullable|integer',

                'remarks'           => 'nullable|max:1000',

            ]);

            if ($validator->fails()) {

                return response()->json([
                    'status' => false,
                    'errors' => $validator->errors()
                ]);

            }

            /*
            |--------------------------------------------------------------------------
            | Duplicate Check
            |--------------------------------------------------------------------------
            */

            $exists = BuildingFloor::where('building_id', $request->building_id)
                        ->where('floor_no', $request->floor_no)
                        ->exists();

            if ($exists) {

                return response()->json([
                    'status' => false,
                    'message' => 'Floor already exists for this building.'
                ]);

            }

            /*
            |--------------------------------------------------------------------------
            | Save Floor
            |--------------------------------------------------------------------------
            */

            $floor = new BuildingFloor();

            $floor->building_id = $request->building_id;

            $floor->floor_no = trim($request->floor_no);

            $floor->floor_name = trim($request->floor_name);

            $floor->purpose = $request->purpose;

            $floor->entity_id = $request->entity_id;

            $floor->branch_id = $request->branch_id;

            $floor->floor_area = $request->floor_area;

            $floor->area_unit = $request->area_unit;

            $floor->occupancy_status = $request->occupancy_status;

            $floor->workstations = $request->workstations ?? 0;

            $floor->meeting_rooms = $request->meeting_rooms ?? 0;

            $floor->cabins = $request->cabins ?? 0;

            $floor->remarks = $request->remarks;

            $floor->status = 1;

            $floor->created_by = session('admin_id'); // change based on your auth

            $floor->save();

            DB::commit();

            return response()->json([

                'status' => true,

                'message' => 'Floor added successfully.'

            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            Log::error(__METHOD__, [

                'message' => $e->getMessage(),

                'line' => $e->getLine(),

                'file' => $e->getFile(),

            ]);

            return response()->json([

                'status' => false,

                'message' => 'Something went wrong.'

            ], 500);

        }
    }


    public function RenewalList($buildingId)
{
    try {

        $renewals = BuildingRenewal::select(
                        'egc_building_renewal.*',
                        'egc_building_floor.floor_no'
                    )
                    ->leftJoin(
                        'egc_building_floor',
                        'egc_building_floor.sno',
                        '=',
                        'egc_building_renewal.floor_id'
                    )
                    ->where(
                        'egc_building_renewal.building_id',
                        $buildingId
                    )
                    ->orderByDesc('egc_building_renewal.sno')
                    ->get();

        $data = [];

        foreach ($renewals as $row) {

            $data[] = [

                'id'             => $row->sno,

                'floor'          => $row->floor_no,

                'agreement_name' => $row->agreement_name,

                'start_date'     => optional($row->start_date)->format('d-M-Y'),

                'end_date'       => optional($row->end_date)->format('d-M-Y'),

                'renewal_date'   => optional($row->renewal_date)->format('d-M-Y'),

                'amount'         => number_format($row->amount,2),

                'status'         => $row->status

            ];

        }

        return response()->json([

            'status'=>true,

            'data'=>$data

        ]);

    } catch (\Exception $e) {

        return response()->json([

            'status'=>false,

            'message'=>'Unable to load renewals.'

        ]);

    }
}




public function AgreementList($buildingId)
{
    try {

        $agreements = DB::table('egc_building_agreements as ba')
            ->leftJoin(
                'egc_building_floors as bf',
                'bf.sno',
                '=',
                'ba.floor_id'
            )
            ->select(
                'ba.sno',
                'ba.agreement_name',
                'ba.agreement_no',
                'ba.agreement_start_date',
                'ba.agreement_end_date',
                'ba.renewal_date',
                'ba.agreement_amount',
                'ba.agreement_status',
                'bf.floor_no'
            )
            ->where('ba.building_id', $buildingId)
            ->where('ba.status', 0)
            ->orderByDesc('ba.sno')
            ->get();

        $data = [];

        foreach ($agreements as $row) {

            $daysRemaining = null;

            if (!empty($row->agreement_end_date)) {

                $daysRemaining = now()->diffInDays(
                    $row->agreement_end_date,
                    false
                );

            }

            $data[] = [

                'id' => $row->sno,

                'floor' => $row->floor_no ?? '-',

                'agreement_name' => $row->agreement_name,

                'agreement_no' => $row->agreement_no,

                'start_date' => $row->agreement_start_date
                    ? date('d-M-Y', strtotime($row->agreement_start_date))
                    : '-',

                'end_date' => $row->agreement_end_date
                    ? date('d-M-Y', strtotime($row->agreement_end_date))
                    : '-',

                'renewal_date' => $row->renewal_date
                    ? date('d-M-Y', strtotime($row->renewal_date))
                    : '-',

                'amount' => number_format($row->agreement_amount,2),

                'status' => $row->agreement_status,

                'days_remaining' => $daysRemaining

            ];

        }

        return response()->json([

            'status' => true,

            'count' => count($data),

            'data' => $data

        ]);

    } catch (\Exception $e) {

        return response()->json([

            'status' => false,

            'message' => $e->getMessage()

        ]);

    }
}


public function BuildingDetails($id)
{
    try {

        $building = BuildingModel::select(
                'egc_buildings.*',
                'egc_lessor.lessor_name',
                'egc_lessor.lessor_code',
                'egc_lessor.mobile_no as lessor_mobile',
                'egc_lessor.contact_person',
            )
            ->leftJoin('egc_lessor', 'egc_lessor.sno', '=', 'egc_buildings.lessor_id')
            ->where('egc_buildings.sno', $id)
            ->first();
     

        if (!$building) {

            return response()->json([
                'status'  => false,
                'message' => 'Building not found.'
            ]);

        }

        /*
        |--------------------------------------------------------------------------
        | Statistics
        |--------------------------------------------------------------------------
        */

        $totalFloors = DB::table('egc_building_floors')
                        ->where('building_id', $id)
                        ->count();

        $occupiedFloors = DB::table('egc_building_floors')
                        ->where('building_id', $id)
                        ->where('occupancy_status', 1)
                        ->count();

        /*
        |--------------------------------------------------------------------------
        | Amenities
        |--------------------------------------------------------------------------
        */

        $amenities = DB::table('egc_building_amenities')
                        ->where('building_id', $id)
                        ->pluck('amenity_name')
                        ->toArray();

        /*
        |--------------------------------------------------------------------------
        | Response
        |--------------------------------------------------------------------------
        */

        $data = [

            'id' => $building->sno,

            'building_name' => $building->building_name,

            'building_code' => $building->building_code,

            'ownership_type' => $building->ownership_type,

            'status' => $building->status,

            'address' => trim($building->address),

            'location_name' => $building->city,

            'builtup_area' => round($building->builtup_area,1),

            'area_unit' => $building->builtup_area_unit,

            'entity_name' => '',

            'branch_name' => '',

            'lessor_name' => $building->lessor_name,

            'lessor_code' => $building->lessor_code,

            'lessor_mobile' => $building->lessor_mobile,

            'contact_person' => $building->contact_person,

            'total_floors' => $totalFloors,

            'occupied' => $occupiedFloors,

            'vacant' => $totalFloors - $occupiedFloors,

            'amenities' => $amenities

        ];

        return response()->json([

            'status' => true,

            'data' => $data

        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([

            'status' => false,

            'message' => $e->getMessage()

        ], 500);

    }
}



public function FloorList($buildingId)
{
    try {

        $floors = DB::table('egc_building_floors as bf')
            ->select(
                'bf.sno',
                'bf.floor_no',
                'bf.floor_name',
                'bf.purpose',
                'bf.floor_area',
                'bf.area_unit',
                'bf.occupancy_status',
                'bf.workstations',
                'bf.meeting_rooms',
                'bf.cabins',
                'bf.status',
            )
            ->where('bf.building_id', $buildingId)
            ->orderBy('bf.sno')
            ->get();

        $data = [];

        foreach ($floors as $floor) {

            $data[] = [

                'id' => $floor->sno,

                'floor_no' => $floor->floor_no,

                'floor_name' => $floor->floor_name,

                'purpose' => $floor->purpose,

                'entity' =>  '-',

                'branch' =>  '-',

                'area' => $floor->floor_area,

                'unit' => $floor->area_unit,

                'occupancy_status' => $floor->occupancy_status,

                'workstations' => $floor->workstations,

                'meeting_rooms' => $floor->meeting_rooms,

                'cabins' => $floor->cabins,

                'status' => $floor->status

            ];

        }

        return response()->json([

            'status' => true,

            'count' => count($data),

            'data' => $data

        ]);

    } catch (\Exception $e) {

        return response()->json([

            'status' => false,

            'message' => $e->getMessage()

        ], 500);

    }
}
}   