<?php

namespace App\Http\Controllers\EmployeeApp;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Laravel\Passport\HasApiTokens;
use App\Models\OtpModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\SmsTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\StaffModel;
use App\Models\StaffAttendanceModel;
use App\Models\AttendanceLogModel;
use Illuminate\Support\Facades\Config;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Laravel\Sanctum\PersonalAccessToken;
use Illuminate\Support\Str;
use App\Models\NotificationMobileModel;
use App\Traits\NotifiableTrait;
use App\Models\HolidayModel;
use App\Models\LeavePermissionModel;
use App\Models\LeaveApprovalModel;
use App\Models\ApprovalHierarchyModel;
use App\Models\LeaveReasonModel;
use App\Models\PermissionReasonModel;
use App\Models\TrainingPlannerModel;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Log;

/**
 * @OA\Info(
 *   title="Employee App API",
 *   version="1.0.0",
 *   description="API documentation for Employee App"
 * )
 *
 * @OA\Server(
 *   url="https://dev.elysium.community/api",
 *   description="Dev API Server"
 * )
 *
 * @OA\Tag(
 *   name="Employee",
 *   description="Employee related APIs"
 * )
 */
class EmployeeAppController extends Controller
{
     use NotifiableTrait;
/**
     * @OA\Post(
     *     path="/employee_login",
     *     summary="Employee login",
     *     tags={"Employee"},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"mobile_no",},
     *             @OA\Property(property="mobile_no", type="string", example="9089788990"),
     *             @OA\Property(property="device_id", type="string", example="device123"),
     *             @OA\Property(property="latitude", type="string", example="12.9716"),
     *             @OA\Property(property="longitude", type="string", example="77.5946")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="OTP Sent Successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="OTP Sent Successfully"),
     *             @OA\Property(property="otp", type="string")
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation Error"
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="User inactive or deactivated"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Invalid credentials or user not found"
     *     )
     * )
     */

  public function EmployeeLogin(Request $request)
  {

    $user_name = $request->user_name;
    $mobile_no = $request->mobile_no;
    $password      = $request->password ? $request->password : 'null';
    $remember = $request->remember;
    $device_id = $request->device_id;
    $latitude = $request->latitude;
    $longitude = $request->longitude;

    $validator = Validator::make($request->all(), [
      'mobile_no' => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
    } else {
        $user = StaffModel::where('mobile_no', $mobile_no)->where('status', 0)->first();

        if (!$user) {
            DB::table('mobile_user_login_logs')->insert([
                'user_id'    => 0,        
                'login_at'   => Carbon::now('Asia/Kolkata'),
                'ip_address' => $request->ip(),
                'user_agent' => $request->header('User-Agent'),
                'mobile_no'  => $mobile_no,
                'latitude'   => $latitude,
                'longitude'   => $longitude,
                'device_id'   => $device_id,
                'type'       => 1, // failed
                'created_at' => Carbon::now('Asia/Kolkata'),
                'updated_at' => Carbon::now('Asia/Kolkata'),
            ]);
            return response()->json([
                'status' => 500,
                'message' => 'User not found.',
                'error_msg'=>'User not found.',
                'data' => NULL
            ]);
        }


        if( $mobile_no == "7358120388"){
            $otp_value  = 123456; // Random 6-digit OTP
        }else{
            $otp_value  = rand(100000, 999999); // Random 6-digit OTP
        } // Random 6-digit OTP

        // Save OTP to Database
        
        $otp = new OtpModel();

        $otp->user_id                  = $user->sno;
        $otp->mobile_no                =  $mobile_no;
        $otp->otp_number               = $otp_value;
        $otp->created_by               = $user->sno;
        $otp->updated_by               = $user->sno;
        $otp->save();

        // sms otp 
        if( $mobile_no != "7358120388"){
            if ($otp_value) {

                $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                $authkey         = $result_sms ? $result_sms->authkey : '';
                $sender_id       = $result_sms ? $result_sms->sender_id : '';
                $template_id     = $result_sms ? $result_sms->template_id : '';
                $country_code    = $result_sms ? $result_sms->country_code : '';
                $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                $mobile_number   = $country_code . $mobile_no;
                

                $app_name = "EGC Employee App";
                // $app_link = 'https://elysiumacademy.org/';
                $app_code = "8dc%2BJrcYXcg";
                // Replace placeholders with actual values
                $replacement_values = [$user->cus_name, $app_name, $otp_value,$app_code];
                $message_content    = preg_replace_callback(
                    '/\{#var#\}/',
                    function () use (&$replacement_values) {
                        return array_shift($replacement_values);
                    },
                    $message_content
                );

                $route    = "default";
                $postData = [
                    'authkey' => $authkey,
                    'mobiles' => $mobile_number,
                    'message' => $message_content,
                    'sender'  => $sender_id,
                    'route'   => $route,
                ];

                // API URL
                $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                // return $url;
                // Initialize the resource
                $ch = curl_init();
                curl_setopt_array($ch, [
                    CURLOPT_URL            => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $postData,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_SSL_VERIFYPEER => 0,
                ]);
                

                // Get response
                $response = curl_exec($ch);
                
                $err = curl_error($ch);
                curl_close($ch);
            }
        }

        return response()->json([
            'status' => 200,
            'message' => 'OTP Sent Successfully',
            'error_msg'=>NULL,
            'otp'      => $otp_value,
            'staff_id'   => $user->sno,
            'staff_name'   => $user->staff_name,
            'mobile_no'   => $mobile_no,
        ], 200);

    }
  }


    /**
     * @OA\Post(
     *     path="/verify_otp_staff",
     *     summary="Verify OTP",
     *     tags={"Employee"},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"mobile_no","otp"},
     *             @OA\Property(property="mobile_no", type="string", example="9089788990"),
     *             @OA\Property(property="otp", type="string", example="765645")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Logged in Successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Logged in Successfully"),
     *             @OA\Property(property="otp", type="string")
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation Error"
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="User inactive or deactivated"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Invalid credentials or user not found"
     *     )
     * )
     */

  public function verifyOtp(Request $request)
  {

    $validator = Validator::make($request->all(), [
        'mobile_no' => 'required',
        'otp'       => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
    } else {
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
         $device_id = $request->device_id;
        $latitude = $request->latitude;
        $longitude = $request->longitude;

        $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                    ->latest()
                    ->first();
        if (!$otpRecord) {
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }

        $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        $expiryTime = $createdAt->copy()->addMinutes(2);
        $currentTime = Carbon::now('UTC');
    
        if ($currentTime->greaterThan($expiryTime)) {
            return response()->json([
                'status'  => false,
                'message' => 'OTP expired. Please request a new one.'
            ], 410);
        }


        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }

        $staff_id = $otpRecord->user_id;

        $user = StaffModel::select('egc_staff.*')
            ->where('egc_staff.sno', $staff_id)
            ->where('egc_staff.status', 0)
            ->first();

        if ($user->status == 1) {
            return response()->json([
                'status' => 403,
                'message' => 'This user is inactive. Please contact the administrator.',
                'error_msg'=>'This user is inactive. Please contact the administrator.',
                'data' => NULL
            ]);
        } elseif ($user->status > 1) {
            return response()->json([
                'status' => 403,
                'message' => 'This user is deactivated. Please contact the administrator.',
                'error_msg'=>'This user is deactivated. Please contact the administrator.',
                'data' => NULL
            ]);
        }


        $secret_key = env('JWT_SECRET', 'EGC_EMPLOYEE_SUPERAPP_2026'); // Add JWT_SECRET in .env
        $issuer_claim = "Employee App"; // this can be your app name
        $audience_claim = "mobile-app";
        $issued_at = time();
        // $expiry_time = $issued_at + (60*60*168); // 7 day expiry, 
        $expiry_time = $issued_at + (60 * 60 * 24 * 365 * 10);

        $payload = [
            "iss" => $issuer_claim,
            "aud" => $audience_claim,
            "iat" => $issued_at,
            "exp" => $expiry_time,
            "staff_sno" => $staff_id
        ];


        $jwt_token = JWT::encode($payload, $secret_key, 'HS256');

        $token = new PersonalAccessToken();
        $token->forceFill([
            'tokenable_type' => \App\Models\StaffModel::class,
            'tokenable_id'   => $staff_id,
            'name'           => 'jwt_token',
            'token'          => hash('sha256', $jwt_token),
            'abilities'      => ['*'],
            'expires_at'     => Carbon::createFromTimestamp($expiry_time),
        ])->save();
            
        DB::table('mobile_user_login_logs')->insert([
            'user_id'    => $user->sno,
            'login_at'   => Carbon::now('Asia/Kolkata'),
            'ip_address' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'mobile_no'  => $mobile_no,
            'otp'  => $otpInput,
            'latitude'   => $latitude,
            'longitude'   => $longitude,
            'device_id'   => $device_id,
            'type'       => 0, // success
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);


        $this->sendNotification(
                    $user->branch_id,
                    $user->sno,
                    "Logged in Successfully",
                    "Employee App",
                    $user->sno
                );

         return response()->json([
                'status' => 200,
                'message' => 'Logged in Successfully',
                'error_msg'=>NULL,
                'user_id' => $otpRecord->user_id,
                'token' => $jwt_token,
                'expires_at' => date('Y-m-d H:i:s', $expiry_time),
            ], 200);
    }
  }


   /**
 * @OA\Get(
 *     path="/get_staff_data",
 *     summary="Get staff data",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *     @OA\Response(
 *         response=200,
 *         description="Staff data fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=200),
 *             @OA\Property(property="message", type="string", example="Staff data fetched successfully"),
 *             @OA\Property(property="data", type="object")
 *         )
 *     ),
 *     @OA\Response(
 *         response=401,
 *         description="Token missing or invalid",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=401),
 *             @OA\Property(property="message", type="string", example="Token invalid or expired")
 *         )
 *     )
 * )
 */


  public function getStaffData(Request $request)
{
  
    $user = $request->user();
    $staff = StaffModel::where('sno', $user->sno)->first();

    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Staff not found',
            'data' => null
        ]);
    }

        $data =  StaffModel::where('egc_staff.status', '!=', 2)
        ->select('egc_staff.*',
        'egc_entity.entity_name',
        'egc_entity.entity_short_name',
        'egc_company.company_name',
        'egc_company.company_base_color',
        'egc_department.department_name',
        'egc_division.division_name',
        'egc_user_role.role_name',
        'egc_languages.name as mother_tongue',
        'egc_job_role.job_position_name as job_role_name',
        )
        ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
        ->leftJoin('egc_user_role', 'egc_staff.role_id', 'egc_user_role.sno')
        ->leftJoin('egc_languages', 'egc_staff.mother_tongue', 'egc_languages.sno')
        ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
        ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
        ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
        ->where('egc_staff.sno', $user->sno)
        ->first();
        $languages_ids=$data->languages ? json_decode($data->languages):[];
        $hobby_ids=$data->hobby ? json_decode($data->hobby):[];
        $language_known=DB::table('egc_languages')->whereIn('sno',$languages_ids)->pluck('name');
        $hobbies=DB::table('egc_hobbies')->whereIn('sno',$hobby_ids)->pluck('hobby_name');
        $staff_family=DB::table('egc_staff_family')->where('staff_id',$user->sno)->where('status','!=',2)->first();
        $data->language_known=$language_known;
        $data->hobbies=$hobbies;
        // family details
        $data->father_name=$staff_family? $staff_family->father_name :'';
        $data->father_occup=$staff_family? $staff_family->father_occup :'';
        $data->mother_name=$staff_family? $staff_family->mother_name :'';
        $data->mother_occup=$staff_family? $staff_family->mother_occup :'';
        $data->has_children=$staff_family? $staff_family->has_children :'';
        $data->children_count=$staff_family? $staff_family->children_count :'';
        $data->has_siblings=$staff_family? $staff_family->has_siblings :'';

        $data->contact_person_name = $data->contact_person_name ? json_decode($data->contact_person_name) : [];
        $data->contact_person_no = $data->contact_person_no ? json_decode($data->contact_person_no) : [];
        $contact_person_relation_ids = $data->contact_person_relation ? json_decode($data->contact_person_relation) : [];
        $relation=DB::table('egc_relationship_type')->whereIn('sno',$contact_person_relation_ids)->pluck('relationship_name');
        $data->relationship=$relation;

        $work_details = DB::table('egc_staff_work_info')
            ->select('egc_staff_work_info.*')
            ->where('egc_staff_work_info.staff_id',$user->sno)
            ->where('egc_staff_work_info.status', '!=', 2)
            ->orderBy('egc_staff_work_info.sno','asc')
            ->get();
        
        $data->work_details =$work_details;
        $data->job_level = 'L1';

        $documents = DB::table('egc_staff_attachment')
            ->where('egc_staff_attachment.staff_id',$user->sno)
            ->select('egc_staff_attachment.*','egc_documents.document_name')
            ->where('egc_staff_attachment.status', '!=', 2)
            ->join('egc_documents', 'egc_staff_attachment.document_id', '=', 'egc_documents.sno')
            ->get();
            $documentData = [];

        foreach ($documents as $doc) {
            $fileNames = json_decode($doc->attachment_name); // Decode the JSON file names
            $documentData[] = [
                'document_name' => $doc->document_name,
                'files' => array_map(function($fileName) use ($doc) {
                    return asset("staff_attachments/{$doc->staff_id}/{$doc->document_id}/{$fileName}");
                }, $fileNames)
            ];
        }

        $qualification = DB::table('egc_staff_education_info')
            ->select('egc_staff_education_info.*','egc_qualification_level.qualification_level_name as qualification_name','egc_major.major_name')
            ->where('egc_staff_education_info.status', '!=', 2)
            ->where('egc_staff_education_info.staff_id', $user->sno)
            // ->join('egc_education', 'egc_staff_education_info.qualification_type', '=', 'egc_education.sno')
            ->join('egc_qualification_level', 'egc_staff_education_info.qualification_type', '=', 'egc_qualification_level.sno')
            ->leftJoin('egc_major', 'egc_staff_education_info.major', '=', 'egc_major.sno')
            ->get();

            $document_checkList = DB::table('egc_document_checklist')
            ->select('egc_document_checklist.*')
            ->where('egc_document_checklist.status', '!=', 2)
            ->get();
            $document_checklist_snos = $data->document_checklist ? json_decode($data->document_checklist) : [];

            foreach ($document_checkList as $document) {
                if (in_array($document->sno, $document_checklist_snos)) {
                    $document->is_checked = 1;
                } else {
                    $document->is_checked = 0;
                }
            }
            $data->documents =$documentData;
            $data->qualification =$qualification;
            $data->document_checkList =$document_checkList;

            if ($data->gender == 1) {
                $defaultPath = asset('assets/egc_images/auth/user_2.png');
            } else {
                $defaultPath = asset('assets/egc_images/auth/user_7.png');
            }
            if ($data->company_type == 1) {
                $relativePath = 'staff_images/Management/' . $data->staff_image;
            } else {
                $relativePath = 'staff_images/Buisness/' . $data->company_id . '/' . $data->entity_id . '/' . $data->staff_image;
            }
            //  Correct physical path
            $fullPath = public_path($relativePath);
            //  Correct URL
            $filePath = asset($relativePath);
            //  Proper check
            $isStaffImage = ($data->staff_image && file_exists($fullPath)) ? 1 : 0;

        $staffImageUrl = $isStaffImage ? $filePath : $defaultPath;
        
        $staffData =[
            "id"=>$data->sno,
            "employee_id"=>$data->staff_id,
            "staff_name"=>$data->staff_name,
            "nick_name"=>$data->nick_name ?? '',
            "staff_image"=>$staffImageUrl ?? '',
            "date_of_birth"=>$data->dob ? date('d-M-Y',strtotime($data->dob)) : '',
            "date_of_joining"=>$data->date_of_joining ? date('d-M-Y',strtotime($data->date_of_joining)) : '',
            "mobile_no"=>$data->mobile_no ?? '',
            "email_id"=>$data->email_id ?? '',
            "department_name"=>$data->department_name ?? '',
            "division_name"=>$data->division_name ?? '',
            "level"=>$data->job_level ?? 'L1',
            "job_role_name"=>$data->job_role_name ?? '',
            "document_verified"=> 0,
            "document_pending"=> 0,
            "contacts"=> 0,
            "reporting_staff"=> '',
            "blood_group"=> '',
            
        ];

    return response()->json([
        'status' => 200,
        'message' => 'Staff data fetched successfully',
        'error_msg' => null,
        'data' => $staffData
    ]);
}


 /**
     * @OA\Get(
     *     path="/get_staff_today_check_in",
     *     summary="Get staff Today Check Data",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Today Check-in Data",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Today Check-in Data"),
     *             @OA\Property(property="data", type="object")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Token missing or invalid",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Token invalid or expired")
     *         )
     *     )
     * )
     */

public function getTodayCheckIN(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->sno)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $face_id_check = $staff->face_id ? true : false;

        $date = now()->toDateString();

        $today_checks = StaffAttendanceModel::where('status', '!=', 2)
            ->where('date', $date)
            ->where('staff_id', $user->sno)
            ->latest('sno')
            ->first();

        $today_checkIn = (int) optional($today_checks)->checkin_verified;
        $today_checkOut = (int) optional($today_checks)->checkout_verified;

        $checkIn_time = $today_checkIn ? $today_checks->check_in_time : '';
        $checkOut_time = $today_checkOut ? $today_checks->check_out_time : '';

         $shiftLog = DB::table('egc_shift_time_log')
            ->where('staff_id', $user->sno)
            ->whereDate('start_date', '<=', $date)
            ->where(function ($q) use ($date) {
                $q->whereNull('end_date')
                ->orWhereDate('end_date', '>=', $date);
            })
            ->latest('sno')
            ->first();

           

            $dayName = strtolower(now()->format('D'));

            if($shiftLog){
                
                $shiftTime = DB::table('egc_shift_day_times')
                    ->where('shift_id', $shiftLog->change_shift_id)
                    ->whereRaw('LOWER(day_name) = ?', [$dayName])
                    ->where('status', 0)
                    ->first();
                 $shiftIntime = $shiftTime->time_from ?? '09:00:00';
                $shiftOuttime = $shiftTime->time_to ?? '18:00:00';
            }else{
                 $shiftIntime = '09:00:00';
                $shiftOuttime =  '18:00:00';
            }

        return response()->json([
            'status' => 200,
            'message' => 'Today Check-in Data',
            'data' => [
                "date" => $date,
                "today_check_in" => $today_checkIn,
                "today_check_out" => $today_checkOut,
                "check_in_time" => $checkIn_time,
                "check_out_time" => $checkOut_time,
                "shift_intime" => $shiftIntime,
                "shift_outtime" => $shiftOuttime,
                "face_id_check" => $face_id_check,
            ]
        ]);
    }

    
    /**
     * @OA\Get(
     *     path="/get_staff_face_id",
     *     summary="Get staff Face Id",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Get Face Id SuccessFully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Get Face Id SuccessFully"),
     *             @OA\Property(property="data", type="object")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Token missing or invalid",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Token invalid or expired")
     *         )
     *     )
     * )
     */

public function getStaffFaceId(Request $request)
    {
        $user = $request->user();
        $staff = StaffModel::where('status', '!=', 2)
            ->where('sno', $user->sno)
            ->first();

        // $defaultFaceId =  [-0.006812307983636856, 0.031957145780324936, 0.01114064920693636, 0.004786323290318251, -0.046853311359882355, 0.08809966593980789, -0.08970628678798676, -0.1628168523311615, -0.04266291856765747, 0.1220361590385437, -0.017565619200468063, 0.013139070011675358, -0.005291406996548176, 0.021069513633847237, -0.002145678037777543, -0.0014305065851658583, -0.02788355201482773, -0.014002140611410141, -0.002830462297424674, 0.0012957878643646836, -0.025508036836981773, 0.08548711985349655, 0.013177970424294472, 0.010322692804038525, -0.038645029067993164, 0.018841495737433434, -0.042264144867658615, 0.03340059146285057, 0.060951560735702515, 0.0778016597032547, -0.017882272601127625, 0.23416773974895477, -0.04661112651228905, 0.001699536689557135, -0.1506941318511963, 0.12023527920246124, 0.19726814329624176, -0.026423998177051544, -0.000010575400665402412, 0.010266436263918877, 0.006171199027448893, 0.002294901292771101, 0.016793731600046158, -0.007449257653206587, -0.001560805831104517, -0.08001046627759933];

        // $staff->face_id = json_encode($defaultFaceId);
        // $staff->update();

        if (!$staff) {
            return response()->json([
                'status' => 401,
                'message' => 'Unauthorized'
            ], 401);
        }
        if(!$staff->face_id){
             return response()->json([
                'status' => 401,
                'message' => 'Face Id Not Found'
            ], 401);
        }

        return response()->json([
            'status' => 200,
            'message' => 'Get Face Id SuccessFully',
            'data' => [
                "face_id" => is_array($staff->face_id)
                    ? $staff->face_id
                    : json_decode($staff->face_id, true),
            ]
        ]);
    }

     /**
     * @OA\Post(
     *     path="/verify_checkin_location",
     *     summary="Verify Employee Check-in Location",
     *     description="Validates whether the employee is within the allowed office radius using latitude and longitude.",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"date","latitude","longitude"},
     *             @OA\Property(property="date", type="string", format="date", example="2026-05-05"),
     *             @OA\Property(property="latitude", type="number", format="float", example=12.9716),
     *             @OA\Property(property="longitude", type="number", format="float", example=77.5946)
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Location verified successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Location Verified Successfully"),
     *             @OA\Property(property="distance", type="number", example=25.45)
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="User not within allowed radius",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=403),
     *             @OA\Property(property="message", type="string", example="You are not within office location"),
     *             @OA\Property(property="distance", type="string", example="150.25 meters")
     *         )
     *     ),
     *     @OA\Response(
     *         response=409,
     *         description="Already checked in",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=409),
     *             @OA\Property(property="message", type="string", example="Already checked in")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation Error"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Server Error (Office location not configured)"
     *     )
     * )
     */




    public function verifyCheckinLocation(Request $request)
    {
        $request->validate([
            'latitude'  => 'required',
            'longitude' => 'required',
            'date'      => 'required'
        ]);

        $user = $request->user();

        if (!$user) {
            return response()->json([
                'status' => 401,
                'message' => 'Unauthorized'
            ], 401);
        }

        $userLat = (float) $request->latitude;
        $userLng = (float) $request->longitude;

        $helper = new \App\Helpers\Helpers();
        $general_setting = $helper->general_setting_data();

        if (!$general_setting || !$general_setting->latitude || !$general_setting->longitude) {
            return response()->json([
                'status' => 500,
                'message' => 'Office location not configured'
            ], 500);
        }

        $officeLat = (float) $general_setting->latitude;
        $officeLng = (float) $general_setting->longitude;

        //  Calculate distance
        $distance = $this->calculateDistance($userLat, $userLng, $officeLat, $officeLng);

        //  Allow within 100 meters (you can move to config)
        $allowedRadius = 100;

        if ($distance > $allowedRadius) {
            return response()->json([
                'status' => 403,
                'message' => 'You are not within office location',
                'distance' => round($distance, 2) . ' meters'
            ], 403);
        }

        // 🔒 Prevent duplicate check-in
        $exists = StaffAttendanceModel::where('staff_id', $user->sno)
            ->whereDate('date', $request->date)
            ->where('checkin_verified', 1)
            ->exists();

        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'Already checked in'
            ], 409);
        }

        return response()->json([
            'status' => 200,
            'message' => 'Location Verified Successfully',
            'distance' => round($distance, 2)
        ]);
    }

    private function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371000; // meters

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat / 2) * sin($dLat / 2) +
            cos(deg2rad($lat1)) *
            cos(deg2rad($lat2)) *
            sin($dLon / 2) * sin($dLon / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c; // distance in meters
    }

    /**
     * @OA\Post(
     *     path="/confirm_checkin",
     *     summary="Confirm Employee Check-in",
     *     description="Final step of attendance. Verifies face ID and stores check-in time and location.",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"face_id","date","latitude","longitude"},
     *             @OA\Property(property="face_id", type="string", example="FACE123456"),
     *             @OA\Property(property="date", type="string", format="date", example="2026-05-05"),
     *             @OA\Property(property="latitude", type="number", format="float", example=12.9716),
     *             @OA\Property(property="longitude", type="number", format="float", example=77.5946)
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Check-in successful",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Check-in successful"),
     *             @OA\Property(
     *                 property="data",
     *                 type="object",
     *                 @OA\Property(property="check_in_time", type="string", example="2026-05-05 10:35:22"),
     *                 @OA\Property(property="date", type="string", example="2026-05-05")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Face verification failed",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=403),
     *             @OA\Property(property="message", type="string", example="Face verification failed")
     *         )
     *     ),
     *     @OA\Response(
     *         response=409,
     *         description="Already checked in",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=409),
     *             @OA\Property(property="message", type="string", example="Already checked in")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation Error"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */
    public function confirmCheckin(Request $request)
    {
        $request->validate([
            'face_id'   => 'required',
            'date'      => 'required|date',
            'latitude'  => 'required',
            'longitude' => 'required',
        ]);

        $user = $request->user();

        // //  1. Validate Face ID (basic check)
        // $staff = StaffModel::where('sno', $user->sno)
        //     ->where('face_id', $request->face_id)
        //     ->first();

        // if (!$staff) {
        //     return response()->json([
        //         'status' => 403,
        //         'message' => 'Face verification failed'
        //     ]);
        // }

        //  2. Prevent duplicate check-in
        $alreadyChecked = StaffAttendanceModel::where('staff_id', $user->sno)
            ->where('date', $request->date)
            ->where('checkin_verified', 1)
            ->exists();

        if ($alreadyChecked) {
            return response()->json([
                'status' => 409,
                'message' => 'Already checked in'
            ]);
        }

        //  3. Save Check-in
        $attendance = StaffAttendanceModel::updateOrCreate(
            [
                'staff_id' => $user->sno,
                'status' => 0,
                'date'     => $request->date
            ],
            [
                'attendance'=>'P',
                'checkin_verified'     => 1,
                'check_in_time'        =>Carbon::now('Asia/Kolkata')->format('H:i:s'),
                'check_in_latitude'    => $request->latitude,
                'check_in_longitude'   => $request->longitude,
                'updated_at'           => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s')
            ]
        );


        AttendanceLogModel::create([
            'staff_id' => $user->sno,
            'type' => 'checkin',
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'face_id' => $request->face_id,
            'created_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s')
        ]);

        $this->sendNotification(
                    $user->branch_id,
                    $user->sno,
                    "Check-in Successfully",
                    "Employee App",
                    $user->sno
                );

        return response()->json([
            'status' => 200,
            'message' => 'Check-in successful',
        ]);
    }


     /**
     * @OA\Get(
     *     path="/staff_notification_list",
     *     summary="Get Staff Notification List",
     *     description="Fetch all unread notifications for logged-in staff",
     *     operationId="staffNotificationList",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Response(
     *         response=200,
     *         description="Notification list fetched successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Notification list fetched successfully"),
     *
     *             @OA\Property(
     *                 property="data",
     *                 type="array",
     *
     *                 @OA\Items(
     *                     type="object",
     *
     *                     @OA\Property(property="id", type="integer", example=1),
     *                     @OA\Property(property="message", type="string", example="Check-in successfully"),
     *                     @OA\Property(property="notification_date", type="string", example="2026-05-11 10:30:00"),
     *                     @OA\Property(property="time_ago", type="string", example="2 hours ago"),
     *                     @OA\Property(property="formatted_date", type="string", example="11-May-2026"),
     *                     @OA\Property(property="formatted_time", type="string", example="10:30 AM"),
     *                     @OA\Property(property="status", type="integer", example=0)
     *                 )
     *             )
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Unauthorized")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */

    public function NotificationList(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->sno)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $notifications = NotificationMobileModel::where('staff_id', $user->sno)
                ->where('branch_id', $staff->branch_id)
                ->where('status', '!=', 2)
                ->latest('notification_date')
                ->get();

            $notifications = $notifications->map(function ($item) {

                $dt = Carbon::parse($item->notification_date);

                return [
                    'id' => $item->sno,
                    'message' => $item->notification_content,
                    'notification_date' => $item->notification_date,
                    'time_ago' => $dt->diffForHumans(),
                    'formatted_date' => $dt->format('d-M-Y'),
                    'formatted_time' => $dt->format('h:i A'),
                    'status' => $item->status,
                ];
            });

            return response()->json([
                'status' => 200,
                'message' => 'Notification list fetched successfully',
                'data' => $notifications
            ]);
        } catch (\Exception $e) {

            \Log::error('Notification List Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }

    /**
     * @OA\Get(
     *     path="/get_unread_notification_count",
     *     summary="Get Unread Count",
     *     description="Get unread notifications Count",
     *     operationId="GetUnreadNotificationCount",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Response(
     *         response=200,
     *         description="Get Unread Count successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Get Unread Count successfully"),
     *
     *             @OA\Property(
     *                 property="data",
     *                 type="array",
     *
     *                 @OA\Items(
     *                     type="object",
     *
     *                     @OA\Property(property="id", type="integer", example=1),
     *                     @OA\Property(property="message", type="string", example="Get Unread Count successfully"),
     *                     @OA\Property(property="status", type="integer", example=0)
     *                 )
     *             )
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Unauthorized")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */

    public function GetUnreadNotificationCount(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->sno)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $notifications = NotificationMobileModel::where('staff_id', $user->sno)
                ->where('branch_id', $staff->branch_id)
                ->where('status', 0)
                ->latest('notification_date')
                ->count();

           

            return response()->json([
                'status' => 200,
                'message' => 'Get Unread Count successfully',
                'data' => [
                    "unread_count" => $notifications,
                ]
            ]);
        } catch (\Exception $e) {

            \Log::error('Notification Count Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }



    /**
     * @OA\Post(
     *     path="/staff_clear_all",
     *     summary="Clear All Notifications",
     *     description="Mark all unread notifications as read",
     *     operationId="clearAllNotifications",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Response(
     *         response=200,
     *         description="All notifications cleared successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="All notifications cleared successfully")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Unauthorized")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */


    public function ClearAllNotifications(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->sno)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            NotificationMobileModel::where('staff_id', $user->sno)
                ->where('branch_id', $staff->branch_id)
                // ->where('status', 0)
                ->update([
                    'status' => 2
                ]);

            return response()->json([
                'status' => 200,
                'message' => 'All notifications cleared successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Clear All Notification Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }


    /**
     * @OA\Post(
     *     path="/staff_clear_notification/{id}",
     *     summary="Clear Single Notification",
     *     description="Mark single notification as read",
     *     operationId="clearSingleNotification",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="Notification ID",
     *         @OA\Schema(type="integer", example=1)
     *     ),
     *
     *     @OA\Response(
     *         response=200,
     *         description="Notification cleared successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Notification cleared successfully")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=404,
     *         description="Notification not found",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=404),
     *             @OA\Property(property="message", type="string", example="Notification not found")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */

    public function ClearSingleNotification(Request $request, $id)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->sno)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $notification = NotificationMobileModel::where('sno', $id)
                ->where('staff_id', $user->sno)
                ->where('branch_id', $staff->branch_id)
                // ->where('status', 0)
                ->first();

            if (!$notification) {

                return response()->json([
                    'status' => 404,
                    'message' => 'Notification not found or already cleared'
                ], 404);
            }

            $notification->update([
                'status' => 2
            ]);

            return response()->json([
                'status' => 200,
                'message' => 'Notification cleared successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Clear Single Notification Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }

    /**
     * @OA\Post(
     *     path="/staff_mark_read_all",
     *     summary="Read All Notifications",
     *     description="Mark all unread notifications as read",
     *     operationId="ReadAllNotifications",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Response(
     *         response=200,
     *         description="All notifications Read successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="All notifications Read successfully")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Unauthorized")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */


    public function MarkasReadAllNotifications(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->sno)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            NotificationMobileModel::where('staff_id', $user->sno)
                ->where('branch_id', $staff->branch_id)
                ->where('status', 0)
                ->update([
                    'status' => 1
                ]);

            return response()->json([
                'status' => 200,
                'message' => 'All notifications Read successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Read All Notification Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }


    /**
     * @OA\Post(
     *     path="/staff_read_notification/{id}",
     *     summary="Read Single Notification",
     *     description="Mark single notification as read",
     *     operationId="ReadSingleNotification",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="Notification ID",
     *         @OA\Schema(type="integer", example=1)
     *     ),
     *
     *     @OA\Response(
     *         response=200,
     *         description="Notification Read successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Notification Read successfully")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=404,
     *         description="Notification not found",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=404),
     *             @OA\Property(property="message", type="string", example="Notification not found")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */

    public function ReadSingleNotification(Request $request, $id)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->sno)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $notification = NotificationMobileModel::where('sno', $id)
                ->where('staff_id', $user->sno)
                ->where('branch_id', $staff->branch_id)
                ->where('status', 0)
                ->first();

            if (!$notification) {

                return response()->json([
                    'status' => 404,
                    'message' => 'New Notification not found or already Read'
                ], 404);
            }

            $notification->update([
                'status' => 1
            ]);

            return response()->json([
                'status' => 200,
                'message' => 'Notification Read successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Read Single Notification Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }

    /**
     * @OA\Post(
     *     path="/confirm_checkout",
     *     summary="Confirm Employee Check-out",
     *     description="Final step of attendance.  stores check-out time and location.",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"face_id","date","latitude","longitude"},
     *             @OA\Property(property="date", type="string", format="date", example="2026-05-05"),
     *             @OA\Property(property="latitude", type="number", format="float", example=12.9716),
     *             @OA\Property(property="longitude", type="number", format="float", example=77.5946)
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Check-out successful",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Check-out successful"),
     *             @OA\Property(
     *                 property="data",
     *                 type="object",
     *                 @OA\Property(property="check_out_time", type="string", example="2026-05-05 10:35:22"),
     *                 @OA\Property(property="date", type="string", example="2026-05-05")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=409,
     *         description="Already checked out",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=409),
     *             @OA\Property(property="message", type="string", example="Already checked out")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation Error"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */
    public function confirmCheckOut(Request $request)
    {
        $request->validate([
            'date'      => 'required|date',
            'latitude'  => 'required',
            'longitude' => 'required',
        ]);

        $user = $request->user();



        //  2. Prevent duplicate check-in
        $alreadyChecked = StaffAttendanceModel::where('staff_id', $user->sno)
            ->where('date', $request->date)
            ->where('checkout_verified', 1)
            ->exists();

        if ($alreadyChecked) {
            return response()->json([
                'status' => 409,
                'message' => 'Already checked Out'
            ]);
        }

        //  3. Save Check-in
        $attendance = StaffAttendanceModel::updateOrCreate(
            [
                'staff_id' => $user->sno,
                'status' => 0,
                'date'     => $request->date
            ],
            [
                'checkout_verified'     => 1,
                'check_out_time'        => Carbon::now('Asia/Kolkata')->format('H:i:s'),
                'check_out_latitude'    => $request->latitude,
                'check_out_logitude'   => $request->longitude,
                'updated_at'           => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s')
            ]
        );


        AttendanceLogModel::create([
            'staff_id' => $user->sno,
            'type' => 'checkout',
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'created_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s')
        ]);

        $this->sendNotification(
                    $user->branch_id,
                    $user->sno,
                    "Check-out Successfully",
                    "Employee App",
                    $user->sno
                );

        return response()->json([
            'status' => 200,
            'message' => 'Check-Out successful',
        ]);
    }

    /**
     * @OA\Get(
     *     path="/get_month_staff_attendance_count",
     *     summary="Get Attendance Month Count",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *  * @OA\Parameter(
    *         name="year",
    *         in="query",
    *         required=false,
    *         description="Year (Example: 2026)",
    *         @OA\Schema(type="integer", example=2026)
    *     ),
     * @OA\Parameter(
    *         name="month",
    *         in="query",
    *         required=false,
    *         description="Month (Example: 04)",
    *         @OA\Schema(type="integer", example=04)
    *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Staff data fetched successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Staff Attendance fetched successfully"),
     *             @OA\Property(property="data", type="object")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Token missing or invalid",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Token invalid or expired")
     *         )
     *     )
     * )
     */

    public function getAttendanceCount(Request $request)
    {
        $user = $request->user();
        $staff = StaffModel::where('sno', $user->sno)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ], 404);
        }
    
        $year = $request->year ?? date('Y');
        $month = $request->month ?? date('m');

        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {

                $q->whereBetween('hol_date', [$startDate, $endDate])
                    ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->select('hol_date', 'hol_end_date')
            ->get();

        $holidayDates = [];

        foreach ($holidays as $holiday) {
            $from = Carbon::parse($holiday->hol_date);
            $to = Carbon::parse($holiday->hol_end_date ?? $holiday->hol_date);
            while ($from->lte($to)) {
                $holidayDates[] = $from->format('Y-m-d');
                $from->addDay();
            }
        }

        $holidayDates = array_unique($holidayDates);

        $attendanceCounts = StaffAttendanceModel::where('staff_id', $user->sno)
            ->whereYear('date', $year)
            ->whereMonth('date', $month)
            ->where('status', 0)
            ->selectRaw("
                SUM(CASE WHEN attendance = 'P' THEN 1 ELSE 0 END) as present_count,
                SUM(CASE WHEN attendance = 'L' THEN 
                    CASE 
                        WHEN leave_type IN ('first_half','second_half') THEN 0.5
                        ELSE 1
                    END
                ELSE 0 END) as leave_count,
                SUM(CASE WHEN attendance = 'A' THEN 1 ELSE 0 END) as absent_count,
                SUM(CASE WHEN attendance = 'PR' THEN 1 ELSE 0 END) as permission_count,
                SUM(CASE WHEN attendance = 'OD' THEN 1 ELSE 0 END) as onduty_count
            ")
            ->first();

        $lateCount = DB::table('egc_staff_attendance as a')
            ->join('egc_shift_time_log as stl', function ($join) {
                $join->on('stl.staff_id', '=', 'a.staff_id');
            })
            ->join('egc_shift_day_times as sd', function ($join) {
                $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                    ->where('sd.status', 0);
            })
            ->where('a.staff_id', $user->sno)
            ->whereYear('a.date', $year)
            ->whereMonth('a.date', $month)
            ->where('a.status', 0)
            ->whereNotIn('a.attendance', ['L', 'A', 'PR', 'OD'])
            ->whereNotNull('a.in_time')
            ->whereNotIn('a.date', $holidayDates)
            ->whereRaw("
                DATE(a.date) BETWEEN stl.start_date 
                AND IFNULL(stl.end_date, '9999-12-31')
            ")
            ->whereRaw("
                LOWER(sd.day_name) = LOWER(DATE_FORMAT(a.date, '%a'))
            ")
            ->whereRaw("
                TIME(a.in_time) > ADDTIME(sd.time_from, '00:11:00')
            ")
            ->count();

        $staffData = [
            "staff_sno"        => $staff->sno,
            "employee_id"      => $staff->staff_id,
            "staff_name"       => $staff->staff_name,
            "total_present_count"    => (float)$attendanceCounts->present_count + (float)$attendanceCounts->onduty_count,
            "present_count"    => (float)$attendanceCounts->present_count,
            "leave_count"      => (float)$attendanceCounts->leave_count,
            "absent_count"     => (float)$attendanceCounts->absent_count,
            "permission_count" => (float)$attendanceCounts->permission_count,
            "onduty_count"     => (float)$attendanceCounts->onduty_count,
            "late_count"       => (int)$lateCount,
            "month"            => $month,
            "year"             => $year,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Staff attendance fetched successfully',
            'error_msg' => null,
            'data' => $staffData

        ], 200);
    }

    /**
 * @OA\Get(
 *     path="/get_year_holiday_list",
 *     summary="Get Current Year Holiday List",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *     @OA\Parameter(
 *         name="year",
 *         in="query",
 *         required=false,
 *         description="Year (Example: 2026)",
 *         @OA\Schema(type="integer", example=2026)
 *     ),
 *     @OA\Response(
 *         response=200,
 *         description="Holiday data fetched successfully"
 *     )
 * )
 */
public function getYearHolidayList(Request $request)
{
    $user = $request->user();

    $staff = StaffModel::where('sno', $user->sno)->first();

    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Staff not found',
            'data' => null
        ], 404);
    }

    // Current year default
    $year = $request->year ?? date('Y');

    $holidays = HolidayModel::where('status', 0)
        ->where(function ($query) use ($year) {

            $query->whereYear('hol_date', $year)
                ->orWhereYear('hol_end_date', $year);
        })
        ->orderBy('hol_date', 'asc')
        ->get();

    $holidayData = $holidays->map(function ($holiday) {

        $startDate = Carbon::parse($holiday->hol_date);

        $endDate = $holiday->hol_end_date
            ? Carbon::parse($holiday->hol_end_date)
            : null;

        return [
            'id' => $holiday->sno,

            // UI Date
            'day' => $startDate->format('d'),
            'month' => strtoupper($startDate->format('M')),

            // Holiday Details
            'reason' => $holiday->hol_reason,

            // Optional if available in DB
            'type' => $holiday->holiday_type ?? 'National',

            // Dates
            'start_date' => $startDate->format('Y-m-d'),

            'end_date' => $endDate
                ? $endDate->format('Y-m-d')
                : null,

            'full_date' => $endDate
                ? $startDate->format('Y-m-d') . ' - ' . $endDate->format('Y-m-d')
                : $startDate->format('Y-m-d'),
        ];
    })->values();

    return response()->json([
        'status' => 200,
        'message' => 'Holiday data fetched successfully',
        'error_msg' => null,
        'year' => (int) $year,
        'total_holidays' => $holidayData->count(),
        'data' => $holidayData

    ], 200);
}



/**
 * @OA\Get(
 *     path="/get_month_leave_perm_request",
 *     summary="Get Monthly Leave & Permission Requests",
 *     description="Returns the logged-in employee's leave and permission requests for a selected month and year.",
 *     operationId="getMonthLeavePermissionRequest",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *
 *     @OA\Parameter(
 *         name="year",
 *         in="query",
 *         required=false,
 *         description="Year (Example: 2026). Defaults to current year.",
 *         @OA\Schema(
 *             type="integer",
 *             example=2026
 *         )
 *     ),
 *
 *     @OA\Parameter(
 *         name="month",
 *         in="query",
 *         required=false,
 *         description="Month (1-12). Defaults to current month.",
 *         @OA\Schema(
 *             type="integer",
 *             example=4
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Leave and Permission requests fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=200),
 *             @OA\Property(property="message", type="string", example="Leave and Permission requests fetched successfully"),
 *             @OA\Property(property="error_msg", type="string", nullable=true, example=null),
 *
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *
 *                 @OA\Property(property="staff_sno", type="integer", example=101),
 *                 @OA\Property(property="employee_id", type="string", example="EGC001"),
 *                 @OA\Property(property="staff_name", type="string", example="Vetri Vijayan"),
 *                 @OA\Property(property="month", type="integer", example=4),
 *                 @OA\Property(property="year", type="integer", example=2026),
 *                 @OA\Property(property="total_requests", type="integer", example=3),
 *
 *                 @OA\Property(
 *                     property="requests",
 *                     type="array",
 *
 *                     @OA\Items(
 *                         type="object",
 *
 *                         @OA\Property(property="request_id", type="integer", example=125),
 *                         @OA\Property(property="request_type", type="string", example="Leave"),
 *                         @OA\Property(property="from_date", type="string", example="04 Apr 2026"),
 *                         @OA\Property(property="to_date", type="string", nullable=true, example="05 Apr 2026"),
 *                         @OA\Property(property="from_time", type="string", nullable=true, example="10:00 AM"),
 *                         @OA\Property(property="to_time", type="string", nullable=true, example="11:00 AM"),
 *                         @OA\Property(property="leave_type", type="string", nullable=true, example="Casual Leave"),
 *                         @OA\Property(property="total_days", type="number", format="float", example=2),
 *                         @OA\Property(property="reason", type="string", example="Travelling Out of Station"),
 *                         @OA\Property(property="submitted_on", type="string", example="25 Mar 2026"),
 *                         @OA\Property(property="status", type="string", example="Pending"),
 *                         @OA\Property(property="status_color", type="string", example="#F59E0B"),
 *                         @OA\Property(property="status_icon", type="string", example="pending"),
 *
 *                         @OA\Property(
 *                             property="display_title",
 *                             type="string",
 *                             example="Leave • Apr 4 - Apr 5"
 *                         ),
 *
 *                         @OA\Property(
 *                             property="display_subtitle",
 *                             type="string",
 *                             example="Travelling Out of Station • Submitted Mar 25"
 *                         )
 *                     )
 *                 )
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="Unauthorized",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=401),
 *             @OA\Property(property="message", type="string", example="Token invalid or expired")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="Staff not found",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=404),
 *             @OA\Property(property="message", type="string", example="Staff not found")
 *         )
 *     )
 * )
 */

    public function getLeavePermRequest(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->sno)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ], 404);
        }

        $year  = $request->year ?? now()->year;
        $month = $request->month ?? now()->month;

        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();

        $requests = LeavePermissionModel::where('staff_id', $staff->sno)
            ->whereBetween('from_date', [$startDate, $endDate])
            ->orderByDesc('created_at')
            ->get()
            ->map(function ($item) {
                $statusData = match ((int)$item->status) {
                    0 => [
                        'status' => 'Pending',
                        'status_code' => 0,
                        'status_color' => '#F59E0B',
                        'status_icon' => 'pending'
                    ],

                    1 => [
                        'status' => 'Approved',
                        'status_code' => 1,
                        'status_color' => '#22C55E',
                        'status_icon' => 'approved'
                    ],

                    3 => [
                        'status' => 'On Hold',
                        'status_code' => 3,
                        'status_color' => '#3B82F6',
                        'status_icon' => 'hold'
                    ],

                    4 => [
                        'status' => 'Rejected',
                        'status_code' => 4,
                        'status_color' => '#EF4444',
                        'status_icon' => 'rejected'
                    ],

                    default => [
                        'status' => 'Unknown',
                        'status_code' => null,
                        'status_color' => '#6B7280',
                        'status_icon' => 'unknown'
                    ]
                };

                return [
                    'request_id' => $item->sno,
                    'request_code' => $item->request_id,
                    'request_type' => $item->request_type,

                    'from_date' => $item->from_date
                        ? Carbon::parse($item->from_date)->format('d M Y')
                        : null,

                    'from_time' => $item->from_time
                        ? Carbon::parse($item->from_time)->format('h:i A')
                        : null,

                    'to_time' => $item->to_time
                        ? Carbon::parse($item->to_time)->format('h:i A')
                        : null,

                    'leave_type' => $item->leave_type,
                    'reason' => $item->reason,

                    'submitted_on' => $item->created_at
                        ? Carbon::parse($item->created_at)->format('d M Y')
                        : null,
                    'status_code' =>  $item->status,
                    'status' => $statusData['status'],
                ];
            });

        return response()->json([
            'status' => 200,
            'message' => 'Leave and Permission requests fetched successfully',
            'error_msg' => null,
            'data' => $requests
            
        ], 200);
    }
 

     /**
 * @OA\Get(
 *     path="/get_month_staff_attendance_list",
 *     summary="Get Monthly Staff Attendance Calendar",
 *     description="Returns attendance status for each day of the selected month.",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *
 *     @OA\Parameter(
 *         name="year",
 *         in="query",
 *         required=false,
 *         description="Year (Example: 2026)",
 *         @OA\Schema(type="integer", example=2026)
 *     ),
 *
 *     @OA\Parameter(
 *         name="month",
 *         in="query",
 *         required=false,
 *         description="Month (1-12)",
 *         @OA\Schema(type="integer", example=4)
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Attendance calendar fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=200
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Attendance fetched successfully"
 *             ),
 *             @OA\Property(
 *                 property="error_msg",
 *                 type="string",
 *                 nullable=true,
 *                 example=null
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="array",
 *                 @OA\Items(
 *                     type="object",
 *                     @OA\Property(
 *                         property="day",
 *                         type="integer",
 *                         example=1
 *                     ),
 *                     @OA\Property(
 *                         property="date",
 *                         type="string",
 *                         format="date",
 *                         example="2026-04-01"
 *                     ),
 *                     @OA\Property(
 *                         property="status",
 *                         type="string",
 *                         example="present",
 *                         description="possible values: present, late, leave, absent, permission, onduty, holiday, none"
 *                     )
 *                 )
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="Staff not found",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=404
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Staff not found"
 *             ),
 *             @OA\Property(
 *                 property="error_msg",
 *                 type="string",
 *                 example="Staff not found"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="array",
 *                 @OA\Items()
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="Token missing or invalid",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=401
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Token invalid or expired"
 *             )
 *         )
 *     )
 * )
 */

    public function getAttendanceList(Request $request)
{
    $user = $request->user();

    $staff = StaffModel::find($user->sno);

    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Staff not found',
            'data' => []
        ], 404);
    }

    $year = $request->year ?? date('Y');
    $month = $request->month ?? date('m');

    $startDate = Carbon::create($year, $month, 1)->startOfMonth();
    $endDate   = Carbon::create($year, $month, 1)->endOfMonth();

    /*
    |--------------------------------------------------------------------------
    | Holidays
    |--------------------------------------------------------------------------
    */

    $holidays = DB::table('egc_holiday')
        ->where('status', 0)
        ->where(function ($q) use ($startDate, $endDate) {

            $q->whereBetween('hol_date', [$startDate, $endDate])
                ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
        })
        ->get();

    $holidayDates = [];

    foreach ($holidays as $holiday) {

        $from = Carbon::parse($holiday->hol_date);
        $to   = Carbon::parse(
            $holiday->hol_end_date ?? $holiday->hol_date
        );

        while ($from->lte($to)) {

            $holidayDates[$from->format('Y-m-d')] = true;

            $from->addDay();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Attendance
    |--------------------------------------------------------------------------
    */

    $attendanceList = StaffAttendanceModel::where('staff_id', $user->sno)
        ->whereYear('date', $year)
        ->whereMonth('date', $month)
        ->where('status', 0)
        ->get()
        ->keyBy(function ($row) {
            return Carbon::parse($row->date)->format('Y-m-d');
        });

    $calendarData = [];

    $currentDate = $startDate->copy();

    while ($currentDate->lte($endDate)) {

        $date = $currentDate->format('Y-m-d');

        $status = 'none';

        /*
        |--------------------------------------------------------------------------
        | Holiday
        |--------------------------------------------------------------------------
        */

        if (isset($holidayDates[$date])) {

            $status = 'holiday';
        }

        /*
        |--------------------------------------------------------------------------
        | Attendance Exists
        |--------------------------------------------------------------------------
        */

        if (isset($attendanceList[$date])) {

            $attendance = $attendanceList[$date];

            switch ($attendance->attendance) {

                case 'L':
                    $status = 'leave';
                    break;

                case 'A':
                    $status = 'absent';
                    break;

                case 'PR':
                    $status = 'permission';
                    break;

                case 'OD':
                    $status = 'onduty';
                    break;

                case 'P':

                    $isLate = DB::table('egc_staff_attendance as a')
                        ->join('egc_shift_time_log as stl', function ($join) {
                            $join->on('stl.staff_id', '=', 'a.staff_id');
                        })
                        ->join('egc_shift_day_times as sd', function ($join) {
                            $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                                ->where('sd.status', 0);
                        })
                        ->where('a.staff_id', $attendance->staff_id)
                        ->whereDate('a.date', $date)
                        ->whereRaw("
                            DATE(a.date)
                            BETWEEN stl.start_date
                            AND IFNULL(stl.end_date,'9999-12-31')
                        ")
                        ->whereRaw("
                            LOWER(sd.day_name)
                            =
                            LOWER(DATE_FORMAT(a.date,'%a'))
                        ")
                        ->whereRaw("
                            TIME(a.in_time)
                            >
                            ADDTIME(sd.time_from,'00:11:00')
                        ")
                        ->exists();

                    $status = $isLate
                        ? 'late'
                        : 'present';

                    break;
            }
        }

        $calendarData[] = [
            'day' => (int)$currentDate->format('d'),
            'date' => $date,
            'status' => $status
        ];

        $currentDate->addDay();
    }

    return response()->json([
        'status' => 200,
        'message' => 'Attendance fetched successfully',
        'error_msg' => null,
        'data' => $calendarData
    ]);
}


/**
 * @OA\Get(
 *     path="/get_leave_reason_list",
 *     summary="Get Leave & Permission Reason List",
 *     description="Fetch all active leave and permission reasons.",
 *     operationId="getLeaveReasonList",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *
 *     @OA\Response(
 *         response=200,
 *         description="Reason list fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=200
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Reason list fetched successfully"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="array",
 *                 @OA\Items(
 *                     type="object",
 *
 *                     @OA\Property(
 *                         property="sno",
 *                         type="integer",
 *                         example=1
 *                     ),
 *
 *                     @OA\Property(
 *                         property="reason_name",
 *                         type="string",
 *                         example="Medical Emergency"
 *                     ),
 *
 *                     @OA\Property(
 *                         property="comments_check",
 *                         type="integer",
 *                         example=1,
 *                         description="1 = Comments mandatory, 0 = Comments optional"
 *                     ),
 *
 *                     @OA\Property(
 *                         property="reason_type",
 *                         type="integer",
 *                         example=1,
 *                         description="1 = Leave Reason, 2 = Permission Reason"
 *                     )
 *                 )
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="Unauthorized",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=401
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Unauthorized"
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Server Error",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=500
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Server Error"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="array",
 *                 @OA\Items()
 *             )
 *         )
 *     )
 * )
 */

    public function LeaveAndPermissionReasonList(Request $request)
{
    try {

        $leaveReasons = LeaveReasonModel::where('status', 0)
            ->select(
                'sno',
                'reason_name',
                'comments_check'
            )
            ->get()
            ->map(function ($item) {

                return [
                    'sno' => $item->sno,
                    'reason_name' => $item->reason_name,
                    'comments_check' => (int)$item->comments_check,
                    'reason_type' => 1 // Leave
                ];
            });

        $permissionReasons = PermissionReasonModel::where('status', 0)
            ->select(
                'sno',
                'reason_name',
                'comments_check'
            )
            ->get()
            ->map(function ($item) {

                return [
                    'sno' => $item->sno,
                    'reason_name' => $item->reason_name,
                    'comments_check' => (int)$item->comments_check,
                    'reason_type' => 2 // Permission
                ];
            });

        $reasons = $leaveReasons
            ->concat($permissionReasons)
            ->sortBy('reason_name')
            ->values();

        return response()->json([
            'status' => 200,
            'message' => 'Reason list fetched successfully',
            'data' => $reasons
        ]);

    } catch (\Exception $e) {

        \Log::error('Reason List Error', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
        ]);

        return response()->json([
            'status' => 500,
            'message' => 'Server Error',
            'data' => []
        ], 500);
    }
}


/**
     * @OA\Post(
     *     path="/add_leave_permission_request",
     *     summary="Create Leave or Permission Request",
     *     description="Submit a Leave or Permission request. The request will be sent through the configured approval workflow and assigned to the respective approvers.",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
    *         required=true,
    *         @OA\JsonContent(
    *             required={"request_type","date"},
    *
    *             @OA\Property(
    *                 property="request_type",
    *                 type="integer",
    *                 enum={1,2},
    *                 example=1,
    *                 description="1 = Leave, 2 = Permission"
    *             ),
    *
    *             @OA\Property(
    *                 property="date",
    *                 type="string",
    *                 format="date",
    *                 example="2026-06-08",
    *                 description="Leave or Permission date"
    *             ),
    *
    *             @OA\Property(
    *                 property="leave_type",
    *                 type="string",
    *                 example="Casual Leave",
    *                 description="Required for Leave requests"
    *             ),
    *
    *             @OA\Property(
    *                 property="reason_id",
    *                 type="integer",
    *                 example=1,
    *                 description="Reason master ID"
    *             ),
    *
    *             @OA\Property(
    *                 property="comments",
    *                 type="string",
    *                 example="Family function",
    *                 description="Additional remarks"
    *             ),
    *
    *             @OA\Property(
    *                 property="from_time",
    *                 type="string",
    *                 format="time",
    *                 example="10:00:00",
    *                 description="Required for Permission requests"
    *             ),
    *
    *             @OA\Property(
    *                 property="to_time",
    *                 type="string",
    *                 format="time",
    *                 example="12:00:00",
    *                 description="Required for Permission requests"
    *             )
    *         )
    *     ),
    *
    *     @OA\Response(
    *         response=200,
    *         description="Request submitted successfully",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="integer", example=200),
    *             @OA\Property(property="message", type="string", example="Leave request submitted successfully."),
    *             @OA\Property(
    *                 property="data",
    *                 type="object",
    *                 @OA\Property(
    *                     property="request_id",
    *                     type="string",
    *                     example="REQST-0001-06-26"
    *                 ),
    *                 @OA\Property(
    *                     property="leave_id",
    *                     type="integer",
    *                     example=125
    *                 ),
    *                 @OA\Property(
    *                     property="status",
    *                     type="string",
    *                     example="Pending Approval"
    *                 )
    *             )
    *         )
    *     ),
    *
    *     @OA\Response(
    *         response=401,
    *         description="Unauthorized",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="integer", example=401),
    *             @OA\Property(property="message", type="string", example="Unauthenticated.")
    *         )
    *     ),
    *
    *     @OA\Response(
    *         response=404,
    *         description="Staff not found",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="integer", example=404),
    *             @OA\Property(property="message", type="string", example="Staff not found")
    *         )
    *     ),
    *
    *     @OA\Response(
    *         response=422,
    *         description="Validation Error",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="integer", example=422),
    *             @OA\Property(property="message", type="string", example="Validation failed"),
    *             @OA\Property(
    *                 property="errors",
    *                 type="object",
    *                 example={
    *                     "request_type":{"The request type field is required."},
    *                     "date":{"The date field is required."}
    *                 }
    *             )
    *         )
    *     ),
    *
    *     @OA\Response(
    *         response=500,
    *         description="Internal Server Error",
    *         @OA\JsonContent(
    *             @OA\Property(property="status", type="integer", example=500),
    *             @OA\Property(property="message", type="string", example="Something went wrong. Please try again later.")
    *         )
    *     )
     * )
     */
    
public function AddLeavePermissionRequest(Request $request)
{
    $validator = Validator::make($request->all(), [
        'request_type' => 'required|in:1,2',
        'date'         => 'required|date',
        'reason_id'    => 'nullable',
        'leave_type'   => 'nullable|string|max:50',
        'comments'     => 'nullable',
        'from_time'    => 'required_if:request_type,2',
        'to_time'      => 'required_if:request_type,2',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'  => 422,
            'message' => 'Validation failed',
            'errors'  => $validator->errors()
        ], 422);
    }

    try {

        return DB::transaction(function () use ($request) {

            $user = $request->user();

            $staff = StaffModel::find($user->sno);

            if (!$staff) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Staff not found'
                ], 404);
            }

            $requestType = $request->request_type == 1
                ? 'Leave'
                : 'Permission';

            /*
            |--------------------------------------------------------------------------
            | Approval Workflow
            |--------------------------------------------------------------------------
            */

            $workflow = ApprovalHierarchyModel::firstOrCreate(
                [
                    'company_id'    => $staff->company_id,
                    'entity_id'     => $staff->entity_id,
                    'department_id' => $staff->department_id,
                    'job_role_id'   => $staff->job_role_id,
                ],
                [
                    'approve_level' => json_encode([
                        [
                            'level'      => 1,
                            'company'    => 0,
                            'entity'     => 0,
                            'department' => 1,
                            'staff_id'   => $this->getHrStaff(),
                        ]
                    ]),
                    'created_by' => $user->sno,
                    'updated_by' => $user->sno,
                ]
            );

            $levels = json_decode($workflow->approve_level, true);

            if (empty($levels)) {
                throw new \Exception('Approval hierarchy not configured.');
            }

            /*
            |--------------------------------------------------------------------------
            | Request Details
            |--------------------------------------------------------------------------
            */

            $leave = LeavePermissionModel::create([
                'request_id'   => $this->generateRequestId(),
                'staff_id'     => $user->sno,
                'from_date'    => date('Y-m-d', strtotime($request->date)),
                'reason_id'    => $request->reason_id,
                'reason'       => trim($request->comments),
                'leave_type'   => $request->leave_type,
                'request_type' => $requestType,
                'from_time'    => $requestType == 'Permission'
                    ? date('H:i:s', strtotime($request->from_time))
                    : null,
                'to_time'      => $requestType == 'Permission'
                    ? date('H:i:s', strtotime($request->to_time))
                    : null,
                'created_by'   => $user->sno,
                'updated_by'   => $user->sno,
            ]);

            /*
            |--------------------------------------------------------------------------
            | Approval Levels
            |--------------------------------------------------------------------------
            */

            foreach ($levels as $level) {

                LeaveApprovalModel::create([
                    'request_id'        => $leave->sno,
                    'level_no'          => $level['level'],
                    'approver_staff_id' => $level['staff_id'],
                    'created_by'        => $user->sno,
                    'updated_by'        => $user->sno,
                ]);
            }

            return response()->json([
                'status' => 200,
                'message' => ucfirst($requestType) . ' request submitted successfully.',
                'data' => [
                    'request_id' => $leave->request_id,
                    'leave_id'   => $leave->sno,
                    'status'     => 'Pending Approval'
                ]
            ], 200);
        });

    } catch (\Exception $e) {

        Log::error('Leave Request Error', [
            'message' => $e->getMessage(),
            'user_id' => optional($request->user())->user_id
        ]);

        return response()->json([
            'status' => 500,
            'message' => 'Something went wrong. Please try again later.'.$e->getMessage(),
        ], 500);
    }
}

private function getHrStaff()
  {
      $HrStaff = staffModel::where('department_id', 1)
          ->where('division_id', 1)
          ->where('job_role_id', 1)
          ->where('role_id', 2)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();

      return $HrStaff ? $HrStaff->sno : 2;  // Fallback to staff ID 2 if no HR staff is found
  }

private function generateRequestId()
{
    $lastId = LeavePermissionModel::lockForUpdate()
        ->latest('sno')
        ->value('request_id');

    $runningNo = 1;

    if ($lastId &&
        preg_match('/REQST-(\d+)-(\d+)-(\d+)/', $lastId, $matches)) {

        $runningNo = ((int) $matches[1]) + 1;
    }

    return sprintf(
        'REQST-%04d-%s-%s',
        $runningNo,
        date('m'),
        date('y')
    );
}


/**
 * @OA\Get(
 *     path="/get_leave_permission_details",
 *     summary="Get Leave / Permission Request Details",
 *     description="Fetch complete details of a specific leave or permission request including approval workflow and attachments.",
 *     operationId="GetLeavePermissionDetails",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *
 *     @OA\Parameter(
 *         name="request_id",
 *         in="query",
 *         required=true,
 *         description="Leave/Permission Request ID",
 *         @OA\Schema(
 *             type="string",
 *             example="1"
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Request details fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=200),
 *             @OA\Property(property="message", type="string", example="Request details fetched successfully"),
 *
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *
 *                 @OA\Property(property="request_id", type="string", example="REQST-0001-06-26"),
 *                 @OA\Property(property="request_type", type="string", example="Leave"),
 *                 @OA\Property(property="leave_type", type="string", example="Full Day"),
 *
 *                 @OA\Property(property="from_date", type="string", example="2026-03-10"),
 *                 @OA\Property(property="to_date", type="string", example="2026-03-12"),
 *
 *                 @OA\Property(property="from_time", type="string", nullable=true, example=null),
 *                 @OA\Property(property="to_time", type="string", nullable=true, example=null),
 *
 *                 @OA\Property(property="reason_id", type="integer", example=1),
 *                 @OA\Property(property="reason_name", type="string", example="Medical Leave"),
 *                 @OA\Property(property="comments", type="string", example="Experiencing health issues, advised rest by doctor."),
 *
 *                 @OA\Property(
 *                     property="status",
 *                     type="string",
 *                     example="Pending"
 *                 ),
 *
 *                 @OA\Property(
 *                     property="attachments",
 *                     type="array",
 *                     @OA\Items(
 *                         type="object",
 *                         @OA\Property(property="name", type="string", example="medical_report.jpg"),
 *                         @OA\Property(property="url", type="string", example="https://domain.com/storage/leave_docs/medical_report.jpg")
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="approval_timeline",
 *                     type="array",
 *                     @OA\Items(
 *                         type="object",
 *                         @OA\Property(property="level", type="integer", example=1),
 *                         @OA\Property(property="approver_name", type="string", example="Rahul"),
 *                         @OA\Property(property="status", type="string", example="Pending"),
 *                         @OA\Property(property="remarks", type="string", example=""),
 *                         @OA\Property(property="action_date", type="string", nullable=true, example=null)
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="workflow_progress",
 *                     type="array",
 *                     @OA\Items(
 *                         type="object",
 *                         @OA\Property(property="title", type="string", example="HR Approval"),
 *                         @OA\Property(property="status", type="string", example="Pending"),
 *                         @OA\Property(property="date", type="string", nullable=true, example=null),
 *                         @OA\Property(property="time", type="string", nullable=true, example=null)
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="created_at",
 *                     type="string",
 *                     example="10 Jun 2026 09:05 AM"
 *                 )
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="Request not found",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=404),
 *             @OA\Property(property="message", type="string", example="Request not found")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="Unauthorized",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=401),
 *             @OA\Property(property="message", type="string", example="Unauthorized")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=422,
 *         description="Validation Error",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=422),
 *             @OA\Property(property="message", type="string", example="Validation failed")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Server Error",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=500),
 *             @OA\Property(property="message", type="string", example="Something went wrong. Please try again later.")
 *         )
 *     )
 * )
 */
public function GetLeavePermissionDetails(Request $request)
{
    $validator = Validator::make($request->all(), [
        'request_id' => 'required|integer'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation failed',
            'errors' => $validator->errors()
        ], 422);
    }

    try {

        $user = $request->user();

        $leave = LeavePermissionModel::where('sno', $request->request_id)
            ->where('staff_id', $user->sno) // Security Check
            ->where('status','!=',2)
            ->first();

        if (!$leave) {
            return response()->json([
                'status' => 404,
                'message' => 'Request not found'
            ], 404);
        }

        
        $reasonName = null;

        if (!empty($leave->reason_id)) {

            $reason = $leave->request_type == 'Leave'
                ? LeaveReasonModel::select('reason_name')
                    ->where('status', 0)
                    ->where('sno', $leave->reason_id)
                    ->first()
                : PermissionReasonModel::select('reason_name')
                    ->where('status', 0)
                    ->where('sno', $leave->reason_id)
                    ->first();

            $reasonName = $reason->reason_name ?? null;
        }

    
        $approvals = LeaveApprovalModel::where('request_id', $leave->sno)
            ->where('status','!=',2)
            ->orderBy('level_no')
            ->get();

        $approvalTimeline = [];

        foreach ($approvals as $approval) {

            $approver = StaffModel::select(
                    'egc_staff.sno',
                    'egc_staff.staff_name as name',
                    'egc_user_role.role_name'
                )
                ->leftJoin('egc_user_role', 'egc_user_role.sno', '=', 'egc_staff.role_id')
                ->where('egc_staff.sno', $approval->approver_staff_id)
                ->first();

            $approvalTimeline[] = [
                'level' => $approval->level_no,
                'approver_name' => $approver->name ?? 'Unknown',
                'approver_role' => $approver->role_name ?? '',
                'status_code' => $approval->status,
                'status' => match ((int)($approval->status ?? 0)) {
                    1 => 'Approved',
                    3 => 'On Hold',
                    4 => 'Rejected',
                    default => 'Pending'
                },
                'remarks' => $approval->remarks ?? '',
                'action_date' => !empty($approval->action_date)
                    ? date('d M Y h:i A', strtotime($approval->action_date))
                    : null
            ];
        }

        $requestStatus = match ((int)($leave->status ?? 0)) {
            1 => 'Approved',
            3 => 'On Hold',
            4 => 'Rejected',
            default => 'Pending'
        };

        
        return response()->json([
            'status' => 200,
            'message' => 'Request details fetched successfully',
            'data' => [
                'request_id' => $leave->request_id,
                'request_type' => $leave->request_type,
                'leave_type' => $leave->leave_type,
                'date' => !empty($leave->from_date)? date('d M Y', strtotime($leave->from_date)) : null,
                'from_date' => $leave->from_date,
                'from_time' => $leave->from_time ? date('h:i A', strtotime($leave->from_time)) : null,
                'to_time' => $leave->to_time? date('h:i A', strtotime($leave->to_time)) : null,
                'reason_id' => $leave->reason_id,
                'reason_name' => $reasonName,
                'comments' => $leave->reason,
                'status' => $requestStatus,
                'status_code' => $leave->status,
                'approval_timeline' => $approvalTimeline,
                'created_at' => !empty($leave->created_at) ? date('d M Y h:i A', strtotime($leave->created_at)) : null,
            ]
        ], 200);

    } catch (\Exception $e) {

        Log::error('Leave Request Details Error', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
        ]);

        return response()->json([
            'status' => 500,
            'message' => 'Something went wrong. Please try again later.'.$e->getMessage(),
        ], 500);
    }
}



/**
 * @OA\Get(
 *     path="/get_staff_dashboard_points",
 *     summary="Get Staff Dashboard Points",
 *     description="Returns staff reward points, attendance percentage and dashboard summary for the current month.",
 *     operationId="getDashboardPoint",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *
 *     @OA\Response(
 *         response=200,
 *         description="Dashboard points fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=200
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Dashboard points fetched successfully"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *
 *                 @OA\Property(
 *                     property="points",
 *                     type="integer",
 *                     example=1250,
 *                     description="Available reward points"
 *                 ),
 *
 *                 @OA\Property(
 *                     property="level",
 *                     type="string",
 *                     example="L1",
 *                     description="Current employee level"
 *                 ),
 *
 *                 @OA\Property(
 *                     property="attendance",
 *                     type="number",
 *                     format="float",
 *                     example=92.5,
 *                     description="Current month attendance percentage"
 *                 ),
 *
 *
 *                 @OA\Property(
 *                     property="momentum_message",
 *                     type="string",
 *                     example="Keep your momentum going"
 *                 )
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="Unauthorized",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Unauthenticated."
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="Staff not found",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=404
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Staff not found"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *                 nullable=true
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Server Error",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=500
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Server Error"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *                 nullable=true
 *             )
 *         )
 *     )
 * )
 */
public function getDashboardPoint(Request $request)
{
    try {

        $user = $request->user();

        $staff = StaffModel::where('egc_staff.status', '!=', 2)
            ->select(
                'egc_staff.*',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_user_role.role_name',
                'egc_languages.name as mother_tongue',
                'egc_job_role.job_position_name as job_role_name'
            )
            ->leftJoin('egc_company', 'egc_staff.company_id', '=', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_staff.entity_id', '=', 'egc_entity.sno')
            ->leftJoin('egc_user_role', 'egc_staff.role_id', '=', 'egc_user_role.sno')
            ->leftJoin('egc_languages', 'egc_staff.mother_tongue', '=', 'egc_languages.sno')
            ->leftJoin('egc_department', 'egc_staff.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 'egc_staff.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 'egc_staff.job_role_id', '=', 'egc_job_role.sno')
            ->where('egc_staff.sno', $user->sno)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'data' => null
            ], 404);
        }

        $year = now()->year;
        $month = now()->month;

        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('hol_date', [$startDate, $endDate])
                    ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->select('hol_date', 'hol_end_date')
            ->get();

        $holidayDates = [];

        foreach ($holidays as $holiday) {
            $from = Carbon::parse($holiday->hol_date);
            $to   = Carbon::parse($holiday->hol_end_date ?? $holiday->hol_date);
            while ($from->lte($to)) {
                $holidayDates[] = $from->format('Y-m-d');
                $from->addDay();
            }
        }
        $holidayDates = array_unique($holidayDates);
        $daysInMonth = $startDate->daysInMonth;
        $workingDays = $daysInMonth - count($holidayDates);
        $attendanceCounts = StaffAttendanceModel::where('staff_id', $user->sno)
            ->whereYear('date', $year)
            ->whereMonth('date', $month)
            ->where('status', 0)
            ->selectRaw("
                SUM(CASE WHEN attendance = 'P' THEN 1 ELSE 0 END) as present_count,
                SUM(CASE WHEN attendance = 'OD' THEN 1 ELSE 0 END) as onduty_count,
                SUM(CASE WHEN attendance = 'PR' THEN 1 ELSE 0 END) as permission_count,
                SUM(CASE WHEN attendance = 'A' THEN 1 ELSE 0 END) as absent_count,
                SUM(
                    CASE
                        WHEN attendance = 'L' THEN
                            CASE
                                WHEN leave_type IN ('first_half','second_half')
                                    THEN 0.5
                                ELSE 1
                            END
                        ELSE 0
                    END
                ) as leave_count
            ")
            ->first();
        $presentCount    = (float) ($attendanceCounts->present_count ?? 0);
        $ondutyCount     = (float) ($attendanceCounts->onduty_count ?? 0);
        $permissionCount = (float) ($attendanceCounts->permission_count ?? 0);

        $attendanceDays = $presentCount + $ondutyCount + $permissionCount;
        $currentMonthPresentPercentage = $workingDays > 0
            ? round(($attendanceDays / $workingDays) * 100, 1)
            : 0;

        if ($currentMonthPresentPercentage >= 95) {
            $momentumMessage = 'Outstanding attendance';
        } elseif ($currentMonthPresentPercentage >= 85) {
            $momentumMessage = 'Keep your momentum going';
        } elseif ($currentMonthPresentPercentage >= 75) {
            $momentumMessage = 'Good progress so far';
        } else {
            $momentumMessage = 'Improve attendance rate';
        }

        $data = [
            'points' => (int) ($staff->avaiable_points ?? 0),
            'level' => 'L1',
            'attendance' => $currentMonthPresentPercentage,
            'momentum_message' => $momentumMessage,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Dashboard points fetched successfully',
            'data' => $data
        ]);

    } catch (\Exception $e) {
        Log::error('Dashboard Point Error', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'user_id' => optional($request->user())->user_id
        ]);
        return response()->json([
            'status' => 500,
            'message' => 'Server Error',
            'data' => null
        ], 500);
    }
}
/**
 * @OA\Get(
 *     path="/get_staff_dashboard_overview",
 *     summary="Get Dashboard Overview",
 *     description="Returns dashboard overview including HR tickets, incentives, leave summary and upcoming training details.",
 *     operationId="getDashboardOverview",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *
 *     @OA\Response(
 *         response=200,
 *         description="Overview data fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=200
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Overview data fetched successfully"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *
 *                 @OA\Property(
 *                     property="hr_ticket",
 *                     type="object",
 *                     @OA\Property(
 *                         property="resolved",
 *                         type="integer",
 *                         example=0
 *                     ),
 *                     @OA\Property(
 *                         property="total",
 *                         type="integer",
 *                         example=0
 *                     ),
 *                     @OA\Property(
 *                         property="due_today",
 *                         type="integer",
 *                         example=0
 *                     ),
 *                     @OA\Property(
 *                         property="progress",
 *                         type="integer",
 *                         example=100
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="incentive",
 *                     type="object",
 *                     @OA\Property(
 *                         property="amount",
 *                         type="number",
 *                         format="float",
 *                         example=0
 *                     ),
 *                     @OA\Property(
 *                         property="progress",
 *                         type="integer",
 *                         example=100
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="leave_taken",
 *                     type="object",
 *                     @OA\Property(
 *                         property="count",
 *                         type="integer",
 *                         example=3
 *                     ),
 *                     @OA\Property(
 *                         property="available",
 *                         type="integer",
 *                         example=12
 *                     ),
 *                     @OA\Property(
 *                         property="progress",
 *                         type="integer",
 *                         example=20
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="next_training",
 *                     type="object",
 *                     @OA\Property(
 *                         property="date",
 *                         type="string",
 *                         nullable=true,
 *                         example="24 Mar"
 *                     ),
 *                     @OA\Property(
 *                         property="days_to_go",
 *                         type="integer",
 *                         example=3
 *                     ),
 *                     @OA\Property(
 *                         property="title",
 *                         type="string",
 *                         nullable=true,
 *                         example="React Advanced"
 *                     ),
 *                     @OA\Property(
 *                         property="progress",
 *                         type="integer",
 *                         example=50
 *                     )
 *                 )
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="Unauthorized",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Unauthenticated."
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="Staff not found",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=404
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Staff not found"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *                 nullable=true
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Server Error",
 *         @OA\JsonContent(
 *             @OA\Property(
 *                 property="status",
 *                 type="integer",
 *                 example=500
 *             ),
 *             @OA\Property(
 *                 property="message",
 *                 type="string",
 *                 example="Server Error"
 *             ),
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *                 nullable=true
 *             )
 *         )
 *     )
 * )
 */
public function getDashboardOverview(Request $request)
{
    try {

        $user = $request->user();

        $staff = StaffModel::where('egc_staff.status', '!=', 2)
            ->select(
                'egc_staff.*',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_user_role.role_name',
                'egc_languages.name as mother_tongue',
                'egc_job_role.job_position_name as job_role_name'
            )
            ->leftJoin('egc_company', 'egc_staff.company_id', '=', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_staff.entity_id', '=', 'egc_entity.sno')
            ->leftJoin('egc_user_role', 'egc_staff.role_id', '=', 'egc_user_role.sno')
            ->leftJoin('egc_languages', 'egc_staff.mother_tongue', '=', 'egc_languages.sno')
            ->leftJoin('egc_department', 'egc_staff.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 'egc_staff.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 'egc_staff.job_role_id', '=', 'egc_job_role.sno')
            ->where('egc_staff.sno', $user->sno)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'data' => null
            ], 404);
        }

        $year = now()->year;
        $month = now()->month;

        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();

        

        $leaveTaken = StaffAttendanceModel::where('staff_id', $user->sno)
            ->whereYear('date', $year)
            ->whereMonth('date', $month)
            ->where('status', 0)
            ->whereIn('attendance', ['L', 'A'])
            ->count();

       $availableLeave = (int) ($staff->casual_leave ?? 0);

       $totalLeaveQuota = $leaveTaken + $availableLeave;

        $leaveProgress = $totalLeaveQuota > 0
            ? round(($leaveTaken / $totalLeaveQuota) * 100)
            : 0;

        $nextTraining = TrainingPlannerModel::where('status', 0)
            ->whereDate(DB::raw('COALESCE(schedule_to_date, schedule_date)'), '>=', now()->toDateString())
            ->get()
            ->filter(function ($training) use ($user) {

                if ($training->all_check == 1) {
                    return true;
                }

                $staffIds = $training->staff_check ?: [];

                if (is_string($staffIds)) {
                    $staffIds = json_decode($staffIds, true) ?? [];
                }

                return in_array((string)$user->sno, array_map('strval', $staffIds));
            })
            ->values()
            ->sortBy(function ($training) {
                $fromDate = $training->schedule_from_date ?: $training->schedule_date;
                return Carbon::parse($fromDate)->startOfDay()->getTimestamp();
            })
            ->first();


            $trainingData = [
                'date' => null,
                'days_to_go' => 0,
                'title' => null,
                'progress' => 0
            ];

            if ($nextTraining) {
                $fromDate = $nextTraining->schedule_from_date ?: $nextTraining->schedule_date;
                $scheduleDate = Carbon::parse($fromDate);

                $daysToGo = now()->startOfDay()->diffInDays($scheduleDate, false);

                $trainingData = [
                    'date' => $scheduleDate->format('d M'),

                    'days_to_go' => max($daysToGo, 0),

                    'title' => $nextTraining->training_planner_name,

                    'progress' => $daysToGo <= 0
                        ? 100
                        : max(0, min(100, round((30 - $daysToGo) / 30 * 100)))
                ];
            }

            $hrTicket = [
                'resolved' => 0,
                'total' => 0,
                'due_today' => 0,
                'progress' => 100
            ];

            $incentive = [
                'amount' => 0,
                'progress' => 100
            ];

        $data = [
            'hr_ticket' => $hrTicket,
            'incentive' => $incentive,
            'leave_taken' => [
                'count' => $leaveTaken,
                'available' => $availableLeave,
                'progress' => $leaveProgress
            ],
            'next_training' => $trainingData
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Overview data fetched successfully',
            'data' => $data
        ]);

    } catch (\Exception $e) {
        Log::error('Dashboard Point Error', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'user_id' => optional($request->user())->user_id
        ]);
        return response()->json([
            'status' => 500,
            'message' => 'Server Error',
            'data' => null
        ], 500);
    }
}



/**
* @OA\Get(
* path="/get_staff_payslip_list",
* summary="Get Staff Payslip List",
* description="Fetch latest payslip summary and recent payslip history for the logged-in staff.",
* operationId="getStaffPayslipList",
*tags={"Employee"},
* security={{"bearerAuth":{}}},
* @OA\Response(
* response=200,
* description="Payslip list fetched successfully",
*  @OA\JsonContent(
* @OA\Property(property="status", type="integer", example=200),
* @OA\Property(property="message", type="string", example="Payslip list fetched successfully"),
* @OA\Property(
* property="data",
* type="object",
* @OA\Property(property="latest_net_pay", type="number", format="float", example=48128),
* @OA\Property(property="latest_payslip_month", type="integer", example=3),
* @OA\Property(property="latest_payslip_year", type="integer", example=2026),
*@OA\Property(property="latest_gross", type="number", format="float", example=51800),
* @OA\Property(property="latest_deduction", type="number", format="float", example=7872),
*@OA\Property(property="latest_incentive", type="number", format="float", example=4200),
* @OA\Property(
* property="latest_payslip_link",
* type="string",
* nullable=true,
*example="https://domain.com/payroll/payslip_print/eyJpdiI6..."
* ),
*
* @OA\Property(
* property="recent_payslips",
*type="array",
*@OA\Items(
*type="object",
*@OA\Property(property="id", type="integer", example=12),
*@OA\Property(property="month", type="string", example="March"),
* @OA\Property(property="year", type="integer", example=2026),
*@OA\Property(property="net_pay", type="number", format="float", example=48128),
* @OA\Property(property="date", type="string", example="Mar 31"),
* @OA\Property(
*property="payslip_link",
*type="string",
*nullable=true,
*example="https://domain.com/payroll/payslip_print/eyJpdiI6..."
*)
*)
*)
*)
*)
* ),
*
*@OA\Response(
*response=404,
*description="Staff not found",
* @OA\JsonContent(
*@OA\Property(property="status", type="integer", example=404),
*@OA\Property(property="message", type="string", example="Staff not found"),
*@OA\Property(property="data", type="object", nullable=true)
*)
*),
*@OA\Response(
* response=401,
* description="Unauthorized",
* @OA\JsonContent(
* @OA\Property(property="status", type="integer", example=401),
* @OA\Property(property="message", type="string", example="Unauthorized")
* )
*),
*@OA\Response(
* response=500,
* description="Server Error",
* @OA\JsonContent(
* @OA\Property(property="status", type="integer", example=500),
*@OA\Property(property="message", type="string", example="Server Error"),
* @OA\Property(property="data", type="object", nullable=true)
* )
*)
* )
  */



public function getStaffPayslipList(Request $request)
{
    try {

        $user = $request->user();
        $staff = StaffModel::where('sno', $user->sno)
            ->where('status', '!=', 2)
            ->first();
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'data' => null
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Latest Payroll
        |--------------------------------------------------------------------------
        */
        $latestPayroll = DB::table('egc_payroll_employee_payrolls')
            ->join(
                'egc_payroll_processes',
                'egc_payroll_processes.sno',
                '=',
                'egc_payroll_employee_payrolls.payroll_process_sno'
            )
            ->where('egc_payroll_employee_payrolls.staff_id', $user->sno)
            ->where('egc_payroll_employee_payrolls.status', 0)
            ->orderByDesc('egc_payroll_processes.payroll_end_date')
            ->select('egc_payroll_employee_payrolls.*')
            ->first();

        $latestIncentiveAmount = 0;
        $latestPayslipLink = null;
        if ($latestPayroll) {
            $latestIncentive = DB::table('egc_payroll_employee_payroll_details')
                ->where('payroll_employee_sno', $latestPayroll->sno)
                ->where('payroll_component_sno', 6)
                ->where('status', 0)
                ->first();
            $latestIncentiveAmount = $latestIncentive->actual_amount ?? 0;

            $paySlip = DB::table('egc_payroll_payslips')
                ->where('payroll_employee_sno', $latestPayroll->sno)
                ->select('sno')
                ->first();

            if ($paySlip) {
                $latestPayslipLink = url(
                    'payroll/payslip_print/' . encrypt($paySlip->sno)
                );
            }
        }
        $recentPayslips = DB::table('egc_payroll_employee_payrolls')
            ->join(
                'egc_payroll_processes',
                'egc_payroll_processes.sno',
                '=',
                'egc_payroll_employee_payrolls.payroll_process_sno'
            )
            ->leftJoin('egc_payroll_payslips','egc_payroll_payslips.payroll_employee_sno', '=','egc_payroll_employee_payrolls.sno')
            ->where('egc_payroll_employee_payrolls.staff_id', $user->sno)
            ->where('egc_payroll_employee_payrolls.status', 0)
            ->select(
                'egc_payroll_employee_payrolls.payroll_month',
                'egc_payroll_employee_payrolls.payroll_year',
                'egc_payroll_employee_payrolls.net_payable',
                'egc_payroll_processes.payroll_end_date',
                'egc_payroll_processes.created_at',
                'egc_payroll_payslips.sno as payslip_id'
            )
            ->orderByDesc('egc_payroll_processes.payroll_end_date')
            ->limit(10)
            ->get();

        $recentData = [];

        foreach ($recentPayslips as $payslip) {

            $recentData[] = [
                'id' => $payslip->payslip_id,
                'month' => date('F', mktime(0, 0, 0, $payslip->payroll_month, 1)),
                'year' => (int) $payslip->payroll_year,
                'net_pay' => round($payslip->net_payable),
                'created_date' => date('M d',strtotime($payslip->created_at)),
            ];
        }


        $data = [
            'latest_net_pay' => round($latestPayroll->net_payable ?? 0),
            'format_month' =>$latestPayroll->payroll_month ? date('F', mktime(0, 0, 0, $latestPayroll->payroll_month, 1)) : NULL, 
            'latest_payslip_month' => $latestPayroll->payroll_month ?? null,
            'latest_payslip_year' => $latestPayroll->payroll_year ?? null,
            'latest_gross' => round($latestPayroll->fixed_salary ?? 0),
            'latest_deduction' => round($latestPayroll->gross_deductions ?? 0),
            'latest_incentive' => round($latestIncentiveAmount),
            'latest_payslip_link' => $latestPayslipLink,
            'recent_payslips' => $recentData
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Payslip list fetched successfully',
            'data' => $data
        ]);

    } catch (\Exception $e) {
        Log::error('Payslip List Error', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'user_id' => optional($request->user())->user_id
        ]);
        return response()->json([
            'status' => 500,
            'message' => 'Server Error '.$e->getMessage(),
            'data' => null
        ], 500);
    }
}


/**
 * @OA\Get(
 *     path="/get_staff_payslip_detail_by_id",
 *     summary="Get Staff Payslip Detail",
 *     description="Fetch detailed payslip information for the logged-in employee.",
 *     operationId="getStaffPayslipDetailById",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *
 *     @OA\Parameter(
 *         name="payslip_id",
 *         in="query",
 *         required=true,
 *         description="Payslip ID",
 *         @OA\Schema(
 *             type="integer",
 *             example=1
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=200,
 *         description="Payslip details fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=200),
 *             @OA\Property(property="message", type="string", example="Payslip details fetched successfully"),
 *
 *             @OA\Property(
 *                 property="data",
 *                 type="object",
 *
 *                 @OA\Property(property="payslip_id", type="integer", example=1),
 *
 *                 @OA\Property(
 *                     property="employee",
 *                     type="object",
 *                     @OA\Property(property="name", type="string", example="Alagu Akilan K"),
 *                     @OA\Property(property="staff_code", type="string", example="EGC04063"),
 *                     @OA\Property(property="department", type="string", example="Production"),
 *                     @OA\Property(property="division", type="string", example="Development"),
 *                     @OA\Property(property="job_role", type="string", example="Full Stack Developer")
 *                 ),
 *
 *                 @OA\Property(
 *                     property="pay_period",
 *                     type="object",
 *                     @OA\Property(property="month", type="integer", example=1),
 *                     @OA\Property(property="year", type="integer", example=2026),
 *                     @OA\Property(property="generated_at", type="string", example="04 Jun 2026")
 *                 ),
 *
 *                 @OA\Property(
 *                     property="company",
 *                     type="object",
 *                     @OA\Property(property="name", type="string", example="Elysian Intelligence Business Solution"),
 *                     @OA\Property(property="base_color", type="string", example="#3c2289"),
 *                     @OA\Property(property="logo", type="string", nullable=true, example="https://domain.com/company/logo/company_2.jpg")
 *                 ),
 *
 *                 @OA\Property(
 *                     property="bank_details",
 *                     type="object",
 *                     @OA\Property(property="bank_name", type="string", nullable=true, example="HDFC Bank"),
 *                     @OA\Property(property="account_number", type="string", nullable=true, example="XXXX1234")
 *                 ),
 *
 *                 @OA\Property(
 *                     property="summary",
 *                     type="object",
 *                     @OA\Property(property="gross_earnings", type="number", format="float", example=14000),
 *                     @OA\Property(property="total_deductions", type="number", format="float", example=1094),
 *                     @OA\Property(property="net_payable", type="number", format="float", example=12906)
 *                 ),
 *
 *                 @OA\Property(
 *                     property="earnings",
 *                     type="array",
 *                     @OA\Items(
 *                         type="object",
 *                         @OA\Property(property="component_name", type="string", example="Basic Salary"),
 *                         @OA\Property(property="amount", type="number", format="float", example=5600),
 *                         @OA\Property(property="calculation_type", type="string", example="percentage")
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="deductions",
 *                     type="array",
 *                     @OA\Items(
 *                         type="object",
 *                         @OA\Property(property="component_name", type="string", example="Provident Fund"),
 *                         @OA\Property(property="amount", type="number", format="float", example=780),
 *                         @OA\Property(property="calculation_type", type="string", example="percentage")
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="employer_contributions",
 *                     type="array",
 *                     @OA\Items(
 *                         type="object",
 *                         @OA\Property(property="component_name", type="string", example="Employer PF"),
 *                         @OA\Property(property="amount", type="number", format="float", example=1008),
 *                         @OA\Property(property="calculation_type", type="string", example="formula")
 *                     )
 *                 ),
 *
 *                 @OA\Property(
 *                     property="payslip_template_url",
 *                     type="string",
 *                     nullable=true,
 *                     example="https://domain.com/settings/payslip_template/template.jpg"
 *                 )
 *             )
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=404,
 *         description="Payslip not found",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=404),
 *             @OA\Property(property="message", type="string", example="Payslip not found"),
 *             @OA\Property(property="data", type="object", nullable=true)
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=422,
 *         description="Validation Error",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=422),
 *             @OA\Property(property="message", type="string", example="Validation failed")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=401,
 *         description="Unauthorized",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=401),
 *             @OA\Property(property="message", type="string", example="Unauthorized")
 *         )
 *     ),
 *
 *     @OA\Response(
 *         response=500,
 *         description="Server Error",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=500),
 *             @OA\Property(property="message", type="string", example="Server Error")
 *         )
 *     )
 * )
 */
public function getStaffPayslipDetailById(Request $request)
{
    $validator = Validator::make($request->all(), [
        'payslip_id' => 'required|integer'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation failed',
            'errors' => $validator->errors()
        ], 422);
    }
    try {

        $user = $request->user();
        $staff = StaffModel::where('sno', $user->sno)
            ->where('status', '!=', 2)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'data' => null
            ], 404);
        }

        $payslip = DB::table('egc_payroll_payslips as p')
            ->join('egc_staff as s', 's.sno', '=', 'p.employee_sno')
            ->join('egc_payroll_processes as pp', 'pp.sno', '=', 'p.payroll_process_sno')
            ->join('egc_payroll_employee_payrolls as pep', 'pep.sno', '=', 'p.payroll_employee_sno')
            ->leftJoin('egc_staff_bank_details as bd', 'bd.staff_id', '=', 's.sno')
            ->leftJoin('egc_company as company', 'company.sno', '=', 's.company_id')
            ->leftJoin('egc_company as salary_company', 'salary_company.sno', '=', 's.salary_company_id')
            ->leftJoin('egc_department', 's.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 's.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 's.job_role_id', '=', 'egc_job_role.sno')
            ->where('p.sno', $request->payslip_id)
            ->where('p.employee_sno', $user->sno)
            ->select(
                'p.sno',
                'p.payroll_employee_sno',

                's.staff_name',
                's.staff_id',
                's.company_type',
                's.basic_salary',

                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name',

                'bd.bank_name',
                'bd.bank_account_no',

                'company.company_name',
                'company.company_base_color',
                'company.company_logo',
                'company.company_favicon',

                'salary_company.company_name as salary_company_name',
                'salary_company.company_base_color as salary_company_color',
                'salary_company.company_logo as salary_company_logo',
                'salary_company.company_favicon as salary_company_favicon',

                'pep.gross_earnings',
                'pep.gross_deductions',
                'pep.net_payable',

                'pp.payroll_month',
                'pp.payroll_year',

                'p.generated_date'
            )
            ->first();

        if (!$payslip) {
            return response()->json([
                'status' => 404,
                'message' => 'Payslip not found',
                'data' => null
            ], 404);
        }

        $template = DB::table('egc_payslip_template')
            ->where('status', 0)
            ->where('company_id', $staff->salary_company_id)
            ->first();

        $templateUrl = $template && $template->payslip_template
            ? asset('settings/payslip_template/' . $template->payslip_template)
            : asset('assets/egc_images/payslip_bg.jpg');

        $components = DB::table('egc_payroll_employee_payroll_details as d')
            ->join(
                'egc_payroll_components as c',
                'c.sno',
                '=',
                'd.payroll_component_sno'
            )
            ->where('d.payroll_employee_sno', $payslip->payroll_employee_sno)
            ->where('d.status', 0)
            ->select(
                'c.component_name',
                'c.calculation_type',
                'd.component_category',
                'd.actual_amount'
            )
            ->get();

        $earnings = [];
        $deductions = [];

        foreach ($components as $component) {

            $item = [
                'component_name' => $component->component_name,
                'amount' => (float) $component->actual_amount,
            ];

            if ($component->component_category == 'earning') {
                $earnings[] = $item;
            } elseif ($component->component_category == 'deduction') {
                $deductions[] = $item;
            }
        }

       
                $PayslipLink = url(
                    'payroll/payslip_print/' . encrypt($request->payslip_id)
                );

        $data = [
            'payslip_id' => $payslip->sno,

            'employee' => [
                'name' => $payslip->staff_name,
                'staff_code' => $payslip->staff_id,
                'department' => $payslip->department_name,
                'division' => $payslip->division_name,
                'job_role' => $payslip->job_role_name,
                'level' => 'L1',
                'format_month'  => $payslip->payroll_month ? date('F', mktime(0, 0, 0, $payslip->payroll_month, 1)) : NULL,
                'month' => (int) $payslip->payroll_month,
                'year' => (int) $payslip->payroll_year,
            ],

            'company' => [
                'name' => $payslip->salary_company_name ?? $payslip->company_name,
                'base_color' => $payslip->salary_company_color ?? $payslip->company_base_color,
            ],
            'summary' => [
                'gross_earnings' => (float) $payslip->gross_earnings,
                'total_deductions' => (float) $payslip->gross_deductions,
                'net_payable' => (float) $payslip->net_payable,
            ],

            'earnings' => $earnings,
            'deductions' => $deductions,
            'payslip_url' => $PayslipLink,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Payslip details fetched successfully',
            'data' => $data
        ]);

    } catch (\Exception $e) {

        Log::error('Payslip Detail Error', [
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
            'user_id' => optional($request->user())->user_id
        ]);

        return response()->json([
            'status' => 500,
            'message' => 'Server Error',
            'data' => null
        ], 500);
    }
}


/**
     * @OA\Get(
     *     path="/get_hr_support_category_list",
     *     summary="Get HR Support Category List",
     *     description="Fetch all active support categories under the HR department.",
     *     operationId="getHrSupportCategoryList",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Response(
     *         response=200,
     *         description="HR support categories fetched successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="HR support categories fetched successfully"),
     *             @OA\Property(property="data", type="array", @OA\Items(
     *                 type="object",
     *                 @OA\Property(property="sno", type="integer", example=1),
     *                 @OA\Property(property="department_id", type="integer", example=1),
     *                 @OA\Property(property="category_code", type="string", example="HR-LEAVE"),
     *                 @OA\Property(property="category_name", type="string", example="Leave Management"),
     *                 @OA\Property(property="description", type="string", nullable=true),
     *                 @OA\Property(property="allow_attachment", type="boolean", example=true),
     *                 @OA\Property(property="is_approval_required", type="boolean", example=false),
     *                 @OA\Property(property="display_order", type="integer", example=1)
     *             ))
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Token invalid or expired")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */

    public function getHrSupportCategoryList(Request $request)
    {
        try {

            $user = $request->user();

            if (!$user) {
                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $categories = DB::table('egc_support_category as sc')
                ->select(
                    'sc.sno',
                    'sc.department_id',
                    'sc.category_code',
                    'sc.category_name',
                    'sc.description',
                    'sc.allow_attachment',
                    'sc.is_approval_required',
                    'sc.display_order'
                )
                ->join('egc_support_department as sd', 'sd.sno', '=', 'sc.department_id')
                ->where('sd.status', 0)
                ->where('sc.status', 0)
                ->where('sd.department_code', 'HR')
                ->orderBy('sc.display_order')
                ->orderBy('sc.category_name')
                ->get();

            return response()->json([
                'status' => 200,
                'message' => 'HR support categories fetched successfully',
                'data' => $categories
            ]);
        } catch (\Exception $e) {

            \Log::error('HR Support Category List Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }

    /**
     * @OA\Get(
     *     path="/get_hr_department_ticket_list",
     *     summary="Get HR Department Support Ticket List",
     *     description="Fetch active support tickets for the logged-in staff member under the HR department.",
     *     operationId="getHrDepartmentTicketList",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Response(
     *         response=200,
     *         description="HR department tickets fetched successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="HR department tickets fetched successfully"),
     *             @OA\Property(property="data", type="array", @OA\Items(
     *                 type="object",
     *                 @OA\Property(property="sno", type="integer", example=1),
     *                 @OA\Property(property="ticket_no", type="string", example="TKT-000001"),
     *                 @OA\Property(property="subject", type="string", example="Leave application issue"),
     *                 @OA\Property(property="priority", type="string", example="Medium"),
     *                 @OA\Property(property="status", type="string", example="Open"),
     *                 @OA\Property(property="department_name", type="string", example="Human Resources"),
     *                 @OA\Property(property="category_name", type="string", example="Leave Management"),
     *                 @OA\Property(property="assigned_to_name", type="string", nullable=true),
     *                 @OA\Property(property="created_at", type="string", format="date-time"),
     *                 @OA\Property(property="last_activity_at", type="string", format="date-time")
     *             ))
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Token invalid or expired")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */

    public function getHrDepartmentTicketList(Request $request)
    {
        try {

            $user = $request->user();

            if (!$user) {
                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $tickets = DB::table('egc_support_ticket as st')
                ->select(
                    'st.sno',
                    'st.ticket_no',
                    'st.subject',
                    'st.priority',
                    'st.status',
                    'sd.department_name',
                    'sc.category_name',
                    DB::raw('CONCAT_WS(" ", assigned_staff.staff_name) as assigned_to_name'),
                    'st.created_at',
                    'st.last_activity_at'
                )
                ->leftJoin('egc_support_department as sd', 'sd.sno', '=', 'st.department_id')
                ->leftJoin('egc_support_category as sc', 'sc.sno', '=', 'st.category_id')
                ->leftJoin('egc_staff as assigned_staff', 'assigned_staff.sno', '=', 'st.assigned_to')
                ->where('st.staff_id', $user->sno)
                ->where('st.status_flag', 0)
                ->where('sd.department_code', 'HR')
                ->orderByDesc('st.last_activity_at')
                ->orderByDesc('st.sno')
                ->get();

            return response()->json([
                'status' => 200,
                'message' => 'HR department tickets fetched successfully',
                'data' => $tickets
            ]);
        } catch (\Exception $e) {

            \Log::error('HR Department Ticket List Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }

    
    /**
     * @OA\Post(
     *     path="/add_hr_support_ticket",
     *     summary="Add HR Support Ticket",
     *     description="Create a new support ticket under the HR department.",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"category_id","subject"},
     *             @OA\Property(property="category_id", type="integer", example=1),
     *             @OA\Property(property="subject", type="string", example="Leave application issue"),
     *             @OA\Property(property="description", type="string", nullable=true, example="Unable to apply for leave"),
     *             @OA\Property(property="priority", type="string", example="Medium")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="HR support ticket created successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="HR support ticket created successfully"),
     *             @OA\Property(property="data", type="object")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation Error"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */
    public function addHrSupportTicket(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_id' => 'required|integer',
            'subject' => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority' => 'nullable|string|max:50',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = $request->user();
            $staff = StaffModel::where('sno', $user->sno)->first();

            if (!$staff) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Staff not found'
                ], 404);
            }

            $hrDepartment = DB::table('egc_support_department')
                ->where('department_code', 'HR')
                ->where('status', 0)
                ->first();

            if (!$hrDepartment) {
                return response()->json([
                    'status' => 500,
                    'message' => 'HR department not configured'
                ], 500);
            }

            $category = DB::table('egc_support_category')
                ->where('sno', $request->category_id)
                ->where('department_id', $hrDepartment->sno)
                ->where('status', 0)
                ->first();

            if (!$category) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Invalid support category'
                ], 404);
            }

            $lastTicket = DB::table('egc_support_ticket')
                ->where('department_id', $hrDepartment->sno)
                ->orderByDesc('sno')
                ->first();

            $runningNo = 1;
            if ($lastTicket && $lastTicket->ticket_no) {
                preg_match('/TKT-(\d+)/', $lastTicket->ticket_no, $matches);
                if (!empty($matches[1])) {
                    $runningNo = (int)$matches[1] + 1;
                }
            }

            $ticketNo = 'TKT-' . str_pad($runningNo, 6, '0', STR_PAD_LEFT);

            DB::table('egc_support_ticket')->insert([
                'ticket_no' => $ticketNo,
                'staff_id' => $user->sno,
                'staff_name' => $staff->staff_name,
                'department_id' => $hrDepartment->sno,
                'category_id' => $request->category_id,
                'subject' => $request->subject,
                'description' => $request->description,
                'priority' => $request->priority ?? 'Medium',
                'assigned_to'=>$hrDepartment->default_assignee_id,
                'assigned_at'=>$hrDepartment->default_assignee_id
                        ? Carbon::now('Asia/Kolkata')
                        : null,
                'sla_response_hours'=>$hrDepartment->sla_response_hours,
                'sla_resolution_hours'=>$hrDepartment->sla_resolution_hours,
                'status_flag' => 0,
                'created_by' => $user->sno,
                'created_at' => Carbon::now('Asia/Kolkata'),
                'updated_by' => $user->sno,
                'updated_at' => Carbon::now('Asia/Kolkata'),
                'last_activity_at' => Carbon::now('Asia/Kolkata'),
            ]);

            return response()->json([
                'status' => 200,
                'message' => 'HR support ticket created successfully',
                'data' => [
                    'ticket_no' => $ticketNo,
                    'subject' => $request->subject,
                    'category_name' => $category->category_name,
                    'department_name' => $hrDepartment->department_name,
                    'priority' => $request->priority ?? 'Medium',
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Add HR Support Ticket Error', [
                'message' => $e->getMessage(),
                'line' => $e->getLine(),
                'user_id' => optional($request->user())->user_id
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong. Please try again later. '.$e->getMessage()
            ], 500);
        }
    }

     /**
     * @OA\Get(
     *     path="/get_training_list",
     *     summary="Get Staff Training List",
     *     description="Fetch all active training programs assigned or available to the logged-in staff.",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="upcoming",
     *         in="query",
     *         required=false,
     *         description="Set to 1 to fetch only upcoming trainings. Defaults to all.",
     *         @OA\Schema(type="integer", example=1)
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Training list fetched successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Training list fetched successfully"),
     *             @OA\Property(property="data", type="array", @OA\Items(
     *                 type="object",
     *                 @OA\Property(property="sno", type="integer", example=1),
     *                 @OA\Property(property="training_planner_name", type="string", example="React Advanced"),
     *                 @OA\Property(property="training_mode", type="string", example="Online"),
     *                 @OA\Property(property="trainer_name", type="string", example="John Doe"),
     *                 @OA\Property(property="schedule_date", type="string", example="2026-04-20"),
     *                 @OA\Property(property="training_duration", type="string", example="2 days"),
     *                 @OA\Property(property="training_desc", type="string", nullable=true)
     *             ))
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */
    public function trainingList(Request $request)
     {
         try {
             $user = $request->user();

             $staff = StaffModel::where('sno', $user->sno)
                 ->where('status', '!=', 2)
                 ->first();

             if (!$staff) {
                 return response()->json([
                     'status' => 401,
                     'message' => 'Unauthorized'
                 ], 401);
             }

             $upcoming = $request->upcoming == 1;

             $query = TrainingPlannerModel::where('status', 0)
                 ->orderByDesc('sno');

             if ($upcoming) {
                 $query->whereDate(DB::raw('COALESCE(schedule_to_date, schedule_date)'), '>=', now()->toDateString());
             }
             return $user->sno;

             $trainings = $query->get()
                 ->filter(function ($training) use ($user) {
                     if ($training->all_check == 1) {
                         return true;
                     }
                     $staffIds = $training->staff_check ?: [];
                     if (is_string($staffIds)) {
                         $staffIds = json_decode($staffIds, true) ?? [];
                     }
                     return in_array((string)$user->sno, array_map('strval', $staffIds));
                 })
                 ->values()
                 ->map(function ($training) {
                     $trainerName = (int) $training->trainer > 0
                         ? (StaffModel::find($training->trainer)->staff_name ?? $training->trainer_name ?? '-')
                         : ($training->trainer_name ?: 'External Trainer');

                     $fromDate = $training->schedule_from_date ?: $training->schedule_date;
                     $toDate = $training->schedule_to_date ?: $training->schedule_date;

                     return [
                         'sno' => (int) $training->sno,
                         'training_planner_id' => $training->training_planner_id,
                         'training_planner_name' => $training->training_planner_name,
                         'training_mode' => (int) $training->training_mode,
                         'training_mode_label' => [1 => 'Online', 2 => 'Offline', 3 => 'Video'][$training->training_mode] ?? 'Unknown',
                         'trainer' => (int) $training->trainer,
                         'trainer_name' => $trainerName,
                         'training_duration' => (float) $training->training_duration,
                         'schedule_type' => $training->schedule_type ?: 'range',
                         'from_date' => $fromDate,
                         'to_date' => $toDate,
                         'from_time' => $training->schedule_from_time ?: $training->schedule_time,
                         'to_time' => $training->schedule_to_time,
                         'training_desc' => $training->training_desc,
                         'planner_status' => $training->planner_status ?: 'scheduled',
                         'all_attendees' => (bool) $training->all_check,
                         'certificate_available' => (bool) $training->certificate_available,
                         'assessment_required' => (bool) $training->assessment_required,
                         'certificate_name' => $training->certificate_name,
                         'assessment_pass_percentage' => $training->assessment_pass_percentage !== null ? (float) $training->assessment_pass_percentage : null,
                     ];
                 });

             return response()->json([
                 'status' => 200,
                 'message' => 'Training list fetched successfully',
                 'data' => $trainings
             ]);

         } catch (\Exception $e) {
             Log::error('Training List Error', [
                 'message' => $e->getMessage(),
                 'line' => $e->getLine(),
                 'user_id' => optional($request->user())->user_id
             ]);

             return response()->json([
                 'status' => 500,
                 'message' => 'Server Error'
             ], 500);
         }
     }


 
  public function StudentDailyCheck(Request $request)
    {
        $studentId = $request->customer_id; // passed from app

        if (!$studentId) {
            return response()->json([
                'status' => 422,
                'message' => 'Student ID is required',
                'data' => null,
            ], 422);
        }

        $student = DB::table('za_customer')->where('sno', $studentId)->where('status', 0)->first();

        if (!$student) {
            return response()->json([
                'status' => 0,
                'message' => 'Student not found',
                'data' => null,
            ], 200);
        }

        $today = date('Y-m-d');

        $alreadyExists = DB::table('za_students_points')
            ->where('student_id', $studentId)
            ->whereDate('created_at', $today)
            ->where('reason', 'Student Login')
            ->where('status', 0)
            ->exists();

        if (!$alreadyExists) {
            // Insert daily points
            DB::table('za_students_points')->insert([
                'branch_id'   => $student->branch_id ?? 0,
                'student_id'  => $student->sno,
                'points_id'   => 0,
                'points'      => 1,
                'reason'      => 'Student Login',
                'created_at'  => now(),
                'updated_at'  => now(),
                'status'      => 0,
            ]);

            // ✅ Send notification only when points are added
            $this->sendNotification(
                $student->branch_id,
                $student->sno,
                "Your daily login coin reward added successfully",
                "Student App",
                $studentId
            );
        }

        return response()->json([
            'status' => $alreadyExists ? 1 : 0,
            'message' => $alreadyExists ? 'Already rewarded today' : '1 Point added for today',
            'data' => [
                'student_id' => $studentId,
                'date' => $today,
            ],
        ], 200);
    }
 
    /**
     * @OA\Post(
     *     path="/update_staff_face_id",
     *     summary="Update Staff Face Id",
     *     description="Update Staff FaceId",
     *     operationId="UpdateFaceId",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *
     *     @OA\Response(
     *         response=200,
     *         description="Update Face Id Successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Update Staff Face Id Successfully")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=401),
     *             @OA\Property(property="message", type="string", example="Unauthorized")
     *         )
     *     ),
     *
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */


    public function UpdateFaceId(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->sno)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $validator = Validator::make($request->all(), [
                'face_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 422,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $face_id = $request->face_id;

            $staff->face_id = $face_id;
            $staff->save();
            

            return response()->json([
                'status' => 200,
                'message' => 'Update Staff Face Id Successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Update Staff Face Id Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }
   

     /**
     * @OA\Post(
     *     path="/close_support_ticket",
     *     summary="Close Support Ticket",
     *     description="Close a support ticket by ticket ID.",
     *     operationId="closeSupportTicket",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"ticket_id"},
     *             @OA\Property(property="ticket_id", type="integer", example=1, description="Ticket sno (primary key)")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Ticket closed successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Ticket closed successfully")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Ticket not found or does not belong to you"
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation Error"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */
    public function closeSupportTicket(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'ticket_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = $request->user();

            $ticket = DB::table('egc_support_ticket')
                ->where('sno', $request->ticket_id)
                ->where('staff_id', $user->sno)
                ->where('status_flag', 0)
                ->first();

            if (!$ticket) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Ticket not found or already closed'
                ], 404);
            }

            DB::table('egc_support_ticket')
                ->where('sno', $request->ticket_id)
                ->update([
                    'status_flag' => 1,
                    'closed_at' => Carbon::now('Asia/Kolkata'),
                    'updated_by' => $user->sno,
                    'updated_at' => Carbon::now('Asia/Kolkata'),
                ]);

            return response()->json([
                'status' => 200,
                'message' => 'Ticket closed successfully',
            ]);

        } catch (\Exception $e) {

            \Log::error('Close Support Ticket Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }

    /**
     * @OA\Get(
     *     path="/get_ticket_details_by_id",
     *     summary="Get Ticket Details by Ticket ID",
     *     description="Fetch complete details of a specific support ticket by its ticket ID.",
     *     operationId="getTicketDetailsById",
     *     tags={"Employee"},
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="ticket_id",
     *         in="query",
     *         required=true,
     *         description="Ticket sno (primary key)",
     *         @OA\Schema(type="integer", example=1)
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Ticket details fetched successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="Ticket details fetched successfully"),
     *             @OA\Property(
     *                 property="data",
     *                 type="object",
     *                 @OA\Property(property="sno", type="integer", example=1),
     *                 @OA\Property(property="ticket_no", type="string", example="TKT-000001"),
     *                 @OA\Property(property="staff_id", type="integer", example=10),
     *                 @OA\Property(property="staff_name", type="string", example="John Doe"),
     *                 @OA\Property(property="subject", type="string", example="Leave application issue"),
     *                 @OA\Property(property="description", type="string", nullable=true),
     *                 @OA\Property(property="priority", type="string", example="Medium"),
     *                 @OA\Property(property="status", type="string", example="Open"),
     *                 @OA\Property(property="status_flag", type="integer", example=0),
     *                 @OA\Property(property="department_name", type="string", example="Human Resources"),
     *                 @OA\Property(property="category_name", type="string", example="Leave Management"),
     *                 @OA\Property(property="assigned_to_name", type="string", nullable=true),
     *                 @OA\Property(property="assigned_at", type="string", format="date-time", nullable=true),
     *                 @OA\Property(property="is_reopened", type="integer", example=0),
     *                 @OA\Property(property="reopened_count", type="integer", example=0),
     *                 @OA\Property(property="first_response_at", type="string", format="date-time", nullable=true),
     *                 @OA\Property(property="resolved_at", type="string", format="date-time", nullable=true),
     *                 @OA\Property(property="closed_at", type="string", format="date-time", nullable=true),
     *                 @OA\Property(property="sla_response_hours", type="integer", example=4),
     *                 @OA\Property(property="sla_resolution_hours", type="integer", example=24),
     *                 @OA\Property(property="is_sla_breached", type="integer", example=0),
     *                 @OA\Property(property="staff_rating", type="integer", nullable=true),
     *                 @OA\Property(property="staff_feedback", type="string", nullable=true),
     *                 @OA\Property(property="last_reply_by", type="integer", nullable=true),
     *                 @OA\Property(property="last_reply_at", type="string", format="date-time", nullable=true),
     *                 @OA\Property(property="last_activity_at", type="string", format="date-time"),
     *                 @OA\Property(property="created_at", type="string", format="date-time"),
     *                 @OA\Property(property="updated_at", type="string", format="date-time")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Ticket not found"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Server Error"
     *     )
     * )
     */
    public function getTicketDetailsById(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'ticket_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = $request->user();

            $ticket = DB::table('egc_support_ticket as st')
                ->select(
                    'st.sno',
                    'st.ticket_no',
                    'st.staff_id',
                    'st.staff_name',
                    'st.subject',
                    'st.description',
                    'st.priority',
                    'st.status',
                    'st.status_flag',
                    'st.assigned_to',
                    'st.assigned_at',
                    'st.is_reopened',
                    'st.reopened_count',
                    'st.first_response_at',
                    'st.resolved_at',
                    'st.closed_at',
                    'st.sla_response_hours',
                    'st.sla_resolution_hours',
                    'st.is_sla_breached',
                    'st.staff_rating',
                    'st.staff_feedback',
                    'st.last_reply_by',
                    'st.last_reply_at',
                    'st.last_activity_at',
                    'st.created_at',
                    'st.updated_at',
                    'sd.department_name',
                    'sc.category_name',
                    DB::raw('CONCAT_WS(" ", assigned_staff.staff_name) as assigned_to_name')
                )
                ->leftJoin('egc_support_department as sd', 'sd.sno', '=', 'st.department_id')
                ->leftJoin('egc_support_category as sc', 'sc.sno', '=', 'st.category_id')
                ->leftJoin('egc_staff as assigned_staff', 'assigned_staff.sno', '=', 'st.assigned_to')
                ->where('st.sno', $request->ticket_id)
                ->where('st.staff_id', $user->sno)
                ->first();

            if (!$ticket) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Ticket not found'
                ], 404);
            }

            return response()->json([
                'status' => 200,
                'message' => 'Ticket details fetched successfully',
                'data' => $ticket
            ]);

        } catch (\Exception $e) {

            \Log::error('Get Ticket Details Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }
  
  
}