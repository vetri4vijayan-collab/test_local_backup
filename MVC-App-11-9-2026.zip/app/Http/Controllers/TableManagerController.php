<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Symfony\Component\HttpFoundation\StreamedResponse;

class TableManagerController extends Controller
{
  public function index(Request $request)
  {
    return view('content.settings.Base.data.data_base');
  }

  /**
   * Get all database tables
   */
  public function getTables()
  {
    try {
      $tables = DB::select('SHOW TABLES');
      $tableNames = array_map('current', $tables);

      return response()->json([
        'success' => true,
        'tables' => $tableNames
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => 'Failed to fetch tables: ' . $e->getMessage()
      ], 500);
    }
  }

  /**
   * Get table data with pagination and optional column filters
   */
  public function getTableData(Request $request)
  {
    try {
      $table = $request->input('table');
      $page = $request->input('page', 1);
      $limit = $request->input('limit', 10);
      $offset = ($page - 1) * $limit;
      $columnFilters = $request->input('column_filters', []);

      if (empty($table)) {
        throw new \Exception('Table name is required');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Get table columns
      $columns = Schema::getColumnListing($table);

      // Check if table has id column
      $hasIdColumn = in_array('sno', $columns);

      // Build query
      $query = DB::table($table);

      // Apply column filters
      if (!empty($columnFilters)) {
        foreach ($columnFilters as $column => $value) {
          if (in_array($column, $columns)) {
            $query->where($column, 'LIKE', "%{$value}%");
          }
        }
      }

      // Get total records count
      $totalRecords = $query->count();

      // Order by id if exists, otherwise order by first column
      if ($hasIdColumn) {
        $query->orderBy('sno', 'asc');
      } else {
        $query->orderBy($columns[0], 'asc');
      }

      $data = $query->skip($offset)->take($limit)->get();

      $totalPages = ceil($totalRecords / $limit);

      return response()->json([
        'success' => true,
        'columns' => $columns,
        'data' => $data,
        'pagination' => [
          'current_page' => (int)$page,
          'total_pages' => $totalPages,
          'total_records' => $totalRecords,
          'start' => $offset + 1,
          'end' => min($offset + $limit, $totalRecords),
          'limit' => $limit
        ]
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Update single cell value
   */
  public function updateCell(Request $request)
  {
    try {
      $table = $request->input('table');
      $id = $request->input('id');
      $column = $request->input('column');
      $value = $request->input('value');

      if (empty($table) || empty($id) || empty($column)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Validate column exists
      if (!Schema::hasColumn($table, $column)) {
        throw new \Exception('Column does not exist');
      }

      // Validate id column exists
      if (!Schema::hasColumn($table, 'sno')) {
        throw new \Exception('Table must have an id column for updates');
      }

      // Update record
      $updated = DB::table($table)
        ->where('sno', $id)
        ->update([$column => $value]);

      if ($updated) {
        return response()->json([
          'success' => true,
          'message' => 'Record updated successfully'
        ]);
      } else {
        return response()->json([
          'success' => false,
          'message' => 'No changes made or record not found'
        ], 400);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Update entire row
   */
  public function updateRow(Request $request)
  {
    try {
      $table = $request->input('table');
      $id = $request->input('id');
      $data = $request->input('data', []);

      if (empty($table) || empty($id) || empty($data)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Validate id column exists
      if (!Schema::hasColumn($table, 'sno')) {
        throw new \Exception('Table must have an sno column for updates');
      }

      // Validate columns exist
      foreach (array_keys($data) as $column) {
        if (!Schema::hasColumn($table, $column)) {
          throw new \Exception("Column '$column' does not exist");
        }
      }

      // Update record
      $updated = DB::table($table)
        ->where('sno', $id)
        ->update($data);

      if ($updated) {
        return response()->json([
          'success' => true,
          'message' => 'Row updated successfully'
        ]);
      } else {
        return response()->json([
          'success' => false,
          'message' => 'No changes made or record not found'
        ], 400);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Delete record
   */
  public function deleteRecord(Request $request)
  {
    try {
      $table = $request->input('table');
      $id = $request->input('id');

      if (empty($table) || empty($id)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Validate id column exists
      if (!Schema::hasColumn($table, 'sno')) {
        throw new \Exception('Table must have an id column for deletion');
      }

      // Delete record
      $deleted = DB::table($table)
        ->where('sno', $id)
        ->delete();

      if ($deleted) {
        return response()->json([
          'success' => true,
          'message' => 'Record deleted successfully'
        ]);
      } else {
        return response()->json([
          'success' => false,
          'message' => 'Record not found'
        ], 404);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Add new record
   */
  public function addRecord(Request $request)
  {
    try {
      $table = $request->input('table');
      $data = $request->input('data', []);

      if (empty($table) || empty($data)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Validate columns exist
      foreach (array_keys($data) as $column) {
        if (!Schema::hasColumn($table, $column)) {
          throw new \Exception("Column '$column' does not exist");
        }
      }

      // Insert new record
      $id = DB::table($table)->insertGetId($data);

      if ($id) {
        return response()->json([
          'success' => true,
          'message' => 'Record added successfully',
          'id' => $id
        ]);
      } else {
        return response()->json([
          'success' => false,
          'message' => 'Failed to add record'
        ], 400);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Search table data with optional column filters
   */
  public function searchTable(Request $request)
  {
    try {
      $table = $request->input('table');
      $search = $request->input('search');
      $page = $request->input('page', 1);
      $limit = $request->input('limit', 10);
      $offset = ($page - 1) * $limit;
      $columnFilters = $request->input('column_filters', []);

      if (empty($table)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Get table columns
      $columns = Schema::getColumnListing($table);

      // Build search query
      $query = DB::table($table);

      // Apply global search if provided
      if (!empty($search)) {
        $query->where(function ($q) use ($columns, $search) {
          foreach ($columns as $column) {
            $q->orWhere($column, 'LIKE', "%{$search}%");
          }
        });
      }

      // Apply column filters
      if (!empty($columnFilters)) {
        foreach ($columnFilters as $column => $value) {
          if (in_array($column, $columns)) {
            $query->where($column, 'LIKE', "%{$value}%");
          }
        }
      }

      // Get total records count
      $totalRecords = $query->count();

      // Get paginated data
      $data = $query->skip($offset)->take($limit)->get();

      $totalPages = ceil($totalRecords / $limit);

      return response()->json([
        'success' => true,
        'columns' => $columns,
        'data' => $data,
        'pagination' => [
          'current_page' => (int)$page,
          'total_pages' => $totalPages,
          'total_records' => $totalRecords,
          'start' => $offset + 1,
          'end' => min($offset + $limit, $totalRecords),
          'limit' => $limit,
          'search' => $search
        ]
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Export table data
   */
  public function exportTable(Request $request)
  {
    try {
      $table = $request->input('table');
      $format = $request->input('format', 'csv');
      $scope = $request->input('scope', 'all');
      $search = $request->input('search');
      $columnFilters = $request->input('column_filters', []);

      if (empty($table)) {
        throw new \Exception('Table name is required');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Get table columns
      $columns = Schema::getColumnListing($table);

      // Build query
      $query = DB::table($table);

      // Apply filters based on scope
      if ($scope === 'filtered') {
        if (!empty($search)) {
          $query->where(function ($q) use ($columns, $search) {
            foreach ($columns as $column) {
              $q->orWhere($column, 'LIKE', "%{$search}%");
            }
          });
        }

        if (!empty($columnFilters)) {
          foreach ($columnFilters as $column => $value) {
            if (is_array($value)) {
              $value = json_decode(key($value), true);
            }
            if (in_array($column, $columns)) {
              $query->where($column, 'LIKE', "%{$value}%");
            }
          }
        }
      }

      $data = $query->get();

      // Generate export file based on format
      switch ($format) {
        case 'csv':
          return $this->exportCSV($data, $columns, $table);

        case 'excel':
          return $this->exportExcel($data, $columns, $table);

        case 'json':
          return $this->exportJSON($data, $table);

        default:
          throw new \Exception('Invalid export format');
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Export data as CSV
   */
  private function exportCSV($data, $columns, $table)
  {
    $filename = $table . '_' . date('Y-m-d_H-i-s') . '.csv';

    $headers = [
      'Content-Type' => 'text/csv',
      'Content-Disposition' => 'attachment; filename="' . $filename . '"',
      'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
      'Pragma' => 'public'
    ];

    $callback = function () use ($data, $columns) {
      $file = fopen('php://output', 'w');

      // Add headers
      fputcsv($file, $columns);

      // Add data rows
      foreach ($data as $row) {
        $rowData = [];
        foreach ($columns as $column) {
          $rowData[] = $row->$column ?? '';
        }
        fputcsv($file, $rowData);
      }

      fclose($file);
    };

    return response()->stream($callback, 200, $headers);
  }

  /**
   * Export data as Excel
   */
  private function exportExcel($data, $columns, $table)
  {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Add headers
    $col = 'A';
    foreach ($columns as $column) {
      $sheet->setCellValue($col . '1', $column);
      $sheet->getColumnDimension($col)->setAutoSize(true);
      $col++;
    }

    // Style headers
    $headerStyle = [
      'font' => ['bold' => true],
      'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        'startColor' => ['rgb' => '343A40']
      ],
      'font' => [
        'color' => ['rgb' => 'FFFFFF']
      ]
    ];
    $sheet->getStyle('A1:' . ($col - 1) . '1')->applyFromArray($headerStyle);

    // Add data
    $row = 2;
    foreach ($data as $record) {
      $col = 'A';
      foreach ($columns as $column) {
        $sheet->setCellValue($col . $row, $record->$column ?? '');
        $col++;
      }
      $row++;
    }

    $filename = $table . '_' . date('Y-m-d_H-i-s') . '.xlsx';

    $writer = new Xlsx($spreadsheet);

    $response = new StreamedResponse(function () use ($writer) {
      $writer->save('php://output');
    });

    $response->headers->set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    $response->headers->set('Content-Disposition', 'attachment;filename="' . $filename . '"');
    $response->headers->set('Cache-Control', 'max-age=0');

    return $response;
  }

  /**
   * Export data as JSON
   */
  private function exportJSON($data, $table)
  {
    $filename = $table . '_' . date('Y-m-d_H-i-s') . '.json';

    $jsonData = json_encode($data, JSON_PRETTY_PRINT);

    return response()->streamDownload(function () use ($jsonData) {
      echo $jsonData;
    }, $filename, [
      'Content-Type' => 'application/json',
    ]);
  }

  /**
   * Get table structure
   */
  public function getTableStructure(Request $request)
  {
    try {
      $table = $request->input('table');

      if (empty($table)) {
        throw new \Exception('Table name is required');
      }

      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Get CREATE TABLE statement
      $createTable = DB::select("SHOW CREATE TABLE `{$table}`");
      $structure = $createTable[0]->{'Create Table'};

      return response()->json([
        'success' => true,
        'structure' => $structure
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Modify table structure via SQL
   */
  public function modifyTable(Request $request)
  {
    try {
      $table = $request->input('table');
      $sql = $request->input('sql');

      if (empty($table) || empty($sql)) {
        throw new \Exception('Missing required parameters');
      }

      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Security: Only allow ALTER TABLE statements for the specified table
      $sql = trim($sql);
      $sqlUpper = strtoupper($sql);

      // Validate SQL starts with ALTER TABLE
      if (strpos($sqlUpper, 'ALTER TABLE') !== 0) {
        throw new \Exception('Only ALTER TABLE statements are allowed');
      }

      // Extract table name from SQL and verify it matches
      preg_match('/ALTER\s+TABLE\s+`?(\w+)`?/i', $sql, $matches);
      if (isset($matches[1]) && $matches[1] !== $table) {
        throw new \Exception('SQL statement must reference the selected table: ' . $table);
      }

      // Execute the SQL
      DB::statement($sql);

      return response()->json([
        'success' => true,
        'message' => 'Table modified successfully'
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Get column information with types for a table (used for add record examples)
   */
  public function getColumnInfo(Request $request)
  {
    try {
      $table = $request->input('table');
      if (empty($table) || !Schema::hasTable($table)) {
        throw new \Exception('Invalid table');
      }
      $columns = Schema::getColumnListing($table);
      $columnInfo = [];
      foreach ($columns as $column) {
        $columnInfo[] = [
          'name' => $column,
          'type' => Schema::getColumnType($table, $column),
          'nullable' => Schema::getConnection()->getDoctrineColumn($table, $column)->getNotnull() === false,
        ];
      }
      return response()->json(['success' => true, 'columns' => $columnInfo]);
    } catch (\Exception $e) {
      return response()->json(['success' => false, 'message' => $e->getMessage()], 400);
    }
  }

  /**
   * Execute a safe UPDATE query on the selected table
   */
  public function executeUpdateQuery(Request $request)
  {
    try {
      $table = $request->input('table');
      $sql = $request->input('sql');

      if (empty($table) || empty($sql)) {
        throw new \Exception('Missing required parameters');
      }
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      $sql = trim($sql);
      $sqlUpper = strtoupper($sql);

      // Only allow UPDATE statements for the specified table
      if (strpos($sqlUpper, 'UPDATE') !== 0) {
        throw new \Exception('Only UPDATE statements are allowed');
      }

      // Extract table name from SQL and verify it matches the selected table
      preg_match('/UPDATE\s+`?(\w+)`?/i', $sql, $matches);
      if (isset($matches[1]) && $matches[1] !== $table) {
        throw new \Exception('UPDATE statement must reference the selected table: ' . $table);
      }

      // Optional: prevent dangerous updates (e.g., no WHERE clause can be allowed but with warning)
      if (strpos($sqlUpper, 'WHERE') === false) {
        // We allow but the frontend already warns
      }

      DB::statement($sql);

      // Get number of affected rows
      $affected = DB::affectingStatement($sql);
      $message = "UPDATE executed successfully. Affected rows: " . $affected;

      return response()->json(['success' => true, 'message' => $message]);
    } catch (\Exception $e) {
      return response()->json(['success' => false, 'message' => $e->getMessage()], 400);
    }
  }
}
