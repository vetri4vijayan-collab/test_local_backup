<?php

namespace App\Http\Controllers\whatsapp_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
// use App\Models\WhatsappContactModel;
// use App\Models\WhatsappMessageModel;
// use App\Events\NewMessage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http; // Import Http facade
use Carbon\Carbon;

class WhatsappConfig extends Controller
{
    public function WhatsappWebhook(Request $request)
    {
        // $accessToken = 'EAAFb1ehfWDIBO3IxRjM766z6Hyx00dC8MzmepCI5QZC30BjNU4z72nwDmegzVtxZBQKv1o0iyD7HduA4PUtPiA1iZBJvFAcntx2wSiJFU69VKWZBevCW3B0Dbai0RZB4gKFM6ZBycwnD5VUCKL3jTea95GTLBGgGTYm07ihWVngg750IBWeZB7nubdG6Lov4bbdnwZDZD';
        $verfiy_token='2027d0dfea8175ec07b42b2245da10f7egc';
        // Handle verification challenge
        if ($request->method() === 'GET') {
            $mode = $request->query('hub_mode');
            $token = $request->query('hub_verify_token');
            $challenge = $request->query('hub_challenge');
    
            if ($mode === 'subscribe' && $token === $verfiy_token) {
                return response($challenge, 200);
            }
            return response()->json(['error' => 'Verification failed'], 403);
        }
  
    }
}