<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Illuminate\Contracts\Container\BindingResolutionException;
use BadMethodCallException;
use ErrorException;
use Error;

class Handler extends ExceptionHandler
{
    /**
     * The list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }

    public function render($request, Throwable $exception)
    {
        if ($exception instanceof NotFoundHttpException) {
            return response()->view('errors.404', [], 404);
        }

        if ($exception instanceof BadMethodCallException) {
            return response()->view('errors.500', [
                'message' => $exception->getMessage(),
            ], 500);
        }
        if ($exception instanceof ErrorException) {
            return response()->view('errors.500', [
                'message' => $exception->getMessage(),
            ], 500);
        }
        if ($exception instanceof Error) {
            return response()->view('errors.500', [
                'message' => $exception->getMessage(),
            ], 500);
        }

        if ($exception instanceof BindingResolutionException) {
            return response()->view('errors.500', [
                'message' => "Binding Resolution Error: " . $exception->getMessage(),
            ], 500);
        }
        
        if ($exception instanceof HttpException) {
            $status = $exception->getStatusCode();

            // If a view exists for this status code, use it:
            if (view()->exists("errors.$status")) {
                return response()->view("errors.$status", [], $status);
            }
        }

        return parent::render($request, $exception);
    }
}
