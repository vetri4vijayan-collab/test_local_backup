<?php

namespace App\Services\HR;

use App\Models\HR\StaffModel;
use App\Models\HR\StaffProfileDataModel;
use App\Models\HR\StaffRemunerationModel;
use App\Models\HR\StaffRemunerationHistoryModel;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/** HR business rules for staff; controllers must not contain database workflow logic. */
class StaffService
{
    public function __construct(private PayrollCalculationService $payrollCalculationService) {}

    public const TYPE_PERMANENT = 1;
    public const TYPE_CONTRACT = 2;

    public function employmentValue(string $type): int
    {
        if ($type === 'permanent') return self::TYPE_PERMANENT;
        if ($type === 'contract') return self::TYPE_CONTRACT;
        abort(404, 'Unknown staff category.');
    }

    /** Safe reusable scope. staff_type on ryans_staff is NOT the employment category. */
    public function applyCategoryScope($query, string $staffAlias, string $type)
    {
        $employment = $this->employmentValue($type);
        $query->whereRaw(
            "({$staffAlias}.employment_type = ? OR ({$staffAlias}.employment_type IS NULL AND EXISTS (SELECT 1 FROM users hr_user WHERE hr_user.user_id = {$staffAlias}.sno AND hr_user.staff_type = ?)))",
            [$employment, $employment]
        );
        return $query;
    }

    public function applyNotDeletedScope($query, string $staffAlias = 's')
    {
        // Keep original ryans_staff.status untouched for other ERP modules.
        return $query->whereRaw("COALESCE({$staffAlias}.hr_status, CASE WHEN {$staffAlias}.status = 0 THEN 0 WHEN {$staffAlias}.status IN (1,4) THEN 1 WHEN {$staffAlias}.status = 2 THEN 2 WHEN {$staffAlias}.status IN (3,5,6,7) THEN 3 ELSE 3 END) <> 2");
    }

    public function options(): array
    {
        return [
            'relations' => DB::table('ryans_relationship')->where('status', 0)->orderBy('relationship_name')->get(['sno as id', 'relationship_name as name']),
            'blood_groups' => DB::table('rayans_blood_group')->where('status', 0)->orderBy('sno')->get(['sno as id', 'blood_group as name']),
            'departments' => DB::table('ryans_department')->where('status', 0)->orderBy('department_name')->get(['sno as id', 'department_name as name']),
            'designations' => DB::table('rayans_designation')->where('status', 0)->orderBy('designation')->get(['sno as id', 'designation as name']),
            'job_roles' => DB::table('ryans_job_role')->where('status', 0)->orderBy('job_role_name')->get(['sno as id', 'job_role_name as name', 'department_id']),
            'roles' => DB::table('ryans_user_role')->where('status', 0)->orderBy('role_name')->get(['sno as id', 'role_name as name']),
            'languages' => DB::table('ryans_languages')->where('status', 0)->orderBy('name')->get(['sno as id', 'name']),
            'remuneration_types' => DB::table('ryans_renumeration_type')->where('status', 0)->orderBy('sno')->get(['sno as id', 'renumeration_name as name', 'component_type', 'renumeration_desc as description']),
        ];
    }

    public function unclassified(int $perPage = 10)
    {
        $query = StaffModel::query()->from('ryans_staff as s')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id')
            // Include unlinked and conflicting legacy user mappings for explicit HR classification.
            ->whereNull('s.employment_type');
        $this->applyNotDeletedScope($query, 's');
        return $query->orderBy('s.staff_name')->paginate($perPage, [
            's.sno as id', 
            's.staff_id', 
            's.staff_name as name', 
            's.email_id as email',
            's.mobile_no as mobile', 
            'd.department_name as department', 
            'dg.designation as designation', 
            's.status'
        ]);
    }

    public function paginate(string $type, array $filters)
    {
        $query = StaffModel::query()->from('ryans_staff as s')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id');
        $this->applyCategoryScope($query, 's', $type);
        $this->applyNotDeletedScope($query, 's');

        $query->when(($filters['search'] ?? '') !== '', function ($q) use ($filters) {
            $term = trim((string) $filters['search']);
            $q->where(function ($nested) use ($term) {
                $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $term) . '%';
                $nested->where('s.staff_name', 'like', $like)->orWhere('s.staff_id', 'like', $like)
                    ->orWhere('s.email_id', 'like', $like)->orWhere('s.mobile_no', 'like', $like)
                    ->orWhere('d.department_name', 'like', $like)->orWhere('dg.designation', 'like', $like);
            });
        });
        if (!empty($filters['department_id'])) $query->where('s.department_id', (int) $filters['department_id']);
        if (isset($filters['status']) && in_array((int) $filters['status'], [0, 1, 3], true)) {
            $query->whereRaw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN 1 WHEN s.status = 2 THEN 2 WHEN s.status IN (3,5,6,7) THEN 3 ELSE 3 END) = ?", [(int) $filters['status']]);
        }

        $sortMap = [
            'name' => 's.staff_name', 'staff_id' => 's.staff_id', 'email' => 's.email_id',
            'mobile' => 's.mobile_no', 'department' => 'd.department_name', 'designation' => 'dg.designation',
            'wage' => 's.basic_salary', 'status' => DB::raw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN 1 WHEN s.status = 2 THEN 2 WHEN s.status IN (3,5,6,7) THEN 3 ELSE 3 END)"), 'joining_date' => 's.date_of_joining',
        ];
        $sort = $filters['sort'] ?? 'name';
        $direction = strtolower((string) ($filters['direction'] ?? 'asc')) === 'desc' ? 'desc' : 'asc';
        $query->orderBy($sortMap[$sort] ?? $sortMap['name'], $direction)->orderBy('s.sno', 'desc');

        $page = $query->select([
            's.sno as id', 's.staff_id', 's.staff_name as name', 's.email_id as email', 's.mobile_no as mobile',
            's.staff_image', 's.department_id', 's.designation_id', 's.role_id', 's.basic_salary', 's.per_hour_cost',
            's.date_of_joining', 's.employment_type',
            DB::raw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN 1 WHEN s.status = 2 THEN 2 WHEN s.status IN (3,5,6,7) THEN 3 ELSE 3 END) as status"),
            'd.department_name as department', 'dg.designation as designation',
        ])->paginate((int) ($filters['per_page'] ?? 10))->withQueryString();
        $page->getCollection()->transform(function ($row) {
            $row->staff_image_url = $row->staff_image ? url('/admin-hr/api/staff/' . $row->id . '/photo') : null;
            return $row;
        });
        return $page;
    }

    public function find(int $id): array
    {
        $row = DB::table('ryans_staff as s')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id')
            ->leftJoin('ryans_user_role as r', 'r.sno', '=', 's.role_id')
            ->where('s.sno', $id)->first([
                's.*', 'd.department_name', 'dg.designation as designation_name', 'r.role_name as user_role_name',
                DB::raw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN 1 WHEN s.status = 2 THEN 2 WHEN s.status IN (3,5,6,7) THEN 3 ELSE 3 END) as hr_display_status")
            ]);
        if (!$row || (int) $row->hr_display_status === 2) abort(404, 'Staff record not found.');

        $profile = StaffProfileDataModel::query()->where('staff_id', $id)->first();
        $profileData = is_array($profile?->profile_json) ? $profile->profile_json : [];
        $languages = $profileData['language_ids'] ?? $this->resolveLanguageIds($row->languages ?? null);
        $components = DB::table('ryans_staff_remuneration as sr')
            ->join('ryans_renumeration_type as rt', 'rt.sno', '=', 'sr.remuneration_type_id')
            ->where('sr.staff_id', $id)->where('sr.status', 0)
            ->orderBy('rt.sno')
            ->get([
                'sr.sno as id', 
                'sr.remuneration_type_id as type_id', 
                'rt.renumeration_name as name', 
                'rt.component_type', 
                'sr.amount'
            ]);

        $row->staff_image_url = $row->staff_image ? url('/admin-hr/api/staff/' . $id . '/photo') : null;
        $leaveYear = (int) now()->year;
        $profileData['leave_balance_configuration'] = DB::table('ryans_leave_entitlements')->where('staff_id', $id)->where('year', $leaveYear)->where('status', 0)->pluck('annual_days', 'leave_type')->map(fn ($v) => (float) $v)->all();
        $profileData['blood_group_id'] = $profile?->blood_group_id ?? ($profileData['blood_group_id'] ?? null);
        $profileData['relation_id'] = $profile?->relation_id ?? ($profileData['relation_id'] ?? null);
        $profileData['language_ids'] = array_values(array_map('intval', (array) $languages));

        // Read the existing normalized HR tables for tabs that already have a legacy schema.
        // Empty datasets are returned as empty arrays; demo placeholders are not treated as real records.
        $education = DB::table('ryans_staff_education_info')
                ->where('staff_id', $id)
                ->where('status', 0)
                ->orderBy('sno')
                ->get([
                    'sno as id', 
                    'qualification_type', 
                    'degree_name', 
                    'major', 
                    'university_name', 
                    'year', 
                    'grade'
                ]);

        $experience = DB::table('ryans_staff_work_info')
            ->where('staff_id', $id)
            ->where('status', 0)
            ->orderBy('start_date')
            ->orderBy('sno')
            ->get([
                'sno as id', 
                'staff_type', 
                'position', 
                'year_of_experience', 
                'company_name', 
                'start_date', 
                'end_date', 
                'salary', 
                'exit_reason', 
                'responsibilities'
            ]);

        $family = DB::table('ryans_staff_family')
            ->where('staff_id', $id)
            ->where('status', 0)
            ->orderByDesc('sno')
            ->first();

        $attachments = DB::table('ryans_staff_attachment as a')
        ->leftJoin('ryans_documents as d', 'd.sno', '=', 'a.document_id')
        ->where('a.staff_id', $id)->where('a.status', 0)->orderBy('a.sno')
        ->get([
            'a.sno as id', 
            'a.document_id', 
            'a.attachment_name', 
            'd.document_name'
        ]);

        $profileData['family_members'] = is_array($profileData['family_members'] ?? null) ? $profileData['family_members'] : [];

        if (!$profileData['family_members'] && $family) {
            foreach ([
                [
                    'name' => $family->father_name, 
                    'relation' => 'Father', 'occupation' => $family->father_occup
                ], 
                [
                    'name' => $family->mother_name, 
                    'relation' => 'Mother', 
                    'occupation' => $family->mother_occup
                ], 
                [
                    'name' => $family->spouse_name, 
                    'relation' => 'Spouse', 
                    'occupation' => $family->spouse_working
                ]
            ] as $member) {

                if (trim((string) ($member['name'] ?? '')) !== '') $profileData['family_members'][] = $member + ['age' => null];
            }
            $children = json_decode((string) ($family->children_details ?? ''), true);
            if (is_array($children)) foreach ($children as $child) if (is_array($child)) $profileData['family_members'][] = $child + ['relation' => 'Child'];
        }
        return [
            'staff' => $row, 
            'profile' => $profileData, 
            'remuneration' => $components,
            'education' => $education, 
            'experience' => $experience, 
            'family' => $family,
            'attachments' => $attachments,
        ];
    }

    private function resolveLanguageIds(?string $stored): array
    {
        if (!$stored) return [];
        $json = json_decode($stored, true);
        if (is_array($json)) return array_values(array_filter(array_map('intval', $json)));
        $names = array_filter(array_map('trim', explode(',', $stored)));
        if (!$names) return [];
        return DB::table('ryans_languages')->whereIn('name', $names)->pluck('sno')->map(fn ($id) => (int) $id)->all();
    }

    public function create(string $type, array $data, ?UploadedFile $photo, int $actor): int
    {
        if (!isset($data['gross_amount']) || !is_numeric($data['gross_amount']) || (float) $data['gross_amount'] <= 0) {
            throw ValidationException::withMessages(['gross_amount' => 'Enter a positive monthly gross salary and calculate its configured structure before saving staff.']);
        }
        if (array_key_exists('gross_amount', $data) && $data['gross_amount'] !== null && $data['gross_amount'] !== '') {
            $calculation = $this->payrollCalculationService->calculate((float) $data['gross_amount']);
            $data['gross_salary'] = $calculation['gross_amount'];
            $data['basic_salary'] = (int) round($calculation['ctc']);
            $data['remuneration'] = array_map(static fn ($component) => [
                'type_id' => (int) $component['type_id'], 'amount' => (float) $component['amount'],
            ], $calculation['components']);
        }
        $employment = $this->employmentValue($type);
        if (($data['login_access'] ?? false) && empty($data['email_id'])) {
            throw ValidationException::withMessages(['email_id' => 'Email is required when login access is enabled.']);
        }

        return DB::transaction(function () use ($employment, $data, $photo, $actor) {
            $now = now();
            $relation = !empty($data['relation_id']) ? DB::table('ryans_relationship')->where('sno', $data['relation_id'])->where('status', 0)->value('relationship_name') : null;
            $languageNames = !empty($data['languages']) ? DB::table('ryans_languages')->whereIn('sno', $data['languages'])->where('status', 0)->orderBy('name')->pluck('name')->implode(', ') : null;
            $staff = new StaffModel();
            $staff->fill([
                'staff_id' => null, 'employment_type' => $employment, 'hr_status' => 0,
                // staff_type keeps its existing meaning: 1 management / 2 business.
                'department_id' => (int) $data['department_id'], 'division_id' => (int) ($data['division_id'] ?? 0),
                'job_role_id' => (int) ($data['job_role_id'] ?? 0), 'designation_id' => (int) ($data['designation_id'] ?? 0),
                'role_id' => (int) ($data['role_id'] ?? 0), 'staff_name' => trim($data['staff_name']),
                'mobile_no' => $data['mobile_no'] ?? null, 'email_id' => isset($data['email_id']) ? strtolower(trim($data['email_id'])) : null,
                'gender' => $this->genderCode($data['gender'] ?? null), 'dob' => $data['dob'] ?? null,
                'date_of_joining' => $data['date_of_joining'] ?? null, 'staff_last_date' => $data['staff_last_date'] ?? null,
                'alternative_no' => $data['alternative_no'] ?? null, 'address' => $data['address'] ?? null,
                'residential_address' => $data['residential_address'] ?? null, 'contact_person_name' => $data['contact_person_name'] ?? null,
                'contact_person_no' => $data['contact_person_no'] ?? null, 'contact_person_relation' => $relation,
                'martial_status' => $data['martial_status'] ?? null, 'mother_tongue' => $data['mother_tongue'] ?? null,
                'languages' => $languageNames, 'hobby' => $data['hobby'] ?? null, 'description' => $data['description'] ?? null,
                'basic_salary' => (int) round((float) ($data['basic_salary'] ?? 0)), 'gross_salary' => round((float) ($data['gross_salary'] ?? 0), 2), 'per_hour_cost' => (int) round((float) ($data['per_hour_cost'] ?? 0)),
                'login_access' => (int) ($data['login_access'] ?? 0), 'user_name' => $data['username'] ?? null,
                'created_by' => $actor, 'updated_by' => $actor, 'created_at' => $now, 'updated_at' => $now, 'status' => 0,
            ]);
            if ($photo) $staff->staff_image = $photo->store('staff/profile', 'local');
            $staff->save();
            $staff->staff_id = 'STF-' . str_pad((string) $staff->sno, 6, '0', STR_PAD_LEFT);
            $staff->save();

            $profile = (array) ($data['profile_data'] ?? []);
            $profile['language_ids'] = array_values(array_map('intval', $data['languages'] ?? []));
            $profile['marital_status'] = $data['martial_status'] ?? null;
            StaffProfileDataModel::query()->updateOrCreate(['staff_id' => $staff->sno], [
                'blood_group_id' => $data['blood_group_id'] ?? null, 'relation_id' => $data['relation_id'] ?? null,
                'profile_json' => $profile, 'created_at' => $now, 'updated_at' => $now,
            ]);
            $this->syncFamily((int) $staff->sno, (array) ($profile['family_members'] ?? []), $profile, $actor, $now);
            $this->replaceRemuneration((int) $staff->sno, (array) ($data['remuneration'] ?? []), $actor, $now, false);
            $this->saveLeaveBalanceConfiguration((int) $staff->sno, $data, $actor, $now);

            if ((int) ($data['login_access'] ?? 0) === 1) {
                $email = strtolower(trim($data['email_id']));
                if (DB::table('users')->where('email', $email)->exists()) {
                    throw ValidationException::withMessages(['email_id' => 'This email already has a login account.']);
                }
                if (DB::table('users')->where('username', trim((string) $data['username']))->exists()) {
                    throw ValidationException::withMessages(['username' => 'This username is already in use.']);
                }
                DB::table('users')->insert([
                    'user_id' => $staff->sno, 
                    'role_id' => (int) ($data['role_id'] ?? 0), 
                    'staff_type' => $employment,
                    'name' => trim($data['staff_name']), 
                    'email' => $email,
                    'password' => Hash::make((string) $data['login_pin']), 
                    'username' => trim((string) $data['username']), 
                    'created_at' => $now, 
                    'updated_at' => $now,
                ]);
            }
            return (int) $staff->sno;
        }, 3);
    }

    public function update(int $id, array $data, ?UploadedFile $photo, int $actor): void
    {
        DB::transaction(function () use ($id, $data, $photo, $actor) {
            $staff = StaffModel::query()->where('sno', $id)->lockForUpdate()->first();
            if (!$staff) abort(404, 'Staff record not found.');
            if ((int) ($staff->hr_status ?? $this->legacyStatusToHr((int) $staff->status)) === 2) abort(404, 'Staff record not found.');
            if (array_key_exists('gross_amount', $data) && $data['gross_amount'] !== null && $data['gross_amount'] !== '') {
                $calculation = $this->payrollCalculationService->calculate((float) $data['gross_amount']);
                $data['gross_salary'] = $calculation['gross_amount'];
                $data['basic_salary'] = (int) round($calculation['ctc']);
                $data['remuneration'] = array_map(static fn ($component) => [
                    'type_id' => (int) $component['type_id'], 'amount' => (float) $component['amount'],
                ], $calculation['components']);
            }
            $now = now();
            $fields = ['staff_name', 'mobile_no', 'email_id', 'department_id', 'division_id', 'job_role_id', 'designation_id', 'role_id', 'dob', 'date_of_joining', 'staff_last_date', 'alternative_no', 'address', 'residential_address', 'contact_person_name', 'contact_person_no', 'martial_status', 'mother_tongue', 'hobby', 'description', 'basic_salary', 'gross_salary', 'per_hour_cost', 'dep_reason'];
            foreach ($fields as $field) {
                if (array_key_exists($field, $data)) $staff->{$field} = $data[$field];
            }
            if (array_key_exists('gender', $data)) $staff->gender = $this->genderCode($data['gender']);
            if (array_key_exists('relation_id', $data)) {
                $staff->contact_person_relation = $data['relation_id'] ? DB::table('ryans_relationship')->where('sno', $data['relation_id'])->where('status', 0)->value('relationship_name') : null;
            }
            if (array_key_exists('languages', $data)) {
                $staff->languages = DB::table('ryans_languages')->whereIn('sno', $data['languages'] ?? [])->where('status', 0)->orderBy('name')->pluck('name')->implode(', ');
            }
            if ($photo) {
                $old = $staff->staff_image;
                $staff->staff_image = $photo->store('staff/profile', 'local');
                if ($old && Storage::disk('local')->exists($old)) Storage::disk('local')->delete($old);
            }
            $staff->updated_by = $actor; $staff->updated_at = $now; $staff->save();

            // Keep a linked login account aligned with the canonical staff record.
            // This does not create or remove accounts as a side-effect of profile editing.
            $linkedUser = DB::table('users')->where('user_id', $id)->orderBy('id')->first();
            if ($linkedUser) {
                $userUpdates = ['updated_at' => $now];
                if (array_key_exists('staff_name', $data)) $userUpdates['name'] = trim((string) $data['staff_name']);
                if (array_key_exists('email_id', $data)) {
                    $email = strtolower(trim((string) ($data['email_id'] ?? '')));
                    if ($email === '') throw ValidationException::withMessages(['email_id' => 'A linked login account must have an email address.']);
                    if (DB::table('users')->where('email', $email)->where('id', '<>', $linkedUser->id)->exists()) throw ValidationException::withMessages(['email_id' => 'This email is already used by another login account.']);
                    $userUpdates['email'] = $email;
                }
                if (array_key_exists('username', $data)) {
                    $username = trim((string) ($data['username'] ?? ''));
                    if ($username === '') throw ValidationException::withMessages(['username' => 'A linked login account must have a username.']);
                    if (DB::table('users')->where('username', $username)->where('id', '<>', $linkedUser->id)->exists()) throw ValidationException::withMessages(['username' => 'This username is already in use.']);
                    $userUpdates['username'] = $username;
                }
                if (array_key_exists('role_id', $data)) $userUpdates['role_id'] = (int) $data['role_id'];
                DB::table('users')->where('id', $linkedUser->id)->update($userUpdates);
            }

            $profile = StaffProfileDataModel::query()->firstOrNew(['staff_id' => $id]);
            $json = is_array($profile->profile_json) ? $profile->profile_json : [];
            if (isset($data['profile_data'])) $json = array_replace_recursive($json, $data['profile_data']);
            if (array_key_exists('languages', $data)) $json['language_ids'] = array_values(array_map('intval', $data['languages'] ?? []));
            if (array_key_exists('martial_status', $data)) $json['marital_status'] = $data['martial_status'];
            if (array_key_exists('blood_group_id', $data)) $profile->blood_group_id = $data['blood_group_id'];
            if (array_key_exists('relation_id', $data)) $profile->relation_id = $data['relation_id'];
            $profile->profile_json = $json; $profile->updated_at = $now; if (!$profile->exists) $profile->created_at = $now; $profile->save();

            if (array_key_exists('family_members', $json)) $this->syncFamily($id, (array) $json['family_members'], $json, $actor, $now);
            if (array_key_exists('education', $data)) $this->syncEducation($id, (array) $data['education'], $actor, $now);
            if (array_key_exists('experience', $data)) $this->syncExperience($id, (array) $data['experience'], $actor, $now);
            if (array_key_exists('remuneration', $data)) $this->replaceRemuneration($id, (array) $data['remuneration'], $actor, $now, true);
            $this->saveLeaveBalanceConfiguration($id, $data, $actor, $now);
        }, 3);
    }

    /**
     * Persist the effective staff-specific allocations displayed in the Add Staff form.
     * The UI calculates the joining-year proration from the policy quota whenever Date
     * of Joining changes. These submitted values are already prorated and must not be
     * prorated a second time. LeaveCycleService migrates the year row into the anniversary
     * cycle while preserving the submitted effective amount.
     */
    private function saveLeaveBalanceConfiguration(int $staffId, array $data, int $actor, $now): void
    {
        $map = [
            'casual_leave' => 'Casual Leave',
            'paid_leave' => 'Paid Leave',
            'sick_leave' => 'Sick Leave',
        ];
        $provided = array_intersect(array_keys($map), array_keys($data));
        if (!$provided) return; // Profile-only edits must not reset staff leave balances.

        $staff = DB::table('ryans_staff')->where('sno', $staffId)->first(['employment_type', 'date_of_joining']);
        $employmentType = (int) ($staff->employment_type ?? 0);
        if (!in_array($employmentType, [1, 2], true)) {
            $employmentType = (int) (DB::table('users')->where('user_id', $staffId)->value('staff_type') ?? 0);
        }
        $year = (int) now()->year;
        foreach ($map as $field => $leaveType) {
            if (!array_key_exists($field, $data)) continue;
            $allocatedDays = max(0, min(366, (float) ($data[$field] ?? 0)));

            $entitlementKey = ['staff_id' => $staffId, 'leave_type' => $leaveType, 'year' => $year];
            $existing = DB::table('ryans_leave_entitlements')->where($entitlementKey)->first(['sno']);
            if ($existing) {
                DB::table('ryans_leave_entitlements')->where('sno', $existing->sno)->update([
                    'annual_days' => $allocatedDays,
                    'status' => 0,
                    'updated_by' => $actor,
                    'updated_at' => $now,
                ]);
            } else {
                DB::table('ryans_leave_entitlements')->insert($entitlementKey + [
                    'annual_days' => $allocatedDays,
                    'status' => 0,
                    'created_by' => $actor,
                    'updated_by' => $actor,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);
            }
        }
    }

    /** Keep generic family cards in profile JSON and synchronize the legacy normalized family row. */
    private function syncFamily(int $staffId, array $members, array $profile, int $actor, $now): void
    {
        $normaliseRelation = static function ($value): string {
            $value = mb_strtolower(trim((string) $value));
            if (str_contains($value, 'father')) return 'father';
            if (str_contains($value, 'mother')) return 'mother';
            if (str_contains($value, 'spouse') || str_contains($value, 'wife') || str_contains($value, 'husband')) return 'spouse';
            if (str_contains($value, 'child') || str_contains($value, 'son') || str_contains($value, 'daughter')) return 'child';
            return 'other';
        };
        $current = DB::table('ryans_staff_family')->where('staff_id', $staffId)->where('status', 0)->orderByDesc('sno')->first();
        if (!$members) {
            if ($current) DB::table('ryans_staff_family')->where('sno', $current->sno)->update(['status' => 2, 'updated_by' => $actor, 'updated_at' => $now]);
            return;
        }
        $father = $mother = $spouse = null; $children = []; $fatherOccupation = $motherOccupation = null; $spouseWorking = null; $spouseDesignation = $spouseCompany = null;
        foreach ($members as $member) {
            if (!is_array($member)) continue;
            $name = trim((string) ($member['name'] ?? ''));
            if ($name === '') continue;
            $relation = $normaliseRelation($member['relation'] ?? $member['relation_id'] ?? '');
            $occupation = trim((string) ($member['occupation'] ?? ''));
            if ($relation === 'father') { $father = $name; $fatherOccupation = $occupation ?: null; }
            elseif ($relation === 'mother') { $mother = $name; $motherOccupation = $occupation ?: null; }
            elseif ($relation === 'spouse') { $spouse = $name; $spouseWorking = $occupation !== '' ? 1 : 0; $spouseDesignation = $occupation ?: null; }
            elseif ($relation === 'child') $children[] = $member;
        }
        $values = [
            'father_name' => $father, 'father_occup' => $fatherOccupation,
            'mother_name' => $mother, 'mother_occup' => $motherOccupation,
            'marital_status' => (int) ($profile['marital_status'] ?? 0),
            'spouse_name' => $spouse, 'spouse_working' => $spouseWorking,
            'spouse_designation' => $spouseDesignation, 'spouse_company_name' => $spouseCompany,
            'has_children' => count($children) > 0 ? 1 : 0, 'children_count' => count($children),
            'children_details' => json_encode($children, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
            'updated_by' => $actor, 'updated_at' => $now, 'status' => 0,
        ];
        if ($current) DB::table('ryans_staff_family')->where('sno', $current->sno)->update($values);
        else DB::table('ryans_staff_family')->insert($values + ['staff_id' => $staffId, 'created_by' => $actor, 'created_at' => $now]);
    }

    private function syncEducation(int $staffId, array $items, int $actor, $now): void
    {
        DB::table('ryans_staff_education_info')->where('staff_id', $staffId)->where('status', 0)
            ->update(['status' => 2, 'updated_by' => $actor, 'updated_at' => $now]);
        foreach ($items as $item) {
            $degree = trim((string) ($item['degree_name'] ?? ''));
            $university = trim((string) ($item['university_name'] ?? ''));
            if ($degree === '' && $university === '') continue;
            DB::table('ryans_staff_education_info')->insert([
                'staff_id' => $staffId, 'qualification_type' => (int) ($item['qualification_type'] ?? 0),
                'degree_name' => $degree, 'major' => trim((string) ($item['major'] ?? '')),
                'university_name' => $university, 'year' => trim((string) ($item['year'] ?? '')),
                'grade' => trim((string) ($item['grade'] ?? '')),
                'created_by' => $actor, 'updated_by' => $actor, 'created_at' => $now, 'updated_at' => $now, 'status' => 0,
            ]);
        }
    }

    private function syncExperience(int $staffId, array $items, int $actor, $now): void
    {
        DB::table('ryans_staff_work_info')->where('staff_id', $staffId)->where('status', 0)
            ->update(['status' => 2, 'updated_by' => $actor, 'updated_at' => $now]);
        foreach ($items as $item) {
            $position = trim((string) ($item['position'] ?? ''));
            $company = trim((string) ($item['company_name'] ?? ''));
            if ($position === '' && $company === '') continue;
            $start = $item['start_date'] ?? null;
            $end = $item['end_date'] ?? null;
            $years = (int) ($item['year_of_experience'] ?? 0);
            if (!$start && !$end && !empty($item['period']) && preg_match('/(19|20)\d{2}.*?(19|20)\d{2}/', (string) $item['period'], $matches)) {
                preg_match_all('/(?:19|20)\d{2}/', (string) $item['period'], $yearsFound);
                if (count($yearsFound[0]) >= 2) {
                    $start = $yearsFound[0][0] . '-01-01';
                    $end = $yearsFound[0][1] . '-12-31';
                    $years = max(0, (int) $yearsFound[0][1] - (int) $yearsFound[0][0]);
                }
            }
            DB::table('ryans_staff_work_info')->insert([
                'staff_id' => $staffId, 'staff_type' => (int) ($item['staff_type'] ?? 0), 'position' => $position,
                'year_of_experience' => max(0, $years), 'company_name' => $company ?: null,
                'start_date' => $start ?: null, 'end_date' => $end ?: null,
                'salary' => (float) ($item['salary'] ?? 0), 'exit_reason' => trim((string) ($item['exit_reason'] ?? '')),
                'responsibilities' => trim((string) ($item['responsibilities'] ?? '')),
                'created_by' => $actor, 'updated_by' => $actor, 'created_at' => $now, 'updated_at' => $now, 'status' => 0,
            ]);
        }
    }

    private function replaceRemuneration(int $staffId, array $items, int $actor, $now, bool $keepHistory): void
    {
        $items = array_values($items);
        $typeIds = array_values(array_unique(array_map(fn ($item) => (int) ($item['type_id'] ?? 0), $items)));
        if (count($typeIds) !== count($items)) throw ValidationException::withMessages(['remuneration' => 'Each remuneration component must be selected only once.']);
        if ($typeIds) {
            $valid = DB::table('ryans_renumeration_type')->whereIn('sno', $typeIds)->where('status', 0)->count();
            if ($valid !== count($typeIds)) throw ValidationException::withMessages(['remuneration' => 'One or more remuneration types are no longer active.']);
        }
        $old = DB::table('ryans_staff_remuneration as sr')->join('ryans_renumeration_type as rt', 'rt.sno', '=', 'sr.remuneration_type_id')->where('sr.staff_id', $staffId)->where('sr.status', 0)->get(['sr.remuneration_type_id as type_id', 'rt.renumeration_name as name', 'rt.component_type', 'sr.amount'])->map(fn ($r) => (array) $r)->all();
        $normalise = static function (array $rows): array {
            $normal = array_map(static function ($row): array {
                if (is_object($row)) $row = (array) $row;
                return [
                    'type_id' => (int) ($row['type_id'] ?? 0),
                    'amount' => number_format((float) ($row['amount'] ?? 0), 2, '.', ''),
                ];
            }, $rows);
            usort($normal, static fn (array $a, array $b): int => $a['type_id'] <=> $b['type_id']);
            return $normal;
        };
        if ($keepHistory && $normalise($old) !== $normalise($items)) {
            StaffRemunerationHistoryModel::query()->create([
                'staff_id' => $staffId, 'previous_json' => $old, 'current_json' => $items,
                'created_by' => $actor, 'updated_by' => $actor, 'created_at' => $now, 'updated_at' => $now,
            ]);
        }
        StaffRemunerationModel::query()->where('staff_id', $staffId)->where('status', 0)->update(['status' => 2, 'updated_by' => $actor, 'updated_at' => $now]);
        foreach ($items as $item) {
            StaffRemunerationModel::query()->create(['staff_id' => $staffId, 'remuneration_type_id' => (int) $item['type_id'], 'amount' => (float) $item['amount'], 'created_by' => $actor, 'updated_by' => $actor, 'status' => 0]);
        }
    }

    public function setStatus(int $id, int $status, ?string $reason, ?string $lastDate, int $actor): void
    {
        if (!in_array($status, [0, 1, 3, 2], true)) {
            throw ValidationException::withMessages(['status' => 'The selected staff status is invalid.']);
        }
        if ($status === 3 && (trim((string) $reason) === '' || trim((string) $lastDate) === '')) {
            throw ValidationException::withMessages([
                'exit_reason' => 'An exit remark is required.',
                'staff_last_date' => 'A date of exit is required.',
            ]);
        }

        DB::transaction(function () use ($id, $status, $reason, $lastDate, $actor): void {
            $staff = StaffModel::query()->where('sno', $id)->lockForUpdate()->first();
            if (!$staff || (int) ($staff->hr_status ?? $this->legacyStatusToHr((int) $staff->status)) === 2) {
                abort(404, 'Staff record not found.');
            }

            $staff->hr_status = $status;
            if ($status === 3) {
                $staff->dep_reason = trim((string) $reason);
                $staff->staff_last_date = $lastDate;
            }
            $staff->updated_by = $actor;
            $staff->updated_at = now();
            $staff->save();
        }, 3);
    }

    public function classify(int $id, string $type, int $actor): void
    {
        $staff = StaffModel::query()->where('sno', $id)->firstOrFail();
        $staff->employment_type = $this->employmentValue($type);
        $staff->updated_by = $actor; $staff->updated_at = now(); $staff->save();
    }

    public function delete(int $id, int $actor): void
    {
        $this->setStatus($id, 2, null, null, $actor);
    }

    private function genderCode($value): ?int
    {
        if ($value === null || $value === '') return null;
        return match (strtolower((string) $value)) { 'male', '1' => 1, 'female', '2' => 2, 'other', '3' => 3, default => throw ValidationException::withMessages(['gender' => 'Choose a valid gender.']) };
    }

    private function legacyStatusToHr(int $status): int
    {
        return match ($status) { 0 => 0, 1,4 => 1, 2 => 2, 3,5,6,7 => 3, default => 3 };
    }
}
