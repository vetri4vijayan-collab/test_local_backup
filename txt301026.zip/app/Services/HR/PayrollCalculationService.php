<?php

namespace App\Services\HR;

use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Configurable monthly gross-to-net/CTC calculation.
 * All rates and caps are HR-admin settings; tax is a configured deduction preview,
 * not a substitute for a full annual Indian income-tax projection.
 */
class PayrollCalculationService
{
    private const METHODS = [
        'percentage_gross', 'percentage_basic', 'percentage_component',
        'remainder', 'flat', 'pf', 'esi', 'tds', 'none',
    ];

    public function componentGroup(object|array $component): string
    {
        $read = fn (string $key) => is_array($component) ? ($component[$key] ?? '') : ($component->{$key} ?? '');
        $configured = strtolower(trim((string) $read('component_type')));
        $name = strtolower(trim((string) $read('renumeration_name')) . ' ' . (string) $read('name') . ' ' . (string) $read('renumeration_desc') . ' ' . (string) $read('description'));
        if (in_array($configured, ['b', '2', 'component b', 'component 2'], true) || str_contains($configured, 'deduct') || str_contains($configured, 'detection') || str_contains($configured, 'employee share')) return 'B';
        if (in_array($configured, ['c', '3', 'component c', 'component 3'], true) || str_contains($configured, 'employer') || str_contains($configured, 'contribution') || str_contains($configured, 'benefit')) return 'C';
        if (str_contains($name, 'employer') || str_contains($name, 'contribution') || str_contains($name, 'employer benefit')) return 'C';
        if (str_contains($name, 'deduction') || str_contains($name, 'employee share') || str_contains($name, 'tds') || str_contains($name, 'income tax') || str_contains($name, 'provident fund') || preg_match('/\bpf\b/', $name) || str_contains($name, 'esi') || str_contains($name, 'professional tax')) return 'B';
        return 'A';
    }

    public function configuration(): array
    {
        $types = DB::table('ryans_renumeration_type')->where('status', 0)->orderBy('sno')
            ->get(['sno as type_id', 'renumeration_name as name', 'component_type', 'renumeration_desc as description']);
        $stored = DB::table('ryans_payroll_component_rules')->get()->keyBy('remuneration_type_id');
        $aTypes = $types->filter(fn ($type) => $this->componentGroup($type) === 'A')->values();
        $defaultRemainderId = (int) ($aTypes->firstWhere('name', 'Basic Salary')->type_id ?? ($aTypes->count() === 1 ? ($aTypes->first()->type_id ?? 0) : 0));

        $rules = $types->map(function ($type) use ($stored, $defaultRemainderId) {
            $group = $this->componentGroup($type);
            $name = strtolower((string) $type->name);
            $existing = $stored->get((int) $type->type_id);
            $method = $existing->calculation_method ?? 'none';
            $rate = (float) ($existing->rate ?? 0);
            $threshold = $existing?->threshold_amount;
            $ceiling = $existing?->wage_ceiling;
            $cap = $existing?->cap_amount;
            $baseId = $existing?->base_component_id;
            $enabled = (bool) ($existing->enabled ?? true);
            $sort = (int) ($existing->sort_order ?? $type->type_id);

            if (!$existing) {
                if ($group === 'A') {
                    $method = (int) $type->type_id === $defaultRemainderId ? 'remainder' : 'percentage_gross';
                } elseif (preg_match('/\bpf\b|provident|epf/', $name)) {
                    $method = 'pf'; $rate = 12; $ceiling = 15000;
                } elseif (str_contains($name, 'esi')) {
                    $method = 'esi'; $rate = $group === 'C' ? 3.25 : 0.75; $threshold = 21000;
                } elseif (str_contains($name, 'tds') || str_contains($name, 'income tax')) {
                    $method = 'tds'; $rate = 0;
                } else {
                    $method = 'none';
                }
            }
            return [
                'type_id' => (int) $type->type_id, 'name' => $type->name,
                'component_type' => $type->component_type, 'description' => $type->description,
                'group' => $group, 'calculation_method' => $method, 'rate' => $rate,
                'base_component_id' => $baseId ? (int) $baseId : null,
                'threshold_amount' => $threshold !== null ? (float) $threshold : null,
                'wage_ceiling' => $ceiling !== null ? (float) $ceiling : null,
                'cap_amount' => $cap !== null ? (float) $cap : null,
                'enabled' => $enabled, 'sort_order' => $sort,
            ];
        })->all();

        return ['components' => $types->map(function ($type) { return (array) $type + ['group' => $this->componentGroup($type)]; })->all(), 'rules' => $rules];
    }

    public function saveConfiguration(array $items, int $actor): void
    {
        $activeComponents = DB::table('ryans_renumeration_type')->where('status', 0)->orderBy('sno')
            ->get(['sno', 'renumeration_name', 'component_type', 'renumeration_desc']);
        $types = $activeComponents->pluck('sno')->map(fn ($id) => (int) $id)->all();
        if (!$types) throw ValidationException::withMessages(['rules' => 'Create at least one active remuneration type before configuring payroll.']);
        $groupsById = $activeComponents->mapWithKeys(fn ($component) => [(int) $component->sno => $this->componentGroup($component)])->all();
        $seen = [];
        foreach ($items as $index => $item) {
            $id = (int) ($item['type_id'] ?? 0);
            if (!$id || !in_array($id, $types, true)) throw ValidationException::withMessages(["rules.$index.type_id" => 'Select an active remuneration component.']);
            if (isset($seen[$id])) throw ValidationException::withMessages(['rules' => 'Configure each remuneration component exactly once.']);
            $seen[$id] = true;
            $method = (string) ($item['calculation_method'] ?? '');
            if (!in_array($method, self::METHODS, true)) throw ValidationException::withMessages(["rules.$index.calculation_method" => 'Select a supported calculation method.']);
            if ((float) ($item['rate'] ?? 0) < 0 || (float) ($item['rate'] ?? 0) > 999999999) throw ValidationException::withMessages(["rules.$index.rate" => 'Rate or fixed amount is outside the allowed range.']);
            $baseId = !empty($item['base_component_id']) ? (int) $item['base_component_id'] : null;
            if ($baseId !== null) {
                if (!in_array($baseId, $types, true)) throw ValidationException::withMessages(["rules.$index.base_component_id" => 'Select an active base earning component.']);
                if ($baseId === $id) throw ValidationException::withMessages(["rules.$index.base_component_id" => 'A component cannot calculate itself as its base.']);
                if (($groupsById[$baseId] ?? null) !== 'A') throw ValidationException::withMessages(["rules.$index.base_component_id" => 'The base component must be an earning (Component A).']);
            }
            if ($method === 'percentage_component' && $baseId === null) throw ValidationException::withMessages(["rules.$index.base_component_id" => 'Select the earning component used as the percentage base.']);
        }

        DB::transaction(function () use ($items, $actor) {
            foreach ($items as $item) {
                $typeId = (int) $item['type_id'];
                $values = [
                    'calculation_method' => $item['calculation_method'],
                    'rate' => round((float) ($item['rate'] ?? 0), 4),
                    'base_component_id' => !empty($item['base_component_id']) ? (int) $item['base_component_id'] : null,
                    'threshold_amount' => ($item['threshold_amount'] ?? '') !== '' && ($item['threshold_amount'] ?? null) !== null ? max(0, (float) $item['threshold_amount']) : null,
                    'wage_ceiling' => ($item['wage_ceiling'] ?? '') !== '' && ($item['wage_ceiling'] ?? null) !== null ? max(0, (float) $item['wage_ceiling']) : null,
                    'cap_amount' => ($item['cap_amount'] ?? '') !== '' && ($item['cap_amount'] ?? null) !== null ? max(0, (float) $item['cap_amount']) : null,
                    'enabled' => !empty($item['enabled']) ? 1 : 0,
                    'sort_order' => (int) ($item['sort_order'] ?? $typeId),
                    'updated_by' => $actor, 'updated_at' => now(),
                ];
                $exists = DB::table('ryans_payroll_component_rules')->where('remuneration_type_id', $typeId)->exists();
                if ($exists) DB::table('ryans_payroll_component_rules')->where('remuneration_type_id', $typeId)->update($values);
                else DB::table('ryans_payroll_component_rules')->insert($values + ['remuneration_type_id' => $typeId, 'created_by' => $actor, 'created_at' => now()]);
            }
        }, 3);
    }

    public function calculate(float $gross): array
    {
        if (!is_finite($gross) || $gross <= 0 || $gross > 999999999) {
            throw ValidationException::withMessages(['gross_amount' => 'Enter a positive monthly gross amount.']);
        }
        $config = $this->configuration();
        $rules = array_values(array_filter($config['rules'], fn ($rule) => $rule['enabled']));
        $groups = ['A' => [], 'B' => [], 'C' => []];
        foreach ($rules as $rule) $groups[$rule['group']][] = $rule;
        if (!$groups['A']) throw ValidationException::withMessages(['rules' => 'Configure at least one active Component A earning.']);

        $enabledById = [];
        foreach ($rules as $rule) $enabledById[(int) $rule['type_id']] = $rule;
        $basicRule = null;
        foreach ($groups['A'] as $rule) {
            if (str_contains(strtolower($rule['name']), 'basic')) { $basicRule = $rule; break; }
        }
        $basicRule ??= $groups['A'][0];
        foreach ($rules as $rule) {
            $method = $rule['calculation_method'];
            if ($method === 'percentage_component' && empty($rule['base_component_id'])) {
                throw ValidationException::withMessages(['rules' => "Select a base earning component for '{$rule['name']}'."]);
            }
            if (in_array($method, ['percentage_basic', 'percentage_component'], true)) {
                $baseId = $method === 'percentage_basic'
                    ? (int) ($rule['base_component_id'] ?: $basicRule['type_id'])
                    : (int) $rule['base_component_id'];
                if (!isset($enabledById[$baseId]) || $enabledById[$baseId]['group'] !== 'A') {
                    throw ValidationException::withMessages(['rules' => "The base earning for '{$rule['name']}' is inactive or unavailable. Enable it or choose another base."]);
                }
            }
        }
        $amounts = [];
        $remainderRules = [];
        $pendingEarnings = [];
        $allocated = 0.0;
        foreach ($groups['A'] as $rule) {
            $method = $rule['calculation_method'];
            $rate = (float) $rule['rate'];
            if ($method === 'remainder') {
                $remainderRules[] = $rule;
                continue;
            }
            if (in_array($method, ['percentage_basic', 'percentage_component'], true)) {
                $pendingEarnings[] = $rule;
                continue;
            }
            if ($method === 'percentage_gross') $amount = $gross * $rate / 100;
            elseif ($method === 'flat') $amount = $rate;
            elseif ($method === 'none') $amount = 0;
            else throw ValidationException::withMessages(['rules' => "Component A '{$rule['name']}' must use Percentage of Gross, Percentage of Base/Basic, Percentage of Selected Component, Fixed Amount, Remainder, or None."]);
            $amounts[$rule['type_id']] = round(max(0, $amount), 2);
            $allocated += $amounts[$rule['type_id']];
        }
        if (count($remainderRules) > 1) throw ValidationException::withMessages(['rules' => 'Only one Component A earning can use Remainder.']);

        // Resolve dependent earnings after their base component has been calculated.
        // This supports common structures such as Basic = 50% of gross, HRA = 40% of Basic,
        // and Special Allowance = remainder. A dependent component of a Remainder must be
        // configured after assigning Basic a non-remainder formula to avoid circular math.
        while ($pendingEarnings) {
            $remaining = [];
            $progress = false;
            foreach ($pendingEarnings as $rule) {
                $method = $rule['calculation_method'];
                $baseId = $method === 'percentage_basic'
                    ? (int) ($rule['base_component_id'] ?: $basicRule['type_id'])
                    : (int) ($rule['base_component_id'] ?? 0);
                if ($baseId <= 0) {
                    throw ValidationException::withMessages(['rules' => "Select a base component for '{$rule['name']}'."]);
                }
                if (!array_key_exists($baseId, $amounts)) {
                    $remaining[] = $rule;
                    continue;
                }
                $base = (float) $amounts[$baseId];
                $amount = $base * (float) $rule['rate'] / 100;
                if ($rule['wage_ceiling'] !== null && $rule['wage_ceiling'] > 0) $amount = min($amount, (float) $rule['wage_ceiling']);
                if ($rule['cap_amount'] !== null && $rule['cap_amount'] > 0) $amount = min($amount, (float) $rule['cap_amount']);
                $amounts[$rule['type_id']] = round(max(0, $amount), 2);
                $allocated += $amounts[$rule['type_id']];
                $progress = true;
            }
            if (!$progress) {
                $names = implode(', ', array_map(static fn ($rule) => $rule['name'], $remaining));
                $hasRemainderBase = $remainderRules && array_filter($remaining, function ($rule) use ($remainderRules) {
                    $method = $rule['calculation_method'];
                    $baseId = $method === 'percentage_basic'
                        ? (int) ($rule['base_component_id'] ?: 0)
                        : (int) ($rule['base_component_id'] ?? 0);
                    return $baseId === (int) $remainderRules[0]['type_id'] || ($method === 'percentage_basic' && !$baseId);
                });
                $message = $hasRemainderBase
                    ? 'An earning cannot be calculated from a Remainder component because that creates a circular formula. Configure the base earning (usually Basic Salary) as a percentage first.'
                    : "Payroll earning components have a missing or circular base reference: {$names}.";
                throw ValidationException::withMessages(['rules' => $message]);
            }
            $pendingEarnings = $remaining;
        }

        if ($remainderRules) {
            if ($allocated > $gross + 0.01) throw ValidationException::withMessages(['rules' => 'Configured earnings exceed Gross. Adjust earning percentages or fixed amounts.']);
            $amounts[$remainderRules[0]['type_id']] = round(max(0, $gross - $allocated), 2);
        } elseif (abs($allocated - $gross) > 0.01) {
            throw ValidationException::withMessages(['rules' => 'Configure Component A to total 100% of Gross or designate one earning component as Remainder.']);
        }
        $basicAmount = (float) ($amounts[$basicRule['type_id']] ?? 0);
        $allRules = array_merge($groups['A'], $groups['B'], $groups['C']);
        foreach (array_merge($groups['B'], $groups['C']) as $rule) {
            $method = $rule['calculation_method']; $rate = (float) $rule['rate'];
            if ($method === 'percentage_gross') {
                $amount = $gross * $rate / 100;
            } elseif ($method === 'tds') {
                $taxableGross = $rule['threshold_amount'] !== null && $rule['threshold_amount'] > 0 && $gross <= $rule['threshold_amount'] ? 0 : $gross;
                $amount = $taxableGross * $rate / 100;
            } elseif ($method === 'percentage_basic' || $method === 'pf') {
                $baseId = $rule['base_component_id'] ?: $basicRule['type_id'];
                $base = (float) ($amounts[$baseId] ?? $basicAmount);
                if ($method === 'pf' && $rule['wage_ceiling'] !== null && $rule['wage_ceiling'] > 0) $base = min($base, (float) $rule['wage_ceiling']);
                $amount = $base * $rate / 100;
            } elseif ($method === 'percentage_component') {
                $base = (float) ($amounts[$rule['base_component_id'] ?? 0] ?? 0);
                if ($rule['wage_ceiling'] !== null && $rule['wage_ceiling'] > 0) $base = min($base, (float) $rule['wage_ceiling']);
                $amount = $base * $rate / 100;
            } elseif ($method === 'esi') {
                $base = $gross;
                if ($rule['threshold_amount'] !== null && $rule['threshold_amount'] > 0 && $gross > $rule['threshold_amount']) $base = 0;
                if ($rule['wage_ceiling'] !== null && $rule['wage_ceiling'] > 0) $base = min($base, (float) $rule['wage_ceiling']);
                $amount = $base * $rate / 100;
            } elseif ($method === 'flat') {
                $amount = $rate;
            } else {
                $amount = 0;
            }
            if ($rule['cap_amount'] !== null && $rule['cap_amount'] > 0) $amount = min($amount, (float) $rule['cap_amount']);
            $amounts[$rule['type_id']] = round(max(0, $amount), 2);
        }

        $components = [];
        foreach ($allRules as $rule) {
            $components[] = [
                'type_id' => (int) $rule['type_id'], 'name' => $rule['name'],
                'component_type' => $rule['component_type'], 'group' => $rule['group'],
                'amount' => round((float) ($amounts[$rule['type_id']] ?? 0), 2),
                'calculation_method' => $rule['calculation_method'],
            ];
        }
        $totals = ['A' => 0.0, 'B' => 0.0, 'C' => 0.0];
        foreach ($components as $component) $totals[$component['group']] += $component['amount'];
        foreach ($totals as $key => $value) $totals[$key] = round($value, 2);
        if ($totals['B'] > $totals['A'] + 0.01) throw ValidationException::withMessages(['rules' => 'Configured employee deductions exceed gross earnings. Review payroll configuration.']);
        return [
            'gross_amount' => round($gross, 2), 'components' => $components, 'totals' => $totals,
            'net_pay' => round(max(0, $totals['A'] - $totals['B']), 2),
            'ctc' => round($totals['A'] + $totals['C'], 2),
        ];
    }
}
