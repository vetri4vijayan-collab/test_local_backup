<?php

namespace App\Services\HR;

use App\Models\HR\StaffModel;
use App\Models\HR\StaffRemunerationHistoryModel;
use App\Models\HR\StaffRemunerationModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class WagesService
{
    public function __construct(private StaffService $staffService, private PayrollCalculationService $payrollCalculationService) {}

    public function paginate(string $type, array $filters)
    {
        $query = StaffModel::query()->from('ryans_staff as s')->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        if (($filters['search'] ?? '') !== '') {
            $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => $q->where('s.staff_name', 'like', $like)->orWhere('s.staff_id', 'like', $like)->orWhere('d.department_name', 'like', $like));
        }
        $query->orderBy('s.staff_name');
        return $query->select([
            's.sno as staff_pk', 's.staff_id as staff_code', 's.staff_name', 's.email_id', 's.basic_salary', 's.gross_salary', 's.per_hour_cost',
            's.date_of_joining', 's.department_id', 'd.department_name', 's.designation_id', 'dg.designation',
            DB::raw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status = 1 THEN 1 WHEN s.status = 4 THEN 1 WHEN s.status IN (5,6,7) THEN 3 WHEN s.status = 2 THEN 2 ELSE 3 END) as status")
        ])->paginate((int) ($filters['per_page'] ?? 10))->withQueryString();
    }

    /**
     * Compute the salary-screen KPI cards from real active staff, saved wage components
     * and the latest attendance mark for today. No dashboard seed values are used.
     */
    public function dashboardSummary(string $type): array
    {
        $query = DB::table('ryans_staff as s');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        $query->whereRaw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN 1 WHEN s.status = 2 THEN 2 WHEN s.status IN (3,5,6,7) THEN 3 ELSE 3 END) = 0");
        $staffRows = $query->get(['s.sno', 's.basic_salary', 's.per_hour_cost']);
        $staffIds = $staffRows->pluck('sno')->map(fn ($id) => (int) $id)->all();
        if (!$staffIds) {
            return ['active_staff_count' => 0, 'present_count' => 0, 'daily_wage_output' => 0, 'average_daily_wage_rate' => 0, 'monthly_cost_projection' => 0];
        }

        // Match the visible salary UI groups: A = earnings/gross, B = employee
        // deductions, C = employer contributions. The monthly cost KPI is A + C,
        // not the sum of deductions as well.
        $componentRows = DB::table('ryans_staff_remuneration as sr')
            ->join('ryans_renumeration_type as rt', 'rt.sno', '=', 'sr.remuneration_type_id')
            ->whereIn('sr.staff_id', $staffIds)
            ->where('sr.status', 0)
            ->get(['sr.staff_id', 'sr.amount', 'rt.component_type', 'rt.renumeration_name', 'rt.renumeration_desc']);

        $componentTotals = [];
        foreach ($componentRows as $component) {
            $staffId = (int) $component->staff_id;
            $bucket = $this->remunerationBucket((string) ($component->component_type ?? ''), (string) ($component->renumeration_name ?? '') . ' ' . (string) ($component->renumeration_desc ?? ''));
            $componentTotals[$staffId][$bucket] = ($componentTotals[$staffId][$bucket] ?? 0.0) + (float) $component->amount;
        }

        $dailyRateByStaff = [];
        $monthlyCost = 0.0;
        foreach ($staffRows as $staff) {
            $id = (int) $staff->sno;
            $totals = $componentTotals[$id] ?? [];
            $gross = (float) ($totals['a'] ?? 0.0);
            $employerShare = (float) ($totals['c'] ?? 0.0);
            // Legacy employees may only have basic_salary and no component rows.
            if ($gross <= 0.0 && $employerShare <= 0.0) $gross = (float) ($staff->basic_salary ?? 0.0);
            $hourly = (float) ($staff->per_hour_cost ?? 0.0);
            $dailyRateByStaff[$id] = $hourly > 0 ? $hourly * 8 : $gross / 26;
            $monthlyCost += $gross + $employerShare;
        }

        $latestMarks = DB::table('ryans_staff_attendance')->whereIn('staff_id', $staffIds)
            ->whereDate('date', now()->toDateString())->where('status', 0)
            ->orderByDesc('sno')->get(['staff_id', 'attendance'])->unique('staff_id');
        $presentIds = $latestMarks->filter(fn ($row) => in_array(strtoupper((string) $row->attendance), ['P', 'PR', 'OD', 'PRESENT', 'ON DUTY'], true))
            ->pluck('staff_id')->map(fn ($id) => (int) $id)->all();
        $dailyOutput = 0.0;
        foreach ($presentIds as $id) $dailyOutput += (float) ($dailyRateByStaff[$id] ?? 0);
        $rates = array_values(array_filter($dailyRateByStaff, static fn ($rate) => $rate > 0));

        return [
            'active_staff_count' => count($staffIds),
            'present_count' => count($presentIds),
            'daily_wage_output' => round($dailyOutput, 2),
            'average_daily_wage_rate' => $rates ? round(array_sum($rates) / count($rates), 2) : 0,
            'monthly_cost_projection' => round($monthlyCost, 2),
        ];
    }

    /** Keep dashboard totals aligned with the A/B/C grouping used by the salary UI. */
    private function remunerationBucket(string $componentType, string $componentName = ''): string
    {
        $value = strtolower(trim($componentType));
        $name = strtolower($componentName);
        if (in_array($value, ['b', '2', 'component b', 'component 2'], true) || str_contains($value, 'deduct') || str_contains($value, 'detection') || str_contains($value, 'employee share')) return 'b';
        if (in_array($value, ['c', '3', 'component c', 'component 3'], true) || str_contains($value, 'employer') || str_contains($value, 'contribution') || str_contains($value, 'benefit')) return 'c';
        if (str_contains($name, 'employer') || str_contains($name, 'contribution')) return 'c';
        if (str_contains($name, 'deduction') || str_contains($name, 'employee share') || str_contains($name, 'tds') || str_contains($name, 'income tax') || str_contains($name, 'provident fund') || preg_match('/\bpf\b/', $name) || str_contains($name, 'epf') || str_contains($name, 'esi') || str_contains($name, 'professional tax')) return 'b';
        return 'a';
    }

    /** Bulk-enrich a paginated wages list to avoid one component query-set per staff row. */
    public function enrichPage($rows)
    {
        $staffIds = collect($rows)->pluck('staff_pk')->map(fn ($id) => (int) $id)->filter()->values()->all();
        if (!$staffIds) return collect();

        $types = DB::table('ryans_renumeration_type')->where('status', 0)->orderBy('sno')
            ->get(['sno as type_id', 'renumeration_name as name', 'component_type', 'renumeration_desc as description']);
        $stored = DB::table('ryans_staff_remuneration as sr')
            ->join('ryans_renumeration_type as rt', 'rt.sno', '=', 'sr.remuneration_type_id')
            ->whereIn('sr.staff_id', $staffIds)->where('sr.status', 0)->orderBy('rt.sno')
            ->get(['sr.sno as id', 'sr.staff_id', 'sr.remuneration_type_id as type_id', 'rt.renumeration_name as name', 'rt.component_type', 'sr.amount', 'rt.renumeration_desc as description'])
            ->groupBy('staff_id');

        return collect($rows)->map(function ($row) use ($types, $stored) {
            $byType = $stored->get((int) $row->staff_pk, collect())->keyBy(fn ($item) => (int) $item->type_id);
            $row->components = $types->map(function ($type) use ($byType) {
                $saved = $byType->get((int) $type->type_id);
                return (object) [
                    'id' => $saved->id ?? null, 'type_id' => (int) $type->type_id,
                    'name' => $type->name, 'component_type' => $type->component_type,
                    'description' => $type->description, 'amount' => (float) ($saved->amount ?? 0),
                ];
            });
            $row->total_components = round((float) $row->components->sum('amount'), 2);
            return $row;
        });
    }

    public function details(int $staffId, ?string $type = null): array
    {
        if ($type !== null) {
            $scope = DB::table('ryans_staff as s')->where('s.sno', $staffId);
            $this->staffService->applyCategoryScope($scope, 's', $type);
            if (!$scope->exists()) abort(404, 'Staff record not found in this category.');
        }
        $staff = DB::table('ryans_staff as s')->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id')->where('s.sno', $staffId)
            ->whereRaw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status = 1 THEN 1 WHEN s.status = 4 THEN 1 WHEN s.status IN (5,6,7) THEN 3 WHEN s.status = 2 THEN 2 ELSE 3 END) <> 2")
            ->first(['s.sno as staff_pk', 's.staff_id as staff_code', 's.staff_name', 's.email_id', 's.basic_salary', 's.gross_salary', 's.per_hour_cost', 's.date_of_joining', 's.department_id', 'd.department_name', 's.designation_id', 'dg.designation']);
        if (!$staff) abort(404, 'Staff record not found.');
        $storedComponents = DB::table('ryans_staff_remuneration as sr')->join('ryans_renumeration_type as rt', 'rt.sno', '=', 'sr.remuneration_type_id')
            ->where('sr.staff_id', $staffId)->where('sr.status', 0)->orderBy('rt.sno')
            ->get(['sr.sno as id', 'sr.remuneration_type_id as type_id', 'rt.renumeration_name as name', 'rt.component_type', 'sr.amount', 'rt.renumeration_desc as description']);
        $storedByType = $storedComponents->keyBy(fn ($item) => (int) $item->type_id);
        $availableTypes = DB::table('ryans_renumeration_type')->where('status', 0)->orderBy('sno')
            ->get(['sno as type_id', 'renumeration_name as name', 'component_type', 'renumeration_desc as description'])
            ->map(function ($typeRow) use ($storedByType) {
                $stored = $storedByType->get((int) $typeRow->type_id);
                return (object) [
                    'id' => $stored->id ?? null, 'type_id' => (int) $typeRow->type_id,
                    'name' => $typeRow->name, 'component_type' => $typeRow->component_type,
                    'description' => $typeRow->description, 'amount' => (float) ($stored->amount ?? 0),
                ];
            });
        return ['staff' => $staff, 'components' => $availableTypes, 'stored_components' => $storedComponents,
            'total_components' => round((float) $availableTypes->sum('amount'), 2)];
    }

    public function payrollConfiguration(): array
    {
        return $this->payrollCalculationService->configuration();
    }

    public function savePayrollConfiguration(array $rules, int $actor): void
    {
        $this->payrollCalculationService->saveConfiguration($rules, $actor);
    }

    public function calculatePayrollPreview(float $grossAmount): array
    {
        return $this->payrollCalculationService->calculate($grossAmount);
    }

    public function save(int $staffId, string $type, array $data, int $actor): void
    {
        if (!isset($data['gross_amount']) || !is_numeric($data['gross_amount']) || (float) $data['gross_amount'] <= 0) {
            throw ValidationException::withMessages(['gross_amount' => 'Enter a positive monthly gross salary to calculate and save the configured wage structure.']);
        }
        if (array_key_exists('gross_amount', $data)) {
            $calculation = $this->payrollCalculationService->calculate((float) $data['gross_amount']);
            $data['gross_salary'] = $calculation['gross_amount'];
            $data['basic_salary'] = (int) round($calculation['ctc']);
            $data['remuneration'] = array_map(static fn ($component) => [
                'type_id' => (int) $component['type_id'], 'amount' => (float) $component['amount'],
            ], $calculation['components']);
        }
        $scope = DB::table('ryans_staff as s')->where('s.sno', $staffId);
        $this->staffService->applyCategoryScope($scope, 's', $type);
        if (!$scope->exists()) abort(404, 'Staff record not found in this category.');
        DB::transaction(function () use ($staffId, $data, $actor) {
            $staff = StaffModel::query()->where('sno', $staffId)->lockForUpdate()->first();
            if (!$staff || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) === 2) abort(404, 'Staff record not found.');
            $oldComponents = DB::table('ryans_staff_remuneration as sr')->join('ryans_renumeration_type as rt', 'rt.sno', '=', 'sr.remuneration_type_id')
                ->where('sr.staff_id', $staffId)->where('sr.status', 0)->get(['sr.remuneration_type_id as type_id', 'rt.renumeration_name as name', 'rt.component_type', 'sr.amount'])->map(fn ($r) => (array) $r)->all();
            $newComponents = array_values($data['remuneration'] ?? []);
            $typeIds = array_map(fn ($r) => (int) ($r['type_id'] ?? 0), $newComponents);
            if (count($typeIds) !== count(array_unique($typeIds))) throw ValidationException::withMessages(['remuneration' => 'A wage component cannot be repeated.']);
            if ($typeIds && DB::table('ryans_renumeration_type')->whereIn('sno', $typeIds)->where('status', 0)->count() !== count($typeIds)) {
                throw ValidationException::withMessages(['remuneration' => 'One or more remuneration components are inactive.']);
            }
            $oldSalary = ['basic_salary' => (int) $staff->basic_salary, 'gross_salary' => (float) ($staff->gross_salary ?? 0), 'per_hour_cost' => (int) $staff->per_hour_cost, 'components' => $oldComponents];
            $componentGross = 0.0;
            foreach ($newComponents as $row) {
                $componentType = DB::table('ryans_renumeration_type')->where('sno', (int) ($row['type_id'] ?? 0))->first(['component_type', 'renumeration_name', 'renumeration_desc']);
                if ($this->remunerationBucket((string) ($componentType->component_type ?? ''), (string) ($componentType->renumeration_name ?? '') . ' ' . (string) ($componentType->renumeration_desc ?? '')) === 'a') $componentGross += (float) ($row['amount'] ?? 0);
            }
            $newSalary = ['basic_salary' => (int) round((float) ($data['basic_salary'] ?? $staff->basic_salary)), 'gross_salary' => (float) ($data['gross_salary'] ?? $componentGross), 'per_hour_cost' => (int) round((float) ($data['per_hour_cost'] ?? $staff->per_hour_cost)), 'components' => $newComponents];
            StaffRemunerationHistoryModel::query()->create([
                'staff_id' => $staffId, 'previous_json' => $oldSalary, 'current_json' => $newSalary,
                'created_by' => $actor, 'updated_by' => $actor,
            ]);
            $staff->basic_salary = $newSalary['basic_salary']; $staff->gross_salary = round((float) $newSalary['gross_salary'], 2); $staff->per_hour_cost = $newSalary['per_hour_cost'];
            $staff->updated_by = $actor; $staff->updated_at = now(); $staff->save();
            StaffRemunerationModel::query()->where('staff_id', $staffId)->where('status', 0)->update(['status' => 2, 'updated_by' => $actor, 'updated_at' => now()]);
            foreach ($newComponents as $component) {
                StaffRemunerationModel::query()->create([
                    'staff_id' => $staffId, 'remuneration_type_id' => (int) $component['type_id'],
                    'amount' => (float) $component['amount'], 'created_by' => $actor, 'updated_by' => $actor, 'status' => 0,
                ]);
            }
        }, 3);
    }

    private function legacyStatus(int $status): int
    {
        return match ($status) { 0 => 0, 1,4 => 1, 2 => 2, 5,6,7 => 3, default => 3 };
    }
}
