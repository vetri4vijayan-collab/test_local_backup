<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\View\View;

class PayrollConfiguration extends Controller
{
    public function index(): View
    {
        return view('content.settings.adminhr.payroll_configuration');
    }
}
