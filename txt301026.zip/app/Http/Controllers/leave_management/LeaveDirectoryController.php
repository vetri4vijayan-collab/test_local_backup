<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use App\Services\HR\LeaveService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

/** JSON endpoints used by the existing HR leave-management Blade screens. */
class LeaveDirectoryController extends Controller
{
    public function __construct(private LeaveService $leaveService) {}

    public function index(Request $request, string $type)
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:120'],
            'employee' => ['nullable', 'string', 'max:120'],
            'leave_type' => ['nullable', 'string', 'max:80'],
            'status' => ['nullable', Rule::in(['ALL', 'Pending', 'Approved', 'Rejected'])],
            'from_date' => ['nullable', 'date_format:Y-m-d'],
            'to_date' => ['nullable', 'date_format:Y-m-d', 'after_or_equal:from_date'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        $page = $this->leaveService->paginate($type, array_merge(['per_page' => 10], $filters));
        return response()->json([
            'success' => true,
            'data' => $page->items(),
            'meta' => $this->meta($page),
            'summary' => $this->leaveService->summary($type, $filters),
        ]);
    }

    /** Accepts either the legacy single-item payload or the new date-entry collection. */
    public function storeRequest(Request $request, string $type)
    {
        $data = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'],
            'leave_type' => ['required_without:items', 'nullable', 'string', 'max:80'],
            'from_date' => ['required_without:items', 'nullable', 'date_format:Y-m-d'],
            'to_date' => ['required_without:items', 'nullable', 'date_format:Y-m-d', 'after_or_equal:from_date'],
            'leave_mode' => ['nullable', Rule::in(['full', 'first_half', 'second_half'])],
            'reason' => ['nullable', 'string', 'max:2000'],
            'items' => ['required_without:from_date', 'nullable', 'array', 'min:1', 'max:62'],
            'items.*.date' => ['required_with:items', 'date_format:Y-m-d'],
            'items.*.leave_type' => ['required_with:items', 'string', 'max:80'],
            'items.*.leave_mode' => ['required_with:items', Rule::in(['full', 'first_half', 'second_half'])],
            'items.*.reason' => ['required_with:items', 'string', 'max:2000'],
        ]);

        $items = $data['items'] ?? [[
            'date' => $data['from_date'],
            'to_date' => $data['to_date'],
            'leave_type' => $data['leave_type'],
            'leave_mode' => $data['leave_mode'] ?? 'full',
            'reason' => $data['reason'] ?? '',
        ]];
        $staffId = (int) $data['staff_id'];
        $actor = $this->actor($request);

        $created = DB::transaction(function () use ($items, $staffId, $type, $actor) {
            $result = [];
            foreach ($items as $item) {
                $from = (string) $item['date'];
                $to = (string) ($item['to_date'] ?? $item['date']);
                $result[] = $this->leaveService->createRequest($staffId, [
                    'from_date' => $from,
                    'to_date' => $to,
                    'leave_type' => (string) $item['leave_type'],
                    'leave_mode' => (string) ($item['leave_mode'] ?? 'full'),
                    'reason' => (string) ($item['reason'] ?? ''),
                ], $type, $actor);
            }
            return $result;
        }, 3);

        return response()->json([
            'success' => true,
            'message' => count($created) === 1 ? 'Leave request submitted.' : count($created) . ' leave requests submitted.',
            'data' => array_map(static fn ($row) => ['id' => (int) $row->sno, 'days' => (float) $row->days], $created),
        ], 201);
    }

    public function review(Request $request, string $type, int $id)
    {
        $data = $request->validate([
            'approval_status' => ['required', Rule::in(['Approved', 'Rejected'])],
            'review_note' => ['nullable', 'string', 'max:2000'],
            'note' => ['nullable', 'string', 'max:2000'],
        ]);
        $this->leaveService->review($id, $data['approval_status'], $data['review_note'] ?? $data['note'] ?? null, $this->actor($request), $type);
        return response()->json(['success' => true, 'message' => 'Leave request ' . strtolower($data['approval_status']) . '.']);
    }

    public function policies(string $type)
    {
        return response()->json(['success' => true, 'data' => $this->leaveService->policies($type)]);
    }

    public function savePolicies(Request $request, string $type)
    {
        $data = $request->validate([
            'policies' => ['required', 'array', 'min:3', 'max:3'],
            'policies.*.policy_key' => ['nullable', 'string', 'max:80'],
            'policies.*.leave_type' => ['required', 'string', 'max:80'],
            'policies.*.annual_days' => ['required', 'numeric', 'min:0', 'max:366'],
            'policies.*.carry_forward_enabled' => ['nullable', 'boolean'],
            'policies.*.max_carry_forward_days' => ['required', 'numeric', 'min:0', 'max:366'],
            'policies.*.accrual_method' => ['nullable', Rule::in(['annual', 'monthly', 'pro_rata'])],
        ]);
        $canonical = [];
        $seen = [];
        $inputPolicies = array_values($data['policies']);
        $expectedOrder = ['Casual Leave', 'Paid Leave', 'Sick Leave'];
        $mappingFailed = false;

        foreach ($inputPolicies as $index => $item) {
            // Prefer stable keys, then accept legacy display labels from cached clients.
            $policyKey = strtolower(trim((string) ($item['policy_key'] ?? '')));
            $legacyKey = strtolower(preg_replace('/[^a-z]/', '', (string) ($item['leave_type'] ?? '')));
            $typeKey = match ($policyKey) {
                'casual', 'cl', 'casual_leave' => 'Casual Leave',
                'paid', 'pl', 'paid_leave', 'privilege', 'privilege_leave' => 'Paid Leave',
                'sick', 'sl', 'sick_leave' => 'Sick Leave',
                default => match ($legacyKey) {
                    'cl', 'casual', 'casualleave' => 'Casual Leave',
                    'pl', 'paid', 'paidleave', 'privilege', 'privilegeleave', 'earnedleave' => 'Paid Leave',
                    'sl', 'sick', 'sickleave', 'medicalleave' => 'Sick Leave',
                    default => null,
                },
            };

            if (!$typeKey || isset($seen[$typeKey])) {
                $mappingFailed = true;
                break;
            }

            $seen[$typeKey] = true;
            $normalised = $item;
            $normalised['leave_type'] = $typeKey;
            $normalised['policy_key'] = ['Casual Leave' => 'casual', 'Paid Leave' => 'paid', 'Sick Leave' => 'sick'][$typeKey];
            $normalised['carry_forward_enabled'] = ((float) $item['max_carry_forward_days']) > 0 ? 1 : 0;
            $canonical[] = $normalised;
        }

        if ($mappingFailed || count($seen) !== 3 || !isset($seen['Casual Leave'], $seen['Paid Leave'], $seen['Sick Leave'])) {
            // The existing settings modal has exactly three fields in CL/PL/SL order.
            // This positional fallback supports older cached Blade/JS bundles that submit
            // legacy or duplicated display labels, while preserving the form's field order.
            if (count($inputPolicies) !== 3) {
                return response()->json(['success' => false, 'message' => 'Configure Casual, Paid and Sick Leave exactly once each.'], 422);
            }

            $canonical = [];
            foreach ($inputPolicies as $index => $item) {
                $typeKey = $expectedOrder[$index];
                $normalised = $item;
                $normalised['leave_type'] = $typeKey;
                $normalised['policy_key'] = ['Casual Leave' => 'casual', 'Paid Leave' => 'paid', 'Sick Leave' => 'sick'][$typeKey];
                $normalised['carry_forward_enabled'] = ((float) $item['max_carry_forward_days']) > 0 ? 1 : 0;
                $canonical[] = $normalised;
            }
        }

        $this->leaveService->savePolicies($type, $canonical, $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Leave policy and common carry-forward limits saved.']);
    }

    public function entitlements(Request $request, string $type)
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:120'],
            'as_of' => ['nullable', 'date_format:Y-m-d'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        $page = $this->leaveService->entitlements($type, array_merge(['per_page' => 10], $filters));
        return response()->json(['success' => true, 'data' => $page->items(), 'meta' => $this->meta($page)]);
    }

    public function saveEntitlement(Request $request, string $type)
    {
        $data = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'],
            'leave_type' => ['required', 'string', 'max:80'],
            'annual_days' => ['required', 'numeric', 'min:0', 'max:366'],
            'carry_forward_days' => ['nullable', 'numeric', 'min:0', 'max:366'],
            'as_of' => ['nullable', 'date_format:Y-m-d'],
        ]);
        $this->leaveService->saveEntitlement($type, $data, $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Leave entitlement saved.']);
    }

    public function saveEntitlementsBulk(Request $request, string $type)
    {
        $data = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'],
            'as_of' => ['nullable', 'date_format:Y-m-d'],
            'entitlements' => ['required', 'array', 'min:1', 'max:3'],
            'entitlements.*.leave_type' => ['required', 'string', 'max:80'],
            'entitlements.*.annual_days' => ['required', 'numeric', 'min:0', 'max:366'],
            'entitlements.*.carry_forward_days' => ['nullable', 'numeric', 'min:0', 'max:366'],
        ]);
        $this->leaveService->saveEntitlementsBulk($type, (int) $data['staff_id'], $data['entitlements'], $this->actor($request), $data['as_of'] ?? null);
        return response()->json(['success' => true, 'message' => 'Leave quota saved for this staff member’s current cycle.']);
    }

    public function batchCredit(Request $request, string $type)
    {
        $data = $request->validate([
            'leave_type' => ['required', 'string', 'max:80'],
            'annual_days' => ['required', 'numeric', 'gt:0', 'max:366'],
        ]);
        $count = $this->leaveService->creditEntitlementForCategory($type, $data['leave_type'], (float) $data['annual_days'], $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Credit saved for ' . $count . ' active staff member(s).', 'count' => $count]);
    }

    public function batchCreditGroup(Request $request)
    {
        $data = $request->validate([
            'staff_group' => ['required', Rule::in(['Permanent', 'Contract', 'ALL', 'permanent', 'contract', 'all'])],
            'leave_type' => ['required', 'string', 'max:80'],
            'annual_days' => ['required', 'numeric', 'gt:0', 'max:366'],
        ]);
        $group = strtolower($data['staff_group']);
        $group = $group === 'all' ? 'all' : $group;
        $count = $this->leaveService->creditEntitlementForGroup($group, $data['leave_type'], (float) $data['annual_days'], $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Credit saved for ' . $count . ' active staff member(s).', 'count' => $count]);
    }

    public function history(Request $request, string $type)
    {
        $filters = $request->validate([
            'staff_id' => ['nullable', 'integer', 'min:1'],
            'event_type' => ['nullable', 'string', 'max:80'],
            'search' => ['nullable', 'string', 'max:120'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        $page = $this->leaveService->history($type, array_merge(['per_page' => 20], $filters));
        return response()->json(['success' => true, 'data' => $page->items(), 'meta' => $this->meta($page)]);
    }

    private function actor(Request $request): int
    {
        return (int) (($request->user()->user_id ?? 0) ?: ($request->user()->id ?? session('user_id', 1)));
    }

    private function meta($page): array
    {
        return [
            'current_page' => $page->currentPage(),
            'last_page' => $page->lastPage(),
            'per_page' => $page->perPage(),
            'total' => $page->total(),
        ];
    }
}
