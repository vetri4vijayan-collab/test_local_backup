<?php
namespace App\Http\Controllers\warehouse;
use App\Http\Controllers\Controller;
use App\Models\CityModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\DepotYardModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class DepotYard extends Controller
{
  public function indexlist(Request $request){
    $search = trim($request->input('search_filter', ''));
     $region = trim($request->input('region_filter', ''));
        $perPage = (int) $request->input('sorting_filter', 10);
        $perPage = max(1, min($perPage, 500));
        $countries = CountryModel::where('status', 0)->select('sno', 'country_name')->orderBy('country_name', 'asc')->get();
        $cities = DepotYardModel::query()
    ->leftJoin('ryans_countries','ryans_countries.sno','=','rayans_depot_yard.country_id')
    ->leftJoin('ryans_states','ryans_states.sno','=','rayans_depot_yard.state_id')
    ->leftJoin('ryans_cities','ryans_cities.sno','=','rayans_depot_yard.city_id')
    ->where('rayans_depot_yard.status', '!=', 2)
    ->when($search !== '', function ($query) use ($search) {
        $query->where(function ($q) use ($search) {
            $q->where('ryans_countries.country_name', 'LIKE', "%{$search}%")
                ->orWhere('ryans_states.state_name', 'LIKE', "%{$search}%")
                ->orWhere('rayans_depot_yard.project_site', 'LIKE', "%{$search}%")
                ->orWhere('rayans_depot_yard.response_officer_name', 'LIKE', "%{$search}%")
                ->orWhere('rayans_depot_yard.head_office', 'LIKE', "%{$search}%")
                ->orWhere('rayans_depot_yard.zip_code', 'LIKE', "%{$search}%")
                ->orWhere('ryans_cities.city_name', 'LIKE', "%{$search}%");
        });
    })
    ->select([
        'rayans_depot_yard.sno',
        'rayans_depot_yard.country_id',
        'rayans_depot_yard.state_id',
        'rayans_depot_yard.city_id',
        'rayans_depot_yard.project_site',
        'rayans_depot_yard.head_office',
        'rayans_depot_yard.address',
        'rayans_depot_yard.zip_code',
        'rayans_depot_yard.response_officer_name',
        'rayans_depot_yard.contact_number',
        'rayans_depot_yard.desigination',
        'rayans_depot_yard.mail_id',
        'rayans_depot_yard.status',
        'ryans_countries.country_name as country_name',
        'ryans_states.state_name as state_name',
        'ryans_cities.city_name as city_name',
    ])
    ->orderBy('rayans_depot_yard.sno', 'desc')
    ->paginate($perPage)
    ->appends($request->query());
    if ($region !== '') {
        $query->where('rayans_depot_yard.region', $region);
    }

        if ($request->ajax() || $request->expectsJson()) {
            return response()->json([
                'data' => $cities->getCollection()->map(function ($item) {
                    return [
                        'sno' => $item->sno,
                        'city_id' => $item->city_id,
                        'project_site' => $item->project_site,
                        'head_office' => $item->head_office,
                        'address' => $item->address,
                        'zip_code' => $item->zip_code,
                        'response_officer_name' => $item->response_officer_name,
                        'contact_number' => $item->contact_number,
                        'desigination' => $item->desigination,
                        'mail_id' => $item->mail_id,
                        'state_id' => $item->state_id,
                        'country_name' => $item->country_name ?? '',
                        'state_name' => $item->state_name ?? '',
                        'city_name' => $item->city_name,
                        'status' => $item->status,
                    ];
                })->values(),

                'current_page' => $cities->currentPage(),
                'last_page' => $cities->lastPage(),
                'total' => $cities->total(),
            ]);
        }
         return view('content.store_purchase.warehouse.depot_yard_list', [
            'perpage' => $perPage,
            'search_filter' => $search,
            'categorylist' => $cities,
            'countries' => $countries,
        ]);
  }
   public function index(Request $request)
    {
        $search = trim($request->input('search_filter', ''));
        $perPage = (int) $request->input('sorting_filter', 10);
        $perPage = max(1, min($perPage, 500));
        $countries = CountryModel::where('status', 0)
            ->select('sno', 'country_name')
            ->orderBy('country_name', 'asc')
            ->get();

        $cities = DepotYardModel::query()
    ->leftJoin('ryans_countries','ryans_countries.sno','=','rayans_depot_yard.country_id')
    ->leftJoin('ryans_states','ryans_states.sno','=','rayans_depot_yard.state_id')
    ->leftJoin('ryans_cities','ryans_cities.sno','=','rayans_depot_yard.city_id')
    ->where('ryans_cities.status', '!=', 2)
    ->when($search !== '', function ($query) use ($search) {
        $query->where(function ($q) use ($search) {
            $q->where('ryans_countries.country_name', 'LIKE', "%{$search}%")
                ->orWhere('ryans_states.state_name', 'LIKE', "%{$search}%")
                ->orWhere('ryans_cities.city_name', 'LIKE', "%{$search}%");
        });
    })
    ->select([
        'rayans_depot_yard.sno',
        'rayans_depot_yard.country_id',
        'rayans_depot_yard.state_id',
        'rayans_depot_yard.city_id',
        'rayans_depot_yard.project_site',
        'rayans_depot_yard.head_office',
        'rayans_depot_yard.address',
        'rayans_depot_yard.zip_code',
        'rayans_depot_yard.response_officer_name',
        'rayans_depot_yard.contact_number',
        'rayans_depot_yard.desigination',
        'rayans_depot_yard.mail_id',
        'rayans_depot_yard.status',
        'ryans_countries.country_name as country_name',
        'ryans_states.state_name as state_name',
        'ryans_cities.city_name as city_name',
    ])
    ->orderBy('rayans_depot_yard.sno', 'desc')
    ->paginate($perPage)
    ->appends($request->query());

        if ($request->ajax() || $request->expectsJson()) {
            return response()->json([
                'data' => $cities->getCollection()->map(function ($item) {
                    return [
                        'sno' => $item->sno,
                        'city_id' => $item->city_id,
                        'project_site' => $item->project_site,
                        'head_office' => $item->head_office,
                        'address' => $item->address,
                        'zip_code' => $item->zip_code,
                        'response_officer_name' => $item->response_officer_name,
                        'contact_number' => $item->contact_number,
                        'desigination' => $item->desigination,
                        'mail_id' => $item->mail_id,
                        'state_id' => $item->state_id,
                        'country_name' => $item->country_name ?? '',
                        'state_name' => $item->state_name ?? '',
                        'city_name' => $item->city_name,
                        'status' => $item->status,
                    ];
                })->values(),

                'current_page' => $cities->currentPage(),
                'last_page' => $cities->lastPage(),
                'total' => $cities->total(),
            ]);
        }

        return view('content.store_purchase.warehouse.depot_yard', [
            'perpage' => $perPage,
            'search_filter' => $search,
            'categorylist' => $cities,
            'countries' => $countries,
        ]);
    }


public function ListCountry()
{
    $countries = CountryModel::where('status', 0)->select('sno', 'country_name')->orderBy('country_name', 'asc')->get();
    return response()->json([
        'status' => 200,
        'message' => 'Countries fetched successfully.',
        'data' => $countries,
    ]);
}

public function List($countryId)
{
    $states = StateModel::where('country_id', $countryId)->where('status', 0)->select('sno', 'country_id', 'state_name')->orderBy('state_name', 'asc')->get();
    return response()->json([
        'status' => 200,
        'message' => 'States fetched successfully.',
        'data' => $states,
    ]);
}

public function ListCity($stateId)
{
    $cities = CityModel::where('state_id', $stateId)->where('status', 0)->select('sno', 'state_id', 'city_name')->orderBy('city_name', 'asc')->get();
    return response()->json([
        'status' => 200,
        'message' => 'Cities fetched successfully.',
        'data' => $cities,
    ]);
}
public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [
    'project_site' => 'required|string|max:255',
    'head_office' => 'required|string|max:255',
    'distance' => 'required|numeric|min:0',
    'address' => 'required|string',
    'country_id' => 'required|integer|exists:ryans_countries,sno',
    'state_id' => 'required|integer|exists:ryans_states,sno',
    'city_id' => 'required|integer|exists:ryans_cities,sno',
    'zip_code' => 'required|string|max:20',
    'response_officer_name' => 'nullable|string|max:255',
    'contact_number' => 'nullable|string|max:20',
    'desigination' => 'nullable|string|max:255',
    'mail_id' => 'nullable|email|max:255',
]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
        ], 422);
    }
    $projectSite = ucfirst(trim($request->project_site));
    $exists = DepotYardModel::whereRaw('LOWER(project_site) = ?',[strtolower($projectSite)])->where('status', '!=', 2)->exists();
    if ($exists) {
        return response()->json([
            'status' => 200,
            'message' => 'Already Exist',
        ]);
    }
    $warehouse = new DepotYardModel();
    $warehouse->project_site = $projectSite;
    $warehouse->head_office = trim($request->head_office);
    $warehouse->distance = $request->distance;
    $warehouse->address = trim($request->address);
    $warehouse->country_id = $request->country_id;
    $warehouse->state_id = $request->state_id;
    $warehouse->city_id = $request->city_id;
    $warehouse->zip_code = trim($request->zip_code);
    $warehouse->response_officer_name = $request->response_officer_name;
    $warehouse->contact_number = $request->contact_number;
    $warehouse->desigination = $request->desigination;
    $warehouse->mail_id = $request->mail_id;
    $warehouse->created_by = 1;
    $warehouse->updated_by = 1;
    $warehouse->status = 0;
    $warehouse->save();
    return response()->json([
        'status' => 200,
        'message' => 'Warehouse Master added successfully!',
    ]);
}
public function listWarehouses(Request $request)
{
    $search = trim($request->input('search_filter', ''));
    $region = trim($request->input('region_filter', ''));
    $query = DepotYardModel::query()
        ->leftJoin('ryans_cities','ryans_cities.sno','=','rayans_depot_yard.city_id')
        ->leftJoin('ryans_states','ryans_states.sno','=','rayans_depot_yard.state_id')
        ->leftJoin('ryans_countries','ryans_countries.sno','=','rayans_depot_yard.country_id')
        ->where('rayans_depot_yard.status', '!=', 2);
    if ($search !== '') {
        $query->where(function ($q) use ($search) {
            $term = "%{$search}%";
            $q->where('rayans_depot_yard.project_site', 'LIKE', $term)
                ->orWhere('rayans_depot_yard.head_office', 'LIKE', $term)
                ->orWhere('rayans_depot_yard.address', 'LIKE', $term)
                ->orWhere('rayans_depot_yard.zip_code', 'LIKE', $term)
                ->orWhere('rayans_depot_yard.response_officer_name', 'LIKE', $term)
                ->orWhere('rayans_depot_yard.contact_number', 'LIKE', $term)
                ->orWhere('rayans_depot_yard.desigination', 'LIKE', $term)
                ->orWhere('rayans_depot_yard.mail_id', 'LIKE', $term)
                ->orWhere('ryans_cities.city_name', 'LIKE', $term)
                ->orWhere('ryans_states.state_name', 'LIKE', $term)
                ->orWhere('ryans_countries.country_name', 'LIKE', $term);
        });
    }
    if ($region !== '') {
        $query->where('rayans_depot_yard.region', $region);
    }
    $warehouses = $query
        ->select([
            'rayans_depot_yard.sno',
            'rayans_depot_yard.project_site',
            'rayans_depot_yard.head_office',
            'rayans_depot_yard.distance',
            'rayans_depot_yard.address',
            'rayans_depot_yard.zip_code',
            'rayans_depot_yard.city_id',
            'rayans_depot_yard.state_id',
            'rayans_depot_yard.country_id',
            'rayans_depot_yard.response_officer_name',
            'rayans_depot_yard.contact_number',
            'rayans_depot_yard.desigination',
            'rayans_depot_yard.mail_id',
            'rayans_depot_yard.status',
            'ryans_cities.city_name',
            'ryans_states.state_name',
            'ryans_countries.country_name',
        ])
        ->orderBy('rayans_depot_yard.sno', 'desc')
        ->paginate(
            max(1, min((int) $request->input('per_page', 10), 100))
        );

    return response()->json($warehouses);
}
public function EditFetch($warehouse_id)
{
    $warehouse = DepotYardModel::where('sno', $warehouse_id)
        ->where('status', '!=', 2)
        ->first();

    if (!$warehouse) {
        return response()->json([
            'status' => 404,
            'message' => 'Warehouse not found.',
        ], 404);
    }

    return response()->json([
        'status' => 200,
        'message' => 'Warehouse fetched successfully.',
        'data' => [
            'sno' => $warehouse->sno,
            'project_site' => $warehouse->project_site,
            'head_office' => $warehouse->head_office,
            'distance' => $warehouse->distance,
            'address' => $warehouse->address,
            'country_id' => $warehouse->country_id,
            'state_id' => $warehouse->state_id,
            'city_id' => $warehouse->city_id,
            'zip_code' => $warehouse->zip_code,
            'response_officer_name' => $warehouse->response_officer_name,
            'contact_number' => $warehouse->contact_number,
            'desigination' => $warehouse->desigination,
            'mail_id' => $warehouse->mail_id,
        ],
    ]);
}
public function UpdateStatus(Request $request, $id)
{
    $validator = Validator::make($request->all(), [
        'status' => 'required|integer|in:0,1',
    ]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
        ], 422);
    }
    $warehouse = DepotYardModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$warehouse) {
        return response()->json([
            'status' => 404,
            'message' => 'Warehouse not found.',
        ], 404);
    }
    $warehouse->status = (int) $request->status;
    $warehouse->updated_by = auth()->id() ?? 1;
    $warehouse->save();
    return response()->json([
        'status' => 200,
        'message' => $warehouse->status === 0
            ? 'Warehouse activated successfully!'
            : 'Warehouse deactivated successfully!',
        'data' => [
            'sno' => $warehouse->sno,
            'status' => $warehouse->status,
        ],
    ]);
}
public function Update(Request $request, $id)
{
    $warehouse = DepotYardModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$warehouse) {
        return response()->json([
            'status' => 404,
            'message' => 'Warehouse not found.',
        ], 404);
    }
    $validator = Validator::make($request->all(), [
        'project_site' => 'required|string|max:255',
        'head_office' => 'required|string|max:255',
        'distance' => 'required|numeric|min:0',
        'address' => 'required|string',
        'country_id' => 'required|integer|exists:ryans_countries,sno',
        'state_id' => 'required|integer|exists:ryans_states,sno',
        'city_id' => 'required|integer|exists:ryans_cities,sno',
        'zip_code' => 'required|string|max:20',
        'response_officer_name' => 'nullable|string|max:255',
        'contact_number' => 'nullable|string|max:20',
        'desigination' => 'nullable|string|max:255',
        'mail_id' => 'nullable|email|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
            'errors' => $validator->errors(),
        ], 422);
    }
    $stateExists = StateModel::where('sno', $request->country_id)->exists();
    $state = StateModel::where('sno', $request->state_id)->where('country_id', $request->country_id)->where('status', 0)->exists();
    $city = CityModel::where('sno', $request->city_id)->where('state_id', $request->state_id)->where('status', 0)->exists();
    if (!$state || !$city) {
        return response()->json([
            'status' => 422,
            'message' => 'Please select a valid country, state and city.',
            'errors' => [
                'state_id' => !$state
                    ? ['Please select a valid state for the selected country.']
                    : [],
                'city_id' => !$city
                    ? ['Please select a valid city for the selected state.']
                    : [],
            ],
        ], 422);
    }
    $projectSite = ucfirst(trim($request->project_site));
    $exists = DepotYardModel::whereRaw('LOWER(project_site) = ?',[mb_strtolower($projectSite)])->where('sno', '!=', $warehouse->sno)->where('status', '!=', 2)->exists();
    if ($exists) {
        return response()->json([
            'status' => 200,
            'message' => 'Already Exist',
        ]);
    }
    $warehouse->project_site = $projectSite;
    $warehouse->head_office = trim($request->head_office);
    $warehouse->distance = $request->distance;
    $warehouse->address = trim($request->address);
    $warehouse->country_id = $request->country_id;
    $warehouse->state_id = $request->state_id;
    $warehouse->city_id = $request->city_id;
    $warehouse->zip_code = trim($request->zip_code);
    $warehouse->response_officer_name = $request->response_officer_name;
    $warehouse->contact_number = $request->contact_number;
    $warehouse->desigination = $request->desigination;
    $warehouse->mail_id = $request->mail_id;
    $warehouse->updated_by = auth()->id() ?? 1;
    $warehouse->save();
    return response()->json([
        'status' => 200,
        'message' => 'Warehouse updated successfully!',
    ]);
}
public function Delete($id)
{
    $warehouse = DepotYardModel::where('sno', $id)
        ->where('status', '!=', 2)
        ->first();

    if (!$warehouse) {
        return response()->json([
            'status' => 404,
            'message' => 'Warehouse not found or already deleted.',
        ], 404);
    }

    // Soft delete: status 2 means deleted
    $warehouse->status = 2;
    $warehouse->updated_by = auth()->id() ?? 1;
    $warehouse->save();

    return response()->json([
        'status' => 200,
        'message' => 'Warehouse deleted successfully!',
        'data' => [
            'sno' => $warehouse->sno,
            'status' => $warehouse->status,
        ],
    ], 200);
}
 public function Status($id, Request $request)
{
    $validator = Validator::make($request->all(), [
        'status' => 'required|integer|in:0,1',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
        ], 422);
    }

    $warehouse = DepotYardModel::where('sno', $id)
        ->where('status', '!=', 2)
        ->first();

    if (!$warehouse) {
        return response()->json([
            'status' => 404,
            'message' => 'Warehouse not found or already deleted.',
        ], 404);
    }

    $warehouse->status = (int) $request->input('status');
    $warehouse->updated_by = auth()->id() ?? 1;
    $warehouse->save();

    return response()->json([
        'status' => 200,
        'message' => 'Warehouse status updated successfully!',
        'data' => [
            'sno' => $warehouse->sno,
            'status' => $warehouse->status,
        ],
    ], 200);
}
public function ViewFetch($warehouse_id)
{
    $warehouse = DepotYardModel::query()
        ->leftJoin('ryans_countries','ryans_countries.sno','=','rayans_depot_yard.country_id')
        ->leftJoin('ryans_states','ryans_states.sno','=','rayans_depot_yard.state_id')
        ->leftJoin('ryans_cities','ryans_cities.sno','=','rayans_depot_yard.city_id')
        ->where('rayans_depot_yard.sno', $warehouse_id)
        ->where('rayans_depot_yard.status', '!=', 2)
        ->select([
            'rayans_depot_yard.sno',
            'rayans_depot_yard.project_site',
            'rayans_depot_yard.head_office',
            'rayans_depot_yard.distance',
            'rayans_depot_yard.address',
            'rayans_depot_yard.zip_code',
            'rayans_depot_yard.response_officer_name',
            'rayans_depot_yard.contact_number',
            'rayans_depot_yard.desigination',
            'rayans_depot_yard.mail_id',
            'rayans_depot_yard.country_id',
            'rayans_depot_yard.state_id',
            'rayans_depot_yard.city_id',
            'ryans_countries.country_name',
            'ryans_states.state_name',
            'ryans_cities.city_name',
        ])->first();
    if (!$warehouse) {
        return response()->json([
            'status' => 404,
            'message' => 'Warehouse not found.',
        ], 404);
    }
    return response()->json([
        'status' => 200,
        'message' => 'Warehouse details fetched successfully.',
        'data' => $warehouse,
    ]);
}
}
