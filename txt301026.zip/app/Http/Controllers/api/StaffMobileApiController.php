<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\HR\StaffAttendanceModel;
use App\Models\HR\StaffModel;
use App\Services\HR\AttendanceService;
use App\Services\HR\LeaveService;
use App\Services\HR\StaffService;
use Carbon\Carbon;
use Firebase\JWT\JWT;
use Illuminate\Http\Request;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Laravel\Sanctum\PersonalAccessToken;
use Illuminate\Support\Facades\Validator;

/**
 * @OA\Info(
 *   title="Employee App API",
 *   version="2.0.0",
 *   description="Authenticated mobile APIs for employee profile, leave and attendance."
 * )
 * @OA\Server(url="/api", description="Application API base path")
 * @OA\Tag(name="Employee", description="Employee mobile APIs")
 * @OA\SecurityScheme(securityScheme="bearerAuth", type="http", scheme="bearer", bearerFormat="JWT")
 */
class StaffMobileApiController extends Controller
{
    public function __construct(
        private readonly StaffService $staffService,
        private readonly LeaveService $leaveService,
        private readonly AttendanceService $attendanceService,
    ) {}

    /**
     * @OA\Post(
     *   path="/v1/staff/login", operationId="staffMobileLogin", summary="Sign in to the employee app", tags={"Employee"},
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"user_name","password"},
     *     @OA\Property(property="user_name", type="string", example="employee01"),
     *     @OA\Property(property="password", type="string", format="password", example="strong-password"),
     *     @OA\Property(property="device_id", type="string", nullable=true, example="device-123"),
     *     @OA\Property(property="latitude", type="number", nullable=true, example=9.9252),
     *     @OA\Property(property="longitude", type="number", nullable=true, example=78.1198)
     *   )),
     *   @OA\Response(response=200, description="Login successful", @OA\JsonContent(
     *     @OA\Property(property="status", type="integer", example=200),
     *     @OA\Property(property="message", type="string", example="Logged in Successfully"),
     *     @OA\Property(property="user_id", type="integer", example=12),
     *     @OA\Property(property="token", type="string"),
     *     @OA\Property(property="expires_at", type="string", format="date-time")
     *   )),
     *   @OA\Response(response=401, description="Invalid username or password"),
     *   @OA\Response(response=403, description="Staff profile is inactive or not classified"),
     *   @OA\Response(response=422, description="Validation error")
     * )
     */
    public function login(Request $request)
    {
        $validated = $request->validate([
            'user_name' => ['required', 'string', 'max:100'],
            'password' => ['required', 'string', 'max:1024'],
            'device_id' => ['nullable', 'string', 'max:255'],
            'latitude' => ['nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['nullable', 'numeric', 'between:-180,180'],
        ]);

        $username = trim($validated['user_name']);
        $user = DB::table('users')->where('username', $username)->first();
        $validCredentials = $user
            && hash_equals((string) $user->username, $username)
            && is_string($user->password ?? null)
            && Hash::check($validated['password'], $user->password);

        if (!$validCredentials) {
            $this->writeLoginLog($request, $user ? (int) $user->id : null, $username, null, $validated, false);
            return response()->json([
                'status' => 401,
                'message' => 'Invalid username or password.',
                'error_msg' => 'Invalid credentials.',
                'data' => null,
            ], 401);
        }

        $staff = $this->resolveStaffContext((int) ($user->user_id ?? 0), isset($user->staff_type) ? (int) $user->staff_type : null);
        if (!$staff) {
            $this->writeLoginLog($request, (int) $user->id, $username, null, $validated, false);
            return response()->json([
                'status' => 403,
                'message' => 'The staff profile is inactive or the employment category is not configured. Please contact the administrator.',
                'error_msg' => 'Staff profile unavailable.',
                'data' => null,
            ], 403);
        }

        // The Laravel APP_KEY is the fallback so an undocumented hard-coded secret is never used.
        $secret = (string) (config('services.mobile_jwt.secret') ?: config('app.key'));
        if ($secret === '') {
            return response()->json([
                'status' => 500,
                'message' => 'Mobile authentication is not configured on this server.',
                'data' => null,
            ], 500);
        }

        $now = time();
        $expiresAt = $now + (7 * 24 * 60 * 60);
        $jwt = JWT::encode([
            'iss' => (string) config('app.url', config('app.name', 'Employee App')),
            'aud' => 'mobile-app',
            'iat' => $now,
            'exp' => $expiresAt,
            'user_id' => (int) $user->id,
            'staff_sno' => (int) $staff->sno,
            'staff_type' => (int) $staff->resolved_employment_type,
        ], $secret, 'HS256');

        $personalToken = new PersonalAccessToken();
        $personalToken->forceFill([
            'tokenable_type' => StaffModel::class,
            'tokenable_id' => (int) $staff->sno,
            'name' => 'staff_mobile_jwt',
            'token' => hash('sha256', $jwt),
            'abilities' => ['*'],
            'expires_at' => Carbon::createFromTimestamp($expiresAt),
        ])->save();

        $this->writeLoginLog($request, (int) $user->id, $username, $staff, $validated, true);

        return response()->json([
            'status' => 200,
            'message' => 'Logged in Successfully',
            'error_msg' => null,
            'user_id' => (int) $staff->sno,
            'token' => $jwt,
            'expires_at' => Carbon::createFromTimestamp($expiresAt)->toIso8601String(),
        ]);
    }

    /**
     * @OA\Get(path="/v1/staff/profile", operationId="staffMobileProfile", summary="Get authenticated staff profile", tags={"Employee"}, security={{"bearerAuth":{}}},
     *   @OA\Response(response=200, description="Profile fetched"),
     *   @OA\Response(response=401, description="Missing or expired token"),
     *   @OA\Response(response=403, description="Staff profile unavailable")
     * )
     */
    public function profile(Request $request)
    {
        $context = $this->currentStaffContext($request);
        if (!$context) return $this->staffUnavailableResponse();

        $detail = $this->staffService->find((int) $context->sno);
        $staff = (array) $detail['staff'];
        foreach ([
            'password', 'credential', 'user_name', 'username', 'super_user_token', 'remember_token',
            'login_pin', 'otp', 'password_reset_token',
        ] as $sensitive) {
            unset($staff[$sensitive]);
        }
        $staff['staff_image_url'] = !empty($staff['staff_image']) ? url('/admin-hr/api/staff/' . $staff['sno'] . '/photo') : asset('assets/img/avatar/admin.png');
        
        unset($staff['attachment']);

        $attachments = collect($detail['attachments'] ?? [])->map(function ($item) {
            $record = (array) $item;
            if (isset($record['attachment_name'])) {
                $record['file_name'] = basename(str_replace('\\', '/', (string) $record['attachment_name']));
                unset($record['attachment_name']);
            }
            return $record;
        });

        $today = now()->toDateString();

        $todayCheckin = StaffAttendanceModel::query()->where('staff_id', $staff['sno'])->whereDate('date', $today)->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();

        if($todayCheckin){
            if($todayCheckin && $todayCheckin->in_time){
                $today_check_in = 1;
            }else{
                $today_check_in = 0;
            }

            if($todayCheckin && $todayCheckin->out_time){
                $today_check_out = 1;
            }else{
                $today_check_out = 0;
            }
            
            $today_attendance =[
                "today_check_in"=>$today_check_in,
                "today_check_out"=>$today_check_out,
                'attendance' => (string) $todayCheckin->attendance,
                'leave_mode' => $todayCheckin->leave_mode ?? null,
                'in_time' => $todayCheckin->in_time,
                'out_time' => $todayCheckin->out_time,
                'time_start' => $todayCheckin->time_start,
                'time_end' => $todayCheckin->time_end,
                'reason' => $todayCheckin->reason,
                'type' => $todayCheckin->type,
            ];
        }else{
            $today_attendance = [
                'today_check_in' => 0,
                'today_check_out' => 0,
                'attendance' => null,
                'leave_mode' => null,
                'in_time' => null,
                'out_time' => null,
                'time_start' => null,
                'time_end' => null,
                'reason' => null,
                'type' => null,
            ];
        }
        
        

        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Staff profile fetched successfully.',
            'data' => [
                'staff' => $staff,
                'today_attendance' => $today_attendance,
                'profile' => $detail['profile'] ?? [],
                'remuneration' => $detail['remuneration'] ?? [],
                'education' => $detail['education'] ?? [],
                'experience' => $detail['experience'] ?? [],
                'family' => $detail['family'] ?? null,
                'attachments' => $attachments,
            ],
        ]);
    }

    /**
     * @OA\Get(path="/v1/staff/profile/photo", operationId="staffMobileProfilePhoto", summary="Stream the authenticated staff profile photo", tags={"Employee"}, security={{"bearerAuth":{}}},
     *   @OA\Response(response=200, description="Profile image", @OA\Content(mediaType="image/*", @OA\Schema(type="string", format="binary"))),
     *   @OA\Response(response=401, description="Missing or expired token"),
     *   @OA\Response(response=404, description="Photo not found")
     * )
     */
    public function photo(Request $request)
    {
        $context = $this->currentStaffContext($request);
        if (!$context) return $this->staffUnavailableResponse();

        $path = trim((string) ($context->staff_image ?? ''));
        if ($path === '' || !str_starts_with($path, 'staff/profile/') || str_contains($path, '..') || !Storage::disk('local')->exists($path)) {
            return response()->json(['success' => false, 'message' => 'Profile image not found.'], 404);
        }
        $absolutePath = Storage::disk('local')->path($path);
        $mime = function_exists('mime_content_type') ? mime_content_type($absolutePath) : 'application/octet-stream';
        if (!is_string($mime) || !str_starts_with($mime, 'image/')) {
            return response()->json(['success' => false, 'message' => 'Profile image not found.'], 404);
        }

        return response()->file($absolutePath, [
            'Content-Type' => $mime,
            'Cache-Control' => 'private, no-store, max-age=0',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

     /**
     * @OA\Get(
     *   path="/v1/staff/leave-requests-list",
     *   operationId="staffMobileLeaveRequestList",
     *   summary="List the authenticated staff member's leave requests",
     *   tags={"Employee"},
     *   security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="page", in="query", required=false, @OA\Schema(type="integer", minimum=1, example=1)),
     *   @OA\Parameter(name="per_page", in="query", required=false, @OA\Schema(type="integer", minimum=1, maximum=100, example=10)),
     *   @OA\Parameter(name="approval_status", in="query", required=false, @OA\Schema(type="string", enum={"Pending", "Approved", "Rejected"})),
     *   @OA\Response(response=200, description="Leave requests fetched successfully"),
     *   @OA\Response(response=401, description="Missing or expired token"),
     *   @OA\Response(response=403, description="Staff profile unavailable"),
     *   @OA\Response(response=422, description="Invalid query parameters")
     * )
     */
    public function leaveRequestList(Request $request)
    {
        $context = $this->currentStaffContext($request);
        if (!$context) return $this->staffUnavailableResponse();

        $validator = Validator::make($request->all(), [
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
            'approval_status' => ['nullable', 'string', 'in:Pending,Approved,Rejected'],
            'status' => ['nullable', 'string', 'in:Pending,Approved,Rejected'],
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false, 'status' => 422, 'message' => 'Validation Error',
                'error_msg' => $validator->errors(), 'data' => null,
            ], 422);
        }

        // This query is always scoped to the authenticated staff ID.
        $query = DB::table('ryans_leave_requests')->where('staff_id', (int) $context->sno)->where('status', 0);
        $approvalStatus = $request->input('approval_status');
        if ($approvalStatus === null || $approvalStatus === '') $approvalStatus = $request->input('status');
        if ($approvalStatus !== null && $approvalStatus !== '') $query->where('approval_status', $approvalStatus);

        $perPage = (int) $request->input('per_page', 10);
        $page = $query->select([
            'sno', 'leave_type', 'from_date', 'to_date', 'days', 'leave_mode', 'reason',
            'approval_status', 'review_note', 'reviewed_at', 'created_at', 'updated_at',
        ])->orderByDesc('created_at')->orderByDesc('sno')
            ->paginate($perPage, ['*'], 'page', (int) $request->input('page', 1));

        $records = collect($page->items())->map(static function ($row) {
            return [
                'id' => (int) $row->sno,
                'date' => $row->from_date !== null ? (string) $row->from_date : null,
                'leave_type' => (string) $row->leave_type,
                'from_date' => $row->from_date !== null ? (string) $row->from_date : null,
                'to_date' => $row->to_date !== null ? (string) $row->to_date : null,
                'days' => round((float) ($row->days ?? 0), 2),
                'leave_mode' => (string) ($row->leave_mode ?? 'full'),
                'reason' => $row->reason,
                'approval_status' => $row->approval_status,
                'review_note' => $row->review_note,
                'reviewed_at' => $row->reviewed_at,
                'created_at' => $row->created_at,
                'updated_at' => $row->updated_at,
            ];
        })->values();

        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Leave requests fetched successfully.',
            'data' => $records,
            'summary' => $this->leaveService->mobileRequestSummary((int) $context->sno),
            'leave_balances' => $this->leaveService->mobileBalanceSummary((int) $context->sno),
            'meta' => [
                'current_page' => $page->currentPage(), 'last_page' => $page->lastPage(),
                'per_page' => $page->perPage(), 'total' => $page->total(),
            ],
        ]);
    }

   

    /**
     * @OA\Post(path="/v1/staff/leave-requests", operationId="staffMobileLeaveRequest", summary="Submit one or more dated leave entries", tags={"Employee"}, security={{"bearerAuth":{}}},
     *   @OA\RequestBody(required=true, @OA\JsonContent(
     *     @OA\Property(property="items", type="array", @OA\Items(type="object",
     *       required={"date","leave_type","leave_mode","reason"},
     *       @OA\Property(property="date", type="string", format="date", example="2026-11-10"),
     *       @OA\Property(property="leave_type", type="string", example="Casual Leave"),
     *       @OA\Property(property="leave_mode", type="string", enum={"full","first_half","second_half"}, example="first_half"),
     *       @OA\Property(property="reason", type="string", example="Personal work")
     *     )),
     *     @OA\Property(property="leave_type", type="string", description="Legacy single-range field"),
     *     @OA\Property(property="from_date", type="string", format="date"),
     *     @OA\Property(property="to_date", type="string", format="date"),
     *     @OA\Property(property="leave_mode", type="string", enum={"full","first_half","second_half"}),
     *     @OA\Property(property="reason", type="string")
     *   )),
     *   @OA\Response(response=201, description="Request created"),
     *   @OA\Response(response=401, description="Missing or expired token"),
     *   @OA\Response(response=422, description="Validation or leave balance error")
     * )
     */
    public function leaveRequest(Request $request)
    {
        $context = $this->currentStaffContext($request);
        if (!$context) return $this->staffUnavailableResponse();

        $hasItems = $request->has('items');
        $rules = $hasItems ? [
            'items' => ['required', 'array', 'min:1', 'max:62'],
            'items.*.date' => ['required', 'date_format:Y-m-d', 'after_or_equal:today', 'distinct:strict'],
            'items.*.leave_type' => ['required', 'string', 'max:80'],
            'items.*.leave_mode' => ['required', 'string', 'in:full,first_half,second_half'],
            'items.*.reason' => ['required', 'string', 'max:2000'],
        ] : [
            // Backward compatibility for installed mobile clients using the old date range.
            'leave_type' => ['required', 'string', 'max:80'],
            'from_date' => ['required', 'date_format:Y-m-d', 'after_or_equal:today'],
            'to_date' => ['required', 'date_format:Y-m-d', 'after_or_equal:from_date'],
            'leave_mode' => ['nullable', 'string', 'in:full,first_half,second_half'],
            'reason' => ['required', 'string', 'max:2000'],
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json([
                'success' => false, 'status' => 422, 'message' => 'Validation Error',
                'error_msg' => $validator->errors(), 'data' => null,
            ], 422);
        }

        $type = (int) $context->resolved_employment_type === StaffService::TYPE_PERMANENT ? 'permanent' : 'contract';
        try {
            if ($hasItems) {
                // Matches the web UI: one independently typed/mode/reasoned request per date.
                $items = array_values($request->input('items', []));
                $seenDates = [];
                foreach ($items as $index => $item) {
                    $date = (string) ($item['date'] ?? '');
                    if (isset($seenDates[$date])) {
                        return response()->json([
                            'success' => false, 'status' => 422,
                            'message' => 'Only one leave entry can be submitted for each date.',
                            'error_msg' => ["items.$index.date" => ['Duplicate leave date: ' . $date]], 'data' => null,
                        ], 422);
                    }
                    $seenDates[$date] = true;
                }
                $created = $this->leaveService->createDateRequests(
                    (int) $context->sno, $items, $type, (int) $context->sno
                );
                $requests = collect($created)->map(static function ($leave) {
                    return [
                        'id' => (int) $leave->sno,
                        'date' => (string) $leave->from_date,
                        'leave_type' => (string) $leave->leave_type,
                        'from_date' => (string) $leave->from_date,
                        'to_date' => (string) $leave->to_date,
                        'days' => round((float) $leave->days, 2),
                        'leave_mode' => (string) ($leave->leave_mode ?? 'full'),
                        'reason' => $leave->reason,
                        'approval_status' => $leave->approval_status,
                        'created_at' => $leave->created_at ? Carbon::parse($leave->created_at)->toIso8601String() : null,
                    ];
                })->values();

                return response()->json([
                    'success' => true, 'status' => 201,
                    'message' => count($requests) . ' leave date(s) submitted for approval.',
                    'data' => [
                        'requests' => $requests,
                        'total_requests' => $requests->count(),
                        'total_days' => round((float) $requests->sum('days'), 2),
                    ],
                    'summary' => $this->leaveService->mobileRequestSummary((int) $context->sno),
                    'leave_balances' => $this->leaveService->mobileBalanceSummary((int) $context->sno),
                ], 201);
            }

            $validated = $validator->validated();
            $leave = $this->leaveService->createRequest((int) $context->sno, $validated, $type, (int) $context->sno);
            return response()->json([
                'success' => true, 'status' => 201, 'message' => 'Leave request submitted for approval.',
                'data' => [
                    'id' => (int) $leave->sno,
                    'leave_type' => $leave->leave_type,
                    'from_date' => (string) $leave->from_date,
                    'to_date' => (string) $leave->to_date,
                    'days' => round((float) $leave->days, 2),
                    'leave_mode' => (string) ($leave->leave_mode ?? 'full'),
                    'reason' => $leave->reason,
                    'approval_status' => $leave->approval_status,
                    'created_at' => $leave->created_at ? Carbon::parse($leave->created_at)->toIso8601String() : null,
                ],
                'summary' => $this->leaveService->mobileRequestSummary((int) $context->sno),
            ], 201);
        } catch (ValidationException $exception) {
            return response()->json([
                'success' => false, 'status' => 422, 'message' => 'Leave request validation failed.',
                'error_msg' => $exception->errors(), 'data' => null,
            ], 422);
        }
    }

    /**
     * @OA\Post(path="/v1/staff/check-in", operationId="staffMobileCheckIn", summary="Record today's check-in with GPS", tags={"Employee"}, security={{"bearerAuth":{}}},
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"latitude","longitude"},
     *     @OA\Property(property="latitude", type="number", example=9.9252),
     *     @OA\Property(property="longitude", type="number", example=78.1198),
     *     @OA\Property(property="accuracy_m", type="number", nullable=true, example=12.5),
     *     @OA\Property(property="device_id", type="string", nullable=true, example="device-123")
     *   )),
     *   @OA\Response(response=200, description="Check-in recorded"),
     *   @OA\Response(response=401, description="Missing or expired token"),
     *   @OA\Response(response=422, description="Location or attendance validation error")
     * )
     */
    public function checkIn(Request $request)
    {
        $context = $this->currentStaffContext($request);
        if (!$context) return $this->staffUnavailableResponse();
        $validated = $this->validateLocation($request);
        $result = $this->checkInUpdate(
            (int) $context->sno,
            (int) $context->resolved_employment_type,
            (int) $context->sno,
            (float) $validated['latitude'],
            (float) $validated['longitude'],
            $validated['location'] ?? null,
            isset($validated['accuracy_m']) ? (float) $validated['accuracy_m'] : null,
            $validated['device_id'] ?? null,
        );
        return response()->json([
            'success' => true, 
            'status' => 200,
            'message' => 'Check-in recorded successfully.', 
            'data' => $result
        ]);
    }

    /**
     * @OA\Post(path="/v1/staff/check-out", operationId="staffMobileCheckOut", summary="Record today's check-out with GPS", tags={"Employee"}, security={{"bearerAuth":{}}},
     *   @OA\RequestBody(required=true, @OA\JsonContent(required={"latitude","longitude"},
     *     @OA\Property(property="latitude", type="number", example=9.9252),
     *     @OA\Property(property="longitude", type="number", example=78.1198),
     *     @OA\Property(property="accuracy_m", type="number", nullable=true, example=12.5),
     *     @OA\Property(property="device_id", type="string", nullable=true, example="device-123")
     *   )),
     *   @OA\Response(response=200, description="Check-out recorded"),
     *   @OA\Response(response=401, description="Missing or expired token"),
     *   @OA\Response(response=422, description="Location or attendance validation error")
     * )
     */
    public function checkOut(Request $request)
    {
        $context = $this->currentStaffContext($request);
        if (!$context) return $this->staffUnavailableResponse();
        $validated = $this->validateLocation($request);
        $result = $this->checkOutUpdate(
            (int) $context->sno,
            (int) $context->resolved_employment_type,
            (int) $context->sno,
            (float) $validated['latitude'],
            (float) $validated['longitude'],
            $validated['location'] ?? null,
            isset($validated['accuracy_m']) ? (float) $validated['accuracy_m'] : null,
            $validated['device_id'] ?? null,
        );
        return response()->json([
            'success' => true, 
            'status' => 200,
            'message' => 'Check-out recorded successfully.', 
            'data' => $result
            ]);
    }

    /**
     * @OA\Get(path="/v1/staff/attendance-history", operationId="staffMobileAttendanceHistory", summary="Get monthly attendance history", tags={"Employee"}, security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="month", in="query", required=true, @OA\Schema(type="string", pattern="^\\d{4}-(0[1-9]|1[0-2])$", example="2026-10")),
     *   @OA\Parameter(name="page", in="query", required=false, @OA\Schema(type="integer", minimum=1, example=1)),
     *   @OA\Parameter(name="per_page", in="query", required=false, @OA\Schema(type="integer", minimum=1, maximum=100, example=31)),
     *   @OA\Response(response=200, description="Attendance history returned"),
     *   @OA\Response(response=401, description="Missing or expired token"),
     *   @OA\Response(response=422, description="Invalid query parameters")
     * )
     */
    public function attendanceHistory(Request $request)
    {
        $context = $this->currentStaffContext($request);
        if (!$context) return $this->staffUnavailableResponse();

        $validator = Validator::make($request->all(), [
            'month' => ['required', 'date_format:Y-m'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false, 'status' => 422, 'message' => 'Validation Error',
                'error_msg' => $validator->errors(), 'data' => null,
            ], 422);
        }

        $month = (string) $request->input('month');
        $perPage = (int) $request->input('per_page', 31);
        $page = $this->attendanceService->history((int) $context->sno, $month, $perPage);
        $records = collect($page->items())->map(static function (StaffAttendanceModel $row) {
            $date = $row->date ? Carbon::parse($row->date)->toDateString() : null;
            return [
                'id' => (int) $row->sno,
                'date' => $date,
                'attendance' => (string) $row->attendance,
                'leave_mode' => $row->leave_mode ?? null,
                'in_time' => $row->in_time,
                'out_time' => $row->out_time,
                'time_start' => $row->time_start,
                'time_end' => $row->time_end,
                'type' => $row->type,
                'reason' => $row->reason,
                'check_in' => [
                    'latitude' => $row->check_in_latitude === null ? null : (float) $row->check_in_latitude,
                    'longitude' => $row->check_in_longitude === null ? null : (float) $row->check_in_longitude,
                    'accuracy_m' => $row->check_in_accuracy_m === null ? null : (float) $row->check_in_accuracy_m,
                    'device_id' => $row->check_in_device_id,
                ],
                'check_out' => [
                    'latitude' => $row->check_out_latitude === null ? null : (float) $row->check_out_latitude,
                    'longitude' => $row->check_out_longitude === null ? null : (float) $row->check_out_longitude,
                    'accuracy_m' => $row->check_out_accuracy_m === null ? null : (float) $row->check_out_accuracy_m,
                    'device_id' => $row->check_out_device_id,
                ],
            ];
        })->values();

        return response()->json([
            'success' => true, 'status' => 200,
            'message' => 'Monthly attendance history fetched successfully.',
            'data' => $records,
            'summary' => $this->attendanceService->mobileMonthlySummary((int) $context->sno, $month),
            'meta' => [
                'month' => $month,
                'current_page' => $page->currentPage(), 'last_page' => $page->lastPage(),
                'per_page' => $page->perPage(), 'total' => $page->total(),
            ],
        ]);
    }

    /**
     * @OA\Get(path="/v1/staff/dashboard", operationId="staffMobileDashboard", summary="Get authenticated employee dashboard", tags={"Employee"}, security={{"bearerAuth":{}}},
     *   @OA\Parameter(name="month", in="query", required=false, @OA\Schema(type="string", pattern="^\\d{4}-(0[1-9]|1[0-2])$", example="2026-10")),
     *   @OA\Response(response=200, description="Dashboard summary returned"),
     *   @OA\Response(response=401, description="Missing or expired token")
     * )
     */
    public function dashboard(Request $request)
    {
        $context = $this->currentStaffContext($request);
        if (!$context) return $this->staffUnavailableResponse();

        $validator = Validator::make($request->all(), [
            'month' => ['nullable', 'date_format:Y-m'],
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false, 'status' => 422, 'message' => 'Validation Error',
                'error_msg' => $validator->errors(), 'data' => null,
            ], 422);
        }

        $today = now()->toDateString();
        $month = (string) $request->input('month', now()->format('Y-m'));
        $todayRow = StaffAttendanceModel::query()
            ->where('staff_id', (int) $context->sno)
            ->whereDate('date', $today)->where('status', 0)
            ->orderByDesc('sno')->first();

        $todayAttendance = $todayRow ? [
            'id' => (int) $todayRow->sno,
            'date' => Carbon::parse($todayRow->date)->toDateString(),
            'attendance' => (string) $todayRow->attendance,
            'leave_mode' => $todayRow->leave_mode ?? null,
            'in_time' => $todayRow->in_time,
            'out_time' => $todayRow->out_time,
            'time_start' => $todayRow->time_start,
            'time_end' => $todayRow->time_end,
            'type' => $todayRow->type,
            'reason' => $todayRow->reason,
            'today_check_in' => !empty($todayRow->in_time) ? 1 : 0,
            'today_check_out' => !empty($todayRow->out_time) ? 1 : 0,
        ] : [
            'id' => null, 'date' => $today, 'attendance' => null, 'leave_mode' => null,
            'in_time' => null, 'out_time' => null, 'time_start' => null, 'time_end' => null,
            'type' => null, 'reason' => null, 'today_check_in' => 0, 'today_check_out' => 0,
        ];

        $recentLeaves = DB::table('ryans_leave_requests')->where('staff_id', (int) $context->sno)->where('status', 0)
            ->orderByDesc('created_at')->orderByDesc('sno')->limit(5)
            ->get(['sno', 'leave_type', 'from_date', 'to_date', 'days', 'leave_mode', 'reason', 'approval_status', 'created_at'])
            ->map(static fn ($row) => [
                'id' => (int) $row->sno,
                'leave_type' => (string) $row->leave_type,
                'date' => (string) $row->from_date,
                'from_date' => (string) $row->from_date,
                'to_date' => (string) $row->to_date,
                'days' => round((float) ($row->days ?? 0), 2),
                'leave_mode' => (string) ($row->leave_mode ?? 'full'),
                'reason' => $row->reason,
                'approval_status' => $row->approval_status,
                'created_at' => $row->created_at,
            ])->values();

        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Dashboard fetched successfully.',
            'data' => [
                'staff' => [
                    'id' => (int) $context->sno,
                    'staff_id' => $context->staff_id ?? null,
                    'staff_name' => $context->staff_name ?? null,
                    'employment_type' => (int) $context->resolved_employment_type,
                    'staff_image_url' => !empty($context->staff_image) ? url('/api/v1/staff/profile/photo') : asset('assets/img/avatar/admin.png'),
                ],
                'today_attendance' => $todayAttendance,
                'attendance_summary' => $this->attendanceService->mobileMonthlySummary((int) $context->sno, $month),
                'leave_summary' => $this->leaveService->mobileRequestSummary((int) $context->sno),
                'leave_balances' => $this->leaveService->mobileBalanceSummary((int) $context->sno, $today),
                'recent_leave_requests' => $recentLeaves,
            ],
        ]);
    }

    /**
     * @OA\Post(path="/v1/staff/logout", operationId="staffMobileLogout", summary="Revoke the current mobile token", tags={"Employee"}, security={{"bearerAuth":{}}},
     *   @OA\Response(response=200, description="Logged out"),
     *   @OA\Response(response=401, description="Missing or expired token")
     * )
     */
    public function logout(Request $request)
    {
        /** @var PersonalAccessToken|null $token */
        $token = $request->attributes->get('mobile_access_token');
        if ($token) $token->delete();
        return response()->json([
            'success' => true, 
            'status' => 200,
            'message' => 'Logged out successfully.'
        ]);
    }

    /** Find an active staff profile and reconcile legacy employment category from users.staff_type. */
    private function currentStaffContext(Request $request): ?object
    {
        $user = $request->user();
        $staffId = (int) ($user->sno ?? $user->user_id ?? 0);
        if ($staffId <= 0) return null;
        $expectedType = null;
        if (isset($user->staff_type) && in_array((int) $user->staff_type, [1, 2], true)) {
            $expectedType = (int) $user->staff_type;
        }
        return $this->resolveStaffContext($staffId, $expectedType);
    }

    private function resolveStaffContext(int $staffId, ?int $expectedType = null): ?object
    {
        $staff = DB::table('ryans_staff as s')
            ->leftJoin('users as linked_user', 'linked_user.user_id', '=', 's.sno')
            ->where('s.sno', $staffId)
            ->select('s.*', 'linked_user.staff_type as linked_staff_type')
            ->first();
        if (!$staff) return null;

        $hrStatus = $staff->hr_status !== null
            ? (int) $staff->hr_status
            : match ((int) $staff->status) {
                0 => 0,
                1, 4 => 1,
                2 => 2,
                3, 5, 6, 7 => 3,
                default => 3,
            };
        if ($hrStatus !== 0) return null;

        $currentType = in_array((int) ($staff->employment_type ?? 0), [1, 2], true) ? (int) $staff->employment_type : null;
        $legacyType = in_array((int) ($staff->linked_staff_type ?? 0), [1, 2], true) ? (int) $staff->linked_staff_type : null;
        if ($currentType !== null && $legacyType !== null && $currentType !== $legacyType) return null;
        $employment = $currentType ?? $legacyType;
        if (!in_array($employment, [1, 2], true)) return null;
        if ($expectedType !== null && $expectedType !== $employment) return null;
        $staff->resolved_employment_type = $employment;
        return $staff;
    }

    private function staffUnavailableResponse()
    {
        return response()->json([
            'success' => false,
            'status' => 403,
            'message' => 'The staff profile is inactive or the employment category is not configured. Please contact the administrator.',
            'error_msg' => 'Staff profile unavailable.',
            'data' => null,
        ], 403);
    }

    private function validateLocation(Request $request): array
    {
        return $request->validate([
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'accuracy_m' => ['nullable', 'numeric', 'min:0', 'max:100000'],
            'device_id' => ['nullable', 'string', 'max:255'],
            'location' => ['nullable', 'string'],
        ]);
    }

    private function writeLoginLog(Request $request, ?int $userId, string $username, ?object $staff, array $data, bool $success): void
    {
        DB::table('mobile_user_login_logs')->insert([
            'user_id' => $userId,
            // This table records both successful and failed login attempts.
            'login_at' => Carbon::now('Asia/Kolkata'),
            'logout_at' => null,
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 4000),
            'mobile_no' => $staff->mobile_no ?? null,
            'user_name' => substr($username, 0, 250),
            'type' => $success ? 0 : 1,
            'failed_type' => $success ? null : 1,
            'latitude' => isset($data['latitude']) ? (string) $data['latitude'] : null,
            'longitude' => isset($data['longitude']) ? (string) $data['longitude'] : null,
            'device_id' => $data['device_id'] ?? null,
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);
    }


    public function checkInUpdate(
        int $staffId,
        int $employment,
        int $actor,
        ?float $latitude = null,
        ?float $longitude = null,
        ?string $check_in_location = null,
        ?float $accuracyM = null,
        ?string $deviceId = null,
    ): array {
        return DB::transaction(function () use ($staffId, $employment, $actor, $latitude, $longitude, $accuracyM, $deviceId,$check_in_location) {
            $staff = DB::table('ryans_staff')->where('sno', $staffId)->lockForUpdate()->first();
            if (!$staff || (int) ($staff->employment_type ?? $employment) !== $employment || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) !== 0) {
                throw new HttpResponseException(response()->json([
                    'success' => false,
                    'status' => 403,
                    'message' => 'Active staff profile was not found for this account.',
                    'error_msg' => 'Active staff profile was not found for this account.',
                    'data' => null,
                ], 403));
            }
            $today = now()->toDateString();
            $row = StaffAttendanceModel::query()->where('staff_id', $staffId)->whereDate('date', $today)->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();
            if ($row && strtoupper((string) $row->attendance) === 'L' && (string) $row->type === 'Leave Management') {
                
                throw new HttpResponseException(response()->json([
                    'success' => false,
                    'status' => 403,
                    'message' => 'Approved leave is recorded for today. Contact HR if this attendance needs correction.',
                    'error_msg' => 'Approved leave is recorded for today. Contact HR if this attendance needs correction.',
                    'data' => null,
                ], 403));
                
            }
            if ($row && $row->in_time){
                throw new HttpResponseException(response()->json([
                    'success' => false,
                    'status' => 403,
                    'message' => 'You have already checked in today.',
                    'error_msg' => 'You have already checked in today.',
                    'data' => null,
                ], 403));
            } 
            
            if ($row) {
                $row->attendance = 'P';
                $row->in_time = now()->format('H:i:s');
                $row->type = 'Mobile';
                $row->check_in_latitude = $latitude;
                $row->check_in_longitude = $longitude;
                $row->check_in_accuracy_m = $accuracyM;
                $row->check_in_device_id = $deviceId;
                $row->check_in_location = $check_in_location;
                $row->updated_by = $actor;
                $row->updated_at = now();
                $row->save();
            } else {
                $row = StaffAttendanceModel::query()->create([
                    'staff_attendance_id' => 'ATT-' . $staffId . '-' . now()->format('Ymd'),
                    'date' => $today,
                    'staff_id' => $staffId,
                    'attendance' => 'P',
                    'in_time' => now()->format('H:i:s'),
                    'type' => 'Mobile',
                    'reason' => null,
                    'check_in_latitude' => $latitude,
                    'check_in_longitude' => $longitude,
                    'check_in_accuracy_m' => $accuracyM,
                    'check_in_device_id' => $deviceId,
                    'check_in_location' => $check_in_location,
                    'created_by' => $actor,
                    'updated_by' => $actor,
                    'status' => 0,
                ]);
            }
            return [
                'id' => (int) $row->sno,
                'date' => $today,
                'in_time' => $row->in_time,
                'attendance' => $row->attendance,
                'check_in' => ['latitude' => $row->check_in_latitude, 'longitude' => $row->check_in_longitude, 'accuracy_m' => $row->check_in_accuracy_m, 'device_id' => $row->check_in_device_id],
            ];
        }, 3);
    }

    public function checkOutUpdate(
        int $staffId,
        int $employment,
        int $actor,
        ?float $latitude = null,
        ?float $longitude = null,
        ?string $check_out_location = null,
        ?float $accuracyM = null,
        ?string $deviceId = null,
    ): array {
        return DB::transaction(function () use ($staffId, $employment, $actor, $latitude, $longitude, $accuracyM, $deviceId,$check_out_location) {
            $staff = DB::table('ryans_staff')->where('sno', $staffId)->lockForUpdate()->first();
            if (!$staff || (int) ($staff->employment_type ?? $employment) !== $employment || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) !== 0) {
                throw ValidationException::withMessages(['staff' => 'Active staff profile was not found for this account.']);
            }
            $row = StaffAttendanceModel::query()->where('staff_id', $staffId)->whereDate('date', now()->toDateString())->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();
            if (!$row || !$row->in_time) throw ValidationException::withMessages(['check_out' => 'Check-in is required before check-out.']);
            if ($row->out_time) throw ValidationException::withMessages(['check_out' => 'You have already checked out today.']);
            $row->out_time = now()->format('H:i:s');
            $row->check_out_latitude = $latitude;
            $row->check_out_longitude = $longitude;
            $row->check_out_accuracy_m = $accuracyM;
            $row->check_out_device_id = $deviceId;
            $row->check_out_location = $check_out_location;
            $row->updated_by = $actor;
            $row->updated_at = now();
            $row->save();
            return [
                'id' => (int) $row->sno,
                'date' => (string) $row->date,
                'in_time' => $row->in_time,
                'out_time' => $row->out_time,
                'check_out' => ['latitude' => $row->check_out_latitude, 'longitude' => $row->check_out_longitude, 'accuracy_m' => $row->check_out_accuracy_m, 'device_id' => $row->check_out_device_id],
            ];
        }, 3);
    }
}
