@extends('layouts.layoutMaster')

@section('title', 'Admin & HR Payroll Configuration')

@section('content')
<div class="container-fluid px-0" id="adminHrPayrollConfiguration">
    <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4">
        <div>
            <div class="text-muted small mb-1">Settings / Admin &amp; HR</div>
            <h4 class="fw-bold mb-1" style="color:#0C3C62;">Payroll Configuration</h4>
            <p class="text-muted mb-0">Configure gross earnings, employee deductions and employer contributions used by Staff Add and the Wages menu.</p>
        </div>
        <button type="button" class="btn btn-outline-primary" id="payrollReloadButton">
            <i class="mdi mdi-refresh me-1"></i> Reload settings
        </button>
    </div>

    <div class="alert alert-info d-flex align-items-start gap-2 mb-4">
        <i class="mdi mdi-information-outline fs-5"></i>
        <div class="small">
            <strong>Component A:</strong> earning percentages should total 100%, or use one <em>Remainder of Gross</em> component.
            Example: Basic Salary 50% + HRA 30% + Special Allowance 20%. All amounts shown in Staff Add and Wages are calculated by the server from these settings.
        </div>
    </div>

    <div id="payrollConfigurationMessage" class="alert d-none" role="status"></div>
    <div id="payrollConfigurationLoading" class="card border-0 shadow-sm mb-4">
        <div class="card-body py-5 text-center text-muted">
            <span class="spinner-border spinner-border-sm me-2" role="status"></span> Loading remuneration components and payroll rules…
        </div>
    </div>

    <div id="payrollConfigurationContent" class="d-none">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-header bg-white border-0 px-4 pt-4">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div>
                        <h5 class="fw-bold mb-1">Component A — Employee Gross Earnings</h5>
                        <small class="text-muted">Set each earning as a percentage of gross, a base-dependent percentage, a fixed amount, or the remaining gross.</small>
                    </div>
                    <span class="badge bg-primary-subtle text-primary" id="componentAPercentageTotal">0.0% configured</span>
                </div>
            </div>
            <div class="card-body px-4 pb-4">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="min-width:190px;">Earning component</th>
                                <th style="min-width:175px;">Calculation method</th>
                                <th style="width:125px;">Rate / %</th>
                                <th style="min-width:170px;">Base component</th>
                                <th style="width:95px;">Enabled</th>
                            </tr>
                        </thead>
                        <tbody id="payrollGroupABody"></tbody>
                    </table>
                </div>
                <div class="small text-muted mt-2">The Remainder method can be assigned to only one earning. If you use percentage splits, make sure all active earning percentages total 100%.</div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-header bg-white border-0 px-4 pt-4">
                <h5 class="fw-bold mb-1">Component B — Employee Deductions</h5>
                <small class="text-muted">Configure PF, ESI, professional tax, TDS preview and other employee deductions.</small>
            </div>
            <div class="card-body px-4 pb-4">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="min-width:180px;">Deduction component</th>
                                <th style="min-width:170px;">Calculation method</th>
                                <th style="width:115px;">Rate / %</th>
                                <th style="min-width:165px;">Base component</th>
                                <th style="width:125px;">Eligibility threshold</th>
                                <th style="width:115px;">Wage ceiling</th>
                                <th style="width:105px;">Maximum cap</th>
                                <th style="width:80px;">Enabled</th>
                            </tr>
                        </thead>
                        <tbody id="payrollGroupBBody"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-header bg-white border-0 px-4 pt-4">
                <h5 class="fw-bold mb-1">Component C — Employer Contributions &amp; Benefits</h5>
                <small class="text-muted">Configure employer PF, employer ESI, gratuity accrual and other employer-side cost components.</small>
            </div>
            <div class="card-body px-4 pb-4">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="min-width:180px;">Employer component</th>
                                <th style="min-width:170px;">Calculation method</th>
                                <th style="width:115px;">Rate / %</th>
                                <th style="min-width:165px;">Base component</th>
                                <th style="width:125px;">Eligibility threshold</th>
                                <th style="width:115px;">Wage ceiling</th>
                                <th style="width:105px;">Maximum cap</th>
                                <th style="width:80px;">Enabled</th>
                            </tr>
                        </thead>
                        <tbody id="payrollGroupCBody"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-header bg-white border-0 px-4 pt-4">
                <h5 class="fw-bold mb-1">Test gross salary calculation</h5>
                <small class="text-muted">Preview the configured split before saving or using it in Staff Add/Wages.</small>
            </div>
            <div class="card-body px-4 pb-4">
                <div class="row g-3 align-items-end">
                    <div class="col-12 col-md-4">
                        <label for="payrollPreviewGross" class="form-label fw-semibold">Monthly gross salary (₹)</label>
                        <input id="payrollPreviewGross" class="form-control" type="number" min="0.01" max="999999999" step="0.01" value="30000" inputmode="decimal">
                    </div>
                    <div class="col-auto">
                        <button type="button" class="btn btn-outline-primary" id="payrollPreviewButton"><i class="mdi mdi-calculator me-1"></i> Calculate preview</button>
                    </div>
                </div>
                <div id="payrollPreviewResult" class="mt-3 d-none"></div>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2 mb-5">
            <button type="button" class="btn btn-light" id="payrollCancelButton">Reload saved settings</button>
            <button type="button" class="btn btn-primary" id="payrollSaveButton"><i class="mdi mdi-content-save me-1"></i> Save Payroll Configuration</button>
        </div>
    </div>
</div>

<script>
(() => {
    'use strict';

    const payrollApi = '/admin-hr/api';
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    const state = { components: [], rules: [], lastPreview: null };
    const methodsA = [
        ['percentage_gross', 'Percentage of Gross'],
        ['percentage_basic', 'Percentage of Basic'],
        ['percentage_component', 'Percentage of selected component'],
        ['remainder', 'Remainder of Gross'],
        ['flat', 'Fixed amount'],
        ['none', 'No calculation']
    ];
    const methodsBC = [
        ['percentage_gross', 'Percentage of Gross'],
        ['percentage_basic', 'Percentage of Basic'],
        ['percentage_component', 'Percentage of selected component'],
        ['pf', 'PF contribution'],
        ['esi', 'ESI contribution'],
        ['tds', 'TDS monthly preview'],
        ['flat', 'Fixed amount'],
        ['none', 'No calculation']
    ];

    const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[char]);
    const money = value => `₹${Number(value || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    async function payrollRequest(url, options = {}) {
        const response = await fetch(url, {
            credentials: 'same-origin',
            ...options,
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': csrfToken,
                ...(options.headers || {})
            }
        });
        let payload = {};
        try { payload = await response.json(); } catch (_) { /* response validation below */ }
        if (!response.ok || payload.success === false) {
            const validation = Object.values(payload.errors || {}).flat().filter(Boolean)[0];
            throw new Error(payload.message || validation || `Request failed (${response.status}).`);
        }
        return payload;
    }

    function showMessage(message, type = 'info') {
        const host = document.getElementById('payrollConfigurationMessage');
        if (!host) return;
        host.className = `alert alert-${type}`;
        host.textContent = message;
        host.classList.remove('d-none');
    }

    function hideMessage() {
        document.getElementById('payrollConfigurationMessage')?.classList.add('d-none');
    }

    function groupFor(component) {
        const group = String(component.group || '').toUpperCase();
        return ['A', 'B', 'C'].includes(group) ? group : 'A';
    }

    function readFormRules() {
        return [...document.querySelectorAll('[data-payroll-rule-row]')].map(row => {
            const result = { type_id: Number(row.dataset.payrollRuleRow), sort_order: Number(row.dataset.sortOrder || 0) };
            row.querySelectorAll('[data-key]').forEach(input => {
                const key = input.dataset.key;
                if (input.type === 'checkbox') result[key] = input.checked;
                else if (key === 'calculation_method') result[key] = input.value;
                else if (key === 'base_component_id') result[key] = input.value ? Number(input.value) : null;
                else result[key] = input.value === '' ? null : Number(input.value);
            });
            return result;
        });
    }

    function updatePercentageSummary() {
        const rules = readFormRules();
        const earningRules = rules.filter(rule => {
            const component = state.components.find(item => Number(item.type_id) === Number(rule.type_id));
            return component && groupFor(component) === 'A' && rule.enabled;
        });
        const percentageTotal = earningRules
            .filter(rule => rule.calculation_method === 'percentage_gross')
            .reduce((sum, rule) => sum + Number(rule.rate || 0), 0);
        const baseDependentCount = earningRules.filter(rule => ['percentage_basic', 'percentage_component'].includes(rule.calculation_method)).length;
        const remainderCount = earningRules.filter(rule => rule.calculation_method === 'remainder').length;
        const label = document.getElementById('componentAPercentageTotal');
        if (label) {
            label.textContent = `${percentageTotal.toFixed(1)}% of Gross${baseDependentCount ? ` · ${baseDependentCount} base-based` : ''}${remainderCount ? ' + Remainder' : ''}`;
            const grossSplitComplete = remainderCount > 0 || Math.abs(percentageTotal - 100) < 0.01;
            label.className = `badge ${grossSplitComplete ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning'}`;
        }
    }

    function componentRow(component, rule) {
        const group = groupFor(component);
        const methods = group === 'A' ? methodsA : methodsBC;
        const baseId = rule.base_component_id == null ? '' : String(rule.base_component_id);
        const baseOptions = state.components.filter(item => groupFor(item) === 'A');
        const componentCell = `<strong>${escapeHtml(component.name)}</strong><small class="d-block text-muted">${escapeHtml(component.description || '')}</small>`;
        const methodOptions = methods.map(([value, label]) => `<option value="${value}" ${rule.calculation_method === value ? 'selected' : ''}>${label}</option>`).join('');
        const baseSelect = `<select class="form-select form-select-sm" data-key="base_component_id" aria-label="Base component"><option value="">Default Basic / Gross</option>${baseOptions.map(item => `<option value="${Number(item.type_id)}" ${baseId === String(item.type_id) ? 'selected' : ''}>${escapeHtml(item.name)}</option>`).join('')}</select>`;
        const rateInput = `<input class="form-control form-control-sm text-end" type="number" min="0" max="999999999" step="0.01" data-key="rate" value="${Number(rule.rate || 0)}" aria-label="Rate or percentage">`;
        const enabled = `<input class="form-check-input" type="checkbox" data-key="enabled" ${rule.enabled ? 'checked' : ''} aria-label="Enable ${escapeHtml(component.name)}">`;
        if (group === 'A') {
            return `<tr data-payroll-rule-row="${Number(component.type_id)}" data-sort-order="${Number(rule.sort_order || component.type_id)}">
                <td>${componentCell}</td>
                <td><select class="form-select form-select-sm" data-key="calculation_method">${methodOptions}</select></td>
                <td>${rateInput}</td>
                <td>${baseSelect}</td>
                <td class="text-center">${enabled}</td>
            </tr>`;
        }
        return `<tr data-payroll-rule-row="${Number(component.type_id)}" data-sort-order="${Number(rule.sort_order || component.type_id)}">
            <td>${componentCell}</td>
            <td><select class="form-select form-select-sm" data-key="calculation_method">${methodOptions}</select></td>
            <td>${rateInput}</td>
            <td>${baseSelect}</td>
            <td><input class="form-control form-control-sm text-end" type="number" min="0" step="0.01" data-key="threshold_amount" value="${rule.threshold_amount ?? ''}" placeholder="—"></td>
            <td><input class="form-control form-control-sm text-end" type="number" min="0" step="0.01" data-key="wage_ceiling" value="${rule.wage_ceiling ?? ''}" placeholder="—"></td>
            <td><input class="form-control form-control-sm text-end" type="number" min="0" step="0.01" data-key="cap_amount" value="${rule.cap_amount ?? ''}" placeholder="—"></td>
            <td class="text-center">${enabled}</td>
        </tr>`;
    }

    function renderConfiguration() {
        const groups = { A: [], B: [], C: [] };
        state.components.forEach(component => groups[groupFor(component)].push(component));
        const ruleMap = new Map(state.rules.map(rule => [Number(rule.type_id), rule]));
        for (const group of ['A', 'B', 'C']) {
            const body = document.getElementById(`payrollGroup${group}Body`);
            if (!body) continue;
            body.innerHTML = groups[group].length ? groups[group].map(component => {
                const rule = ruleMap.get(Number(component.type_id)) || {
                    type_id: Number(component.type_id), group,
                    calculation_method: group === 'A' ? 'percentage_gross' : 'none',
                    rate: 0, base_component_id: null, threshold_amount: null,
                    wage_ceiling: null, cap_amount: null, enabled: true,
                    sort_order: Number(component.type_id)
                };
                return componentRow(component, rule);
            }).join('') : `<tr><td colspan="${group === 'A' ? 5 : 8}" class="text-muted small">No active Component ${group} remuneration types. Add them in Remuneration Type settings first.</td></tr>`;
        }
        document.getElementById('payrollConfigurationLoading')?.classList.add('d-none');
        document.getElementById('payrollConfigurationContent')?.classList.remove('d-none');
        updatePercentageSummary();
    }

    async function loadConfiguration() {
        hideMessage();
        document.getElementById('payrollConfigurationContent')?.classList.add('d-none');
        document.getElementById('payrollConfigurationLoading')?.classList.remove('d-none');
        const result = await payrollRequest(`${payrollApi}/payroll-config`);
        state.components = result.data?.components || [];
        state.rules = result.data?.rules || [];
        renderConfiguration();
    }

    async function saveConfiguration() {
        const rules = readFormRules();
        if (!rules.length) {
            showMessage('No active remuneration components are available to configure.', 'warning');
            return;
        }
        const earningComponents = state.components.filter(component => groupFor(component) === 'A');
        const enabledEarnings = rules.filter(rule => rule.enabled && earningComponents.some(component => Number(component.type_id) === Number(rule.type_id)));
        if (!enabledEarnings.length) {
            showMessage('Enable at least one Component A earning before saving.', 'warning');
            return;
        }
        const remainderCount = enabledEarnings.filter(rule => rule.calculation_method === 'remainder').length;
        if (remainderCount > 1) {
            showMessage('Only one Component A earning can use Remainder of Gross.', 'warning');
            return;
        }
        const grossPercentageRules = enabledEarnings.filter(rule => rule.calculation_method === 'percentage_gross');
        const totalGrossPercent = grossPercentageRules.reduce((sum, rule) => sum + Number(rule.rate || 0), 0);
        const allEnabledAreGrossPercent = grossPercentageRules.length === enabledEarnings.length;
        if (!remainderCount && allEnabledAreGrossPercent && Math.abs(totalGrossPercent - 100) > 0.01) {
            showMessage(`Component A percentages of Gross currently total ${totalGrossPercent.toFixed(2)}%. They must total 100% or one earning must be set to Remainder of Gross.`, 'warning');
            return;
        }
        const button = document.getElementById('payrollSaveButton');
        if (button) button.disabled = true;
        hideMessage();
        try {
            const result = await payrollRequest(`${payrollApi}/payroll-config`, {
                method: 'PUT', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ rules })
            });
            showMessage(result.message || 'Payroll configuration saved successfully.', 'success');
            const refreshed = await payrollRequest(`${payrollApi}/payroll-config`);
            state.components = refreshed.data?.components || [];
            state.rules = refreshed.data?.rules || [];
            renderConfiguration();
        } catch (error) {
            showMessage(error.message, 'danger');
        } finally {
            if (button) button.disabled = false;
        }
    }

    async function previewCalculation() {
        const gross = Number(document.getElementById('payrollPreviewGross')?.value || 0);
        const host = document.getElementById('payrollPreviewResult');
        if (!host) return;
        if (gross <= 0) {
            showMessage('Enter a positive monthly gross salary to preview the split.', 'warning');
            host.classList.add('d-none');
            return;
        }
        try {
            const result = await payrollRequest(`${payrollApi}/payroll/calculate`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ gross_amount: gross })
            });
            const data = result.data || {};
            const totals = data.totals || {};
            host.innerHTML = `<div class="table-responsive"><table class="table table-sm table-bordered mb-0">
                <tbody>
                    <tr><th>Component A — Gross earnings</th><td class="text-end">${money(totals.A)}</td></tr>
                    <tr><th>Component B — Employee deductions</th><td class="text-end text-danger">${money(totals.B)}</td></tr>
                    <tr><th>Net take-home (A − B)</th><td class="text-end fw-bold text-success">${money(data.net_pay)}</td></tr>
                    <tr><th>Component C — Employer contributions</th><td class="text-end">${money(totals.C)}</td></tr>
                    <tr><th>Monthly CTC (A + C)</th><td class="text-end fw-bold">${money(data.ctc)}</td></tr>
                </tbody></table></div>`;
            host.classList.remove('d-none');
            showMessage('Preview calculated from the currently saved payroll rules.', 'success');
        } catch (error) {
            host.classList.add('d-none');
            showMessage(error.message, 'danger');
        }
    }

    document.addEventListener('change', event => {
        if (event.target.closest('[data-payroll-rule-row]')) updatePercentageSummary();
    });
    document.addEventListener('input', event => {
        if (event.target.closest('[data-payroll-rule-row]')) updatePercentageSummary();
    });
    document.getElementById('payrollSaveButton')?.addEventListener('click', saveConfiguration);
    document.getElementById('payrollReloadButton')?.addEventListener('click', () => loadConfiguration().catch(error => showMessage(error.message, 'danger')));
    document.getElementById('payrollCancelButton')?.addEventListener('click', () => loadConfiguration().catch(error => showMessage(error.message, 'danger')));
    document.getElementById('payrollPreviewButton')?.addEventListener('click', previewCalculation);

    loadConfiguration().catch(error => {
        document.getElementById('payrollConfigurationLoading')?.classList.add('d-none');
        showMessage(error.message, 'danger');
    });
})();
</script>
@endsection
