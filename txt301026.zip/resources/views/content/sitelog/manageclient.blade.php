@extends('layouts/layoutMaster')

@section('title', 'Client')

@section('content')

<style>
    /* Hide the text caret outside editable fields on this page. */
    #clientlist,
    #addClient,
    #updateClient {
        caret-color: transparent;
    }

    /* Keep the blinking caret visible only inside actual text-entry fields. */
    #clientlist input,
    #addClient input:not([type="file"]),
    #addClient textarea,
    #updateClient input,
    #updateClient textarea {
        caret-color: auto;
    }

    /* Keep the document upload control the same width and height as other fields. */
    #addClient .client-upload-input {
        width: 100%;
        height: 38px;
        padding: 5px 8px;
        border: 1px dashed #b8c4d6;
        border-radius: 6px;
        background-color: #f8fafc;
        font-size: .875rem;
    }

    #addClient .client-upload-input:hover,
    #addClient .client-upload-input:focus {
        border-color: var(--bs-primary);
    }

    #addClient #clientDocumentList .client-document-row {
        min-width: 0;
    }

    @media (max-width: 575.98px) {
        #addClient #clientDocumentList .client-document-row {
            align-items: flex-start !important;
        }
    }
</style>

<div id="clientlist">
  <div class="card rounded">
      <div class="d-flex justify-content-between p-3">
          <div class="d-flex gap-3 align-items-center">
              <i class="mdi mdi-office-building text-primary fs-4"></i>

              <div class="d-flex flex-column">
                  <label class="text-primary fw-bold mb-1 text-uppercase">Client</label>

                  <span class="text-muted fw-semibold">
                      Site Operations Management & Logs
                  </span>
              </div>
          </div>
          <div>
            <button
                type="button"
                class="btn btn-primary d-flex align-items-center gap-2"
                onclick="showAddClient()"
            >
                <i class="mdi mdi-plus"></i>
                Add Client
            </button>
          </div>
      </div>
  </div>

  <div class="card rounded shadow-sm mt-3">
      <div class="card-body p-4">
          <div class="d-flex flex-column flex-md-row align-items-md-center gap-3 mb-4">
            <div>
                <span>Show</span>
                    <select id="perpage" class="form-select form-select-sm w-75px"
                        onchange="loadThemes(1)">
                             @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                             <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                    </select>
                    </div>
              <div class="position-relative justify-content-between mt-4" style="max-width: 500px; width: 100%;">
                  <i class="mdi mdi-magnify position-absolute top-50 start-0 translate-middle-y ms-3 text-muted fs-5"></i>
                  <input
                      type="search"
                      class="form-control ps-5 rounded"
                      placeholder="Search by client name, contact, GST, PAN, address..." id="search_filter"/>
              </div>
              <div class="d-flex flex-column flex-md-row align-items-md-center gap-5 mt-4">
              <span class="badge bg-label-primary px-3 py-2" id="count">
                      <i class="mdi mdi-account-multiple-outline me-1"></i>
                      Showing {{$count}} client records
                  </span>
            </div>
              
          </div>
          
              

          <div class="table-responsive rounded">
              <table class="table border table-hover align-middle mb-0">
                  <thead class="table-light">
                      <tr>
                          <th class="text-dark text-uppercase fs-8">Client Name</th>
                          <th class="text-dark text-uppercase fs-8">Contact Person</th>
                          <th class="text-dark text-uppercase fs-8">Contact No & Email</th>
                          <th class="text-dark text-uppercase fs-8">Alternate Contact</th>
                          <th class="text-dark text-uppercase fs-8">Address</th>
                          <th class="text-dark text-uppercase fs-8">PAN / GST No</th>
                          <th class="text-dark text-uppercase fs-8">Status</th>
                          <th class="text-dark text-uppercase fs-8 text-center">Action</th>
                      </tr>
                  </thead>
                  
                  <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                        <tr class="skeleton-loader" id="skeleton-loader">
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                        </tr> 
                    </tbody>
              </table>
          </div>
          <div class="text-center my-3" id="pagination-container">
            <!-- Pagination buttons will appear here -->
        </div>
      </div>
  </div>
</div>

<!-- add client -->
<div id="addClient" class="d-none">
  <div class="card rounded shadow-sm mt-3">
    <div class="card-header bg-white border-bottom py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <button
                    type="button"
                    class="btn"
                    title="Back"
                    onclick="showClientList()"
                >
                    <i class="mdi mdi-chevron-double-left"></i>
                </button>

                <div>
                    <h6 class="mb-0 text-dark fw-bold text-uppercase">
                        Add Client
                    </h6>
                </div>
            </div>
            
        </div>
    </div>
<form action="{{ route('add_client') }}" method="POST" enctype="multipart/form-data" autocomplete="off" id="addclientForm">
    @csrf
    <div class="card-body p-4">
        <div class="row g-4">
            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Client Name
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. SPK and Co." id="client_name" name="client_name"/>

                <small class="text-muted">
                    Enter the registered client name.
                </small>
                <div class="text-danger" id="client_name_err"></div>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Contact Person
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. S.Nagarajan" id="contact_person" name="contact_person"/>
                    <div class="text-danger" id="contact_person_err"></div>
            </div>

            <!-- Contact Number -->
            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Contact No
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. 98765 43210" id="contact_no" name="contact_no"/>
                    <div class="text-danger" id="contact_no_err"></div>
            </div>

            <!-- Email -->
            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Email
                </label>

                <input
                    type="email"
                    class="form-control"
                    placeholder="e.g. client@example.com" id="email_id" name="email_id"
                />
                <div class="text-danger" id="email_id_err"></div>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Alternate Contact Person
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. Boominathan" id="alter_contact_person" name="alter_contact_person" 
                />
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Alternate Contact No
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. phone or mobile" id="alter_contact_no" name="alter_contact_no"
                />
            </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Country
                      <span class="text-danger">*</span>
                  </label>
                  <select id="country_id" name="country_id" class="form-select" onchange="countrychange()">
                      <option value="">Select Country</option>
                       @foreach ($country_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->country_name}}</option> 
                       @endforeach
                  </select>
                  <div class="text-danger" id="country_id_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      State
                      <span class="text-danger">*</span>
                  </label>

                  <select id="state_id" name="state_id" class="form-select" onchange="statechange()">
                      <option value="">Select State</option>
                       
                  </select>
                  <div class="text-danger" id="state_id_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      City
                      <span class="text-danger">*</span>
                  </label>

                  <select id="city_id" name="city_id" class="form-select">
                      <option value="">Select City</option>
                       
                  </select>
                  <div class="text-danger" id="city_id_err"></div>
              </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Address (Door no. / Area)
                </label>
                <textarea
                    class="form-control"
                    rows="1"
                    placeholder="Enter client address" id="address" name="address"
                ></textarea>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    GST Number
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. 33ABCDE1234F1Z5" id="gst_number" name="gst_number"
                />
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    PAN Number
                </label>
                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. ABCDE1234F" id="pan_number" name="pan_number"
                />
            </div>

            <div class="col-md-4">
                <label for="clientDocuments" id="upload_doc" name="upload_doc" class="form-label fw-semibold text-dark">
                    Upload Documents
                </label>
                <input
                    type="file"
                    id="client_document" name="client_doc[]"
                    class="form-control client-upload-input"
                    accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                    multiple
                    onchange="handleClientDocuments(this)"
                />
                
                <small class="text-muted d-block mt-1">
                    PDF, DOC, DOCX, JPG, PNG · Max 5 MB per file
                </small>

                <div id="clientDocumentList" class="mt-2"></div>
                <div id="clientDocumentError" class="text-danger small mt-2"></div>
            </div>
        </div>
    </div>

    <div class="card-footer bg-white border-top d-flex justify-content-end gap-2 py-3">

      <button
          type="button"
          class="btn btn-outline-secondary"
          onclick="showClientList()"
      >
          Cancel
      </button>

      <button
          type="button"
          class="btn btn-primary" id="saveclient" onclick="AddValidation()">
          Save Client
      </button>
    </div>
</form>
  </div>
</div>

<!-- update client -->
<div id="updateClient" class="d-none">
    <div class="card rounded shadow-sm mt-3">
        <div class="card-header bg-white border-bottom py-3">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-2">
                    <button
                        type="button"
                        class="btn"
                        title="Back"
                        onclick="showClientList()"
                    >
                        <i class="mdi mdi-chevron-double-left"></i>
                    </button>

                    <div class="mt-3">
                      <h4>Update Client</h4>
                    </div>
                </div>

                <div>
                    <span id="updateSystemCode">
                        System Code: CLI-SPK-01
                    </span>
                </div>

            </div>
        </div>
    
        <div class="card-body p-4">
            <div class="row g-4">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Client Name
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        id="updateClientName" name="updateClientName"
                        class="form-control"
                        placeholder="e.g. SPK and Co."
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Contact Person
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        id="updateContactPerson"
                        class="form-control"
                        placeholder="e.g. S.Nagarajan"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Contact No
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="tel"
                        id="updateContactNo" name="updateContactNo"
                        class="form-control"
                        placeholder="e.g. 98765 43210"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Email
                    </label>

                    <input
                        type="email"
                        id="updateEmail" name="updateEmail"
                        class="form-control"
                        placeholder="e.g. client@example.com"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Alternate Contact Person
                    </label>

                    <input
                        type="text"
                        id="updateAlternateContactPerson" name="updateAlternateContactPerson"
                        class="form-control"
                        placeholder="e.g. Boominathan"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Alternate Contact No
                    </label>

                    <input
                        type="text"
                        id="updateAlternateContactNo" name="updateAlternateContactNo"
                        class="form-control"
                        placeholder="e.g. phone or mobile"
                    />
                </div>
                <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Country
                      <span class="text-danger">*</span>
                  </label>
                  <select id="update_country_id" name="country_id" class="form-select" onchange="update_country_change()">
                      <option value="">Select Country</option>
                       @foreach ($country_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->country_name}}</option> 
                       @endforeach
                  </select>
                  <div class="text-danger" id="country_id_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      State
                      <span class="text-danger">*</span>
                  </label>

                  <select id="update_state_id" name="state_id" class="form-select" onchange="update_statechange()">
                      <option value="">Select State</option>
                       
                  </select>
                  <div class="text-danger" id="state_id_err"></div>
              </div>
            <div class="col-md-4">  
                  <label class="form-label fw-semibold text-dark">
                      City
                      <span class="text-danger">*</span>
                  </label>

                  <select id="update_city_id" name="update_city_id" class="form-select">
                      <option value="">Select City</option>
                       
                  </select>
                  <div class="text-danger" id="city_id_err"></div>
              </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Address
                    </label>

                    <textarea
                        id="updateAddress" name="updateAddress"
                        class="form-control"
                        rows="1"
                        placeholder="Enter client address"
                    ></textarea>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        GST Number
                    </label>

                    <input
                        type="text"
                        id="updateGst" name="updateGst"
                        class="form-control"
                        placeholder="e.g. 33ABCDE1234F1Z5"
                    />
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        PAN Number
                    </label>

                    <input
                        type="text"
                        id="updatePan" name="updatePan"
                        class="form-control"
                        placeholder="e.g. ABCDE1234F"
                    />
                </div>
                <div class="col-md-4">
                <label for="updateclientDocuments" id="update_upload_doc" name="update_upload_doc" class="form-label fw-semibold text-dark">
                    Upload Documents
                </label>
                <input
                    type="file"
                    id="updateclientDocuments" name="update_client_doc[]"
                    class="form-control client-upload-input"
                    accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                    multiple
                    onchange="handleDocuments(this)"
                />
                

                <small class="text-muted d-block mt-1">
                    PDF, DOC, DOCX, JPG, PNG · Max 5 MB per file
                </small>

                <div id="updateclientDocumentList" class="mt-2"></div>
                <div id="updateclientDocumentError" class="text-danger small mt-2"></div>
            </div>
            </div>
        </div>

        <div class="card-footer bg-white border-top d-flex justify-content-end gap-2 py-3">
            <button type="button" class="btn btn-outline-secondary" onclick="showClientList()">
                Cancel
            </button>
            <button
          type="button"
          class="btn btn-primary" id="edit_client" onclick="saveClientUpdate()">
          Update Client
      </button>
        </div>
    </div>
</div>

<!-- View Client Modal -->
<div class="modal fade" id="viewClientModal" tabindex="-1" aria-labelledby="viewClientModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-between align-items-center border-bottom">
                <div class="d-flex flex-column mb-3">
                    <h5 class="modal-title" id="viewClientModalLabel">
                        Client Details
                    </h5>

                    <small class="text-muted">
                        System Code:
                        <span id="viewSystemCode" class="fw-bold"></span>
                    </small>
                </div>

                <div class="mb-3">
                  <button
                      type="button"
                      class="btn-close mb-3"
                      data-bs-dismiss="modal"
                      aria-label="Close">
                  </button>
                </div>
            </div>

            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Client Name:
                        </label>

                        <div class="text-black">
                            <span id="viewClientName">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Contact Person:
                        </label>

                        <div class="text-black">
                            <span id="viewContactPerson">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Contact Number:
                        </label>

                        <div class="text-black">
                            <span id="viewContactNo">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Email:
                        </label>

                        <div class="text-black">
                            <span id="viewEmail">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Alternate Contact Person:
                        </label>

                        <div class="text-black">
                            <span id="viewAlternateContactPerson">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            Alternate Contact Number:
                        </label>

                        <div class="text-black">
                            <span id="viewAlternateContactNo">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            GST Number:
                        </label>

                        <div class="text-black">
                            <span id="viewGst">-</span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-muted">
                            PAN Number:
                        </label>

                        <div class="text-black">
                            <span id="viewPan">-</span>
                        </div>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold text-muted">
                            Address:
                        </label>

                        <div class="text-black">
                            <span id="viewAddress">-</span>
                        </div>              
                        <div class="row g-3">
                            <div class="col-12">
                            </div>
                        </div>                   
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- delete client -->
<div class="modal fade" id="deleteClientModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow w-100" style="max-width: 400px">
            <div class="modal-body text-center p-4">
                <div
                    class="d-flex align-items-center justify-content-center rounded-circle mx-auto mb-3"
                    style="
                        width: 48px;
                        height: 48px;
                        background-color: #fff0f1;
                        color: #ff3e5b;
                    "
                >
                    <i class="mdi mdi-trash-can-outline fs-4"></i>
                </div>

                <h5 class="fw-bold text-dark mb-2">
                    Confirm Deletion
                </h5>
                <p class="text-muted small mb-4" id="delete_message">
                    Are you sure you want to delete client record
                    <strong>"SPK And Co., - VF"</strong>?
                    This action cannot be undone.
                </p>
                <div class="row g-2">
                    <div class="col-6">
                        <button
                            type="button"
                            class="btn btn-light w-100"
                            data-bs-dismiss="modal"
                        >
                            Cancel
                        </button>
                    </div>

                    <div class="col-6">
                        <button
                            type="button"
                            class="btn btn-danger w-100" onclick="deletelevel()"
                        >
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    function AddValidation() {
            let err=0;  
            var client_name=$('#client_name').val();
            var contact_person=$('#contact_person').val();
            var contact_no=$('#contact_no').val();
            var country_id=$('#country_id').val();
            var state_id=$('#state_id').val();
            var city_id=$('#city_id').val();
            var email_id=$('#email_id').val();
            
        const input = document.getElementById('client_document');

        console.log('Number of files:', input.files.length);

        for (const file of input.files) {
            console.log({
                name: file.name,
                size: file.size,
                type: file.type
            });
        }

             
            if(client_name == ""){
                $('#client_name_err').text('Client Name is required')
                err++
            }
            if(contact_person == ""){
                $('#contact_person_err').text('Contact Person is required')
                err++
            }
            if(contact_no == ""){
                $('#contact_no_err').text('Contact Number is required')
                err++
            }
            if(country_id == ""){
                $('#country_id_err').text('Country is required')
                err++
            }
            if(state_id == ""){
                $('#state_id_err').text('State is required')
                err++
            }
            if(city_id == ""){
                $('#city_id_err').text('City is required')
                err++
            }
            if (email_id != '' && !/^\S+@\S+\.\S+$/.test(email_id)) {
                 $('#email_id_err').text('Enter valid email')
                err++
            }
            if (err>0){
            return false;
            }
            else{ 
                Addclient();
            }
}

    
function Addclient() {
    const form = document.getElementById("addclientForm");
    const submitBtn = document.getElementById("saveclient");
    const fileInput = document.getElementById("client_document");

    if (!form) return;

    // Check selected documents
    console.log("Selected files:", fileInput.files.length);

    for (const file of fileInput.files) {
        console.log(file.name, file.size, file.type);
    }

    const formData = new FormData(form);

    // Remove empty file entries
    formData.delete("client_doc[]");

    // Append only actual selected files
    for (const file of fileInput.files) {
        formData.append("client_doc[]", file);
    }

    submitBtn.disabled = true;

    $.ajax({
        url: form.action,
        method: "POST",
        data: formData,
        processData: false,
        contentType: false,

        success: function(response) {
            console.log("Success:", response);
            toastr.success("Client added successfully!");
            window.location.href = '/site/client';
            submitBtn.disabled = false;
        },

        error: function(xhr) {
            console.error(xhr.responseJSON || xhr.responseText);
            toastr.error("Client failed to add!");
            submitBtn.disabled = false;
        }
    });

    
}


</script>
<script>
     function confirmDelete(id, name) {
            document.querySelector('#deleteClientModal .btn-danger').setAttribute(
                'data-id', id);
            $('#delete_message').html('Are you sure you want to delete client record <br> <b class="text-danger"> ' + name +
                '</b> ? This action cannot be undone.');
        }

        function deletelevel() {
            const reloadPage = tableState.currentPage;
            var id = document.querySelector('#deleteClientModal .btn-danger').getAttribute('data-id');

            fetch('/delete_client/' + id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Client Deleted successfully!');
                        location.reload(reloadPage);

                    } else {
                        toastr.error('Failed to delete Client');
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
</script>

<script>
    function updatelevelStatus(id, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state
           const reloadPage = tableState.currentPage;
            fetch(`/client_status/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('client status Updated successfully!');
                         loadThemes(reloadPage); 
                    } else {
                        console.error('Error updating client status:', data.message);
                        toastr.error('Failed to update client');
                    }
                })
                .catch(error => {
                    console.error('Error updating client status:', error);
                });
        }
</script>
<script>
        function countrychange() { 
            var countryId = $('#country_id').val();
            var stateDropdown = $('#state_id'); 
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('client_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        }   
                    } 
                }); 
            } 
        
        } 
            function statechange() { 
                var stateId = $('#state_id').val(); 
                var countryId = $('#country_id').val(); 
                var cityDropdown = $('#city_id'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('client_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                        } 
                    }); 
                } 
            } 

             
    </script>


  <script>
    function showAddClient() {
        document.getElementById('clientlist').classList.add('d-none');
        document.getElementById('addClient').classList.remove('d-none');
        document.getElementById('updateClient').classList.add('d-none');
    }

    function showUpdateClient(id) {
        global_state_id=null;
        global_city_id=null;
        currentCategoryId = id;
            fetch('/client_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                        console.log(com);
                        
                        $('#update_country_id').val(com.country_id).change();
                        $('#updateClientName').val(com.client_name);
                        $('#updateContactPerson').val(com.contact_person);
                        $('#updateContactNo').val(com.contact_no);
                        $('#updateEmail').val(com.email_id);
                        $('#updateAlternateContactPerson').val(com.alter_contact_person);
                        $('#updateAlternateContactNo').val(com.alter_contact_no);
                        $('#updateAddress').val(com.address);
                        global_state_id=com.state_id;
                        global_city_id=com.city_id;
                        
                        $('#updateGst').val(com.gst_number);
                        $('#updatePan').val(com.pan_number);
                        $('#updateclientDocuments').val(com.upload_doc);
                        // $('#edit_leadtype').val(com.lead_type).change();
                        // $('#edit_leadsource').val(com.lead_source).change();
                        // $('#edit_referperson').val(com.refer_person);
                        // $('#edit_referid').val(com.refer_person_id);
                        // $('#edit_comments').val(com.comments);      
                                                
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });

        document.getElementById('clientlist').classList.add('d-none');
        document.getElementById('addClient').classList.add('d-none');
        document.getElementById('updateClient').classList.remove('d-none');

    }
    function update_country_change() { 
            var countryId = $('#update_country_id').val();
            var stateDropdown = $('#update_state_id'); 
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('client_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        }   
                        if(global_state_id){
                            var changes=global_state_id;
                            stateDropdown.val(changes).change();
                          }
                    } 
                }); 
            } 
        
        } 

            function update_statechange() { 
                var stateId = $('#update_state_id').val(); 
                var countryId = $('#update_country_id').val(); 
                var cityDropdown = $('#update_city_id'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('client_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                            if(global_city_id){
                            var changes=global_city_id;
                            cityDropdown.val(changes).change();
                          }
                        } 
                    }); 
                } 
            }
    function showClientList() {
        document.getElementById('addClient').classList.add('d-none');
        document.getElementById('updateClient').classList.add('d-none');
        document.getElementById('clientlist').classList.remove('d-none');
    }


    function saveClientUpdate() {
    
            
            const input = document.getElementById('updateclientDocuments');
            const formData = new FormData();

         
            formData.append('client_name', document.getElementById('updateClientName').value);
            formData.append('contact_person', document.getElementById('updateContactPerson').value);
            formData.append('contact_no', document.getElementById('updateContactNo').value);
            formData.append('email_id', document.getElementById('updateEmail').value);
            formData.append('alter_contact_person', document.getElementById('updateAlternateContactPerson').value);
            formData.append('alter_contact_no', document.getElementById('updateAlternateContactNo').value);
            formData.append('address', document.getElementById('updateAddress').value);
            formData.append('gst_number', document.getElementById('updateGst').value);
            formData.append('pan_number', document.getElementById('updatePan').value);
            formData.append('country_id', document.getElementById('update_country_id').value);
            formData.append('state_id', document.getElementById('update_state_id').value);
            formData.append('city_id', document.getElementById('update_city_id').value);

            
            for (const file of input.files) {
                    console.log({
                        name: file.name,
                        type: file.type,
                        size: file.size,
                        isFile: file instanceof File
                    });
                formData.append('update_client_doc[]', file);
            }

            console.log('Selected files:', input.files.length);

            for (const [key, value] of formData.entries()) {
                console.log(
                    key,
                    value instanceof File ? value.name : value
                );
            }

            fetch(`/client_updates/${currentCategoryId}`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector(
                        'meta[name="csrf-token"]'
                    ).content,
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(async response => {
                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.message || 'Update failed');
                }
                toastr.success('Client updated successfully!');
                window.location.href = '/site/client';
                console.log(data);
            })
            .catch(error => {
                console.error(error);
                toastr.error(error.message);
            });

        }
        

    // Add Client document upload (client-side demo)
    const selectedClientDocuments = [];

    function handleClientDocuments(input) {
        console.log(input);
        const errorElement = document.getElementById('clientDocumentError');
        errorElement.textContent = '';
        const allowedExtensions = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
        const maxFileSize = 5 * 1024 * 1024; // 5 MB per file

        Array.from(input.files).forEach(function (file) {
            const extension = file.name.split('.').pop().toLowerCase();
            console.log(file.name);
            if (!allowedExtensions.includes(extension)) {
                errorElement.textContent =
                    'Invalid file type: ' + file.name +
                    '. Allowed formats: PDF, DOC, DOCX, JPG, JPEG, PNG.';
                return;
            }
            if (file.size > maxFileSize) {
                errorElement.textContent =
                    file.name + ' exceeds the 5 MB limit.';
                return;
            }

            const alreadyExists = selectedClientDocuments.some(function (item) {
                return item.name === file.name &&
                    item.size === file.size &&
                    item.lastModified === file.lastModified;
            });

            if (!alreadyExists) {
                selectedClientDocuments.push(file);
            }
        });
        // Reset so the same file can be selected again after removal.
       
        renderClientDocuments();
    }
    function renderClientDocuments() {
        const listElement = document.getElementById('clientDocumentList');
        listElement.innerHTML = '';

        selectedClientDocuments.forEach(function (file, index) {
            const row = document.createElement('div');
            row.className =
                'client-document-row d-flex justify-content-between align-items-center ' +
                'border rounded p-3 mb-2 bg-white gap-3';

            const details = document.createElement('div');
            details.className = 'd-flex align-items-center gap-2';

            const icon = document.createElement('i');
            icon.className =
                'mdi mdi-file-document-outline text-primary fs-4';
            const textContainer = document.createElement('div');

            const name = document.createElement('div');
            name.className = 'fw-semibold text-dark text-break';
            name.textContent = file.name;
            const size = document.createElement('small');
            size.className = 'text-muted';
            size.textContent = (file.size / (1024 * 1024)).toFixed(2) + ' MB';
            textContainer.appendChild(name);
            textContainer.appendChild(size);
            details.appendChild(icon);
            details.appendChild(textContainer);
            const removeButton = document.createElement('button');
            removeButton.type = 'button';
            removeButton.className = 'btn btn-sm btn-outline-danger flex-shrink-0';
            removeButton.innerHTML =
                '<i class="mdi mdi-delete-outline"></i> Remove';

            removeButton.addEventListener('click', function () {
                selectedClientDocuments.splice(index, 1);
                document.getElementById('clientDocumentError').textContent = '';
                renderClientDocuments();
            });

            row.appendChild(details);
            row.appendChild(removeButton);
            listElement.appendChild(row);
        });
    }
  </script>

<script>
   const selectedUpdateDocuments = [];

    function handleDocuments(input) {
        console.log(input);
        const errorElement = document.getElementById('updateclientDocumentError');
        errorElement.textContent = '';
        const allowedExtensions = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
        const maxFileSize = 5 * 1024 * 1024; // 5 MB per file

        Array.from(input.files).forEach(function (file) {
            const extension = file.name.split('.').pop().toLowerCase();
            console.log(file.name);
            if (!allowedExtensions.includes(extension)) {
                errorElement.textContent =
                    'Invalid file type: ' + file.name +
                    '. Allowed formats: PDF, DOC, DOCX, JPG, JPEG, PNG.';
                return;
            }
            if (file.size > maxFileSize) {
                errorElement.textContent =
                    file.name + ' exceeds the 5 MB limit.';
                return;
            }

            const alreadyExists = selectedUpdateDocuments.some(function (item) {
                return item.name === file.name &&
                    item.size === file.size &&
                    item.lastModified === file.lastModified;
            });

            if (!alreadyExists) {
                selectedUpdateDocuments.push(file);
            }
        });
        // Reset so the same file can be selected again after removal.
        
        renderClientDocuments();
    }
    function renderClientDocuments() {
        const listElement = document.getElementById('updateclientDocumentList');
        listElement.innerHTML = '';

        selectedUpdateDocuments.forEach(function (file, index) {
            const row = document.createElement('div');
            row.className =
                'client-document-row d-flex justify-content-between align-items-center ' +
                'border rounded p-3 mb-2 bg-white gap-3';

            const details = document.createElement('div');
            details.className = 'd-flex align-items-center gap-2';

            const icon = document.createElement('i');
            icon.className =
                'mdi mdi-file-document-outline text-primary fs-4';
            const textContainer = document.createElement('div');

            const name = document.createElement('div');
            name.className = 'fw-semibold text-dark text-break';
            name.textContent = file.name;

            const size = document.createElement('small');
            size.className = 'text-muted';
            size.textContent = (file.size / (1024 * 1024)).toFixed(2) + ' MB';

            textContainer.appendChild(name);
            textContainer.appendChild(size);
            details.appendChild(icon);
            details.appendChild(textContainer);

            const removeButton = document.createElement('button');
            removeButton.type = 'button';
            removeButton.className = 'btn btn-sm btn-outline-danger flex-shrink-0';
            removeButton.innerHTML =
                '<i class="mdi mdi-delete-outline"></i> Remove';

            removeButton.addEventListener('click', function () {
                selectedUpdateDocuments.splice(index, 1);
                document.getElementById('updateclientDocumentError').textContent = '';
                renderClientDocuments();
            });

            row.appendChild(details);
            row.appendChild(removeButton);
            listElement.appendChild(row);
        });
    }
  </script>
 

<!-- view client -->
  <script>
        




    function showViewModal(id) {
        document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                skeleton.style.display = 'block'; // Show skeleton loaders
            });
        
            // Hide actual data elements
            document.querySelectorAll('.view-data').forEach(element => {
                element.style.display = 'none'; // Hide actual data until it is loaded
            });
            
            fetch('/client_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                        console.log(com);
                        document.querySelectorAll('.view-data').forEach(element => {
                            element.style.display = 'block'; // Show actual data
                        });
                        
                        $('#viewClientName').text(com.client_name);
                        $('#viewContactPerson').text(com.contact_person);
                        $('#viewContactNo').text(com.contact_no); 
                        $('#viewEmail').text(com.email_id);
                        $('#viewAlternateContactPerson').text(com.alter_contact_person);
                        $('#viewAlternateContactNo').text(com.alter_contact_no);
                        $('#viewAddress').html(
                                              (com.address || '') +', '+
                                              (com.city_name || '') +', '+
                                              (com.state_name || '') +', '+
                                              (com.country_name || '')
                                            );
                        $('#viewGst').text(com.gst_number);
                        $('#viewPan').text(com.pan_number||'-');
                        showClientAttachment(com.upload_doc);
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
    }
    function showClientAttachment(fileUrl) {
            const container = document.getElementById("viewClientAttachment");
            container.innerHTML = "";
            if (!fileUrl) {
                container.textContent = "No document or image available.";
                return;
            }
            const extension = fileUrl.split("?")[0].split(".").pop().toLowerCase();
            if (["jpg", "jpeg", "png", "gif", "webp"].includes(extension)) {
                const img = document.createElement("img");
                img.src = fileUrl;
                img.alt = "Client attachment";
                img.className = "img-fluid rounded border";
                img.style.maxHeight = "300px";
                container.appendChild(img);
            } else {
                const link = document.createElement("a");
                link.href = fileUrl;
                link.target = "_blank";
                link.rel = "noopener noreferrer";
                link.textContent = "View / Download Document";
                link.className = "btn btn-outline-primary btn-sm";
                container.appendChild(link);
            }
        }

  </script>



<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let tableState = {
        currentPage: 1
    };

    
    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index) {
        
        return `
            <tr>
                <td><label class="fw-semibold text-dark fs-7">${item.client_name}</label></td>               
                <td><label class="text-black fs-7">${item.contact_person}</label></td>    
                <td>
                    <div class="d-flex flex-column">
                        <div class="d-flex">
                            <i class="mdi mdi-phone-outline"></i>
                            <span class="text-black fs-7">${item.contact_no}</span>
                        </div>
                        <div class="d-flex">
                            <i class="mdi mdi-message-outline"></i>
                            <span class="text-black fs-7">${item.email_id}</span>
                        </div>
                    </div>
                </td>          
                <td>
                    <div class="d-flex flex-column">
                        <span class="fw-semibold fs-7 text-black">${item.alter_contact_person}</span>
                        <small class="text-muted">${item.alter_contact_no}</small>
                    </div>
                </td> 
                <td>
                    <span class="text-muted fs-8">
                            ${item.address},${item.city_name},${item.state_name},${item.country_name}
                    </span>
                </td> 
                <td>
                    <div class="d-flex flex-column">
                        <div class="d-flex">
                            <label class="text-muted text-uppercase fs-8 me-1">pan:</label>
                                <span class="text-black fs-8">${item.pan_number}</span>
                        </div>
                        <div class="d-flex">
                            <label class="text-muted text-uppercase fs-8 me-1">gst:</label>
                            <span class="text-black fs-8">${item.gst_number}</span>
                        </div>
                    </div>
                </td> 
                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" id="RemunerationStatus1" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)">
                    </div>
                </td>
                <td>
                <div class="d-flex dropdown">
                    <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#viewClientModal"
                                onclick="showViewModal('${item.sno}')">
                        <i class="mdi mdi-eye"></i>
                    </button>
                    <button class="btn" type="button" onclick="showUpdateClient('${item.sno}')" >
                        <i class="mdi mdi-pencil"></i>
                    </button>
                    <button class="btn" type="button" data-bs-toggle="modal" data-bs-target="#deleteClientModal" onclick="confirmDelete('${item.sno}','${item.client_name}')">
                        <i class="mdi mdi-trash-can-outline"></i>
                    </button>
                </div>
                </td>
                
            </tr>
        `;
    }
    function loadThemes(page = 1) {
         tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        
        const search = document.getElementById('search_filter').value;
        
        const url = `/site/client?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();
         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
               if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }
    

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="8" class="text-center">No Data Found</td></tr>
            `;
    }

  

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

</script>

@endsection


