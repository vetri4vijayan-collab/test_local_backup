<?php

namespace App\Jobs\hr_management\hr_recruiter;

use App\Services\CandidateServices\RecruitmentAtsRoleMatchingService;
use App\Services\CandidateServices\RecruitmentAtsRunService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Throwable;

class ProcessRecruitmentAtsRoleMatchingRunJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 1;
    public $timeout;
    public $failOnTimeout = true;

    public array $claimedApplicantIds = [];

    public function __construct(public int $runSno)
    {
        $this->timeout = (int) config('recruitment_ats.job_timeout', 600);
    }

    public function handle(
        RecruitmentAtsRunService $runService,
        RecruitmentAtsRoleMatchingService $matchingService
    ): void {
        $run = $runService->getById($this->runSno);

        if (!$run || $run->status !== 'running') {
            return;
        }

        $claim = null;

        try {
            $claim = $runService->claimNextChunk($this->runSno);

            if (!$claim) {
                $runService->workerFinished($this->runSno);
                return;
            }

            $this->claimedApplicantIds = $claim['applicant_ids'];

            $results = $matchingService->analyzeApplicantsByIds(
                $claim['applicant_ids'],
                $this->runSno,
                (bool) $claim['force_reprocess'],
                (int) $claim['actor_id']
            );

            $runService->recordBatch(
                $this->runSno,
                $claim['applicant_ids'],
                $results
            );
        } catch (Throwable $e) {
            Log::error('ATS bulk worker chunk failed.', [
                'run_sno' => $this->runSno,
                'applicant_ids' => $claim['applicant_ids'] ?? [],
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            if (!empty($claim['applicant_ids'])) {
                $runService->recordBatchFailure(
                    $this->runSno,
                    $claim['applicant_ids'],
                    $e->getMessage()
                );
            }
        }

        $currentRun = $runService->getById($this->runSno);

        if (!$currentRun) {
            return;
        }

        if (
            $currentRun->status === 'running'
            && (int) $currentRun->claimed_count < (int) $currentRun->target_count
        ) {
            self::dispatch($this->runSno)
                ->onQueue(config('recruitment_ats.queue', 'ats-role-matching'));
            return;
        }

        $runService->workerFinished($this->runSno);
    }

    public function failed(Throwable $exception): void
    {
        try {
            $runService = app(RecruitmentAtsRunService::class);

            $runService->recordBatchFailure(
                $this->runSno,
                $this->claimedApplicantIds,
                $exception->getMessage()
            );

            $runService->workerFinished($this->runSno);
        } catch (Throwable $e) {
            Log::error('ATS bulk worker failure handler failed.', [
                'run_sno' => $this->runSno,
                'message' => $e->getMessage(),
            ]);
        }
    }
}
