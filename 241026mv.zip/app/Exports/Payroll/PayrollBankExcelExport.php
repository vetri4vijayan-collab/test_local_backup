<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class PayrollBankExcelExport implements
    FromArray,
    WithEvents,
    WithStyles,
    ShouldAutoSize
{
    protected $payroll;

    public function __construct($payroll)
    {
        $this->payroll = $payroll;
    }

    public function array(): array
    {
        $rows = [];

        /*
        |--------------------------------------------------------------------------
        | Empty rows (Header written using Events)
        |--------------------------------------------------------------------------
        */

        for($i=0;$i<12;$i++)
        {
            $rows[]=[''];
        }

        $sl=1;

        foreach($this->payroll['rows'] as $row)
        {
            $rows[]=[

                $sl++,

                $row['staff_name'],

                $row['account_no'],

                $row['amount']

            ];
        }

        $rows[]=[
            '',
            'TOTAL',
            '',
            $this->payroll['grand_total']
        ];

        return $rows;
    }

    public function styles(Worksheet $sheet)
    {
        return [];
    }

    public function registerEvents(): array
    {
        return [

            AfterSheet::class=>function(AfterSheet $event){

                $sheet=$event->sheet;

                /*
                |--------------------------------------------------------------------------
                | Title
                |--------------------------------------------------------------------------
                */

                $sheet->mergeCells('A1:D1');

                $sheet->setCellValue(
                    'A1',
                    $this->payroll['company_name']
                );

                $sheet->getStyle('A1')->applyFromArray([

                    'font'=>[
                        'bold'=>true,
                        'size'=>18
                    ],

                    'alignment'=>[
                        'horizontal'=>'center'
                    ]

                ]);

                /*
                |--------------------------------------------------------------------------
                | Date
                |--------------------------------------------------------------------------
                */

                $sheet->setCellValue(
                    'D2',
                    'Date : '.$this->payroll['date']
                );

                /*
                |--------------------------------------------------------------------------
                | Address
                |--------------------------------------------------------------------------
                */

                $sheet->setCellValue('A4','To');
                $sheet->setCellValue('A5','The Manager');
                $sheet->setCellValue('A6',$this->payroll['bank_name']);
                $sheet->setCellValue('A7',$this->payroll['bank_branch']);

                /*
                |--------------------------------------------------------------------------
                | Subject
                |--------------------------------------------------------------------------
                */

                $sheet->mergeCells('A9:D9');

                $sheet->setCellValue(

                    'A9',

                    'Sub : Salary Transfer for '.$this->payroll['month']

                );

                $sheet->getStyle('A9')->getFont()->setBold(true);

                /*
                |--------------------------------------------------------------------------
                | Letter
                |--------------------------------------------------------------------------
                */

                $sheet->mergeCells('A10:D10');

                $sheet->setCellValue(

                    'A10',

                    'Please debit our Current Account '.$this->payroll['current_account'].' and credit the salary amount to the following employee bank accounts.'

                );

                /*
                |--------------------------------------------------------------------------
                | Amount
                |--------------------------------------------------------------------------
                */

                $sheet->mergeCells('A11:D11');

                $sheet->setCellValue(

                    'A11',

                    'Total Amount : Rs. '.number_format($this->payroll['grand_total'],2)

                );

                /*
                |--------------------------------------------------------------------------
                | Header
                |--------------------------------------------------------------------------
                */

                $sheet->fromArray(

                    [

                        [

                            'Sl.No',

                            'Employee Name',

                            'Account Number',

                            'Amount'

                        ]

                    ],

                    NULL,

                    'A13'

                );

                $sheet->getStyle('A13:D13')->applyFromArray([

                    'font'=>[
                        'bold'=>true,
                        'color'=>[
                            'rgb'=>'FFFFFF'
                        ]
                    ],

                    'fill'=>[
                        'fillType'=>'solid',
                        'startColor'=>[
                            'rgb'=>'1F4E78'
                        ]
                    ]

                ]);

                $highest=$sheet->getHighestRow();

                /*
                |--------------------------------------------------------------------------
                | Borders
                |--------------------------------------------------------------------------
                */

                $sheet->getStyle(

                    'A13:D'.$highest

                )->applyFromArray([

                    'borders'=>[

                        'allBorders'=>[

                            'borderStyle'=>'thin'

                        ]

                    ]

                ]);

                /*
                |--------------------------------------------------------------------------
                | Total Row
                |--------------------------------------------------------------------------
                */

                $sheet->getStyle(

                    'A'.$highest.':D'.$highest

                )->applyFromArray([

                    'font'=>[
                        'bold'=>true
                    ],

                    'fill'=>[
                        'fillType'=>'solid',
                        'startColor'=>[
                            'rgb'=>'FFF2CC'
                        ]
                    ]

                ]);

                /*
                |--------------------------------------------------------------------------
                | Signature
                |--------------------------------------------------------------------------
                */

                $row=$highest+4;

                $sheet->mergeCells(

                    'A'.$row.':D'.$row

                );

                $sheet->setCellValue(

                    'A'.$row,

                    'Managing Director'

                );

                $sheet->getStyle(

                    'A'.$row

                )->applyFromArray([

                    'font'=>[
                        'bold'=>true
                    ],

                    'alignment'=>[
                        'horizontal'=>'right'
                    ]

                ]);

            }

        ];
    }
}