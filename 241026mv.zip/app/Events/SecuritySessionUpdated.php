<?php
namespace App\Events;

use App\Models\WebhookDispatchModel;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class SecuritySessionUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public string $sessionUuid,
        public string $status,
        public array $data = []
    ) {}

    public function broadcastOn()
    {
        return new PrivateChannel(
            'security.session.'.$this->sessionUuid
        );
    }

    public function broadcastAs()
    {
        return 'security.updated';
    }
}
