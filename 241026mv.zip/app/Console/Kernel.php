<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    // protected function schedule(Schedule $schedule): void
    // {
    //     // $schedule->command('inspire')->hourly();
    //     // $schedule->command('clean:temp-uploads')->daily();
    //     $schedule->command('clean:temp-uploads')->everyMinute();
    //      $schedule->command('ai:check-usage')->hourly();
    // }

    protected function schedule(Schedule $schedule)
    {
        $schedule->command('achievement:sync')
            ->dailyAt('23:00');
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}
