<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\ManageEntityModel;
use App\Models\BranchModel;
use App\Models\TargetAchievementModel;
use Illuminate\Support\Facades\Http;

class SyncAchievementCron extends Command
{
    protected $signature = 'achievement:sync';

    protected $description = 'Daily Achievement Sync';

    public function handle()
    {
        try {

            $today = Carbon::today()->format('Y-m-d');

            $entities = ManageEntityModel::where('status', 1)->get();

            foreach ($entities as $entity) {

                $baseurl = rtrim($entity->entity_base_url, '/') . '/';

                $branches = BranchModel::where('entity_id', $entity->sno)
                    ->where('status', 1)
                    ->get();

                foreach ($branches as $branch) {

                    try {

                        $response = Http::timeout(60)->post(
                            $baseurl . 'api/get_achieve_values',
                            [
                                'verify_key' => 'egcsecret2030datagetapierp',
                                'branch_id'  => $branch->sno,
                                'from_date'  => $today,
                                'to_date'    => $today,
                            ]
                        );

                        if (!$response->successful()) {

                            \Log::error(
                                "Achievement API Failed : Entity {$entity->sno} Branch {$branch->sno}"
                            );

                            continue;
                        }

                        $result = $response->json();

                        if (!isset($result['data'])) {
                            continue;
                        }

                        foreach ($result['data'] as $row) {

                            $date = Carbon::parse($row['date']);

                            $month = $date->month;

                            // FINANCIAL QUARTER
                            $quarter = match (true) {
                                $month >= 4 && $month <= 6   => 1,
                                $month >= 7 && $month <= 9   => 2,
                                $month >= 10 && $month <= 12 => 3,
                                default => 4,
                            };

                            $week = match (true) {
                                $date->day <= 7  => 1,
                                $date->day <= 14 => 2,
                                $date->day <= 21 => 3,
                                default          => 4,
                            };

                            TargetAchievementModel::updateOrCreate(

                                [
                                    'entity_id'     => $entity->sno,
                                    'branch_id'     => $branch->sno,
                                    'achieved_date' => $date->format('Y-m-d'),
                                ],

                                [
                                    'year'             => $date->year,
                                    'month'            => $month,
                                    'quarter'          => $quarter,
                                    'week'             => $week,

                                    'achieved_amount'  => $row['amount'],
                                    'pre_sale'         => $row['pre_sale'],
                                    'post_sale'        => $row['post_sale'],
                                ]
                            );
                        }

                        $this->info(
                            "Synced Entity {$entity->sno} Branch {$branch->sno}"
                        );
                    } catch (\Exception $e) {

                        \Log::error(
                            "Branch Sync Error : " . $e->getMessage()
                        );
                    }
                }
            }

            $this->info('Achievement Sync Completed');
        } catch (\Exception $e) {

            \Log::error(
                'Achievement Cron Error : ' . $e->getMessage()
            );
        }
    }
}
