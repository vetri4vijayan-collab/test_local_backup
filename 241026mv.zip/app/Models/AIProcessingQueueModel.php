<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AIProcessingQueue extends Model
{
    protected $table='egc_ai_processing_queue';

    protected $fillable=[

        'applicant_id',

        'process_type',

        'status',

        'attempts',

        'priority',

        'error_message',

        'started_at',

        'completed_at'

    ];
}
