<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ElectricityMeterModel extends Model
{
    use HasFactory;

    protected $table = 'egc_electricity_meters';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'account_id',

        'meter_no',
        'meter_name',
        'meter_type_id',

        'meter_make',
        'meter_model',
        'serial_no',

        'phase_type_id',

        'multiplier_factor',

        'initial_reading',
        'current_reading',

        'reading_unit',

        'installation_date',
        'warranty_expiry',

        'meter_location',

        'max_load',
        'load_unit',

        'remarks',

        'created_by',
        'created_at',

        'updated_by',
        'updated_at',

        'status'

    ];

    /*
    |--------------------------------------------------------------------------
    | Electricity Account
    |--------------------------------------------------------------------------
    */

    public function account()
    {
        return $this->belongsTo(
            ElectricityAccountModel::class,
            'account_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Meter Readings
    |--------------------------------------------------------------------------
    */

    public function readings()
    {
        return $this->hasMany(
            ElectricityReadingModel::class,
            'meter_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Bills
    |--------------------------------------------------------------------------
    */

    public function bills()
    {
        return $this->hasMany(
            ElectricityBillModel::class,
            'meter_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Complaints
    |--------------------------------------------------------------------------
    */

    public function complaints()
    {
        return $this->hasMany(
            ElectricityComplaintModel::class,
            'meter_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Scope : Active
    |--------------------------------------------------------------------------
    */

    public function scopeActive($query)
    {
        return $query->where('status',0);
    }

    /*
    |--------------------------------------------------------------------------
    | Scope : Main Meter
    |--------------------------------------------------------------------------
    */

    public function scopeMainMeter($query)
    {
        return $query->where('meter_type','Main');
    }

    /*
    |--------------------------------------------------------------------------
    | Scope : Solar Meter
    |--------------------------------------------------------------------------
    */

    public function scopeSolarMeter($query)
    {
        return $query->where('meter_type','Solar');
    }

    /*
    |--------------------------------------------------------------------------
    | Scope : DG Meter
    |--------------------------------------------------------------------------
    */

    public function scopeDgMeter($query)
    {
        return $query->where('meter_type','DG');
    }

}