<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IndustrialVisitAttendeeModel extends Model
{
    use HasFactory;

    protected $table = 'egc_industrial_visit_attendees';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'iv_sno',
        'college_id',
        'college_name',
        'iv_date',
        'student_name',
        'gender',
        'qualification_id',
        'qualification_name',
        'major_id',
        'major_name',
        'year_of_passing',
        'address',
        'mobile',
        'email',
        'state_id',
        'state_name',
        'city_id',
        'city_name',
        'field_of_interest',
        'ip_address',
        'user_agent',
        'status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'iv_sno' => 'integer',
        'college_id' => 'integer',
        'qualification_id' => 'integer',
        'major_id' => 'integer',
        'gender' => 'integer',
        'year_of_passing' => 'integer',
        'state_id' => 'integer',
        'city_id' => 'integer',
        'field_of_interest' => 'array',
        'status' => 'integer',
    ];
}
