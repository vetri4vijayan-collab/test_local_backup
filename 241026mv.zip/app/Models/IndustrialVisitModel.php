<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IndustrialVisitModel extends Model
{
    use HasFactory;

    protected $table = 'egc_industrial_visits';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'iv_code',
        'iv_date',
        'college_id',
        'college_name',
        'company_id',
        'company_name',
        'company_logo',
        'company_base_color',
        'entity_id',
        'entity_name',
        'entity_logo',
        'entity_company_id',
        'entity_base_color',
        'google_review_link',
        'qr_token',
        'status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'iv_date' => 'date:Y-m-d',
        'entity_id' => 'integer',
        'company_id' => 'integer',
        'college_id' => 'integer',
        'status' => 'integer',
    ];
}
