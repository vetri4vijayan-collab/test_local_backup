<?php

namespace App\Helpers;

class PayrollFormulaHelper
{
    public static function evaluate($formula, $variables = [])
    {
        try {

            // Convert IF(condition,a,b) → PHP ternary
            $formula = preg_replace(
                '/IF\s*\((.*?),(.*?),(.*?)\)/i',
                '(($1) ? ($2) : ($3))',
                $formula
            );

            // Replace variable names with PHP variables
            foreach ($variables as $key => $value) {

                $formula = preg_replace(
                    '/\b' . preg_quote($key, '/') . '\b/',
                    '$' . $key,
                    $formula
                );

                ${$key} = $value;
            }

            // Debug
            // dd($formula);

            $result = eval("return $formula;");

            return round((float)$result, 2);
        } catch (\Throwable $e) {

            \Log::error('Payroll Formula Error', [
                'formula' => $formula,
                'variables' => $variables,
                'error' => $e->getMessage()
            ]);

            return 0;
        }
    }
}
