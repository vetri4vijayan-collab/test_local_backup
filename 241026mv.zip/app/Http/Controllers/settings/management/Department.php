<?php

namespace App\Http\Controllers\settings\management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DepartmentModel;
use Carbon\Carbon;

class Department extends Controller
{

  // management Department
  public function index(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = DepartmentModel::where('egc_department.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_department.*')
      ->where('egc_department.company_type',1);
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Department=$Department->orderBy('egc_department.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'department_name' => $item->department_name,
                    'department_desc' => $item->department_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
 
    return view('content.settings.management.department.department_list', [
      'ListTable' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
    ]);
  }

  public function BusinessDepartmentIndex(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = DepartmentModel::where('egc_department.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_department.*', 'egc_entity.entity_name as entityname', 'egc_branch.branch_name', 'egc_branch.franchise_name', 'egc_branch.branch_type')
      ->leftJoin('egc_entity', 'egc_department.entity_id', 'egc_entity.sno')
      ->leftJoin('egc_branch', 'egc_department.branch_id', 'egc_branch.sno')
      ->orderBy('egc_department.sno', 'desc')->get();
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_department.name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.sortname', 'LIKE', "%{$search_filter}%");
                    
            });
        }
    // return $Department;
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.management.department.department_list', [
      'ListTable' => $Department,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function List(Request $request)
  {
    
    $entity_id=$request->entity_id;
    $Department = DepartmentModel::where('status', 0)->where('entity_id',$entity_id)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

  public function BranchDepartList(Request $request)
  {

    $branch_id = $request->branch_id;
    // ->where('branch_id', $branch_id)
    $Department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $staff =  DepartmentModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Department Status Updated Successfully!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = DepartmentModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {


      $department_name = $request->edit_department_name;
      $department_desc = $request->edit_department_desc;

    
        $add_department = new DepartmentModel();
        $add_department->department_id = "fdghh";
        $add_department->department_name = $department_name;
        $add_department->department_desc = $department_desc;
        $add_department->created_by = 1;
        $add_department->updated_by = 1;

        $add_department->save();

 
      
      return redirect()->back();
    
  }

  public function Edit($id)
  {
    $editdepartment = DepartmentModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Department not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Department fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

   public function Update(Request $request)
  {
    return $request;

    $validator = Validator::make($request->all(), [
      'department_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $department_name = $request->department_name;
      $department_desc = $request->department_desc;
      $user_id = $request->user()->user_id;
      $chk = DepartmentModel::where('department_name', $department_name)->where('company_type', 1)->where('sno', '!=', $sno)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Department Name Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = DepartmentModel::where('sno', $sno)->first();
        $up_department->department_name = $department_name;
        $up_department->department_desc = $department_desc;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Department updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
}