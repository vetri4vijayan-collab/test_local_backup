<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\AI;

use App\Http\Controllers\Controller;
use App\Services\RecruitmentRoleProfileService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Throwable;

class RecruitmentRoleAIProfileController
    extends Controller
{
    protected RecruitmentRoleProfileService $profiles;

    public function __construct(
        RecruitmentRoleProfileService $profiles
    ) {
        $this->profiles = $profiles;
    }

    /**
     * Show AI role profile.
     */
    public function show(
        int $sno
    ): JsonResponse {

        $role = $this->profiles
            ->getProfile($sno);

        if (!$role) {

            return response()->json([
                'status' => false,
                'message' => 'Recruitment role not found.'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $role
        ]);
    }

    /**
     * Update AI role profile.
     */
    public function update(
        Request $request,
        int $sno
    ): JsonResponse {

        $validator = Validator::make(
            $request->all(),
            [
                'role_description' =>
                    'nullable|string|max:10000',

                'mandatory_skills' =>
                    'nullable|array|max:100',

                'mandatory_skills.*' =>
                    'string|max:200',

                'preferred_skills' =>
                    'nullable|array|max:100',

                'preferred_skills.*' =>
                    'string|max:200',

                'responsibilities' =>
                    'nullable|array|max:100',

                'responsibilities.*' =>
                    'string|max:1000',

                'minimum_experience' =>
                    'nullable|string|max:200',

                'education_requirements' =>
                    'nullable|string|max:1000',

                'seniority' =>
                    'nullable|string|max:100',

                'ai_matching_enabled' =>
                    'nullable|boolean',
            ]
        );

        if ($validator->fails()) {

            return response()->json([
                'status' => false,
                'message' => 'Validation failed.',
                'errors' => $validator->errors()
            ], 422);
        }

        $role = DB::table(
            'egc_recruitment_roles'
        )
            ->where('sno', $sno)
            ->first();

        if (!$role) {

            return response()->json([
                'status' => false,
                'message' => 'Recruitment role not found.'
            ], 404);
        }

        try {
            DB::transaction(function () use ($request, $role, $sno) {
                $clean = function (mixed $value): string {
                    return trim(preg_replace('/\s+/u', ' ', strip_tags((string) ($value ?? ''))) ?? '');
                };
                $mandatory = $this->cleanArray($request->input('mandatory_skills', json_decode((string) ($role->mandatory_skills ?? '[]'), true) ?: []));
                $preferred = $this->cleanArray($request->input('preferred_skills', json_decode((string) ($role->preferred_skills ?? '[]'), true) ?: []));
                $responsibilities = $this->cleanArray($request->input('responsibilities', json_decode((string) ($role->responsibilities ?? '[]'), true) ?: []));
                $roleDescription = array_key_exists('role_description', $request->all())
                    ? $clean($request->input('role_description'))
                    : $clean($role->role_description ?? $role->description ?? $role->role_name);
                $minimumExperience = array_key_exists('minimum_experience', $request->all()) ? $clean($request->input('minimum_experience')) : $clean($role->minimum_experience ?? '');
                $educationRequirements = array_key_exists('education_requirements', $request->all()) ? $clean($request->input('education_requirements')) : $clean($role->education_requirements ?? '');
                $seniority = array_key_exists('seniority', $request->all()) ? $clean($request->input('seniority')) : $clean($role->seniority ?? '');
                $aiEnabled = array_key_exists('ai_matching_enabled', $request->all()) ? (bool) $request->boolean('ai_matching_enabled') : (bool) ($role->ai_matching_enabled ?? true);
                $version = max(1, (int) ($role->ai_profile_version ?? 1)) + 1;
                $hashPayload = [
                    'role_name' => (string) $role->role_name, 'role_family' => (string) $role->role_family,
                    'seniority_level' => (int) $role->seniority_level, 'description' => (string) $role->description,
                    'role_description' => $roleDescription, 'mandatory_skills' => $mandatory,
                    'preferred_skills' => $preferred, 'responsibilities' => $responsibilities,
                    'minimum_experience' => $minimumExperience, 'education_requirements' => $educationRequirements,
                    'seniority' => $seniority, 'ai_matching_enabled' => $aiEnabled,
                ];

                DB::table('egc_recruitment_roles')->where('sno', $sno)->update([
                    'role_description' => $roleDescription,
                    'mandatory_skills' => json_encode($mandatory, JSON_UNESCAPED_UNICODE),
                    'preferred_skills' => json_encode($preferred, JSON_UNESCAPED_UNICODE),
                    'responsibilities' => json_encode($responsibilities, JSON_UNESCAPED_UNICODE),
                    'minimum_experience' => $minimumExperience,
                    'education_requirements' => $educationRequirements,
                    'seniority' => $seniority,
                    'ai_matching_enabled' => $aiEnabled,
                    'ai_profile_version' => $version,
                    'ai_profile_hash' => hash('sha256', json_encode($hashPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: ''),
                    'ai_profile_updated_at' => now(),
                    'ai_profile_updated_by' => (int) ($request->user()?->getAuthIdentifier() ?? 0),
                    'updated_at' => now(),
                ]);
            });

            /*
             * IMPORTANT:
             *
             * Role definition changed.
             * Existing role-profile cache must be cleared.
             */
            $this->profiles->clearCache();

            return response()->json([
                'status' => true,
                'message' =>
                    'AI role profile updated successfully.'
            ]);

        } catch (Throwable $e) {

            report($e);

            return response()->json([
                'status' => false,
                'message' =>
                    'Unable to update AI role profile.'
            ], 500);
        }
    }

    /**
     * Clean array values.
     */
    protected function cleanArray(
        mixed $values
    ): array {

        if (!is_array($values)) {
            return [];
        }

        $values = array_map(
            function ($value) {

                return trim(
                    strip_tags(
                        (string) $value
                    )
                );

            },
            $values
        );

        $values = array_filter(
            $values,
            fn ($value) =>
                $value !== ''
        );

        return array_values(
            array_unique(
                $values
            )
        );
    }
}