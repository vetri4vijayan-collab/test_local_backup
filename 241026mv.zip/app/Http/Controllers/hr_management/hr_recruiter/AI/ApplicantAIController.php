<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\AI;

use App\Http\Controllers\Controller;
use App\Services\CandidateServices\ApplicantRoleMatchingService;
use App\Services\CandidateServices\RecruitmentAtsRoleMatchingService;
use App\Services\CandidateServices\RecruitmentAtsRunService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\ApplicantModel;
use App\Services\CandidateServices\HuggingFaceRoleMatcherService;
use App\Services\CandidateServices\ApplicantAIService;
use Throwable;

class ApplicantAIController extends Controller
{
    protected ApplicantRoleMatchingService $matchingService;
    protected HuggingFaceRoleMatcherService $matcher;
    protected ApplicantAIService $service;
    protected RecruitmentAtsRoleMatchingService $atsMatching;
    protected RecruitmentAtsRunService $atsRuns;

    public function __construct(
        ApplicantRoleMatchingService $matchingService,
        HuggingFaceRoleMatcherService $matcher,
        ApplicantAIService $service,
        RecruitmentAtsRoleMatchingService $atsMatching,
        RecruitmentAtsRunService $atsRuns
    ) {
        $this->matchingService = $matchingService;
        $this->matcher = $matcher;
        $this->service = $service;
        $this->atsMatching = $atsMatching;
        $this->atsRuns = $atsRuns;
    }

    /**
     * AI match one applicant by egc_applicant.sno
     */
    public function matchBySno(Request $request, int $sno): JsonResponse
    {
        $applicant = ApplicantModel::query()->whereKey($sno)->first();
        if (!$applicant) {
            return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);
        }

        try {
            $result = $this->atsMatching->analyzeApplicant(
                $applicant,
                [],
                null,
                (int) ($request->user()?->getAuthIdentifier() ?? 0),
                false
            );
            return response()->json($result, $result['status'] ? 200 : 422);
        } catch (Throwable $e) {
            Log::error('Canonical ATS compatibility match failed.', ['applicant_sno' => $sno, 'message' => $e->getMessage()]);
            return response()->json(['status' => false, 'message' => 'Unable to analyse applicant.'], 500);
        }
    }

    /**
     * Get stored AI analysis.
     */
    public function analysis(int $sno): JsonResponse
    {
        $applicant = ApplicantModel::query()->whereKey($sno)->first();
        if (!$applicant) return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);
        try {
            $analysis = $this->atsMatching->getStoredAnalysis($applicant);
            return response()->json([
                'status' => true,
                'data' => $analysis ? $this->atsMatching->formatStoredAnalysis($applicant, $analysis) : null,
                'has_analysis' => $analysis !== null,
                'is_current' => $analysis ? $this->atsMatching->isAnalysisCurrent($applicant, $analysis) : false,
            ]);
        } catch (Throwable $e) {
            Log::error('Canonical ATS compatibility analysis failed.', ['applicant_sno' => $sno, 'message' => $e->getMessage()]);
            return response()->json(['status' => false, 'message' => 'Unable to load AI analysis.'], 500);
        }
    }

    /**
     * Bulk AI role matching.
     *
     * This is a normal authenticated web/AJAX endpoint,
     * not the old public API endpoint.
     */
    public function bulkMatch(Request $request): JsonResponse
    {
        $data = $request->validate([
            'limit' => ['nullable','integer','min:1','max:' . (int) config('recruitment_ats.max_bulk_limit',50000)],
            'batch_size' => ['nullable','integer','min:1','max:' . (int) config('recruitment_ats.max_batch_size',3)],
            'workers' => ['nullable','integer','min:1','max:' . (int) config('recruitment_ats.max_workers',8)],
            'force' => ['nullable','boolean'],
            'force_reprocess' => ['nullable','boolean'],
        ]);

        if ((string) config('queue.default') === 'sync') {
            return response()->json(['status' => false, 'message' => 'Bulk ATS matching requires an asynchronous queue connection.'], 503);
        }

        try {
            $run = $this->atsRuns->start(
                (int) ($request->user()?->getAuthIdentifier() ?? 0),
                (int) ($data['limit'] ?? 100),
                (int) ($data['batch_size'] ?? config('recruitment_ats.default_batch_size',2)),
                (int) ($data['workers'] ?? config('recruitment_ats.default_workers',3)),
                (bool) ($data['force_reprocess'] ?? $data['force'] ?? false)
            );
            $job = \App\Jobs\hr_management\hr_recruiter\ProcessRecruitmentAtsRoleMatchingRunJob::class;
            for ($i=0; $i<(int)$run->worker_count; $i++) { $job::dispatch((int)$run->sno)->onQueue(config('recruitment_ats.queue','ats-role-matching')); }
            return response()->json(['status'=>true,'message'=>'Bulk ATS role matching queued.','data'=>['run_uuid'=>$run->run_uuid,'target_count'=>(int)$run->target_count]],202);
        } catch (Throwable $e) {
            Log::error('Canonical ATS compatibility bulk failed.', ['message'=>$e->getMessage()]);
            return response()->json(['status'=>false,'message'=>'Unable to queue bulk ATS matching.'],500);
        }
    }

        /**
     * Match Single Applicant
     */
    public function match(Request $request): JsonResponse
    {
        $data = $request->validate(['applicant_id' => ['required']]);
        $applicant = ApplicantModel::query()->where('applicant_id', $data['applicant_id'])->first();
        if (!$applicant) return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);

        try {
            $result = $this->atsMatching->analyzeApplicant(
                $applicant,
                [],
                null,
                (int) ($request->user()?->getAuthIdentifier() ?? 0),
                false
            );
            return response()->json($result, $result['status'] ? 200 : 422);
        } catch (Throwable $e) {
            Log::error('Canonical ATS API match failed.', ['applicant_id' => $data['applicant_id'], 'message' => $e->getMessage()]);
            return response()->json(['status' => false, 'message' => 'Unable to analyse applicant.'], 500);
        }
    }

    /**
     * Resume Extraction
     */
    private function extractResume(
        ApplicantModel $applicant
    )
    {
        $drive_old = $applicant->drive_data;

        $drive_data = $drive_old
            ? json_decode($drive_old)
            : null;

        if (
            $drive_data &&
            isset($drive_data->file_id)
        ) {

            return app()
                ->make(\App\Http\Controllers\YourController::class)
                ->extractResumeTextFromDrive(
                    $drive_data->file_id
                );

        }

        if ($applicant->attachment) {

            return app()
                ->make(\App\Http\Controllers\YourController::class)
                ->extractResumeText(

                    public_path(
                        'job_applications/resume_files/' .
                        $applicant->attachment
                    )

                );

        }

        return null;
    }

     public function show(int $id)
    {
        try {
            $result = $this->service->getApplicant($id);

            if (!$result['status']) {
                return response()->json($result,404);
            }

             $applicant = ApplicantModel::query()
                ->select([
                    'sno',
                    'applicant_id',
                    'applicant_name',
                    'question_answers',
                ])
                ->where('sno', $id)
                ->first();

            $answers = [];

            if ($applicant && !empty($applicant->question_answers)) {

                $decoded = json_decode(
                    $applicant->question_answers,
                    true
                );

                if (
                    json_last_error() === JSON_ERROR_NONE &&
                    is_array($decoded)
                ) {
                    $answers = $decoded;
                }
            }

            /* Normalize Answers*/

            $answers = collect($answers)
                ->map(function ($item) {

                    $answer = $item['answer'] ?? null;

                    if (is_array($answer)) {
                        $answer = array_values(
                            array_filter(
                                $answer,
                                fn ($value) =>
                                    $value !== null &&
                                    $value !== ''
                            )
                        );
                    }

                    return [
                        'question_id' => $item['question_id'] ?? null,
                        'question'    => $item['question'] ?? '',
                        'type'        => $item['type'] ?? '',
                        'answer'      => $answer,
                    ];
                })
                ->values()
                ->toArray();

            /*
            |--------------------------------------------------------------------------
            | Single Production Response
            |--------------------------------------------------------------------------
            */

            return response()->json([
                'status' => true,

                'data' => array_merge(
                    $result['data'],
                    [
                        'application_answers' => [
                            'has_answers' => count($answers) > 0,
                            'answer_count' => count($answers),
                            'answers' => $answers,
                        ],
                    ]
                ),
            ]);

        }

        catch(Throwable $e){

            \Log::error('Applicant AI View',[
                'applicant'=>$id,
                'message'=>$e->getMessage()
            ]);
            return response()->json([
                'status'=>false,
                'message'=>'Unable to load applicant.'
            ],500);
        }
    }

    
 /**
 * Applicant Application Questions & Answers
 */
public function applicationAnswers(int $id)
{
    try {

        $applicant = ApplicantModel::query()
            ->select([
                'sno',
                'applicant_id',
                'applicant_name',
                'question_answers',
            ])
            ->where('sno', $id)
            ->first();

        if (!$applicant) {
            return response()->json([
                'status'  => false,
                'message' => 'Applicant not found.',
            ], 404);
        }

        $answers = [];

        if (!empty($applicant->question_answers)) {

            $decoded = json_decode(
                $applicant->question_answers,
                true
            );

            if (
                json_last_error() === JSON_ERROR_NONE &&
                is_array($decoded)
            ) {
                $answers = $decoded;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Normalize answers for HR UI
        |--------------------------------------------------------------------------
        */

        $answers = collect($answers)
            ->map(function ($item) {

                $answer = $item['answer'] ?? null;

                if (is_array($answer)) {
                    $answer = array_values(
                        array_filter(
                            $answer,
                            fn ($value) =>
                                $value !== null &&
                                $value !== ''
                        )
                    );
                }

                return [
                    'question_id' => $item['question_id'] ?? null,
                    'question'    => $item['question'] ?? '',
                    'type'        => $item['type'] ?? '',
                    'answer'      => $answer,
                ];
            })
            ->values()
            ->toArray();

        return response()->json([
            'status' => true,

            'data' => [
                'applicant' => [
                    'id'   => $applicant->sno,
                    'code' => $applicant->applicant_id,
                    'name' => $applicant->applicant_name,
                ],

                'has_answers' => count($answers) > 0,

                'answer_count' => count($answers),

                'answers' => $answers,
            ],
        ]);

    } catch (\Throwable $e) {

        Log::error(
            'Applicant Application Answers',
            [
                'applicant' => $id,
                'message'   => $e->getMessage(),
                'line'      => $e->getLine(),
                'file'      => $e->getFile(),
            ]
        );

        return response()->json([
            'status'  => false,
            'message' => 'Unable to load application answers.',
        ], 500);
    }
}
}