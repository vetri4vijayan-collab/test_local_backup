<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use App\Models\ApplicantModel;
use App\Services\ApplicantResumeStorage\WasabiResumeStorageService;
use App\Services\GoogleDriveService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

class ApplicantResumeStorageController extends Controller
{
    private WasabiResumeStorageService $storage;

    public function __construct(WasabiResumeStorageService $storage)
    {
        $this->storage = $storage;
    }

    /** Return stable ERP resolver URLs; each access rechecks Wasabi then falls back to Drive and local storage. */
    public function urls(Request $request, int $sno)
    {
        $applicant = $this->findApplicant($sno);
        if (!$applicant) {
            return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);
        }

        $inlineUrl = url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=inline');
        $downloadUrl = url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=attachment');
        $provider = $this->legacyProvider($applicant);
        $originalName = $this->legacyOriginalName($applicant, $sno);
        $mimeType = null;
        $fileSize = null;
        $expiry = null;

        try {
            if ($this->storageReady()) {
                $row = $this->storage->anyRow($sno);
                if ($row && ($row->storage_status ?? '') === 'deleted') {
                    return response()->json([
                        'status' => false,
                        'message' => 'The active resume was deleted. Legacy copies, if any, were retained for rollback.',
                    ], 410);
                }
                if ($row && ($row->storage_status ?? '') === 'deleting') {
                    return response()->json(['status' => false, 'message' => 'Resume deletion is in progress. Retry shortly.'], 423);
                }
                if ($row && ($row->storage_status ?? '') === 'active' && $this->storage->objectAvailable($row)) {
                    $provider = 'wasabi';
                    $originalName = (string) ($row->original_name ?: $originalName);
                    $mimeType = $row->mime_type ?? null;
                    $fileSize = isset($row->file_size) ? (int) $row->file_size : null;
                    $expiry = max(60, min(900, (int) config('wasabi.url_expiry_seconds', 300)));
                }
            }
        } catch (Throwable $e) {
            Log::warning('Wasabi resume metadata lookup failed; resolver URLs will use the legacy fallback order.', [
                'applicant_sno' => $sno,
                'message' => $e->getMessage(),
            ]);
        }

        return response()->json([
            'status' => true,
            'provider' => $provider,
            'expires_in_seconds' => $expiry,
            'view_url' => $inlineUrl,
            'download_url' => $downloadUrl,
            'original_name' => $originalName,
            'mime_type' => $mimeType,
            'file_size' => $fileSize,
            'message' => 'Use these authenticated ERP resolver URLs; the source is checked in priority order on each request.',
        ]);
    }

    /** Resolve in order: reachable Wasabi object -> authenticated Google Drive file/link -> local legacy file. */
    public function open(Request $request, int $sno)
    {
        $applicant = $this->findApplicant($sno);
        if (!$applicant) {
            abort(404, 'Applicant not found.');
        }

        $disposition = strtolower((string) $request->query('disposition', 'inline'));
        if (!in_array($disposition, ['inline', 'attachment'], true)) {
            $disposition = 'inline';
        }

        // 1. Wasabi: only redirect after a real HEAD request confirms that the object is available.
        try {
            if ($this->storageReady()) {
                $row = $this->storage->anyRow($sno);
                if ($row && ($row->storage_status ?? '') === 'deleted') {
                    abort(410, 'The active resume was deleted.');
                }
                if ($row && ($row->storage_status ?? '') === 'deleting') {
                    abort(423, 'Resume deletion is in progress.');
                }
                if ($row && ($row->storage_status ?? '') === 'active') {
                    if ($this->storage->objectAvailable($row)) {
                        try {
                            return redirect()->away($this->storage->temporaryUrl($row, $disposition));
                        } catch (Throwable $e) {
                            Log::warning('Wasabi signed URL could not be created; trying legacy resume sources.', [
                                'applicant_sno' => $sno,
                                'message' => $e->getMessage(),
                            ]);
                        }
                    }
                }
            }
        } catch (\Symfony\Component\HttpKernel\Exception\HttpException $e) {
            throw $e;
        } catch (Throwable $e) {
            Log::warning('Wasabi resume lookup failed; trying Google Drive and local fallback.', [
                'applicant_sno' => $sno,
                'message' => $e->getMessage(),
            ]);
        }

        // 2. Google Drive: prefer an authenticated file-id download. This confirms the file can really be read.
        $drive = $this->decodeDriveData($applicant->drive_data ?? null);
        $webViewLink = (string) ($drive['webViewLink'] ?? '');
        $driveId = trim((string) ($drive['file_id'] ?? ''));
        if ($driveId === '' && $this->isAllowedDriveLink($webViewLink)) {
            $driveId = $this->extractDriveFileId($webViewLink);
        }
        if ($driveId !== '') {
            $temporaryDirectory = storage_path('app/tmp/legacy-resume-access');
            if (!is_dir($temporaryDirectory) && !mkdir($temporaryDirectory, 0700, true) && !is_dir($temporaryDirectory)) {
                Log::error('Unable to create the private temporary resume directory.', ['applicant_sno' => $sno]);
            } else {
                $originalName = $this->storage->safeOriginalName((string) ($drive['file_name'] ?? $applicant->attachment ?? ('resume-' . $sno . '.pdf')));
                $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
                $extension = preg_replace('/[^a-z0-9]/i', '', $extension) ?: 'bin';
                $temporaryPath = $temporaryDirectory . DIRECTORY_SEPARATOR . Str::uuid() . '.' . $extension;

                try {
                    app(GoogleDriveService::class)->downloadToFile($driveId, $temporaryPath);
                    $size = is_file($temporaryPath) ? filesize($temporaryPath) : false;
                    $maxBytes = max(1, (int) config('wasabi.max_file_size_bytes', 52428800));
                    if ($size === false || $size < 1) {
                        throw new \RuntimeException('Google Drive returned an empty resume.');
                    }
                    if ($size > $maxBytes) {
                        @unlink($temporaryPath);
                        Log::warning('Google Drive resume exceeded the configured transfer size; trying local fallback.', [
                            'applicant_sno' => $sno,
                            'size_bytes' => $size,
                        ]);
                    } else {
                        if (in_array($extension, ['html', 'htm', 'svg', 'xhtml', 'xml', 'js'], true)) {
                            $disposition = 'attachment';
                        }
                        $mime = function_exists('mime_content_type') ? (mime_content_type($temporaryPath) ?: 'application/octet-stream') : 'application/octet-stream';
                        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $originalName) ?: 'resume';
                        $headers = [
                            'Content-Type' => $mime,
                            'Content-Disposition' => $disposition . '; filename="' . $safeName . '"',
                            'Cache-Control' => 'private, no-store, max-age=0',
                            'Pragma' => 'no-cache',
                            'X-Content-Type-Options' => 'nosniff',
                            'X-Frame-Options' => 'SAMEORIGIN',
                        ];
                        if ($disposition === 'attachment') {
                            return response()->download($temporaryPath, $originalName, $headers)->deleteFileAfterSend(true);
                        }
                        return response()->file($temporaryPath, $headers)->deleteFileAfterSend(true);
                    }
                } catch (Throwable $e) {
                    if (is_file($temporaryPath)) {
                        @unlink($temporaryPath);
                    }
                    Log::warning('Google Drive resume could not be downloaded; trying the local fallback.', [
                        'applicant_sno' => $sno,
                        'message' => $e->getMessage(),
                    ]);
                }
            }
        }

        // If the stored Drive link had no extractable file id, allow only HTTPS links on approved Google hosts.
        if ($driveId === '' && $this->isAllowedDriveLink($webViewLink) && $disposition === 'inline') {
            return redirect()->away($webViewLink);
        }

        // 3. Local public-folder legacy copy is the last fallback, but is served via this authenticated route.
        $localPath = $this->resolveLegacyLocalPath((string) ($applicant->attachment ?? ''));
        if ($localPath) {
            $name = basename($localPath);
            $extension = strtolower((string) pathinfo($name, PATHINFO_EXTENSION));
            if (in_array($extension, ['html', 'htm', 'svg', 'xhtml', 'xml', 'js'], true)) {
                $disposition = 'attachment';
            }
            $mime = function_exists('mime_content_type') ? (mime_content_type($localPath) ?: 'application/octet-stream') : 'application/octet-stream';
            $headers = [
                'Content-Type' => $mime,
                'Content-Disposition' => $disposition . '; filename="' . (preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?: 'resume') . '"',
                'Cache-Control' => 'private, no-store, max-age=0',
                'Pragma' => 'no-cache',
                'X-Content-Type-Options' => 'nosniff',
                'X-Frame-Options' => 'SAMEORIGIN',
            ];
            if ($disposition === 'attachment') {
                return response()->download($localPath, $name, $headers);
            }
            return response()->file($localPath, $headers);
        }

        abort(404, 'No readable resume source is available in Wasabi, Google Drive, or the local legacy folder.');
    }

    /** Upload/replace a resume for an existing applicant; keep a legacy mirror for old screens. */
    public function upload(Request $request, int $sno)
    {
        $applicant = $this->findApplicant($sno);
        if (!$applicant) return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);
        if (!$this->storageReady()) {
            return response()->json(['status' => false, 'message' => 'Wasabi is not ready. Verify configuration, install aws/aws-sdk-php and apply the Wasabi storage SQL.'], 503);
        }

        $validated = $request->validate([
            'upload_resume' => ['required', 'file', 'max:10240', 'mimes:pdf,doc,docx,docm,odt,rtf,txt,text,md,markdown,html,htm,ppt,pptx,xls,xlsx,jpg,jpeg,png,webp,bmp,gif,tif,tiff'],
        ]);
        $file = $validated['upload_resume'];
        $oldAttachment = (string) ($applicant->attachment ?? '');
        $safeExtension = strtolower((string) $file->getClientOriginalExtension());
        $safeExtension = preg_replace('/[^a-z0-9]/i', '', $safeExtension) ?: 'bin';
        $newName = 'RESUME-' . $sno . '-' . Str::uuid() . '.' . $safeExtension;
        $localPath = public_path('job_applications/resume_files/' . $newName);
        $localDirectory = dirname($localPath);
        if (!File::exists($localDirectory)) File::makeDirectory($localDirectory, 0775, true);

        // Copy, don't move: Laravel may need the UploadedFile through the request lifecycle.
        if (!copy($file->getRealPath(), $localPath)) {
            return response()->json(['status' => false, 'message' => 'Could not create the compatibility copy. No resume was changed.'], 500);
        }

        $oldResumeText = $applicant->resume_text;
        $oldResumeHash = $applicant->recruitment_resume_sha256;
        $oldUpdatedBy = $applicant->updated_by;
        $oldUpdatedAt = $applicant->updated_at;
        $actorId = (int) (auth()->user()->user_id ?? auth()->id() ?? 0);
        try {
            // Switch the legacy attachment pointer first; restore it if Wasabi rejects the new object.
            $applicant->attachment = $newName;
            $applicant->resume_text = null;
            $applicant->recruitment_resume_sha256 = hash_file('sha256', $localPath);
            $applicant->updated_by = $actorId > 0 ? $actorId : null;
            $applicant->updated_at = now();
            $applicant->save();

            $stored = $this->storage->storePath(
                $sno,
                $localPath,
                $file->getClientOriginalName(),
                'upload',
                'upload:' . $file->getClientOriginalName(),
                $actorId > 0 ? $actorId : null,
                true
            );

            return response()->json([
                'status' => true,
                'message' => 'Resume uploaded and verified in Wasabi. A local compatibility mirror was retained for older ERP screens.',
                'data' => [
                    'applicant_sno' => $sno,
                    'provider' => 'wasabi',
                    'original_name' => $stored['original_name'],
                    'file_size' => $stored['file_size'],
                    'sha256' => $stored['sha256'],
                    'view_url' => url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=inline'),
                    'download_url' => url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=attachment'),
                ],
            ]);
        } catch (Throwable $e) {
            try {
                $applicant->attachment = $oldAttachment ?: null;
                $applicant->resume_text = $oldResumeText;
                $applicant->recruitment_resume_sha256 = $oldResumeHash;
                $applicant->updated_by = $oldUpdatedBy;
                $applicant->updated_at = $oldUpdatedAt;
                $applicant->save();
            } catch (Throwable $restoreError) {
                Log::critical('Could not restore the previous applicant attachment after Wasabi upload failure.', ['applicant_sno' => $sno, 'message' => $restoreError->getMessage()]);
            }
            @unlink($localPath);
            Log::error('Existing applicant Wasabi resume upload failed.', ['applicant_sno' => $sno, 'message' => $e->getMessage()]);
            return response()->json(['status' => false, 'message' => 'Wasabi upload failed. The previous active resume was preserved.'], 503);
        }
    }

    /** Delete the active cloud object only; retain legacy local/Drive sources for controlled rollback. */
    public function destroy(Request $request, int $sno)
    {
        if (!$this->findApplicant($sno)) return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);
        if (!$this->storageReady()) return response()->json(['status' => false, 'message' => 'Wasabi is not ready.'], 503);

        try {
            $actorId = (int) (auth()->user()->user_id ?? auth()->id() ?? 0);
            $deleted = $this->storage->deleteApplicantObject($sno, $actorId > 0 ? $actorId : null);
            if (!$deleted) return response()->json(['status' => false, 'message' => 'No active Wasabi object was found.'], 404);
            return response()->json(['status' => true, 'message' => 'Wasabi object deleted. Legacy local/Drive copies were not removed.']);
        } catch (Throwable $e) {
            Log::error('Wasabi resume deletion failed.', ['applicant_sno' => $sno, 'message' => $e->getMessage()]);
            return response()->json(['status' => false, 'message' => 'Wasabi delete failed. Storage metadata was not marked deleted.'], 503);
        }
    }

    /**
     * Protected by a separate high-entropy API token (X-Wasabi-Migration-Token).
     * dry_run defaults to true. The source files are never deleted by this endpoint.
     */
    public function migrate(Request $request)
    {
        $configuredToken = (string) config('wasabi.migration_api_token', '');
        $providedToken = (string) $request->header('X-Wasabi-Migration-Token', '');
        if (strlen($configuredToken) < 32) {
            return response()->json(['status' => false, 'message' => 'WASABI_MIGRATION_API_TOKEN must contain at least 32 characters.'], 503);
        }
        if ($providedToken === '' || !hash_equals($configuredToken, $providedToken)) {
            return response()->json(['status' => false, 'message' => 'Unauthorized migration request.'], 401);
        }
        if (!$this->storageReady()) {
            return response()->json(['status' => false, 'message' => 'Wasabi is not ready. Verify config, SDK dependency and SQL.'], 503);
        }

        $validated = $request->validate([
            'applicant_sno' => ['nullable', 'integer', 'min:1'],
            'source' => ['nullable', 'in:auto,local,drive'],
            'dry_run' => ['nullable', 'boolean'],
            'limit' => ['nullable', 'integer', 'min:1', 'max:100'],
            'after_sno' => ['nullable', 'integer', 'min:0'],
            'replace' => ['nullable', 'boolean'],
        ]);
        $dryRun = array_key_exists('dry_run', $validated) ? (bool) $validated['dry_run'] : true;
        $sourceChoice = (string) ($validated['source'] ?? 'auto');
        $limit = (int) ($validated['limit'] ?? 25);
        $replace = (bool) ($validated['replace'] ?? false);

        $query = ApplicantModel::query()->where('status', '!=', 2);
        if (!empty($validated['applicant_sno'])) {
            $query->where('sno', (int) $validated['applicant_sno']);
            $limit = 1;
        } else {
            if (array_key_exists('after_sno', $validated)) $query->where('sno', '>', (int) $validated['after_sno']);
            $query->where(function ($q) {
                $q->whereNotNull('attachment')->orWhereNotNull('drive_data');
            });
            $query->orderBy('sno')->limit($limit);
        }
        $applicants = $query->get(['sno', 'attachment', 'drive_data', 'applicant_id']);
        $results = [];
        $counts = ['planned' => 0, 'migrated' => 0, 'skipped' => 0, 'failed' => 0];
        $lastSno = null;
        $singleApplicant = !empty($validated['applicant_sno']);

        foreach ($applicants as $applicant) {
            $sno = (int) $applicant->sno;
            $lastSno = $sno;
            $temporaryFile = null;
            try {
                $existing = $this->storage->anyRow($sno);
                if ($existing && ($existing->storage_status ?? '') === 'active' && !$replace) {
                    $counts['skipped']++;
                    $results[] = ['applicant_sno' => $sno, 'status' => 'skipped', 'reason' => 'active_wasabi_object_already_exists'];
                    continue;
                }
                if ($existing && ($existing->storage_status ?? '') === 'deleted' && !$replace) {
                    $counts['skipped']++;
                    $results[] = ['applicant_sno' => $sno, 'status' => 'skipped', 'reason' => 'cloud_object_was_deleted; pass replace=true to restore'];
                    continue;
                }

                $driveData = $this->decodeDriveData($applicant->drive_data ?? null);
                $driveId = trim((string) ($driveData['file_id'] ?? ''));
                $localPath = $this->resolveLegacyLocalPath((string) ($applicant->attachment ?? ''));
                $selectedProvider = null;
                $sourcePath = null;
                $originalName = '';
                $temporaryFile = null;

                if ($sourceChoice === 'local' || ($sourceChoice === 'auto' && $localPath)) {
                    if (!$localPath) throw new \RuntimeException('The legacy public-path file was not found.');
                    $selectedProvider = 'local';
                    $sourcePath = $localPath;
                    $originalName = basename($localPath);
                } elseif ($sourceChoice === 'drive' || ($sourceChoice === 'auto' && !$localPath)) {
                    if ($driveId === '') throw new \RuntimeException('No Google Drive file_id is present in drive_data and no usable local source was found.');
                    $selectedProvider = 'drive';
                    $originalName = (string) ($driveData['file_name'] ?? $applicant->attachment ?? ('resume-' . $sno . '.pdf'));
                    if (!$dryRun) {
                        $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
                        $extension = preg_replace('/[^a-z0-9]/i', '', $extension) ?: 'bin';
                        $temporaryDirectory = storage_path('app/tmp/wasabi-migration');
                        if (!is_dir($temporaryDirectory) && !mkdir($temporaryDirectory, 0700, true) && !is_dir($temporaryDirectory)) {
                            throw new \RuntimeException('Could not create secure temporary directory for Drive download.');
                        }
                        $temporaryFile = $temporaryDirectory . DIRECTORY_SEPARATOR . Str::uuid() . '.' . $extension;
                        app(GoogleDriveService::class)->downloadToFile($driveId, $temporaryFile);
                        $sourcePath = $temporaryFile;
                    }
                } else {
                    throw new \RuntimeException('No valid legacy resume source was found.');
                }

                if ($dryRun) {
                    $counts['planned']++;
                    $results[] = [
                        'applicant_sno' => $sno,
                        'status' => 'planned',
                        'source' => $selectedProvider,
                        'source_name' => basename($originalName),
                        'would_replace' => $replace,
                    ];
                    continue;
                }

                if (!$sourcePath || !is_file($sourcePath)) throw new \RuntimeException('Selected source did not produce a readable file.');
                $stored = $this->storage->storePath(
                    $sno,
                    $sourcePath,
                    $originalName,
                    $selectedProvider,
                    $selectedProvider === 'drive' ? $driveId : ('local:' . basename($sourcePath)),
                    null,
                    $replace
                );
                $counts['migrated']++;
                $results[] = [
                    'applicant_sno' => $sno,
                    'status' => 'migrated',
                    'source' => $selectedProvider,
                    'object_key' => $stored['object_key'],
                    'sha256' => $stored['sha256'],
                    'file_size' => $stored['file_size'],
                ];
            } catch (Throwable $e) {
                $counts['failed']++;
                $this->storage->audit($sno, 'migration', $sourceChoice, null, null, 'failed', $e->getMessage(), null);
                Log::error('Applicant Wasabi migration failed.', ['applicant_sno' => $sno, 'source' => $sourceChoice, 'message' => $e->getMessage()]);
                $results[] = ['applicant_sno' => $sno, 'status' => 'failed', 'message' => 'Migration failed; inspect the server log/audit record.'];
            } finally {
                if (!empty($temporaryFile) && is_file($temporaryFile)) @unlink($temporaryFile);
            }
        }

        return response()->json([
            'status' => true,
            'dry_run' => $dryRun,
            'source' => $sourceChoice,
            'limit' => $limit,
            'counts' => $counts,
            'last_processed_sno' => $lastSno,
            'next_after_sno' => $singleApplicant ? null : $lastSno,
            'results' => $results,
            'source_files_deleted' => false,
        ]);
    }

    private function findApplicant(int $sno): ?ApplicantModel
    {
        return ApplicantModel::query()->where('sno', $sno)->where('status', '!=', 2)->first();
    }

    private function storageReady(): bool
    {
        if (!$this->storage->isConfigured()) return false;
        try {
            $this->storage->assertConfigured();
            return true;
        } catch (Throwable $e) {
            return false;
        }
    }

    private function resolveLegacyLocalPath(string $attachment): ?string
    {
        $attachment = trim($attachment);
        if ($attachment === '') return null;
        $baseDirectory = realpath(public_path('job_applications/resume_files'));
        if (!$baseDirectory) return null;
        $basename = basename(str_replace('\\', '/', $attachment));
        if ($basename === '' || $basename === '.' || $basename === '..') return null;
        $candidate = realpath($baseDirectory . DIRECTORY_SEPARATOR . $basename);
        if (!$candidate || !is_file($candidate) || !is_readable($candidate)) return null;
        if (!str_starts_with($candidate, $baseDirectory . DIRECTORY_SEPARATOR)) return null;
        return $candidate;
    }

    private function decodeDriveData($driveData): array
    {
        if (is_array($driveData)) return $driveData;
        if (!is_string($driveData) || trim($driveData) === '') return [];
        $decoded = json_decode($driveData, true);
        return is_array($decoded) ? $decoded : [];
    }

    /** Extract a Google Drive resource id from supported Drive/Docs viewer URL shapes. */
    private function extractDriveFileId(string $url): string
    {
        if (!$this->isAllowedDriveLink($url)) {
            return '';
        }

        $parts = parse_url($url);
        $path = (string) ($parts['path'] ?? '');
        if (preg_match('~/(?:file|document|spreadsheets|presentation|forms)/d/([A-Za-z0-9_-]+)~', $path, $matches)) {
            return $matches[1];
        }

        parse_str((string) ($parts['query'] ?? ''), $query);
        $queryId = trim((string) ($query['id'] ?? ''));
        return preg_match('/^[A-Za-z0-9_-]{10,}$/', $queryId) ? $queryId : '';
    }

    private function isAllowedDriveLink(string $url): bool
    {
        if ($url === '') return false;
        $parts = parse_url($url);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https') return false;
        $host = strtolower((string) ($parts['host'] ?? ''));
        return in_array($host, ['drive.google.com', 'docs.google.com'], true);
    }

    private function legacyProvider(ApplicantModel $applicant): string
    {
        $drive = $this->decodeDriveData($applicant->drive_data ?? null);
        if (!empty($drive['file_id']) || $this->isAllowedDriveLink((string) ($drive['webViewLink'] ?? ''))) {
            return 'google_drive';
        }
        if ($this->resolveLegacyLocalPath((string) ($applicant->attachment ?? ''))) {
            return 'local';
        }
        return 'unavailable';
    }

    private function legacyOriginalName(ApplicantModel $applicant, int $sno): ?string
    {
        $drive = $this->decodeDriveData($applicant->drive_data ?? null);
        $name = trim((string) ($drive['file_name'] ?? ''));
        if ($name === '') {
            $name = basename((string) ($applicant->attachment ?? ''));
        }
        if ($name === '') {
            return null;
        }
        return $this->storage->safeOriginalName($name);
    }
}
