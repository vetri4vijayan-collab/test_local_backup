<?php

namespace App\Http\Controllers\hr_management\hr_sib;

class StaffEarlyBirdController extends AttendanceEligibilityReportController
{
    protected const REPORT_TYPE = 'early_bird';
    protected const VIEW_NAME = 'content.hr_management.hr_sib.early_bird.early_bird_list';
    protected const PAGE_TITLE = 'Staff Early Bird';
    protected const PAGE_DESCRIPTION = 'Employees must meet the Master Attendance rules and arrive at least five minutes before each scheduled shift.';
    protected const DATA_ROUTE_NAME = 'hr_sib.early_bird.data';
    protected const EXPORT_ROUTE_NAME = 'hr_sib.early_bird.export';
    protected const CONFIRM_ROUTE_NAME = 'hr_sib.early_bird.confirm';
    protected const LOG_TABLE = 'egc_staff_early_bird_log';
}
