<?php

namespace App\Http\Controllers\hr_management\hr_sib;

use App\Http\Controllers\Controller;
use App\Services\AttendanceEligibility\MonthlyAttendanceEligibilityService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Schema;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use InvalidArgumentException;
use Illuminate\Validation\ValidationException;
use Throwable;

abstract class AttendanceEligibilityReportController extends Controller
{
    protected const REPORT_TYPE = 'master';
    protected const VIEW_NAME = '';
    protected const PAGE_TITLE = '';
    protected const PAGE_DESCRIPTION = '';
    protected const DATA_ROUTE_NAME = '';
    protected const EXPORT_ROUTE_NAME = '';
    protected const CONFIRM_ROUTE_NAME = '';
    protected const LOG_TABLE = '';

    public function index()
    {
        $entities = DB::table('egc_entity')
            ->where('status', 0)
            ->orderBy('entity_name')
            ->get(['sno', 'entity_name', 'entity_short_name']);

        return view(static::VIEW_NAME, [
            'reportType' => static::REPORT_TYPE,
            'reportTitle' => static::PAGE_TITLE,
            'reportDescription' => static::PAGE_DESCRIPTION,
            'dataUrl' => route(static::DATA_ROUTE_NAME),
            'exportUrl' => route(static::EXPORT_ROUTE_NAME),
            'confirmUrl' => route(static::CONFIRM_ROUTE_NAME),
            'csrfToken' => csrf_token(),
            'currentMonth' => now()->format('M-Y'),
            'entities' => $entities,
            'perPage' => 25,
        ]);
    }

    public function data(Request $request, MonthlyAttendanceEligibilityService $service)
    {
        try {
            $filters = $this->validatedFilters($request);
            $report = $service->generate(static::REPORT_TYPE, $filters, true, true, false);

            return response()->json([
                'status' => 200,
                'data' => $report['rows'],
                'summary' => $report['summary'],
                'pagination' => $report['pagination'],
                'period' => $report['period'],
            ]);
        } catch (ValidationException $exception) {
            return response()->json([
                'status' => 422,
                'message' => 'Please correct the submitted filters.',
                'errors' => $exception->errors(),
            ], 422);
        } catch (InvalidArgumentException $exception) {
            return response()->json([
                'status' => 422,
                'message' => $exception->getMessage(),
            ], 422);
        } catch (Throwable $exception) {
            Log::error('Monthly attendance eligibility report failed.', [
                'report_type' => static::REPORT_TYPE,
                'user_id' => optional($request->user())->id,
                'message' => $exception->getMessage(),
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'Unable to load the attendance report. Please retry or contact the system administrator.',
            ], 500);
        }
    }

    public function exportEligible(Request $request, MonthlyAttendanceEligibilityService $service)
    {
        try {
            $filters = $this->validatedFilters($request);
            $report = $service->generate(static::REPORT_TYPE, $filters, false, false, true);
        } catch (ValidationException $exception) {
            abort(422, 'Please correct the submitted export filters.');
        } catch (InvalidArgumentException $exception) {
            abort(422, $exception->getMessage());
        } catch (Throwable $exception) {
            Log::error('Monthly attendance eligibility export failed.', [
                'report_type' => static::REPORT_TYPE,
                'user_id' => optional($request->user())->id,
                'message' => $exception->getMessage(),
            ]);
            abort(500, 'Unable to export the attendance report. Please retry or contact the system administrator.');
        }

        $rows = $report['rows'];
        $reportType = static::REPORT_TYPE;
        $filename = ($reportType === 'early_bird' ? 'staff-early-bird-' : 'master-attendance-')
            . $report['period']['month'] . '-eligible.csv';

        return response()->streamDownload(function () use ($rows, $reportType, $report) {
            $output = fopen('php://output', 'w');
            // UTF-8 BOM improves compatibility with Microsoft Excel.
            fwrite($output, "\xEF\xBB\xBF");

            $headers = [
                'Staff ID', 'Staff Name', 'Department', 'Company', 'Entity',
                'Report Month', 'Period Start', 'Period End', 'Eligibility',
                'Scheduled Working Days', 'Attended Days', 'Leave Days',
                'Permission Days', 'Absent Days', 'Missing Attendance Days', 'Shift Log Gap Weekdays',
            ];
            if ($reportType === 'early_bird') {
                $headers[] = 'Early Arrival Days';
                $headers[] = 'Not Early Days';
                $headers[] = 'Late Days';
                $headers[] = 'Missing In-time Days';
                $headers[] = 'Early Arrival Rate (%)';
            } else {
                $headers[] = 'Attendance Rate (%)';
            }
            array_push($headers, 'HR Confirmation', 'HR Decision Mode', 'System Recommendation', 'Confirmed At', 'Eligibility Reason');
            fputcsv($output, $headers);

            foreach ($rows as $row) {
                $company = $row['company_name'] ?: ($row['company_type'] === 1 ? 'EGC Management' : '');
                $entity = $row['entity_name'] ?: '';
                $line = [
                    $this->csvSafe($row['employee_id'] ?? ''),
                    $this->csvSafe($row['staff_name'] ?? ''),
                    $this->csvSafe($row['department_name'] ?? ''),
                    $this->csvSafe($company),
                    $this->csvSafe($entity),
                    $report['period']['month'],
                    $report['period']['start_date'],
                    $report['period']['end_date'],
                    !empty($row['eligible']) ? 'Eligible' : 'Not Eligible',
                    $row['scheduled_days'],
                    $row['attended_days'],
                    $row['leave_days'],
                    $row['permission_days'],
                    $row['absent_days'],
                    $row['missing_days'],
                    $row['shift_log_gap_days'],
                ];

                if ($reportType === 'early_bird') {
                    $line[] = $row['early_days'];
                    $line[] = $row['not_early_days'];
                    $line[] = $row['late_days'];
                    $line[] = $row['missing_in_time_days'];
                    $line[] = $row['early_percent'];
                } else {
                    $line[] = $row['attendance_percent'];
                }
                $decisionLabels = [
                    'calculated' => 'System calculated',
                    'manual_eligible' => 'HR manually confirmed Eligible',
                    'manual_not_eligible' => 'HR manually confirmed Not Eligible',
                ];
                $line[] = !empty($row['is_confirmed']) ? 'Confirmed' : 'Not confirmed';
                $line[] = $decisionLabels[$row['decision_mode'] ?? 'calculated'] ?? 'System calculated';
                $line[] = !empty($row['calculated_eligible']) ? 'Eligible' : 'Not Eligible';
                $line[] = $this->csvSafe($row['confirmed_at'] ?? '');
                $line[] = $this->csvSafe($row['reason'] ?? '');
                fputcsv($output, $line);
            }

            fclose($output);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Cache-Control' => 'no-store, no-cache, must-revalidate',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    /**
     * Save the selected staff's monthly HR decision and preserve the current system recommendation.
     * The explicit decision mode is validated server-side and upserted by staff/month.
     */
    public function confirmSelected(Request $request, MonthlyAttendanceEligibilityService $service)
    {
        try {
            $validated = $request->validate([
                'month' => ['required', 'date_format:M-Y'],
                'staff_ids' => ['required', 'array', 'min:1', 'max:500'],
                'staff_ids.*' => ['required', 'integer', 'min:1', 'distinct'],
                'decision_mode' => ['required', 'in:calculated,manual_eligible,manual_not_eligible'],
                'scope' => ['nullable', 'string', 'max:20', 'regex:/^(all|egc|[1-9][0-9]*)$/'],
                'search' => ['nullable', 'string', 'max:100'],
            ]);

            $month = trim((string) $validated['month']);
            try {
                $monthStart = Carbon::createFromFormat('!M-Y', $month)->startOfMonth();
            } catch (\Throwable $exception) {
                throw new InvalidArgumentException('Select a valid report month.');
            }
            if (!$monthStart || $monthStart->format('M-Y') !== $month) {
                throw new InvalidArgumentException('Select a valid report month.');
            }
            if ($monthStart->greaterThan(now()->startOfMonth())) {
                throw new InvalidArgumentException('Future months cannot be selected.');
            }

            if (!Schema::hasTable(static::LOG_TABLE)) {
                return response()->json([
                    'status' => 503,
                    'message' => 'The confirmation log table is not installed. Run the supplied production SQL first.',
                ], 503);
            }
            if (!Schema::hasColumn(static::LOG_TABLE, 'decision_mode')
                || !Schema::hasColumn(static::LOG_TABLE, 'calculated_eligibility_status')) {
                return response()->json([
                    'status' => 503,
                    'message' => 'The eligibility log table needs the latest SQL update. Run the supplied production SQL and retry.',
                ], 503);
            }
            if (static::REPORT_TYPE === 'early_bird' && !Schema::hasColumn(static::LOG_TABLE, 'not_early_days')) {
                return response()->json([
                    'status' => 503,
                    'message' => 'The Early Bird log table needs the not_early_days column. Run the updated production SQL and retry.',
                ], 503);
            }

            $decisionMode = (string) $validated['decision_mode'];
            $requestedIds = array_values(array_unique(array_map('intval', $validated['staff_ids'])));
            $report = $service->generate(static::REPORT_TYPE, [
                'month' => $month,
                'scope' => (string) ($validated['scope'] ?? 'all'),
                'search' => trim((string) ($validated['search'] ?? '')),
                'row_filter' => 'all',
                'per_page' => 100,
                'page' => 1,
            ], false, false, false, false);

            $rowsByStaffId = [];
            foreach ($report['rows'] as $row) {
                $rowsByStaffId[(int) $row['staff_pk']] = $row;
            }

            $selectedRows = [];
            foreach ($requestedIds as $staffId) {
                if (!isset($rowsByStaffId[$staffId])) {
                    return response()->json([
                        'status' => 422,
                        'message' => 'One or more selected staff no longer match the current report filters. Reload the report and select them again.',
                    ], 422);
                }
                // Joining-month day-1 rule is mandatory and cannot be bypassed by
                // choosing a manual "Eligible" confirmation.
                if ($decisionMode === 'manual_eligible'
                    && !empty($rowsByStaffId[$staffId]['joined_after_month_start'])) {
                    return response()->json([
                        'status' => 422,
                        'message' => 'Staff who joined after the first calendar day cannot be marked eligible for their joining month.',
                    ], 422);
                }
                $selectedRows[] = $rowsByStaffId[$staffId];
            }

            $now = now();
            $reportMonth = $monthStart->toDateString();
            $confirmedBy = (int) ($request->user()->getAuthIdentifier() ?? 0);
            $records = [];
            $savedEligibleCount = 0;
            $savedNotEligibleCount = 0;

            foreach ($selectedRows as $row) {
                $calculatedEligible = !empty($row['eligible']);
                $finalEligible = match ($decisionMode) {
                    'manual_eligible' => true,
                    'manual_not_eligible' => false,
                    default => $calculatedEligible,
                };
                $savedEligibleCount += $finalEligible ? 1 : 0;
                $savedNotEligibleCount += $finalEligible ? 0 : 1;

                $record = [
                    'staff_id' => (int) $row['staff_pk'],
                    'report_month' => $reportMonth,
                    'eligibility_status' => $finalEligible ? 1 : 0,
                    'decision_mode' => $decisionMode,
                    'calculated_eligibility_status' => $calculatedEligible ? 1 : 0,
                    'scheduled_days' => (int) $row['scheduled_days'],
                    'attended_days' => (int) $row['attended_days'],
                    'leave_days' => (int) $row['leave_days'],
                    'permission_days' => (int) $row['permission_days'],
                    'absent_days' => (int) $row['absent_days'],
                    'missing_days' => (int) $row['missing_days'],
                    'shift_log_gap_days' => (int) $row['shift_log_gap_days'],
                    'attendance_percent' => (float) $row['attendance_percent'],
                    'reason' => (string) $row['reason'],
                    'confirmed_by' => $confirmedBy,
                    'confirmed_at' => $now,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];

                if (static::REPORT_TYPE === 'early_bird') {
                    $record['early_days'] = (int) $row['early_days'];
                    $record['not_early_days'] = (int) $row['not_early_days'];
                    $record['late_days'] = (int) $row['late_days'];
                    $record['missing_in_time_days'] = (int) $row['missing_in_time_days'];
                    $record['early_percent'] = (float) $row['early_percent'];
                }
                $records[] = $record;
            }

            $updateColumns = [
                'eligibility_status', 'decision_mode', 'calculated_eligibility_status',
                'scheduled_days', 'attended_days', 'leave_days',
                'permission_days', 'absent_days', 'missing_days', 'shift_log_gap_days',
                'attendance_percent', 'reason', 'confirmed_by', 'confirmed_at', 'updated_at',
            ];
            if (static::REPORT_TYPE === 'early_bird') {
                array_push($updateColumns, 'early_days', 'not_early_days', 'late_days', 'missing_in_time_days', 'early_percent');
            }

            DB::transaction(function () use ($records, $updateColumns) {
                DB::table(static::LOG_TABLE)->upsert($records, ['staff_id', 'report_month'], $updateColumns);
            });

            return response()->json([
                'status' => 200,
                'message' => 'Monthly eligibility decision saved for ' . count($records) . ' staff member(s). Existing month/staff records were updated where present.',
                'saved_count' => count($records),
                'report_month' => $reportMonth,
                'decision_mode' => $decisionMode,
                'eligibility_counts' => [
                    'eligible' => $savedEligibleCount,
                    'not_eligible' => $savedNotEligibleCount,
                ],
            ]);
        } catch (ValidationException $exception) {
            return response()->json([
                'status' => 422,
                'message' => 'Please select a valid month and one or more staff members.',
                'errors' => $exception->errors(),
            ], 422);
        } catch (InvalidArgumentException $exception) {
            return response()->json(['status' => 422, 'message' => $exception->getMessage()], 422);
        } catch (\Throwable $exception) {
            Log::error('Monthly eligibility confirmation failed.', [
                'report_type' => static::REPORT_TYPE,
                'user_id' => optional($request->user())->id,
                'message' => $exception->getMessage(),
            ]);
            return response()->json([
                'status' => 500,
                'message' => 'Unable to save eligibility confirmations. Please retry or contact the system administrator.',
            ], 500);
        }
    }

    protected function validatedFilters(Request $request): array
    {
        $validated = $request->validate([
            'month' => ['nullable', 'date_format:M-Y'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'in:10,25,50,100'],
            'search' => ['nullable', 'string', 'max:100'],
            'scope' => ['nullable', 'string', 'max:20', 'regex:/^(all|egc|[1-9][0-9]*)$/'],
            'row_filter' => ['nullable', 'in:all,eligible,not_eligible'],
        ]);

        $month = trim((string) ($validated['month'] ?? now()->format('M-Y')));
        try {
            $monthStart = Carbon::createFromFormat('!M-Y', $month)->startOfMonth();
        } catch (\Throwable $exception) {
            throw new InvalidArgumentException('Select a valid report month.');
        }
        if (!$monthStart || $monthStart->format('M-Y') !== $month) {
            throw new InvalidArgumentException('Select a valid report month.');
        }
        if ($monthStart->greaterThan(now()->startOfMonth())) {
            throw new InvalidArgumentException('Future months cannot be selected.');
        }

        return [
            'month' => $month,
            'page' => (int) ($validated['page'] ?? 1),
            'per_page' => (int) ($validated['per_page'] ?? 25),
            'search' => trim((string) ($validated['search'] ?? '')),
            'scope' => (string) ($validated['scope'] ?? 'all'),
            'row_filter' => (string) ($validated['row_filter'] ?? 'all'),
        ];
    }

    private function csvSafe($value): string
    {
        $value = (string) ($value ?? '');
        // Prevent user-controlled text from being interpreted as an Excel formula.
        if ($value !== '' && preg_match('/^[\s]*[=+@\-]/', $value)) {
            return "'" . $value;
        }

        return $value;
    }
}
