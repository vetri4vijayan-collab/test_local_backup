<?php

namespace App\Http\Controllers\hr_management\hr_sib;

class MasterAttendanceController extends AttendanceEligibilityReportController
{
    protected const REPORT_TYPE = 'master';
    protected const VIEW_NAME = 'content.hr_management.hr_sib.master_attendance.master_attendance_list';
    protected const PAGE_TITLE = 'Staff Master Attendance';
    protected const PAGE_DESCRIPTION = 'Month-wise working-day attendance review. Sundays and configured holidays are excluded.';
    protected const DATA_ROUTE_NAME = 'hr_sib.master_attendance.data';
    protected const EXPORT_ROUTE_NAME = 'hr_sib.master_attendance.export';
    protected const CONFIRM_ROUTE_NAME = 'hr_sib.master_attendance.confirm';
    protected const LOG_TABLE = 'egc_master_attendance_log';
}
