<?php

namespace App\Http\Controllers\hr_management\hr_operation;

use App\Http\Controllers\Controller;
use App\Models\GeneralSettingsModel;
use App\Models\IndustrialVisitAttendeeModel;
use App\Models\IndustrialVisitModel;
use App\Models\CompanyModel;
use App\Models\QualificationLevelModel;
use App\Models\SocialMediaModel;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Throwable;

class IndustrialVisitController extends Controller
{
    private const CAREER_INTERESTS = [
        'Software',
        'Hardware',
        'Networking',
        'Embedded & Testing',
    ];
    public function index(): \Illuminate\Contracts\View\View
    {
        return view('content.hr_management.hr_operation.industrial_visit.industrial_visit_list');
    }

    public function lookups(): JsonResponse
    {
        try {
            $collegeNameColumn = $this->collegeNameColumn();

            $collegeQuery = DB::table('egc_college')
                ->select(['sno', DB::raw("{$collegeNameColumn} as college_name")])
                ->orderBy($collegeNameColumn);

            $collegeColumns = Schema::getColumnListing('egc_college');
            if (in_array('status', $collegeColumns, true)) {
                $collegeQuery->where('status', 0);
            }

            $colleges = $collegeQuery->get();

            $companies = CompanyModel::query()
                ->where('status', 0)
                ->select(['sno', 'company_name', 'company_logo', 'company_base_color', 'google_review_link', 'social_media_details'])
                ->orderBy('sno', 'asc')
                ->get()
                ->map(fn ($company) => [
                    'id' => (int) $company->sno,
                    'name' => $company->company_name,
                    'logo' => $this->companyLogoUrl($company),
                    'color' => $this->safeColor($company->company_base_color),
                    'google_review_link' => $this->resolveGoogleReviewLink($company, 'company'),
                ])
                ->values();

            $general = GeneralSettingsModel::query()->orderBy('sno')->first();
            $mainCompanyLogo = $general ? $this->generalLogoUrl($general) : asset('assets/common/logo_small.png');
            $mainCompanyColor = $this->safeColor($general?->company_base_color);

            $companies->prepend([
                'id' => 0,
                'name' => $general?->title ?: 'Main Company',
                'logo' => $mainCompanyLogo,
                'color' => $mainCompanyColor,
                'google_review_link' => $this->resolveGoogleReviewLink($general, 'general'),
            ]);

            $qualifications = QualificationLevelModel::query()
                ->where('status', 0)
                ->orderBy('qualification_level_name')
                ->get(['sno', 'qualification_level_name'])
                ->map(fn ($item) => [
                    'id' => (int) $item->sno,
                    'name' => $item->qualification_level_name,
                ])
                ->values();

            return response()->json([
                'success' => true,
                'data' => [
                    'colleges' => $colleges,
                    'companies' => $companies,
                    'qualifications' => $qualifications,
                    'today' => now()->format('Y-m-d'),
                ],
            ]);
        } catch (Throwable $e) {
            Log::error('Industrial Visit lookup loading failed.', [
                'exception' => $e,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Industrial Visit lookup data could not be loaded.',
            ], 500);
        }
    }

    public function majors(int $qualificationId): JsonResponse
    {
        try {
            $exists = QualificationLevelModel::query()
                ->where('sno', $qualificationId)
                ->where('status', 0)
                ->exists();

            if (!$exists) {
                return response()->json([
                    'success' => false,
                    'message' => 'Qualification level not found.',
                ], 404);
            }

            $majors = DB::table('egc_major')
                ->where('status', 0)
                ->where('qualification_id', $qualificationId)
                ->orderBy('major_name')
                ->get(['sno', 'major_name'])
                ->map(fn ($item) => [
                    'id' => (int) $item->sno,
                    'name' => $item->major_name,
                ])
                ->values();

            return response()->json([
                'success' => true,
                'data' => $majors,
            ]);
        } catch (Throwable $e) {
            Log::error('Industrial Visit major lookup failed.', [
                'qualification_id' => $qualificationId,
                'exception' => $e,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Major list could not be loaded.',
            ], 500);
        }
    }

    public function data(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'page' => ['nullable', 'integer', 'min:1'],
            'perpage' => ['nullable', 'integer', 'min:5', 'max:500'],
            'search' => ['nullable', 'string', 'max:150'],
            'college_id' => ['nullable', 'integer', 'min:1'],
            'company_id' => ['nullable', 'integer', 'min:0'],
            'date' => ['nullable', 'date_format:Y-m-d'],
        ]);

        $page = (int) ($validated['page'] ?? 1);
        $perpage = (int) ($validated['perpage'] ?? 25);
        $search = trim((string) ($validated['search'] ?? ''));
        $companyFilter = array_key_exists('company_id', $validated) && $validated['company_id'] !== null
            ? (int) $validated['company_id']
            : null;

        $attendeeCounts = DB::table('egc_industrial_visit_attendees as iva')
            ->select('iva.iv_sno', DB::raw('COUNT(*) as attendee_count'))
            ->where('iva.status', 0)
            ->groupBy('iva.iv_sno');

        $query = IndustrialVisitModel::query()
            ->from('egc_industrial_visits as iv')
            ->leftJoinSub($attendeeCounts, 'ac', function ($join) {
                $join->on('ac.iv_sno', '=', 'iv.sno');
            })
            ->where('iv.status', 0)
            ->select([
                'iv.sno',
                'iv.iv_code',
                'iv.iv_date',
                'iv.college_id',
                'iv.college_name',
                'iv.company_id',
                'iv.company_name',
                'iv.company_logo',
                'iv.company_base_color',
                'iv.google_review_link',
                'iv.qr_token',
                DB::raw('COALESCE(ac.attendee_count, 0) as attendee_count'),
            ])
            ->orderByDesc('iv.iv_date')
            ->orderByDesc('iv.sno');

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('iv.iv_code', 'like', "%{$search}%")
                    ->orWhere('iv.college_name', 'like', "%{$search}%")
                    ->orWhere('iv.company_name', 'like', "%{$search}%");
            });
        }

        if (array_key_exists('college_id', $validated) && $validated['college_id'] !== null) {
            $query->where('iv.college_id', (int) $validated['college_id']);
        }

        if ($companyFilter !== null) {
            if ($companyFilter === 0) {
                $query->where(function ($q) {
                    $q->where('iv.company_id', 0)
                        ->orWhere(function ($legacy) {
                            $legacy->whereNull('iv.company_id')
                                ->whereNull('iv.entity_company_id');
                        });
                });
            } else {
                $query->where(function ($q) use ($companyFilter) {
                    $q->where('iv.company_id', $companyFilter)
                        ->orWhere(function ($legacy) use ($companyFilter) {
                            $legacy->whereNull('iv.company_id')
                                ->where('iv.entity_company_id', $companyFilter);
                        });
                });
            }
        }

        if (!empty($validated['date'])) {
            $query->whereDate('iv.iv_date', $validated['date']);
        }

        $paginated = $query->paginate($perpage, ['*'], 'page', $page);
        $items = collect($paginated->items());

        $companyIds = $items
            ->map(fn ($item) => (int) ($item->company_id ?? 0))
            ->filter(fn ($id) => $id > 0)
            ->unique()
            ->values();

        $companyMap = $companyIds->isEmpty()
            ? collect()
            : CompanyModel::query()->whereIn('sno', $companyIds->all())->get()->keyBy('sno');

        $general = $items->contains(fn ($item) => (int) ($item->company_id ?? 0) === 0)
            ? GeneralSettingsModel::query()->orderBy('sno')->first()
            : null;


        return response()->json([
            'success' => true,
            'data' => $items->map(function ($item) use ($companyMap, $general) {
                $companyId = (int) ($item->company_id ?? 0);
                $company = $companyId > 0 ? $companyMap->get($companyId) : null;

                if ($companyId === 0) {
                    $companyName = $item->company_name ?: ($general?->title ?: 'Main Company');
                    $companyLogo = $item->company_logo ?: ($general ? $this->generalFavIconUrl($general) : asset('assets/common/logo_small.png'));
                    $companyColor = $item->company_base_color ?: $general?->company_base_color;
                    $reviewLink = $item->google_review_link ?: ($general ? $this->resolveGoogleReviewLink($general, 'general') : null);
                } else {
                    $companyName = $item->company_name ?: ($company?->company_name ?: 'Company');
                    $companyLogo = $item->company_logo ?: ($company ? $this->companyLogoUrl($company) : asset('assets/common/logo_small.png'));
                    $companyColor = $item->company_base_color ?: $company?->company_base_color;
                    $reviewLink = $item->google_review_link ?: ($company ? $this->resolveGoogleReviewLink($company, 'company') : null);
                }

                return [
                    'id' => (int) $item->sno,
                    'iv_code' => $item->iv_code,
                    'iv_date' => Carbon::parse($item->iv_date)->format('d-M-Y'),
                    'iv_date_raw' => Carbon::parse($item->iv_date)->format('Y-m-d'),
                    'college_id' => $item->college_id ? (int) $item->college_id : null,
                    'college_name' => $item->college_name,
                    'company_id' => $companyId,
                    'company_name' => trim((string) $companyName),
                    'company_logo' => $companyLogo ?: asset('assets/common/logo_small.png'),
                    'company_base_color' => $this->safeColor($companyColor),
                    'google_review_link' => $reviewLink,
                    'qr_token' => $item->qr_token,
                    'qr_url' => route('hr-industrial-visit.scan', ['token' => $item->qr_token]),
                    'attendee_count' => (int) $item->attendee_count,
                ];
            })->values(),
            'pagination' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'iv_date' => ['required', 'date_format:Y-m-d'],
            'college_id' => ['required', 'integer', 'min:1'],
            'company_id' => ['required', 'integer', 'min:0'],
        ]);

        try {
            $collegeNameColumn = $this->collegeNameColumn();

            $collegeQuery = DB::table('egc_college')
                ->where('sno', (int) $validated['college_id']);

            $collegeColumns = Schema::getColumnListing('egc_college');
            if (in_array('status', $collegeColumns, true)) {
                $collegeQuery->where('status', 0);
            }

            $college = $collegeQuery->first(['sno', DB::raw("{$collegeNameColumn} as college_name")]);

            if (!$college) {
                return response()->json([
                    'success' => false,
                    'message' => 'Selected college is no longer active.',
                    'errors' => ['college_id' => ['Selected college is no longer active.']],
                ], 422);
            }

            $companyId = (int) $validated['company_id'];
            $company = null;
            $general = GeneralSettingsModel::query()->orderBy('sno')->first();

            if ($companyId > 0) {
                $company = CompanyModel::query()
                    ->where('sno', $companyId)
                    ->where('status', 0)
                    ->first();

                if (!$company) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Selected company is no longer active.',
                        'errors' => ['company_id' => ['Selected company is no longer active.']],
                    ], 422);
                }
            }

            $companyName = $company?->company_name ?: ($general?->title ?: 'Main Company');
            $companyLogo = $company
                ? $this->companyLogoUrl($company)
                : ($general ? $this->generalLogoUrl($general) : asset('assets/common/logo_small.png'));
            $companyBaseColor = $company
                ? $this->safeColor($company->company_base_color)
                : $this->safeColor($general?->company_base_color);
            $googleReviewLink = $company
                ? $this->resolveGoogleReviewLink($company, 'company')
                : $this->resolveGoogleReviewLink($general, 'general');

            $duplicate = IndustrialVisitModel::query()
                ->where('status', 0)
                ->whereDate('iv_date', $validated['iv_date'])
                ->where('college_id', (int) $college->sno)
                ->where(function ($q) use ($companyId) {
                    if ($companyId === 0) {
                        $q->where('company_id', 0)
                            ->orWhere(function ($legacy) {
                                $legacy->whereNull('company_id')
                                    ->whereNull('entity_company_id');
                            });
                    } else {
                        $q->where('company_id', $companyId)
                            ->orWhere(function ($legacy) use ($companyId) {
                                $legacy->whereNull('company_id')
                                    ->where('entity_company_id', $companyId);
                            });
                    }
                })
                ->exists();

            if ($duplicate) {
                return response()->json([
                    'success' => false,
                    'message' => 'An Industrial Visit already exists for this college, company and date.',
                ], 409);
            }

            $userId = (int) ($request->user()?->user_id ?? $request->user()?->id ?? 0);

            $visit = DB::transaction(function () use (
                $validated,
                $college,
                $companyId,
                $companyName,
                $companyLogo,
                $companyBaseColor,
                $googleReviewLink,
                $userId
            ) {
                return IndustrialVisitModel::create([
                    'iv_code' => $this->nextIvCode(),
                    'iv_date' => $validated['iv_date'],
                    'college_id' => (int) $college->sno,
                    'college_name' => trim((string) $college->college_name),
                    // New Company fields.
                    'company_id' => $companyId,
                    'company_name' => trim((string) $companyName),
                    'company_logo' => $companyLogo,
                    'company_base_color' => $companyBaseColor,
                    'google_review_link' => $googleReviewLink,
                    'qr_token' => hash('sha256', Str::random(100) . microtime(true)),
                    'status' => 0,
                    'created_by' => $userId,
                    'updated_by' => $userId,
                ]);
            });

            return response()->json([
                'success' => true,
                'message' => 'Industrial Visit created successfully.',
                'data' => [
                    'id' => $visit->sno,
                    'iv_code' => $visit->iv_code,
                    'iv_date' => Carbon::parse($visit->iv_date)->format('d-M-Y'),
                    'iv_date_raw' => Carbon::parse($visit->iv_date)->format('Y-m-d'),
                    'college_name' => $visit->college_name,
                    'company_id' => (int) $visit->company_id,
                    'company_name' => $visit->company_name,
                    'company_logo' => $visit->company_logo,
                    'company_base_color' => $visit->company_base_color,
                    'google_review_link' => $visit->google_review_link,
                    'qr_token' => $visit->qr_token,
                    'qr_url' => route('hr-industrial-visit.scan', ['token' => $visit->qr_token]),
                    'attendee_count' => 0,
                ],
            ], 201);
        } catch (Throwable $e) {
            Log::error('Industrial Visit creation failed.', [
                'exception' => $e,
                'user_id' => $request->user()?->user_id ?? $request->user()?->id,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Industrial Visit could not be created. Please try again.',
            ], 500);
        }
    }


    public function colleges(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'page' => ['nullable', 'integer', 'min:1'],
            'perpage' => ['nullable', 'integer', 'min:5', 'max:500'],
            'search' => ['nullable', 'string', 'max:150'],
            'status' => ['nullable', 'integer', Rule::in([0, 1])],
        ]);

        try {
            $nameColumn = $this->collegeNameColumn();
            $page = (int) ($validated['page'] ?? 1);
            $perpage = (int) ($validated['perpage'] ?? 25);
            $search = trim((string) ($validated['search'] ?? ''));

            $columns = Schema::getColumnListing('egc_college');
            if (!in_array('college_desc', $columns, true)) {
                throw new \RuntimeException('The college_desc column is missing from egc_college.');
            }

            $query = DB::table('egc_college')
                ->whereIn('status', [0, 1])
                ->select([
                    'sno',
                    DB::raw($nameColumn . ' as college_name'),
                    'college_desc',
                    'status',
                ])
                ->orderBy('status')
                ->orderBy($nameColumn);

            if ($search !== '') {
                $query->where(function ($q) use ($search, $nameColumn) {
                    $q->where($nameColumn, 'like', "%{$search}%")
                        ->orWhere('college_desc', 'like', "%{$search}%");
                });
            }

            if (array_key_exists('status', $validated) && $validated['status'] !== null) {
                $query->where('status', (int) $validated['status']);
            }

            $paginated = $query->paginate($perpage, ['*'], 'page', $page);

            return response()->json([
                'success' => true,
                'data' => collect($paginated->items())->map(fn ($item) => [
                    'id' => (int) $item->sno,
                    'college_name' => (string) $item->college_name,
                    'college_desc' => (string) ($item->college_desc ?? ''),
                    'status' => (int) $item->status,
                    'status_label' => (int) $item->status === 0 ? 'Active' : 'Inactive',
                ])->values(),
                'pagination' => [
                    'current_page' => $paginated->currentPage(),
                    'last_page' => $paginated->lastPage(),
                    'per_page' => $paginated->perPage(),
                    'total' => $paginated->total(),
                ],
            ]);
        } catch (Throwable $e) {
            Log::error('Industrial Visit college list loading failed.', [
                'exception' => $e,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'College list could not be loaded.',
            ], 500);
        }
    }

    public function storeCollege(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'college_name' => ['required', 'string', 'max:255'],
            'college_desc' => ['nullable', 'string', 'max:5000'],
        ]);

        try {
            $nameColumn = $this->collegeNameColumn();
            $columns = Schema::getColumnListing('egc_college');

            if (!in_array('college_desc', $columns, true)) {
                return response()->json([
                    'success' => false,
                    'message' => 'College description field is not available in the database.',
                ], 500);
            }

            $collegeName = trim($validated['college_name']);
            $collegeDesc = trim((string) ($validated['college_desc'] ?? ''));

            $duplicate = DB::table('egc_college')
                ->whereRaw('LOWER(' . $nameColumn . ') = ?', [mb_strtolower($collegeName)])
                ->exists();

            if ($duplicate) {
                return response()->json([
                    'success' => false,
                    'message' => 'A college with this name already exists.',
                    'errors' => ['college_name' => ['A college with this name already exists.']],
                ], 409);
            }

            $now = now();
            $userId = (int) ($request->user()?->user_id ?? $request->user()?->id ?? 0);
            $payload = [
                $nameColumn => $collegeName,
                'college_desc' => $collegeDesc !== '' ? $collegeDesc : null,
                'status' => 0,
            ];

            if (in_array('created_at', $columns, true)) {
                $payload['created_at'] = $now;
            }
            if (in_array('updated_at', $columns, true)) {
                $payload['updated_at'] = $now;
            }
            if (in_array('created_by', $columns, true)) {
                $payload['created_by'] = $userId;
            }
            if (in_array('updated_by', $columns, true)) {
                $payload['updated_by'] = $userId;
            }

            $id = DB::table('egc_college')->insertGetId($payload, 'sno');

            return response()->json([
                'success' => true,
                'message' => 'College added successfully.',
                'data' => [
                    'id' => (int) $id,
                    'college_name' => $collegeName,
                    'college_desc' => $collegeDesc,
                    'status' => 0,
                    'status_label' => 'Active',
                ],
            ], 201);
        } catch (Throwable $e) {
            Log::error('Industrial Visit college creation failed.', [
                'exception' => $e,
                'user_id' => $request->user()?->user_id ?? $request->user()?->id,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'College could not be added. Please try again.',
            ], 500);
        }
    }

    public function updateCollege(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'college_name' => ['required', 'string', 'max:255'],
            'college_desc' => ['nullable', 'string', 'max:5000'],
        ]);

        try {
            $nameColumn = $this->collegeNameColumn();
            $columns = Schema::getColumnListing('egc_college');

            if (!in_array('college_desc', $columns, true)) {
                return response()->json([
                    'success' => false,
                    'message' => 'College description field is not available in the database.',
                ], 500);
            }

            $college = DB::table('egc_college')
                ->where('sno', $id)
                ->first(['sno', $nameColumn, 'college_desc', 'status']);

            if (!$college) {
                return response()->json([
                    'success' => false,
                    'message' => 'College not found.',
                ], 404);
            }

            $collegeName = trim($validated['college_name']);
            $collegeDesc = trim((string) ($validated['college_desc'] ?? ''));

            $duplicate = DB::table('egc_college')
                ->whereRaw('LOWER(' . $nameColumn . ') = ?', [mb_strtolower($collegeName)])
                ->where('sno', '<>', $id)
                ->exists();

            if ($duplicate) {
                return response()->json([
                    'success' => false,
                    'message' => 'A college with this name already exists.',
                    'errors' => ['college_name' => ['A college with this name already exists.']],
                ], 409);
            }

            $now = now();
            $userId = (int) ($request->user()?->user_id ?? $request->user()?->id ?? 0);
            $payload = [
                $nameColumn => $collegeName,
                'college_desc' => $collegeDesc !== '' ? $collegeDesc : null,
            ];

            if (in_array('updated_at', $columns, true)) {
                $payload['updated_at'] = $now;
            }
            if (in_array('updated_by', $columns, true)) {
                $payload['updated_by'] = $userId;
            }

            DB::table('egc_college')->where('sno', $id)->update($payload);

            return response()->json([
                'success' => true,
                'message' => 'College updated successfully.',
                'data' => [
                    'id' => $id,
                    'college_name' => $collegeName,
                    'college_desc' => $collegeDesc,
                    'status' => (int) $college->status,
                    'status_label' => (int) $college->status === 0 ? 'Active' : 'Inactive',
                ],
            ]);
        } catch (Throwable $e) {
            Log::error('Industrial Visit college update failed.', [
                'college_id' => $id,
                'exception' => $e,
                'user_id' => $request->user()?->user_id ?? $request->user()?->id,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'College could not be updated. Please try again.',
            ], 500);
        }
    }

    public function toggleCollegeStatus(int $id): JsonResponse
    {
        try {
            $college = DB::table('egc_college')
                ->where('sno', $id)
                ->first(['sno', 'status']);

            if (!$college) {
                return response()->json([
                    'success' => false,
                    'message' => 'College not found.',
                ], 404);
            }

            if (!in_array((int) $college->status, [0, 1], true)) {
                return response()->json([
                    'success' => false,
                    'message' => 'This college has an unsupported status and cannot be toggled here.',
                ], 422);
            }

            $newStatus = (int) $college->status === 0 ? 1 : 0;
            $columns = Schema::getColumnListing('egc_college');
            $payload = ['status' => $newStatus];

            if (in_array('updated_at', $columns, true)) {
                $payload['updated_at'] = now();
            }
            if (in_array('updated_by', $columns, true)) {
                $userId = request()->user()?->user_id ?? request()->user()?->id ?? 0;
                $payload['updated_by'] = (int) $userId;
            }

            DB::table('egc_college')->where('sno', $id)->update($payload);

            return response()->json([
                'success' => true,
                'message' => $newStatus === 0 ? 'College activated successfully.' : 'College deactivated successfully.',
                'data' => [
                    'id' => $id,
                    'status' => $newStatus,
                    'status_label' => $newStatus === 0 ? 'Active' : 'Inactive',
                ],
            ]);
        } catch (Throwable $e) {
            Log::error('Industrial Visit college status update failed.', [
                'college_id' => $id,
                'exception' => $e,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'College status could not be updated. Please try again.',
            ], 500);
        }
    }

    public function attendees(int $id, Request $request): JsonResponse
    {
        $validated = $request->validate([
            'page' => ['nullable', 'integer', 'min:1'],
            'perpage' => ['nullable', 'integer', 'min:10', 'max:100'],
            'search' => ['nullable', 'string', 'max:150'],
        ]);

        $visit = IndustrialVisitModel::query()
            ->where('sno', $id)
            ->where('status', 0)
            ->first();

        if (!$visit) {
            return response()->json([
                'success' => false,
                'message' => 'Industrial Visit not found or inactive.',
            ], 404);
        }

        try {
            $companySnapshot = $this->resolveVisitCompanySnapshot($visit);

            $page = (int) ($validated['page'] ?? 1);
            $perpage = (int) ($validated['perpage'] ?? 50);
            $search = trim((string) ($validated['search'] ?? ''));

            $query = IndustrialVisitAttendeeModel::query()
                ->where('iv_sno', $visit->sno)
                ->where('status', 0)
                ->select([
                    'sno',
                    'student_name',
                    'gender',
                    'qualification_name',
                    'major_name',
                    'year_of_passing',
                    'address',
                    'mobile',
                    'email',
                    'state_id',
                    'state_name',
                    'city_id',
                    'city_name',
                    'field_of_interest',
                    'created_at',
                ])
                ->orderByDesc('sno');

            if ($search !== '') {
                $query->where(function ($q) use ($search) {
                    $q->where('student_name', 'like', "%{$search}%")
                        ->orWhere('mobile', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhere('qualification_name', 'like', "%{$search}%")
                        ->orWhere('major_name', 'like', "%{$search}%");
                });
            }

            $paginated = $query->paginate($perpage, ['*'], 'page', $page);

            $genderLabels = [1 => 'Male', 2 => 'Female', 3 => 'Others'];
            $genderSummary = DB::table('egc_industrial_visit_attendees')
                ->select('gender', DB::raw('COUNT(*) as total'))
                ->where('iv_sno', $visit->sno)
                ->where('status', 0)
                ->groupBy('gender')
                ->pluck('total', 'gender')
                ->map(fn ($value) => (int) $value);

            return response()->json([
                'success' => true,
                'data' => collect($paginated->items())->map(function ($item) use ($genderLabels) {
                    return [
                        'id' => (int) $item->sno,
                        'student_name' => $item->student_name,
                        'gender' => (int) $item->gender,
                        'gender_label' => $genderLabels[(int) $item->gender] ?? 'Others',
                        'qualification_name' => $item->qualification_name,
                        'major_name' => $item->major_name,
                        'year_of_passing' => (int) $item->year_of_passing,
                        'address' => $item->address,
                        'mobile' => $item->mobile,
                        'email' => $item->email,
                        'state_id' => $item->state_id ? (int) $item->state_id : null,
                        'state_name' => $item->state_name,
                        'city_id' => $item->city_id ? (int) $item->city_id : null,
                        'city_name' => $item->city_name,
                        'field_of_interest' => $item->field_of_interest ?: [],
                        'registered_at' => $item->created_at
                            ? Carbon::parse($item->created_at)->format('d-M-Y h:i A')
                            : null,
                    ];
                })->values(),
                'visit' => [
                    'id' => (int) $visit->sno,
                    'iv_code' => $visit->iv_code,
                    'iv_date' => Carbon::parse($visit->iv_date)->format('d-M-Y'),
                    'college_name' => $visit->college_name,
                    'company_id' => $companySnapshot['id'],
                    'company_name' => $companySnapshot['name'],
                    'company_logo' => $companySnapshot['logo'],
                    'company_base_color' => $companySnapshot['color'],
                ],
                'pagination' => [
                    'current_page' => $paginated->currentPage(),
                    'last_page' => $paginated->lastPage(),
                    'per_page' => $paginated->perPage(),
                    'total' => $paginated->total(),
                ],
                'gender_summary' => [
                    'male' => (int) ($genderSummary[1] ?? 0),
                    'female' => (int) ($genderSummary[2] ?? 0),
                    'others' => (int) ($genderSummary[3] ?? 0),
                ],
            ]);
        } catch (Throwable $e) {
            Log::error('Industrial Visit attendee list failed.', [
                'industrial_visit_id' => $id,
                'exception' => $e,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Attendee details could not be loaded.',
            ], 500);
        }
    }

    public function scanPage(string $token)
    {

         $visit = IndustrialVisitModel::query()
            ->where('qr_token', $token)
            ->where('status', 0)
            ->first();

        if (!$visit) {
            abort(419);
        }
        $iv_date = $visit->iv_date ? date('Y-m-d',strtotime( $visit->iv_date)) : null;

        if( $iv_date < date('Y-m-d')){
            abort(419);
        }

        return view('content.hr_management.hr_operation.industrial_visit.industrial_visit_scan', [
            'token' => $token,
        ]);
    }

    public function scanDetails(string $token): JsonResponse
    {
        $visit = IndustrialVisitModel::query()
            ->where('qr_token', $token)
            ->where('status', 0)
            ->first();

        if (!$visit) {
            return response()->json([
                'success' => false,
                'message' => 'This Industrial Visit QR code is invalid or inactive.',
            ], 404);
        }

        // The public Industrial Visit registration intentionally exposes only UG and PG.
        $qualifications = QualificationLevelModel::query()
            ->where('status', 0)
            ->get(['sno', 'qualification_level_name'])
            ->filter(function ($item) {
                return in_array(
                    strtoupper(trim((string) $item->qualification_level_name)),
                    ['UG', 'PG'],
                    true
                );
            })
            ->sortBy(function ($item) {
                return strtoupper(trim((string) $item->qualification_level_name)) === 'UG' ? 1 : 2;
            })
            ->map(fn ($item) => [
                'id' => (int) $item->sno,
                'name' => $item->qualification_level_name,
            ])
            ->values();

        $states = DB::table('egc_states')
            ->where('status', 0)
            ->select(['id', 'name'])
            ->orderByRaw("CASE WHEN LOWER(REPLACE(TRIM(name), ' ', '')) = 'tamilnadu' THEN 0 ELSE 1 END")
            ->orderBy('name')
            ->get()
            ->map(function ($item) {
                $name = trim((string) $item->name);
                $normalized = strtolower(preg_replace('/\s+/', '', $name));

                return [
                    'id' => (int) $item->id,
                    'name' => $name,
                    'is_default' => $normalized === 'tamilnadu',
                ];
            })
            ->values();

        $defaultState = $states->firstWhere('is_default', true);

        $companySnapshot = $this->resolveVisitCompanySnapshot($visit, true);

        return response()->json([
            'success' => true,
            'data' => [
                'iv_code' => $visit->iv_code,
                'iv_date' => Carbon::parse($visit->iv_date)->format('d-M-Y'),
                'iv_date_raw' => Carbon::parse($visit->iv_date)->format('Y-m-d'),
                'college_id' => $visit->college_id ? (int) $visit->college_id : null,
                'college_name' => $visit->college_name,
                'company_id' => $companySnapshot['id'],
                'company_name' => $companySnapshot['name'],
                'company_logo' => $companySnapshot['logo'],
                'company_base_color' => $companySnapshot['color'],
                'google_review_link' => $companySnapshot['google_review_link'],
                'qualifications' => $qualifications,
                'states' => $states,
                'default_state_id' => $defaultState ? (int) $defaultState['id'] : null,
            ],
        ]);
    }

    public function scanCities(int $stateId): JsonResponse
    {
        try {
            $state = DB::table('egc_states')
                ->where('id', $stateId)
                ->where('status', 0)
                ->first(['id', 'name']);

            if (!$state) {
                return response()->json([
                    'success' => false,
                    'message' => 'Selected state is not available.',
                    'data' => [],
                ], 404);
            }

            $cities = DB::table('egc_cities')
                ->where('state_id', $stateId)
                ->where('status', 0)
                ->orderBy('name')
                ->get(['id', 'name'])
                ->map(fn ($item) => [
                    'id' => (int) $item->id,
                    'name' => trim((string) $item->name),
                ])
                ->values();

            return response()->json([
                'success' => true,
                'data' => $cities,
            ]);
        } catch (Throwable $e) {
            Log::error('Industrial Visit city lookup failed.', [
                'state_id' => $stateId,
                'exception' => $e,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'City list could not be loaded.',
            ], 500);
        }
    }

    public function registerAttendee(Request $request, string $token): JsonResponse
    {
        $validated = $request->validate([
            'student_name' => ['required', 'string', 'max:255'],
            'gender' => ['required', 'integer', Rule::in([1, 2])],
            'qualification_id' => ['required', 'integer', 'min:1'],
            'major_id' => ['required', 'integer', 'min:1'],
            'year_of_passing' => ['required', 'integer', 'min:1950', 'max:' . (now()->year + 5)],
            'state_id' => ['required', 'integer', 'min:1'],
            'city_id' => ['required', 'integer', 'min:1'],
            'mobile' => ['required', 'digits:10'],
            'email' => ['nullable', 'email', 'max:255'],
        ]);

        try {

            $visit = IndustrialVisitModel::query()
                ->where('qr_token', $token)
                ->where('status', 0)
                ->lockForUpdate()
                ->first();

            if (!$visit) {
                return response()->json([
                    'success' => false,
                    'message' => 'This Industrial Visit is no longer active.',
                ], 404);
            }

            $qualification = QualificationLevelModel::query()
                ->where('sno', (int) $validated['qualification_id'])
                ->where('status', 0)
                ->first();

            if (!$qualification) {
                return response()->json([
                    'success' => false,
                    'message' => 'Selected degree is not available.',
                ], 422);
            }

            $qualificationName = strtoupper(trim((string) $qualification->qualification_level_name));
            if (!in_array($qualificationName, ['UG', 'PG'], true)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Only UG and PG qualifications are available for this registration.',
                    'errors' => ['qualification_id' => ['Please select UG or PG.']],
                ], 422);
            }

            $major = DB::table('egc_major')
                ->where('sno', (int) $validated['major_id'])
                ->where('qualification_id', (int) $validated['qualification_id'])
                ->where('status', 0)
                ->first(['sno', 'major_name']);

            if (!$major) {
                return response()->json([
                    'success' => false,
                    'message' => 'Selected major is not valid for the chosen degree.',
                    'errors' => ['major_id' => ['Selected major is not valid for the chosen degree.']],
                ], 422);
            }

            $state = DB::table('egc_states')
                ->where('id', (int) $validated['state_id'])
                ->where('status', 0)
                ->first(['id', 'name']);

            if (!$state) {
                return response()->json([
                    'success' => false,
                    'message' => 'Selected state is not available.',
                    'errors' => ['state_id' => ['Please select a valid state.']],
                ], 422);
            }

            $city = DB::table('egc_cities')
                ->where('id', (int) $validated['city_id'])
                ->where('state_id', (int) $state->id)
                ->where('status', 0)
                ->first(['id', 'name']);

            if (!$city) {
                return response()->json([
                    'success' => false,
                    'message' => 'Selected city is not valid for the chosen state.',
                    'errors' => ['city_id' => ['Please select a valid city.']],
                ], 422);
            }

            $duplicate = IndustrialVisitAttendeeModel::query()
                ->where('iv_sno', $visit->sno)
                ->where('mobile', $validated['mobile'])
                ->where('status', 0)
                ->exists();

            if ($duplicate) {
                return response()->json([
                    'success' => false,
                    'message' => 'This mobile number is already registered for this Industrial Visit.',
                ], 409);
            }

            $attendee = DB::transaction(function () use ($request, $validated, $visit, $qualification, $major, $state, $city) {
                return IndustrialVisitAttendeeModel::create([
                    'iv_sno' => (int) $visit->sno,
                    'college_id' => $visit->college_id,
                    'college_name' => $visit->college_name,
                    'iv_date' => $visit->iv_date,
                    'student_name' => trim($validated['student_name']),
                    'gender' => (int) $validated['gender'],
                    'qualification_id' => (int) $qualification->sno,
                    'qualification_name' => $qualification->qualification_level_name,
                    'major_id' => $major?->sno ? (int) $major->sno : null,
                    'major_name' => $major->major_name,
                    'year_of_passing' => (int) $validated['year_of_passing'],
                    // Legacy address column is intentionally left empty; public form now captures state/city.
                    'address' => null,
                    'state_id' => (int) $state->id,
                    'state_name' => trim((string) $state->name),
                    'city_id' => (int) $city->id,
                    'city_name' => trim((string) $city->name),
                    'mobile' => trim($validated['mobile']),
                    'email' => trim((string) ($validated['email'] ?? '')),
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->userAgent(),
                    'status' => 0,
                    'created_by' => 0,
                    'updated_by' => 0,
                ]);
            });

            return response()->json([
                'success' => true,
                'message' => 'Your Industrial Visit registration was submitted successfully.',
                'data' => [
                    'attendee_id' => (int) $attendee->sno,
                    'student_name' => $attendee->student_name,
                    'college_name' => $attendee->college_name,
                    'company_name' => $this->resolveVisitCompanySnapshot($visit)['name'],
                    // Always show the 3-second Thank You page first; it performs the final feedback redirect.
                    'redirect' => route('hr-industrial-visit.thank-you', [
                        'token' => $token,
                        'attendee' => $attendee->sno,
                    ]),
                ],
            ], 201);
        } catch (Throwable $e) {
            Log::error('Industrial Visit attendee registration failed.', [
                'token_prefix' => substr($token, 0, 10),
                'mobile' => $request->input('mobile'),
                'exception' => $e,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'We could not complete your registration. Please try again.',
            ], 500);
        }
    }

    public function thankYou(string $token, int $attendee)
    {
        $visit = IndustrialVisitModel::query()
            ->where('qr_token', $token)
            ->where('status', 0)
            ->firstOrFail();

        $attendeeRecord = IndustrialVisitAttendeeModel::query()
            ->where('sno', $attendee)
            ->where('iv_sno', $visit->sno)
            ->where('status', 0)
            ->firstOrFail();

        $companySnapshot = $this->resolveVisitCompanySnapshot($visit, true);

        return view('content.hr_management.hr_operation.industrial_visit.industrial_visit_thank_you', [
            'visit' => $visit,
            'attendee' => $attendeeRecord,
            'displayLogo' => $companySnapshot['logo'],
            'companySnapshot' => $companySnapshot,
        ]);
    }

    private function safeFeedbackRedirect(?string $url, string $fallback): string
    {
        $url = trim((string) $url);

        if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL)) {
            $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));

            if (in_array($scheme, ['http', 'https'], true)) {
                return $url;
            }
        }

        return $fallback;
    }

    private function nextIvCode(): string
    {
        do {
            $code = 'EGC-IV-' . now()->format('ymd') . '-' . strtoupper(Str::random(6));
        } while (IndustrialVisitModel::query()->where('iv_code', $code)->exists());

        return $code;
    }

    private function collegeNameColumn(): string
    {
        $columns = Schema::getColumnListing('egc_college');

        foreach (['college_name', 'name', 'college', 'college_title', 'institution_name'] as $candidate) {
            if (in_array($candidate, $columns, true)) {
                return $candidate;
            }
        }

        throw new \RuntimeException('No supported college name column was found in egc_college.');
    }

    private function generalFavIconUrl(?GeneralSettingsModel $general): string
    {
        if (!$general?->fav_icon) {
            return asset('assets/common/logo_small.png');
        }

        try {
            $helper = new \App\Helpers\Helpers();
            return $helper->Fav_Icon_pic($general->fav_icon) ?: asset('assets/common/logo_small.png');
        } catch (Throwable) {
            return asset('assets/common/logo_small.png');
        }
    }

    private function generalLogoUrl(?GeneralSettingsModel $general): string
    {
        if (!$general?->logo) {
            return asset('assets/common/logo_small.png');
        }

        try {
            $helper = new \App\Helpers\Helpers();
            return $helper->Logo_pic($general->logo) ?: asset('assets/common/logo_small.png');
        } catch (Throwable) {
            return asset('assets/common/logo_small.png');
        }
    }

    private function companyLogoUrl(?CompanyModel $company): string
    {
        if (!$company?->company_logo) {
            return asset('assets/common/logo_small.png');
        }

        $logo = trim((string) $company->company_logo);
        if ($logo === '') {
            return asset('assets/common/logo_small.png');
        }

        if (filter_var($logo, FILTER_VALIDATE_URL)) {
            return $logo;
        }

        if (str_starts_with($logo, '/')) {
            return asset(ltrim($logo, '/'));
        }

        if (str_starts_with($logo, 'Company_logos/')) {
            return asset($logo);
        }

        if (str_contains($logo, '/')) {
            return asset(ltrim($logo, '/'));
        }

        return asset('Company_logos/' . ltrim($logo, '/'));
    }

    private function resolveVisitCompanySnapshot(IndustrialVisitModel $visit, bool $public = false): array
    {
        $companyId = $visit->company_id !== null
            ? (int) $visit->company_id
            : ($visit->entity_company_id !== null
                ? (int) $visit->entity_company_id
                : ((int) ($visit->entity_id ?? 0) === 0 ? 0 : null));

        if ($companyId === null) {
            return [
                'id' => null,
                'name' => trim((string) ($visit->company_name ?: $visit->entity_name ?: 'Company')),
                'logo' => $visit->company_logo ?: ($visit->entity_logo ?: asset('assets/common/logo_small.png')),
                'color' => $this->safeColor($visit->company_base_color ?: $visit->entity_base_color),
                'google_review_link' => $visit->google_review_link ?: null,
            ];
        }

        if ($companyId === 0) {
            $general = GeneralSettingsModel::query()->orderBy('sno')->first();
            $logo = $visit->company_logo ?: ($general ? $this->generalLogoUrl($general) : asset('assets/common/logo_small.png'));
            if ($public && $general) {
                $logo = $this->generalFavIconUrl($general);
            }

            return [
                'id' => 0,
                'name' => trim((string) ($visit->company_name ?: $visit->entity_name ?: ($general?->title ?: 'Main Company'))),
                'logo' => $logo ?: asset('assets/common/logo_small.png'),
                'color' => $this->safeColor($visit->company_base_color ?: $general?->company_base_color),
                'google_review_link' => $visit->google_review_link ?: $this->resolveGoogleReviewLink($general, 'general'),
            ];
        }

        $company = CompanyModel::query()->where('sno', $companyId)->first();

        return [
            'id' => $companyId,
            'name' => trim((string) ($visit->company_name ?: $company?->company_name ?: $visit->entity_name ?: 'Company')),
            'logo' => $visit->company_logo ?: ($company ? $this->companyLogoUrl($company) : ($visit->entity_logo ?: asset('assets/common/logo_small.png'))),
            'color' => $this->safeColor($visit->company_base_color ?: ($company?->company_base_color ?: $visit->entity_base_color)),
            'google_review_link' => $visit->google_review_link ?: ($company ? $this->resolveGoogleReviewLink($company, 'company') : null),
        ];
    }

    private function safeColor(?string $color): string
    {
        $color = trim((string) $color);
        return preg_match('/^#[0-9a-fA-F]{3,8}$/', $color) ? $color : '#ab2b22';
    }

    private function resolveGoogleReviewLink($row, string $source): ?string
    {
        if (!$row) {
            return null;
        }

        $directFields = [
            'google_review_link',
            'google_review_url',
            'google_reviews_link',
            'google_reviews_url',
            'review_link',
            'review_url',
        ];

        try {
            $columns = Schema::getColumnListing($source === 'company' ? 'egc_company' : 'egc_general_settings');

            foreach ($directFields as $field) {
                if (in_array($field, $columns, true) && !empty($row->{$field})) {
                    return trim((string) $row->{$field});
                }
            }
        } catch (Throwable) {
            // Fall through to social_media_details resolution.
        }

        $socialDetails = $row->social_media_details ?? null;
        if (is_string($socialDetails)) {
            $decoded = json_decode($socialDetails, true);
            $socialDetails = json_last_error() === JSON_ERROR_NONE ? $decoded : null;
        }

        if (is_array($socialDetails)) {
            foreach ($socialDetails as $key => $value) {
                if (!is_scalar($value) || trim((string) $value) === '') {
                    continue;
                }

                $keyString = strtolower((string) $key);
                if (str_contains($keyString, 'google') && str_contains($keyString, 'review')) {
                    return trim((string) $value);
                }
            }

            try {
                $googleNames = SocialMediaModel::query()
                    ->where('status', 0)
                    ->where(function ($q) {
                        $q->whereRaw('LOWER(social_media_name) LIKE ?', ['%google%'])
                            ->orWhereRaw('LOWER(social_media_name) LIKE ?', ['%review%']);
                    })
                    ->get(['sno', 'social_media_name']);

                foreach ($googleNames as $social) {
                    $value = $socialDetails[(string) $social->sno] ?? $socialDetails[$social->sno] ?? null;
                    if (is_scalar($value) && trim((string) $value) !== '') {
                        return trim((string) $value);
                    }
                }
            } catch (Throwable) {
                // Optional social-media lookup; do not fail an IV creation.
            }
        }

        return null;
    }
}
