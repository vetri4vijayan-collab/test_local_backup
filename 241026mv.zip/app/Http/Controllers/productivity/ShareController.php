<?php

namespace App\Http\Controllers\productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ShareController extends ProductivityBaseController
{
    public function data(Request $request)
    {
        $data = $request->validate([
            'resource_type' => ['required', 'string', 'max:80'],
            'resource_id' => ['required', 'integer', 'min:1'],
        ]);

        $meta = $this->resourceMeta($data['resource_type'], (int) $data['resource_id']);
        abort_unless($meta && $this->access->canReadResource(
            $data['resource_type'],
            (int) $data['resource_id'],
            $meta['owner_user_id'],
            $meta['company_id'],
            $meta['visibility']
        ), 403);

        return $this->ok(
            DB::table('egc_tool_share_grants')
                ->where('resource_type', $data['resource_type'])
                ->where('resource_id', $data['resource_id'])
                ->whereIn('status', ['active', 'pending'])
                ->orderByDesc('created_at')
                ->get()
        );
    }

    public function store(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);

        $data = $request->validate([
            'resource_type' => ['required', 'string', 'max:80'],
            'resource_id' => ['required', 'integer', 'min:1'],
            'grantee_type' => ['required', 'in:user,role,company,group'],
            'grantee_id' => ['required'],
            'permission' => ['required', 'in:View,Manage'],
            'expires_at' => ['nullable', 'date', 'after:now'],
        ]);

        $meta = $this->resourceMeta($data['resource_type'], (int) $data['resource_id']);
        abort_unless($meta, 404, 'Resource not found.');
        abort_unless($this->access->canManageResource(
            $data['resource_type'],
            (int) $data['resource_id'],
            $meta['owner_user_id']
        ), 403, 'You do not have permission to share this resource.');

        abort_unless($data['resource_type'] !== 'money', 422, 'My Money records are private and cannot be shared.');

        /*
         * BookMarks uses a different, explicit sharing model from the other
         * productivity modules:
         *
         *  - Person      = exactly one staff member (user grant)
         *  - Companies   = one or more companies (company grants); every active
         *                  staff member belonging to those companies is eligible
         *  - Staff group = one or more selected staff members (user grants)
         *
         * Role and whole-group grants are intentionally not created for boards.
         * The existing role/group support below remains unchanged for the other
         * productivity resources.
         */
        if ($data['resource_type'] === 'board') {
            abort_unless(
                in_array($data['grantee_type'], ['user', 'company'], true),
                422,
                'BookMarks boards can be shared only with people or companies.'
            );

            $rawIds = is_array($data['grantee_id']) ? $data['grantee_id'] : [$data['grantee_id']];
            $granteeIds = array_values(array_unique(array_filter(array_map(
                static function ($id) {
                    return trim((string) $id);
                },
                $rawIds
            ), static function ($id) {
                return $id !== '';
            })));

            abort_unless($granteeIds, 422, $data['grantee_type'] === 'company'
                ? 'Select at least one company.'
                : 'Select at least one staff member.');

            if ($data['grantee_type'] === 'user') {
                abort_unless(
                    !array_filter($granteeIds, static fn ($id) => !ctype_digit($id) || (int) $id < 1),
                    422,
                    'One or more selected staff identifiers are invalid.'
                );

                // A single user grant is the Person flow. Multiple user IDs are
                // the Staff group flow from the BookMarks UI.
                if (count($granteeIds) > 500) {
                    abort(422, 'You can share a board with up to 500 staff members at once.');
                }

                $valid = DB::table('egc_staff')
                    ->whereIn('sno', array_map('intval', $granteeIds))
                    ->where('status', '!=', 2)
                    ->count();

                abort_unless(
                    (int) $valid === count($granteeIds),
                    422,
                    'One or more selected staff members are not active.'
                );
            } else {
                abort_unless(
                    !array_filter($granteeIds, static fn ($id) => !ctype_digit($id) || (int) $id < 0),
                    422,
                    'One or more selected company identifiers are invalid.'
                );

                if (count($granteeIds) > 100) {
                    abort(422, 'You can share a board with up to 100 companies at once.');
                }

                $companyIds = array_map('intval', $granteeIds);
                $positiveCompanyIds = array_values(array_filter($companyIds, static fn ($id) => $id > 0));
                $validPositive = $positiveCompanyIds
                    ? DB::table('egc_company')
                        ->whereIn('sno', $positiveCompanyIds)
                        ->where('status', 0)
                        ->count()
                    : 0;

                // Company 0 is the ERP main organisation and is represented by
                // the general settings title rather than a physical company row.
                $validMainCompany = in_array(0, $companyIds, true) ? 1 : 0;
                abort_unless(
                    (int) $validPositive + $validMainCompany === count($companyIds),
                    422,
                    'One or more selected companies are not active.'
                );
            }

            $duplicates = DB::table('egc_tool_share_grants')
                ->where('resource_type', 'board')
                ->where('resource_id', (int) $data['resource_id'])
                ->where('grantee_type', $data['grantee_type'])
                ->whereIn('grantee_id', $granteeIds)
                ->whereIn('status', ['active', 'pending'])
                ->pluck('grantee_id')
                ->map(fn ($id) => (string) $id)
                ->values()
                ->all();

            abort_if(
                $duplicates,
                409,
                count($duplicates) === 1
                    ? 'This board is already shared with the selected recipient.'
                    : 'This board is already shared with one or more selected recipients.'
            );

            $grantIds = [];
            $actorId = $this->uid();
            $expiresAt = $data['expires_at'] ?? null;

            DB::transaction(function () use (
                $data,
                $granteeIds,
                $actorId,
                $expiresAt,
                &$grantIds
            ) {
                foreach ($granteeIds as $granteeId) {
                    $grantIds[] = DB::table('egc_tool_share_grants')->insertGetId([
                        'resource_type' => 'board',
                        'resource_id' => (int) $data['resource_id'],
                        'owner_user_id' => $actorId,
                        'grantee_type' => $data['grantee_type'],
                        'grantee_id' => (string) $granteeId,
                        'permission' => $data['permission'],
                        'status' => 'active',
                        'expires_at' => $expiresAt,
                        'requested_by' => $actorId,
                        'approved_by' => $actorId,
                        'approval_required' => 0,
                        'approved_at' => now(),
                        'metadata_json' => json_encode([
                            'source' => 'bookmarks_share_board',
                        ], JSON_UNESCAPED_UNICODE),
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);

                    DB::table('egc_tool_board_shares')->insert([
                        'board_id' => (int) $data['resource_id'],
                        'owner_user_id' => $actorId,
                        'user_id' => $data['grantee_type'] === 'user' ? (int) $granteeId : null,
                        'grantee_type' => $data['grantee_type'],
                        'grantee_id' => (string) $granteeId,
                        'permission' => $data['permission'],
                        'status' => 'active',
                        'expires_at' => $expiresAt,
                        'requested_by' => $actorId,
                        'approved_by' => $actorId,
                        'approved_at' => now(),
                        'created_by' => $actorId,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            });

            // Keep the existing notification behavior for direct staff shares.
            // Company shares intentionally do not fan out thousands of
            // notifications; the company grant makes the staff eligible on read.
            if ($data['grantee_type'] === 'user') {
                foreach ($granteeIds as $granteeId) {
                    DB::table('egc_tool_productivity_notifications')->insert([
                        'user_id' => (int) $granteeId,
                        'company_id' => $meta['company_id'] ?? null,
                        'module_name' => 'Sharing',
                        'notification_type' => 'share',
                        'title' => 'A board was shared with you',
                        'message' => 'Board #' . (int) $data['resource_id'] . ' was shared with you with ' . $data['permission'] . ' access.',
                        'resource_type' => 'board',
                        'resource_id' => (int) $data['resource_id'],
                        'action_url' => url('/productivity/bookmarks'),
                        'icon' => 'share-variant-outline',
                        'icon_color' => '#4A3E8E',
                        'is_read' => 0,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            }

            $this->audit(
                $request,
                'BookMarks',
                'board_share_created',
                'board',
                (int) $data['resource_id'],
                null,
                null,
                [
                    'grant_ids' => $grantIds,
                    'grantee_type' => $data['grantee_type'],
                    'grantee_ids' => $granteeIds,
                    'permission' => $data['permission'],
                    'expires_at' => $expiresAt,
                ]
            );

            $recipientCount = count($granteeIds);
            $recipientLabel = $data['grantee_type'] === 'company'
                ? ($recipientCount === 1 ? 'company' : 'companies')
                : ($recipientCount === 1 ? 'staff member' : 'staff members');

            return $this->ok(
                [
                    'ids' => $grantIds,
                    'grantee_type' => $data['grantee_type'],
                    'grantee_ids' => $granteeIds,
                    'count' => $recipientCount,
                ],
                'Board shared with ' . $recipientCount . ' ' . $recipientLabel . '.'
            );
        }

        // Generic sharing behavior for non-BookMarks resources remains unchanged.
        abort_unless(is_string($data['grantee_id']) || is_int($data['grantee_id']), 422, 'Invalid recipient.');
        $data['grantee_id'] = (string) $data['grantee_id'];

        if ($data['resource_type'] === 'vault' && (int) session('egc_tool_stepup_until', 0) < now()->timestamp) {
            $request->validate(['stepup_password' => ['required', 'string', 'max:255']]);
            $user = $request->user();
            abort_unless($user && !empty($user->password) && Hash::check($request->input('stepup_password'), $user->password), 403, 'Invalid step-up credential.');
            session(['egc_tool_stepup_until' => now()->addMinutes(5)->timestamp]);
        }

        $crossCompany = false;
        if ($data['grantee_type'] === 'company') {
            $crossCompany = (int) $data['grantee_id'] !== (int) ($meta['company_id'] ?? -1);
        } elseif ($data['grantee_type'] === 'group') {
            $crossCompany = true;
        }

        if ($data['grantee_type'] === 'user') {
            abort_unless(
                DB::table('egc_staff')->where('sno', (int) $data['grantee_id'])->where('status', '!=', 2)->exists(),
                422,
                'Selected user is not active.'
            );
        }

        if ($data['grantee_type'] === 'company') {
            abort_unless(
                DB::table('egc_company')->where('sno', (int) $data['grantee_id'])->where('status', 0)->exists(),
                422,
                'Selected company is not active.'
            );
        }

        if ($data['grantee_type'] === 'role') {
            abort_unless(
                in_array($data['grantee_id'], ['Super Admin', 'Group Admin', 'Company Admin', 'Module Manager', 'Staff', 'Auditor'], true),
                422,
                'Invalid recipient role.'
            );
        }

        $duplicate = DB::table('egc_tool_share_grants')
            ->where('resource_type', $data['resource_type'])
            ->where('resource_id', $data['resource_id'])
            ->where('grantee_type', $data['grantee_type'])
            ->where('grantee_id', $data['grantee_id'])
            ->whereIn('status', ['active', 'pending'])
            ->exists();

        abort_if($duplicate, 409, 'This resource is already shared with the selected recipient.');

        $status = 'active';
        if ($crossCompany) {
            $status = $data['resource_type'] === 'vault'
                ? ($this->access->isSuper() ? 'active' : 'pending')
                : ($this->access->isGroupAdmin() ? 'active' : 'pending');
        }

        $id = DB::table('egc_tool_share_grants')->insertGetId([
            'resource_type' => $data['resource_type'],
            'resource_id' => $data['resource_id'],
            'owner_user_id' => $this->uid(),
            'grantee_type' => $data['grantee_type'],
            'grantee_id' => $data['grantee_id'],
            'permission' => $data['permission'],
            'status' => $status,
            'expires_at' => $data['expires_at'] ?? null,
            'requested_by' => $this->uid(),
            'approved_by' => $status === 'active' ? $this->uid() : null,
            'approved_at' => $status === 'active' ? now() : null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // In-app notification to the recipient for direct user grants.
        if ($status === 'active' && $data['grantee_type'] === 'user') {
            DB::table('egc_tool_productivity_notifications')->insert([
                'user_id' => (int) $data['grantee_id'],
                'company_id' => $meta['company_id'] ?? null,
                'module_name' => 'Sharing',
                'notification_type' => 'share',
                'title' => 'A resource was shared with you',
                'message' => ucfirst($data['resource_type']).' #'.(int) $data['resource_id'].' was shared with you with '.$data['permission'].' access.',
                'resource_type' => $data['resource_type'],
                'resource_id' => (int) $data['resource_id'],
                'action_url' => url('/productivity/'.$data['resource_type'].'/'.(int) $data['resource_id']),
                'icon' => 'share-variant-outline',
                'icon_color' => '#4A3E8E',
                'is_read' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        // Board shares have a dedicated table because the board canvas needs fast permission checks.
        if ($data['resource_type'] === 'board') {
            DB::table('egc_tool_board_shares')->insert([
                'board_id' => $data['resource_id'],
                'owner_user_id' => $this->uid(),
                'grantee_type' => $data['grantee_type'],
                'grantee_id' => $data['grantee_id'],
                'permission' => $data['permission'],
                'status' => $status === 'active' ? 'active' : 'pending',
                'expires_at' => $data['expires_at'] ?? null,
                'requested_by' => $this->uid(),
                'approved_by' => $status === 'active' ? $this->uid() : null,
                'approved_at' => $status === 'active' ? now() : null,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $this->audit(
            $request,
            'Admin',
            'share_created',
            $data['resource_type'],
            (int) $data['resource_id'],
            null,
            null,
            ['grant_id' => $id, 'grantee_type' => $data['grantee_type'], 'permission' => $data['permission'], 'status' => $status],
            $data['resource_type'] === 'vault'
        );

        return $this->ok(
            ['id' => $id, 'status' => $status],
            $status === 'pending' ? 'Share request sent for Group Admin approval.' : 'Resource shared successfully.'
        );
    }

    public function pending(Request $request)
    {
        abort_unless($this->access->isGroupAdmin() || $this->access->isSuper(), 403);

        $query = DB::table('egc_tool_share_grants')
            ->where('status', 'pending')
            ->orderByDesc('created_at');

        // Vault approvals are intentionally restricted to Super Admins.
        if (! $this->access->isSuper()) {
            $query->where('resource_type', '!=', 'vault');
        }

        return $this->ok($query->limit(100)->get());
    }

    public function approve(Request $request, $id)
    {
        $grant = DB::table('egc_tool_share_grants')->where('sno', $id)->where('status', 'pending')->first();
        abort_unless($grant, 404, 'Share request not found.');
        abort_unless($grant->resource_type === 'vault' ? $this->access->isSuper() : $this->access->isGroupAdmin(), 403);

        DB::transaction(function () use ($grant) {
            DB::table('egc_tool_share_grants')->where('sno', $grant->sno)->update([
                'status' => 'active',
                'approved_by' => $this->uid(),
                'approved_at' => now(),
                'updated_at' => now(),
            ]);

            if ($grant->resource_type === 'board') {
                DB::table('egc_tool_board_shares')
                    ->where('board_id', $grant->resource_id)
                    ->where('grantee_type', $grant->grantee_type)
                    ->where('grantee_id', $grant->grantee_id)
                    ->where('status', 'pending')
                    ->update([
                        'status' => 'active',
                        'approved_by' => $this->uid(),
                        'approved_at' => now(),
                        'updated_at' => now(),
                    ]);
            }
        });

        $this->audit($request, 'Admin', 'share_approved', $grant->resource_type, (int) $grant->resource_id, null, null, ['grant_id' => $id]);

        return $this->ok(null, 'Share approved successfully.');
    }

    public function revoke(Request $request, $id)
    {
        $grant = DB::table('egc_tool_share_grants')->where('sno', $id)->first();
        abort_unless($grant, 404, 'Share grant not found.');
        abort_unless($this->access->isGroupAdmin() || (int) $grant->owner_user_id === $this->uid(), 403);

        DB::transaction(function () use ($grant, $id) {
            DB::table('egc_tool_share_grants')->where('sno', $id)->update([
                'status' => 'revoked',
                'updated_at' => now(),
            ]);

            if ($grant->resource_type === 'board') {
                DB::table('egc_tool_board_shares')
                    ->where('board_id', $grant->resource_id)
                    ->where('grantee_type', $grant->grantee_type)
                    ->where('grantee_id', $grant->grantee_id)
                    ->whereIn('status', ['active', 'pending'])
                    ->update(['status' => 'revoked', 'updated_at' => now()]);
            }
        });

        $this->audit($request, 'Admin', 'share_revoked', $grant->resource_type, (int) $grant->resource_id, null, null, ['grant_id' => $id], $grant->resource_type === 'vault');

        return $this->ok(null, 'Share revoked successfully.');
    }

    private function resourceMeta(string $type, int $id): ?array
    {
        $map = [
            'contact' => ['table' => 'egc_tool_contacts', 'owner' => 'owner_user_id'],
            'board' => ['table' => 'egc_tool_boards', 'owner' => 'owner_user_id'],
            'bookmark' => ['table' => 'egc_tool_bookmarks', 'owner' => 'owner_user_id'],
            'vault' => ['table' => 'egc_tool_vault_entries', 'owner' => 'owner_user_id'],
            'knowledge' => ['table' => 'egc_tool_knowledge_posts', 'owner' => 'author_user_id'],
            'portal' => ['table' => 'egc_tool_portal_apps', 'owner' => 'created_by'],
            'meeting' => ['table' => 'egc_tool_meetings', 'owner' => 'owner_user_id'],
            'task' => ['table' => 'egc_tool_tasks', 'owner' => 'owner_user_id'],
            'note' => ['table' => 'egc_tool_sticky_notes', 'owner' => 'owner_user_id'],
            'document' => ['table' => 'egc_tool_documents', 'owner' => 'owner_user_id'],
            'event' => ['table' => 'egc_tool_events', 'owner' => 'owner_user_id'],
        ];

        if (!isset($map[$type]) || !DB::getSchemaBuilder()->hasTable($map[$type]['table'])) {
            return null;
        }

        $row = DB::table($map[$type]['table'])->where('sno', $id)->first();
        if (!$row) {
            return null;
        }

        return [
            'owner_user_id' => isset($row->{$map[$type]['owner']}) ? (int) $row->{$map[$type]['owner']} : null,
            'company_id' => isset($row->company_id) ? (int) $row->company_id : null,
            'visibility' => $row->visibility ?? ($type === 'knowledge' ? ($row->audience_scope === 'Group' ? 'Group' : 'Company') : null),
        ];
    }
}
