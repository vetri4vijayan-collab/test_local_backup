<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\VaultEntry;
use App\Services\Productivity\ProductivityAccessService;
use App\Services\Productivity\ProductivityCryptoService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class PassWalletController extends ProductivityBaseController
{
    private const TYPES = [
        ['value' => 'Website', 'label' => 'Website', 'icon' => 'mdi-web', 'description' => 'Browser-based services and websites.'],
        ['value' => 'System', 'label' => 'System', 'icon' => 'mdi-server-outline', 'description' => 'Servers, operating systems and infrastructure.'],
        ['value' => 'Application', 'label' => 'Application', 'icon' => 'mdi-apps', 'description' => 'Desktop and web applications.'],
        ['value' => 'Mobile App', 'label' => 'Mobile App', 'icon' => 'mdi-cellphone-outline', 'description' => 'Mobile applications and device credentials.'],
    ];

    public function __construct(
        ProductivityAccessService $access,
        private readonly ProductivityCryptoService $crypto,
    ) {
        parent::__construct($access);
    }

    public function index()
    {
        return view('content.productivity.passwallet.index');
    }

    public function options(Request $request): JsonResponse
    {
        $generalTitle = trim((string) (DB::table('egc_general_settings')->where('sno', 1)->value('title') ?? 'Elysium Groups'));

        return $this->ok([
            'types' => self::TYPES,
            'scope_modes' => [
                ['value' => 'private', 'label' => 'Private', 'icon' => 'mdi-lock-outline', 'hint' => 'Only you can access this credential.'],
                ['value' => 'company', 'label' => 'Company', 'icon' => 'mdi-office-building-outline', 'hint' => 'Everyone matching the selected companies will have access.'],
                ['value' => 'entity', 'label' => 'Entity', 'icon' => 'mdi-domain', 'hint' => 'Everyone belonging to the selected entities will have access.'],
                ['value' => 'role', 'label' => 'Role', 'icon' => 'mdi-account-badge-outline', 'hint' => 'Users with the selected roles inside the selected entities will have access.'],
                ['value' => 'staff', 'label' => 'Staff', 'icon' => 'mdi-account-multiple-outline', 'hint' => 'Only the selected staff members will have access.'],
            ],
            'general' => ['value' => 0, 'label' => $generalTitle],
        ]);
    }

    /**
     * Dynamic audience options. This mirrors the Knowledge Panel audience API
     * so the same Company -> Entity -> Role/Staff dependency model is used.
     */
    public function audienceOptions(Request $r): JsonResponse
    {
        $mode = strtolower((string) $r->input('mode', 'company'));
        abort_unless(in_array($mode, ['private', 'company', 'entity', 'role', 'staff'], true), 422, 'Invalid audience type.');

        $generalTitle = trim((string) (DB::table('egc_general_settings')->where('sno', 1)->value('title') ?? 'General'));
        $groupAdmin = $this->access->isGroupAdmin($r);
        $companyId = $this->cid();

        if ($mode === 'private') {
            return $this->ok([
                'mode' => 'private',
                'general' => ['value' => 0, 'label' => $generalTitle],
                'items' => [],
            ]);
        }

        $selectedEntityIds = $this->normalizeAudienceValue($r->input('entity_ids', []), true);

        if ($mode === 'company') {
            $query = DB::table('egc_company')
                ->where('status', 0)
                ->select(['sno', 'company_name', 'company_short_name', 'company_base_color'])
                ->orderBy('company_name');

            if (!$groupAdmin && $companyId !== null) {
                $query->where('sno', $companyId);
            }

            return $this->ok([
                'mode' => 'company',
                'general' => ['value' => 0, 'label' => $generalTitle],
                'all' => ['value' => 'all', 'label' => 'All companies'],
                'items' => $query->get(),
            ]);
        }

        $entityQuery = DB::table('egc_entity as e')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'e.company_id')
            ->where('e.status', 0)
            ->select([
                'e.sno',
                'e.company_id',
                'e.entity_name',
                'e.entity_short_name',
                'c.company_name',
            ])
            ->orderBy('e.entity_name');

        if (!$groupAdmin && $companyId !== null) {
            $entityQuery->where('e.company_id', $companyId);
        }

        $entities = $entityQuery->get();

        if ($mode === 'entity') {
            return $this->ok([
                'mode' => 'entity',
                'general' => ['value' => 0, 'label' => $generalTitle],
                'all' => ['value' => 'all', 'label' => 'All entities'],
                'items' => $entities,
            ]);
        }

        $entityIds = array_values(array_filter($selectedEntityIds, static fn ($v) => $v !== 'all'));
        if (in_array('all', $selectedEntityIds, true)) {
            $entityIds = $entities->pluck('sno')->map(fn ($v) => (int) $v)->all();
            $entityIds[] = 0;
        }

        if (!$entityIds) {
            return $this->ok([
                'mode' => $mode,
                'items' => [],
                'entities' => [
                    'general' => ['value' => 0, 'label' => $generalTitle],
                    'all' => ['value' => 'all', 'label' => 'All entities'],
                    'items' => $entities,
                ],
            ]);
        }

        if ($mode === 'role') {
            $roleQuery = DB::table('egc_user_role as ur')
                ->where('ur.status', 0)
                ->leftJoin('egc_entity as entity', 'entity.sno', '=', 'ur.entity_id')
                ->select(['ur.sno', 'ur.entity_id', 'entity.entity_name', 'ur.role_name', 'ur.company_id'])
                ->orderBy('ur.role_name');

            if (!in_array(0, $entityIds, true) || count($entityIds) > 1) {
                $roleQuery->whereIn('ur.entity_id', $entityIds);
            } else {
                $roleQuery->where('ur.entity_id', 0);
            }

            $roles = $roleQuery->get();

            return $this->ok([
                'mode' => 'role',
                'items' => $roles,
                'entities' => [
                    'general' => ['value' => 0, 'label' => $generalTitle],
                    'all' => ['value' => 'all', 'label' => 'All entities'],
                    'items' => $entities,
                ],
                'all_roles' => ['value' => 'all', 'label' => 'All roles'],
            ]);
        }

        $staffQuery = DB::table('egc_staff as s')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 's.entity_id')
            ->leftJoin('egc_company as c', 'c.sno', '=', 's.company_id')
            ->where('s.status', 0)
            ->where('s.sno', '>', 0)
            ->select([
                's.sno',
                's.staff_name',
                's.staff_id',
                's.email_id',
                's.role_id',
                's.entity_id',
                's.company_id',
                'e.entity_name',
                'c.company_name',
            ])
            ->orderBy('s.staff_name');

        if (!$groupAdmin && $companyId !== null) {
            $staffQuery->where('s.company_id', $companyId);
        }
        if (!in_array(0, $entityIds, true) || count($entityIds) > 1) {
            $staffQuery->whereIn('s.entity_id', $entityIds);
        } else {
            $staffQuery->where('s.entity_id', 0);
        }

        return $this->ok([
            'mode' => 'staff',
            'items' => $staffQuery->get(),
            'entities' => [
                'general' => ['value' => 0, 'label' => $generalTitle],
                'all' => ['value' => 'all', 'label' => 'All entities'],
                'items' => $entities,
            ],
        ]);
    }

    public function data(Request $request): JsonResponse
    {
        /*
         * VaultEntry uses SoftDeletes. Because this query deliberately aliases
         * the table as "v", the model SoftDeletingScope would qualify the
         * original table name and produce an invalid mixed-alias condition.
         * Follow the Knowledge Panel pattern: bypass global scopes only for
         * this aliased read and keep the soft-delete condition explicitly.
         */
        $query = VaultEntry::withoutGlobalScopes()
            ->from('egc_tool_vault_entries as v')
            ->leftJoin('egc_company as co', function ($join) {
                $join->on('co.sno', '=', 'v.company_id')->where('co.status', 0);
            })
            ->where('v.status', 0)
            ->whereNull('v.deleted_at')
            ->select([
                'v.*',
                DB::raw("COALESCE(co.company_name, 'Group') as company_name"),
            ]);

        // The readable audience scope remains the single authorization source.
        $this->applyPassWalletReadableQueryScope($query, $request, 'v');

        $query
            ->when($request->filled('entry_type'), fn ($q) => $q->where('v.entry_type', $request->string('entry_type')->toString()));

        if ($request->filled('search')) {
            $search = trim((string) $request->input('search'));
            $query->where(function ($q) use ($search) {
                $like = '%' . $search . '%';
                $q->where('v.entry_name', 'like', $like)
                    ->orWhere('v.username', 'like', $like)
                    ->orWhere('v.email', 'like', $like)
                    ->orWhere('v.mobile', 'like', $like)
                    ->orWhere('v.url', 'like', $like);
            });
        }

        /*
         * Calculate Mine / Shared / Company counts before applying the current
         * tab filter. Otherwise every count becomes an intersection of the
         * currently selected tab.
         */
        $tabCountBase = clone $query;
        $currentUserId = $this->uid();
        $companyId = $this->cid();

        $tabCounts = [
            'mine' => (clone $tabCountBase)
                ->where('v.owner_user_id', $currentUserId)
                ->count('v.sno'),

            'shared' => (clone $tabCountBase)
                ->where('v.owner_user_id', '!=', $currentUserId)
                ->count('v.sno'),

            'company' => (clone $tabCountBase)
                ->where(function ($scope) use ($companyId) {
                    $scope->where(function ($x) use ($companyId) {
                        if ($companyId !== null) {
                            $x->where('v.visibility', 'Company')
                                ->where('v.company_id', $companyId);
                        } else {
                            $x->whereRaw('1=0');
                        }
                    })
                    ->orWhere('v.visibility', 'Group')
                    ->orWhereExists(function ($g) use ($companyId) {
                        $g->selectRaw('1')
                            ->from('egc_tool_share_grants as ag')
                            ->where('ag.resource_type', 'vault')
                            ->whereColumn('ag.resource_id', 'v.sno')
                            ->where('ag.status', 'active')
                            ->where('ag.grantee_type', 'group')
                            ->where('ag.grantee_id', '0')
                            ->where('ag.metadata_json', 'like', '%"source":"passwallet_audience"%')
                            ->where('ag.metadata_json', 'like', '%"audience_context":"post"%')
                            ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(ag.metadata_json, '$.audience_mode')) = 'company'")
                            ->where(function ($ids) use ($companyId) {
                                if ($companyId !== null) {
                                    $ids->whereRaw(
                                        "JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.company_ids'), ?)",
                                        [json_encode((int) $companyId)]
                                    );
                                }
                                $ids->orWhereRaw(
                                    "JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.company_ids'), ?)",
                                    ['"all"']
                                );
                            });
                    });
                })
                ->count('v.sno'),
        ];

        // Apply only the selected tab to the actual displayed rows.
        $view = strtolower((string) $request->input('view', 'mine'));

        if ($view === 'mine') {
            $query->where('v.owner_user_id', $currentUserId);
        } elseif ($view === 'shared') {
            $query->where('v.owner_user_id', '!=', $currentUserId);
        } elseif ($view === 'company') {
            $query->where(function ($x) use ($companyId) {
                if ($companyId !== null) {
                    $x->where('v.visibility', 'Company')
                        ->where('v.company_id', $companyId);
                } else {
                    $x->whereRaw('1=0');
                }

                $x->orWhere('v.visibility', 'Group');

                $x->orWhereExists(function ($g) use ($companyId) {
                    $g->selectRaw('1')
                        ->from('egc_tool_share_grants as ag')
                        ->where('ag.resource_type', 'vault')
                        ->whereColumn('ag.resource_id', 'v.sno')
                        ->where('ag.status', 'active')
                        ->where('ag.grantee_type', 'group')
                        ->where('ag.grantee_id', '0')
                        ->where('ag.metadata_json', 'like', '%"source":"passwallet_audience"%')
                        ->where('ag.metadata_json', 'like', '%"audience_context":"post"%')
                        ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(ag.metadata_json, '$.audience_mode')) = 'company'")
                        ->where(function ($ids) use ($companyId) {
                            if ($companyId !== null) {
                                $ids->whereRaw(
                                    "JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.company_ids'), ?)",
                                    [json_encode((int) $companyId)]
                                );
                            }
                            $ids->orWhereRaw(
                                "JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.company_ids'), ?)",
                                ['"all"']
                            );
                        });
                });
            });
        }

        $perPage = min(max((int) $request->input('per_page', 10), 10), 100);
        $rows = $query->orderBy('v.entry_name')->paginate($perPage);

        $audienceMap = $this->audienceMapForVaultEntries(
            $rows->getCollection()->pluck('sno')->all()
        );

        $rows->getCollection()->transform(function ($entry) use ($audienceMap) {
            $entry->password_mask = '••••••••';
            $entry->notes_available = !empty($entry->notes_cipher);
            $audience = $audienceMap[(int) $entry->sno] ?? null;
            $entry->audience = $audience;
            $entry->scope_label = $audience['label'] ?? $this->legacyVisibilityLabel($entry);
            $entry->scope_mode = $audience['audience_mode'] ?? null;
            $entry->rotation_state = $this->rotationState($entry->next_rotation_at);
            unset($entry->password_cipher, $entry->password_key_ref, $entry->notes_cipher);
            return $entry;
        });

        $rotationQuery = clone $query;

        return $this->ok([
            'rows' => $rows,
            'rotation_overdue' => $rotationQuery
                ->whereNotNull('v.next_rotation_at')
                ->where('v.next_rotation_at', '<', now())
                ->count(),
            'summary' => [
                'total' => (int) $rows->total(),
            ],
            'tab_counts' => $tabCounts,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'entry_type' => ['required', 'in:Website,System,Application,Mobile App'],
            'entry_name' => ['required', 'string', 'max:180'],
            'url' => ['nullable', 'url', 'max:2000'],
            'username' => ['nullable', 'string', 'max:255'],
            'password' => ['required', 'string', 'max:1000'],
            'notes' => ['nullable', 'string', 'max:10000'],
            'email' => ['nullable', 'email', 'max:180'],
            'mobile' => ['nullable', 'string', 'max:40'],
            'icon_url' => ['nullable', 'url', 'max:1000'],
            'rotation_days' => ['nullable', 'integer', 'min:1', 'max:3650'],
            'audience_mode' => ['required', 'in:private,company,entity,role,staff'],
            'audience_company_ids' => ['nullable', 'array'],
            'audience_entity_ids' => ['nullable', 'array'],
            'audience_role_ids' => ['nullable', 'array'],
            'audience_staff_ids' => ['nullable', 'array'],
        ]);

        $audience = $this->normalizePassWalletAudience($request);
        $this->assertPassWalletAudienceAllowed($request, $audience);

        $companyId = $this->resolvePassWalletCompany($request, $data['company_id'] ?? null);
        $encryptedPassword = $this->crypto->encrypt($data['password']);
        $encryptedNotes = !empty($data['notes']) ? $this->crypto->encrypt($data['notes']) : null;
        $rotationDays = isset($data['rotation_days']) ? (int) $data['rotation_days'] : 90;

        $entry = DB::transaction(function () use ($data, $companyId, $encryptedPassword, $encryptedNotes, $rotationDays, $audience, $request) {
            $entry = VaultEntry::create([
                'company_id' => $companyId,
                'owner_user_id' => $this->uid(),
                'entry_type' => $data['entry_type'],
                'entry_name' => trim($data['entry_name']),
                'url' => $data['url'] ?? null,
                'username' => $data['username'] ?? null,
                'password_cipher' => $encryptedPassword['cipher'],
                'password_key_ref' => $encryptedPassword['key_ref'],
                'notes_cipher' => $encryptedNotes['cipher'] ?? null,
                'email' => $data['email'] ?? null,
                'mobile' => $data['mobile'] ?? null,
                'icon_url' => $data['icon_url'] ?? null,
                // The new audience grant is the source of truth. Keep the legacy
                // enum Private so old readers cannot broaden visibility.
                'visibility' => 'Private',
                'rotation_days' => $rotationDays,
                'last_rotated_at' => now(),
                'next_rotation_at' => now()->addDays($rotationDays),
                'created_by' => $this->uid(),
                'updated_by' => $this->uid(),
            ]);

            $this->replacePassWalletAudienceGrants(
                (int) $entry->sno,
                (int) $entry->owner_user_id,
                $audience,
                'View',
                null,
            );

            return $entry;
        });

        $this->audit(
            $request,
            'PassWallet',
            'created',
            'vault',
            $entry->sno,
            null,
            [
                'entry_id' => $entry->sno,
                'entry_name' => $entry->entry_name,
                'entry_type' => $entry->entry_type,
                'scope_mode' => $audience['audience_mode'],
            ],
            [],
            true,
        );

        return $this->ok(['id' => $entry->sno], 'Vault entry created securely.');
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry, $request);

        $payload = $entry->makeHidden([
            'password_cipher',
            'password_key_ref',
            'notes_cipher',
            'deleted_at',
        ])->toArray();

        $audience = $this->audienceCurrent('vault', $id);
        if (empty($audience['audience_mode'])) {
            $audience = [
                'source' => null,
                'audience_mode' => 'private',
                'mode' => 'private',
                'label' => 'Private',
                'company_ids' => [],
                'entity_ids' => [],
                'role_ids' => [],
                'staff_ids' => [],
            ];
        }

        $payload['password_mask'] = '••••••••••••';
        $payload['has_secret'] = !empty($entry->password_cipher);
        $payload['has_notes'] = !empty($entry->notes_cipher);
        $payload['audience'] = $audience;
        $payload['scope_label'] = $audience['label'] ?? $this->legacyVisibilityLabel($entry);
        $payload['can_manage'] = $this->canManagePassWalletResource($request, $entry);

        return $this->ok($payload);
    }

    public function stepUp(Request $request): JsonResponse
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot perform credential step-up actions.');

        $request->validate(['stepup_password' => ['required', 'string', 'max:255']]);
        $user = $request->user();

        abort_unless($user && !empty($user->password), 403, 'Step-up verification is unavailable.');
        abort_unless(Hash::check($request->input('stepup_password'), $user->password), 403, 'Invalid step-up credential.');

        session(['egc_tool_stepup_until' => now()->addMinutes(5)->timestamp]);

        $this->audit(
            $request,
            'PassWallet',
            'step_up_verified',
            'security',
            null,
            null,
            null,
            ['valid_for_minutes' => 5],
            true,
        );

        return $this->ok(['verified_until' => session('egc_tool_stepup_until')], 'Step-up verification successful.');
    }

    public function reveal(Request $request, int $id): JsonResponse
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot reveal credentials.');

        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry, $request);
        $this->requireStepUp($request);

        $secret = $this->crypto->decrypt($entry->password_cipher, $entry->password_key_ref);

        $this->audit($request, 'PassWallet', 'revealed', 'vault', $id, null, null, [], true);

        return $this->ok(['password' => $secret]);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot change credentials.');

        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->canManagePassWalletResource($request, $entry), 403);
        $this->requireStepUp($request);

        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'entry_type' => ['required', 'in:Website,System,Application,Mobile App'],
            'entry_name' => ['required', 'string', 'max:180'],
            'url' => ['nullable', 'url', 'max:2000'],
            'username' => ['nullable', 'string', 'max:255'],
            'password' => ['nullable', 'string', 'max:1000'],
            'notes' => ['nullable', 'string', 'max:10000'],
            'email' => ['nullable', 'email', 'max:180'],
            'mobile' => ['nullable', 'string', 'max:40'],
            'icon_url' => ['nullable', 'url', 'max:1000'],
            'rotation_days' => ['nullable', 'integer', 'min:1', 'max:3650'],
            'audience_mode' => ['required', 'in:private,company,entity,role,staff'],
            'audience_company_ids' => ['nullable', 'array'],
            'audience_entity_ids' => ['nullable', 'array'],
            'audience_role_ids' => ['nullable', 'array'],
            'audience_staff_ids' => ['nullable', 'array'],
        ]);

        $audience = $this->normalizePassWalletAudience($request);
        $this->assertPassWalletAudienceAllowed($request, $audience);
        $companyId = $this->resolvePassWalletCompany($request, $data['company_id'] ?? $entry->company_id);

        $before = [
            'entry_name' => $entry->entry_name,
            'entry_type' => $entry->entry_type,
            'username' => $entry->username,
            'rotation_days' => $entry->rotation_days,
            'visibility' => $entry->visibility,
        ];

        DB::transaction(function () use ($data, $entry, $companyId, $audience) {
            $payload = [
                'company_id' => $companyId,
                'entry_type' => $data['entry_type'],
                'entry_name' => trim($data['entry_name']),
                'url' => $data['url'] ?? null,
                'username' => $data['username'] ?? null,
                'email' => $data['email'] ?? null,
                'mobile' => $data['mobile'] ?? null,
                'icon_url' => $data['icon_url'] ?? null,
                'visibility' => 'Private',
                'rotation_days' => isset($data['rotation_days']) ? (int) $data['rotation_days'] : 90,
                'updated_by' => $this->uid(),
                'updated_at' => now(),
            ];

            if (array_key_exists('password', $data) && $data['password'] !== null && $data['password'] !== '') {
                DB::table('egc_tool_vault_entry_history')->insert([
                    'vault_entry_id' => $entry->sno,
                    'password_cipher' => $entry->password_cipher,
                    'password_key_ref' => $entry->password_key_ref,
                    'changed_by' => $this->uid(),
                    'changed_at' => now(),
                    'created_at' => now(),
                ]);

                $encrypted = $this->crypto->encrypt($data['password']);
                $payload['password_cipher'] = $encrypted['cipher'];
                $payload['password_key_ref'] = $encrypted['key_ref'];
                $payload['last_rotated_at'] = now();
                $payload['next_rotation_at'] = !empty($payload['rotation_days'])
                    ? now()->addDays((int) $payload['rotation_days'])
                    : null;
            }

            if (array_key_exists('notes', $data)) {
                $encryptedNotes = $data['notes'] !== '' && $data['notes'] !== null
                    ? $this->crypto->encrypt($data['notes'])
                    : null;
                $payload['notes_cipher'] = $encryptedNotes['cipher'] ?? null;
            }

            $entry->update($payload);

            $this->replacePassWalletAudienceGrants(
                (int) $entry->sno,
                (int) $entry->owner_user_id,
                $audience,
                'View',
                null,
            );
        });

        $this->audit(
            $request,
            'PassWallet',
            'updated',
            'vault',
            $id,
            $before,
            [
                'entry_name' => $entry->entry_name,
                'entry_type' => $entry->entry_type,
                'username' => $entry->username,
                'rotation_days' => $entry->rotation_days,
                'scope_mode' => $audience['audience_mode'],
            ],
            ['secret_changed' => array_key_exists('password', $data) && $data['password'] !== null && $data['password'] !== ''],
            true,
        );

        return $this->ok(null, 'Vault entry updated securely.');
    }

    public function copyAudit(Request $request, int $id): JsonResponse
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot copy credentials.');

        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry, $request);
        $this->requireStepUp($request);

        $this->audit($request, 'PassWallet', 'copied', 'vault', $id, null, null, [], true);

        return $this->ok(null, 'Credential copy access recorded.');
    }

    public function history(Request $request, int $id): JsonResponse
    {
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry, $request);

        $rows = DB::table('egc_tool_vault_entry_history as h')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'h.changed_by')
            ->where('h.vault_entry_id', $id)
            ->orderByDesc('h.changed_at')
            ->limit(10)
            ->get([
                'h.sno',
                'h.changed_by',
                'h.changed_at',
                DB::raw("COALESCE(s.staff_name, 'ERP User') as changed_by_name"),
            ]);

        return $this->ok($rows);
    }

    public function auditTrail(Request $request, int $id): JsonResponse
    {
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry, $request);

        $rows = DB::table('egc_tool_audit_logs')
            ->where('resource_type', 'vault')
            ->where('resource_id', $id)
            ->orderByDesc('created_at')
            ->limit(25)
            ->get([
                'sno',
                'action',
                'actor_user_id',
                'actor_name',
                'ip_address',
                'is_high_sensitivity',
                'created_at',
            ]);

        return $this->ok($rows);
    }

    public function shares(Request $request, int $id): JsonResponse
    {
        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->canManagePassWalletResource($request, $entry), 403, 'You do not have permission to manage this credential sharing.');

        $rows = DB::table('egc_tool_share_grants')
            ->where('resource_type', 'vault')
            ->where('resource_id', $id)
            ->whereIn('status', ['active', 'pending'])
            ->where(function ($q) {
                $q->where(function ($audience) {
                    $audience->where('metadata_json', 'like', '%"source":"passwallet_audience"%')
                        ->where('metadata_json', 'like', '%"audience_context":"share"%');
                })->orWhere(function ($legacy) {
                    $legacy->whereNull('metadata_json')
                        ->orWhere('metadata_json', 'not like', '%"source":"passwallet_audience"%');
                });
            })
            ->orderByDesc('created_at')
            ->get();

        $items = $rows->map(function ($row) {
            $meta = json_decode((string) ($row->metadata_json ?? ''), true);
            if (is_array($meta) && ($meta['source'] ?? null) === 'passwallet_audience') {
                return [
                    'sno' => $row->sno,
                    'permission' => $row->permission,
                    'status' => $row->status,
                    'expires_at' => $row->expires_at,
                    'audience_mode' => $meta['audience_mode'] ?? null,
                    'audience' => $meta,
                ];
            }

            return [
                'sno' => $row->sno,
                'permission' => $row->permission,
                'status' => $row->status,
                'expires_at' => $row->expires_at,
                'audience_mode' => match ($row->grantee_type) {
                    'company' => 'company',
                    'role' => 'role',
                    'user' => 'staff',
                    default => 'group',
                },
                'legacy_grantee_type' => $row->grantee_type,
                'legacy_grantee_id' => $row->grantee_id,
            ];
        })->values();

        return $this->ok($this->hydratePassWalletAudienceNames($items));
    }

    public function shareStore(Request $request, int $id): JsonResponse
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot share credentials.');

        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->canManagePassWalletResource($request, $entry), 403, 'You do not have permission to share this credential.');
        $this->requireStepUp($request);

        $data = $request->validate([
            'permission' => ['required', 'in:View,Manage'],
            'expires_at' => ['nullable', 'date', 'after:now'],
            'audience_mode' => ['required', 'in:company,entity,role,staff'],
            'audience_company_ids' => ['nullable', 'array'],
            'audience_entity_ids' => ['nullable', 'array'],
            'audience_role_ids' => ['nullable', 'array'],
            'audience_staff_ids' => ['nullable', 'array'],
        ]);

        $audience = $this->normalizePassWalletAudience($request, 'passwallet_audience');
        $this->assertPassWalletAudienceAllowed($request, $audience);

        $grantId = $this->upsertPassWalletShareGrant(
            $id,
            (int) $entry->owner_user_id,
            $audience,
            $data['permission'],
            $data['expires_at'] ?? null,
        );

        $this->audit(
            $request,
            'PassWallet',
            'shared',
            'vault',
            $id,
            null,
            ['grant_id' => $grantId, 'permission' => $data['permission'], 'scope_mode' => $audience['audience_mode']],
            [],
            true,
        );

        return $this->ok(['id' => $grantId], 'Credential sharing updated.');
    }

    public function shareRevoke(Request $request, int $grantId): JsonResponse
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot revoke credential shares.');

        $grant = DB::table('egc_tool_share_grants')
            ->where('sno', $grantId)
            ->where('resource_type', 'vault')
            ->first();

        abort_unless($grant, 404);

        $grantMeta = json_decode((string) ($grant->metadata_json ?? ''), true);
        if (is_array($grantMeta)
            && ($grantMeta['source'] ?? null) === 'passwallet_audience'
            && ($grantMeta['audience_context'] ?? null) === 'post') {
            abort(422, 'The primary PassWallet audience is managed from the credential record and cannot be revoked here.');
        }

        $entry = VaultEntry::findOrFail((int) $grant->resource_id);
        abort_unless($this->canManagePassWalletResource($request, $entry), 403);
        $this->requireStepUp($request);

        DB::table('egc_tool_share_grants')
            ->where('sno', $grantId)
            ->update([
                'status' => 'revoked',
                'revoked_by' => $this->uid(),
                'revoked_at' => now(),
                'updated_at' => now(),
            ]);

        $this->audit($request, 'PassWallet', 'share_revoked', 'vault', $entry->sno, null, ['grant_id' => $grantId], [], true);

        return $this->ok(null, 'Credential share revoked.');
    }

    public function lockdown(Request $request, int $userId): JsonResponse
    {
        abort_unless($this->access->isSuper(), 403);

        DB::transaction(function () use ($userId) {
            DB::table('egc_tool_share_grants')
                ->where('resource_type', 'vault')
                ->where('grantee_type', 'user')
                ->where('grantee_id', (string) $userId)
                ->whereIn('status', ['active', 'pending'])
                ->update([
                    'status' => 'revoked',
                    'revoked_by' => $this->uid(),
                    'revoked_at' => now(),
                    'updated_at' => now(),
                ]);
        });

        $this->audit($request, 'PassWallet', 'user_lockdown', 'user', $userId, null, null, [], true);

        return $this->ok(null, 'Vault access frozen for the user.');
    }

    public function generator(Request $request): JsonResponse
    {
        $data = $request->validate([
            'length' => ['required', 'integer', 'min:8', 'max:128'],
            'upper' => ['nullable', 'boolean'],
            'lower' => ['nullable', 'boolean'],
            'numbers' => ['nullable', 'boolean'],
            'symbols' => ['nullable', 'boolean'],
        ]);

        $chars = '';
        $chars .= ($data['upper'] ?? true) ? 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' : '';
        $chars .= ($data['lower'] ?? true) ? 'abcdefghijklmnopqrstuvwxyz' : '';
        $chars .= ($data['numbers'] ?? true) ? '0123456789' : '';
        $chars .= ($data['symbols'] ?? true) ? '!@#$%^&*()-_=+[]{}' : '';

        abort_if($chars === '', 422, 'At least one character set must be enabled.');

        $password = '';
        for ($i = 0; $i < (int) $data['length']; $i++) {
            $password .= $chars[random_int(0, strlen($chars) - 1)];
        }

        return $this->ok(['password' => $password]);
    }

    public function delete(Request $request, int $id): JsonResponse
    {
        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->canManagePassWalletResource($request, $entry), 403);
        $this->requireStepUp($request);

        DB::transaction(function () use ($entry) {
            $entry->update([
                'status' => 2,
                'deleted_at' => now(),
                'updated_by' => $this->uid(),
                'updated_at' => now(),
            ]);

            DB::table('egc_tool_share_grants')
                ->where('resource_type', 'vault')
                ->where('resource_id', $entry->sno)
                ->whereIn('status', ['active', 'pending'])
                ->update([
                    'status' => 'revoked',
                    'revoked_by' => $this->uid(),
                    'revoked_at' => now(),
                    'updated_at' => now(),
                ]);
        });

        $this->audit($request, 'PassWallet', 'deleted', 'vault', $id, null, null, [], true);

        return $this->ok(null, 'Vault entry removed.');
    }

    public function attachment(Request $request, int $id): JsonResponse
    {
        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->canManagePassWalletResource($request, $entry), 403);
        $this->requireStepUp($request);

        $data = $request->validate([
            'attachment' => ['required', 'file', 'max:20480', 'mimes:pdf,txt,csv,jpg,jpeg,png,zip'],
        ]);

        $file = $data['attachment'];
        $path = $file->store('egpk/vault/' . date('Y/m'), 's3');

        $attachmentId = DB::table('egc_tool_vault_entry_attachments')->insertGetId([
            'vault_entry_id' => $id,
            'storage_path' => $path,
            'original_name' => $file->getClientOriginalName(),
            'mime_type' => $file->getMimeType(),
            'file_size' => $file->getSize(),
            'created_by' => $this->uid(),
            'created_at' => now(),
        ]);

        $this->audit($request, 'PassWallet', 'attachment_added', 'vault', $id, null, null, ['attachment_id' => $attachmentId], true);

        return $this->ok(['id' => $attachmentId], 'Vault attachment stored securely.');
    }

    public function attachments(Request $request, int $id): JsonResponse
    {
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry, $request);

        return $this->ok(
            DB::table('egc_tool_vault_entry_attachments')
                ->where('vault_entry_id', $id)
                ->orderByDesc('created_at')
                ->get(['sno', 'original_name', 'mime_type', 'file_size', 'created_at'])
        );
    }

    private function resolvePassWalletCompany(Request $request, $requestedCompanyId): ?int
    {
        $groupAdmin = $this->access->isGroupAdmin($request);
        $currentCompany = $this->cid();

        if ($requestedCompanyId !== null && $requestedCompanyId !== '') {
            $requestedCompanyId = (int) $requestedCompanyId;
        } else {
            $requestedCompanyId = null;
        }

        if (!$groupAdmin) {
            if ($requestedCompanyId !== null && $currentCompany !== null) {
                abort_unless((int) $requestedCompanyId === (int) $currentCompany, 403, 'Selected company is outside your company scope.');
            }
            return $currentCompany !== null ? (int) $currentCompany : $requestedCompanyId;
        }

        if ($requestedCompanyId !== null) {
            $exists = DB::table('egc_company')
                ->where('sno', $requestedCompanyId)
                ->where('status', 0)
                ->exists();
            abort_unless($exists, 422, 'Selected company is not active.');
            return $requestedCompanyId;
        }

        return null;
    }

    private function passWalletUserContext(Request $r): array
    {
        $user = $r->user();
        $uid = (int) ($user?->user_id ?? 0);
        $companyId = $user?->company_id !== null ? (int) $user->company_id : null;
        $entityId = $user?->entity_d !== null ? (int) $user->entity_d : null;
        $roleId = $user?->role_id !== null ? (int) $user->role_id : null;

        if ($uid <= 0) {
            $uid = (int) $this->access->userId($r);
        }

        $staff = null;
        if ($uid > 0 && ($companyId === null || $entityId === null || $roleId === null)) {
            $staff = DB::table('egc_staff')
                ->where('sno', $uid)
                ->select(['sno', 'company_id', 'entity_id', 'role_id'])
                ->first();
        }

        if ($companyId === null) {
            $companyId = $staff?->company_id !== null
                ? (int) $staff->company_id
                : $this->access->companyId($r);
        }

        if ($entityId === null) {
            $entityId = $staff?->entity_id !== null ? (int) $staff->entity_id : 0;
        }

        if ($roleId === null) {
            $roleId = $staff?->role_id !== null
                ? (int) $staff->role_id
                : $this->access->roleId($r);
        }

        return [
            'uid' => $uid,
            'company_id' => $companyId,
            'entity_id' => $entityId,
            'role_id' => $roleId,
            'role_name' => $this->access->role($r),
        ];
    }

    private function normalizeAudienceValue($value, bool $allowAll = false): array
    {
        if (!is_array($value)) {
            $value = ($value === null || $value === '') ? [] : [$value];
        }

        $result = [];
        foreach ($value as $item) {
            $item = trim((string) $item);
            if ($item === '') {
                continue;
            }

            if ($allowAll && $item === 'all') {
                $result[] = 'all';
                continue;
            }

            if (preg_match('/^0$|^[1-9][0-9]*$/', $item)) {
                $result[] = (int) $item;
            }
        }

        return array_values(array_unique($result, SORT_REGULAR));
    }

    private function normalizePassWalletAudience(Request $r, string $source = 'passwallet_audience'): array
    {
        $mode = strtolower((string) $r->input('audience_mode', 'company'));
        abort_unless(in_array($mode, ['private', 'company', 'entity', 'role', 'staff'], true), 422, 'Invalid audience type.');

        $audience = [
            'source' => $source,
            'audience_mode' => $mode,
            'mode' => $mode,
            'company_ids' => [],
            'entity_ids' => [],
            'role_ids' => [],
            'staff_ids' => [],
        ];

        if ($mode === 'private') {
            // Private has no audience selections. The entry remains owned by the current user.
        } elseif ($mode === 'company') {
            $audience['company_ids'] = $this->normalizeAudienceValue($r->input('audience_company_ids', []), true);
        } elseif ($mode === 'entity') {
            $audience['entity_ids'] = $this->normalizeAudienceValue($r->input('audience_entity_ids', []), true);
        } elseif ($mode === 'role') {
            $audience['entity_ids'] = $this->normalizeAudienceValue($r->input('audience_entity_ids', []), true);
            $audience['role_ids'] = $this->normalizeAudienceValue($r->input('audience_role_ids', []), true);
        } else {
            $audience['entity_ids'] = $this->normalizeAudienceValue($r->input('audience_entity_ids', []), true);
            $audience['staff_ids'] = $this->normalizeAudienceValue($r->input('audience_staff_ids', []), false);
        }

        abort_unless($this->passWalletAudienceHasSelection($audience), 422, 'Choose at least one audience option.');

        return $audience;
    }

    private function passWalletAudienceHasSelection(array $audience): bool
    {
        return match ($audience['audience_mode']) {
            'private' => true,
            'company' => !empty($audience['company_ids']),
            'entity' => !empty($audience['entity_ids']),
            'role' => !empty($audience['entity_ids']) && !empty($audience['role_ids']),
            'staff' => !empty($audience['entity_ids']) && !empty($audience['staff_ids']),
            default => false,
        };
    }

    private function assertPassWalletAudienceAllowed(Request $r, array $audience): void
    {
        $groupAdmin = $this->access->isGroupAdmin($r);
        $companyId = $this->cid();

        if ($audience['audience_mode'] === 'private') {
            return;
        }

        if ($audience['audience_mode'] === 'company') {
            $ids = $audience['company_ids'];

            if (in_array('all', $ids, true)) {
                abort_unless($groupAdmin, 403, 'Only Group Admin can target all companies.');
                return;
            }

            if (!$groupAdmin && $companyId !== null) {
                foreach ($ids as $id) {
                    abort_unless((int) $id === (int) $companyId, 403, 'Selected company is outside your scope.');
                }
            }

            $positive = array_values(array_filter($ids, static fn ($id) => is_int($id) && $id > 0));
            if ($positive) {
                $count = DB::table('egc_company')
                    ->whereIn('sno', $positive)
                    ->where('status', 0)
                    ->count();

                abort_unless((int) $count === count($positive), 422, 'One or more selected companies are not active.');
            }
            return;
        }

        $entityIds = $audience['entity_ids'];
        if (in_array('all', $entityIds, true)) {
            abort_unless($groupAdmin, 403, 'Only Group Admin can target all entities.');
        }

        $positive = array_values(array_filter($entityIds, static fn ($id) => is_int($id) && $id > 0));
        $entityQuery = DB::table('egc_entity')->whereIn('sno', $positive)->where('status', 0);
        if (!$groupAdmin && $companyId !== null) {
            $entityQuery->where('company_id', $companyId);
        }
        if ($positive) {
            abort_unless((int) $entityQuery->count() === count($positive), 422, 'One or more selected entities are outside your scope.');
        }

        if ($audience['audience_mode'] === 'entity') {
            return;
        }

        if ($audience['audience_mode'] === 'role') {
            $roleIds = $audience['role_ids'];
            $rolePositive = array_values(array_filter($roleIds, static fn ($id) => is_int($id) && $id > 0));
            $roleQuery = DB::table('egc_user_role as ur')->where('ur.status', 0);

            if (in_array(0, $entityIds, true) && count($entityIds) === 1) {
                $roleQuery->where('ur.entity_id', 0);
            } elseif ($positive) {
                $roleQuery->whereIn('ur.entity_id', $positive);
            }

            if ($rolePositive) {
                abort_unless(
                    (int) $roleQuery->whereIn('ur.sno', $rolePositive)->count() === count($rolePositive),
                    422,
                    'One or more selected roles are unavailable.'
                );
            }

            return;
        }

        $staffIds = $audience['staff_ids'];
        $staffPositive = array_values(array_filter($staffIds, static fn ($id) => is_int($id) && $id > 0));
        if ($staffPositive) {
            $staffQuery = DB::table('egc_staff as s')
                ->where('s.status', 0)
                ->whereIn('s.sno', $staffPositive);

            if (!in_array('all', $entityIds, true)) {
                if ($positive) {
                    $staffQuery->whereIn('s.entity_id', $positive);
                } elseif (in_array(0, $entityIds, true)) {
                    $staffQuery->where('s.entity_id', 0);
                }
            }

            if (!$groupAdmin && $companyId !== null) {
                $staffQuery->where('s.company_id', $companyId);
            }

            abort_unless(
                (int) $staffQuery->count() === count($staffPositive),
                422,
                'One or more selected staff members are outside your scope.'
            );
        }
    }

    private function replacePassWalletAudienceGrants(
        int $entryId,
        int $ownerUserId,
        array $audience,
        string $permission = 'View',
        ?string $expiresAt = null,
    ): void {
        DB::table('egc_tool_share_grants')
            ->where('resource_type', 'vault')
            ->where('resource_id', $entryId)
            ->where('metadata_json', 'like', '%"source":"passwallet_audience"%')
            ->where('metadata_json', 'like', '%"audience_context":"post"%')
            ->update([
                'status' => 'revoked',
                'updated_at' => now(),
                'revoked_by' => $this->uid(),
                'revoked_at' => now(),
            ]);

        if (($audience['audience_mode'] ?? null) === 'private') {
            return;
        }

        $metadata = array_merge($audience, [
            'source' => 'passwallet_audience',
            'audience_context' => 'post',
        ]);

        DB::table('egc_tool_share_grants')->insert([
            'resource_type' => 'vault',
            'resource_id' => $entryId,
            'owner_user_id' => $ownerUserId,
            'grantee_type' => 'group',
            'grantee_id' => '0',
            'permission' => $permission,
            'status' => 'active',
            'expires_at' => $expiresAt,
            'requested_by' => $this->uid(),
            'approved_by' => $this->uid(),
            'approval_required' => 0,
            'approved_at' => now(),
            'metadata_json' => json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    private function upsertPassWalletShareGrant(
        int $entryId,
        int $ownerUserId,
        array $audience,
        string $permission = 'View',
        ?string $expiresAt = null,
    ): int {
        $metadata = array_merge($audience, [
            'source' => 'passwallet_audience',
            'audience_context' => 'share',
        ]);
        $metadataJson = json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $existing = DB::table('egc_tool_share_grants')
            ->where('resource_type', 'vault')
            ->where('resource_id', $entryId)
            ->where('grantee_type', 'group')
            ->where('grantee_id', '0')
            ->whereIn('status', ['active', 'pending'])
            ->where('permission', $permission)
            ->where('metadata_json', $metadataJson)
            ->first();

        if ($existing) {
            DB::table('egc_tool_share_grants')
                ->where('sno', $existing->sno)
                ->update([
                    'expires_at' => $expiresAt,
                    'approved_by' => $this->uid(),
                    'approval_required' => 0,
                    'approved_at' => now(),
                    'updated_at' => now(),
                ]);
            return (int) $existing->sno;
        }

        return (int) DB::table('egc_tool_share_grants')->insertGetId([
            'resource_type' => 'vault',
            'resource_id' => $entryId,
            'owner_user_id' => $ownerUserId,
            'grantee_type' => 'group',
            'grantee_id' => '0',
            'permission' => $permission,
            'status' => 'active',
            'expires_at' => $expiresAt,
            'requested_by' => $this->uid(),
            'approved_by' => $this->uid(),
            'approval_required' => 0,
            'approved_at' => now(),
            'metadata_json' => $metadataJson,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    private function canManagePassWalletResource(Request $request, VaultEntry $entry): bool
    {
        $ctx = $this->passWalletUserContext($request);
        $uid = (int) $ctx['uid'];

        if ((int) $ctx['role_id'] === 1 || (int) $entry->owner_user_id === $uid) {
            return true;
        }

        if ($this->access->canManageResource('vault', $entry->sno, $entry->owner_user_id)) {
            return true;
        }

        return $this->passWalletAudienceGrantExists($request, (int) $entry->sno, true);
    }

    private function assertReadable(VaultEntry $entry, Request $request): void
    {
        abort_unless($this->canViewPassWalletEntry($request, $entry), 403);
    }

    private function canViewPassWalletEntry(Request $r, VaultEntry $entry): bool
    {
        $ctx = $this->passWalletUserContext($r);

        if ((int) $ctx['role_id'] === 1) {
            return true;
        }

        if ((int) $entry->owner_user_id === (int) $ctx['uid']) {
            return true;
        }

        if ($this->passWalletAudienceDefinitionExists((int) $entry->sno)) {
            return $this->passWalletAudienceGrantExists($r, (int) $entry->sno);
        }

        return $this->access->canReadResource(
            'vault',
            (int) $entry->sno,
            $entry->owner_user_id,
            $entry->company_id,
            $entry->visibility
        ) || $this->passWalletAudienceGrantExists($r, (int) $entry->sno);
    }

    private function passWalletAudienceDefinitionExists(int $entryId): bool
    {
        return DB::table('egc_tool_share_grants')
            ->where('resource_type', 'vault')
            ->where('resource_id', $entryId)
            ->where('metadata_json', 'like', '%"source":"passwallet_audience"%')
            ->where('metadata_json', 'like', '%"audience_context":"post"%')
            ->exists();
    }

    private function passWalletAudienceGrantExists(Request $r, int $entryId, bool $manage = false): bool
    {
        $ctx = $this->passWalletUserContext($r);

        $query = DB::table('egc_tool_share_grants as g')
            ->where('g.resource_type', 'vault')
            ->where('g.resource_id', $entryId)
            ->where('g.status', 'active')
            ->where(fn ($e) => $e->whereNull('g.expires_at')->orWhere('g.expires_at', '>=', now()))
            ->when($manage, fn ($x) => $x->where('g.permission', 'Manage'));

        $query->where(function ($aud) use ($ctx) {
            $aud->where(function ($x) use ($ctx) {
                $x->where('g.metadata_json', 'like', '%"source":"passwallet_audience"%')
                    ->where(function ($context) {
                $context->where('g.metadata_json', 'like', '%"audience_context":"post"%')
                    ->orWhere('g.metadata_json', 'like', '%"audience_context":"share"%');
            })
                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'company'")
                    ->where(function ($ids) use ($ctx) {
                        if ($ctx['company_id'] !== null) {
                            $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.company_ids'), ?)", [json_encode((int) $ctx['company_id'])]);
                        }
                        $ids->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.company_ids'), ?)", ['"all"']);
                    });
            })
            ->orWhere(function ($x) use ($ctx) {
                $x->where('g.metadata_json', 'like', '%"source":"passwallet_audience"%')
                    ->where(function ($context) {
                $context->where('g.metadata_json', 'like', '%"audience_context":"post"%')
                    ->orWhere('g.metadata_json', 'like', '%"audience_context":"share"%');
            })
                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'entity'")
                    ->where(function ($ids) use ($ctx) {
                        if ($ctx['entity_id'] !== null) {
                            $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", [json_encode((int) $ctx['entity_id'])]);
                        }
                        $ids->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", ['"all"']);
                    });
            })
            ->orWhere(function ($x) use ($ctx) {
                $x->where('g.metadata_json', 'like', '%"source":"passwallet_audience"%')
                    ->where(function ($context) {
                $context->where('g.metadata_json', 'like', '%"audience_context":"post"%')
                    ->orWhere('g.metadata_json', 'like', '%"audience_context":"share"%');
            })
                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'role'")
                    ->where(function ($ids) use ($ctx) {
                        if ($ctx['entity_id'] !== null) {
                            $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", [json_encode((int) $ctx['entity_id'])]);
                        }
                        $ids->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", ['"all"']);
                    })
                    ->where(function ($roles) use ($ctx) {
                        if ($ctx['role_id'] !== null) {
                            $roles->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.role_ids'), ?)", [json_encode((int) $ctx['role_id'])]);
                        }
                        $roles->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.role_ids'), ?)", ['"all"']);
                    });
            })
            ->orWhere(function ($x) use ($ctx) {
                $x->where('g.metadata_json', 'like', '%"source":"passwallet_audience"%')
                    ->where(function ($context) {
                $context->where('g.metadata_json', 'like', '%"audience_context":"post"%')
                    ->orWhere('g.metadata_json', 'like', '%"audience_context":"share"%');
            })
                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'staff'")
                    ->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.staff_ids'), ?)", [json_encode((int) $ctx['uid'])]);
            });
        });

        return $query->exists();
    }

    private function applyPassWalletReadableQueryScope($query, Request $r, string $alias = 'v'): void
    {
        $ctx = $this->passWalletUserContext($r);

        if ((int) $ctx['role_id'] === 1) {
            return;
        }

        if ((int) $ctx['uid'] <= 0) {
            $query->whereRaw('1=0');
            return;
        }

        $companyId = $ctx['company_id'];
        $entityId = $ctx['entity_id'];
        $roleId = $ctx['role_id'];
        $uid = $ctx['uid'];
        $roleName = $ctx['role_name'];

        $query->where(function ($scope) use ($alias, $uid, $companyId, $roleName, $entityId, $roleId) {
            $scope->where("{$alias}.owner_user_id", $uid)
                ->orWhereExists(function ($g) use ($alias, $uid, $companyId, $entityId, $roleId) {
                    $g->selectRaw('1')
                        ->from('egc_tool_share_grants as g')
                        ->where('g.resource_type', 'vault')
                        ->whereColumn('g.resource_id', "{$alias}.sno")
                        ->where('g.status', 'active')
                        ->where('g.grantee_type', 'group')
                        ->where('g.grantee_id', '0')
                        ->where(function ($aud) use ($companyId, $entityId, $roleId, $uid) {
                            $aud->where(function ($x) use ($companyId) {
                                $x->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.source')) = 'passwallet_audience'")
                                    ->whereIn(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_context'))"), ['post', 'share'])
                                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'company'")
                                    ->where(function ($ids) use ($companyId) {
                                        if ($companyId !== null) {
                                            $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.company_ids'), ?)", [json_encode((int) $companyId)]);
                                        }
                                        $ids->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.company_ids'), ?)", ['"all"']);
                                    });
                            })
                            ->orWhere(function ($x) use ($entityId) {
                                $x->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.source')) = 'passwallet_audience'")
                                    ->whereIn(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_context'))"), ['post', 'share'])
                                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'entity'")
                                    ->where(function ($ids) use ($entityId) {
                                        if ($entityId !== null) {
                                            $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", [json_encode((int) $entityId)]);
                                        }
                                        $ids->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", ['"all"']);
                                    });
                            })
                            ->orWhere(function ($x) use ($entityId, $roleId) {
                                $x->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.source')) = 'passwallet_audience'")
                                    ->whereIn(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_context'))"), ['post', 'share'])
                                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'role'")
                                    ->where(function ($ids) use ($entityId) {
                                        if ($entityId !== null) {
                                            $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", [json_encode((int) $entityId)]);
                                        }
                                        $ids->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", ['"all"']);
                                    })
                                    ->where(function ($roles) use ($roleId) {
                                        if ($roleId !== null) {
                                            $roles->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.role_ids'), ?)", [json_encode((int) $roleId)]);
                                        }
                                        $roles->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.role_ids'), ?)", ['"all"']);
                                    });
                            })
                            ->orWhere(function ($x) use ($uid) {
                                $x->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.source')) = 'passwallet_audience'")
                                    ->whereIn(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_context'))"), ['post', 'share'])
                                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'staff'")
                                    ->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.staff_ids'), ?)", [json_encode((int) $uid)]);
                            });
                        })
                        ->where(fn ($e) => $e->whereNull('g.expires_at')->orWhere('g.expires_at', '>=', now()));
                })
                ->orWhere(function ($legacy) use ($alias, $uid, $companyId, $roleName) {
                    $legacy->whereNotExists(function ($audienceEntry) use ($alias) {
                        $audienceEntry->selectRaw('1')
                            ->from('egc_tool_share_grants as pa')
                            ->where('pa.resource_type', 'vault')
                            ->whereColumn('pa.resource_id', "{$alias}.sno")
                            ->where('pa.metadata_json', 'like', '%"source":"passwallet_audience"%')
                            ->where('pa.metadata_json', 'like', '%"audience_context":"post"%');
                    })
                    ->where(function ($oldVisibility) use ($alias, $uid, $companyId) {
                        $oldVisibility->where("{$alias}.visibility", 'Group')
                            ->orWhere(function ($x) use ($alias, $companyId) {
                                if ($companyId !== null) {
                                    $x->where("{$alias}.visibility", 'Company')->where("{$alias}.company_id", $companyId);
                                } else {
                                    $x->whereRaw('1=0');
                                }
                            })
                            ->orWhereExists(function ($g) use ($alias, $uid, $companyId, $roleName) {
                                $g->selectRaw('1')
                                    ->from('egc_tool_share_grants as g')
                                    ->where('g.resource_type', 'vault')
                                    ->whereColumn('g.resource_id', "{$alias}.sno")
                                    ->where('g.status', 'active')
                                    ->where(fn ($e) => $e->whereNull('g.expires_at')->orWhere('g.expires_at', '>=', now()))
                                    ->where(function ($grantee) use ($uid, $companyId, $roleName) {
                                        $grantee->where(fn ($x) => $x->where('g.grantee_type', 'user')->where('g.grantee_id', (string) $uid))
                                            ->orWhere(fn ($x) => $x->where('g.grantee_type', 'role')->where('g.grantee_id', (string) $roleName))
                                            ->when($companyId !== null, fn ($x) => $x->orWhere(fn ($co) => $co->where('g.grantee_type', 'company')->where('g.grantee_id', (string) $companyId)))
                                            ->orWhere(fn ($x) => $x->where('g.grantee_type', 'group')->where('g.grantee_id', '0'));
                                    });
                            });
                    });
                });
        });
    }

    private function audienceCurrent(string $resourceType, int $resourceId): array
    {
        $row = DB::table('egc_tool_share_grants')
            ->where('resource_type', $resourceType)
            ->where('resource_id', $resourceId)
            ->where('status', 'active')
            ->where('metadata_json', 'like', '%"source":"passwallet_audience"%')
            ->where('metadata_json', 'like', '%"audience_context":"post"%')
            ->orderByDesc('sno')
            ->first();

        if (!$row) {
            return [
                'source' => null,
                'audience_mode' => null,
                'label' => null,
                'company_ids' => [],
                'entity_ids' => [],
                'role_ids' => [],
                'staff_ids' => [],
            ];
        }

        $meta = json_decode((string) ($row->metadata_json ?? ''), true);
        if (!is_array($meta)) {
            $meta = [];
        }

        return array_merge($meta, [
            'grant_id' => $row->sno,
            'permission' => $row->permission,
            'status' => $row->status,
            'expires_at' => $row->expires_at,
            'label' => $this->audienceLabel($meta),
        ]);
    }

    private function audienceMapForVaultEntries(array $ids): array
    {
        if (!$ids) {
            return [];
        }

        $rows = DB::table('egc_tool_share_grants')
            ->where('resource_type', 'vault')
            ->whereIn('resource_id', $ids)
            ->where('status', 'active')
            ->where('metadata_json', 'like', '%"source":"passwallet_audience"%')
            ->where('metadata_json', 'like', '%"audience_context":"post"%')
            ->orderByDesc('sno')
            ->get(['sno', 'resource_id', 'permission', 'expires_at', 'metadata_json']);

        $map = [];
        foreach ($rows as $row) {
            $id = (int) $row->resource_id;
            if (isset($map[$id])) {
                continue;
            }

            $meta = json_decode((string) ($row->metadata_json ?? ''), true);
            if (!is_array($meta)) {
                continue;
            }

            $meta['grant_id'] = $row->sno;
            $meta['permission'] = $row->permission;
            $meta['status'] = 'active';
            $meta['expires_at'] = $row->expires_at;
            $meta['label'] = $this->audienceLabel($meta);
            $map[$id] = $meta;
        }

        return $map;
    }

    private function audienceLabel(array $meta): string
    {
        return match (strtolower((string) ($meta['audience_mode'] ?? $meta['mode'] ?? ''))) {
            'company' => ((array) ($meta['company_ids'] ?? [])) === ['all'] ? 'All companies' : 'Company audience',
            'entity' => ((array) ($meta['entity_ids'] ?? [])) === ['all'] ? 'All entities' : 'Entity audience',
            'role' => 'Role audience',
            'staff' => 'Staff audience',
            default => 'Private',
        };
    }

    private function legacyVisibilityLabel(VaultEntry $entry): string
    {
        return match ((string) $entry->visibility) {
            'Group' => 'Group',
            'Company' => 'Company',
            default => 'Private',
        };
    }

    private function rotationState($nextRotationAt): array
    {
        if (!$nextRotationAt) {
            return ['key' => 'none', 'label' => 'Not scheduled', 'days' => null];
        }

        $when = $nextRotationAt instanceof \Carbon\CarbonInterface
            ? $nextRotationAt
            : now()->parse((string) $nextRotationAt);
        $days = now()->diffInDays($when, false);

        if ($days < 0) {
            return ['key' => 'overdue', 'label' => 'Overdue ' . abs($days) . 'd', 'days' => $days];
        }
        if ($days === 0) {
            return ['key' => 'due', 'label' => 'Due today', 'days' => 0];
        }
        if ($days <= 30) {
            return ['key' => 'due', 'label' => 'Due in ' . $days . 'd', 'days' => $days];
        }

        return ['key' => 'ok', 'label' => 'OK', 'days' => $days];
    }

    private function hydratePassWalletAudienceNames($items)
    {
        $companyIds = collect();
        $entityIds = collect();
        $roleIds = collect();
        $staffIds = collect();
        $legacyRoleValues = collect();

        foreach ($items as $item) {
            $mode = (string) ($item['audience_mode'] ?? '');
            $meta = is_array($item['audience'] ?? null) ? $item['audience'] : [];

            foreach ((array) ($meta['company_ids'] ?? []) as $id) {
                if (is_numeric($id) && (int) $id >= 0) {
                    $companyIds->push((int) $id);
                }
            }
            foreach ((array) ($meta['entity_ids'] ?? []) as $id) {
                if (is_numeric($id) && (int) $id >= 0) {
                    $entityIds->push((int) $id);
                }
            }
            foreach ((array) ($meta['role_ids'] ?? []) as $id) {
                if (is_numeric($id) && (int) $id > 0) {
                    $roleIds->push((int) $id);
                }
            }
            foreach ((array) ($meta['staff_ids'] ?? []) as $id) {
                if (is_numeric($id) && (int) $id > 0) {
                    $staffIds->push((int) $id);
                }
            }

            if ($mode === 'role' && !empty($item['legacy_grantee_id'])) {
                $legacyRoleValues->push((string) $item['legacy_grantee_id']);
            }
            if ($mode === 'company' && !empty($item['legacy_grantee_id']) && is_numeric($item['legacy_grantee_id'])) {
                $companyIds->push((int) $item['legacy_grantee_id']);
            }
            if ($mode === 'staff' && !empty($item['legacy_grantee_id']) && is_numeric($item['legacy_grantee_id'])) {
                $staffIds->push((int) $item['legacy_grantee_id']);
            }
        }

        $companyIdList = $companyIds->unique()->values()->all();
        $entityIdList = $entityIds->unique()->values()->all();
        $roleIdList = $roleIds->unique()->values()->all();
        $staffIdList = $staffIds->unique()->values()->all();

        $companies = $companyIdList
            ? DB::table('egc_company')->where('status', 0)->whereIn('sno', $companyIdList)->get(['sno', 'company_name', 'company_short_name'])->keyBy('sno')
            : collect();

        $entities = $entityIdList
            ? DB::table('egc_entity as e')
                ->leftJoin('egc_company as c', 'c.sno', '=', 'e.company_id')
                ->where('e.status', 0)
                ->whereIn('e.sno', $entityIdList)
                ->get(['e.sno', 'e.entity_name', 'e.company_id', 'c.company_name'])
                ->keyBy('sno')
            : collect();

        $roles = ($roleIdList || $legacyRoleValues->count())
            ? DB::table('egc_user_role as ur')
                ->leftJoin('egc_entity as e', 'e.sno', '=', 'ur.entity_id')
                ->leftJoin('egc_company as c', 'c.sno', '=', 'ur.company_id')
                ->where('ur.status', 0)
                ->where(function ($q) use ($roleIdList, $legacyRoleValues) {
                    if ($roleIdList) {
                        $q->whereIn('ur.sno', $roleIdList);
                    }
                    if ($legacyRoleValues->count()) {
                        if ($roleIdList) {
                            $q->orWhereIn('ur.role_name', $legacyRoleValues->unique()->values()->all());
                        } else {
                            $q->whereIn('ur.role_name', $legacyRoleValues->unique()->values()->all());
                        }
                    }
                })
                ->get(['ur.sno', 'ur.role_name', 'ur.entity_id', 'ur.company_id', 'e.entity_name', 'c.company_name'])
            : collect();

        $staff = $staffIdList
            ? DB::table('egc_staff as s')
                ->leftJoin('egc_entity as e', 'e.sno', '=', 's.entity_id')
                ->leftJoin('egc_company as c', 'c.sno', '=', 's.company_id')
                ->where('s.status', 0)
                ->whereIn('s.sno', $staffIdList)
                ->get(['s.sno', 's.staff_name', 's.staff_id', 's.entity_id', 's.company_id', 'e.entity_name', 'c.company_name'])
                ->keyBy('sno')
            : collect();

        $rolesById = $roles->keyBy('sno');
        $rolesByName = $roles->keyBy(fn ($row) => (string) $row->role_name);

        return $items->map(function ($item) use ($companies, $entities, $rolesById, $rolesByName, $staff) {
            $mode = (string) ($item['audience_mode'] ?? '');
            $meta = is_array($item['audience'] ?? null) ? $item['audience'] : [];
            $details = [];

            if ($mode === 'company') {
                $ids = (array) ($meta['company_ids'] ?? []);
                $details = in_array('all', $ids, true)
                    ? ['All companies']
                    : collect($ids)->map(fn ($id) => $companies[(int) $id]->company_name ?? 'Elysium Groups')->values()->all();
            } elseif ($mode === 'entity') {
                $ids = (array) ($meta['entity_ids'] ?? []);
                $details = in_array('all', $ids, true)
                    ? ['All entities']
                    : collect($ids)->map(fn ($id) => $entities[(int) $id]->entity_name ?? 'Entity')->values()->all();
            } elseif ($mode === 'role') {
                $entityText = collect((array) ($meta['entity_ids'] ?? []))->map(fn ($id) => $id === 'all' ? 'All entities' : ($id === 0 ? 'General' : ($entities[(int) $id]->entity_name ?? 'Entity')))->values()->all();
                $roleText = collect((array) ($meta['role_ids'] ?? []))->map(fn ($id) => $id === 'all' ? 'All roles' : ($rolesById[(int) $id]->role_name ?? ($rolesByName[(string) $id]->role_name ?? 'Role')))->values()->all();
                $details = array_merge($entityText, $roleText);
            } elseif ($mode === 'staff') {
                $entityText = collect((array) ($meta['entity_ids'] ?? []))->map(fn ($id) => $id === 'all' ? 'All entities' : ($id === 0 ? 'General' : ($entities[(int) $id]->entity_name ?? 'Entity')))->values()->all();
                $staffText = collect((array) ($meta['staff_ids'] ?? []))->map(fn ($id) => $staff[(int) $id]->staff_name ?? 'Staff')->values()->all();
                $details = array_merge($entityText, $staffText);
            }

            $item['audience'] = $meta;
            $item['audience']['details'] = array_values(array_filter(array_map('strval', $details)));
            $item['label'] = $this->audienceLabel($meta);
            return $item;
        })->all();
    }

    private function requireStepUp(Request $request): void
    {
        $validUntil = (int) session('egc_tool_stepup_until', 0);
        if ($validUntil >= now()->timestamp) {
            return;
        }

        $request->validate([
            'stepup_password' => ['required', 'string', 'max:255'],
        ]);

        $user = $request->user();
        abort_unless($user && !empty($user->password), 403, 'Step-up verification is unavailable.');
        abort_unless(Hash::check($request->input('stepup_password'), $user->password), 403, 'Invalid step-up credential.');

        session(['egc_tool_stepup_until' => now()->addMinutes(5)->timestamp]);
    }
}
