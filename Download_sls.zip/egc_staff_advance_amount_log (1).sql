-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2026 at 03:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_staff_advance_amount_log`
--

CREATE TABLE `egc_staff_advance_amount_log` (
  `sno` bigint(20) NOT NULL,
  `month` tinyint(4) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `entity_id` int(11) DEFAULT 0,
  `job_role_id` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  `staff_id` bigint(20) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT 0.00,
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `status` int(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `egc_staff_advance_amount_log`
--

INSERT INTO `egc_staff_advance_amount_log` (`sno`, `month`, `year`, `entity_id`, `job_role_id`, `role_id`, `staff_id`, `total_amount`, `remarks`, `created_at`, `updated_at`, `created_by`, `updated_by`, `status`) VALUES
(1, 7, '2026', 0, NULL, NULL, 122, 6000.00, NULL, '2026-07-31 17:25:16', '2026-07-31 17:25:16', 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_staff_advance_amount_log`
--
ALTER TABLE `egc_staff_advance_amount_log`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_staff_advance_amount_log`
--
ALTER TABLE `egc_staff_advance_amount_log`
  MODIFY `sno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
