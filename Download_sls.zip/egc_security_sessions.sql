-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2026 at 03:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_security_sessions`
--

CREATE TABLE `egc_security_sessions` (
  `sno` bigint(20) UNSIGNED NOT NULL,
  `session_uuid` char(36) NOT NULL,
  `module_id` bigint(20) UNSIGNED NOT NULL,
  `record_id` bigint(20) UNSIGNED NOT NULL,
  `requested_staff_id` bigint(20) UNSIGNED NOT NULL,
  `verified_staff_id` bigint(20) UNSIGNED DEFAULT NULL,
  `device_id` bigint(20) UNSIGNED DEFAULT NULL,
  `qr_token` varchar(255) NOT NULL,
  `pin_hash` varchar(255) DEFAULT NULL,
  `pin_attempts` int(11) NOT NULL DEFAULT 0,
  `generated_at` datetime NOT NULL,
  `qr_expires_at` datetime NOT NULL,
  `pin_generated_at` datetime DEFAULT NULL,
  `pin_expires_at` datetime DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `access_expires_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `status` enum('CREATED','SCANNED','PIN_GENERATED','VERIFIED','EXPIRED','FAILED','CLOSED') NOT NULL DEFAULT 'CREATED',
  `ip_address` varchar(100) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_security_sessions`
--
ALTER TABLE `egc_security_sessions`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `uk_session_uuid` (`session_uuid`),
  ADD KEY `idx_module_record` (`module_id`,`record_id`),
  ADD KEY `idx_status` (`status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_security_sessions`
--
ALTER TABLE `egc_security_sessions`
  MODIFY `sno` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `egc_security_sessions`
--
ALTER TABLE `egc_security_sessions`
  ADD CONSTRAINT `fk_session_module` FOREIGN KEY (`module_id`) REFERENCES `egc_security_modules` (`sno`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
