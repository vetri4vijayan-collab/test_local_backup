import { Navigate } from "react-router-dom";
import VendorLogin from "../pages/VendorLogin";
import VendorTermsAcceptance from "../pages/VendorTermsAcceptance";
import VendorSummary from "../components/vendor_dashboard/vendor_summary";
import VendorNotifications from "../pages/VendorNotifications";
import VendorModulePlaceholder from "../pages/VendorModulePlaceholder";

export const routes = [
    { path: "/", element: <Navigate to="/vendor-login" replace />, layout: "blank" },
    { path: "/vendor-login", element: <VendorLogin />, layout: "blank" },
    {
        path: "/vendor_terms",
        element: <VendorTermsAcceptance />,
        layout: "blank",
        auth: true,
    },
    {
        path: "/vendor_dashboard",
        element: <VendorSummary />,
        layout: "default",
        auth: true,
    },
    {
        path: "/notifications",
        element: <VendorNotifications />,
        layout: "default",
        auth: true,
    },
    {
        path: "/bids-proposals",
        element: (
            <VendorModulePlaceholder
                title="Bids & Proposals"
                description="Vendor quotations, bid submissions, proposal revisions and status tracking."
            />
        ),
        layout: "default",
        auth: true,
    },
    {
        path: "/projects",
        element: (
            <VendorModulePlaceholder
                title="Projects"
                description="Vendor-scoped assigned projects, milestones, documents and progress."
            />
        ),
        layout: "default",
        auth: true,
    },
    {
        path: "/projects/project_details/:projectId",
        element: (
            <VendorModulePlaceholder
                title="Project Details"
                description="Vendor access to the selected project will be connected to the shared project APIs."
            />
        ),
        layout: "default",
        auth: true,
    },
    {
        path: "/tasks",
        element: (
            <VendorModulePlaceholder
                title="My Tasks"
                description="Vendor-scoped tasks, deadlines, deliverables and status updates."
            />
        ),
        layout: "default",
        auth: true,
    },
    {
        path: "/user_management",
        element: (
            <VendorModulePlaceholder
                title="User Management"
                description="Vendor administrators will manage users belonging only to their own vendor account."
            />
        ),
        layout: "default",
        auth: true,
    },
    {
        path: "/settings/roles_permissions",
        element: (
            <VendorModulePlaceholder
                title="Roles & Permissions"
                description="Vendor-admin role and permission management will be scoped to the vendor account."
            />
        ),
        layout: "default",
        auth: true,
    },
    { path: "*", element: <Navigate to="/vendor_dashboard" replace />, layout: "default", auth: true },
];
