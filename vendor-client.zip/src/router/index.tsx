import { createBrowserRouter, Navigate } from "react-router-dom";
import BlankLayout from "../components/Layouts/BlankLayout";
import VendorDefaultLayout from "../components/Layouts/VendorDefaultLayout";
import ProtectedRoute from "../auth/ProtectedRoute";
import App from "../App";
import { routes } from "./routes";

const router = createBrowserRouter(
    routes.map((route: any) => {
        const protectedElement = route.auth ? (
            <ProtectedRoute>{route.element}</ProtectedRoute>
        ) : (
            route.element
        );

        return {
            ...route,
            element:
                route.layout === "blank" ? (
                    <BlankLayout>{protectedElement}</BlankLayout>
                ) : (
                    <VendorDefaultLayout>{protectedElement}</VendorDefaultLayout>
                ),
        };
    }),
);

export default router;
