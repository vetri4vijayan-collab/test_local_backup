import { PropsWithChildren, Suspense, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import App from "../../App";
import { IRootState } from "../../store";
import { toggleSidebar } from "../../store/themeConfigSlice";
import VendorHeader from "./VendorHeader";
import VendorSidebar from "./VendorSidebar";
import Footer from "./Footer";

export default function VendorDefaultLayout({ children }: PropsWithChildren) {
    const themeConfig = useSelector((state: IRootState) => state.themeConfig);
    const dispatch = useDispatch();
    const [showLoader, setShowLoader] = useState(true);

    useEffect(() => {
        const handler = () => undefined;
        window.addEventListener("scroll", handler);

        const screenLoader = document.getElementsByClassName("screen_loader");
        if (screenLoader?.length) {
            screenLoader[0].classList.add("animate__fadeOut");
            const timer = window.setTimeout(() => setShowLoader(false), 200);
            return () => {
                clearTimeout(timer);
                window.removeEventListener("scroll", handler);
            };
        }

        setShowLoader(false);
        return () => window.removeEventListener("scroll", handler);
    }, []);

    return (
        <App>
            <div className="relative">
                <div
                    className={`${(!themeConfig.sidebar && "hidden") || ""} fixed inset-0 z-50 bg-black/60 lg:hidden`}
                    onClick={() => dispatch(toggleSidebar())}
                />
                {showLoader && (
                    <div className="screen_loader fixed inset-0 z-[60] grid place-content-center bg-[#fafafa] dark:bg-[#060818]">
                        <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary/20 border-t-primary" aria-label="Loading" />
                    </div>
                )}

                <div className={`${themeConfig.navbar} main-container min-h-screen text-black dark:text-white-dark`}>
                    <VendorSidebar />
                    <div className="main-content flex min-h-screen flex-col">
                        <VendorHeader />
                        <Suspense fallback={<div className="p-6 text-sm text-slate-500">Loading…</div>}>
                            <main className={`${themeConfig.animation} min-h-0 flex-1 p-6 animate__animated`}>
                                {children}
                            </main>
                        </Suspense>
                        <Footer />
                    </div>
                </div>
            </div>
        </App>
    );
}
