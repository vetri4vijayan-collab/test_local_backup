import { useEffect, useMemo, useState } from "react";
import { BellIcon, XCircleIcon, SignOutIcon } from "@phosphor-icons/react";
import { Link, useLocation } from "react-router-dom";
import api from "../../api/axios";
import { useAuth } from "../../auth/AuthProvider";
import logo from "../../assets/img/logo.png";

type VendorNotification = {
    id: string;
    eventType: string;
    title: string;
    message: string;
    readAt?: string | null;
    createdAt?: string | null;
};

export default function VendorHeader() {
    const { user, signOut } = useAuth();
    const location = useLocation();
    const [notifications, setNotifications] = useState<VendorNotification[]>([]);
    const [notificationsOpen, setNotificationsOpen] = useState(false);
    const [loadingNotifications, setLoadingNotifications] = useState(false);

    const displayName =
        user?.displayName?.trim() ||
        user?.email?.split("@")[0] ||
        "Vendor";
    const email = user?.email || "";

    const initials = useMemo(
        () =>
            displayName
                .split(/\s+/)
                .filter(Boolean)
                .slice(0, 2)
                .map((part) => part.charAt(0))
                .join("")
                .toUpperCase() || "V",
        [displayName],
    );

    const profileImageUrl = user?.profileImage && user.id
        ? `${String(api.defaults.baseURL || "").replace(/\/+$/, "")}/users/${encodeURIComponent(user.id)}/avatar?ts=${encodeURIComponent(user.profileImage.uploadedAt || "current")}`
        : null;

    const notificationTime = (value?: string | null) => {
        if (!value) return "";
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return "";
        const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
        if (seconds < 60) return "Just now";
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes}m ago`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours}h ago`;
        const days = Math.floor(hours / 24);
        if (days < 7) return `${days}d ago`;
        return date.toLocaleDateString();
    };

    const loadNotifications = async () => {
        if (!user?.id) return;
        setLoadingNotifications(true);
        try {
            const response = await api.get("/vendor-portal/notifications", {
                params: { limit: 20, unreadOnly: true },
            });
            if (response.data?.success === true) {
                setNotifications(Array.isArray(response.data?.data) ? response.data.data : []);
            }
        } finally {
            setLoadingNotifications(false);
        }
    };

    useEffect(() => {
        void loadNotifications();
        const interval = window.setInterval(() => void loadNotifications(), 30000);
        return () => window.clearInterval(interval);
    }, [user?.id, location.pathname]);

    const markRead = async (id: string) => {
        try {
            await api.patch(`/vendor-portal/notifications/${id}/read`);
        } finally {
            setNotifications((current) => current.filter((item) => item.id !== id));
        }
    };

    const markAllRead = async () => {
        try {
            await api.patch("/vendor-portal/notifications/read-all");
        } finally {
            setNotifications([]);
        }
    };

    return (
        <header className="z-40">
            <div className="shadow-sm">
                <div className="relative flex w-full items-center bg-white px-5 py-2.5 dark:bg-black">
                    <div className="flex items-center gap-2 lg:hidden">
                        <Link to="/vendor_dashboard" className="flex items-center shrink-0">
                            <img src={logo} className="h-8 w-auto" alt="ARGUS" />
                        </Link>
                    </div>

                    <div className="ml-auto flex items-center gap-3">
                        <div className="relative">
                            <button
                                type="button"
                                aria-label="Notifications"
                                onClick={() => {
                                    setNotificationsOpen((value) => !value);
                                    if (!notificationsOpen) void loadNotifications();
                                }}
                                className="relative flex h-10 w-10 items-center justify-center rounded-full p-2 transition hover:bg-slate-100"
                            >
                                <BellIcon size={21} />
                                {notifications.length > 0 && (
                                    <span className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full bg-success ring-2 ring-white" />
                                )}
                            </button>

                            {notificationsOpen && (
                                <>
                                    <button
                                        type="button"
                                        aria-label="Close notifications"
                                        className="fixed inset-0 z-40 cursor-default"
                                        onClick={() => setNotificationsOpen(false)}
                                    />
                                    <div className="absolute right-0 z-50 mt-2 w-[320px] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl sm:w-[380px]">
                                        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
                                            <div>
                                                <h4 className="text-sm font-bold text-slate-800">Notifications</h4>
                                                <p className="text-[11px] text-slate-400">
                                                    {loadingNotifications ? "Refreshing..." : `${notifications.length} unread`}
                                                </p>
                                            </div>
                                            {notifications.length > 0 && (
                                                <button
                                                    type="button"
                                                    onClick={() => void markAllRead()}
                                                    className="text-xs font-semibold text-primary hover:underline"
                                                >
                                                    Read all
                                                </button>
                                            )}
                                        </div>

                                        {notifications.length ? (
                                            <div className="max-h-[380px] overflow-y-auto">
                                                {notifications.map((notification) => (
                                                    <div key={notification.id} className="group border-b border-slate-100 px-4 py-3 hover:bg-slate-50">
                                                        <div className="flex items-start gap-3">
                                                            <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                                                                <BellIcon size={16} />
                                                            </div>
                                                            <div className="min-w-0 flex-1">
                                                                <div className="flex items-start gap-2">
                                                                    <div className="min-w-0 flex-1">
                                                                        <div className="text-xs font-bold text-slate-800">{notification.title}</div>
                                                                        <div className="mt-0.5 text-xs leading-5 text-slate-500">{notification.message}</div>
                                                                        <div className="mt-1 text-[10px] text-slate-400">{notificationTime(notification.createdAt)}</div>
                                                                    </div>
                                                                    <button
                                                                        type="button"
                                                                        title="Mark as read"
                                                                        className="text-slate-300 opacity-0 transition group-hover:opacity-100 hover:text-red-600"
                                                                        onClick={() => void markRead(notification.id)}
                                                                    >
                                                                        <XCircleIcon size={17} />
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        ) : (
                                            <div className="flex min-h-[180px] items-center justify-center px-6 text-center text-xs text-slate-400">
                                                No new notifications.
                                            </div>
                                        )}
                                    </div>
                                </>
                            )}
                        </div>

                        <div className="h-10 w-px bg-slate-200" />

                        <div className="flex items-center gap-2">
                            <div className="flex max-w-[220px] flex-col items-end">
                                <div className="truncate text-sm font-semibold text-slate-800">{displayName}</div>
                                <div className="truncate text-[11px] text-slate-400">{email}</div>
                            </div>

                            {profileImageUrl ? (
                                <img
                                    src={profileImageUrl}
                                    alt={`${displayName} profile`}
                                    className="h-9 w-9 rounded-full object-cover ring-1 ring-slate-200"
                                />
                            ) : (
                                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary ring-1 ring-primary/10">
                                    {initials}
                                </div>
                            )}

                            <button
                                type="button"
                                title="Logout"
                                className="text-primary transition hover:text-secondary"
                                onClick={() => void signOut()}
                            >
                                <SignOutIcon size={19} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
}
