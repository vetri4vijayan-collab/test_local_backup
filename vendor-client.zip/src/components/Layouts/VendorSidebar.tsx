import { useEffect, useState } from "react";
import PerfectScrollbar from "react-perfect-scrollbar";
import { NavLink, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
    BellIcon,
    CaretDoubleLeftIcon,
    ChartBarIcon,
    ClipboardTextIcon,
    FolderOpenIcon,
    GearSixIcon,
    HouseSimpleIcon,
    ListChecksIcon,
    ShieldCheckIcon,
    UserListIcon,
} from "@phosphor-icons/react";
import { IRootState } from "../../store";
import { toggleSidebar } from "../../store/themeConfigSlice";
import logo from "../../assets/img/logo.png";

type MenuItem = {
    label: string;
    icon: React.ElementType;
    url?: string;
    children?: { label: string; url: string; icon: React.ElementType }[];
    matchPaths?: string[];
};

const menuItems: MenuItem[] = [
    { label: "Dashboard", icon: HouseSimpleIcon, url: "/vendor_dashboard" },
    { label: "Notifications", icon: BellIcon, url: "/notifications" },
    { label: "Quotations", icon: ClipboardTextIcon, url: "/bids-proposals" },
    { label: "Projects", icon: FolderOpenIcon, url: "/projects" },
    { label: "My Tasks", icon: ListChecksIcon, url: "/tasks" },
    { label: "User Management", icon: UserListIcon, url: "/user_management" },
    {
        label: "Settings",
        icon: GearSixIcon,
        url: "/settings/roles_permissions",
        matchPaths: ["/settings"],
        children: [
            {
                label: "Roles & Permissions",
                url: "/settings/roles_permissions",
                icon: ShieldCheckIcon,
            },
        ],
    },
];

export default function VendorSidebar() {
    const themeConfig = useSelector((state: IRootState) => state.themeConfig);
    const semidark = themeConfig.semidark;
    const location = useLocation();
    const dispatch = useDispatch();
    const [settingsOpen, setSettingsOpen] = useState(location.pathname.startsWith("/settings"));

    useEffect(() => {
        if (location.pathname.startsWith("/settings")) setSettingsOpen(true);
        if (window.innerWidth < 1024 && themeConfig.sidebar) dispatch(toggleSidebar());
    }, [location.pathname]);

    const isActive = (item: MenuItem) => {
        const candidates = item.matchPaths?.length ? item.matchPaths : item.url ? [item.url] : [];
        return candidates.some((path) => location.pathname === path || location.pathname.startsWith(`${path}/`));
    };

    return (
        <div className={semidark ? "dark" : ""}>
            <nav className={`sidebar fixed bottom-0 left-0 top-0 z-50 h-full w-[260px] shadow-[5px_0_25px_0_rgba(94,92,154,0.1)] transition-all duration-300 ${semidark ? "text-white-dark" : ""}`}>
                <div className="h-full bg-secondary dark:bg-black">
                    <div className="flex items-center justify-between px-4 py-3">
                        <NavLink to="/vendor_dashboard" className="main-logo flex shrink-0 items-center rounded-xl bg-white px-4 py-1">
                            <img className="ml-[5px] w-8 flex-none" src={logo} alt="ARGUS" />
                            <span className="align-middle text-2xl font-bold text-primary ltr:ml-1.5 lg:inline dark:text-white-light">
                                ARGUS
                            </span>
                        </NavLink>
                        <button
                            type="button"
                            className="collapse-icon flex h-5 w-5 items-center rounded-full text-white transition hover:bg-gray-500/10 dark:text-white-light"
                            onClick={() => dispatch(toggleSidebar())}
                            aria-label="Collapse sidebar"
                        >
                            <CaretDoubleLeftIcon size={20} className="m-auto" />
                        </button>
                    </div>

                    <PerfectScrollbar className="relative h-[calc(100vh-80px)]">
                        <ul className="space-y-0.5 p-4 font-semibold">
                            {menuItems.map((item) => {
                                const Icon = item.icon;
                                const active = isActive(item);
                                const hasChildren = Boolean(item.children?.length);

                                return (
                                    <li className="nav-item" key={item.label}>
                                        {hasChildren ? (
                                            <>
                                                <button
                                                    type="button"
                                                    className={`nav-link group w-full ${active ? "active" : ""}`}
                                                    onClick={() => setSettingsOpen((value) => !value)}
                                                >
                                                    <div className="flex items-center">
                                                        <Icon className="shrink-0 group-hover:!text-white" />
                                                        <span className="ltr:pl-3 rtl:pr-3 text-slate-400 group-hover:text-white dark:text-[#506690] dark:group-hover:text-white-dark">
                                                            {item.label}
                                                        </span>
                                                    </div>
                                                </button>
                                                {settingsOpen && (
                                                    <ul className="sub-menu space-y-0.5">
                                                        {item.children?.map((child) => {
                                                            const ChildIcon = child.icon;
                                                            return (
                                                                <li key={child.url}>
                                                                    <NavLink
                                                                        to={child.url}
                                                                        className={({ isActive: childActive }) => `${childActive ? "active" : ""}`}
                                                                    >
                                                                        <ChildIcon size={18} />
                                                                        <span className="ltr:ml-2 rtl:mr-2">{child.label}</span>
                                                                    </NavLink>
                                                                </li>
                                                            );
                                                        })}
                                                    </ul>
                                                )}
                                            </>
                                        ) : (
                                            <NavLink
                                                to={item.url || "#"}
                                                className={`nav-link group w-full ${active ? "active" : ""}`}
                                            >
                                                <div className="flex items-center">
                                                    <Icon className="shrink-0 group-hover:!text-white" />
                                                    <span className="ltr:pl-3 rtl:pr-3 text-slate-400 group-hover:text-white dark:text-[#506690] dark:group-hover:text-white-dark">
                                                        {item.label}
                                                    </span>
                                                </div>
                                            </NavLink>
                                        )}
                                    </li>
                                );
                            })}
                        </ul>
                    </PerfectScrollbar>
                </div>
            </nav>
        </div>
    );
}
