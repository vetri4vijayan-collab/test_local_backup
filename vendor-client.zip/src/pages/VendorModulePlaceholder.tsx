import { ArrowRightIcon } from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";

interface Props {
    title: string;
    description: string;
}

export default function VendorModulePlaceholder({ title, description }: Props) {
    const navigate = useNavigate();
    return (
        <div className="space-y-5">
            <div>
                <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
                <p className="mt-1 text-sm text-slate-500">{description}</p>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <ArrowRightIcon size={22} />
                </div>
                <h2 className="mt-4 text-base font-bold text-slate-800">Vendor module shell is ready</h2>
                <p className="mx-auto mt-1 max-w-xl text-sm leading-6 text-slate-500">
                    This route is isolated to the vendor portal. Its production API integration is being implemented
                    one module at a time against the shared ARGUS backend, without using mock business data.
                </p>
                <button
                    type="button"
                    onClick={() => navigate("/vendor_dashboard")}
                    className="mt-5 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-white hover:opacity-90"
                >
                    Back to Dashboard
                </button>
            </div>
        </div>
    );
}
