import { useCallback, useEffect, useState } from "react";
import { BellIcon, ArrowClockwiseIcon, CheckCircleIcon } from "@phosphor-icons/react";
import api from "../api/axios";

type NotificationItem = {
    id: string;
    eventType: string;
    title: string;
    message: string;
    readAt?: string | null;
    createdAt?: string | null;
};

export default function VendorNotifications() {
    const [items, setItems] = useState<NotificationItem[]>([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState("");

    const load = useCallback(async (refresh = false) => {
        setError("");
        if (refresh) setRefreshing(true);
        else setLoading(true);
        try {
            const response = await api.get("/vendor-portal/notifications", {
                params: { limit: 100, unreadOnly: false },
            });
            if (response.data?.success !== true) {
                throw new Error(response.data?.message || "Unable to load notifications.");
            }
            setItems(Array.isArray(response.data?.data) ? response.data.data : []);
            setUnreadCount(Number(response.data?.unreadCount || 0));
        } catch (requestError: any) {
            setError(requestError?.response?.data?.message || requestError?.message || "Unable to load notifications.");
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    useEffect(() => {
        void load();
    }, [load]);

    const markAll = async () => {
        try {
            await api.patch("/vendor-portal/notifications/read-all");
            await load(true);
        } catch (requestError: any) {
            setError(requestError?.response?.data?.message || requestError?.message || "Unable to update notifications.");
        }
    };

    const markOne = async (id: string) => {
        try {
            await api.patch(`/vendor-portal/notifications/${id}/read`);
            await load(true);
        } catch (requestError: any) {
            setError(requestError?.response?.data?.message || requestError?.message || "Unable to update notification.");
        }
    };

    return (
        <div className="space-y-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">Notifications</h1>
                    <p className="mt-1 text-sm text-slate-500">Vendor-scoped messages from the ARGUS workspace.</p>
                </div>
                <div className="flex items-center gap-2">
                    <button type="button" onClick={() => void load(true)} disabled={loading || refreshing} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-60">
                        <ArrowClockwiseIcon size={15} />
                        Refresh
                    </button>
                    <button type="button" onClick={() => void markAll()} disabled={!unreadCount || loading} className="inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50">
                        <CheckCircleIcon size={15} />
                        Mark all read
                    </button>
                </div>
            </div>

            {error && <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}

            <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                {loading ? (
                    <div className="px-5 py-12 text-center text-sm text-slate-500">Loading notifications…</div>
                ) : items.length === 0 ? (
                    <div className="px-5 py-12 text-center text-sm text-slate-500">
                        <BellIcon size={26} className="mx-auto mb-2 text-slate-300" />
                        No notifications.
                    </div>
                ) : (
                    <div className="divide-y divide-slate-100">
                        {items.map((item) => (
                            <div key={item.id} className="flex items-start gap-3 px-5 py-4 hover:bg-slate-50">
                                <div className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${item.readAt ? "bg-slate-100 text-slate-400" : "bg-primary/10 text-primary"}`}>
                                    <BellIcon size={18} />
                                </div>
                                <div className="min-w-0 flex-1">
                                    <div className="flex items-start justify-between gap-3">
                                        <div>
                                            <h2 className="text-sm font-semibold text-slate-800">{item.title}</h2>
                                            <p className="mt-1 text-sm leading-6 text-slate-500">{item.message}</p>
                                            <p className="mt-1 text-[11px] text-slate-400">{item.createdAt ? new Date(item.createdAt).toLocaleString() : ""}</p>
                                        </div>
                                        {!item.readAt && (
                                            <button type="button" onClick={() => void markOne(item.id)} className="shrink-0 text-xs font-semibold text-primary hover:underline">
                                                Mark read
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}
