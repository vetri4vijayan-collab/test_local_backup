
import axios, {
    AxiosError,
    AxiosInstance,
    AxiosRequestConfig,
    InternalAxiosRequestConfig,
} from "axios";

/*
|--------------------------------------------------------------------------
| Environment
|--------------------------------------------------------------------------
|
| Expected frontend environment variable:
|
| VITE_API_URL=http://localhost:3000/api/v1
|
| Production example:
|
| VITE_API_URL=https://api.example.com/api/v1
|
| The backend should expose its API under /api/v1.
|--------------------------------------------------------------------------
*/

const configuredBaseUrl = String(
    import.meta.env.VITE_API_URL || "",
).trim();

/*
|--------------------------------------------------------------------------
| Base URL Normalization
|--------------------------------------------------------------------------
*/

function normalizeBaseUrl(
    value: string,
): string {
    const fallback =
        "http://localhost:3000/api/v1";

    const base =
        (value || fallback).replace(
            /\/+$/,
            "",
        );

    return base;
}

function resolveRuntimeApiBaseUrl(value: string): string {
    const base = normalizeBaseUrl(value);

    // During local/Vite development, keep the API on the same host
    // that serves the frontend. This is critical for HttpOnly cookies:
    // localhost -> localhost:3000, LAN IP -> LAN IP:3000.
    if (import.meta.env.DEV && typeof window !== "undefined") {
        try {
            const url = new URL(base);
            const browserHost = window.location.hostname;

            if (browserHost) {
                url.hostname = browserHost;
            }

            return url.toString().replace(/\/$/, "");
        } catch {
            // Fall back to the configured value below.
        }
    }

    return base;
}

const API_BASE_URL =
    resolveRuntimeApiBaseUrl(
        configuredBaseUrl,
    );

/*
|--------------------------------------------------------------------------
| Axios Instance
|--------------------------------------------------------------------------
*/

const api: AxiosInstance =
    axios.create({
        baseURL: API_BASE_URL,

        timeout: 30000,

        withCredentials: true,

        headers: {
            Accept:
                "application/json",
        },

        /*
         * Do not hard-code Content-Type globally.
         *
         * Axios will automatically set the correct multipart boundary
         * for FormData requests.
         */
    });

/*
|--------------------------------------------------------------------------
| Token Helpers
|--------------------------------------------------------------------------
*/

const ACCESS_TOKEN_KEYS = [
    "argus_access_token",
    "accessToken",
    "token",
] as const;

const REFRESH_TOKEN_KEYS = [
    "argus_refresh_token",
    "refreshToken",
] as const;

function getStoredToken(
    keys: readonly string[],
): string | null {
    if (
        typeof window ===
        "undefined"
    ) {
        return null;
    }

    for (const key of keys) {
        const value =
            window.localStorage.getItem(
                key,
            );

        if (
            value &&
            value.trim()
        ) {
            return value.trim();
        }
    }

    return null;
}

function getAccessToken():
    | string
    | null {
    return getStoredToken(
        ACCESS_TOKEN_KEYS,
    );
}

function getRefreshToken():
    | string
    | null {
    return getStoredToken(
        REFRESH_TOKEN_KEYS,
    );
}

function setAccessToken(
    token: string,
): void {
    if (
        typeof window ===
        "undefined"
    ) {
        return;
    }

    /*
     * Keep the canonical ARGUS key.
     */
    window.localStorage.setItem(
        "argus_access_token",
        token,
    );
}

function setRefreshToken(
    token: string,
): void {
    if (
        typeof window ===
        "undefined"
    ) {
        return;
    }

    window.localStorage.setItem(
        "argus_refresh_token",
        token,
    );
}

function clearStoredAuth():
    void {
    if (
        typeof window ===
        "undefined"
    ) {
        return;
    }

    [
        ...ACCESS_TOKEN_KEYS,
        ...REFRESH_TOKEN_KEYS,
    ].forEach((key) => {
        window.localStorage.removeItem(
            key,
        );
    });
}

/*
|--------------------------------------------------------------------------
| Request ID
|--------------------------------------------------------------------------
*/

function createRequestId():
    string {
    if (
        typeof crypto !==
            "undefined" &&
        typeof crypto.randomUUID ===
            "function"
    ) {
        return crypto.randomUUID();
    }

    return `${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 12)}`;
}

/*
|--------------------------------------------------------------------------
| Request Interceptor
|--------------------------------------------------------------------------
*/

api.interceptors.request.use(
    (
        config: InternalAxiosRequestConfig,
    ) => {
        const accessToken =
            getAccessToken();

        /*
         * Backend supports Bearer authentication.
         *
         * If authentication is instead handled entirely through
         * the HttpOnly access-token cookie, this header simply
         * won't be added.
         */
        if (
            accessToken &&
            !config.headers.Authorization
        ) {
            config.headers.Authorization =
                `Bearer ${accessToken}`;
        }

        /*
         * Useful for backend request tracing.
         */
        if (
            !config.headers[
                "X-Request-ID"
            ]
        ) {
            config.headers[
                "X-Request-ID"
            ] = createRequestId();
        }

        /*
         * API version header.
         */
        if (
            !config.headers[
                "X-API-Version"
            ]
        ) {
            config.headers[
                "X-API-Version"
            ] = "v1";
        }

        /*
         * Axios automatically manages the multipart boundary when
         * FormData is supplied. We intentionally do not set
         * multipart/form-data manually here.
         */

        return config;
    },
    (error) =>
        Promise.reject(error),
);

/*
|--------------------------------------------------------------------------
| Refresh State
|--------------------------------------------------------------------------
*/

let refreshPromise:
    | Promise<string | null>
    | null = null;

let isRedirectingToLogin =
    false;

/*
|--------------------------------------------------------------------------
| Refresh Access Token
|--------------------------------------------------------------------------
*/

async function refreshAccessToken():
    Promise<string | null> {
    if (refreshPromise) {
        return refreshPromise;
    }

    refreshPromise =
        (async () => {
            const refreshToken =
                getRefreshToken();

            /*
             * Backend cookie-based refresh may work without a
             * client-side refresh token.
             *
             * Therefore we still send the request when no
             * local refresh token exists.
             */
            try {
                const response =
                    await axios.post(
                        `${API_BASE_URL}/auth/refresh`,
                        refreshToken
                            ? {
                                  refreshToken,
                              }
                            : {},
                        {
                            timeout: 15000,
                            withCredentials:
                                true,
                            headers: {
                                Accept:
                                    "application/json",
                            },
                        },
                    );

                const payload =
                    response.data;

                const data =
                    payload?.data ??
                    payload;

                const newAccessToken =
                    data?.accessToken ??
                    data?.token ??
                    null;

                const newRefreshToken =
                    data?.refreshToken ??
                    null;

                if (
                    typeof newAccessToken ===
                    "string" &&
                    newAccessToken.trim()
                ) {
                    setAccessToken(
                        newAccessToken.trim(),
                    );
                }

                if (
                    typeof newRefreshToken ===
                    "string" &&
                    newRefreshToken.trim()
                ) {
                    setRefreshToken(
                        newRefreshToken.trim(),
                    );
                }

                return newAccessToken;
            } catch {
                return null;
            } finally {
                refreshPromise = null;
            }
        })();

    return refreshPromise;
}

/*
|--------------------------------------------------------------------------
| Authentication Failure Handling
|--------------------------------------------------------------------------
*/

function redirectToLogin():
    void {
    if (
        typeof window ===
            "undefined" ||
        isRedirectingToLogin
    ) {
        return;
    }

    isRedirectingToLogin =
        true;

    clearStoredAuth();

    /*
     * Preserve the current location so the application can return
     * the user to the same page after authentication.
     */
    const currentPath =
        `${window.location.pathname}${window.location.search}${window.location.hash}`;

    if (
        window.location.pathname === "/" ||
        window.location.pathname === "/login" ||
        window.location.pathname === "/vendor-login"
    ) {
        return;
    }

    const loginPath =
        `/?returnUrl=${encodeURIComponent(
            currentPath,
        )}`;

    window.location.assign(
        loginPath,
    );
}

/*
|--------------------------------------------------------------------------
| Response Interceptor
|--------------------------------------------------------------------------
*/

api.interceptors.response.use(
    (response) => response,

    async (
        error: AxiosError,
    ) => {
        const originalRequest =
            error.config as
                | (AxiosRequestConfig & {
                      _argusRetry?: boolean;
                  })
                | undefined;

        const status =
            error.response?.status;

        /*
         * Do not attempt refresh for:
         *
         * - login
         * - refresh
         * - logout
         *
         * otherwise refresh failures can recurse forever.
         */
        const requestUrl =
            originalRequest?.url || "";

        const isAuthEndpoint =
            requestUrl.includes(
                "/auth/admin/login",
            ) ||
            requestUrl.includes(
                "/auth/vendor/login",
            ) ||
            requestUrl.includes(
                "/auth/login",
            ) ||
            requestUrl.includes(
                "/auth/refresh",
            ) ||
            requestUrl.includes(
                "/auth/logout",
            ) ||
            requestUrl.includes(
                "/auth/me",
            );

        if (
            status === 401 &&
            originalRequest &&
            !originalRequest._argusRetry &&
            !isAuthEndpoint
        ) {
            originalRequest._argusRetry =
                true;

            const newAccessToken =
                await refreshAccessToken();

            if (newAccessToken) {
                originalRequest.headers =
                    originalRequest.headers ||
                    {};

                originalRequest.headers.Authorization =
                    `Bearer ${newAccessToken}`;

                return api.request(
                    originalRequest,
                );
            }

            redirectToLogin();
        }

        return Promise.reject(
            error,
        );
    },
);

/*
|--------------------------------------------------------------------------
| Public API Helpers
|--------------------------------------------------------------------------
*/

export function getApiBaseUrl():
    string {
    return API_BASE_URL;
}

export function getAccessTokenValue():
    | string
    | null {
    return getAccessToken();
}

export function getRefreshTokenValue():
    | string
    | null {
    return getRefreshToken();
}

export function saveAccessToken(
    token: string,
): void {
    setAccessToken(token);
}

export function saveRefreshToken(
    token: string,
): void {
    setRefreshToken(token);
}

export function logoutLocalAuth():
    void {
    clearStoredAuth();
}

/*
|--------------------------------------------------------------------------
| Error Helper
|--------------------------------------------------------------------------
*/

export function getApiErrorMessage(
    error: unknown,
    fallback = "An unexpected error occurred.",
): string {
    if (
        axios.isAxiosError(
            error,
        )
    ) {
        const data =
            error.response?.data as
                | {
                      message?: unknown;
                      error?: {
                          message?: unknown;
                      };
                  }
                | undefined;

        if (
            typeof data?.message ===
            "string"
        ) {
            return data.message;
        }

        if (
            typeof data?.error
                ?.message === "string"
        ) {
            return data.error.message;
        }

        if (
            typeof error.message ===
            "string" &&
            error.message.trim()
        ) {
            return error.message;
        }
    }

    if (
        error instanceof Error &&
        error.message.trim()
    ) {
        return error.message;
    }

    return fallback;
}

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

export default api;