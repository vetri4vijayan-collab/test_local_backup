import { PropsWithChildren } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "./AuthProvider";

export default function ProtectedRoute({ children }: PropsWithChildren) {
    const { loading, isAuthenticated, user } = useAuth();
    const location = useLocation();

    if (loading) {
        return (
            <div className="flex min-h-screen items-center justify-center bg-[#F5F7FA]">
                <div className="rounded-xl bg-white px-5 py-4 text-sm font-medium text-slate-600 shadow-sm">
                    Checking your session…
                </div>
            </div>
        );
    }

    if (!isAuthenticated || String(user?.userType || "").toLowerCase() !== "vendor") {
        const returnUrl = `${location.pathname}${location.search}${location.hash}`;
        return <Navigate to={`/vendor-login?returnUrl=${encodeURIComponent(returnUrl)}`} replace />;
    }

    const requiresTerms = user?.vendorPortalOnboarding?.requiresTermsAcceptance === true;

    if (requiresTerms && location.pathname !== "/vendor_terms") {
        return <Navigate to="/vendor_terms" replace />;
    }

    if (!requiresTerms && location.pathname === "/vendor_terms") {
        return <Navigate to="/vendor_dashboard" replace />;
    }

    return <>{children}</>;
}
