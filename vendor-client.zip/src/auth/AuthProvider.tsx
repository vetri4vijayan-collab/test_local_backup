import {
    createContext,
    PropsWithChildren,
    useCallback,
    useContext,
    useEffect,
    useMemo,
    useState,
} from "react";
import api from "../api/axios";

export interface VendorAuthUser {
    id: string;
    email: string;
    displayName?: string | null;
    profileImage?: {
        mimeType?: string | null;
        extension?: string | null;
        size?: number | null;
        uploadedAt?: string | null;
    } | null;
    userType?: string | null;
    roleId?: string | null;
    vendorId?: string | null;
    status?: string | null;
    vendorPortalOnboarding?: {
        requiresTermsAcceptance?: boolean;
        termsAcceptedAt?: string | null;
        invitationSentAt?: string | null;
    } | null;
}

export interface VendorAuthRole {
    id: string;
    key: string;
    name: string;
    system?: boolean;
    ownerRole?: boolean;
}

interface AuthContextValue {
    user: VendorAuthUser | null;
    role: VendorAuthRole | null;
    permissions: unknown[] | Record<string, unknown>;
    loading: boolean;
    isAuthenticated: boolean;
    signInVendor: (email: string, password: string) => Promise<void>;
    signOut: () => Promise<void>;
    reloadSession: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function readAuthPayload(response: any) {
    const data = response?.data?.data ?? response?.data ?? {};
    return {
        user: data.user ?? null,
        role: data.role ?? null,
        permissions: data.permissions ?? [],
    };
}

function getErrorMessage(error: any) {
    return error?.response?.data?.message || error?.message || "Authentication failed.";
}

export function AuthProvider({ children }: PropsWithChildren) {
    const [user, setUser] = useState<VendorAuthUser | null>(null);
    const [role, setRole] = useState<VendorAuthRole | null>(null);
    const [permissions, setPermissions] = useState<unknown[] | Record<string, unknown>>([]);
    const [loading, setLoading] = useState(true);

    const applySession = useCallback((response: any) => {
        const payload = readAuthPayload(response);
        setUser(payload.user);
        setRole(payload.role);
        setPermissions(payload.permissions);
    }, []);

    const clearSession = useCallback(() => {
        setUser(null);
        setRole(null);
        setPermissions([]);
    }, []);

    const reloadSession = useCallback(async () => {
        try {
            const response = await api.get("/auth/me");
            const payload = readAuthPayload(response);
            if (String(payload.user?.userType || "").toLowerCase() !== "vendor") {
                clearSession();
                return false;
            }
            applySession(response);
            return true;
        } catch {
            clearSession();
            return false;
        }
    }, [applySession, clearSession]);

    useEffect(() => {
        let mounted = true;
        (async () => {
            try {
                const response = await api.get("/auth/me");
                const payload = readAuthPayload(response);
                if (
                    mounted &&
                    String(payload.user?.userType || "").toLowerCase() === "vendor"
                ) {
                    applySession(response);
                } else if (mounted) {
                    clearSession();
                }
            } catch {
                if (mounted) clearSession();
            } finally {
                if (mounted) setLoading(false);
            }
        })();
        return () => {
            mounted = false;
        };
    }, [applySession, clearSession]);

    const signInVendor = useCallback(
        async (email: string, password: string) => {
            try {
                const response = await api.post("/auth/vendor/login", {
                    email: email.trim().toLowerCase(),
                    password,
                });
                if (response.data?.success !== true) {
                    throw new Error(response.data?.message || "Unable to sign in.");
                }
                const payload = readAuthPayload(response);
                if (String(payload.user?.userType || "").toLowerCase() !== "vendor") {
                    throw new Error("This account is not a vendor portal account.");
                }
                applySession(response);
            } catch (error) {
                throw new Error(getErrorMessage(error));
            }
        },
        [applySession],
    );

    const signOut = useCallback(async () => {
        try {
            await api.post("/auth/logout");
        } finally {
            clearSession();
            window.location.assign("/vendor-login");
        }
    }, [clearSession]);

    const value = useMemo(
        () => ({
            user,
            role,
            permissions,
            loading,
            isAuthenticated: Boolean(user),
            signInVendor,
            signOut,
            reloadSession,
        }),
        [user, role, permissions, loading, signInVendor, signOut, reloadSession],
    );

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
    const context = useContext(AuthContext);
    if (!context) throw new Error("useAuth must be used inside <AuthProvider />.");
    return context;
}
