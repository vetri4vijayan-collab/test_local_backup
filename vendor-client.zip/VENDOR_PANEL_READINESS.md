# ARGUS Vendor Portal — Initial Production Foundation

Frontend is intentionally separated from the internal/admin client and runs on port 5080.

## Runtime
- Development: `http://localhost:5080`
- Shared backend: `http://localhost:3000/api/v1`
- Vendor authentication: `POST /auth/vendor/login`
- Session validation: `GET /auth/me`
- Telecom Terms: `/vendor_terms`
- Vendor dashboard: `GET /vendor-portal/dashboard`

## Vendor navigation
- Notifications
- Vendor Dashboard
- Quotations → Bids & Proposals
- Projects
- My Tasks
- User Management
- Settings → Roles & Permissions

The navigation is isolated to `userType=vendor`; internal/admin users are not accepted by this application.

## Important current backend gaps
The uploaded shared backend currently has placeholder route modules for:
- quotations
- projects
- tasks
- notifications (internal-only route)

The vendor frontend therefore does not fabricate business data for those modules. Their routes are isolated and ready for the corresponding vendor-scoped APIs to be implemented one module at a time.

The vendor notification endpoints added with this foundation are:
- GET `/vendor-portal/notifications`
- PATCH `/vendor-portal/notifications/:id/read`
- PATCH `/vendor-portal/notifications/read-all`

These use the existing notification collection/service and the authenticated vendor user as recipient scope.

## Security
- Vendor app only accepts authenticated `userType=vendor`.
- Telecom T&C acceptance is enforced before protected vendor modules.
- The frontend still uses the shared hardened Axios client with credentials, bearer-token support, request IDs and refresh handling.
- No vendor business data is mocked in the production foundation.
