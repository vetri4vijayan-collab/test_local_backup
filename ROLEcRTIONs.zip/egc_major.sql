-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2026 at 08:58 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_major`
--

CREATE TABLE `egc_major` (
  `sno` int(11) NOT NULL,
  `qualification_id` int(11) NOT NULL DEFAULT 0,
  `major_name` varchar(250) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `egc_major`
--

INSERT INTO `egc_major` (`sno`, `qualification_id`, `major_name`, `description`, `created_by`, `created_at`, `updated_by`, `updated_at`, `status`) VALUES
(1, 1, 'Bcom(CA)', 'Bcom(CA)', 125, '2025-05-31 05:30:49', 125, '2026-01-12 11:45:41', 0),
(2, 1, 'B.E.', 'Bachelor of Engineering (Theory/Engineering)', 0, '2025-06-06 16:49:38', 0, '2026-01-12 11:45:43', 0),
(3, 2, 'MCA', 'Master of Computer Applications', 0, '2025-06-06 16:51:09', 0, '2026-01-12 11:51:57', 0),
(4, 2, 'M.Sc', 'Master of Science', 0, '2025-06-06 16:51:27', 0, '2026-01-12 11:51:55', 0),
(5, 1, 'B.Sc', 'Bachelor of Science', 0, '2025-06-06 16:51:50', 0, '2026-01-12 11:51:53', 0),
(6, 1, 'BCA', 'Bachelor of Computer Applications', 0, '2025-06-06 16:52:11', 0, '2026-01-12 11:51:49', 0),
(7, 2, 'M.Com', 'Master of Commerce', 0, '2025-06-06 16:52:37', 0, '2026-01-12 11:51:46', 0),
(8, 2, 'M.E', 'Master of Engineering', 0, '2025-07-01 11:37:02', 0, '2026-01-12 11:51:44', 0),
(9, 1, 'B.Tech', 'Bachelor of Technology (Technical/Engineering)', 0, '2025-07-21 14:18:48', 0, '2026-01-12 11:51:42', 0),
(10, 2, 'MBA', 'Master of Business Administration', 0, '2025-08-02 16:43:26', 0, '2026-01-12 11:51:38', 0),
(11, 1, 'B.Com', 'Bachelor of Commerce', 0, '2025-08-20 14:57:08', 0, '2026-01-12 11:51:35', 0),
(12, 1, 'B.A.', 'Bachelor of Arts', 0, '2026-01-10 11:13:15', 0, '2026-01-12 11:51:33', 0),
(13, 1, 'BBA', 'Bachelor of Business Administration', 0, '2026-01-10 11:14:33', 0, '2026-01-12 11:51:30', 0),
(14, 2, 'M.A.', 'Master of Arts', 0, '2026-01-10 12:37:13', 0, '2026-01-12 11:51:28', 0),
(15, 3, 'Ph.D.', 'Doctor of Philosophy', 0, '2026-01-10 12:37:28', 0, '2026-01-12 11:51:25', 0),
(16, 1, 'MBBS', 'Bachelor of Medicine and Bachelor of Surgery', 0, '2026-01-10 12:41:48', 0, '2026-01-12 11:51:22', 0),
(17, 1, 'B.Arch', 'Bachelor of Architecture', 0, '2026-01-10 12:42:08', 0, '2026-01-12 11:51:21', 0),
(18, 1, 'B.Pharm', 'Bachelor of Pharmacy', 0, '2026-01-10 12:42:35', 0, '2026-01-12 11:51:19', 0),
(19, 1, 'B.Ed', 'Bachelor of Education', 0, '2026-01-10 12:42:45', 0, '2026-01-12 11:51:17', 0),
(20, 1, 'LL.B.', 'Bachelor of Laws', 0, '2026-01-10 12:42:56', 0, '2026-01-12 11:51:16', 0),
(21, 2, 'M.Tech', 'Master of Technology', 0, '2026-01-10 12:44:26', 0, '2026-01-12 11:51:14', 0),
(22, 2, 'M.Arch', 'Master of Architecture', 0, '2026-01-10 12:45:33', 0, '2026-01-12 11:51:12', 0),
(23, 2, 'M.Pharm', 'Master of Pharmacy', 0, '2026-01-10 12:45:45', 0, '2026-01-12 11:51:11', 0),
(24, 2, 'M.Ed', 'Master of Education', 0, '2026-01-10 12:46:26', 0, '2026-01-12 11:51:10', 0),
(25, 2, 'LL.M.', 'Master of Laws', 0, '2026-01-10 12:46:42', 0, '2026-01-12 11:51:08', 0),
(26, 2, 'M.Sc. INFORMATION TECHNOLOGY', NULL, 0, '2026-01-12 11:18:54', 0, '2026-01-12 11:51:05', 0),
(27, 2, 'M.Sc. COMPUTER SCIENCE', NULL, 0, '2026-01-12 11:19:06', 0, '2026-01-12 11:51:03', 0),
(28, 2, 'M.Sc. BIOTECHNOLOGY', NULL, 0, '2026-01-12 11:19:21', 0, '2026-01-12 11:51:01', 0),
(29, 2, 'M.Sc. CHEMISTRY', NULL, 0, '2026-01-12 11:19:27', 0, '2026-01-12 11:51:00', 0),
(30, 2, 'M.Sc. PHYSICS', NULL, 0, '2026-01-12 11:19:33', 0, '2026-01-12 11:50:56', 0),
(31, 2, 'M.Sc. STATISTICS', NULL, 0, '2026-01-12 11:19:41', 0, '2026-01-12 11:50:58', 0),
(32, 2, 'M.Sc. MATHEMATICS', NULL, 0, '2026-01-12 11:19:49', 0, '2026-01-12 11:50:54', 0),
(33, 2, 'M.COM. COMPUTER APPLICATIONS', NULL, 0, '2026-01-12 11:19:56', 0, '2026-01-12 11:50:53', 0),
(34, 2, 'M.A. ECONOMICS', NULL, 0, '2026-01-12 11:20:23', 0, '2026-01-12 11:50:50', 0),
(35, 2, 'M.A. HISTORY', NULL, 0, '2026-01-12 11:20:31', 0, '2026-01-12 11:50:49', 0),
(36, 2, 'M.A. ENGLISH', NULL, 0, '2026-01-12 11:20:37', 0, '2026-01-12 11:50:48', 0),
(37, 2, 'M.A. TAMIL', NULL, 0, '2026-01-12 11:20:44', 0, '2026-01-12 11:50:46', 0),
(38, 1, 'B.Sc. PHYSICAL EDUCATION', NULL, 0, '2026-01-12 11:20:54', 0, '2026-01-12 11:50:43', 0),
(39, 1, 'B.Sc. BIOCHEMISTRY', NULL, 0, '2026-01-12 11:21:03', 0, '2026-01-12 11:50:41', 0),
(40, 1, 'B.Sc. COMPUTER SCIENCE', NULL, 0, '2026-01-12 11:21:10', 0, '2026-01-12 11:50:38', 0),
(41, 1, 'B.Sc. INFORMATION TECHNOLOGY', NULL, 0, '2026-01-12 11:21:18', 0, '2026-01-12 11:50:36', 0),
(42, 1, 'B.Sc. VISUAL COMMUNICATION', NULL, 0, '2026-01-12 11:21:26', 0, '2026-01-12 11:50:35', 0),
(43, 1, 'B.Sc. PSYCHOLOGY', NULL, 0, '2026-01-12 11:21:33', 0, '2026-01-12 11:50:32', 0),
(44, 1, 'B.Sc. DATA SCIENCE', NULL, 0, '2026-01-12 11:21:41', 0, '2026-01-12 11:50:31', 0),
(45, 1, 'B.Sc. ARTIFICAL INTELLIGENCE', NULL, 0, '2026-01-12 11:21:48', 0, '2026-01-12 11:50:29', 0),
(46, 1, 'B.Sc. INDUSTRIAL CHEMISTRY', NULL, 0, '2026-01-12 11:21:55', 0, '2026-01-12 11:50:27', 0),
(47, 1, 'B.Sc. CHEMISTRY', NULL, 0, '2026-01-12 11:22:02', 0, '2026-01-12 11:50:26', 0),
(48, 1, 'B.Sc. PHYSICS', NULL, 0, '2026-01-12 11:22:08', 0, '2026-01-12 11:50:25', 0),
(49, 1, 'B.Sc. STATISTICS', NULL, 0, '2026-01-12 11:22:17', 0, '2026-01-12 11:50:23', 0),
(50, 1, 'B.Sc. MATHEMATICS', NULL, 0, '2026-01-12 11:22:24', 0, '2026-01-12 11:50:22', 0),
(51, 1, 'B.A. Economics', NULL, 0, '2026-01-12 11:22:31', 0, '2026-01-12 11:50:19', 0),
(52, 1, 'B.A. History', NULL, 0, '2026-01-12 11:22:37', 0, '2026-01-12 11:50:17', 0),
(53, 1, 'B.A. English', NULL, 0, '2026-01-12 11:22:45', 0, '2026-01-12 11:50:14', 0),
(54, 1, 'B.A. Tamil', NULL, 0, '2026-01-12 11:22:52', 0, '2026-01-12 11:50:13', 0),
(55, 2, 'M.E. Biomedical Engineering', NULL, 0, '2026-01-12 11:23:00', 0, '2026-01-12 11:50:10', 0),
(56, 2, 'M.E. Software Engineering', NULL, 0, '2026-01-12 11:23:08', 0, '2026-01-12 11:50:08', 0),
(57, 2, 'M.Tech. Information Technology', NULL, 0, '2026-01-12 11:23:16', 0, '2026-01-12 11:50:06', 0),
(58, 2, 'M.E. Computer Science and Engineering', NULL, 0, '2026-01-12 11:24:08', 0, '2026-01-12 11:50:05', 0),
(59, 2, 'M.E. Structural Engineering', NULL, 0, '2026-01-12 11:24:23', 0, '2026-01-12 11:50:03', 0),
(60, 2, 'M.E. Automobile Engineering', NULL, 0, '2026-01-12 11:24:33', 0, '2026-01-12 11:52:45', 0),
(61, 2, 'M.E. Aeronautical Engineering', NULL, 0, '2026-01-12 11:24:40', 0, '2026-01-12 11:52:50', 0),
(62, 1, 'B.E. Electrical and Electronics Engineering', NULL, 0, '2026-01-12 11:24:50', 0, '2026-01-12 11:52:53', 0),
(63, 1, 'B.E. Biomedical Engineering', NULL, 0, '2026-01-12 11:25:28', 0, '2026-01-12 11:52:57', 0),
(64, 1, 'B.Tech. Biotechnology', NULL, 0, '2026-01-12 11:25:36', 0, '2026-01-12 11:53:02', 0),
(65, 1, 'B.Tech. Food Technology', NULL, 0, '2026-01-12 11:25:44', 0, '2026-01-12 11:53:04', 0),
(66, 1, 'B.Tech. Chemical Engineering', NULL, 0, '2026-01-12 11:25:50', 0, '2026-01-12 11:53:07', 0),
(67, 1, 'B.E Artificial Intelligence and Data Science', NULL, 0, '2026-01-12 11:25:59', 0, '2026-01-12 11:53:09', 0),
(68, 1, 'B.E Artificial Intelligence and Machine Learning', NULL, 0, '2026-01-12 11:26:07', 0, '2026-01-12 11:53:16', 0),
(69, 1, 'B.Tech Information Technology', NULL, 0, '2026-01-12 11:26:14', 0, '2026-01-12 11:53:22', 0),
(70, 1, 'B.E Mechatronics Engineering', NULL, 0, '2026-01-12 11:26:24', 0, '2026-01-12 11:53:26', 0),
(71, 1, 'B.E Aerospace Engineering', NULL, 0, '2026-01-12 11:26:35', 0, '2026-01-12 11:53:29', 0),
(72, 1, 'B.E Mechanical Engineering', NULL, 0, '2026-01-12 11:26:43', 0, '2026-01-12 11:53:32', 0),
(73, 1, 'B.E Automobile Engineering', NULL, 0, '2026-01-12 11:26:51', 0, '2026-01-12 11:53:36', 0),
(74, 1, 'B.E Aeronautical Engineering', NULL, 0, '2026-01-12 11:27:07', 0, '2026-01-12 11:53:40', 0),
(75, 1, 'B.E Civil Engineering', NULL, 0, '2026-01-12 11:27:16', 0, '2026-01-12 11:53:44', 0),
(76, 1, 'B.E Computer Science and Engineering', NULL, 0, '2026-01-12 11:27:29', 0, '2026-01-12 11:53:46', 0),
(77, 1, 'B.E Agriculture Engineering', NULL, 0, '2026-01-12 11:28:07', 0, '2026-01-12 11:53:49', 0),
(78, 1, 'B.E. Electronics and Communication Engineering (ECE)', NULL, 0, '2026-01-12 11:28:07', 0, '2026-01-12 11:53:49', 0),
(79, 1, 'B.E. Electronics and Instrumentation (E&I)', NULL, 0, '2026-01-12 11:28:07', 0, '2026-01-12 11:53:49', 0),
(80, 1, 'B.E. Information Technology (IT)', NULL, 0, '2026-01-12 11:28:07', 0, '2026-01-12 11:53:49', 0),
(81, 1, 'B.E. Food Technology', NULL, 0, '2026-01-12 11:28:07', 0, '2026-01-12 11:53:49', 0),
(82, 1, 'B.Tech  Architecture Engineering', NULL, 0, '2026-01-12 11:28:07', 0, '2026-01-12 11:53:49', 0),
(83, 2, 'Master Of Business Adminstration Hr & Marketing', 'Master Of Business Adminstration HR & Marketing', 0, '2026-04-11 04:46:04', 0, '2026-04-11 04:46:04', 0),
(84, 1, 'Bachelor Of Engineering (eee), Bachelor Of Engineering In Electrical And Electronics Engineering, Bachelor Of Technology, Bachelor Of Technology In Computer Science Engineering, Master Of Business Administration', 'Bachelor of Engineering (EEE), Bachelor of Engineering in Electrical and Electronics Engineering, Bachelor of Technology, Bachelor of Technology in Computer Science Engineering, Master of Business Administration', 0, '2026-04-11 05:47:37', 0, '2026-04-11 06:09:01', 2),
(85, 2, 'Master Of Commerce', 'Master of Commerce', 148, '2026-04-11 08:30:50', 0, '2026-04-11 08:30:50', 0),
(86, 1, 'Bachelor Of Science In Information Technology', 'Bachelor of Science in Information Technology', 148, '2026-04-11 08:31:18', 0, '2026-04-11 08:31:18', 0),
(87, 7, 'Diploma In General Nursing And Midwifery', 'Diploma in General Nursing and Midwifery', 175, '2026-04-11 10:43:27', 0, '2026-04-11 10:43:27', 0),
(88, 2, 'Master Of Computer Applications', 'Master of Computer Applications', 175, '2026-04-11 10:48:33', 0, '2026-04-11 10:48:33', 0),
(89, 1, 'Bachelor Of Commerce', 'Bachelor of Commerce', 175, '2026-04-11 10:56:00', 0, '2026-04-11 10:56:00', 0),
(90, 1, 'Bachelor Of Commerce From Madras University', 'Bachelor of Commerce from Madras university', 148, '2026-04-11 11:00:56', 0, '2026-04-11 11:00:56', 0),
(91, 2, 'Master Of Computer Applications - Kalasalingam University, Krishnan Koil, Srivilliputhur, Tamilnadu-626126', 'Master of Computer Applications - Kalasalingam University, Krishnan Koil, Srivilliputhur, Tamilnadu-626126', 175, '2026-04-11 11:04:50', 0, '2026-04-11 11:04:50', 0),
(92, 1, 'Bachelor Of Commerce Degree, Diploma In Computer Applications, Higher Grade Typewriting, Osha General Industrial Safety And Health Program', 'Bachelor of Commerce degree, Diploma in Computer Applications, Higher Grade Typewriting, OSHA General industrial Safety and Health Program', 175, '2026-04-11 11:22:32', 0, '2026-04-11 11:22:32', 0),
(93, 1, 'Bachelor Of Commerce In Business And Industry', 'Bachelor of Commerce in Business and Industry', 175, '2026-04-11 11:37:18', 0, '2026-04-11 11:37:18', 0),
(94, 2, 'Master Of Business Management', 'Master of Business Management', 175, '2026-04-11 11:39:09', 0, '2026-04-11 11:39:09', 0),
(95, 1, 'Bachelor Of Commerce (b.com)', 'Bachelor Of Commerce (B.Com)', 175, '2026-04-11 11:41:05', 0, '2026-04-11 11:41:05', 0),
(96, 1, 'Bachelor Of Arts In History', 'Bachelor of Arts in History', 175, '2026-04-11 11:54:43', 0, '2026-04-11 11:54:43', 0),
(97, 1, 'Bachelor Of Arts In Journalism And Mass Communication', 'Bachelor of Arts in Journalism and Mass Communication', 175, '2026-04-11 12:03:34', 0, '2026-04-11 12:03:34', 0),
(98, 1, 'Bachelor Of Arts In Economics With Post Graduate Diploma In Management And Marketing', 'Bachelor of Arts in Economics with Post Graduate Diploma in Management and Marketing', 175, '2026-04-11 12:11:38', 0, '2026-04-11 12:11:38', 0),
(99, 3, 'Phd English Literature (in Submission)', 'PHD ENGLISH LITERATURE (IN SUBMISSION)', 198, '2026-05-16 17:28:25', 0, '2026-05-16 11:58:25', 0),
(100, 1, 'B.Tech Information & Communication Technology', NULL, 0, '2026-09-12 11:22:07', 0, '2026-09-12 11:39:40', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_major`
--
ALTER TABLE `egc_major`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_major`
--
ALTER TABLE `egc_major`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
