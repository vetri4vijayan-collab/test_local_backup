-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2026 at 08:58 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_qualification_level`
--

CREATE TABLE `egc_qualification_level` (
  `sno` int(11) NOT NULL,
  `qualification_level_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `is_checked` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `egc_qualification_level`
--

INSERT INTO `egc_qualification_level` (`sno`, `qualification_level_name`, `description`, `created_at`, `created_by`, `updated_at`, `updated_by`, `status`, `is_checked`) VALUES
(1, 'UG', 'Undergraduate', '2026-01-10 11:08:38', 0, '2026-01-10 11:08:38', 0, 0, 1),
(2, 'PG', 'Postgraduate', '2026-01-10 11:08:38', 0, '2026-01-10 11:08:38', 0, 0, 1),
(3, 'Doctorate', 'Doctoral Degree', '2026-01-10 11:08:38', 0, '2026-01-10 11:08:38', 0, 0, 1),
(4, 'HSC', 'Higher Secondary', '2026-01-10 11:08:38', 0, '2026-01-10 11:08:38', 0, 0, 0),
(5, 'SSLC', 'SSLC', '2026-01-10 11:08:38', 0, '2026-01-10 11:08:38', 0, 0, 0),
(6, 'Below SSLC', 'Below SSLC', '2026-01-10 11:08:38', 0, '2026-01-10 11:08:38', 0, 0, 0),
(7, 'Diploma', 'Diploma', '2026-01-10 11:08:38', 0, '2026-01-10 11:08:38', 0, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_qualification_level`
--
ALTER TABLE `egc_qualification_level`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_qualification_level`
--
ALTER TABLE `egc_qualification_level`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
