import { Router } from "express";

import authenticate, {
    requireInternalUser,
} from "../middleware/auth.js";

import authorize from "../middleware/rbac.js";

import * as vendorController from "../controllers/vendor/vendorController.js";
import * as vendorCategoryController from "../controllers/vendor/vendorCategoryController.js";
import * as vendorCurrencyController from "../controllers/vendor/vendorCurrencyController.js";

import vendorPaymentTermRoutes from "./vendorPaymentTerm.routes.js";
import vendorIndustrySectorRoutes from "./vendorIndustrySector.routes.js";
import vendorStatusRoutes from "./vendorStatus.routes.js";

const router = Router();

/*
|--------------------------------------------------------------------------
| Authentication / internal-user guard
|--------------------------------------------------------------------------
|
| All routes under /vendors are internal/admin management APIs.
| Keeping these guards at router level prevents individual endpoints from
| accidentally being exposed without authentication.
|--------------------------------------------------------------------------
*/

router.use(authenticate);
router.use(requireInternalUser);


/*
|--------------------------------------------------------------------------
| Vendor Settings sub-resources
|--------------------------------------------------------------------------
|
| These paths MUST be registered before /:id.
|
| Example:
|   /categories
|   /currencies
|
| If /:id is registered first, Express treats "categories" or "currencies"
| as a vendor ObjectId and the controller returns:
|
|   INVALID_VENDOR_ID
|--------------------------------------------------------------------------
*/

router.use(
    "/payment-terms",
    vendorPaymentTermRoutes,
);

router.use(
    "/industry-sectors",
    vendorIndustrySectorRoutes,
);

router.use(
    "/statuses",
    vendorStatusRoutes,
);


/* -------------------------------------------------------------------------- */
/* Vendor Category Settings                                                   */
/* -------------------------------------------------------------------------- */

const canViewVendorSettings =
    authorize({
        module: "vendor_settings",
        action: "view",
        realms: [
            "admin",
            "internal",
        ],
        userTypes: [
            "admin",
            "internal",
        ],
    });

const canAddVendorSettings =
    authorize({
        module: "vendor_settings",
        action: "add",
        realms: [
            "admin",
            "internal",
        ],
        userTypes: [
            "admin",
            "internal",
        ],
    });

const canEditVendorSettings =
    authorize({
        module: "vendor_settings",
        action: "edit",
        realms: [
            "admin",
            "internal",
        ],
        userTypes: [
            "admin",
            "internal",
        ],
    });

const canDeleteVendorSettings =
    authorize({
        module: "vendor_settings",
        action: "delete",
        realms: [
            "admin",
            "internal",
        ],
        userTypes: [
            "admin",
            "internal",
        ],
    });


/*
 * IMPORTANT:
 *
 * categoryId matches vendorCategoryController.js:
 *
 *   req.params.categoryId
 */
router.get(
    "/categories",
    canViewVendorSettings,
    vendorCategoryController.list,
);

router.get(
    "/categories/:categoryId",
    canViewVendorSettings,
    vendorCategoryController.get,
);

router.post(
    "/categories",
    canAddVendorSettings,
    vendorCategoryController.create,
);

router.patch(
    "/categories/:categoryId",
    canEditVendorSettings,
    vendorCategoryController.update,
);

router.patch(
    "/categories/:categoryId/status",
    canEditVendorSettings,
    vendorCategoryController.status,
);

router.delete(
    "/categories/:categoryId",
    canDeleteVendorSettings,
    vendorCategoryController.remove,
);


/* -------------------------------------------------------------------------- */
/* Vendor Currency Settings                                                   */
/* -------------------------------------------------------------------------- */

/*
 * vendorCurrencyController.js uses req.params.id,
 * therefore currency routes deliberately keep :id.
 */
router.get(
    "/currencies",
    canViewVendorSettings,
    vendorCurrencyController.list,
);

router.get(
    "/currencies/:id",
    canViewVendorSettings,
    vendorCurrencyController.get,
);

router.post(
    "/currencies",
    canAddVendorSettings,
    vendorCurrencyController.create,
);

router.patch(
    "/currencies/:id",
    canEditVendorSettings,
    vendorCurrencyController.update,
);

router.patch(
    "/currencies/:id/status",
    canEditVendorSettings,
    vendorCurrencyController.setStatus,
);

router.delete(
    "/currencies/:id",
    canDeleteVendorSettings,
    vendorCurrencyController.remove,
);


/* -------------------------------------------------------------------------- */
/* Vendor Management                                                         */
/* -------------------------------------------------------------------------- */

const canViewVendor =
    authorize({
        module: "vendors",
        action: "view",
        realms: [
            "admin",
            "internal",
        ],
        userTypes: [
            "admin",
            "internal",
        ],
    });

const canAddVendor =
    authorize({
        module: "vendors",
        action: "add",
        realms: [
            "admin",
            "internal",
        ],
        userTypes: [
            "admin",
            "internal",
        ],
    });

const canEditVendor =
    authorize({
        module: "vendors",
        action: "edit",
        realms: [
            "admin",
            "internal",
        ],
        userTypes: [
            "admin",
            "internal",
        ],
    });

const canDeleteVendor =
    authorize({
        module: "vendors",
        action: "delete",
        realms: [
            "admin",
            "internal",
        ],
        userTypes: [
            "admin",
            "internal",
        ],
    });


/*
|--------------------------------------------------------------------------
| IMPORTANT ROUTE ORDER
|--------------------------------------------------------------------------
|
| Keep the static/settings paths above the generic vendor :id routes.
|
| These generic routes are intentionally LAST because:
|
|   GET /:id
|   PATCH /:id
|   PATCH /:id/status
|   DELETE /:id
|
| would otherwise capture:
|
|   /categories
|   /currencies
|--------------------------------------------------------------------------
*/

router.get(
    "/",
    canViewVendor,
    vendorController.list,
);

router.post(
    "/",
    canAddVendor,
    vendorController.create,
);

router.get(
    "/:id",
    canViewVendor,
    vendorController.get,
);

router.patch(
    "/:id",
    canEditVendor,
    vendorController.update,
);

router.patch(
    "/:id/status",
    canEditVendor,
    vendorController.setStatus,
);

router.delete(
    "/:id",
    canDeleteVendor,
    vendorController.remove,
);


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;
