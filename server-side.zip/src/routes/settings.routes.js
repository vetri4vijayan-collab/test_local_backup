
// src/routes/settings.routes.js

import { Router } from "express";

import companySettingsController from "../controllers/settings/companySettingsController.js";

import authMiddleware from "../middleware/auth.js";
import rbacMiddleware from "../middleware/rbac.js";

import {
    companyLogoUpload,
    companyFaviconUpload,
} from "../middleware/upload.js";

const router = Router();

/*
|--------------------------------------------------------------------------
| Company Information
|--------------------------------------------------------------------------
|
| Mounted by:
|
|   /api/v1/settings
|
| Final endpoints:
|
|   GET    /api/v1/settings/company
|   PATCH  /api/v1/settings/company
|   POST   /api/v1/settings/company/logo
|   DELETE /api/v1/settings/company/logo
|   POST   /api/v1/settings/company/favicon
|   DELETE /api/v1/settings/company/favicon
|   PATCH  /api/v1/settings/company/status
|
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| GET Company Profile
|--------------------------------------------------------------------------
*/

router.get(
    "/company",
    authMiddleware,
    rbacMiddleware({
        module: "company_settings",
        action: "view",
    }),
    companySettingsController.getCompanyProfile,
);

/*
|--------------------------------------------------------------------------
| PATCH Company Profile
|--------------------------------------------------------------------------
*/

router.patch(
    "/company",
    authMiddleware,
    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),
    companySettingsController.updateCompanyProfile,
);

/*
|--------------------------------------------------------------------------
| Upload Company Logo
|--------------------------------------------------------------------------
|
| Multipart field:
|
|   logo
|
|--------------------------------------------------------------------------
*/

router.post(
    "/company/logo",
    authMiddleware,
    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),
    companyLogoUpload,
    companySettingsController.uploadCompanyLogo,
);

/*
|--------------------------------------------------------------------------
| Delete Company Logo
|--------------------------------------------------------------------------
*/

router.delete(
    "/company/logo",
    authMiddleware,
    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),
    companySettingsController.deleteCompanyLogo,
);

/*
|--------------------------------------------------------------------------
| Upload Company Favicon
|--------------------------------------------------------------------------
|
| Multipart field:
|
|   favicon
|
|--------------------------------------------------------------------------
*/

router.post(
    "/company/favicon",
    authMiddleware,
    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),
    companyFaviconUpload,
    companySettingsController.uploadCompanyFavicon,
);

/*
|--------------------------------------------------------------------------
| Delete Company Favicon
|--------------------------------------------------------------------------
*/

router.delete(
    "/company/favicon",
    authMiddleware,
    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),
    companySettingsController.deleteCompanyFavicon,
);

/*
|--------------------------------------------------------------------------
| Company Profile Status
|--------------------------------------------------------------------------
*/

router.patch(
    "/company/status",
    authMiddleware,
    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),
    companySettingsController.updateCompanyStatus,
);

export default router;