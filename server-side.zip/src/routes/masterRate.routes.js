// src/routes/masterRate.routes.js

import { Router } from "express";

import authenticate, {
  requireInternalUser,
} from "../middleware/auth.js";

import authorize from "../middleware/rbac.js";

import { upload } from "../middleware/upload.js";

import categoryController from "../controllers/masterRate/categoryController.js";
import rateController from "../controllers/masterRate/rateController.js";
import rateHistoryController from "../controllers/masterRate/rateHistoryController.js";
import importExportController from "../controllers/masterRate/importExportController.js";

/*
|--------------------------------------------------------------------------
| Router
|--------------------------------------------------------------------------
*/

const router = Router();

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
|
| Master Rate management is an internal/admin capability.
| Vendor users must never be allowed to manage master rates/categories.
|
|--------------------------------------------------------------------------
*/

router.use(authenticate);

router.use(requireInternalUser);

/*
|--------------------------------------------------------------------------
| Permission Middleware
|--------------------------------------------------------------------------
*/

const canView = authorize({
  module: "master_rate",
  action: "view",
  realms: ["admin", "internal"],
  userTypes: ["admin", "internal"],
});

const canAdd = authorize({
  module: "master_rate",
  action: "add",
  realms: ["admin", "internal"],
  userTypes: ["admin", "internal"],
});

const canEdit = authorize({
  module: "master_rate",
  action: "edit",
  realms: ["admin", "internal"],
  userTypes: ["admin", "internal"],
});

const canDelete = authorize({
  module: "master_rate",
  action: "delete",
  realms: ["admin", "internal"],
  userTypes: ["admin", "internal"],
});

/*
|--------------------------------------------------------------------------
| IMPORTANT EXPRESS ROUTE ORDER
|--------------------------------------------------------------------------
|
| Register:
|
|   static routes
|   special routes
|   history routes
|   parameter routes
|
| before `/:id`.
|
|--------------------------------------------------------------------------
*/


/* ==========================================================================
| CATEGORY SETTINGS
========================================================================== */

/*
 * GET /api/master-rates/categories/types
 */
router.get(
  "/categories/types",
  canView,
  categoryController.types,
);

/*
 * GET /api/master-rates/categories/active
 */
router.get(
  "/categories/active",
  canView,
  categoryController.active,
);

/*
 * PATCH /api/master-rates/categories/bulk-status
 */
router.patch(
  "/categories/bulk-status",
  canEdit,
  categoryController.bulkStatus,
);

/*
 * GET /api/master-rates/categories
 */
router.get(
  "/categories",
  canView,
  categoryController.list,
);

/*
 * POST /api/master-rates/categories
 */
router.post(
  "/categories",
  canAdd,
  categoryController.create,
);

/*
 * GET /api/master-rates/categories/:id
 */
router.get(
  "/categories/:id",
  canView,
  categoryController.get,
);

/*
 * PATCH /api/master-rates/categories/:id
 */
router.patch(
  "/categories/:id",
  canEdit,
  categoryController.update,
);

/*
 * PATCH /api/master-rates/categories/:id/status
 */
router.patch(
  "/categories/:id/status",
  canEdit,
  categoryController.setStatus,
);

/*
 * DELETE /api/master-rates/categories/:id
 */
router.delete(
  "/categories/:id",
  canDelete,
  categoryController.remove,
);


/* ==========================================================================
| MASTER RATE IMPORT / EXPORT
========================================================================== */

/*
 * These static routes MUST appear before /:id.
 */

/*
 * GET /api/master-rates/import-template
 *
 * Download the server-generated CSV import template.
 */
router.get(
  "/import-template",
  canView,
  importExportController.importTemplate,
);

/*
 * GET /api/master-rates/export
 *
 * Export Master Rate records as CSV.
 *
 * Supported query filters are handled by the service:
 *
 *   search
 *   categoryType
 *   category
 *   subcategory
 *   unit
 *   status
 *   effectiveDate
 */
router.get(
  "/export",
  canView,
  importExportController.exportRatesFile,
);

/*
 * POST /api/master-rates/import
 *
 * Multipart form field:
 *
 *   file
 *
 * The uploaded CSV is kept in memory by the existing multer
 * middleware and passed directly to the import service.
 */
router.post(
  "/import",
  canAdd,
  upload.single("file"),
  importExportController.importRatesFile,
);

/*
 * PATCH /api/master-rates/bulk-status
 */
router.patch(
  "/bulk-status",
  canEdit,
  rateController.bulkStatus,
);


/* ==========================================================================
| MASTER RATE SPECIAL LOOKUPS
========================================================================== */

/*
 * GET /api/master-rates/active
 */
router.get(
  "/active",
  canView,
  rateController.active,
);

/*
 * GET /api/master-rates/code/:code
 */
router.get(
  "/code/:code",
  canView,
  rateController.getByCode,
);


/* ==========================================================================
| MASTER RATE LIST / CREATE
========================================================================== */

/*
 * GET /api/master-rates
 */
router.get(
  "/",
  canView,
  rateController.list,
);

/*
 * POST /api/master-rates
 */
router.post(
  "/",
  canAdd,
  rateController.create,
);


/* ==========================================================================
| RATE HISTORY
========================================================================== */

/*
 * GET /api/master-rates/:id/history
 *
 * This MUST be before /:id.
 */
router.get(
  "/:id/history",
  canView,
  rateHistoryController.list,
);


/* ==========================================================================
| MASTER RATE BY ID
========================================================================== */

/*
 * GET /api/master-rates/:id
 */
router.get(
  "/:id",
  canView,
  rateController.get,
);

/*
 * PATCH /api/master-rates/:id
 */
router.patch(
  "/:id",
  canEdit,
  rateController.update,
);

/*
 * PATCH /api/master-rates/:id/status
 */
router.patch(
  "/:id/status",
  canEdit,
  rateController.setStatus,
);

/*
 * DELETE /api/master-rates/:id
 */
router.delete(
  "/:id",
  canDelete,
  rateController.remove,
);


/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

export default router;