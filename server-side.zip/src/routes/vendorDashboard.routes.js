import { Router } from "express";

import authMiddleware, {
    requireVendorUser,
} from "../middleware/auth.js";

import * as controller from "../controllers/vendor/vendorDashboardController.js";
import { requireVendorTermsAcceptedMiddleware } from "../middleware/vendorTerms.js";

const router = Router();

router.get(
    "/dashboard",
    authMiddleware,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    controller.get,
);

export default router;
