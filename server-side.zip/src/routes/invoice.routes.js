import { Router } from 'express';
const router = Router();
// TODO: register invoice controllers with auth, RBAC, validation and service calls.
export default router;
