import { Router } from "express";
import authenticate, { requireInternalUser } from "../middleware/auth.js";
import * as notificationController from "../controllers/notificationController.js";

const router = Router();

router.use(authenticate);
router.use(requireInternalUser);

router.get("/", notificationController.list);
router.patch("/:id/read", notificationController.read);
router.patch("/read-all", notificationController.readAll);

export default router;
