import { Router } from "express";

import authenticate, {
    requireInternalUser,
    requireVendorUser,
} from "../middleware/auth.js";

import authorize from "../middleware/rbac.js";

import * as vendorPortalController from "../controllers/vendor/vendorPortalController.js";
import * as vendorTermsController from "../controllers/vendor/vendorTermsController.js";
import * as notificationController from "../controllers/notificationController.js";
import { requireVendorTermsAcceptedMiddleware } from "../middleware/vendorTerms.js";

const router = Router();

/* Vendor portal: current active Telecom Terms & Conditions. */
router.get(
    "/terms",
    authenticate,
    requireVendorUser,
    vendorTermsController.current,
);

/* Vendor portal: record first-login Telecom Terms & Conditions acceptance. */
router.post(
    "/terms/accept",
    authenticate,
    requireVendorUser,
    vendorTermsController.accept,
);

/* Vendor portal user: read own scoped profile. */
router.get(
    "/me",
    authenticate,
    requireVendorUser,
    vendorPortalController.profile,
);

/* Vendor portal: vendor-scoped notifications. */
router.get(
    "/notifications",
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    notificationController.list,
);

router.patch(
    "/notifications/read-all",
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    notificationController.readAll,
);

router.patch(
    "/notifications/:id/read",
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    notificationController.read,
);

/* Internal user: approve a pending vendor, provision portal access, and invite by email. */
router.post(
    "/vendors/:id/approve-and-invite",
    authenticate,
    requireInternalUser,
    authorize({ module: "vendors", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] }),
    vendorPortalController.approveAndInvite,
);

/* Internal user: resend vendor portal invitation. */
router.post(
    "/vendors/:id/account/resend-invitation",
    authenticate,
    requireInternalUser,
    authorize({ module: "vendors", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] }),
    vendorPortalController.resendInvitation,
);

/* Internal user: inspect a vendor's existing portal account. */
router.get(
    "/vendors/:id/account",
    authenticate,
    requireInternalUser,
    authorize({ module: "vendors", action: "view", realms: ["admin", "internal"], userTypes: ["admin", "internal"] }),
    vendorPortalController.getAccount,
);

/* Internal user: provision portal access for an approved vendor. */
router.post(
    "/vendors/:id/account",
    authenticate,
    requireInternalUser,
    authorize({ module: "vendors", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] }),
    vendorPortalController.provision,
);

export default router;
