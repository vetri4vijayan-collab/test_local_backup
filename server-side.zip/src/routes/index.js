
// src/routes/index.js

import { Router } from "express";

import authRoutes from "./auth.routes.js";

import auditRoutes from "./audit.routes.js";
import boqRoutes from "./boq.routes.js";
import budgetRoutes from "./budget.routes.js";
import commercialRoutes from "./commercial.routes.js";
import dashboardRoutes from "./dashboard.routes.js";
import invoiceRoutes from "./invoice.routes.js";
import masterRateRoutes from "./masterRate.routes.js";
import paymentRoutes from "./payment.routes.js";
import projectRoutes from "./project.routes.js";
import quotationRoutes from "./quotation.routes.js";
import reportsRoutes from "./reports.routes.js";
import rfqRoutes from "./rfq.routes.js";
import settingsRoutes from "./settings.routes.js";
import surveyRoutes from "./survey.routes.js";
import taskRoutes from "./task.routes.js";
import userRoutes from "./user.routes.js";
import vendorRoutes from "./vendor.routes.js";

/*
|--------------------------------------------------------------------------
| Root API Router
|--------------------------------------------------------------------------
|
| server.js mounts this router at:
|
|   /api/v1
|
| Therefore the final application endpoints become:
|
|   /api/v1/auth/...
|   /api/v1/audit/...
|   /api/v1/boq/...
|   /api/v1/budget/...
|   /api/v1/commercial/...
|   /api/v1/dashboard/...
|   /api/v1/invoice/...
|   /api/v1/master-rate/...
|   /api/v1/payment/...
|   /api/v1/project/...
|   /api/v1/quotation/...
|   /api/v1/reports/...
|   /api/v1/rfq/...
|   /api/v1/settings/...
|   /api/v1/survey/...
|   /api/v1/task/...
|   /api/v1/user/...
|   /api/v1/vendor/...
|
|--------------------------------------------------------------------------
*/

const router = Router();

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

router.use(
    "/auth",
    authRoutes,
);

/*
|--------------------------------------------------------------------------
| Core Application Modules
|--------------------------------------------------------------------------
*/

router.use(
    "/audit",
    auditRoutes,
);

router.use(
    "/boq",
    boqRoutes,
);

router.use(
    "/budget",
    budgetRoutes,
);

router.use(
    "/commercial",
    commercialRoutes,
);

router.use(
    "/dashboard",
    dashboardRoutes,
);

router.use(
    "/invoice",
    invoiceRoutes,
);

router.use(
    "/master-rate",
    masterRateRoutes,
);

router.use(
    "/payment",
    paymentRoutes,
);

router.use(
    "/project",
    projectRoutes,
);

router.use(
    "/quotation",
    quotationRoutes,
);

router.use(
    "/reports",
    reportsRoutes,
);

router.use(
    "/rfq",
    rfqRoutes,
);

/*
|--------------------------------------------------------------------------
| Settings
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| Do not mount settings.routes.js a second time here.
|
| That file already owns the Company Information routes:
|
|   GET    /company
|   PATCH  /company
|   POST   /company/logo
|   DELETE /company/logo
|   POST   /company/favicon
|   DELETE /company/favicon
|   PATCH  /company/status
|
| Final path:
|
|   /api/v1/settings/company
|
|--------------------------------------------------------------------------
*/

router.use(
    "/settings",
    settingsRoutes,
);

router.use(
    "/survey",
    surveyRoutes,
);

router.use(
    "/task",
    taskRoutes,
);

router.use(
    "/user",
    userRoutes,
);

router.use(
    "/vendor",
    vendorRoutes,
);

/*
|--------------------------------------------------------------------------
| Root API Information
|--------------------------------------------------------------------------
|
| Useful for basic connectivity checks.
|--------------------------------------------------------------------------
*/

router.get(
    "/",
    (req, res) => {
        res.status(200).json({
            success: true,

            message:
                "ARGUS API is running.",

            data: {
                version:
                    "v1",
            },

            requestId:
                req.requestId ||
                null,
        });
    },
);

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

export default router;