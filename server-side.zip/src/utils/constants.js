export const USER_TYPES = Object.freeze({ ADMIN: 'admin', VENDOR: 'vendor' });
export const PERMISSION_ACTIONS = Object.freeze(['view','add','edit','delete','all']);
