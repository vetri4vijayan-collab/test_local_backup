
// src/controllers/auth/authController.js

import env from "../../config/env.js";

import authService, {
    AuthenticationServiceError,
} from "../../services/auth/authService.js";

/*
|--------------------------------------------------------------------------
| Cookie configuration
|--------------------------------------------------------------------------
|
| Authentication tokens are stored in HttpOnly cookies.
|
| Access token:
| - short-lived
| - HttpOnly
|
| Refresh token:
| - long-lived
| - HttpOnly
|
| The browser cannot read either token from JavaScript.
|--------------------------------------------------------------------------
*/

const ACCESS_COOKIE_NAME =
    "argus_access_token";

const REFRESH_COOKIE_NAME =
    "argus_refresh_token";

/*
|--------------------------------------------------------------------------
| Environment helpers
|--------------------------------------------------------------------------
|
| Keep cookie behavior independent from the auth service.
|--------------------------------------------------------------------------
*/

function isProduction() {
    return (
        env.isProduction === true
    );
}

function getCookieSameSite() {
    /*
     * Production can override the policy when frontend and backend
     * are deployed on different sites.
     *
     * Supported values:
     *   strict
     *   lax
     *   none
     */
    const configured =
        String(
            process.env
                .COOKIE_SAME_SITE ||
                "",
        )
            .trim()
            .toLowerCase();

    if (
        [
            "strict",
            "lax",
            "none",
        ].includes(
            configured,
        )
    ) {
        return configured;
    }

    return isProduction()
        ? "strict"
        : "lax";
}

function getCookieOptions({
    maxAge,
} = {}) {
    const sameSite =
        getCookieSameSite();

    return {
        httpOnly: true,

        secure:
            isProduction() ||
            sameSite === "none",

        sameSite,

        path: "/",

        ...(Number.isFinite(
            maxAge,
        )
            ? {
                  maxAge,
              }
            : {}),
    };
}

/*
|--------------------------------------------------------------------------
| JWT duration
|--------------------------------------------------------------------------
*/

function parseDurationMs(
    value,
) {
    if (
        typeof value ===
        "number"
    ) {
        return value * 1000;
    }

    const source =
        String(
            value || "",
        )
            .trim()
            .toLowerCase();

    if (!source) {
        return undefined;
    }

    /*
     * Numeric value is interpreted as seconds.
     */
    if (
        /^\d+$/.test(
            source,
        )
    ) {
        return (
            Number(source) *
            1000
        );
    }

    const match =
        source.match(
            /^(\d+(?:\.\d+)?)\s*(s|m|h|d|w)$/,
        );

    if (!match) {
        return undefined;
    }

    const amount =
        Number(
            match[1],
        );

    const multiplier =
        {
            s: 1000,

            m:
                60 *
                1000,

            h:
                60 *
                60 *
                1000,

            d:
                24 *
                60 *
                60 *
                1000,

            w:
                7 *
                24 *
                60 *
                60 *
                1000,
        }[match[2]];

    return amount * multiplier;
}

/*
|--------------------------------------------------------------------------
| Authentication cookies
|--------------------------------------------------------------------------
*/

function setAuthenticationCookies(
    res,
    {
        accessToken,
        refreshToken,
        rememberMe = true,
    },
) {
    if (
        !accessToken ||
        !refreshToken
    ) {
        throw new Error(
            "Authentication tokens were not generated.",
        );
    }

    const accessMaxAge =
        parseDurationMs(
            process.env
                .JWT_ACCESS_EXPIRES_IN,
        );

    const refreshMaxAge =
        parseDurationMs(
            process.env
                .JWT_REFRESH_EXPIRES_IN,
        );

    /*
     * Keep-me-signed-in controls browser persistence, not JWT lifetime.
     * When disabled, the cookies are session cookies and disappear when
     * the browser session ends. When enabled, the existing configured
     * JWT lifetimes are used as cookie max-age values.
     */
    const persistent =
        rememberMe !== false;

    res.cookie(
        ACCESS_COOKIE_NAME,
        accessToken,
        persistent
            ? getCookieOptions({
                  maxAge: accessMaxAge,
              })
            : getCookieOptions(),
    );

    res.cookie(
        REFRESH_COOKIE_NAME,
        refreshToken,
        persistent
            ? getCookieOptions({
                  maxAge: refreshMaxAge,
              })
            : getCookieOptions(),
    );
}

function clearAuthenticationCookies(
    res,
) {
    const options =
        getCookieOptions();

    res.clearCookie(
        ACCESS_COOKIE_NAME,
        options,
    );

    res.clearCookie(
        REFRESH_COOKIE_NAME,
        options,
    );
}

/*
|--------------------------------------------------------------------------
| Request helpers
|--------------------------------------------------------------------------
*/

function getRequestId(
    req,
) {
    return (
        req.requestId ||
        null
    );
}

function getRefreshToken(
    req,
) {
    const cookieToken =
        req.cookies?.[
            REFRESH_COOKIE_NAME
        ];

    if (
        typeof cookieToken ===
            "string" &&
        cookieToken.trim()
    ) {
        return cookieToken.trim();
    }

    const bodyToken =
        req.body?.refreshToken;

    if (
        typeof bodyToken ===
            "string" &&
        bodyToken.trim()
    ) {
        return bodyToken.trim();
    }

    return null;
}

function getRequestContext(
    req,
) {
    return {
        ipAddress:
            req.ip ||
            req.socket
                ?.remoteAddress ||
            null,

        userAgent:
            req.get(
                "user-agent",
            ) || null,
    };
}

/*
|--------------------------------------------------------------------------
| Body validation
|--------------------------------------------------------------------------
*/

function getLoginInput(
    req,
) {
    const email =
        String(
            req.body?.email ||
                "",
        ).trim();

    const password =
        typeof req.body?.password ===
        "string"
            ? req.body.password
            : "";

    return {
        email,
        password,
    };
}

function validateLoginInput(
    req,
    res,
) {
    const {
        email,
        password,
    } = getLoginInput(
        req,
    );

    if (
        !email ||
        !password
    ) {
        res.status(
            400,
        ).json({
            success: false,

            message:
                "Email and password are required.",

            code:
                "INVALID_LOGIN_INPUT",

            requestId:
                getRequestId(req),
        });

        return null;
    }

    return {
        email,
        password,
    };
}

/*
|--------------------------------------------------------------------------
| Error response
|--------------------------------------------------------------------------
*/

function sendServiceError(
    req,
    res,
    error,
) {
    if (
        error instanceof
        AuthenticationServiceError
    ) {
        return res
            .status(
                error.statusCode ||
                    401,
            )
            .json({
                success: false,

                message:
                    error.message,

                code:
                    error.code,

                requestId:
                    getRequestId(req),
            });
    }

    /*
     * Do not expose internal error details to the client.
     */
    console.error(
        "[AUTH CONTROLLER] Unexpected authentication error:",
        error,
    );

    return res
        .status(500)
        .json({
            success: false,

            message:
                "Authentication service temporarily unavailable.",

            code:
                "AUTHENTICATION_INTERNAL_ERROR",

            requestId:
                getRequestId(req),
        });
}

/*
|--------------------------------------------------------------------------
| Admin Login
|--------------------------------------------------------------------------
*/

export const adminLogin =
    async (
        req,
        res,
    ) => {
        const credentials =
            validateLoginInput(
                req,
                res,
            );

        if (!credentials) {
            return;
        }

        try {
            const result =
                await authService.adminLogin(
                    {
                        email:
                            credentials.email,

                        password:
                            credentials.password,

                        requestContext:
                            getRequestContext(
                                req,
                            ),
                    },
                );

            setAuthenticationCookies(
                res,
                {
                    ...result,
                    rememberMe:
                        req.body?.rememberMe === true,
                },
            );

            return res
                .status(200)
                .json({
                    success: true,

                    message:
                        "Login successful.",

                    data: {
                        user:
                            result.user,

                        role:
                            result.role,

                        permissions:
                            result.permissions,

                        onboarding:
                            result.onboarding || null,

                        sessionId:
                            result.sessionId,
                    },

                    requestId:
                        getRequestId(
                            req,
                        ),
                });
        } catch (
            error
        ) {
            return sendServiceError(
                req,
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| Vendor Login
|--------------------------------------------------------------------------
*/

export const vendorLogin =
    async (
        req,
        res,
    ) => {
        const credentials =
            validateLoginInput(
                req,
                res,
            );

        if (!credentials) {
            return;
        }

        try {
            const result =
                await authService.vendorLogin(
                    {
                        email:
                            credentials.email,

                        password:
                            credentials.password,

                        requestContext:
                            getRequestContext(
                                req,
                            ),
                    },
                );

            setAuthenticationCookies(
                res,
                result,
            );

            return res
                .status(200)
                .json({
                    success: true,

                    message:
                        "Login successful.",

                    data: {
                        user:
                            result.user,

                        role:
                            result.role,

                        permissions:
                            result.permissions,

                        onboarding:
                            result.onboarding || null,

                        sessionId:
                            result.sessionId,
                    },

                    requestId:
                        getRequestId(
                            req,
                        ),
                });
        } catch (
            error
        ) {
            return sendServiceError(
                req,
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| Refresh
|--------------------------------------------------------------------------
*/

export const refresh =
    async (
        req,
        res,
    ) => {
        try {
            const refreshToken =
                getRefreshToken(
                    req,
                );

            if (
                !refreshToken
            ) {
                clearAuthenticationCookies(
                    res,
                );

                return res
                    .status(401)
                    .json({
                        success:
                            false,

                        message:
                            "Refresh token is required.",

                        code:
                            "REFRESH_TOKEN_REQUIRED",

                        requestId:
                            getRequestId(
                                req,
                            ),
                    });
            }

            const result =
                await authService.refresh(
                    {
                        refreshToken,

                        requestContext:
                            getRequestContext(
                                req,
                            ),
                    },
                );

            setAuthenticationCookies(
                res,
                result,
            );

            return res
                .status(200)
                .json({
                    success: true,

                    message:
                        "Session refreshed successfully.",

                    data: {
                        user:
                            result.user,

                        role:
                            result.role,

                        permissions:
                            result.permissions,

                        sessionId:
                            result.sessionId,
                    },

                    requestId:
                        getRequestId(
                            req,
                        ),
                });
        } catch (
            error
        ) {
            clearAuthenticationCookies(
                res,
            );

            return sendServiceError(
                req,
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| Logout
|--------------------------------------------------------------------------
*/

export const logout =
    async (
        req,
        res,
    ) => {
        try {
            const refreshToken =
                getRefreshToken(
                    req,
                );

            const sessionId =
                req.user
                    ?.sessionId ||
                null;

            await authService.logout(
                {
                    refreshToken,

                    sessionId,
                },
            );

            clearAuthenticationCookies(
                res,
            );

            return res
                .status(200)
                .json({
                    success: true,

                    message:
                        "Logged out successfully.",

                    data: null,

                    requestId:
                        getRequestId(
                            req,
                        ),
                });
        } catch (
            error
        ) {
            clearAuthenticationCookies(
                res,
            );

            return sendServiceError(
                req,
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| Current User
|--------------------------------------------------------------------------
*/

export const me =
    async (
        req,
        res,
    ) => {
        try {
            if (
                !req.user?.id
            ) {
                return res
                    .status(401)
                    .json({
                        success:
                            false,

                        message:
                            "Authentication required.",

                        code:
                            "AUTHENTICATION_REQUIRED",

                        requestId:
                            getRequestId(
                                req,
                            ),
                    });
            }

            const result =
                await authService.me(
                    {
                        userId:
                            req.user.id,
                    },
                );

            return res
                .status(200)
                .json({
                    success: true,

                    message:
                        "Authenticated user loaded.",

                    data: {
                        user:
                            result.user,

                        role:
                            result.role,

                        permissions:
                            result.permissions,
                    },

                    requestId:
                        getRequestId(
                            req,
                        ),
                });
        } catch (
            error
        ) {
            return sendServiceError(
                req,
                res,
                error,
            );
        }
    };