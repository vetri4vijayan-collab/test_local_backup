export const requestReset = async (_req,res)=>res.status(501).json({success:false,message:'Implementation pending'});
export const resetPassword = async (_req,res)=>res.status(501).json({success:false,message:'Implementation pending'});
export const changePassword = async (_req,res)=>res.status(501).json({success:false,message:'Implementation pending'});
