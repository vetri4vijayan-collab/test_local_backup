// src/controllers/storage/fileController.js

import fs from 'node:fs';
import path from 'node:path';

import CompanySetting, {
  COMPANY_SETTING_KEY,
} from '../../models/CompanySetting.js';
import storageService from '../../services/storage/storageService.js';

const COMPANY_LOGO_KEY = 'logo';
const COMPANY_FAVICON_KEY = 'favicon';

class FileControllerError extends Error {
  constructor(message, statusCode = 400, code = 'FILE_ERROR') {
    super(message);
    this.name = 'FileControllerError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

/**
 * Safely extract authenticated user id.
 */
function getAuthenticatedUserId(req) {
  return (
    req?.user?.id ||
    req?.user?.userId ||
    req?.user?._id ||
    null
  );
}

/**
 * Send a consistent JSON error response.
 */
function sendError(res, error) {
  const statusCode =
    Number.isInteger(error?.statusCode) && error.statusCode >= 400
      ? error.statusCode
      : 500;

  const code = error?.code || 'FILE_ERROR';

  return res.status(statusCode).json({
    success: false,
    message:
      statusCode >= 500
        ? 'Unable to access the requested file.'
        : error?.message || 'Unable to access the requested file.',
    code,
  });
}

/**
 * Build a safe download filename.
 */
function sanitizeDownloadName(value, fallback = 'file') {
  const input = String(value || fallback)
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .replace(/[<>:"/\\|?*]+/g, '_')
    .replace(/\s+/g, ' ')
    .trim();

  return input || fallback;
}

/**
 * Quote an RFC-compatible filename value.
 */
function buildContentDisposition(filename, disposition = 'inline') {
  const safeFilename = sanitizeDownloadName(filename);

  return `${disposition}; filename="${safeFilename.replace(/"/g, '\\"')}"`;
}

/**
 * Resolve a company file from the singleton company profile.
 *
 * IMPORTANT:
 * storageKey is never accepted directly from the HTTP request.
 * The client can request only the explicitly supported company asset.
 */
async function resolveCompanyAsset(assetType) {
  const company = await CompanySetting.findOne({
    settingKey:
      COMPANY_SETTING_KEY,
    active: true,
  })
    .select(
      'logo favicon active settingKey',
    )
    .lean();

  if (!company) {
    throw new FileControllerError(
      'Company profile has not been configured.',
      404,
      'COMPANY_PROFILE_NOT_FOUND',
    );
  }

  const file =
    assetType === COMPANY_LOGO_KEY
      ? company.logo
      : assetType === COMPANY_FAVICON_KEY
        ? company.favicon
        : null;

  if (!file?.storageKey) {
    throw new FileControllerError(
      `${assetType === COMPANY_LOGO_KEY ? 'Company logo' : 'Company favicon'} is not configured.`,
      404,
      'FILE_NOT_FOUND',
    );
  }

  return file;
}

/**
 * Validate that the resolved storage key can only be accessed through
 * the configured private storage service.
 */
function validateFileMetadata(file) {
  if (!file || typeof file !== 'object') {
    throw new FileControllerError(
      'Invalid file metadata.',
      404,
      'INVALID_FILE_METADATA',
    );
  }

  if (!file.storageKey || typeof file.storageKey !== 'string') {
    throw new FileControllerError(
      'File storage reference is missing.',
      404,
      'INVALID_STORAGE_REFERENCE',
    );
  }

  if (
    file.storageKey.includes('\0') ||
    file.storageKey.includes('..') ||
    path.isAbsolute(file.storageKey)
  ) {
    throw new FileControllerError(
      'Invalid file storage reference.',
      400,
      'INVALID_STORAGE_REFERENCE',
    );
  }

  return true;
}

/**
 * Resolve a local file path using the storage service instead of allowing
 * arbitrary filesystem paths to enter the controller.
 *
 * This supports the storage service implementations where the normalized
 * storage key can be resolved under the configured private root.
 */
function resolveStoragePath(file) {
  validateFileMetadata(file);

  if (typeof storageService.resolveStoragePath === 'function') {
    return storageService.resolveStoragePath(file.storageKey);
  }

  if (typeof storageService.getAbsolutePath === 'function') {
    return storageService.getAbsolutePath(file.storageKey);
  }

  if (typeof storageService.resolvePath === 'function') {
    return storageService.resolvePath(file.storageKey);
  }

  if (file.absolutePath) {
    return file.absolutePath;
  }

  throw new FileControllerError(
    'Storage service cannot resolve the requested file.',
    500,
    'STORAGE_RESOLVER_UNAVAILABLE',
  );
}

/**
 * Verify that the file actually exists.
 */
async function verifyFileExists(filePath) {
  try {
    const stats = await fs.promises.stat(filePath);

    if (!stats.isFile()) {
      throw new FileControllerError(
        'Requested file is not available.',
        404,
        'FILE_NOT_FOUND',
      );
    }

    return stats;
  } catch (error) {
    if (error instanceof FileControllerError) {
      throw error;
    }

    if (error?.code === 'ENOENT') {
      throw new FileControllerError(
        'Requested file is not available.',
        404,
        'FILE_NOT_FOUND',
      );
    }

    throw new FileControllerError(
      'Unable to inspect the requested file.',
      500,
      'FILE_STAT_FAILED',
    );
  }
}

/**
 * Set safe response headers for private assets.
 */
function setFileHeaders(res, file, stats, disposition = 'inline') {
  const mimeType = file.mimeType || 'application/octet-stream';

  const filename = sanitizeDownloadName(
    file.originalName ||
      `argus-file${file.extension ? `.${String(file.extension).replace(/^\./, '')}` : ''}`,
    'argus-file',
  );

  const lastModified = stats.mtime?.toUTCString();
  const etag = `"${stats.size.toString(16)}-${Math.floor(
    stats.mtimeMs,
  ).toString(16)}"`;

  res.setHeader('Content-Type', mimeType);
  res.setHeader('Content-Length', stats.size);
  res.setHeader(
    'Content-Disposition',
    buildContentDisposition(filename, disposition),
  );

  res.setHeader('Cache-Control', 'private, max-age=3600, must-revalidate');
  res.setHeader('ETag', etag);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-site');

  if (lastModified) {
    res.setHeader('Last-Modified', lastModified);
  }

  return {
    etag,
    lastModified,
  };
}

/**
 * Handle conditional GET requests.
 */
function isNotModified(req, etag, lastModified) {
  const incomingEtag = req.headers['if-none-match'];

  if (incomingEtag && incomingEtag === etag) {
    return true;
  }

  const incomingModified = req.headers['if-modified-since'];

  if (incomingModified && lastModified) {
    const incomingDate = Date.parse(incomingModified);
    const lastModifiedDate = Date.parse(lastModified);

    if (
      Number.isFinite(incomingDate) &&
      Number.isFinite(lastModifiedDate) &&
      lastModifiedDate <= incomingDate
    ) {
      return true;
    }
  }

  return false;
}

/**
 * Stream a local private file.
 */
async function streamFile(req, res, file, options = {}) {
  const {
    disposition = 'inline',
    cacheControl = 'private, max-age=3600, must-revalidate',
  } = options;

  const filePath = resolveStoragePath(file);
  const stats = await verifyFileExists(filePath);

  const headers = setFileHeaders(res, file, stats, disposition);

  res.setHeader('Cache-Control', cacheControl);

  if (isNotModified(req, headers.etag, headers.lastModified)) {
    res.status(304).end();
    return;
  }

  const stream = fs.createReadStream(filePath);

  let responseFinished = false;

  const cleanup = () => {
    if (!responseFinished) {
      responseFinished = true;
    }
  };

  stream.once('error', (error) => {
    cleanup();

    if (res.headersSent) {
      res.destroy(error);
      return;
    }

    sendError(
      res,
      new FileControllerError(
        'Unable to read the requested file.',
        500,
        'FILE_READ_FAILED',
      ),
    );
  });

  stream.once('end', cleanup);

  req.once('aborted', () => {
    stream.destroy();
  });

  res.once('close', () => {
    if (!responseFinished) {
      stream.destroy();
    }
  });

  stream.pipe(res);
}

/**
 * GET /settings/company/logo
 *
 * Protected company logo access.
 */
async function getCompanyLogo(req, res) {
  try {
    const userId = getAuthenticatedUserId(req);

    if (!userId) {
      throw new FileControllerError(
        'Authentication is required.',
        401,
        'AUTHENTICATION_REQUIRED',
      );
    }

    const file = await resolveCompanyAsset(COMPANY_LOGO_KEY);

    await streamFile(req, res, file, {
      disposition: 'inline',
      cacheControl: 'private, max-age=3600, must-revalidate',
    });
  } catch (error) {
    if (error?.name === 'CastError') {
      return sendError(
        res,
        new FileControllerError(
          'Invalid file request.',
          400,
          'INVALID_FILE_REQUEST',
        ),
      );
    }

    return sendError(res, error);
  }
}

/**
 * GET /settings/company/favicon
 *
 * Protected company favicon access.
 */
async function getCompanyFavicon(req, res) {
  try {
    const userId = getAuthenticatedUserId(req);

    if (!userId) {
      throw new FileControllerError(
        'Authentication is required.',
        401,
        'AUTHENTICATION_REQUIRED',
      );
    }

    const file = await resolveCompanyAsset(COMPANY_FAVICON_KEY);

    await streamFile(req, res, file, {
      disposition: 'inline',
      cacheControl: 'private, max-age=3600, must-revalidate',
    });
  } catch (error) {
    if (error?.name === 'CastError') {
      return sendError(
        res,
        new FileControllerError(
          'Invalid file request.',
          400,
          'INVALID_FILE_REQUEST',
        ),
      );
    }

    return sendError(res, error);
  }
}

/**
 * GET /settings/company/logo/download
 *
 * Forces browser download of the company logo.
 */
async function downloadCompanyLogo(req, res) {
  try {
    const userId = getAuthenticatedUserId(req);

    if (!userId) {
      throw new FileControllerError(
        'Authentication is required.',
        401,
        'AUTHENTICATION_REQUIRED',
      );
    }

    const file = await resolveCompanyAsset(COMPANY_LOGO_KEY);

    await streamFile(req, res, file, {
      disposition: 'attachment',
      cacheControl: 'private, no-store',
    });
  } catch (error) {
    return sendError(res, error);
  }
}

/**
 * GET /settings/company/favicon/download
 *
 * Forces browser download of the company favicon.
 */
async function downloadCompanyFavicon(req, res) {
  try {
    const userId = getAuthenticatedUserId(req);

    if (!userId) {
      throw new FileControllerError(
        'Authentication is required.',
        401,
        'AUTHENTICATION_REQUIRED',
      );
    }

    const file = await resolveCompanyAsset(COMPANY_FAVICON_KEY);

    await streamFile(req, res, file, {
      disposition: 'attachment',
      cacheControl: 'private, no-store',
    });
  } catch (error) {
    return sendError(res, error);
  }
}

const fileController = {
  getCompanyLogo,
  getCompanyFavicon,
  downloadCompanyLogo,
  downloadCompanyFavicon,
};

export default fileController;