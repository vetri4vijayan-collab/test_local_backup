// src/controllers/masterRate/rateController.js

import {
    listRates,
    getRate,
    getRateHistory,
    createRate,
    updateRate,
    setRateStatus,
    deleteRate,
    bulkUpdateStatus,
    listActiveRates,
    getRateByCode,
    RateServiceError,
} from "../../services/masterRate/rateService.js";

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getAuthenticatedUserId(req) {
    return (
        req.user?.id ||
        req.user?._id ||
        req.user?.userId ||
        null
    );
}

function getAuthenticatedUserName(
    req,
) {
    return (
        req.user?.displayName ||
        req.user?.name ||
        req.user?.email ||
        ""
    );
}

function requireAuthenticatedUser(
    req,
) {
    const userId =
        getAuthenticatedUserId(
            req,
        );

    if (!userId) {
        throw new RateServiceError(
            "Authentication is required.",
            {
                code:
                    "AUTHENTICATION_REQUIRED",
                statusCode: 401,
            },
        );
    }

    return userId;
}

function getQueryValue(
    value,
    fallback = "",
) {
    if (
        value === undefined ||
        value === null
    ) {
        return fallback;
    }

    if (
        Array.isArray(value)
    ) {
        return String(
            value[0] ??
                fallback,
        ).trim();
    }

    return String(
        value,
    ).trim();
}

function parseIds(value) {
    if (
        Array.isArray(value)
    ) {
        return value
            .map((id) =>
                String(
                    id,
                ).trim(),
            )
            .filter(Boolean);
    }

    if (
        typeof value ===
        "string"
    ) {
        return value
            .split(",")
            .map((id) =>
                id.trim(),
            )
            .filter(Boolean);
    }

    return [];
}

function requireParam(
    value,
    message,
    code,
) {
    const normalized =
        getQueryValue(
            value,
        );

    if (!normalized) {
        throw new RateServiceError(
            message,
            {
                code,
                statusCode: 400,
            },
        );
    }

    return normalized;
}

function parseBoolean(
    value,
) {
    if (
        typeof value ===
        "boolean"
    ) {
        return value;
    }

    if (
        typeof value !==
            "string"
    ) {
        return undefined;
    }

    const normalized =
        value.trim().toLowerCase();

    if (
        normalized ===
            "true" ||
        normalized ===
            "1"
    ) {
        return true;
    }

    if (
        normalized ===
            "false" ||
        normalized ===
            "0"
    ) {
        return false;
    }

    return undefined;
}

/*
|--------------------------------------------------------------------------
| Error Handling
|--------------------------------------------------------------------------
*/

function sendError(
    res,
    error,
) {
    if (
        error instanceof
        RateServiceError
    ) {
        return res
            .status(
                error.statusCode ||
                    400,
            )
            .json({
                success: false,

                message:
                    error.message,

                code:
                    error.code,

                ...(error.details
                    ? {
                          details:
                              error.details,
                      }
                    : {}),
            });
    }

    if (
        error?.name ===
        "ValidationError"
    ) {
        const fields = {};

        Object.entries(
            error.errors || {},
        ).forEach(
            ([
                field,
                fieldError,
            ]) => {
                fields[field] =
                    fieldError.message;
            },
        );

        return res
            .status(422)
            .json({
                success: false,

                message:
                    "Master rate validation failed.",

                code:
                    "VALIDATION_ERROR",

                fields,
            });
    }

    if (
        error?.name ===
            "CastError" &&
        error?.kind ===
            "ObjectId"
    ) {
        return res
            .status(400)
            .json({
                success: false,

                message:
                    "Invalid master rate ID.",

                code:
                    "INVALID_MASTER_RATE_ID",
            });
    }

    if (
        error?.code ===
        11000
    ) {
        return res
            .status(409)
            .json({
                success: false,

                message:
                    "A master rate with the same code already exists.",

                code:
                    "MASTER_RATE_CODE_DUPLICATE",
            });
    }

    console.error(
        "[rateController] Internal error",
        {
            name:
                error?.name,
            message:
                error?.message,
            code:
                error?.code,
            stack:
                error?.stack,
        },
    );

    return res
        .status(500)
        .json({
            success: false,

            message:
                "An unexpected error occurred while processing the master rate.",

            code:
                "INTERNAL_SERVER_ERROR",
        });
}

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
|
| GET /api/master-rates
|
|--------------------------------------------------------------------------
*/

export async function list(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const result =
            await listRates({
                page:
                    getQueryValue(
                        req.query
                            ?.page,
                        "1",
                    ),

                limit:
                    getQueryValue(
                        req.query
                            ?.limit,
                        "25",
                    ),

                search:
                    getQueryValue(
                        req.query
                            ?.search,
                        "",
                    ),

                categoryType:
                    getQueryValue(
                        req.query
                            ?.categoryType,
                        "",
                    ),

                category:
                    getQueryValue(
                        req.query
                            ?.category,
                        "",
                    ),

                subcategory:
                    getQueryValue(
                        req.query
                            ?.subcategory,
                        "",
                    ),

                unit:
                    getQueryValue(
                        req.query
                            ?.unit,
                        "",
                    ),

                status:
                    getQueryValue(
                        req.query
                            ?.status,
                        "",
                    ),

                effectiveDate:
                    getQueryValue(
                        req.query
                            ?.effectiveDate,
                        "",
                    ),

                sort:
                    getQueryValue(
                        req.query
                            ?.sort,
                        "updatedAt",
                    ),

                sortOrder:
                    getQueryValue(
                        req.query
                            ?.sortOrder,
                        "desc",
                    ),
            });

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Master rates retrieved successfully.",

                data:
                    result.items,

                pagination:
                    result.pagination,

                filters:
                    result.filters,

                sort:
                    result.sort,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| GET
|--------------------------------------------------------------------------
|
| GET /api/master-rates/:id
|
|--------------------------------------------------------------------------
*/

export async function get(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const id =
            requireParam(
                req.params?.id,
                "Master rate ID is required.",
                "MASTER_RATE_ID_REQUIRED",
            );

        const result =
            await getRate(
                id,
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Master rate retrieved successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| GET BY CODE
|--------------------------------------------------------------------------
|
| GET /api/master-rates/code/:code
|
|--------------------------------------------------------------------------
*/

export async function getByCode(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const code =
            requireParam(
                req.params?.code,
                "Master rate code is required.",
                "MASTER_RATE_CODE_REQUIRED",
            );

        const result =
            await getRateByCode(
                code,
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Master rate retrieved successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| HISTORY
|--------------------------------------------------------------------------
|
| GET /api/master-rates/:id/history
|
|--------------------------------------------------------------------------
*/

export async function history(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const id =
            requireParam(
                req.params?.id,
                "Master rate ID is required.",
                "MASTER_RATE_ID_REQUIRED",
            );

        const result =
            await getRateHistory(
                id,
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Master rate history retrieved successfully.",

                data:
                    result.history,

                rateId:
                    result.rateId,

                code:
                    result.code,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| CREATE
|--------------------------------------------------------------------------
|
| POST /api/master-rates
|
|--------------------------------------------------------------------------
*/

export async function create(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        const payload =
            req.body &&
            typeof req.body ===
                "object" &&
            !Array.isArray(
                req.body,
            )
                ? req.body
                : null;

        if (!payload) {
            throw new RateServiceError(
                "Master rate payload must be an object.",
                {
                    code:
                        "INVALID_MASTER_RATE_PAYLOAD",
                    statusCode: 400,
                },
            );
        }

        const result =
            await createRate(
                payload,
                {
                    userId,

                    user: {
                        id:
                            userId,

                        displayName:
                            getAuthenticatedUserName(
                                req,
                            ),
                    },
                },
            );

        return res
            .status(201)
            .json({
                success: true,

                message:
                    "Master rate created successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| UPDATE
|--------------------------------------------------------------------------
|
| PATCH /api/master-rates/:id
|
|--------------------------------------------------------------------------
*/

export async function update(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        const id =
            requireParam(
                req.params?.id,
                "Master rate ID is required.",
                "MASTER_RATE_ID_REQUIRED",
            );

        const payload =
            req.body &&
            typeof req.body ===
                "object" &&
            !Array.isArray(
                req.body,
            )
                ? req.body
                : null;

        if (!payload) {
            throw new RateServiceError(
                "Master rate payload must be an object.",
                {
                    code:
                        "INVALID_MASTER_RATE_PAYLOAD",
                    statusCode: 400,
                },
            );
        }

        const result =
            await updateRate(
                id,
                payload,
                {
                    userId,

                    user: {
                        id:
                            userId,

                        displayName:
                            getAuthenticatedUserName(
                                req,
                            ),
                    },

                    changeReason:
                        req.body
                            ?.changeReason ||
                        "",
                },
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Master rate updated successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
|
| PATCH /api/master-rates/:id/status
|
| Body:
|
| {
|     "status": "active"
| }
|
|--------------------------------------------------------------------------
*/

export async function setStatus(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        let status =
            req.body?.status;

        /*
         * Compatibility with a frontend using `active`.
         */
        if (
            status ===
                undefined &&
            req.body?.active !==
                undefined
        ) {
            const active =
                parseBoolean(
                    req.body.active,
                );

            if (
                active ===
                undefined
            ) {
                throw new RateServiceError(
                    "The active value must be true or false.",
                    {
                        code:
                            "INVALID_MASTER_RATE_STATUS",
                        statusCode: 422,
                    },
                );
            }

            status =
                active
                    ? "active"
                    : "inactive";
        }

        const normalizedStatus =
            getQueryValue(
                status,
            ).toLowerCase();

        if (
            normalizedStatus !==
                "active" &&
            normalizedStatus !==
                "inactive"
        ) {
            throw new RateServiceError(
                "Master rate status must be active or inactive.",
                {
                    code:
                        "INVALID_MASTER_RATE_STATUS",
                    statusCode: 422,
                },
            );
        }

        const id =
            requireParam(
                req.params?.id,
                "Master rate ID is required.",
                "MASTER_RATE_ID_REQUIRED",
            );

        const result =
            await setRateStatus(
                id,
                normalizedStatus,
                {
                    userId,
                },
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    result.status ===
                    "active"
                        ? "Master rate enabled successfully."
                        : "Master rate disabled successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| BULK STATUS
|--------------------------------------------------------------------------
|
| PATCH /api/master-rates/bulk-status
|
|--------------------------------------------------------------------------
*/

export async function bulkStatus(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        const ids =
            parseIds(
                req.body?.ids,
            );

        if (
            ids.length ===
            0
        ) {
            throw new RateServiceError(
                "At least one master rate ID is required.",
                {
                    code:
                        "MASTER_RATE_IDS_REQUIRED",
                    statusCode: 400,
                },
            );
        }

        let status =
            req.body?.status;

        if (
            status ===
                undefined &&
            req.body?.active !==
                undefined
        ) {
            const active =
                parseBoolean(
                    req.body.active,
                );

            if (
                active ===
                undefined
            ) {
                throw new RateServiceError(
                    "The active value must be true or false.",
                    {
                        code:
                            "INVALID_MASTER_RATE_STATUS",
                        statusCode: 422,
                    },
                );
            }

            status =
                active
                    ? "active"
                    : "inactive";
        }

        const normalizedStatus =
            getQueryValue(
                status,
            ).toLowerCase();

        if (
            normalizedStatus !==
                "active" &&
            normalizedStatus !==
                "inactive"
        ) {
            throw new RateServiceError(
                "Master rate status must be active or inactive.",
                {
                    code:
                        "INVALID_MASTER_RATE_STATUS",
                    statusCode: 422,
                },
            );
        }

        const result =
            await bulkUpdateStatus(
                ids,
                normalizedStatus,
                {
                    userId,
                },
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Master rate statuses updated successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| ACTIVE
|--------------------------------------------------------------------------
|
| GET /api/master-rates/active
|
|--------------------------------------------------------------------------
*/

export async function active(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const result =
            await listActiveRates({
                categoryType:
                    getQueryValue(
                        req.query
                            ?.categoryType,
                        "",
                    ),

                category:
                    getQueryValue(
                        req.query
                            ?.category,
                        "",
                    ),
            });

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Active master rates retrieved successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| DELETE
|--------------------------------------------------------------------------
|
| DELETE /api/master-rates/:id
|
|--------------------------------------------------------------------------
*/

export async function remove(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const id =
            requireParam(
                req.params?.id,
                "Master rate ID is required.",
                "MASTER_RATE_ID_REQUIRED",
            );

        const result =
            await deleteRate(
                id,
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Master rate deleted successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

const rateController = {
    list,

    get,

    getByCode,

    history,

    create,

    update,

    setStatus,

    bulkStatus,

    active,

    remove,
};

export default rateController;