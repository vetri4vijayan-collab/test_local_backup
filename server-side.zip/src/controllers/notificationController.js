import {
    listNotifications,
    markNotificationRead,
    markAllNotificationsRead,
    NotificationServiceError,
} from "../services/notification/notificationService.js";

function currentUserId(req) {
    return req.user?.id || req.user?._id || req.user?.userId || null;
}

function sendError(res, error) {
    if (error instanceof NotificationServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message,
            code: error.code,
            ...(error.details ? { details: error.details } : {}),
        });
    }

    console.error("[notificationController]", error);

    return res.status(500).json({
        success: false,
        message: "Unable to process notifications.",
        code: "INTERNAL_SERVER_ERROR",
    });
}

export async function list(req, res) {
    try {
        const result = await listNotifications({
            recipientId: currentUserId(req),
            unreadOnly: String(req.query?.unreadOnly || "").toLowerCase() === "true",
            limit: req.query?.limit,
        });

        return res.status(200).json({
            success: true,
            data: result.data,
            unreadCount: result.unreadCount,
        });
    } catch (error) {
        return sendError(res, error);
    }
}

export async function read(req, res) {
    try {
        const data = await markNotificationRead({
            id: req.params.id,
            recipientId: currentUserId(req),
        });

        return res.status(200).json({
            success: true,
            data,
        });
    } catch (error) {
        return sendError(res, error);
    }
}

export async function readAll(req, res) {
    try {
        const data = await markAllNotificationsRead({
            recipientId: currentUserId(req),
        });

        return res.status(200).json({
            success: true,
            data,
        });
    } catch (error) {
        return sendError(res, error);
    }
}

export default { list, read, readAll };
