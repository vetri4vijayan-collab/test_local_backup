// src/controllers/settings/companySettingsController.js

import {
  getCompanyProfile,
  updateCompanyProfile,
  updateCompanyLogo,
  updateCompanyFavicon,
  removeCompanyLogo,
  removeCompanyFavicon,
  setCompanyProfileStatus,
  CompanySettingsServiceError,
} from '../../services/settings/companySettingsService.js';


/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Safely extract the authenticated user's ID.
 *
 * The authentication middleware will eventually populate:
 *
 * req.user = {
 *   id,
 *   role,
 *   userType,
 *   permissions,
 *   ...
 * }
 *
 * The controller supports the common `id` and `_id` forms.
 */
function getAuthenticatedUserId(req) {
  return (
    req.user?.id ||
    req.user?._id ||
    null
  );
}


/**
 * Determine whether the user is authenticated.
 *
 * Authentication middleware should normally guarantee this,
 * but the controller keeps the boundary defensive.
 */
function requireAuthenticatedUser(req) {
  const userId =
    getAuthenticatedUserId(req);

  if (!userId) {
    const error =
      new CompanySettingsServiceError(
        'Authentication is required.',
        {
          code:
            'AUTHENTICATION_REQUIRED',
          statusCode: 401,
        },
      );

    throw error;
  }

  return userId;
}


/**
 * Convert service/database errors into safe HTTP responses.
 */
function sendError(
  res,
  error,
) {
  if (
    error instanceof CompanySettingsServiceError
  ) {
    return res
      .status(
        error.statusCode || 400,
      )
      .json({
        success: false,

        message:
          error.message,

        code:
          error.code,

        ...(error.details
          ? {
              details:
                error.details,
            }
          : {}),
      });
  }


  /**
   * Mongoose validation errors.
   */
  if (
    error?.name ===
    'ValidationError'
  ) {
    const fields = {};

    for (
      const [
        field,
        fieldError,
      ] of Object.entries(
        error.errors || {},
      )
    ) {
      fields[field] =
        fieldError.message;
    }


    return res
      .status(422)
      .json({
        success: false,

        message:
          'Company profile validation failed.',

        code:
          'VALIDATION_ERROR',

        fields,
      });
  }


  /**
   * Mongo duplicate-key errors.
   */
  if (
    error?.code === 11000
  ) {
    return res
      .status(409)
      .json({
        success: false,

        message:
          'Company profile already exists.',

        code:
          'COMPANY_PROFILE_DUPLICATE',
      });
  }


  /**
   * Unknown errors.
   *
   * Do not expose stack traces or internal database details.
   */
  console.error(
    '[COMPANY SETTINGS CONTROLLER] Unexpected error:',
    error,
  );


  return res
    .status(500)
    .json({
      success: false,

      message:
        'An unexpected server error occurred.',

      code:
        'INTERNAL_SERVER_ERROR',
    });
}


/**
 * Build a consistent success response.
 */
function sendSuccess(
  res,
  {
    statusCode = 200,
    message = 'Request completed successfully.',
    data = {},
  } = {},
) {
  return res
    .status(statusCode)
    .json({
      success: true,

      message,

      data,
    });
}


/**
 * Return only fields expected from the frontend.
 *
 * The service has already stripped internal file paths.
 */
function buildCompanyResponse(
  company,
  {
    req,
  } = {},
) {
  if (!company) {
    return null;
  }


  const response = {
    ...company,
  };


  /**
   * Browser-facing asset URLs are API routes.
   *
   * The actual protected-file endpoint will be implemented
   * with the local storage service.
   *
   * We do not expose filesystem paths.
   */
  if (response.logo) {
    response.logo = {
      ...response.logo,

      url:
        company.logo?.url ||
        buildAssetUrl(
          req,
          '/settings/company/logo',
        ),
    };
  }


  if (response.favicon) {
    response.favicon = {
      ...response.favicon,

      url:
        company.favicon?.url ||
        buildAssetUrl(
          req,
          '/settings/company/favicon',
        ),
    };
  }


  return response;
}


/**
 * Build the frontend URL for a protected company asset.
 */
function buildAssetUrl(
  req,
  endpoint,
) {
  const protocol =
    req.protocol;

  const host =
    req.get('host');

  return `${protocol}://${host}${endpoint}`;
}


/**
 * Extract company update fields from request body.
 *
 * The frontend currently uses:
 *
 * companyName
 * taxNumber
 * email
 * phone
 * address
 *
 * The backend domain model uses:
 *
 * legalName
 * taxId
 * contactEmail
 * supportPhone
 * headquartersAddress
 */
function mapFrontendFields(
  body = {},
) {
  const mapped = {};


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'legalName',
    )
  ) {
    mapped.legalName =
      body.legalName;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'companyName',
    )
  ) {
    mapped.legalName =
      body.companyName;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'taxId',
    )
  ) {
    mapped.taxId =
      body.taxId;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'taxNumber',
    )
  ) {
    mapped.taxId =
      body.taxNumber;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'contactEmail',
    )
  ) {
    mapped.contactEmail =
      body.contactEmail;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'email',
    )
  ) {
    mapped.contactEmail =
      body.email;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'supportPhone',
    )
  ) {
    mapped.supportPhone =
      body.supportPhone;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'phone',
    )
  ) {
    mapped.supportPhone =
      body.phone;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'headquartersAddress',
    )
  ) {
    mapped.headquartersAddress =
      body.headquartersAddress;
  }


  if (
    Object.prototype.hasOwnProperty.call(
      body,
      'address',
    )
  ) {
    mapped.headquartersAddress =
      body.address;
  }


  /**
   * Reject values that are arrays/objects where scalar
   * company fields are expected.
   */
  for (
    const [
      field,
      value,
    ] of Object.entries(
      mapped,
    )
  ) {
    if (
      value !== undefined &&
      value !== null &&
      (
        typeof value ===
          'object' ||
        Array.isArray(value)
      )
    ) {
      throw new CompanySettingsServiceError(
        `${field} must be a scalar value.`,
        {
          code:
            'INVALID_COMPANY_PROFILE_FIELD',
          statusCode: 422,
          details: {
            field,
          },
        },
      );
    }
  }


  return mapped;
}


/**
 * Extract uploaded file from multer-style request.
 *
 * Supports both:
 *
 * req.file
 *
 * and:
 *
 * req.files.logo
 */
function getUploadedFile(
  req,
  fieldName,
) {
  if (req.file) {
    return req.file;
  }


  if (
    req.files &&
    !Array.isArray(
      req.files,
    ) &&
    req.files[fieldName]
  ) {
    const files =
      req.files[fieldName];

    return Array.isArray(
      files,
    )
      ? files[0]
      : files;
  }


  if (
    Array.isArray(
      req.files,
    )
  ) {
    return (
      req.files.find(
        (file) =>
          file.fieldname ===
          fieldName,
      ) ||
      null
    );
  }


  return null;
}


/**
 * Convert a multer file into the metadata expected by
 * companySettingsService.
 *
 * The actual storage adapter will create:
 *
 * storageKey
 * relativePath
 * checksum
 *
 * before this controller calls the service.
 */
function getFileMetadata(
  req,
  file,
) {
  if (!file) {
    return null;
  }


  /**
   * Local-storage middleware/service is expected to attach
   * these values to the uploaded file object.
   */
  const storageKey =
    file.storageKey ||
    file.key ||
    file.filename;


  const relativePath =
    file.relativePath ||
    file.path ||
    file.filename;


  if (
    !storageKey ||
    !relativePath
  ) {
    throw new CompanySettingsServiceError(
      'Uploaded file was not processed by the storage layer.',
      {
        code:
          'FILE_STORAGE_PROCESSING_FAILED',
        statusCode: 500,
      },
    );
  }


  return {
    originalName:
      file.originalname ||
      file.originalName ||
      'upload',

    storageKey,

    relativePath,

    mimeType:
      file.mimetype ||
      'application/octet-stream',

    extension:
      getExtension(
        file.originalname ||
          file.originalName ||
          '',
      ),

    size:
      Number(
        file.size || 0,
      ),

    checksum:
      file.checksum ||
      null,

    uploadedAt:
      new Date(),

    uploadedBy:
      getAuthenticatedUserId(
        req,
      ),
  };
}


/**
 * Get file extension without exposing the original
 * filesystem name as a storage location.
 */
function getExtension(
  fileName,
) {
  const cleanName =
    String(
      fileName || '',
    ).split(
      /[\\/]/,
    ).pop();


  const lastDot =
    cleanName.lastIndexOf(
      '.',
    );


  if (
    lastDot <= 0 ||
    lastDot ===
      cleanName.length - 1
  ) {
    return '';
  }


  return cleanName
    .slice(lastDot + 1)
    .toLowerCase();
}


/* -------------------------------------------------------------------------- */
/* GET Company Profile                                                        */
/* -------------------------------------------------------------------------- */

/**
 * GET /settings/company
 *
 * Admin/internal side.
 */
export async function getCompanyProfileController(
  req,
  res,
) {
  try {
    requireAuthenticatedUser(
      req,
    );


    const company =
      await getCompanyProfile();


    if (!company) {
      return sendSuccess(
        res,
        {
          statusCode: 200,

          message:
            'Company profile has not been configured yet.',

          data: {
            company:
              null,
          },
        },
      );
    }


    return sendSuccess(
      res,
      {
        statusCode: 200,

        message:
          'Company profile retrieved successfully.',

        data: {
          company:
            buildCompanyResponse(
              company,
              {
                req,
              },
            ),
        },
      },
    );
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* PATCH Company Profile                                                      */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /settings/company
 *
 * Supports both the backend domain field names and the
 * existing frontend field names.
 */
export async function updateCompanyProfileController(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );


    const data =
      mapFrontendFields(
        req.body,
      );


    const result =
      await updateCompanyProfile({
        data,

        updatedBy:
          userId,
      });


    return sendSuccess(
      res,
      {
        statusCode: 200,

        message:
          result.changed
            ? 'Company profile updated successfully.'
            : 'No changes were made to the company profile.',

        data: {
          company:
            buildCompanyResponse(
              result.company,
              {
                req,
              },
            ),

          changed:
            result.changed,

          changes:
            result.changes,
        },
      },
    );
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* POST Company Logo                                                          */
/* -------------------------------------------------------------------------- */

/**
 * POST /settings/company/logo
 *
 * Multipart field:
 *
 * logo
 */
export async function uploadCompanyLogoController(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );


    const file =
      getUploadedFile(
        req,
        'logo',
      );


    if (!file) {
      return res
        .status(422)
        .json({
          success: false,

          message:
            'Company logo file is required.',

          code:
            'COMPANY_LOGO_REQUIRED',
        });
    }


    const fileMetadata =
      getFileMetadata(
        req,
        file,
      );


    const result =
      await updateCompanyLogo({
        fileMetadata,

        updatedBy:
          userId,
      });


    return sendSuccess(
      res,
      {
        statusCode: 200,

        message:
          'Company logo updated successfully.',

        data: {
          company:
            buildCompanyResponse(
              result.company,
              {
                req,
              },
            ),
        },
      },
    );
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* DELETE Company Logo                                                        */
/* -------------------------------------------------------------------------- */

/**
 * DELETE /settings/company/logo
 */
export async function deleteCompanyLogoController(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );


    const result =
      await removeCompanyLogo({
        updatedBy:
          userId,
      });


    return sendSuccess(
      res,
      {
        statusCode: 200,

        message:
          result.changed
            ? 'Company logo removed successfully.'
            : 'Company logo is already empty.',

        data: {
          company:
            buildCompanyResponse(
              result.company,
              {
                req,
              },
            ),
        },
      },
    );
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* POST Company Favicon                                                       */
/* -------------------------------------------------------------------------- */

/**
 * POST /settings/company/favicon
 *
 * Multipart field:
 *
 * favicon
 */
export async function uploadCompanyFaviconController(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );


    const file =
      getUploadedFile(
        req,
        'favicon',
      );


    if (!file) {
      return res
        .status(422)
        .json({
          success: false,

          message:
            'Favicon file is required.',

          code:
            'COMPANY_FAVICON_REQUIRED',
        });
    }


    const fileMetadata =
      getFileMetadata(
        req,
        file,
      );


    const result =
      await updateCompanyFavicon({
        fileMetadata,

        updatedBy:
          userId,
      });


    return sendSuccess(
      res,
      {
        statusCode: 200,

        message:
          'Company favicon updated successfully.',

        data: {
          company:
            buildCompanyResponse(
              result.company,
              {
                req,
              },
            ),
        },
      },
    );
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* DELETE Company Favicon                                                     */
/* -------------------------------------------------------------------------- */

/**
 * DELETE /settings/company/favicon
 */
export async function deleteCompanyFaviconController(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );


    const result =
      await removeCompanyFavicon({
        updatedBy:
          userId,
      });


    return sendSuccess(
      res,
      {
        statusCode: 200,

        message:
          result.changed
            ? 'Company favicon removed successfully.'
            : 'Company favicon is already empty.',

        data: {
          company:
            buildCompanyResponse(
              result.company,
              {
                req,
              },
            ),
        },
      },
    );
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* PATCH Company Status                                                       */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /settings/company/status
 *
 * Body:
 *
 * {
 *   "active": true
 * }
 */
export async function updateCompanyStatusController(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );


    const active =
      req.body?.active;


    /**
     * Handle JSON booleans and string form values safely.
     */
    let normalizedActive;


    if (
      typeof active ===
      'boolean'
    ) {
      normalizedActive =
        active;
    } else if (
      active === 'true' ||
      active === '1'
    ) {
      normalizedActive =
        true;
    } else if (
      active === 'false' ||
      active === '0'
    ) {
      normalizedActive =
        false;
    } else {
      throw new CompanySettingsServiceError(
        'The active field must be true or false.',
        {
          code:
            'INVALID_COMPANY_PROFILE_STATUS',
          statusCode: 422,
        },
      );
    }


    const result =
      await setCompanyProfileStatus({
        active:
          normalizedActive,

        updatedBy:
          userId,
      });


    return sendSuccess(
      res,
      {
        statusCode: 200,

        message:
          result.changed
            ? 'Company profile status updated successfully.'
            : 'Company profile status is already set to the requested value.',

        data: {
          company:
            buildCompanyResponse(
              result.company,
              {
                req,
              },
            ),

          changed:
            result.changed,
        },
      },
    );
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Controller export                                                          */
/* -------------------------------------------------------------------------- */

const companySettingsController =
  Object.freeze({
    getCompanyProfile:
      getCompanyProfileController,

    updateCompanyProfile:
      updateCompanyProfileController,

    uploadCompanyLogo:
      uploadCompanyLogoController,

    deleteCompanyLogo:
      deleteCompanyLogoController,

    uploadCompanyFavicon:
      uploadCompanyFaviconController,

    deleteCompanyFavicon:
      deleteCompanyFaviconController,

    updateCompanyStatus:
      updateCompanyStatusController,
  });


export default companySettingsController;