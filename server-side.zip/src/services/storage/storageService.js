// src/services/storage/storageService.js

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pipeline } from 'node:stream/promises';

import env from '../../config/env.js';


/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Maximum filename length used by the application.
 */
const MAX_FILENAME_LENGTH =
  255;


/**
 * Maximum logical storage-key length.
 */
const MAX_STORAGE_KEY_LENGTH =
  1000;


/**
 * Supported storage driver.
 *
 * ARGUS currently supports local filesystem storage only.
 */
const STORAGE_DRIVER =
  'local';


/**
 * Hash algorithm used for integrity verification.
 */
const CHECKSUM_ALGORITHM =
  'sha256';


/**
 * File access modes.
 */
const ACCESS_MODE = Object.freeze({
  READ:
    fs.constants.F_OK,

  READ_WRITE:
    fs.constants.R_OK |
    fs.constants.W_OK,
});


/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class StorageServiceError extends Error {
  constructor(
    message,
    {
      code =
        'STORAGE_ERROR',

      statusCode =
        500,

      details =
        undefined,

      cause =
        undefined,
    } = {},
  ) {
    super(message);

    this.name =
      'StorageServiceError';

    this.code =
      code;

    this.statusCode =
      statusCode;

    this.details =
      details;

    if (cause) {
      this.cause =
        cause;
    }

    Error.captureStackTrace?.(
      this,
      StorageServiceError,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Initialization                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Ensure required storage directories exist.
 */
export async function initializeStorage() {
  if (
    env.storage.driver !==
    STORAGE_DRIVER
  ) {
    throw new StorageServiceError(
      `Unsupported storage driver "${env.storage.driver}".`,
      {
        code:
          'UNSUPPORTED_STORAGE_DRIVER',

        statusCode:
          500,
      },
    );
  }


  const directories =
    getStorageDirectories();


  for (
    const directory of
      Object.values(
        directories,
      )
  ) {
    await fs.promises.mkdir(
      directory,
      {
        recursive:
          true,

        mode:
          0o750,
      },
    );
  }


  return Object.freeze({
    initialized:
      true,

    driver:
      STORAGE_DRIVER,

    directories:
      Object.freeze({
        ...directories,
      }),
  });
}


/* -------------------------------------------------------------------------- */
/* Storage roots                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Resolve configured storage directories.
 *
 * No directory returned here should be publicly exposed.
 */
function getStorageDirectories() {
  const privateRoot =
    path.resolve(
      env.storage.privateRoot,
    );


  const exportRoot =
    path.resolve(
      env.storage.exportRoot,
    );


  const tempRoot =
    path.resolve(
      env.storage.tempRoot,
    );


  const directories = {
    root:
      path.resolve(
        env.storage.root,
      ),

    private:
      privateRoot,

    exports:
      exportRoot,

    temp:
      tempRoot,
  };


  for (
    const [
      name,
      directory,
    ] of Object.entries(
      directories,
    )
  ) {
    if (
      name ===
      'root'
    ) {
      continue;
    }


    assertPathInsideRoot(
      directory,
      name ===
        'exports'
        ? path.dirname(
            exportRoot,
          )
        : name === 'temp'
          ? path.dirname(
              tempRoot,
            )
          : privateRoot,
    );
  }


  return directories;
}


/* -------------------------------------------------------------------------- */
/* Context directories                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Resolve one logical ARGUS storage context.
 *
 * Example:
 *
 * company
 * vendors
 * quotations
 * invoices
 */
export function resolveContextDirectory(
  context,
) {
  const normalizedContext =
    normalizeContext(
      context,
    );


  const configuredDirectory =
    env.storage.directories[
      normalizedContext
    ];


  if (
    !configuredDirectory
  ) {
    throw new StorageServiceError(
      `Unknown storage context "${context}".`,
      {
        code:
          'UNKNOWN_STORAGE_CONTEXT',

        statusCode:
          400,
      },
    );
  }


  const privateRoot =
    path.resolve(
      env.storage.privateRoot,
    );


  const directory =
    path.resolve(
      privateRoot,
      configuredDirectory,
    );


  assertPathInsideRoot(
    directory,
    privateRoot,
  );


  return directory;
}


/**
 * Normalize context names.
 */
function normalizeContext(
  context,
) {
  if (
    typeof context !==
    'string'
  ) {
    throw new StorageServiceError(
      'Storage context must be a string.',
      {
        code:
          'INVALID_STORAGE_CONTEXT',

        statusCode:
          400,
      },
    );
  }


  const normalized =
    context
      .trim()
      .toLowerCase()
      .replace(
        /[^a-z0-9_-]/g,
        '',
      );


  if (
    !normalized
  ) {
    throw new StorageServiceError(
      'Storage context cannot be empty.',
      {
        code:
          'INVALID_STORAGE_CONTEXT',

        statusCode:
          400,
      },
    );
  }


  return normalized;
}


/* -------------------------------------------------------------------------- */
/* Storage key validation                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Validate a logical storage key.
 *
 * Examples:
 *
 * company/logo/abc.png
 * vendors/68a.../documents/abc.pdf
 */
export function normalizeStorageKey(
  storageKey,
) {
  if (
    typeof storageKey !==
    'string'
  ) {
    throw new StorageServiceError(
      'Storage key must be a string.',
      {
        code:
          'INVALID_STORAGE_KEY',

        statusCode:
          400,
      },
    );
  }


  let normalized =
    storageKey
      .trim()
      .replace(
        /\\/g,
        '/',
      );


  /**
   * Remove duplicate separators.
   */
  normalized =
    normalized.replace(
      /\/{2,}/g,
      '/',
    );


  /**
   * Storage keys must always be relative.
   */
  normalized =
    normalized.replace(
      /^\/+/,
      '',
    );


  if (
    !normalized
  ) {
    throw new StorageServiceError(
      'Storage key cannot be empty.',
      {
        code:
          'INVALID_STORAGE_KEY',

        statusCode:
          400,
      },
    );
  }


  if (
    normalized.length >
    MAX_STORAGE_KEY_LENGTH
  ) {
    throw new StorageServiceError(
      'Storage key is too long.',
      {
        code:
          'STORAGE_KEY_TOO_LONG',

        statusCode:
          400,
      },
    );
  }


  /**
   * Reject traversal segments.
   */
  const segments =
    normalized.split('/');


  if (
    segments.some(
      (segment) =>
        segment ===
        '..',
    )
  ) {
    throw new StorageServiceError(
      'Invalid storage key.',
      {
        code:
          'STORAGE_PATH_TRAVERSAL',

        statusCode:
          400,
      },
    );
  }


  /**
   * Reject null/control characters.
   */
  if (
    /[\u0000-\u001F\u007F]/.test(
      normalized,
    )
  ) {
    throw new StorageServiceError(
      'Storage key contains invalid characters.',
      {
        code:
          'INVALID_STORAGE_KEY',

        statusCode:
          400,
      },
    );
  }


  return normalized;
}


/* -------------------------------------------------------------------------- */
/* Resolve safe file paths                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Resolve a storage key against one trusted root.
 *
 * This is one of the most important security functions in the service.
 */
export function resolveStoragePath(
  storageKey,
  {
    root =
      env.storage.privateRoot,
  } = {},
) {
  const normalizedKey =
    normalizeStorageKey(
      storageKey,
    );


  const safeRoot =
    path.resolve(
      root,
    );


  const resolvedPath =
    path.resolve(
      safeRoot,
      normalizedKey,
    );


  assertPathInsideRoot(
    resolvedPath,
    safeRoot,
  );


  return resolvedPath;
}


/**
 * Ensure resolved path cannot escape root.
 */
function assertPathInsideRoot(
  targetPath,
  rootPath,
) {
  const resolvedTarget =
    path.resolve(
      targetPath,
    );

  const resolvedRoot =
    path.resolve(
      rootPath,
    );


  const rootWithSeparator =
    resolvedRoot.endsWith(
      path.sep,
    )
      ? resolvedRoot
      : `${resolvedRoot}${path.sep}`;


  if (
    resolvedTarget !==
      resolvedRoot &&
    !resolvedTarget.startsWith(
      rootWithSeparator,
    )
  ) {
    throw new StorageServiceError(
      'Storage path is outside the permitted storage directory.',
      {
        code:
          'STORAGE_PATH_OUTSIDE_ROOT',

        statusCode:
          400,
      },
    );
  }
}


/* -------------------------------------------------------------------------- */
/* File existence                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Check whether a storage object exists.
 */
export async function fileExists(
  storageKey,
) {
  const filePath =
    resolveStoragePath(
      storageKey,
    );


  try {
    await fs.promises.access(
      filePath,
      ACCESS_MODE.READ,
    );

    return true;
  } catch {
    return false;
  }
}


/* -------------------------------------------------------------------------- */
/* File stats                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Read safe file statistics.
 */
export async function getFileStats(
  storageKey,
) {
  const filePath =
    resolveStoragePath(
      storageKey,
    );


  let stats;

  try {
    stats =
      await fs.promises.stat(
        filePath,
      );
  } catch (error) {
    if (
      error.code ===
      'ENOENT'
    ) {
      throw new StorageServiceError(
        'Requested file does not exist.',
        {
          code:
            'FILE_NOT_FOUND',

          statusCode:
            404,
        },
      );
    }


    throw new StorageServiceError(
      'Unable to inspect stored file.',
      {
        code:
          'FILE_STAT_FAILED',

        statusCode:
          500,

        cause:
          error,
      },
    );
  }


  if (
    !stats.isFile()
  ) {
    throw new StorageServiceError(
      'Requested storage object is not a file.',
      {
        code:
          'STORAGE_OBJECT_NOT_FILE',

        statusCode:
          404,
      },
    );
  }


  return stats;
}


/* -------------------------------------------------------------------------- */
/* Checksum                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Calculate SHA-256 checksum for a local file.
 */
export async function calculateFileChecksum(
  storageKey,
) {
  const filePath =
    resolveStoragePath(
      storageKey,
    );


  await ensureRegularFile(
    filePath,
  );


  return new Promise(
    (
      resolve,
      reject,
    ) => {
      const hash =
        crypto.createHash(
          CHECKSUM_ALGORITHM,
        );


      const stream =
        fs.createReadStream(
          filePath,
        );


      stream.on(
        'data',
        (chunk) => {
          hash.update(
            chunk,
          );
        },
      );


      stream.on(
        'error',
        (error) => {
          reject(
            new StorageServiceError(
              'Unable to calculate file checksum.',
              {
                code:
                  'CHECKSUM_FAILED',

                statusCode:
                  500,

                cause:
                  error,
              },
            ),
          );
        },
      );


      stream.on(
        'end',
        () => {
          resolve(
            hash.digest(
              'hex',
            ),
          );
        },
      );
    },
  );
}


/**
 * Ensure path points to a normal file.
 */
async function ensureRegularFile(
  filePath,
) {
  let stats;

  try {
    stats =
      await fs.promises.stat(
        filePath,
      );
  } catch (error) {
    if (
      error.code ===
      'ENOENT'
    ) {
      throw new StorageServiceError(
        'Stored file was not found.',
        {
          code:
            'FILE_NOT_FOUND',

          statusCode:
            404,
        },
      );
    }


    throw new StorageServiceError(
      'Unable to access stored file.',
      {
        code:
          'FILE_ACCESS_FAILED',

        statusCode:
          500,

        cause:
          error,
      },
    );
  }


  if (
    !stats.isFile()
  ) {
    throw new StorageServiceError(
      'Storage object is not a regular file.',
      {
        code:
          'INVALID_STORAGE_OBJECT',

        statusCode:
          400,
      },
    );
  }


  return stats;
}


/* -------------------------------------------------------------------------- */
/* Read file                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Create a secure read stream for a stored file.
 *
 * The controller is responsible for authentication/RBAC.
 *
 * This service only guarantees the requested key remains inside
 * the private storage root.
 */
export async function createReadStream(
  storageKey,
) {
  const filePath =
    resolveStoragePath(
      storageKey,
    );


  const stats =
    await ensureRegularFile(
      filePath,
    );


  return {
    stream:
      fs.createReadStream(
        filePath,
      ),

    path:
      filePath,

    size:
      stats.size,

    modifiedAt:
      stats.mtime,

    mimeType:
      null,
  };
}


/* -------------------------------------------------------------------------- */
/* Write file                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Move an already-uploaded temporary file into its final
 * storage location.
 *
 * Expected source:
 *
 * {
 *   sourcePath: "/temporary/path/file",
 *   context: "company",
 *   filename: "..."
 * }
 */
export async function storeFile(
  {
    sourcePath,
    context,
    filename,
  },
) {
  if (
    typeof sourcePath !==
      'string' ||
    !sourcePath.trim()
  ) {
    throw new StorageServiceError(
      'Source file path is required.',
      {
        code:
          'SOURCE_FILE_REQUIRED',

        statusCode:
          400,
      },
    );
  }


  if (
    typeof filename !==
      'string' ||
    !filename.trim()
  ) {
    throw new StorageServiceError(
      'Storage filename is required.',
      {
        code:
          'STORAGE_FILENAME_REQUIRED',

        statusCode:
          400,
      },
    );
  }


  const source =
    path.resolve(
      sourcePath,
    );


  const privateRoot =
    path.resolve(
      env.storage.privateRoot,
    );


  /**
   * Temporary uploads must live inside the application's
   * trusted storage tree.
   */
  assertPathInsideRoot(
    source,
    path.resolve(
      env.storage.root,
    ),
  );


  await ensureRegularFile(
    source,
  );


  const directory =
    resolveContextDirectory(
      context,
    );


  await fs.promises.mkdir(
    directory,
    {
      recursive:
        true,

      mode:
        0o750,
    },
  );


  const safeFilename =
    sanitizeStorageFilename(
      filename,
    );


  const destination =
    path.resolve(
      directory,
      safeFilename,
    );


  assertPathInsideRoot(
    destination,
    privateRoot,
  );


  /**
   * Prevent accidental overwrite.
   */
  if (
    await pathExists(
      destination,
    )
  ) {
    throw new StorageServiceError(
      'A storage object with the requested name already exists.',
      {
        code:
          'STORAGE_OBJECT_EXISTS',

        statusCode:
          409,
      },
    );
  }


  try {
    /**
     * Rename is atomic when source and destination are on
     * the same filesystem.
     */
    await fs.promises.rename(
      source,
      destination,
    );
  } catch (error) {
    /**
     * EXDEV means source and destination are on different
     * filesystems. Fall back to stream copy + delete.
     */
    if (
      error.code !==
      'EXDEV'
    ) {
      throw new StorageServiceError(
        'Unable to store uploaded file.',
        {
          code:
            'FILE_STORE_FAILED',

          statusCode:
            500,

          cause:
            error,
        },
      );
    }


    try {
      await copyFileSafely(
        source,
        destination,
      );


      await fs.promises.rm(
        source,
        {
          force:
            true,
        },
      );
    } catch (copyError) {
      /**
       * Clean up partially created destination.
       */
      await safelyDeleteAbsolutePath(
        destination,
      );


      throw new StorageServiceError(
        'Unable to store uploaded file.',
        {
          code:
            'FILE_STORE_FAILED',

          statusCode:
            500,

          cause:
            copyError,
        },
      );
    }
  }


  const relativePath =
    path.relative(
      privateRoot,
      destination,
    ).replace(
      /\\/g,
      '/',
    );


  const checksum =
    await calculateAbsoluteFileChecksum(
      destination,
    );


  const stats =
    await fs.promises.stat(
      destination,
    );


  return {
    storageKey:
      relativePath,

    relativePath,

    absolutePath:
      destination,

    size:
      stats.size,

    checksum,

    createdAt:
      new Date(
        stats.birthtimeMs,
      ),
  };
}


/* -------------------------------------------------------------------------- */
/* Save buffer/file data                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Directly save a Buffer to a private storage context.
 *
 * Useful for:
 * - generated reports
 * - generated documents
 * - company assets
 * - imported/exported files
 */
export async function saveBuffer(
  {
    buffer,
    context,
    filename,
    overwrite = false,
  },
) {
  if (
    !Buffer.isBuffer(
      buffer,
    )
  ) {
    throw new StorageServiceError(
      'saveBuffer requires a Buffer.',
      {
        code:
          'INVALID_BUFFER',

        statusCode:
          400,
      },
    );
  }


  if (
    buffer.length === 0
  ) {
    throw new StorageServiceError(
      'Cannot store an empty file.',
      {
        code:
          'EMPTY_FILE',

        statusCode:
          422,
      },
    );
  }


  const directory =
    resolveContextDirectory(
      context,
    );


  await fs.promises.mkdir(
    directory,
    {
      recursive:
        true,

      mode:
        0o750,
    },
  );


  const safeFilename =
    sanitizeStorageFilename(
      filename,
    );


  const privateRoot =
    path.resolve(
      env.storage.privateRoot,
    );


  const destination =
    path.resolve(
      directory,
      safeFilename,
    );


  assertPathInsideRoot(
    destination,
    privateRoot,
  );


  if (
    !overwrite &&
    await pathExists(
      destination,
    )
  ) {
    throw new StorageServiceError(
      'Storage object already exists.',
      {
        code:
          'STORAGE_OBJECT_EXISTS',

        statusCode:
          409,
      },
    );
  }


  const temporaryFilename =
    `.${crypto.randomUUID()}.tmp`;


  const temporaryPath =
    path.resolve(
      directory,
      temporaryFilename,
    );


  assertPathInsideRoot(
    temporaryPath,
    privateRoot,
  );


  try {
    await fs.promises.writeFile(
      temporaryPath,
      buffer,
      {
        mode:
          0o640,

        flag:
          'wx',
      },
    );


    if (
      overwrite
    ) {
      /**
       * Rename temporary object into place.
       *
       * On supported filesystems this avoids exposing a
       * partially-written final file.
       */
      await fs.promises.rename(
        temporaryPath,
        destination,
      );
    } else {
      await fs.promises.rename(
        temporaryPath,
        destination,
      );
    }
  } catch (error) {
    await safelyDeleteAbsolutePath(
      temporaryPath,
    );


    throw new StorageServiceError(
      'Unable to save file.',
      {
        code:
          'FILE_WRITE_FAILED',

        statusCode:
          500,

        cause:
          error,
      },
    );
  }


  const checksum =
    await calculateAbsoluteFileChecksum(
      destination,
    );


  const stats =
    await fs.promises.stat(
      destination,
    );


  const relativePath =
    path.relative(
      privateRoot,
      destination,
    ).replace(
      /\\/g,
      '/',
    );


  return {
    storageKey:
      relativePath,

    relativePath,

    absolutePath:
      destination,

    size:
      stats.size,

    checksum,

    createdAt:
      new Date(
        stats.birthtimeMs,
      ),
  };
}


/* -------------------------------------------------------------------------- */
/* Copy                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Safely copy a file inside the trusted storage tree.
 */
async function copyFileSafely(
  source,
  destination,
) {
  const root =
    path.resolve(
      env.storage.root,
    );


  assertPathInsideRoot(
    source,
    root,
  );


  assertPathInsideRoot(
    destination,
    path.resolve(
      env.storage.root,
    ),
  );


  await fs.promises.mkdir(
    path.dirname(
      destination,
    ),
    {
      recursive:
        true,

      mode:
        0o750,
    },
  );


  await pipeline(
    fs.createReadStream(
      source,
    ),
    fs.createWriteStream(
      destination,
      {
        flags:
          'wx',

        mode:
          0o640,
      },
    ),
  );
}


/* -------------------------------------------------------------------------- */
/* Delete                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Delete a stored file using its logical storage key.
 *
 * Returns false when it does not exist.
 */
export async function deleteFile(
  storageKey,
) {
  const filePath =
    resolveStoragePath(
      storageKey,
    );


  try {
    await fs.promises.rm(
      filePath,
      {
        force:
          false,
      },
    );


    return true;
  } catch (error) {
    if (
      error.code ===
      'ENOENT'
    ) {
      return false;
    }


    throw new StorageServiceError(
      'Unable to delete stored file.',
      {
        code:
          'FILE_DELETE_FAILED',

        statusCode:
          500,

        cause:
          error,
      },
    );
  }
}


/**
 * Best-effort deletion used during rollback/cleanup.
 *
 * This function intentionally does not throw.
 */
export async function safelyDeleteFile(
  storageKey,
) {
  try {
    return await deleteFile(
      storageKey,
    );
  } catch (error) {
    console.error(
      '[STORAGE] Failed to delete file during cleanup:',
      error.message,
    );


    return false;
  }
}


/* -------------------------------------------------------------------------- */
/* Rename                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Move one already-stored object between logical keys.
 *
 * Both locations remain under private storage.
 */
export async function moveFile(
  {
    sourceKey,
    destinationKey,
    overwrite = false,
  },
) {
  const sourcePath =
    resolveStoragePath(
      sourceKey,
    );


  const destinationPath =
    resolveStoragePath(
      destinationKey,
    );


  await ensureRegularFile(
    sourcePath,
  );


  await fs.promises.mkdir(
    path.dirname(
      destinationPath,
    ),
    {
      recursive:
        true,

      mode:
        0o750,
    },
  );


  if (
    !overwrite &&
    await pathExists(
      destinationPath,
    )
  ) {
    throw new StorageServiceError(
      'Destination storage object already exists.',
      {
        code:
          'STORAGE_DESTINATION_EXISTS',

        statusCode:
          409,
      },
    );
  }


  try {
    await fs.promises.rename(
      sourcePath,
      destinationPath,
    );
  } catch (error) {
    if (
      error.code !==
      'EXDEV'
    ) {
      throw new StorageServiceError(
        'Unable to move storage object.',
        {
          code:
            'FILE_MOVE_FAILED',

          statusCode:
            500,

          cause:
            error,
        },
      );
    }


    await copyFileSafely(
      sourcePath,
      destinationPath,
    );


    await fs.promises.rm(
      sourcePath,
      {
        force:
          true,
      },
    );
  }


  return {
    storageKey:
      normalizeStorageKey(
        destinationKey,
      ),

    relativePath:
      normalizeStorageKey(
        destinationKey,
      ),
  };
}


/* -------------------------------------------------------------------------- */
/* Replace existing file                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Replace an existing stored file with a new file.
 *
 * Returns the old key so the caller can decide when to remove
 * the obsolete physical object.
 */
export async function replaceFile(
  {
    sourcePath,
    context,
    filename,
    previousStorageKey =
      null,
  },
) {
  const stored =
    await storeFile({
      sourcePath,
      context,
      filename,
    });


  return {
    ...stored,

    previousStorageKey:
      previousStorageKey || null,
  };
}


/* -------------------------------------------------------------------------- */
/* Metadata                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Build storage metadata for MongoDB.
 *
 * This object contains no physical path for frontend exposure.
 */
export async function buildFileMetadata(
  {
    storageKey,
    originalName,
    mimeType,
    extension =
      '',
    uploadedBy =
      null,
  },
) {
  const normalizedKey =
    normalizeStorageKey(
      storageKey,
    );


  const stats =
    await getFileStats(
      normalizedKey,
    );


  const checksum =
    await calculateFileChecksum(
      normalizedKey,
    );


  return {
    originalName:
      sanitizeOriginalName(
        originalName,
      ),

    storageKey:
      normalizedKey,

    relativePath:
      normalizedKey,

    mimeType:
      normalizeMimeType(
        mimeType,
      ),

    extension:
      sanitizeExtension(
        extension ||
        path.extname(
          normalizedKey,
        ).slice(1),
      ),

    size:
      stats.size,

    checksum,

    uploadedAt:
      new Date(),

    uploadedBy:
      uploadedBy || null,
  };
}


/* -------------------------------------------------------------------------- */
/* Filename sanitation                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Sanitize original browser filename.
 *
 * This is metadata only.
 */
export function sanitizeOriginalName(
  filename,
) {
  const value =
    String(
      filename || '',
    )
      .normalize('NFKC')
      .replace(
        /[\u0000-\u001F\u007F]/g,
        '',
      )
      .replace(
        /[\\/]+/g,
        '_',
      )
      .replace(
        /[^a-zA-Z0-9._() \-]/g,
        '_',
      )
      .trim();


  if (
    !value
  ) {
    return 'upload';
  }


  return value.slice(
    0,
    MAX_FILENAME_LENGTH,
  );
}


/**
 * Sanitize server-controlled storage filename.
 *
 * Path separators are never allowed.
 */
export function sanitizeStorageFilename(
  filename,
) {
  const value =
    String(
      filename || '',
    )
      .normalize('NFKC')
      .replace(
        /[\u0000-\u001F\u007F]/g,
        '',
      )
      .replace(
        /[\\/]/g,
        '',
      )
      .replace(
        /\.\./g,
        '',
      )
      .replace(
        /[^a-zA-Z0-9._-]/g,
        '_',
      )
      .trim();


  if (
    !value
  ) {
    throw new StorageServiceError(
      'Invalid storage filename.',
      {
        code:
          'INVALID_STORAGE_FILENAME',

        statusCode:
          400,
      },
    );
  }


  return value.slice(
    0,
    MAX_FILENAME_LENGTH,
  );
}


/**
 * Sanitize extension.
 */
function sanitizeExtension(
  extension,
) {
  return String(
    extension || '',
  )
    .replace(
      /^\./,
      '',
    )
    .replace(
      /[^a-zA-Z0-9]/g,
      '',
    )
    .toLowerCase()
    .slice(
      0,
      20,
    );
}


/**
 * Normalize MIME type.
 */
function normalizeMimeType(
  mimeType,
) {
  return String(
    mimeType ||
      'application/octet-stream',
  )
    .trim()
    .toLowerCase()
    .slice(
      0,
      150,
    );
}


/* -------------------------------------------------------------------------- */
/* Absolute checksum                                                          */
/* -------------------------------------------------------------------------- */

async function calculateAbsoluteFileChecksum(
  filePath,
) {
  return new Promise(
    (
      resolve,
      reject,
    ) => {
      const hash =
        crypto.createHash(
          CHECKSUM_ALGORITHM,
        );


      const stream =
        fs.createReadStream(
          filePath,
        );


      stream.on(
        'data',
        (chunk) => {
          hash.update(
            chunk,
          );
        },
      );


      stream.on(
        'error',
        reject,
      );


      stream.on(
        'end',
        () => {
          resolve(
            hash.digest(
              'hex',
            ),
          );
        },
      );
    },
  );
}


/* -------------------------------------------------------------------------- */
/* Utilities                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Check absolute path existence.
 */
async function pathExists(
  absolutePath,
) {
  try {
    await fs.promises.access(
      absolutePath,
      ACCESS_MODE.READ,
    );

    return true;
  } catch {
    return false;
  }
}


/**
 * Safely delete an absolute path.
 *
 * Only paths inside ARGUS storage may be deleted.
 */
async function safelyDeleteAbsolutePath(
  absolutePath,
) {
  try {
    const root =
      path.resolve(
        env.storage.root,
      );


    const target =
      path.resolve(
        absolutePath,
      );


    assertPathInsideRoot(
      target,
      root,
    );


    await fs.promises.rm(
      target,
      {
        force:
          true,
      },
    );
  } catch (error) {
    console.error(
      '[STORAGE] Cleanup failed:',
      error.message,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Temporary storage                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Create a random temporary file path.
 *
 * No file is created until writeTempFile() is called.
 */
export async function createTempFilePath(
  {
    extension =
      '',
  } = {},
) {
  const tempRoot =
    path.resolve(
      env.storage.tempRoot,
    );


  await fs.promises.mkdir(
    tempRoot,
    {
      recursive:
        true,

      mode:
        0o750,
    },
  );


  const cleanExtension =
    sanitizeExtension(
      extension,
    );


  const filename =
    cleanExtension
      ? `${crypto.randomUUID()}.${cleanExtension}`
      : crypto.randomUUID();


  const targetPath =
    path.resolve(
      tempRoot,
      filename,
    );


  assertPathInsideRoot(
    targetPath,
    tempRoot,
  );


  return targetPath;
}


/**
 * Save temporary buffer.
 *
 * Temporary objects can later be moved into permanent
 * private storage.
 */
export async function writeTempBuffer(
  buffer,
  {
    extension =
      '',
  } = {},
) {
  if (
    !Buffer.isBuffer(
      buffer,
    )
  ) {
    throw new StorageServiceError(
      'Temporary storage requires a Buffer.',
      {
        code:
          'INVALID_TEMP_BUFFER',

        statusCode:
          400,
      },
    );
  }


  const temporaryPath =
    await createTempFilePath({
      extension,
    });


  try {
    await fs.promises.writeFile(
      temporaryPath,
      buffer,
      {
        flag:
          'wx',

        mode:
          0o640,
      },
    );


    return temporaryPath;
  } catch (error) {
    await safelyDeleteAbsolutePath(
      temporaryPath,
    );


    throw new StorageServiceError(
      'Unable to write temporary file.',
      {
        code:
          'TEMP_FILE_WRITE_FAILED',

        statusCode:
          500,

        cause:
          error,
      },
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Cleanup                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Remove a single temporary file.
 */
export async function deleteTempFile(
  absolutePath,
) {
  const tempRoot =
    path.resolve(
      env.storage.tempRoot,
    );


  const target =
    path.resolve(
      absolutePath,
    );


  assertPathInsideRoot(
    target,
    tempRoot,
  );


  await fs.promises.rm(
    target,
    {
      force:
        true,
    },
  );
}


/**
 * Remove old files from the temp directory.
 *
 * This is intentionally limited to files older than the
 * configured age.
 */
export async function cleanupTempFiles(
  {
    olderThanMs =
      24 * 60 * 60 * 1000,
  } = {},
) {
  if (
    !Number.isFinite(
      olderThanMs,
    ) ||
    olderThanMs < 0
  ) {
    throw new StorageServiceError(
      'olderThanMs must be a non-negative finite number.',
      {
        code:
          'INVALID_CLEANUP_AGE',

        statusCode:
          400,
      },
    );
  }


  const tempRoot =
    path.resolve(
      env.storage.tempRoot,
    );


  await fs.promises.mkdir(
    tempRoot,
    {
      recursive:
        true,

      mode:
        0o750,
    },
  );


  const entries =
    await fs.promises.readdir(
      tempRoot,
      {
        withFileTypes:
          true,
      },
    );


  const cutoff =
    Date.now() -
    olderThanMs;


  let deleted =
    0;


  for (
    const entry of entries
  ) {
    if (
      !entry.isFile()
    ) {
      continue;
    }


    const filePath =
      path.resolve(
        tempRoot,
        entry.name,
      );


    assertPathInsideRoot(
      filePath,
      tempRoot,
    );


    try {
      const stats =
        await fs.promises.stat(
          filePath,
        );


      if (
        stats.mtimeMs <
        cutoff
      ) {
        await fs.promises.rm(
          filePath,
          {
            force:
              true,
          },
        );


        deleted += 1;
      }
    } catch (error) {
      console.error(
        `[STORAGE] Failed to clean temporary file "${entry.name}":`,
        error.message,
      );
    }
  }


  return {
    deleted,
  };
}


/* -------------------------------------------------------------------------- */
/* File integrity                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Verify an existing stored file against a known checksum.
 */
export async function verifyFileChecksum(
  {
    storageKey,
    expectedChecksum,
  },
) {
  if (
    typeof expectedChecksum !==
      'string' ||
    !/^[a-fA-F0-9]{64}$/.test(
      expectedChecksum,
    )
  ) {
    throw new StorageServiceError(
      'Expected SHA-256 checksum is invalid.',
      {
        code:
          'INVALID_CHECKSUM',

        statusCode:
          400,
      },
    );
  }


  const actualChecksum =
    await calculateFileChecksum(
      storageKey,
    );


  const expectedBuffer =
    Buffer.from(
      expectedChecksum.toLowerCase(),
      'hex',
    );


  const actualBuffer =
    Buffer.from(
      actualChecksum,
      'hex',
    );


  if (
    expectedBuffer.length !==
    actualBuffer.length
  ) {
    return false;
  }


  return crypto.timingSafeEqual(
    expectedBuffer,
    actualBuffer,
  );
}


/* -------------------------------------------------------------------------- */
/* Public asset metadata                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Convert private file metadata into a safe response.
 *
 * Controllers will add the authenticated download URL.
 */
export function toPublicFileMetadata(
  metadata,
) {
  if (
    !metadata
  ) {
    return null;
  }


  return {
    originalName:
      metadata.originalName ||
      null,

    mimeType:
      metadata.mimeType ||
      null,

    extension:
      metadata.extension ||
      null,

    size:
      metadata.size ??
      null,

    checksum:
      metadata.checksum ||
      null,

    uploadedAt:
      metadata.uploadedAt ||
      null,

    url:
      null,
  };
}


/* -------------------------------------------------------------------------- */
/* Default export                                                             */
/* -------------------------------------------------------------------------- */

const storageService =
  Object.freeze({
    initialize:
      initializeStorage,

    resolveContextDirectory:
      resolveContextDirectory,

    normalizeStorageKey:
      normalizeStorageKey,

    resolveStoragePath:
      resolveStoragePath,

    exists:
      fileExists,

    stats:
      getFileStats,

    checksum:
      calculateFileChecksum,

    createReadStream,

    storeFile,

    saveBuffer,

    deleteFile,

    safelyDeleteFile,

    moveFile,

    replaceFile,

    buildFileMetadata,

    sanitizeOriginalName,

    sanitizeStorageFilename,

    createTempFilePath,

    writeTempBuffer,

    deleteTempFile,

    cleanupTempFiles,

    verifyFileChecksum,

    toPublicFileMetadata,
  });


export default storageService;