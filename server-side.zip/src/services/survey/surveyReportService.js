// Business-logic boundary: surveyReportService.js
// Keep HTTP concerns in controllers and perform multi-step writes in PostgreSQL transactions.
export const serviceName = 'surveyReportService';
