import crypto from "node:crypto";
import { mailer, emailConfig } from "../../config/email.js";
import env from "../../config/env.js";

export class EmailServiceError extends Error {
    constructor(message, { code = "EMAIL_ERROR", statusCode = 503, details = null } = {}) {
        super(message);
        this.name = "EmailServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, EmailServiceError);
    }
}

function text(value) {
    return String(value ?? "").trim();
}

function escapeHtml(value) {
    return text(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
}

function vendorPortalUrl() {
    const base = String(env?.cors?.vendorFrontendUrl || "").replace(/\/+$/, "");
    return base ? `${base}/vendor-login` : "/vendor-login";
}

export function generateTemporaryPassword(length = 16) {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*";
    const bytes = crypto.randomBytes(length);
    let output = "";
    for (let i = 0; i < length; i += 1) {
        output += alphabet[bytes[i] % alphabet.length];
    }
    return output;
}

export async function sendVendorInvitation({
    to,
    vendorName,
    displayName,
    email,
    temporaryPassword,
}) {
    const recipient = text(to).toLowerCase();

    if (!recipient) {
        throw new EmailServiceError("Vendor invitation recipient email is required.", {
            code: "EMAIL_RECIPIENT_REQUIRED",
            statusCode: 422,
        });
    }

    if (!emailConfig.enabled || !mailer) {
        throw new EmailServiceError(
            "Email delivery is not configured. Configure SMTP before sending vendor invitations.",
            {
                code: "EMAIL_NOT_CONFIGURED",
                statusCode: 503,
            },
        );
    }

    const safeVendor = escapeHtml(vendorName || "Vendor");
    const safeName = escapeHtml(displayName || "Vendor Admin");
    const safeEmail = escapeHtml(email || recipient);
    const safePassword = escapeHtml(temporaryPassword || "");
    const loginUrl = vendorPortalUrl();

    const subject = `ARGUS Vendor Portal invitation — ${vendorName || "Vendor"}`;

    const textBody = [
        `Hello ${displayName || "Vendor Admin"},`,
        "",
        `Your vendor portal account for ${vendorName || "your company"} has been approved.`,
        "",
        `Sign in: ${loginUrl}`,
        `Email: ${email || recipient}`,
        `Temporary password: ${temporaryPassword || ""}`,
        "",
        "On your first login, you must review and accept the current Telecom Terms & Conditions before accessing the vendor portal.",
        "",
        "Please keep this invitation confidential.",
    ].join("\n");

    const htmlBody = `
        <div style="font-family:Arial,Helvetica,sans-serif;line-height:1.6;color:#1e293b">
            <h2 style="margin:0 0 16px">ARGUS Vendor Portal Invitation</h2>
            <p>Hello <strong>${safeName}</strong>,</p>
            <p>Your vendor portal account for <strong>${safeVendor}</strong> has been approved.</p>
            <div style="margin:20px 0;padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px">
                <p style="margin:0 0 8px"><strong>Sign in:</strong> <a href="${loginUrl}">${loginUrl}</a></p>
                <p style="margin:0 0 8px"><strong>Email:</strong> ${safeEmail}</p>
                <p style="margin:0"><strong>Temporary password:</strong> ${safePassword}</p>
            </div>
            <p>On your first login, you must review and accept the current Telecom Terms &amp; Conditions before accessing the vendor portal.</p>
            <p style="font-size:12px;color:#64748b">Please keep this invitation confidential.</p>
        </div>
    `;

    const result = await mailer.sendMail({
        from: {
            name: emailConfig.from.name,
            address: emailConfig.from.email,
        },
        to: recipient,
        subject,
        text: textBody,
        html: htmlBody,
    });

    return {
        messageId: result.messageId || null,
        accepted: Array.isArray(result.accepted) ? result.accepted : [],
        rejected: Array.isArray(result.rejected) ? result.rejected : [],
    };
}
