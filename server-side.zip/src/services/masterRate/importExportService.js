// src/services/masterRate/importExportService.js

import mongoose from "mongoose";

import MarketRateItem from "../../models/MarketRateItem.js";
import RateHistory from "../../models/RateHistory.js";

/*
|--------------------------------------------------------------------------
| Constants
|--------------------------------------------------------------------------
*/

const MAX_IMPORT_ROWS = 5000;

const IMPORT_HEADERS = Object.freeze([
    "Code",
    "Module",
    "Category Type",
    "Category",
    "Subcategory",
    "Description",
    "Unit of Measure",
    "Standard Rate (JMD)",
    "Rate",
    "Effective Date",
    "Status",
]);

const CSV_MIME_TYPE =
    "text/csv; charset=utf-8";

const CSV_FILENAME =
    "master-rate-schedule.csv";

const IMPORT_TEMPLATE_FILENAME =
    "master-rate-schedule-import-template.csv";

/*
|--------------------------------------------------------------------------
| Service Error
|--------------------------------------------------------------------------
*/

export class ImportExportServiceError
    extends Error {
    constructor(
        message,
        {
            code =
                "MASTER_RATE_IMPORT_EXPORT_ERROR",
            statusCode = 400,
            details = undefined,
            cause = undefined,
        } = {},
    ) {
        super(message);

        this.name =
            "ImportExportServiceError";

        this.code =
            code;

        this.statusCode =
            statusCode;

        this.details =
            details;

        if (cause) {
            this.cause =
                cause;
        }

        Error.captureStackTrace?.(
            this,
            ImportExportServiceError,
        );
    }
}

/*
|--------------------------------------------------------------------------
| Generic Helpers
|--------------------------------------------------------------------------
*/

function normalizeString(value) {
    if (
        value === undefined ||
        value === null
    ) {
        return "";
    }

    return String(value).trim();
}

function escapeRegex(value) {
    return value.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&",
    );
}

function normalizeStatus(value) {
    const normalized =
        normalizeString(
            value,
        ).toLowerCase();

    if (
        !normalized ||
        normalized === "active"
    ) {
        return "active";
    }

    if (
        normalized === "inactive"
    ) {
        return "inactive";
    }

    throw new ImportExportServiceError(
        "Status must be active or inactive.",
        {
            code:
                "INVALID_IMPORT_STATUS",
            statusCode: 422,
        },
    );
}

function parseRate(
    value,
    rowNumber,
    fieldName = "Standard Rate",
) {
    const normalized =
        normalizeString(value);

    if (!normalized) {
        throw new ImportExportServiceError(
            `${fieldName} is required.`,
            {
                code:
                    "IMPORT_RATE_REQUIRED",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        fieldName,
                },
            },
        );
    }

    /*
     * Accept common exported numeric representations:
     *
     *   1250
     *   1,250
     *   1250.50
     *   JMD 1,250
     */
    const cleaned =
        normalized.replace(
            /[^0-9.-]/g,
            "",
        );

    const rate =
        Number(cleaned);

    if (
        !Number.isFinite(rate)
    ) {
        throw new ImportExportServiceError(
            `${fieldName} must be a valid number.`,
            {
                code:
                    "IMPORT_INVALID_RATE",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        fieldName,
                    value:
                        normalized,
                },
            },
        );
    }

    if (rate < 0) {
        throw new ImportExportServiceError(
            `${fieldName} cannot be negative.`,
            {
                code:
                    "IMPORT_NEGATIVE_RATE",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        fieldName,
                },
            },
        );
    }

    return rate;
}

function parseDateOnly(
    value,
    rowNumber,
) {
    const normalized =
        normalizeString(value);

    if (!normalized) {
        throw new ImportExportServiceError(
            "Effective Date is required.",
            {
                code:
                    "IMPORT_EFFECTIVE_DATE_REQUIRED",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        "Effective Date",
                },
            },
        );
    }

    /*
     * Primary format used by the current frontend:
     *
     *   YYYY-MM-DD
     */
    const isoMatch =
        normalized.match(
            /^(\d{4})-(\d{2})-(\d{2})$/,
        );

    if (isoMatch) {
        const year =
            Number(
                isoMatch[1],
            );

        const month =
            Number(
                isoMatch[2],
            );

        const day =
            Number(
                isoMatch[3],
            );

        const date =
            new Date(
                year,
                month - 1,
                day,
                0,
                0,
                0,
                0,
            );

        if (
            date.getFullYear() !==
                year ||
            date.getMonth() !==
                month - 1 ||
            date.getDate() !==
                day
        ) {
            throw new ImportExportServiceError(
                "Effective Date is invalid.",
                {
                    code:
                        "IMPORT_INVALID_EFFECTIVE_DATE",
                    statusCode: 422,
                    details: {
                        row:
                            rowNumber,
                        field:
                            "Effective Date",
                        value:
                            normalized,
                    },
                },
            );
        }

        return date;
    }

    /*
     * Allow DD/MM/YYYY for controlled bulk imports.
     */
    const dmyMatch =
        normalized.match(
            /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/,
        );

    if (dmyMatch) {
        const day =
            Number(
                dmyMatch[1],
            );

        const month =
            Number(
                dmyMatch[2],
            );

        const year =
            Number(
                dmyMatch[3],
            );

        const date =
            new Date(
                year,
                month - 1,
                day,
                0,
                0,
                0,
                0,
            );

        if (
            date.getFullYear() !==
                year ||
            date.getMonth() !==
                month - 1 ||
            date.getDate() !==
                day
        ) {
            throw new ImportExportServiceError(
                "Effective Date is invalid.",
                {
                    code:
                        "IMPORT_INVALID_EFFECTIVE_DATE",
                    statusCode: 422,
                    details: {
                        row:
                            rowNumber,
                        field:
                            "Effective Date",
                        value:
                            normalized,
                    },
                },
            );
        }

        return date;
    }

    throw new ImportExportServiceError(
        "Effective Date must use YYYY-MM-DD format.",
        {
            code:
                "IMPORT_INVALID_EFFECTIVE_DATE",
            statusCode: 422,
            details: {
                row:
                    rowNumber,
                field:
                    "Effective Date",
                value:
                    normalized,
            },
        },
    );
}

function formatDateOnly(
    value,
) {
    if (!value) {
        return "";
    }

    const date =
        value instanceof Date
            ? value
            : new Date(value);

    if (
        Number.isNaN(
            date.getTime(),
        )
    ) {
        return "";
    }

    return [
        date.getFullYear(),
        String(
            date.getMonth() + 1,
        ).padStart(2, "0"),
        String(
            date.getDate(),
        ).padStart(2, "0"),
    ].join("-");
}

function getUserId(user) {
    return (
        user?.id ||
        user?._id ||
        user?.userId ||
        null
    );
}

function getUserName(user) {
    return (
        user?.displayName ||
        user?.name ||
        user?.email ||
        ""
    );
}

/*
|--------------------------------------------------------------------------
| Persistence / Transaction Helpers
|--------------------------------------------------------------------------
*/

function normalizeAuditUserId(
    userId,
    fieldName = "updatedBy",
) {
    const normalized =
        normalizeString(
            userId,
        );

    if (!normalized) {
        return null;
    }

    if (
        !mongoose.Types.ObjectId.isValid(
            normalized,
        )
    ) {
        throw new ImportExportServiceError(
            `Invalid ${fieldName} user identifier.`,
            {
                code:
                    "INVALID_AUDIT_USER_ID",
                statusCode: 400,
                details: {
                    field:
                        fieldName,
                },
            },
        );
    }

    return new mongoose.Types.ObjectId(
        normalized,
    );
}

async function supportsTransactions() {
    try {
        const client =
            mongoose.connection.getClient();

        const hello =
            await client
                .db()
                .admin()
                .command({
                    hello: 1,
                });

        return Boolean(
            hello?.setName ||
                hello?.msg ===
                    "isdbgrid",
        );
    } catch {
        return false;
    }
}

async function endSessionSafely(
    session,
) {
    if (!session) {
        return;
    }

    try {
        await session.endSession();
    } catch {
        /* Preserve the import result/error. */
    }
}

/*
|--------------------------------------------------------------------------
| CSV Parser
|--------------------------------------------------------------------------
|
| Small RFC4180-compatible parser for the backend.
|
| It handles:
|   - quoted fields
|   - commas inside quoted values
|   - escaped double quotes
|   - CRLF / LF
|   - BOM
|
|--------------------------------------------------------------------------
*/

function parseCsvText(
    input,
) {
    const text =
        String(input || "")
            .replace(
                /^\uFEFF/,
                "",
            );

    const rows = [];

    let row = [];

    let field = "";

    let inQuotes = false;

    for (
        let index = 0;
        index < text.length;
        index += 1
    ) {
        const character =
            text[index];

        const next =
            text[index + 1];

        if (inQuotes) {
            if (
                character ===
                    '"' &&
                next === '"'
            ) {
                field += '"';
                index += 1;
                continue;
            }

            if (
                character ===
                '"'
            ) {
                inQuotes =
                    false;
                continue;
            }

            field +=
                character;

            continue;
        }

        if (
            character ===
            '"'
        ) {
            inQuotes =
                true;

            continue;
        }

        if (
            character ===
            ","
        ) {
            row.push(
                field,
            );

            field = "";

            continue;
        }

        if (
            character ===
            "\n"
        ) {
            row.push(
                field,
            );

            field = "";

            rows.push(
                row,
            );

            row = [];

            continue;
        }

        if (
            character ===
                "\r" &&
            next ===
                "\n"
        ) {
            index += 1;

            row.push(
                field,
            );

            field = "";

            rows.push(
                row,
            );

            row = [];

            continue;
        }

        if (
            character ===
            "\r"
        ) {
            row.push(
                field,
            );

            field = "";

            rows.push(
                row,
            );

            row = [];

            continue;
        }

        field +=
            character;
    }

    if (inQuotes) {
        throw new ImportExportServiceError(
            "CSV contains an unclosed quoted field.",
            {
                code:
                    "INVALID_CSV_FORMAT",
                statusCode: 422,
            },
        );
    }

    /*
     * Flush trailing field/row.
     */
    if (
        field.length > 0 ||
        row.length > 0
    ) {
        row.push(
            field,
        );

        rows.push(
            row,
        );
    }

    /*
     * Remove completely blank rows.
     */
    return rows.filter(
        (currentRow) =>
            currentRow.some(
                (value) =>
                    normalizeString(
                        value,
                    ) !== "",
            ),
    );
}

function normalizeHeader(
    header,
) {
    return normalizeString(
        header,
    )
        .toLowerCase()
        .replace(
            /^\uFEFF/,
            "",
        );
}

function createHeaderMap(
    headers,
) {
    const map =
        new Map();

    headers.forEach(
        (
            header,
            index,
        ) => {
            const normalized =
                normalizeHeader(
                    header,
                );

            if (
                normalized
            ) {
                map.set(
                    normalized,
                    index,
                );
            }
        },
    );

    return map;
}

function getCell(
    row,
    headerMap,
    ...headers
) {
    for (
        const header of headers
    ) {
        const index =
            headerMap.get(
                normalizeHeader(
                    header,
                ),
            );

        if (
            index !==
                undefined
        ) {
            return normalizeString(
                row[index],
            );
        }
    }

    return "";
}

/*
|--------------------------------------------------------------------------
| Import Row Normalization
|--------------------------------------------------------------------------
*/

function normalizeImportRow(
    row,
    headerMap,
    rowNumber,
    {
        activateImported = true,
    } = {},
) {
    const code =
        getCell(
            row,
            headerMap,
            "Code",
            "code",
        ).toUpperCase();

    if (!code) {
        throw new ImportExportServiceError(
            "Code is required.",
            {
                code:
                    "IMPORT_CODE_REQUIRED",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        "Code",
                },
            },
        );
    }

    if (
        code.length >
        50
    ) {
        throw new ImportExportServiceError(
            "Code cannot exceed 50 characters.",
            {
                code:
                    "IMPORT_INVALID_CODE",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        "Code",
                },
            },
        );
    }

    const categoryType =
        getCell(
            row,
            headerMap,
            "Category Type",
            "categoryType",
        );

    if (!categoryType) {
        throw new ImportExportServiceError(
            "Category Type is required.",
            {
                code:
                    "IMPORT_CATEGORY_TYPE_REQUIRED",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        "Category Type",
                },
            },
        );
    }

    const category =
        getCell(
            row,
            headerMap,
            "Category",
            "category",
        );

    if (!category) {
        throw new ImportExportServiceError(
            "Category is required.",
            {
                code:
                    "IMPORT_CATEGORY_REQUIRED",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        "Category",
                },
            },
        );
    }

    const subcategory =
        getCell(
            row,
            headerMap,
            "Subcategory",
            "subcategory",
        );

    if (!subcategory) {
        throw new ImportExportServiceError(
            "Subcategory is required.",
            {
                code:
                    "IMPORT_SUBCATEGORY_REQUIRED",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        "Subcategory",
                },
            },
        );
    }

    const module =
        getCell(
            row,
            headerMap,
            "Module",
            "module",
        );

    const description =
        getCell(
            row,
            headerMap,
            "Description",
            "description",
        );

    if (!description) {
        throw new ImportExportServiceError(
            "Description is required.",
            {
                code:
                    "IMPORT_DESCRIPTION_REQUIRED",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        "Description",
                },
            },
        );
    }

    const unit =
        getCell(
            row,
            headerMap,
            "Unit of Measure",
            "Unit",
            "unit",
        );

    if (!unit) {
        throw new ImportExportServiceError(
            "Unit of Measure is required.",
            {
                code:
                    "IMPORT_UNIT_REQUIRED",
                statusCode: 422,
                details: {
                    row:
                        rowNumber,
                    field:
                        "Unit of Measure",
                },
            },
        );
    }

    /*
     * Frontend export uses Standard Rate (JMD).
     * Import supports all four names used by csvUtils.tsx.
     */
    const standardRateRaw =
        getCell(
            row,
            headerMap,
            "Standard Rate (JMD)",
            "Standard Rate",
            "Rate",
            "standardRate",
            "rate",
        );

    const rate =
        parseRate(
            standardRateRaw,
            rowNumber,
            "Standard Rate",
        );

    const effectiveDateRaw =
        getCell(
            row,
            headerMap,
            "Effective Date",
            "effectiveDate",
        );

    const effectiveDate =
        effectiveDateRaw
            ? parseDateOnly(
                  effectiveDateRaw,
                  rowNumber,
              )
            : null;

    const statusRaw =
        getCell(
            row,
            headerMap,
            "Status",
            "status",
        );

    const status =
        activateImported
            ? "active"
            : normalizeStatus(
                  statusRaw ||
                      "active",
              );

    return {
        code,

        module:
            module ||
            category,

        categoryType,

        category,

        subcategory,

        description,

        unit,

        standardRate:
            rate,

        rate,

        effectiveDate:
            effectiveDate ||
            new Date(),

        status,
    };
}

/*
|--------------------------------------------------------------------------
| Header Validation
|--------------------------------------------------------------------------
*/

function validateImportHeaders(
    headers,
) {
    const normalized =
        new Set(
            headers.map(
                normalizeHeader,
            ),
        );

    const hasCode =
        normalized.has(
            "code",
        );

    if (!hasCode) {
        throw new ImportExportServiceError(
            "CSV must contain a Code column.",
            {
                code:
                    "IMPORT_CODE_HEADER_MISSING",
                statusCode: 422,
            },
        );
    }

    const hasRate =
        normalized.has(
            "standard rate (jmd)",
        ) ||
        normalized.has(
            "standard rate",
        ) ||
        normalized.has(
            "rate",
        ) ||
        normalized.has(
            "standardrate",
        ) ||
        normalized.has(
            "standardrate (jmd)",
        );

    if (!hasRate) {
        throw new ImportExportServiceError(
            "CSV must contain a Standard Rate (JMD) or Rate column.",
            {
                code:
                    "IMPORT_RATE_HEADER_MISSING",
                statusCode: 422,
            },
        );
    }

    return true;
}

/*
|--------------------------------------------------------------------------
| Buffer Validation
|--------------------------------------------------------------------------
*/

function getImportBuffer(
    file,
) {
    if (
        Buffer.isBuffer(
            file,
        )
    ) {
        return file;
    }

    if (
        file?.buffer &&
        Buffer.isBuffer(
            file.buffer,
        )
    ) {
        return file.buffer;
    }

    throw new ImportExportServiceError(
        "A valid CSV file buffer is required.",
        {
            code:
                "IMPORT_BUFFER_REQUIRED",
            statusCode: 400,
        },
    );
}

/*
|--------------------------------------------------------------------------
| Existing Rate Lookup
|--------------------------------------------------------------------------
*/

async function getExistingRatesByCodes(
    codes,
) {
    const normalizedCodes =
        Array.from(
            new Set(
                codes
                    .map(
                        (code) =>
                            normalizeString(
                                code,
                            ).toUpperCase(),
                    )
                    .filter(Boolean),
            ),
        );

    if (
        normalizedCodes.length ===
        0
    ) {
        return new Map();
    }

    const documents =
        await MarketRateItem.find({
            code: {
                $in:
                    normalizedCodes,
            },
        }).lean();

    return new Map(
        documents.map(
            (document) => [
                String(
                    document.code,
                ).toUpperCase(),
                document,
            ],
        ),
    );
}

/*
|--------------------------------------------------------------------------
| Import
|--------------------------------------------------------------------------
*/

/**
 * Import CSV into MarketRateItem.
 *
 * Behavior:
 *
 *   updateExisting = false
 *       duplicate codes are rejected
 *
 *   updateExisting = true
 *       existing records are updated
 *
 * Every created/updated rate gets a RateHistory record whenever
 * it becomes a new rate or its rate/effectiveDate changes.
 */
export async function importRates(
    {
        file,
        userId = null,
        user = null,
        userName = "",
        options = {},
    } = {},
) {
    const buffer =
        getImportBuffer(
            file,
        );

    if (
        buffer.length ===
        0
    ) {
        throw new ImportExportServiceError(
            "Uploaded CSV file is empty.",
            {
                code:
                    "IMPORT_FILE_EMPTY",
                statusCode: 422,
            },
        );
    }

    /*
     * Prevent accidental processing of arbitrarily huge payloads.
     */
    if (
        buffer.length >
        25 * 1024 * 1024
    ) {
        throw new ImportExportServiceError(
            "CSV file is too large. Maximum supported size is 25 MB.",
            {
                code:
                    "IMPORT_FILE_TOO_LARGE",
                statusCode: 413,
            },
        );
    }

    const text =
        buffer.toString(
            "utf8",
        );

    const rows =
        parseCsvText(
            text,
        );

    if (
        rows.length <
        2
    ) {
        throw new ImportExportServiceError(
            "CSV must contain a header row and at least one data row.",
            {
                code:
                    "IMPORT_NO_DATA",
                statusCode: 422,
            },
        );
    }

    const headers =
        rows[0];

    validateImportHeaders(
        headers,
    );

    const headerMap =
        createHeaderMap(
            headers,
        );

    const dataRows =
        rows.slice(1);

    if (
        dataRows.length >
        MAX_IMPORT_ROWS
    ) {
        throw new ImportExportServiceError(
            `CSV cannot contain more than ${MAX_IMPORT_ROWS} rows per import.`,
            {
                code:
                    "IMPORT_ROW_LIMIT_EXCEEDED",
                statusCode: 422,
                details: {
                    maxRows:
                        MAX_IMPORT_ROWS,
                },
            },
        );
    }

    const actorId =
        normalizeAuditUserId(
            userId ||
                getUserId(user),
            "updatedBy",
        );

    const actorName =
        userName ||
        getUserName(
            user,
        );

    const updateExisting =
        options.updateExisting ===
        true;

    const activateImported =
        options.activateImported !==
        false;

    /*
     * Parse every row before performing writes.
     *
     * This prevents bad data in a later row from being discovered only
     * after earlier rows have already been persisted.
     */
    const parsedRows = [];

    const seenCodes =
        new Set();

    for (
        let index = 0;
        index <
        dataRows.length;
        index += 1
    ) {
        const rowNumber =
            index + 2;

        const parsed =
            normalizeImportRow(
                dataRows[index],
                headerMap,
                rowNumber,
                {
                    activateImported,
                },
            );

        if (
            seenCodes.has(
                parsed.code,
            )
        ) {
            throw new ImportExportServiceError(
                `Duplicate code "${parsed.code}" appears more than once in the CSV.`,
                {
                    code:
                        "IMPORT_DUPLICATE_CODE_IN_FILE",
                    statusCode: 422,
                    details: {
                        row:
                            rowNumber,
                        code:
                            parsed.code,
                    },
                },
            );
        }

        seenCodes.add(
            parsed.code,
        );

        parsedRows.push({
            ...parsed,
            rowNumber,
        });
    }

    const codes =
        parsedRows.map(
            (row) => row.code,
        );

    const existingByCode =
        await getExistingRatesByCodes(
            codes,
        );

    const duplicateRows =
        parsedRows.filter(
            (row) =>
                existingByCode.has(
                    row.code,
                ),
        );

    if (
        duplicateRows.length &&
        !updateExisting
    ) {
        throw new ImportExportServiceError(
            "Some rate codes already exist. Enable updateExisting to update existing records.",
            {
                code:
                    "IMPORT_EXISTING_CODES_FOUND",
                statusCode: 409,
                details: {
                    codes:
                        duplicateRows
                            .map(
                                (
                                    row,
                                ) =>
                                    row.code,
                            )
                            .slice(
                                0,
                                100,
                            ),

                    count:
                        duplicateRows.length,
                },
            },
        );
    }

    /*
     * Pre-build operation summary.
     */
    let createdCount = 0;
    let updatedCount = 0;
    let unchangedCount = 0;

    const created = [];
    const updated = [];
    const unchanged = [];

    /*
     * Mongo transactions are preferred where supported.
     *
     * The implementation attempts a transaction but falls back to
     * sequential writes when the current Mongo deployment is a
     * standalone server that does not support transactions.
     */
    let session = null;
    let transactionStarted =
        false;

    try {
        if (
            await supportsTransactions()
        ) {
            session =
                await mongoose.startSession();

            session.startTransaction();

            transactionStarted =
                true;
        }

        for (
            const row of parsedRows
        ) {
            const existing =
                existingByCode.get(
                    row.code,
                );

            if (!existing) {
                const document =
                    new MarketRateItem({
                        code:
                            row.code,

                        module:
                            row.module,

                        categoryType:
                            row.categoryType,

                        category:
                            row.category,

                        subcategory:
                            row.subcategory,

                        description:
                            row.description,

                        unit:
                            row.unit,

                        standardRate:
                            row.standardRate,

                        rate:
                            row.rate,

                        effectiveDate:
                            row.effectiveDate,

                        status:
                            row.status,

                        history: [
                            {
                                rate:
                                    row.standardRate,

                                effectiveDate:
                                    row.effectiveDate,

                                updatedAt:
                                    new Date(),

                                updatedBy:
                                    actorId ||
                                    null,

                                updatedByName:
                                    actorName,
                            },
                        ],

                        createdBy:
                            actorId ||
                            null,

                        updatedBy:
                            actorId ||
                            null,
                    });

                if (
                    transactionStarted
                ) {
                    await document.save({
                        session,
                        validateModifiedOnly:
                            true,
                    });
                } else {
                    await document.save({
                        validateModifiedOnly:
                            true,
                    });
                }

                await RateHistory.create(
                    [
                        {
                            marketRateItemId:
                                document._id,

                            rate:
                                row.standardRate,

                            effectiveDate:
                                row.effectiveDate,

                            updatedBy:
                                actorId ||
                                null,

                            updatedByName:
                                actorName,

                            changeReason:
                                "Bulk CSV import.",
                        },
                    ],
                    transactionStarted
                        ? {
                              session,
                          }
                        : undefined,
                );

                createdCount +=
                    1;

                created.push(
                    row.code,
                );

                continue;
            }

            if (
                !updateExisting
            ) {
                continue;
            }

            const previousRate =
                Number(
                    existing.standardRate,
                );

            const previousDate =
                formatDateOnly(
                    existing.effectiveDate,
                );

            const rateChanged =
                previousRate !==
                Number(
                    row.standardRate,
                );

            const effectiveDateChanged =
                previousDate !==
                formatDateOnly(
                    row.effectiveDate,
                );

            const otherFieldsChanged =
                existing.categoryType !==
                    row.categoryType ||
                existing.category !==
                    row.category ||
                existing.subcategory !==
                    row.subcategory ||
                (existing.module ||
                    "") !==
                    row.module ||
                existing.description !==
                    row.description ||
                existing.unit !==
                    row.unit ||
                existing.status !==
                    row.status;

            if (
                !rateChanged &&
                !effectiveDateChanged &&
                !otherFieldsChanged
            ) {
                unchangedCount +=
                    1;

                unchanged.push(
                    row.code,
                );

                continue;
            }

            existing.categoryType =
                row.categoryType;

            existing.category =
                row.category;

            existing.subcategory =
                row.subcategory;

            existing.module =
                row.module;

            existing.description =
                row.description;

            existing.unit =
                row.unit;

            existing.standardRate =
                row.standardRate;

            existing.rate =
                row.rate;

            existing.effectiveDate =
                row.effectiveDate;

            existing.status =
                row.status;

            if (
                actorId
            ) {
                existing.updatedBy =
                    actorId;
            }

            if (
                rateChanged ||
                effectiveDateChanged
            ) {
                if (
                    !Array.isArray(
                        existing.history,
                    )
                ) {
                    existing.history =
                        [];
                }

                existing.history.push(
                    {
                        rate:
                            row.standardRate,

                        effectiveDate:
                            row.effectiveDate,

                        updatedAt:
                            new Date(),

                        updatedBy:
                            actorId ||
                            null,

                        updatedByName:
                            actorName,
                    },
                );

                existing.history =
                    existing.history.sort(
                        (
                            a,
                            b,
                        ) =>
                            new Date(
                                b.effectiveDate,
                            ).getTime() -
                            new Date(
                                a.effectiveDate,
                            ).getTime(),
                    );
            }

            if (
                transactionStarted
            ) {
                await existing.save({
                    session,
                    validateModifiedOnly:
                        true,
                });
            } else {
                await existing.save({
                    validateModifiedOnly:
                        true,
                });
            }

            /*
             * Keep separate history authoritative whenever the actual
             * effective rate changed.
             */
            if (
                rateChanged ||
                effectiveDateChanged
            ) {
                await RateHistory.create(
                    [
                        {
                            marketRateItemId:
                                existing._id,

                            rate:
                                row.standardRate,

                            effectiveDate:
                                row.effectiveDate,

                            updatedBy:
                                actorId ||
                                null,

                            updatedByName:
                                actorName,

                            changeReason:
                                "Bulk CSV import.",
                        },
                    ],
                    transactionStarted
                        ? {
                              session,
                          }
                        : undefined,
                );
            }

            updatedCount +=
                1;

            updated.push(
                row.code,
            );
        }

        if (
            transactionStarted
        ) {
            await session.commitTransaction();
        }

        return {
            statusCode:
                200,

            message:
                "Master rates imported successfully.",

            summary: {
                totalRows:
                    parsedRows.length,

                created:
                    createdCount,

                updated:
                    updatedCount,

                unchanged:
                    unchangedCount,

                failed:
                    0,

                updateExisting,

                activated:
                    activateImported,
            },

            createdCodes:
                created,

            updatedCodes:
                updated,

            unchangedCodes:
                unchanged,
        };
    } catch (error) {
        if (
            transactionStarted
        ) {
            try {
                await session.abortTransaction();
            } catch {
                /*
                 * Preserve the original error.
                 */
            }
        }

        if (
            error instanceof
            ImportExportServiceError
        ) {
            throw error;
        }

        if (
            error?.code ===
            11000
        ) {
            throw new ImportExportServiceError(
                "Import contains a duplicate master rate code.",
                {
                    code:
                        "IMPORT_DUPLICATE_CODE",
                    statusCode: 409,
                    details: {
                        fields:
                            error.keyPattern
                                ? Object.keys(
                                      error.keyPattern,
                                  )
                                : [],
                    },
                    cause:
                        error,
                },
            );
        }

        if (
            error?.name ===
            "ValidationError"
        ) {
            throw new ImportExportServiceError(
                "One or more master rate rows failed validation.",
                {
                    code:
                        "IMPORT_VALIDATION_FAILED",
                    statusCode: 422,
                    details: {
                        fields:
                            Object.fromEntries(
                                Object.entries(
                                    error.errors ||
                                        {},
                                ).map(
                                    ([
                                        field,
                                        fieldError,
                                    ]) => [
                                        field,
                                        fieldError?.message ||
                                            "Invalid value.",
                                    ],
                                ),
                            ),
                    },
                    cause:
                        error,
                },
            );
        }

        throw new ImportExportServiceError(
            "An unexpected error occurred during master rate import.",
            {
                code:
                    "IMPORT_FAILED",
                statusCode: 500,
                cause:
                    error,
            },
        );
    } finally {
        await endSessionSafely(
            session,
        );
    }
}

/*
|--------------------------------------------------------------------------
| CSV Value Encoding
|--------------------------------------------------------------------------
*/

function csvEscape(
    value,
) {
    const normalized =
        value ===
            undefined ||
        value === null
            ? ""
            : String(value);

    if (
        /[",\r\n]/.test(
            normalized,
        )
    ) {
        return `"${normalized.replace(
            /"/g,
            '""',
        )}"`;
    }

    return normalized;
}

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

function buildExportRow(
    document,
) {
    const standardRate =
        Number(
            document.standardRate ??
                document.rate ??
                0,
        );

    return [
        document.code || "",

        /*
         * Preserve the current frontend export contract.
         */
        document.module ||
            document.category ||
            "",

        document.categoryType ||
            "",

        document.category ||
            "",

        document.subcategory ||
            "",

        document.description ||
            "",

        document.unit ||
            "",

        standardRate,

        Number(
            document.rate ??
                standardRate,
        ),

        formatDateOnly(
            document.effectiveDate,
        ),

        document.status ||
            "active",
    ];
}

function createCsv(
    headers,
    rows,
) {
    const output = [];

    output.push(
        headers
            .map(csvEscape)
            .join(","),
    );

    for (
        const row of rows
    ) {
        output.push(
            row
                .map(csvEscape)
                .join(","),
        );
    }

    /*
     * UTF-8 BOM improves compatibility with Excel.
     */
    return (
        "\uFEFF" +
        output.join("\r\n") +
        "\r\n"
    );
}

/*
|--------------------------------------------------------------------------
| Export Service
|--------------------------------------------------------------------------
*/

export async function exportRates(
    {
        filters = {},
    } = {},
) {
    const query = {};

    const search =
        normalizeString(
            filters.search,
        );

    if (search) {
        const regex =
            new RegExp(
                escapeRegex(
                    search,
                ),
                "i",
            );

        query.$or = [
            {
                code: regex,
            },
            {
                module: regex,
            },
            {
                categoryType:
                    regex,
            },
            {
                category: regex,
            },
            {
                subcategory:
                    regex,
            },
            {
                description:
                    regex,
            },
            {
                unit: regex,
            },
        ];
    }

    if (
        normalizeString(
            filters.categoryType,
        )
    ) {
        query.categoryType =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        filters.categoryType,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(
            filters.category,
        )
    ) {
        query.category =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        filters.category,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(
            filters.subcategory,
        )
    ) {
        query.subcategory =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        filters.subcategory,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(
            filters.unit,
        )
    ) {
        query.unit =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        filters.unit,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(
            filters.status,
        )
    ) {
        const status =
            normalizeString(
                filters.status,
            ).toLowerCase();

        if (
            status !==
                "active" &&
            status !==
                "inactive"
        ) {
            throw new ImportExportServiceError(
                "Invalid export status filter.",
                {
                    code:
                        "INVALID_EXPORT_STATUS",
                    statusCode: 422,
                },
            );
        }

        query.status =
            status;
    }

    if (
        normalizeString(
            filters.effectiveDate,
        )
    ) {
        const date =
            parseDateOnly(
                filters.effectiveDate,
                0,
            );

        const nextDay =
            new Date(
                date,
            );

        nextDay.setDate(
            nextDay.getDate() +
                1,
        );

        query.effectiveDate = {
            $gte: date,
            $lt: nextDay,
        };
    }

    const documents =
        await MarketRateItem.find(
            query,
        )
            .sort({
                categoryType: 1,
                category: 1,
                subcategory: 1,
                code: 1,
            })
            .lean();

    /*
     * Keep export data bounded. A user should use filtered exports
     * for extremely large datasets rather than accidentally generating
     * an enormous in-memory response.
     */
    if (
        documents.length >
        10000
    ) {
        throw new ImportExportServiceError(
            "Export contains more than 10,000 records. Apply filters and export in smaller batches.",
            {
                code:
                    "EXPORT_ROW_LIMIT_EXCEEDED",
                statusCode: 422,
                details: {
                    maxRows:
                        10000,
                    records:
                        documents.length,
                },
            },
        );
    }

    const csv =
        createCsv(
            IMPORT_HEADERS,
            documents.map(
                buildExportRow,
            ),
        );

    return {
        buffer:
            Buffer.from(
                csv,
                "utf8",
            ),

        filename:
            CSV_FILENAME,

        contentType:
            CSV_MIME_TYPE,

        rowCount:
            documents.length,
    };
}

/*
|--------------------------------------------------------------------------
| Import Template
|--------------------------------------------------------------------------
*/

export async function getImportTemplate() {
    /*
     * Example row is intentionally conservative and uses the same
     * columns generated by the frontend's csvUtils.tsx.
     */
    const exampleRow = [
        "MR-001",

        "Fiber Installation",

        "Material",

        "Fiber Optic",

        "Fiber Cable",

        "24 Core Fiber Optic Cable",

        "Meter",

        "1250",

        "1250",

        formatDateOnly(
            new Date(),
        ),

        "active",
    ];

    const csv =
        createCsv(
            IMPORT_HEADERS,
            [
                exampleRow,
            ],
        );

    return {
        buffer:
            Buffer.from(
                csv,
                "utf8",
            ),

        filename:
            IMPORT_TEMPLATE_FILENAME,

        contentType:
            CSV_MIME_TYPE,
    };
}

/*
|--------------------------------------------------------------------------
| Service Object
|--------------------------------------------------------------------------
*/

const importExportService = {
    import:
        importRates,

    export:
        exportRates,

    template:
        getImportTemplate,
};

export default importExportService;