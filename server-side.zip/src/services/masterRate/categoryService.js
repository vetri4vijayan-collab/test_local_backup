// src/services/masterRate/categoryService.js

import mongoose from "mongoose";
import RateCategory from "../../models/RateCategory.js";

/*
|--------------------------------------------------------------------------
| Constants
|--------------------------------------------------------------------------
*/

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;

const CATEGORY_TYPES = Object.freeze([
    "Material",
    "Service",
    "Equipment",
]);

const SORT_FIELDS = Object.freeze({
    categoryType: "categoryType",
    category: "category",
    status: "status",
    createdAt: "createdAt",
    updatedAt: "updatedAt",
    sortOrder: "sortOrder",
});

/*
|--------------------------------------------------------------------------
| Service Error
|--------------------------------------------------------------------------
*/

export class CategoryServiceError extends Error {
    constructor(
        message,
        {
            code = "CATEGORY_SERVICE_ERROR",
            statusCode = 400,
            details = undefined,
            cause = undefined,
        } = {},
    ) {
        super(message);

        this.name =
            "CategoryServiceError";

        this.code =
            code;

        this.statusCode =
            statusCode;

        this.details =
            details;

        if (cause) {
            this.cause =
                cause;
        }

        Error.captureStackTrace?.(
            this,
            CategoryServiceError,
        );
    }
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function normalizeString(
    value,
) {
    if (
        value === undefined ||
        value === null
    ) {
        return "";
    }

    return String(value).trim();
}

function normalizeBoolean(
    value,
    fieldName = "status",
) {
    if (
        typeof value === "boolean"
    ) {
        return value;
    }

    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        return undefined;
    }

    const normalized =
        String(value)
            .trim()
            .toLowerCase();

    if (
        normalized === "true" ||
        normalized === "1"
    ) {
        return true;
    }

    if (
        normalized === "false" ||
        normalized === "0"
    ) {
        return false;
    }

    throw new CategoryServiceError(
        `${fieldName} must be true or false.`,
        {
            code:
                "INVALID_BOOLEAN_VALUE",
            statusCode: 422,
            details: {
                field:
                    fieldName,
            },
        },
    );
}

function normalizePage(
    value,
) {
    const page =
        Number.parseInt(
            String(value ?? ""),
            10,
        );

    if (
        !Number.isFinite(page) ||
        page < 1
    ) {
        return DEFAULT_PAGE;
    }

    return page;
}

function normalizeLimit(
    value,
) {
    const limit =
        Number.parseInt(
            String(value ?? ""),
            10,
        );

    if (
        !Number.isFinite(limit) ||
        limit < 1
    ) {
        return DEFAULT_LIMIT;
    }

    return Math.min(
        MAX_LIMIT,
        limit,
    );
}

function normalizeSort(
    sort,
) {
    const value =
        normalizeString(
            sort,
        );

    return (
        SORT_FIELDS[value] ||
        "sortOrder"
    );
}

function normalizeSortDirection(
    sortOrder,
) {
    return normalizeString(
        sortOrder,
    ).toLowerCase() ===
        "desc"
        ? -1
        : 1;
}

function ensureObjectId(
    id,
) {
    const value =
        normalizeString(id);

    if (
        !mongoose.Types.ObjectId.isValid(
            value,
        )
    ) {
        throw new CategoryServiceError(
            "Invalid category ID.",
            {
                code:
                    "INVALID_CATEGORY_ID",
                statusCode: 400,
            },
        );
    }

    return new mongoose.Types.ObjectId(
        value,
    );
}

function getUserId(
    user,
) {
    return (
        user?.id ||
        user?._id ||
        user?.userId ||
        null
    );
}

/**
 * Normalize the authenticated user identifier before writing audit fields.
 * This prevents invalid JWT/user payloads from reaching Mongoose and becoming
 * opaque 500 responses during otherwise valid category writes.
 */
function normalizeUserId(
    userId,
    fieldName = "updatedBy",
) {
    if (
        userId === undefined ||
        userId === null ||
        userId === ""
    ) {
        return null;
    }

    if (
        userId instanceof mongoose.Types.ObjectId
    ) {
        return userId;
    }

    const value =
        normalizeString(userId);

    if (
        !mongoose.Types.ObjectId.isValid(
            value,
        )
    ) {
        throw new CategoryServiceError(
            `Invalid ${fieldName} user identifier.`,
            {
                code:
                    "INVALID_AUDIT_USER_ID",
                statusCode: 400,
            },
        );
    }

    return new mongoose.Types.ObjectId(
        value,
    );
}

function normalizePersistenceError(
    error,
    operation = "saving category",
) {
    if (
        error instanceof CategoryServiceError
    ) {
        return error;
    }

    if (
        error?.code === 11000
    ) {
        return new CategoryServiceError(
            "This category already exists under the selected category type.",
            {
                code:
                    "CATEGORY_DUPLICATE",
                statusCode: 409,
                cause: error,
            },
        );
    }

    if (
        error?.name === "ValidationError"
    ) {
        return new CategoryServiceError(
            `Category validation failed while ${operation}.`,
            {
                code:
                    "CATEGORY_VALIDATION_FAILED",
                statusCode: 422,
                details: {
                    fields: Object.fromEntries(
                        Object.entries(
                            error.errors || {},
                        ).map(([field, fieldError]) => [
                            field,
                            fieldError?.message ||
                                "Invalid value.",
                        ]),
                    ),
                },
                cause: error,
            },
        );
    }

    if (
        error?.name === "CastError" &&
        error?.kind === "ObjectId"
    ) {
        return new CategoryServiceError(
            "Invalid category value.",
            {
                code:
                    "INVALID_CATEGORY_VALUE",
                statusCode: 422,
                details: {
                    field:
                        error.path || undefined,
                },
                cause: error,
            },
        );
    }

    return error;
}

function escapeRegex(
    value,
) {
    return value.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&",
    );
}

/*
|--------------------------------------------------------------------------
| Validation
|--------------------------------------------------------------------------
*/

function validateCategoryType(
    value,
) {
    const categoryType =
        normalizeString(
            value,
        );

    if (!categoryType) {
        throw new CategoryServiceError(
            "Category type is required.",
            {
                code:
                    "CATEGORY_TYPE_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const matchedType =
        CATEGORY_TYPES.find(
            (type) =>
                type.toLowerCase() ===
                categoryType.toLowerCase(),
        );

    if (!matchedType) {
        throw new CategoryServiceError(
            "Invalid category type.",
            {
                code:
                    "INVALID_CATEGORY_TYPE",
                statusCode: 422,
                details: {
                    allowed:
                        CATEGORY_TYPES,
                },
            },
        );
    }

    return matchedType;
}

function validateCategoryName(
    value,
) {
    const category =
        normalizeString(
            value,
        );

    if (!category) {
        throw new CategoryServiceError(
            "Category is required.",
            {
                code:
                    "CATEGORY_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        category.length > 150
    ) {
        throw new CategoryServiceError(
            "Category cannot exceed 150 characters.",
            {
                code:
                    "INVALID_CATEGORY",
                statusCode: 422,
            },
        );
    }

    return category;
}

function validateDescription(
    value,
) {
    const description =
        normalizeString(
            value,
        );

    if (!description) {
        throw new CategoryServiceError(
            "Description is required.",
            {
                code:
                    "CATEGORY_DESCRIPTION_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        description.length > 1000
    ) {
        throw new CategoryServiceError(
            "Description cannot exceed 1000 characters.",
            {
                code:
                    "INVALID_CATEGORY_DESCRIPTION",
                statusCode: 422,
            },
        );
    }

    return description;
}

function validateCreatePayload(
    payload,
) {
    if (
        !payload ||
        typeof payload !==
            "object" ||
        Array.isArray(payload)
    ) {
        throw new CategoryServiceError(
            "Category payload must be an object.",
            {
                code:
                    "INVALID_CATEGORY_PAYLOAD",
                statusCode: 400,
            },
        );
    }

    return {
        categoryType:
            validateCategoryType(
                payload.categoryType,
            ),

        category:
            validateCategoryName(
                payload.category,
            ),

        description:
            validateDescription(
                payload.description,
            ),

        status:
            normalizeBoolean(
                payload.status,
            ) ?? true,
    };
}

/*
|--------------------------------------------------------------------------
| Serialization
|--------------------------------------------------------------------------
*/

function serializeCategory(
    document,
) {
    if (!document) {
        return null;
    }

    if (
        typeof document.toSafeJSON ===
        "function"
    ) {
        return document.toSafeJSON();
    }

    const data =
        typeof document.toObject ===
        "function"
            ? document.toObject({
                  depopulate: true,
              })
            : document;

    return {
        id:
            data._id?.toString(),

        categoryType:
            data.categoryType,

        category:
            data.category,

        description:
            data.description,

        status:
            data.status === true,

        sortOrder:
            data.sortOrder ??
            0,

        createdBy:
            data.createdBy
                ? data.createdBy.toString()
                : null,

        updatedBy:
            data.updatedBy
                ? data.updatedBy.toString()
                : null,

        createdAt:
            data.createdAt ||
            null,

        updatedAt:
            data.updatedAt ||
            null,
    };
}

/*
|--------------------------------------------------------------------------
| Duplicate Detection
|--------------------------------------------------------------------------
*/

async function ensureUniqueCategory(
    categoryType,
    category,
    {
        excludeId = null,
    } = {},
) {
    const filter = {
        categoryType,
        category: {
            $regex: `^${escapeRegex(
                category,
            )}$`,
            $options: "i",
        },
    };

    if (excludeId) {
        filter._id = {
            $ne: excludeId,
        };
    }

    const existing =
        await RateCategory.findOne(
            filter,
        ).select(
            "_id categoryType category",
        );

    if (existing) {
        throw new CategoryServiceError(
            "This category already exists under the selected category type.",
            {
                code:
                    "CATEGORY_DUPLICATE",
                statusCode: 409,
                details: {
                    categoryType,
                    category,
                },
            },
        );
    }
}

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
*/

export async function listCategories(
    {
        page = DEFAULT_PAGE,
        limit = DEFAULT_LIMIT,
        search = "",
        categoryType,
        status,
        sort = "sortOrder",
        sortOrder = "asc",
    } = {},
) {
    const normalizedPage =
        normalizePage(page);

    const normalizedLimit =
        normalizeLimit(limit);

    const normalizedSearch =
        normalizeString(
            search,
        );

    const filter = {};

    /*
     * Search exactly the business fields exposed by the existing UI.
     */
    if (normalizedSearch) {
        const regex =
            new RegExp(
                escapeRegex(
                    normalizedSearch,
                ),
                "i",
            );

        filter.$or = [
            {
                categoryType:
                    regex,
            },
            {
                category:
                    regex,
            },
            {
                description:
                    regex,
            },
        ];
    }

    if (
        normalizeString(
            categoryType,
        )
    ) {
        filter.categoryType =
            validateCategoryType(
                categoryType,
            );
    }

    const normalizedStatus =
        normalizeBoolean(
            status,
            "status",
        );

    if (
        normalizedStatus !==
        undefined
    ) {
        filter.status =
            normalizedStatus;
    }

    const skip =
        (normalizedPage - 1) *
        normalizedLimit;

    const sortField =
        normalizeSort(sort);

    const direction =
        normalizeSortDirection(
            sortOrder,
        );

    const sortSpec = {
        [sortField]:
            direction,

        /*
         * Stable secondary ordering.
         */
        category: 1,
        categoryType: 1,
    };

    const [
        documents,
        total,
    ] = await Promise.all([
        RateCategory.find(
            filter,
        )
            .sort(sortSpec)
            .skip(skip)
            .limit(
                normalizedLimit,
            ),

        RateCategory.countDocuments(
            filter,
        ),
    ]);

    const items =
        documents.map(
            serializeCategory,
        );

    return {
        items,

        data:
            items,

        pagination: {
            page:
                normalizedPage,

            limit:
                normalizedLimit,

            total,

            totalPages:
                total === 0
                    ? 0
                    : Math.ceil(
                          total /
                              normalizedLimit,
                      ),
        },

        filters: {
            search:
                normalizedSearch,

            categoryType:
                categoryType
                    ? validateCategoryType(
                          categoryType,
                      )
                    : null,

            status:
                normalizedStatus,
        },

        sort: {
            field:
                sortField,

            order:
                direction === -1
                    ? "desc"
                    : "asc",
        },
    };
}

/*
|--------------------------------------------------------------------------
| GET
|--------------------------------------------------------------------------
*/

export async function getCategory(
    id,
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await RateCategory.findById(
            objectId,
        );

    if (!document) {
        throw new CategoryServiceError(
            "Category not found.",
            {
                code:
                    "CATEGORY_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return serializeCategory(
        document,
    );
}

/*
|--------------------------------------------------------------------------
| CREATE
|--------------------------------------------------------------------------
*/

export async function createCategory(
    payload,
    {
        userId = null,
    } = {},
) {
    const data =
        validateCreatePayload(
            payload,
        );

    await ensureUniqueCategory(
        data.categoryType,
        data.category,
    );

    const latest =
        await RateCategory.findOne({})
            .sort({
                sortOrder:
                    -1,
            })
            .select(
                "sortOrder",
            )
            .lean();

    const sortOrder =
        Number(
            latest?.sortOrder ||
                0,
        ) + 1;

    const createData = {
        ...data,

        sortOrder,
    };

    const normalizedUserId =
        normalizeUserId(
            userId,
            "createdBy",
        );

    if (normalizedUserId) {
        createData.createdBy =
            normalizedUserId;

        createData.updatedBy =
            normalizedUserId;
    }

    try {
        const document =
            await RateCategory.create(
                createData,
            );

        return serializeCategory(
            document,
        );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
                "creating the category",
            );

        if (
            normalizedError !== error
        ) {
            throw normalizedError;
        }

        throw error;
    }
}

/*
|--------------------------------------------------------------------------
| UPDATE
|--------------------------------------------------------------------------
*/

export async function updateCategory(
    id,
    payload,
    {
        userId = null,
    } = {},
) {
    if (
        !payload ||
        typeof payload !==
            "object" ||
        Array.isArray(payload)
    ) {
        throw new CategoryServiceError(
            "Category payload must be an object.",
            {
                code:
                    "INVALID_CATEGORY_PAYLOAD",
                statusCode: 400,
            },
        );
    }

    const objectId =
        ensureObjectId(id);

    const document =
        await RateCategory.findById(
            objectId,
        );

    if (!document) {
        throw new CategoryServiceError(
            "Category not found.",
            {
                code:
                    "CATEGORY_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    /*
     * categoryType
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "categoryType",
        )
    ) {
        const nextCategoryType =
            validateCategoryType(
                payload.categoryType,
            );

        if (
            nextCategoryType !==
                document.categoryType
        ) {
            await ensureUniqueCategory(
                nextCategoryType,
                document.category,
                {
                    excludeId:
                        objectId,
                },
            );
        }

        document.categoryType =
            nextCategoryType;
    }

    /*
     * category
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "category",
        )
    ) {
        const nextCategory =
            validateCategoryName(
                payload.category,
            );

        if (
            nextCategory.toLowerCase() !==
            String(
                document.category,
            ).toLowerCase()
        ) {
            await ensureUniqueCategory(
                document.categoryType,
                nextCategory,
                {
                    excludeId:
                        objectId,
                },
            );
        }

        document.category =
            nextCategory;
    }

    /*
     * description
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "description",
        )
    ) {
        document.description =
            validateDescription(
                payload.description,
            );
    }

    /*
     * status
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "status",
        )
    ) {
        const nextStatus =
            normalizeBoolean(
                payload.status,
                "status",
            );

        if (
            nextStatus ===
            undefined
        ) {
            throw new CategoryServiceError(
                "Status is required.",
                {
                    code:
                        "CATEGORY_STATUS_REQUIRED",
                    statusCode: 422,
                },
            );
        }

        document.status =
            nextStatus;
    }

    const normalizedUserId =
        normalizeUserId(
            userId,
            "updatedBy",
        );

    if (normalizedUserId) {
        document.updatedBy =
            normalizedUserId;
    }

    try {
        await document.save({
            validateModifiedOnly:
                true,
        });

        return serializeCategory(
            document,
        );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
                "updating the category",
            );

        if (
            normalizedError !== error
        ) {
            throw normalizedError;
        }

        throw error;
    }
}

/*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
*/

export async function setCategoryStatus(
    id,
    status,
    {
        userId = null,
    } = {},
) {
    const objectId =
        ensureObjectId(id);

    const normalizedStatus =
        normalizeBoolean(
            status,
            "status",
        );

    if (
        normalizedStatus ===
        undefined
    ) {
        throw new CategoryServiceError(
            "Status is required.",
            {
                code:
                    "CATEGORY_STATUS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const update = {
        status:
            normalizedStatus,
    };

    const normalizedUserId =
        normalizeUserId(
            userId,
            "updatedBy",
        );

    if (normalizedUserId) {
        update.updatedBy =
            normalizedUserId;
    }

    let document;

    try {
        document =
            await RateCategory.findByIdAndUpdate(
                objectId,
                {
                    $set:
                        update,
                },
                {
                    new: true,
                    runValidators:
                        true,
                    },
            );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
                "updating category status",
            );

        if (
            normalizedError !== error
        ) {
            throw normalizedError;
        }

        throw error;
    }

    if (!document) {
        throw new CategoryServiceError(
            "Category not found.",
            {
                code:
                    "CATEGORY_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return serializeCategory(
        document,
    );
}

/*
|--------------------------------------------------------------------------
| DELETE
|--------------------------------------------------------------------------
*/

export async function deleteCategory(
    id,
    {
        userId = null,
    } = {},
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await RateCategory.findById(
            objectId,
        );

    if (!document) {
        throw new CategoryServiceError(
            "Category not found.",
            {
                code:
                    "CATEGORY_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    /*
     * Master-rate categories can be referenced by rate records.
     *
     * The current ZIP does not provide an implemented MarketRateItem
     * relationship yet, so we do not guess a dependency collection
     * here. Once MarketRateItem is implemented, deletion protection
     * should be added there before physical deletion is enabled.
     */

    await RateCategory.deleteOne({
        _id: objectId,
    });

    return {
        id:
            objectId.toString(),

        deleted: true,

        deletedBy:
            getUserId({
                id: userId,
            }),
    };
}

/*
|--------------------------------------------------------------------------
| BULK STATUS
|--------------------------------------------------------------------------
*/

export async function bulkUpdateStatus(
    ids,
    status,
    {
        userId = null,
    } = {},
) {
    if (
        !Array.isArray(ids) ||
        ids.length === 0
    ) {
        throw new CategoryServiceError(
            "At least one category ID is required.",
            {
                code:
                    "CATEGORY_IDS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const normalizedStatus =
        normalizeBoolean(
            status,
            "status",
        );

    if (
        normalizedStatus ===
        undefined
    ) {
        throw new CategoryServiceError(
            "Status is required.",
            {
                code:
                    "CATEGORY_STATUS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const objectIds =
        ids.map(
            ensureObjectId,
        );

    const update = {
        status:
            normalizedStatus,
    };

    const normalizedUserId =
        normalizeUserId(
            userId,
            "updatedBy",
        );

    if (normalizedUserId) {
        update.updatedBy =
            normalizedUserId;
    }

    let result;

    try {
        result =
            await RateCategory.updateMany(
            {
                _id: {
                    $in: objectIds,
                },
            },
                {
                    $set:
                        update,
                },
            );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
                "updating category statuses",
            );

        if (
            normalizedError !== error
        ) {
            throw normalizedError;
        }

        throw error;
    }

    return {
        matched:
            result.matchedCount ??
            result.n ??
            0,

        modified:
            result.modifiedCount ??
            result.nModified ??
            0,

        status:
            normalizedStatus,
    };
}

/*
|--------------------------------------------------------------------------
| Active Categories
|--------------------------------------------------------------------------
|
| Used by Master Rate, Quotation, BOQ and other future screens.
|--------------------------------------------------------------------------
*/

export async function listActiveCategories(
    categoryType = null,
) {
    const filter = {
        status: true,
    };

    if (
        categoryType !==
            null &&
        categoryType !==
            undefined &&
        normalizeString(
            categoryType,
        )
    ) {
        filter.categoryType =
            validateCategoryType(
                categoryType,
            );
    }

    const documents =
        await RateCategory.find(
            filter,
        ).sort({
            sortOrder: 1,
            categoryType: 1,
            category: 1,
        });

    return documents.map(
        serializeCategory,
    );
}

/*
|--------------------------------------------------------------------------
| Category Types
|--------------------------------------------------------------------------
|
| The current UI hardcodes these choices. Returning them from the
| backend lets future forms use the same authoritative values.
|--------------------------------------------------------------------------
*/

export function listCategoryTypes() {
    return CATEGORY_TYPES.map(
        (value) => ({
            value,
            label: value,
        }),
    );
}

/*
|--------------------------------------------------------------------------
| Service Object
|--------------------------------------------------------------------------
*/

const categoryService = {
    list:
        listCategories,

    get:
        getCategory,

    create:
        createCategory,

    update:
        updateCategory,

    setStatus:
        setCategoryStatus,

    delete:
        deleteCategory,

    bulkUpdateStatus,

    listActive:
        listActiveCategories,

    listCategoryTypes,
};

export default categoryService;