// src/services/audit/auditService.js

import mongoose from 'mongoose';

import AuditLog from '../../models/AuditLog.js';


/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;
const MAX_SEARCH_LENGTH = 120;
const MAX_METADATA_DEPTH = 6;
const MAX_ARRAY_ITEMS = 200;
const MAX_STRING_LENGTH = 5000;

const RESERVED_KEYS = new Set([
    'password',
    'passwordHash',
    'currentPassword',
    'newPassword',
    'confirmPassword',
    'token',
    'accessToken',
    'refreshToken',
    'authorization',
    'cookie',
    'secret',
    'clientSecret',
    'apiKey',
    'keyMaterial',
    'privateKey',
    'encryptedBlob',
    'fileContents',
    'contentBase64',
]);


/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class AuditServiceError extends Error {
    constructor(
        message,
        {
            code = 'AUDIT_ERROR',
            statusCode = 400,
            details = null,
        } = {},
    ) {
        super(message);

        this.name = 'AuditServiceError';
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;

        Error.captureStackTrace?.(
            this,
            AuditServiceError,
        );
    }
}


/* -------------------------------------------------------------------------- */
/* Normalization helpers                                                      */
/* -------------------------------------------------------------------------- */

function normalizeString(value) {
    return typeof value === 'string'
        ? value.trim()
        : '';
}

function normalizeEmail(value) {
    return normalizeString(value).toLowerCase();
}

function normalizeLower(value) {
    return normalizeString(value).toLowerCase();
}

function isValidObjectId(value) {
    return Boolean(
        value &&
        mongoose.isValidObjectId(value),
    );
}

function toObjectId(value, fieldName) {
    if (!isValidObjectId(value)) {
        throw new AuditServiceError(
            `Invalid ${fieldName}.`,
            {
                code: 'INVALID_OBJECT_ID',
                statusCode: 422,
                details: { field: fieldName },
            },
        );
    }

    return new mongoose.Types.ObjectId(value);
}

function parsePage(value) {
    const page = Number.parseInt(
        String(value ?? ''),
        10,
    );

    return Number.isFinite(page) && page > 0
        ? page
        : DEFAULT_PAGE;
}

function parseLimit(value) {
    const limit = Number.parseInt(
        String(value ?? ''),
        10,
    );

    if (!Number.isFinite(limit) || limit <= 0) {
        return DEFAULT_LIMIT;
    }

    return Math.min(limit, MAX_LIMIT);
}

function normalizeSearch(value) {
    return normalizeString(value)
        .slice(0, MAX_SEARCH_LENGTH);
}

function normalizeDate(value, fieldName) {
    if (
        value === undefined ||
        value === null ||
        value === ''
    ) {
        return null;
    }

    const date = value instanceof Date
        ? new Date(value.getTime())
        : new Date(value);

    if (Number.isNaN(date.getTime())) {
        throw new AuditServiceError(
            `Invalid ${fieldName}.`,
            {
                code: 'INVALID_DATE',
                statusCode: 422,
                details: { field: fieldName },
            },
        );
    }

    return date;
}

function normalizeStatus(value) {
    const status = normalizeLower(value);

    if (!status) {
        return undefined;
    }

    if (!['active', 'archived'].includes(status)) {
        throw new AuditServiceError(
            'Invalid audit status.',
            {
                code: 'INVALID_AUDIT_STATUS',
                statusCode: 422,
            },
        );
    }

    return status;
}


/* -------------------------------------------------------------------------- */
/* Safe structured data                                                      */
/* -------------------------------------------------------------------------- */

function safeString(value, maxLength = MAX_STRING_LENGTH) {
    return String(value)
        .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
        .slice(0, maxLength);
}

function isReservedKey(key) {
    const normalized = String(key)
        .trim()
        .toLowerCase();

    return RESERVED_KEYS.has(normalized);
}

function sanitizeValue(value, depth = 0) {
    if (value === null || value === undefined) {
        return value ?? null;
    }

    if (depth > MAX_METADATA_DEPTH) {
        return '[truncated]';
    }

    if (typeof value === 'string') {
        return safeString(value);
    }

    if (typeof value === 'number') {
        return Number.isFinite(value)
            ? value
            : null;
    }

    if (typeof value === 'boolean') {
        return value;
    }

    if (value instanceof Date) {
        return value.toISOString();
    }

    if (value instanceof mongoose.Types.ObjectId) {
        return String(value);
    }

    if (Buffer.isBuffer(value)) {
        return '[binary omitted]';
    }

    if (Array.isArray(value)) {
        return value
            .slice(0, MAX_ARRAY_ITEMS)
            .map((item) => sanitizeValue(item, depth + 1));
    }

    if (typeof value === 'object') {
        const result = {};

        for (const [key, item] of Object.entries(value)) {
            if (isReservedKey(key)) {
                continue;
            }

            if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
                continue;
            }

            result[key] = sanitizeValue(item, depth + 1);
        }

        return result;
    }

    return safeString(value);
}

function sanitizeStructuredData(value, { allowNull = true } = {}) {
    if (value === undefined) {
        return allowNull ? null : {};
    }

    return sanitizeValue(value);
}


/* -------------------------------------------------------------------------- */
/* Actor / request context helpers                                            */
/* -------------------------------------------------------------------------- */

function resolveActorId(actor) {
    const value =
        actor?.id ??
        actor?.userId ??
        actor?._id ??
        actor?.actorUserId ??
        null;

    return value && isValidObjectId(value)
        ? new mongoose.Types.ObjectId(value)
        : null;
}

function normalizeActorType(actor) {
    const value = normalizeLower(
        actor?.userType ??
        actor?.type ??
        actor?.actorType ??
        'system',
    );

    return value.slice(0, 50) || 'system';
}

function resolveActorName(actor) {
    return safeString(
        normalizeString(
            actor?.displayName ??
            actor?.name ??
            actor?.fullName ??
            '',
        ),
        180,
    );
}

function resolveActorEmail(actor) {
    return safeString(
        normalizeEmail(actor?.email ?? actor?.actorEmail ?? ''),
        255,
    );
}

function normalizeIpAddress(value) {
    return safeString(
        normalizeString(value),
        128,
    );
}

function normalizeUserAgent(value) {
    return safeString(
        normalizeString(value),
        1000,
    );
}

export function getRequestAuditContext(req) {
    return {
        actor: req?.user ?? null,
        ipAddress:
            req?.ip ??
            req?.headers?.['x-forwarded-for'] ??
            req?.socket?.remoteAddress ??
            '',
        userAgent:
            req?.get?.('user-agent') ??
            req?.headers?.['user-agent'] ??
            '',
    };
}


/* -------------------------------------------------------------------------- */
/* Serialization                                                              */
/* -------------------------------------------------------------------------- */

function serializeAuditRecord(record) {
    if (!record) {
        return null;
    }

    if (typeof record.toSafeJSON === 'function') {
        return record.toSafeJSON();
    }

    return {
        id: record._id ? String(record._id) : null,
        action: record.action ?? '',
        module: record.module ?? '',
        title: record.title ?? '',
        description: record.description ?? '',
        actor: {
            id: record.actorUserId
                ? String(record.actorUserId)
                : null,
            name: record.actorName ?? '',
            email: record.actorEmail ?? '',
            type: record.actorType ?? 'system',
        },
        entity: {
            type: record.entityType ?? '',
            id: record.entityId ?? '',
            name: record.entityName ?? '',
        },
        vendorId: record.vendorId
            ? String(record.vendorId)
            : null,
        ipAddress: record.ipAddress ?? '',
        userAgent: record.userAgent ?? '',
        metadata: record.metadata ?? {},
        changes: record.changes ?? null,
        status: record.status ?? 'active',
        occurredAt: record.occurredAt ?? null,
        createdAt: record.createdAt ?? null,
    };
}


/* -------------------------------------------------------------------------- */
/* Filter builder                                                             */
/* -------------------------------------------------------------------------- */

function buildListFilter(options = {}) {
    const filter = {};

    const action = normalizeLower(options.action);
    const module = normalizeLower(options.module);
    const actorType = normalizeLower(options.actorType);
    const entityType = normalizeLower(options.entityType);
    const entityId = normalizeString(options.entityId);
    const status = normalizeStatus(options.status);
    const vendorId = options.vendorId;
    const actorUserId = options.actorUserId;
    const fromDate = normalizeDate(options.fromDate, 'fromDate');
    const toDate = normalizeDate(options.toDate, 'toDate');

    if (action) {
        filter.action = action.slice(0, 120);
    }

    if (module) {
        filter.module = module.slice(0, 120);
    }

    if (actorType) {
        filter.actorType = actorType.slice(0, 50);
    }

    if (entityType) {
        filter.entityType = entityType.slice(0, 120);
    }

    if (entityId) {
        filter.entityId = entityId.slice(0, 200);
    }

    if (status) {
        filter.status = status;
    }

    if (actorUserId) {
        filter.actorUserId = toObjectId(
            actorUserId,
            'actorUserId',
        );
    }

    if (vendorId) {
        filter.vendorId = toObjectId(
            vendorId,
            'vendorId',
        );
    }

    if (fromDate || toDate) {
        filter.occurredAt = {};

        if (fromDate) {
            filter.occurredAt.$gte = fromDate;
        }

        if (toDate) {
            filter.occurredAt.$lte = toDate;
        }
    }

    const search = normalizeSearch(options.search);

    if (search) {
        const escaped = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(escaped, 'i');

        filter.$or = [
            { action: regex },
            { module: regex },
            { title: regex },
            { description: regex },
            { actorName: regex },
            { actorEmail: regex },
            { entityType: regex },
            { entityId: regex },
            { entityName: regex },
        ];
    }

    return filter;
}


/* -------------------------------------------------------------------------- */
/* Audit write                                                                */
/* -------------------------------------------------------------------------- */

export async function recordAudit({
    action,
    module,
    title = '',
    description = '',
    actor = null,
    request = null,
    entityType = '',
    entityId = '',
    entityName = '',
    vendorId = null,
    metadata = {},
    changes = null,
    occurredAt = null,
    status = 'active',
    session = null,
} = {}) {
    const normalizedAction = normalizeLower(action);
    const normalizedModule = normalizeLower(module);

    if (!normalizedAction) {
        throw new AuditServiceError(
            'Audit action is required.',
            {
                code: 'AUDIT_ACTION_REQUIRED',
                statusCode: 422,
            },
        );
    }

    if (!normalizedModule) {
        throw new AuditServiceError(
            'Audit module is required.',
            {
                code: 'AUDIT_MODULE_REQUIRED',
                statusCode: 422,
            },
        );
    }

    const context = request
        ? getRequestAuditContext(request)
        : {};

    const effectiveActor = actor ?? context.actor ?? null;
    const actorUserId = resolveActorId(effectiveActor);

    const effectiveVendorId = vendorId ?? effectiveActor?.vendorId ?? null;

    let normalizedVendorId = null;
    if (effectiveVendorId) {
        normalizedVendorId = toObjectId(
            effectiveVendorId,
            'vendorId',
        );
    }

    const normalizedOccurredAt = normalizeDate(
        occurredAt,
        'occurredAt',
    );

    const normalizedStatus = normalizeStatus(status) || 'active';

    const document = new AuditLog({
        action: normalizedAction.slice(0, 120),
        module: normalizedModule.slice(0, 120),
        title: safeString(normalizeString(title), 200),
        description: safeString(normalizeString(description), 2000),
        actorUserId,
        actorName: resolveActorName(effectiveActor),
        actorEmail: resolveActorEmail(effectiveActor),
        actorType: normalizeActorType(effectiveActor),
        entityType: normalizeLower(entityType).slice(0, 120),
        entityId: normalizeString(entityId).slice(0, 200),
        entityName: safeString(normalizeString(entityName), 300),
        vendorId: normalizedVendorId,
        ipAddress: normalizeIpAddress(
            context.ipAddress ??
            request?.ip ??
            '',
        ),
        userAgent: normalizeUserAgent(
            context.userAgent ??
            request?.get?.('user-agent') ??
            '',
        ),
        metadata: sanitizeStructuredData(metadata),
        changes: sanitizeStructuredData(changes),
        status: normalizedStatus,
        ...(normalizedOccurredAt
            ? { occurredAt: normalizedOccurredAt }
            : {}),
    });

    try {
        await document.save(
            session
                ? { session }
                : undefined,
        );
    } catch (error) {
        if (error?.name === 'ValidationError') {
            const fields = {};

            for (const [field, detail] of Object.entries(error.errors || {})) {
                fields[field] = detail.message;
            }

            throw new AuditServiceError(
                'Audit event validation failed.',
                {
                    code: 'AUDIT_VALIDATION_ERROR',
                    statusCode: 422,
                    details: { fields },
                },
            );
        }

        if (error?.name === 'CastError') {
            throw new AuditServiceError(
                'One or more audit identifiers are invalid.',
                {
                    code: 'AUDIT_INVALID_IDENTIFIER',
                    statusCode: 422,
                },
            );
        }

        throw error;
    }

    return serializeAuditRecord(document);
}


/* -------------------------------------------------------------------------- */
/* Audit read                                                                 */
/* -------------------------------------------------------------------------- */

export async function listAuditLogs(options = {}) {
    const page = parsePage(options.page);
    const limit = parseLimit(options.limit);
    const skip = (page - 1) * limit;
    const filter = buildListFilter(options);

    const [items, total] = await Promise.all([
        AuditLog.find(filter)
            .sort({ occurredAt: -1, _id: -1 })
            .skip(skip)
            .limit(limit)
            .lean(),
        AuditLog.countDocuments(filter),
    ]);

    const totalPages = Math.ceil(total / limit);

    return {
        items: items.map(serializeAuditRecord),
        pagination: {
            page,
            limit,
            total,
            totalPages,
            hasNextPage: page < totalPages,
            hasPreviousPage: page > 1,
        },
        filters: {
            search: normalizeSearch(options.search),
            action: normalizeLower(options.action),
            module: normalizeLower(options.module),
            actorType: normalizeLower(options.actorType),
            entityType: normalizeLower(options.entityType),
            entityId: normalizeString(options.entityId),
            actorUserId: options.actorUserId
                ? String(options.actorUserId)
                : null,
            vendorId: options.vendorId
                ? String(options.vendorId)
                : null,
            status: normalizeStatus(options.status) ?? null,
            fromDate: normalizeDate(options.fromDate, 'fromDate'),
            toDate: normalizeDate(options.toDate, 'toDate'),
        },
    };
}


export async function getAuditLogById(id) {
    const _id = toObjectId(id, 'audit log id');

    const record = await AuditLog.findById(_id).lean();

    if (!record) {
        throw new AuditServiceError(
            'Audit log entry not found.',
            {
                code: 'AUDIT_NOT_FOUND',
                statusCode: 404,
            },
        );
    }

    return serializeAuditRecord(record);
}


export async function countAuditLogs(options = {}) {
    const filter = buildListFilter(options);
    return AuditLog.countDocuments(filter);
}


/* -------------------------------------------------------------------------- */
/* Immutable policy                                                           */
/* -------------------------------------------------------------------------- */

export async function updateAuditLog() {
    throw new AuditServiceError(
        'Audit log records are immutable and cannot be updated.',
        {
            code: 'AUDIT_IMMUTABLE',
            statusCode: 409,
        },
    );
}

export async function removeAuditLog() {
    throw new AuditServiceError(
        'Audit log records are immutable and cannot be deleted.',
        {
            code: 'AUDIT_IMMUTABLE',
            statusCode: 409,
        },
    );
}


/* -------------------------------------------------------------------------- */
/* Service object                                                             */
/* -------------------------------------------------------------------------- */

const auditService = {
    serviceName: 'auditService',
    recordAudit,
    create: recordAudit,
    listAuditLogs,
    list: listAuditLogs,
    getAuditLogById,
    get: getAuditLogById,
    countAuditLogs,
    count: countAuditLogs,
    updateAuditLog,
    removeAuditLog,
    getRequestAuditContext,
};


export default auditService;
