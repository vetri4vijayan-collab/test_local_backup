// src/services/settings/companySettingsService.js

import CompanySetting, {
  COMPANY_SETTING_KEY,
} from '../../models/CompanySetting.js';


/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const UPDATABLE_FIELDS = Object.freeze([
  'legalName',
  'taxId',
  'contactEmail',
  'supportPhone',
  'headquartersAddress',
]);


/**
 * Fields that may be returned to the frontend.
 *
 * Internal storage paths and database implementation details
 * are intentionally excluded.
 */
const PUBLIC_FIELDS = Object.freeze([
  'settingKey',
  'legalName',
  'taxId',
  'contactEmail',
  'supportPhone',
  'headquartersAddress',
  'logo',
  'favicon',
  'active',
  'createdAt',
  'updatedAt',
]);


/* -------------------------------------------------------------------------- */
/* Error helpers                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Service-layer error.
 *
 * Controllers can map these errors to HTTP status codes.
 */
export class CompanySettingsServiceError extends Error {
  constructor(
    message,
    {
      code = 'COMPANY_SETTINGS_ERROR',
      statusCode = 400,
      details = undefined,
      cause = undefined,
    } = {},
  ) {
    super(message);

    this.name =
      'CompanySettingsServiceError';

    this.code =
      code;

    this.statusCode =
      statusCode;

    this.details =
      details;

    if (cause) {
      this.cause =
        cause;
    }

    Error.captureStackTrace?.(
      this,
      CompanySettingsServiceError,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Validation helpers                                                         */
/* -------------------------------------------------------------------------- */

/**
 * Normalize a string.
 *
 * Empty strings are converted to an empty string.
 */
function normalizeString(value) {
  if (
    value === undefined ||
    value === null
  ) {
    return '';
  }

  return String(value).trim();
}


/**
 * Normalize email addresses.
 */
function normalizeEmail(value) {
  return normalizeString(
    value,
  ).toLowerCase();
}


/**
 * Validate an email at service level.
 *
 * Mongoose also has schema-level validation, but keeping
 * validation here gives the controller/service a clean
 * domain contract before persistence.
 */
function isValidEmail(email) {
  if (!email) {
    return false;
  }

  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
    email,
  );
}


/**
 * Validate a company profile update payload.
 *
 * The service validates only fields that belong to the
 * Company Profile itself.
 *
 * Unknown fields are rejected rather than silently ignored.
 */
function normalizeUpdatePayload(payload = {}) {
  if (
    payload === null ||
    typeof payload !== 'object' ||
    Array.isArray(payload)
  ) {
    throw new CompanySettingsServiceError(
      'Company profile payload must be an object.',
      {
        code:
          'INVALID_COMPANY_PROFILE_PAYLOAD',
        statusCode: 400,
      },
    );
  }


  const allowed =
    new Set(
      UPDATABLE_FIELDS,
    );


  const receivedFields =
    Object.keys(payload);


  const unknownFields =
    receivedFields.filter(
      (field) =>
        !allowed.has(field),
    );


  if (unknownFields.length > 0) {
    throw new CompanySettingsServiceError(
      'Company profile contains unsupported fields.',
      {
        code:
          'UNSUPPORTED_COMPANY_PROFILE_FIELDS',
        statusCode: 400,
        details: {
          fields:
            unknownFields,
        },
      },
    );
  }


  const update = {};


  /* ---------------------------------------------------------------------- */
  /* Legal name                                                             */
  /* ---------------------------------------------------------------------- */

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'legalName',
    )
  ) {
    const legalName =
      normalizeString(
        payload.legalName,
      );


    if (!legalName) {
      throw new CompanySettingsServiceError(
        'Company legal name is required.',
        {
          code:
            'COMPANY_LEGAL_NAME_REQUIRED',
          statusCode: 422,
        },
      );
    }


    if (
      legalName.length < 2 ||
      legalName.length > 200
    ) {
      throw new CompanySettingsServiceError(
        'Company legal name must contain between 2 and 200 characters.',
        {
          code:
            'INVALID_COMPANY_LEGAL_NAME',
          statusCode: 422,
        },
      );
    }


    update.legalName =
      legalName;
  }


  /* ---------------------------------------------------------------------- */
  /* Tax ID                                                                 */
  /* ---------------------------------------------------------------------- */

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'taxId',
    )
  ) {
    const taxId =
      normalizeString(
        payload.taxId,
      );


    if (!taxId) {
      throw new CompanySettingsServiceError(
        'Tax ID / VAT number is required.',
        {
          code:
            'COMPANY_TAX_ID_REQUIRED',
          statusCode: 422,
        },
      );
    }


    if (
      taxId.length > 100
    ) {
      throw new CompanySettingsServiceError(
        'Tax ID / VAT number cannot exceed 100 characters.',
        {
          code:
            'INVALID_COMPANY_TAX_ID',
          statusCode: 422,
        },
      );
    }


    update.taxId =
      taxId;
  }


  /* ---------------------------------------------------------------------- */
  /* Contact email                                                           */
  /* ---------------------------------------------------------------------- */

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'contactEmail',
    )
  ) {
    const contactEmail =
      normalizeEmail(
        payload.contactEmail,
      );


    if (!contactEmail) {
      throw new CompanySettingsServiceError(
        'Primary contact email is required.',
        {
          code:
            'COMPANY_EMAIL_REQUIRED',
          statusCode: 422,
        },
      );
    }


    if (
      contactEmail.length > 254
    ) {
      throw new CompanySettingsServiceError(
        'Primary contact email cannot exceed 254 characters.',
        {
          code:
            'INVALID_COMPANY_EMAIL',
          statusCode: 422,
        },
      );
    }


    if (
      !isValidEmail(
        contactEmail,
      )
    ) {
      throw new CompanySettingsServiceError(
        'Enter a valid primary contact email address.',
        {
          code:
            'INVALID_COMPANY_EMAIL',
          statusCode: 422,
        },
      );
    }


    update.contactEmail =
      contactEmail;
  }


  /* ---------------------------------------------------------------------- */
  /* Phone                                                                   */
  /* ---------------------------------------------------------------------- */

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'supportPhone',
    )
  ) {
    const supportPhone =
      normalizeString(
        payload.supportPhone,
      );


    if (
      supportPhone.length > 50
    ) {
      throw new CompanySettingsServiceError(
        'Support phone cannot exceed 50 characters.',
        {
          code:
            'INVALID_SUPPORT_PHONE',
          statusCode: 422,
        },
      );
    }


    update.supportPhone =
      supportPhone;
  }


  /* ---------------------------------------------------------------------- */
  /* Address                                                                 */
  /* ---------------------------------------------------------------------- */

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'headquartersAddress',
    )
  ) {
    const headquartersAddress =
      normalizeString(
        payload.headquartersAddress,
      );


    if (!headquartersAddress) {
      throw new CompanySettingsServiceError(
        'Headquarters address is required.',
        {
          code:
            'COMPANY_ADDRESS_REQUIRED',
          statusCode: 422,
        },
      );
    }


    if (
      headquartersAddress.length > 2000
    ) {
      throw new CompanySettingsServiceError(
        'Headquarters address cannot exceed 2000 characters.',
        {
          code:
            'INVALID_COMPANY_ADDRESS',
          statusCode: 422,
        },
      );
    }


    update.headquartersAddress =
      headquartersAddress;
  }


  return update;
}


/* -------------------------------------------------------------------------- */
/* Serialization                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Convert a Mongoose CompanySetting document into a safe
 * API-facing object.
 *
 * The actual local filesystem path is never exposed.
 *
 * The controller/storage layer will later turn the file
 * metadata into a protected API download URL.
 */
function serializeCompanySetting(
  company,
) {
  if (!company) {
    return null;
  }


  const object =
    typeof company.toObject ===
      'function'
      ? company.toObject({
          depopulate: true,
        })
      : {
          ...company,
        };


  const response = {};


  for (
    const field of PUBLIC_FIELDS
  ) {
    if (
      Object.prototype.hasOwnProperty.call(
        object,
        field,
      )
    ) {
      response[field] =
        object[field];
    }
  }


  /**
   * Storage metadata that is safe for the frontend.
   *
   * Do not expose:
   * - storageKey
   * - relativePath
   * - physical filesystem location
   */
  for (
    const fileField of [
      'logo',
      'favicon',
    ]
  ) {
    if (
      response[fileField]
    ) {
      const file =
        response[fileField];


      response[fileField] = {
        originalName:
          file.originalName ||
          null,

        mimeType:
          file.mimeType ||
          null,

        extension:
          file.extension ||
          null,

        size:
          file.size ??
          null,

        checksum:
          file.checksum ||
          null,

        uploadedAt:
          file.uploadedAt ||
          null,

        /**
         * Browser-facing URL will be assigned by
         * the controller after authentication/authorization.
         */
        url:
          null,
      };
    }
  }


  return response;
}


/* -------------------------------------------------------------------------- */
/* Get company profile                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Get the ARGUS company profile.
 *
 * Returns null when the profile has not yet been initialized.
 */
export async function getCompanyProfile() {
  const company =
    await CompanySetting.findOne({
      settingKey:
        COMPANY_SETTING_KEY,
    }).lean(false);


  return serializeCompanySetting(
    company,
  );
}


/* -------------------------------------------------------------------------- */
/* Get company profile document                                               */
/* -------------------------------------------------------------------------- */

/**
 * Internal helper.
 *
 * Unlike getCompanyProfile(), this returns the Mongoose
 * document and is intended for service/controller workflows
 * that need to modify files or fields.
 */
export async function getCompanyProfileDocument(
  {
    session = undefined,
  } = {},
) {
  const query =
    CompanySetting.findOne({
      settingKey:
        COMPANY_SETTING_KEY,
    });


  if (session) {
    query.session(
      session,
    );
  }


  return query.exec();
}


/* -------------------------------------------------------------------------- */
/* Create initial company profile                                             */
/* -------------------------------------------------------------------------- */

/**
 * Initialize Company Profile.
 *
 * This method must be called during application setup or
 * first-time configuration.
 *
 * We intentionally do NOT create fake/default business values.
 */
export async function initializeCompanyProfile(
  {
    legalName,
    taxId,
    contactEmail,
    supportPhone = '',
    headquartersAddress,
    createdBy = null,
  },
) {
  const existing =
    await CompanySetting.exists({
      settingKey:
        COMPANY_SETTING_KEY,
    });


  if (existing) {
    throw new CompanySettingsServiceError(
      'Company profile is already initialized.',
      {
        code:
          'COMPANY_PROFILE_ALREADY_INITIALIZED',
        statusCode: 409,
      },
    );
  }


  const normalized =
    normalizeUpdatePayload({
      legalName,
      taxId,
      contactEmail,
      supportPhone,
      headquartersAddress,
    });


  const company =
    new CompanySetting({
      settingKey:
        COMPANY_SETTING_KEY,

      legalName:
        normalized.legalName,

      taxId:
        normalized.taxId,

      contactEmail:
        normalized.contactEmail,

      supportPhone:
        normalized.supportPhone || '',

      headquartersAddress:
        normalized.headquartersAddress,

      active:
        true,

      createdBy:
        createdBy || null,

      updatedBy:
        createdBy || null,
    });


  await company.save();


  return serializeCompanySetting(
    company,
  );
}


/* -------------------------------------------------------------------------- */
/* Update company profile                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Update Company Profile text/settings fields.
 *
 * File replacement is intentionally handled separately.
 * This keeps file replacement atomic and easier to roll back.
 */
export async function updateCompanyProfile(
  {
    data,
    updatedBy,
  },
) {
  const normalized =
    normalizeUpdatePayload(
      data,
    );


  if (
    Object.keys(
      normalized,
    ).length === 0
  ) {
    throw new CompanySettingsServiceError(
      'No company profile fields were provided for update.',
      {
        code:
          'NO_COMPANY_PROFILE_CHANGES',
        statusCode: 400,
      },
    );
  }


  const company =
    await CompanySetting.findOne({
      settingKey:
        COMPANY_SETTING_KEY,
    });


  if (!company) {
    throw new CompanySettingsServiceError(
      'Company profile has not been initialized.',
      {
        code:
          'COMPANY_PROFILE_NOT_INITIALIZED',
        statusCode: 404,
      },
    );
  }


  /**
   * Capture the fields that actually changed.
   *
   * This is useful later for audit logging.
   */
  const changes = {};


  for (
    const field of Object.keys(
      normalized,
    )
  ) {
    const previousValue =
      company[field];

    const nextValue =
      normalized[field];


    if (
      previousValue !==
      nextValue
    ) {
      changes[field] = {
        before:
          previousValue,

        after:
          nextValue,
      };

      company[field] =
        nextValue;
    }
  }


  if (
    Object.keys(
      changes,
    ).length === 0
  ) {
    return {
      company:
        serializeCompanySetting(
          company,
        ),

      changed:
        false,

      changes: {},
    };
  }


  company.setUpdatedBy(
    updatedBy,
  );


  await company.save();


  return {
    company:
      serializeCompanySetting(
        company,
      ),

    changed:
      true,

    changes,
  };
}


/* -------------------------------------------------------------------------- */
/* Update logo metadata                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Replace company logo metadata.
 *
 * The physical file lifecycle is handled by storageService.
 *
 * Expected fileMetadata shape:
 *
 * {
 *   originalName,
 *   storageKey,
 *   relativePath,
 *   mimeType,
 *   extension,
 *   size,
 *   checksum,
 *   uploadedAt,
 *   uploadedBy
 * }
 */
export async function updateCompanyLogo(
  {
    fileMetadata,
    updatedBy,
  },
) {
  if (
    !fileMetadata ||
    typeof fileMetadata !== 'object'
  ) {
    throw new CompanySettingsServiceError(
      'Logo file metadata is required.',
      {
        code:
          'LOGO_METADATA_REQUIRED',
        statusCode: 400,
      },
    );
  }


  validateFileMetadata(
    fileMetadata,
    {
      field:
        'logo',
    },
  );


  const company =
    await getRequiredCompanyProfileDocument();


  const previousLogo =
    company.logo
      ? cloneFileMetadata(
          company.logo,
        )
      : null;


  company.logo =
    buildFileMetadata(
      fileMetadata,
    );


  company.setUpdatedBy(
    updatedBy,
  );


  await company.save();


  return {
    company:
      serializeCompanySetting(
        company,
      ),

    previousFile:
      previousLogo,
  };
}


/* -------------------------------------------------------------------------- */
/* Update favicon metadata                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Replace company favicon metadata.
 */
export async function updateCompanyFavicon(
  {
    fileMetadata,
    updatedBy,
  },
) {
  if (
    !fileMetadata ||
    typeof fileMetadata !== 'object'
  ) {
    throw new CompanySettingsServiceError(
      'Favicon file metadata is required.',
      {
        code:
          'FAVICON_METADATA_REQUIRED',
        statusCode: 400,
      },
    );
  }


  validateFileMetadata(
    fileMetadata,
    {
      field:
        'favicon',
    },
  );


  const company =
    await getRequiredCompanyProfileDocument();


  const previousFavicon =
    company.favicon
      ? cloneFileMetadata(
          company.favicon,
        )
      : null;


  company.favicon =
    buildFileMetadata(
      fileMetadata,
    );


  company.setUpdatedBy(
    updatedBy,
  );


  await company.save();


  return {
    company:
      serializeCompanySetting(
        company,
      ),

    previousFile:
      previousFavicon,
  };
}


/* -------------------------------------------------------------------------- */
/* Remove company logo                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Remove only the logo metadata from MongoDB.
 *
 * Actual physical file deletion should happen AFTER the DB
 * update succeeds.
 *
 * The caller/storage layer can then safely delete the
 * previous local file.
 */
export async function removeCompanyLogo(
  {
    updatedBy,
  } = {},
) {
  const company =
    await getRequiredCompanyProfileDocument();


  if (!company.logo) {
    return {
      company:
        serializeCompanySetting(
          company,
        ),

      removedFile:
        null,

      changed:
        false,
    };
  }


  const removedFile =
    cloneFileMetadata(
      company.logo,
    );


  company.logo =
    null;


  company.setUpdatedBy(
    updatedBy,
  );


  await company.save();


  return {
    company:
      serializeCompanySetting(
        company,
      ),

    removedFile,

    changed:
      true,
  };
}


/* -------------------------------------------------------------------------- */
/* Remove favicon                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Remove favicon metadata from MongoDB.
 */
export async function removeCompanyFavicon(
  {
    updatedBy,
  } = {},
) {
  const company =
    await getRequiredCompanyProfileDocument();


  if (!company.favicon) {
    return {
      company:
        serializeCompanySetting(
          company,
        ),

      removedFile:
        null,

      changed:
        false,
    };
  }


  const removedFile =
    cloneFileMetadata(
      company.favicon,
    );


  company.favicon =
    null;


  company.setUpdatedBy(
    updatedBy,
  );


  await company.save();


  return {
    company:
      serializeCompanySetting(
        company,
      ),

    removedFile,

    changed:
      true,
  };
}


/* -------------------------------------------------------------------------- */
/* Activate / deactivate profile                                              */
/* -------------------------------------------------------------------------- */

/**
 * Company profile can be marked active/inactive.
 *
 * This is primarily useful for platform-level configuration
 * and future multi-company support.
 */
export async function setCompanyProfileStatus(
  {
    active,
    updatedBy,
  },
) {
  if (
    typeof active !== 'boolean'
  ) {
    throw new CompanySettingsServiceError(
      'Company profile status must be a boolean.',
      {
        code:
          'INVALID_COMPANY_PROFILE_STATUS',
        statusCode: 422,
      },
    );
  }


  const company =
    await getRequiredCompanyProfileDocument();


  if (
    company.active === active
  ) {
    return {
      company:
        serializeCompanySetting(
          company,
        ),

      changed:
        false,
    };
  }


  company.active =
    active;


  company.setUpdatedBy(
    updatedBy,
  );


  await company.save();


  return {
    company:
      serializeCompanySetting(
        company,
      ),

    changed:
      true,
  };
}


/* -------------------------------------------------------------------------- */
/* File metadata validation                                                   */
/* -------------------------------------------------------------------------- */

function validateFileMetadata(
  metadata,
  {
    field,
  },
) {
  const requiredFields =
    [
      'storageKey',
      'relativePath',
      'mimeType',
      'size',
    ];


  for (
    const property of requiredFields
  ) {
    if (
      metadata[property] === undefined ||
      metadata[property] === null ||
      metadata[property] === ''
    ) {
      throw new CompanySettingsServiceError(
        `Invalid ${field} file metadata: ${property} is required.`,
        {
          code:
            'INVALID_FILE_METADATA',
          statusCode: 422,
          details: {
            field,
            property,
          },
        },
      );
    }
  }


  if (
    !Number.isInteger(
      metadata.size,
    ) ||
    metadata.size < 0
  ) {
    throw new CompanySettingsServiceError(
      `Invalid ${field} file size.`,
      {
        code:
          'INVALID_FILE_SIZE',
        statusCode: 422,
      },
    );
  }


  /**
   * Absolute filesystem paths should NEVER be written into
   * CompanySetting file metadata.
   *
   * Storage service should produce logical/relative references.
   */
  if (
    isAbsoluteFilesystemPath(
      metadata.relativePath,
    ) ||
    isAbsoluteFilesystemPath(
      metadata.storageKey,
    )
  ) {
    throw new CompanySettingsServiceError(
      `Invalid ${field} storage reference.`,
      {
        code:
          'INVALID_STORAGE_REFERENCE',
        statusCode: 422,
      },
    );
  }
}


/**
 * Detect common Unix/Windows absolute path forms.
 */
function isAbsoluteFilesystemPath(
  value,
) {
  if (
    typeof value !== 'string'
  ) {
    return false;
  }


  return (
    value.startsWith('/') ||
    value.startsWith('\\') ||
    /^[A-Za-z]:[\\/]/.test(
      value,
    )
  );
}


/* -------------------------------------------------------------------------- */
/* File metadata builders                                                     */
/* -------------------------------------------------------------------------- */

function buildFileMetadata(
  metadata,
) {
  return {
    originalName:
      normalizeString(
        metadata.originalName,
      ),

    storageKey:
      normalizeStorageReference(
        metadata.storageKey,
      ),

    relativePath:
      normalizeStorageReference(
        metadata.relativePath,
      ),

    mimeType:
      normalizeString(
        metadata.mimeType,
      ).toLowerCase(),

    extension:
      normalizeString(
        metadata.extension,
      ).toLowerCase(),

    size:
      Number(
        metadata.size,
      ),

    checksum:
      normalizeString(
        metadata.checksum,
      ),

    uploadedAt:
      metadata.uploadedAt
        ? new Date(
            metadata.uploadedAt,
          )
        : new Date(),

    uploadedBy:
      metadata.uploadedBy ||
      null,
  };
}


function cloneFileMetadata(
  metadata,
) {
  if (!metadata) {
    return null;
  }


  const object =
    typeof metadata.toObject ===
      'function'
      ? metadata.toObject()
      : {
          ...metadata,
        };


  delete object._id;


  return {
    ...object,
  };
}


/**
 * Normalize logical storage references.
 *
 * Backslashes are converted to forward slashes so the
 * database representation remains platform-neutral.
 */
function normalizeStorageReference(
  value,
) {
  return normalizeString(
    value,
  )
    .replace(/\\/g, '/')
    .replace(/^\/+/, '');
}


/* -------------------------------------------------------------------------- */
/* Required document helper                                                   */
/* -------------------------------------------------------------------------- */

async function getRequiredCompanyProfileDocument() {
  const company =
    await CompanySetting.findOne({
      settingKey:
        COMPANY_SETTING_KEY,
    });


  if (!company) {
    throw new CompanySettingsServiceError(
      'Company profile has not been initialized.',
      {
        code:
          'COMPANY_PROFILE_NOT_INITIALIZED',
        statusCode: 404,
      },
    );
  }


  return company;
}


/* -------------------------------------------------------------------------- */
/* Default export                                                             */
/* -------------------------------------------------------------------------- */

const companySettingsService =
  Object.freeze({
    getCompanyProfile,

    getCompanyProfileDocument,

    initializeCompanyProfile,

    updateCompanyProfile,

    updateCompanyLogo,

    updateCompanyFavicon,

    removeCompanyLogo,

    removeCompanyFavicon,

    setCompanyProfileStatus,
  });


export default companySettingsService;