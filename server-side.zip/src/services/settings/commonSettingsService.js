// Business-logic boundary: commonSettingsService.js
// Keep HTTP concerns in controllers and perform multi-step writes in PostgreSQL transactions.
export const serviceName = 'commonSettingsService';
