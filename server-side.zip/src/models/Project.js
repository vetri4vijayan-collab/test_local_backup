// ARGUS data model contract for Project.
// SQL is authoritative; service layer owns transaction/query rules.
export const Project = Object.freeze({ table: 'Project' });
