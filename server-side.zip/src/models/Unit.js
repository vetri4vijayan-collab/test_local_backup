// ARGUS data model contract for Unit.
// SQL is authoritative; service layer owns transaction/query rules.
export const Unit = Object.freeze({ table: 'Unit' });
