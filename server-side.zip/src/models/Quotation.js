// ARGUS data model contract for Quotation.
// SQL is authoritative; service layer owns transaction/query rules.
export const Quotation = Object.freeze({ table: 'Quotation' });
