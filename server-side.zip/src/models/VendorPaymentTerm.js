import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const vendorPaymentTermSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, "Payment term name is required."],
      trim: true,
      minlength: 1,
      maxlength: 120,
      index: true,
    },

    description: {
      type: String,
      required: [true, "Payment term description is required."],
      trim: true,
      minlength: 1,
      maxlength: 1000,
    },

    status: {
      type: Boolean,
      required: true,
      default: true,
      index: true,
    },

    sortOrder: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
      index: true,
    },

    createdBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    updatedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    collection: "vendor_payment_terms",
  },
);

vendorPaymentTermSchema.index(
  { name: 1 },
  {
    unique: true,
    collation: {
      locale: "en",
      strength: 2,
    },
  },
);

vendorPaymentTermSchema.index({
  sortOrder: 1,
  name: 1,
});

export default (
  models.VendorPaymentTerm ||
  model("VendorPaymentTerm", vendorPaymentTermSchema)
);
