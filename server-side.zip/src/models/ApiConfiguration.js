// ARGUS data model contract for ApiConfiguration.
// SQL is authoritative; service layer owns transaction/query rules.
export const ApiConfiguration = Object.freeze({ table: 'ApiConfiguration' });
