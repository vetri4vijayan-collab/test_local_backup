// ARGUS data model contract for RateCategory.
// SQL is authoritative; service layer owns transaction/query rules.
export const RateCategory = Object.freeze({ table: 'RateCategory' });
