import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const vendorStatusSchema = new Schema(
    {
        status: {
            type: String,
            required: [true, "Vendor status is required."],
            trim: true,
            minlength: 1,
            maxlength: 100,
        },
        color: {
            type: String,
            required: true,
            enum: ["Green", "Red", "Gray", "Amber"],
            default: "Gray",
        },
        description: {
            type: String,
            required: [true, "Vendor status description is required."],
            trim: true,
            minlength: 1,
            maxlength: 1000,
        },
        active: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },
        sortOrder: {
            type: Number,
            required: true,
            default: 0,
            min: 0,
            index: true,
        },
        system: {
            type: Boolean,
            default: false,
            index: true,
        },
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "vendor_statuses",
        timestamps: true,
        strict: "throw",
        versionKey: false,
    },
);

vendorStatusSchema.index(
    { status: 1 },
    {
        unique: true,
        name: "vendor_statuses_status_unique",
        collation: { locale: "en", strength: 2 },
    },
);

vendorStatusSchema.index({ active: 1, sortOrder: 1, status: 1 });

export default (
    models.VendorStatus ||
    model("VendorStatus", vendorStatusSchema)
);
