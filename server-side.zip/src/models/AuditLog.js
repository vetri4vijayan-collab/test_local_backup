import mongoose from "mongoose";

const {
    Schema,
    model,
    models,
} = mongoose;


/*
|--------------------------------------------------------------------------
| Audit Log
|--------------------------------------------------------------------------
|
| Immutable application audit trail.
|
| Audit records are intentionally independent from business documents so
| they remain available even after a related document changes status.
|
| Typical records:
|
|   user.created
|   user.updated
|   user.status_changed
|   user.password_reset
|   role.created
|   role.updated
|   permission_matrix.updated
|   auth.login
|   auth.logout
|
| The actual audit write is owned by auditService.js.
| Controllers/services should not mutate an existing audit record.
|--------------------------------------------------------------------------
*/


const auditLogSchema =
    new Schema(
        {
            /*
             * Action performed.
             *
             * Keep this as a stable machine-readable identifier.
             */
            action: {
                type: String,
                required: true,
                trim: true,
                lowercase: true,
                maxlength: 120,
                match: /^[a-z0-9_.:-]+$/,
                index: true,
            },


            /*
             * Logical module/resource.
             *
             * Examples:
             * user_management
             * roles_permissions
             * vendor
             * quotation
             */
            module: {
                type: String,
                required: true,
                trim: true,
                lowercase: true,
                maxlength: 120,
                index: true,
            },


            /*
             * Human-readable event title.
             *
             * This is presentation metadata only; action/module remain
             * the stable machine-readable identifiers.
             */
            title: {
                type: String,
                default: "",
                trim: true,
                maxlength: 200,
            },


            /*
             * Optional description shown in activity timelines.
             */
            description: {
                type: String,
                default: "",
                trim: true,
                maxlength: 2000,
            },


            /*
             * The authenticated user who caused the event.
             *
             * Nullable for system/background events.
             */
            actorUserId: {
                type: Schema.Types.ObjectId,
                ref: "User",
                default: null,
                index: true,
            },


            /*
             * Snapshots prevent the timeline from changing historically
             * when a user's display name/email later changes.
             */
            actorName: {
                type: String,
                default: "",
                trim: true,
                maxlength: 180,
            },

            actorEmail: {
                type: String,
                default: "",
                trim: true,
                lowercase: true,
                maxlength: 255,
            },


            /*
             * Authentication realm / user type at event time.
             *
             * Examples:
             * admin
             * internal
             * vendor
             * system
             */
            actorType: {
                type: String,
                default: "system",
                trim: true,
                lowercase: true,
                maxlength: 50,
                index: true,
            },


            /*
             * Target resource.
             *
             * entityId is intentionally stored as a string so audit events
             * can cover MongoDB ObjectIds as well as non-ObjectId business
             * keys/codes.
             */
            entityType: {
                type: String,
                default: "",
                trim: true,
                lowercase: true,
                maxlength: 120,
                index: true,
            },

            entityId: {
                type: String,
                default: "",
                trim: true,
                maxlength: 200,
                index: true,
            },

            entityName: {
                type: String,
                default: "",
                trim: true,
                maxlength: 300,
            },


            /*
             * Optional vendor scope.
             *
             * Useful for vendor-side records and future audit filtering.
             */
            vendorId: {
                type: Schema.Types.ObjectId,
                ref: "Vendor",
                default: null,
                index: true,
            },


            /*
             * Optional request context.
             *
             * Store IP/user-agent for security investigation, but avoid
             * putting authentication tokens or passwords into metadata.
             */
            ipAddress: {
                type: String,
                default: "",
                trim: true,
                maxlength: 128,
            },

            userAgent: {
                type: String,
                default: "",
                trim: true,
                maxlength: 1000,
            },


            /*
             * Safe structured event details.
             *
             * Services decide which fields are suitable to persist.
             * Do not store passwords, tokens, session secrets, or file
             * contents here.
             */
            metadata: {
                type: Schema.Types.Mixed,
                default: () => ({}),
            },


            /*
             * Optional before/after snapshots for administrative changes.
             *
             * Keep them deliberately optional because many events do not
             * need document snapshots.
             */
            changes: {
                type: Schema.Types.Mixed,
                default: null,
            },


            /*
             * Audit records are append-only.
             *
             * This status allows future retention/archive workflows without
             * exposing destructive deletion through normal application UI.
             */
            status: {
                type: String,
                enum: [
                    "active",
                    "archived",
                ],
                default: "active",
                index: true,
            },


            /*
             * When the business event occurred.
             *
             * createdAt remains the database insertion timestamp.
             */
            occurredAt: {
                type: Date,
                default: Date.now,
                required: true,
                index: true,
            },
        },
        {
            timestamps: true,
            strict: "throw",
            versionKey: false,
            minimize: false,
        },
    );


/*
|--------------------------------------------------------------------------
| Compound indexes
|--------------------------------------------------------------------------
|
| These support the common Admin Activity Log use cases:
|   - a user's timeline
|   - a specific entity's timeline
|   - module/event filtering
|   - latest activity first
|--------------------------------------------------------------------------
*/

auditLogSchema.index({
    actorUserId: 1,
    occurredAt: -1,
});

auditLogSchema.index({
    entityType: 1,
    entityId: 1,
    occurredAt: -1,
});

auditLogSchema.index({
    module: 1,
    occurredAt: -1,
});

auditLogSchema.index({
    vendorId: 1,
    occurredAt: -1,
});


/*
|--------------------------------------------------------------------------
| Immutability
|--------------------------------------------------------------------------
|
| Normal application code must append new events rather than modifying
| existing audit records.
|
| Query/update middleware explicitly blocks mutation attempts.
|--------------------------------------------------------------------------
*/

auditLogSchema.pre(
    "findOneAndUpdate",
    function blockAuditUpdate() {
        throw new Error(
            "Audit log records are immutable.",
        );
    },
);

auditLogSchema.pre(
    "updateOne",
    function blockAuditUpdateOne() {
        throw new Error(
            "Audit log records are immutable.",
        );
    },
);

auditLogSchema.pre(
    "updateMany",
    function blockAuditUpdateMany() {
        throw new Error(
            "Audit log records are immutable.",
        );
    },
);

auditLogSchema.pre(
    "replaceOne",
    function blockAuditReplace() {
        throw new Error(
            "Audit log records are immutable.",
        );
    },
);


/*
|--------------------------------------------------------------------------
| Serialization
|--------------------------------------------------------------------------
|
| Keep the model response safe and predictable.
|--------------------------------------------------------------------------
*/

auditLogSchema.methods.toSafeJSON =
    function toSafeJSON() {
        const data =
            this.toObject();

        return {
            id:
                String(
                    data._id,
                ),

            action:
                data.action,

            module:
                data.module,

            title:
                data.title,

            description:
                data.description,

            actor: {
                id:
                    data.actorUserId
                        ? String(
                              data.actorUserId,
                          )
                        : null,

                name:
                    data.actorName,

                email:
                    data.actorEmail,

                type:
                    data.actorType,
            },

            entity: {
                type:
                    data.entityType,

                id:
                    data.entityId,

                name:
                    data.entityName,
            },

            vendorId:
                data.vendorId
                    ? String(
                          data.vendorId,
                      )
                    : null,

            ipAddress:
                data.ipAddress,

            userAgent:
                data.userAgent,

            metadata:
                data.metadata,

            changes:
                data.changes,

            status:
                data.status,

            occurredAt:
                data.occurredAt,

            createdAt:
                data.createdAt,
        };
    };


/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const AuditLog =
    models.AuditLog ||
    model(
        "AuditLog",
        auditLogSchema,
    );


export default AuditLog;
