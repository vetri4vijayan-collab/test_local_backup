// ARGUS data model contract for QuotationAttachment.
// SQL is authoritative; service layer owns transaction/query rules.
export const QuotationAttachment = Object.freeze({ table: 'QuotationAttachment' });
