// ARGUS data model contract for Vendor.
// SQL is authoritative; service layer owns transaction/query rules.
export const Vendor = Object.freeze({ table: 'Vendor' });
