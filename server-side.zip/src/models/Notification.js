// ARGUS data model contract for Notification.
// SQL is authoritative; service layer owns transaction/query rules.
export const Notification = Object.freeze({ table: 'Notification' });
