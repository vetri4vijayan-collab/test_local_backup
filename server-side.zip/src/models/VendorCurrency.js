import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const vendorCurrencySchema = new Schema(
    {
        name: {
            type: String,
            required: [true, "Currency name is required."],
            trim: true,
            minlength: 1,
            maxlength: 120,
            index: true,
        },

        code: {
            type: String,
            required: [true, "Currency code is required."],
            trim: true,
            uppercase: true,
            minlength: 3,
            maxlength: 3,
            match: [
                /^[A-Z]{3}$/,
                "Currency code must be exactly 3 letters.",
            ],
            unique: true,
            index: true,
        },

        symbol: {
            type: String,
            required: [true, "Currency symbol is required."],
            trim: true,
            minlength: 1,
            maxlength: 12,
        },

        description: {
            type: String,
            required: [true, "Currency description is required."],
            trim: true,
            minlength: 1,
            maxlength: 1000,
        },

        status: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },

        sortOrder: {
            type: Number,
            required: true,
            default: 0,
            min: 0,
            index: true,
        },

        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        timestamps: true,
        collection: "vendor_currencies",
    },
);

vendorCurrencySchema.index(
    { name: 1 },
    {
        unique: true,
        collation: {
            locale: "en",
            strength: 2,
        },
    },
);

vendorCurrencySchema.index({
    sortOrder: 1,
    name: 1,
});

export default (
    models.VendorCurrency ||
    model("VendorCurrency", vendorCurrencySchema)
);