import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const vendorIndustrySectorSchema = new Schema(
    {
        name: {
            type: String,
            required: [true, "Industry sector name is required."],
            trim: true,
            minlength: 1,
            maxlength: 120,
            index: true,
        },

        description: {
            type: String,
            required: [true, "Industry sector description is required."],
            trim: true,
            minlength: 1,
            maxlength: 1000,
        },

        status: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },

        sortOrder: {
            type: Number,
            required: true,
            default: 0,
            min: 0,
            index: true,
        },

        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "vendor_industry_sectors",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

vendorIndustrySectorSchema.index(
    { name: 1 },
    {
        unique: true,
        name: "vendor_industry_sectors_name_unique",
        collation: {
            locale: "en",
            strength: 2,
        },
    },
);

vendorIndustrySectorSchema.index(
    { status: 1, sortOrder: 1, name: 1 },
    { name: "vendor_industry_sectors_status_sort_name" },
);

export default (
    models.VendorIndustrySector ||
    model("VendorIndustrySector", vendorIndustrySectorSchema)
);
