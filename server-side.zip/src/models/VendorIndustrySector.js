// ARGUS data model contract for VendorIndustrySector.
// SQL is authoritative; service layer owns transaction/query rules.
export const VendorIndustrySector = Object.freeze({ table: 'VendorIndustrySector' });
