import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const vendorCategorySchema = new Schema(
    {
        name: {
            type: String,
            required: [true, "Category name is required."],
            trim: true,
            minlength: 2,
            maxlength: 160,
        },

        nameNormalized: {
            type: String,
            required: true,
            unique: true,
            index: true,
        },

        description: {
            type: String,
            required: [true, "Description is required."],
            trim: true,
            minlength: 1,
            maxlength: 1000,
        },

        status: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },

        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        timestamps: true,
        versionKey: false,
    },
);

vendorCategorySchema.pre("validate", function normalizeCategoryName() {
    this.name = String(this.name || "").trim();
    this.nameNormalized = this.name.toLocaleLowerCase();
    this.description = String(this.description || "").trim();
});

vendorCategorySchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: this._id.toString(),
        name: this.name,
        description: this.description,
        status: this.status === true,
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
    };
};

export default models.VendorCategory || model("VendorCategory", vendorCategorySchema);
