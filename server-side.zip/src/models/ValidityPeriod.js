// ARGUS data model contract for ValidityPeriod.
// SQL is authoritative; service layer owns transaction/query rules.
export const ValidityPeriod = Object.freeze({ table: 'ValidityPeriod' });
