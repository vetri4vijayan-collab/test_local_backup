// src/models/RateHistory.js

import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Rate History
|--------------------------------------------------------------------------
|
| Existing frontend contract:
|
| {
|     rate: number;
|     effectiveDate: string;
|     updatedAt: string;
|     updatedBy: string;
| }
|
| Backend additionally stores:
|
|   marketRateItemId
|
| so every rate-history record belongs to one Master Rate item.
|
|--------------------------------------------------------------------------
*/

const rateHistorySchema = new Schema(
    {
        /*
         * Parent Master Rate item.
         *
         * This should reference the MarketRateItem model.
         */
        marketRateItemId: {
            type: Schema.Types.ObjectId,
            ref: "MarketRateItem",
            required: [
                true,
                "Master rate item is required.",
            ],
            index: true,
        },

        /*
         * Historical standard rate.
         */
        rate: {
            type: Number,
            required: [
                true,
                "Rate is required.",
            ],
            min: [
                0,
                "Rate cannot be negative.",
            ],
            finite: true,
        },

        /*
         * Date from which this rate becomes effective.
         *
         * Stored as a Date rather than a formatted string.
         * API serialization can return YYYY-MM-DD to match the
         * existing frontend.
         */
        effectiveDate: {
            type: Date,
            required: [
                true,
                "Effective date is required.",
            ],
            index: true,
        },

        /*
         * User who changed the rate.
         */
        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
            index: true,
        },

        /*
         * Human-readable fallback used when the frontend needs
         * to display who made the historical change.
         *
         * This is intentionally stored as a snapshot because a user's
         * display name may change later.
         */
        updatedByName: {
            type: String,
            trim: true,
            maxlength: 150,
            default: "",
        },

        /*
         * Optional reason for changing a master rate.
         *
         * The current UI does not expose this field, so it remains
         * optional for future audit/change-management functionality.
         */
        changeReason: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: "",
        },
    },
    {
        collection: "rate_histories",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

/*
 * History is normally read newest-effective-date first.
 */
rateHistorySchema.index(
    {
        marketRateItemId: 1,
        effectiveDate: -1,
        createdAt: -1,
    },
    {
        name:
            "rate_histories_item_effective_created",
    },
);

/*
 * Supports latest/current-rate lookup.
 */
rateHistorySchema.index(
    {
        marketRateItemId: 1,
        effectiveDate: -1,
    },
    {
        name:
            "rate_histories_item_effective",
    },
);

/*
 * Useful for audit/reporting queries.
 */
rateHistorySchema.index(
    {
        updatedBy: 1,
        updatedAt: -1,
    },
    {
        name:
            "rate_histories_updated_by_at",
    },
);

/*
|--------------------------------------------------------------------------
| Validation / Normalization
|--------------------------------------------------------------------------
*/

rateHistorySchema.pre(
    "validate",
    function rateHistoryValidation() {
        if (
            typeof this.updatedByName ===
            "string"
        ) {
            this.updatedByName =
                this.updatedByName.trim();
        }

        if (
            typeof this.changeReason ===
            "string"
        ) {
            this.changeReason =
                this.changeReason.trim();
        }

        /*
         * Normalize date to the beginning of the day.
         *
         * The frontend uses YYYY-MM-DD and does not represent
         * a time component for effectiveDate.
         */
        if (
            this.effectiveDate
        ) {
            const date =
                new Date(
                    this.effectiveDate,
                );

            if (
                Number.isNaN(
                    date.getTime(),
                )
            ) {
                this.invalidate(
                    "effectiveDate",
                    "Invalid effective date.",
                );
            } else {
                date.setHours(
                    0,
                    0,
                    0,
                    0,
                );

                this.effectiveDate =
                    date;
            }
        }
    },
);

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Format effective date for the existing frontend contract.
 */
rateHistorySchema.methods.getEffectiveDateISO =
    function getEffectiveDateISO() {
        if (
            !this.effectiveDate
        ) {
            return "";
        }

        const year =
            this.effectiveDate
                .getFullYear();

        const month =
            String(
                this.effectiveDate
                    .getMonth() + 1,
            ).padStart(
                2,
                "0",
            );

        const day =
            String(
                this.effectiveDate
                    .getDate(),
            ).padStart(
                2,
                "0",
            );

        return `${year}-${month}-${day}`;
    };

/**
 * Safe frontend representation.
 *
 * This returns exactly the shape expected by RateHistoryOffcanvas.tsx.
 */
rateHistorySchema.methods.toSafeJSON =
    function toSafeJSON() {
        return {
            id:
                this._id?.toString(),

            rate:
                Number(
                    this.rate,
                ),

            effectiveDate:
                this.getEffectiveDateISO(),

            updatedAt:
                this.updatedAt
                    ? this.updatedAt
                          .toISOString()
                    : "",

            updatedBy:
                this.updatedByName ||
                (
                    this.updatedBy
                        ? this.updatedBy.toString()
                        : ""
                ),
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Get complete history for one Master Rate item.
 *
 * Newest effective rate appears first, matching the current UI where
 * history item 0 is marked "Current".
 */
rateHistorySchema.statics.findByItem =
    function findByItem(
        marketRateItemId,
    ) {
        return this.find({
            marketRateItemId,
        }).sort({
            effectiveDate: -1,
            createdAt: -1,
        });
    };

/**
 * Get history in chronological order.
 */
rateHistorySchema.statics.findByItemChronological =
    function findByItemChronological(
        marketRateItemId,
    ) {
        return this.find({
            marketRateItemId,
        }).sort({
            effectiveDate: 1,
            createdAt: 1,
        });
    };

/**
 * Get the latest/current historical rate.
 */
rateHistorySchema.statics.findLatestByItem =
    function findLatestByItem(
        marketRateItemId,
    ) {
        return this.findOne({
            marketRateItemId,
        }).sort({
            effectiveDate: -1,
            createdAt: -1,
        });
    };

/**
 * Find history records effective on/before a date.
 */
rateHistorySchema.statics.findEffectiveRate =
    function findEffectiveRate(
        marketRateItemId,
        effectiveDate,
    ) {
        return this.findOne({
            marketRateItemId,

            effectiveDate: {
                $lte:
                    effectiveDate,
            },
        }).sort({
            effectiveDate: -1,
            createdAt: -1,
        });
    };

/**
 * Count how many historical changes an item has.
 */
rateHistorySchema.statics.countByItem =
    function countByItem(
        marketRateItemId,
    ) {
        return this.countDocuments({
            marketRateItemId,
        });
    };

/*
|--------------------------------------------------------------------------
| JSON Serialization
|--------------------------------------------------------------------------
*/

rateHistorySchema.set(
    "toJSON",
    {
        transform(_doc, ret) {
            const effectiveDate =
                ret.effectiveDate
                    ? formatDateOnly(
                          ret.effectiveDate,
                      )
                    : "";

            const updatedAt =
                ret.updatedAt
                    ? new Date(
                          ret.updatedAt,
                      ).toISOString()
                    : "";

            return {
                id:
                    ret._id
                        ? ret._id.toString()
                        : undefined,

                /*
                 * Existing frontend contract.
                 */
                rate:
                    Number(
                        ret.rate,
                    ),

                effectiveDate,

                updatedAt,

                updatedBy:
                    ret.updatedByName ||
                    (
                        ret.updatedBy
                            ? ret.updatedBy.toString()
                            : ""
                    ),
            };
        },
    },
);

rateHistorySchema.set(
    "toObject",
    {
        transform(_doc, ret) {
            ret.id =
                ret._id
                    ? ret._id.toString()
                    : undefined;

            delete ret._id;

            return ret;
        },
    },
);

/*
|--------------------------------------------------------------------------
| Date Helper
|--------------------------------------------------------------------------
*/

function formatDateOnly(
    value,
) {
    const date =
        value instanceof Date
            ? value
            : new Date(value);

    if (
        Number.isNaN(
            date.getTime(),
        )
    ) {
        return "";
    }

    /*
     * Use local date components because effectiveDate is a
     * date-only business value, not an instant in time.
     */
    const year =
        date.getFullYear();

    const month =
        String(
            date.getMonth() + 1,
        ).padStart(
            2,
            "0",
        );

    const day =
        String(
            date.getDate(),
        ).padStart(
            2,
            "0",
        );

    return `${year}-${month}-${day}`;
}

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const RateHistory =
    models.RateHistory ||
    model(
        "RateHistory",
        rateHistorySchema,
    );

export {
    RateHistory,
    rateHistorySchema,
};

export default RateHistory;