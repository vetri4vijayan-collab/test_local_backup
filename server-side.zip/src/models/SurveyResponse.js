// ARGUS data model contract for SurveyResponse.
// SQL is authoritative; service layer owns transaction/query rules.
export const SurveyResponse = Object.freeze({ table: 'SurveyResponse' });
