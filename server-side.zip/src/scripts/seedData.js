
// src/scripts/seedData.js

import bcrypt from "bcrypt";

import env from "../config/env.js";
import {
    connectDatabase,
    disconnectDatabase,
} from "../config/database.js";

import User from "../models/User.js";
import Role from "../models/Role.js";
import Permission from "../models/Permission.js";
import RolePermission from "../models/RolePermission.js";

/*
|--------------------------------------------------------------------------
| ARGUS MongoDB Seed
|--------------------------------------------------------------------------
|
| Creates the initial authorization foundation:
|
|   Permissions
|       ↓
|   workspace_owner
|       ↓
|   RolePermission
|       ↓
|   Bootstrap User
|
| This script is intentionally idempotent.
|
| Running:
|
|   npm run db:seed
|
| multiple times should not create duplicate roles or permissions.
|
|--------------------------------------------------------------------------
*/

/* -------------------------------------------------------------------------- */
/* Bootstrap configuration                                                    */
/* -------------------------------------------------------------------------- */

const BOOTSTRAP_ADMIN_EMAIL =
    String(
        process.env.BOOTSTRAP_ADMIN_EMAIL ||
            "",
    )
        .trim()
        .toLowerCase();

const BOOTSTRAP_ADMIN_PASSWORD =
    String(
        process.env.BOOTSTRAP_ADMIN_PASSWORD ||
            "",
    );

const BOOTSTRAP_ADMIN_NAME =
    String(
        process.env.BOOTSTRAP_ADMIN_NAME ||
            "ARGUS Workspace Owner",
    ).trim();

/* -------------------------------------------------------------------------- */
/* Permission catalog                                                         */
/* -------------------------------------------------------------------------- */

/*
 * Keep the existing ARGUS application permission vocabulary.
 *
 * Additional Settings permissions are included because the Settings
 * module is being built first.
 */
const DEFAULT_PERMISSION_ACTIONS = Object.freeze({
    view: true,
    add: true,
    edit: true,
    delete: true,
});
const PERMISSIONS = [
    {
        key: "dashboard",
        name: "Dashboard",
        category: "core",
        sortOrder: 10,
        description:
            "Application dashboard access.",
    },

    {
        key: "vendor",
        name: "Vendor Management",
        category: "procurement",
        sortOrder: 20,
        description:
            "Vendor management and vendor records.",
    },

    {
        key: "master_rate",
        name: "Master Rate Schedule",
        category: "procurement",
        sortOrder: 30,
        description:
            "Master rate schedules and rate items.",
    },

    {
        key: "boq",
        name: "BOQ",
        category: "procurement",
        sortOrder: 40,
        description:
            "Bill of quantities management.",
    },

    {
        key: "rfq",
        name: "RFQ",
        category: "procurement",
        sortOrder: 50,
        description:
            "Request for quotation management.",
    },

    {
        key: "quotation",
        name: "Quotation",
        category: "procurement",
        sortOrder: 60,
        description:
            "Vendor quotation management.",
    },

    {
        key: "commercial",
        name: "Commercial Comparison & Award",
        category: "procurement",
        sortOrder: 70,
        description:
            "Commercial comparison and award workflows.",
    },

    {
        key: "project",
        name: "Projects",
        category: "project",
        sortOrder: 80,
        description:
            "Project management.",
    },

    {
        key: "task",
        name: "Tasks",
        category: "project",
        sortOrder: 90,
        description:
            "Project task management.",
    },

    {
        key: "budget",
        name: "Budget",
        category: "finance",
        sortOrder: 100,
        description:
            "Project budget management.",
    },

    {
        key: "invoice",
        name: "Invoices",
        category: "finance",
        sortOrder: 110,
        description:
            "Invoice management.",
    },

    {
        key: "payment",
        name: "Payments",
        category: "finance",
        sortOrder: 120,
        description:
            "Payment management.",
    },

    {
        key: "survey_report",
        name: "Survey Report",
        category: "survey",
        sortOrder: 130,
        description:
            "Survey and report management.",
    },

    {
        key: "user_management",
        name: "User Management",
        category: "administration",
        sortOrder: 140,
        description:
            "Internal user administration.",
    },

    {
        key: "roles_permissions",
        name: "Roles & Permissions",
        category: "settings",
        sortOrder: 150,
        description:
            "Role and permission administration.",
    },

    {
        key: "settings",
        name: "Settings",
        category: "settings",
        sortOrder: 160,
        description:
            "Application settings area.",
    },

    {
        key: "company_settings",
        name: "Company Information",
        category: "settings",
        sortOrder: 161,
        description:
            "Company identity, contact information and branding.",
    },

    {
        key: "api_configuration",
        name: "API Configuration",
        category: "settings",
        sortOrder: 162,
        description:
            "External API configuration.",
    },

    {
        key: "vendor_settings",
        name: "Vendor Settings",
        category: "settings",
        sortOrder: 163,
        description:
            "Vendor portal settings.",
    },

    {
        key: "common_settings",
        name: "Common Settings",
        category: "settings",
        sortOrder: 164,
        description:
            "Common application settings.",
    },

    {
        key: "master_rate_settings",
        name: "Master Rate Settings",
        category: "settings",
        sortOrder: 165,
        description:
            "Master-rate-related application settings.",
    },

    {
        key: "audit_log",
        name: "Audit Log",
        category: "administration",
        sortOrder: 170,
        description:
            "Audit history and security events.",
    },
];

/* -------------------------------------------------------------------------- */
/* System role catalog                                                        */
/* -------------------------------------------------------------------------- */

const ROLES = [
    /*
     * Admin accounts authenticate in the "admin" realm while internal
     * accounts authenticate in the "internal" realm. These system roles
     * are explicitly assignable to both user types, so their role realm
     * must be "both".
     */
    {
        key: "workspace_owner",
        name: "Workspace Owner",
        description:
            "Full administrative access to the ARGUS workspace.",
        realm: "both",
        allowedUserTypes: [
            "admin",
            "internal",
        ],
        system: true,
        ownerRole: true,
        sortOrder: 10,
    },

    {
        key: "network_admin",
        name: "Network Admin",
        description:
            "Administrative access to assigned internal modules.",
        realm: "both",
        allowedUserTypes: [
            "admin",
            "internal",
        ],
        system: true,
        ownerRole: false,
        sortOrder: 20,
    },

    {
        key: "field_technician",
        name: "Field Technician",
        description:
            "Operational field access based on assigned permissions.",
        realm: "both",
        allowedUserTypes: [
            "admin",
            "internal",
        ],
        system: true,
        ownerRole: false,
        sortOrder: 30,
    },

    {
        key: "billing_manager",
        name: "Billing Manager",
        description:
            "Finance and billing access based on assigned permissions.",
        realm: "both",
        allowedUserTypes: [
            "admin",
            "internal",
        ],
        system: true,
        ownerRole: false,
        sortOrder: 40,
    },

    {
        key: "vendor_admin",
        name: "Vendor Admin",
        description:
            "Vendor portal administration.",
        realm: "vendor",
        allowedUserTypes: [
            "vendor",
        ],
        system: true,
        ownerRole: false,
        sortOrder: 50,
    },
];

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

function validateBootstrapConfiguration() {
    if (
        BOOTSTRAP_ADMIN_PASSWORD &&
        BOOTSTRAP_ADMIN_PASSWORD.length <
            env.auth.passwordMinLength
    ) {
        throw new Error(
            `BOOTSTRAP_ADMIN_PASSWORD must contain at least ${env.auth.passwordMinLength} characters.`,
        );
    }

    if (
        BOOTSTRAP_ADMIN_EMAIL &&
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
            BOOTSTRAP_ADMIN_EMAIL,
        )
    ) {
        throw new Error(
            "BOOTSTRAP_ADMIN_EMAIL must be a valid email address.",
        );
    }

    /*
     * Creating a brand-new bootstrap user without a password would
     * create an unusable account. Refuse instead of generating or
     * shipping a default password.
     */
    if (
        BOOTSTRAP_ADMIN_EMAIL &&
        !BOOTSTRAP_ADMIN_PASSWORD
    ) {
        throw new Error(
            "BOOTSTRAP_ADMIN_PASSWORD is required when BOOTSTRAP_ADMIN_EMAIL is configured.",
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Permission seeding                                                         */
/* -------------------------------------------------------------------------- */

async function seedPermissions() {
    const permissionMap =
        new Map();

    for (
        const definition of PERMISSIONS
    ) {
        const permission =
            await Permission.findOneAndUpdate(
                {
                    key:
                        definition.key,
                },

                {
                    $set: {
                        name:
                            definition.name,

                        description:
                            definition.description,

                        category:
                            definition.category,

                        sortOrder:
                            definition.sortOrder,

                        /*
                         * Permission actions describe the actions that
                         * the module supports.
                         *
                         * RolePermission separately controls which
                         * supported actions are granted to a role.
                         *
                         * IMPORTANT:
                         *
                         * This is intentionally under $set, not only
                         * $setOnInsert, so existing installations are
                         * repaired when the seed is executed again.
                         */
                        actions: {
                            ...DEFAULT_PERMISSION_ACTIONS,
                        },

                        active:
                            true,

                        system:
                            true,
                    },

                    $setOnInsert: {
                        key:
                            definition.key,
                    },
                },

                {
                    upsert:
                        true,

                    new:
                        true,

                    setDefaultsOnInsert:
                        true,
                },
            );

        permissionMap.set(
            permission.key,
            permission,
        );
    }

    return permissionMap;
}
/* -------------------------------------------------------------------------- */
/* Role seeding                                                               */
/* -------------------------------------------------------------------------- */

async function seedRoles() {
    const roleMap =
        new Map();

    for (
        const definition of ROLES
    ) {
        const role =
            await Role.findOneAndUpdate(
                {
                    key:
                        definition.key,
                },

                {
                    $set: {
                        name:
                            definition.name,

                        description:
                            definition.description,

                        realm:
                            definition.realm,

                        allowedUserTypes:
                            definition.allowedUserTypes,

                        system:
                            definition.system,

                        ownerRole:
                            definition.ownerRole,

                        sortOrder:
                            definition.sortOrder,

                        active:
                            true,
                    },

                    $setOnInsert: {
                        key:
                            definition.key,
                    },
                },

                {
                    upsert: true,
                    new: true,
                    setDefaultsOnInsert:
                        true,
                },
            );

        roleMap.set(
            role.key,
            role,
        );
    }

    return roleMap;
}

/* -------------------------------------------------------------------------- */
/* Workspace owner permissions                                                */
/* -------------------------------------------------------------------------- */

async function seedWorkspaceOwnerPermissions(
    role,
    permissionMap,
) {
    /*
     * Workspace Owner receives all currently registered application
     * permissions with all four actions.
     *
     * Future role customization is done through the Roles & Permissions
     * service/UI.
     */
    for (
        const permission of
            permissionMap.values()
    ) {
        await RolePermission.findOneAndUpdate(
            {
                roleId:
                    role._id,

                permissionId:
                    permission._id,
            },

            {
                $set: {
                    actions: {
                        view:
                            true,

                        add:
                            true,

                        edit:
                            true,

                        delete:
                            true,
                    },

                    active:
                        true,
                },

                $setOnInsert: {
                    roleId:
                        role._id,

                    permissionId:
                        permission._id,
                },
            },

            {
                upsert: true,
                new: true,
                setDefaultsOnInsert:
                    true,
            },
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Bootstrap user                                                             */
/* -------------------------------------------------------------------------- */

async function seedBootstrapUser(
    ownerRole,
) {
    if (
        !BOOTSTRAP_ADMIN_EMAIL
    ) {
        console.warn(
            "[SEED] BOOTSTRAP_ADMIN_EMAIL not configured. No bootstrap user was created or assigned.",
        );

        console.warn(
            "[SEED] Add BOOTSTRAP_ADMIN_EMAIL and BOOTSTRAP_ADMIN_PASSWORD to explicitly grant Workspace Owner access.",
        );

        return null;
    }

    let user =
        await User.findOne({
            email:
                BOOTSTRAP_ADMIN_EMAIL,
        }).select(
            "+passwordHash",
        );

    if (
        user
    ) {
        if (
            ![
                "admin",
                "internal",
            ].includes(
                user.userType,
            )
        ) {
            throw new Error(
                `Bootstrap user ${BOOTSTRAP_ADMIN_EMAIL} is not an admin/internal user.`,
            );
        }

        /*
         * Explicit bootstrap configuration means the operator is
         * intentionally granting ownership to this account.
         */
        user.roleId =
            ownerRole._id;

        user.status =
            "active";

        user.updatedBy =
            user._id;

        /*
         * Do not silently replace an existing password.
         */
        if (
            !user.passwordHash
        ) {
            user.passwordHash =
                await bcrypt.hash(
                    BOOTSTRAP_ADMIN_PASSWORD,
                    env.auth
                        .bcryptSaltRounds,
                );
        }

        await user.save();

        console.info(
            `[SEED] Existing bootstrap user assigned Workspace Owner: ${BOOTSTRAP_ADMIN_EMAIL}`,
        );

        return user;
    }

    /*
     * Creating a new admin is only allowed when both email and password
     * were explicitly supplied through environment variables.
     */
    const passwordHash =
        await bcrypt.hash(
            BOOTSTRAP_ADMIN_PASSWORD,
            env.auth
                .bcryptSaltRounds,
        );

    user =
        await User.create({
            email:
                BOOTSTRAP_ADMIN_EMAIL,

            passwordHash,

            displayName:
                BOOTSTRAP_ADMIN_NAME,

            userType:
                "admin",

            roleId:
                ownerRole._id,

            vendorId:
                null,

            status:
                "active",

            passwordChangedAt:
                new Date(),

            emailVerifiedAt:
                new Date(),
        });

    console.info(
        `[SEED] Bootstrap Workspace Owner created: ${BOOTSTRAP_ADMIN_EMAIL}`,
    );

    return user;
}

/* -------------------------------------------------------------------------- */
/* Existing users without roles                                               */
/* -------------------------------------------------------------------------- */

async function reportUsersWithoutRoles() {
    const count =
        await User.countDocuments({
            roleId: null,
        });

    if (
        count === 0
    ) {
        return;
    }

    console.warn(
        `[SEED] ${count} user(s) currently have no role assigned.`,
    );

    console.warn(
        "[SEED] They will remain unauthorized until a valid role is assigned.",
    );
}

/* -------------------------------------------------------------------------- */
/* Main                                                                       */
/* -------------------------------------------------------------------------- */

async function main() {
    console.info(
        "[SEED] Starting ARGUS MongoDB authorization seed...",
    );

    validateBootstrapConfiguration();

    await connectDatabase();

    const permissionMap =
        await seedPermissions();

    console.info(
        `[SEED] Permissions ready: ${permissionMap.size}`,
    );

    const roleMap =
        await seedRoles();

    console.info(
        `[SEED] Roles ready: ${roleMap.size}`,
    );

    const workspaceOwner =
        roleMap.get(
            "workspace_owner",
        );

    if (
        !workspaceOwner
    ) {
        throw new Error(
            "workspace_owner role could not be created.",
        );
    }

    await seedWorkspaceOwnerPermissions(
        workspaceOwner,
        permissionMap,
    );

    console.info(
        "[SEED] Workspace Owner permissions ready.",
    );

    await seedBootstrapUser(
        workspaceOwner,
    );

    await reportUsersWithoutRoles();

    console.info(
        "[SEED] ARGUS MongoDB authorization seed completed successfully.",
    );
}

/* -------------------------------------------------------------------------- */
/* Process                                                                    */
/* -------------------------------------------------------------------------- */

main()
    .then(
        async () => {
            await disconnectDatabase();

            process.exit(
                0,
            );
        },
    )
    .catch(
        async (error) => {
            console.error(
                "[SEED] Failed:",
                error,
            );

            try {
                await disconnectDatabase();
            } catch {
                // Preserve the original seed failure.
            }

            process.exit(
                1,
            );
        },
    );