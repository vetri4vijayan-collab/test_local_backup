export class HttpError extends Error {}
export const notFound = (req, _res, next) => { const e = new Error(`Route not found: ${req.method} ${req.originalUrl}`); e.statusCode = 404; e.code = 'NOT_FOUND'; next(e); };
export const errorHandler = (err, _req, res, _next) => {
  const status = err.statusCode ?? 500;
  res.status(status).json({ success: false, error: { code: err.code ?? 'INTERNAL_ERROR', message: status >= 500 ? 'Internal server error' : err.message, details: err.details ?? undefined } });
};
