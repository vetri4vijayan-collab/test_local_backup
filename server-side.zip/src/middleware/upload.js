import multer from 'multer';
import path from 'node:path';
import env from '../config/env.js';

export const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: env.storage.maxUploadMb * 1024 * 1024,
    files: 10,
  },
  fileFilter: (_req, file, cb) => {
    if (
      !env.storage.allowedMime.length ||
      env.storage.allowedMime.includes(file.mimetype)
    ) {
      return cb(null, true);
    }

    cb(new Error(`File type not allowed: ${file.mimetype}`));
  },
});

export const safeExtension = (filename, fallback = '.bin') => {
  const ext = path.extname(filename || '').toLowerCase();
  return /^[.][a-z0-9]{1,10}$/.test(ext) ? ext : fallback;
};

// Company Settings Uploads
export const companyLogoUpload = upload.single('logo');

export const companyFaviconUpload = upload.single('favicon');