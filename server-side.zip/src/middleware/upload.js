import multer from 'multer';
import path from 'node:path';
import env from '../config/env.js';

export const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: env.uploads.maxFileSizeBytes,
    files: 10,
  },
  fileFilter: (_req, file, cb) => {
    if (
      !env.uploads.mimeTypes.documents.length || env.uploads.mimeTypes.spreadsheets.length || env.uploads.mimeTypes.images.length ||
      Object.values(env.uploads.mimeTypes).flat().includes(file.mimetype)
    ) {
      return cb(null, true);
    }

    cb(new Error(`File type not allowed: ${file.mimetype}`));
  },
});

export const safeExtension = (filename, fallback = '.bin') => {
  const ext = path.extname(filename || '').toLowerCase();
  return /^[.][a-z0-9]{1,10}$/.test(ext) ? ext : fallback;
};

// Company Settings Uploads
export const companyLogoUpload = upload.single('logo');

export const companyFaviconUpload = upload.single('favicon');

const PROFILE_IMAGE_MAX_BYTES = Math.min(
  env.uploads.maxFileSizeBytes,
  2 * 1024 * 1024,
);

const profileImageParser = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: PROFILE_IMAGE_MAX_BYTES,
    files: 1,
  },
  fileFilter: (_req, file, cb) => {
    const allowed = env.uploads.mimeTypes.images || [];

    if (allowed.includes(file.mimetype)) {
      return cb(null, true);
    }

    cb(new Error(`Profile image type not allowed: ${file.mimetype}`));
  },
}).single('image');

export const profileImageUpload = (req, res, next) => {
  profileImageParser(req, res, (error) => {
    if (!error) {
      return next();
    }

    if (error.code === 'LIMIT_FILE_SIZE') {
      error.statusCode = 413;
      error.code = 'PROFILE_IMAGE_TOO_LARGE';
      error.message = 'Profile image must be 2 MB or smaller.';
      return next(error);
    }

    error.statusCode = 422;
    error.code = 'PROFILE_IMAGE_TYPE_NOT_ALLOWED';
    return next(error);
  });
};
