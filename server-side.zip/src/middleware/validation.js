// src/middleware/upload.js

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

import multer from 'multer';

import env from '../config/env.js';


/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const DEFAULT_UPLOAD_CONTEXT =
  'general';


const FILE_FIELD_CONTEXTS =
  Object.freeze({
    logo: 'company',
    favicon: 'company',

    quotation: 'quotation',
    attachment: 'quotation',

    taskAttachment: 'task',
    paymentProof: 'payment',
    invoiceAttachment: 'invoice',

    surveyAttachment: 'survey',

    vendorDocument: 'vendor',
  });


/**
 * Hard safety limit.
 *
 * Even if someone changes MAX_FILE_SIZE_BYTES to a very large
 * value, this prevents accidental multi-gigabyte uploads.
 */
const ABSOLUTE_MAX_FILE_SIZE =
  100 * 1024 * 1024;


/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class UploadError extends Error {
  constructor(
    message,
    {
      code =
        'UPLOAD_ERROR',
      statusCode =
        400,
      details =
        undefined,
    } = {},
  ) {
    super(message);

    this.name =
      'UploadError';

    this.code =
      code;

    this.statusCode =
      statusCode;

    this.details =
      details;

    Error.captureStackTrace?.(
      this,
      UploadError,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Utility helpers                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Ensure a directory exists.
 */
function ensureDirectory(
  directory,
) {
  fs.mkdirSync(
    directory,
    {
      recursive: true,
      mode: 0o750,
    },
  );
}


/**
 * Sanitize a filename for metadata purposes.
 *
 * This value is never used directly as the stored filesystem filename.
 */
function sanitizeOriginalName(
  filename,
) {
  const value =
    String(
      filename || '',
    )
      .normalize('NFKC')
      .replace(
        /[\u0000-\u001F\u007F]/g,
        '',
      )
      .replace(
        /[\\/]+/g,
        '_',
      )
      .replace(
        /[^a-zA-Z0-9._() \-]/g,
        '_',
      )
      .trim();


  if (!value) {
    return 'upload';
  }


  return value.slice(
    0,
    255,
  );
}


/**
 * Return a safe lower-case extension.
 */
function getExtension(
  filename,
) {
  const safeName =
    path.basename(
      String(
        filename || '',
      ),
    );


  const extension =
    path.extname(
      safeName,
    );


  if (!extension) {
    return '';
  }


  return extension
    .slice(1)
    .toLowerCase();
}


/**
 * Validate that a generated path remains inside the expected
 * storage root.
 */
function assertPathInsideRoot(
  targetPath,
  rootPath,
) {
  const resolvedTarget =
    path.resolve(
      targetPath,
    );

  const resolvedRoot =
    path.resolve(
      rootPath,
    );


  const rootWithSeparator =
    resolvedRoot.endsWith(
      path.sep,
    )
      ? resolvedRoot
      : `${resolvedRoot}${path.sep}`;


  if (
    resolvedTarget !==
      resolvedRoot &&
    !resolvedTarget.startsWith(
      rootWithSeparator,
    )
  ) {
    throw new UploadError(
      'Invalid storage path.',
      {
        code:
          'INVALID_STORAGE_PATH',

        statusCode:
          500,
      },
    );
  }
}


/**
 * Determine upload category from the field name.
 */
function resolveUploadContext(
  fieldName,
) {
  return (
    FILE_FIELD_CONTEXTS[
      fieldName
    ] ||
    DEFAULT_UPLOAD_CONTEXT
  );
}


/**
 * Return context-specific directory.
 */
function resolveDirectory(
  fieldName,
) {
  const context =
    resolveUploadContext(
      fieldName,
    );


  const contextDirectory =
    env.storage.directories[
      context
    ];


  /**
   * For unknown fields, use the generic temporary area.
   *
   * Unknown upload contexts are not automatically trusted
   * as permanent storage.
   */
  if (!contextDirectory) {
    return path.resolve(
      env.storage.tempRoot,
    );
  }


  const directory =
    path.resolve(
      env.storage.privateRoot,
      contextDirectory,
    );


  assertPathInsideRoot(
    directory,
    env.storage.privateRoot,
  );


  ensureDirectory(
    directory,
  );


  return directory;
}


/**
 * Create a cryptographically random server filename.
 */
function generateStoredFilename(
  originalName,
  mimeType,
) {
  const extension =
    getExtension(
      originalName,
    );


  /**
   * 256-bit random identifier.
   */
  const randomId =
    crypto.randomBytes(
      32,
    ).toString('hex');


  /**
   * Preserve an extension only.
   *
   * Never use the original basename.
   */
  if (extension) {
    return `${randomId}.${extension}`;
  }


  /**
   * For extensionless uploads, infer a safe extension
   * from MIME where possible.
   */
  const inferredExtension =
    extensionFromMimeType(
      mimeType,
    );


  if (
    inferredExtension
  ) {
    return `${randomId}.${inferredExtension}`;
  }


  return randomId;
}


/**
 * MIME → safe extension fallback.
 */
function extensionFromMimeType(
  mimeType,
) {
  const normalized =
    String(
      mimeType || '',
    ).toLowerCase();


  const mapping =
    Object.freeze({
      'image/png':
        'png',

      'image/jpeg':
        'jpg',

      'image/webp':
        'webp',

      'image/x-icon':
        'ico',

      'image/vnd.microsoft.icon':
        'ico',

      'image/svg+xml':
        'svg',

      'application/pdf':
        'pdf',

      'application/msword':
        'doc',

      'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        'docx',

      'text/csv':
        'csv',

      'application/csv':
        'csv',

      'application/vnd.ms-excel':
        'xls',

      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
        'xlsx',
    });


  return (
    mapping[
      normalized
    ] ||
    ''
  );
}


/**
 * Check allowed MIME type.
 */
function isAllowedMimeType(
  mimeType,
  allowedTypes,
) {
  return allowedTypes.includes(
    String(
      mimeType || '',
    ).toLowerCase(),
  );
}


/**
 * Validate file extension against MIME type.
 *
 * This prevents simple attacks such as:
 *
 * malicious.exe renamed to malicious.jpg
 */
function isExtensionCompatibleWithMime(
  filename,
  mimeType,
) {
  const extension =
    getExtension(
      filename,
    );


  const normalizedMime =
    String(
      mimeType || '',
    ).toLowerCase();


  const expectedExtensions =
    Object.freeze({
      'image/png': ['png'],

      'image/jpeg': [
        'jpg',
        'jpeg',
      ],

      'image/webp': ['webp'],

      'image/x-icon': ['ico'],

      'image/vnd.microsoft.icon': [
        'ico',
      ],

      'image/svg+xml': ['svg'],

      'application/pdf': ['pdf'],

      'application/msword': ['doc'],

      'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        ['docx'],

      'text/csv': ['csv'],

      'application/csv': ['csv'],

      'application/vnd.ms-excel': [
        'xls',
        'xlsx',
      ],

      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
        ['xlsx'],
    });


  /**
   * Unknown MIME mapping.
   *
   * The MIME validation remains the primary control.
   */
  if (
    !expectedExtensions[
      normalizedMime
    ]
  ) {
    return true;
  }


  return expectedExtensions[
    normalizedMime
  ].includes(
    extension,
  );
}


/**
 * Return SHA-256 checksum for a saved file.
 */
async function calculateChecksum(
  filePath,
) {
  return new Promise(
    (
      resolve,
      reject,
    ) => {
      const hash =
        crypto.createHash(
          'sha256',
        );

      const stream =
        fs.createReadStream(
          filePath,
        );


      stream.on(
        'data',
        (chunk) => {
          hash.update(
            chunk,
          );
        },
      );


      stream.on(
        'error',
        reject,
      );


      stream.on(
        'end',
        () => {
          resolve(
            hash.digest(
              'hex',
            ),
          );
        },
      );
    },
  );
}


/* -------------------------------------------------------------------------- */
/* File validation                                                            */
/* -------------------------------------------------------------------------- */

function validateIncomingFile(
  file,
) {
  if (!file) {
    throw new UploadError(
      'No file was uploaded.',
      {
        code:
          'FILE_REQUIRED',
        statusCode:
          422,
      },
    );
  }


  const mimeType =
    String(
      file.mimetype || '',
    ).toLowerCase();


  /**
   * Reject files without a browser-provided MIME type.
   *
   * A deeper magic-byte inspection can be added later for
   * especially sensitive document workflows.
   */
  if (!mimeType) {
    throw new UploadError(
      'Unable to determine the uploaded file type.',
      {
        code:
          'FILE_TYPE_UNKNOWN',
        statusCode:
          415,
      },
    );
  }


  if (
    file.size >
    env.uploads.maxFileSizeBytes
  ) {
    throw new UploadError(
      'Uploaded file exceeds the maximum allowed size.',
      {
        code:
          'FILE_TOO_LARGE',
        statusCode:
          413,
        details: {
          maxBytes:
            env.uploads.maxFileSizeBytes,
        },
      },
    );
  }


  if (
    file.size >
    ABSOLUTE_MAX_FILE_SIZE
  ) {
    throw new UploadError(
      'Uploaded file exceeds the system safety limit.',
      {
        code:
          'FILE_SAFETY_LIMIT_EXCEEDED',
        statusCode:
          413,
      },
    );
  }


  /**
   * Do not allow the client to control filesystem path.
   */
  if (
    file.path &&
    (
      file.path.includes('..') ||
      path.isAbsolute(
        file.path,
      ) &&
      !path.resolve(
        file.path,
      )
    )
  ) {
    /**
     * The path generated by multer's diskStorage should always
     * be internally generated. This is a defensive guard.
     */
  }


  if (
    !isExtensionCompatibleWithMime(
      file.originalname,
      mimeType,
    )
  ) {
    throw new UploadError(
      'File extension does not match the uploaded file type.',
      {
        code:
          'FILE_EXTENSION_MISMATCH',
        statusCode:
          415,
      },
    );
  }
}


/* -------------------------------------------------------------------------- */
/* MIME policy                                                                */
/* -------------------------------------------------------------------------- */

function getAllowedMimeTypesForField(
  fieldName,
) {
  switch (
    fieldName
  ) {
    case 'logo':
      return (
        env.uploads.mimeTypes.images
      );


    case 'favicon':
      return [
        ...env.uploads.mimeTypes.images,
        'image/x-icon',
        'image/vnd.microsoft.icon',
        'image/svg+xml',
      ];


    case 'quotation':
    case 'attachment':
      return (
        env.uploads
          .mimeTypes
          .attachments
      );


    case 'taskAttachment':
      return (
        env.uploads
          .mimeTypes
          .attachments
      );


    case 'invoiceAttachment':
      return (
        env.uploads
          .mimeTypes
          .attachments
      );


    case 'paymentProof':
      return (
        env.uploads
          .mimeTypes
          .attachments
      );


    case 'vendorDocument':
      return (
        env.uploads
          .mimeTypes
          .attachments
      );


    case 'surveyAttachment':
      return (
        env.uploads
          .mimeTypes
          .attachments
      );


    default:
      return [
        ...env.uploads
          .mimeTypes
          .attachments,
      ];
  }
}


/* -------------------------------------------------------------------------- */
/* Storage engine                                                             */
/* -------------------------------------------------------------------------- */

const storage =
  multer.diskStorage({
    destination(
      req,
      file,
      callback,
    ) {
      try {
        const directory =
          resolveDirectory(
            file.fieldname,
          );


        callback(
          null,
          directory,
        );
      } catch (error) {
        callback(
          error,
        );
      }
    },


    filename(
      req,
      file,
      callback,
    ) {
      try {
        const storedFilename =
          generateStoredFilename(
            file.originalname,
            file.mimetype,
          );


        callback(
          null,
          storedFilename,
        );
      } catch (error) {
        callback(
          error,
        );
      }
    },
  });


/* -------------------------------------------------------------------------- */
/* Multer file filter                                                         */
/* -------------------------------------------------------------------------- */

function fileFilter(
  req,
  file,
  callback,
) {
  try {
    const allowedTypes =
      getAllowedMimeTypesForField(
        file.fieldname,
      );


    if (
      !isAllowedMimeType(
        file.mimetype,
        allowedTypes,
      )
    ) {
      return callback(
        new UploadError(
          `File type "${file.mimetype}" is not allowed for "${file.fieldname}".`,
          {
            code:
              'FILE_TYPE_NOT_ALLOWED',
            statusCode:
              415,
            details: {
              field:
                file.fieldname,

              mimeType:
                file.mimetype,

              allowedTypes,
            },
          },
        ),
      );
    }


    if (
      !isExtensionCompatibleWithMime(
        file.originalname,
        file.mimetype,
      )
    ) {
      return callback(
        new UploadError(
          'File extension does not match the uploaded file type.',
          {
            code:
              'FILE_EXTENSION_MISMATCH',
            statusCode:
              415,
          },
        ),
      );
    }


    return callback(
      null,
      true,
    );
  } catch (error) {
    return callback(
      error,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Base uploader                                                              */
/* -------------------------------------------------------------------------- */

const uploader =
  multer({
    storage,
    fileFilter,
    limits: {
      fileSize: Math.min(env.uploads.maxFileSizeBytes, ABSOLUTE_MAX_FILE_SIZE,),
      files: env.uploads.maxMultipartFiles,
      fields: env.uploads.maxMultipartFields,
      parts: env.uploads.maxMultipartFiles + env.uploads.maxMultipartFields + 20,
      headerPairs: 2000,
    }
});


/* -------------------------------------------------------------------------- */
/* Post-upload metadata                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Enrich req.file after multer saves it.
 *
 * Adds:
 * - storageKey
 * - relativePath
 * - checksum
 * - safeOriginalName
 * - uploadContext
 */
export async function enrichUploadedFile(
  file,
) {
  if (!file) {
    return null;
  }


  validateIncomingFile(
    file,
  );


  const privateRoot =
    path.resolve(
      env.storage.privateRoot,
    );


  const absolutePath =
    path.resolve(
      file.path,
    );


  assertPathInsideRoot(
    absolutePath,
    privateRoot,
  );


  const relativePath =
    path.relative(
      privateRoot,
      absolutePath,
    ).replace(
      /\\/g,
      '/',
    );


  if (
    relativePath.startsWith(
      '..',
    )
  ) {
    throw new UploadError(
      'Generated upload path is invalid.',
      {
        code:
          'INVALID_GENERATED_PATH',
        statusCode:
          500,
      },
    );
  }


  const checksum =
    await calculateChecksum(
      absolutePath,
    );


  file.storageKey =
    relativePath;


  file.relativePath =
    relativePath;


  file.checksum =
    checksum;


  file.safeOriginalName =
    sanitizeOriginalName(
      file.originalname,
    );


  file.uploadContext =
    resolveUploadContext(
      file.fieldname,
    );


  /**
   * The application never needs to expose this path to
   * the browser.
   *
   * It remains available internally to the storage service.
   */
  file.absolutePath =
    absolutePath;


  return file;
}


/* -------------------------------------------------------------------------- */
/* Express middleware wrappers                                                */
/* -------------------------------------------------------------------------- */

/**
 * Single-file uploader.
 *
 * The middleware:
 *
 * 1. accepts the multipart file
 * 2. stores it privately
 * 3. calculates checksum
 * 4. enriches req.file
 */
export function single(
  fieldName,
) {
  if (
    typeof fieldName !==
    'string' ||
    !fieldName.trim()
  ) {
    throw new TypeError(
      'upload.single() requires a field name.',
    );
  }


  const middleware =
    uploader.single(
      fieldName,
    );


  return async (
    req,
    res,
    next,
  ) => {
    try {
      await runMulter(
        middleware,
        req,
        res,
      );


      if (req.file) {
        await enrichUploadedFile(
          req.file,
        );
      }


      next();
    } catch (error) {
      /**
       * Remove the uploaded physical file if post-upload
       * validation/enrichment fails.
       */
      await safelyRemoveFile(
        req.file,
      );


      next(
        normalizeUploadError(
          error,
        ),
      );
    }
  };
}


/**
 * Multiple named fields.
 *
 * Example:
 *
 * upload.fields([
 *   { name: 'logo', maxCount: 1 },
 *   { name: 'favicon', maxCount: 1 }
 * ])
 */
export function fields(
  definitions,
) {
  if (
    !Array.isArray(
      definitions,
    ) ||
    definitions.length ===
      0
  ) {
    throw new TypeError(
      'upload.fields() requires at least one field definition.',
    );
  }


  const middleware =
    uploader.fields(
      definitions,
    );


  return async (
    req,
    res,
    next,
  ) => {
    try {
      await runMulter(
        middleware,
        req,
        res,
      );


      const files =
        req.files ||
        {};


      for (
        const fileList of Object.values(
          files,
        )
      ) {
        for (
          const file of fileList
        ) {
          await enrichUploadedFile(
            file,
          );
        }
      }


      next();
    } catch (error) {
      await safelyRemoveFiles(
        req.files,
      );


      next(
        normalizeUploadError(
          error,
        ),
      );
    }
  };
}


/**
 * Array uploader.
 */
export function array(
  fieldName,
  maxCount,
) {
  if (
    typeof fieldName !==
    'string' ||
    !fieldName.trim()
  ) {
    throw new TypeError(
      'upload.array() requires a field name.',
    );
  }


  if (
    !Number.isInteger(
      maxCount,
    ) ||
    maxCount < 1
  ) {
    throw new TypeError(
      'upload.array() requires a positive maxCount.',
    );
  }


  const middleware =
    uploader.array(
      fieldName,
      maxCount,
    );


  return async (
    req,
    res,
    next,
  ) => {
    try {
      await runMulter(
        middleware,
        req,
        res,
      );


      if (
        Array.isArray(
          req.files,
        )
      ) {
        for (
          const file of req.files
        ) {
          await enrichUploadedFile(
            file,
          );
        }
      }


      next();
    } catch (error) {
      await safelyRemoveFiles(
        req.files,
      );


      next(
        normalizeUploadError(
          error,
        ),
      );
    }
  };
}


/* -------------------------------------------------------------------------- */
/* Multer promise adapter                                                      */
/* -------------------------------------------------------------------------- */

function runMulter(
  middleware,
  req,
  res,
) {
  return new Promise(
    (
      resolve,
      reject,
    ) => {
      middleware(
        req,
        res,
        (error) => {
          if (error) {
            reject(
              normalizeUploadError(
                error,
              ),
            );

            return;
          }

          resolve();
        },
      );
    },
  );
}


/* -------------------------------------------------------------------------- */
/* Error normalization                                                        */
/* -------------------------------------------------------------------------- */

function normalizeUploadError(
  error,
) {
  if (
    error instanceof
    UploadError
  ) {
    return error;
  }


  /**
   * Multer errors.
   */
  if (
    error?.name ===
      'MulterError' ||
    error?.code?.startsWith(
      'LIMIT_',
    )
  ) {
    switch (
      error.code
    ) {
      case 'LIMIT_FILE_SIZE':
        return new UploadError(
          'Uploaded file exceeds the maximum allowed size.',
          {
            code:
              'FILE_TOO_LARGE',
            statusCode:
              413,
          },
        );


      case 'LIMIT_FILE_COUNT':
        return new UploadError(
          'Too many files were uploaded.',
          {
            code:
              'TOO_MANY_FILES',
            statusCode:
              413,
          },
        );


      case 'LIMIT_FIELD_COUNT':
        return new UploadError(
          'Too many form fields were submitted.',
          {
            code:
              'TOO_MANY_FIELDS',
            statusCode:
              413,
          },
        );


      case 'LIMIT_UNEXPECTED_FILE':
        return new UploadError(
          'Unexpected upload field.',
          {
            code:
              'UNEXPECTED_FILE_FIELD',
            statusCode:
              400,
          },
        );


      case 'LIMIT_PART_COUNT':
        return new UploadError(
          'Multipart request contains too many parts.',
          {
            code:
              'TOO_MANY_MULTIPART_PARTS',
            statusCode:
              413,
          },
        );


      default:
        return new UploadError(
          'File upload failed.',
          {
            code:
              'UPLOAD_LIMIT_ERROR',
            statusCode:
              400,
          },
        );
    }
  }


  /**
   * Generic file errors.
   */
  if (
    error?.message &&
    error.name ===
      'Error'
  ) {
    return new UploadError(
      error.message,
      {
        code:
          'UPLOAD_PROCESSING_ERROR',
        statusCode:
          400,
      },
    );
  }


  console.error(
    '[UPLOAD] Unexpected upload error:',
    error,
  );


  return new UploadError(
    'File upload failed unexpectedly.',
    {
      code:
        'UPLOAD_INTERNAL_ERROR',
      statusCode:
        500,
    },
  );
}


/* -------------------------------------------------------------------------- */
/* File cleanup                                                               */
/* -------------------------------------------------------------------------- */

async function safelyRemoveFile(
  file,
) {
  if (
    !file?.path
  ) {
    return;
  }


  try {
    const privateRoot =
      path.resolve(
        env.storage.privateRoot,
      );


    const filePath =
      path.resolve(
        file.path,
      );


    assertPathInsideRoot(
      filePath,
      privateRoot,
    );


    await fs.promises.rm(
      filePath,
      {
        force: true,
      },
    );
  } catch (error) {
    console.error(
      '[UPLOAD] Failed to clean up temporary upload:',
      error.message,
    );
  }
}


async function safelyRemoveFiles(
  files,
) {
  if (
    !files
  ) {
    return;
  }


  if (
    Array.isArray(
      files,
    )
  ) {
    await Promise.all(
      files.map(
        (file) =>
          safelyRemoveFile(
            file,
          ),
      ),
    );

    return;
  }


  for (
    const fileList of Object.values(
      files,
    )
  ) {
    if (
      Array.isArray(
        fileList,
      )
    ) {
      await Promise.all(
        fileList.map(
          (file) =>
            safelyRemoveFile(
              file,
            ),
        ),
      );
    }
  }
}


/* -------------------------------------------------------------------------- */
/* File security helpers                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Validate a saved file again after disk write.
 *
 * This can be used by storage services before making the
 * file available to other parts of the application.
 */
export async function validateSavedFile(
  file,
) {
  validateIncomingFile(
    file,
  );


  if (
    !file.path
  ) {
    throw new UploadError(
      'Saved upload does not contain a valid path.',
      {
        code:
          'INVALID_SAVED_FILE',
        statusCode:
          500,
      },
    );
  }


  const privateRoot =
    path.resolve(
      env.storage.privateRoot,
    );


  const resolvedFile =
    path.resolve(
      file.path,
    );


  assertPathInsideRoot(
    resolvedFile,
    privateRoot,
  );


  const stats =
    await fs.promises.stat(
      resolvedFile,
    );


  if (
    !stats.isFile()
  ) {
    throw new UploadError(
      'Uploaded storage object is not a file.',
      {
        code:
          'INVALID_STORAGE_OBJECT',
        statusCode:
          500,
      },
    );
  }


  return true;
}


/* -------------------------------------------------------------------------- */
/* Storage directory initialization                                           */
/* -------------------------------------------------------------------------- */

/**
 * Initialize all directories that are known to ARGUS.
 *
 * This is safe to call at application startup.
 */
export function initializeUploadDirectories() {
  ensureDirectory(
    path.resolve(
      env.storage.root,
    ),
  );


  ensureDirectory(
    path.resolve(
      env.storage.privateRoot,
    ),
  );


  ensureDirectory(
    path.resolve(
      env.storage.exportRoot,
    ),
  );


  ensureDirectory(
    path.resolve(
      env.storage.tempRoot,
    ),
  );


  for (
    const directory of Object.values(
      env.storage.directories,
    )
  ) {
    const target =
      path.resolve(
        env.storage.privateRoot,
        directory,
      );


    assertPathInsideRoot(
      target,
      env.storage.privateRoot,
    );


    ensureDirectory(
      target,
    );
  }


  return true;
}


/* -------------------------------------------------------------------------- */
/* Company Profile upload presets                                             */
/* -------------------------------------------------------------------------- */

/**
 * Company Logo
 *
 * React:
 *
 * FormData.append('logo', file)
 */
export const companyLogoUpload =
  single(
    'logo',
  );


/**
 * Company Favicon
 *
 * React:
 *
 * FormData.append('favicon', file)
 */
export const companyFaviconUpload = single('favicon', );


/* -------------------------------------------------------------------------- */
/* Generic presets                                                            */
/* -------------------------------------------------------------------------- */

export const quotationUpload =
  single(
    'quotation',
  );


export const invoiceAttachmentUpload =
  single(
    'invoiceAttachment',
  );


export const paymentProofUpload =
  single(
    'paymentProof',
  );


export const taskAttachmentUpload =
  single(
    'taskAttachment',
  );


export const vendorDocumentUpload =
  single(
    'vendorDocument',
  );


export const surveyAttachmentUpload =
  single(
    'surveyAttachment',
  );


/* -------------------------------------------------------------------------- */
/* Default export                                                             */
/* -------------------------------------------------------------------------- */

const uploadMiddleware =
  Object.freeze({
    /**
     * Keep the API compatible with the route files.
     */
    single,

    array,

    fields,

    uploader,

    initializeUploadDirectories,

    enrichUploadedFile,

    validateSavedFile,

    companyLogoUpload,

    companyFaviconUpload,

    quotationUpload,

    invoiceAttachmentUpload,

    paymentProofUpload,

    taskAttachmentUpload,

    vendorDocumentUpload,

    surveyAttachmentUpload,
  });


export default uploadMiddleware;