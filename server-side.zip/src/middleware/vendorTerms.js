import {
    requireVendorTermsAccepted,
    VendorTermsServiceError,
} from "../services/vendor/vendorTermsService.js";

export async function requireVendorTermsAcceptedMiddleware(req, res, next) {
    try {
        await requireVendorTermsAccepted(req.user?.id);
        return next();
    } catch (error) {
        if (error instanceof VendorTermsServiceError) {
            return res.status(error.statusCode || 400).json({
                success: false,
                message: error.message,
                code: error.code,
                ...(error.details ? { details: error.details } : {}),
            });
        }

        console.error("[vendorTermsMiddleware]", error);

        return res.status(500).json({
            success: false,
            message: "Unable to validate vendor portal onboarding state.",
            code: "INTERNAL_SERVER_ERROR",
        });
    }
}
