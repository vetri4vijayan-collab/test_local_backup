# Docker

The API container mounts `storage/uploads` from the host. Keep the upload directory on persistent disk and back it up with PostgreSQL.
