# Local Storage

No AWS/S3/cloud object storage. Use STORAGE_ROOT (default `./storage/uploads`) and domain folders for vendors, quotations, tasks, invoices, payments, company, users, surveys, exports, temp. Generate random stored names, validate MIME/size, persist metadata in PostgreSQL, and authorize downloads through API controllers rather than exposing arbitrary filesystem paths.
