
import http from 'node:http';

import express from 'express';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import morgan from 'morgan';

import env from './src/config/env.js';
import database from './src/config/database.js';


/* -------------------------------------------------------------------------- */
/* Application constants                                                      */
/* -------------------------------------------------------------------------- */

const app = express();
const server = http.createServer(app);
let isShuttingDown = false;

/* -------------------------------------------------------------------------- */
/* Trust proxy                                                                */
/* -------------------------------------------------------------------------- */

if (env.isProduction || env.isStaging) {
  app.set('trust proxy', 1);
}


/* -------------------------------------------------------------------------- */
/* Express application settings                                               */
/* -------------------------------------------------------------------------- */

app.disable('x-powered-by');
app.set('case sensitive routing', true);
app.set('strict routing', false);


/* -------------------------------------------------------------------------- */
/* Request correlation ID                                                     */
/* -------------------------------------------------------------------------- */

/**
 *
 * This ID will later be used by:
 * - request logger
 * - application logger
 * - audit logger
 * - error responses
 *
 * We use crypto.randomUUID() through Node's request ID facilities
 * without introducing another dependency.
 */
import crypto from 'node:crypto';

app.use((req, res, next) => {

  const incomingRequestId = req.get('x-request-id');
  const requestId = incomingRequestId && incomingRequestId.length <= 128  ? incomingRequestId : crypto.randomUUID();

  req.requestId = requestId;
  res.setHeader('X-Request-ID', requestId,);

  next();
});

/* -------------------------------------------------------------------------- */
/* Security headers                                                           */
/* -------------------------------------------------------------------------- */

if (env.security.headersEnabled) {
  app.use(
    helmet({
      /**
       * HSTS is enabled only after HTTPS is fully configured.
       */
      hsts: env.security.hstsEnabled
        ? {
            maxAge: 31536000,
            includeSubDomains: true,
            preload: true,
          }
        : false,

      /**
       * Admin/vendor frontend are separate applications.
       */
      crossOriginResourcePolicy: {
        policy: 'same-site',
      },

      /**
       * Prevent MIME sniffing.
       */
      noSniff: true,

      /**
       * Prevent clickjacking.
       */
      frameguard: {
        action: 'deny',
      },

      /**
       * Referrer policy for the application.
       */
      referrerPolicy: {
        policy: 'strict-origin-when-cross-origin',
      },
    }),
  );
}


/* -------------------------------------------------------------------------- */
/* CORS                                                                       */
/* -------------------------------------------------------------------------- */

app.use(
  cors({
    origin(origin, callback) {
      /**
       * Requests without an Origin header can be:
       * - health checks
       * - server-to-server calls
       * - curl/Postman
       */
      if (!origin) {
        return callback(null, true);
      }

      if (
        env.cors.allowedOrigins.includes(
          origin,
        )
      ) {
        return callback(
          null,
          true,
        );
      }

      return callback(
        new Error(
          'CORS policy: origin is not allowed.',
        ),
        false,
      );
    },

    methods: [
      'GET',
      'POST',
      'PUT',
      'PATCH',
      'DELETE',
      'OPTIONS',
    ],

    allowedHeaders: [
      'Accept',
      'Authorization',
      'Content-Type',
      'X-Requested-With',
      'X-Request-ID',
      'X-API-Version',
    ],

    exposedHeaders: [
      'X-Request-ID',
      'Content-Disposition',
      'Content-Length',
    ],

    credentials: true,

    optionsSuccessStatus: 204,

    maxAge: 86400,
  }),
);


/* -------------------------------------------------------------------------- */
/* Compression                                                                */
/* -------------------------------------------------------------------------- */

app.use(
  compression({
    threshold: 1024,

    level: 6,

    /**
     * Do not compress already compressed file formats.
     */
    filter(req, res) {
      const contentType =
        res.getHeader(
          'Content-Type',
        );

      if (
        typeof contentType === 'string' &&
        (
          contentType.includes(
            'application/pdf',
          ) ||
          contentType.includes(
            'image/',
          ) ||
          contentType.includes(
            'application/zip',
          ) ||
          contentType.includes(
            'application/octet-stream',
          )
        )
      ) {
        return false;
      }

      return compression.filter(
        req,
        res,
      );
    },
  }),
);


/* -------------------------------------------------------------------------- */
/* Request logging                                                            */
/* -------------------------------------------------------------------------- */

const morganFormat =
  env.isProduction
    ? 'combined'
    : 'dev';

app.use(
  morgan(
    morganFormat,
    {
      skip(req) {
        /**
         * Health requests can become noisy.
         */
        return (
          req.path ===
          env.health.path
        );
      },
    },
  ),
);


/* -------------------------------------------------------------------------- */
/* Cookie parser                                                              */
/* -------------------------------------------------------------------------- */

app.use(
  cookieParser(),
);


/* -------------------------------------------------------------------------- */
/* Body parsers                                                               */
/* -------------------------------------------------------------------------- */

/**
 * JSON requests.
 */
app.use(
  express.json({
    limit: env.uploads.maxBodySize,

    strict: true,

    /**
     * Never expose the full request body in errors.
     */
    type: [
      'application/json',
      'application/*+json',
    ],
  }),
);


/**
 * URL encoded requests.
 */
app.use(
  express.urlencoded({
    extended: false,

    limit: env.uploads.maxBodySize,

    parameterLimit: 1000,
  }),
);


/* -------------------------------------------------------------------------- */
/* General API rate limit                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Broad protection for the public API.
 *
 * Authentication endpoints receive an additional stricter
 * limiter later in the authentication route layer.
 */
const apiRateLimiter =
  rateLimit({
    windowMs: env.rateLimit.general.windowMs,
    limit: env.rateLimit.general.maxRequests,
    standardHeaders: 'draft-8',
    legacyHeaders: false,

    skip(req) {
      /**
       * Do not spend API quota on health/readiness probes.
       */
      return (
        req.path === env.health.path ||
        req.path === env.health.readinessPath
      );
    },

    handler(req, res) {
      res.status(429).json({
        success: false,
        message: 'Too many requests. Please try again later.',
        requestId: req.requestId,
      });
    },
  });


app.use(
  env.app.apiPrefix,
  apiRateLimiter,
);


/* -------------------------------------------------------------------------- */
/* API version headers                                                        */
/* -------------------------------------------------------------------------- */

app.use(
  env.app.apiPrefix,
  (req, res, next) => {
    res.setHeader(
      'X-API-Version',
      env.app.apiVersion,
    );

    next();
  },
);


/* -------------------------------------------------------------------------- */
/* Root endpoint                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Keep root endpoint lightweight.
 */
app.get(
  '/',
  (req, res) => {
    res.status(200).json({
      success: true,
      application:  env.app.name,
      message: 'ARGUS API is running.',
      version: env.app.apiVersion,
      environment:
        env.isProduction
          ? 'production'
          : env.nodeEnv,
      requestId: req.requestId,
    });
  },
);


/* -------------------------------------------------------------------------- */
/* Liveness health check                                                      */
/* -------------------------------------------------------------------------- */


if (env.health.enabled) {
  app.get(
    env.health.path,
    (req, res) => {
      if (isShuttingDown) {
        return res.status(503).json({
          success: false,
          status: 'shutting_down',
          application:  env.app.name,
          requestId: req.requestId,
        });
      }


      return res.status(200).json({
        success: true,
        status: 'ok',
        application:  env.app.name,
        version: env.app.version || undefined,
        environment: env.nodeEnv,
        uptime: process.uptime(),
        timestamp: new Date().toISOString(),
        requestId: req.requestId,
      });
    },
  );
}


/* -------------------------------------------------------------------------- */
/* Readiness check                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Readiness:
 *
 * Answers:
 * "Can this API safely receive application traffic?"
 *
 * MongoDB MUST be reachable.
 */
if (env.health.enabled) {
  app.get(
    env.health.readinessPath,
    async (req, res, next) => {
      try {
        const databaseHealth = await database.health();

        const ready = databaseHealth.healthy === true && !isShuttingDown;

        return res
          .status( ready ? 200 : 503,)
          .json({
            success: ready,
            status: ready ? 'ready' : 'not_ready',
            application: env.app.name,
            dependencies: {
              database:
                databaseHealth,
            },
            timestamp: new Date().toISOString(),
            requestId: req.requestId,
          });
      } catch (error) {
        return next(error);
      }
    },
  );
}


/* -------------------------------------------------------------------------- */
/* API router import                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Imported dynamically so the server initialization order
 * remains explicit:
 *
 * 1. Load configuration
 * 2. Connect database
 * 3. Load application routes
 *
 * The actual route index will be created later.
 */
const { default: apiRouter } = await import('./src/routes/index.js');


/* -------------------------------------------------------------------------- */
/* API routes                                                                 */
/* -------------------------------------------------------------------------- */

app.use(
  `${env.app.apiPrefix}/${env.app.apiVersion}`,
  apiRouter,
);


/* -------------------------------------------------------------------------- */
/* 404 handler                                                                */
/* -------------------------------------------------------------------------- */

/**
 * Express 5 supports the final middleware handler without
 * needing a wildcard route.
 */
app.use(
  (req, res) => {
    res.status(404).json({
      success: false,
      message: 'The requested resource was not found.',
      path: req.originalUrl,
      method: req.method,
      requestId: req.requestId,
    });
  },
);


/* -------------------------------------------------------------------------- */
/* Central error handler                                                      */
/* -------------------------------------------------------------------------- */

app.use(
  (
    error,
    req,
    res,
    next,
) => {
    /**
     * next is intentionally referenced to preserve
     * Express error-handler signature.
     */
    void next;

    let statusCode =
      error.statusCode ||
      error.status ||
      500;

    /**
     * Never allow invalid status codes.
     */
    if (
      !Number.isInteger(
        statusCode,
      ) ||
      statusCode < 400 ||
      statusCode > 599
    ) {
      statusCode = 500;
    }


    /**
     * CORS errors.
     */
    if (
      error.message?.startsWith(
        'CORS policy:',
      )
    ) {
      statusCode = 403;
    }


    /**
     * Payload too large.
     */
    if (
      error.type ===
      'entity.too.large'
    ) {
      statusCode = 413;
    }


    /**
     * Malformed JSON.
     */
    if (
      error instanceof SyntaxError &&
      error.status === 400 &&
      'body' in error
    ) {
      statusCode = 400;
    }


    const isServerError =
      statusCode >= 500;


    /**
     * Never expose internal error stacks in production.
     */
    const response = {
      success: false,

      message:
        isServerError
          ? 'An unexpected server error occurred.'
          : error.message ||
            'Request failed.',

      requestId:
        req.requestId,
    };


    /**
     * Development/test diagnostics.
     */
    if (
      !env.isProduction
    ) {
      response.error = {
        name:
          error.name,

        stack:
          error.stack,
      };
    }


    /**
     * Log server-side diagnostics.
     */
    if (isServerError) {
      console.error( '[SERVER ERROR]',
        {
          requestId: req.requestId,
          method: req.method,
          url: req.originalUrl,
          statusCode,
          error: error.message,
          stack: error.stack,
        },
      );
    } else {
      console.warn(
        '[REQUEST ERROR]',
        {
          requestId: req.requestId,
          method: req.method,
          url: req.originalUrl,
          statusCode,
          error: error.message,
        },
      );
    }


    if (
      res.headersSent
    ) {
      return;
    }

    return res
      .status(statusCode)
      .json(response);
  },
);


/* -------------------------------------------------------------------------- */
/* Graceful shutdown                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Stop accepting new requests first.
 *
 * Then:
 * 1. Wait for active requests
 * 2. Close MongoDB
 * 3. Close HTTP server
 * 4. Exit
 */
async function gracefulShutdown(
  signal,
) {
  if (isShuttingDown) {
    return;
  }

  isShuttingDown = true;

  console.warn(
    `[SERVER] ${signal} received. Starting graceful shutdown...`,
  );


  /**
   * Tell load balancers/container orchestrators that
   * this instance is no longer ready.
   */
  try {
    await new Promise(
      (resolve) => {
        server.close(
          async () => {
            try {
              await database.shutdown();

              console.info(
                '[SERVER] Graceful shutdown completed.',
              );

              resolve();
            } catch (error) {
              console.error(
                '[SERVER] Database shutdown failed:',
                error.message,
              );

              resolve();
            }
          },
        );
      },
    );


    process.exitCode = 0;
  } catch (error) {
    console.error(
      '[SERVER] Graceful shutdown failed:',
      error,
    );

    process.exitCode = 1;
  }
}


/* -------------------------------------------------------------------------- */
/* Process-level error handling                                               */
/* -------------------------------------------------------------------------- */

/**
 * An unhandled rejection means application state can no longer
 * be considered reliable.
 */
process.on(
  'unhandledRejection',
  (reason) => {
    console.error(
      '[PROCESS] Unhandled promise rejection:',
      reason,
    );

    void gracefulShutdown(
      'unhandledRejection',
    );
  },
);


/**
 * An uncaught exception generally indicates an unsafe
 * application state, so terminate gracefully.
 */
process.on(
  'uncaughtException',
  (error) => {
    console.error(
      '[PROCESS] Uncaught exception:',
      error,
    );

    void gracefulShutdown(
      'uncaughtException',
    );
  },
);


/* -------------------------------------------------------------------------- */
/* Operating-system shutdown signals                                          */
/* -------------------------------------------------------------------------- */

process.once(
  'SIGINT',
  () => {
    void gracefulShutdown(
      'SIGINT',
    );
  },
);


process.once(
  'SIGTERM',
  () => {
    void gracefulShutdown(
      'SIGTERM',
    );
  },
);


/* -------------------------------------------------------------------------- */
/* Start server                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Bootstrap sequence:
 *
 * 1. Validate/load env configuration
 * 2. Establish MongoDB connection
 * 3. Start HTTP server
 */
async function bootstrap() {
  try {
    console.info(
      `[SERVER] Starting ${env.app.name} API...`,
    );

    console.info(
      `[SERVER] Environment: ${env.nodeEnv}`,
    );

    console.info(
      `[SERVER] API: ${env.app.apiPrefix}/${env.app.apiVersion}`,
    );


    /**
     * Database must be available before the application
     * starts accepting requests.
     */
    await database.connect();


    await new Promise(
      (
        resolve,
        reject,
      ) => {
        server.listen(
          env.app.port,
          env.app.host,
          () => {
            console.info(
              `[SERVER] ${env.app.name} API listening on ${env.app.host}:${env.app.port}`,
            );

            console.info(
              `[SERVER] API base: ${env.app.apiUrl}`,
            );

            resolve();
          },
        );


        server.once(
          'error',
          reject,
        );
      },
    );
  } catch (error) {
    console.error(
      '[SERVER] Application startup failed:',
      error.message,
    );

    try {
      await database.shutdown();
    } catch {
      // Ignore secondary shutdown failure.
    }

    process.exitCode = 1;
  }
}


/* -------------------------------------------------------------------------- */
/* Start ARGUS                                                               */
/* -------------------------------------------------------------------------- */

await bootstrap();