# ARGUS Backend — Production Structure

Phase 1 scaffold based on the supplied ARGUS project analysis and the supplied React UI ZIP.

Decisions: Node.js + Express + PostgreSQL; local filesystem storage only; two authentication domains (Admin/Internal and Vendor Portal); API-level RBAC; vendor data isolation; server-side calculations; audit trail.

Feature implementation placeholders are intentional for the next coding phase.
