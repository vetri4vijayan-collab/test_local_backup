-- Wasabi S3 storage metadata and audit tables for applicant resumes.
-- Run during a maintenance window after a database backup. This does not alter or delete
-- egc_applicant. It intentionally has no foreign key so it can be installed against the
-- existing ERP schema without assuming the legacy column's integer signedness.

CREATE TABLE IF NOT EXISTS `egc_applicant_file_storage` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `applicant_sno` BIGINT UNSIGNED NOT NULL,
  `bucket_name` VARCHAR(255) NOT NULL,
  `object_key` VARCHAR(768) NOT NULL,
  `original_name` VARCHAR(240) NOT NULL,
  `mime_type` VARCHAR(191) DEFAULT NULL,
  `file_size` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `sha256` CHAR(64) NOT NULL,
  `source_provider` VARCHAR(32) NOT NULL DEFAULT 'upload',
  `source_reference_hash` CHAR(64) DEFAULT NULL,
  `storage_status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `deleted_at` DATETIME DEFAULT NULL,
  `created_by` BIGINT DEFAULT NULL,
  `updated_by` BIGINT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_egc_applicant_storage_applicant` (`applicant_sno`),
  KEY `idx_egc_applicant_storage_status` (`storage_status`),
  KEY `idx_egc_applicant_storage_sha256` (`sha256`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `egc_applicant_storage_audit` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `applicant_sno` BIGINT UNSIGNED NOT NULL,
  `action_name` VARCHAR(40) NOT NULL,
  `source_provider` VARCHAR(32) DEFAULT NULL,
  `object_key` VARCHAR(768) DEFAULT NULL,
  `sha256` CHAR(64) DEFAULT NULL,
  `outcome` VARCHAR(20) NOT NULL,
  `message` TEXT,
  `actor_id` BIGINT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`),
  KEY `idx_egc_storage_audit_applicant_created` (`applicant_sno`, `created_at`),
  KEY `idx_egc_storage_audit_outcome_created` (`outcome`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
