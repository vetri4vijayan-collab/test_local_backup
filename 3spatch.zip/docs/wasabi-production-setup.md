# Wasabi S3 applicant resume storage patch

## What this patch changes

- Adds a reusable `WasabiResumeStorageService` using the AWS SDK for PHP S3 client, configured for Wasabi's S3-compatible endpoint and Signature V4.
- Stores applicant resume objects as **private** Wasabi objects under an opaque key such as `erp/applicants/{applicant_sno}/resumes/{uuid}.pdf`. It never sends a `public-read` ACL.
- Verifies the stored object by checking content length and a SHA-256 object metadata value before switching the active storage pointer in SQL.
- Adds short-lived view/download URLs (default 300 seconds, bounded to 60–900 seconds), authorized ERP routes, upload/replace and delete endpoints, and an append-only audit table.
- Adds a token-protected Postman migration API that supports dry-run, one applicant, or small batches from the existing public resume directory or Google Drive.
- Updates the Candidate list and AI resume viewer to use the ERP-authenticated resume resolver first.
- Keeps the current local file and Google Drive write behavior during the compatibility phase. This is deliberate: other ERP controllers/templates in the supplied archive still use the legacy `attachment`/`drive_data` fields and static asset paths.

## Important source-archive limitation

The ZIP supplied for this change did not contain `composer.json`, `.env.example`, `artisan`, Laravel configuration/bootstrap files, or the live database schema. Therefore, this patch contains the dependency and environment instructions below, but it cannot update a missing Composer manifest or prove a full end-to-end test against the production database. PHP syntax checks were run on the changed PHP files.

## 1. Install dependency

Run from the **actual ERP project root** (the directory containing `composer.json`):

```bash
composer require aws/aws-sdk-php
```

The patch uses the AWS SDK directly, so a Laravel Flysystem S3 adapter is not required for these endpoints. Do not overwrite the existing Laravel `filesystems.php` disks for this patch.

## 2. Add environment variables

Add these to the production `.env`. Put real values only in `.env`/secret management; never commit them to Git or put them in a Postman collection.

```dotenv
WASABI_ENABLED=true
WASABI_ACCESS_KEY=replace_with_wasabi_access_key
WASABI_SECRET_KEY=replace_with_wasabi_secret_key
WASABI_DEFAULT_REGION=us-east-2
WASABI_BUCKET=replace_with_existing_bucket_name
WASABI_ENDPOINT=https://s3.us-east-2.wasabisys.com
WASABI_PREFIX=erp
WASABI_URL_EXPIRY_SECONDS=300
WASABI_MAX_FILE_SIZE_BYTES=52428800
WASABI_CONNECT_TIMEOUT_SECONDS=5
WASABI_REQUEST_TIMEOUT_SECONDS=60
WASABI_MIGRATION_API_TOKEN=replace_with_a_long_random_secret
WASABI_DELETE_PREVIOUS_ON_REPLACE=true
```

Generate a migration token with:

```bash
php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
```

`WASABI_MAX_FILE_SIZE_BYTES` defaults to 50 MiB for migration of old objects. The existing Add Candidate form keeps its current 10 MiB validation. Set the value to your required migration limit only after checking PHP `upload_max_filesize`, `post_max_size`, timeouts and server storage capacity.

The bucket should already exist in the `us-east-2` region. Keep public bucket/object access disabled. Give the application access key only the permissions it needs for this bucket/prefix: `PutObject`, `GetObject`, `HeadObject`/read metadata, and `DeleteObject`. Do not use account-owner access keys in application deployments.

## 3. SQL rollout

1. Take a production database backup.
2. Apply `database/sql/wasabi_applicant_storage.sql` to the ERP database.
3. Verify both tables exist: `egc_applicant_file_storage` and `egc_applicant_storage_audit`.
4. Deploy the files in this patch.
5. From the project root run:

```bash
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan config:cache
```

The SQL deliberately adds two independent tables and does **not** alter `egc_applicant` or overwrite `attachment`/`drive_data`. No legacy source files are deleted by upload/migration. On rollback, disable `WASABI_ENABLED`, clear/cache Laravel config and restore the previous deployed PHP/Blade files; existing local/Drive resume paths are left in place.

## 4. Web endpoint routes

These routes inherit the same authenticated `auth:web` + timezone group as the current HR recruitment screens.

| Method | Path | Purpose |
|---|---|---|
| GET | `/hr-recruiter/applicants/{sno}/resume/urls` | Return short-lived Wasabi `view_url` and `download_url`, or legacy ERP URLs |
| GET | `/hr-recruiter/applicants/{sno}/resume/open?disposition=inline` | Open the active Wasabi object; falls back to authenticated local/Drive retrieval |
| GET | `/hr-recruiter/applicants/{sno}/resume/open?disposition=attachment` | Download the active Wasabi object; falls back to authenticated local/Drive retrieval |
| POST | `/hr-recruiter/applicants/{sno}/resume` | Upload/replace an existing applicant resume; accepts multipart field `upload_resume` |
| DELETE | `/hr-recruiter/applicants/{sno}/resume` | Delete the active Wasabi object and mark its pointer deleted; leaves local/Drive rollback copies intact |

The `urls` response includes the actual pre-signed Wasabi URLs when a private cloud object is active. Treat those values as credentials until expiry; do not persist them in the database or application logs.

## 5. Migration API (Postman)

**Endpoint:** `POST {{base_url}}/api/wasabi/applicants/migrate`

**Headers**

```http
Accept: application/json
Content-Type: application/json
X-Wasabi-Migration-Token: {{migration_token}}
```

The route is throttled to five requests per minute and independently guarded by `WASABI_MIGRATION_API_TOKEN`. Rotate the token if it is ever exposed. The endpoint only attempts to migrate records whose applicant status is not `2`.

### A. First request must be dry-run

```json
{
  "dry_run": true,
  "source": "auto",
  "limit": 25,
  "after_sno": 0
}
```

`auto` uses the legacy local file when it is readable; if no local file is found, it tries the `file_id` in `drive_data`. Dry-run checks source eligibility and existing storage status but makes no object writes.

### B. Migrate one candidate

```json
{
  "applicant_sno": 123,
  "dry_run": false,
  "source": "auto"
}
```

Use `source: "local"` to require `public/job_applications/resume_files/{attachment}` or `source: "drive"` to require `drive_data.file_id`. Only set `replace: true` after reviewing the existing active object. By default, rows with an active Wasabi object are skipped.

### C. Batch migration

```json
{
  "dry_run": false,
  "source": "auto",
  "limit": 25,
  "after_sno": 0
}
```

Use `next_after_sno` from the response as the next request's `after_sno`. Run small batches first; increase only after checking latency, server logs, Wasabi request limits and Drive access. Failed items return generic client messages; the detailed error is in Laravel logs and the audit table. Re-run failed records individually after correcting the source/configuration.

Example response fields:

```json
{
  "status": true,
  "dry_run": false,
  "counts": { "planned": 0, "migrated": 1, "skipped": 0, "failed": 0 },
  "last_processed_sno": 123,
  "next_after_sno": 123,
  "source_files_deleted": false
}
```

## 6. Candidate upload behavior

When an HR user submits Add Candidate with a resume, the existing extraction, validation, local compatibility save, and Google Drive upload still run as they did before. After the applicant database transaction commits, the new Wasabi service uploads and verifies a private cloud object and writes its storage metadata. The response returns `data.resume_storage`:

- `wasabi_verified`: Wasabi object and metadata verification succeeded.
- `legacy_fallback`: Wasabi/SQL/SDK failed; the already-saved applicant and existing local/Drive file remain intact. Check `storage/logs/laravel.log` before retrying.
- `wasabi_not_configured`: the access credentials/bucket/endpoint are missing or Wasabi is explicitly disabled.

That failure policy is intentional to avoid making an S3 outage break candidate registration during rollout. For strict cloud-only policy, change the business requirement after all legacy readers have been converted and after testing failure/retry handling.

## 7. Operational/security checklist

- Restrict credentials to the dedicated bucket/prefix; use HTTPS and private objects only.
- Keep `.env` and logs access-restricted. Do not store pre-signed URLs in SQL or logs.
- Test one local-file migration, one Drive-only migration, and one new candidate upload in staging first; compare SHA-256 and sizes.
- Test inline PDF, Office download, missing file, expired signed URL, Wasabi outage, invalid token, and storage-table-unavailable cases.
- Review `egc_applicant_storage_audit` for success/failure events. The migration never removes the local source or Drive record.
- Existing public static URLs like `/job_applications/resume_files/{attachment}` may still be directly accessible until every other ERP reader is migrated. The patched Candidate list links use the authenticated resolver, but this patch intentionally does not block the legacy public folder because doing so could break older modules. Plan a separate final cutover to move compatibility files outside `public/` and deny direct static access after scanning all uses.
- Use a Wasabi bucket policy and account controls to keep the bucket private. Consider versioning/retention according to your operational rollback policy before enabling deletes.

## Official references

- Wasabi S3-compatible endpoint and authentication: https://docs.wasabi.com/apidocs
- Wasabi service URL for US East 2: https://docs.wasabi.com/docs/service-urls-for-wasabis-storage-regions
- AWS SDK for PHP short-lived S3 pre-signed URLs: https://docs.aws.amazon.com/sdk-for-php/v3/developer-guide/s3-presigned-url.html
