<?php

return [
    'enabled' => env('WASABI_ENABLED', true),
    'access_key' => env('WASABI_ACCESS_KEY'),
    'secret_key' => env('WASABI_SECRET_KEY'),
    'region' => env('WASABI_DEFAULT_REGION', 'us-east-2'),
    'bucket' => env('WASABI_BUCKET'),
    'endpoint' => env('WASABI_ENDPOINT', 'https://s3.us-east-2.wasabisys.com'),
    'prefix' => trim((string) env('WASABI_PREFIX', 'erp'), '/'),
    'url_expiry_seconds' => (int) env('WASABI_URL_EXPIRY_SECONDS', 300),
    'max_file_size_bytes' => (int) env('WASABI_MAX_FILE_SIZE_BYTES', 52428800),
    'migration_api_token' => env('WASABI_MIGRATION_API_TOKEN'),
    // Existing resume writes keep the ERP's local compatibility copy until legacy asset consumers are cut over.
    'delete_previous_on_replace' => env('WASABI_DELETE_PREVIOUS_ON_REPLACE', true),
    'connect_timeout_seconds' => (int) env('WASABI_CONNECT_TIMEOUT_SECONDS', 5),
    'request_timeout_seconds' => (int) env('WASABI_REQUEST_TIMEOUT_SECONDS', 60),
];
