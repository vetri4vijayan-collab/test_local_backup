@extends('layouts.layoutMaster')

@section('title', 'Planning & Quantity Surveying (QS) Engine - Balance Work Programme')

@section('content')

<div class="container-fluid">


    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-lg-row
                        justify-content-between
                        align-items-lg-center gap-3">

                <div>

                    <h4 class="mb-1 fw-bold">
                        Planning & Quantity Surveying (QS) Engine
                    </h4>

                    <p class="text-muted mb-0">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>

                </div>

                <div class="d-flex flex-wrap gap-2">

                    <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">

                            <i class="mdi mdi-chevron-left"></i>

                        </button>

                        <div class="settings-tabs-scroller">

                            <div class="settings-tabs-track"
                                 id="qsTabsTrack">

                                <a href="{{ route('planning-qs.schedule') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.schedule') ? 'active' : '' }}">
                                    Monthly Program
                                </a>

                                <a href="{{ route('planning-qs.schedule.balance') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.schedule.balance') ? 'active' : '' }}">
                                    Balance Work Programme
                                </a>
                       </div>

                        </div>

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">

                            <i class="mdi mdi-chevron-right"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    </div>



    <div class="row g-3 mb-4">

    {{-- Pending BOQ Scope Items --}}
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-4">

                <div class="d-flex justify-content-between align-items-start">

                    <div>
                        <div class="text-muted fw-medium mb-2">
                            Pending BOQ Scope Items
                        </div>

                        <div class="fw-bold display-6 mb-1"
                             id="pendingCount">
                            10
                        </div>

                        <small class="text-muted">
                            <i class="mdi mdi-clock-outline me-1"></i>
                            uncompleted packages
                        </small>
                    </div>

                    <div class="rounded-3 p-3"
                         style="color:#ff9f43;background:rgba(255,159,67,.10);">

                        <i class="mdi mdi-file-document-multiple-outline fs-3"></i>

                    </div>

                </div>

            </div>
        </div>
    </div>


    {{-- Balance Work Value --}}
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-4">

                <div class="d-flex justify-content-between align-items-start">

                    <div>
                        <div class="text-muted fw-medium mb-2">
                            Balance Work Value
                        </div>

                        <div class="fw-bold display-6 mb-1"
                             id="balanceValueStat">
                            ₹ 8.56 Cr
                        </div>

                        <small class="text-muted">
                            <i class="mdi mdi-chart-line me-1"></i>
                            remaining BOQ value
                        </small>
                    </div>

                    <div class="rounded-3 p-3"
                         style="color:#28c76f;background:rgba(40,199,111,.10);">

                        <i class="mdi mdi-currency-inr fs-3"></i>

                    </div>

                </div>

            </div>
        </div>
    </div>


    {{-- Delayed Packages --}}
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-4">

                <div class="d-flex justify-content-between align-items-start">

                    <div>
                        <div class="text-muted fw-medium mb-2">
                            Delayed Packages
                        </div>

                        <div class="fw-bold display-6 mb-1"
                             id="delayedCount">
                            3
                        </div>

                        <small class="text-muted">
                            <i class="mdi mdi-alert-circle-outline me-1"></i>
                            requires acceleration
                        </small>
                    </div>

                    <div class="rounded-3 p-3"
                         style="color:#ea5455;background:rgba(234,84,85,.10);">

                        <i class="mdi mdi-alert-circle-outline fs-3"></i>

                    </div>

                </div>

            </div>
        </div>
    </div>


    {{-- Average Schedule Completion --}}
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-4">

                <div class="d-flex justify-content-between align-items-start">

                    <div>
                        <div class="text-muted fw-medium mb-2">
                            Avg Schedule Completion
                        </div>

                        <div class="fw-bold display-6 mb-1"
                             id="avgCompletionStat">
                            40%
                        </div>

                        <small class="text-muted">
                            <i class="mdi mdi-progress-clock me-1"></i>
                            overall progress
                        </small>
                    </div>

                    <div class="rounded-3 p-3"
                         style="color:#ff9f43;background:rgba(255,159,67,.10);">

                        <i class="mdi mdi-progress-clock fs-3"></i>

                    </div>

                </div>

            </div>
        </div>
    </div>

</div>

    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body p-3">

            <div class="row g-3 align-items-end">

                {{-- PROJECT --}}
                <div class="col-12 col-md-3">

                    <label class="form-label fw-semibold small">
                        All Projects
                    </label>

                    <select id="subProjectFilter"
                            class="form-select form-select-sm rounded-pill-select">

                        <option value="all">
                            All Projects
                        </option>

                        <option value="PRJ-001">
                            Reinforcing Steel Cage Fabrication
                        </option>

                        <option value="PRJ-002">
                            Piling Concrete Pouring
                        </option>
                    </select>

                </div>


                {{-- CONTRACTOR --}}
                <div class="col-12 col-md-3">

                    <label class="form-label fw-semibold small">
                        All Sub-Contractors
                    </label>

                    <select id="contractorWOFilter"
                            class="form-select form-select-sm rounded-pill-select">

                        <option value="all">
                            All Sub-Contractors
                        </option>

                        <option value="Apex Structural Sub-Contractors">
                            Apex Structural Sub-Contractors
                        </option>

                        <option value="Star Bar-Bending Works">
                            Star Bar-Bending Works
                        </option>

                        <option value="Vanguard Piling Rigs">
                            Vanguard Piling Rigs
                        </option>

                    </select>

                </div>


                {{-- STATUS --}}
                <div class="col-12 col-md-3">

                    <label class="form-label fw-semibold small">
                        All Statuses
                    </label>

                    <select id="statusFilter"
                            class="form-select form-select-sm rounded-pill-select">

                        <option value="all">
                            All Statuses
                        </option>

                        <option value="in-progress">
                            In Progress
                        </option>

                        <option value="started">
                            Started
                        </option>

                        <option value="delayed">
                            Delayed
                        </option>

                        <option value="not-started">
                            Not Started
                        </option>

                    </select>

                </div>


                {{-- SEARCH --}}
                <div class="col-12 col-md-3">

                    <label class="form-label fw-semibold small">
                        Search
                    </label>

                    <div class="input-group input-group-sm search-pill">

                        <span class="input-group-text bg-white border-0">
                            <i class="mdi mdi-magnify"></i>
                        </span>

                        <input type="text"
                               id="subSearchInput"
                               class="form-control border-0"
                               placeholder="Search balance work item...">

                    </div>

                </div>

            </div>

        </div>

    </div>



    <div class="row g-3" id="balanceCardGrid">


       {{-- Balance Work Item --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">

    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px; overflow:hidden;"
         data-column="piling"
         data-project="PRJ-001"
         data-contractor="Apex Structural Sub-Contractors"
         data-status="in-progress"
         data-balance="1160000"
         data-progress="89">

        <div class="card-body p-4">

            {{-- Category + Status --}}
            <div class="d-flex justify-content-between align-items-center mb-2">

                <span class="text-uppercase text-muted fw-semibold small">
                    Piling &amp; Deep Foundations
                </span>

                <span class="badge px-3 py-2"
                      style="
                          color:#7367f0;
                          background:rgba(115,103,240,.10);
                          border-radius:20px;
                      ">
                    in-progress
                </span>

            </div>


            {{-- Work Title --}}
            <h5 class="fw-bold mb-3">
                Reinforcing Steel Cage Fabrication
            </h5>


            {{-- Contractor --}}
            <div class="d-flex align-items-start gap-2 mb-4 text-muted">

                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>

                <span>
                    Sub-Contractor:
                    <strong class="text-dark">
                        Apex Structural Sub-Contractors
                    </strong>

                    <span class="text-muted">
                        (SCWO/APEX/088)
                    </span>
                </span>

            </div>


            {{-- INNER DETAILS CARD --}}
            <div style="
                    background:#f8f9fa;
                    border-radius:18px;
                    padding:16px;
                    margin-bottom:18px;
                ">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-07-03</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-07-28</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>180 MT</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>160 MT</strong>
                </div>

                {{-- Balance --}}
                <div class="d-flex justify-content-between align-items-center pt-3">

                    <span class="text-muted fw-medium">
                        Balance Work Qty:
                    </span>

                    <div class="text-end">
                        <strong class="text-success">
                            20 MT
                        </strong>

                        <small class="d-block text-success">
                            ₹ 11,60,000
                        </small>
                    </div>

                </div>

            </div>


            {{-- Execution Progress --}}
            <div class="mb-3">

                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">
                        Execution Progress
                    </span>

                    <strong>89%</strong>
                </div>

                <div class="progress"
                     style="
                         height:8px;
                         border-radius:20px;
                         background:#eee;
                     ">

                    <div class="progress-bar"
                         style="
                             width:89%;
                             background:#28c76f;
                             border-radius:20px;
                         ">
                    </div>

                </div>

            </div>


            {{-- Update Button --}}
            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="
                        background:rgba(115,103,240,.10);
                        color:#7367f0;
                        border-radius:16px;
                        padding:12px;
                    ">

                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule

            </button>

        </div>

    </div>

</div>


      {{-- 2 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">

    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px; overflow:hidden;"
         data-column="piling"
         data-project="PRJ-001"
         data-contractor="Apex Structural Sub-Contractors"
         data-status="in-progress"
         data-balance="1550000"
         data-progress="79">

        <div class="card-body p-4">

            {{-- Category + Status --}}
            <div class="d-flex justify-content-between align-items-center mb-2">

                <span class="text-uppercase text-muted fw-semibold small">
                    Piling &amp; Deep Foundations
                </span>

                <span class="badge px-3 py-2"
                      style="
                          color:#7367f0;
                          background:rgba(115,103,240,.10);
                          border-radius:20px;
                      ">
                    in-progress
                </span>

            </div>


            {{-- Work Title --}}
            <h5 class="fw-bold mb-3">
                Piling Concrete Pouring
            </h5>


            {{-- Contractor --}}
            <div class="d-flex align-items-start gap-2 mb-4 text-muted">

                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>

                <span>
                    Sub-Contractor:
                    <strong class="text-dark">
                        Apex Structural Sub-Contractors
                    </strong>

                    <span class="text-muted">
                        (SCWO/APEX/088)
                    </span>
                </span>

            </div>


            {{-- INNER DETAILS CARD --}}
            <div style="
                    background:#f8f9fa;
                    border-radius:18px;
                    padding:16px;
                    margin-bottom:18px;
                ">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-07-05</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-07-30</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>1,200 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>950 CuM</strong>
                </div>

                {{-- Balance --}}
                <div class="d-flex justify-content-between align-items-center pt-3">

                    <span class="text-muted fw-medium">
                        Balance Work Qty:
                    </span>

                    <div class="text-end">
                        <strong class="text-success">
                            250 CuM
                        </strong>

                        <small class="d-block text-success">
                            ₹ 15,50,000
                        </small>
                    </div>

                </div>

            </div>


            {{-- Execution Progress --}}
            <div class="mb-3">

                <div class="d-flex justify-content-between align-items-center mb-2">

                    <span class="text-muted fw-medium">
                        Execution Progress
                    </span>

                    <strong>79%</strong>

                </div>

                <div class="progress"
                     style="
                         height:8px;
                         border-radius:20px;
                         background:#eee;
                     ">

                    <div class="progress-bar"
                         role="progressbar"
                         style="
                             width:79%;
                             background:#28c76f;
                             border-radius:20px;
                         "
                         aria-valuenow="79"
                         aria-valuemin="0"
                         aria-valuemax="100">
                    </div>

                </div>

            </div>


            {{-- Update Button --}}
            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="
                        background:rgba(115,103,240,.10);
                        color:#7367f0;
                        border-radius:16px;
                        padding:12px;
                    ">

                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule

            </button>

        </div>

    </div>

</div>
        {{-- 3 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">

    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px; overflow:hidden;"
         data-column="piling"
         data-project="PRJ-001"
         data-contractor="Star Bar-Bending Works"
         data-status="not-started"
         data-balance="26400000"
         data-progress="0">

        <div class="card-body p-4">

            {{-- Category + Status --}}
            <div class="d-flex justify-content-between align-items-center mb-2">

                <span class="text-uppercase text-muted fw-semibold small">
                    Piling &amp; Deep Foundations
                </span>

                <span class="badge px-3 py-2"
                      style="
                          color:#82868b;
                          background:rgba(130,134,139,.10);
                          border-radius:20px;
                      ">
                    not-started
                </span>

            </div>


            {{-- Work Title --}}
            <h5 class="fw-bold mb-3">
                Piling Excavation (25m depth)
            </h5>


            {{-- Contractor --}}
            <div class="d-flex align-items-start gap-2 mb-4 text-muted">

                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>

                <span>
                    Sub-Contractor:
                    <strong class="text-dark">
                        Star Bar-Bending Works
                    </strong>

                    <span class="text-muted">
                        (SCWO/STAR/042)
                    </span>
                </span>

            </div>


            {{-- INNER DETAILS CARD --}}
            <div style="
                    background:#f8f9fa;
                    border-radius:18px;
                    padding:16px;
                    margin-bottom:18px;
                ">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-02-20</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-07-31</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>1,200 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>0 CuM</strong>
                </div>

                {{-- Balance --}}
                <div class="d-flex justify-content-between align-items-center pt-3">

                    <span class="text-muted fw-medium">
                        Balance Work Qty:
                    </span>

                    <div class="text-end">
                        <strong class="text-success">
                            1,200 CuM
                        </strong>

                        <small class="d-block text-success">
                            ₹ 2,64,00,000
                        </small>
                    </div>

                </div>

            </div>


            {{-- Execution Progress --}}
            <div class="mb-3">

                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">
                        Execution Progress
                    </span>

                    <strong>0%</strong>
                </div>

                <div class="progress"
                     style="
                         height:8px;
                         border-radius:20px;
                         background:#eee;
                     ">

                    <div class="progress-bar"
                         style="
                             width:0%;
                             background:#28c76f;
                             border-radius:20px;
                         ">
                    </div>

                </div>

            </div>


            {{-- Update Button --}}
            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="
                        background:rgba(115,103,240,.10);
                        color:#7367f0;
                        border-radius:16px;
                        padding:12px;
                    ">

                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule

            </button>

        </div>

    </div>

</div>


{{-- 4 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">

    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px; overflow:hidden;"
         data-column="piling"
         data-project="PRJ-001"
         data-contractor="Star Bar-Bending Works"
         data-status="in-progress"
         data-balance="870000"
         data-progress="92">

        <div class="card-body p-4">

            {{-- Category + Status --}}
            <div class="d-flex justify-content-between align-items-center mb-2">

                <span class="text-uppercase text-muted fw-semibold small">
                    Piling &amp; Deep Foundations
                </span>

                <span class="badge px-3 py-2"
                      style="
                          color:#7367f0;
                          background:rgba(115,103,240,.10);
                          border-radius:20px;
                      ">
                    in-progress
                </span>

            </div>


            {{-- Work Title --}}
            <h5 class="fw-bold mb-3">
                Reinforcing Steel Cage Fabrication
            </h5>


            {{-- Contractor --}}
            <div class="d-flex align-items-start gap-2 mb-4 text-muted">

                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>

                <span>
                    Sub-Contractor:
                    <strong class="text-dark">
                        Star Bar-Bending Works
                    </strong>

                    <span class="text-muted">
                        (SCWO/STAR/042)
                    </span>
                </span>

            </div>


            {{-- INNER DETAILS CARD --}}
            <div style="
                    background:#f8f9fa;
                    border-radius:18px;
                    padding:16px;
                    margin-bottom:18px;
                ">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-07-02</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-07-28</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>180 MT</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>165 MT</strong>
                </div>

                {{-- Balance --}}
                <div class="d-flex justify-content-between align-items-center pt-3">

                    <span class="text-muted fw-medium">
                        Balance Work Qty:
                    </span>

                    <div class="text-end">
                        <strong class="text-success">
                            15 MT
                        </strong>

                        <small class="d-block text-success">
                            ₹ 8,70,000
                        </small>
                    </div>

                </div>

            </div>


            {{-- Execution Progress --}}
            <div class="mb-3">

                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">
                        Execution Progress
                    </span>

                    <strong>92%</strong>
                </div>

                <div class="progress"
                     style="
                         height:8px;
                         border-radius:20px;
                         background:#eee;
                     ">

                    <div class="progress-bar"
                         style="
                             width:92%;
                             background:#28c76f;
                             border-radius:20px;
                         ">
                    </div>

                </div>

            </div>


            {{-- Update Button --}}
            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="
                        background:rgba(115,103,240,.10);
                        color:#7367f0;
                        border-radius:16px;
                        padding:12px;
                    ">

                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule

            </button>

        </div>

    </div>

</div>

{{-- 5 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">

    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px; overflow:hidden;"
         data-column="piling"
         data-project="PRJ-001"
         data-contractor="Star Bar-Bending Works"
         data-status="not-started"
         data-balance="7920000"
         data-progress="0">

        <div class="card-body p-4">

            {{-- Category + Status --}}
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Piling &amp; Deep Foundations
                </span>

                <span class="badge px-3 py-2"
                      style="color:#82868b;background:rgba(130,134,139,.10);border-radius:20px;">
                    not-started
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Piling Concrete Pouring
            </h5>

            {{-- Contractor --}}
            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>

                <span>
                    Sub-Contractor:
                    <strong class="text-dark">
                        Star Bar-Bending Works
                    </strong>
                    <span class="text-muted">
                        (SCWO/STAR/042)
                    </span>
                </span>
            </div>

            {{-- Inner Details Card --}}
            <div style="
                background:#f8f9fa;
                border-radius:18px;
                padding:16px;
                margin-bottom:18px;
            ">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-02-20</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-07-31</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>1,200 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>0 CuM</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">
                        Balance Work Qty:
                    </span>

                    <div class="text-end">
                        <strong class="text-success">
                            1,200 CuM
                        </strong>
                        <small class="d-block text-success">
                            ₹ 79,20,000
                        </small>
                    </div>
                </div>

            </div>

            {{-- Progress --}}
            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">
                        Execution Progress
                    </span>
                    <strong>0%</strong>
                </div>

                <div class="progress"
                     style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:0%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="
                        background:rgba(115,103,240,.10);
                        color:#7367f0;
                        border-radius:16px;
                        padding:12px;
                    ">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>

</div>


{{-- 6 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">

    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px;overflow:hidden;"
         data-column="substructure"
         data-project="PRJ-001"
         data-contractor="Apex Structural Sub-Contractors"
         data-status="started"
         data-balance="3053000"
         data-progress="49">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Substructure &amp; Piers
                </span>

                <span class="badge px-3 py-2"
                      style="color:#7367f0;background:rgba(115,103,240,.10);border-radius:20px;">
                    started
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Pile Cap Concrete
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>

                <span>
                    Sub-Contractor:
                    <strong class="text-dark">
                        Apex Structural Sub-Contractors
                    </strong>
                    <span class="text-muted">
                        (SCWO/APEX/088)
                    </span>
                </span>
            </div>

            {{-- Inner Details Card --}}
            <div style="
                background:#f8f9fa;
                border-radius:18px;
                padding:16px;
                margin-bottom:18px;
            ">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-07-15</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-08-15</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>850 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>420 CuM</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">
                        Balance Work Qty:
                    </span>

                    <div class="text-end">
                        <strong class="text-success">
                            430 CuM
                        </strong>
                        <small class="d-block text-success">
                            ₹ 30,53,000
                        </small>
                    </div>
                </div>

            </div>

            {{-- Progress --}}
            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">
                        Execution Progress
                    </span>
                    <strong>49%</strong>
                </div>

                <div class="progress"
                     style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:49%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="
                        background:rgba(115,103,240,.10);
                        color:#7367f0;
                        border-radius:16px;
                        padding:12px;
                    ">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>

</div>


{{-- 7 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">

    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px;overflow:hidden;"
         data-column="substructure"
         data-project="PRJ-001"
         data-contractor="Apex Structural Sub-Contractors"
         data-status="started"
         data-balance="3900000"
         data-progress="32">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Substructure &amp; Piers
                </span>

                <span class="badge px-3 py-2"
                      style="color:#7367f0;background:rgba(115,103,240,.10);border-radius:20px;">
                    started
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Pier Pedestal Fabrication
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>

                <span>
                    Sub-Contractor:
                    <strong class="text-dark">
                        Apex Structural Sub-Contractors
                    </strong>
                    <span class="text-muted">
                        (SCWO/APEX/088)
                    </span>
                </span>
            </div>

            {{-- Inner Details Card --}}
            <div style="
                background:#f8f9fa;
                border-radius:18px;
                padding:16px;
                margin-bottom:18px;
            ">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-07-18</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-08-20</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>95 MT</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>30 MT</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">
                        Balance Work Qty:
                    </span>

                    <div class="text-end">
                        <strong class="text-success">
                            65 MT
                        </strong>
                        <small class="d-block text-success">
                            ₹ 39,00,000
                        </small>
                    </div>
                </div>

            </div>

            {{-- Progress --}}
            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">
                        Execution Progress
                    </span>
                    <strong>32%</strong>
                </div>

                <div class="progress"
                     style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:32%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="
                        background:rgba(115,103,240,.10);
                        color:#7367f0;
                        border-radius:16px;
                        padding:12px;
                    ">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>

</div>


{{-- 8 - DELAYED --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">

    <div class="card border-0 shadow-sm h-100 balance-item delayed-card"
         style="border-radius:24px;overflow:hidden;"
         data-column="substructure"
         data-project="PRJ-001"
         data-contractor="Apex Structural Sub-Contractors"
         data-status="delayed"
         data-balance="3744000"
         data-progress="20">

        <div class="card-body p-4">

            {{-- Category + Status --}}
            <div class="d-flex justify-content-between align-items-center mb-2">

                <span class="text-uppercase text-muted fw-semibold small">
                    Substructure &amp; Piers
                </span>

                <span class="badge px-3 py-2"
                      style="
                          color:#ea5455;
                          background:rgba(234,84,85,.10);
                          border-radius:20px;
                      ">
                    delayed
                </span>

            </div>

            <h5 class="fw-bold mb-3">
                Pier Column Casting
            </h5>

            {{-- Contractor --}}
            <div class="d-flex align-items-start gap-2 mb-4 text-muted">

                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>

                <span>
                    Sub-Contractor:
                    <strong class="text-dark">
                        Apex Structural Sub-Contractors
                    </strong>

                    <span class="text-muted">
                        (SCWO/APEX/088)
                    </span>
                </span>

            </div>

            {{-- Inner Details Card --}}
            <div style="
                background:#f8f9fa;
                border-radius:18px;
                padding:16px;
                margin-bottom:18px;
            ">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-07-20</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-08-30</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>600 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>120 CuM</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">
                        Balance Work Qty:
                    </span>

                    <div class="text-end">
                        <strong class="text-success">
                            480 CuM
                        </strong>

                        <small class="d-block text-success">
                            ₹ 37,44,000
                        </small>
                    </div>
                </div>

            </div>

            {{-- Progress --}}
            <div class="mb-3">

                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">
                        Execution Progress
                    </span>

                    <strong>20%</strong>
                </div>

                <div class="progress"
                     style="height:8px;border-radius:20px;background:#eee;">

                    <div class="progress-bar"
                         style="
                             width:20%;
                             background:#ea5455;
                             border-radius:20px;
                         ">
                    </div>

                </div>

            </div>

            {{-- Delay Reason --}}
            <div style="
                background:rgba(234,84,85,.08);
                border-left:4px solid #ea5455;
                border-radius:12px;
                padding:12px 14px;
                margin-bottom:16px;
            ">

                <div class="fw-semibold mb-1"
                     style="color:#ea5455;">

                    <i class="mdi mdi-alert-circle-outline me-1"></i>
                    Reason for Delay

                </div>

                <div class="text-muted small">
                    RMC batching plant conveyor breakdown caused
                    4-day pour halt.
                </div>

            </div>

            {{-- Update Button --}}
            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="
                        background:rgba(115,103,240,.10);
                        color:#7367f0;
                        border-radius:16px;
                        padding:12px;
                    ">

                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule

            </button>

        </div>

    </div>

</div>
{{-- 9 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">
    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px;overflow:hidden;"
         data-column="substructure"
         data-project="PRJ-001"
         data-contractor="Star Bar-Bending Works"
         data-status="not-started"
         data-balance="61336000"
         data-progress="0">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Substructure &amp; Piers
                </span>

                <span class="badge px-3 py-2"
                      style="color:#82868b;background:rgba(130,134,139,.10);border-radius:20px;">
                    not-started
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Pile Cap Concrete
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>
                <span>
                    Sub-Contractor:
                    <strong class="text-dark">Star Bar-Bending Works</strong>
                    <span class="text-muted">(SCWO/STAR/042)</span>
                </span>
            </div>

            <div style="background:#f8f9fa;border-radius:18px;padding:16px;margin-bottom:18px;">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-02-20</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-07-31</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>850 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>0 CuM</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">Balance Work Qty:</span>

                    <div class="text-end">
                        <strong class="text-success">850 CuM</strong>
                        <small class="d-block text-success">₹ 61,33,600</small>
                    </div>
                </div>

            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">Execution Progress</span>
                    <strong>0%</strong>
                </div>

                <div class="progress" style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:0%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="background:rgba(115,103,240,.10);color:#7367f0;border-radius:16px;padding:12px;">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>
</div>


{{-- 10 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">
    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px;overflow:hidden;"
         data-column="substructure"
         data-project="PRJ-001"
         data-contractor="Star Bar-Bending Works"
         data-status="not-started"
         data-balance="5700000"
         data-progress="0">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Substructure &amp; Piers
                </span>

                <span class="badge px-3 py-2"
                      style="color:#82868b;background:rgba(130,134,139,.10);border-radius:20px;">
                    not-started
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Pier Pedestal Fabrication
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>
                <span>
                    Sub-Contractor:
                    <strong class="text-dark">Star Bar-Bending Works</strong>
                    <span class="text-muted">(SCWO/STAR/042)</span>
                </span>
            </div>

            <div style="background:#f8f9fa;border-radius:18px;padding:16px;margin-bottom:18px;">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-08-01</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-08-25</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>95 MT</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>0 MT</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">Balance Work Qty:</span>

                    <div class="text-end">
                        <strong class="text-success">95 MT</strong>
                        <small class="d-block text-success">₹ 57,00,000</small>
                    </div>
                </div>

            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">Execution Progress</span>
                    <strong>0%</strong>
                </div>

                <div class="progress" style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:0%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="background:rgba(115,103,240,.10);color:#7367f0;border-radius:16px;padding:12px;">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>
</div>


{{-- 11 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">
    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px;overflow:hidden;"
         data-column="substructure"
         data-project="PRJ-001"
         data-contractor="Star Bar-Bending Works"
         data-status="not-started"
         data-balance="4752000"
         data-progress="0">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Substructure &amp; Piers
                </span>

                <span class="badge px-3 py-2"
                      style="color:#82868b;background:rgba(130,134,139,.10);border-radius:20px;">
                    not-started
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Pier Column Casting
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>
                <span>
                    Sub-Contractor:
                    <strong class="text-dark">Star Bar-Bending Works</strong>
                    <span class="text-muted">(SCWO/STAR/042)</span>
                </span>
            </div>

            <div style="background:#f8f9fa;border-radius:18px;padding:16px;margin-bottom:18px;">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-02-20</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-07-31</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>600 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>0 CuM</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">Balance Work Qty:</span>

                    <div class="text-end">
                        <strong class="text-success">600 CuM</strong>
                        <small class="d-block text-success">₹ 47,52,000</small>
                    </div>
                </div>

            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">Execution Progress</span>
                    <strong>0%</strong>
                </div>

                <div class="progress" style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:0%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="background:rgba(115,103,240,.10);color:#7367f0;border-radius:16px;padding:12px;">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>
</div>


{{-- 12 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">
    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px;overflow:hidden;"
         data-column="substructure"
         data-project="PRJ-001"
         data-contractor="Apex Structural Sub-Contractors"
         data-status="not-started"
         data-balance="2200000"
         data-progress="0">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Substructure &amp; Piers
                </span>

                <span class="badge px-3 py-2"
                      style="color:#82868b;background:rgba(130,134,139,.10);border-radius:20px;">
                    not-started
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Substructure Finishing Works
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>
                <span>
                    Sub-Contractor:
                    <strong class="text-dark">Apex Structural Sub-Contractors</strong>
                    <span class="text-muted">(SCWO/APEX/088)</span>
                </span>
            </div>

            <div style="background:#f8f9fa;border-radius:18px;padding:16px;margin-bottom:18px;">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-08-10</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-09-10</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>1,000 SqM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>0 SqM</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">Balance Work Qty:</span>

                    <div class="text-end">
                        <strong class="text-success">1,000 SqM</strong>
                        <small class="d-block text-success">₹ 22,00,000</small>
                    </div>
                </div>

            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">Execution Progress</span>
                    <strong>0%</strong>
                </div>

                <div class="progress" style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:0%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="background:rgba(115,103,240,.10);color:#7367f0;border-radius:16px;padding:12px;">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>
</div>


{{-- 13 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">
    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px;overflow:hidden;"
         data-column="adyar"
         data-project="PRJ-002"
         data-contractor="Vanguard Piling Rigs"
         data-status="in-progress"
         data-balance="2160000"
         data-progress="79">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Adyar Block B Structure Core
                </span>

                <span class="badge px-3 py-2"
                      style="color:#7367f0;background:rgba(115,103,240,.10);border-radius:20px;">
                    in-progress
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Post-Tensioned Slab Casting
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>
                <span>
                    Sub-Contractor:
                    <strong class="text-dark">Vanguard Piling Rigs</strong>
                    <span class="text-muted">(SCWO/VANG/015)</span>
                </span>
            </div>

            <div style="background:#f8f9fa;border-radius:18px;padding:16px;margin-bottom:18px;">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-07-10</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-07-31</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>1,400 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>1,100 CuM</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">Balance Work Qty:</span>

                    <div class="text-end">
                        <strong class="text-success">300 CuM</strong>
                        <small class="d-block text-success">₹ 21,60,000</small>
                    </div>
                </div>

            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">Execution Progress</span>
                    <strong>79%</strong>
                </div>

                <div class="progress" style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:79%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="background:rgba(115,103,240,.10);color:#7367f0;border-radius:16px;padding:12px;">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>
</div>


{{-- 14 - DELAYED --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">
    <div class="card border-0 shadow-sm h-100 balance-item delayed-card"
         style="border-radius:24px;overflow:hidden;"
         data-column="adyar"
         data-project="PRJ-002"
         data-contractor="Vanguard Piling Rigs"
         data-status="delayed"
         data-balance="325500"
         data-progress="30">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Adyar Block B Structure Core
                </span>

                <span class="badge px-3 py-2"
                      style="color:#ea5455;background:rgba(234,84,85,.10);border-radius:20px;">
                    delayed
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Anchorage Installation
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>
                <span>
                    Sub-Contractor:
                    <strong class="text-dark">Vanguard Piling Rigs</strong>
                    <span class="text-muted">(SCWO/VANG/015)</span>
                </span>
            </div>

            <div style="background:#f8f9fa;border-radius:18px;padding:16px;margin-bottom:18px;">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-07-18</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-08-10</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>150 Nos.</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>45 Nos.</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">Balance Work Qty:</span>

                    <div class="text-end">
                        <strong class="text-success">105 Nos.</strong>
                        <small class="d-block text-success">₹ 3,25,500</small>
                    </div>
                </div>

            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">Execution Progress</span>
                    <strong>30%</strong>
                </div>

                <div class="progress" style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:30%;background:#ea5455;border-radius:20px;">
                    </div>
                </div>
            </div>

            {{-- Delay Reason --}}
            <div style="
                background:rgba(234,84,85,.08);
                border-left:4px solid #ea5455;
                border-radius:12px;
                padding:12px 14px;
                margin-bottom:16px;
            ">
                <div class="fw-semibold mb-1" style="color:#ea5455;">
                    <i class="mdi mdi-alert-circle-outline me-1"></i>
                    Reason for Delay
                </div>

                <div class="text-muted small">
                    Port customs clearance hold for imported anchorage castings.
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="background:rgba(115,103,240,.10);color:#7367f0;border-radius:16px;padding:12px;">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>
</div>


{{-- 15 --}}
<div class="col-12 col-md-6 col-lg-4 balance-col">
    <div class="card border-0 shadow-sm h-100 balance-item"
         style="border-radius:24px;overflow:hidden;"
         data-column="adyar"
         data-project="PRJ-002"
         data-contractor="Vanguard Piling Rigs"
         data-status="not-started"
         data-balance="9600000"
         data-progress="0">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-semibold small">
                    Adyar Block B Structure Core
                </span>

                <span class="badge px-3 py-2"
                      style="color:#82868b;background:rgba(130,134,139,.10);border-radius:20px;">
                    not-started
                </span>
            </div>

            <h5 class="fw-bold mb-3">
                Concrete Core Walls
            </h5>

            <div class="d-flex align-items-start gap-2 mb-4 text-muted">
                <i class="mdi mdi-account-hard-hat-outline fs-5"></i>
                <span>
                    Sub-Contractor:
                    <strong class="text-dark">Vanguard Piling Rigs</strong>
                    <span class="text-muted">(SCWO/VANG/015)</span>
                </span>
            </div>

            <div style="background:#f8f9fa;border-radius:18px;padding:16px;margin-bottom:18px;">

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Date Assigned:</span>
                    <strong>2026-08-05</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Target Completion:</span>
                    <strong>2026-09-15</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Total Scope:</span>
                    <strong>1,200 CuM</strong>
                </div>

                <div class="d-flex justify-content-between py-2 border-bottom">
                    <span class="text-muted">Executed:</span>
                    <strong>0 CuM</strong>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <span class="text-muted fw-medium">Balance Work Qty:</span>

                    <div class="text-end">
                        <strong class="text-success">1,200 CuM</strong>
                        <small class="d-block text-success">₹ 96,00,000</small>
                    </div>
                </div>

            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted fw-medium">Execution Progress</span>
                    <strong>0%</strong>
                </div>

                <div class="progress" style="height:8px;border-radius:20px;background:#eee;">
                    <div class="progress-bar"
                         style="width:0%;background:#28c76f;border-radius:20px;">
                    </div>
                </div>
            </div>

            <button type="button"
                    class="btn w-100 fw-semibold update-btn"
                    style="background:rgba(115,103,240,.10);color:#7367f0;border-radius:16px;padding:12px;">
                <i class="mdi mdi-pencil-outline me-1"></i>
                Update Status &amp; Schedule
            </button>

        </div>
    </div>
</div>


    <div id="noResults"
         class="d-none text-center py-5">

        <div class="mb-2">
            <i class="mdi mdi-file-search-outline fs-1 text-muted"></i>
        </div>

        <h6 class="fw-semibold">No records found</h6>

        <p class="text-muted mb-0">
            Try changing your project, contractor, status or search filter.
        </p>

    </div>



    <div class="d-flex justify-content-end mt-3">

        <span class="badge bg-label-primary px-3 py-2" id="recordCount">
            0 Records
        </span>

    </div>

</div>

@endsection



<!-- @stack('page-style') -->

<style>

        
.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}


    .program-icon {
        width: 44px;
        height: 44px;
        min-width: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        background: rgba(32, 201, 151, .10);
        color: #20c997;
        font-size: 22px;
    }

    .stat-card {
        background: #fff;
        border: 1px solid #e9edf4;
        border-radius: 14px;
        padding: 16px 18px;
        height: 100%;
        transition: .15s ease;
    }

    .stat-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,.05);
    }

    .stat-icon {
        width: 46px;
        height: 46px;
        min-width: 46px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
        color: #696cff;
        background: rgba(105,108,255,.10);
        font-size: 23px;
    }

    .stat-value {
        font-size: 23px;
        font-weight: 700;
        line-height: 1.2;
        color: #1a2332;
    }

    .stat-label {
        font-size: 13px;
        font-weight: 600;
        color: #697586;
    }

    /* -------- Filters -------- */
    .rounded-pill-select {
        border-radius: 10px;
    }

    .search-pill {
        border: 1px solid #dce1e8;
        border-radius: 10px;
        overflow: hidden;
    }

    .search-pill .form-control:focus {
        box-shadow: none;
    }

    /* -------- Balance Work Cards -------- */
    .balance-card {
        background: #fff;
        border: 1px solid #e7ebf1;
        border-radius: 14px;
        padding: 18px;
        height: 100%;
        box-shadow: 0 1px 2px rgba(0,0,0,.03);
        transition: .15s ease;
    }

    .balance-card:hover {
        border-color: #d3d9e3;
        box-shadow: 0 6px 16px rgba(0,0,0,.06);
        transform: translateY(-2px);
    }

    .balance-card.delayed-card {
        border-left: 4px solid #ea5455;
    }

    .balance-card-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 8px;
        margin-bottom: 8px;
    }

    .category-eyebrow {
        font-size: 10px;
        font-weight: 700;
        letter-spacing: .05em;
        text-transform: uppercase;
        color: #98a2b3;
    }

    .status-badge {
        display: inline-flex;
        padding: 4px 9px;
        border-radius: 20px;
        font-size: 10px;
        font-weight: 700;
        white-space: nowrap;
    }

    .status-in-progress { color: #696cff; background: rgba(105,108,255,.10); }
    .status-started     { color: #28a745; background: rgba(40,199,111,.10); }
    .status-delayed      { color: #ea5455; background: rgba(234,84,85,.10); }
    .status-not-started  { color: #6c757d; background: rgba(108,117,125,.10); }

    .work-title {
        font-size: 15px;
        line-height: 1.4;
        font-weight: 700;
        color: #1a2332;
        margin: 2px 0 8px;
    }

    .contractor-line {
        display: flex;
        align-items: flex-start;
        gap: 6px;
        color: #68768a;
        font-size: 11.5px;
        line-height: 1.5;
        margin-bottom: 14px;
    }

    .contractor-line i {
        color: #696cff;
        font-size: 14px;
        margin-top: 1px;
    }

    .contractor-line strong {
        color: #303b4d;
    }

    .contractor-line .work-code {
        color: #9aa5b3;
        font-family: monospace;
        font-size: 10.5px;
    }

    .detail-rows {
        display: flex;
        flex-direction: column;
        gap: 7px;
        padding: 10px 0;
        border-top: 1px solid #f0f2f5;
        border-bottom: 1px solid #f0f2f5;
        margin-bottom: 12px;
    }

    .detail-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 12px;
        gap: 10px;
    }

    .detail-row span {
        color: #8a94a6;
        white-space: nowrap;
    }

    .detail-row strong {
        color: #263346;
        font-weight: 700;
        text-align: right;
    }

    .detail-row.balance-row {
        background: rgba(234,84,85,.07);
        border-radius: 8px;
        padding: 7px 9px;
        margin: 2px -3px;
    }

    .detail-row.balance-row span {
        color: #c23c3d;
        font-weight: 600;
    }

    .detail-row.balance-row strong {
        color: #ea5455;
    }

    .detail-row.balance-row strong small {
        color: #c9787a;
        font-weight: 500;
        margin-left: 4px;
    }

    .progress-section {
        margin-bottom: 14px;
        color: #7d8998;
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
    }

    .progress-section strong {
        font-size: 11px;
        color: #39475a;
    }

    .progress {
        height: 6px;
        border-radius: 10px;
        background: #eceef2;
    }

    .progress-bar {
        background: #696cff;
        border-radius: 10px;
    }

    .delayed-card .progress-bar {
        background: #ea5455;
    }

    .delay-box {
        background: rgba(234,84,85,.06);
        border-left: 3px solid #ea5455;
        border-radius: 7px;
        padding: 9px 10px;
        margin-bottom: 12px;
        color: #ea5455;
        font-size: 10.5px;
        line-height: 1.45;
    }

    .update-btn {
        width: 100%;
        border: 0;
        border-radius: 8px;
        padding: 10px;
        font-size: 12.5px;
        font-weight: 600;
        color: #fff;
        background: #22314f;
        transition: .15s ease;
    }

    .update-btn:hover {
        background: #1a2540;
        color: #fff;
    }

    .delayed-card .update-btn {
        background: #ea5455;
    }

    .delayed-card .update-btn:hover {
        background: #d63a3b;
    }

    @media (max-width: 575.98px) {
        .balance-card { padding: 14px; }
        .stat-card { padding: 12px; }
    }

</style>


@stack('page-script')
<script>
document.addEventListener('DOMContentLoaded', function () {

    const projectFilter = document.getElementById('subProjectFilter');
    const contractorFilter = document.getElementById('contractorWOFilter');
    const statusFilter = document.getElementById('statusFilter');
    const searchFilter = document.getElementById('subSearchInput');

    const recordCount = document.getElementById('recordCount');
    const noResults = document.getElementById('noResults');

    function normalize(value) {
        return String(value || '')
            .toLowerCase()
            .trim()
            .replace(/\s+/g, ' ');
    }

    function filterBalanceWork() {

        const projectValue = normalize(projectFilter ? projectFilter.value : '');
        const contractorValue = normalize(contractorFilter ? contractorFilter.value : '');
        const statusValue = normalize(statusFilter ? statusFilter.value : '');
        const searchValue = normalize(searchFilter ? searchFilter.value : '');

        const cards = document.querySelectorAll('.balance-item');
        let visibleCount = 0;

        cards.forEach(function (card) {

            const cardProject = normalize(card.dataset.project);
            const cardContractor = normalize(card.dataset.contractor);
            const cardStatus = normalize(card.dataset.status);
            const cardText = normalize(card.innerText || card.textContent);

            const projectMatch =
                !projectValue || projectValue === 'all' || cardProject === projectValue;

            const contractorMatch =
                !contractorValue || contractorValue === 'all' || cardContractor === contractorValue;

            const statusMatch =
                !statusValue || statusValue === 'all' || cardStatus === statusValue;

            const searchMatch =
                !searchValue || cardText.includes(searchValue);

            const show =
                projectMatch && contractorMatch && statusMatch && searchMatch;

            const column = card.closest('.balance-col') || card.closest('[class*="col-"]');

            if (show) {
                if (column) { column.style.display = ''; } else { card.style.display = ''; }
                visibleCount++;
            } else {
                if (column) { column.style.display = 'none'; } else { card.style.display = 'none'; }
            }

        });

        if (recordCount) {
            recordCount.textContent = visibleCount + (visibleCount === 1 ? ' Record' : ' Records');
        }

        if (noResults) {
            noResults.classList.toggle('d-none', visibleCount !== 0);
        }
    }

    if (projectFilter) projectFilter.addEventListener('change', filterBalanceWork);
    if (contractorFilter) contractorFilter.addEventListener('change', filterBalanceWork);
    if (statusFilter) statusFilter.addEventListener('change', filterBalanceWork);

    if (searchFilter) {
        searchFilter.addEventListener('input', filterBalanceWork);
        searchFilter.addEventListener('keyup', function (event) {
            if (event.key === 'Enter') filterBalanceWork();
        });
    }

    filterBalanceWork();

});
</script>
