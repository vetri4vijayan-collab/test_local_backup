@extends('layouts.layoutMaster')

@section('title', 'Planning & Quantity Surveying (QS) Engine')

@section('content')

<div class="container-fluid">


    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-lg-row
                        justify-content-between
                        align-items-lg-center gap-3">

                <div>
                    <h4 class="mb-1 fw-bold">
                        Planning & Quantity Surveying (QS) Engine
                    </h4>

                    <p class="text-muted mb-0">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>
                </div>

                <div class="d-flex flex-wrap gap-2">
                    
                  <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">

                            <i class="mdi mdi-chevron-left"></i>

                        </button>

                        <div class="settings-tabs-scroller">

                            <div class="settings-tabs-track"
                                 id="qsTabsTrack">

                                <a href="{{ route('planning-qs.schedule') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.schedule') ? 'active' : '' }}">
                                    Monthly Program
                                </a>

                                <a href="{{ route('planning-qs.schedule.balance') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.schedule.balance') ? 'active' : '' }}">
                                    Balance Work Programme
                                </a>
                       </div>

                        </div>

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">

                            <i class="mdi mdi-chevron-right"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body p-3">

            <div class="row g-3 align-items-end">

                {{-- All Projects --}}
                <div class="col-12 col-md-3">

                    <label class="form-label fw-semibold small">
                        Project
                    </label>

                    <select id="projectFilter"
                            class="form-select form-select-sm">

                        <option value="">All Projects</option>

                        <option value="PRJ-001">
                            Chennai Metro Phase 2 - Corridor 4
                        </option>

                        <option value="PRJ-002">
                            Adyar Block B
                        </option>

                    </select>

                </div>


                {{-- All Sub-Contractors --}}
                <div class="col-12 col-md-3">

                    <label class="form-label fw-semibold small">
                        Sub-Contractor
                    </label>

                    <select id="contractorFilter"
                            class="form-select form-select-sm">

                        <option value="">All Sub-Contractors</option>

                        <option value="Apex Structural Sub-Contractors">
                            Apex Structural Sub-Contractors
                        </option>

                        <option value="Star Bar-Bending Works">
                            Star Bar-Bending Works
                        </option>

                        <option value="Vanguard Piling Rigs">
                            Vanguard Piling Rigs
                        </option>

                    </select>

                </div>


                {{-- All Status --}}
                <div class="col-12 col-md-3">

                    <label class="form-label fw-semibold small">
                        Status
                    </label>

                    <select id="statusFilter"
                            class="form-select form-select-sm">

                        <option value="">All Status</option>
                        <option value="started">Started</option>
                        <option value="delayed">Delayed</option>
                        <option value="not-started">Not Started</option>

                    </select>

                </div>


                {{-- Search --}}
                <div class="col-12 col-md-3">

                    <label class="form-label fw-semibold small">
                        Search
                    </label>

                    <div class="input-group input-group-sm">

                        <span class="input-group-text bg-white">
                            <i class="mdi mdi-magnify"></i>
                        </span>

                        <input type="text"
                               id="searchFilter"
                               class="form-control"
                               placeholder="Search WO, BOQ, item...">

                    </div>

                </div>

            </div>

        </div>

    </div>



    <div class="card shadow-sm border-0 rounded-3">

        <div class="card-header bg-white border-bottom py-3">

            <div class="d-flex justify-content-between
                        align-items-center flex-wrap gap-2">

                <div>
                    <h6 class="mb-0 fw-bold">
                        Monthly Target Items
                    </h6>

                    <small class="text-muted">
                        Work Order / BOQ wise monthly execution tracking
                    </small>
                </div>

                <span class="badge bg-label-primary"
                      id="recordCount">
                    6 Records
                </span>

            </div>

        </div>


        <div class="table-responsive">

            <table class="table table-hover align-middle mb-0"
                   id="scheduleTable">

                <thead class="table-light">

                    <tr>

                        <th class="text-nowrap">
                            Sub-Contractor
                        </th>

                        <th class="text-nowrap">
                            WO / BOQ
                        </th>

                        <th style="min-width: 280px;">
                            Structure & Item
                        </th>

                        <th class="text-nowrap">
                            Date of Assignment
                        </th>

                        <th class="text-nowrap">
                            Date of Completion
                        </th>

                        <th style="min-width: 170px;">
                            Scope / Executed Qty
                        </th>

                        <th class="text-nowrap">
                            Status
                        </th>

                        <th style="min-width: 320px;">
                            Progress Remarks & Delay Reasons
                        </th>

                        <th class="text-center">
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>



                    <tr class="schedule-row"
                        data-project="PRJ-001"
                        data-contractor="Apex Structural Sub-Contractors"
                        data-status="started"
                        data-search="SCWO/APEX/088 PRJ-001 Substructure Piers Pile Cap Concrete">

                        <td>
                            <div class="fw-semibold text-dark">
                                Apex Structural
                            </div>

                            <small class="text-muted">
                                Sub-Contractors
                            </small>
                        </td>

                        <td>
                            <span class="fw-semibold">
                                SCWO/APEX/088
                            </span>

                            <br>

                            <small class="text-muted">
                                PRJ-001
                            </small>
                        </td>

                        <td>

                            <div class="fw-semibold">
                                Substructure & Piers
                            </div>

                            <div class="text-muted small">
                                Pile Cap Concrete
                            </div>

                            <span class="badge bg-label-secondary mt-1">
                                Unit: CuM
                            </span>

                        </td>

                        <td class="text-nowrap">
                            15 Jul 2026
                        </td>

                        <td class="text-nowrap">
                            15 Aug 2026
                        </td>

                        <td>

                            <div class="d-flex justify-content-between
                                        small mb-1">

                                <span>420 / 850</span>

                                <span class="fw-semibold">
                                    49.4%
                                </span>

                            </div>

                            <div class="progress"
                                 style="height: 6px;">

                                <div class="progress-bar"
                                     style="width:49.4%;">
                                </div>

                            </div>

                        </td>

                        <td>
                            <span class="badge bg-label-info">
                                Started
                            </span>
                        </td>

                        <td>

                            <div class="small fw-semibold">
                                Formwork for Pier Caps P42-P48.
                            </div>

                        </td>

                        <td class="text-center">

                            <button type="button"
                                    class="btn btn-sm btn-icon btn-outline-primary"
                                    title="Update">

                                <i class="mdi mdi-update"></i>

                            </button>

                        </td>

                    </tr>



                    <tr class="schedule-row"
                        data-project="PRJ-001"
                        data-contractor="Apex Structural Sub-Contractors"
                        data-status="started"
                        data-search="SCWO/APEX/088 PRJ-001 Substructure Piers Pier Pedestal Fabrication">

                        <td>
                            <div class="fw-semibold text-dark">
                                Apex Structural
                            </div>

                            <small class="text-muted">
                                Sub-Contractors
                            </small>
                        </td>

                        <td>
                            <span class="fw-semibold">
                                SCWO/APEX/088
                            </span>

                            <br>

                            <small class="text-muted">
                                PRJ-001
                            </small>
                        </td>

                        <td>

                            <div class="fw-semibold">
                                Substructure & Piers
                            </div>

                            <div class="text-muted small">
                                Pier Pedestal Fabrication
                            </div>

                            <span class="badge bg-label-secondary mt-1">
                                Unit: MT
                            </span>

                        </td>

                        <td class="text-nowrap">
                            18 Jul 2026
                        </td>

                        <td class="text-nowrap">
                            20 Aug 2026
                        </td>

                        <td>

                            <div class="d-flex justify-content-between
                                        small mb-1">

                                <span>30 / 95</span>

                                <span class="fw-semibold">
                                    31.6%
                                </span>

                            </div>

                            <div class="progress"
                                 style="height: 6px;">

                                <div class="progress-bar"
                                     style="width:31.6%;">
                                </div>

                            </div>

                        </td>

                        <td>
                            <span class="badge bg-label-info">
                                Started
                            </span>
                        </td>

                        <td>

                            <div class="small fw-semibold">
                                Template alignment in progress.
                            </div>

                        </td>

                        <td class="text-center">

                            <button type="button"
                                    class="btn btn-sm btn-icon btn-outline-primary"
                                    title="Update">

                                <i class="mdi mdi-update"></i>

                            </button>

                        </td>

                    </tr>

                    <tr class="schedule-row"
                        data-project="PRJ-001"
                        data-contractor="Star Bar-Bending Works"
                        data-status="not-started"
                        data-search="SCWO/STAR/042 PRJ-001 Substructure Piers Pier Pedestal Fabrication">

                        <td>
                            <div class="fw-semibold text-dark">
                                Star Bar-Bending
                            </div>

                            <small class="text-muted">
                                Works
                            </small>
                        </td>

                        <td>
                            <span class="fw-semibold">
                                SCWO/STAR/042
                            </span>

                            <br>

                            <small class="text-muted">
                                PRJ-001
                            </small>
                        </td>

                        <td>

                            <div class="fw-semibold">
                                Substructure & Piers
                            </div>

                            <div class="text-muted small">
                                Pier Pedestal Fabrication
                            </div>

                            <span class="badge bg-label-secondary mt-1">
                                Unit: MT
                            </span>

                        </td>

                        <td class="text-nowrap">
                            01 Aug 2026
                        </td>

                        <td class="text-nowrap">
                            25 Aug 2026
                        </td>

                        <td>

                            <div class="d-flex justify-content-between
                                        small mb-1">

                                <span>0 / 95</span>

                                <span class="fw-semibold">
                                    0%
                                </span>

                            </div>

                            <div class="progress"
                                 style="height: 6px;">

                                <div class="progress-bar"
                                     style="width:0%;">
                                </div>

                            </div>

                        </td>

                        <td>
                            <span class="badge bg-label-secondary">
                                Not Started
                            </span>
                        </td>

                        <td>

                            <div class="small fw-semibold">
                                Pier pedestal templates queue.
                            </div>

                        </td>

                        <td class="text-center">

                            <button type="button"
                                    class="btn btn-sm btn-icon btn-outline-primary"
                                    title="Update">

                                <i class="mdi mdi-update"></i>

                            </button>

                        </td>

                    </tr>



                    <tr class="schedule-row"
                        data-project="PRJ-002"
                        data-contractor="Vanguard Piling Rigs"
                        data-status="delayed"
                        data-search="SCWO/VANG/015 PRJ-002 Adyar Block B Structure Core Anchorage Installation Port customs clearance imported anchorage castings">

                        <td>
                            <div class="fw-semibold text-dark">
                                Vanguard Piling
                            </div>

                            <small class="text-muted">
                                Rigs
                            </small>
                        </td>

                        <td>
                            <span class="fw-semibold">
                                SCWO/VANG/015
                            </span>

                            <br>

                            <small class="text-muted">
                                PRJ-002
                            </small>
                        </td>

                        <td>

                            <div class="fw-semibold">
                                Adyar Block B Structure Core
                            </div>

                            <div class="text-muted small">
                                Anchorage Installation
                            </div>

                            <span class="badge bg-label-secondary mt-1">
                                Unit: Nos.
                            </span>

                        </td>

                        <td class="text-nowrap">
                            18 Jul 2026
                        </td>

                        <td class="text-nowrap">
                            10 Aug 2026
                        </td>

                        <td>

                            <div class="d-flex justify-content-between
                                        small mb-1">

                                <span>45 / 150</span>

                                <span class="fw-semibold">
                                    30%
                                </span>

                            </div>

                            <div class="progress"
                                 style="height: 6px;">

                                <div class="progress-bar bg-danger"
                                     style="width:30%;">
                                </div>

                            </div>

                        </td>

                        <td>
                            <span class="badge bg-label-danger">
                                Delayed
                            </span>
                        </td>

                        <td>

                            <div class="small fw-semibold mb-2">
                                Anchorage block sets installation.
                            </div>

                            <div class="delay-reason">

                                <div class="d-flex align-items-center gap-1
                                            text-danger fw-semibold small">

                                    <i class="mdi mdi-alert-circle-outline"></i>
                                    Reason for Delay

                                </div>

                                <div class="small text-danger mt-1">
                                    Port customs clearance hold for imported
                                    anchorage castings.
                                </div>

                            </div>

                        </td>

                        <td class="text-center">

                            <button type="button"
                                    class="btn btn-sm btn-icon btn-outline-primary"
                                    title="Update">

                                <i class="mdi mdi-update"></i>

                            </button>

                        </td>

                    </tr>



                    <tr class="schedule-row"
                        data-project="PRJ-002"
                        data-contractor="Vanguard Piling Rigs"
                        data-status="not-started"
                        data-search="SCWO/VANG/015 PRJ-002 Adyar Block B Structure Core Concrete Core Walls">

                        <td>
                            <div class="fw-semibold text-dark">
                                Vanguard Piling
                            </div>

                            <small class="text-muted">
                                Rigs
                            </small>
                        </td>

                        <td>
                            <span class="fw-semibold">
                                SCWO/VANG/015
                            </span>

                            <br>

                            <small class="text-muted">
                                PRJ-002
                            </small>
                        </td>

                        <td>

                            <div class="fw-semibold">
                                Adyar Block B Structure Core
                            </div>

                            <div class="text-muted small">
                                Concrete Core Walls
                            </div>

                            <span class="badge bg-label-secondary mt-1">
                                Unit: CuM
                            </span>

                        </td>

                        <td class="text-nowrap">
                            05 Aug 2026
                        </td>

                        <td class="text-nowrap">
                            15 Sep 2026
                        </td>

                        <td>

                            <div class="d-flex justify-content-between
                                        small mb-1">

                                <span>0 / 1,200</span>

                                <span class="fw-semibold">
                                    0%
                                </span>

                            </div>

                            <div class="progress"
                                 style="height: 6px;">

                                <div class="progress-bar"
                                     style="width:0%;">
                                </div>

                            </div>

                        </td>

                        <td>
                            <span class="badge bg-label-secondary">
                                Not Started
                            </span>
                        </td>

                        <td>

                            <div class="small fw-semibold">
                                Lift core wall casting staging.
                            </div>

                        </td>

                        <td class="text-center">

                            <button type="button"
                                    class="btn btn-sm btn-icon btn-outline-primary"
                                    title="Update">

                                <i class="mdi mdi-update"></i>

                            </button>

                        </td>

                    </tr>


                </tbody>

            </table>

        </div>


        {{-- No Results --}}
        <div id="noResults"
             class="text-center py-5 d-none">

            <div class="mb-2">
                <i class="mdi mdi-file-search-outline fs-1 text-muted"></i>
            </div>

            <h6 class="fw-semibold">
                No records found
            </h6>

            <p class="text-muted mb-0">
                Try changing your filters or search keyword.
            </p>

        </div>

    </div>

</div>


<style>

    
.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}


    .program-icon {
        width: 44px;
        height: 44px;
        min-width: 44px;

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: 10px;

        background: rgba(105, 108, 255, 0.10);
        color: #696cff;

        font-size: 22px;
    }


    #scheduleTable th {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .02em;
        white-space: nowrap;
    }


    #scheduleTable td {
        font-size: 13px;
        vertical-align: middle;
    }


    #scheduleTable tbody tr {
        transition: background-color .15s ease;
    }


    #scheduleTable tbody tr:hover {
        background-color: rgba(105, 108, 255, .035);
    }


    .progress {
        background-color: #eceef1;
        border-radius: 10px;
    }


    .progress-bar {
        border-radius: 10px;
    }


    .delay-reason {
        padding: 8px 10px;
        border-radius: 6px;

        background: rgba(234, 84, 85, .07);
        border-left: 3px solid #ea5455;
    }


    .btn-icon {
        width: 32px;
        height: 32px;

        padding: 0;

        display: inline-flex;
        align-items: center;
        justify-content: center;
    }


    .badge {
        font-weight: 600;
    }


    @media (max-width: 768px) {

        #scheduleTable {
            min-width: 1500px;
        }

    }

</style>



<script>

document.addEventListener('DOMContentLoaded', function () {

    const projectFilter =
        document.getElementById('projectFilter');

    const contractorFilter =
        document.getElementById('contractorFilter');

    const statusFilter =
        document.getElementById('statusFilter');

    const searchFilter =
        document.getElementById('searchFilter');

    const rows =
        document.querySelectorAll('.schedule-row');

    const recordCount =
        document.getElementById('recordCount');

    const noResults =
        document.getElementById('noResults');


    function filterTable() {

        const project =
            projectFilter.value.toLowerCase().trim();

        const contractor =
            contractorFilter.value.toLowerCase().trim();

        const status =
            statusFilter.value.toLowerCase().trim();

        const search =
            searchFilter.value.toLowerCase().trim();


        let visibleCount = 0;


        rows.forEach(function (row) {

            const rowProject =
                (row.dataset.project || '').toLowerCase();

            const rowContractor =
                (row.dataset.contractor || '').toLowerCase();

            const rowStatus =
                (row.dataset.status || '').toLowerCase();

            const rowSearch =
                (row.dataset.search || '').toLowerCase();


            const projectMatch =
                !project ||
                rowProject === project;


            const contractorMatch =
                !contractor ||
                rowContractor === contractor;


            const statusMatch =
                !status ||
                rowStatus === status;


            const searchMatch =
                !search ||
                rowSearch.includes(search);


            if (
                projectMatch &&
                contractorMatch &&
                statusMatch &&
                searchMatch
            ) {

                row.style.display = '';

                visibleCount++;

            } else {

                row.style.display = 'none';

            }

        });


        recordCount.textContent =
            visibleCount + (visibleCount === 1 ? ' Record' : ' Records');


        if (visibleCount === 0) {

            noResults.classList.remove('d-none');

        } else {

            noResults.classList.add('d-none');

        }

    }


    projectFilter.addEventListener(
        'change',
        filterTable
    );


    contractorFilter.addEventListener(
        'change',
        filterTable
    );


    statusFilter.addEventListener(
        'change',
        filterTable
    );


    searchFilter.addEventListener(
        'input',
        filterTable
    );

});

</script>

@endsection
