@extends('layouts.layoutMaster')

@section('title', 'Planned Vs Achieved')

@section('content')

<div class="container-fluid">

    {{-- Page Header --}}
    <div class="card mb-4">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                <div>
                    <h4 class="fw-bold mb-1">
                        Planning & QS Daily Progress Reports
                    </h4>

                    <p class="text-muted mb-0">
                        Cumulative Planned % vs Achieved % and Schedule Performance Index (SPI)
                    </p>
                </div>

                 <div class="d-flex align-items-center gap-2 flex-wrap">

                    <div class="settings-tabs-wrapper">

                        <div class="d-flex align-items-center gap-2">

                            <button type="button"
                                    class="settings-tab-scroll-btn"
                                    id="plannerTabScrollLeft"
                                    aria-label="Scroll tabs left">
                                <i class="mdi mdi-chevron-left"></i>
                            </button>

                            <div class="settings-tabs-scroller">
                                <div class="settings-tabs-track" id="plannerTabsTrack">

                                    <a href="{{ route('planning-qs.management') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.management') ? 'active' : '' }}">
                                        Management Planner
                                    </a>

                                    <a href="{{ route('planning-qs.daily') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.daily') ? 'active' : '' }}">
                                        Daily Progress Report
                                    </a>

                                    <a href="{{ route('planning-qs.achieved') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.achieved') ? 'active' : '' }}">
                                        Planned Vs Achieved
                                    </a>

                                </div>
                            </div>

                            <button type="button"
                                    class="settings-tab-scroll-btn"
                                    id="plannerTabScrollRight"
                                    aria-label="Scroll tabs right">
                                <i class="mdi mdi-chevron-right"></i>
                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    </div>

{{-- S-Curve Progress Variance Summary --}}
<div class="card mb-4">

    <div class="card-body">

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

            {{-- Title --}}
            <div>
              <h6 class="mb-1" style="color: #000000;">S-Curve Progress Variance Analysis</h6>

                <small class="text-dark">
                    Cumulative Planned % vs Achieved % and Schedule Performance Index (SPI)
                </small>
            </div>


            {{-- SPI / CPI --}}
            <div class="d-flex gap-2 flex-wrap">

                {{-- SPI --}}
                <div class="btn btn-outline-primary d-flex align-items-center gap-2 px-3 py-2 bg-success-subtle border border-success-subtle">

                    <span class="fw-semibold text-success bg-success-subtle small">
                        SPI:
                    </span>

                    <span class="fw-bold text-success bg-success-subtle small">
                        0.98
                    </span>

                    <span class="badge bg-label-success rounded-pill">
                        (On Schedule)
                    </span>

                </div>


                {{-- CPI --}}
                <div class="btn btn-outline-success d-flex align-items-center gap-2 px-3 py-2 bg-primary-subtle border border-primary-subtle">

                    <span class="fw-semibold text-primary bg-primary-subtle small">
                        CPI:
                    </span>

                    <span class="fw-bold text-primary bg-primary-subtle small">
                        1.01
                    </span>

                    <span class="badge bg-label-primary rounded-pill text-primary bg-primary-subtle small">
                        (Under Budget)
                    </span>

                </div>

            </div>

        </div>

    </div>

</div>



<div class="card mb-4">

    <div class="card-body p-0">
<div class="table-responsive">

    <table class="table table-hover align-middle mb-0">

        <thead class="table-light">
            <tr>
                <th>Month</th>
                <th>Planned Cumulative %</th>
                <th>Achieved Cumulative %</th>
                <th>Variance %</th>
                <th>SPI</th>
                <th>CPI</th>
            </tr>
        </thead>

        <tbody>

            <tr>
                <td>Jan 2026</td>

                {{-- Planned --}}
                <td>
                    <span class="text-primary fw-semibold">
                        5%
                    </span>
                </td>

                {{-- Achieved --}}
                <td>
                    <span class="text-success fw-semibold">
                        5%
                    </span>
                </td>

                <td>
                    <span class="text-success fw-semibold">
                        +0%
                    </span>
                </td>

                <td>1.00</td>
                <td>1.02</td>
            </tr>


            <tr>
                <td>Feb 2026</td>

                <td>
                    <span class="text-primary fw-semibold">
                        15%
                    </span>
                </td>

                <td>
                    <span class="text-success fw-semibold">
                        14.5%
                    </span>
                </td>

                <td>
                    <span class="text-danger fw-semibold">
                        -0.5%
                    </span>
                </td>

                <td>0.97</td>
                <td>1.01</td>
            </tr>


            <tr>
                <td>Mar 2026</td>

                <td>
                    <span class="text-primary fw-semibold">
                        28%
                    </span>
                </td>

                <td>
                    <span class="text-success fw-semibold">
                        29%
                    </span>
                </td>

                <td>
                    <span class="text-success fw-semibold">
                        +1%
                    </span>
                </td>

                <td>1.03</td>
                <td>1.04</td>
            </tr>


            <tr>
                <td>Apr 2026</td>

                <td>
                    <span class="text-primary fw-semibold">
                        42%
                    </span>
                </td>

                <td>
                    <span class="text-success fw-semibold">
                        41.2%
                    </span>
                </td>

                <td>
                    <span class="text-danger fw-semibold">
                        -0.8%
                    </span>
                </td>

                <td>0.98</td>
                <td>0.99</td>
            </tr>


            <tr>
                <td>May 2026</td>

                <td>
                    <span class="text-primary fw-semibold">
                        58%
                    </span>
                </td>

                <td>
                    <span class="text-success fw-semibold">
                        57.5%
                    </span>
                </td>

                <td>
                    <span class="text-danger fw-semibold">
                        -0.5%
                    </span>
                </td>

                <td>0.99</td>
                <td>1.02</td>
            </tr>


            <tr>
                <td>Jun 2026</td>

                <td>
                    <span class="text-primary fw-semibold">
                        72%
                    </span>
                </td>

                <td>
                    <span class="text-success fw-semibold">
                        70.8%
                    </span>
                </td>

                <td>
                    <span class="text-danger fw-semibold">
                        -1.2%
                    </span>
                </td>

                <td>0.98</td>
                <td>1.00</td>
            </tr>


            <tr>
                <td>Jul 2026</td>

                <td>
                    <span class="text-primary fw-semibold">
                        82%
                    </span>
                </td>

                <td>
                    <span class="text-success fw-semibold">
                        80.5%
                    </span>
                </td>

                <td>
                    <span class="text-danger fw-semibold">
                        -1.5%
                    </span>
                </td>

                <td>0.98</td>
                <td>1.01</td>
            </tr>

        </tbody>

    </table>

</div>
    </div>
</div>

</div>{{-- /container-fluid --}}

@endsection


@stack('page-style')

<style>


.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-wrapper .d-flex {
    gap: 10px !important;
}

/* ---- Scroll buttons (chevron arrows) ---- */
.settings-tab-scroll-btn {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
    transition: all 0.15s ease;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
    border-color: #16659E;
}

.settings-tab-scroll-btn i {
    font-size: 18px;
    line-height: 1;
}

/* ---- Scroller + track ---- */
.settings-tabs-scroller {
    overflow: hidden;
    max-width: 100%;
    min-width: 0;
}

.settings-tabs-track {
    display: flex;
    align-items: center;
    gap: 10px;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

/* ---- Tab pills ---- */
a.settings-tab {
    white-space: nowrap;
    padding: 10px 22px;
    border-radius: 50px;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    flex-shrink: 0;
}

a.settings-tab:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

a.settings-tab.active {
    background: #16659E;
    color: #fff;
    box-shadow: 0 2px 5px rgba(22, 101, 158, 0.20);
}

:root {
    --bs-primary: #16659E !important;
    --bs-primary-rgb: 22, 101, 158 !important;
}

.btn-primary {
    --bs-btn-color: #fff !important;
    --bs-btn-bg: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #124f7c !important;
    --bs-btn-hover-border-color: #124f7c !important;
    --bs-btn-active-color: #fff !important;
    --bs-btn-active-bg: #0f4265 !important;
    --bs-btn-active-border-color: #0f4265 !important;
    background-color: #16659E !important;
    border-color: #16659E !important;
    color: #fff !important;
}

.bg-primary {
    background-color: #16659E !important;
}

.text-primary {
    color: #16659E !important;
}

.btn-outline-primary {
    --bs-btn-color: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #16659E !important;
    --bs-btn-hover-border-color: #16659E !important;
    color: #16659E !important;
    border-color: #16659E !important;
}

.bg-primary-subtle {
    background-color: #e8eef5 !important;
}

    .card-body > .d-flex {
        min-height: 55px;
    }

    .card-body .btn {
        white-space: nowrap;
    }

    /* KPI Cards */
    .variance-kpi-card {
        border: 1px solid #e7e7e7;
        border-radius: 12px;
        padding: 20px;
        background: #fff;
        height: 100%;
        transition: all 0.2s ease;
    }

    .variance-kpi-card:hover {
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.08);
        transform: translateY(-2px);
    }

    .kpi-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
    }

    .spi-card {
        border-left: 4px solid #696cff;
    }

    .cpi-card {
        border-left: 4px solid #71dd37;
    }

    @media (max-width: 992px) {

        .card-body > .d-flex {
            align-items: flex-start !important;
        }

        .card-body > .d-flex > div:last-child {
            width: 100%;
        }

    }

</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Planner Tabs Scroll (chevron arrows) ---------- */
    const plannerTabsTrack = document.getElementById('plannerTabsTrack');
    const plannerLeftBtn   = document.getElementById('plannerTabScrollLeft');
    const plannerRightBtn  = document.getElementById('plannerTabScrollRight');

    if (plannerLeftBtn && plannerTabsTrack) {
        plannerLeftBtn.addEventListener('click', function () {
            plannerTabsTrack.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (plannerRightBtn && plannerTabsTrack) {
        plannerRightBtn.addEventListener('click', function () {
            plannerTabsTrack.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

});
</script>
