@extends('layouts.layoutMaster')

@section('title', 'Management Planner')

@section('content')

<div class="container-fluid">

    <div class="card mb-4">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                <div>
                    <h4 class="fw-bold mb-1">
                        Planning & Quantity Surveying (QS) Engine
                    </h4>

                    <p class="text-muted mb-0">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>
                </div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <div class="settings-tabs-wrapper">

                        <div class="d-flex align-items-center gap-2">

                            <button type="button"
                                    class="settings-tab-scroll-btn"
                                    id="plannerTabScrollLeft"
                                    aria-label="Scroll tabs left">
                                <i class="mdi mdi-chevron-left"></i>
                            </button>

                            <div class="settings-tabs-scroller">
                                <div class="settings-tabs-track" id="plannerTabsTrack">

                                    <a href="{{ route('planning-qs.management') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.management') ? 'active' : '' }}">
                                        Management Planner
                                    </a>

                                    <a href="{{ route('planning-qs.daily') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.daily') ? 'active' : '' }}">
                                        Daily Progress Report
                                    </a>

                                    <a href="{{ route('planning-qs.achieved') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.achieved') ? 'active' : '' }}">
                                        Planned Vs Achieved
                                    </a>

                                </div>
                            </div>

                            <button type="button"
                                    class="settings-tab-scroll-btn"
                                    id="plannerTabScrollRight"
                                    aria-label="Scroll tabs right">
                                <i class="mdi mdi-chevron-right"></i>
                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    </div>


    <div class="card">

        <div class="card-body">


            <!-- WBS-1.1 -->
            <div class="border rounded-3 p-3 mb-3 wbs-item-card">

                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">

                    <div class="d-flex align-items-center gap-2 flex-wrap">

                        <span class="fw-semibold text-primary">
                            WBS-1.1
                        </span>

                        <span class="fw-semibold">
                            Site Preparation & Land Demarcation
                        </span>

                        <span class="badge bg-label-danger rounded-pill px-3 py-2">
                            CPM Critical Path
                        </span>

                    </div>

                    <span class="badge bg-label-success rounded-pill px-3 py-2">
                        Completed
                    </span>

                </div>


                <div class="progress mb-2" style="height: 8px;">

                    <div
                        class="progress-bar bg-success"
                        role="progressbar"
                        style="width: 100%"
                        aria-valuenow="100"
                        aria-valuemin="0"
                        aria-valuemax="100">
                    </div>

                </div>


                <div class="d-flex justify-content-between flex-wrap gap-2 small">

                    <div class="text-muted">
                        Start:
                        <span class="text-primary">
                            2026-01-10
                        </span>

                        &rarr;

                        End:
                        <span class="text-primary">
                            2026-02-15
                        </span>
                    </div>

                    <div class="text-muted">
                        WBS Weightage:
                        <span class="text-primary fw-semibold">
                            5%
                        </span>
                    </div>

                    <div class="text-muted">
                        Progress:
                        <span class="fw-semibold text-success">
                            100%
                        </span>
                    </div>

                </div>

            </div>


            <!-- WBS-1.2 -->
            <div class="border rounded-3 p-3 mb-3 wbs-item-card">

                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">

                    <div class="d-flex align-items-center gap-2 flex-wrap">

                        <span class="fw-semibold text-primary">
                            WBS-1.2
                        </span>

                        <span class="fw-semibold">
                            Deep Foundation Piling & Soil Testing
                        </span>

                        <span class="badge bg-label-danger rounded-pill px-3 py-2">
                            CPM Critical Path
                        </span>

                    </div>

                    <span class="badge bg-label-success rounded-pill px-3 py-2">
                        Completed
                    </span>

                </div>


                <div class="progress mb-2" style="height: 8px;">

                    <div
                        class="progress-bar bg-success"
                        role="progressbar"
                        style="width: 100%"
                        aria-valuenow="100"
                        aria-valuemin="0"
                        aria-valuemax="100">
                    </div>

                </div>


                <div class="d-flex justify-content-between flex-wrap gap-2 small">

                    <div class="text-muted">
                        Start:
                        <span class="text-primary">
                            2026-02-16
                        </span>

                        &rarr;

                        End:
                        <span class="text-primary">
                            2026-05-30
                        </span>
                    </div>

                    <div class="text-muted">
                        WBS Weightage:
                        <span class="text-primary fw-semibold">
                            20%
                        </span>
                    </div>

                    <div class="text-muted">
                        Progress:
                        <span class="fw-semibold text-success">
                            100%
                        </span>
                    </div>

                </div>

            </div>


            <!-- WBS-2.1 -->
            <div class="border rounded-3 p-3 mb-3 wbs-item-card">

                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">

                    <div class="d-flex align-items-center gap-2 flex-wrap">

                        <span class="fw-semibold text-primary">
                            WBS-2.1
                        </span>

                        <span class="fw-semibold">
                            Pier Structure & Pier Cap Concreting
                        </span>

                        <span class="badge bg-label-danger rounded-pill px-3 py-2">
                            CPM Critical Path
                        </span>

                    </div>

                    <span class="badge bg-label-info rounded-pill px-3 py-2">
                        In Progress
                    </span>

                </div>


                <div class="progress mb-2" style="height: 8px;">

                    <div
                        class="progress-bar bg-primary"
                        role="progressbar"
                        style="width: 78%"
                        aria-valuenow="78"
                        aria-valuemin="0"
                        aria-valuemax="100">
                    </div>

                </div>


                <div class="d-flex justify-content-between flex-wrap gap-2 small">

                    <div class="text-muted">
                        Start:
                        <span class="text-primary">
                            2026-06-01
                        </span>

                        &rarr;

                        End:
                        <span class="text-primary">
                            2026-10-15
                        </span>
                    </div>

                    <div class="text-muted">
                        WBS Weightage:
                        <span class="text-primary fw-semibold">
                            30%
                        </span>
                    </div>

                    <div class="text-muted">
                        Progress:
                        <span class="fw-semibold text-primary">
                            78%
                        </span>
                    </div>

                </div>

            </div>


            <!-- WBS-2.2 -->
            <div class="border rounded-3 p-3 mb-3 wbs-item-card">

                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">

                    <div class="d-flex align-items-center gap-2 flex-wrap">

                        <span class="fw-semibold text-primary">
                            WBS-2.2
                        </span>

                        <span class="fw-semibold">
                            Prestressed Girder Erection & Deck Launching
                        </span>

                        <span class="badge bg-label-danger rounded-pill px-3 py-2">
                            CPM Critical Path
                        </span>

                    </div>

                    <span class="badge bg-label-info rounded-pill px-3 py-2">
                        In Progress
                    </span>

                </div>


                <div class="progress mb-2" style="height: 8px;">

                    <div
                        class="progress-bar bg-primary"
                        role="progressbar"
                        style="width: 15%"
                        aria-valuenow="15"
                        aria-valuemin="0"
                        aria-valuemax="100">
                    </div>

                </div>


                <div class="d-flex justify-content-between flex-wrap gap-2 small">

                    <div class="text-muted">
                        Start:
                        <span class="text-primary">
                            2026-10-16
                        </span>

                        &rarr;

                        End:
                        <span class="text-primary">
                            2027-02-28
                        </span>
                    </div>

                    <div class="text-muted">
                        WBS Weightage:
                        <span class="text-primary fw-semibold">
                            25%
                        </span>
                    </div>

                    <div class="text-muted">
                        Progress:
                        <span class="fw-semibold text-primary">
                            15%
                        </span>
                    </div>

                </div>

            </div>


            <!-- WBS-3.1 -->
            <div class="border rounded-3 p-3 mb-3 wbs-item-card">

                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">

                    <div class="d-flex align-items-center gap-2 flex-wrap">

                        <span class="fw-semibold text-primary">
                            WBS-3.1
                        </span>

                        <span class="fw-semibold">
                            Track Bed Layout & MEP Electrical Grid
                        </span>

                        <span class="badge bg-label-secondary rounded-pill px-3 py-2">
                            Normal
                        </span>

                    </div>

                    <span class="badge bg-label-secondary rounded-pill px-3 py-2">
                        Planning
                    </span>

                </div>


                <div class="progress mb-2" style="height: 8px;">

                    <div
                        class="progress-bar bg-secondary"
                        role="progressbar"
                        style="width: 0%"
                        aria-valuenow="0"
                        aria-valuemin="0"
                        aria-valuemax="100">
                    </div>

                </div>


                <div class="d-flex justify-content-between flex-wrap gap-2 small">

                    <div class="text-muted">
                        Start:
                        <span class="text-primary">
                            2027-03-01
                        </span>

                        &rarr;

                        End:
                        <span class="text-primary">
                            2027-06-30
                        </span>
                    </div>

                    <div class="text-muted">
                        WBS Weightage:
                        <span class="text-primary fw-semibold">
                            20%
                        </span>
                    </div>

                    <div class="text-muted">
                        Progress:
                        <span class="fw-semibold text-primary">
                            0%
                        </span>
                    </div>

                </div>

            </div>


        </div>

    </div>

</div>


<style>


.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-wrapper .d-flex {
    gap: 10px !important;
}

/* ---- Scroll buttons (chevron arrows) ---- */
.settings-tab-scroll-btn {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
    transition: all 0.15s ease;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
    border-color: #16659E;
}

.settings-tab-scroll-btn i {
    font-size: 18px;
    line-height: 1;
}

/* ---- Scroller + track ---- */
.settings-tabs-scroller {
    overflow: hidden;
    max-width: 100%;
    min-width: 0;
}

.settings-tabs-track {
    display: flex;
    align-items: center;
    gap: 10px;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

/* ---- Tab pills ---- */
a.settings-tab {
    white-space: nowrap;
    padding: 10px 22px;
    border-radius: 50px;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    flex-shrink: 0;
}

a.settings-tab:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

a.settings-tab.active {
    background: #16659E;
    color: #fff;
    box-shadow: 0 2px 5px rgba(22, 101, 158, 0.20);
}



:root {
    --bs-primary: #16659E !important;
    --bs-primary-rgb: 22, 101, 158 !important;
}

.btn-primary {
    --bs-btn-color: #fff !important;
    --bs-btn-bg: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #124f7c !important;
    --bs-btn-hover-border-color: #124f7c !important;
    --bs-btn-active-color: #fff !important;
    --bs-btn-active-bg: #0f4265 !important;
    --bs-btn-active-border-color: #0f4265 !important;

    background-color: #16659E !important;
    border-color: #16659E !important;
    color: #fff !important;
}

.bg-primary {
    background-color: #16659E !important;
}

.text-primary {
    color: #16659E !important;
}

.btn-outline-primary {
    --bs-btn-color: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #16659E !important;
    --bs-btn-hover-border-color: #16659E !important;

    color: #16659E !important;
    border-color: #16659E !important;
}

.bg-primary-subtle {
    background-color: #e8eef5 !important;
}



.wbs-item-card {
    transition: box-shadow 0.2s ease, transform 0.2s ease;
    background-color: #fff;
}

.wbs-item-card:hover {
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
    transform: translateY(-1px);
}

.card-body > .d-flex {
    min-height: 55px;
}

.card-body .btn {
    white-space: nowrap;
}




@media (max-width: 992px) {

    .card-body > .d-flex {
        align-items: flex-start !important;
    }

    .card-body > .d-flex > div:last-child {
        width: 100%;
    }

}

@media (max-width: 768px) {

    .settings-tabs-wrapper .d-flex {
        overflow-x: auto;
        flex-wrap: nowrap !important;
        padding-bottom: 4px;
    }

    a.settings-tab {
        flex-shrink: 0;
        padding: 9px 18px;
    }

}

</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Planner Tabs Scroll (chevron arrows) ---------- */
    const plannerTabsTrack = document.getElementById('plannerTabsTrack');
    const plannerLeftBtn   = document.getElementById('plannerTabScrollLeft');
    const plannerRightBtn  = document.getElementById('plannerTabScrollRight');

    if (plannerLeftBtn && plannerTabsTrack) {
        plannerLeftBtn.addEventListener('click', function () {
            plannerTabsTrack.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (plannerRightBtn && plannerTabsTrack) {
        plannerRightBtn.addEventListener('click', function () {
            plannerTabsTrack.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

});
</script>

@endsection
