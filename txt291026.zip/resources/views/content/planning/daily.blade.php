@extends('layouts.layoutMaster')


@section('title', 'Daily Progress Report')

@section('content')

<div class="container-fluid">

    <div class="card mb-4">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                
                <div class="flex-shrink-0" style="min-width: 0;">
                    <h5 class="fw-bold mb-1">Planning & Quantity Surveying (QS) Engine</h5>

                    <p class="text-muted small mb-0">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>
                </div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <div class="settings-tabs-wrapper">

                        <div class="d-flex align-items-center gap-2">

                            <button type="button"
                                    class="settings-tab-scroll-btn"
                                    id="plannerTabScrollLeft"
                                    aria-label="Scroll tabs left">
                                <i class="mdi mdi-chevron-left"></i>
                            </button>

                            <div class="settings-tabs-scroller">
                                <div class="settings-tabs-track" id="plannerTabsTrack">

                                    <a href="{{ route('planning-qs.management') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.management') ? 'active' : '' }}">
                                        Management Planner
                                    </a>

                                    <a href="{{ route('planning-qs.daily') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.daily') ? 'active' : '' }}">
                                        Daily Progress Report
                                    </a>

                                    <a href="{{ route('planning-qs.achieved') }}"
                                       class="settings-tab {{ request()->routeIs('planning-qs.achieved') ? 'active' : '' }}">
                                        Planned Vs Achieved
                                    </a>

                                </div>
                            </div>

                            <button type="button"
                                    class="settings-tab-scroll-btn"
                                    id="plannerTabScrollRight"
                                    aria-label="Scroll tabs right">
                                <i class="mdi mdi-chevron-right"></i>
                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    </div>

    <div class="card dpr-item-card mb-3">

        <div class="card-body">

            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">

                <span class="dpr-code text-primary bg-primary-subtle small">
                    DPR-QS-01
                </span>

                <span class="dpr-date">
                    2026-07-22
                </span>

            </div>

            <h6 class="dpr-title mb-2" style="color: #000000;">
                Concreting Pier Cap #12
            </h6>

            <div class="card border mb-3">
                <div class="card-body py-3 px-3 bg-light-subtle">
                   <div class="text-light-subtle">
                        Cube samples collected. Slump test 110mm verified.
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

                <div class="dpr-field">
                    <span class="dpr-label">
                        Location:
                    </span>

                    <span class="dpr-value fw-semibold" style="color: #000000;">
                        Pier P-45 Site
                    </span>
                </div>

                <div class="dpr-field">
                    <span class="dpr-label">
                        Achieved:
                    </span>

                    <span class="dpr-value dpr-achieved text-success">
                        85 Cu.m
                    </span>
                </div>

                <div class="dpr-field text-md-end">
                    <span class="dpr-label">
                        Verified By:
                    </span>

                    <span class="dpr-value fw-semibold" style="color: #000000;">
                        J. Swamy (Senior QS)
                    </span>
                </div>

            </div>

        </div>

    </div>

    <div class="card dpr-item-card mb-3">

        <div class="card-body">

            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">

                <span class="dpr-code text-primary bg-primary-subtle small">
                    DPR-QS-02
                </span>

                <span class="dpr-date">
                    2026-07-21
                </span>

            </div>

            <h6 class="dpr-title mb-2" style="color: #000000;">
                Rebar Inspection & Binding
            </h6>

            <div class="card border shadow-sm mb-3">
                <div class="card-body py-3 px-3 bg-light-subtle">
                    <div class="text-light-subtle">
                        Minor delay due to 1hr rain. Rebar spacing approved.
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

                <div class="dpr-field">
                    <span class="dpr-label">
                        Location:
                    </span>

                    <span class="dpr-value fw-semibold" style="color: #000000;">
                        Adyar Yard B
                    </span>
                </div>

                <div class="dpr-field">
                    <span class="dpr-label">
                        Achieved:
                    </span>

                    <span class="dpr-value dpr-achieved text-success">
                        18 MT
                    </span>
                </div>

                <div class="dpr-field text-md-end">
                    <span class="dpr-label">
                        Verified By:
                    </span>

                    <span class="dpr-value fw-semibold" style="color: #000000;">
                        M. Anand (Planning Eng)
                    </span>
                </div>

            </div>

        </div>

    </div>


<style>

.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-wrapper .d-flex {
    gap: 10px !important;
}

/* ---- Scroll buttons (chevron arrows) ---- */
.settings-tab-scroll-btn {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
    transition: all 0.15s ease;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
    border-color: #16659E;
}

.settings-tab-scroll-btn i {
    font-size: 18px;
    line-height: 1;
}

/* ---- Scroller + track ---- */
.settings-tabs-scroller {
    overflow: hidden;
    max-width: 100%;
    min-width: 0;
}

.settings-tabs-track {
    display: flex;
    align-items: center;
    gap: 10px;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

/* ---- Tab pills ---- */
a.settings-tab {
    white-space: nowrap;
    padding: 10px 22px;
    border-radius: 50px;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    flex-shrink: 0;
}

a.settings-tab:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

a.settings-tab.active {
    background: #16659E;
    color: #fff;
    box-shadow: 0 2px 5px rgba(22, 101, 158, 0.20);
}

:root {
    --bs-primary: #16659E !important;
    --bs-primary-rgb: 22, 101, 158 !important;
}

.btn-primary {
    --bs-btn-color: #fff !important;
    --bs-btn-bg: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #124f7c !important;
    --bs-btn-hover-border-color: #124f7c !important;
    --bs-btn-active-color: #fff !important;
    --bs-btn-active-bg: #0f4265 !important;
    --bs-btn-active-border-color: #0f4265 !important;
    background-color: #16659E !important;
    border-color: #16659E !important;
    color: #fff !important;
}

.bg-primary {
    background-color: #16659E !important;
}

.text-primary {
    color: #16659E !important;
}

.btn-outline-primary {
    --bs-btn-color: #16659E !important;
    --bs-btn-border-color: #16659E !important;
    --bs-btn-hover-color: #fff !important;
    --bs-btn-hover-bg: #16659E !important;
    --bs-btn-hover-border-color: #16659E !important;
    color: #16659E !important;
    border-color: #16659E !important;
}

.bg-primary-subtle {
    background-color: #e8eef5 !important;
}

.dpr-item-card {
    border: 1px solid #edeff2;
    border-radius: 0.5rem;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
    transition: box-shadow 0.15s ease;
}

.dpr-item-card:hover {
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.dpr-code {
    display: inline-block;
    font-family: 'Courier New', Courier, monospace;
    font-size: 0.72rem;
    font-weight: 600;
    letter-spacing: 0.03em;
    color: #3b5bdb;
    background-color: #eef2ff;
    padding: 0.2rem 0.55rem;
    border-radius: 0.35rem;
}

.dpr-date {
    font-size: 0.82rem;
    color: #6c757d;
}

.dpr-title {
    font-weight: 700;
    color: #2b2f33;
    font-size: 0.98rem;
    margin: 0;
}

.dpr-field {
    font-size: 0.8rem;
}

.dpr-label {
    color: #8a929b;
    margin-right: 0.25rem;
}

.dpr-label-location {
    color: #3b7ddd;
}

.dpr-value {
    color: #2b2f33;
    font-weight: 600;
}

.dpr-achieved {
    font-family: 'Courier New', Courier, monospace;
    color: #2f9e44;
}

.dpr-footer-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.4rem;
    padding: 0.25rem 0;
    font-family: 'Courier New', Courier, monospace;
    font-size: 0.68rem;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: #adb5bd;
}

@media (max-width: 992px) {

    .dpr-item-card .d-flex.justify-content-between.align-items-center {
        align-items: flex-start !important;
        flex-direction: column;
    }

    .dpr-footer-bar {
        flex-direction: column;
        align-items: flex-start;
    }

}

</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Planner Tabs Scroll (chevron arrows) ---------- */
    const plannerTabsTrack = document.getElementById('plannerTabsTrack');
    const plannerLeftBtn   = document.getElementById('plannerTabScrollLeft');
    const plannerRightBtn  = document.getElementById('plannerTabScrollRight');

    if (plannerLeftBtn && plannerTabsTrack) {
        plannerLeftBtn.addEventListener('click', function () {
            plannerTabsTrack.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (plannerRightBtn && plannerTabsTrack) {
        plannerRightBtn.addEventListener('click', function () {
            plannerTabsTrack.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

});
</script>

@endsection
