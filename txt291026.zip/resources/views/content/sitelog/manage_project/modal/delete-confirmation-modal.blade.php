<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">

            <div class="modal-body px-4 py-4">

                <!-- Delete Icon -->
                <div class="text-center mb-2">
                    <div class="delete-icon-modal mx-auto">
                        <i class="bi bi-trash3"></i>
                    </div>
                </div>

                <!-- Title -->
                <h5 class="modal-title text-center fw-bold mb-2" id="deleteConfirmationModalLabel">
                    Confirm Deletion
                </h5>

                <!-- Message -->
                <p class="text-center text-muted small mb-3">
                    Are you sure you want to delete project record
                    <strong id="deleteProjectName" class="text-dark">
                        "Chennai Metro Phase 2 - Corridor 4"
                    </strong>?
                    This action cannot be undone.
                </p>

                <!-- Buttons -->
                <div class="d-flex gap-2">

                    <button type="button" class="btn btn-light flex-fill rounded-3 fw-semibold" data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <form id="deleteProjectForm" method="POST" class="flex-fill">
                        @csrf
                        @method('DELETE')

                        <button type="submit" class="btn btn-danger w-100 rounded-3 fw-semibold">
                            Delete
                        </button>
                    </form>

                </div>

            </div>

        </div>
    </div>
    <style>
    /* Delete icon */
    .delete-icon-modal {
        width: 44px;
        height: 44px;
        border-radius: 50%;
        background: #fff1f4;
        border: 1px solid #ffd5df;

        display: flex;
        align-items: center;
        justify-content: center;

        color: #f00446;
        font-size: 20px;
    }

    /* Modal width */
    #deleteConfirmationModal .modal-dialog {
        max-width: 345px;
    }

    /* Modal */
    #deleteConfirmationModal .modal-content {
        border-radius: 14px !important;
    }

    /* Description */
    #deleteConfirmationModal .modal-body p {
        font-size: 11px;
        line-height: 17px;
    }

    /* Buttons */
    #deleteConfirmationModal .btn {
        height: 30px;
        font-size: 11px;
        border: 0;
    }

    #deleteConfirmationModal .btn-light {
        background-color: #edf2f7;
        color: #344054;
    }

    #deleteConfirmationModal .btn-danger {
        background-color: #f00446;
    }

    #deleteConfirmationModal .btn-danger:hover {
        background-color: #d9043d;
    }
    </style>
</div>