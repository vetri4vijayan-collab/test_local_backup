<div class="modal fade" id="editProjectModal" tabindex="-1" aria-labelledby="editProjectModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">

        <div class="modal-content">

            {{-- Modal Header --}}
            <div class="modal-header border-bottom">

                <div>
                    <h5 class="modal-title fw-semibold mb-1" id="editProjectModalLabel">

                        <i class="bi bi-pencil-square me-2 text-primary"></i>
                        Update Project

                    </h5>

                    <p class="text-muted mb-2">
                        Update project details, client association, structural scope
                        & assigned contractors
                    </p>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>


            {{-- Modal Body --}}
            <div class="modal-body">

                <form id="editProjectForm">

                    <div class="row g-3">

                        {{-- Client --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Mapped Client Organization
                                <span class="text-danger">*</span>
                            </label>

                            <select class="form-select">

                                <option>ABC Constructions Pvt Ltd</option>
                                <option selected>
                                    SPK And Co., - VF
                                </option>
                                <option>
                                    Chennai Infrastructure Ltd
                                </option>
                                <option>
                                    XYZ Developers
                                </option>

                            </select>

                        </div>


                        {{-- Project Code --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Project Code
                                <span class="text-danger">*</span>
                            </label>

                            <input type="text" class="form-control" value="PRJ-NEW-154">

                        </div>


                        {{-- Project Name --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Project Name
                                <span class="text-danger">*</span>
                            </label>

                            <input type="text" class="form-control" value="Chennai Metro Phase 2 - Corridor 4">

                        </div>


                        {{-- Structure Count --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Structure Count (Total Units)
                            </label>

                            <input type="number" class="form-control" value="12">

                        </div>


                        {{-- Start Date --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Start Date
                            </label>

                            <input type="date" class="form-control" value="2026-09-16">

                        </div>


                        {{-- End Date --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                End Date
                            </label>

                            <input type="date" class="form-control" value="2027-12-31">

                        </div>


                        {{-- Budget --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Project Total Budget (₹ INR)
                            </label>

                            <input type="text" class="form-control" value="100000000">

                        </div>


                        {{-- Project Manager --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Project Manager
                            </label>

                            <input type="text" class="form-control" value="Er. Dinesh Kathrik">

                        </div>


                        {{-- Site Engineer --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Site Engineer In-Charge
                            </label>

                            <input type="text" class="form-control" value="R. Vigneshwar">

                        </div>


                        {{-- Project Status --}}
                        <div class="col-md-4">

                            <label class="form-label">
                                Project Status
                            </label>

                            <select class="form-select">

                                <option>
                                    Not Started
                                </option>

                                <option selected>
                                    In Progress
                                </option>

                                <option>
                                    Completed
                                </option>

                                <option>
                                    On Hold
                                </option>

                            </select>

                        </div>


                        {{-- Site Location --}}
                        <div class="col-md-8">

                            <label class="form-label">
                                Site Location Address
                            </label>

                            <input type="text" class="form-control" value="Porur to Power House Corridor, Chennai">

                        </div>


                        {{-- Sub Contractors --}}
                        <div class="col-12 mt-4">

                            <label class="form-label fw-semibold">
                                Assign Sub-Contractors to Project
                            </label>

                            <div class="border rounded-3 p-3">

                                <div class="row g-3">

                                    {{-- AquaLine --}}
                                    <div class="col-md-4">

                                        <div class="border rounded-3 p-3">

                                            <div class="form-check">

                                                <input type="checkbox" class="form-check-input" id="edit_aqualine"
                                                    checked>

                                                <label class="form-check-label" for="edit_aqualine">
                                                    AquaLine Plumbing Works
                                                </label>

                                            </div>

                                        </div>

                                    </div>


                                    {{-- Apex --}}
                                    <div class="col-md-4">

                                        <div class="border rounded-3 p-3">

                                            <div class="form-check">

                                                <input type="checkbox" class="form-check-input" id="edit_apex" checked>

                                                <label class="form-check-label" for="edit_apex">
                                                    Apex Structural Sub-Contractors
                                                </label>

                                            </div>

                                        </div>

                                    </div>


                                    {{-- Star --}}
                                    <div class="col-md-4">

                                        <div class="border rounded-3 p-3">

                                            <div class="form-check">

                                                <input type="checkbox" class="form-check-input" id="edit_star">

                                                <label class="form-check-label" for="edit_star">
                                                    Star Bar-Bending & Rebar Works
                                                </label>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>


                        {{-- Project Scope --}}
                        <div class="col-12">

                            <label class="form-label">
                                Project Scope / Remarks Description
                            </label>

                            <textarea class="form-control"
                                rows="4">Construction and structural development work for Chennai Metro Phase 2 - Corridor 4.</textarea>

                        </div>

                    </div>

                </form>

            </div>


            {{-- Footer --}}
            <div class="modal-footer border-top">
                <div class="mt-2">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button" class="btn btn-primary px-4">

                        <i class="bi bi-check2-circle me-1"></i>
                        Update Project

                    </button>
                </div>
            </div>

        </div>

    </div>

</div>