<div class="client-report-dashboard">

    <!-- STAT CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-invoiced">
                    <i class="bi bi-file-earmark-check-fill"></i>
                </div>
                <div class="stat-label">JMR INVOICES CERTIFIED TO CLIENT</div>
                <div class="stat-value">₹2.40 <span>Cr</span></div>
                <div class="stat-desc text-success-custom">Funds disbursed completely</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-pending">
                    <i class="bi bi-hourglass-split"></i>
                </div>
                <div class="stat-label">PENDING CLIENT VERIFICATION</div>
                <div class="stat-value text-warning-custom">₹1.85 <span>Cr</span></div>
                <div class="stat-desc">Under June measurement audit</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-satisfaction">
                    <i class="bi bi-emoji-smile-fill"></i>
                </div>
                <div class="stat-label">CLIENT SATISFACTION LEVEL</div>
                <div class="stat-value text-info-custom">Excellent <span>(9.2)</span></div>
                <div class="stat-desc">Based on CMRL site inspection</div>
            </div>
        </div>

    </div>


    <div class="row g-3">

        <!-- LEFT: SUBMITTED CLIENT PROGRESS & MEASUREMENT REPORTS -->
        <div class="col-lg-8">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">SUBMITTED CLIENT PROGRESS &amp; MEASUREMENT REPORTS</h6>
                    <button type="button" class="btn btn-sm export-btn d-flex align-items-center gap-1">
                        <i class="bi bi-download"></i> Export report Log
                    </button>
                </div>

                <div class="card-body">

                    <div class="report-row">
                        <div class="d-flex align-items-start justify-content-between flex-wrap gap-2">
                            <div>
                                <div class="report-name">Monthly Joint Measurement Record (JMR) - June</div>
                                <div class="report-meta">Report ID: REP-101 &bull; Submitted on 2026-07-02</div>
                            </div>
                            <span class="status-pill status-approved">APPROVED &amp; BILLED</span>
                        </div>

                        <div class="d-flex align-items-end justify-content-between flex-wrap gap-2 mt-3">
                            <div class="report-billing">
                                Billing Cycle: <span class="fw-bold">June 2026</span>
                            </div>
                            <div class="text-end">
                                <div class="invoice-value-label">Invoice Value: <span class="invoice-value">₹2.40
                                        Cr</span></div>
                                <button type="button" class="btn btn-sm export-pdf-btn mt-2">
                                    <i class="bi bi-file-earmark-pdf-fill"></i> Export Report PDF
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="report-row">
                        <div class="d-flex align-items-start justify-content-between flex-wrap gap-2">
                            <div>
                                <div class="report-name">Physical Execution Progress &amp; Safety Audit Q2</div>
                                <div class="report-meta">Report ID: REP-102 &bull; Submitted on 2026-07-15</div>
                            </div>
                            <span class="status-pill status-verification">UNDER CLIENT VERIFICATION</span>
                        </div>

                        <div class="d-flex align-items-end justify-content-between flex-wrap gap-2 mt-3">
                            <div class="report-billing">
                                Billing Cycle: <span class="fw-bold">Q2 2026</span>
                            </div>
                            <div class="text-end">
                                <div class="invoice-value-label">Invoice Value: <span class="invoice-value">₹1.85
                                        Cr</span></div>
                                <button type="button" class="btn btn-sm export-pdf-btn mt-2">
                                    <i class="bi bi-file-earmark-pdf-fill"></i> Export Report PDF
                                </button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>


        <!-- RIGHT: GENERATE PROGRESS REPORT -->
        <div class="col-lg-4">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">GENERATE PROGRESS REPORT</h6>
                    <a href="javascript:void(0)" class="generate-report-link" data-bs-toggle="modal"
                        data-bs-target="#generateReportModal">
                        [ + Generate Report ]
                    </a>
                </div>

                <div class="card-body">

                    <div class="protocol-banner">
                        <div class="protocol-header">
                            <i class="bi bi-shield-check"></i> JOINT MEASUREMENT PROTOCOL (JMR)
                        </div>
                        <p class="protocol-text mb-0">
                            Client reports must be authorized by both the contractor's site engineer and client's
                            designated PM to proceed to invoicing.
                        </p>
                    </div>

                </div>

            </div>
        </div>

    </div>

</div>

<!-- Generate Progress Report Modal -->
@include('content.sitelog.manage_project.tabs.modal.generate-progress-report')


<style>
.client-report-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Stat cards */
.stat-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px 18px;
    position: relative;
}

.stat-icon {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
}

.stat-icon.icon-invoiced {
    background: #dcfce7;
    color: #16a34a;
}

.stat-icon.icon-pending {
    background: #fef3c7;
    color: #d97706;
}

.stat-icon.icon-satisfaction {
    background: #dbeafe;
    color: #2563eb;
}

.stat-label {
    font-size: 8px;
    font-weight: 700;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 8px;
    padding-right: 36px;
}

.stat-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
    line-height: 1;
    margin-bottom: 6px;
}

.stat-value span {
    font-size: 12px;
    font-weight: 700;
    color: #64748b;
}

.stat-desc {
    font-size: 8.5px;
    color: #64748b;
}

.text-success-custom {
    color: #16a34a !important;
}

.text-warning-custom {
    color: #d97706 !important;
}

.text-info-custom {
    color: #2563eb !important;
}


/* Panel cards */
.panel-card {
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    overflow: hidden;
}

.panel-card .card-header {
    background: #ffffff;
    border-bottom: 1px solid #e2e8f0;
    padding: 14px 18px;
}

.panel-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 10.5px;
    font-weight: 800;
    color: #0f172a;
    letter-spacing: 0.4px;
}

.panel-card .card-body {
    padding: 18px;
}

.generate-report-link {
    font-size: 9px;
    font-weight: 700;
    color: #2563eb;
    text-decoration: none;
    white-space: nowrap;
}

.generate-report-link:hover {
    color: #1d4ed8;
    text-decoration: underline;
}

.export-btn {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    color: #334155;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.export-btn:hover {
    background: #f8fafc;
    color: #334155;
}


/* Report rows */
.report-row {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px 18px;
    margin-bottom: 14px;
}

.report-row:last-child {
    margin-bottom: 0;
}

.report-name {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    font-size: 11px;
    color: #0f172a;
    margin-bottom: 2px;
}

.report-meta {
    font-size: 8px;
    color: #94a3b8;
}

.report-billing {
    font-size: 9px;
    color: #334155;
}

.invoice-value-label {
    font-size: 8.5px;
    color: #64748b;
}

.invoice-value {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #2563eb;
    font-size: 10px;
}

.export-pdf-btn {
    background: #1d4ed8;
    color: #ffffff;
    border: 0;
    border-radius: 6px;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 12px;
    white-space: nowrap;
}

.export-pdf-btn:hover {
    background: #1e40af;
    color: #ffffff;
}

.status-pill {
    display: inline-block;
    font-size: 7.5px;
    font-weight: 700;
    letter-spacing: 0.2px;
    padding: 4px 10px;
    border-radius: 20px;
    white-space: nowrap;
}

.status-approved {
    background: #dcfce7;
    color: #15803d;
}

.status-verification {
    background: #fef3c7;
    color: #b45309;
}


/* Protocol banner */
.protocol-banner {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 10px;
    padding: 14px 16px;
}

.protocol-header {
    font-family: 'Urbanist', sans-serif;
    font-size: 9.5px;
    font-weight: 800;
    color: #1d4ed8;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 8px;
}

.protocol-header i {
    font-size: 12px;
}

.protocol-text {
    font-size: 9px;
    color: #1e40af;
    line-height: 1.6;
}


/* Mobile */
@media (max-width: 767px) {

    .stat-card {
        padding: 14px 16px;
    }

    .panel-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .export-btn {
        justify-content: center;
    }
}
</style>