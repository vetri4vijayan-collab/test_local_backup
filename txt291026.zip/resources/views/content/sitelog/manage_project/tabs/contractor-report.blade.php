<div class="contractor-report-dashboard">

    <!-- STAT CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-contractors">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div class="stat-label">ASSIGNED CONTRACTORS</div>
                <div class="stat-value">2 <span>Partner Agencies</span></div>
                <div class="stat-desc">Working in-site structural works</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-wages">
                    <i class="bi bi-cash-coin"></i>
                </div>
                <div class="stat-label">WAGES DISBURSED ON-TIME</div>
                <div class="stat-value text-success-custom">100.0%</div>
                <div class="stat-desc text-success-custom">Muster wages fully cleared</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-safety">
                    <i class="bi bi-shield-fill-check"></i>
                </div>
                <div class="stat-label">AVERAGE SITE SAFETY COMPLIANCE</div>
                <div class="stat-value text-success-custom">94.8 <span>/ 100</span></div>
                <div class="stat-desc">Based on site engineer audit</div>
            </div>
        </div>

    </div>


    <!-- SUB-CONTRACTORS ACTIVE SITE COMPLIANCE & SCORECARDS -->
    <div class="card panel-card">

        <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
            <h6 class="mb-0 panel-title">SUB-CONTRACTORS ACTIVE SITE COMPLIANCE &amp; SCORECARDS</h6>
            <button type="button" class="btn btn-sm export-btn d-flex align-items-center gap-1">
                <i class="bi bi-printer"></i> Print compliance scorecard
            </button>
        </div>

        <div class="card-body">
            <div class="row g-3">

                <div class="col-md-6">
                    <div class="contractor-card h-100">
                        <div class="d-flex align-items-start justify-content-between">
                            <div>
                                <div class="contractor-name">Apex Structural Sub-Contractors</div>
                                <div class="contractor-category">Assigned Partner &bull; Category Structural</div>
                            </div>
                            <span class="score-pill">Score: 92/100</span>
                        </div>
                        <hr class="contractor-divider">
                        <div class="d-flex flex-wrap gap-4 mb-2">
                            <div class="contractor-metric">
                                <span class="metric-label"><i class="bi bi-tools"></i> Site Work Quality:</span>
                                <span class="metric-value">92% Excellent</span>
                            </div>
                            <div class="contractor-metric">
                                <span class="metric-label"><i class="bi bi-shield-check"></i> Safety Index:</span>
                                <span class="metric-value">95/100 Pass</span>
                            </div>
                        </div>
                        <div class="contractor-metric">
                            <span class="metric-label"><i class="bi bi-patch-check-fill"></i> Compliance
                                Category:</span>
                            <span class="metric-value compliance-value">ISO 9001 certified execution</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="contractor-card h-100">
                        <div class="d-flex align-items-start justify-content-between">
                            <div>
                                <div class="contractor-name">Star Bar-Bending &amp; Rebar Works</div>
                                <div class="contractor-category">Assigned Partner &bull; Category Structural</div>
                            </div>
                            <span class="score-pill">Score: 88/100</span>
                        </div>
                        <hr class="contractor-divider">
                        <div class="d-flex flex-wrap gap-4 mb-2">
                            <div class="contractor-metric">
                                <span class="metric-label"><i class="bi bi-tools"></i> Site Work Quality:</span>
                                <span class="metric-value">88% Excellent</span>
                            </div>
                            <div class="contractor-metric">
                                <span class="metric-label"><i class="bi bi-shield-check"></i> Safety Index:</span>
                                <span class="metric-value">92/100 Pass</span>
                            </div>
                        </div>
                        <div class="contractor-metric">
                            <span class="metric-label"><i class="bi bi-patch-check-fill"></i> Compliance
                                Category:</span>
                            <span class="metric-value compliance-value">ISO 9001 certified execution</span>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>

</div>


<style>
.contractor-report-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Stat cards */
.stat-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px 18px;
    position: relative;
}

.stat-icon {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
}

.stat-icon.icon-contractors {
    background: #f1f5f9;
    color: #475569;
}

.stat-icon.icon-wages {
    background: #dcfce7;
    color: #16a34a;
}

.stat-icon.icon-safety {
    background: #dcfce7;
    color: #16a34a;
}

.stat-label {
    font-size: 8px;
    font-weight: 700;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 8px;
    padding-right: 36px;
}

.stat-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
    line-height: 1;
    margin-bottom: 6px;
}

.stat-value span {
    font-size: 12px;
    font-weight: 700;
    color: #64748b;
}

.stat-desc {
    font-size: 8.5px;
    color: #64748b;
}

.text-success-custom {
    color: #16a34a !important;
}


/* Panel card */
.panel-card {
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    overflow: hidden;
}

.panel-card .card-header {
    background: #ffffff;
    border-bottom: 1px solid #e2e8f0;
    padding: 14px 18px;
}

.panel-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 10.5px;
    font-weight: 800;
    color: #0f172a;
    letter-spacing: 0.4px;
}

.panel-card .card-body {
    padding: 18px;
}

.export-btn {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    color: #334155;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.export-btn:hover {
    background: #f8fafc;
    color: #334155;
}


/* Contractor cards */
.contractor-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px 18px;
}

.contractor-name {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    font-size: 11px;
    color: #0f172a;
    margin-bottom: 2px;
}

.contractor-category {
    font-size: 8px;
    color: #94a3b8;
}

.score-pill {
    display: inline-block;
    font-size: 8px;
    font-weight: 700;
    letter-spacing: 0.2px;
    padding: 4px 10px;
    border-radius: 6px;
    background: #dbeafe;
    color: #1d4ed8;
    white-space: nowrap;
}

.contractor-divider {
    margin: 12px 0;
    border-top: 1px solid #e2e8f0;
    opacity: 1;
}

.contractor-metric {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 9px;
}

.metric-label {
    color: #64748b;
    display: flex;
    align-items: center;
    gap: 5px;
    white-space: nowrap;
}

.metric-label i {
    font-size: 9px;
    color: #94a3b8;
}

.metric-value {
    font-weight: 700;
    color: #0f172a;
    white-space: nowrap;
}

.compliance-value {
    color: #16a34a;
}


/* Mobile */
@media (max-width: 767px) {

    .stat-card {
        padding: 14px 16px;
    }

    .panel-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .export-btn {
        justify-content: center;
    }

    .contractor-metric {
        flex-wrap: wrap;
    }
}
</style>