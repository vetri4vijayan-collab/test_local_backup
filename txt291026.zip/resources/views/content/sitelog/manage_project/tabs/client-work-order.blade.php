<div class="work-order-dashboard">

    <!-- SUMMARY CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="summary-card h-100">
                <div class="summary-icon icon-value">
                    <i class="bi bi-currency-rupee"></i>
                </div>
                <div class="summary-label">TOTAL WORK ORDER VALUE</div>
                <div class="summary-value">₹28.00 <span>Cr</span></div>
                <div class="summary-description">Sum of all approved work orders</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="summary-card h-100">
                <div class="summary-icon icon-active">
                    <i class="bi bi-file-earmark-check"></i>
                </div>
                <div class="summary-label">ACTIVE WORK ORDERS</div>
                <div class="summary-value text-primary-custom">2 <span>Issued</span></div>
                <div class="summary-description completed-text">Fully authorized execution limits</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="summary-card h-100">
                <div class="summary-icon icon-date">
                    <i class="bi bi-calendar-event"></i>
                </div>
                <div class="summary-label">LATEST WO ISSUE DATE</div>
                <div class="summary-value date-value">2026-02-10</div>
                <div class="summary-description warning-text">Fresh contractual authorization</div>
            </div>
        </div>

    </div>


    <!-- TOOLBAR -->
    <div class="wo-toolbar d-flex align-items-center justify-content-between gap-2 mb-3 flex-wrap">
        <div class="wo-search flex-grow-1">
            <i class="bi bi-search"></i>
            <input type="text" placeholder="Search Work Orders...">
        </div>
         <button type="button" class="btn btn-sm create-wo-btn d-flex align-items-center gap-1 flex-shrink-0"
            onclick="window.location.href='{{ route('manage_project.tabs.page.create-client-work-order') }}'">
            <i class="bi bi-plus-lg"></i> Create Client Work Order
        </button>
    </div>


    <!-- WORK ORDER LIST -->
    <div class="d-flex flex-column gap-3">

        <div class="card wo-card">
            <div class="card-body">

                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-2 flex-wrap">
                            <span class="wo-code">WO/CMRL/2025/089</span>
                            <span class="wo-issued">Issued: 2025-08-18</span>
                        </div>
                        <h5 class="wo-title mb-0">Corridor 4 Piling &amp; Substructure Contract</h5>
                    </div>
                    <div class="text-end">
                        <div class="wo-value-label">WORK ORDER VALUE</div>
                        <div class="wo-value">₹18.50 Cr</div>
                    </div>
                </div>

                <hr class="wo-divider">

                <div class="wo-scope-label">DETAILED SCOPE OF WORK</div>
                <p class="wo-scope-text">Piling work up to 25m depth, installation of piling caps, and pier
                    constructions.</p>

                <hr class="wo-divider">

                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div class="wo-signatory">Client Signatory: <strong>Er. Rajesh Gopal (CMRL)</strong></div>
                    <div class="d-flex gap-2">
                        <span class="status-badge status-active">ACTIVE</span>
                        <button class="action-btn boq-btn" type="button" data-bs-toggle="modal"
                            data-bs-target="#boqModal">VIEW BOQ DETAILS</button>
                        <button class="action-btn print-btn" type="button">PRINT WO</button>
                    </div>
                </div>

            </div>
        </div>


        <div class="card wo-card">
            <div class="card-body">

                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-2 flex-wrap">
                            <span class="wo-code">WO/CMRL/2026/041</span>
                            <span class="wo-issued">Issued: 2026-02-10</span>
                        </div>
                        <h5 class="wo-title mb-0">Station Elevated Box Girders Launching Amendment</h5>
                    </div>
                    <div class="text-end">
                        <div class="wo-value-label">WORK ORDER VALUE</div>
                        <div class="wo-value">₹9.50 Cr</div>
                    </div>
                </div>

                <hr class="wo-divider">

                <div class="wo-scope-label">DETAILED SCOPE OF WORK</div>
                <p class="wo-scope-text">Launching pre-cast concrete box girders across elevated viaduct stations.</p>

                <hr class="wo-divider">

                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div class="wo-signatory">Client Signatory: <strong>Er. Rajesh Gopal (CMRL)</strong></div>
                    <div class="d-flex gap-2">
                        <span class="status-badge status-active">ACTIVE</span>
                        <button class="action-btn boq-btn" type="button" data-bs-toggle="modal"
                            data-bs-target="#boqModal">VIEW BOQ DETAILS</button>
                        <button class="action-btn print-btn" type="button">PRINT WO</button>
                    </div>
                </div>

            </div>
        </div>

    </div>

</div>

<!-- View BOQ Modal -->
@include('content.sitelog.manage_project.tabs.modal.view-details-boq')
<style>
.work-order-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Summary cards */

.summary-card {
    background: #f8fafc;
    border: 1px solid #dce5ef;
    border-radius: 10px;
    padding: 18px 16px;
}

.summary-label {
    font-family: 'Inter', sans-serif;
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    margin-bottom: 8px;
}

.summary-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 17px;
    font-weight: 800;
    color: #0c3d72;
    line-height: 1;
}

.summary-value span {
    font-family: 'Urbanist', sans-serif;
    font-size: 13px;
    font-weight: 700;
}

.summary-value.text-primary-custom {
    color: #17649b;
}

.summary-value.date-value {
    color: #7a3fd1;
}

.summary-description {
    font-family: 'Inter', sans-serif;
    font-size: 8px;
    color: #67809c;
    margin-top: 8px;
}

/* Icon container, positioned top-right of each summary card */
.summary-card {
    position: relative;
}

.summary-icon {
    position: absolute;
    top: 14px;
    right: 14px;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
}

.summary-icon.icon-value {
    background: #eaf2fb;
    color: #17649b;
}

.summary-icon.icon-active {
    background: #e6fbf3;
    color: #00a875;
}

.summary-icon.icon-date {
    background: #f2ecfc;
    color: #7a3fd1;
}

.completed-text {
    color: #00a875;
}

.warning-text {
    color: #d9534f;
}


/* Toolbar */
.wo-toolbar {
    background: #f8fafc;
    border: 1px solid #dce5ef;
    border-radius: 10px;
    padding: 9px;
}

.wo-search {
    height: 32px;
    border: 1px solid #bfd0e2;
    background: #ffffff;
    border-radius: 6px;
    display: flex;
    align-items: center;
    padding: 0 10px;
    max-width: 340px;
}

.wo-search i {
    font-size: 12px;
    color: #7891ad;
    margin-right: 8px;
}

.wo-search input {
    font-family: 'Inter', sans-serif;
    width: 100%;
    border: 0;
    outline: 0;
    font-size: 10px;
    color: #334e68;
    background: transparent;
}

.wo-search input::placeholder {
    color: #8094aa;
}

.create-wo-btn {
    font-family: 'Inter', sans-serif;
    height: 32px;
    padding: 0 14px;
    border: 0;
    border-radius: 6px;
    background: #17649b;
    color: #ffffff;
    font-size: 9.5px;
    font-weight: 700;
}

.create-wo-btn:hover {
    background: #0f5689;
    color: #ffffff;
}


/* Work order cards */
.wo-card {
    border: 1px solid #dce5ef;
    border-radius: 11px;
    transition: all 0.18s ease;
}

.wo-card:hover {
    border-color: #b8ccdf;
    box-shadow: 0 4px 15px rgba(30, 70, 110, 0.08);
}

.wo-card .card-body {
    padding: 18px 20px;
}

.wo-code {
    font-family: 'Urbanist', sans-serif;
    display: inline-block;
    padding: 3px 8px;
    border-radius: 5px;
    background: #edf6fd;
    border: 1px solid #d7e8f6;
    color: #17649b;
    font-size: 8.5px;
    font-weight: 700;
}

.wo-issued {
    font-family: 'Inter', sans-serif;
    font-size: 8px;
    color: #94a7bc;
}

.wo-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 14px;
    font-weight: 800;
    color: #071d35;
}

.wo-value-label {
    font-family: 'Inter', sans-serif;
    font-size: 7.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    margin-bottom: 4px;
}

.wo-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 15px;
    font-weight: 800;
    color: #00a875;
}

.wo-divider {
    border: none;
    height: 1px;
    background: #edf1f5;
    margin: 14px 0;
}

.wo-scope-label {
    font-family: 'Inter', sans-serif;
    font-size: 8.5px;
    font-weight: 700;
    color: #142c47;
    letter-spacing: 0.2px;
    margin-bottom: 6px;
}

.wo-scope-text {
    font-family: 'Inter', sans-serif;
    font-size: 9.5px;
    color: #5a7fb8;
    margin-bottom: 0;
    line-height: 1.5;
}

.wo-signatory {
    font-family: 'Inter', sans-serif;
    font-size: 9px;
    color: #607993;
}

.wo-signatory strong {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #142c47;
}


.status-badge {
    font-family: 'Urbanist', sans-serif;
    display: inline-flex;
    align-items: center;
    border-radius: 5px;
    padding: 5px 10px;
    font-size: 8px;
    font-weight: 700;
    letter-spacing: 0.2px;
}

.status-active {
    color: #00a875;
    border: 1px solid #8be7c7;
    background: #f4fffb;
}

.action-btn {
    font-family: 'Inter', sans-serif;
    height: 26px;
    padding: 0 10px;
    border-radius: 5px;
    font-size: 8px;
    font-weight: 700;
    background: #ffffff;
    white-space: nowrap;
}

.boq-btn {
    color: #17649b;
    border: 1px solid #b7d4eb;
}

.print-btn {
    color: #334e68;
    border: 1px solid #dce5ef;
}

.boq-btn:hover,
.print-btn:hover {
    background: #f5f9fc;
}


@media (max-width: 767px) {
    .wo-toolbar {
        flex-direction: column;
        align-items: stretch !important;
    }

    .wo-search {
        max-width: 100%;
    }

    .create-wo-btn {
        justify-content: center;
    }

    .status-badge,
    .action-btn {
        flex: 1;
        justify-content: center;
        text-align: center;
    }
}

@media (max-width: 767px) {

    /* Summary cards: icon overlaps text at narrow widths since it's
       absolutely positioned top-right — give the text room to breathe */
    .summary-card {
        padding: 16px 14px;
        padding-right: 54px;
        /* clears the icon */
    }

    .summary-icon {
        width: 28px;
        height: 28px;
        font-size: 13px;
        top: 12px;
        right: 12px;
    }

    .summary-value {
        font-size: 15px;
    }


    /* Work order card header: code/title block vs. value block
       already wraps via flex-wrap, just stack them fully and
       right-align the value block below the title on mobile */
    .wo-card .card-body {
        padding: 16px 14px;
    }

    .wo-card .card-body>.d-flex.justify-content-between.align-items-start {
        flex-direction: column;
        align-items: flex-start !important;
        gap: 10px;
    }

    .wo-card .card-body>.d-flex.justify-content-between.align-items-start .text-end {
        text-align: left !important;
        width: 100%;
    }

    .wo-title {
        font-size: 12.5px;
    }

    .wo-value {
        font-size: 14px;
    }


    /* Footer row: signatory vs. action buttons stack */
    .wo-card .card-body>.d-flex.justify-content-between.align-items-center {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .wo-card .card-body>.d-flex.justify-content-between.align-items-center>.d-flex.gap-2 {
        flex-wrap: wrap;
    }

    .wo-signatory {
        font-size: 8.5px;
    }
}


@media (max-width: 575px) {

    /* On very small screens, action buttons go full-width, one per row group */
    .status-badge,
    .action-btn {
        flex: 1 1 calc(50% - 4px);
    }

    .wo-scope-text {
        font-size: 9px;
    }
}
</style>
