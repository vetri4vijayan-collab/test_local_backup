@extends('layouts/contentNavbarLayout')

@section('title', 'Manage Project')

@section('content')

<div class="container-fluid">

    <!-- Page Header Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-3">
        <div class="card-body p-3">
            <div class="d-flex align-items-center gap-3">
                <div class="bg-primary-subtle rounded-3 px-2 py-1">
                    <i class="bi bi-briefcase text-primary fs-6"></i>
                </div>

                <div>
                    <h6 class="fw-bold mb-1">Manage Project</h6>
                    <small class="text-primary">
                        Site Operations Management & Logs
                    </small>
                </div>
            </div>
        </div>
    </div>


    <!-- Project Title / Action Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-3">
        <div class="card-body px-3 py-3">
            <div class="d-flex justify-content-between align-items-center">

                <div>
                    <small class="text-primary fw-semibold">
                        <i class="bi bi-buildings me-1"></i>
                        SITE PROJECT MANAGEMENT & CLIENT MAPPING
                    </small>

                    <h5 class="fw-bold mb-0 mt-2">
                        Projects Master Registry
                    </h5>


                    <p class=" text-muted small mb-0">
                        Create new projects against clients, track structure counts,
                        contractor assignments & budgets
                    </p>
                </div>

                <button class="btn btn-primary btn-sm rounded-3 px-3 " data-bs-toggle="modal"
                    data-bs-target="#createProjectModal">
                    <i class=" bi bi-plus-lg me-1"></i>
                    Create Project against Client
                </button>

            </div>
        </div>
    </div>


    <!-- Search + Project Table Card -->
    <div class="card border-0 shadow-sm rounded-4">

        <!-- Search Header -->
        <div class="card-body border-bottom py-3 px-3">
            <div class="d-flex justify-content-between align-items-center">

                <div class="input-group input-group-sm" style="max-width: 410px;">
                    <span class="input-group-text bg-light border-end-0">
                        <i class="bi bi-search text-muted"></i>
                    </span>

                    <input type="text" class="form-control bg-light border-start-0"
                        placeholder="Search by project code, name, client, contractors, status...">
                </div>

                <small class="text-muted">
                    Showing <strong>4</strong> active projects
                </small>

            </div>
        </div>


        <!-- Table -->
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">
                    <tr>
                        <th class="small text-uppercase text-muted px-3 py-3">
                            Project Code
                        </th>

                        <th class="small text-uppercase text-muted">
                            Project Name
                        </th>

                        <th class="small text-uppercase text-muted">
                            Client Name
                        </th>

                        <th class="small text-uppercase text-muted">
                            Structure Count
                        </th>

                        <th class="small text-uppercase text-muted">
                            Contractors Assigned
                        </th>

                        <th class="small text-uppercase text-muted">
                            Start Date
                        </th>

                        <th class="small text-uppercase text-muted">
                            End Date
                        </th>

                        <th class="small text-uppercase text-muted">
                            Budget
                        </th>

                        <th class="small text-uppercase text-muted">
                            Status
                        </th>

                        <th class="small text-uppercase text-muted text-center">
                            Actions
                        </th>
                    </tr>
                </thead>


                <tbody>

                    <!-- Row 1 -->
                    <tr>
                        <td class="px-3">
                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                                PRJ-CMRL-04
                            </span>
                        </td>

                        <td>
                            <div class="fw-semibold">
                                Chennai Metro Phase 2 - Corridor 4
                            </div>
                            <small class="text-muted">
                                <i class="bi bi-geo-alt"></i>
                                Chennai Metro House
                            </small>
                        </td>

                        <td>
                            <i class="bi bi-building text-muted me-1"></i>
                            <span class="fw-semibold small">
                                Chennai Metro Rail Limited...
                            </span>
                        </td>

                        <td>
                            <span class="badge rounded-pill bg-light text-dark border">
                                <i class="bi bi-stack text-primary me-1"></i>
                                14 Units
                            </span>
                        </td>

                        <td>
                            <div class="d-flex flex-column gap-1">
                                <span class="badge bg-light text-dark border text-start">
                                    Apex Structural Sub-Contractor
                                </span>
                                <span class="badge bg-light text-dark border text-start">
                                    Star Bar-Bending & Rebar...
                                </span>
                            </div>
                        </td>

                        <td class="small">2025-08-15</td>

                        <td class="small">2027-12-31</td>

                        <td class="fw-semibold">₹48.50 Cr</td>

                        <td>
                            <span class="badge rounded-pill bg-info-subtle text-primary border border-info-subtle">
                                In Progress
                            </span>
                        </td>

                        <td>
                            <div class="d-flex justify-content-center align-items-center gap-2">
                                <button type="button" class="action-icon view-icon" title="Profile View"
                                    onclick="window.location.href='{{ route('sitelog.manage_project.view') }}'">
                                    <i class="bi bi-eye"></i>
                                </button>


                                <button type="button" class="action-icon edit-icon" title="Edit" data-bs-toggle="modal"
                                    data-bs-target="#editProjectModal">
                                    <i class="bi bi-pencil"></i>
                                </button>

                                <button type="button" class="action-icon delete-icon" title="Delete"
                                    data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal">
                                    <i class="bi bi-trash"></i>
                                </button>

                            </div>
                        </td>
                    </tr>


                    <!-- Row 2 -->
                    <tr>
                        <td class="px-3">
                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                                PRJ-ELY-02
                            </span>
                        </td>

                        <td>
                            <div class="fw-semibold">
                                Adyar Premium Residences - Block B
                            </div>
                            <small class="text-muted">
                                <i class="bi bi-geo-alt"></i>
                                LB Road, Adyar, Chennai
                            </small>
                        </td>

                        <td>
                            <i class="bi bi-building text-muted me-1"></i>
                            <span class="fw-semibold small">
                                Elyzium Realty Developers
                            </span>
                        </td>

                        <td>
                            <span class="badge rounded-pill bg-light text-dark border">
                                <i class="bi bi-stack text-primary me-1"></i>
                                8 Units
                            </span>
                        </td>

                        <td>
                            <div class="d-flex flex-column gap-1">
                                <span class="badge bg-light text-dark border text-start">
                                    Apex Structural Sub-Contractor
                                </span>
                                <span class="badge bg-light text-dark border text-start">
                                    Vanguard Piling & Foundation...
                                </span>
                            </div>
                        </td>

                        <td class="small">2025-11-01</td>

                        <td class="small">2026-10-30</td>

                        <td class="fw-semibold">₹24.00 Cr</td>

                        <td>
                            <span class="badge rounded-pill bg-info-subtle text-primary border border-info-subtle">
                                In Progress
                            </span>
                        </td>

                        <td>
                            <div class="d-flex justify-content-center align-items-center gap-2">
                                <button type="button" class="action-icon view-icon" title="Profile View"
                                    onclick="window.location.href='{{ route('sitelog.manage_project.view') }}'">
                                    <i class="bi bi-eye"></i>
                                </button>


                                <button type="button" class="action-icon edit-icon" title="Edit" data-bs-toggle="modal"
                                    data-bs-target="#editProjectModal">
                                    <i class="bi bi-pencil"></i>
                                </button>

                                <button type="button" class="action-icon delete-icon" title="Delete"
                                    data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal">
                                    <i class="bi bi-trash"></i>
                                </button>

                            </div>
                        </td>
                    </tr>


                    <!-- Row 3 -->
                    <tr>
                        <td class="px-3">
                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                                PRJ-SPK-01
                            </span>
                        </td>

                        <td>
                            <div class="fw-semibold">
                                SPK Commercial Complex & Plaza
                            </div>
                            <small class="text-muted">
                                <i class="bi bi-geo-alt"></i>
                                G.N Chetty Road, T. Nagar, Chennai
                            </small>
                        </td>

                        <td>
                            <i class="bi bi-building text-muted me-1"></i>
                            <span class="fw-semibold small">
                                SPK And Co., - VF
                            </span>
                        </td>

                        <td>
                            <span class="badge rounded-pill bg-light text-dark border">
                                <i class="bi bi-stack text-primary me-1"></i>
                                6 Units
                            </span>
                        </td>

                        <td>
                            <span class="badge bg-light text-dark border text-start">
                                Vanguard Piling & Foundation...
                            </span>
                        </td>

                        <td class="small">2026-01-10</td>

                        <td class="small">2027-04-15</td>

                        <td class="fw-semibold">₹35.00 Cr</td>

                        <td>
                            <span class="badge rounded-pill bg-info-subtle text-primary border border-info-subtle">
                                In Progress
                            </span>
                        </td>

                        <td>
                            <div class="d-flex justify-content-center align-items-center gap-2">
                                <button type="button" class="action-icon view-icon" title="Profile View"
                                    onclick="window.location.href='{{ route('sitelog.manage_project.view') }}'">
                                    <i class="bi bi-eye"></i>
                                </button>


                                <button type="button" class="action-icon edit-icon" title="Edit" data-bs-toggle="modal"
                                    data-bs-target="#editProjectModal">
                                    <i class="bi bi-pencil"></i>
                                </button>

                                <button type="button" class="action-icon delete-icon" title="Delete"
                                    data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal">
                                    <i class="bi bi-trash"></i>
                                </button>

                            </div>
                        </td>
                    </tr>


                    <!-- Row 4 -->
                    <tr>
                        <td class="px-3">
                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                                PRJ-TNRDC-05
                            </span>
                        </td>

                        <td>
                            <div class="fw-semibold">
                                East Coast Road Elevated Bypass Bridge
                            </div>
                            <small class="text-muted">
                                <i class="bi bi-geo-alt"></i>
                                ECR Kovalam Junction, Kanchipuram
                            </small>
                        </td>

                        <td>
                            <i class="bi bi-building text-muted me-1"></i>
                            <span class="fw-semibold small">
                                Tamil Nadu Road Develop...
                            </span>
                        </td>

                        <td>
                            <span class="badge rounded-pill bg-light text-dark border">
                                <i class="bi bi-stack text-primary me-1"></i>
                                22 Units
                            </span>
                        </td>

                        <td>
                            <div class="d-flex flex-column gap-1">
                                <span class="badge bg-light text-dark border text-start">
                                    Apex Structural Sub-Contractor
                                </span>
                                <span class="badge bg-light text-dark border text-start">
                                    Vanguard Piling & Foundation...
                                </span>
                            </div>
                        </td>

                        <td class="small">2026-03-01</td>

                        <td class="small">2028-06-30</td>

                        <td class="fw-semibold">₹62.00 Cr</td>

                        <td>
                            <span
                                class="badge rounded-pill bg-warning-subtle text-warning border border-warning px-2 py-1">
                                Planning
                            </span>

                        </td>

                        <td>
                            <div class="d-flex justify-content-center align-items-center gap-2">
                                <button type="button" class="action-icon view-icon" title="Profile View"
                                    onclick="window.location.href='{{ route('sitelog.manage_project.view') }}'">
                                    <i class="bi bi-eye"></i>
                                </button>

                                <button type="button" class="action-icon edit-icon" title="Edit" data-bs-toggle="modal"
                                    data-bs-target="#editProjectModal">
                                    <i class="bi bi-pencil"></i>
                                </button>

                                <button type="button" class="action-icon delete-icon" title="Delete"
                                    data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal">
                                    <i class="bi bi-trash"></i>
                                </button>

                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
    {{-- Create Project Modal --}}
    @include('content.sitelog.manage_project.modal.create-project')
    {{-- Edit Project Modal --}}
    @include('content.sitelog.manage_project.modal.edit-project')
    {{-- Delete Project Modal --}}
    @include('content.sitelog.manage_project.modal.delete-confirmation-modal')
</div>


<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
body {
    background: #f5f7fa;
    font-family: 'Inter', sans-serif;
    color: #14213d;
}

.card {
    border: 1px solid #e2e8f0 !important;
}

.table {
    font-size: 12px;
}

.table thead th {
    font-size: 10px;
    letter-spacing: .3px;
    color: #64748b;
    white-space: nowrap;
    background: #f8fafc;
}

.table tbody td {
    white-space: nowrap;
    border-color: #edf1f5;
    padding-top: 12px;
    padding-bottom: 12px;
}

.table tbody tr:hover {
    background-color: #f8fbff;
}

.btn-primary {
    background-color: #0868ad;
    border-color: #0868ad;
}

.btn-outline-primary {
    color: #0868ad;
    border-color: #b8d5eb;
    background: #f8fcff;
}

.btn-outline-primary:hover {
    background: #0868ad;
    border-color: #0868ad;
}

.bg-primary-subtle {
    background-color: #eaf5ff !important;
}

.text-primary {
    color: #0868ad !important;
}

.badge {
    font-weight: 500;
}

.input-group-text,
.form-control {
    border-color: #dbe3ec;
}

.form-control:focus {
    box-shadow: none;
    border-color: #86b7fe;
}

.action-icon {
    border: none !important;
    background: transparent !important;
    padding: 4px;
    margin: 0;
    box-shadow: none !important;
    outline: none !important;
    cursor: pointer;
}

/* Edit icon */
.edit-icon {
    color: #2563eb !important;
}

/* Delete icon */
.delete-icon {
    color: #ef4444 !important;
}

.view-icon {
    color: #0891b2 !important;
}

/* Icon size */
.action-icon i {
    font-size: 14px;
}
</style>
@endsection