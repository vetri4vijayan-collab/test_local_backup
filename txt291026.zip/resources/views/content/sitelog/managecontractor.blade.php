@extends('layouts/layoutMaster')

@section('title', 'Contractor')

@section('content')
<style>
  /* Hide cursor globally except inside input fields */
  * {
    caret-color: transparent !important;
  }
  input, textarea, select {
    caret-color: auto !important;
  }
</style>

<div id="contractorlist">
  <div class="card rounded">
      <div class="d-flex justify-content-between p-3">
          <div class="d-flex gap-3 align-items-center">
              <i class="mdi mdi-office-building text-primary fs-4"></i>

              <div class="d-flex flex-column">
                  <label class="text-primary fw-bold mb-1 text-uppercase">Contractor</label>

                  <span class="text-muted fw-semibold">
                      Site Operations Management & Logs
                  </span>
              </div>
          </div>
          <div>
            <button
                type="button"
                class="btn btn-primary d-flex align-items-center gap-2"
                onclick="showAddContractor()"
            >
                <i class="mdi mdi-plus"></i>
                Add Contractor
            </button>
          </div>
      </div>
  </div>

  <div class="card rounded shadow-sm mt-3">
      <div class="card-body p-4">
          <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <span>Show</span>
                <select id="perpage" class="form-select form-select-sm w-75px"
                    onchange="loadThemes(1)">
                        @php $options = [5,10, 25, 100, 500]; @endphp
                        @foreach ($options as $option)
                        <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                         {{ $option }}
                        </option>
                        @endforeach
                </select>
            </div>
              <div class="position-relative mt-4" style="max-width: 500px; width: 100%;">
                  <i class="mdi mdi-magnify position-absolute top-50 start-0 translate-middle-y ms-3 text-muted fs-5"></i>
                  <input
                      type="search"
                      class="form-control ps-5 rounded"
                      placeholder="Search by contractor name, contact, GST, PAN, address..." id="search_filter"
                  />
              </div>
              <div class="d-flex align-items-center gap-2 mt-4">
                  <label for="tradeFilter" class="fw-semibold text-nowrap mb-0">
                      Filter by trade:
                  </label>

                  <select id="tradeFilter" class="form-select" style="min-width: 220px;">
                      <option value="">All Trades</option>
                       @foreach ($contract_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->contractor_type}}</option> 
                       @endforeach
                  </select>
              </div>
          </div>

          <div class="table-responsive rounded">
              <table class="table border table-hover align-middle mb-0">
                  <thead class="table-light">
                      <tr>
                          <th class="text-dark text-uppercase fs-8">Contractor Name</th>
                          <th class="text-dark text-uppercase fs-8">Type & Trade</th>
                          <th class="text-dark text-uppercase fs-8">Contact Person</th>
                          <th class="text-dark text-uppercase fs-8">City & Statect</th>
                          <th class="text-dark text-uppercase fs-8">PAN / GST No</th>
                          <th class="text-dark text-uppercase fs-8">Bank / Account No</th>
                          <th class="text-dark text-uppercase fs-8">Status</th>
                          <th class="text-dark text-uppercase fs-8 text-center">Action</th>
                      </tr>
                  </thead>
                  <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                        <tr class="skeleton-loader" id="skeleton-loader">
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                        </tr> 
                    </tbody>

              </table>
          </div>
          <div class="text-center my-3" id="pagination-container">
            <!-- Pagination buttons will appear here -->
        </div>
      </div>
  </div>
</div>

<!-- add contractor -->
  <div id="addContractor" class="d-none">
    <div class="card rounded shadow-sm mt-3">
      <div class="card-header bg-white border-bottom py-3">
          <div class="d-flex justify-content-between align-items-center">
              <div class="d-flex align-items-center gap-2">
                  <button
                      type="button"
                      class="btn"
                      title="Back"
                      onclick="showContractorList()"
                  >
                      <i class="mdi mdi-chevron-double-left"></i>
                  </button>

                  <div>
                      <h6 class="mb-0 text-dark fw-bold text-uppercase">
                          Add Contractor
                      </h6>
                  </div>
              </div>


          </div>
      </div>
    <form action="{{ route('add_contractor') }}"method="POST" enctype="multipart/form-data" autocomplete="off" id="addcontractorForm">
      @csrf
      <div class="card-body p-4">
          <div class="row g-4 border-b mb-4">
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Contractor Type
                      <span class="text-danger">*</span>
                  </label>
                  <select class="form-select" id="contract_type" name="contract_type">
                      <option value="">Select Contractor Type</option>
                       @foreach ($contract_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->contractor_type}}</option> 
                       @endforeach
                  </select>
                  <div class="text-danger" id="contract_type_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Name of the Company
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="e.g. AquaLine Plumbing Works" id="contract_company_name" name="contract_company_name"
                  />
                  <div class="text-danger" id="contract_company_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Contract Name
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="Enter Contract Name" id="contract_name" name="contract_name"
                  />
              </div>
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Country
                      <span class="text-danger">*</span>
                  </label>
                  <select id="country_id" name="country_id" class="form-select" onchange="countrychange()">
                      <option value="">Select Country</option>
                       @foreach ($country_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->country_name}}</option> 
                       @endforeach
                  </select>
                  <div class="text-danger" id="country_id_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      State
                      <span class="text-danger">*</span>
                  </label>

                  <select id="state_id" name="state_id" class="form-select" onchange="statechange()">
                      <option value="">Select State</option>
                       
                  </select>
                  <div class="text-danger" id="state_id_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      City
                      <span class="text-danger">*</span>
                  </label>

                  <select id="city_id" name="city_id" class="form-select">
                      <option value="">Select City</option>
                       
                  </select>
                  <div class="text-danger" id="city_id_err"></div>
              </div>

              <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Address (Door no. / Area)
                </label>
                <textarea
                    class="form-control"
                    rows="1"
                    placeholder="Enter client address" id="address" name="address"
                ></textarea>
            </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Pincode
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="625001" id="pin_code" name="pin_code"
                  />
                  <div class="text-danger" id="pin_code_err"></div>
              </div>

              <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    PAN NO<span class="text-danger">*</span>
                </label>
                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. ABCDE1234F" id="pan_number" name="pan_number"
                />
                <div class="text-danger" id="pan_number_err"></div>
            </div>

              <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    GST NO<span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="e.g. 33ABCDE1234F1Z5" id="gst_number" name="gst_number"
                />
                <div class="text-danger" id="gst_number_err"></div>
            </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Aadhar No
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="4444 5555 6666" id="aadhar_no" name="aadhar_no"
                  />
                  <div class="text-danger" id="aadhar_no_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      ESI No
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="ESI400500600" id="esi_no" name="esi_no"
                  />
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      EPF No
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="EPF400500600" id="epf_no" name="epf_no"
                  />
              </div>
          </div>

          <div id="personcontainer">
              <div class="mb-3">
                  <label class="text-black fw-bold fs-5">Primary</label>
              </div>
              <div class="row g-4 person-row">
                    <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Person Type
                          <span class="text-danger">*</span>
                      </label>

                      <select class="form-select" id="prmy_person_type" name="persons[0][person_type]">
                          <option value="">Commercial/Technical</option>
                          <option value="1">Commercial Admin</option>
                          <option value="2">Technical lead</option>
                          <option value="3">Site Representative</option>
                      </select>
                      <div class="text-danger" id="prmy_person_type_err"></div>
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Person Name
                          <span class="text-danger">*</span>
                      </label>

                      <input
                          type="text"
                          class="form-control"
                          placeholder="salvam(supervisor)" id="prmy_person_name" name="persons[0][person_name]"
                      />
                      <div class="text-danger" id="prmy_person_name_err"></div>
                  </div>

                  <!-- Contact Number -->
                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Mobile No
                          <span class="text-danger">*</span>
                      </label>

                      <input
                          type="tel"
                          class="form-control"
                          placeholder="98765 43210" id="prmy_person_number" name="persons[0][person_number]"
                      />
                      <div class="text-danger" id="prmy_person_number_err"></div>
                  </div>

                  <!-- Email -->
                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Email
                      </label>

                      <input
                          type="email"
                          class="form-control"
                          placeholder="salvam@example.com" id="prmy_person_email" name="persons[0][person_email]"
                      />
                      <div class="text-danger" id="prmy_person_email_err"></div>
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Telephone No
                      </label>

                      <input
                          type="text"
                          class="form-control"
                          placeholder="0452-2698712" id="prmy_person_teleno" name="persons[0][person_teleno]"
                      />
                  </div>
              </div>
          </div>

          <div class="d-flex justify-content-end align-align-items-end mt-12">
            <button type="button" class="btn" onclick="addperson()">
              <i class="mdi mdi-plus border rounded p-1"></i>
            </button>
          </div>
          <div class="mt-12 pt-4 border-top" id="bankcontainer">
              <div class="mb-3">
                <label class="text-black fw-bold fs-5 mb-2">Primary Bank Details</label><br>
                <label class="text-black fw-semibold fs-6">Details for Making Payment by NEFT
                  / RTGS, with the NEFT / RTGS bank charges to Suppliers' / Contractors' Account
                </label>
              </div>

              <div class="row g-4 border-b mb-4 bank-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Name
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="IOB" id="prmy_bank_name" name="banks[0][bank_name]"
                    />
                    <div class="text-danger" id="prmy_bank_name_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Branch
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="South avani moola street" id="prmy_bank_branch" name="banks[0][bank_branch]"
                    />
                    <div class="text-danger" id="prmy_branch_err"></div>
                </div>
                <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Country
                      <span class="text-danger">*</span>
                  </label>
                  <select id="prmy_bank_country_id" name="banks[0][bank_country]" class="form-select" onchange="bankcountrychange()">
                      <option value="">Select Country</option>
                       @foreach ($country_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->country_name}}</option> 
                       @endforeach
                  </select>
                  <div class="text-danger" id="prmy_bank_country_id_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      State
                      <span class="text-danger">*</span>
                  </label>

                  <select id="prmy_bank_state_id" name="banks[0][bank_state]" class="form-select" onchange="bankstatechange()">
                      <option value="">Select State</option>
                       
                  </select>
                  <div class="text-danger" id="prmy_bank_state_id_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      City
                      <span class="text-danger">*</span>
                  </label>

                  <select id="prmy_bank_city_id" name="banks[0][bank_city]" class="form-select">
                      <option value="">Select City</option>
                       
                  </select>
                  <div class="text-danger" id="prmy_bank_city_id_err"></div>
              </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Address
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="South avani moola street" id="prmy_bank_address" name="banks[0][bank_address]"
                    />
                    <div class="text-danger" id="prmy_bank_address_err"></div>
                </div>
                <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Bank Pincode
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      class="form-control"
                      placeholder="625001" id="prmy_bank_pin_code" name="banks[0][bank_pincode]"
                  />
                  <div class="text-danger" id="prmy_bank_pin_code_err"></div>
              </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Name
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="Aqualine plumbing works" id="prmy_acc_name" name="banks[0][bank_acc_name]"
                    />
                    <div class="text-danger" id="prmy_acc_name_err"></div>
                </div>
                 

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Type
                        <span class="text-danger">*</span>
                    </label>

                    <select class="form-select" id="prmy_acc_type" name="banks[0][bank_acc_type]">
                         <option value="">Select Account Type</option>
                      <option value="1">Current Account</option>
                      <option value="2">Saveing Account</option>
                      <option value="3">OverDraft</option>
                  </select>
                  <div class="text-danger" id="prmy_acc_type_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Number
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="444455556666" id="prmy_acc_no" name="banks[0][bank_acc_number]"
                    />
                    <div class="text-danger" id="prmy_acc_no_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        MICR Code of Bank
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="625020005" id="prmy_bank_micr" name="banks[0][bank_micr]"
                    />
                    <div class="text-danger" id="prmy_bank_micr_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        IFSC / RTGS Code No. of the Bank
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="IOBA0000789" id="prmy_bank_ifsc" name="banks[0][bank_ifsc]"
                    />
                    <div class="text-danger" id="prmy_bank_ifsc_err"></div>
                </div>
              </div>
          </div>

          <div class="d-flex justify-content-end align-align-items-end mt-12">
            <button type="button" class="btn" onclick="addbank()">
              <i class="mdi mdi-plus border rounded p-1"></i>
            </button>
          </div>
      </div>

      <div class="card-footer bg-white border-top d-flex justify-content-end gap-2 py-3">
        <button
            type="button"
            class="btn btn-outline-secondary"
            onclick="showContractorList()"
        >
            Cancel
        </button>

        <button
            type="button"
            class="btn btn-primary" id="submitcontractor" onclick="AddValidation()">
            Save Contractor
        </button>
      </div>
    </form>
    </div>
  </div>

<!-- update contractor -->
  <div id="updateContractor" class="d-none">
    <div class="card rounded shadow-sm mt-3">
      <div class="card-header bg-white border-bottom py-3">
          <div class="d-flex justify-content-between align-items-center">
              <div class="d-flex align-items-center gap-2">
                  <button
                      type="button"
                      class="btn"
                      title="Back"
                      onclick="showContractorList()"
                  >
                      <i class="mdi mdi-chevron-double-left"></i>
                  </button>

                  <div>
                      <h6 class="mb-0 text-dark fw-bold text-uppercase">
                          Update Contractor
                      </h6>
                  </div>
              </div>

              <div>
                  <span id="updateSystemCode">
                      System Code: CON-0003
                  </span>
              </div>

          </div>
      </div>

      <div class="card-body p-4">
          <div class="row g-4 border-b mb-4">
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Contractor Type
                      <span class="text-danger">*</span>
                  </label>

                  <select id="updateContractorType" name="updateContractorType" class="form-select">
                      <option value="">Select Contractor Type</option>
                      @foreach ($contract_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->contractor_type}}</option> 
                       @endforeach
                  </select>
                  <div class="text-danger" id="updateContractorType_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                  Name of the Company
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateContractorCompany" name="updateContractorCompany"
                      class="form-control"
                      placeholder="e.g. AquaLine Plumbing Works"
                  />
                  <div class="text-danger" id="updateContractorCompany_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Contract Name
                  </label>

                  <input
                      type="text"
                      id="updateContractName" name="updateContractName"
                      class="form-control"
                      placeholder="Enter Contract Name"
                  />
                  <div class="text-danger" id="updateContractName_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Country
                      <span class="text-danger">*</span>
                  </label>
                  <select id="updateCountry" name="updateCountry" class="form-select" onchange="update_country_change()">
                      <option value="">Select Country</option>
                       @foreach ($country_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->country_name}}</option> 
                       @endforeach
                  </select>
                  <div class="text-danger" id="updateCountry_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      State
                      <span class="text-danger">*</span>
                  </label>

                  <select id="updateState" name="updateState" class="form-select" onchange="update_state_change()">
                      <option value="">Select State</option>
                       
                  </select>
                  <div class="text-danger" id="updateState_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      City
                      <span class="text-danger">*</span>
                  </label>

                  <select id="updateCity" name="updateCity" class="form-select">
                      <option value="">Select City</option>
                       
                  </select>
                  <div class="text-danger" id="updateCity_err"></div>
              </div>

              <div class="col-md-4">
                <label class="form-label fw-semibold text-dark">
                    Address (Door no. / Area)
                </label>
                <textarea
                    class="form-control"
                    rows="1"
                    placeholder="Enter client address" id="updateAddress" name="updateAddress"
                ></textarea>
                <div class="text-danger" id="updateAddress_err"></div>
            </div>

              
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Pincode
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updatePincode" name="updatePincode"
                      class="form-control"
                      placeholder="625001"
                  />
                  <div class="text-danger" id="updatePincode_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      PAN NO
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updatePan" name="updatePan"
                      class="form-control"
                      placeholder="ABXFS5510P"
                  />
                  <div class="text-danger" id="updatePan_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      GST NO
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateGst" name="updateGst"
                      class="form-control"
                      placeholder="33ABXFS5510P1ZG"
                  />
                  <div class="text-danger" id="updateGst_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Aadhar No
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updateAadhar" name="updateAadhar"
                      class="form-control"
                      placeholder="4444 5555 6666"
                  />
                  <div class="text-danger" id="updateAadhar_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      ESI No
                  </label>

                  <input
                      type="text"
                      id="updateEsi" name="updateEsi"
                      class="form-control"
                      placeholder="ESI400500600"
                  />
                  
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      EPF No
                  </label>

                  <input
                      type="text"
                      id="updateEpf" name="updateEpf"
                      class="form-control"
                      placeholder="EPF400500600"
                  />
              </div>
          </div>

          <div id="updatepersoncontainer">
            <div class="mb-3">
                <label class="text-black fw-bold fs-5">Primary</label>
            </div>
            <div class="row g-4 person-row">
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Person Type
                      <span class="text-danger">*</span>
                  </label>

                  <select id="updatePersonType" name="updatePersonType" class="form-select">
                    <option value="">Commercial/Technical</option>
                    <option value="1">Commercial Admin</option>
                    <option value="2">Technical Lead</option>
                    <option value="3">Site Representative</option>
                </select>
                <div class="text-danger" id="updatePersonType_err"></div>
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Person Name
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="text"
                      id="updatePersonName" name="updatePersonName"
                      class="form-control"
                      placeholder="Selvam (Supervisor)"
                  />
                  <div class="text-danger" id="updatePersonName_err"></div>
              </div>

              <!-- Contact Number -->
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Mobile No
                      <span class="text-danger">*</span>
                  </label>

                  <input
                      type="tel"
                      id="updateMobile" name="updateMobile"
                      class="form-control"
                      placeholder="98765 43210"
                  />
                  <div class="text-danger" id="updateMobile_err"></div>
              </div>

              <!-- Email -->
              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Email
                  </label>

                  <input
                      type="email"
                      id="updateEmail" name="updateEmail"
                      class="form-control"
                      placeholder="selvam@example.com"
                  />
               
              </div>

              <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Telephone No
                  </label>

                  <input
                      type="text"
                      id="updateTelephone"
                      class="form-control"
                      placeholder="0452-2698712"
                  />
              </div>
            </div>
          </div>

          <div class="d-flex justify-content-end align-items-end mt-4">
              <button
                  class="btn"
                  type="button"
                  onclick="updatecontractor()"
              >
                  <i class="mdi mdi-plus border rounded p-1"></i>
              </button>
          </div>

          <div class="mt-12 pt-4 border-top" id="updatebankcontainer">
            <div class="mb-3">
              <label class="text-black fw-bold fs-5 mb-2">Primary Bank Details</label><br>
              <label class="text-black fw-semibold fs-6">Details for Making Payment by NEFT
                / RTGS, with the NEFT / RTGS bank charges to Suppliers' / Contractors' Account
              </label>
            </div>
              <div class="row g-4 border-b mb-4 bank-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Name
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankName" name="updateBankName" type="text" class="form-control">
                    <div class="text-danger" id="updateBankName_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Branch
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankBranch" name="updateBankBranch" type="text" class="form-control">
                    <div class="text-danger" id="updateBankBranch_err"></div>
                </div>

                <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Country
                      <span class="text-danger">*</span>
                  </label>
                  <select id="updateBankCountry" name="updateBankCountry" class="form-select" onchange="update_bank_country()">
                      <option value="">Select Country</option>
                       @foreach ($country_list as $i=> $list) 
                      <option value="{{$list->sno}}" >{{$list->country_name}}</option> 
                       @endforeach
                  </select>
                  <div class="text-danger" id="updateBankCountry_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      State
                      <span class="text-danger">*</span>
                  </label>

                  <select id="updateBankState" name="updateBankState" class="form-select" onchange="update_bank_state()">
                      <option value="">Select State</option>
                       
                  </select>
                  <div class="text-danger" id="updateBankState_err"></div>
              </div>
            <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      City
                      <span class="text-danger">*</span>
                  </label>

                  <select id="updateBankCity" name="updateBankCity" class="form-select">
                      <option value="">Select City</option>
                       
                  </select>
                  <div class="text-danger" id="updateBankCity_err"></div>
              </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Address
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateBankAddress" name="updateBankAddress" type="text" class="form-control"/>
                    <div class="text-danger" id="updateBankAddress_err"></div>
                </div>
                <div class="col-md-4">
                  <label class="form-label fw-semibold text-dark">
                      Bank Pincode
                      <span class="text-danger">*</span>
                  </label>
                  <input
                      type="text"
                      class="form-control"
                      placeholder="625001" id="updateBankPincode" name="updateBankPincode"
                  />
                  <div class="text-danger" id="updateBankPincode_err"></div>
              </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Name
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateAccountName" name="updateAccountName" type="text" class="form-control">
                    <div class="text-danger" id="updateAccountName_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Type
                        <span class="text-danger">*</span>
                    </label>

                    <select id="updateAccountType" name="updateAccountType" class="form-select">
                        <option value="">Select Account Type</option>
                        <option value="1">Current Account</option>
                        <option value="2">Saving Account</option>
                        <option value="3">OverDraft</option>
                    </select>
                    <div class="text-danger" id="updateAccountType_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Bank Account Number
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateAccountNumber" name="updateAccountNumber" type="text" class="form-control">
                    <div class="text-danger" id="updateAccountNumber_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        MICR Code of Bank
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateMicr" name="updateMicr" type="text" class="form-control">
                    <div class="text-danger" id="updateMicr_err"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        IFSC / RTGS Code No. of the Bank
                        <span class="text-danger">*</span>
                    </label>

                    <input id="updateIfsc" name="updateIfsc" type="text" class="form-control">
                    <div class="text-danger" id="updateIfsc_err"></div>
                </div>
              </div>
          </div>

          <div class="d-flex justify-content-end align-items-end mt-4">
            <button type="button" class="btn" onclick="addUpdateBank()">
              <i class="mdi mdi-plus border rounded p-1"></i>
            </button>
          </div>
      </div>

      <div class="card-footer bg-white border-top d-flex justify-content-end gap-2 py-3">
        <button
            type="button"
            class="btn btn-outline-secondary"
            onclick="showContractorList()"
        >
            Cancel
        </button>

        <button
            type="button"
            class="btn btn-primary" id="saveupdatecontractor" onclick="saveUpdateContract()"
        >
            Save Contractor
        </button>
      </div>
    </div>
  </div>

<!-- view Contractor -->
  <div class="modal fade" id="viewContractorModal" tabindex="-1" aria-labelledby="viewContractorModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header border-bottom">
                <h5 class="modal-title mb-4" id="viewContractorModalLabel">
                    Contractor Details
                </h5>

                <button
                    type="button"
                    class="btn-close mb-4"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Contractor Code
                        </label>
                        <div class="fw-semibold" id="viewContractorCode">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Type
                        </label>
                        <div class="fw-semibold" id="viewContractorType">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Contractor Name
                        </label>
                        <div class="fw-semibold" id="viewContractorName">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Contact Person
                        </label>
                        <div class="fw-semibold" id="viewContactPerson">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Contact Number
                        </label>
                        <div class="fw-semibold" id="viewContactNo">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            Email
                        </label>
                        <div class="fw-semibold" id="viewEmail">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            PAN
                        </label>
                        <div class="fw-semibold" id="viewPan">-</div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-muted">
                            GST
                        </label>
                        <div class="fw-semibold" id="viewGst">-</div>
                    </div>

                    <div class="col-12">
                        <label class="form-label text-muted">
                            Address
                        </label>
                        <div class="fw-semibold" id="viewAddress">-</div>
                    </div>
                </div>

                <div class="border rounded mb-4 mt-4">
                  <div class="d-flex align-items-center mb-3 p-2">
                      <i class="mdi mdi-bank-outline fs-5 text-primary me-2"></i>
                      <h6 class="mb-0 fw-semibold">Bank Details</h6>
                  </div>

                  <div class="table-responsive">
                      <table class="table align-middle mb-0">
                          <tbody>
                              <tr class="border-top">
                                  <td class="text-muted fw-medium py-3" style="width: 40%;">
                                      Bank Name
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankName">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Account Name
                                  </td>
                                  <td class="fw-semibold py-3" id="viewAccountName">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Account Number
                                  </td>
                                  <td class="fw-semibold py-3" id="viewAccountNo">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      IFSC Code
                                  </td>
                                  <td class="fw-semibold py-3" id="viewIfsc">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Branch
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankBranch">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Address
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankAddress">
                                      -
                                  </td>
                              </tr>
                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Country
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankCountry">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      State
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankState">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      City
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankCity">
                                      -
                                  </td>
                              </tr>

                              <tr>
                                  <td class="text-muted fw-medium py-3">
                                      Pincode
                                  </td>
                                  <td class="fw-semibold py-3" id="viewBankPincode">
                                      -
                                  </td>
                              </tr>
                          </tbody>
                      </table>
                  </div>
                </div>
            </div>
        </div>
    </div>
  </div>

<!-- delete contractor -->
  <div class="modal fade" id="deleteContractorModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content border-0 rounded-4 shadow w-100" style="max-width: 400px">
              <div class="modal-body text-center p-4">
                  <div
                      class="d-flex align-items-center justify-content-center rounded-circle mx-auto mb-3"
                      style="
                          width: 48px;
                          height: 48px;
                          background-color: #fff0f1;
                          color: #ff3e5b;
                      "
                  >
                      <i class="mdi mdi-trash-can-outline fs-4"></i>
                  </div>

                  <h5 class="fw-bold text-dark mb-2">
                      Confirm Deletion
                  </h5>
                  <p class="text-muted small mb-4" id="delete_message">
                    
                  </p>
                  <div class="row g-2">
                      <div class="col-6">
                          <button
                              type="button"
                              class="btn btn-light w-100"
                              data-bs-dismiss="modal"
                          >
                              Cancel
                          </button>
                      </div>

                      <div class="col-6">
                          <button
                              type="button"
                              class="btn btn-danger w-100" onclick="deletelevel()"
                          >
                              Delete
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

<!-- add contractor -->

<script>
    function AddValidation() {
            let err=0;  
            var contract_type=$('#contract_type').val();
            var contract_company_name=$('#contract_company_name').val();
            var contract_name=$('#contract_name').val();
            var country_id=$('#country_id').val();
            var state_id=$('#state_id').val();
            var city_id=$('#city_id').val();
            var address=$('#address').val();
            var pin_code=$('#pin_code').val();
            var pan_number=$('#pan_number').val();
            var gst_number=$('#gst_number').val();
            var aadhar_no=$('#aadhar_no').val();
            var esi_no=$('#esi_no').val();
            var epf_no=$('#epf_no').val();
            var primary_person_type=$('#prmy_person_type').val().trim();
            var primary_person_name=$('#prmy_person_name').val().trim();
            var primary_person_number=$('#prmy_person_number').val().trim();
            var primary_person_email=$('#prmy_person_email').val().trim();
            var primary_person_teleno=$('#prmy_person_teleno').val().trim();
            var secondary_person_type=$('#sec_person_type').val();
            var secondary_person_name=$('#sec_person_name').val();
            var secondary_person_number=$('#sec_person_number').val();
            var secondary_person_email=$('#sec_person_email').val();
            var secondary_person_teleno=$('#sec_person_teleno').val();
            var primary_bank_name=$('#prmy_bank_name').val();
            var primary_bank_branch=$('#prmy_bank_branch').val();
            var primary_bank_address=$('#prmy_bank_address').val();
            var primary_acc_name=$('#prmy_acc_name').val();
            var primary_acc_type=$('#prmy_acc_type').val();
            var primary_acc_no=$('#prmy_acc_no').val();
            var primary_bank_micr=$('#prmy_bank_micr').val();
            var primary_bank_ifsc=$('#prmy_bank_ifsc').val();
            var primary_bank_country_id=$('#prmy_bank_country_id').val();
            var primary_bank_state_id=$('#prmy_bank_state_id').val();
            var primary_bank_city_id=$('#prmy_bank_city_id').val();
            var primary_bank_pin_code=$('#prmy_bank_pin_code').val();
       
            $('.secondary-person').each(function () {
            const row = $(this);

            const type = row.find('[name$="[person_type]"]');
            const name = row.find('[name$="[person_name]"]');
            const mobile = row.find('[name$="[person_number]"]');
            const email = row.find('[name$="[person_email]"]');
            const teleno = row.find('[name$="[person_teleno]"]');

            row.find('.person-type-error, .person-name-error, .person-number-error, .person-email-error')
                    .text('');

            if (!type.val()) {
                type.siblings('.person-type-error').text('Person Type is required');
            err++;
            }

            if (!name.val().trim()) {
                name.siblings('.person-name-error').text('Person Name is required');
                err++;
            }

            if (!mobile.val().trim()) {
                mobile.siblings('.person-number-error').text('Mobile No is required');
                err++;
            }

            if (email.val().trim() &&
                !/^\S+@\S+\.\S+$/.test(email.val().trim())) {
                email.siblings('.person-email-error').text('Enter a valid email');
                err++;
            }
        });


             $('.secondary-bank').each(function () {
                const row = $(this);
                const bankName = row.find('[name$="[bank_name]"]');
                const branch = row.find('[name$="[bank_branch]"]');
                const country = row.find('[name$="[bank_country]"]');
                const state = row.find('[name$="[bank_state]"]');
                const city = row.find('[name$="[bank_city]"]');
                const address = row.find('[name$="[bank_address]"]');
                const pin = row.find('[name$="[bank_pincode]"]');
                const accName = row.find('[name$="[bank_acc_name]"]');
                const accType = row.find('[name$="[bank_acc_type]"]');
                const accNo = row.find('[name$="[bank_acc_number]"]');  
                const micr = row.find('[name$="[bank_micr]"]');
                const ifsc = row.find('[name$="[bank_ifsc]"]');

                row.find(
                    '.bank-name-error, .bank-branch-error, .bank-country-error, ' +
                    '.bank-state-error, .bank-city-error, .bank-address-error, ' +
                    '.bank-pin-error, .bank-acc-name-error, .bank-acc-type-error, ' +
                    '.bank-acc-no-error, .bank-micr-error, .bank-ifsc-error'
                ).text('');

                if (!bankName.val().trim()) {
                    row.find('.bank-name-error').text('Bank Name is required');
                    err++;
                }

                if (!branch.val().trim()) {
                    row.find('.bank-branch-error').text('Bank Branch is required');
                    err++;
                }

                if (!country.val()) {
                    row.find('.bank-country-error').text('Country is required');
                    err++;
                }

                if (!state.val()) {
                    row.find('.bank-state-error').text('State is required');
                    err++;
                }

                if (!city.val()) {
                    row.find('.bank-city-error').text('City is required');
                    err++;
                }

                if (!address.val().trim()) {
                    row.find('.bank-address-error').text('Bank Address is required');
                    err++;
                }

                if (!pin.val().trim()) {
                    row.find('.bank-pin-error').text('Bank Pincode is required');
                    err++;
                } else if (!/^\d{6}$/.test(pin.val().trim())) {
                    row.find('.bank-pin-error').text('Pincode must be 6 digits');
                    err++;
                }

                if (!accName.val().trim()) {
                    row.find('.bank-acc-name-error').text('Account Name is required');
                    err++;
                }

                if (!accType.val()) {
                    row.find('.bank-acc-type-error').text('Account Type is required');
                    err++;
                }

                if (!accNo.val().trim()) {
                    row.find('.bank-acc-no-error').text('Account Number is required');
                    err++;
                }

                if (!micr.val().trim()) {
                    row.find('.bank-micr-error').text('MICR Code is required');
                    err++;
                }

                if (!ifsc.val().trim()) {
                    row.find('.bank-ifsc-error').text('IFSC Code is required');
                    err++;
                }
            });
            
             
            if(contract_type == ""){
                $('#contract_type_err').text('Contractor type is required')
                err++
            }
            if(contract_company_name == ""){
                $('#contract_company_err').text('Contractor company name is required')
                err++
            }
            
            if(country_id == ""){
                $('#country_id_err').text('Country is required')
                err++
            }
            if(state_id == ""){
                $('#state_id_err').text('State is required')
                err++
            }
            if(city_id == ""){
                $('#city_id_err').text('City is required')
                err++
            }
            
            if(pin_code == ""){
                $('#pin_code_err').text('Pincode is required')
                err++
            }
            if(pan_number == ""){
                $('#pan_number_err').text('PAN Number is required')
                err++
            }
            if(gst_number == ""){
                $('#gst_number_err').text('GST Number is required')
                err++
            }
            if(pin_code == ""){
                $('#pin_code_err').text('Pincode is required')
                err++
            }
            if(pin_code != "" && pin_code.length!=6){
                $('#pin_code_err').text('Pincode Must be 6 digit')
                err++
            }
            if(aadhar_no == ""){
                $('#aadhar_no_err').text('Aadhar Number is required')
                err++
            }
            if (primary_person_email != '' && !/^\S+@\S+\.\S+$/.test(primary_person_email)) {
                 $('#prmy_person_email_err').text('Enter valid email')
                err++
            }
            if(primary_person_type == ""){
                $('#prmy_person_type_err').text('Person Type is required')
                err++
            }
            if(primary_person_name == ""){
                $('#prmy_person_name_err').text('Person Name is required')
                err++
            }
            if(primary_person_number == ""){
                $('#prmy_person_number_err').text('Mobile No is required')
                err++
            }
            
            if(primary_bank_name == ""){
                $('#prmy_bank_name_err').text('Bank Name is required')
                err++
            }
            if(primary_bank_branch == ""){
                $('#prmy_branch_err').text('Branch is required')
                err++
            }
            if(primary_bank_address == ""){
                $('#prmy_bank_address_err').text('Branch is required')
                err++
            }
            if(primary_bank_country_id == ""){
                $('#prmy_bank_country_id_err').text('Country is required')
                err++
            }
            if(primary_bank_state_id == ""){
                $('#prmy_bank_state_id_err').text('State is required')
                err++
            }
            if(primary_bank_city_id == ""){
                $('#prmy_bank_city_id_err').text('City is required')
                err++
            }
            if(primary_bank_pin_code == ""){
                $('#prmy_bank_pin_code_err').text('Pincode is required')
                err++
            }
            if(primary_acc_name == ""){
                $('#prmy_acc_name_err').text('Account Name is required')
                err++
            }
            if(primary_acc_type == ""){
                $('#prmy_acc_type_err').text('Account Type is required')
                err++
            }
            if(primary_acc_no == ""){
                $('#prmy_acc_no_err').text('Account Number is required')
                err++
            }
            if(primary_bank_micr == ""){
                $('#prmy_bank_micr_err').text('MICR Code is required')
                err++
            }
            if(primary_bank_ifsc == ""){
                $('#prmy_bank_ifsc_err').text('IFSC Code is required')
                err++
            }
            
            if (err>0){
            return false;
            }
            else{ 
                Addcontractor();
            }
}
function Addcontractor() {

        const reloadPage = tableState.currentPage;
        
        const form = document.getElementById("addcontractorForm");
        console.log(form);
        const submitBtn = document.getElementById("submitcontractor");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                 url: "{{ route('add_contractor') }}",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    toastr.success('Contractor Added successfully!');
                    window.location.href = '/site/contractor';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    toastr.error('Contractor Failed to Add!');
                    submitBtn.disabled = false;
                }
            });
        }
    }
</script>

<script>
        function countrychange() { 
            var countryId = $('#country_id').val();
            var stateDropdown = $('#state_id'); 
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('contactor_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        }   
                    } 
                }); 
            } 
        
        } 
            function statechange() { 
                var stateId = $('#state_id').val(); 
                var countryId = $('#country_id').val(); 
                var cityDropdown = $('#city_id'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('contractor_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                        } 
                    }); 
                } 
            } 

             
    </script>
<script>
        function bankcountrychange() { 
            console.log('hi');
            var countryId = $('#prmy_bank_country_id').val();
            var stateDropdown = $('#prmy_bank_state_id'); 
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('bank_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        }   
                    } 
                }); 
            } 
        
        } 
            function bankstatechange() { 
                var stateId = $('#prmy_bank_state_id').val(); 
                var countryId = $('#prmy_bank_country_id').val(); 
                var cityDropdown = $('#prmy_bank_city_id'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('bank_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                            
                        } 
                    }); 
                } 
            } 
            function bankCountryChange(element) {
                const bank = $(element).closest('.secondary-bank');
                const countryId = $(element).val();
                const stateDropdown = bank.find('.bank-state');
                const cityDropdown = bank.find('.bank-city');

                stateDropdown.html('<option value="">Select State</option>');
                cityDropdown.html('<option value="">Select City</option>');

                if (countryId) {
                    $.ajax({
                        url: "{{ route('bank_state_listing') }}",
                        type: "GET",
                        data: { country_id: countryId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append(
                                        $('<option></option>')
                                            .val(state.sno)
                                            .text(state.state_name)
                                    );
                                });
                            }
                        }
                    });
                }
            }
            function bankStateChange(element) {
                const bank = $(element).closest('.secondary-bank');
                const stateId = $(element).val();
                const countryId = bank.find('.bank-country').val();
                const cityDropdown = bank.find('.bank-city');

                cityDropdown.html('<option value="">Select City</option>');

                if (stateId) {
                    $.ajax({
                        url: "{{ route('bank_city_listing') }}",
                        type: "GET",
                        data: {
                            country_id: countryId,
                            state_id: stateId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append(
                                        $('<option></option>')
                                            .val(city.sno)
                                            .text(city.city_name)
                                    );
                                });
                            }
                        }
                    });
                }
            }


             
    </script>


  <script>
    function showAddContractor() {
        document.getElementById('contractorlist').classList.add('d-none');
        document.getElementById('addContractor').classList.remove('d-none');
        document.getElementById('updateContractor').classList.add('d-none');
    }

    function showContractorList() {
        document.getElementById('addContractor').classList.add('d-none');
        document.getElementById('updateContractor').classList.add('d-none');
        document.getElementById('contractorlist').classList.remove('d-none');
    }
  </script>

<!-- update contractor -->
  <script>
    
function showUpdateContractor(id) {
    global_state_id = null;
    global_city_id = null;
    global_bank_state_id = null;
    global_bank_city_id = null;
    currentCategoryId = id;

    // Remove previously rendered secondary records
    resetUpdatePersons();

    document.querySelectorAll(
        '#updatebankcontainer .secondary-bank'
    ).forEach(bank => bank.remove());

    fetch('/contractor_view/' + id, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status !== 200) {
            console.error(data.message || 'Contractor not found');
            return;
        }

        const com = data.data;
        console.log(com);

        // Contractor details
        $('#updateContractorType').val(com.contractor_type_id).change();
        $('#updateContractorCompany').val(com.contract_company_name);
        $('#updateSystemCode').text('System Code: ' + com.contractor_code);
        $('#updateContractName').val(com.contract_name);

        $('#updatePincode').val(com.pin_code);
        $('#updateAlternateContactNo').val(com.alter_contact_no);
        $('#updateAddress').val(com.address);

        $('#updateCountry').val(com.country_id).change();
        global_state_id = com.state_id;
        global_city_id = com.city_id;

        $('#updateGst').val(com.gst_number);
        $('#updatePan').val(com.pan_number);
        $('#updateAadhar').val(com.aadhar_no);
        $('#updateEsi').val(com.esi_no || '');
        $('#updateEpf').val(com.epf_no || '');

        // Decode JSON arrays if necessary
        const persons = Array.isArray(com.persons)
            ? com.persons
            : JSON.parse(com.persons || '[]');

        const banks = Array.isArray(com.banks)
            ? com.banks
            : JSON.parse(com.banks || '[]');

        // ----------------------------------
        // PRIMARY PERSON - index 0
        // ----------------------------------
        const primaryPerson = persons[0] || {};

        $('#updatePersonName').val(primaryPerson.person_name || '');
        $('#updatePersonType').val(primaryPerson.person_type || '');
        $('#updateMobile').val(primaryPerson.person_number || '');
        $('#updateEmail').val(primaryPerson.person_email || '');
        $('#updateTelephone').val(primaryPerson.person_teleno || '');

        // ----------------------------------
        // SECONDARY PERSONS - index 1 onwards
        // ----------------------------------
        persons.slice(1).forEach(function (person) {
            updatecontractor();

            const row = $('#updatepersoncontainer .secondary-person').last();

            row.find('[name$="[person_type]"]').val(person.person_type || '');
            row.find('[name$="[person_name]"]').val(person.person_name || '');
            row.find('[name$="[person_number]"]').val(person.person_number || '');
            row.find('[name$="[person_email]"]').val(person.person_email || '');
            row.find('[name$="[person_teleno]"]').val(person.person_teleno || '');
        });

        // Continue indexes after existing secondary persons
        updatePersonCount = persons.length;

        // ----------------------------------
        // PRIMARY BANK - index 0
        // ----------------------------------
        const primaryBank = banks[0] || {};

        $('#updateBankName').val(primaryBank.bank_name || '');
        $('#updateBankBranch').val(primaryBank.bank_branch || '');
        $('#updateBankAddress').val(primaryBank.bank_address || '');

        $('#updateBankCountry').val(primaryBank.bank_country || '').trigger('change');

        global_bank_state_id = primaryBank.bank_state || null;
        global_bank_city_id = primaryBank.bank_city || null;

        $('#updateAccountName').val(primaryBank.bank_acc_name || '');
        $('#updateAccountType').val(primaryBank.bank_acc_type || '');
        $('#updateBankPincode').val(primaryBank.bank_pincode || '');
        $('#updateAccountNumber').val(primaryBank.bank_acc_number || '');
        $('#updateMicr').val(primaryBank.bank_micr || '');
        $('#updateIfsc').val(primaryBank.bank_ifsc || '');

        
        banks.slice(1).forEach(function (bank) {
            addUpdateBank();

            const row = $('#updatebankcontainer .secondary-bank').last();

            row.find('[name$="[bank_name]"]').val(bank.bank_name || '');
            row.find('[name$="[bank_branch]"]').val(bank.bank_branch || '');
            row.find('[name$="[bank_address]"]').val(bank.bank_address || '');
            row.find('[name$="[bank_pincode]"]').val(bank.bank_pincode || '');
            row.find('[name$="[bank_acc_name]"]').val(bank.bank_acc_name || '');
            row.find('[name$="[bank_acc_type]"]').val(bank.bank_acc_type || '');
            row.find('[name$="[bank_acc_number]"]').val(bank.bank_acc_number || '');
            row.find('[name$="[bank_micr]"]').val(bank.bank_micr || '');
            row.find('[name$="[bank_ifsc]"]').val(bank.bank_ifsc || '');

            function waitForOption(dropdown, value, callback, attempts = 30) {
                const timer = setInterval(function () {
                    const optionExists = dropdown.find('option').filter(function () {
                        return String(this.value) === String(value);
                    }).length > 0;

                    if (optionExists) {
                        clearInterval(timer);
                        dropdown.val(String(value)).trigger('change');

                        if (callback) callback();
                    } else if (--attempts <= 0) {
                        clearInterval(timer);
                        console.warn('Option not found:', value, dropdown.attr('name'));
                    }
                }, 100);
            }

            const countryDropdown = row.find('[name$="[bank_country]"]');
            countryDropdown.val(bank.bank_country || '').trigger('change');

            if (bank.bank_country) {
                bankCountryChange(countryDropdown[0]);

                const stateDropdown = row.find('[name$="[bank_state]"]');

                waitForOption(stateDropdown, bank.bank_state, function () {
                    if (bank.bank_state) {
                        bankStateChange(stateDropdown[0]);

                        const cityDropdown = row.find('[name$="[bank_city]"]');

                        waitForOption(cityDropdown, bank.bank_city);
                    }
                });
            }
        });

        updateBankCount = banks.length;
        if (primaryBank.bank_country) {
            setTimeout(function () {
                $('#updateBankState').val(global_bank_state_id).trigger('change');

                setTimeout(function () {
                    $('#updateBankCity').val(global_bank_city_id);
                }, 300);
            }, 300);
        }

    })
    .catch(error => {
        console.error('Error fetching contractor:', error);
    });

    document.getElementById('contractorlist').classList.add('d-none');
    document.getElementById('addContractor').classList.add('d-none');
    document.getElementById('updateContractor').classList.remove('d-none');
}


    function update_country_change() { 
            var countryId = $('#updateCountry').val();
            var stateDropdown = $('#updateState'); 
            console.log('hi')
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('contactor_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        }   
                        if(global_state_id){
                            var changes=global_state_id;
                            stateDropdown.val(changes).change();
                          }
                    } 
                }); 
            } 
        
        } 

            function update_state_change() { 
                var stateId = $('#updateState').val(); 
                var countryId = $('#updateCountry').val(); 
                var cityDropdown = $('#updateCity'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('contractor_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                            if(global_city_id){
                            var changes=global_city_id;
                            cityDropdown.val(changes).change();
                          }
                        } 
                    }); 
                } 
            }
            function update_bank_country() { 
            var countryId = $('#updateBankCountry').val();
            var stateDropdown = $('#updateBankState'); 
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('bank_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        } 
                        if(global_bank_state_id){
                            var changes=global_bank_state_id;
                            stateDropdown.val(changes).change();
                          }  
                    } 
                }); 
            } 
        
        } 
            function update_bank_state() { 
                var stateId = $('#updateBankState').val(); 
                var countryId = $('#updateBankCountry').val(); 
                var cityDropdown = $('#updateBankCity'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('bank_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                            if(global_bank_city_id){
                            var changes=global_bank_city_id;
                            cityDropdown.val(changes).change();
                          }
                        } 
                    }); 
                } 
            } 
  </script>

<!-- view contractor -->
  <script>
    function showContractor(id) {
        document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                skeleton.style.display = 'block'; // Show skeleton loaders
            });
        
            // Hide actual data elements
            document.querySelectorAll('.view-data').forEach(element => {
                element.style.display = 'none'; // Hide actual data until it is loaded
            });
            
            fetch('/contractor_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                        console.log(com);
                        document.querySelectorAll('.view-data').forEach(element => {
                            element.style.display = 'block'; // Show actual data
                        });
                        
                        $('#viewContractorCode').text(com.contractor_code);
                        $('#viewContractorName').text(com.contract_company_name);
                        $('#viewContractorType').text(com.contractor_type); 
                        $('#viewContactPerson').text(com.primary_person_name);
                        $('#viewContactNo').text(com.primary_person_number);
                        $('#viewEmail').text(com.primary_person_email);
                        $('#viewAddress').html(
                                              (com.address || '') +', '+
                                              (com.city_name || '') +', '+
                                              (com.state_name || '') +', '+
                                              (com.country_name || '')
                                            );
                        $('#viewGst').text(com.gst_number);
                        $('#viewPan').text(com.pan_number||'-');
                        $('#viewBankName').text(com.primary_bank.bank_name||'-');
                        $('#viewAccountName').text(com.primary_bank.bank_acc_name||'-');
                        $('#viewAccountNo').text(com.primary_bank.bank_acc_number||'-');
                        $('#viewIfsc').text(com.primary_bank.bank_ifsc||'-');
                        $('#viewBankBranch').text(com.primary_bank.bank_branch||'-');
                        $('#viewBankAddress').text(com.primary_bank.bank_address||'-');
                        $('#viewBankPincode').text(com.primary_bank.bank_pincode||'-');
                        $('#viewBankCity').text(com.primary_bank.city_name||'-');
                        $('#viewBankCountry').text(com.primary_bank.country_name||'-');
                        $('#viewBankState').text(com.primary_bank.state_name||'-');
                        
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
    }
        

    
  </script>

  <!-- add modal add person -->
   <!-- <script>
      function addperson() {

          const container = document.getElementById('personcontainer');

          const newPerson = document.createElement('div');

          newPerson.className = 'mt-4';

          newPerson.innerHTML = `
              <div class="mb-3">
                  <label class="text-black fw-bold fs-5">Secondary</label>
              </div>
              <div class="row g-4 person-row">
                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Person Type
                          <span class="text-danger">*</span>
                      </label>

                      <select class="form-select" id="sec_person_type" name="sec_person_type">
                          <option value="">Commercial/Technical</option>
                          <option value="1">Commercial Admin</option>
                          <option value="2">Technical Lead</option>
                          <option value="3">Site Representative</option>
                      </select>
                      <div class="text-danger" id="sec_person_type_err"></div>
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Person Name
                          <span class="text-danger">*</span>
                      </label>

                      <input
                          type="text"
                          class="form-control"
                          placeholder="Salvam (Supervisor)" id="sec_person_name" name="sec_person_name"
                      />
                      <div class="text-danger" id="sec_person_name_err"></div>
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Mobile No
                          <span class="text-danger">*</span>
                      </label>

                      <input
                          type="tel"
                          class="form-control"
                          placeholder="98765 43210" id="sec_person_number" name="sec_person_number"/>
                          <div class="text-danger" id="sec_person_number_err"></div>
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Email
                      </label>

                      <input
                          type="email"
                          class="form-control"
                          placeholder="salvam@example.com" id="sec_person_email" name="sec_person_email"
                      />
                      <div class="text-danger" id="sec_person_email_err"></div>
                  </div>

                  <div class="col-md-4">
                      <label class="form-label fw-semibold text-dark">
                          Telephone No
                      </label>
                      <input
                          type="text"
                          class="form-control"
                          placeholder="0452-2698712" id="sec_person_teleno" name="sec_person_teleno"
                      />
                  </div>

                  <div class="col-12 d-flex justify-content-end">
                      <button
                          type="button"
                          class="btn btn-outline-danger btn-sm"
                          onclick="removePerson(this)"
                      >
                          <i class="mdi mdi-delete-outline"></i>
                          Remove
                      </button>
                  </div>
              </div>
          `;

          container.appendChild(newPerson);
      }


      function removePerson(button) {

          const personRow = button.closest('.mt-4');

          if (personRow) {
              personRow.remove();
          }

      }
  </script> -->

  

<script>
    let personCount = 1; // Primary person uses index 0

    function addperson() {
        const container = document.getElementById('personcontainer');
        const newPerson = document.createElement('div');
        newPerson.className = 'mt-4 secondary-person';

        newPerson.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <label class="text-black fw-bold fs-5">
                    Secondary Person
                </label>

                <button type="button"
                    class="btn btn-outline-danger btn-sm"
                    onclick="removePerson(this)">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>

            <div class="row g-4 person-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Person Type <span class="text-danger">*</span>
                    </label>
                    <select class="form-select"
                        name="persons[${personCount}][person_type]" required>
                        <option value="">Select Person Type</option>
                        <option value="1">Commercial Admin</option>
                        <option value="2">Technical Lead</option>
                        <option value="3">Site Representative</option>
                    </select>
                    <div class="text-danger person-type-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Person Name <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="persons[${personCount}][person_name]"
                        placeholder="Person Name" required>
                    <div class="text-danger person-name-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Mobile No <span class="text-danger">*</span>
                    </label>
                    <input type="tel" class="form-control"
                        name="persons[${personCount}][person_number]"
                        placeholder="98765 43210" required>
                    <div class="text-danger person-number-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">Email</label>
                    <input type="email" class="form-control"
                        name="persons[${personCount}][person_email]"
                        placeholder="person@example.com">
                    <div class="text-danger person-email-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">Telephone No</label>
                    <input type="text" class="form-control"
                        name="persons[${personCount}][person_teleno]"
                        placeholder="0452-2698712">
                </div>
            </div>

            <hr class="mt-4">
        `;

        container.appendChild(newPerson);
        personCount++;
    }

    function removePerson(button) {
        const person = button.closest('.secondary-person');

        if (person) {
            person.remove();
        }
    }
</script>


<!-- update modal add person -->
 <script>
    let updatePersonCount = 1; // Primary person uses index 0

    function updatecontractor() {
        const container = document.getElementById('updatepersoncontainer');
        const index = updatePersonCount++;

        const newPerson = document.createElement('div');
        newPerson.className = 'mt-4 secondary-person';

        newPerson.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <label class="text-black fw-bold fs-5">
                    Secondary Person
                </label>

                <button type="button"
                    class="btn btn-outline-danger btn-sm"
                    onclick="removeUpdatePerson(this)">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>

            <div class="row g-4 person-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Person Type <span class="text-danger">*</span>
                    </label>
                    <select class="form-select"
                        name="persons[${index}][person_type]" required>
                        <option value="">Select Person Type</option>
                        <option value="1">Commercial Admin</option>
                        <option value="2">Technical Lead</option>
                        <option value="3">Site Representative</option>
                    </select>
                    <div class="text-danger person-type-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Person Name <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="persons[${index}][person_name]"
                        placeholder="Person Name" required>
                    <div class="text-danger person-name-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Mobile No <span class="text-danger">*</span>
                    </label>
                    <input type="tel" class="form-control"
                        name="persons[${index}][person_number]"
                        placeholder="98765 43210" required>
                    <div class="text-danger person-number-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Email
                    </label>
                    <input type="email" class="form-control"
                        name="persons[${index}][person_email]"
                        placeholder="person@example.com">
                    <div class="text-danger person-email-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold text-dark">
                        Telephone No
                    </label>
                    <input type="text" class="form-control"
                        name="persons[${index}][person_teleno]"
                        placeholder="0452-2698712">
                </div>
            </div>

            <hr class="mt-4">
        `;

        container.appendChild(newPerson);
    }

    function removeUpdatePerson(button) {
        const person = button.closest('.secondary-person');

        if (person) {
            person.remove();
        }
    }

    function resetUpdatePersons() {
        updatePersonCount = 1;

        document.querySelectorAll(
            '#updatepersoncontainer .secondary-person'
        ).forEach(person => person.remove());
    }
</script>

<!-- <script>
    function saveUpdateContract(){
        let err=0;
     const reloadPage = tableState.currentPage;
            const id = currentCategoryId;
            const contract_type = document.getElementById('updateContractorType').value;
            const contract_company_name = document.getElementById('updateContractorCompany').value;
            const contract_name = document.getElementById('updateContractName').value;
            const primary_person_name = document.getElementById('updatePersonName').value;
            const primary_person_type = document.getElementById('updatePersonType').value;
            const primary_person_number = document.getElementById('updateMobile').value;
            const primary_person_email = document.getElementById('updateEmail').value;
            const primary_person_teleno = document.getElementById('updateTelephone').value;
            const pin_code = document.getElementById('updatePincode').value;
            const address = document.getElementById('updateAddress').value;
            const country_id = document.getElementById('updateCountry').value;
            const state_id = document.getElementById('updateState').value;
            const city_id = document.getElementById('updateCity').value;
            const gst_number = document.getElementById('updateGst').value;
            const pan_number = document.getElementById('updatePan').value;
            const aadhar_no = document.getElementById('updateAadhar').value;
            const esi_no = document.getElementById('updateEsi').value;
            const epf_no = document.getElementById('updateEpf').value;
            const primary_bank_name = document.getElementById('updateBankName').value;
            const primary_bank_branch = document.getElementById('updateBankBranch').value;
            const primary_bank_address = document.getElementById('updateBankAddress').value;
            const primary_bank_country_id = document.getElementById('updateBankCountry').value;
            const primary_bank_state_id = document.getElementById('updateBankState').value;
            const primary_bank_city_id = document.getElementById('updateBankCity').value;
            const primary_acc_name = document.getElementById('updateAccountName').value;
            const primary_acc_type = document.getElementById('updateAccountType').value;
            const primary_bank_pin_code = document.getElementById('updateBankPincode').value;
            const primary_acc_no = document.getElementById('updateAccountNumber').value;
            const primary_bank_micr = document.getElementById('updateMicr').value;
            const primary_bank_ifsc = document.getElementById('updateIfsc').value;



            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');



            $('.secondary-person').each(function () {
            const row = $(this);

            const type = row.find('[name$="[person_type]"]');
            const name = row.find('[name$="[person_name]"]');
            const mobile = row.find('[name$="[person_number]"]');
            const email = row.find('[name$="[person_email]"]');
            const teleno = row.find('[name$="[person_teleno]"]');

            row.find('.person-type-error, .person-name-error, .person-number-error, .person-email-error')
                    .text('');

            if (!type.val()) {
                type.siblings('.person-type-error').text('Person Type is required');
            err++;
            }

            if (!name.val().trim()) {
                name.siblings('.person-name-error').text('Person Name is required');
                err++;
            }

            if (!mobile.val().trim()) {
                mobile.siblings('.person-number-error').text('Mobile No is required');
                err++;
            }

            if (email.val().trim() &&
                !/^\S+@\S+\.\S+$/.test(email.val().trim())) {
                email.siblings('.person-email-error').text('Enter a valid email');
                err++;
            }
        });


             $('.secondary-bank').each(function () {
                const row = $(this);
                const bankName = row.find('[name$="[bank_name]"]');
                const branch = row.find('[name$="[bank_branch]"]');
                const country = row.find('[name$="[bank_country]"]');
                const state = row.find('[name$="[bank_state]"]');
                const city = row.find('[name$="[bank_city]"]');
                const address = row.find('[name$="[bank_address]"]');
                const pin = row.find('[name$="[bank_pincode]"]');
                const accName = row.find('[name$="[bank_acc_name]"]');
                const accType = row.find('[name$="[bank_acc_type]"]');
                const accNo = row.find('[name$="[bank_acc_number]"]');  
                const micr = row.find('[name$="[bank_micr]"]');
                const ifsc = row.find('[name$="[bank_ifsc]"]');

                row.find(
                    '.bank-name-error, .bank-branch-error, .bank-country-error, ' +
                    '.bank-state-error, .bank-city-error, .bank-address-error, ' +
                    '.bank-pin-error, .bank-acc-name-error, .bank-acc-type-error, ' +
                    '.bank-acc-no-error, .bank-micr-error, .bank-ifsc-error'
                ).text('');

                if (!bankName.val().trim()) {
                    row.find('.bank-name-error').text('Bank Name is required');
                    err++;
                }

                if (!branch.val().trim()) {
                    row.find('.bank-branch-error').text('Bank Branch is required');
                    err++;
                }

                if (!country.val()) {
                    row.find('.bank-country-error').text('Country is required');
                    err++;
                }

                if (!state.val()) {
                    row.find('.bank-state-error').text('State is required');
                    err++;
                }

                if (!city.val()) {
                    row.find('.bank-city-error').text('City is required');
                    err++;
                }

                if (!address.val().trim()) {
                    row.find('.bank-address-error').text('Bank Address is required');
                    err++;
                }

                if (!pin.val().trim()) {
                    row.find('.bank-pin-error').text('Bank Pincode is required');
                    err++;
                } else if (!/^\d{6}$/.test(pin.val().trim())) {
                    row.find('.bank-pin-error').text('Pincode must be 6 digits');
                    err++;
                }

                if (!accName.val().trim()) {
                    row.find('.bank-acc-name-error').text('Account Name is required');
                    err++;
                }

                if (!accType.val()) {
                    row.find('.bank-acc-type-error').text('Account Type is required');
                    err++;
                }

                if (!accNo.val().trim()) {
                    row.find('.bank-acc-no-error').text('Account Number is required');
                    err++;
                }

                if (!micr.val().trim()) {
                    row.find('.bank-micr-error').text('MICR Code is required');
                    err++;
                }

                if (!ifsc.val().trim()) {
                    row.find('.bank-ifsc-error').text('IFSC Code is required');
                    err++;
                }
            });

            if(contract_type == ""){
                $('#updateContractorType_err').text('Contractor type is required')
                err++
            }
            if(contract_company_name == ""){
                $('#updateContractorCompany_err').text('Contractor company name is required')
                err++
            }
            
            if(country_id == ""){
                $('#updateCountry_err').text('Country is required')
                err++
            }
            if(state_id == ""){
                $('#updateState_err').text('State is required')
                err++
            }
            if(city_id == ""){
                $('#updateCity_err').text('City is required')
                err++
            }
            
            if(pin_code == ""){
                $('#updatePincode_err').text('Pincode is required')
                err++
            }
            if(pan_number == ""){
                $('#updatePan_err').text('PAN Number is required')
                err++
            }
            if(gst_number == ""){
                $('#updateGst_err').text('GST Number is required')
                err++
            }
            
            if(pin_code != "" && pin_code.length!=6){
                $('#updatePincode_err').text('Pincode Must be 6 digit')
                err++
            }
            if(aadhar_no == ""){
                $('#updateAadhar_err').text('Aadhar Number is required')
                err++
            }
            if (primary_person_email != '' && !/^\S+@\S+\.\S+$/.test(primary_person_email)) {
                 $('#updateEmail_err').text('Enter valid email')
                err++
            }
            if(primary_person_type == ""){
                $('#updatePersonType_err').text('Person Type is required')
                err++
            }
            if(primary_person_name == ""){
                $('#updatePersonName_err').text('Person Name is required')
                err++
            }
            if(primary_person_number == ""){
                $('#updateMobile_err').text('Mobile No is required')
                err++
            }
            if(primary_bank_name == ""){
                $('#updateBankName_err').text('Bank Name is required')
                err++
            }
            if(primary_bank_branch == ""){
                $('#updateBankBranch_err').text('Branch is required')
                err++
            }
            if(primary_bank_address == ""){
                $('#updateBankAddress_err').text('Bank Address is required')
                err++
            }
            if(primary_bank_country_id == ""){
                $('#updateBankCountry_err').text('Country is required')
                err++
            }
            if(primary_bank_state_id == ""){
                $('#updateBankState_err').text('State is required')
                err++
            }
            if(primary_bank_city_id == ""){
                $('#updateBankCity_err').text('City is required')
                err++
            }
            if(primary_bank_pin_code == ""){
                $('#updateBankPincode_err').text('Pincode is required')
                err++
            }
            if(primary_bank_pin_code != "" && primary_bank_pin_code.length!=6){
                $('#updateBankPincode_err').text('Pincode Must be 6 digit')
                err++
            }
            if(primary_acc_name == ""){
                $('#updateAccountName_err').text('Account Name is required')
                err++
            }
            if(primary_acc_type == ""){
                $('#updateAccountType_err').text('Account Type is required')
                err++
            }
            if(primary_acc_no == ""){
                $('#updateAccountNumber_err').text('Account Number is required')
                err++
            }
            if(primary_bank_micr == ""){
                $('#updateMicr_err').text('MICR Code is required')
                err++
            }
            if(primary_bank_ifsc == ""){
                $('#updateIfsc_err').text('IFSC Code is required')
                err++
            }
            if (err>0){
            return false;
            }
            else{ 
                

            fetch(`/contract_updates/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        contract_type: contract_type,
                        contract_company_name: contract_company_name,
                        contract_name: contract_name,
                        primary_person_name: primary_person_name,
                        primary_person_type: primary_person_type,
                        primary_person_number: primary_person_number,
                        primary_person_email: primary_person_email,
                        primary_person_teleno: primary_person_teleno,
                        pin_code: pin_code,
                        address: address,
                        country_id: country_id,
                        state_id: state_id,
                        city_id: city_id,
                        gst_number: gst_number,
                        pan_number: pan_number,
                        aadhar_no: aadhar_no,
                        esi_no: esi_no,
                        epf_no: epf_no,
                        primary_bank_name: primary_bank_name,
                        primary_bank_branch: primary_bank_branch,
                        primary_bank_address: primary_bank_address,
                        primary_bank_country_id: primary_bank_country_id,
                        primary_bank_state_id: primary_bank_state_id,
                        primary_bank_city_id: primary_bank_city_id,
                        primary_acc_name: primary_acc_name,
                        primary_acc_type: primary_acc_type,
                        primary_bank_pin_code: primary_bank_pin_code,
                        primary_acc_no: primary_acc_no,
                        primary_bank_micr: primary_bank_micr,
                        primary_bank_ifsc: primary_bank_ifsc,
                    }),
                })
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Contractor Updated successfully!');
                        //  location.reload(reloadPage);
                    } else {
                        toastr.error('Contractor Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating Contractor:', error);

                });
        }
}
        document.getElementById('saveupdatecontractor').addEventListener('button', function(event) {
            event.preventDefault();
            saveUpdateContract();
        });
</script> -->
  <!-- add modal add bank -->
  


<script>
async function saveUpdateContract() {
    let err = 0;

    const id = currentCategoryId;
    const csrfToken = document.querySelector(
        'meta[name="csrf-token"]'
    ).getAttribute('content');

    // Clear existing errors
    $('[id$="_err"]').text('');

    // Contractor details
    const contractor = {
        contract_type: $('#updateContractorType').val(),
        contract_company_name: $('#updateContractorCompany').val().trim(),
        contract_name: $('#updateContractName').val().trim(),
        pin_code: $('#updatePincode').val().trim(),
        address: $('#updateAddress').val().trim(),
        country_id: $('#updateCountry').val(),
        state_id: $('#updateState').val(),
        city_id: $('#updateCity').val(),
        gst_number: $('#updateGst').val().trim(),
        pan_number: $('#updatePan').val().trim(),
        aadhar_no: $('#updateAadhar').val().trim(),
        esi_no: $('#updateEsi').val().trim(),
        epf_no: $('#updateEpf').val().trim()
    };

    // Validate contractor details
    const requiredFields = [
        ['contract_type', 'updateContractorType_err', 'Contractor type'],
        ['contract_company_name', 'updateContractorCompany_err', 'Contractor company name'],
        ['country_id', 'updateCountry_err', 'Country'],
        ['state_id', 'updateState_err', 'State'],
        ['city_id', 'updateCity_err', 'City'],
        ['pin_code', 'updatePincode_err', 'Pincode'],
        ['pan_number', 'updatePan_err', 'PAN Number'],
        ['gst_number', 'updateGst_err', 'GST Number'],
        ['aadhar_no', 'updateAadhar_err', 'Aadhar Number']
    ];

    requiredFields.forEach(([field, errorId, label]) => {
        if (!contractor[field]) {
            $('#' + errorId).text(label + ' is required');
            err++;
        }
    });

    if (contractor.pin_code &&
        !/^\d{6}$/.test(contractor.pin_code)) {
        $('#updatePincode_err').text('Pincode must be 6 digits');
        err++;
    }

    // Collect primary person (index 0)
    const persons = [{
        person_type: $('#updatePersonType').val(),
        person_name: $('#updatePersonName').val().trim(),
        person_number: $('#updateMobile').val().trim(),
        person_email: $('#updateEmail').val().trim(),
        person_teleno: $('#updateTelephone').val().trim()
    }];

    // Validate primary person
    if (!persons[0].person_type) {
        $('#updatePersonType_err').text('Person Type is required');
        err++;
    }

    if (!persons[0].person_name) {
        $('#updatePersonName_err').text('Person Name is required');
        err++;
    }

    if (!persons[0].person_number) {
        $('#updateMobile_err').text('Mobile No is required');
        err++;
    }

    if (persons[0].person_email &&
        !/^\S+@\S+\.\S+$/.test(persons[0].person_email)) {
        $('#updateEmail_err').text('Enter a valid email');
        err++;
    }

    // Collect secondary persons
    $('#updatepersoncontainer .secondary-person').each(function () {
        const row = $(this);

        const person = {
            person_type: row.find('[name$="[person_type]"]').val(),
            person_name: row.find('[name$="[person_name]"]').val().trim(),
            person_number: row.find('[name$="[person_number]"]').val().trim(),
            person_email: row.find('[name$="[person_email]"]').val().trim(),
            person_teleno: row.find('[name$="[person_teleno]"]').val().trim()
        };

        row.find(
            '.person-type-error, .person-name-error, ' +
            '.person-number-error, .person-email-error'
        ).text('');

        if (!person.person_type) {
            row.find('.person-type-error').text('Person Type is required');
            err++;
        }

        if (!person.person_name) {
            row.find('.person-name-error').text('Person Name is required');
            err++;
        }

        if (!person.person_number) {
            row.find('.person-number-error').text('Mobile No is required');
            err++;
        }

        if (person.person_email &&
            !/^\S+@\S+\.\S+$/.test(person.person_email)) {
            row.find('.person-email-error').text('Enter a valid email');
            err++;
        }

        persons.push(person);
    });

    // Collect primary bank (index 0)
    const banks = [{
        bank_name: $('#updateBankName').val().trim(),
        bank_branch: $('#updateBankBranch').val().trim(),
        bank_country: $('#updateBankCountry').val(),
        bank_state: $('#updateBankState').val(),
        bank_city: $('#updateBankCity').val(),
        bank_address: $('#updateBankAddress').val().trim(),
        bank_pincode: $('#updateBankPincode').val().trim(),
        bank_acc_name: $('#updateAccountName').val().trim(),
        bank_acc_type: $('#updateAccountType').val(),
        bank_acc_number: $('#updateAccountNumber').val().trim(),
        bank_micr: $('#updateMicr').val().trim(),
        bank_ifsc: $('#updateIfsc').val().trim()
    }];

    // Validate primary bank
    const primaryBankErrors = [
        ['bank_name', 'updateBankName_err', 'Bank Name'],
        ['bank_branch', 'updateBankBranch_err', 'Bank Branch'],
        ['bank_country', 'updateBankCountry_err', 'Country'],
        ['bank_state', 'updateBankState_err', 'State'],
        ['bank_city', 'updateBankCity_err', 'City'],
        ['bank_address', 'updateBankAddress_err', 'Bank Address'],
        ['bank_pincode', 'updateBankPincode_err', 'Pincode'],
        ['bank_acc_name', 'updateAccountName_err', 'Account Name'],
        ['bank_acc_type', 'updateAccountType_err', 'Account Type'],
        ['bank_acc_number', 'updateAccountNumber_err', 'Account Number'],
        ['bank_micr', 'updateMicr_err', 'MICR Code'],
        ['bank_ifsc', 'updateIfsc_err', 'IFSC Code']
    ];

    primaryBankErrors.forEach(([field, errorId, label]) => {
        if (!banks[0][field]) {
            $('#' + errorId).text(label + ' is required');
            err++;
        }
    });

    if (banks[0].bank_pincode &&
        !/^\d{6}$/.test(banks[0].bank_pincode)) {
        $('#updateBankPincode_err').text('Pincode must be 6 digits');
        err++;
    }

    // Collect secondary banks
    $('#updatebankcontainer .secondary-bank').each(function () {
        const row = $(this);

        const bank = {
            bank_name: row.find('[name$="[bank_name]"]').val().trim(),
            bank_branch: row.find('[name$="[bank_branch]"]').val().trim(),
            bank_country: row.find('[name$="[bank_country]"]').val(),
            bank_state: row.find('[name$="[bank_state]"]').val(),
            bank_city: row.find('[name$="[bank_city]"]').val(),
            bank_address: row.find('[name$="[bank_address]"]').val().trim(),
            bank_pincode: row.find('[name$="[bank_pincode]"]').val().trim(),
            bank_acc_name: row.find('[name$="[bank_acc_name]"]').val().trim(),
            bank_acc_type: row.find('[name$="[bank_acc_type]"]').val(),
            bank_acc_number: row.find('[name$="[bank_acc_number]"]').val().trim(),
            bank_micr: row.find('[name$="[bank_micr]"]').val().trim(),
            bank_ifsc: row.find('[name$="[bank_ifsc]"]').val().trim()
        };

        const bankFields = [
            ['bank_name', '.bank-name-error', 'Bank Name'],
            ['bank_branch', '.bank-branch-error', 'Bank Branch'],
            ['bank_country', '.bank-country-error', 'Country'],
            ['bank_state', '.bank-state-error', 'State'],
            ['bank_city', '.bank-city-error', 'City'],
            ['bank_address', '.bank-address-error', 'Bank Address'],
            ['bank_pincode', '.bank-pin-error', 'Pincode'],
            ['bank_acc_name', '.bank-acc-name-error', 'Account Name'],
            ['bank_acc_type', '.bank-acc-type-error', 'Account Type'],
            ['bank_acc_number', '.bank-acc-no-error', 'Account Number'],
            ['bank_micr', '.bank-micr-error', 'MICR Code'],
            ['bank_ifsc', '.bank-ifsc-error', 'IFSC Code']
        ];

        row.find(
            '.bank-name-error, .bank-branch-error, .bank-country-error, ' +
            '.bank-state-error, .bank-city-error, .bank-address-error, ' +
            '.bank-pin-error, .bank-acc-name-error, .bank-acc-type-error, ' +
            '.bank-acc-no-error, .bank-micr-error, .bank-ifsc-error'
        ).text('');

        bankFields.forEach(([field, errorClass, label]) => {
            if (!bank[field]) {
                row.find(errorClass).text(label + ' is required');
                err++;
            }
        });

        if (bank.bank_pincode &&
            !/^\d{6}$/.test(bank.bank_pincode)) {
            row.find('.bank-pin-error').text('Pincode must be 6 digits');
            err++;
        }

        banks.push(bank);
    });

    if (err > 0) {
        return false;
    }

    // Send contractor, person array and bank array

        fetch(`/contract_updates/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                            ...contractor,
                            persons: persons,
                            banks: banks
                    })
                })
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Contractor Updated successfully!');
                        //  location.reload(reloadPage);
                    } else {
                        toastr.error('Contractor Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating Contractor:', error);

                });
    
}
</script>




<script>
    let bankCount = 1; // Primary bank uses index 0

    function addbank() {
        const container = document.getElementById('bankcontainer');
        const index = bankCount++;

        const newBank = document.createElement('div');
        newBank.className = 'mt-4 border-top pt-4 secondary-bank';

        newBank.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <label class="text-black fw-bold fs-5">
                    Secondary Bank Details
                </label>
                <button type="button"
                    class="btn btn-outline-danger btn-sm"
                    onclick="removeBank(this)">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>

            <div class="row g-4 bank-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Bank Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_name]">
                     <div class="text-danger bank-name-error"></div>   
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">Bank Branch <span class="text-danger">*</span></label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_branch]">
                        <div class="text-danger bank-branch-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">Country <span class="text-danger">*</span></label>
                    <select name="banks[${index}][bank_country]"
                        class="form-select bank-country"
                        onchange="bankCountryChange(this)">
                        <option value="">Select Country</option>
                        @foreach ($country_list as $list)
                            <option value="{{ $list->sno }}">
                                {{ $list->country_name }}
                            </option>
                        @endforeach
                    </select>
                    <div class="text-danger bank-country-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">State <span class="text-danger">*</span></label>
                    <select name="banks[${index}][bank_state]"
                        class="form-select bank-state"
                        onchange="bankStateChange(this)" >
                        <option value="">Select State</option>
                    </select>
                    <div class="text-danger bank-state-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">City <span class="text-danger">*</span></label>
                    <select name="banks[${index}][bank_city]"
                        class="form-select bank-city">
                        <option value="">Select City</option>
                    </select>
                    <div class="text-danger bank-city-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">Bank Address <span class="text-danger">*</span></label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_address]">
                        <div class="text-danger bank-address-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">Bank Pincode <span class="text-danger">*</span></label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_pincode]"
                        maxlength="6">
                        <div class="text-danger bank-pin-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">Bank Account Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_acc_name]">
                        <div class="text-danger bank-acc-name-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">Bank Account Type <span class="text-danger">*</span></label>
                    <select name="banks[${index}][bank_acc_type]"
                        class="form-select">
                        <option value="">Select Account Type</option>
                        <option value="1">Current Account</option>
                        <option value="2">Saving Account</option>
                        <option value="3">Overdraft</option>
                    </select>
                    <div class="text-danger bank-acc-type-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">Bank Account Number <span class="text-danger">*</span></label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_acc_number]">
                        <div class="text-danger bank-acc-no-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">MICR Code <span class="text-danger">*</span></label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_micr]">
                        <div class="text-danger bank-micr-error"></div> 
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">IFSC / RTGS Code <span class="text-danger">*</span></label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_ifsc]">
                        <div class="text-danger bank-ifsc-error"></div> 
                </div>
            </div>
        `;

        container.appendChild(newBank);
    }

    function removeBank(button) {
        const bank = button.closest('.secondary-bank');
        if (bank) {
            bank.remove();
        }
    }
</script>   


  <!-- update modal add bank -->
  <script>
    let updateBankCount = 1; // Primary bank uses index 0

    function addUpdateBank() {
        const container = document.getElementById('updatebankcontainer');
        const index = updateBankCount++;

        const newBank = document.createElement('div');
        newBank.className = 'mt-4 border-top pt-4 secondary-bank';

        newBank.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <label class="text-black fw-bold fs-5">
                    Secondary Bank Details
                </label>
                <button type="button"
                    class="btn btn-outline-danger btn-sm"
                    onclick="removeUpdateBank(this)">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>

            <div class="row g-4 bank-row">
                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Bank Name <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_name]" required>
                    <div class="text-danger bank-name-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Bank Branch <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_branch]" required>
                    <div class="text-danger bank-branch-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Country <span class="text-danger">*</span>
                    </label>
                    <select name="banks[${index}][bank_country]"
                        class="form-select bank-country"
                        onchange="bankCountryChange(this)" required>
                        <option value="">Select Country</option>
                        @foreach ($country_list as $list)
                            <option value="{{ $list->sno }}">
                                {{ $list->country_name }}
                            </option>
                        @endforeach
                    </select>
                    <div class="text-danger bank-country-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        State <span class="text-danger">*</span>
                    </label>
                    <select name="banks[${index}][bank_state]"
                        class="form-select bank-state"
                        onchange="bankStateChange(this)" required>
                        <option value="">Select State</option>
                    </select>
                    <div class="text-danger bank-state-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        City <span class="text-danger">*</span>
                    </label>
                    <select name="banks[${index}][bank_city]"
                        class="form-select bank-city" required>
                        <option value="">Select City</option>
                    </select>
                    <div class="text-danger bank-city-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Bank Address <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_address]" required>
                    <div class="text-danger bank-address-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Bank Pincode <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_pincode]"
                        maxlength="6" required>
                    <div class="text-danger bank-pin-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Bank Account Name <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_acc_name]" required>
                    <div class="text-danger bank-acc-name-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Bank Account Type <span class="text-danger">*</span>
                    </label>
                    <select name="banks[${index}][bank_acc_type]"
                        class="form-select" required>
                        <option value="">Select Account Type</option>
                        <option value="1">Current Account</option>
                        <option value="2">Saving Account</option>
                        <option value="3">Overdraft</option>
                    </select>
                    <div class="text-danger bank-acc-type-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Bank Account Number <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_acc_number]" required>
                    <div class="text-danger bank-acc-no-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        MICR Code <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_micr]" required>
                    <div class="text-danger bank-micr-error"></div>
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        IFSC / RTGS Code <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control"
                        name="banks[${index}][bank_ifsc]" required>
                    <div class="text-danger bank-ifsc-error"></div>
                </div>
            </div>
        `;

        container.appendChild(newBank);
    }

    function removeUpdateBank(button) {
        const bank = button.closest('.secondary-bank');
        if (bank) {
            bank.remove();
        }
    }
</script>


<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let tableState = {
        currentPage: 1
    };

    
    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index) {
        return `
            <tr>
                <td>
                    <div class="d-flex flex-column justify-content-between gap-2">
                        <label class="fw-semibold text-dark fs-7">${item.contract_company_name}</label>
                        <span class="badge rounded-pill bg-label-primary fs-8">
                            ${item.contractor_code}
                        </span>
                    </div>
                </td>               
                <td>
                    <div class="d-flex flex-column align-items-start">
                        <span class="fw-semibold text-dark fs-7">
                                ${item.contractor_type}
                        </span>
                        <span class="text-muted fs-8">
                            ${item.contract_name}
                        </span>
                    </div>
                </td>    
                <td>
                    <div class="d-flex flex-column">
                        <div class="d-flex">
                            <span class="text-dark fw-semibold fs-7">${item.primary_person_name}</span>
                        </div>
                        <div class="d-flex">
                            <i class="mdi mdi-phone-outline"></i>
                            <span class="text-muted fs-8">${item.primary_person_number}</span>
                        </div>
                    </div>
                </td>          
                <td>
                    <div class="d-flex flex-column">
                                  <span class="fw-semibold text-dark fs-7">${item.city_name}</span>
                                  <small class="text-muted">${item.state_name} - ${item.pin_code}</small>
                              </div>
                </td> 
                <td>
                    <div class="d-flex flex-column">
                        <div class="d-flex">
                            <label class="text-muted text-uppercase fs-8 me-1">pan:</label>
                            <span class="text-dark fs-8">${item.pan_number}</span>
                        </div>
                        <div class="d-flex">
                            <label class="text-muted text-uppercase fs-8 me-1">gst:</label>
                            <span class="text-dark fs-8">${item.gst_number}</span>
                        </div>
                    </div>  
                </td> 
                <td>
                    <div class="d-flex flex-column">
                        <div class="">
                            <label class="text-black fs-7">${item.primary_bank_name}</label>
                        </div>
                        <div class="d-flex">
                            <label class="text-muted text-uppercase fs-8 me-1">A/C :</label>
                            <span class="text-dark fs-8">${item.primary_acc_no}</span>
                        </div>
                        <div class="d-flex">
                            <label class="text-muted text-uppercase fs-8 me-1">IFSC :</label>
                            <span class="text-dark fs-8">${item.primary_bank_ifsc}</span>
                        </div>
                    </div>
                </td> 
                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" id="RemunerationStatus1" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)">
                    </div>
                </td>
                <td>
                    <div class="d-flex dropdown">
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#viewContractorModal"
                            onclick="showContractor('${item.sno}')">
                                <i class="mdi mdi-eye"></i>
                        </button>
                        <button class="btn" type="button" onclick="showUpdateContractor('${item.sno}')">
                            <i class="mdi mdi-pencil"></i>
                        </button>
                        <button class="btn" type="button" data-bs-toggle="modal"
                                data-bs-target="#deleteContractorModal" onclick="confirmDelete('${item.sno}','${item.contract_company_name}')">
                            <i class="mdi mdi-trash-can-outline"></i>
                        </button>
                    </div>
                </td>
                
            </tr>
        `;
    }
    function loadThemes(page = 1) {
         tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        
        const search = document.getElementById('search_filter').value;
        const tradefilter=document.getElementById('tradeFilter').value;
        
        const url = `/site/contractor?page=${page}&sorting_filter=${perpage}&search_filter=${search}&tradeFilter=${tradeFilter}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();
         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
               if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }
    

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="8" class="text-center">No Data Found</td></tr>
            `;
    }

  

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });
    document.getElementById('tradeFilter').addEventListener('change', function() {
        const Value = document.getElementById('tradeFilter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));
    document.getElementById('tradeFilter').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

</script>

<script>
    function updatelevelStatus(id, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state
           const reloadPage = tableState.currentPage;
            fetch(`/contractor_status/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Contractor status Updated successfully!');
                         loadThemes(reloadPage); 
                    } else {
                        console.error('Error updating Contractor status:', data.message);
                        toastr.error('Failed to update Contractor');
                    }
                })
                .catch(error => {
                    console.error('Error updating Contractor status:', error);
                });
        }
</script>
<script>
     function confirmDelete(id, name) {
            document.querySelector('#deleteContractorModal .btn-danger').setAttribute(
                'data-id', id);
            $('#delete_message').html('Are you sure you want to delete Contractor record <br> <b class="text-danger"> ' + name +
                '</b> ? This action cannot be undone.');
        }

        function deletelevel() {
            const reloadPage = tableState.currentPage;
            var id = document.querySelector('#deleteContractorModal .btn-danger').getAttribute('data-id');

            fetch('/delete_contractor/' + id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Contractor Deleted successfully!');
                        location.reload(reloadPage);

                    } else {
                        toastr.error('Failed to delete Contractor');
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
</script>
@endsection

