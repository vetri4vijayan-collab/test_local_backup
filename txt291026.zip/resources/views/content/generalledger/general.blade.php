@extends('layouts.layoutMaster')

@section('title', 'General Ledger')

@section('content')


<div class="container-fluid">

             <button
                        type="button"
                        class="btn bg-white text-primary btn-sm d-flex align-items-center gap-1">
                        Daily Accounts Ledger
                    </button>

</div>

<div class="container-fluid">

    {{-- Header Card with Filters --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3">

                <div class="flex-shrink-0" style="min-width: 0;">

                    <h5 class="fw-bold mb-1 d-flex align-items-center gap-2">
                        <i class="mdi mdi-book-open-page-variant-outline text-primary" style="font-size: 22px;"></i>
                        General Ledger
                    </h5>

                    <p class="text-muted small mb-0">
                        Account-wise opening balance, transactions log, credit/debit totals, OD amounts, and closing balance statement
                    </p>

                </div>

                <div class="d-flex align-items-center gap-2 flex-shrink-0">

                    <button
                        type="button"
                        class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1"
                        id="glExportBtn"
                    >
                        <i class="mdi mdi-download"></i>
                        Export
                    </button>

                    <button
                        type="button"
                        class="btn btn-primary btn-sm d-flex align-items-center gap-1"
                        id="glPostJournalBtn"
                    >
                        <i class="mdi mdi-plus"></i>
                        Post Journal Entry
                    </button>

                </div>

            </div>

            <div class="gl-filter-row">

                <div class="d-flex align-items-center gap-2">

                    <label class="form-label fw-semibold small mb-0 text-nowrap">
                        From Date
                    </label>

                    <input
                        type="date"
                        class="form-control form-control-sm gl-date-input"
                        id="glFromDate"
                        value=""
                    >

                </div>

                <div class="d-flex align-items-center gap-2">

                    <label class="form-label fw-semibold small mb-0 text-nowrap">
                        To Date
                    </label>

                    <input
                        type="date"
                        class="form-control form-control-sm gl-date-input"
                        id="glToDate"
                        value=""
                    >

                </div>

                <button
                    type="button"
                    class="btn btn-primary btn-sm fw-semibold d-flex align-items-center gap-1 gl-go-btn"
                    id="glGoBtn"
                >
                    GO
                </button>

                <div class="gl-filter-spacer"></div>

                <select
                    class="form-select form-select-sm gl-project-select"
                    id="glProjectFilter"
                >
                    <option value="">All Projects</option>
                    <option value="Coastal Expressway Bridge">Coastal Expressway Bridge</option>
                    <option value="Metro Line Extension - Phase 3">Metro Line Extension - Phase 3</option>
                    <option value="Skyline Premium Residences">Skyline Premium Residences</option>
                    <option value="Industrial Logistics Park">Industrial Logistics Park</option>
                </select>

                <select
                    class="form-select form-select-sm gl-account-select"
                    id="glAccountFilter"
                >
                    <option value="">All Accounts</option>
                    <option value="ICICI Bank Ltd-260805000359">ICICI Bank Ltd-260805000359</option>
                    <option value="ICICI Bank Ltd-260805000519">ICICI Bank Ltd-260805000519</option>
                    <option value="INDIAN OVERSEAS BANK-123456789098">INDIAN OVERSEAS BANK-123456789098</option>
                    <option value="Indian Overseas Bank -123456789098">Indian Overseas Bank -123456789098</option>
                    <option value="HDFC Corporate Escrow Account-502000889123">HDFC Corporate Escrow Account-502000889123</option>
                </select>

                <div class="input-group input-group-sm gl-search">

                    <span class="input-group-text bg-white border-end-0">
                        <i class="mdi mdi-magnify text-muted"></i>
                    </span>

                    <input
                        type="text"
                        class="form-control border-start-0"
                        id="glSearch"
                        placeholder="Search Ledger..."
                    >

                </div>

            </div>

        </div>
    </div>


    {{-- General Ledger Table --}}
    <div class="card shadow-sm border-0 rounded-3">

        <div class="table-responsive">

            <table
                class="table align-middle mb-0 gl-table"
                id="glTable"
            >

                <thead>

                    <tr>

                        <th class="gl-th" style="width: 11%;">
                            DATE
                        </th>

                        <th class="gl-th" style="width: 15%;">
                            PROJECT
                        </th>

                        <th class="gl-th" style="width: 30%;">
                            TYPE
                        </th>

                        <th class="gl-th text-end" style="width: 13%;">
                            OPENING BALANCE
                        </th>

                        <th class="gl-th text-end" style="width: 10%;">
                            CREDIT
                        </th>

                        <th class="gl-th text-end" style="width: 10%;">
                            DEBIT
                        </th>

                        <th class="gl-th text-end" style="width: 11%;">
                            CLOSING BALANCE
                        </th>

                    </tr>

                </thead>



                <tbody
                    class="gl-block"
                    data-account="ICICI Bank Ltd-260805000359"
                >

                    <tr class="gl-account-row">

                        <td></td>
                        <td></td>

                        <td>
                            <strong class="gl-account-name">
                                ICICI Bank Ltd-260805000359
                            </strong>
                        </td>

                        <td class="text-end">
                            <span class="gl-account-amount">
                                -7,09,098.26
                            </span>
                        </td>

                        <td></td>
                        <td></td>
                        <td></td>

                    </tr>

                    <tr
                        class="gl-txn-row"
                        data-date="2026-07-28"
                        data-project="Coastal Expressway Bridge"
                    >

                        <td>28-07-2026</td>

                        <td>Coastal Expressway Bridge</td>

                        <td>
                            <span class="fw-semibold text-dark d-block">
                                Client RA Payment Realization
                            </span>

                            <span class="gl-subtext">
                                Post receipt against certified RA Bill #04
                            </span>
                        </td>

                        <td class="text-end">
                            -7,09,098.26
                        </td>

                        <td class="text-end gl-credit">
                            5,42,866.00
                        </td>

                        <td class="text-end">
                            -
                        </td>

                        <td class="text-end gl-balance">
                            -1,66,232.26
                        </td>

                    </tr>

                    <tr
                        class="gl-txn-row"
                        data-date="2026-07-28"
                        data-project="Coastal Expressway Bridge"
                    >

                        <td>28-07-2026</td>

                        <td>Coastal Expressway Bridge</td>

                        <td>
                            <span class="fw-semibold text-dark d-block">
                                Subcontractor Vendor Outflow
                            </span>

                            <span class="gl-subtext">
                                Earthwork subcontractor interim payout
                            </span>
                        </td>

                        <td class="text-end">
                            -1,66,232.26
                        </td>

                        <td class="text-end">
                            -
                        </td>

                        <td class="text-end gl-debit">
                            1,50,000.00
                        </td>

                        <td class="text-end gl-balance">
                            -3,16,232.26
                        </td>

                    </tr>

                    <tr class="gl-closing-row">

                        <td colspan="6" class="text-end gl-closing-label">
                            CLOSING BALANCE
                        </td>

                        <td class="text-end gl-balance fw-bold">
                            -3,16,232.26
                        </td>

                    </tr>

                </tbody>


                {{-- ============ Block 2 ============ --}}
                <tbody
                    class="gl-block"
                    data-account="ICICI Bank Ltd-260805000519"
                >

                    <tr class="gl-account-row">

                        <td></td>
                        <td></td>

                        <td>
                            <strong class="gl-account-name">
                                ICICI Bank Ltd-260805000519
                            </strong>
                        </td>

                        <td class="text-end">

                            <span class="gl-account-amount">
                                3,30,000.00
                            </span>

                        </td>

                        <td></td>
                        <td></td>
                        <td></td>

                    </tr>

                    <tr
                        class="gl-txn-row"
                        data-date="2026-07-27"
                        data-project="Metro Line Extension - Phase 3"
                    >

                        <td>27-07-2026</td>

                        <td>
                            Metro Line Extension - Phase 3
                        </td>

                        <td>

                            <span class="fw-semibold text-dark d-block">
                                Mobilization Advance Credit
                            </span>

                            <span class="gl-subtext">
                                Interim client credit transfer
                            </span>

                        </td>

                        <td class="text-end">
                            3,30,000.00
                        </td>

                        <td class="text-end gl-credit">
                            2,00,000.00
                        </td>

                        <td class="text-end">
                            -
                        </td>

                        <td class="text-end gl-balance">
                            5,30,000.00
                        </td>

                    </tr>

                    <tr class="gl-closing-row">

                        <td colspan="6" class="text-end gl-closing-label">
                            CLOSING BALANCE
                        </td>

                        <td class="text-end gl-balance fw-bold">
                            5,30,000.00
                        </td>

                    </tr>

                </tbody>


                {{-- ============ Block 3 ============ --}}
                <tbody
                    class="gl-block"
                    data-account="INDIAN OVERSEAS BANK-123456789098"
                >

                    <tr class="gl-account-row">

                        <td></td>
                        <td></td>

                        <td>
                            <strong class="gl-account-name">
                                INDIAN OVERSEAS BANK-123456789098
                            </strong>
                        </td>

                        <td class="text-end">

                            <span class="gl-account-amount">
                                7,50,000.00
                            </span>

                        </td>

                        <td></td>
                        <td></td>
                        <td></td>

                    </tr>

                    <tr
                        class="gl-txn-row"
                        data-date=""
                        data-project=""
                    >

                        <td></td>
                        <td></td>

                        <td>
                            <span class="gl-subtext-line">
                                Opening OD Amount
                            </span>
                        </td>

                        <td class="text-end">
                            5,00,000.00
                        </td>

                        <td class="text-end">-</td>

                        <td class="text-end">-</td>

                        <td class="text-end gl-balance">
                            5,00,000.00
                        </td>

                    </tr>

                    <tr
                        class="gl-txn-row"
                        data-date="2026-07-26"
                        data-project="Skyline Premium Residences"
                    >

                        <td>26-07-2026</td>

                        <td>
                            Skyline Premium Residences
                        </td>

                        <td>

                            <span class="fw-semibold text-dark d-block">
                                Escrow RA Bill Collection
                            </span>

                            <span class="gl-subtext">
                                Direct client deposit
                            </span>

                        </td>

                        <td class="text-end">
                            7,50,000.00
                        </td>

                        <td class="text-end gl-credit">
                            1,25,000.00
                        </td>

                        <td class="text-end">-</td>

                        <td class="text-end gl-balance">
                            8,75,000.00
                        </td>

                    </tr>

                    <tr class="gl-closing-row">

                        <td colspan="6" class="text-end gl-closing-label">
                            CLOSING BALANCE
                        </td>

                        <td class="text-end gl-balance fw-bold">
                            8,75,000.00
                        </td>

                    </tr>

                    <tr
                        class="gl-txn-row"
                        data-date=""
                        data-project=""
                    >

                        <td></td>
                        <td></td>

                        <td>
                            <span class="gl-subtext-line">
                                Closing OD Amount
                            </span>
                        </td>

                        <td class="text-end">-</td>
                        <td class="text-end">-</td>
                        <td class="text-end">-</td>

                        <td class="text-end gl-balance">
                            5,00,000.00
                        </td>

                    </tr>

                </tbody>


                {{-- ============ Block 4 ============ --}}
                <tbody
                    class="gl-block"
                    data-account="Indian Overseas Bank -123456789098"
                >

                    <tr class="gl-account-row">

                        <td></td>
                        <td></td>

                        <td>
                            <strong class="gl-account-name">
                                Indian Overseas Bank -123456789098
                            </strong>
                        </td>

                        <td class="text-end">

                            <span class="gl-account-amount">
                                0.00
                            </span>

                        </td>

                        <td></td>
                        <td></td>
                        <td></td>

                    </tr>

                    <tr class="gl-closing-row">

                        <td colspan="6" class="text-end gl-closing-label">
                            CLOSING BALANCE
                        </td>

                        <td class="text-end gl-balance fw-bold">
                            0.00
                        </td>

                    </tr>

                </tbody>


                {{-- ============ Block 5 ============ --}}
                <tbody
                    class="gl-block"
                    data-account="HDFC Corporate Escrow Account-502000889123"
                >

                    <tr class="gl-account-row">

                        <td></td>
                        <td></td>

                        <td>
                            <strong class="gl-account-name">
                                HDFC Corporate Escrow Account-502000889123
                            </strong>
                        </td>

                        <td class="text-end">

                            <span class="gl-account-amount">
                                12,50,000.00
                            </span>

                        </td>

                        <td></td>
                        <td></td>
                        <td></td>

                    </tr>

                    <tr
                        class="gl-txn-row"
                        data-date="2026-07-25"
                        data-project="Industrial Logistics Park"
                    >

                        <td>25-07-2026</td>

                        <td>
                            Industrial Logistics Park
                        </td>

                        <td>

                            <span class="fw-semibold text-dark d-block">
                                Client Inter-Project Transfer
                            </span>

                            <span class="gl-subtext">
                                Site funding allocation
                            </span>

                        </td>

                        <td class="text-end">
                            12,50,000.00
                        </td>

                        <td class="text-end gl-credit">
                            3,50,000.00
                        </td>

                        <td class="text-end gl-debit">
                            1,00,000.00
                        </td>

                        <td class="text-end gl-balance">
                            15,00,000.00
                        </td>

                    </tr>

                    <tr class="gl-closing-row">

                        <td colspan="6" class="text-end gl-closing-label">
                            CLOSING BALANCE
                        </td>

                        <td class="text-end gl-balance fw-bold">
                            15,00,000.00
                        </td>

                    </tr>

                </tbody>


                {{-- Grand Total --}}
                <tbody class="gl-grand-total-tbody">

                    <tr class="gl-grand-total">

                        <td colspan="6" class="text-end gl-closing-label">
                            CLOSING BALANCE
                        </td>

                        <td class="text-end gl-balance gl-grand-amount">
                            55,88,767.74
                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

    </div>

</div>


<div
    class="gl-modal-overlay"
    id="glPostJournalModal"
>

    <div class="gl-modal">

        {{-- Modal Header --}}
        <div class="gl-modal-header">

            <div class="gl-modal-header-left">

                <div class="gl-modal-icon">
                    <i class="mdi mdi-book-open-page-variant-outline"></i>
                </div>

                <div>

                    <h5 class="gl-modal-title">
                        Post General Ledger Voucher
                    </h5>

                    <p class="gl-modal-subtitle">
                        Log debit or credit transaction to account head
                    </p>

                </div>

            </div>

            <button
                type="button"
                class="gl-modal-close"
                id="glModalCloseBtn"
            >
                <i class="mdi mdi-close"></i>
            </button>

        </div>


        {{-- Modal Body --}}
        <div class="gl-modal-body">

            {{-- Row 1: GL Account --}}
            <div class="gl-form-group">

                <label class="gl-form-label">
                    Select General Ledger Account
                    <span class="text-danger">*</span>
                </label>

                <select
                    class="form-select form-select-sm gl-form-control"
                    id="glVoucherAccount"
                >

                    <option value="ICICI Bank Ltd-260805000359">
                        ICICI Bank Ltd-260805000359
                    </option>

                    <option value="ICICI Bank Ltd-260805000519">
                        ICICI Bank Ltd-260805000519
                    </option>

                    <option value="INDIAN OVERSEAS BANK-123456789098">
                        INDIAN OVERSEAS BANK-123456789098
                    </option>

                    <option value="Indian Overseas Bank -123456789098">
                        Indian Overseas Bank -123456789098
                    </option>

                    <option value="HDFC Corporate Escrow Account-502000889123">
                        HDFC Corporate Escrow Account-502000889123
                    </option>

                </select>

            </div>


            {{-- Row 2: Date & Project --}}
            <div class="gl-form-row">

                <div class="gl-form-group gl-form-half">

                    <label class="gl-form-label">
                        Transaction Date
                        <span class="text-danger">*</span>
                    </label>

                    <div class="gl-date-wrapper">

                        <input
                            type="date"
                            id="glTransactionDate"
                            class="form-control form-control-sm gl-form-control"
                            value="2026-09-18"
                        >

                    </div>

                </div>


                <div class="gl-form-group gl-form-half">

                    <label class="gl-form-label">
                        Associated Project
                        <span class="text-danger">*</span>
                    </label>

                    <select
                        class="form-select form-select-sm gl-form-control"
                        id="glVoucherProject"
                    >

                        <option value="">
                            Chennai Metro Phase 2 - Corrido
                        </option>

                        <option value="Coastal Expressway Bridge">
                            Coastal Expressway Bridge
                        </option>

                        <option value="Metro Line Extension - Phase 3">
                            Metro Line Extension - Phase 3
                        </option>

                        <option value="Skyline Premium Residences">
                            Skyline Premium Residences
                        </option>

                        <option value="Industrial Logistics Park">
                            Industrial Logistics Park
                        </option>

                    </select>

                </div>

            </div>


            {{-- Row 3: Type & Credit/Debit --}}
            <div class="gl-form-row">

                <div class="gl-form-group gl-form-half">

                    <label class="gl-form-label">
                        Transaction Type / Narration
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        id="glVoucherNarration"
                        class="form-control form-control-sm gl-form-control"
                        placeholder="e.g. Subcontractor Vendor Outflow"
                    >

                </div>


                <div class="gl-form-group gl-form-half">

                    <label class="gl-form-label">
                        Credit or Debit
                        <span class="text-danger">*</span>
                    </label>

                    <select
                        class="form-select form-select-sm gl-form-control"
                        id="glVoucherType"
                    >

                        <option value="Credit">
                            Credit (+ Inflow)
                        </option>

                        <option value="Debit">
                            Debit (- Outflow)
                        </option>

                    </select>

                </div>

            </div>


            {{-- Row 4: Amount & Remarks --}}
            <div class="gl-form-row">

                <div class="gl-form-group gl-form-half">

                    <label class="gl-form-label">
                        Amount ($)
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        id="glVoucherAmount"
                        class="form-control form-control-sm gl-form-control"
                        placeholder="e.g. 150000"
                    >

                </div>


                <div class="gl-form-group gl-form-half">

                    <label class="gl-form-label">
                        Remarks / Reference
                    </label>

                    <input
                        type="text"
                        id="glVoucherRemarks"
                        class="form-control form-control-sm gl-form-control"
                        placeholder="e.g. Check / UTR #88192"
                    >

                </div>

            </div>

        </div>


        {{-- Modal Footer --}}
        <div class="gl-modal-footer">

            <button
                type="button"
                class="btn btn-sm gl-btn-cancel"
                id="glModalCancelBtn"
            >
                Cancel
            </button>

            <button
                type="button"
                class="btn btn-sm gl-btn-submit"
                id="glSubmitJournalBtn"
            >
                Post Journal Entry
            </button>

        </div>

    </div>

</div>


<style>

    /* ---------- Filter Row ---------- */

    .gl-filter-row {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: nowrap;
        width: 100%;
    }

    .gl-date-input {
        width: 150px;
        min-height: 34px;
        font-size: 12.5px;
    }

    .gl-go-btn {
        min-height: 34px;
        padding: 0 20px;
        font-size: 12px;
        letter-spacing: .05em;
    }

    .gl-filter-spacer {
        flex: 1 1 auto;
    }

    .gl-project-select {
        width: 180px;
        min-height: 34px;
        font-size: 12.5px;
    }

    .gl-account-select {
        width: 260px;
        min-height: 34px;
        font-size: 12.5px;
    }

    .gl-search {
        width: 220px;
    }

    .gl-search .form-control {
        min-height: 34px;
        font-size: 12.5px;
    }

    @media (max-width: 1200px) {

        .gl-filter-row {
            flex-wrap: wrap;
        }

        .gl-filter-spacer {
            display: none;
        }

        .gl-search {
            flex: 1 1 100%;
            width: auto;
        }

    }


    /* ---------- General Ledger Table ---------- */

    .gl-table {
        font-size: 12.5px;
    }

    .gl-table > :not(caption) > * > * {
        border-bottom-width: 1px;
        border-color: #eef0f4;
    }

    .gl-table .gl-th {
        background: #ffffff;
        font-size: 10px;
        letter-spacing: .05em;
        text-transform: uppercase;
        font-weight: 700;
        color: #6c757d;
        padding: 14px 16px;
        border-bottom: 1px solid #eef0f4 !important;
        white-space: nowrap;
    }

    .gl-table .gl-th i {
        font-size: 11px;
        opacity: .5;
    }

    .gl-account-row td {
        background: #f8f9fc;
        padding: 12px 16px;
        border-bottom: 1px solid #eef0f4;
        border-top: 1px solid #eef0f4;
    }

    .gl-account-name {
        color: #1a2332;
        font-size: 13px;
        font-weight: 700;
    }

    .gl-account-amount {
        font-size: 12.5px;
        font-weight: 600;
        color: #1a2332;
    }

    .gl-txn-row td {
        padding: 12px 16px;
        border-bottom: 1px dashed #eef0f4;
        vertical-align: middle;
        font-size: 12.5px;
        color: #495057;
    }

    .gl-txn-row .gl-subtext {
        display: block;
        font-size: 11px;
        color: #6c757d;
        font-style: italic;
        margin-top: 2px;
    }

    .gl-txn-row .gl-subtext-line {
        font-size: 12.5px;
        color: #495057;
        font-style: italic;
    }

    .gl-credit {
        color: #16a34a;
        font-weight: 600;
    }

    .gl-debit {
        color: #1a2332;
        font-weight: 600;
    }

    .gl-balance {
        color: #1a2332;
        font-weight: 500;
    }

    .gl-closing-row td {
        padding: 12px 16px;
        background: transparent;
        border-bottom: 1px solid #eef0f4;
    }

    .gl-closing-label {
        font-size: 11px;
        letter-spacing: .05em;
        text-transform: uppercase;
        font-weight: 700;
        color: #495057;
    }

    .gl-closing-row .gl-balance {
        color: #1a2332;
        font-weight: 600;
    }

    .gl-grand-total td {
        padding: 14px 16px;
        border-top: 1px solid #ced4da;
        border-bottom: 1px solid #ced4da;
        background: transparent;
    }

    .gl-grand-total .gl-closing-label {
        font-weight: 800;
        color: #1a2332;
    }

    .gl-grand-total .gl-grand-amount {
        font-size: 14px;
        font-weight: 800;
        color: #1a2332;
        text-decoration: underline;
    }


    /* ---------- Card & Buttons ---------- */

    .card {
        border: 1px solid #eef0f4 !important;
    }

    .text-primary {
        color: #16659E !important;
    }

    .btn-primary {
        background-color: #16659E !important;
        border-color: #16659E !important;
    }

    .btn-primary:hover {
        background-color: #124f7c !important;
        border-color: #124f7c !important;
    }

    .btn-outline-primary {
        color: #16659E !important;
        border-color: #16659E !important;
    }

    .btn-outline-primary:hover {
        background-color: #16659E !important;
        color: #fff !important;
    }


    /* ============================================================ */
    /* POST JOURNAL ENTRY MODAL */
    /* ============================================================ */

    .gl-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(3px);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        padding: 20px;
    }

    .gl-modal-overlay.gl-modal-open {
        display: flex;
    }

    .gl-modal {
        background: #ffffff;
        border-radius: 16px;
        width: 100%;
        max-width: 640px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        padding: 24px 28px 20px 28px;
        animation: glModalFadeIn 0.2s ease-out;
    }

    @keyframes glModalFadeIn {

        from {
            opacity: 0;
            transform: translateY(10px) scale(0.98);
        }

        to {
            opacity: 1;
            transform: translateY(0) scale(1);
        }

    }

    .gl-modal-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 20px;
    }

    .gl-modal-header-left {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .gl-modal-icon {
        width: 40px;
        height: 40px;
        background: #eaf3fa;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #16659E;
        font-size: 20px;
        flex-shrink: 0;
    }

    .gl-modal-title {
        font-size: 16px;
        font-weight: 700;
        color: #1a2332;
        margin: 0 0 2px 0;
        line-height: 1.2;
    }

    .gl-modal-subtitle {
        font-size: 12px;
        color: #6c757d;
        margin: 0;
        line-height: 1.3;
    }

    .gl-modal-close {
        background: transparent;
        border: none;
        font-size: 20px;
        color: #adb5bd;
        cursor: pointer;
        padding: 0;
        line-height: 1;
        transition: color 0.2s;
        margin-top: 2px;
    }

    .gl-modal-close:hover {
        color: #495057;
    }

    .gl-modal-body {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    .gl-form-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .gl-form-row {
        display: flex;
        gap: 16px;
    }

    .gl-form-half {
        flex: 1 1 0;
        min-width: 0;
    }

    .gl-form-label {
        font-size: 12px;
        font-weight: 600;
        color: #1a2332;
        margin: 0;
    }

    .gl-form-label .text-danger {
        color: #dc3545 !important;
    }

    .gl-form-control {
        font-size: 12.5px;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 7px 12px;
        color: #495057;
        background-color: #ffffff;
        min-height: 38px;
        box-shadow: none;
        transition: border-color 0.2s;
    }

    .gl-form-control:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 0.15rem rgba(22, 101, 158, 0.15);
    }

    .gl-form-control::placeholder {
        color: #adb5bd;
        font-size: 12px;
    }

    .gl-date-wrapper {
        position: relative;
    }

    .gl-date-wrapper .gl-form-control {
        padding-right: 36px;
    }

    .gl-date-icon {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 16px;
        color: #6c757d;
        pointer-events: auto;
        cursor: pointer;
        z-index: 2;
    }

    .gl-modal-footer {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: 10px;
        margin-top: 24px;
        padding-top: 16px;
        border-top: 1px solid #f0f2f5;
    }

    .gl-btn-cancel {
        background: #f1f3f5;
        border: 1px solid #f1f3f5;
        color: #495057;
        font-weight: 500;
        font-size: 12.5px;
        padding: 8px 24px;
        border-radius: 8px;
        transition: background 0.2s;
    }

    .gl-btn-cancel:hover {
        background: #e9ecef;
        border-color: #e9ecef;
        color: #1a2332;
    }

    .gl-btn-submit {
        background-color: #16659E !important;
        border-color: #16659E !important;
        color: #ffffff !important;
        font-weight: 600;
        font-size: 12.5px;
        padding: 8px 24px;
        border-radius: 8px;
        transition: background 0.2s;
    }

    .gl-btn-submit:hover {
        background-color: #124f7c !important;
        border-color: #124f7c !important;
    }

    @media (max-width: 576px) {

        .gl-modal {
            padding: 18px;
        }

        .gl-form-row {
            flex-direction: column;
            gap: 16px;
        }

        .gl-modal-footer {
            flex-direction: column-reverse;
        }

        .gl-btn-cancel,
        .gl-btn-submit {
            width: 100%;
            text-align: center;
        }

    }

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    /* ============================================================
       ELEMENT REFERENCES
    ============================================================ */

    const glFromDate = document.getElementById('glFromDate');
    const glToDate = document.getElementById('glToDate');
    const glGoBtn = document.getElementById('glGoBtn');
    const glResetBtn = document.getElementById('glResetBtn');

    const glProjectFilter =
        document.getElementById('glProjectFilter');

    const glAccountFilter =
        document.getElementById('glAccountFilter');

    const glSearch =
        document.getElementById('glSearch');

    const glTable =
        document.getElementById('glTable');

    const blocks =
        glTable.querySelectorAll('tbody.gl-block');

    const grandTotalTbody =
        glTable.querySelector('tbody.gl-grand-total-tbody');


    /* ============================================================
       MODAL REFERENCES
    ============================================================ */

    const glPostJournalBtn =
        document.getElementById('glPostJournalBtn');

    const glPostJournalModal =
        document.getElementById('glPostJournalModal');

    const glModalCloseBtn =
        document.getElementById('glModalCloseBtn');

    const glModalCancelBtn =
        document.getElementById('glModalCancelBtn');

    const glSubmitJournalBtn =
        document.getElementById('glSubmitJournalBtn');


    /* ============================================================
       VOUCHER FORM REFERENCES
    ============================================================ */

    const glVoucherAccount =
        document.getElementById('glVoucherAccount');

    const glTransactionDate =
        document.getElementById('glTransactionDate');

    const glTransactionDateIcon =
        document.getElementById('glTransactionDateIcon');

    const glVoucherProject =
        document.getElementById('glVoucherProject');

    const glVoucherNarration =
        document.getElementById('glVoucherNarration');

    const glVoucherType =
        document.getElementById('glVoucherType');

    const glVoucherAmount =
        document.getElementById('glVoucherAmount');

    const glVoucherRemarks =
        document.getElementById('glVoucherRemarks');


    /* ============================================================
       EXPORT
    ============================================================ */

    const glExportBtn =
        document.getElementById('glExportBtn');


    /* ============================================================
       DATE PARSER
    ============================================================ */

    function parseDate(value) {

        if (!value) {
            return null;
        }

        const d = new Date(value + 'T00:00:00');

        return isNaN(d.getTime()) ? null : d;

    }


    /* ============================================================
       DATE FORMAT
    ============================================================ */

    function formatDisplayDate(value) {

        if (!value) {
            return '';
        }

        const parts = value.split('-');

        if (parts.length !== 3) {
            return value;
        }

        return parts[2] + '-' + parts[1] + '-' + parts[0];

    }


    /* ============================================================
       NUMBER FORMAT
    ============================================================ */

    function formatAmount(number) {

        const value = Number(number);

        if (isNaN(value)) {
            return '0.00';
        }

        return value.toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

    }


    /* ============================================================
       GET NUMERIC VALUE FROM TABLE
    ============================================================ */

    function getNumericAmount(value) {

        if (!value) {
            return 0;
        }

        let cleaned = value
            .replace(/,/g, '')
            .replace(/\$/g, '')
            .trim();

        if (cleaned === '-' || cleaned === '') {
            return 0;
        }

        return parseFloat(cleaned) || 0;

    }


    /* ============================================================
       APPLY FILTERS
    ============================================================ */

    function applyGlFilters() {

        const from =
            parseDate(
                glFromDate ? glFromDate.value : ''
            );

        const to =
            parseDate(
                glToDate ? glToDate.value : ''
            );

        const project =
            (
                glProjectFilter
                    ? glProjectFilter.value
                    : ''
            )
            .toLowerCase()
            .trim();

        const account =
            (
                glAccountFilter
                    ? glAccountFilter.value
                    : ''
            )
            .toLowerCase()
            .trim();

        const search =
            (
                glSearch
                    ? glSearch.value
                    : ''
            )
            .toLowerCase()
            .trim();

        let anyBlockVisible = false;


        blocks.forEach(function (block) {

            const blockAccount =
                (
                    block.getAttribute(
                        'data-account'
                    ) || ''
                ).toLowerCase();

            const accountMatch =
                account === '' ||
                blockAccount === account;


            if (!accountMatch) {

                block.style.display = 'none';

                return;

            }


            const txnRows =
                block.querySelectorAll(
                    '.gl-txn-row'
                );

            let visibleTxns = 0;


            txnRows.forEach(function (row) {

                const rowDateStr =
                    row.getAttribute(
                        'data-date'
                    ) || '';

                const rowDate =
                    parseDate(rowDateStr);

                const rowProject =
                    (
                        row.getAttribute(
                            'data-project'
                        ) || ''
                    ).toLowerCase();

                const rowText =
                    row.innerText.toLowerCase();


                let dateMatch = true;


                if (rowDate) {

                    if (from && rowDate < from) {
                        dateMatch = false;
                    }

                    if (to && rowDate > to) {
                        dateMatch = false;
                    }

                } else {

                    if (from || to) {
                        dateMatch = false;
                    }

                }


                const projectMatch =
                    project === '' ||
                    rowProject.includes(project);

                const searchMatch =
                    search === '' ||
                    rowText.includes(search);


                const match =
                    dateMatch &&
                    projectMatch &&
                    searchMatch;


                row.style.display =
                    match ? '' : 'none';


                if (match) {
                    visibleTxns++;
                }

            });


            const showBlock =
                visibleTxns > 0;

            block.style.display =
                showBlock ? '' : 'none';


            if (showBlock) {
                anyBlockVisible = true;
            }

        });


        if (grandTotalTbody) {

            grandTotalTbody.style.display =
                anyBlockVisible ? '' : 'none';

        }

    }


    /* ============================================================
       GO BUTTON
    ============================================================ */

    if (glGoBtn) {

        glGoBtn.addEventListener(
            'click',
            function (e) {

                e.preventDefault();

                applyGlFilters();

            }
        );

    }


    /* ============================================================
       RESET BUTTON
    ============================================================ */

    if (glResetBtn) {

        glResetBtn.addEventListener(
            'click',
            function () {

                if (glFromDate) {
                    glFromDate.value = '';
                }

                if (glToDate) {
                    glToDate.value = '';
                }

                if (glProjectFilter) {
                    glProjectFilter.value = '';
                }

                if (glAccountFilter) {
                    glAccountFilter.value = '';
                }

                if (glSearch) {
                    glSearch.value = '';
                }

                applyGlFilters();

            }
        );

    }


    /* ============================================================
       FILTER EVENTS
    ============================================================ */

    if (glFromDate) {

        glFromDate.addEventListener(
            'change',
            applyGlFilters
        );

    }

    if (glToDate) {

        glToDate.addEventListener(
            'change',
            applyGlFilters
        );

    }

    if (glProjectFilter) {

        glProjectFilter.addEventListener(
            'change',
            applyGlFilters
        );

    }

    if (glAccountFilter) {

        glAccountFilter.addEventListener(
            'change',
            applyGlFilters
        );

    }

    if (glSearch) {

        glSearch.addEventListener(
            'input',
            applyGlFilters
        );

    }


    /* ============================================================
       TRANSACTION DATE CALENDAR
    ============================================================ */

    if (
        glTransactionDateIcon &&
        glTransactionDate
    ) {

        glTransactionDateIcon.addEventListener(
            'click',
            function () {

                if (
                    typeof glTransactionDate.showPicker ===
                    'function'
                ) {

                    glTransactionDate.showPicker();

                } else {

                    glTransactionDate.focus();

                }

            }
        );

    }


    /* ============================================================
       MODAL OPEN
    ============================================================ */

    function openModal() {

        if (glPostJournalModal) {

            glPostJournalModal.classList.add(
                'gl-modal-open'
            );

            document.body.style.overflow =
                'hidden';

        }

    }


    /* ============================================================
       MODAL CLOSE
    ============================================================ */

    function closeModal() {

        if (glPostJournalModal) {

            glPostJournalModal.classList.remove(
                'gl-modal-open'
            );

            document.body.style.overflow = '';

        }

    }


    /* ============================================================
       RESET VOUCHER FORM
    ============================================================ */

    function resetVoucherForm() {

        if (glVoucherAccount) {
            glVoucherAccount.selectedIndex = 0;
        }

        if (glTransactionDate) {

            glTransactionDate.value =
                new Date().toISOString().split('T')[0];

        }

        if (glVoucherProject) {
            glVoucherProject.selectedIndex = 0;
        }

        if (glVoucherNarration) {
            glVoucherNarration.value = '';
        }

        if (glVoucherType) {
            glVoucherType.value = 'Credit';
        }

        if (glVoucherAmount) {
            glVoucherAmount.value = '';
        }

        if (glVoucherRemarks) {
            glVoucherRemarks.value = '';
        }

    }


    /* ============================================================
       OPEN MODAL BUTTON
    ============================================================ */

    if (glPostJournalBtn) {

        glPostJournalBtn.addEventListener(
            'click',
            function (e) {

                e.preventDefault();

                openModal();

            }
        );

    }


    /* ============================================================
       CLOSE X
    ============================================================ */

    if (glModalCloseBtn) {

        glModalCloseBtn.addEventListener(
            'click',
            closeModal
        );

    }


    /* ============================================================
       CLOSE CANCEL
    ============================================================ */

    if (glModalCancelBtn) {

        glModalCancelBtn.addEventListener(
            'click',
            closeModal
        );

    }


    /* ============================================================
       CLOSE OUTSIDE
    ============================================================ */

    if (glPostJournalModal) {

        glPostJournalModal.addEventListener(
            'click',
            function (e) {

                if (
                    e.target ===
                    glPostJournalModal
                ) {

                    closeModal();

                }

            }
        );

    }


    /* ============================================================
       ESCAPE
    ============================================================ */

    document.addEventListener(
        'keydown',
        function (e) {

            if (
                e.key === 'Escape' &&
                glPostJournalModal &&
                glPostJournalModal.classList.contains(
                    'gl-modal-open'
                )
            ) {

                closeModal();

            }

        }
    );


    /* ============================================================
       POST JOURNAL ENTRY
    ============================================================ */

    if (glSubmitJournalBtn) {

        glSubmitJournalBtn.addEventListener(
            'click',
            function () {

                const account =
                    glVoucherAccount
                        ? glVoucherAccount.value.trim()
                        : '';

                const transactionDate =
                    glTransactionDate
                        ? glTransactionDate.value
                        : '';

                const project =
                    glVoucherProject
                        ? glVoucherProject.value.trim()
                        : '';

                const narration =
                    glVoucherNarration
                        ? glVoucherNarration.value.trim()
                        : '';

                const transactionType =
                    glVoucherType
                        ? glVoucherType.value
                        : 'Credit';

                const amount =
                    glVoucherAmount
                        ? getNumericAmount(
                            glVoucherAmount.value
                        )
                        : 0;

                const remarks =
                    glVoucherRemarks
                        ? glVoucherRemarks.value.trim()
                        : '';


                /* ---------- Validation ---------- */

                if (!account) {

                    alert(
                        'Please select a General Ledger Account.'
                    );

                    return;

                }

                if (!transactionDate) {

                    alert(
                        'Please select Transaction Date.'
                    );

                    return;

                }

                if (!project) {

                    alert(
                        'Please select Associated Project.'
                    );

                    return;

                }

                if (!narration) {

                    alert(
                        'Please enter Transaction Type / Narration.'
                    );

                    return;

                }

                if (!amount || amount <= 0) {

                    alert(
                        'Please enter a valid Amount.'
                    );

                    return;

                }


                /* ---------- Find Account Block ---------- */

                let accountBlock = null;

                blocks.forEach(function (block) {

                    const blockAccount =
                        (
                            block.getAttribute(
                                'data-account'
                            ) || ''
                        ).trim();

                    if (
                        blockAccount.toLowerCase() ===
                        account.toLowerCase()
                    ) {

                        accountBlock = block;

                    }

                });


                if (!accountBlock) {

                    alert(
                        'Selected GL Account was not found in the ledger table.'
                    );

                    return;

                }


                /* ---------- Find Closing Row ---------- */

                let closingRow =
                    accountBlock.querySelector(
                        '.gl-closing-row'
                    );


                /* ---------- Get Current Closing Balance ---------- */

                let currentBalance = 0;


                if (closingRow) {

                    const balanceCell =
                        closingRow.querySelector(
                            '.gl-balance'
                        );

                    if (balanceCell) {

                        currentBalance =
                            getNumericAmount(
                                balanceCell.innerText
                            );

                    }

                }


                /* ---------- Calculate New Balance ---------- */

                let newBalance =
                    currentBalance;

                if (
                    transactionType ===
                    'Credit'
                ) {

                    newBalance =
                        currentBalance + amount;

                } else {

                    newBalance =
                        currentBalance - amount;

                }


                /* ---------- Create New Transaction Row ---------- */

                const newRow =
                    document.createElement('tr');

                newRow.className =
                    'gl-txn-row';

                newRow.setAttribute(
                    'data-date',
                    transactionDate
                );

                newRow.setAttribute(
                    'data-project',
                    project
                );


                const displayDate =
                    formatDisplayDate(
                        transactionDate
                    );


                let narrationHtml =
                    '<span class="fw-semibold text-dark d-block">' +
                    escapeHtml(narration) +
                    '</span>';


                if (remarks) {

                    narrationHtml +=
                        '<span class="gl-subtext">' +
                        escapeHtml(remarks) +
                        '</span>';

                }


                const creditHtml =
                    transactionType === 'Credit'
                        ? '<span class="gl-credit">' +
                            formatAmount(amount) +
                          '</span>'
                        : '-';


                const debitHtml =
                    transactionType === 'Debit'
                        ? '<span class="gl-debit">' +
                            formatAmount(amount) +
                          '</span>'
                        : '-';


                newRow.innerHTML =

                    '<td>' +
                        escapeHtml(displayDate) +
                    '</td>' +

                    '<td>' +
                        escapeHtml(project) +
                    '</td>' +

                    '<td>' +
                        narrationHtml +
                    '</td>' +

                    '<td class="text-end">' +
                        formatAmount(currentBalance) +
                    '</td>' +

                    '<td class="text-end">' +
                        creditHtml +
                    '</td>' +

                    '<td class="text-end">' +
                        debitHtml +
                    '</td>' +

                    '<td class="text-end gl-balance">' +
                        formatAmount(newBalance) +
                    '</td>';


                /* ---------- Insert Before Closing Row ---------- */

                if (closingRow) {

                    accountBlock.insertBefore(
                        newRow,
                        closingRow
                    );

                } else {

                    accountBlock.appendChild(
                        newRow
                    );

                }


                /* ---------- Update Closing Balance ---------- */

                if (closingRow) {

                    const closingBalance =
                        closingRow.querySelector(
                            '.gl-balance'
                        );

                    if (closingBalance) {

                        closingBalance.innerText =
                            formatAmount(newBalance);

                    }

                }


                /* ---------- Update Account Amount ---------- */

                const accountAmount =
                    accountBlock.querySelector(
                        '.gl-account-amount'
                    );

                if (accountAmount) {

                    accountAmount.innerText =
                        formatAmount(newBalance);

                }


                /* ---------- Update Grand Total ---------- */

                updateGrandTotal();


                /* ---------- Refresh Filters ---------- */

                applyGlFilters();


                /* ---------- Close Modal ---------- */

                closeModal();


                /* ---------- Reset Form ---------- */

                resetVoucherForm();


                /* ---------- Success Message ---------- */

                alert(
                    'Journal Entry posted successfully.'
                );

            }
        );

    }


    /* ============================================================
       ESCAPE HTML
    ============================================================ */

    function escapeHtml(value) {

        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');

    }


    /* ============================================================
       UPDATE GRAND TOTAL
    ============================================================ */

    function updateGrandTotal() {

        if (!grandTotalTbody) {
            return;
        }

        let total = 0;


        blocks.forEach(function (block) {

            const closingRow =
                block.querySelector(
                    '.gl-closing-row'
                );

            if (!closingRow) {
                return;
            }

            const balance =
                closingRow.querySelector(
                    '.gl-balance'
                );

            if (!balance) {
                return;
            }

            total +=
                getNumericAmount(
                    balance.innerText
                );

        });


        const grandAmount =
            grandTotalTbody.querySelector(
                '.gl-grand-amount'
            );


        if (grandAmount) {

            grandAmount.innerText =
                formatAmount(total);

        }

    }


    /* ============================================================
       EXPORT CSV
    ============================================================ */

    if (glExportBtn) {

        glExportBtn.addEventListener(
            'click',
            function () {

                if (!glTable) {
                    return;
                }


                const rows =
                    glTable.querySelectorAll('tr');

                const csvRows = [];


                rows.forEach(function (row) {

                    const parentBody =
                        row.closest('tbody');


                    if (
                        parentBody &&
                        parentBody.style.display ===
                        'none'
                    ) {

                        return;

                    }


                    if (
                        row.style.display ===
                        'none'
                    ) {

                        return;

                    }


                    const cells =
                        row.querySelectorAll(
                            'th, td'
                        );


                    if (!cells.length) {
                        return;
                    }


                    const rowData = [];


                    cells.forEach(function (cell) {

                        let text =
                            cell.innerText
                                .replace(/\s+/g, ' ')
                                .trim()
                                .replace(/"/g, '""');


                        rowData.push(
                            '"' + text + '"'
                        );

                    });


                    csvRows.push(
                        rowData.join(',')
                    );

                });


                if (!csvRows.length) {

                    alert(
                        'No ledger data available to export.'
                    );

                    return;

                }


                const csvContent =
                    csvRows.join('\n');


                const blob =
                    new Blob(
                        [csvContent],
                        {
                            type:
                                'text/csv;charset=utf-8;'
                        }
                    );


                const url =
                    URL.createObjectURL(blob);


                const link =
                    document.createElement('a');


                link.href = url;

                link.download =
                    'general-ledger.csv';


                document.body.appendChild(link);

                link.click();

                document.body.removeChild(link);

                URL.revokeObjectURL(url);

            }
        );

    }


    /* ============================================================
       INITIAL LOAD
    ============================================================ */

    applyGlFilters();

});

</script>

@endsection
