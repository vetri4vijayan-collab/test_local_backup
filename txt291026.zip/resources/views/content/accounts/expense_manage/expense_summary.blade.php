@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
    <div class="card shadow-sm rounded-2 mb-4">
        <div class="card-body p-3 p-md-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

                {{-- Title & Icon --}}
                <div class="d-flex align-items-center gap-3">
                    <i class="mdi mdi-swap-horizontal-circle-outline fs-1 text-primary"></i>

                    <div>
                        <h4 class="mb-1 fw-bold text-primary fs-5">
                            Site Wise Expenditure - Credit &amp; Debit Ledger
                        </h4>

                        <p class="text-muted mb-0 fs-8">
                            Comprehensive list view of site receipts (Credits) and contractor / material payouts (Debits) by project
                        </p>
                    </div>
                </div>

                {{-- Navigation & Action Buttons --}}
                <div class="nav-scroll-wrapper">
                    <div class="nav-scroll-container d-flex justify-content-end align-items-center gap-2">
                        @php
                            $isListViewActive    = request()->is('/accounts/expense-management');
                            $isSiteSummaryActive = request()->is('accounts/expense-management/summary');
                        @endphp

                        {{-- Tab Pills --}}
                        <div class="d-inline-flex border rounded-2 overflow-hidden bg-light">
                            <a href="{{ url('accounts/expense-management') }}"
                               class="btn btn-sm settings-tab-pill rounded-0 border-0 text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold {{ $isListViewActive ? 'btn-primary' : 'btn-light' }}">
                                <span class="mdi mdi-format-list-bulleted me-2"></span>
                                List View
                            </a>

                            <a href="{{ url('/site/expenditure/summary') }}"
                               class="btn btn-sm settings-tab-pill rounded-0 border-0 text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold {{ $isSiteSummaryActive ? 'btn-primary' : 'btn-light' }}">
                                <span class="mdi mdi-view-dashboard-outline me-2"></span>
                                Site Summary
                            </a>
                        </div>

                        {{-- Log Transaction Button --}}
                       <button type="button"
                              class="btn btn-sm btn-success text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold"
                              data-bs-toggle="modal"
                              data-bs-target="#siteExpenditureModal">
                          <span class="mdi mdi-plus-circle-outline me-2"></span>
                          Log Site Transaction
                      </button>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-3">
            <div class="filter-layout d-flex flex-column flex-md-row align-items-stretch align-items-md-center justify-content-between gap-3">

                {{-- Search --}}
                <div class="filter-search flex-grow-1" style="max-width: 500px;">
                    <div class="position-relative">
                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                              style="pointer-events: none;">
                            <i class="mdi mdi-magnify fs-5"></i>
                        </span>

                        <input id="hr-search-field"
                               type="text"
                               placeholder="Search staff, designation or email"
                               class="form-control form-control-sm ps-7 bg-light border-0 rounded-3 text-secondary" />
                    </div>
                </div>

                {{-- Right Filters --}}
                <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2">

                    {{-- Project Filter --}}
                    <div class="filter-project">
                        <select id="projectFilter"
                                class="form-select form-select-sm bg-light border-0 rounded-3"
                                style="min-width: 200px;">
                            <option value="">All Projects</option>
                            <option value="maa-met-c4">MAA-MET-C4 - Chennai Metro Phase 2 Corridor 4</option>
                            <option value="ady-res">ADY-RES - Adyar Residential Project</option>
                            <option value="ecr-brg">ECR-BRG - ECR Bridge Works</option>
                            <option value="sip-log">SIP-LOG - SIP Logistics Project</option>
                            <option value="elc-hq">ELC-HQ - Elysium Head Office</option>
                        </select>
                    </div>

                    {{-- Status Filter --}}
                    <div class="filter-status">
                        <select id="statusFilter"
                                class="form-select form-select-sm bg-light border-0 rounded-3"
                                style="min-width: 160px;">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="pending">Pending</option>
                            <option value="completed">Completed</option>
                            <option value="on-hold">On Hold</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">

    <!-- Card 1 -->
    <div class="col-12 col-lg-6">
        <div class="card shadow-sm rounded-3 h-100">
            <div class="card-body p-4">

                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <h5 class="mb-1 fw-bold text-primary">
                            Metro Line Extension - Phase 3
                        </h5>
                        <p class="text-muted mb-0 fs-7">
                            Site Budget
                        </p>
                    </div>

                    <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2">
                        +14.4% Buffer
                    </span>
                </div>

                <div class="border-top pt-3">

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label mb-1 fw-semibold text-muted">
                                Raw Materials
                            </label>
                            <div class="form-control bg-light fw-semibold">
                                ₹ 42,00,000
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label mb-1 fw-semibold text-muted">
                                Labor & Wages
                            </label>
                            <div class="form-control bg-light fw-semibold">
                                ₹ 18,00,000
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label mb-1 fw-semibold text-muted">
                                Equipment Lease
                            </label>
                            <div class="form-control bg-light fw-semibold">
                                ₹ 9,50,000
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label mb-1 fw-semibold text-muted">
                                Site Overheads
                            </label>
                            <div class="form-control bg-light fw-semibold">
                                ₹ 3,20,000
                            </div>
                        </div>

                    </div>

                </div>

                <div class="bg-light rounded-3 p-3 mt-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-semibold text-muted">
                            Total Spent / Allocated
                        </span>

                        <span class="fw-bold text-primary">
                            ₹ 72,70,000 / ₹ 85,00,000
                        </span>
                    </div>
                </div>

            </div>
        </div>
    </div>


<!-- Card 2 -->
<div class="col-12 col-lg-6">
    <div class="card shadow-sm rounded-3 h-100">
        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <h5 class="mb-1 fw-bold text-primary">
                        Adyar Premium Residences
                    </h5>
                    <p class="text-muted mb-0 fs-7">
                        Site Budget
                    </p>
                </div>

                <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2">
                    +11.8% Buffer
                </span>
            </div>

            <div class="border-top pt-3">

                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Raw Materials
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 28,50,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Labor & Wages
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 14,25,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Equipment Lease
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 6,75,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Site Overheads
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 3,10,000
                        </div>
                    </div>

                </div>

            </div>

            <div class="bg-light rounded-3 p-3 mt-3">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="fw-semibold text-muted">
                        Total Spent / Allocated
                    </span>

                    <span class="fw-bold text-primary">
                        ₹ 52,60,000 / ₹ 62,00,000
                    </span>
                </div>
            </div>

        </div>
    </div>
</div>


<!-- Card 3 -->
<div class="col-12 col-lg-6">
    <div class="card shadow-sm rounded-3 h-100">
        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <h5 class="mb-1 fw-bold text-primary">
                        ECR Bridge Construction
                    </h5>
                    <p class="text-muted mb-0 fs-7">
                        Site Budget
                    </p>
                </div>

                <span class="badge bg-warning-subtle text-warning rounded-pill px-3 py-2">
                    +9.6% Buffer
                </span>
            </div>

            <div class="border-top pt-3">

                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Raw Materials
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 21,50,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Labor & Wages
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 11,80,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Equipment Lease
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 5,40,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Site Overheads
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 2,35,000
                        </div>
                    </div>

                </div>

            </div>

            <div class="bg-light rounded-3 p-3 mt-3">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="fw-semibold text-muted">
                        Total Spent / Allocated
                    </span>

                    <span class="fw-bold text-primary">
                        ₹ 41,05,000 / ₹ 48,00,000
                    </span>
                </div>
            </div>

        </div>
    </div>
</div>


<!-- Card 4 -->
<div class="col-12 col-lg-6">
    <div class="card shadow-sm rounded-3 h-100">
        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <h5 class="mb-1 fw-bold text-primary">
                        SIP Logistics Park
                    </h5>
                    <p class="text-muted mb-0 fs-7">
                        Site Budget
                    </p>
                </div>

                <span class="badge bg-danger-subtle text-danger rounded-pill px-3 py-2">
                    +7.2% Buffer
                </span>
            </div>

            <div class="border-top pt-3">

                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Raw Materials
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 25,75,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Labor & Wages
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 12,50,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Equipment Lease
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 6,25,000
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label mb-1 fw-semibold text-muted">
                            Site Overheads
                        </label>
                        <div class="form-control bg-light fw-semibold">
                            ₹ 3,15,000
                        </div>
                    </div>

                </div>

            </div>

            <div class="bg-light rounded-3 p-3 mt-3">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="fw-semibold text-muted">
                        Total Spent / Allocated
                    </span>

                    <span class="fw-bold text-primary">
                        ₹ 47,65,000 / ₹ 55,00,000
                    </span>
                </div>
            </div>

        </div>
    </div>
</div>

</div>

<div class="modal fade" id="siteExpenditureModal" tabindex="-1" aria-labelledby="siteExpenditureModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-3 border-0 shadow ">

            <div class="modal-header bg-primary">
                <h5 class="modal-title fw-bold text-white p-3" id="siteExpenditureModalLabel">
                    LOG SITE EXPENDITURE / RECEIPT
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <div class="modal-body p-4">

                <div class="row g-3">

                    <!-- Project / Site -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">
                            Project / Site <span class="text-danger">*</span>
                        </label>

                        <select class="form-select">
                            <option value="">Select Project / Site</option>
                            <option>Chennai Metro Phase 2 - Corridor 4</option>
                            <option>Adyar Premium Residences</option>
                            <option>East Coast Road Elevated Bridge</option>
                            <option>SIPCOT Industrial Park</option>
                            <option>ELCOT IT Park</option>
                        </select>
                    </div>

                    <!-- Contractor / Vendor -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">
                            Contractor / Vendor / Party Name <span class="text-danger">*</span>
                        </label>

                        <input type="text"
                               class="form-control"
                               placeholder="Enter contractor / vendor / party name">
                    </div>

                    <!-- Transaction Flow Type -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">
                            Transaction Flow Type <span class="text-danger">*</span>
                        </label>

                        <select class="form-select">
                            <option value="">Select Transaction Flow Type</option>
                            <option value="debit">
                                Debit (-) Outflow (Expense / Contractor Payout)
                            </option>
                            <option value="credit">
                                Credit (+) Inflow (Client Receipt / Payment)
                            </option>
                        </select>
                    </div>

                    <!-- Category -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Category <span class="text-danger">*</span>
                        </label>

                        <select class="form-select">
                            <option value="">Select Category</option>
                            <option>Contractor RA Bill</option>
                            <option>Client RA Bill Receipt</option>
                            <option>Equipment Lease</option>
                            <option>Material Purchase</option>
                            <option>Labor Wages</option>
                            <option>Site Overheads</option>
                            <option>Subcontractor Advance</option>
                        </select>
                    </div>

                    <!-- Amount -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Amount (₹) <span class="text-danger">*</span>
                        </label>

                        <input type="number"
                               class="form-control"
                               placeholder="Enter amount"
                               min="0"
                               step="0.01">
                    </div>

                    <!-- Transaction Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Transaction Date <span class="text-danger">*</span>
                        </label>

                        <input type="date"
                               class="form-control">
                    </div>

                    <!-- Voucher / Reference -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Voucher / Reference No.
                        </label>

                        <input type="text"
                               class="form-control"
                               placeholder="Enter voucher / reference no.">
                    </div>

                    <!-- Description -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">
                            Description / Particulars
                        </label>

                        <textarea class="form-control"
                                  rows="3"
                                  placeholder="Enter description / particulars"></textarea>
                    </div>

                </div>

            </div>

            <div class="modal-footer px-4 pb-4">

                <button type="button"
                        class="btn btn-light border"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button"
                        class="btn btn-success fw-semibold">
                    <span class="mdi mdi-content-save-outline me-1"></span>
                    Save Site Transaction
                </button>

            </div>

        </div>
</div>
@endsection