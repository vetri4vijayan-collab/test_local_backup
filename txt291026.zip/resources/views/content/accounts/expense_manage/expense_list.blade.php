@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
    <div class="card shadow-sm rounded-2 mb-4">
        <div class="card-body p-3 p-md-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

                {{-- Title & Icon --}}
                <div class="d-flex align-items-center gap-3">
                    <i class="mdi mdi-swap-horizontal-circle-outline fs-1 text-primary"></i>

                    <div>
                        <h4 class="mb-1 fw-bold text-primary fs-5">
                            Site Wise Expenditure - Credit &amp; Debit Ledger
                        </h4>

                        <p class="text-muted mb-0 fs-8">
                            Comprehensive list view of site receipts (Credits) and contractor / material payouts (Debits) by project
                        </p>
                    </div>
                </div>

                {{-- Navigation & Action Buttons --}}
                <div class="nav-scroll-wrapper">
                    <div class="nav-scroll-container d-flex justify-content-end align-items-center gap-2">
                        @php
                            $isListViewActive    = request()->is('accounts/expense-management');
                            $isSiteSummaryActive = request()->is('/accounts/expense-management/summary');
                        @endphp

                        {{-- Tab Pills --}}
                        <div class="d-inline-flex border rounded-2 overflow-hidden bg-light">
                            <a href="{{ url('accounts/expense-management') }}"
                               class="btn btn-sm settings-tab-pill rounded-0 border-0 text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold {{ $isListViewActive ? 'btn-primary' : 'btn-light' }}">
                                <span class="mdi mdi-format-list-bulleted me-2"></span>
                                List View
                            </a>

                            <a href="{{ url('/accounts/expense-management/summary') }}"
                               class="btn btn-sm settings-tab-pill rounded-0 border-0 text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold {{ $isSiteSummaryActive ? 'btn-primary' : 'btn-light' }}">
                                <span class="mdi mdi-view-dashboard-outline me-2"></span>
                                Site Summary
                            </a>
                        </div>

                        {{-- Log Transaction Button --}}
                        <button type="button"
                              class="btn btn-sm btn-success text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold"
                              data-bs-toggle="modal"
                              data-bs-target="#siteExpenditureModal">
                          <span class="mdi mdi-plus-circle-outline me-2"></span>
                          Log Site Transaction
                      </button>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-3">
            <div class="filter-layout d-flex flex-column flex-md-row align-items-stretch align-items-md-center justify-content-between gap-3">

                {{-- Search --}}
                <div class="filter-search flex-grow-1" style="max-width: 500px;">
                    <div class="position-relative">
                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                              style="pointer-events: none;">
                            <i class="mdi mdi-magnify fs-5"></i>
                        </span>

                        <input id="hr-search-field"
                               type="text"
                               placeholder="Search staff, designation or email"
                               class="form-control form-control-sm ps-7 bg-light border-0 rounded-3 text-secondary" />
                    </div>
                </div>

                {{-- Right Filters --}}
                <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2">

                    {{-- Project Filter --}}
                    <div class="filter-project">
                        <select id="projectFilter"
                                class="form-select form-select-sm bg-light border-0 rounded-3"
                                style="min-width: 200px;">
                            <option value="">All Projects</option>
                            <option value="maa-met-c4">MAA-MET-C4 - Chennai Metro Phase 2 Corridor 4</option>
                            <option value="ady-res">ADY-RES - Adyar Residential Project</option>
                            <option value="ecr-brg">ECR-BRG - ECR Bridge Works</option>
                            <option value="sip-log">SIP-LOG - SIP Logistics Project</option>
                            <option value="elc-hq">ELC-HQ - Elysium Head Office</option>
                        </select>
                    </div>

                    {{-- Status Filter --}}
                    <div class="filter-status">
                        <select id="statusFilter"
                                class="form-select form-select-sm bg-light border-0 rounded-3"
                                style="min-width: 160px;">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="pending">Pending</option>
                            <option value="completed">Completed</option>
                            <option value="on-hold">On Hold</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>

                </div>
            </div>
        </div>
    </div>
   
<div class="card bg-white border-0 shadow-sm rounded-4 overflow-hidden"> 
    <div class="card-body p-2 bg-white"> 
        <div class="deployment-table-wrapper table-responsive"> 
            <table class="table table-hover align-middle mb-0 ra-bill-table p-5"> 
                <thead class="table-light"> 
                    <tr> 
                        <th scope="col" class="text-nowrap"> Date &amp; Voucher </th> 
                        <th scope="col" class="text-nowrap"> Project / Site </th> 
                        <th scope="col" class="text-nowrap"> Contractor / Party </th> 
                        <th scope="col"> Category &amp; Particulars </th> 
                        <th scope="col" class="text-end text-nowrap"> Credit (₹) </th> 
                        <th scope="col" class="text-end text-nowrap"> Debit (₹) </th> 
                        <th scope="col" class="text-center text-nowrap"> Flow Status </th> 
                        <th scope="col" class="text-center text-nowrap"> Actions </th> 
                    </tr> 
                </thead> 
            <tbody class="bg-white">
                <tr>
                    <td>
                        <div class="fw-bold text-primary text-nowrap">
                            PV-RA-CON-14
                        </div>

                        <small class="text-muted text-nowrap">
                            2026-07-28
                        </small>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Metro Line Extension - Phase 3
                        </div>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Apex Structural Sub-Contractors
                        </div>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Contractor RA Bill
                        </div>

                        <small class="text-muted">
                            Piling &amp; substructure measurement book #12 certified payout
                        </small>
                    </td>

                    <td class="text-end">
                        <span class="text-muted text-nowrap">
                            -
                        </span>
                    </td>

                    <td class="text-end">
                        <span class="fw-bold text-danger text-nowrap">
                            - ₹ 37,80,000
                        </span>
                    </td>

                    <td class="text-center">
                        <span class="badge rounded-pill bg-danger-subtle text-danger px-3 py-2 text-nowrap">
                            <i class="mdi mdi-arrow-down-bold me-1"></i>
                            Debit (Outflow)
                        </span>
                    </td>

                    <td class="text-center">
                        <div class="d-flex align-items-center justify-content-center">
                            <button type="button"
                                    class="btn"
                                    title="View"
                                    data-bs-toggle="modal"
                                    data-bs-target="#viewTransactionModal">
                                <i class="mdi mdi-eye-outline"></i>
                            </button>

                            <button type="button"
                                    class="btn"
                                    title="Voucher">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>
                        <div class="fw-bold text-primary text-nowrap">
                            RV-BMRCL-09
                        </div>

                        <small class="text-muted text-nowrap">
                            2026-07-25
                        </small>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Metro Line Extension - Phase 3
                        </div>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Bangalore Metro Rail Corp (Client)
                        </div>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Client RA Bill Receipt
                        </div>

                        <small class="text-muted">
                            Client RA Bill #09 Interim Certificate Payment Received
                        </small>
                    </td>

                    <td class="text-end">
                        <span class="fw-bold text-success text-nowrap">
                            + ₹ 1,25,00,000
                        </span>
                    </td>

                    <td class="text-end">
                        <span class="text-muted text-nowrap">
                            -
                        </span>
                    </td>

                    <td class="text-center">
                        <span class="badge rounded-pill bg-success-subtle text-success px-3 py-2 text-nowrap">
                            <i class="mdi mdi-arrow-up-bold me-1"></i>
                            Credit (Inflow)
                        </span>
                    </td>

                    <td class="text-center">
                        <div class="d-flex align-items-center justify-content-center">
                            <button type="button"
                                    class="btn"
                                    title="View"
                                    data-bs-toggle="modal"
                                    data-bs-target="#viewTransactionModal">
                                <i class="mdi mdi-eye-outline"></i>
                            </button>

                            <button type="button"
                                    class="btn"
                                    title="Voucher">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>
                        <div class="fw-bold text-primary text-nowrap">
                            PV-8801
                        </div>

                        <small class="text-muted text-nowrap">
                            2026-07-22
                        </small>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Coastal Expressway Bridge
                        </div>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Vanguard Earthmovers Ltd
                        </div>
                    </td>

                    <td>
                        <div class="fw-semibold text-dark text-nowrap">
                            Equipment Lease
                        </div>

                        <small class="text-muted">
                            Heavy 50T Crane &amp; Excavator Monthly Rental Payout
                        </small>
                    </td>

                    <td class="text-end">
                        <span class="text-muted text-nowrap">
                            -
                        </span>
                    </td>

                    <td class="text-end">
                        <span class="fw-bold text-danger text-nowrap">
                            - ₹ 2,90,500
                        </span>
                    </td>

                    <td class="text-center">
                        <span class="badge rounded-pill bg-danger-subtle text-danger px-3 py-2 text-nowrap">
                            <i class="mdi mdi-arrow-down-bold me-1"></i>
                            Debit (Outflow)
                        </span>
                    </td>

                   <td class="text-center">
                        <div class="d-flex align-items-center justify-content-center">
                            <button type="button"
                                    class="btn"
                                    title="View"
                                    data-bs-toggle="modal"
                                    data-bs-target="#viewTransactionModal">
                                <i class="mdi mdi-eye-outline"></i>
                            </button>

                            <button type="button"
                                    class="btn"
                                    title="Voucher">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </td>
                </tr>

            </tbody> 
        </table> 
    </div> 
</div> 
</div>


<div class="modal fade" id="siteExpenditureModal" tabindex="-1" aria-labelledby="siteExpenditureModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-3 border-0 shadow">

            <div class="modal-header bg-primary">
                <h5 class="modal-title fw-bold text-white p-3" id="siteExpenditureModalLabel">
                    LOG SITE EXPENDITURE / RECEIPT
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <div class="modal-body p-4">

                <div class="row g-3">

                    <!-- Project / Site -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">
                            Project / Site <span class="text-danger">*</span>
                        </label>

                        <select class="form-select">
                            <option value="">Select Project / Site</option>
                            <option>Chennai Metro Phase 2 - Corridor 4</option>
                            <option>Adyar Premium Residences</option>
                            <option>East Coast Road Elevated Bridge</option>
                            <option>SIPCOT Industrial Park</option>
                            <option>ELCOT IT Park</option>
                        </select>
                    </div>

                    <!-- Contractor / Vendor -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">
                            Contractor / Vendor / Party Name <span class="text-danger">*</span>
                        </label>

                        <input type="text"
                                class="form-control"
                                placeholder="Enter contractor / vendor / party name">
                    </div>

                    <!-- Transaction Flow Type -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">
                            Transaction Flow Type <span class="text-danger">*</span>
                        </label>

                        <select class="form-select">
                            <option value="">Select Transaction Flow Type</option>
                            <option value="debit">
                                Debit (-) Outflow (Expense / Contractor Payout)
                            </option>
                            <option value="credit">
                                Credit (+) Inflow (Client Receipt / Payment)
                            </option>
                        </select>
                    </div>

                    <!-- Category -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Category <span class="text-danger">*</span>
                        </label>

                        <select class="form-select">
                            <option value="">Select Category</option>
                            <option>Contractor RA Bill</option>
                            <option>Client RA Bill Receipt</option>
                            <option>Equipment Lease</option>
                            <option>Material Purchase</option>
                            <option>Labor Wages</option>
                            <option>Site Overheads</option>
                            <option>Subcontractor Advance</option>
                        </select>
                    </div>

                    <!-- Amount -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Amount (₹) <span class="text-danger">*</span>
                        </label>

                        <input type="number"
                                class="form-control"
                                placeholder="Enter amount"
                                min="0"
                                step="0.01">
                    </div>

                    <!-- Transaction Date -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Transaction Date <span class="text-danger">*</span>
                        </label>

                        <input type="date"
                                class="form-control">
                    </div>

                    <!-- Voucher / Reference -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Voucher / Reference No.
                        </label>

                        <input type="text"
                                class="form-control"
                                placeholder="Enter voucher / reference no.">
                    </div>

                    <!-- Description -->
                    <div class="col-12">
                        <label class="form-label fw-semibold">
                            Description / Particulars
                        </label>

                        <textarea class="form-control"
                                    rows="3"
                                    placeholder="Enter description / particulars"></textarea>
                    </div>

                </div>

            </div>

            <div class="modal-footer px-4 pb-4">

                <button type="button"
                        class="btn btn-light border"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button"
                        class="btn btn-success fw-semibold">
                    <span class="mdi mdi-content-save-outline me-1"></span>
                    Save Site Transaction
                </button>

            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="viewTransactionModal" tabindex="-1" aria-labelledby="viewTransactionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-3 border-0 shadow">

            <div class="modal-header bg-primary">
                <div>
                    <h5 class="modal-title fw-bold text-white mb-0" id="viewTransactionModalLabel">
                        PV-RA-CON-14
                    </h5>

                    <h6 class="fw-bold mb-1">
                        Metro Line Extension - Phase 3
                    </h6>

                    <p class="text-muted mb-0">
                        Contractor / Party:
                        <span class="fw-semibold text-white">
                            Apex Structural Sub-Contractors
                        </span>
                    </p>
                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <div class="modal-body p-4">

                <div class="row g-3">

                    <!-- Transaction Type -->
                    <div class="col-md-6">
                        <div class="border rounded-3 p-3 h-100 bg-light">
                            <div class="text-muted small fw-semibold mb-1">
                                Transaction Type
                            </div>

                            <div class="fw-bold text-danger">
                                Debit (Expense / Payout)
                            </div>
                        </div>
                    </div>

                    <!-- Category -->
                    <div class="col-md-6">
                        <div class="border rounded-3 p-3 h-100 bg-light">
                            <div class="text-muted small fw-semibold mb-1">
                                Category
                            </div>

                            <div class="fw-bold text-dark">
                                Contractor RA Bill
                            </div>
                        </div>
                    </div>

                    <!-- Transaction Amount -->
                    <div class="col-md-6">
                        <div class="border rounded-3 p-3 h-100 bg-light">
                            <div class="text-muted small fw-semibold mb-1">
                                Transaction Amount
                            </div>

                            <div class="fw-bold text-primary fs-5">
                                ₹ 37,80,000
                            </div>
                        </div>
                    </div>

                    <!-- Date & Approved By -->
                    <div class="col-md-6">
                        <div class="border rounded-3 p-3 h-100 bg-light">
                            <div class="text-muted small fw-semibold mb-1">
                                Date & Approved By
                            </div>

                            <div class="fw-bold text-dark">
                                2026-07-28
                            </div>

                            <div class="text-muted mt-1">
                                Senior QS / Project Lead
                            </div>
                        </div>
                    </div>

                    <!-- Particulars -->
                    <div class="col-12">
                        <div class="border rounded-3 p-3 bg-light">

                            <div class="text-muted small fw-semibold mb-2">
                                Particulars / Description
                            </div>

                            <div class="fw-semibold text-dark">
                                Piling & substructure measurement book #12 certified payout
                            </div>

                        </div>
                    </div>

                </div>

            </div>

            <div class="modal-footer px-4 pb-4">

                <button type="button"
                        class="btn btn-primary fw-semibold"
                        onclick="window.print()">
                    <i class="mdi mdi-printer-outline me-1"></i>
                    Print Voucher
                </button>

                <button type="button"
                        class="btn btn-light border fw-semibold"
                        data-bs-dismiss="modal">
                    Close
                </button>

            </div>

        </div>
    </div>
</div>
@endsection