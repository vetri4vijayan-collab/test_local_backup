@extends('layouts.layoutMaster')

@section('title', 'Client view Report - Report')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

    <!-- Page Header -->
    <div class="d-flex flex-wrap align-items-center justify-content-start gap-3 mb-4">
        <a href="{{ route('accounts.client.reports', ['tab' => 'estimation']) }}"
          class="btn rounded-3 d-flex align-items-center gap-2 px-3">
            <i class="mdi mdi-arrow-left fs-5"></i>
        </a>
        <div>

            <h4 class="fw-semibold mb-1">Client Report Detail
                </h4>
            <p class="text-muted mb-0 small">
                Enter the month and GST calculation details below.
            </p>
        </div>


    </div>

<div class="card border-0 shadow-sm rounded-2 bg-white mb-4">
    <div class="card-body p-3">
        <div class="filter-layout d-flex flex-column flex-xl-row align-items-stretch align-items-xl-center  gap-3">

            {{-- Left Side: Date Filters --}}
            <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2 flex-grow-1">

                {{-- From Date --}}
                <div class="filter-field" style="max-width: 220px; width: 100%;">
                    <label for="from-date" class="form-label small text-muted mb-1">
                        From Date
                    </label>

                    <input id="from-date"
                           type="date"
                           class="form-control form-control-sm bg-light border-0 rounded-3 text-secondary"
                           placeholder="dd-mm-yyyy" />
                </div>

                {{-- To Date --}}
                <div class="filter-field" style="max-width: 220px; width: 100%;">
                    <label for="to-date" class="form-label small text-muted mb-1">
                        To Date
                    </label>

                    <input id="to-date"
                           type="date"
                           class="form-control form-control-sm bg-light border-0 rounded-3 text-secondary"
                           placeholder="dd-mm-yyyy" />
                </div>

                 <div class="align-items-center flex-shrink-0 mt-4">
                    <a href=""
                      class="btn btn-primary btm-sm rounded-3 d-flex align-items-center gap-2 px-3">
                      <span>Go</span>
                    </a>
                 </div>

            </div>

            {{-- Right Side: Create Button --}}
            <!-- <div class="d-flex justify-content-end align-items-center flex-shrink-0">
                <a href="{{ route('accounts.tax-management.create_file_return') }}"
                   class="btn btn-primary btn-sm rounded-3 d-flex align-items-center gap-2 px-3 py-3">
                    <span>GO</span>
                </a>
            </div> -->

            <div class="align-items-center flex-shrink-0 mt-4">
              <a href=""
                class="btn btn-primary btm-sm rounded-3 d-flex align-items-center gap-2 px-3">
                <span>Export</span>
              </a>
            </div>
        </div>
    </div>
</div>


<div class="table-responsive">
    <table class="table table-hover table-striped align-middle mb-0">
        <thead class="table-light">
            <tr>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small">Date</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small">Project</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small">Type</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small">Bill No</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small">Description</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Opening Balance</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Credit</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Debit</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Closing Balance</th>

            </tr>
        </thead>

        <tbody>

            <tr>
                <td colspan="5" class="fw-semibold text-dark">
                    Opening Balance
                </td>
                <td class="text-end fw-semibold text-dark">
                    0.00
                </td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">01-04-2023</td>
                <td class="fw-medium text-dark">NTRP</td>
                <td class="text-muted">Bank</td>
                <td class="text-muted">ICICI Bank Ltd-269805000359</td>
                <td class="text-muted">Food Advance for NTRP Site</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">50,000.00</td>
                <td class="text-end text-muted">-</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">01-04-2023</td>
                <td class="fw-medium text-dark">CPRRP</td>
                <td class="text-muted">Bank</td>
                <td class="text-muted">ICICI Bank Ltd-269805000359</td>
                <td class="text-muted">Food Advance for CPRRP Site</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">40,000.00</td>
                <td class="text-end text-muted">-</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">01-04-2023</td>
                <td class="fw-medium text-dark">NTRP</td>
                <td class="text-muted">Bank</td>
                <td class="text-muted">ICICI Bank Ltd-269805000359</td>
                <td class="text-muted">RA Bill Feb 2023 Balance Payment</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">50,000.00</td>
                <td class="text-end text-muted">-</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">04-12-2024</td>
                <td class="fw-medium text-dark">KWRP</td>
                <td class="text-muted">Bank</td>
                <td class="text-muted">ICICI Bank Ltd-269805000519</td>
                <td class="text-muted">Being Sadhan roy food advance paid - KWRP</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">20,000.00</td>
                <td class="text-end text-muted">-</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">01-03-2026</td>
                <td class="fw-medium text-dark">MRR</td>
                <td class="text-muted">Bank</td>
                <td class="text-muted">ICICI Bank Ltd-269805000519</td>
                <td class="text-muted">-</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">2,50,000.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">-</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">01-03-2026</td>
                <td class="fw-medium text-dark">MRR</td>
                <td class="text-muted">Cash</td>
                <td class="text-muted">-</td>
                <td class="text-muted">NIL</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">40,000.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">-</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">16-03-2026</td>
                <td class="fw-medium text-dark">MRR</td>
                <td class="text-muted">Card</td>
                <td class="text-muted">-</td>
                <td class="text-muted">NIL</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">25,00,000.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">-</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">23-07-2026</td>
                <td class="fw-medium text-dark">VF</td>
                <td class="text-muted">Bank</td>
                <td class="text-muted">State Bank of India -456789012345</td>
                <td class="text-muted">0</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">100.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">-</td>

            </tr>

            <tr>
                <td class="fw-medium text-dark">17-09-2026</td>
                <td class="fw-medium text-dark">VSRP-1</td>
                <td class="text-muted">Bank</td>
                <td class="text-muted">Indian Overseas Bank -123456789098</td>
                <td class="text-muted">uyftu</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">5,000.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">-</td>

            </tr>
               <tr>
                <td colspan="4" class="fw-semibold text-dark">

                </td>
                <td colspan="4"class="fw-semibold text-dark">
                    Closing Balance
                </td>
                <td class="text-end fw-semibold text-dark">
                    26,35,100.00
                </td>
                <!-- <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td> -->

            </tr>

        </tbody>
    </table>
</div>

<!-- Footer Section: Show entries and Pagination -->
<div class="d-flex flex-column flex-sm-row justify-content-between align-items-center p-3 border-top gap-3">

    <!-- Show Entries -->
    <div class="d-flex align-items-center gap-2 small text-muted">
        <span>Show</span>
        <select class="form-select form-select-sm" style="width: auto;">
            <option value="20">20</option>
            <option value="40">40</option>
            <option value="100">100</option>
        </select>
        <span>entries</span>
    </div>

    <!-- Pagination Info & Buttons -->
    <div class="d-flex flex-column flex-sm-row align-items-center gap-3">
        <span class="small text-muted">1 - 12 of 12 entries</span>
        <nav aria-label="Table navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                </li>
                <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">1</a>
                </li>

                <li class="page-item disabled">
                    <a class="page-link" href="#">Next</a>
                </li>
            </ul>
        </nav>
    </div>
</div>



<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>
@endsection
