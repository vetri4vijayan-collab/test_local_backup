@extends('layouts.layoutMaster')

@section('title', 'Staff_report - Reports')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">
              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>
              <div>
                  <h4 class="mb-1 fw-bold text-primary fs-5">
                    Staff Report Summary
                </h4>
                   <p class="text-muted mb-0 fs-8">
                        Review vendor-wise opening balances, credits, debits, and closing balances for the selected reporting period.
                    </p>
              </div>
          </div>


          {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">
              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">
                  <i class="mdi mdi-chevron-left"></i>
              </button>
              {{-- Tabs --}}
              <div class="settings-tabs-scroller">
                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">
                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp
                      {{-- GST Payable Entry --}}
                      <a
                          href="{{ route('accounts.reports', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">
                          <i class="mdi mdi-file-document-edit-outline me-1"></i>
                          Profit & Loss
                      </a>
                      {{-- GST Payable Estimation --}}
                      <a
                          href="{{ route('accounts.tax-management.gst-estimate', ['tab' => 'estimation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'estimation' ? 'active' : '' }}">
                          <i class="mdi mdi-calculator-variant-outline me-1"></i>
                            Client Report
                      </a>

                      {{-- GST Payable --}}
                      <a
                          href="{{ route('accounts.reports.contract', ['tab' => 'payable']) }}"
                          class="settings-tab-pill {{ $activeTab === 'payable' ? 'active' : '' }}">
                          <i class="mdi mdi-cash-check me-1"></i>
                         Contractor Report
                      </a>
                       <a href="{{ route('accounts.reports.vendor', ['tab' => 'vendor']) }}"
                          class="settings-tab-pill {{ $activeTab === 'vendor' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                           Vendor Report
                        </a>
                         <a href="{{ route('accounts.reports.staff', ['tab' => 'staff_report']) }}"
                          class="settings-tab-pill {{ $activeTab === 'staff_report' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            Staff Report
                        </a>
                  </div>
              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>

      </div>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-2 bg-white mb-4">
    <div class="card-body p-3">
        <div class="filter-layout d-flex flex-column flex-xl-row align-items-stretch align-items-xl-center justify-content-between gap-3">

            {{-- Left Side: Date Filters --}}
            <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2 flex-grow-1">

                {{-- From Date --}}
                <div class="filter-field" style="max-width: 220px; width: 100%;">
                    <label for="from-date" class="form-label small text-muted mb-1">
                        From Date
                    </label>

                    <input id="from-date"
                           type="date"
                           class="form-control form-control-sm bg-light border-0 rounded-3 text-secondary"
                           placeholder="dd-mm-yyyy" />
                </div>

                {{-- To Date --}}
                <div class="filter-field" style="max-width: 220px; width: 100%;">
                    <label for="to-date" class="form-label small text-muted mb-1">
                        To Date
                    </label>

                    <input id="to-date"
                           type="date"
                           class="form-control form-control-sm bg-light border-0 rounded-3 text-secondary"
                           placeholder="dd-mm-yyyy" />
                </div>

            </div>

            {{-- Right Side: Create Button --}}
            <!-- <div class="d-flex justify-content-end align-items-center flex-shrink-0">
                <a href="{{ route('accounts.tax-management.create_file_return') }}"
                   class="btn btn-primary btn-sm rounded-3 d-flex align-items-center gap-2 px-3 py-3">
                    <span>GO</span>
                </a>
            </div> -->

            <div class="d-flex justify-content-end align-items-center flex-shrink-0">
              <a href=""
                class="btn btn-primary btm-sm rounded-3 d-flex align-items-center gap-2 px-3">
                <span>Go</span>
              </a>
            </div>
        </div>
    </div>
</div>

<div class="table-responsive">
    <table class="table table-hover table-striped align-middle mb-0">
        <thead class="table-light">
            <tr>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small">Staff</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Opening Balance</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Credit</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Debit</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Closing Balance</th>
                <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Row 1 -->
            <tr>
                <td class="fw-medium text-dark">S. Priya Devi</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">8,84,680.78</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">8,84,680.78</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 2 -->
            <tr>
                <td class="fw-medium text-dark">Rajendran. J</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">41,617.47</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">41,617.47</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 3 -->
            <tr>
                <td class="fw-medium text-dark">Manoj Kumar</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">10,030.78</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">10,030.78</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 4 -->
            <tr>
                <td class="fw-medium text-dark">Karthik Raj</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">7,513.51</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">7,513.51</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 5 -->
            <tr>
                <td class="fw-medium text-dark">Dharan</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">5,582.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">5,582.00</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 6 -->
            <tr>
                <td class="fw-medium text-dark">Divya Shankar</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">5,025.02</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">5,025.02</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 7 -->
            <tr>
                <td class="fw-medium text-dark">Veerakaleeswaran. V</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 8 -->
            <tr>
                <td class="fw-medium text-dark">Vasudevan. M</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 9 -->
            <tr>
                <td class="fw-medium text-dark">Vasantha. G</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 10 -->
            <tr>
                <td class="fw-medium text-dark">Vasantha</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
            <!-- Row 11 -->
            <tr>
                <td class="fw-medium text-dark">Vanitha</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">0.00</td>
                <td class="text-end text-muted">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                            onclick="window.location.href='{{ route('accounts.reports.staff.view') }}'">
                        <i class="mdi mdi-eye-outline fs-5"></i>
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>
@endsection