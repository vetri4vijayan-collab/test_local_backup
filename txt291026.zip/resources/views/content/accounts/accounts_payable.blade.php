@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3 p-md-4">
        <div
            class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">

            <div class="d-flex align-items-center gap-3">
                <i class="mdi mdi-file-document-edit-outline fs-1 text-primary"></i>

                <div>
                    <h4 class="mb-1 fw-bold text-primary fs-5">
                        Contractor &amp; Subcontractor RA Bill Payment Detail
                    </h4>

                    <p class="text-muted mb-0 fs-8">
                        Subcontractor work claims, mobilization advance recoveries, and net payout vouchers
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="deployment-table-wrapper table-responsive">
    <table class="table table-hover align-middle mb-0 ra-bill-table">
    <thead class="table-light">
        <tr>
            <th scope="col" class="text-nowrap">RA Bill No</th>
            <th scope="col" class="text-nowrap">Date</th>
            <th scope="col">Client &amp; Project</th>
            <th scope="col" class="text-end text-nowrap">Gross Claim</th>
            <th scope="col" class="text-end text-nowrap">Certified Amt</th>
            <th scope="col" class="text-end text-nowrap">Retention (5%)</th>
            <th scope="col" class="text-end text-nowrap">TDS (194C + GST)</th>
            <th scope="col" class="text-end text-nowrap">Net Certified</th>
            <th scope="col" class="text-end text-nowrap">Amount Realized</th>
            <th scope="col" class="text-end text-nowrap">Balance Due</th>
            <th scope="col" class="text-center text-nowrap">Status</th>
          
        </tr>
    </thead>

    <tbody>

        {{-- RA-CON-14 --}}
        <tr>
            <td>
                <span class="text-primary fw-bold text-nowrap">
                    RA-CON-14
                </span>
            </td>

            <td>
                <span class="text-muted text-nowrap">
                    2026-07-05
                </span>
            </td>

            <td>
                <div class="fw-semibold text-dark text-nowrap">
                    Apex Structural Sub-Contractors
                </div>

                <small class="text-muted text-nowrap">
                    Metro Line Extension - Phase 3
                </small>
            </td>

            <td class="text-end">
                <span class="fw-semibold text-nowrap">
                    ₹ 4,20,00,000
                </span>
            </td>

            <td class="text-end">
                <span class="fw-semibold text-nowrap">
                    ₹ 4,20,00,000
                </span>
            </td>

            <td class="text-end">
                <span class="text-muted text-nowrap">
                    ₹ 21,00,000
                </span>
            </td>

            <td class="text-end">
                <span class="text-muted text-nowrap">
                    ₹ 0
                </span>
            </td>

            <td class="text-end">
                <span class="fw-bold text-dark text-nowrap">
                    ₹ 3,99,00,000
                </span>
            </td>

            <td class="text-end">
                <span class="fw-bold text-success text-nowrap">
                    ₹ 3,99,00,000
                </span>
            </td>

            <td class="text-end">
                <span class="fw-bold text-success text-nowrap">
                    ₹ 0
                </span>
            </td>

            <td class="text-center">
                <span class="badge rounded-pill bg-success-subtle text-success px-3 py-2 text-nowrap">
                    Passed for Payment
                </span>
            </td>
        </tr>


        {{-- RA-CON-15 --}}
        <tr>
            <td>
                <span class="text-primary fw-bold text-nowrap">
                    RA-CON-15
                </span>
            </td>

            <td>
                <span class="text-muted text-nowrap">
                    2026-07-20
                </span>
            </td>

            <td>
                <div class="fw-semibold text-dark text-nowrap">
                    Star Bar-Bending Works
                </div>

                <small class="text-muted text-nowrap">
                    Metro Line Extension - Phase 3
                </small>
            </td>

            <td class="text-end">
                <span class="fw-semibold text-nowrap">
                    ₹ 2,10,00,000
                </span>
            </td>

            <td class="text-end">
                <span class="fw-semibold text-nowrap">
                    ₹ 2,10,00,000
                </span>
            </td>

            <td class="text-end">
                <span class="text-muted text-nowrap">
                    ₹ 10,50,000
                </span>
            </td>

            <td class="text-end">
                <span class="text-muted text-nowrap">
                    ₹ 0
                </span>
            </td>

            <td class="text-end">
                <span class="fw-bold text-dark text-nowrap">
                    ₹ 1,99,50,000
                </span>
            </td>

            <td class="text-end">
                <span class="fw-bold text-warning text-nowrap">
                    ₹ 0
                </span>
            </td>

            <td class="text-end">
                <span class="fw-bold text-danger text-nowrap">
                    ₹ 1,99,50,000
                </span>
            </td>

            <td class="text-center">
                <span class="badge rounded-pill bg-warning-subtle text-warning px-3 py-2 text-nowrap">
                    Under Verification
                </span>
            </td>

           
        </tr>

    </tbody>
</table>


</div>

@endsection