@extends('layouts.layoutMaster')

@section('title', 'GST Reconciliation - Tax_management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')


<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>

              <div>
                  <h4 class="mb-1 fw-bold text-primary fs-5">
                      GST Reconciliation
                  </h4>

                  <p class="text-muted mb-0 fs-8">
                      Manage GST liabilities , tax calculations , input tax credits , and payable records.
                  </p>
              </div>

          </div>


          {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- GST Payable Entry --}}
                      <a
                          href="{{ route('accounts.tax-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                          GST Payable Entry

                      </a>


                      {{-- GST Payable Estimation --}}
                      <a
                          href="{{ route('accounts.tax-management.gst-estimate', ['tab' => 'estimation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'estimation' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                          GST Payable Estimation

                      </a>


                      {{-- GST Payable --}}
                      <a
                          href="{{ route('accounts.tax-management.gst-payable', ['tab' => 'payable']) }}"
                          class="settings-tab-pill {{ $activeTab === 'payable' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                          GST Payable

                      </a>

                       <a href="{{ route('accounts.tax-management.gst-recollination', ['tab' => 'reconciliation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'reconciliation' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            GST Reconciliation
                        </a>

                         <a href="{{ route('accounts.tax-management.gst-file_return', ['tab' => 'file_return']) }}"
                          class="settings-tab-pill {{ $activeTab === 'file_return' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            File Return
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>

      </div>

  </div>
</div>

<div class="card border-0 shadow-sm rounded-2 bg-white mb-4">
    <div class="card-body p-3">
      <div class="filter-layout d-flex flex-column flex-xl-row align-items-stretch align-items-xl-center justify-content-between gap-3">

          {{-- Left Side: Search & Filters --}}
          <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2 flex-grow-1">

            {{-- Search --}}
            <div class="filter-search" style="max-width: 500px; width: 40%;">
                <div class="position-relative">

                    <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                          style="pointer-events: none;">
                        <i class="mdi mdi-magnify fs-5"></i>
                    </span>

                    <input id="hr-search-field"
                          type="text"
                          placeholder="Search month,total"
                          class="form-control form-control-sm ps-7 bg-light border-0 rounded-3 text-secondary" />

                </div>
            </div>

        </div>


          {{-- Right Side: Create Button --}}
          <div class="d-flex justify-content-end align-items-center flex-shrink-0">

             <button type="button"
                      class="btn btn-primary btn-sm rounded-3 d-flex align-items-center gap-2 px-3"
                      data-bs-toggle="modal"
                      data-bs-target="#createGstPayableModal">

                  <i class="mdi mdi-plus fs-5"></i>
                  <span>Create GST Reconciliation</span>

              </button>

          </div>

      </div>
    </div>
</div>
<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
    <div class="card-body p-0">

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">
                    <tr>
                        <th class="fw-semibold text-secondary">
                            GST Month
                        </th>

                        <th class="fw-semibold text-secondary">
                            Project
                        </th>

                        <th class="fw-semibold text-secondary">
                            Client
                        </th>

                        <th class="fw-semibold text-secondary text-end">
                            Taxable Value
                        </th>

                        <th class="fw-semibold text-secondary text-end">
                            GST Payable
                        </th>

                        <th class="fw-semibold text-secondary text-center">
                            Actions
                        </th>
                    </tr>
                </thead>

                <tbody id="gstPayableEntryTableBody">

                    {{-- Example Row --}}
                    <tr>
                        <td>
                            <span class="fw-semibold text-dark">
                                2026-Jun
                            </span>
                        </td>

                        <td>
                            <span class="text-dark">
                                VF
                            </span>
                        </td>

                        <td>
                            <span class="text-dark">
                                ABC Client
                            </span>
                        </td>

                        <td class="text-end">
                            ₹10,00,000.00
                        </td>

                        <td class="text-end fw-semibold">
                            ₹1,80,000.00
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-1">

                                {{-- Edit --}}
                                <button
                                    type="button"
                                    class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-gst-entry-btn"
                                    title="Edit"
                                     data-bs-toggle="modal"
                      data-bs-target="#createGstPayableModal">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>

                                {{-- Delete --}}
                               <button
                                    type="button"
                                    class="btn btn-sm btn-icon btn-text-secondary rounded-pill delete-gst-entry-btn"
                                    title="Delete"
                                    data-bs-toggle="modal"
                                    data-bs-target="#deleteGstEntryModal">
                                    <i class="mdi mdi-delete"></i>
                                </button>

                            </div>
                        </td>
                    </tr>


                    {{-- Example Row --}}
                    <tr>
                        <td>
                            <span class="fw-semibold text-dark">
                                2026-May
                            </span>
                        </td>

                        <td>
                            <span class="text-dark">
                                MRR
                            </span>
                        </td>

                        <td>
                            <span class="text-dark">
                                XYZ Client
                            </span>
                        </td>

                        <td class="text-end">
                            ₹7,50,000.00
                        </td>

                        <td class="text-end fw-semibold">
                            ₹1,35,000.00
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-1">

                               <button
                                    type="button"
                                    class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-gst-entry-btn"
                                    title="Edit"
                                     data-bs-toggle="modal"

                      data-bs-target="#createGstPayableModal">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>

                                <button
                                    type="button"
                                    class="btn btn-sm btn-icon btn-text-secondary rounded-pill delete-gst-entry-btn"
                                    title="Delete"
                                    data-bs-toggle="modal"
                                    data-bs-target="#deleteGstEntryModal">
                                    <i class="mdi mdi-delete"></i>
                                </button>

                            </div>
                        </td>
                    </tr>


                    {{-- No Data --}}
                    {{--
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">
                            No data available in table
                        </td>
                    </tr>
                    --}}
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Footer Section: Show entries and Pagination -->
<div class="d-flex flex-column flex-sm-row justify-content-between align-items-center p-3 border-top gap-3">

    <!-- Show Entries -->
    <div class="d-flex align-items-center gap-2 small text-muted">
        <span>Show</span>
        <select class="form-select form-select-sm" style="width: auto;">
            <option value="20">20</option>
            <option value="40">40</option>
            <option value="100">100</option>
        </select>
        <span>entries</span>
    </div>

    <!-- Pagination Info & Buttons -->
    <div class="d-flex flex-column flex-sm-row align-items-center gap-3">
        <span class="small text-muted">1 - 12 of 12 entries</span>
        <nav aria-label="Table navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                </li>
                <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item disabled">
                    <a class="page-link" href="#">Next</a>
                </li>
            </ul>
        </nav>
    </div>
</div>

<!-- Create GST Reconciliation Modal -->
<div
    class="modal fade"
    id="createGstPayableModal"
    tabindex="-1"
    aria-labelledby="createGstPayableModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content rounded-3 border-0 shadow">

            <!-- Modal Header -->
            <div class="modal-header bg-primary ">
                <div>
                    <h5
                        class="modal-title fw-semibold text-white"
                        id="createGstPayableModalLabel"
                    >
                        Create GST Reconciliation
                    </h5>

                    <p class="text-muted small mb-0 mt-1">
                        Enter the GST reconciliation details below.
                    </p>
                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>


            <!-- Modal Body -->
            <div class="modal-body">
                <div class="row g-3">

                    <!-- Month -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Month <span class="text-danger">*</span>
                        </label>

                        <input
                            type="month"
                            class="form-control"
                            value="2026-09"
                            required
                        >
                    </div>


                    <!-- Project -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            Project <span class="text-danger">*</span>
                        </label>

                        <select class="form-select" required>
                            <option value="">Select Project</option>
                            <option value="1">Project 1</option>
                            <option value="2">Project 2</option>
                            <option value="3">Project 3</option>
                        </select>
                    </div>


                    <!-- Total Taxable Value -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            Total Taxable Value
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- Outward CGST -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            Outward CGST
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- Outward SGST -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            Outward SGST
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- Outward IGST -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            Outward IGST
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- ITC CGST -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            ITC CGST
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- ITC SGST -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            ITC SGST
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- ITC IGST -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            ITC IGST
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- GST Payable -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            GST Payable
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- GST R1 Invoice Value -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            GST R1 Invoice Value
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- GST R1 Taxable Value -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            GST R1 Taxable Value
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- Reversal Charge -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            Reversal Charge
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                    <!-- Interest -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            Interest
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>


                   <!-- Late Fee -->
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">
                            Late Fee
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="number"
                            class="form-control"
                            value="0"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>

                    <!-- Remarks -->
                    <div class="col-md-8">
                        <label class="form-label fw-semibold">
                            Remarks
                        </label>

                        <textarea
                            class="form-control"
                            rows="1"
                            placeholder="Enter remarks"
                        ></textarea>
                    </div>


                </div>
            </div>


            <!-- Modal Footer -->
            <div class="modal-footer">
                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="btn btn-primary px-4"
                >
                    <i class="mdi mdi-content-save-outline me-1"></i>
                    Save Reconciliation
                </button>
            </div>

        </div>
    </div>
</div>

<!-- Delete GST Confirmation Modal -->
<div
    class="modal fade"
    id="deleteGstEntryModal"
    tabindex="-1"
    aria-labelledby="deleteGstEntryModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-3 shadow">

            <!-- Header -->
            <div class="modal-header border-0 pb-2">
                <h5
                    class="modal-title fw-semibold"
                    id="deleteGstEntryModalLabel"
                >
                    Confirm Delete
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>

            <!-- Body -->
            <div class="modal-body pt-2">
                <div class="d-flex align-items-start gap-3">
                    <div
                        class="d-flex align-items-center justify-content-center rounded-circle bg-danger-subtle text-danger"
                        style="width: 42px; height: 42px; flex-shrink: 0;"
                    >
                        <i class="mdi mdi-delete-outline fs-5"></i>
                    </div>

                    <div>
                        <p class="mb-1 fw-semibold text-dark">
                            Delete GST reconciliation?
                        </p>

                        <p class="mb-0 text-muted small">
                            Are you sure you want to delete this GST
                            reconciliation entry? This action cannot be undone.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="modal-footer border-0 pt-2">
                <button
                    type="button"
                    class="btn btn-light px-4"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    class="btn btn-danger px-4"
                    id="confirmDeleteGstEntryBtn"
                >
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Confirm Delete
                </button>
            </div>

        </div>
    </div>
</div>

<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>
@endsection
