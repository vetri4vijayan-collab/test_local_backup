@extends('layouts.layoutMaster')

@section('title', 'GST PAYABLE-ENTRY - Tax_management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>

              <div>
                  <h4 class="mb-1 fw-bold text-primary fs-5">
                      GST Payable Management
                  </h4>

                  <p class="text-muted mb-0 fs-8">
                      Manage GST payable entries, estimations and payable records
                  </p>
              </div>

          </div>


          {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- GST Payable Entry --}}
                      <a
                          href="{{ route('accounts.tax-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                          GST Payable Entry

                      </a>


                      {{-- GST Payable Estimation --}}
                      <a
                          href="{{ route('accounts.tax-management.gst-estimate', ['tab' => 'estimation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'estimation' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                          GST Payable Estimation

                      </a>


                      {{-- GST Payable --}}
                      <a
                          href="{{ route('accounts.tax-management.gst-payable', ['tab' => 'payable']) }}"
                          class="settings-tab-pill {{ $activeTab === 'payable' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                          GST Payable

                      </a>

                       <a href="{{ route('accounts.tax-management.gst-recollination', ['tab' => 'reconciliation']) }}"
                        class="settings-tab-pill {{ $activeTab === 'reconciliation' ? 'active' : '' }}">
                          <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          GST Reconciliation
                      </a>

                      <a href="{{ route('accounts.tax-management.gst-file_return', ['tab' => 'file_return']) }}"
                          class="settings-tab-pill {{ $activeTab === 'file_return' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            File Return
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>

      </div>

  </div>
</div>

<div class="card border-0 shadow-sm rounded-2 bg-white mb-4">
    <div class="card-body p-3">
      <div class="filter-layout d-flex flex-column flex-xl-row align-items-stretch align-items-xl-center justify-content-between gap-3">

          {{-- Left Side: Search & Filters --}}
          <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2 flex-grow-1">

            {{-- Search --}}
            <div class="filter-search" style="max-width: 500px; width: 40%;">
                <div class="position-relative">

                    <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                          style="pointer-events: none;">
                        <i class="mdi mdi-magnify fs-5"></i>
                    </span>

                    <input id="hr-search-field"
                          type="text"
                          placeholder="Search month,total"
                          class="form-control form-control-sm ps-7 bg-light border-0 rounded-3 text-secondary" />

                </div>
            </div>

        </div>


          {{-- Right Side: Create Button --}}
          <div class="d-flex justify-content-end align-items-center flex-shrink-0">

             <button type="button"
                      class="btn btn-primary btn-sm rounded-3 d-flex align-items-center gap-2 px-3"
                      data-bs-toggle="modal"
                      data-bs-target="#createGstPayableModal">

                  <i class="mdi mdi-plus fs-5"></i>

                  <span>Create GST Payable Entry</span>

              </button>

          </div>

      </div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
    <div class="card-body p-0">

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">

            <thead class="table-light">
                <tr>
                    <th class="fw-semibold text-secondary">GST Month</th>
                    <th class="fw-semibold text-secondary text-end">CGST</th>
                    <th class="fw-semibold text-secondary text-end">SGST</th>
                    <th class="fw-semibold text-secondary text-end">IGST</th>
                    <th class="fw-semibold text-secondary text-end">Int</th>
                    <th class="fw-semibold text-secondary text-end">Late Fee</th>
                    <th class="fw-semibold text-secondary text-end">Total</th>
                    <th class="fw-semibold text-secondary text-center">Actions</th>
                </tr>
            </thead>

            <tbody id="gstPayableTableBody">

                {{-- 2026-Jun --}}
                <tr>
                    <td>
                        <span class="fw-semibold text-dark">
                            2026-Jun
                        </span>
                    </td>

                    <td class="text-end">
                        ₹1,25,000.00
                    </td>

                    <td class="text-end">
                        ₹1,25,000.00
                    </td>

                    <td class="text-end">
                        ₹45,000.00
                    </td>

                    <td class="text-end">
                        ₹0.00
                    </td>

                    <td class="text-end">
                        ₹0.00
                    </td>

                    <td class="text-end fw-semibold">
                        ₹2,95,000.00
                    </td>

                    <td class="text-center">
                        <div class="d-inline-flex align-items-center gap-1">

                        <button type="button"
                                class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-gst-btn"
                                title="Edit"
                                data-month="2026-06"
                                data-cgst="125000.00"
                                data-sgst="125000.00"
                                data-igst="45000.00"
                                data-interest="0.00"
                                data-late-fee="0.00"
                                data-total="295000.00">
                            <i class="mdi mdi-pencil-outline"></i>
                        </button>


                        <button type="button"
                                class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                                title="delete"
                                data-bs-toggle="modal"
                                data-bs-target="#deleteGstEntryModal">
                            <i class="mdi mdi-delete"></i>
                        </button>



                        </div>
                    </td>
                </tr>


                {{-- 2026-Apr --}}
                <tr>
                    <td>
                        <span class="fw-semibold text-dark">
                            2026-Apr
                        </span>
                    </td>

                    <td class="text-end">
                        ₹5.00
                    </td>

                    <td class="text-end">
                        ₹5.00
                    </td>

                    <td class="text-end">
                        ₹6.00
                    </td>

                    <td class="text-end">
                        ₹2,000.00
                    </td>

                    <td class="text-end">
                        ₹50.00
                    </td>

                    <td class="text-end fw-semibold">
                        ₹2,066.00
                    </td>

                    <td class="text-center">
                        <div class="d-inline-flex align-items-center gap-1">
                          <button type="button"
                              class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-gst-btn"
                              title="Edit"
                              data-month="2026-04"
                              data-cgst="5.00"
                              data-sgst="5.00"
                              data-igst="6.00"
                              data-interest="2000.00"
                              data-late-fee="50.00"
                              data-total="2066.00">
                             <i class="mdi mdi-pencil-outline"></i>
                          </button>
                            <button type="button"
                                class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                                title="delete"
                                data-bs-toggle="modal"
                                data-bs-target="#deleteGstEntryModal">
                            <i class="mdi mdi-delete"></i>
                        </button>
                        </div>
                    </td>
                </tr>


                {{-- 2026-Mar --}}
                <tr>
                    <td>
                        <span class="fw-semibold text-dark">
                            2026-Mar
                        </span>
                    </td>

                    <td class="text-end">
                        ₹3.00
                    </td>

                    <td class="text-end">
                        ₹3.00
                    </td>

                    <td class="text-end">
                        ₹3.00
                    </td>

                    <td class="text-end">
                        ₹25.00
                    </td>

                    <td class="text-end">
                        ₹500.00
                    </td>

                    <td class="text-end fw-semibold">
                        ₹534.00
                    </td>

                    <td class="text-center">
                        <div class="d-inline-flex align-items-center gap-1">

                           <button type="button"
                              class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-gst-btn"
                              title="Edit"
                              data-month="2026-04"
                              data-cgst="5.00"
                              data-sgst="5.00"
                              data-igst="6.00"
                              data-interest="2000.00"
                              data-late-fee="50.00"
                              data-total="2066.00">
                             <i class="mdi mdi-pencil-outline"></i>
                          </button>
                           <button type="button"
                                class="btn btn-sm btn-icon btn-text-secondary rounded-pill"
                                title="delete"
                                data-bs-toggle="modal"
                                data-bs-target="#deleteGstEntryModal">
                            <i class="mdi mdi-delete"></i>
                        </button>

                        </div>
                    </td>
                </tr>

            </tbody>

        </table>
    </div>

</div>
</div>
<!-- Footer Section: Show entries and Pagination -->
<div class="d-flex flex-column flex-sm-row justify-content-between align-items-center p-3 border-top gap-3">

    <!-- Show Entries -->
    <div class="d-flex align-items-center gap-2 small text-muted">
        <span>Show</span>
        <select class="form-select form-select-sm" style="width: auto;">
            <option value="20">20</option>
            <option value="40">40</option>
            <option value="100">100</option>
        </select>
        <span>entries</span>
    </div>

    <!-- Pagination Info & Buttons -->
    <div class="d-flex flex-column flex-sm-row align-items-center gap-3">
        <span class="small text-muted">1 - 12 of 12 entries</span>
        <nav aria-label="Table navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                </li>
                <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item disabled">
                    <a class="page-link" href="#">Next</a>
                </li>
            </ul>
        </nav>
    </div>
</div>

<div class="modal fade"
     id="createGstPayableModal"
     tabindex="-1"
     aria-labelledby="createGstPayableModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content border-0 shadow-lg rounded-4">

            {{-- Modal Header --}}
            <div class="modal-header border-0 px-4 pt-4 pb-2 bg-primary">

                <div>
                   <h5 class="modal-title fw-bold text-white" id="createGstPayableModalLabel">
                        Create GST Payable Entry
                    </h5>

                    <p class="text-white-50 mb-0 mt-1" id="gstPayableModalDescription">
                        Enter GST payable details for the selected month
                    </p>
                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>

            </div>


            {{-- Modal Body --}}
            <div class="modal-body px-4 py-4">

                <form id="gstPayableEntryForm">

                    <div class="row g-3">

                        {{-- Month --}}
                        <div class="col-md-6">
                            <label for="gstMonth" class="form-label fw-semibold">
                                Month <span class="text-danger">*</span>
                            </label>

                            <input type="month"
                                  id="gstMonth"
                                  name="month"
                                  class="form-control"
                                  required>
                        </div>


                        {{-- CGST --}}
                        <div class="col-md-6">
                            <label for="gstCgst" class="form-label fw-semibold">
                                CGST <span class="text-danger">*</span>
                            </label>

                            <div class="input-group">
                                <span class="input-group-text">₹</span>

                                <input type="number"
                                      id="gstCgst"
                                      name="cgst"
                                      class="form-control"
                                      placeholder="Enter CGST"
                                      min="0"
                                      step="0.01"
                                      required>
                            </div>
                        </div>


                        {{-- SGST --}}
                        <div class="col-md-6">
                            <label for="gstSgst" class="form-label fw-semibold">
                                SGST <span class="text-danger">*</span>
                            </label>

                            <div class="input-group">
                                <span class="input-group-text">₹</span>

                                <input type="number"
                                      id="gstSgst"
                                      name="sgst"
                                      class="form-control"
                                      placeholder="Enter SGST"
                                      min="0"
                                      step="0.01"
                                      required>
                            </div>
                        </div>


                        {{-- IGST --}}
                        <div class="col-md-6">
                            <label for="gstIgst" class="form-label fw-semibold">
                                IGST <span class="text-danger">*</span>
                            </label>

                            <div class="input-group">
                                <span class="input-group-text">₹</span>

                                <input type="number"
                                      id="gstIgst"
                                      name="igst"
                                      class="form-control"
                                      placeholder="Enter IGST"
                                      min="0"
                                      step="0.01"
                                      required>
                            </div>
                        </div>


                        {{-- Interest --}}
                        <div class="col-md-6">
                            <label for="gstInterest" class="form-label fw-semibold">
                                Interest <span class="text-danger">*</span>
                            </label>

                            <div class="input-group">
                                <span class="input-group-text">₹</span>

                                <input type="number"
                                      id="gstInterest"
                                      name="interest"
                                      class="form-control"
                                      placeholder="Enter Interest"
                                      min="0"
                                      step="0.01"
                                      required>
                            </div>
                        </div>


                        {{-- Late Fee --}}
                        <div class="col-md-6">
                            <label for="gstLateFee" class="form-label fw-semibold">
                                Late Fee <span class="text-danger">*</span>
                            </label>

                            <div class="input-group">
                                <span class="input-group-text">₹</span>

                                <input type="number"
                                      id="gstLateFee"
                                      name="late_fee"
                                      class="form-control"
                                      placeholder="Enter Late Fee"
                                      min="0"
                                      step="0.01"
                                      required>
                            </div>
                        </div>


                        {{-- Total --}}
                        <div class="col-12">

                            <label for="gstTotal" class="form-label fw-semibold">
                                Total <span class="text-danger">*</span>
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">₹</span>

                                <input type="number"
                                      id="gstTotal"
                                      name="total"
                                      class="form-control fw-semibold"
                                      placeholder="Total"
                                      min="0"
                                      step="0.01"
                                      readonly
                                      required>

                            </div>

                            <small class="text-muted">
                                Total is automatically calculated from CGST, SGST, IGST, Interest and Late Fee.
                            </small>

                        </div>

                    </div>

                </form>

            </div>


            {{-- Modal Footer --}}
            <div class="modal-footer border-0 px-4 pb-4">

                <button type="button"
                        class="btn btn-light rounded-3"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button"
                        class="btn btn-primary rounded-3 px-4"
                        id="saveGstPayableEntry">

                    <i class="mdi mdi-content-save-outline me-1" id="gstSaveIcon"></i>

                    <span id="gstSaveButtonText">Save Entry</span>

                </button>

            </div>

        </div>

    </div>
</div>


<!-- Delete GST Confirmation Modal -->
<div
    class="modal fade"
    id="deleteGstEntryModal"
    tabindex="-1"
    aria-labelledby="deleteGstEntryModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-3 shadow">

            <!-- Header -->
            <div class="modal-header border-0 pb-2">
                <h5
                    class="modal-title fw-semibold"
                    id="deleteGstEntryModalLabel"
                >
                    Confirm Delete
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>

            <!-- Body -->
            <div class="modal-body pt-2">
                <div class="d-flex align-items-start gap-3">
                    <div
                        class="d-flex align-items-center justify-content-center rounded-circle bg-danger-subtle text-danger"
                        style="width: 42px; height: 42px; flex-shrink: 0;"
                    >
                        <i class="mdi mdi-delete-outline fs-5"></i>
                    </div>

                    <div>
                        <p class="mb-1 fw-semibold text-dark">
                            Delete GST reconciliation?
                        </p>

                        <p class="mb-0 text-muted small">
                            Are you sure you want to delete this GST
                            payable entry? This action cannot be undone.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="modal-footer border-0 pt-2">
                <button
                    type="button"
                    class="btn btn-light px-4"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    class="btn btn-danger px-4"
                    id="confirmDeleteGstEntryBtn"
                >
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Confirm Delete
                </button>
            </div>

        </div>
    </div>
</div>


<style>
    .settings-header-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>


<script>
    document.addEventListener('DOMContentLoaded', function () {

        const scroller = document.getElementById('settingsTabScroller');
        const prevBtn = document.getElementById('settingsTabPrev');
        const nextBtn = document.getElementById('settingsTabNext');

        if (!scroller || !prevBtn || !nextBtn) {
            return;
        }

        prevBtn.addEventListener('click', function () {
            scroller.scrollBy({
                left: -300,
                behavior: 'smooth'
            });
        });

        nextBtn.addEventListener('click', function () {
            scroller.scrollBy({
                left: 300,
                behavior: 'smooth'
            });
        });

    });

    document.addEventListener('DOMContentLoaded', function () {

        const searchInput = document.getElementById('hr-search-field');
        const tableBody = document.getElementById('gstPayableTableBody');

        if (!searchInput || !tableBody) {
            return;
        }

        searchInput.addEventListener('input', function () {

            const searchValue = this.value.toLowerCase().trim();
            const rows = tableBody.querySelectorAll('tr');

            rows.forEach(function (row) {

                const rowText = row.textContent.toLowerCase();

                if (rowText.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }

            });

        });

    });

  document.addEventListener('DOMContentLoaded', function () {

      const modalElement = document.getElementById('createGstPayableModal');
      const form = document.getElementById('gstPayableEntryForm');

      const modalTitle = document.getElementById('createGstPayableModalLabel');
      const modalDescription = document.getElementById('gstPayableModalDescription');

      const monthInput = document.getElementById('gstMonth');
      const cgstInput = document.getElementById('gstCgst');
      const sgstInput = document.getElementById('gstSgst');
      const igstInput = document.getElementById('gstIgst');
      const interestInput = document.getElementById('gstInterest');
      const lateFeeInput = document.getElementById('gstLateFee');
      const totalInput = document.getElementById('gstTotal');

      const saveButton = document.getElementById('saveGstPayableEntry');
      const saveButtonText = document.getElementById('gstSaveButtonText');
      const saveIcon = document.getElementById('gstSaveIcon');

      const editButtons = document.querySelectorAll('.edit-gst-btn');

      let editMode = false;

      function calculateTotal() {

          const cgst = parseFloat(cgstInput.value) || 0;
          const sgst = parseFloat(sgstInput.value) || 0;
          const igst = parseFloat(igstInput.value) || 0;
          const interest = parseFloat(interestInput.value) || 0;
          const lateFee = parseFloat(lateFeeInput.value) || 0;

          const total =
              cgst +
              sgst +
              igst +
              interest +
              lateFee;

          totalInput.value = total.toFixed(2);
      }

      cgstInput.addEventListener('input', calculateTotal);
      sgstInput.addEventListener('input', calculateTotal);
      igstInput.addEventListener('input', calculateTotal);
      interestInput.addEventListener('input', calculateTotal);
      lateFeeInput.addEventListener('input', calculateTotal);


      editButtons.forEach(function (button) {

          button.addEventListener('click', function () {

              editMode = true;

              monthInput.value = this.dataset.month;
              cgstInput.value = this.dataset.cgst;
              sgstInput.value = this.dataset.sgst;
              igstInput.value = this.dataset.igst;
              interestInput.value = this.dataset.interest;
              lateFeeInput.value = this.dataset.lateFee;
              totalInput.value = this.dataset.total;

              modalTitle.textContent = 'Edit GST Payable Entry';

              modalDescription.textContent =
                  'Update GST payable details for the selected month';

              saveButtonText.textContent = 'Update Entry';

              saveIcon.className =
                  'mdi mdi-content-save-edit-outline me-1';

              const modal =
                  bootstrap.Modal.getOrCreateInstance(modalElement);

              modal.show();
          });

      });


      saveButton.addEventListener('click', function () {

          if (!form.checkValidity()) {
              form.reportValidity();
              return;
          }

          const data = {
              month: monthInput.value,
              cgst: cgstInput.value,
              sgst: sgstInput.value,
              igst: igstInput.value,
              interest: interestInput.value,
              late_fee: lateFeeInput.value,
              total: totalInput.value
          };

          if (editMode) {

              console.log('Updating GST Entry:', data);

          } else {

              console.log('Creating GST Entry:', data);

          }

      });


      modalElement.addEventListener('hidden.bs.modal', function () {

          form.reset();

          editMode = false;

          modalTitle.textContent = 'Create GST Payable Entry';

          modalDescription.textContent =
              'Enter GST payable details for the selected month';

          saveButtonText.textContent = 'Save Entry';

          saveIcon.className =
              'mdi mdi-content-save-outline me-1';

          totalInput.value = '';

      });

  });

</script>

@endsection
