@extends('layouts.layoutMaster')

@section('title', 'GST Payable Management - Tax_management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')


<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">
              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>
              <div>
                  <h4 class="mb-1 fw-bold text-primary fs-5">
                      GST Payable Management
                  </h4>
                  <p class="text-muted mb-0 fs-8">
                      Manage GST payable entries, estimations and payable records
                  </p>
              </div>
          </div>


          {{-- Navigation --}}
         <div class="settings-tabs-wrapper d-flex align-items-center">
            {{-- Previous Button --}}
            <button
                type="button"
                class="settings-tab-scroll-btn me-1"
                id="settingsTabPrev">
                <i class="mdi mdi-chevron-left"></i>
            </button>

            {{-- Tabs --}}
            <div class="settings-tabs-scroller" id="settingsTabsScroller">
                <div class="settings-tabs-track" id="settingsTabScroller">

                    @php
                        $activeTab = request('tab', 'entry');
                    @endphp

                    <a href="{{ route('accounts.tax-management', ['tab' => 'entry']) }}"
                      class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">
                        <i class="mdi mdi-file-document-edit-outline me-1"></i>
                        GST Payable Entry
                    </a>

                    <a href="{{ route('accounts.tax-management.gst-estimate', ['tab' => 'estimation']) }}"
                      class="settings-tab-pill {{ $activeTab === 'estimation' ? 'active' : '' }}">
                        <i class="mdi mdi-calculator-variant-outline me-1"></i>
                        GST Payable Estimation
                    </a>

                    <a href="{{ route('accounts.tax-management.gst-payable', ['tab' => 'payable']) }}"
                      class="settings-tab-pill {{ $activeTab === 'payable' ? 'active' : '' }}">
                        <i class="mdi mdi-cash-check me-1"></i>
                        GST Payable
                    </a>

                    <a href="{{ route('accounts.tax-management.gst-recollination', ['tab' => 'reconciliation']) }}"
                      class="settings-tab-pill {{ $activeTab === 'reconciliation' ? 'active' : '' }}">
                        <i class="mdi mdi-clipboard-check-outline me-1"></i>
                        GST Reconciliation
                    </a>

                    <a href="{{ route('accounts.tax-management.gst-file_return', ['tab' => 'file_return']) }}"
                          class="settings-tab-pill {{ $activeTab === 'file_return' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            File Return
                    </a>

                </div>
            </div>

            {{-- Next Button --}}
            <button
                type="button"
                class="settings-tab-scroll-btn ms-1"
                id="settingsTabNext">
                <i class="mdi mdi-chevron-right"></i>
            </button>
        </div>
      </div>
  </div>
</div>


{{-- Date Filter --}}
<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
    <div class="card-body p-3">

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-end gap-3">

            {{-- Left Side: Date Filters --}}
            <div class="row g-3 flex-grow-1">

                {{-- Start Date --}}
                <div class="col-md-4">
                    <label for="startDate" class="form-label fw-semibold mb-1">
                        From
                    </label>

                    <input type="date"
                           id="startDate"
                           class="form-control form-control-sm bg-light border-0 rounded-3">
                </div>


                {{-- End Date --}}
                <div class="col-md-4">
                    <label for="endDate" class="form-label fw-semibold mb-1">
                        To
                    </label>

                    <input type="date"
                           id="endDate"
                           class="form-control form-control-sm bg-light border-0 rounded-3">
                </div>

            </div>


            {{-- Right Side: Apply Button --}}
            <div class="d-flex justify-content-end">

                <button type="button"
                        class="btn btn-primary btn-sm rounded-3 px-4">
                    <i class="mdi mdi-filter-outline me-1"></i>
                    Apply
                </button>

            </div>

        </div>

    </div>
</div>


<div class="row g-4">

    {{-- GST Payable Table --}}
    <div class="col-lg-7">

        <div class="card border-0 shadow-sm rounded-4 bg-white h-100">

            <div class="card-body p-0">

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>
                                <th colspan="7" class="text-center fw-bold text-secondary">
                                    GST Payable - Tamil Nadu
                                </th>
                            </tr>

                            <tr>
                                <th class="fw-semibold text-secondary">
                                    Month
                                </th>

                                <th class="fw-semibold text-secondary text-end">
                                    CGST
                                </th>

                                <th class="fw-semibold text-secondary text-end">
                                    SGST
                                </th>

                                <th class="fw-semibold text-secondary text-end">
                                    IGST
                                </th>

                                <th class="fw-semibold text-secondary text-end">
                                    Int
                                </th>

                                <th class="fw-semibold text-secondary text-end">
                                    Late Fee
                                </th>

                                <th class="fw-semibold text-secondary text-end">
                                    Total to be Paid
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            <tr>
                                <td class="fw-semibold">
                                    2026-Mar
                                </td>

                                <td class="text-end">
                                    ₹3.00
                                </td>

                                <td class="text-end">
                                    ₹3.00
                                </td>

                                <td class="text-end">
                                    ₹3.00
                                </td>

                                <td class="text-end">
                                    ₹25.00
                                </td>

                                <td class="text-end">
                                    ₹500.00
                                </td>

                                <td class="text-end fw-semibold">
                                    ₹534.00
                                </td>
                            </tr>


                            <tr>
                                <td class="fw-semibold">
                                    2026-Apr
                                </td>

                                <td class="text-end">
                                    ₹5.00
                                </td>

                                <td class="text-end">
                                    ₹5.00
                                </td>

                                <td class="text-end">
                                    ₹6.00
                                </td>

                                <td class="text-end">
                                    ₹2,000.00
                                </td>

                                <td class="text-end">
                                    ₹50.00
                                </td>

                                <td class="text-end fw-semibold">
                                    ₹2,066.00
                                </td>
                            </tr>


                            <tr>
                                <td class="fw-semibold">
                                    2026-Jun
                                </td>

                                <td class="text-end">
                                    ₹1,25,000.00
                                </td>

                                <td class="text-end">
                                    ₹1,25,000.00
                                </td>

                                <td class="text-end">
                                    ₹45,000.00
                                </td>

                                <td class="text-end">
                                    -
                                </td>

                                <td class="text-end">
                                    -
                                </td>

                                <td class="text-end fw-semibold">
                                    ₹2,95,000.00
                                </td>
                            </tr>


                        </tbody>


                        <tfoot class="table-light">

                            <tr>

                                <th>
                                    Total:
                                </th>

                                <th class="text-end">
                                    ₹1,25,008.00
                                </th>

                                <th class="text-end">
                                    ₹1,25,008.00
                                </th>

                                <th class="text-end">
                                    ₹45,009.00
                                </th>

                                <th class="text-end">
                                    ₹2,025.00
                                </th>

                                <th class="text-end">
                                    ₹550.00
                                </th>

                                <th class="text-end fw-bold">
                                    ₹2,97,600.00
                                </th>

                            </tr>

                        </tfoot>


                    </table>

                </div>

            </div>

        </div>

    </div>
    {{-- GST Receivable Table --}}
    <div class="col-lg-5">

        <div class="card border-0 shadow-sm rounded-4 bg-white h-100">

            <div class="card-body p-0">

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">


                        <thead class="table-light">

                            <tr>

                                <th colspan="4" class="text-center fw-bold text-secondary">

                                    GST Receivable as per Client Bills

                                </th>

                            </tr>


                            <tr>

                                <th class="fw-semibold text-secondary">
                                    Site
                                </th>

                                <th class="fw-semibold text-secondary text-end">
                                    Gross Amount
                                </th>

                                <th class="fw-semibold text-secondary text-end">
                                    GST Payment
                                </th>

                                <th class="fw-semibold text-secondary">
                                    Remarks
                                </th>

                            </tr>


                        </thead>


                        <tbody>


                            <tr>

                                <td class="fw-semibold">
                                    Industrial Warehouse Construction
                                </td>

                                <td class="text-end">
                                    ₹0.00
                                </td>

                                <td class="text-end">
                                    ₹0.00
                                </td>

                                <td>
                                    -
                                </td>

                            </tr>


                            <tr>

                                <td class="fw-semibold">
                                    Water Treatment Plant Setup
                                </td>

                                <td class="text-end">
                                    ₹0.00
                                </td>

                                <td class="text-end">
                                    ₹0.00
                                </td>

                                <td>
                                    -
                                </td>

                            </tr>


                            <tr>

                                <td class="fw-semibold">
                                    Commercial Complex - Block
                                </td>

                                <td class="text-end">
                                    ₹0.00
                                </td>

                                <td class="text-end">
                                    ₹0.00
                                </td>

                                <td>
                                    -
                                </td>

                            </tr>


                        </tbody>


                        <tfoot class="table-light">

                            <tr>

                                <th>
                                    Total:
                                </th>

                                <th class="text-end">
                                    ₹0.00
                                </th>

                                <th class="text-end">
                                    ₹0.00
                                </th>

                                <th>

                                </th>

                            </tr>

                        </tfoot>


                    </table>


                </div>

            </div>

        </div>

    </div>
</div>



<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }




</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    // The actual element that has horizontal scrolling
    const scroller = document.getElementById('settingsTabScroller');

    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Safety check
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // -----------------------------------------
    // Update left/right button states
    // -----------------------------------------
    function updateButtons() {

        const maxScroll =
            scroller.scrollWidth - scroller.clientWidth;

        // Disable left button when at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable right button when at the end
        nextBtn.disabled =
            scroller.scrollLeft >= maxScroll - 1;
    }


    // -----------------------------------------
    // LEFT BUTTON
    // -----------------------------------------
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // -----------------------------------------
    // RIGHT BUTTON
    // -----------------------------------------
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // -----------------------------------------
    // Update buttons when scrolling
    // -----------------------------------------
    scroller.addEventListener('scroll', updateButtons);


    // -----------------------------------------
    // Update buttons when window resizes
    // -----------------------------------------
    window.addEventListener('resize', updateButtons);


    // -----------------------------------------
    // Automatically show active tab
    // -----------------------------------------
    const activeTab =
        scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // -----------------------------------------
    // Initial button state
    // -----------------------------------------
    updateButtons();

});
</script>

@endsection
