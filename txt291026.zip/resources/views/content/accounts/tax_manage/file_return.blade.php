@extends('layouts.layoutMaster')

@section('title', 'GST File Return - Tax_management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>

              <div>
                  <h4 class="mb-1 fw-bold text-primary fs-5">
                      File return
                  </h4>

                  <p class="text-muted mb-0 fs-8">
                      Manage GST file return entries, estimations and payable records
                  </p>
              </div>

          </div>


          {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- GST Payable Entry --}}
                      <a
                          href="{{ route('accounts.tax-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                          GST Payable Entry

                      </a>


                      {{-- GST Payable Estimation --}}
                      <a
                          href="{{ route('accounts.tax-management.gst-estimate', ['tab' => 'estimation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'estimation' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                          GST Payable Estimation

                      </a>


                      {{-- GST Payable --}}
                      <a
                          href="{{ route('accounts.tax-management.gst-payable', ['tab' => 'payable']) }}"
                          class="settings-tab-pill {{ $activeTab === 'payable' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                          GST Payable

                      </a>

                       <a href="{{ route('accounts.tax-management.gst-recollination', ['tab' => 'reconciliation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'reconciliation' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            GST Reconciliation
                        </a>

                         <a href="{{ route('accounts.tax-management.gst-file_return', ['tab' => 'file_return']) }}"
                          class="settings-tab-pill {{ $activeTab === 'file_return' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            File Return
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>

      </div>

  </div>
</div>

<div class="card border-0 shadow-sm rounded-2 bg-white mb-4">
    <div class="card-body p-3">
      <div class="filter-layout d-flex flex-column flex-xl-row align-items-stretch align-items-xl-center justify-content-between gap-3">

          {{-- Left Side: Search & Filters --}}
          <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2 flex-grow-1">

            {{-- Search --}}
            <div class="filter-search" style="max-width: 500px; width: 40%;">
                <div class="position-relative">

                    <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                          style="pointer-events: none;">
                        <i class="mdi mdi-magnify fs-5"></i>
                    </span>

                    <input id="hr-search-field"
                          type="text"
                          placeholder="Search month,total"
                          class="form-control form-control-sm ps-7 bg-light border-0 rounded-3 text-secondary" />

                </div>
            </div>

        </div>


          {{-- Right Side: Create Button --}}
          <div class="d-flex justify-content-end align-items-center flex-shrink-0">
              <a href="{{ route('accounts.tax-management.create_file_return') }}"
                class="btn btn-primary btn-sm rounded-3 d-flex align-items-center gap-2 px-3">
                  <i class="mdi mdi-plus fs-5"></i>
                  <span>Create GST File Return</span>
              </a>
          </div>

      </div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
    <div class="card-body p-0">

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">
                    <tr>
                        <th class="fw-semibold text-secondary">Date</th>
                        <th class="fw-semibold text-secondary">Year Month</th>
                        <th class="fw-semibold text-secondary text-center">Actions</th>
                    </tr>
                </thead>

                <tbody id="dateYearMonthTableBody">

                    {{-- 18-09-2026 --}}
                    <tr>
                        <td>
                            <span class="fw-semibold text-dark">18-09-2026</span>
                        </td>

                        <td>
                            <span class="fw-semibold text-dark">2026-Sep</span>
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-1">

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"
                                        title="Edit"
                                        data-date="18-09-2026"
                                        data-year-month="2026-Sep">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>

                               <button type="button"
                                      class="btn btn-sm btn-icon rounded-3 btn-text-secondary d-flex align-items-center gap-2 px-3"
                                      data-bs-toggle="modal"
                                      data-bs-target="#viewGstFileReturnModal">
                                  <i class="mdi mdi-eye-outline fs-5"></i>

                              </button>

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill delete-row-btn"
                                        title="Delete"
                                        data-date="18-09-2026"
                                        data-year-month="2026-Sep">
                                    <i class="mdi mdi-delete"></i>
                                </button>

                            </div>
                        </td>
                    </tr>

                    {{-- 17-03-2026 --}}
                    <tr>
                        <td>
                            <span class="fw-semibold text-dark">17-03-2026</span>
                        </td>

                        <td>
                            <span class="fw-semibold text-dark">2026-Mar</span>
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-1">

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"
                                        title="Edit"
                                        data-date="17-03-2026"
                                        data-year-month="2026-Mar">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"

                                        data-bs-toggle="modal"
                                        data-bs-target="#viewGstFileReturnModal">
                                        <i class="mdi mdi-eye-outline"></i>
                                </button>


                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill delete-row-btn"
                                        title="Delete"
                                        data-date="17-03-2026"
                                        data-year-month="2026-Mar">
                                    <i class="mdi mdi-delete"></i>
                                </button>

                            </div>
                        </td>
                    </tr>

                    {{-- 06-07-2026 --}}
                    <tr>
                        <td>
                            <span class="fw-semibold text-dark">06-07-2026</span>
                        </td>

                        <td>
                            <span class="fw-semibold text-dark">2026-Jun</span>
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-1">

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"
                                        title="Edit"
                                        data-date="06-07-2026"
                                        data-year-month="2026-Jun"
                                        data-bs-toggle>
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>

                                <button type="button"
                                      class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"
                                      data-bs-toggle="modal"
                                      data-bs-target="#viewGstFileReturnModal">
                                      <i class="mdi mdi-eye-outline"></i>
                                </button>

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill delete-row-btn"
                                        title="Delete"
                                        data-date="06-07-2026"
                                        data-year-month="2026-Jun">
                                    <i class="mdi mdi-delete"></i>
                                </button>

                            </div>
                        </td>
                    </tr>

                    {{-- 18-09-2026 (2026-Apr) --}}
                    <tr>
                        <td>
                            <span class="fw-semibold text-dark">18-09-2026</span>
                        </td>

                        <td>
                            <span class="fw-semibold text-dark">2026-Apr</span>
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-1">

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"
                                        title="Edit"
                                        data-date="18-09-2026"
                                        data-year-month="2026-Apr">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>

                                <button type="button"
                                    class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"
                                    data-bs-toggle = "modal"
                                    data-bs-target = "#viewGstFileReturnModal">
                                    <i class="mdi mdi-eye-outline"></i>
                                  </button>

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill delete-row-btn"
                                        title="Delete"
                                        data-date="18-09-2026"
                                        data-year-month="2026-Apr">
                                    <i class="mdi mdi-delete"></i>
                                </button>

                            </div>
                        </td>
                    </tr>

                    {{-- 18-09-2026 (2026-Apr) duplicate --}}
                    <tr>
                        <td>
                            <span class="fw-semibold text-dark">18-09-2026</span>
                        </td>

                        <td>
                            <span class="fw-semibold text-dark">2026-Apr</span>
                        </td>

                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-1">

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"
                                        title="Edit"
                                        data-date="18-09-2026"
                                        data-year-month="2026-Apr">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>

                                 <button type="button"
                                    class="btn btn-sm btn-icon btn-text-secondary rounded-pill edit-row-btn"
                                    data-bs-toggle = "modal"
                                    data-bs-target = "#viewGstFileReturnModal">
                                    <i class="mdi mdi-eye-outline"></i>
                                  </button>

                                <button type="button"
                                        class="btn btn-sm btn-icon btn-text-secondary rounded-pill delete-row-btn"
                                        title="Delete"
                                        data-date="18-09-2026"
                                        data-year-month="2026-Apr">
                                    <i class="mdi mdi-delete"></i>
                                </button>

                            </div>
                        </td>
                    </tr>

                </tbody>

            </table>
        </div>

    </div>
</div>

<!-- Footer Section: Show entries and Pagination -->
<div class="d-flex flex-column flex-sm-row justify-content-between align-items-center p-3 border-top gap-3">

    <!-- Show Entries -->
    <div class="d-flex align-items-center gap-2 small text-muted">
        <span>Show</span>
        <select class="form-select form-select-sm" style="width: auto;">
            <option value="20">20</option>
            <option value="40">40</option>
            <option value="100">100</option>
        </select>
        <span>entries</span>
    </div>

    <!-- Pagination Info & Buttons -->
    <div class="d-flex flex-column flex-sm-row align-items-center gap-3">
        <span class="small text-muted">1 - 12 of 12 entries</span>
        <nav aria-label="Table navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                </li>
                <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item disabled">
                    <a class="page-link" href="#">Next</a>
                </li>
            </ul>
        </nav>
    </div>
</div>


{{-- GST File Return — View Modal --}}
<div class="modal fade"
     id="viewGstFileReturnModal"
     tabindex="-1"
     aria-labelledby="viewGstFileReturnModalLabel"
     aria-hidden="true">

    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content rounded-4 border-0 shadow">

            <!-- Header -->
            <div class="modal-header border-bottom bg-primary">
                <div>
                    <h5 class="modal-title fw-semibold mb-1 text-white"
                        id="viewGstFileReturnModalLabel">
                        GST File Return
                    </h5>

                    <div class="small text-muted">
                        <span class="fw-semibold text-dark-subtle">SRK Infra Developers</span>
                        <span class="mx-1">·</span>
                        <span>2026-Mar</span>
                    </div>
                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"></button>
            </div>

            <!-- Body -->
            <div class="modal-body">

                <!-- GST Calculation Table -->
                <div class="table-responsive">
                    <table class="table table-bordered align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="fw-semibold text-secondary"
                                    style="min-width: 260px;">
                                    GST Calculation
                                </th>
                                <th class="fw-semibold text-secondary text-end"
                                    style="min-width: 110px;">Taxable</th>
                                <th class="fw-semibold text-secondary text-end"
                                    style="min-width: 110px;">CGST</th>
                                <th class="fw-semibold text-secondary text-end"
                                    style="min-width: 110px;">SGST</th>
                                <th class="fw-semibold text-secondary text-end"
                                    style="min-width: 110px;">IGST</th>
                                <th class="fw-semibold text-secondary text-end"
                                    style="min-width: 110px;">Total</th>
                            </tr>
                        </thead>

                        <tbody>
                            {{-- Opening (A) --}}
                            <tr>
                                <td class="fw-semibold">Opening (A)</td>
                                <td class="text-end">2,000.00</td>
                                <td class="text-end">3.00</td>
                                <td class="text-end">3.00</td>
                                <td class="text-end">5.00</td>
                                <td class="text-end">11.00</td>
                            </tr>

                            {{-- Inward Supply (B) --}}
                            <tr>
                                <td class="fw-semibold">Inward Supply (B)</td>
                                <td class="text-end">5,000.00</td>
                                <td class="text-end">4.00</td>
                                <td class="text-end">4.00</td>
                                <td class="text-end">4.00</td>
                                <td class="text-end">12.00</td>
                            </tr>

                            {{-- ITC Reversed (C) --}}
                            <tr>
                                <td class="fw-semibold">ITC Reversed (C)</td>
                                <td class="text-end">12,000.00</td>
                                <td class="text-end">4.00</td>
                                <td class="text-end">5.00</td>
                                <td class="text-end">6.00</td>
                                <td class="text-end">15.00</td>
                            </tr>

                            {{-- Reverse Charge (D) --}}
                            <tr>
                                <td class="fw-semibold">Reverse Charge (D)</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                            </tr>

                            {{-- Sub Total (1) --}}
                            <tr class="table-light">
                                <td class="fw-semibold">Sub Total (1) = (A)+(B)-(C)+(D)</td>
                                <td class="text-end fw-semibold">-5,000.00</td>
                                <td class="text-end fw-semibold">3.00</td>
                                <td class="text-end fw-semibold">2.00</td>
                                <td class="text-end fw-semibold">3.00</td>
                                <td class="text-end fw-semibold">8.00</td>
                            </tr>

                            {{-- Outward Supply (A) --}}
                            <tr>
                                <td class="fw-semibold">Outward Supply (A)</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                            </tr>

                            {{-- Reverse Charge (B) --}}
                            <tr>
                                <td class="fw-semibold">Reverse Charge (B)</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                                <td class="text-end">0.00</td>
                            </tr>

                            {{-- Sub Total (2) --}}
                            <tr class="table-light">
                                <td class="fw-semibold">Sub Total (2) = (A)+(B)</td>
                                <td class="text-end fw-semibold">0.00</td>
                                <td class="text-end fw-semibold">0.00</td>
                                <td class="text-end fw-semibold">0.00</td>
                                <td class="text-end fw-semibold">0.00</td>
                                <td class="text-end fw-semibold">0.00</td>
                            </tr>

                            {{-- Before Closing (1-2) --}}
                            <tr>
                                <td class="fw-semibold">Before Closing (1-2)</td>
                                <td class="text-end">-5,000.00</td>
                                <td class="text-end">3.00</td>
                                <td class="text-end">2.00</td>
                                <td class="text-end">3.00</td>
                                <td class="text-end">8.00</td>
                            </tr>

                            {{-- To Pay --}}
                            <tr class="table-warning">
                                <td class="fw-semibold">To Pay</td>
                                <td class="text-end fw-semibold">5,000.00</td>
                                <td class="text-end fw-semibold">-3.00</td>
                                <td class="text-end fw-semibold">-2.00</td>
                                <td class="text-end fw-semibold">-3.00</td>
                                <td class="text-end fw-semibold">-8.00</td>
                            </tr>

                            {{-- After Closing --}}
                            <tr class="table-success">
                                <td class="fw-semibold">After Closing</td>
                                <td class="text-end fw-semibold">0.00</td>
                                <td class="text-end fw-semibold">0.00</td>
                                <td class="text-end fw-semibold">0.00</td>
                                <td class="text-end fw-semibold">0.00</td>
                                <td class="text-end fw-semibold">0.00</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>

            <!-- Footer -->
            <div class="modal-footer border-top">
                <button type="button"
                        class="btn btn-outline-secondary rounded-3"
                        data-bs-dismiss="modal">
                    Close
                </button>

                <button type="button"
                        class="btn btn-primary rounded-3 d-flex align-items-center gap-2 px-3">
                    <i class="mdi mdi-printer-outline fs-5"></i>
                    <span>Print</span>
                </button>
            </div>

        </div>
    </div>
</div>

<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>

@endsection
