@extends('layouts.layoutMaster')

@section('title', 'File_return - Tax_management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <!-- Page Header -->
    <div class="d-flex flex-wrap align-items-center justify-content-start gap-3 mb-4">
      <a href="{{ route('accounts.tax-management.gst-file_return', ['tab' => 'file_return']) }}"
           class="btn rounded-3 d-flex align-items-center gap-2 px-3">
            <i class="mdi mdi-arrow-left fs-5"></i>
        </a>
        <div>

            <h4 class="fw-semibold mb-1">Create GST File Return</h4>
            <p class="text-muted mb-0 small">
                Enter the month and GST calculation details below.
            </p>
        </div>


    </div>

    <!-- Card -->
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-4">

            <!-- Month -->
            <div class="mb-4" style="max-width: 320px;">
                <label for="gstMonth" class="form-label fw-semibold">
                    Month <span class="text-danger">*</span>
                </label>

                <input type="month"
                       id="gstMonth"
                       name="gst_month"
                       class="form-control"
                       value="2026-09"
                       required>
            </div>

            <!-- GST Calculation Table -->
            <div class="table-responsive">
                <table class="table table-bordered align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="fw-semibold text-secondary"
                                style="min-width: 260px;">
                                GST Calculation
                            </th>
                            <th class="fw-semibold text-secondary text-end"
                                style="min-width: 110px;">Taxable</th>
                            <th class="fw-semibold text-secondary text-end"
                                style="min-width: 110px;">CGST</th>
                            <th class="fw-semibold text-secondary text-end"
                                style="min-width: 110px;">SGST</th>
                            <th class="fw-semibold text-secondary text-end"
                                style="min-width: 110px;">IGST</th>
                            <th class="fw-semibold text-secondary text-end"
                                style="min-width: 110px;">Total</th>
                        </tr>
                    </thead>

                    <tbody>
                        {{-- Opening (A) --}}
                        <tr>
                            <td class="fw-semibold">Opening (A)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- Inward Supply (B) --}}
                        <tr>
                            <td class="fw-semibold">Inward Supply (B)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- ITC Reversed (C) --}}
                        <tr>
                            <td class="fw-semibold">ITC Reversed (C)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- Reverse Charge (D) --}}
                        <tr>
                            <td class="fw-semibold">Reverse Charge (D)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- Sub Total (1) --}}
                        <tr class="table-light">
                            <td class="fw-semibold">Sub Total (1) = (A)+(B)-(C)+(D)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- Outward Supply (A) --}}
                        <tr>
                            <td class="fw-semibold">Outward Supply (A)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- Reverse Charge (B) --}}
                        <tr>
                            <td class="fw-semibold">Reverse Charge (B)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- Sub Total (2) --}}
                        <tr class="table-light">
                            <td class="fw-semibold">Sub Total (2) = (A)+(B)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- Before Closing (1-2) --}}
                        <tr>
                            <td class="fw-semibold">Before Closing (1-2)</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- To Pay --}}
                        <tr class="table-warning">
                            <td class="fw-semibold">To Pay</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>

                        {{-- After Closing --}}
                        <tr class="table-success">
                            <td class="fw-semibold">After Closing</td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                            <td><input type="number" class="form-control form-control-sm text-end" value="0"></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Action Buttons -->
            <div class="d-flex justify-content-end gap-2 mt-4">
                <a href="{{ url()->previous() }}"
                   class="btn btn-outline-secondary rounded-3">
                    Cancel
                </a>

                <button type="button"
                        class="btn btn-primary rounded-3 d-flex align-items-center gap-2 px-3">
                    <i class="mdi mdi-content-save-outline fs-5"></i>
                    <span>Save GST Return</span>
                </button>
            </div>

        </div>
    </div>

</div>

@endsection
