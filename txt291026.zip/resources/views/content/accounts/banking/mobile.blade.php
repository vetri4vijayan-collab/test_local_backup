@extends('layouts/contentNavbarLayout')

@section('title', 'Mobile Bill Entry')

@section('content')

<div class="container-fluid">

    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body p-3 p-md-4">
            <div class="d-flex justify-content-between align-items-center flex-nowrap gap-3">
                <div class="flex-shrink-0" style="min-width: 0;">
                    <h5 class="fw-bold mb-1">Mobile Connection &amp; Data Recharge Register</h5>
                    <p class="text-muted small mb-0">
                        Corporate SIM allocations, field staff recharges, and monthly reimbursement claims
                    </p>
                </div>
                <div class="settings-tabs-wrapper">
                    <div class="d-flex align-items-center gap-2">
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollLeft">
                            <i class="mdi mdi-chevron-left"></i>
                        </button>
                        <div class="settings-tabs-scroller">
                            <div class="settings-tabs-track" id="ledgerTabsTrack">
                                <a href="{{ route('accounts.banking') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.banking') ? 'active' : '' }}">
                                    Bank Ledger Entry
                                </a>
                                <a href="{{ route('accounts.ledger') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.ledger') ? 'active' : '' }}">
                                    Settings / Ledger Heads
                                </a>
                                <a href="{{ route('accounts.bank.hold') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.bank.hold') ? 'active' : '' }}">
                                    Bank Hold Amount
                                </a>
                                <a href="{{ route('accounts.cashflow') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.cashflow') ? 'active' : '' }}">
                                    Cash Flow Entry
                                </a>
                                <a href="{{ route('accounts.creditcard') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.creditcard') ? 'active' : '' }}">
                                    Credit Card Utilization
                                </a>
                                <a href="{{ route('accounts.mobilebill') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.mobilebill') ? 'active' : '' }}">
                                    Mobile Bill Entry
                                </a>
                            </div>
                        </div>
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollRight">
                            <i class="mdi mdi-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="row g-3 mb-4">

    <div class="col-12 col-md-6 col-lg-3">
        <div class="card shadow-sm border-0 rounded-3 h-100">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-start">
                    <span class="text-black small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        Total Mobile &amp; Data Expense
                    </span>
                    <span class="d-inline-flex align-items-center justify-content-center rounded-3"
                          style="width: 40px; height: 40px; background: #e8eff7; color: #16659E;">
                        <i class="mdi mdi-cellphone" style="font-size: 22px;"></i>
                    </span>
                </div>
                <div class="d-flex align-items-center gap-1 mt-2">
                    <span class="fw-bold text-black fs-4">
                        $3,096
                    </span>
                </div>
                <span class="text-black text-nowrap small d-block mt-1">
                    Across 4 Active Records
                </span>
            </div>
        </div>
    </div>

    <div class="col-12 col-md-6 col-lg-3">
        <div class="card shadow-sm border-0 rounded-3 h-100">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-start">
                    <span class="text-muted small fw-semibold" style="font-size: 12px;">
                        Approved Reimbursements
                    </span>
                    <span class="d-inline-flex align-items-center justify-content-center rounded-3"
                          style="width: 40px; height: 40px; background: #e6f7ee; color: #0f7a4a;">
                        <i class="mdi mdi-check-circle-outline" style="font-size: 22px;"></i>
                    </span>
                </div>
                <div class="d-flex align-items-center gap-1 mt-2">
                    <span class="fw-bold fs-4" style="color: #0f7a4a;">
                        $2,597
                    </span>
                </div>
                <span class="text-muted small d-block mt-1">
                    3 claims cleared
                </span>
            </div>
        </div>
    </div>

    <!-- Pending Approval card -->
    <div class="col-12 col-md-6 col-lg-3">
        <div class="card shadow-sm border-0 rounded-3 h-100">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-start">
                    <span class="text-muted small fw-semibold" style="font-size: 12px;">
                        Pending Approval
                    </span>
                    <span class="d-inline-flex align-items-center justify-content-center rounded-3"
                          style="width: 40px; height: 40px; background: #fff4e5; color: #c97a1a;">
                        <i class="mdi mdi-clock-outline" style="font-size: 22px;"></i>
                    </span>
                </div>
                <div class="d-flex align-items-center gap-1 mt-2">
                    <span class="fw-bold fs-4" style="color: #c97a1a;">
                        $499
                    </span>
                </div>
                <span class="text-muted small d-block mt-1">
                    1 claims awaiting review
                </span>
            </div>
        </div>
    </div>

    <!-- Prepaid vs Postpaid card -->
    <div class="col-12 col-md-6 col-lg-3">
        <div class="card shadow-sm border-0 rounded-3 h-100">
            <div class="card-body p-3">
                <div class="d-flex justify-content-between align-items-start">
                    <span class="text-muted small fw-semibold" style="font-size: 12px;">
                        Prepaid vs Postpaid
                    </span>
                    <span class="d-inline-flex align-items-center justify-content-center rounded-3"
                          style="width: 40px; height: 40px; background: #e6f7ee; color: #0f7a4a;">
                        <i class="mdi mdi-currency-usd" style="font-size: 22px;"></i>
                    </span>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <span class="fw-bold text-black small">Prepaid: 2</span>
                    <span class="fw-bold text-black small">Postpaid: 2</span>
                </div>
                <div class="progress mt-2" style="height: 8px; border-radius: 6px;">
                    <div class="progress-bar" role="progressbar"
                         style="width: 50%; background: #16659E; border-radius: 6px 0 0 6px;"
                         aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                    <div class="progress-bar" role="progressbar"
                         style="width: 50%; background: #f5a623; border-radius: 0 6px 6px 0;"
                         aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
    </div>

</div>

    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-body px-3 pt-3 pb-2">
            <div class="mb-filter-row">

                <div class="input-group input-group-sm mb-filter-search">
                    <span class="input-group-text bg-white border-end-0">
                        <i class="mdi mdi-magnify text-muted"></i>
                    </span>
                    <input type="text"
                           class="form-control border-start-0"
                           id="mbRegisterSearch"
                           placeholder="Search user name, mobile #, ref...">
                </div>

                <select class="form-select form-select-sm mb-filter-operator" id="mbRegisterOperatorFilter">
                    <option value="">All Operators</option>
                    <option value="Airtel">Airtel</option>
                    <option value="Jio">Jio</option>
                    <option value="Vi">Vi</option>
                    <option value="Vodafone Idea">Vodafone Idea</option>
                </select>

                <select class="form-select form-select-sm mb-filter-connection" id="mbRegisterConnectionFilter">
                    <option value="">All Connection Types</option>
                    <option value="Postpaid">Postpaid</option>
                    <option value="Prepaid">Prepaid</option>
                </select>

                <select class="form-select form-select-sm mb-filter-status" id="mbRegisterStatusFilter">
                    <option value="">All Statuses</option>
                    <option value="Approved for Reimbursement">Approved for Reimbursement</option>
                    <option value="Pending Approval">Pending Approval</option>
                    <option value="Rejected">Rejected</option>
                </select>

                <button type="button"
                        class="btn btn-primary btn-sm d-flex align-items-center gap-1 mb-filter-btn"
                        id="mbQuickAddBtn"
                        data-bs-toggle="modal"
                        data-bs-target="#postMobileExpenseModal">
                    <i class="mdi mdi-plus"></i>
                    Quick Add Recharge Entry
                </button>

            </div>
        </div>

        <div class="table-responsive">
            <table class="table align-middle mb-0" id="mbRegisterTable">
                <thead style="background: #f8f9fc;">
                    <tr>
                        <th class="text-uppercase text-muted fw-bold border-0">
                            DATE &amp; REF #
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0">
                            USER &amp; MOBILE NUMBER
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0">
                            OPERATOR &amp; PLAN
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0">
                            PROJECT SITE
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0">
                            PAYMENT METHOD
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-end">
                            AMOUNT ($)
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center">
                            STATUS
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center">
                            ACTIONS
                        </th>
                    </tr>
                </thead>
                <tbody id="mbRegisterBody">

                    <tr class="border-bottom mb-register-row"
                        data-operator="Airtel"
                        data-connection="Postpaid"
                        data-status="Approved for Reimbursement"
                        data-user="Ramesh Kumar"
                        data-mobile="+91 98765 43210"
                        data-plan="45 GB High-Speed Data"
                        data-project="Coastal Expressway Bridge"
                        data-method="Corporate Credit Card"
                        data-amount="899"
                        data-date="2026-07-25"
                        data-bill-ref="BILL-AIR-99018"
                        data-expense-type="Postpaid Monthly Bill"
                        data-ledger="Communication & Internet"
                        data-subledger="Mobile Recharge & Data Card"
                        data-billing-month="July 2026"
                        data-txn-ref="TXN-882190">
                        <td>
                            <span class="fw-semibold text-dark d-block">2026-07-25</span>
                            <span class="text-muted">BILL-AIR-99018</span>
                        </td>
                        <td>
                            <span class="fw-semibold text-dark d-block">Ramesh Kumar (Site Engineer)</span>
                            <span class="text-muted">+91 98765 43210</span>
                        </td>
                        <td>
                            <div class="d-flex align-items-start gap-2">
                                <span class="badge rounded-pill px-2 py-1"
                                      style="background:#ffe9d6; color:#b45309; border:1px solid #f7c99a;">
                                    AIRTEL
                                </span>
                                <div>
                                    <span class="fw-semibold text-dark d-block">Airtel Corporate Postpaid</span>
                                    <span class="text-muted">45 GB High-Speed Data</span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="text-dark">Coastal Expressway Bridge</span>
                        </td>
                        <td>
                            <span class="badge rounded-pill px-3 py-2"
                                  style="background:#eef0f4; color:#495057;">
                                Corporate Credit Card
                            </span>
                        </td>
                        <td class="text-end">
                            <span class="fw-bold text-dark">$899</span>
                        </td>
                        <td class="text-center">
                            <span class="badge rounded-pill px-3 py-1"
                                  style="background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0;">
                                Approved for Reimbursement
                            </span>
                        </td>
                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-2">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-mb-register-btn"
                                        title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-mb-register-btn"
                                        title="Delete">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr class="border-bottom mb-register-row"
                        data-operator="Jio"
                        data-connection="Postpaid"
                        data-status="Approved for Reimbursement"
                        data-user="Priya Sharma"
                        data-mobile="+91 98123 45678"
                        data-plan="30 GB Data + Unlimited Calls"
                        data-project="Metro Line Extension - Phase 3"
                        data-method="Direct Bank Transfer"
                        data-amount="699"
                        data-date="2026-07-24"
                        data-bill-ref="BILL-JIO-33821"
                        data-expense-type="Postpaid Monthly Bill"
                        data-ledger="Communication & Internet"
                        data-subledger="Mobile Recharge & Data Card"
                        data-billing-month="July 2026"
                        data-txn-ref="TXN-882191">
                        <td>
                            <span class="fw-semibold text-dark d-block">2026-07-24</span>
                            <span class="text-muted">BILL-JIO-33821</span>
                        </td>
                        <td>
                            <span class="fw-semibold text-dark d-block">Priya Sharma (HR Lead)</span>
                            <span class="text-muted">+91 98123 45678</span>
                        </td>
                        <td>
                            <div class="d-flex align-items-start gap-2">
                                <span class="badge rounded-pill px-2 py-1"
                                      style="background:#e3edff; color:#1e4d99; border:1px solid #b9cffb;">
                                    JIO
                                </span>
                                <div>
                                    <span class="fw-semibold text-dark d-block">Jio Business Plan</span>
                                    <span class="text-muted">30 GB Data + Unlimited Calls</span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="text-dark">Metro Line Extension - Phase 3</span>
                        </td>
                        <td>
                            <span class="badge rounded-pill px-3 py-2"
                                  style="background:#eef0f4; color:#495057;">
                                Direct Bank Transfer
                            </span>
                        </td>
                        <td class="text-end">
                            <span class="fw-bold text-dark">$699</span>
                        </td>
                        <td class="text-center">
                            <span class="badge rounded-pill px-3 py-1"
                                  style="background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0;">
                                Approved for Reimbursement
                            </span>
                        </td>
                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-2">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-mb-register-btn"
                                        title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-mb-register-btn"
                                        title="Delete">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr class="border-bottom mb-register-row"
                        data-operator="Vodafone Idea"
                        data-connection="Postpaid"
                        data-status="Pending Approval"
                        data-user="Karthik V"
                        data-mobile="+91 99400 11223"
                        data-plan="2GB/Day + Night Unlimited"
                        data-project="Skyline Premium Residences"
                        data-method="Site Petty Cash"
                        data-amount="499"
                        data-date="2026-07-22"
                        data-bill-ref="RCHG-VI-11829"
                        data-expense-type="Postpaid Monthly Bill"
                        data-ledger="Communication & Internet"
                        data-subledger="Mobile Recharge & Data Card"
                        data-billing-month="July 2026"
                        data-txn-ref="TXN-882192">
                        <td>
                            <span class="fw-semibold text-dark d-block">2026-07-22</span>
                            <span class="text-muted">RCHG-VI-11829</span>
                        </td>
                        <td>
                            <span class="fw-semibold text-dark d-block">Karthik V (Store Manager)</span>
                            <span class="text-muted">+91 99400 11223</span>
                        </td>
                        <td>
                            <div class="d-flex align-items-start gap-2">
                                <span class="badge rounded-pill px-2 py-1"
                                      style="background:#f4e3ff; color:#7a1fa6; border:1px solid #d8b6f0;">
                                    VI
                                </span>
                                <div>
                                    <span class="fw-semibold text-dark d-block">Vi Corporate CUG</span>
                                    <span class="text-muted">2GB/Day + Night Unlimited</span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="text-dark">Skyline Premium Residences</span>
                        </td>
                        <td>
                            <span class="badge rounded-pill px-3 py-2"
                                  style="background:#eef0f4; color:#495057;">
                                Site Petty Cash
                            </span>
                        </td>
                        <td class="text-end">
                            <span class="fw-bold text-dark">$499</span>
                        </td>
                        <td class="text-center">
                            <span class="badge rounded-pill px-3 py-1"
                                  style="background:#fff4d6; color:#a06b00; border:1px solid #f5d78a;">
                                Pending Approval
                            </span>
                        </td>
                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-2">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-mb-register-btn"
                                        title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-mb-register-btn"
                                        title="Delete">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr class="mb-register-row"
                        data-operator="Airtel"
                        data-connection="Prepaid"
                        data-status="Approved for Reimbursement"
                        data-user="Suresh Raina"
                        data-mobile="+91 97112 88390"
                        data-plan="2.5GB/Day 5G Data"
                        data-project="Coastal Expressway Bridge"
                        data-method="Site Petty Cash"
                        data-amount="999"
                        data-date="2026-07-20"
                        data-bill-ref="RCHG-AIR-88201"
                        data-expense-type="Prepaid Data Pack"
                        data-ledger="Communication & Internet"
                        data-subledger="Mobile Recharge & Data Card"
                        data-billing-month="July 2026"
                        data-txn-ref="TXN-882193">
                        <td>
                            <span class="fw-semibold text-dark d-block">2026-07-20</span>
                            <span class="text-muted">RCHG-AIR-88201</span>
                        </td>
                        <td>
                            <span class="fw-semibold text-dark d-block">Suresh Raina (Safety Officer)</span>
                            <span class="text-muted">+91 97112 88390</span>
                        </td>
                        <td>
                            <div class="d-flex align-items-start gap-2">
                                <span class="badge rounded-pill px-2 py-1"
                                      style="background:#ffe9d6; color:#b45309; border:1px solid #f7c99a;">
                                    AIRTEL
                                </span>
                                <div>
                                    <span class="fw-semibold text-dark d-block">Airtel 84 Days Field Pack</span>
                                    <span class="text-muted">2.5GB/Day 5G Data</span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="text-dark">Coastal Expressway Bridge</span>
                        </td>
                        <td>
                            <span class="badge rounded-pill px-3 py-2"
                                  style="background:#eef0f4; color:#495057;">
                                Site Petty Cash
                            </span>
                        </td>
                        <td class="text-end">
                            <span class="fw-bold text-dark">$999</span>
                        </td>
                        <td class="text-center">
                            <span class="badge rounded-pill px-3 py-1"
                                  style="background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0;">
                                Approved for Reimbursement
                            </span>
                        </td>
                        <td class="text-center">
                            <div class="d-inline-flex align-items-center gap-2">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-mb-register-btn"
                                        title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-mb-register-btn"
                                        title="Delete">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>

        <div class="card-footer bg-white border-top d-flex justify-content-end align-items-center px-4 py-2">
            <span class="text-muted small fw-semibold me-3">
                Total Filtered Mobile Expenses:
            </span>
            <span class="text-dark fw-bold" style="font-size: 15px;">$3,096</span>
        </div>
    </div>

</div>

{{-- Modal: Post Mobile Expense Entry --}}
<div class="modal fade" id="postMobileExpenseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-cellphone text-primary" style="font-size: 20px;"></i>
                    <h5 class="modal-title fw-bold mb-0" id="postMobileExpenseTitle" style="font-size: 15px;">
                        Post Mobile Expense Entry
                    </h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body pt-3">
                <form id="postMobileExpenseForm">

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Employee / User Name &amp; Role <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="mbEmployee"
                                   placeholder="e.g. Ramesh Kumar (Site Engineer)">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Mobile Number <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="mbMobile"
                                   placeholder="+91 98765 43210">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Telecom Operator <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="mbOperator">
                                <option value="Airtel" selected>Airtel Corporate</option>
                                <option value="Jio">Jio Business</option>
                                <option value="Vi">Vi Corporate</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Expense Entry Type <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="mbExpenseType">
                                <option value="Postpaid Monthly Bill" selected>Postpaid Monthly Bill</option>
                                <option value="Prepaid Data Pack">Prepaid Data Pack</option>
                                <option value="Recharge Top-up">Recharge Top-up</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Recharge Plan / Data Pack Details
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="mbPlan"
                                   placeholder="e.g. 45 GB High-Speed Data">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Project Site / Cost Center <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="mbProject">
                                <option value="Chennai Metro Phase 2 - Corridor 4" selected>Chennai Metro Phase 2 - Corridor 4</option>
                                <option value="Coastal Expressway Bridge">Coastal Expressway Bridge</option>
                                <option value="Metro Line Extension - Phase 3">Metro Line Extension - Phase 3</option>
                                <option value="Skyline Premium Residences">Skyline Premium Residences</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Ledger Head <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="mbLedger"
                                   value="Communication & Internet">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Sub-Ledger Head <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="mbSubLedger"
                                   value="Mobile Recharge & Data Card">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Payment Method / Source <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="mbPaymentMethod">
                                <option value="Site Petty Cash" selected>Site Petty Cash / Imprest</option>
                                <option value="Corporate Credit Card">Corporate Credit Card</option>
                                <option value="Direct Bank Transfer">Direct Bank Transfer</option>
                                <option value="Reimbursement">Reimbursement</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">
                                Recharge / Bill Date <span class="text-danger">*</span>
                            </label>
                            <input type="date"
                                   class="form-control form-control-sm"
                                   id="mbBillDate"
                                   value="2026-09-17">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">
                                Billing Month / Cycle
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="mbBillingMonth"
                                   placeholder="July 2026">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">
                                Txn Ref / Bill Receipt No
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="mbTxnRef"
                                   placeholder="e.g. TXN-882190">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">
                                Recharge Amount ($) <span class="text-danger">*</span>
                            </label>
                            <input type="number"
                                   class="form-control form-control-sm"
                                   id="mbAmount"
                                   value="899"
                                   step="1">
                        </div>
                    </div>

                </form>
            </div>

            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm px-4" id="mbClearBtn">
                    Clear Form
                </button>
                <button type="button"
                        class="btn btn-primary btn-sm px-4 d-flex align-items-center gap-1"
                        id="mbSubmitBtn">
                    <i class="mdi mdi-plus"></i>
                    Post Mobile Expense Entry
                </button>
            </div>

        </div>
    </div>
</div>

<style>

    .settings-tabs-wrapper {
        width: 900px;
        max-width: 100%;
        min-width: 0;
        flex: 1 1 900px;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 100%;
        min-width: 0;
    }

    .settings-tabs-track {
        display: flex;
        align-items: center;
        gap: .5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 4px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tabs-track .settings-tab-pill,
    a.settings-tab-pill {
        white-space: nowrap;
        padding: .5rem 1.1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: .82rem;
        font-weight: 600;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .settings-tabs-track .settings-tab-pill:hover,
    a.settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
        text-decoration: none;
    }

    .settings-tabs-track .settings-tab-pill.active,
    a.settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tabs-track .settings-tab-pill.active:hover,
    a.settings-tab-pill.active:hover {
        background: #124f7c;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
        cursor: pointer;
        transition: all .15s ease;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }

    /* ---------- Mobile filter row (single-line) ---------- */
    .mb-filter-row {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: nowrap;
        width: 100%;
    }

    .mb-filter-search     { flex: 1 1 auto; min-width: 220px; max-width: 400px; }
    .mb-filter-operator   { flex: 0 0 160px; }
    .mb-filter-connection { flex: 0 0 180px; }
    .mb-filter-status     { flex: 0 0 200px; }

    .mb-filter-btn {
        flex-shrink: 0;
        margin-left: auto;
        white-space: nowrap;
    }

    @media (max-width: 1200px) {
        .mb-filter-search     { min-width: 180px; max-width: 280px; }
        .mb-filter-operator   { flex: 0 0 140px; }
        .mb-filter-connection { flex: 0 0 160px; }
        .mb-filter-status     { flex: 0 0 180px; }
    }
    @media (max-width: 992px) {
        .mb-filter-row        { flex-wrap: wrap; }
        .mb-filter-search     { flex: 1 1 100%; max-width: 100%; min-width: 0; }
        .mb-filter-operator,
        .mb-filter-connection,
        .mb-filter-status     { flex: 1 1 160px; }
        .mb-filter-btn        { flex: 1 1 100%; justify-content: center; margin-left: 0; }
    }

    /* ---------- Compact mobile register table ---------- */
    #mbRegisterTable {
        font-size: 12.5px;
        table-layout: auto;
        width: 100%;
    }

    #mbRegisterTable > :not(caption) > * > * {
        border-bottom-width: 1px;
        border-color: #eef0f4;
    }

    #mbRegisterTable thead th {
        border-bottom: 1px solid #eef0f4 !important;
        font-size: 10px !important;
        letter-spacing: .05em;
        padding: 10px 12px !important;
        white-space: nowrap;
        background: #f8f9fc;
    }

    #mbRegisterTable tbody td {
        padding: 14px 12px !important;
        vertical-align: middle !important;
        font-size: 12.5px;
    }

    #mbRegisterTable tbody td:first-child {
        padding-left: 24px !important;
    }

    #mbRegisterTable tbody td:last-child {
        padding-right: 24px !important;
    }

    #mbRegisterTable .badge {
        font-size: 11px !important;
        font-weight: 600 !important;
    }

    #mbRegisterTable .text-muted {
        font-size: 11.5px;
    }

    #mbRegisterTable tbody td .d-flex.gap-2 {
        gap: 8px !important;
    }

    #mbRegisterTable tbody td .fw-semibold.d-block {
        font-size: 13px;
        margin-bottom: 2px;
    }

    #mbRegisterTable tbody td .d-inline-flex.align-items-center.gap-2 {
        gap: 6px !important;
    }

    #mbRegisterTable tbody td .btn-link {
        padding: 0 !important;
        font-size: 17px !important;
        line-height: 1 !important;
    }

    .form-select-sm,
    .input-group-sm .form-control,
    .input-group-sm .form-select {
        font-size: 12px;
    }

    .form-select-sm {
        min-height: 38px;
    }

    .form-control-sm {
        min-height: 38px;
    }

    /* ---------- Post Mobile Expense Modal ---------- */
    #postMobileExpenseModal .modal-dialog {
        max-width: 1000px;
        width: calc(100% - 40px);
        margin: 1.75rem auto;
    }

    #postMobileExpenseModal .modal-dialog-centered {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: calc(100vh - 3.5rem);
        margin: 1.75rem auto;
    }

    #postMobileExpenseModal .modal-content {
        border-radius: 12px;
        min-height: 480px;
        max-height: calc(100vh - 3.5rem);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        width: 100%;
    }

    #postMobileExpenseModal .modal-header {
        padding: 22px 28px 10px 28px;
        flex-shrink: 0;
    }

    #postMobileExpenseModal .modal-body {
        padding: 18px 28px 20px 28px;
        overflow-y: auto;
        overflow-x: hidden;
        flex-grow: 1;
    }

    #postMobileExpenseModal .modal-footer {
        padding: 14px 28px 22px 28px;
        flex-shrink: 0;
    }

    #postMobileExpenseModal .form-label {
        font-size: 12.5px;
        color: #1a2332;
        margin-bottom: 6px;
        white-space: nowrap;
        overflow: visible;
    }

    #postMobileExpenseModal .form-control-sm,
    #postMobileExpenseModal .form-select-sm {
        font-size: 12.5px;
        padding: 8px 12px;
        border-radius: 7px;
        border: 1px solid #d0d5dd;
        min-height: 40px;
        width: 100%;
    }

    #postMobileExpenseModal .form-control-sm:focus,
    #postMobileExpenseModal .form-select-sm:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    @media (max-width: 1200px) {
        #postMobileExpenseModal .modal-dialog {
            max-width: calc(100% - 32px);
        }
    }

    .card {
        border: 1px solid #eef0f4 !important;
    }

    .text-primary {
        color: #16659E !important;
    }

    .bg-primary {
        background-color: #16659E !important;
    }

    .btn-primary {
        background-color: #16659E !important;
        border-color: #16659E !important;
    }

    .btn-primary:hover {
        background-color: #124f7c !important;
        border-color: #124f7c !important;
    }

    .btn-light {
        background-color: #f1f3f5;
        border-color: #f1f3f5;
        color: #495057;
    }

    .btn-light:hover {
        background-color: #e2e6ea;
        border-color: #e2e6ea;
        color: #212529;
    }

    .btn-link.text-primary:hover {
        color: #124f7c !important;
    }

    @media (max-width: 992px) {
        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 900px;
        }
        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }
    }

    @media (max-width: 768px) {
        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 100%;
        }
        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }
    }

</style>

<script>

document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Tabs Scroll ---------- */
    const tabsTrack = document.getElementById('ledgerTabsTrack');
    const scrollLeftBtn = document.getElementById('ledgerTabScrollLeft');
    const scrollRightBtn = document.getElementById('ledgerTabScrollRight');

    if (scrollLeftBtn && tabsTrack) {
        scrollLeftBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (scrollRightBtn && tabsTrack) {
        scrollRightBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

    /* ---------- Modal References ---------- */
    const postModalEl      = document.getElementById('postMobileExpenseModal');
    const postModalTitle   = document.getElementById('postMobileExpenseTitle');
    const postModalSubmit  = document.getElementById('mbSubmitBtn');
    const postModalClear   = document.getElementById('mbClearBtn');

    const mbEmployee       = document.getElementById('mbEmployee');
    const mbMobile         = document.getElementById('mbMobile');
    const mbOperator       = document.getElementById('mbOperator');
    const mbExpenseType    = document.getElementById('mbExpenseType');
    const mbPlan           = document.getElementById('mbPlan');
    const mbProject        = document.getElementById('mbProject');
    const mbLedger         = document.getElementById('mbLedger');
    const mbSubLedger      = document.getElementById('mbSubLedger');
    const mbPaymentMethod  = document.getElementById('mbPaymentMethod');
    const mbBillDate       = document.getElementById('mbBillDate');
    const mbBillingMonth   = document.getElementById('mbBillingMonth');
    const mbTxnRef         = document.getElementById('mbTxnRef');
    const mbAmount         = document.getElementById('mbAmount');

    let editingRow = null;

    function resetModalToCreate() {
        editingRow = null;

        if (mbEmployee)      mbEmployee.value      = '';
        if (mbMobile)        mbMobile.value        = '';
        if (mbOperator)      mbOperator.selectedIndex = 0;
        if (mbExpenseType)   mbExpenseType.selectedIndex = 0;
        if (mbPlan)          mbPlan.value          = '';
        if (mbProject)       mbProject.selectedIndex = 0;
        if (mbLedger)        mbLedger.value        = 'Communication & Internet';
        if (mbSubLedger)     mbSubLedger.value     = 'Mobile Recharge & Data Card';
        if (mbPaymentMethod) mbPaymentMethod.selectedIndex = 0;
        if (mbBillDate)      mbBillDate.value      = '2026-09-17';
        if (mbBillingMonth)  mbBillingMonth.value  = '';
        if (mbTxnRef)        mbTxnRef.value        = '';
        if (mbAmount)        mbAmount.value        = 899;

        if (postModalTitle)  postModalTitle.textContent = 'Post Mobile Expense Entry';
        if (postModalSubmit) postModalSubmit.innerHTML  =
            '<i class="mdi mdi-plus"></i> Post Mobile Expense Entry';
    }

    function enterModalEditMode(row) {
        const data = row.dataset;
        editingRow = row;

        if (mbEmployee)      mbEmployee.value      = data.user        || '';
        if (mbMobile)        mbMobile.value        = data.mobile      || '';
        if (mbOperator)      mbOperator.value      = data.operator    || '';
        if (mbExpenseType)   mbExpenseType.value   = data.expenseType || 'Postpaid Monthly Bill';
        if (mbPlan)          mbPlan.value          = data.plan        || '';
        if (mbProject)       mbProject.value       = data.project     || '';
        if (mbLedger)        mbLedger.value        = data.ledger      || 'Communication & Internet';
        if (mbSubLedger)     mbSubLedger.value     = data.subledger   || 'Mobile Recharge & Data Card';
        if (mbPaymentMethod) mbPaymentMethod.value = data.method      || '';
        if (mbBillDate)      mbBillDate.value      = data.date        || '';
        if (mbBillingMonth)  mbBillingMonth.value  = data.billingMonth || '';
        if (mbTxnRef)        mbTxnRef.value        = data.txnRef      || '';
        if (mbAmount)        mbAmount.value        = data.amount      || 0;

        if (postModalTitle)  postModalTitle.textContent = 'Update Mobile Expense Entry';
        if (postModalSubmit) postModalSubmit.innerHTML  =
            '<i class="mdi mdi-check"></i> Update Mobile Expense Entry';
    }

    /* ---------- Quick Add → open modal in Create mode ---------- */
    const quickAddBtn = document.getElementById('mbQuickAddBtn');

    if (quickAddBtn && postModalEl) {
        quickAddBtn.addEventListener('click', function () {
            resetModalToCreate();
            bootstrap.Modal.getOrCreateInstance(postModalEl).show();
        });
    }

    /* ---------- Edit icon → open modal in Edit mode ---------- */
    document.querySelectorAll('.edit-mb-register-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();

            const row = btn.closest('.mb-register-row');
            if (!row) return;

            resetModalToCreate();
            enterModalEditMode(row);

            if (postModalEl) {
                bootstrap.Modal.getOrCreateInstance(postModalEl).show();
            }
        });
    });

    /* ---------- Delete icon → remove row (with confirmation) ---------- */
    function bindMobileRowDelete(row) {
        const deleteBtn = row.querySelector('.delete-mb-register-btn');
        if (!deleteBtn || deleteBtn.dataset.bound === '1') return;
        deleteBtn.dataset.bound = '1';

        deleteBtn.addEventListener('click', function (e) {
            e.preventDefault();

            const userName = row.dataset.user    || '';
            const mobile   = row.dataset.mobile  || '';
            const billRef  = row.dataset.billRef || '';

            const label = userName
                ? (userName + (mobile ? ' (' + mobile + ')' : ''))
                : (billRef || 'this entry');

            if (confirm('Delete mobile expense for ' + label + '?')) {
                row.remove();
                applyRegisterFilter();
            }
        });
    }

    document.querySelectorAll('#mbRegisterBody .mb-register-row').forEach(bindMobileRowDelete);

    /* ---------- Submit ---------- */
    if (postModalSubmit && postModalEl) {
        postModalSubmit.addEventListener('click', function () {
            if (editingRow) {
                console.log('Updating row:', editingRow.dataset);
            } else {
                console.log('Posting new mobile expense...');
            }
            bootstrap.Modal.getOrCreateInstance(postModalEl).hide();
        });
    }

    /* ---------- Clear Form ---------- */
    if (postModalClear) {
        postModalClear.addEventListener('click', function () {
            resetModalToCreate();
            const form = document.getElementById('postMobileExpenseForm');
            if (form) form.reset();
        });
    }

    /* ---------- Register Filters ---------- */
    const registerSearch           = document.getElementById('mbRegisterSearch');
    const registerOperatorFilter   = document.getElementById('mbRegisterOperatorFilter');
    const registerConnectionFilter = document.getElementById('mbRegisterConnectionFilter');
    const registerStatusFilter     = document.getElementById('mbRegisterStatusFilter');
    const registerRows             = document.querySelectorAll('#mbRegisterBody .mb-register-row');

    function applyRegisterFilter() {
        const search     = (registerSearch ? registerSearch.value : '').toLowerCase().trim();
        const operator   = (registerOperatorFilter ? registerOperatorFilter.value : '').toLowerCase().trim();
        const connection = (registerConnectionFilter ? registerConnectionFilter.value : '').toLowerCase().trim();
        const status     = (registerStatusFilter ? registerStatusFilter.value : '').toLowerCase().trim();

        registerRows.forEach(function (row) {
            const rowOperator   = (row.getAttribute('data-operator') || '').toLowerCase();
            const rowConnection = (row.getAttribute('data-connection') || '').toLowerCase();
            const rowStatus     = (row.getAttribute('data-status') || '').toLowerCase();
            const rowText       = row.innerText.toLowerCase();

            const match =
                (search === '' || rowText.includes(search)) &&
                (operator === '' || rowOperator.includes(operator)) &&
                (connection === '' || rowConnection.includes(connection)) &&
                (status === '' || rowStatus.includes(status));

            row.style.display = match ? '' : 'none';
        });
    }

    if (registerSearch)           registerSearch.addEventListener('input', applyRegisterFilter);
    if (registerOperatorFilter)   registerOperatorFilter.addEventListener('change', applyRegisterFilter);
    if (registerConnectionFilter) registerConnectionFilter.addEventListener('change', applyRegisterFilter);
    if (registerStatusFilter)     registerStatusFilter.addEventListener('change', applyRegisterFilter);

});

</script>

@endsection
