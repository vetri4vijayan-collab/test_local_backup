@extends('layouts.layoutMaster')

@section('title', 'Bank Ledger Entry')

@section('content')

<div class="container-fluid">

    {{-- Header with Tabs --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body p-3 p-md-4">
            <div class="d-flex justify-content-between align-items-center flex-nowrap gap-3">
                <div class="flex-shrink-0" style="min-width: 0;">
                    <h5 class="fw-bold mb-1">Ledger Head & Sub Ledger Management</h5>
                    <p class="text-muted small mb-0">
                       Bank Entry and Cash Flow will immediately adapt to these head structures.
                    </p>
                </div>
                <div class="settings-tabs-wrapper">
                    <div class="d-flex align-items-center gap-2">
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollLeft">
                            <i class="mdi mdi-chevron-left"></i>
                        </button>
                        <div class="settings-tabs-scroller">
                            <div class="settings-tabs-track" id="ledgerTabsTrack">
                                <a href="{{ route('accounts.banking') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.banking') ? 'active' : '' }}">
                                    Bank Ledger Entry
                                </a>
                                <a href="{{ route('accounts.ledger') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.ledger') ? 'active' : '' }}">
                                    Settings / Ledger Heads
                                </a>

                                  <a href="{{ route('accounts.bank.hold') }}"
                                  class="settings-tab-pill {{ request()->routeIs('accounts.bank.hold') ? 'active' : '' }}">
                                          Bank Hold Amount
                                 </a>

                                  <a href="{{ route('accounts.cashflow') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.cashflow') ? 'active' : '' }}">
                                    Cash Flow Entry
                                </a>

                                 <a href="{{ route('accounts.creditcard') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.creditcard') ? 'active' : '' }}">
                                    Credit Card Utilization
                                </a>

                                  <a href="{{ route('accounts.mobilebill') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.mobilebill') ? 'active' : '' }}">
                                    Mobile Bill Entry
                                </a>

                            </div>
                        </div>
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollRight">
                            <i class="mdi mdi-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- KPI Cards --}}
    <div class="row g-3 mb-4">
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="text-muted small fw-semibold text-uppercase" style="font-size: 10px; letter-spacing: .05em;">
                        Total Ledger Heads
                    </span>
                    <div class="d-flex align-items-center gap-1 mt-2">
                        <i class="mdi mdi-trending-up text-success fs-5"></i>
                        <span class="fw-bold text-success fs-4">5 Heads</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="text-muted small fw-semibold text-uppercase" style="font-size: 10px; letter-spacing: .05em;">
                        Active Sub-Ledgers
                    </span>
                    <div class="d-flex align-items-center gap-1 mt-2">
                        <i class="mdi mdi-trending-down text-danger fs-5"></i>
                        <span class="fw-bold text-danger fs-4">16 Sub-Heads</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="text-muted small fw-semibold text-uppercase" style="font-size: 10px; letter-spacing: .05em;">
                        Expense vs Income Heads
                    </span>
                    <div class="d-flex align-items-center gap-1 mt-2">
                        <span class="fw-bold text-primary fs-4">4 Exp / 1 Inc</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="text-muted small fw-semibold text-uppercase" style="font-size: 10px; letter-spacing: .05em;">
                        Bank Master Accounts
                    </span>
                    <div class="d-flex align-items-baseline gap-1 mt-2">
                        <span class="fw-bold fs-4">4 Accounts</span>

                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Filter Section --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body px-4 py-3">
            <div class="d-flex flex-wrap align-items-center gap-3">
                {{-- Filter Category --}}
                <div class="d-flex align-items-center gap-2">
                    <span class="text-muted small fw-semibold me-1">
                        <i class="mdi mdi-filter-variant me-1"></i>Filter Category
                    </span>
                    <div class="d-flex gap-1 flex-wrap" id="categoryFilterGroup">
                        <button type="button" class="btn btn-primary btn-sm rounded-pill px-3 category-filter-btn" data-category="" style="font-size: 11px;">All Categories</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3 category-filter-btn" data-category="expense" style="font-size: 11px;">Expense</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3 category-filter-btn" data-category="income" style="font-size: 11px;">Income</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3 category-filter-btn" data-category="asset" style="font-size: 11px;">Asset</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3 category-filter-btn" data-category="liability" style="font-size: 11px;">Liability</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3 category-filter-btn" data-category="equity" style="font-size: 11px;">Equity</button>
                    </div>
                </div>

                {{-- Search + Action Buttons (single horizontal line) --}}
                <div class="ms-auto d-flex align-items-center gap-2 flex-nowrap">
                    <div style="min-width: 250px;">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text bg-white border-end-0">
                                <i class="mdi mdi-magnify text-muted"></i>
                            </span>
                            <input type="text" class="form-control border-start-0" id="ledgerSearch" placeholder="Search ledger head or sub-head...">
                        </div>
                    </div>

                    <button type="button"
                            class="btn btn-primary btn-sm d-flex align-items-center gap-1 flex-shrink-0"
                            data-bs-toggle="modal"
                            data-bs-target="#createPrimaryLedgerModal"
                            style="font-size: 11.5px; white-space: nowrap;">
                        <i class="mdi mdi-plus"></i> New Ledger Head
                    </button>

                    <button type="button"
                            class="btn btn-success btn-sm d-flex align-items-center gap-1 flex-shrink-0"
                            data-bs-toggle="modal"
                            data-bs-target="#createSubLedgerModal"
                            style="font-size: 11.5px; white-space: nowrap;">
                        <i class="mdi mdi-plus"></i> New Sub Ledger Head
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- Ledger Cards Grid --}}
    <div class="row g-4" id="ledgerCardsGrid">

      {{-- Card 1: Subcontractor RA Payout --}}
<div class="col-12 col-lg-6 ledger-card-item" data-category="expense">
    <div class="card shadow-sm border-0 rounded-3 h-100">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <span class="badge bg-danger-subtle text-danger fw-bold rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">Expense</span>
                    <span class="badge bg-light text-muted border rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">EXP-SUB-101</span>
                </div>
                <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
            </div>
            <h6 class="fw-bold mb-1">Subcontractor RA Payout</h6>
            <p class="text-muted small mb-3">Payments against subcontracted work and RA bills to subcontractors</p>

            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase text-muted fw-bold" style="font-size: 10px; letter-spacing: .05em;">Sub-Ledger Accounts</span>
                <a href="#" class="text-primary small fw-semibold text-decoration-none" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#createSubLedgerModal"><i class="mdi mdi-plus-circle-outline"></i> Add Sub-Head</a>
            </div>

            <div class="d-flex flex-column gap-2 ledger-subhead-scroll">
                <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                    <div class="d-flex align-items-center gap-2">
                        <i class="mdi mdi-cog-outline text-muted"></i>
                        <div>
                            <span class="fw-semibold d-block" style="font-size: 12px;">MEP & Electrical Piping</span>
                            <span class="text-muted" style="font-size: 10px;">SUB-MEP-01 • Mechanical & Electrical Installation</span>
                        </div>
                    </div>
              <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                </div>
                <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                    <div class="d-flex align-items-center gap-2">
                        <i class="mdi mdi-pillar text-muted"></i>
                        <div>
                            <span class="fw-semibold d-block" style="font-size: 12px;">Bored Piling & Foundation Works</span>
                            <span class="text-muted" style="font-size: 10px;">SUB-PILE-01 • Piling rigs & pile casting</span>
                        </div>
                    </div>
                  <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                </div>
                <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                    <div class="d-flex align-items-center gap-2">
                        <i class="mdi mdi-hammer-screwdriver text-muted"></i>
                        <div>
                            <span class="fw-semibold d-block" style="font-size: 12px;">RC Frame & Formwork Labor</span>
                            <span class="text-muted" style="font-size: 10px;">SUB-RCC-01 • Shuttering & Concrete Labor</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                </div>

                <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                    <div class="d-flex align-items-center gap-2">
                        <i class="mdi mdi-format-paint text-muted"></i>
                        <div>
                            <span class="fw-semibold d-block" style="font-size: 12px;">Finishing & Painting Works</span>
                            <span class="text-muted" style="font-size: 10px;">SUB-FIN-01 • Plastering, putty & final paint</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                   <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
                  <button type="button"
                   class="btn btn-link p-0 text-muted subhead-delete-btn"
                    title="Delete"
                    style="font-size: 16px; line-height: 1;">
                   <i class="mdi mdi-delete-outline"></i>
               </button>
                </div>
                 </div>

                {{-- NEW: HVAC & Ducting Installation --}}
                <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                    <div class="d-flex align-items-center gap-2">
                        <i class="mdi mdi-air-conditioner text-muted"></i>
                        <div>
                            <span class="fw-semibold d-block" style="font-size: 12px;">HVAC & Ducting Installation</span>
                            <span class="text-muted" style="font-size: 10px;">SUB-HVAC-01 • Chiller, AHU & duct work</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                </div>
            </div>

            <div class="d-flex justify-content-between mt-3 pt-2 border-top">
                <span class="text-muted" style="font-size: 10px;">Ref ID: LH-101</span>
                <span class="text-muted" style="font-size: 10px;">Mapped to Banking & Cash Flow</span>
            </div>
        </div>
    </div>
</div>

        {{-- Card 2: Client RA Bill Collection --}}
        <div class="col-12 col-lg-6 ledger-card-item" data-category="income">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <span class="badge bg-success-subtle text-success fw-bold rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">Income</span>
                            <span class="badge bg-light text-muted border rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">INC-CLI-101</span>
                        </div>
                        <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
                    </div>
                    <h6 class="fw-bold mb-1">Client RA Bill Collection</h6>
                    <p class="text-muted small mb-3">Inflows received from employer against certified bills</p>

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-uppercase text-muted fw-bold" style="font-size: 10px; letter-spacing: .05em;">Sub-Ledger Accounts</span>
                        <a href="#" class="text-primary small fw-semibold text-decoration-none" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#createSubLedgerModal"><i class="mdi mdi-plus-circle-outline"></i> Add Sub-Head</a>
                    </div>

                    <div class="d-flex flex-column gap-2 ledger-subhead-scroll">
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-file-document-outline text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Interim RA Bill Collection</span>
                                    <span class="text-muted" style="font-size: 10px;">CLI-INT-01 • Monthly billing inflows</span>
                                </div>
                            </div>
                           <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-cash-fast text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Mobilisation Advance Recovery Inflow</span>
                                    <span class="text-muted" style="font-size: 10px;">CLI-ADV-01 • Mobilisation grant receipts</span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-trophy-outline text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Milestone Early Completion Bonus</span>
                                    <span class="text-muted" style="font-size: 10px;">CLI-BON-01 • Incentive collection bonus</span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-3 pt-2 border-top">
                        <span class="text-muted" style="font-size: 10px;">Ref ID: LH-102</span>
                        <span class="text-muted" style="font-size: 10px;">Mapped to Banking & Cash Flow</span>
                    </div>
                </div>
            </div>
        </div>

        {{-- Card 3: Vendor Material Supply --}}
        <div class="col-12 col-lg-6 ledger-card-item" data-category="expense">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <span class="badge bg-danger-subtle text-danger fw-bold rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">Expense</span>
                            <span class="badge bg-light text-muted border rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">EXP-MAT-101</span>
                        </div>
                        <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
                    </div>
                    <h6 class="fw-bold mb-1">Vendor Material Supply</h6>
                    <p class="text-muted small mb-3">Procurement of raw materials, cement, steel</p>

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-uppercase text-muted fw-bold" style="font-size: 10px; letter-spacing: .05em;">Sub-Ledger Accounts</span>
                        <a href="#" class="text-primary small fw-semibold text-decoration-none" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#createSubLedgerModal"><i class="mdi mdi-plus-circle-outline"></i> Add Sub-Head</a>
                    </div>

                    <div class="d-flex flex-column gap-2 ledger-subhead-scroll">
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-rebar text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">TMT Rebar & Fe550D Steel Batch</span>
                                    <span class="text-muted" style="font-size: 10px;">MAT-STL-01 • Reinforcement steel</span>
                                </div>
                            </div>
                           <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-cube-outline text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Ready Mix Concrete (M15/M40)</span>
                                    <span class="text-muted" style="font-size: 10px;">MAT-RMC-01 • Batching plant RMC supplies</span>
                                </div>
                            </div>
                          <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-grain text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Crushed M-Sand & Coarse Aggregates</span>
                                    <span class="text-muted" style="font-size: 10px;">MAT-SAND-01 • Manufactured sand & gravel</span>
                                </div>
                            </div>
                          <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-3 pt-2 border-top">
                        <span class="text-muted" style="font-size: 10px;">Ref ID: LH-103</span>
                        <span class="text-muted" style="font-size: 10px;">Mapped to Banking & Cash Flow</span>
                    </div>
                </div>
            </div>
        </div>

        {{-- Card 4: Site Petty Cash Advance --}}
        <div class="col-12 col-lg-6 ledger-card-item" data-category="expense">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <span class="badge bg-danger-subtle text-danger fw-bold rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">Expense</span>
                            <span class="badge bg-light text-muted border rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">EXP-PET-101</span>
                        </div>
                        <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
                    </div>
                    <h6 class="fw-bold mb-1">Site Petty Cash Advance</h6>
                    <p class="text-muted small mb-3">Site level imprest cash transfers</p>

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-uppercase text-muted fw-bold" style="font-size: 10px; letter-spacing: .05em;">Sub-Ledger Accounts</span>
                        <a href="#" class="text-primary small fw-semibold text-decoration-none" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#createSubLedgerModal"><i class="mdi mdi-plus-circle-outline"></i> Add Sub-Head</a>
                    </div>

                    <div class="d-flex flex-column gap-2 ledger-subhead-scroll">
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-fuel text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Emergency Diesel & Machinery Fuel</span>
                                    <span class="text-muted" style="font-size: 10px;">CAS-FUEL-01 • Diesel for excavator & DG sets</span>
                                </div>
                            </div>
                           <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-water-outline text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Labor Camp Water & Refreshment</span>
                                    <span class="text-muted" style="font-size: 10px;">CAS-REFRESH-01 • Water tankers & worker provisions</span>
                                </div>
                            </div>
                           <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-shield-check-outline text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">PPE Helmets & Hi-Vis Jackets</span>
                                    <span class="text-muted" style="font-size: 10px;">CAS-SAFETY-01 • Safety gear for site workers</span>
                                </div>
                            </div>
                          <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-3 pt-2 border-top">
                        <span class="text-muted" style="font-size: 10px;">Ref ID: LH-104</span>
                        <span class="text-muted" style="font-size: 10px;">Mapped to Banking & Cash Flow</span>
                    </div>
                </div>
            </div>
        </div>

        {{-- Card 5: Equipment Rental & Fuel --}}
        <div class="col-12 col-lg-6 ledger-card-item" data-category="expense">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <span class="badge bg-danger-subtle text-danger fw-bold rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">Expense</span>
                            <span class="badge bg-light text-muted border rounded-pill px-2 py-1 mb-1" style="font-size: 10px;">EXP-EQP-501</span>
                        </div>
                        <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
                    </div>
                    <h6 class="fw-bold mb-1">Equipment Rental & Fuel</h6>
                    <p class="text-muted small mb-3">Hiring charges for heavy machinery</p>

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-uppercase text-muted fw-bold" style="font-size: 10px; letter-spacing: .05em;">Sub-Ledger Accounts</span>
                        <a href="#" class="text-primary small fw-semibold text-decoration-none" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#createSubLedgerModal"><i class="mdi mdi-plus-circle-outline"></i> Add Sub-Head</a>
                    </div>

                    <div class="d-flex flex-column gap-2 ledger-subhead-scroll">
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-crane text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Crawler Crane & Hydra Hire Charges</span>
                                    <span class="text-muted" style="font-size: 10px;">EQP-CRANE • Crane deployment fees</span>
                                </div>
                            </div>
                           <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border rounded-2 p-2 px-3 bg-white">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-truck-outline text-muted"></i>
                                <div>
                                    <span class="fw-semibold d-block" style="font-size: 12px;">Volvo FM Tipper Truck Rental</span>
                                    <span class="text-muted" style="font-size: 10px;">EQP-TIPPER • Muck & gravel hauling trips</span>
                                </div>
                            </div>
                          <div class="d-flex align-items-center gap-2">
    <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1" style="font-size: 10px;">Active</span>
    <button type="button"
            class="btn btn-link p-0 text-muted subhead-delete-btn"
            title="Delete"
            style="font-size: 16px; line-height: 1;">
        <i class="mdi mdi-delete-outline"></i>
    </button>
</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-3 pt-2 border-top">
                        <span class="text-muted" style="font-size: 10px;">Ref ID: LH-105</span>
                        <span class="text-muted" style="font-size: 10px;">Mapped to Banking & Cash Flow</span>
                    </div>
                </div>
            </div>
        </div>

    </div>

    {{-- Master Corporate Bank Accounts Mapping --}}
    <div class="card shadow-sm border-0 rounded-3 mt-4">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-4">
                <div>
                    <h6 class="fw-bold mb-1">
                        <i class="mdi mdi-bank-outline text-primary me-1"></i>
                        Master Corporate Bank Accounts Mapping
                    </h6>
                    <p class="text-muted small mb-0">
                        Configure corporate escrow and operational bank accounts linked to primary ledger heads
                    </p>
                </div>
                <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-2" style="font-size: 11px;">
                    4 Accounts Active
                </span>
            </div>

            <div class="row g-3">

                {{-- HDFC Escrow Account --}}
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 h-100 bg-white">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="fw-bold text-dark" style="font-size: 13px;">HDFC Escrow Account</span>
                            <span class="badge bg-light text-muted border rounded-pill px-2 py-1" style="font-size: 9px;">HDFC000240</span>
                        </div>
                        <div class="text-muted mb-1" style="font-size: 11px;">A/C: 502000889123</div>
                        <div class="text-muted mb-2" style="font-size: 10.5px;">Branch: Fort Corporate Branch, Mumbai</div>
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-muted" style="font-size: 11px;">Default Head:</span>
                            <a href="#" class="text-primary fw-semibold text-decoration-none" style="font-size: 11px;">Client RA Bill Collection</a>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted" style="font-size: 11px;">Reserve Threshold:</span>
                            <span class="fw-bold text-danger" style="font-size: 11px;">$500,000</span>
                        </div>
                    </div>
                </div>

                {{-- SBI Commercial --}}
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 h-100 bg-white">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="fw-bold text-dark" style="font-size: 13px;">SBI Commercial</span>
                            <span class="badge bg-light text-muted border rounded-pill px-2 py-1" style="font-size: 9px;">SBIN0009920</span>
                        </div>
                        <div class="text-muted mb-1" style="font-size: 11px;">A/C: 30981245801</div>
                        <div class="text-muted mb-2" style="font-size: 10.5px;">Branch: CAG Branch, New Delhi</div>
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-muted" style="font-size: 11px;">Default Head:</span>
                            <a href="#" class="text-primary fw-semibold text-decoration-none" style="font-size: 11px;">Vendor Material Supply</a>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted" style="font-size: 11px;">Reserve Threshold:</span>
                            <span class="fw-bold text-danger" style="font-size: 11px;">$250,000</span>
                        </div>
                    </div>
                </div>

                {{-- ICICI CapEx Operations --}}
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 h-100 bg-white">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="fw-bold text-dark" style="font-size: 13px;">ICICI CapEx Operations</span>
                            <span class="badge bg-light text-muted border rounded-pill px-2 py-1" style="font-size: 9px;">ICIC0000004</span>
                        </div>
                        <div class="text-muted mb-1" style="font-size: 11px;">A/C: 000405481239</div>
                        <div class="text-muted mb-2" style="font-size: 10.5px;">Branch: BKC Complex, Mumbai</div>
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-muted" style="font-size: 11px;">Default Head:</span>
                            <a href="#" class="text-primary fw-semibold text-decoration-none" style="font-size: 11px;">Site Petty Cash Advance</a>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted" style="font-size: 11px;">Reserve Threshold:</span>
                            <span class="fw-bold text-danger" style="font-size: 11px;">$100,000</span>
                        </div>
                    </div>
                </div>

                {{-- Axis Corporate Account --}}
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 h-100 bg-white">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="fw-bold text-dark" style="font-size: 13px;">Axis Corporate Account</span>
                            <span class="badge bg-light text-muted border rounded-pill px-2 py-1" style="font-size: 9px;">UTIB0000102</span>
                        </div>
                        <div class="text-muted mb-1" style="font-size: 11px;">A/C: 918020081198</div>
                        <div class="text-muted mb-2" style="font-size: 10.5px;">Branch: MG Road Branch, Bengaluru</div>
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-muted" style="font-size: 11px;">Default Head:</span>
                            <a href="#" class="text-primary fw-semibold text-decoration-none" style="font-size: 11px;">Subcontractor RA Payout</a>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted" style="font-size: 11px;">Reserve Threshold:</span>
                            <span class="fw-bold text-danger" style="font-size: 11px;">$150,000</span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>

{{-- Modal: Log Bank Entry --}}
<div class="modal fade" id="logBankEntryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-3 border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <div>
                    <h5 class="modal-title fw-bold mb-1">
                        <i class="mdi mdi-book-open-page-variant-outline text-primary me-1"></i>
                        Log Central Bank Ledger Entry
                    </h5>
                    <p class="text-muted small mb-0">
                        Record bank transaction with project, ledger account head, and contractor links
                    </p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body pt-3">
                <form id="logBankEntryForm">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Bank Account <span class="text-danger">*</span></label>
                            <select class="form-select form-select-sm">
                                <option selected>HDFC Escrow Account (502000889123)</option>
                                <option>SBI Commercial (30981245801)</option>
                                <option>ICICI CapEx Operations (000405481239)</option>
                                <option>Axis Corporate Account (918020081198)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Project Link <span class="text-danger">*</span></label>
                            <select class="form-select form-select-sm">
                                <option selected>Chennai Metro Phase 2 - Corridor 4</option>
                                <option>Coastal Expressway Bridge</option>
                                <option>Metro Line Extension - Phase 3</option>
                                <option>Skyline Premium Residences</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex justify-content-between align-items-center">
                                <label class="form-label fw-semibold small mb-1">Ledger Account Head <span class="text-danger">*</span></label>
                                <a href="#" class="text-primary small fw-semibold text-decoration-none" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#createPrimaryLedgerModal">+ New Head</a>
                            </div>
                            <select class="form-select form-select-sm">
                                <option selected>Subcontractor RA Payout (Expense)</option>
                                <option>Client RA Bill Collection</option>
                                <option>Vendor Material Supply</option>
                                <option>Site Petty Cash Advance</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex justify-content-between align-items-center">
                                <label class="form-label fw-semibold small mb-1">Sub-Ledger Account Head</label>
                                <a href="#" class="text-primary small fw-semibold text-decoration-none" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#createSubLedgerModal">+ New Sub-Head</a>
                            </div>
                            <select class="form-select form-select-sm">
                                <option selected>Earthwork & Excavation Clearance</option>
                                <option>TMT Rebar & Fe550D Steel Batch</option>
                                <option>Emergency Diesel & Machinery Fuel</option>
                                <option>MEP & Electrical Piping</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold small">Contractor / Party / Vendor <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Transaction Flow Type <span class="text-danger">*</span></label>
                            <select class="form-select form-select-sm">
                                <option selected>Debit (Outflow / Payment / Expense)</option>
                                <option>Credit (Inflow / Receipt / Income)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Payment Mode <span class="text-danger">*</span></label>
                            <select class="form-select form-select-sm">
                                <option selected>RTGS (Real Time Gross Settlement)</option>
                                <option>NEFT (National Electronic Funds Transfer)</option>
                                <option>IMPS (Immediate Payment Service)</option>
                                <option>EFT (Electronic Funds Transfer)</option>
                                <option>Cheque</option>
                                <option>Cash</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Transaction Amount ($) <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm" placeholder="e.g. 250000">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Reference UTR / Cheque No.</label>
                            <input type="text" class="form-control form-control-sm" placeholder="e.g. UTR883920192  (Auto-generated if blank)">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold small">Purpose / Particulars / Narration <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm" placeholder="e.g. Subcontractor RA #03 Earthwork clearance payout">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary btn-sm">
                    <i class="mdi mdi-plus me-1"></i> Save Entry
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Modal: Create Primary Ledger Head --}}
<div class="modal fade" id="createPrimaryLedgerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content rounded-3 border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <div>
                    <h5 class="modal-title fw-bold mb-1">
                        <i class="mdi mdi-file-document-plus-outline text-primary me-1"></i>
                        Create New Primary Ledger Head
                    </h5>
                    <p class="text-muted small mb-0">
                        Add custom account head to categorize bank transactions and site expenditures
                    </p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body pt-3">
                <form>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Ledger Category <span class="text-danger">*</span></label>
                            <select class="form-select form-select-sm">
                                <option selected>Expense Account Head</option>
                                <option>Income Account Head</option>
                                <option>Asset Account Head</option>
                                <option>Liability Account Head</option>
                                <option>Equity Account Head</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Head Code (Optional)</label>
                            <input type="text" class="form-control form-control-sm" placeholder="e.g. EXP-SUB-101  (Auto if blank)">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold small">Ledger Head Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm" placeholder="e.g. Statutory Safety &amp; Environment Fund / Concrete Testing Fee">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold small">Description / Purpose</label>
                            <textarea class="form-control form-control-sm" rows="3" placeholder="Provide scope, operational guidance, or accounting rules for this ledger head..."></textarea>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary btn-sm">
                    <i class="mdi mdi-plus me-1"></i> Create Ledger Head
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Modal: Create Sub-Ledger Head --}}
<div class="modal fade" id="createSubLedgerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content rounded-3 border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <div>
                    <h5 class="modal-title fw-bold mb-1">
                        <i class="mdi mdi-tag-plus-outline text-success me-1"></i>
                        Create New Sub-Ledger Head
                    </h5>
                    <p class="text-muted small mb-0">
                        Nest specific work sub-categories under a parent primary ledger head
                    </p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body pt-3">
                <form>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label fw-semibold small">Parent Primary Ledger Head <span class="text-danger">*</span></label>
                            <select class="form-select form-select-sm">
                                <option selected>Subcontractor RA Payout (Expense - EXP-SUB-101)</option>
                                <option>Client RA Bill Collection (Income - INC-RA-001)</option>
                                <option>Vendor Material Supply (Expense - EXP-MAT-050)</option>
                                <option>Site Petty Cash Advance (Expense - EXP-PET-020)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Sub-Ledger Head Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm" placeholder="e.g. Earthwork Excavation / Bo...">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Sub-Head Code (Optional)</label>
                            <input type="text" class="form-control form-control-sm" placeholder="e.g. SLH-SUB-01  (Auto if blank)">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold small">Description / Scope Notes</label>
                            <textarea class="form-control form-control-sm" rows="3" placeholder="e.g. Specifically for site levelling, muck removal, and soil compaction"></textarea>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-success btn-sm">
                    <i class="mdi mdi-plus me-1"></i> Add Sub-Ledger Head
                </button>
            </div>
        </div>
    </div>
</div>

<style>
    .settings-tabs-wrapper {
        width: 700px;
        max-width: 100%;
        min-width: 0;
        flex: 1 1 700px;
    }
    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 100%;
        min-width: 0;
    }
    .settings-tabs-track {
        display: flex;
        align-items: center;
        gap: .5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 4px;
    }
    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }
    .settings-tabs-track .settings-tab-pill,
    a.settings-tab-pill {
        white-space: nowrap;
        padding: .5rem 1.1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: .82rem;
        font-weight: 600;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
    .settings-tabs-track .settings-tab-pill:hover,
    a.settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
        text-decoration: none;
    }
    .settings-tabs-track .settings-tab-pill.active,
    a.settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }
    .settings-tabs-track .settings-tab-pill.active:hover,
    a.settings-tab-pill.active:hover {
        background: #124f7c;
        color: #fff;
    }
    .settings-tab-scroll-btn {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
        cursor: pointer;
        transition: all .15s ease;
    }
    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }
    .table > :not(caption) > * > * {
        border-bottom-width: 1px;
        border-color: #eef0f4;
    }
    .table thead th {
        border-bottom: 1px solid #eef0f4 !important;
    }
    .badge.bg-success-subtle {
        background-color: #e6f7ee !important;
    }
    .badge.bg-danger-subtle {
        background-color: #fdecec !important;
    }
    .badge.bg-light {
        background-color: #f4f6f9 !important;
    }
    .form-select-sm,
    .input-group-sm .form-control {
        font-size: 12px;
    }
    .form-select-sm {
        min-height: 31px;
    }
    .input-group-sm .form-control {
        min-height: 31px;
    }
    .card {
        border: 1px solid #eef0f4 !important;
    }
    .text-primary {
        color: #16659E !important;
    }
    .bg-primary {
        background-color: #16659E !important;
    }
    .btn-primary {
        background-color: #16659E !important;
        border-color: #16659E !important;
    }
    .btn-outline-secondary {
        color: #6c757d;
        border-color: #d0d5dd;
    }
    .btn-outline-secondary:hover {
        background-color: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }
    #logBankEntryModal .modal-content,
    #createPrimaryLedgerModal .modal-content,
    #createSubLedgerModal .modal-content {
        border-radius: 12px;
    }
    #logBankEntryModal .modal-header,
    #createPrimaryLedgerModal .modal-header,
    #createSubLedgerModal .modal-header {
        padding: 18px 22px 6px 22px;
    }
    #logBankEntryModal .modal-title,
    #createPrimaryLedgerModal .modal-title,
    #createSubLedgerModal .modal-title {
        font-size: 15px;
    }
    #logBankEntryModal .modal-body,
    #createPrimaryLedgerModal .modal-body,
    #createSubLedgerModal .modal-body {
        padding: 12px 22px 6px 22px;
    }
    #logBankEntryModal .modal-footer,
    #createPrimaryLedgerModal .modal-footer,
    #createSubLedgerModal .modal-footer {
        padding: 8px 22px 18px 22px;
    }
    #logBankEntryModal .form-label,
    #createPrimaryLedgerModal .form-label,
    #createSubLedgerModal .form-label {
        font-size: 12px;
        color: #1a2332;
        margin-bottom: 5px;
    }
    #logBankEntryModal .form-select-sm,
    #logBankEntryModal .form-control-sm,
    #createPrimaryLedgerModal .form-select-sm,
    #createPrimaryLedgerModal .form-control-sm,
    #createSubLedgerModal .form-select-sm,
    #createSubLedgerModal .form-control-sm {
        font-size: 12.5px;
        padding: 7px 10px;
        border-radius: 7px;
        border: 1px solid #d0d5dd;
        min-height: 38px;
    }
    #logBankEntryModal .form-select-sm:focus,
    #logBankEntryModal .form-control-sm:focus,
    #createPrimaryLedgerModal .form-select-sm:focus,
    #createPrimaryLedgerModal .form-control-sm:focus,
    #createSubLedgerModal .form-select-sm:focus,
    #createSubLedgerModal .form-control-sm:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }
    #logBankEntryModal textarea.form-control-sm,
    #createPrimaryLedgerModal textarea.form-control-sm,
    #createSubLedgerModal textarea.form-control-sm {
        min-height: 70px;
        resize: vertical;
    }
    #logBankEntryModal .form-control::placeholder,
    #createPrimaryLedgerModal .form-control::placeholder,
    #createSubLedgerModal .form-control::placeholder {
        color: #adb5bd;
        font-size: 12px;
    }
    /* Filter active-state pill (All Categories vs others) */
    .category-filter-btn.btn-primary {
        background-color: #16659E !important;
        border-color: #16659E !important;
        color: #fff !important;
    }
    .category-filter-btn.btn-outline-secondary {
        background-color: #fff !important;
        color: #6c757d !important;
        border-color: #d0d5dd !important;
    }
    .category-filter-btn.btn-outline-secondary:hover {
        background-color: #f8f9fa !important;
        color: #16659E !important;
        border-color: #16659E !important;
    }

    /* ---------- Ledger card: scrollable sub-ledger list ---------- */
.ledger-card-item .card-body {
    display: flex;
    flex-direction: column;
    min-height: 0;
}

.ledger-subhead-scroll {
    flex: 1 1 auto;
    min-height: 0;
    max-height: 260px;          /* controls visible rows; ~4 rows fit */
    overflow-y: auto;
    padding-right: 8px;
    scrollbar-width: thin;
    scrollbar-color: #b0b7c3 #f1f3f5;
}

.ledger-subhead-scroll::-webkit-scrollbar {
    width: 8px;
}

.ledger-subhead-scroll::-webkit-scrollbar-track {
    background: #f1f3f5;
    border-radius: 50rem;
}

.ledger-subhead-scroll::-webkit-scrollbar-thumb {
    background: #b0b7c3;
    border-radius: 50rem;
}

.ledger-subhead-scroll::-webkit-scrollbar-thumb:hover {
    background: #8c93a0;
}

    @media (max-width: 992px) {
        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 700px;
        }
        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }
    }
    @media (max-width: 768px) {
        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 100%;
        }
        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {


/* ---------- Delete Sub-Ledger Row ---------- */
document.querySelectorAll('.subhead-delete-btn').forEach(function (btn) {   // ① opens forEach
    btn.addEventListener('click', function (e) {                           // ② opens click handler
        e.preventDefault();
        e.stopPropagation();

        const row = btn.closest('.d-flex.justify-content-between.align-items-center.border');
        if (!row) return;

        const nameEl = row.querySelector('.fw-semibold.d-block');
        const codeEl = row.querySelector('.text-muted');
        const name   = nameEl ? nameEl.textContent.trim() : '';
        const code   = codeEl ? codeEl.textContent.split('•')[0].trim() : '';

        const label = name
            ? name + (code ? ' (' + code + ')' : '')
            : 'this sub-ledger';

        if (confirm('Delete sub-ledger ' + label + '?')) {
            row.remove();

            const remaining = document.querySelectorAll(
                '#ledgerCardsGrid .ledger-subhead-scroll .d-flex.justify-content-between.align-items-center.border'
            ).length;
            document.querySelectorAll('.card-body').forEach(function (body) {
                const labelEl = body.querySelector('.text-uppercase');
                if (labelEl && /active sub-ledgers/i.test(labelEl.textContent)) {
                    const numEl = body.querySelector('.fw-bold.text-danger');
                    if (numEl) numEl.textContent = remaining + ' Sub-Heads';
                }
            });
        }
    });                                                                    // ② closes click handler
});                                                                        // ① closes forEach
    /* ---------- Tabs Scroll ---------- */
    const tabsTrack = document.getElementById('ledgerTabsTrack');
    const scrollLeftBtn = document.getElementById('ledgerTabScrollLeft');
    const scrollRightBtn = document.getElementById('ledgerTabScrollRight');

    if (scrollLeftBtn && tabsTrack) {
        scrollLeftBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }
    if (scrollRightBtn && tabsTrack) {
        scrollRightBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

    /* ---------- Ledger Cards Filter ---------- */
    const cardsGrid       = document.getElementById('ledgerCardsGrid');
    const searchInput     = document.getElementById('ledgerSearch');
    const categoryButtons = document.querySelectorAll('.category-filter-btn');

    // Only filter cards that live inside the ledger grid.
    const cards = cardsGrid
        ? cardsGrid.querySelectorAll('.ledger-card-item')
        : [];

    let activeCategory = '';

    function applyFilter() {
        if (!cardsGrid) return;

        const search = searchInput
            ? searchInput.value.toLowerCase().trim()
            : '';

        cards.forEach(function (card) {
            const cardCategory = (card.getAttribute('data-category') || '').toLowerCase();
            const cardText     = card.innerText.toLowerCase();

            const categoryMatch =
                activeCategory === '' || cardCategory === activeCategory;

            const searchMatch =
                search === '' || cardText.includes(search);

            card.style.display = (categoryMatch && searchMatch) ? '' : 'none';
        });
    }

    /* Category pill clicks — swap active class between pills */
    categoryButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            categoryButtons.forEach(function (b) {
                b.classList.remove('btn-primary');
                b.classList.add('btn-outline-secondary');
            });
            btn.classList.remove('btn-outline-secondary');
            btn.classList.add('btn-primary');

            activeCategory = (btn.getAttribute('data-category') || '').toLowerCase();
            applyFilter();
        });
    });

    /* Live search */
    if (searchInput) {
        searchInput.addEventListener('input', applyFilter);
    }
});
</script>

@endsection
