@extends('layouts/contentNavbarLayout')

@section('title', 'Credit Card Utilization')

@section('content')

<div class="container-fluid">

    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body p-3 p-md-4">
            <div class="d-flex justify-content-between align-items-center flex-nowrap gap-3">
                <div class="flex-shrink-0" style="min-width: 0;">
                    <h5 class="fw-bold mb-1">Corporate Credit Card Utilization</h5>
                    <p class="text-muted small mb-0">
                        Record corporate credit card expenses mapped to ledger heads and track utilization.
                    </p>
                </div>
                <div class="settings-tabs-wrapper">
                    <div class="d-flex align-items-center gap-2">
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollLeft">
                            <i class="mdi mdi-chevron-left"></i>
                        </button>
                        <div class="settings-tabs-scroller">
                            <div class="settings-tabs-track" id="ledgerTabsTrack">
                                <a href="{{ route('accounts.banking') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.banking') ? 'active' : '' }}">
                                    Bank Ledger Entry
                                </a>
                                <a href="{{ route('accounts.ledger') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.ledger') ? 'active' : '' }}">
                                    Settings / Ledger Heads
                                </a>
                                <a href="{{ route('accounts.bank.hold') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.bank.hold') ? 'active' : '' }}">
                                    Bank Hold Amount
                                </a>
                                <a href="{{ route('accounts.cashflow') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.cashflow') ? 'active' : '' }}">
                                    Cash Flow Entry
                                </a>
                                <a href="{{ route('accounts.creditcard') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.creditcard') ? 'active' : '' }}">
                                    Credit Card Utilization
                                </a>

                                  <a href="{{ route('accounts.mobilebill') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.mobilebill') ? 'active' : '' }}">
                                    Mobile Bill Entry
                                </a>
                            </div>
                        </div>
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollRight">
                            <i class="mdi mdi-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">

        <div class="col-12 col-md-6 col-lg-3">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <span class="text-black small fw-semibold text-uppercase"
                              style="font-size: 10px; letter-spacing: .05em;">
                            Total Corporate Limit
                        </span>
                        <span class="d-inline-flex align-items-center justify-content-center rounded-3"
                              style="width: 40px; height: 40px; background: #e8eff7; color: #16659E;">
                            <i class="mdi mdi-credit-card-outline" style="font-size: 22px;"></i>
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-1 mt-2">
                        <span class="fw-bold text-black fs-4">
                            $1,800,000
                        </span>
                    </div>
                    <span class="text-black text-nowrap small d-block mt-1">
                        Across 3 Corporate Cards
                    </span>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <span class="text-black small fw-semibold text-uppercase"
                              style="font-size: 10px; letter-spacing: .05em;">
                            Total Utilized Amount
                        </span>
                        <span class="d-inline-flex align-items-center justify-content-center rounded-3"
                              style="width: 40px; height: 40px; background: #fdf3dc; color: #c98a12;">
                            <i class="mdi mdi-arrow-top-right-thin-circle-outline" style="font-size: 22px;"></i>
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-1 mt-2">
                        <span class="fw-bold fs-4" style="color: #d97706;">
                            $745,000
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-2 mt-2">
                        <div class="progress flex-grow-1" style="height: 6px; background:#eef0f4; border-radius: 50rem;">
                            <div class="progress-bar" role="progressbar"
                                 style="width: 41.4%; background:#f0a020; border-radius: 50rem;"
                                 aria-valuenow="41.4" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <span class="fw-semibold small text-black text-nowrap" style="font-size: 12px;">
                            41.4% Used
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <span class="text-muted small fw-semibold" style="font-size: 12px;">
                            Available Credit Balance
                        </span>
                        <span class="d-inline-flex align-items-center justify-content-center rounded-3"
                              style="width: 40px; height: 40px; background: #e6f7ee; color: #0f7a4a;">
                            <i class="mdi mdi-check-circle-outline" style="font-size: 22px;"></i>
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-1 mt-2">
                        <span class="fw-bold fs-4" style="color: #0f7a4a;">
                            $1,055,000
                        </span>
                    </div>
                    <span class="text-muted small d-block mt-1">
                        Ready for emergency site purchases
                    </span>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <span class="text-muted small fw-semibold" style="font-size: 12px;">
                            Card Expense Logged
                        </span>
                        <span class="d-inline-flex align-items-center justify-content-center rounded-3"
                              style="width: 40px; height: 40px; background: #d9f2ee; color: #0f766e;">
                            <i class="mdi mdi-receipt-text-outline" style="font-size: 22px;"></i>
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-1 mt-2">
                        <span class="fw-bold text-black fs-4">
                            $84,700
                        </span>
                    </div>
                    <span class="small d-block mt-1">
                        <span class="fw-semibold text-black">3 mapped entries</span>
                        <span class="text-muted">recorded</span>
                    </span>
                </div>
            </div>
        </div>

    </div>

    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-body px-4 pt-4 pb-3">
            <div class="cc-register-header">

                <div class="cc-register-title">
                    <h6 class="fw-bold mb-1">Credit Card Expense Register (Mapped to Ledger Heads)</h6>
                    <p class="text-muted small mb-0">
                        History of corporate card purchases by Ledger &amp; Sub-Ledger heads
                    </p>
                </div>

                <div class="cc-register-filters">

                    <div class="input-group input-group-sm cc-filter-search">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="mdi mdi-magnify text-muted"></i>
                        </span>
                        <input type="text"
                               class="form-control border-start-0"
                               id="ccRegisterSearch"
                               placeholder="Search merchant, description...">
                    </div>

                    <select class="form-select form-select-sm cc-filter-card" id="ccRegisterCardFilter">
                        <option value="">All Cards</option>
                        <option value="HDFC Corporate Platinum">HDFC Corporate Platinum</option>
                        <option value="SBI Executive Business">SBI Executive Business</option>
                        <option value="Axis Expense Card">Axis Expense Card</option>
                    </select>

                    <select class="form-select form-select-sm cc-filter-head" id="ccRegisterHeadFilter">
                        <option value="">All Ledger Heads</option>
                        <option value="Vendor Material Supply">Vendor Material Supply</option>
                        <option value="Equipment Rental &amp; Fuel">Equipment Rental &amp; Fuel</option>
                        <option value="Site Petty Cash Advance">Site Petty Cash Advance</option>
                    </select>

                    <button type="button"
                            class="btn btn-primary btn-sm d-flex align-items-center gap-1 cc-filter-btn"
                            id="ccPostExpenseBtn"
                            data-bs-toggle="modal"
                            data-bs-target="#postCardExpenseModal">
                        <i class="mdi mdi-plus"></i>
                        Record credit card Expenses
                    </button>

                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table align-middle mb-0" style="font-size: 12.5px;" id="ccRegisterTable">
                <thead style="background: #f8f9fc;">
                    <tr>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 24px;">
                            DATE &amp; REF
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            CARD USED
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            PROJECT SITE
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            LEDGER / SUB-LEDGER HEAD
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            MERCHANT &amp; DESCRIPTION
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-end"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            AMOUNT ($)
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            STATUS
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px; width: 90px;">
                            ACTION
                        </th>
                    </tr>
                </thead>
                <tbody id="ccRegisterBody">

                    <tr class="border-bottom cc-register-row"
                        data-card="HDFC Corporate Platinum"
                        data-head="Vendor Material Supply"
                        data-date="2026-07-25"
                        data-pos="POS-8832819"
                        data-project="Coastal Expressway Bridge"
                        data-subhead="Crushed M-Sand & Coarse Aggregates"
                        data-merchant="Apex Aggregates & ReadyMix"
                        data-description="Emergency aggregate batch payment at site quarry"
                        data-amount="42500">
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block" style="font-size: 11px;">2026-07-25</span>
                            <span class="text-muted" style="font-size: 10px;">POS-8832819</span>
                        </td>
                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-credit-card-outline text-primary"></i>
                                <div>
                                    <span class="fw-semibold text-dark d-block">HDFC Corporate Platinum</span>
                                    <span class="text-muted" style="font-size: 11px;">•••• 4092 • Thangavel Pandi(CEO)</span>
                                </div>
                            </div>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-dark">Coastal Expressway Bridge</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Vendor Material Supply</span>
                            <span class="text-muted" style="font-size: 11px;">Crushed M-Sand &amp; Coarse Aggregates</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Apex Aggregates &amp; ReadyMix</span>
                            <span class="text-muted" style="font-size: 11px;">Emergency aggregate batch payment at site quarry</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold" style="color:#c0392b;">$42,500</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <span class="badge rounded-pill px-3 py-1"
                                  style="background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0; font-size:11px; font-weight:600;">
                                Approved
                            </span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-cc-register-btn"
                                        title="Edit"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted"
                                        title="Delete"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr class="border-bottom cc-register-row"
                        data-card="SBI Executive Business"
                        data-head="Equipment Rental & Fuel"
                        data-date="2026-07-23"
                        data-pos="POS-4481820"
                        data-project="Metro Line Extension - Phase 3"
                        data-subhead="Crawler Crane & Hydra Hire Charges"
                        data-merchant="City Fuel Station"
                        data-description="Bulk diesel procurement for site DG & Excavators"
                        data-amount="28000">
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block" style="font-size: 11px;">2026-07-23</span>
                            <span class="text-muted" style="font-size: 10px;">POS-4481820</span>
                        </td>
                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-credit-card-outline text-primary"></i>
                                <div>
                                    <span class="fw-semibold text-dark d-block">SBI Executive Business</span>
                                    <span class="text-muted" style="font-size: 11px;">•••• 8812 • Project Manager Metro</span>
                                </div>
                            </div>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-dark">Metro Line Extension - Phase 3</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Equipment Rental &amp; Fuel</span>
                            <span class="text-muted" style="font-size: 11px;">Crawler Crane &amp; Hydra Hire Charges</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">City Fuel Station</span>
                            <span class="text-muted" style="font-size: 11px;">Bulk diesel procurement for site DG &amp; Excavators</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold" style="color:#c0392b;">$28,000</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <span class="badge rounded-pill px-3 py-1"
                                  style="background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0; font-size:11px; font-weight:600;">
                                Approved
                            </span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-cc-register-btn"
                                        title="Edit"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted"
                                        title="Delete"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr class="cc-register-row"
                        data-card="Axis Expense Card"
                        data-head="Site Petty Cash Advance"
                        data-date="2026-07-20"
                        data-pos="POS-1182893"
                        data-project="Skyline Premium Residences"
                        data-subhead="PPE Helmets & High-Vis Jackets"
                        data-merchant="SafeGear Industrial Solutions"
                        data-description="Safety helmets & reflective jackets for 50 workers"
                        data-amount="14200">
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block" style="font-size: 11px;">2026-07-20</span>
                            <span class="text-muted" style="font-size: 10px;">POS-1182893</span>
                        </td>
                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-2">
                                <i class="mdi mdi-credit-card-outline text-primary"></i>
                                <div>
                                    <span class="fw-semibold text-dark d-block">Axis Expense Card</span>
                                    <span class="text-muted" style="font-size: 11px;">•••• 1029 • Store Incharge - Expressway</span>
                                </div>
                            </div>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-dark">Skyline Premium Residences</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Site Petty Cash Advance</span>
                            <span class="text-muted" style="font-size: 11px;">PPE Helmets &amp; High-Vis Jackets</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">SafeGear Industrial Solutions</span>
                            <span class="text-muted" style="font-size: 11px;">Safety helmets &amp; reflective jackets for 50 workers</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold" style="color:#c0392b;">$14,200</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <span class="badge rounded-pill px-3 py-1"
                                  style="background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0; font-size:11px; font-weight:600;">
                                Approved
                            </span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-cc-register-btn"
                                        title="Edit"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted"
                                        title="Delete"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>

        <div class="card-footer bg-white border-top d-flex justify-content-end align-items-center px-4 py-3">
            <span class="text-muted small fw-semibold me-3">
                Total Filtered Card Expenses:
            </span>
            <span class="text-dark fw-bold" style="font-size: 15px;">$84,700</span>
        </div>
    </div>

</div>

{{-- Modal: Post Card Expense --}}
<div class="modal fade" id="postCardExpenseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-credit-card-outline text-primary" style="font-size: 20px;"></i>
                    <h5 class="modal-title fw-bold mb-0" id="postCardExpenseTitle" style="font-size: 15px;">
                        Post Card Expense &amp; Update Utilization
                    </h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body pt-3">
                <form id="postCardExpenseForm">

                    <div class="row g-3 mb-3">
                        <div class="col-md-5">
                            <label class="form-label fw-semibold small">
                                Select Corporate Card <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="modalCcCard">
                                <option value="HDFC Corporate Platinum" selected>HDFC Corporate Platinum (•••• 4092) - Avail: $680,000</option>
                                <option value="SBI Executive Business">SBI Executive Business (•••• 8812) - Avail: $315,000</option>
                                <option value="Axis Expense Card">Axis Expense Card (•••• 1029) - Avail: $60,000</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">
                                Expense Date <span class="text-danger">*</span>
                            </label>
                            <input type="date"
                                   class="form-control form-control-sm"
                                   id="modalCcDate"
                                   value="2026-09-16">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Project Site <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="modalCcProject">
                                <option value="Chennai Metro Phase 2 - Corridor 4" selected>Chennai Metro Phase 2 - Corridor 4</option>
                                <option value="Coastal Expressway Bridge">Coastal Expressway Bridge</option>
                                <option value="Metro Line Extension - Phase 3">Metro Line Extension - Phase 3</option>
                                <option value="Skyline Premium Residences">Skyline Premium Residences</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Ledger Head <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="modalCcLedgerHead">
                                <option value="Vendor Material Supply" selected>Vendor Material Supply (EXP-MAT-301)</option>
                                <option value="Site Petty Cash Advance">Site Petty Cash Advance (EXP-PET-020)</option>
                                <option value="Subcontractor RA Payout">Subcontractor RA Payout (EXP-SUB-101)</option>
                                <option value="Equipment Rental & Fuel">Equipment Rental & Fuel (EXP-EQP-501)</option>
                            </select>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label fw-semibold small">
                                Sub-Ledger Head <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="modalCcSubLedger">
                                <option value="Crushed M-Sand & Coarse Aggregates" selected>Crushed M-Sand & Coarse Aggregates (MAT-SAND)</option>
                                <option value="TMT Rebar & Fe550D Steel Batch">TMT Rebar & Fe550D Steel Batch (MAT-STL)</option>
                                <option value="Ready Mix Concrete">Ready Mix Concrete (MAT-RMC)</option>
                                <option value="Emergency Diesel & Machinery Fuel">Emergency Diesel & Machinery Fuel (CAS-FUEL)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">
                                Merchant / Vendor Name <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="modalCcMerchant"
                                   placeholder="e.g. Indian Oil Fuel Bunk">
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Expense Description / Purpose <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="modalCcDescription"
                                   placeholder="e.g. Payment for 1000L diesel refill for JCB Excavator #04">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                POS / Card Slip Ref No.
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="modalCcPosRef"
                                   placeholder="e.g. POS-8832910">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Amount ($) <span class="text-danger">*</span>
                            </label>
                            <input type="number"
                                   class="form-control form-control-sm"
                                   id="modalCcAmount"
                                   value="0.00"
                                   step="0.01">
                        </div>
                    </div>

                    <div class="border rounded-3 p-3" style="background:#f8f9fc;">
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <span class="text-muted small fw-semibold d-flex align-items-center gap-1" style="font-size: 12px;">
                                <i class="mdi mdi-credit-card-outline"></i>
                                HDFC Corporate Platinum impact preview:
                            </span>
                            <div class="text-muted small d-flex align-items-center gap-3 flex-wrap" style="font-size: 12px;">
                                <span>
                                    Current Utilized:
                                    <span class="text-dark fw-semibold">$320,000</span>
                                </span>
                                <span>•</span>
                                <span>
                                    New Utilized:
                                    <span class="text-warning fw-bold">$320,000</span>
                                    <span class="text-muted">(32.0%)</span>
                                </span>
                                <span>•</span>
                                <span>
                                    Remaining Avail:
                                    <span class="text-success fw-semibold">$680,000</span>
                                </span>
                            </div>
                        </div>
                    </div>

                </form>
            </div>

            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm px-4" data-bs-dismiss="modal">
                    Clear Form
                </button>
                <button type="button"
                        class="btn btn-primary btn-sm px-4 d-flex align-items-center gap-1"
                        id="modalCcSubmitBtn">
                    <i class="mdi mdi-plus"></i>
                    Post Card Expense &amp; Update Utilization
                </button>
            </div>

        </div>
    </div>
</div>

{{-- Modal: Issue Corporate Credit Card --}}
<div class="modal fade" id="issueCorporateCardModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-credit-card-outline text-primary" style="font-size: 20px;"></i>
                    <h5 class="modal-title fw-bold mb-0" style="font-size: 15px;">
                        Issue Corporate Credit Card
                    </h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body pt-3">
                <form id="issueCorporateCardForm">

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">
                            Card Name / Type <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               class="form-control form-control-sm"
                               id="icCardName"
                               placeholder="e.g. HDFC Executive Corporate Card">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">
                            Cardholder Name &amp; Designation <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               class="form-control form-control-sm"
                               id="icCardholder"
                               placeholder="e.g. Anand Sharma (Project Director)">
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Issuer Bank <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="icIssuerBank">
                                <option selected>HDFC Bank</option>
                                <option>SBI</option>
                                <option>ICICI Bank</option>
                                <option>Axis Bank</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Credit Limit ($) <span class="text-danger">*</span>
                            </label>
                            <input type="number"
                                   class="form-control form-control-sm"
                                   id="icCreditLimit"
                                   placeholder="e.g. 500000">
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Masked Card No.
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="icMaskedCard"
                                   placeholder="•••• 7447">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Monthly Billing Cycle Due
                            </label>
                            <input type="date"
                                   class="form-control form-control-sm"
                                   id="icBillingDue"
                                   placeholder="15-08-2026">
                        </div>
                    </div>

                </form>
            </div>

            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm px-4" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-primary btn-sm px-4" id="icSubmitBtn">
                    Issue Card
                </button>
            </div>

        </div>
    </div>
</div>

<style>

    .settings-tabs-wrapper {
        width: 700px;
        max-width: 100%;
        min-width: 0;
        flex: 1 1 700px;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 100%;
        min-width: 0;
    }

    .settings-tabs-track {
        display: flex;
        align-items: center;
        gap: .5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 4px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tabs-track .settings-tab-pill,
    a.settings-tab-pill {
        white-space: nowrap;
        padding: .5rem 1.1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: .82rem;
        font-weight: 600;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .settings-tabs-track .settings-tab-pill:hover,
    a.settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
        text-decoration: none;
    }

    .settings-tabs-track .settings-tab-pill.active,
    a.settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tabs-track .settings-tab-pill.active:hover,
    a.settings-tab-pill.active:hover {
        background: #124f7c;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
        cursor: pointer;
        transition: all .15s ease;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }

    /* ---------- Register header (single-line title) ---------- */
    .cc-register-header {
        display: flex;
        flex-wrap: nowrap;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        width: 100%;
    }

    .cc-register-title {
        flex: 0 1 auto;
        min-width: 0;
    }

    .cc-register-title h6,
    .cc-register-title p {
        white-space: nowrap;
    }

    .cc-register-filters {
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 0 1 auto;
        flex-wrap: nowrap;
        min-width: 0;
    }

    .cc-filter-search { width: 220px; }
    .cc-filter-card   { width: 160px; }
    .cc-filter-head   { width: 180px; }

    .cc-filter-btn {
        white-space: nowrap;
        flex-shrink: 0;
    }

    @media (max-width: 1400px) {
        .cc-filter-search { width: 200px; }
        .cc-filter-card   { width: 140px; }
        .cc-filter-head   { width: 160px; }
    }

    @media (max-width: 1200px) {
        .cc-filter-search { width: 180px; }
        .cc-filter-card   { width: 130px; }
        .cc-filter-head   { width: 150px; }
    }

    @media (max-width: 992px) {
        .cc-register-header {
            flex-wrap: wrap;
        }
        .cc-register-title h6,
        .cc-register-title p {
            white-space: normal;
        }
        .cc-register-filters {
            flex-wrap: wrap;
            width: 100%;
        }
        .cc-filter-search {
            width: 100%;
            flex: 1 1 100%;
        }
        .cc-filter-card,
        .cc-filter-head {
            flex: 1 1 160px;
            width: auto;
        }
        .cc-filter-btn {
            flex: 1 1 100%;
            justify-content: center;
        }
    }

    .table > :not(caption) > * > * {
        border-bottom-width: 1px;
        border-color: #eef0f4;
    }

    .table thead th {
        border-bottom: 1px solid #eef0f4 !important;
    }

    .form-select-sm,
    .input-group-sm .form-control,
    .input-group-sm .form-select {
        font-size: 12px;
    }

    .form-select-sm {
        min-height: 38px;
    }

    .form-control-sm {
        min-height: 38px;
    }

    /* ============================================================= */
    /* ---------- Credit Card Register table alignment fix ---------- */
    /* ============================================================= */
    #ccRegisterTable {
        table-layout: auto;
        width: 100%;
    }

    #ccRegisterTable thead th,
    #ccRegisterTable tbody td {
        vertical-align: middle;
        white-space: nowrap;
    }

    /* Main text lines (card name, ledger head, project site, merchant) */
    #ccRegisterTable tbody td .fw-semibold.text-dark,
    #ccRegisterTable tbody td .text-dark {
        white-space: nowrap;
    }

    /* Sub-text lines (masked card number, sub-ledger, merchant description) */
    #ccRegisterTable tbody td .text-muted[style*="font-size: 10px"],
    #ccRegisterTable tbody td .text-muted[style*="font-size:10px"],
    #ccRegisterTable tbody td .text-muted[style*="font-size: 11px"],
    #ccRegisterTable tbody td .text-muted[style*="font-size:11px"] {
        white-space: nowrap;
        display: block;
    }

    /* Amount + status + action columns never wrap */
    #ccRegisterTable tbody td.text-end,
    #ccRegisterTable tbody td.text-center {
        white-space: nowrap;
    }

    /* ---------- Post Card Expense Modal (centered + fits viewport) ---------- */
    #postCardExpenseModal .modal-dialog {
        max-width: 1080px;
        width: calc(100% - 40px);
        margin: 1.75rem auto;
    }

    #postCardExpenseModal .modal-dialog-centered {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: calc(100vh - 3.5rem);
        margin: 1.75rem auto;
    }

    #postCardExpenseModal .modal-content {
        border-radius: 12px;
        max-height: calc(100vh - 3.5rem);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        width: 100%;
    }

    #postCardExpenseModal .modal-header {
        padding: 20px 28px 8px 28px;
        flex-shrink: 0;
    }

    #postCardExpenseModal .modal-body {
        padding: 16px 28px 12px 28px;
        overflow-y: auto;
        overflow-x: hidden;
        flex-grow: 1;
    }

    #postCardExpenseModal .modal-footer {
        padding: 12px 28px 22px 28px;
        flex-shrink: 0;
    }

    #postCardExpenseModal .form-label {
        font-size: 12.5px;
        color: #1a2332;
        margin-bottom: 6px;
        white-space: nowrap;
        overflow: visible;
    }

    #postCardExpenseModal .form-control-sm,
    #postCardExpenseModal .form-select-sm {
        font-size: 12.5px;
        padding: 8px 12px;
        border-radius: 7px;
        border: 1px solid #d0d5dd;
        min-height: 40px;
        width: 100%;
    }

    #postCardExpenseModal .form-control-sm:focus,
    #postCardExpenseModal .form-select-sm:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    @media (max-width: 1200px) {
        #postCardExpenseModal .modal-dialog {
            max-width: calc(100% - 32px);
        }
    }

    /* ---------- Issue Card Modal ---------- */
    #issueCorporateCardModal .modal-dialog {
        max-width: 720px;
        width: calc(100% - 40px);
        margin: 1.75rem auto;
    }

    #issueCorporateCardModal .modal-content {
        border-radius: 12px;
        max-height: calc(100vh - 3.5rem);
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    #issueCorporateCardModal .modal-header {
        padding: 20px 24px 8px 24px;
        flex-shrink: 0;
    }

    #issueCorporateCardModal .modal-body {
        padding: 12px 24px 8px 24px;
        overflow-y: auto;
        flex-grow: 1;
    }

    #issueCorporateCardModal .modal-footer {
        padding: 8px 24px 20px 24px;
        flex-shrink: 0;
    }

    #issueCorporateCardModal .form-label {
        font-size: 12.5px;
        color: #1a2332;
        margin-bottom: 6px;
    }

    #issueCorporateCardModal .form-control-sm,
    #issueCorporateCardModal .form-select-sm {
        font-size: 12.5px;
        padding: 8px 12px;
        border-radius: 8px;
        border: 1px solid #d0d5dd;
        min-height: 40px;
        width: 100%;
    }

    #issueCorporateCardModal .form-control-sm:focus,
    #issueCorporateCardModal .form-select-sm:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    #issueCorporateCardModal .form-control-sm::placeholder {
        color: #adb5bd;
        font-size: 12.5px;
    }

    .card {
        border: 1px solid #eef0f4 !important;
    }

    .text-primary {
        color: #16659E !important;
    }

    .bg-primary {
        background-color: #16659E !important;
    }

    .btn-primary {
        background-color: #16659E !important;
        border-color: #16659E !important;
    }

    .btn-primary:hover {
        background-color: #124f7c !important;
        border-color: #124f7c !important;
    }

    .btn-light {
        background-color: #f1f3f5;
        border-color: #f1f3f5;
        color: #495057;
    }

    .btn-light:hover {
        background-color: #e2e6ea;
        border-color: #e2e6ea;
        color: #212529;
    }

    .btn-link.text-primary:hover {
        color: #124f7c !important;
    }

    @media (max-width: 992px) {

        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 700px;
        }

        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }

    }

    @media (max-width: 768px) {

        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 100%;
        }

        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }

    }

</style>

<script>

document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Tabs Scroll ---------- */
    const tabsTrack = document.getElementById('ledgerTabsTrack');
    const scrollLeftBtn = document.getElementById('ledgerTabScrollLeft');
    const scrollRightBtn = document.getElementById('ledgerTabScrollRight');

    if (scrollLeftBtn && tabsTrack) {
        scrollLeftBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (scrollRightBtn && tabsTrack) {
        scrollRightBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

    /* ---------- Modal References ---------- */
    const postModalEl      = document.getElementById('postCardExpenseModal');
    const postModalTitle   = document.getElementById('postCardExpenseTitle');
    const postModalSubmit  = document.getElementById('modalCcSubmitBtn');

    const modalCcCard        = document.getElementById('modalCcCard');
    const modalCcDate        = document.getElementById('modalCcDate');
    const modalCcProject     = document.getElementById('modalCcProject');
    const modalCcLedgerHead  = document.getElementById('modalCcLedgerHead');
    const modalCcSubLedger   = document.getElementById('modalCcSubLedger');
    const modalCcMerchant    = document.getElementById('modalCcMerchant');
    const modalCcDescription = document.getElementById('modalCcDescription');
    const modalCcPosRef      = document.getElementById('modalCcPosRef');
    const modalCcAmount      = document.getElementById('modalCcAmount');

    let editingRow = null;

    function resetModalToCreate() {
        editingRow = null;

        if (modalCcCard)        modalCcCard.selectedIndex     = 0;
        if (modalCcDate)        modalCcDate.value             = '2026-09-16';
        if (modalCcProject)     modalCcProject.selectedIndex  = 0;
        if (modalCcLedgerHead)  modalCcLedgerHead.selectedIndex = 0;
        if (modalCcSubLedger)   modalCcSubLedger.selectedIndex  = 0;
        if (modalCcMerchant)    modalCcMerchant.value         = '';
        if (modalCcDescription) modalCcDescription.value      = '';
        if (modalCcPosRef)      modalCcPosRef.value           = '';
        if (modalCcAmount)      modalCcAmount.value           = '0.00';

        if (postModalTitle)  postModalTitle.textContent = 'Post Card Expense & Update Utilization';
        if (postModalSubmit) postModalSubmit.innerHTML  =
            '<i class="mdi mdi-plus"></i> Post Card Expense & Update Utilization';
    }

    function enterModalEditMode(row) {
        const data = row.dataset;
        editingRow = row;

        if (modalCcCard)        modalCcCard.value        = data.card        || '';
        if (modalCcDate)        modalCcDate.value        = data.date        || '';
        if (modalCcProject)     modalCcProject.value     = data.project     || '';
        if (modalCcLedgerHead)  modalCcLedgerHead.value  = data.head        || '';
        if (modalCcSubLedger)   modalCcSubLedger.value   = data.subhead     || '';
        if (modalCcMerchant)    modalCcMerchant.value    = data.merchant    || '';
        if (modalCcDescription) modalCcDescription.value = data.description || '';
        if (modalCcPosRef)      modalCcPosRef.value      = data.pos         || '';
        if (modalCcAmount)      modalCcAmount.value      = data.amount      || 0;

        if (postModalTitle)  postModalTitle.textContent = 'Update Card Expense & Update Utilization';
        if (postModalSubmit) postModalSubmit.innerHTML  =
            '<i class="mdi mdi-check"></i> Update Card Expense & Update Utilization';
    }

    const postExpenseBtn = document.getElementById('ccPostExpenseBtn');

    if (postExpenseBtn && postModalEl) {
        postExpenseBtn.addEventListener('click', function () {
            resetModalToCreate();
            bootstrap.Modal.getOrCreateInstance(postModalEl).show();
        });
    }

    document.querySelectorAll('.edit-cc-register-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();

            const row = btn.closest('.cc-register-row');
            if (!row) return;

            resetModalToCreate();
            enterModalEditMode(row);

            if (postModalEl) {
                bootstrap.Modal.getOrCreateInstance(postModalEl).show();
            }
        });
    });

    if (postModalSubmit && postModalEl) {
        postModalSubmit.addEventListener('click', function () {
            if (editingRow) {
                console.log('Updating row:', editingRow.dataset);
            } else {
                console.log('Posting new card expense...');
            }
            bootstrap.Modal.getOrCreateInstance(postModalEl).hide();
        });
    }

    /* ---------- Register Filters ---------- */
    const registerSearch     = document.getElementById('ccRegisterSearch');
    const registerCardFilter = document.getElementById('ccRegisterCardFilter');
    const registerHeadFilter = document.getElementById('ccRegisterHeadFilter');
    const registerRows       = document.querySelectorAll('#ccRegisterBody .cc-register-row');

    function applyRegisterFilter() {
        const search = (registerSearch ? registerSearch.value : '').toLowerCase().trim();
        const card   = (registerCardFilter ? registerCardFilter.value : '').toLowerCase().trim();
        const head   = (registerHeadFilter ? registerHeadFilter.value : '').toLowerCase().trim();

        registerRows.forEach(function (row) {
            const rowCard = (row.getAttribute('data-card') || '').toLowerCase();
            const rowHead = (row.getAttribute('data-head') || '').toLowerCase();
            const rowText = row.innerText.toLowerCase();

            const match =
                (search === '' || rowText.includes(search)) &&
                (card   === '' || rowCard.includes(card)) &&
                (head   === '' || rowHead.includes(head));

            row.style.display = match ? '' : 'none';
        });
    }

    if (registerSearch)     registerSearch.addEventListener('input', applyRegisterFilter);
    if (registerCardFilter) registerCardFilter.addEventListener('change', applyRegisterFilter);
    if (registerHeadFilter) registerHeadFilter.addEventListener('change', applyRegisterFilter);

    /* ---------- Issue Card Modal Submit ---------- */
    const issueCardSubmitBtn = document.getElementById('icSubmitBtn');

    if (issueCardSubmitBtn) {
        issueCardSubmitBtn.addEventListener('click', function () {
            console.log('Issuing new corporate card...');
            const modalEl = document.getElementById('issueCorporateCardModal');
            if (modalEl) {
                const modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) modal.hide();
            }
        });
    }

});

</script>

@endsection
