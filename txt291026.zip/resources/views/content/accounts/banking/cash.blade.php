@extends('layouts/contentNavbarLayout')

@section('title', 'Cash Flow Entry')

@section('content')

<div class="container-fluid">

    {{-- Header Card with Tabs --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body p-3 p-md-4">
            <div class="d-flex justify-content-between align-items-center flex-nowrap gap-3">
                <div class="flex-shrink-0" style="min-width: 0;">
                    <h5 class="fw-bold mb-1">Cash Flow Entries &amp; Voucher Records</h5>
                    <p class="text-muted small mb-0">
                        Record daily cash flow vouchers, site petty cash transactions, and receipts against projects
                    </p>
                </div>
                <div class="settings-tabs-wrapper">
                    <div class="d-flex align-items-center gap-2">
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollLeft">
                            <i class="mdi mdi-chevron-left"></i>
                        </button>
                        <div class="settings-tabs-scroller">
                            <div class="settings-tabs-track" id="ledgerTabsTrack">
                                <a href="{{ route('accounts.banking') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.banking') ? 'active' : '' }}">
                                    Bank Ledger Entry
                                </a>
                                <a href="{{ route('accounts.ledger') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.ledger') ? 'active' : '' }}">
                                    Settings / Ledger Heads
                                </a>
                                <a href="{{ route('accounts.bank.hold') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.bank.hold') ? 'active' : '' }}">
                                    Bank Hold Amount
                                </a>
                                <a href="{{ route('accounts.cashflow') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.cashflow') ? 'active' : '' }}">
                                    Cash Flow Entry
                                </a>
                                <a href="{{ route('accounts.creditcard') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.creditcard') ? 'active' : '' }}">
                                    Credit Card Utilization
                                </a>
                                <a href="{{ route('accounts.mobilebill') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.mobilebill') ? 'active' : '' }}">
                                    Mobile Bill Entry
                                </a>
                            </div>
                        </div>
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollRight">
                            <i class="mdi mdi-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Cash Flow Table Card --}}
    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-body px-4 pt-4 pb-3">
            <div class="cf-register-header">
                <div class="cf-register-title">
                    <h6 class="fw-bold mb-1">Daily Cash Flow &amp; Voucher Records</h6>
                    <p class="text-muted small mb-0">
                        History of created cash flow entries, site petty cash, and receipts
                    </p>
                </div>

                <div class="cf-register-filters">
                    {{-- Export CSV Button --}}
                <button type="button"
                        class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1 hold-filter-btn"
                        id="holdExportCsvBtn">
                    <i class="mdi mdi-download"></i>
                    Export CSV
                </button>

                    <button type="button"
                            class="btn btn-primary btn-sm d-flex align-items-center gap-1 cf-filter-btn"
                            id="cfCreateEntryBtn"
                            data-bs-toggle="modal"
                            data-bs-target="#createCashFlowModal">
                        <i class="mdi mdi-plus"></i>
                        Create Cash Flow Entry
                    </button>
                </div>
            </div>



            {{-- ================= FILTER SECTION ================= --}}
            <div class="cf-table-filters mt-3">
                <div class="row g-2">

                    {{-- Search --}}
                    <div class="col-12 col-md-4">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text bg-white border-end-0">
                                <i class="mdi mdi-magnify text-muted"></i>
                            </span>
                            <input type="text"
                                   class="form-control border-start-0"
                                   id="cfSearchInput"
                                   placeholder="Search voucher, project, ledger, contractor...">
                        </div>
                    </div>

                    {{-- Project Site Filter --}}
                    <div class="col-12 col-md-4">
                        <select class="form-select form-select-sm" id="cfProjectFilter">
                            <option value="">All Project Sites</option>
                            <option value="Chennai Metro Phase 2 - Corridor 4">Chennai Metro Phase 2 - Corridor 4</option>
                            <option value="Coastal Expressway Bridge">Coastal Expressway Bridge</option>
                            <option value="Metro Line Extension - Phase 3">Metro Line Extension - Phase 3</option>
                            <option value="Skyline Premium Residences">Skyline Premium Residences</option>
                        </select>
                    </div>

                    {{-- Type Filter --}}
                    <div class="col-12 col-md-4">
                        <select class="form-select form-select-sm" id="cfTypeFilter">
                            <option value="">All Types</option>
                            <option value="Credit">Credit</option>
                            <option value="Debit">Debit</option>
                        </select>
                    </div>

                </div>
            </div>
            {{-- ================= /FILTER SECTION ================= --}}

        </div>

        <div class="table-responsive">
            <table class="table align-middle mb-0" style="font-size: 12.5px;" id="cashFlowTable">
                <thead style="background: #f8f9fc;">
                    <tr>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 24px;">
                            DATE
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            PROJECT SITE
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            LEDGER / PURPOSE
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            CONTRACTOR / RECIPIENT
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-end"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            CREDIT ($)
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-end"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px;">
                            DEBIT ($)
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center"
                            style="font-size: 10px; letter-spacing: .05em; padding: 12px 16px; width: 100px;">
                            ACTIONS
                        </th>
                    </tr>
                </thead>
                <tbody id="cashFlowBody">

                    {{-- Row 1: Credit entry --}}
                    <tr class="border-bottom cash-flow-row"
                        data-date="23-07-2026"
                        data-project="Chennai Metro Phase 2 - Corridor 4"
                        data-type="Credit"
                        data-ledger="Client RA Bill Collection"
                        data-description="RA Bill No. 12 partial payment received"
                        data-contractor="NHAI Project Authority"
                        data-amount="65000">
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark">23-07-2026</span>
                            <span class="text-muted d-block" style="font-size:11px;"></span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark">Chennai Metro Phase 2 - Corridor 4</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Client RA Bill Collection</span>
                            <span class="text-muted" style="font-size:11px;">
                                RA Bill No. 12 partial payment received
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-dark">NHAI Project Authority</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold" style="color:#0f7a4a;">$65,000</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="text-muted">—</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-cash-flow-btn"
                                        title="Edit"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-cash-flow-btn"
                                        title="Delete"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 2: Debit --}}
                    <tr class="border-bottom cash-flow-row"
                        data-date="22-07-2026"
                        data-project="Metro Line Extension - Phase 3"
                        data-type="Debit"
                        data-ledger="Site Petty Cash Advance"
                        data-description="Emergency Diesel purchase for Excavator #02"
                        data-contractor="Indian Oil Bunk"
                        data-amount="14500">
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark">22-07-2026</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark">Metro Line Extension - Phase 3</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Site Petty Cash Outflow</span>
                            <span class="text-muted" style="font-size:11px;">
                                Emergency Diesel purchase for Excavator #02
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-dark">Indian Oil Bunk</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="text-muted">—</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold" style="color:#c0392b;">$14,500</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-cash-flow-btn"
                                        title="Edit"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-cash-flow-btn"
                                        title="Delete"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 3: Debit --}}
                    <tr class="border-bottom cash-flow-row"
                        data-date="21-07-2026"
                        data-project="Skyline Premium Residences"
                        data-type="Debit"
                        data-ledger="Site Petty Cash Advance"
                        data-description="Labor camp drinking water & tea provisions"
                        data-contractor="Local Supplier"
                        data-amount="3200">
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark">21-07-2026</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark">Skyline Premium Residences</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Site Refreshments &amp; Admin</span>
                            <span class="text-muted" style="font-size:11px;">
                                Labor camp drinking water &amp; tea provisions
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-dark">Local Supplier</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="text-muted">—</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold" style="color:#c0392b;">$3,200</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-cash-flow-btn"
                                        title="Edit"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-cash-flow-btn"
                                        title="Delete"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 4: Debit --}}
                    <tr class="cash-flow-row"
                        data-date="20-07-2026"
                        data-project="Coastal Expressway Bridge"
                        data-type="Debit"
                        data-ledger="Site Petty Cash Advance"
                        data-description="High-vis jackets & helmets emergency batch"
                        data-contractor="Safety Store"
                        data-amount="8900">
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark">20-07-2026</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark">Coastal Expressway Bridge</span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Safety Equipment Purchase</span>
                            <span class="text-muted" style="font-size:11px;">
                                High-vis jackets &amp; helmets emergency batch
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-dark">Safety Store</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="text-muted">—</span>
                        </td>
                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold" style="color:#c0392b;">$8,900</span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-cash-flow-btn"
                                        title="Edit"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-cash-flow-btn"
                                        title="Delete"
                                        style="font-size: 18px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>

        <div class="card-footer bg-white border-top d-flex justify-content-end align-items-center px-4 py-3">
            <span class="text-muted small fw-semibold me-3">
                Total Logged:
            </span>
            <span class="text-dark fw-bold" style="font-size: 15px;">$91,600</span>
        </div>
    </div>

</div>

{{-- ============================================================= --}}
{{-- CREATE CASH FLOW MODAL --}}
{{-- ============================================================= --}}
<div class="modal fade" id="createCashFlowModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-cash-multiple text-primary" style="font-size: 20px;"></i>
                    <h5 class="modal-title fw-bold mb-0" style="font-size: 15px;">
                        Create Cash Flow Entry
                    </h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body pt-3">
                <form id="createCashFlowForm">

                    <div class="row g-3 mb-3">
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">
                                Date <span class="text-danger">*</span>
                            </label>
                            <input type="date"
                                   class="form-control form-control-sm"
                                   id="createCfDate"
                                   value="2026-09-16">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label fw-semibold small">
                                Project Site <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="createCfProject">
                                <option selected>Chennai Metro Phase 2 - Corridor 4</option>
                                <option>Coastal Expressway Bridge</option>
                                <option>Metro Line Extension - Phase 3</option>
                                <option>Skyline Premium Residences</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Type <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="createCfType">
                                <option selected>Credit</option>
                                <option>Debit</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Ledger / Purpose <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="createCfLedgerHead">
                                <option selected>Select Ledger Head</option>
                                <option>Site Petty Cash Advance</option>
                                <option>Vendor Material Supply</option>
                                <option>Subcontractor RA Payout</option>
                                <option>Client RA Bill Collection</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Contractor / Recipient <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="createCfContractor">
                                <option selected>Select Contractor / Recipient</option>
                                <option>Indian Oil Bunk</option>
                                <option>Local Supplier</option>
                                <option>Safety Store</option>
                                <option>Vanguard Earthmovers</option>
                                <option>NHAI Project Authority</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-8">
                            <label class="form-label fw-semibold small">
                                Description <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="createCfDescription"
                                   placeholder="e.g. Emergency diesel purchase">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Amount ($) <span class="text-danger">*</span>
                            </label>
                            <input type="number"
                                   class="form-control form-control-sm"
                                   id="createCfAmount"
                                   value="0"
                                   step="0.01">
                        </div>
                    </div>

                </form>
            </div>

            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm px-4" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button"
                        class="btn btn-primary btn-sm px-4 d-flex align-items-center gap-1"
                        id="createCfSubmitBtn">
                    <i class="mdi mdi-plus"></i>
                    Create Cash Flow Entry
                </button>
            </div>

        </div>
    </div>
</div>


<div class="modal fade" id="editCashFlowModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-cash-multiple text-primary" style="font-size: 20px;"></i>
                    <h5 class="modal-title fw-bold mb-0" style="font-size: 15px;">
                        Edit Cash Flow Entry
                    </h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body pt-3">
                <form id="editCashFlowForm">

                    <div class="row g-3 mb-3">
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">
                                Date <span class="text-danger">*</span>
                            </label>
                            <input type="date"
                                   class="form-control form-control-sm"
                                   id="editCfDate">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label fw-semibold small">
                                Project Site <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="editCfProject">
                                <option>Chennai Metro Phase 2 - Corridor 4</option>
                                <option>Coastal Expressway Bridge</option>
                                <option>Metro Line Extension - Phase 3</option>
                                <option>Skyline Premium Residences</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Type <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="editCfType">
                                <option>Credit</option>
                                <option>Debit</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Ledger / Purpose <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="editCfLedgerHead">
                                <option>Site Petty Cash Advance</option>
                                <option>Vendor Material Supply</option>
                                <option>Subcontractor RA Payout</option>
                                <option>Client RA Bill Collection</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Contractor / Recipient <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="editCfContractor">
                                <option>Indian Oil Bunk</option>
                                <option>Local Supplier</option>
                                <option>Safety Store</option>
                                <option>Vanguard Earthmovers</option>
                                <option>NHAI Project Authority</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-8">
                            <label class="form-label fw-semibold small">
                                Description <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="editCfDescription">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Amount ($) <span class="text-danger">*</span>
                            </label>
                            <input type="number"
                                   class="form-control form-control-sm"
                                   id="editCfAmount"
                                   step="0.01">
                        </div>
                    </div>

                </form>
            </div>

            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm px-4" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button"
                        class="btn btn-primary btn-sm px-4 d-flex align-items-center gap-1"
                        id="editCfSubmitBtn">
                    <i class="mdi mdi-check"></i>
                    Update Cash Flow Entry
                </button>
            </div>

        </div>
    </div>
</div>

<style>

    .settings-tabs-wrapper {
        width: 700px;
        max-width: 100%;
        min-width: 0;
        flex: 1 1 700px;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 100%;
        min-width: 0;
    }

    .settings-tabs-track {
        display: flex;
        align-items: center;
        gap: .5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 4px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tabs-track .settings-tab-pill,
    a.settings-tab-pill {
        white-space: nowrap;
        padding: .5rem 1.1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: .82rem;
        font-weight: 600;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .settings-tabs-track .settings-tab-pill:hover,
    a.settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
        text-decoration: none;
    }

    .settings-tabs-track .settings-tab-pill.active,
    a.settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tabs-track .settings-tab-pill.active:hover,
    a.settings-tab-pill.active:hover {
        background: #124f7c;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
        cursor: pointer;
        transition: all .15s ease;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }

    /* ---------- Register header ---------- */
    .cf-register-header {
        display: flex;
        flex-wrap: nowrap;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        width: 100%;
    }

    .cf-register-title {
        flex: 0 1 auto;
        min-width: 0;
    }

    .cf-register-title h6,
    .cf-register-title p {
        white-space: nowrap;
    }

    .cf-register-filters {
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 0 1 auto;
        flex-wrap: nowrap;
        min-width: 0;
    }

    .cf-filter-btn {
        white-space: nowrap;
        flex-shrink: 0;
    }

    /* ---------- Table Filter Section ---------- */
    .cf-table-filters .form-control-sm,
    .cf-table-filters .form-select-sm,
    .cf-table-filters .input-group-sm .form-control,
    .cf-table-filters .input-group-sm .input-group-text {
        font-size: 12.5px;
        min-height: 38px;
        border-radius: 7px;
    }

    .cf-table-filters .input-group-sm .input-group-text {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
    }

    .cf-table-filters .input-group-sm .form-control {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
    }

    .cf-table-filters .form-control-sm:focus,
    .cf-table-filters .form-select-sm:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    @media (max-width: 992px) {
        .cf-register-header {
            flex-wrap: wrap;
        }
        .cf-register-title h6,
        .cf-register-title p {
            white-space: normal;
        }
        .cf-register-filters {
            flex-wrap: wrap;
            width: 100%;
        }
        .cf-filter-btn {
            flex: 1 1 100%;
            justify-content: center;
        }
    }

    .table > :not(caption) > * > * {
        border-bottom-width: 1px;
        border-color: #eef0f4;
    }

    .table thead th {
        border-bottom: 1px solid #eef0f4 !important;
    }

    .form-select-sm,
    .input-group-sm .form-control,
    .input-group-sm .form-select {
        font-size: 12px;
    }

    .form-select-sm {
        min-height: 38px;
    }

    .form-control-sm {
        min-height: 38px;
    }

    .card {
        border: 1px solid #eef0f4 !important;
    }

    .text-primary {
        color: #16659E !important;
    }

    .bg-primary {
        background-color: #16659E !important;
    }

    .btn-primary {
        background-color: #16659E !important;
        border-color: #16659E !important;
    }

    .btn-primary:hover {
        background-color: #124f7c !important;
        border-color: #124f7c !important;
    }

    .btn-light {
        background-color: #f1f3f5;
        border-color: #f1f3f5;
        color: #495057;
    }

    .btn-light:hover {
        background-color: #e2e6ea;
        border-color: #e2e6ea;
        color: #212529;
    }

    .btn-link.text-primary:hover {
        color: #124f7c !important;
    }

    /* ---------- Modal Common ---------- */
    #createCashFlowModal .modal-dialog,
    #editCashFlowModal .modal-dialog {
        max-width: 820px;
        width: calc(100% - 40px);
        margin: 1.75rem auto;
    }

    #createCashFlowModal .modal-content,
    #editCashFlowModal .modal-content {
        border-radius: 12px;
        max-height: calc(100vh - 3.5rem);
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    #createCashFlowModal .modal-header,
    #editCashFlowModal .modal-header {
        padding: 20px 28px 8px 28px;
        flex-shrink: 0;
    }

    #createCashFlowModal .modal-body,
    #editCashFlowModal .modal-body {
        padding: 12px 28px 8px 28px;
        overflow-y: auto;
        flex-grow: 1;
    }

    #createCashFlowModal .modal-footer,
    #editCashFlowModal .modal-footer {
        padding: 8px 28px 22px 28px;
        flex-shrink: 0;
    }

    #createCashFlowModal .form-label,
    #editCashFlowModal .form-label {
        font-size: 12.5px;
        color: #1a2332;
        margin-bottom: 6px;
    }

    #createCashFlowModal .form-control-sm,
    #createCashFlowModal .form-select-sm,
    #editCashFlowModal .form-control-sm,
    #editCashFlowModal .form-select-sm {
        font-size: 12.5px;
        padding: 8px 12px;
        border-radius: 8px;
        border: 1px solid #d0d5dd;
        min-height: 40px;
        width: 100%;
    }

    #createCashFlowModal .form-control-sm:focus,
    #createCashFlowModal .form-select-sm:focus,
    #editCashFlowModal .form-control-sm:focus,
    #editCashFlowModal .form-select-sm:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    @media (max-width: 992px) {
        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 700px;
        }
        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }
    }

    @media (max-width: 768px) {
        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 100%;
        }
        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }
    }

</style>

<script>

document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Tabs Scroll ---------- */
    const tabsTrack = document.getElementById('ledgerTabsTrack');
    const scrollLeftBtn = document.getElementById('ledgerTabScrollLeft');
    const scrollRightBtn = document.getElementById('ledgerTabScrollRight');

    if (scrollLeftBtn && tabsTrack) {
        scrollLeftBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (scrollRightBtn && tabsTrack) {
        scrollRightBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

    /* ---------- Create Modal References ---------- */
    const createModalEl      = document.getElementById('createCashFlowModal');
    const createCfDate       = document.getElementById('createCfDate');
    const createCfProject    = document.getElementById('createCfProject');
    const createCfType       = document.getElementById('createCfType');
    const createCfLedgerHead = document.getElementById('createCfLedgerHead');
    const createCfContractor = document.getElementById('createCfContractor');
    const createCfDescription= document.getElementById('createCfDescription');
    const createCfAmount     = document.getElementById('createCfAmount');
    const createCfSubmitBtn  = document.getElementById('createCfSubmitBtn');

    /* ---------- Edit Modal References ---------- */
    const editModalEl      = document.getElementById('editCashFlowModal');
    const editCfDate       = document.getElementById('editCfDate');
    const editCfProject    = document.getElementById('editCfProject');
    const editCfType       = document.getElementById('editCfType');
    const editCfLedgerHead = document.getElementById('editCfLedgerHead');
    const editCfContractor = document.getElementById('editCfContractor');
    const editCfDescription= document.getElementById('editCfDescription');
    const editCfAmount     = document.getElementById('editCfAmount');
    const editCfSubmitBtn  = document.getElementById('editCfSubmitBtn');

    let editingRow = null;
    let voucherCounter = 7784;

    /* ============================================================= */
    /* ---------- PERSISTENCE: localStorage helpers ---------- */
    /* ============================================================= */
    const CF_STORAGE_KEY = 'cash_flow_rows_v1';

    /* Save all current rows to localStorage */
    function saveCashFlowRows() {
        const rows = [];
        document.querySelectorAll('#cashFlowBody .cash-flow-row').forEach(function (row) {
            rows.push({
                voucher:     row.dataset.voucher     || '',
                date:        row.dataset.date        || '',
                project:     row.dataset.project     || '',
                type:        row.dataset.type        || '',
                ledger:      row.dataset.ledger      || '',
                description: row.dataset.description || '',
                contractor:  row.dataset.contractor  || '',
                amount:      row.dataset.amount      || '0'
            });
        });
        localStorage.setItem(CF_STORAGE_KEY, JSON.stringify(rows));
    }

    /* Build a table row from a data object */
    function buildCashFlowRow(data) {
        const amount = parseFloat(data.amount || 0);

        const creditHtml = (data.type === 'Credit')
            ? '<span class="fw-bold" style="color:#0f7a4a;">$' + amount.toLocaleString() + '</span>'
            : '<span class="text-muted">—</span>';

        const debitHtml = (data.type === 'Debit')
            ? '<span class="fw-bold" style="color:#c0392b;">$' + amount.toLocaleString() + '</span>'
            : '<span class="text-muted">—</span>';

        const tr = document.createElement('tr');
        tr.className = 'border-bottom cash-flow-row';
        tr.dataset.voucher     = data.voucher     || '';
        tr.dataset.date        = data.date        || '';
        tr.dataset.project     = data.project     || '';
        tr.dataset.type        = data.type        || '';
        tr.dataset.ledger      = data.ledger      || '';
        tr.dataset.description = data.description || '';
        tr.dataset.contractor  = data.contractor  || '';
        tr.dataset.amount      = data.amount      || 0;

        tr.innerHTML =
            '<td class="px-4 py-3">' +
                '<span class="fw-semibold text-dark">' + (data.date || '') + '</span>' +
                '<span class="text-muted d-block" style="font-size:11px;">' + (data.voucher || '') + '</span>' +
            '</td>' +
            '<td class="px-4 py-3">' +
                '<span class="fw-semibold text-dark">' + (data.project || '') + '</span>' +
            '</td>' +
            '<td class="px-4 py-3">' +
                '<span class="fw-semibold text-dark d-block">' + (data.ledger || '') + '</span>' +
                '<span class="text-muted" style="font-size:11px;">' + (data.description || '') + '</span>' +
            '</td>' +
            '<td class="px-4 py-3">' +
                '<span class="text-dark">' + (data.contractor || '') + '</span>' +
            '</td>' +
            '<td class="px-4 py-3 text-end">' + creditHtml + '</td>' +
            '<td class="px-4 py-3 text-end">' + debitHtml + '</td>' +
            '<td class="px-4 py-3 text-center">' +
                '<div class="d-inline-flex align-items-center gap-1">' +
                    '<button type="button" class="btn btn-link p-0 text-primary edit-cash-flow-btn" title="Edit" style="font-size: 18px; line-height: 1;">' +
                        '<i class="mdi mdi-pencil-outline"></i>' +
                    '</button>' +
                    '<button type="button" class="btn btn-link p-0 text-muted delete-cash-flow-btn" title="Delete" style="font-size: 18px; line-height: 1;">' +
                        '<i class="mdi mdi-delete-outline"></i>' +
                    '</button>' +
                '</div>' +
            '</td>';

        return tr;
    }

    /* ---------- Reset Create Form ---------- */
    function resetCreateForm() {
        if (createCfDate)        createCfDate.value = '2026-09-16';
        if (createCfProject)     createCfProject.selectedIndex = 0;
        if (createCfType)        createCfType.selectedIndex = 0;
        if (createCfLedgerHead)  createCfLedgerHead.selectedIndex = 0;
        if (createCfContractor)  createCfContractor.selectedIndex = 0;
        if (createCfDescription) createCfDescription.value = '';
        if (createCfAmount)      createCfAmount.value = 0;
    }

    /* ---------- Create Button (opens modal & resets) ---------- */
    const createEntryBtn = document.getElementById('cfCreateEntryBtn');
    if (createEntryBtn && createModalEl) {
        createEntryBtn.addEventListener('click', function () {
            resetCreateForm();
            bootstrap.Modal.getOrCreateInstance(createModalEl).show();
        });
    }

    /* ---------- Create Submit ---------- */
    if (createCfSubmitBtn && createModalEl) {
        createCfSubmitBtn.addEventListener('click', function () {

            const date        = createCfDate.value;
            const project     = createCfProject.value;
            const type        = createCfType.value;
            const ledger      = createCfLedgerHead.value;
            const contractor  = createCfContractor.value;
            const description = createCfDescription.value;
            const amount      = parseFloat(createCfAmount.value || 0);

            if (!date || !project || !ledger || !contractor || !description || amount <= 0) {
                alert('Please fill all required fields with a valid amount.');
                return;
            }

            const voucher = 'VCH-' + (voucherCounter++);

            /* Build new row */
            const newRow = document.createElement('tr');
            newRow.className = 'border-bottom cash-flow-row';
            newRow.dataset.voucher     = voucher;
            newRow.dataset.date        = date;
            newRow.dataset.project     = project;
            newRow.dataset.type        = type;
            newRow.dataset.ledger      = ledger;
            newRow.dataset.description = description;
            newRow.dataset.contractor  = contractor;
            newRow.dataset.amount      = amount;

            const creditHtml = (type === 'Credit')
                ? '<span class="fw-bold" style="color:#0f7a4a;">$' + amount.toLocaleString() + '</span>'
                : '<span class="text-muted">—</span>';

            const debitHtml = (type === 'Debit')
                ? '<span class="fw-bold" style="color:#c0392b;">$' + amount.toLocaleString() + '</span>'
                : '<span class="text-muted">—</span>';

            newRow.innerHTML =
                '<td class="px-4 py-3">' +
                    '<span class="fw-semibold text-dark">' + date + '</span>' +
                    '<span class="text-muted d-block" style="font-size:11px;">' + voucher + '</span>' +
                '</td>' +
                '<td class="px-4 py-3">' +
                    '<span class="fw-semibold text-dark">' + project + '</span>' +
                '</td>' +
                '<td class="px-4 py-3">' +
                    '<span class="fw-semibold text-dark d-block">' + ledger + '</span>' +
                    '<span class="text-muted" style="font-size:11px;">' + description + '</span>' +
                '</td>' +
                '<td class="px-4 py-3">' +
                    '<span class="text-dark">' + contractor + '</span>' +
                '</td>' +
                '<td class="px-4 py-3 text-end">' + creditHtml + '</td>' +
                '<td class="px-4 py-3 text-end">' + debitHtml + '</td>' +
                '<td class="px-4 py-3 text-center">' +
                    '<div class="d-inline-flex align-items-center gap-1">' +
                        '<button type="button" class="btn btn-link p-0 text-primary edit-cash-flow-btn" title="Edit" style="font-size: 18px; line-height: 1;">' +
                            '<i class="mdi mdi-pencil-outline"></i>' +
                        '</button>' +
                        '<button type="button" class="btn btn-link p-0 text-muted delete-cash-flow-btn" title="Delete" style="font-size: 18px; line-height: 1;">' +
                            '<i class="mdi mdi-delete-outline"></i>' +
                        '</button>' +
                    '</div>' +
                '</td>';

            document.getElementById('cashFlowBody').appendChild(newRow);

            /* Bind events to new row */
            bindRowEvents(newRow);

            /* 🔽 PERSIST after create */
            saveCashFlowRows();

            bootstrap.Modal.getOrCreateInstance(createModalEl).hide();
        });
    }

    /* ---------- Bind Edit/Delete to a row ---------- */
    function bindRowEvents(row) {
        const editBtn   = row.querySelector('.edit-cash-flow-btn');
        const deleteBtn = row.querySelector('.delete-cash-flow-btn');

        if (editBtn) {
            editBtn.addEventListener('click', function () {
                editingRow = row;
                const data = row.dataset;

                if (editCfDate)        editCfDate.value        = data.date        || '';
                if (editCfProject)     editCfProject.value     = data.project     || '';
                if (editCfType)        editCfType.value        = data.type        || 'Debit';
                if (editCfLedgerHead)  editCfLedgerHead.value  = data.ledger      || '';
                if (editCfContractor)  editCfContractor.value  = data.contractor  || '';
                if (editCfDescription) editCfDescription.value = data.description || '';
                if (editCfAmount)      editCfAmount.value      = data.amount      || 0;

                bootstrap.Modal.getOrCreateInstance(editModalEl).show();
            });
        }

        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                const voucher = row.dataset.voucher || 'this entry';
                if (confirm('Are you sure you want to delete ' + voucher + '?')) {
                    row.remove();

                    /* 🔽 PERSIST after delete */
                    saveCashFlowRows();
                }
            });
        }
    }

    /* ---------- Bind Existing Rows ---------- */
    document.querySelectorAll('.cash-flow-row').forEach(function (row) {
        bindRowEvents(row);
    });

    /* ---------- Edit Modal Submit ---------- */
    if (editCfSubmitBtn && editModalEl) {
        editCfSubmitBtn.addEventListener('click', function () {
            if (!editingRow) return;

            const data = editingRow.dataset;

            const newDate        = editCfDate.value;
            const newProject     = editCfProject.value;
            const newType        = editCfType.value;
            const newLedger      = editCfLedgerHead.value;
            const newContractor  = editCfContractor.value;
            const newDescription = editCfDescription.value;
            const newAmount      = parseFloat(editCfAmount.value || 0);

            /* Update data attributes */
            editingRow.dataset.date        = newDate;
            editingRow.dataset.project     = newProject;
            editingRow.dataset.type        = newType;
            editingRow.dataset.ledger      = newLedger;
            editingRow.dataset.contractor  = newContractor;
            editingRow.dataset.description = newDescription;
            editingRow.dataset.amount      = newAmount;

            /* Update visible cells */
            const cells = editingRow.querySelectorAll('td');

            cells[0].innerHTML =
                '<span class="fw-semibold text-dark">' + newDate + '</span>' +
                '<span class="text-muted d-block" style="font-size:11px;">' + (data.voucher || '') + '</span>';

            cells[1].innerHTML =
                '<span class="fw-semibold text-dark">' + newProject + '</span>';

            cells[2].innerHTML =
                '<span class="fw-semibold text-dark d-block">' + newLedger + '</span>' +
                '<span class="text-muted" style="font-size:11px;">' + newDescription + '</span>';

            cells[3].innerHTML =
                '<span class="text-dark">' + newContractor + '</span>';

            if (newType === 'Credit') {
                cells[4].innerHTML =
                    '<span class="fw-bold" style="color:#0f7a4a;">$' +
                    newAmount.toLocaleString() + '</span>';
            } else {
                cells[4].innerHTML = '<span class="text-muted">—</span>';
            }

            if (newType === 'Debit') {
                cells[5].innerHTML =
                    '<span class="fw-bold" style="color:#c0392b;">$' +
                    newAmount.toLocaleString() + '</span>';
            } else {
                cells[5].innerHTML = '<span class="text-muted">—</span>';
            }

            /* 🔽 PERSIST after edit */
            saveCashFlowRows();

            bootstrap.Modal.getOrCreateInstance(editModalEl).hide();
            editingRow = null;
        });
    }

    /* ============================================================= */
    /* ---------- TABLE FILTERS (Search + Project + Type) ---------- */
    /* ============================================================= */
    const cfSearchInput   = document.getElementById('cfSearchInput');
    const cfProjectFilter = document.getElementById('cfProjectFilter');
    const cfTypeFilter    = document.getElementById('cfTypeFilter');

    function applyCashFlowFilters() {
        const search  = (cfSearchInput   ? cfSearchInput.value   : '').toLowerCase().trim();
        const project = (cfProjectFilter ? cfProjectFilter.value : '').toLowerCase().trim();
        const type    = (cfTypeFilter    ? cfTypeFilter.value    : '').toLowerCase().trim();

        document.querySelectorAll('#cashFlowBody .cash-flow-row').forEach(function (row) {
            const rowProject = (row.dataset.project || '').toLowerCase();
            const rowType    = (row.dataset.type    || '').toLowerCase();
            const rowText    = row.innerText.toLowerCase();

            const matchSearch  = (search  === '' || rowText.includes(search));
            const matchProject = (project === '' || rowProject === project);
            const matchType    = (type    === '' || rowType    === type);

            row.style.display = (matchSearch && matchProject && matchType) ? '' : 'none';
        });
    }

    if (cfSearchInput)   cfSearchInput.addEventListener('input',  applyCashFlowFilters);
    if (cfProjectFilter) cfProjectFilter.addEventListener('change', applyCashFlowFilters);
    if (cfTypeFilter)    cfTypeFilter.addEventListener('change', applyCashFlowFilters);

    /* ============================================================= */
    /* ---------- LOAD SAVED ROWS ON PAGE LOAD ---------- */
    /* ============================================================= */
    (function loadCashFlowRowsFromStorage() {
        const stored = localStorage.getItem(CF_STORAGE_KEY);
        if (!stored) return;              // first visit → keep Blade-rendered rows

        let rows;
        try { rows = JSON.parse(stored); } catch (e) { return; }
        if (!Array.isArray(rows)) return;

        const body = document.getElementById('cashFlowBody');
        if (!body) return;

        body.innerHTML = '';              // clear server-rendered rows
        rows.forEach(function (data) {
            const tr = buildCashFlowRow(data);
            body.appendChild(tr);
            bindRowEvents(tr);
        });
    })();

});

 /* ============================================================= */
    /* ---------- EXPORT CSV ---------- */
    /* ============================================================= */
    const exportCsvBtn = document.getElementById('holdExportCsvBtn');
    if (exportCsvBtn) {
        exportCsvBtn.addEventListener('click', function () {
            const headers = [
                'Ref ID', 'Guarantee #', 'Bank Account', 'Hold Category',
                'Project Site', 'Purpose', 'Hold Amount', 'Interest',
                'Maturity', 'Status'
            ];

            const csvRows = [headers.join(',')];

            document.querySelectorAll('#holdTable tbody .hold-row').forEach(function (row) {
                if (row.style.display === 'none') return;

                const cells = row.querySelectorAll('td');
                const refId = (cells[0].innerText || '').split('\n')[0].trim();
                const refNo = (cells[0].innerText || '').split('\n')[1]?.trim() || '';
                const bank  = cells[1].innerText.trim();
                const cat   = cells[2].innerText.trim();
                const proj  = cells[3].innerText.trim();
                const purp  = cells[4].innerText.trim().replace(/\s+/g, ' ').replace(/,/g, ';');
                const amt   = cells[5].innerText.trim();
                const rate  = cells[6].innerText.trim();
                const mat   = cells[7].innerText.trim();
                const stat  = cells[8].querySelector('select')?.value || cells[8].innerText.trim();

                csvRows.push([
                    '"' + refId + '"',
                    '"' + refNo + '"',
                    '"' + bank + '"',
                    '"' + cat + '"',
                    '"' + proj + '"',
                    '"' + purp + '"',
                    '"' + amt + '"',
                    '"' + rate + '"',
                    '"' + mat + '"',
                    '"' + stat + '"'
                ].join(','));
            });

            const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const url  = URL.createObjectURL(blob);
            const a    = document.createElement('a');
            a.href     = url;
            a.download = 'bank_hold_entries_' + new Date().toISOString().slice(0,10) + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }


</script>

@endsection
