@extends('layouts/contentNavbarLayout')

@section('title', 'Bank Ledger Entry')

@section('content')

<div class="container-fluid">

    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex justify-content-between align-items-center flex-nowrap gap-3">

                <div class="flex-shrink-0" style="min-width: 0;">
                    <h5 class="fw-bold mb-1">Central Bank Ledger Entries</h5>

                    <p class="text-muted small mb-0">
                        Comprehensive log of bank transactions with project, ledger account head, and contractor/vendor mappings
                    </p>
                </div>

                <div class="settings-tabs-wrapper">

                    <div class="d-flex align-items-center gap-2">

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="ledgerTabScrollLeft">
                            <i class="mdi mdi-chevron-left"></i>
                        </button>

                        <div class="settings-tabs-scroller">

                            <div class="settings-tabs-track" id="ledgerTabsTrack">

                                  <a href="{{ route('accounts.banking') }}"
                                        class="settings-tab-pill {{ request()->routeIs('accounts.banking') ? 'active' : '' }}">
                                   Bank Ledger Entry
                                  </a>

                                 <a href="{{ route('accounts.ledger') }}"
                                    class="settings-tab-pill {{ request()->routeIs('accounts.ledger') ? 'active' : '' }}">
                                  Settings / Ledger Heads
                                </a>

                                 <a href="{{ route('accounts.bank.hold') }}"
                                class="settings-tab-pill {{ request()->routeIs('accounts.bank.hold') ? 'active' : '' }}">
                                 Bank Hold Amount
                                 </a>

                                 <a href="{{ route('accounts.cashflow') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.cashflow') ? 'active' : '' }}">
                                    Cash Flow Entry
                                 </a>

                                <a href="{{ route('accounts.creditcard') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.creditcard') ? 'active' : '' }}">
                                    Credit Card Utilization
                                </a>

                                <a href="{{ route('accounts.mobilebill') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.mobilebill') ? 'active' : '' }}">
                                    Mobile Bill Entry
                                </a>

                            </div>

                            </div>

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="ledgerTabScrollRight">
                            <i class="mdi mdi-chevron-right"></i>
                        </button>

                    </div>

                </div>

            </div>

        </div>
    </div>

    <div class="row g-3 mb-4">

        <div class="col-12 col-md-6 col-lg-3">

            <div class="card shadow-sm border-0 rounded-3 h-100">

                <div class="card-body p-3">

                    <span class="text-muted small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        TOTAL BANK INFLOW (CREDITS)
                    </span>

                    <div class="d-flex align-items-center gap-1 mt-2">

                        <i class="mdi mdi-trending-up text-success fs-5"></i>

                        <span class="fw-bold text-success fs-4">
                            +$1,250,000
                        </span>

                    </div>

                    <span class="text-muted small d-block mt-1">
                        Client receipts & deposits
                    </span>

                </div>

            </div>

        </div>

        <div class="col-12 col-md-6 col-lg-3">

            <div class="card shadow-sm border-0 rounded-3 h-100">

                <div class="card-body p-3">

                    <span class="text-muted small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        TOTAL BANK OUTFLOW (DEBITS)
                    </span>

                    <div class="d-flex align-items-center gap-1 mt-2">

                        <i class="mdi mdi-trending-down text-danger fs-5"></i>

                        <span class="fw-bold text-danger fs-4">
                            -$807,400
                        </span>

                    </div>

                    <span class="text-muted small d-block mt-1">
                        Subcontractor & vendor payouts
                    </span>

                </div>

            </div>

        </div>

        <div class="col-12 col-md-6 col-lg-3">

            <div class="card shadow-sm border-0 rounded-3 h-100">

                <div class="card-body p-3">

                    <span class="text-muted small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        NET BANK LIQUIDITY FLOW
                    </span>

                    <div class="d-flex align-items-center gap-1 mt-2">

                        <span class="fw-bold text-primary fs-4">
                            +$442,600
                        </span>

                    </div>

                    <span class="text-muted small d-block mt-1">
                        Reconciled net period balance
                    </span>

                </div>

            </div>

        </div>

        <div class="col-12 col-md-6 col-lg-3">

            <div class="card shadow-sm border-0 rounded-3 h-100">

                <div class="card-body p-3">

                    <span class="text-muted small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        LOGGED LEDGER ENTRIES
                    </span>

                    <div class="d-flex align-items-baseline gap-1 mt-2">

                        <span class="fw-bold fs-4">
                            5
                        </span>

                        <span class="text-muted small">
                            / 5 total
                        </span>

                    </div>

                    <span class="text-success small fw-semibold d-block mt-1">
                        100% Audit Reconciled
                    </span>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body px-4 py-3">

            <div class="row g-2 align-items-center">

                <div class="col-12 col-md-2 col-lg-2">

                    <div class="input-group input-group-sm">

                        <span class="input-group-text bg-white">
                            <i class="mdi mdi-magnify text-muted"></i>
                        </span>

                        <input type="text"
                               class="form-control"
                               id="ledgerSearch"
                               placeholder="Search ID, contractor, ref...">

                    </div>

                </div>

                <div class="col-6 col-md-1">

                    <select class="form-select form-select-sm"
                            id="ledgerProjectFilter">

                        <option value="">
                            All Projects
                        </option>

                        <option value="Coastal Expressway Bridge">
                            Coastal Expressway Bridge
                        </option>

                        <option value="Metro Line Extension - Phase 3">
                            Metro Line Extension - Phase 3
                        </option>

                        <option value="Skyline Premium Residences">
                            Skyline Premium Residences
                        </option>

                    </select>

                </div>

                <div class="col-6 col-md-2">

                    <select class="form-select form-select-sm"
                            id="ledgerBankFilter">

                        <option value="">
                            All Bank Accounts
                        </option>

                        <option value="HDFC Escrow Account">
                            HDFC Escrow Account
                        </option>

                        <option value="SBI Commercial">
                            SBI Commercial
                        </option>

                        <option value="ICICI CapEx Operations">
                            ICICI CapEx Operations
                        </option>

                        <option value="Axis Corporate Account">
                            Axis Corporate Account
                        </option>

                    </select>

                </div>

                <div class="col-6 col-md-2">

                    <select class="form-select form-select-sm"
                            id="ledgerHeadFilter">

                        <option value="">
                            All Ledger Accounts
                        </option>

                        <option value="Client RA Bill Collection">
                            Client RA Bill Collection
                        </option>

                        <option value="Vendor Material Supply">
                            Vendor Material Supply
                        </option>

                        <option value="Site Petty Cash Advance">
                            Site Petty Cash Advance
                        </option>

                        <option value="Subcontractor RA Payout">
                            Subcontractor RA Payout
                        </option>

                    </select>

                </div>

                <div class="col-6 col-md-2">

                    <select class="form-select form-select-sm"
                            id="ledgerTypeFilter">

                        <option value="">
                            All Tx Types (Credit/Debit)
                        </option>

                        <option value="Credit">
                            Credit
                        </option>

                        <option value="Debit">
                            Debit
                        </option>

                    </select>

                </div>

                <div class="col-12 col-md-auto d-flex align-items-center gap-2">

                    <button type="button"
                            class="btn btn-outline-secondary btn-sm"
                            id="exportLedgerCsv">

                        <i class="mdi mdi-download me-1"></i>

                        Export CSV

                    </button>

                    <button type="button"
                            class="btn btn-primary btn-sm"
                            id="logBankEntryBtn"
                            data-bs-toggle="modal"
                            data-bs-target="#logBankEntryModal">

                        <i class="mdi mdi-plus me-1"></i>

                        Log Bank Entry

                    </button>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow-sm border-0 rounded-3">

        <div class="table-responsive">

            <table class="table align-middle mb-0"
                   style="font-size: 12px;"
                   id="ledgerTable">

                <thead style="background: #f8f9fc;">

                    <tr>

                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            ENTRY ID & DATE
                        </th>

                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            BANK ACCOUNT
                        </th>

                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            PROJECT
                        </th>

                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            LEDGER HEAD & SUB-HEAD
                        </th>

                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            CONTRACTOR / PARTY
                        </th>

                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            MODE & TYPE
                        </th>

                        <th class="text-uppercase text-muted fw-bold border-0"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            REF UTR / PURPOSE
                        </th>

                        <th class="text-uppercase text-muted fw-bold border-0 text-end"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            AMOUNT ($)
                        </th>

                        <th class="text-uppercase text-muted fw-bold border-0 text-center"
                            style="font-size: 10px; letter-spacing: .04em; padding: 12px 16px;">
                            STATUS
                        </th>

                    </tr>

                </thead>

                <tbody>

                    <tr class="border-bottom">

                        <td class="px-4 py-3">
                            <span class="fw-bold text-dark d-block">BL-1001</span>
                            <span class="text-muted small">2026-07-22</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">HDFC Escrow Account</span>
                            <span class="text-muted small">582008089123</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-light text-primary border border-primary-subtle rounded-pill px-2 py-1">
                                <i class="mdi mdi-office-building-outline me-1"></i>
                                Coastal Expressway Bridge
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-primary text-white rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content;">
                                <i class="mdi mdi-bank-outline me-1"></i>
                                Client RA Bill Collection
                            </span>
                            <span class="text-muted small">
                                <i class="mdi mdi-tag-outline"></i>
                                Interim RA Bill Collection
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-1">
                                <i class="mdi mdi-account-outline text-muted"></i>
                                <span class="fw-semibold text-dark">National Highways</span>
                            </div>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-success-subtle text-success fw-bold rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content; font-size: 10px;">
                                RTGS
                            </span>
                            <span class="text-success small fw-semibold">(Credit)</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="text-dark d-block">Client RA Bill #04 Payment Received</span>
                            <span class="text-muted small">UTR: N183920250812</span>
                        </td>

                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold text-success">+$1,250,000</span>
                        </td>

                        <td class="px-4 py-3 text-center">
                            <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-1">
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Cleared
                            </span>
                        </td>

                    </tr>

                    <tr class="border-bottom">

                        <td class="px-4 py-3">
                            <span class="fw-bold text-dark d-block">BL-1002</span>
                            <span class="text-muted small">2026-07-21</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">SBI Commercial</span>
                            <span class="text-muted small">30981245801</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-light text-primary border border-primary-subtle rounded-pill px-2 py-1">
                                <i class="mdi mdi-office-building-outline me-1"></i>
                                Metro Line Extension - Phase 3
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-primary text-white rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content;">
                                <i class="mdi mdi-truck-outline me-1"></i>
                                Vendor Material Supply
                            </span>
                            <span class="text-muted small">
                                <i class="mdi mdi-tag-outline"></i>
                                TMT Rebar & Fe550D Steel Batch
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-1">
                                <i class="mdi mdi-account-outline text-muted"></i>
                                <span class="fw-semibold text-dark">Apex Steel Suppliers</span>
                            </div>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-danger-subtle text-danger fw-bold rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content; font-size: 10px;">
                                NEFT
                            </span>
                            <span class="text-danger small fw-semibold">(Debit)</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="text-dark d-block">Vendor Payment - TMT Rebar Fe550D Batch #4</span>
                            <span class="text-muted small">UTR: N183920250812</span>
                        </td>

                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold text-danger">-$345,000</span>
                        </td>

                        <td class="px-4 py-3 text-center">
                            <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-1">
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Cleared
                            </span>
                        </td>

                    </tr>

                    <tr class="border-bottom">

                        <td class="px-4 py-3">
                            <span class="fw-bold text-dark d-block">BL-1003</span>
                            <span class="text-muted small">2026-07-20</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">ICICI CapEx Operations</span>
                            <span class="text-muted small">000405481239</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-light text-primary border border-primary-subtle rounded-pill px-2 py-1">
                                <i class="mdi mdi-office-building-outline me-1"></i>
                                Metro Line Extension - Phase 3
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-primary text-white rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content;">
                                <i class="mdi mdi-cash-multiple me-1"></i>
                                Site Petty Cash Advance
                            </span>
                            <span class="text-muted small">
                                <i class="mdi mdi-tag-outline"></i>
                                Emergency Diesel & Machinery Fuel
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-1">
                                <i class="mdi mdi-account-outline text-muted"></i>
                                <span class="fw-semibold text-dark">Sri Lakshmi Earthmovers</span>
                            </div>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-danger-subtle text-danger fw-bold rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content; font-size: 10px;">
                                IMPS
                            </span>
                            <span class="text-danger small fw-semibold">(Debit)</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="text-dark d-block">Site Imprest Transfer for Emergency Fuel</span>
                            <span class="text-muted small">UTR: 309922850104</span>
                        </td>

                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold text-danger">-$85,000</span>
                        </td>

                        <td class="px-4 py-3 text-center">
                            <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-1">
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Cleared
                            </span>
                        </td>

                    </tr>

                    <tr class="border-bottom">

                        <td class="px-4 py-3">
                            <span class="fw-bold text-dark d-block">BL-1004</span>
                            <span class="text-muted small">2026-07-19</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">HDFC Escrow Account</span>
                            <span class="text-muted small">582008089123</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-light text-primary border border-primary-subtle rounded-pill px-2 py-1">
                                <i class="mdi mdi-office-building-outline me-1"></i>
                                Coastal Expressway Bridge
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-primary text-white rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content;">
                                <i class="mdi mdi-account-cash-outline me-1"></i>
                                Subcontractor RA Payout
                            </span>
                            <span class="text-muted small">
                                <i class="mdi mdi-tag-outline"></i>
                                Earthwork & Excavation Clearance
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-1">
                                <i class="mdi mdi-account-outline text-muted"></i>
                                <span class="fw-semibold text-dark">Vanguard Earthmovers</span>
                            </div>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-danger-subtle text-danger fw-bold rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content; font-size: 10px;">
                                EFT
                            </span>
                            <span class="text-danger small fw-semibold">(Debit)</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="text-dark d-block">Subcontractor RA #03 Earthwork Clearance</span>
                            <span class="text-muted small">UTR: 877775205120</span>
                        </td>

                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold text-danger">-$210,000</span>
                        </td>

                        <td class="px-4 py-3 text-center">
                            <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-1">
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Cleared
                            </span>
                        </td>

                    </tr>

                    <tr>

                        <td class="px-4 py-3">
                            <span class="fw-bold text-dark d-block">BL-1005</span>
                            <span class="text-muted small">2026-07-18</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="fw-semibold text-dark d-block">Axis Corporate Account</span>
                            <span class="text-muted small">918020081198</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-light text-primary border border-primary-subtle rounded-pill px-2 py-1">
                                <i class="mdi mdi-office-building-outline me-1"></i>
                                Skyline Premium Residences
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-primary text-white rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content;">
                                <i class="mdi mdi-account-cash-outline me-1"></i>
                                Subcontractor RA Payout
                            </span>
                            <span class="text-muted small">
                                <i class="mdi mdi-tag-outline"></i>
                                MEP & Electrical Piping
                            </span>
                        </td>

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-1">
                                <i class="mdi mdi-account-outline text-muted"></i>
                                <span class="fw-semibold text-dark">SafeGuard Electricals</span>
                            </div>
                        </td>

                        <td class="px-4 py-3">
                            <span class="badge bg-danger-subtle text-danger fw-bold rounded-pill px-2 py-1 d-block mb-1" style="width: fit-content; font-size: 10px;">
                                NEFT
                            </span>
                            <span class="text-danger small fw-semibold">(Debit)</span>
                        </td>

                        <td class="px-4 py-3">
                            <span class="text-dark d-block">MEP Electrical Piping RA #02 Final Settlement</span>
                            <span class="text-muted small">UTR: N87772008188</span>
                        </td>

                        <td class="px-4 py-3 text-end">
                            <span class="fw-bold text-danger">-$167,400</span>
                        </td>

                        <td class="px-4 py-3 text-center">
                            <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-1">
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Cleared
                            </span>
                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

    </div>

</div>

<div class="modal fade"
     id="logBankEntryModal"
     tabindex="-1"
     aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">

                <div>

                    <h5 class="modal-title fw-bold mb-1">

                        <i class="mdi mdi-book-open-page-variant-outline text-primary me-1"></i>

                        Log Central Bank Ledger Entry

                    </h5>

                    <p class="text-muted small mb-0">

                        Record bank transaction with project, ledger account head, and contractor links

                    </p>

                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                </button>

            </div>

            <div class="modal-body pt-3">

                <form id="logBankEntryForm">

                    <div class="row g-3">

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Bank Account <span class="text-danger">*</span>
                            </label>

                            <select class="form-select form-select-sm">

                                <option selected>
                                    HDFC Escrow Account (502000889123)
                                </option>

                                <option>
                                    SBI Commercial (30981245801)
                                </option>

                                <option>
                                    ICICI CapEx Operations (000405481239)
                                </option>

                                <option>
                                    Axis Corporate Account (918020081198)
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Project Link <span class="text-danger">*</span>
                            </label>

                            <select class="form-select form-select-sm">

                                <option selected>
                                    Chennai Metro Phase 2 - Corridor 4
                                </option>

                                <option>
                                    Coastal Expressway Bridge
                                </option>

                                <option>
                                    Metro Line Extension - Phase 3
                                </option>

                                <option>
                                    Skyline Premium Residences
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <div class="d-flex justify-content-between align-items-center">

                                <label class="form-label fw-semibold small mb-1">
                                    Ledger Account Head <span class="text-danger">*</span>
                                </label>

                                <a href="#"
                                   class="text-primary small fw-semibold text-decoration-none"
                                   style="font-size: 11px;"
                                   data-bs-toggle="modal"
                                   data-bs-target="#createPrimaryLedgerModal">
                                    + New Head
                                </a>

                            </div>

                            <select class="form-select form-select-sm">

                                <option selected>
                                    Subcontractor RA Payout (Expense)
                                </option>

                                <option>
                                    Client RA Bill Collection
                                </option>

                                <option>
                                    Vendor Material Supply
                                </option>

                                <option>
                                    Site Petty Cash Advance
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <div class="d-flex justify-content-between align-items-center">

                                <label class="form-label fw-semibold small mb-1">
                                    Sub-Ledger Account Head
                                </label>

                                <a href="#"
                                   class="text-primary small fw-semibold text-decoration-none"
                                   style="font-size: 11px;"
                                   data-bs-toggle="modal"
                                   data-bs-target="#createSubLedgerModal">
                                    + New Sub-Head
                                </a>

                            </div>

                            <select class="form-select form-select-sm">

                                <option selected>
                                    Earthwork & Excavation Clearance
                                </option>

                                <option>
                                    TMT Rebar & Fe550D Steel Batch
                                </option>

                                <option>
                                    Emergency Diesel & Machinery Fuel
                                </option>

                                <option>
                                    MEP & Electrical Piping
                                </option>

                            </select>

                        </div>

                        <div class="col-md-12">

                            <label class="form-label fw-semibold small">
                                Contractor / Party / Vendor <span class="text-danger">*</span>
                            </label>

                            <input type="text"
                                   class="form-control form-control-sm">

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Transaction Flow Type <span class="text-danger">*</span>
                            </label>

                            <select class="form-select form-select-sm">

                                <option selected>
                                    Debit (Outflow / Payment / Expense)
                                </option>

                                <option>
                                    Credit (Inflow / Receipt / Income)
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Payment Mode <span class="text-danger">*</span>
                            </label>

                            <select class="form-select form-select-sm">

                                <option selected>
                                    RTGS (Real Time Gross Settlement)
                                </option>

                                <option>
                                    NEFT (National Electronic Funds Transfer)
                                </option>

                                <option>
                                    IMPS (Immediate Payment Service)
                                </option>

                                <option>
                                    EFT (Electronic Funds Transfer)
                                </option>

                                <option>
                                    Cheque
                                </option>

                                <option>
                                    Cash
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Transaction Amount ($) <span class="text-danger">*</span>
                            </label>

                            <input type="text"
                                   class="form-control form-control-sm"
                                   placeholder="e.g. 250000">

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Reference UTR / Cheque No.
                            </label>

                            <input type="text"
                                   class="form-control form-control-sm"
                                   placeholder="e.g. UTR883920192  (Auto-generated if blank)">

                        </div>

                        <div class="col-md-12">

                            <label class="form-label fw-semibold small">
                                Purpose / Particulars / Narration <span class="text-danger">*</span>
                            </label>

                            <input type="text"
                                   class="form-control form-control-sm"
                                   placeholder="e.g. Subcontractor RA #03 Earthwork clearance payout">

                        </div>

                    </div>

                </form>

            </div>

            <div class="modal-footer border-0 pt-0">

                <button type="button"
                        class="btn btn-light btn-sm"
                        data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button"
                        class="btn btn-primary btn-sm">

                    <i class="mdi mdi-plus me-1"></i>

                    Save Entry

                </button>

            </div>

        </div>

    </div>

</div>

<div class="modal fade"
     id="createPrimaryLedgerModal"
     tabindex="-1"
     aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-md">

        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">

                <div>

                    <h5 class="modal-title fw-bold mb-1">

                        <i class="mdi mdi-file-document-plus-outline text-primary me-1"></i>

                        Create New Primary Ledger Head

                    </h5>

                    <p class="text-muted small mb-0">

                        Add custom account head to categorize bank transactions and site expenditures

                    </p>

                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                </button>

            </div>

            <div class="modal-body pt-3">

                <form>

                    <div class="row g-3">

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Ledger Category <span class="text-danger">*</span>
                            </label>

                            <select class="form-select form-select-sm">

                                <option selected>
                                    Expense Account Head
                                </option>

                                <option>
                                    Income Account Head
                                </option>

                                <option>
                                    Asset Account Head
                                </option>

                                <option>
                                    Liability Account Head
                                </option>

                                <option>
                                    Equity Account Head
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Head Code (Optional)
                            </label>

                            <input type="text"
                                   class="form-control form-control-sm"
                                   placeholder="e.g. EXP-SUB-101  (Auto if blank)">

                        </div>

                        <div class="col-md-12">

                            <label class="form-label fw-semibold small">
                                Ledger Head Name <span class="text-danger">*</span>
                            </label>

                            <input type="text"
                                   class="form-control form-control-sm"
                                   placeholder="e.g. Statutory Safety &amp; Environment Fund / Concrete Testing Fee">

                        </div>

                        <div class="col-md-12">

                            <label class="form-label fw-semibold small">
                                Description / Purpose
                            </label>

                            <textarea class="form-control form-control-sm"
                                      rows="3"
                                      placeholder="Provide scope, operational guidance, or accounting rules for this ledger head..."></textarea>

                        </div>

                    </div>

                </form>

            </div>

            <div class="modal-footer border-0 pt-0">

                <button type="button"
                        class="btn btn-light btn-sm"
                        data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button"
                        class="btn btn-primary btn-sm">

                    <i class="mdi mdi-plus me-1"></i>

                    Create Ledger Head

                </button>

            </div>

        </div>

    </div>

</div>

<div class="modal fade"
     id="createSubLedgerModal"
     tabindex="-1"
     aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-md">

        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">

                <div>

                    <h5 class="modal-title fw-bold mb-1">

                        <i class="mdi mdi-tag-plus-outline text-success me-1"></i>

                        Create New Sub-Ledger Head

                    </h5>

                    <p class="text-muted small mb-0">

                        Nest specific work sub-categories under a parent primary ledger head

                    </p>

                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                </button>

            </div>

            <div class="modal-body pt-3">

                <form>

                    <div class="row g-3">

                        <div class="col-md-12">

                            <label class="form-label fw-semibold small">
                                Parent Primary Ledger Head <span class="text-danger">*</span>
                            </label>

                            <select class="form-select form-select-sm">

                                <option selected>
                                    Subcontractor RA Payout (Expense - EXP-SUB-101)
                                </option>

                                <option>
                                    Client RA Bill Collection (Income - INC-RA-001)
                                </option>

                                <option>
                                    Vendor Material Supply (Expense - EXP-MAT-050)
                                </option>

                                <option>
                                    Site Petty Cash Advance (Expense - EXP-PET-020)
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Sub-Ledger Head Name <span class="text-danger">*</span>
                            </label>

                            <input type="text"
                                   class="form-control form-control-sm"
                                   placeholder="e.g. Earthwork Excavation / Bo...">

                        </div>

                        <div class="col-md-6">

                            <label class="form-label fw-semibold small">
                                Sub-Head Code (Optional)
                            </label>

                            <input type="text"
                                   class="form-control form-control-sm"
                                   placeholder="e.g. SLH-SUB-01  (Auto if blank)">

                        </div>

                        <div class="col-md-12">

                            <label class="form-label fw-semibold small">
                                Description / Scope Notes
                            </label>

                            <textarea class="form-control form-control-sm"
                                      rows="3"
                                      placeholder="e.g. Specifically for site levelling, muck removal, and soil compaction"></textarea>

                        </div>

                    </div>

                </form>

            </div>

            <div class="modal-footer border-0 pt-0">

                <button type="button"
                        class="btn btn-light btn-sm"
                        data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button"
                        class="btn btn-success btn-sm">

                    <i class="mdi mdi-plus me-1"></i>

                    Add Sub-Ledger Head

                </button>

            </div>

        </div>

    </div>

</div>

<style>

    .settings-tabs-wrapper {
        width: 700px;
        max-width: 100%;
        min-width: 0;
        flex: 1 1 700px;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 100%;
        min-width: 0;
    }

    .settings-tabs-track {
        display: flex;
        align-items: center;
        gap: .5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 4px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tabs-track .settings-tab-pill,
    a.settings-tab-pill {
        white-space: nowrap;
        padding: .5rem 1.1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: .82rem;
        font-weight: 600;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .settings-tabs-track .settings-tab-pill:hover,
    a.settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
        text-decoration: none;
    }

    .settings-tabs-track .settings-tab-pill.active,
    a.settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tabs-track .settings-tab-pill.active:hover,
    a.settings-tab-pill.active:hover {
        background: #124f7c;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
        cursor: pointer;
        transition: all .15s ease;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }

    .table > :not(caption) > * > * {
        border-bottom-width: 1px;
        border-color: #eef0f4;
    }

    .table thead th {
        border-bottom: 1px solid #eef0f4 !important;
    }

    .badge.bg-success-subtle {
        background-color: #e6f7ee !important;
    }

    .badge.bg-danger-subtle {
        background-color: #fdecec !important;
    }

    .badge.bg-light {
        background-color: #f4f6f9 !important;
    }

    .form-select-sm,
    .input-group-sm .form-control {
        font-size: 12px;
    }

    .form-select-sm {
        min-height: 31px;
    }

    .input-group-sm .form-control {
        min-height: 31px;
    }

    .card {
        border: 1px solid #eef0f4 !important;
    }

    .text-primary {
        color: #16659E !important;
    }

    .bg-primary {
        background-color: #16659E !important;
    }

    .btn-primary {
        background-color: #16659E !important;
        border-color: #16659E !important;
    }

    .btn-outline-secondary {
        color: #6c757d;
        border-color: #d0d5dd;
    }

    .btn-outline-secondary:hover {
        background-color: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }

    #logBankEntryModal .modal-content,
    #createPrimaryLedgerModal .modal-content,
    #createSubLedgerModal .modal-content {
        border-radius: 12px;
    }

    #logBankEntryModal .modal-header,
    #createPrimaryLedgerModal .modal-header,
    #createSubLedgerModal .modal-header {
        padding: 18px 22px 6px 22px;
    }

    #logBankEntryModal .modal-title,
    #createPrimaryLedgerModal .modal-title,
    #createSubLedgerModal .modal-title {
        font-size: 15px;
    }

    #logBankEntryModal .modal-body,
    #createPrimaryLedgerModal .modal-body,
    #createSubLedgerModal .modal-body {
        padding: 12px 22px 6px 22px;
    }

    #logBankEntryModal .modal-footer,
    #createPrimaryLedgerModal .modal-footer,
    #createSubLedgerModal .modal-footer {
        padding: 8px 22px 18px 22px;
    }

    #logBankEntryModal .form-label,
    #createPrimaryLedgerModal .form-label,
    #createSubLedgerModal .form-label {
        font-size: 12px;
        color: #1a2332;
        margin-bottom: 5px;
    }

    #logBankEntryModal .form-select-sm,
    #logBankEntryModal .form-control-sm,
    #createPrimaryLedgerModal .form-select-sm,
    #createPrimaryLedgerModal .form-control-sm,
    #createSubLedgerModal .form-select-sm,
    #createSubLedgerModal .form-control-sm {
        font-size: 12.5px;
        padding: 7px 10px;
        border-radius: 7px;
        border: 1px solid #d0d5dd;
        min-height: 38px;
    }

    #logBankEntryModal .form-select-sm:focus,
    #logBankEntryModal .form-control-sm:focus,
    #createPrimaryLedgerModal .form-select-sm:focus,
    #createPrimaryLedgerModal .form-control-sm:focus,
    #createSubLedgerModal .form-select-sm:focus,
    #createSubLedgerModal .form-control-sm:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    #logBankEntryModal textarea.form-control-sm,
    #createPrimaryLedgerModal textarea.form-control-sm,
    #createSubLedgerModal textarea.form-control-sm {
        min-height: 70px;
        resize: vertical;
    }

    #logBankEntryModal .form-control::placeholder,
    #createPrimaryLedgerModal .form-control::placeholder,
    #createSubLedgerModal .form-control::placeholder {
        color: #adb5bd;
        font-size: 12px;
    }

    @media (max-width: 992px) {

        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 700px;
        }

        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }

    }

    @media (max-width: 768px) {

        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 100%;
        }

        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }

    }

</style>

<script>

document.addEventListener('DOMContentLoaded', function () {

    const tabsTrack = document.getElementById('ledgerTabsTrack');

    const scrollLeftBtn =
        document.getElementById('ledgerTabScrollLeft');

    const scrollRightBtn =
        document.getElementById('ledgerTabScrollRight');

    if (scrollLeftBtn && tabsTrack) {

        scrollLeftBtn.addEventListener('click', function () {

            tabsTrack.scrollBy({
                left: -200,
                behavior: 'smooth'
            });

        });

    }

    if (scrollRightBtn && tabsTrack) {

        scrollRightBtn.addEventListener('click', function () {

            tabsTrack.scrollBy({
                left: 200,
                behavior: 'smooth'
            });

        });

    }

    const searchInput =
        document.getElementById('ledgerSearch');

    const projectFilter =
        document.getElementById('ledgerProjectFilter');

    const bankFilter =
        document.getElementById('ledgerBankFilter');

    const headFilter =
        document.getElementById('ledgerHeadFilter');

    const typeFilter =
        document.getElementById('ledgerTypeFilter');

    const ledgerTable =
        document.getElementById('ledgerTable');

    if (!ledgerTable) {
        return;
    }

    const rows =
        ledgerTable.querySelectorAll('tbody tr');

    function filterLedger() {

        const search =
            searchInput
                ? searchInput.value.toLowerCase().trim()
                : '';

        const project =
            projectFilter
                ? projectFilter.value.toLowerCase().trim()
                : '';

        const bank =
            bankFilter
                ? bankFilter.value.toLowerCase().trim()
                : '';

        const head =
            headFilter
                ? headFilter.value.toLowerCase().trim()
                : '';

        const type =
            typeFilter
                ? typeFilter.value.toLowerCase().trim()
                : '';

        rows.forEach(function (row) {

            const cells =
                row.querySelectorAll('td');

            if (cells.length < 9) {
                return;
            }

            const rowText =
                row.innerText
                    .toLowerCase()
                    .trim();

            const rowBank =
                cells[1].innerText
                    .toLowerCase()
                    .trim();

            const rowProject =
                cells[2].innerText
                    .toLowerCase()
                    .trim();

            const rowHead =
                cells[3].innerText
                    .toLowerCase()
                    .trim();

            const rowType =
                cells[5].innerText
                    .toLowerCase()
                    .trim();

            const searchMatch =
                search === '' ||
                rowText.includes(search);

            const projectMatch =
                project === '' ||
                rowProject.includes(project);

            const bankMatch =
                bank === '' ||
                rowBank.includes(bank);

            const headMatch =
                head === '' ||
                rowHead.includes(head);

            const typeMatch =
                type === '' ||
                rowType.includes(type);

            if (
                searchMatch &&
                projectMatch &&
                bankMatch &&
                headMatch &&
                typeMatch
            ) {

                row.style.display = '';

            } else {

                row.style.display = 'none';

            }

        });

    }

    if (searchInput) {
        searchInput.addEventListener('input', filterLedger);
    }

    if (projectFilter) {
        projectFilter.addEventListener('change', filterLedger);
    }

    if (bankFilter) {
        bankFilter.addEventListener('change', filterLedger);
    }

    if (headFilter) {
        headFilter.addEventListener('change', filterLedger);
    }

    if (typeFilter) {
        typeFilter.addEventListener('change', filterLedger);
    }

    const exportButton =
        document.getElementById('exportLedgerCsv');

    if (exportButton) {

        exportButton.addEventListener('click', function () {

            const headers =
                Array.from(
                    ledgerTable.querySelectorAll('thead th')
                ).map(function (th) {

                    return '"' +
                        th.innerText
                            .trim()
                            .replace(/"/g, '""') +
                        '"';

                });

            const csvRows = [];

            csvRows.push(
                headers.join(',')
            );

            rows.forEach(function (row) {

                if (row.style.display === 'none') {
                    return;
                }

                const cells =
                    row.querySelectorAll('td');

                const values =
                    Array.from(cells).map(function (cell) {

                        return '"' +
                            cell.innerText
                                .replace(/\n/g, ' ')
                                .replace(/\s+/g, ' ')
                                .trim()
                                .replace(/"/g, '""') +
                            '"';

                    });

                csvRows.push(
                    values.join(',')
                );

            });

            const csvContent =
                csvRows.join('\n');

            const blob =
                new Blob(
                    [csvContent],
                    {
                        type: 'text/csv;charset=utf-8;'
                    }
                );

            const url =
                URL.createObjectURL(blob);

            const link =
                document.createElement('a');

            link.href = url;

            link.download =
                'bank-ledger-entries.csv';

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);

        });

    }

});

</script>

@endsection
