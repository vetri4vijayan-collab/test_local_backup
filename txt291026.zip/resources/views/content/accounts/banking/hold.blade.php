@extends('layouts/contentNavbarLayout')

@section('title', 'Bank Hold Amount')

@section('content')

<div class="container-fluid">

    {{-- Header with Tabs --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body p-3 p-md-4">
            <div class="d-flex justify-content-between align-items-center flex-nowrap gap-3">
                <div class="flex-shrink-0" style="min-width: 0;">
                    <h5 class="fw-bold mb-1">Bank Hold Amounts & Tender Margins</h5>
                    <p class="text-muted small mb-0">
                        Track bank guarantees, letters of credit, EMDs and fixed deposit liens held with corporate bank accounts
                    </p>
                </div>
                <div class="settings-tabs-wrapper">
                    <div class="d-flex align-items-center gap-2">
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollLeft">
                            <i class="mdi mdi-chevron-left"></i>
                        </button>
                        <div class="settings-tabs-scroller">
                            <div class="settings-tabs-track" id="ledgerTabsTrack">
                                <a href="{{ route('accounts.banking') }}"
                                class="settings-tab-pill {{ request()->routeIs('accounts.banking') ? 'active' : '' }}">
                                    Bank Ledger Entry
                                </a>

                                 <a href="{{ route('accounts.ledger') }}"
                                 class="settings-tab-pill {{ request()->routeIs('accounts.ledger') ? 'active' : '' }}">
                                     Settings / Ledger Heads
                                 </a>

                                <a href="{{ route('accounts.bank.hold') }}"
                                class="settings-tab-pill {{ request()->routeIs('accounts.bank.hold') ? 'active' : '' }}">
                                       Bank Hold Amount
                                 </a>

                                 <a href="{{ route('accounts.cashflow') }}"
                                 class="settings-tab-pill {{ request()->routeIs('accounts.cashflow') ? 'active' : '' }}">
                                         Cash Flow Entry
                                 </a>

                                 <a href="{{ route('accounts.creditcard') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.creditcard') ? 'active' : '' }}">
                                       Credit Card Utilization
                                 </a>

                                   <a href="{{ route('accounts.mobilebill') }}"
                                   class="settings-tab-pill {{ request()->routeIs('accounts.mobilebill') ? 'active' : '' }}">
                                    Mobile Bill Entry
                                </a>

                            </div>
                        </div>
                        <button type="button" class="settings-tab-scroll-btn" id="ledgerTabScrollRight">
                            <i class="mdi mdi-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <div class="row g-3 mb-4">

        <div class="col-12 col-md-6 col-lg-3">

            <div class="card shadow-sm border-0 rounded-3 h-100">

                <div class="card-body p-3">

                    <span class="text-muted small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        Total Encumbered Hold
                    </span>

                    <div class="d-flex align-items-center gap-1 mt-2">

                        <i class="mdi mdi-trending-up text-success fs-5"></i>

                        <span class="fw-bold text-success fs-4">
                            $1,620,000
                        </span>

                    </div>
                </div>

            </div>

        </div>

        <div class="col-12 col-md-6 col-lg-3">

            <div class="card shadow-sm border-0 rounded-3 h-100">

                <div class="card-body p-3">

                    <span class="text-muted small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        Active BG / LC Holds
                    </span>

                    <div class="d-flex align-items-center gap-1 mt-2">

                        <i class="mdi mdi-trending-down text-danger fs-5"></i>

                        <span class="fw-bold text-danger fs-4">
                            $1,500,000
                        </span>

                    </div>

                    <span class="text-muted small d-block mt-1">
                        (3 Active Entries)
                    </span>

                </div>

            </div>

        </div>

        <div class="col-12 col-md-6 col-lg-3">

            <div class="card shadow-sm border-0 rounded-3 h-100">

                <div class="card-body p-3">

                    <span class="text-muted small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        Pending Release
                    </span>

                    <div class="d-flex align-items-center gap-1 mt-2">

                        <span class="fw-bold text-primary fs-4">
                            $120,000
                        </span>

                    </div>

                    <span class="text-muted small d-block mt-1">
                        (1 Entries)
                    </span>

                </div>

            </div>

        </div>

        <div class="col-12 col-md-6 col-lg-3">

            <div class="card shadow-sm border-0 rounded-3 h-100">

                <div class="card-body p-3">

                    <span class="text-muted small fw-semibold text-uppercase"
                          style="font-size: 10px; letter-spacing: .05em;">
                        Released / Refunded
                    </span>

                    <div class="d-flex align-items-baseline gap-1 mt-2">

                        <span class="fw-bold fs-4">
                          $0
                        </span>

                    </div>

                    <span class="text-success small fw-semibold d-block mt-1">
                       (0 Released)
                    </span>

                </div>

            </div>

        </div>

    </div>

    {{-- Filter Bar (single horizontal row, evenly spaced) --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">
        <div class="card-body px-3 py-3">
            <div class="d-flex align-items-center gap-2 hold-filter-bar">

                {{-- Search --}}
                <div class="hold-filter-search">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="mdi mdi-magnify text-muted"></i>
                        </span>
                        <input type="text"
                               class="form-control border-start-0"
                               id="holdSearch"
                               placeholder="Search ref no, bank, project...">
                    </div>
                </div>

                {{-- Bank Account Filter --}}
                <div class="hold-filter-select">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="mdi mdi-bank-outline text-muted"></i>
                        </span>
                        <select class="form-select border-start-0" id="holdBankFilter">
                            <option value="">All Bank Accounts</option>
                            <option value="HDFC Escrow Account">HDFC Escrow Account</option>
                            <option value="SBI Commercial">SBI Commercial</option>
                            <option value="ICICI CapEx Operations">ICICI CapEx Operations</option>
                            <option value="Axis Corporate Account">Axis Corporate Account</option>
                        </select>
                    </div>
                </div>

                {{-- Hold Category Filter --}}
                <div class="hold-filter-select">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="mdi mdi-tag-outline text-muted"></i>
                        </span>
                        <select class="form-select border-start-0" id="holdCategoryFilter">
                            <option value="">All Hold Categories</option>
                            <option value="Bank Guarantee Hold">Bank Guarantee Hold</option>
                            <option value="Letter of Credit (LC) Margin">Letter of Credit (LC) Margin</option>
                            <option value="Earnest Money Deposit (EMD)">Earnest Money Deposit (EMD)</option>
                            <option value="Fixed Deposit (FD) Lien">Fixed Deposit (FD) Lien</option>
                        </select>
                    </div>
                </div>

                {{-- Status Filter --}}
                <div class="hold-filter-select">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="mdi mdi-format-list-bulleted text-muted"></i>
                        </span>
                        <select class="form-select border-start-0" id="holdStatusFilter">
                            <option value="">All Statuses</option>
                            <option value="Active Hold">Active Hold</option>
                            <option value="Pending Release">Pending Release</option>
                            <option value="Released">Released</option>
                        </select>
                    </div>
                </div>

                {{-- Export CSV Button --}}
                <button type="button"
                        class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1 hold-filter-btn"
                        id="holdExportCsvBtn">
                    <i class="mdi mdi-download"></i>
                    Export CSV
                </button>


                <button type="button"
                        class="btn btn-primary btn-sm d-flex align-items-center gap-1 hold-filter-btn"
                        id="holdAddBtn">
                    <i class="mdi mdi-plus"></i>
                    Record Bank Hold Amount
                </button>

                {{-- View Toggle --}}
                <div class="btn-group btn-group-sm ms-auto" role="group" aria-label="View Toggle">
                    <button type="button" class="btn btn-outline-secondary active" id="viewListBtn">
                        <i class="mdi mdi-format-list-bulleted"></i>
                    </button>
                    <button type="button" class="btn btn-outline-secondary" id="viewCardsBtn">
                        <i class="mdi mdi-view-grid-outline"></i>
                    </button>
                </div>

            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 rounded-3" id="listViewWrapper">
        <div class="table-responsive">
            <table class="table align-middle mb-0 hold-table" style="font-size: 12px; table-layout: fixed; width: 100%;" id="holdTable">

                <colgroup>
                    <col style="width: 9%;">    {{-- REF ID / GUARANTEE # --}}
                    <col style="width: 14%;">   {{-- BANK ACCOUNT --}}
                    <col style="width: 10%;">   {{-- HOLD CATEGORY --}}
                    <col style="width: 13%;">   {{-- PROJECT SITE --}}
                    <col style="width: 14%;">   {{-- PURPOSE / OBLIGATION DETAILS --}}
                    <col style="width: 8%;">    {{-- HOLD AMOUNT ($) --}}
                    <col style="width: 5%;">    {{-- INTEREST / YIELD --}}
                    <col style="width: 8%;">    {{-- MATURITY / RELEASE --}}
                    <col style="width: 12%;">   {{-- STATUS --}}
                    <col style="width: 7%;">    {{-- ACTIONS --}}
                </colgroup>

                <thead style="background: #f8f9fc;">
                    <tr>
                        <th class="text-uppercase text-muted fw-bold border-0 hold-th">
                            REF ID /<br>GUARANTEE #
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 hold-th">
                            BANK ACCOUNT
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 hold-th">
                            HOLD CATEGORY
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 hold-th">
                            PROJECT SITE
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 hold-th">
                            PURPOSE / OBLIGATION DETAILS
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-end hold-th">
                            HOLD<br>AMOUNT ($)
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center hold-th">
                            INTEREST /<br>YIELD
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center hold-th">
                            MATURITY /<br>RELEASE
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center hold-th">
                            STATUS
                        </th>
                        <th class="text-uppercase text-muted fw-bold border-0 text-center hold-th">
                            ACTIONS
                        </th>
                    </tr>
                </thead>
                <tbody>

                    {{-- Row 1: HDFC --}}
                    <tr class="border-bottom hold-row"
                        data-bank="HDFC Escrow Account"
                        data-category="Bank Guarantee Hold"
                        data-status="Active Hold"
                        data-project="Coastal Expressway Bridge"
                        data-ref="BG-2026-8801"
                        data-purpose="Performance Security Guarantee against Client RA Bill"
                        data-amount="450000"
                        data-yield="5.2%"
                        data-maturity="31-03-2027">
                        <td class="hold-td">
                            <span class="fw-bold text-dark d-block ref-id">BH-201</span>
                            <span class="text-muted small ref-no">BG-2026-8801</span>
                        </td>
                        <td class="hold-td">
                            <div class="d-flex align-items-start gap-2 bank-cell">
                                <i class="mdi mdi-bank-outline text-primary bank-icon"></i>
                                <span class="fw-semibold text-dark bank-name">HDFC Escrow Account</span>
                            </div>
                        </td>
                        <td class="hold-td">
                            <span class="badge rounded-pill px-3 py-2 category-badge"
                                  style="background:#fff4d6; color:#a06b00; border:1px solid #f5d78a; font-size:11px; font-weight:600;">
                                Bank Guarantee Hold
                            </span>
                        </td>
                        <td class="hold-td">
                            <span class="text-dark project-name">Coastal Expressway Bridge</span>
                        </td>
                        <td class="hold-td">
                            <span class="text-dark d-block fw-semibold purpose-text">Performance Security Guarantee against Client RA Bill</span>
                            <span class="text-muted" style="font-size:10px; font-style: italic;">
                                Note: 25% Cash margin locked in Escrow
                            </span>
                        </td>
                        <td class="hold-td text-end">
                            <span class="fw-bold text-dark amount-text">$450,000</span>
                        </td>
                        <td class="hold-td text-center">
                            <span class="fw-semibold text-dark yield-text">5.2%</span>
                        </td>
                        <td class="hold-td text-center">
                            <span class="text-muted small d-inline-flex align-items-center gap-1 maturity-text">
                                <i class="mdi mdi-calendar-outline"></i> 31-03-2027
                            </span>
                        </td>
                        <td class="hold-td text-center">
                            <select class="form-select form-select-sm hold-status-select"
                                    data-row-status="Active Hold">
                                <option value="Active Hold" selected>Active Hold</option>
                                <option value="Pending Release">Pending Release</option>
                                <option value="Released">Released</option>
                            </select>
                        </td>
                        <td class="hold-td text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-hold-btn"
                                        title="Edit"
                                        style="font-size: 17px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-hold-btn"
                                        title="Delete"
                                        style="font-size: 17px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 2: SBI --}}
                    <tr class="border-bottom hold-row"
                        data-bank="SBI Commercial"
                        data-category="Letter of Credit (LC) Margin"
                        data-status="Active Hold"
                        data-project="Metro Line Extension - Phase 3"
                        data-ref="LC-2026-4402"
                        data-purpose="Heavy Equipment Lease Import Security Deposit"
                        data-amount="800000"
                        data-yield="6.0%"
                        data-maturity="15-11-2026">
                        <td class="hold-td">
                            <span class="fw-bold text-dark d-block ref-id">BH-202</span>
                            <span class="text-muted small ref-no">LC-2026-4402</span>
                        </td>
                        <td class="hold-td">
                            <div class="d-flex align-items-start gap-2 bank-cell">
                                <i class="mdi mdi-bank-outline text-primary bank-icon"></i>
                                <span class="fw-semibold text-dark bank-name">SBI Commercial</span>
                            </div>
                        </td>
                        <td class="hold-td">
                            <span class="badge rounded-pill px-3 py-2 category-badge"
                                  style="background:#e3edff; color:#1e4d99; border:1px solid #b9cffb; font-size:11px; font-weight:600;">
                                Letter of Credit (LC) Margin
                            </span>
                        </td>
                        <td class="hold-td">
                            <span class="text-dark project-name">Metro Line Extension - Phase 3</span>
                        </td>
                        <td class="hold-td">
                            <span class="text-dark d-block fw-semibold purpose-text">Heavy Equipment Lease Import Security Deposit</span>
                            <span class="text-muted" style="font-size:10px; font-style: italic;">
                                Note: Under SBI LC Facility #102
                            </span>
                        </td>
                        <td class="hold-td text-end">
                            <span class="fw-bold text-dark amount-text">$800,000</span>
                        </td>
                        <td class="hold-td text-center">
                            <span class="fw-semibold text-dark yield-text">6.0%</span>
                        </td>
                        <td class="hold-td text-center">
                            <span class="text-muted small d-inline-flex align-items-center gap-1 maturity-text">
                                <i class="mdi mdi-calendar-outline"></i> 15-11-2026
                            </span>
                        </td>
                        <td class="hold-td text-center">
                            <select class="form-select form-select-sm hold-status-select"
                                    data-row-status="Active Hold">
                                <option value="Active Hold" selected>Active Hold</option>
                                <option value="Pending Release">Pending Release</option>
                                <option value="Released">Released</option>
                            </select>
                        </td>
                        <td class="hold-td text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-hold-btn"
                                        title="Edit"
                                        style="font-size: 17px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-hold-btn"
                                        title="Delete"
                                        style="font-size: 17px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 3: ICICI --}}
                    <tr class="border-bottom hold-row"
                        data-bank="ICICI CapEx Operations"
                        data-category="Earnest Money Deposit (EMD)"
                        data-status="Pending Release"
                        data-project="Industrial Logistics Park"
                        data-ref="EMD-9981-2026"
                        data-purpose="Government Tender Bid Security EMD Hold"
                        data-amount="120000"
                        data-yield="4.8%"
                        data-maturity="30-08-2026">
                        <td class="hold-td">
                            <span class="fw-bold text-dark d-block ref-id">BH-203</span>
                            <span class="text-muted small ref-no">EMD-9981-2026</span>
                        </td>
                        <td class="hold-td">
                            <div class="d-flex align-items-start gap-2 bank-cell">
                                <i class="mdi mdi-bank-outline text-primary bank-icon"></i>
                                <span class="fw-semibold text-dark bank-name">ICICI CapEx Operations</span>
                            </div>
                        </td>
                        <td class="hold-td">
                            <span class="badge rounded-pill px-3 py-2 category-badge"
                                  style="background:#f4e3ff; color:#7a1fa6; border:1px solid #d8b6f0; font-size:11px; font-weight:600;">
                                Earnest Money Deposit (EMD)
                            </span>
                        </td>
                        <td class="hold-td">
                            <span class="text-dark project-name">Industrial Logistics Park</span>
                        </td>
                        <td class="hold-td">
                            <span class="text-dark d-block fw-semibold purpose-text">Government Tender Bid Security EMD Hold</span>
                            <span class="text-muted" style="font-size:10px; font-style: italic;">
                                Note: Tender evaluation completed, awaiting release
                            </span>
                        </td>
                        <td class="hold-td text-end">
                            <span class="fw-bold text-dark amount-text">$120,000</span>
                        </td>
                        <td class="hold-td text-center">
                            <span class="fw-semibold text-dark yield-text">4.8%</span>
                        </td>
                        <td class="hold-td text-center">
                            <span class="text-muted small d-inline-flex align-items-center gap-1 maturity-text">
                                <i class="mdi mdi-calendar-outline"></i> 30-08-2026
                            </span>
                        </td>
                        <td class="hold-td text-center">
                            <select class="form-select form-select-sm hold-status-select"
                                    data-row-status="Pending Release">
                                <option value="Active Hold">Active Hold</option>
                                <option value="Pending Release" selected>Pending Release</option>
                                <option value="Released">Released</option>
                            </select>
                        </td>
                        <td class="hold-td text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-hold-btn"
                                        title="Edit"
                                        style="font-size: 17px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-hold-btn"
                                        title="Delete"
                                        style="font-size: 17px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 4: Axis --}}
                    <tr class="hold-row"
                        data-bank="Axis Corporate Account"
                        data-category="Fixed Deposit (FD) Lien"
                        data-status="Active Hold"
                        data-project="Skyline Premium Residences"
                        data-ref="FD-AX-99128"
                        data-purpose="Security Deposit Margin for Utility Right-of-Way Permit"
                        data-amount="250000"
                        data-yield="6.5%"
                        data-maturity="20-12-2026">
                        <td class="hold-td">
                            <span class="fw-bold text-dark d-block ref-id">BH-204</span>
                            <span class="text-muted small ref-no">FD-AX-99128</span>
                        </td>
                        <td class="hold-td">
                            <div class="d-flex align-items-start gap-2 bank-cell">
                                <i class="mdi mdi-bank-outline text-primary bank-icon"></i>
                                <span class="fw-semibold text-dark bank-name">Axis Corporate Account</span>
                            </div>
                        </td>
                        <td class="hold-td">
                            <span class="badge rounded-pill px-3 py-2 category-badge"
                                  style="background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0; font-size:11px; font-weight:600;">
                                Fixed Deposit (FD) Lien
                            </span>
                        </td>
                        <td class="hold-td">
                            <span class="text-dark project-name">Skyline Premium Residences</span>
                        </td>
                        <td class="hold-td">
                            <span class="text-dark d-block fw-semibold purpose-text">Security Deposit Margin for Utility Right-of-Way Permit</span>
                            <span class="text-muted" style="font-size:10px; font-style: italic;">
                                Note: Cumulative FD auto-renewed
                            </span>
                        </td>
                        <td class="hold-td text-end">
                            <span class="fw-bold text-dark amount-text">$250,000</span>
                        </td>
                        <td class="hold-td text-center">
                            <span class="fw-semibold text-dark yield-text">6.5%</span>
                        </td>
                        <td class="hold-td text-center">
                            <span class="text-muted small d-inline-flex align-items-center gap-1 maturity-text">
                                <i class="mdi mdi-calendar-outline"></i> 20-12-2026
                            </span>
                        </td>
                        <td class="hold-td text-center">
                            <select class="form-select form-select-sm hold-status-select"
                                    data-row-status="Active Hold">
                                <option value="Active Hold" selected>Active Hold</option>
                                <option value="Pending Release">Pending Release</option>
                                <option value="Released">Released</option>
                            </select>
                        </td>
                        <td class="hold-td text-center">
                            <div class="d-inline-flex align-items-center gap-1">
                                <button type="button"
                                        class="btn btn-link p-0 text-primary edit-hold-btn"
                                        title="Edit"
                                        style="font-size: 17px; line-height: 1;">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-link p-0 text-muted delete-hold-btn"
                                        title="Delete"
                                        style="font-size: 17px; line-height: 1;">
                                    <i class="mdi mdi-delete-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>

        {{-- Footer --}}
        <div class="card-footer bg-white border-top d-flex justify-content-between align-items-center px-4 py-3">
            <span class="text-muted small" id="listFooterText">
                Showing 4 of 4 Bank Hold Entries
            </span>
            <span class="text-muted small fw-semibold">
                Total Hold Value: <span class="text-dark fw-bold">$1,620,000</span>
            </span>
        </div>
    </div>


    <div class="row g-3 d-none" id="cardsViewWrapper">

        {{-- Card 1: Bank Guarantee Hold --}}
        <div class="col-12 col-md-6 col-xl-4 hold-card-item"
             data-ref-id="BH-201"
             data-bank="HDFC Escrow Account"
             data-category="Bank Guarantee Hold"
             data-status="Active Hold">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">

                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="badge rounded-pill px-3 py-2"
                              style="background:#fff4d6; color:#a06b00; border:1px solid #f5d78a; font-size:10px; font-weight:700;">
                            BANK GUARANTEE HOLD
                        </span>
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-muted" style="font-size:11px;">BH-201</span>
                            <button type="button" class="btn btn-link p-0 text-primary edit-hold-card-btn" title="Edit" style="font-size:15px; line-height:1;">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                            <button type="button" class="btn btn-link p-0 text-muted delete-hold-card-btn" title="Delete" style="font-size:15px; line-height:1;">
                                <i class="mdi mdi-delete-outline"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-2 mb-2">
                        <i class="mdi mdi-bank-outline text-primary"></i>
                        <span class="fw-bold text-dark" style="font-size:13px;">HDFC Escrow Account</span>
                    </div>
                    <div class="text-muted mb-2" style="font-size:12px;">
                        Performance Security Guarantee against Client RA Bill
                    </div>
                    <div class="mb-1" style="font-size:11.5px;">
                        <span class="text-primary fw-semibold">Project:</span>
                        <span class="text-dark">Coastal Expressway Bridge</span>
                    </div>
                    <div class="mb-3" style="font-size:11px;">
                        <span class="text-muted">Ref Guarantee #:</span>
                        <span class="text-dark">BG-2026-8801</span>
                    </div>

                    <div class="d-flex justify-content-between align-items-end mb-2">
                        <div>
                            <span class="text-muted d-block" style="font-size:10.5px;">Amount On Hold</span>
                            <span class="fw-bold text-dark" style="font-size:16px;">$450,000</span>
                        </div>
                        <div class="text-end">
                            <span class="text-muted d-block" style="font-size:10.5px;">Maturity / Yield</span>
                            <span class="fw-semibold text-dark" style="font-size:12px;">
                                2027-03-31 <span class="text-muted">(5.2%)</span>
                            </span>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end align-items-center mt-3 pt-2 border-top">
                        <select class="form-select form-select-sm hold-status-select"
                                data-row-status="Active Hold"
                                style="font-size:11px; min-width:130px; max-width:150px;">
                            <option value="Active Hold" selected>Active Hold</option>
                            <option value="Pending Release">Pending Release</option>
                            <option value="Released">Released</option>
                        </select>
                    </div>

                </div>
            </div>
        </div>

        {{-- Card 2: Letter of Credit --}}
        <div class="col-12 col-md-6 col-xl-4 hold-card-item"
             data-ref-id="BH-202"
             data-bank="SBI Commercial"
             data-category="Letter of Credit (LC) Margin"
             data-status="Active Hold">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">

                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="badge rounded-pill px-3 py-2"
                              style="background:#e3edff; color:#1e4d99; border:1px solid #b9cffb; font-size:10px; font-weight:700;">
                            LETTER OF CREDIT (LC) MARGIN
                        </span>
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-muted" style="font-size:11px;">BH-202</span>
                            <button type="button" class="btn btn-link p-0 text-primary edit-hold-card-btn" title="Edit" style="font-size:15px; line-height:1;">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                            <button type="button" class="btn btn-link p-0 text-muted delete-hold-card-btn" title="Delete" style="font-size:15px; line-height:1;">
                                <i class="mdi mdi-delete-outline"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-2 mb-2">
                        <i class="mdi mdi-bank-outline text-primary"></i>
                        <span class="fw-bold text-dark" style="font-size:13px;">SBI Commercial</span>
                    </div>
                    <div class="text-muted mb-2" style="font-size:12px;">
                        Heavy Equipment Lease Import Security Deposit
                    </div>
                    <div class="mb-1" style="font-size:11.5px;">
                        <span class="text-primary fw-semibold">Project:</span>
                        <span class="text-dark">Metro Line Extension - Phase 3</span>
                    </div>
                    <div class="mb-3" style="font-size:11px;">
                        <span class="text-muted">Ref Guarantee #:</span>
                        <span class="text-dark">LC-2026-4402</span>
                    </div>

                    <div class="d-flex justify-content-between align-items-end mb-2">
                        <div>
                            <span class="text-muted d-block" style="font-size:10.5px;">Amount On Hold</span>
                            <span class="fw-bold text-dark" style="font-size:16px;">$800,000</span>
                        </div>
                        <div class="text-end">
                            <span class="text-muted d-block" style="font-size:10.5px;">Maturity / Yield</span>
                            <span class="fw-semibold text-dark" style="font-size:12px;">
                                15-11-2026<span class="text-muted">(6.0%)</span>
                            </span>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end align-items-center mt-3 pt-2 border-top">
                        <select class="form-select form-select-sm hold-status-select"
                                data-row-status="Active Hold"
                                style="font-size:11px; min-width:130px; max-width:150px;">
                            <option value="Active Hold" selected>Active Hold</option>
                            <option value="Pending Release">Pending Release</option>
                            <option value="Released">Released</option>
                        </select>
                    </div>

                </div>
            </div>
        </div>

        {{-- Card 3: EMD --}}
        <div class="col-12 col-md-6 col-xl-4 hold-card-item"
             data-ref-id="BH-203"
             data-bank="ICICI CapEx Operations"
             data-category="Earnest Money Deposit (EMD)"
             data-status="Pending Release">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">

                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="badge rounded-pill px-3 py-2"
                              style="background:#f4e3ff; color:#7a1fa6; border:1px solid #d8b6f0; font-size:10px; font-weight:700;">
                            EARNEST MONEY DEPOSIT (EMD)
                        </span>
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-muted" style="font-size:11px;">BH-203</span>
                            <button type="button" class="btn btn-link p-0 text-primary edit-hold-card-btn" title="Edit" style="font-size:15px; line-height:1;">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                            <button type="button" class="btn btn-link p-0 text-muted delete-hold-card-btn" title="Delete" style="font-size:15px; line-height:1;">
                                <i class="mdi mdi-delete-outline"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-2 mb-2">
                        <i class="mdi mdi-bank-outline text-primary"></i>
                        <span class="fw-bold text-dark" style="font-size:13px;">ICICI CapEx Operations</span>
                    </div>
                    <div class="text-muted mb-2" style="font-size:12px;">
                        Government Tender Bid Security EMD Hold
                    </div>
                    <div class="mb-1" style="font-size:11.5px;">
                        <span class="text-primary fw-semibold">Project:</span>
                        <span class="text-dark">Industrial Logistics Park</span>
                    </div>
                    <div class="mb-3" style="font-size:11px;">
                        <span class="text-muted">Ref Guarantee #:</span>
                        <span class="text-dark">EMD-9981-2026</span>
                    </div>

                    <div class="d-flex justify-content-between align-items-end mb-2">
                        <div>
                            <span class="text-muted d-block" style="font-size:10.5px;">Amount On Hold</span>
                            <span class="fw-bold text-dark" style="font-size:16px;">$120,000</span>
                        </div>
                        <div class="text-end">
                            <span class="text-muted d-block" style="font-size:10.5px;">Maturity / Yield</span>
                            <span class="fw-semibold text-dark" style="font-size:12px;">
                                30-08-2026 <span class="text-muted">(4.8%)</span>
                            </span>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end align-items-center mt-3 pt-2 border-top">
                        <select class="form-select form-select-sm hold-status-select"
                                data-row-status="Pending Release"
                                style="font-size:11px; min-width:130px; max-width:150px;">
                            <option value="Active Hold">Active Hold</option>
                            <option value="Pending Release" selected>Pending Release</option>
                            <option value="Released">Released</option>
                        </select>
                    </div>

                </div>
            </div>
        </div>

        {{-- Card 4: FD Lien --}}
        <div class="col-12 col-md-6 col-xl-4 hold-card-item"
             data-ref-id="BH-204"
             data-bank="Axis Corporate Account"
             data-category="Fixed Deposit (FD) Lien"
             data-status="Active Hold">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">

                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="badge rounded-pill px-3 py-2"
                              style="background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0; font-size:10px; font-weight:700;">
                            FIXED DEPOSIT (FD) LIEN
                        </span>
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-muted" style="font-size:11px;">BH-204</span>
                            <button type="button" class="btn btn-link p-0 text-primary edit-hold-card-btn" title="Edit" style="font-size:15px; line-height:1;">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                            <button type="button" class="btn btn-link p-0 text-muted delete-hold-card-btn" title="Delete" style="font-size:15px; line-height:1;">
                                <i class="mdi mdi-delete-outline"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-2 mb-2">
                        <i class="mdi mdi-bank-outline text-primary"></i>
                        <span class="fw-bold text-dark" style="font-size:13px;">Axis Corporate Account</span>
                    </div>
                    <div class="text-muted mb-2" style="font-size:12px;">
                        Security Deposit Margin for Utility Right-of-Way Permit
                    </div>
                    <div class="mb-1" style="font-size:11.5px;">
                        <span class="text-primary fw-semibold">Project:</span>
                        <span class="text-dark">Skyline Premium Residences</span>
                    </div>
                    <div class="mb-3" style="font-size:11px;">
                        <span class="text-muted">Ref Guarantee #:</span>
                        <span class="text-dark">FD-AX-99128</span>
                    </div>

                    <div class="d-flex justify-content-between align-items-end mb-2">
                        <div>
                            <span class="text-muted d-block" style="font-size:10.5px;">Amount On Hold</span>
                            <span class="fw-bold text-dark" style="font-size:16px;">$250,000</span>
                        </div>
                        <div class="text-end">
                            <span class="text-muted d-block" style="font-size:10.5px;">Maturity / Yield</span>
                            <span class="fw-semibold text-dark" style="font-size:12px;">
                                20-12-2026<span class="text-muted">(6.5%)</span>
                            </span>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end align-items-center mt-3 pt-2 border-top">
                        <select class="form-select form-select-sm hold-status-select"
                                data-row-status="Active Hold"
                                style="font-size:11px; min-width:130px; max-width:150px;">
                            <option value="Active Hold" selected>Active Hold</option>
                            <option value="Pending Release">Pending Release</option>
                            <option value="Released">Released</option>
                        </select>
                    </div>

                </div>
            </div>
        </div>

    </div>

</div>


<div class="modal fade" id="holdEntryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header border-0 pb-0">
                <div class="d-flex align-items-start gap-2">
                    <i class="mdi mdi-bank-outline text-primary" style="font-size: 22px;"></i>
                    <div>
                        <h5 class="modal-title fw-bold mb-0" id="holdEntryTitle" style="font-size: 15px;">
                            Log New Bank Hold Amount / Margin Entry
                        </h5>
                        <p class="text-muted small mb-0" style="font-size: 12px;">
                            Record cash margin, LC lien, Bank Guarantee, or security deposit hold against a bank account
                        </p>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body pt-3">
                <form id="holdEntryForm">

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Corporate Bank Account <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="heBank">
                                <option value="HDFC Escrow Account">HDFC Escrow Account (A/C: ....89123)</option>
                                <option value="SBI Commercial">SBI Commercial (A/C: ....44102)</option>
                                <option value="ICICI CapEx Operations">ICICI CapEx Operations (A/C: ....99012)</option>
                                <option value="Axis Corporate Account">Axis Corporate Account (A/C: ....77128)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Hold Category / Instrument Type <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="heCategory">
                                <option value="Bank Guarantee Hold">Bank Guarantee (BG) Cash Margin Hold</option>
                                <option value="Letter of Credit (LC) Margin">Letter of Credit (LC) Margin</option>
                                <option value="Earnest Money Deposit (EMD)">Earnest Money Deposit (EMD)</option>
                                <option value="Fixed Deposit (FD) Lien">Fixed Deposit (FD) Lien</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Project Site / Client <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="heProject">
                                <option value="Chennai Metro Phase 2 - Corridor 4">Chennai Metro Phase 2 - Corridor 4</option>
                                <option value="Coastal Expressway Bridge">Coastal Expressway Bridge</option>
                                <option value="Metro Line Extension - Phase 3">Metro Line Extension - Phase 3</option>
                                <option value="Skyline Premium Residences">Skyline Premium Residences</option>
                                <option value="Industrial Logistics Park">Industrial Logistics Park</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Guarantee / Ref Guarantee #
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="heRef"
                                   placeholder="e.g. BG-2026-9012 / LC-1092">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">
                            Purpose / Security Obligation Details <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               class="form-control form-control-sm"
                               id="hePurpose"
                               placeholder="e.g. Performance Security Guarantee against Client RA Bill #05 or Customs Clearance Margin">
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Hold Amount ($) <span class="text-danger">*</span>
                            </label>
                            <input type="number"
                                   class="form-control form-control-sm"
                                   id="heAmount"
                                   placeholder="e.g. 250000"
                                   step="0.01">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Yield / Interest %
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="heYield"
                                   placeholder="e.g. 5.2%">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">
                                Maturity / Release Date <span class="text-danger">*</span>
                            </label>
                            <input type="date"
                                   class="form-control form-control-sm"
                                   id="heMaturity">
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Hold Status <span class="text-danger">*</span>
                            </label>
                            <select class="form-select form-select-sm" id="heStatus">
                                <option value="Active Hold">Active Hold (Cash Margin Locked)</option>
                                <option value="Pending Release">Pending Release</option>
                                <option value="Released">Released</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">
                                Security Notes / Remarks
                            </label>
                            <input type="text"
                                   class="form-control form-control-sm"
                                   id="heNotes"
                                   placeholder="e.g. 25% cash margin retained in bank escrow">
                        </div>
                    </div>

                </form>
            </div>

            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light btn-sm px-4" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button"
                        class="btn btn-primary btn-sm px-4 d-flex align-items-center gap-1"
                        id="holdEntrySubmitBtn"
                        style="font-weight:600;">
                    <i class="mdi mdi-lock-outline"></i>
                    <span id="holdEntrySubmitLabel">Record Bank Hold Amount</span>
                </button>
            </div>

        </div>
    </div>
</div>

<style>

    .settings-tabs-wrapper {
        width: 700px;
        max-width: 100%;
        min-width: 0;
        flex: 1 1 700px;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 100%;
        min-width: 0;
    }

    .settings-tabs-track {
        display: flex;
        align-items: center;
        gap: .5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 4px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tabs-track .settings-tab-pill,
    a.settings-tab-pill {
        white-space: nowrap;
        padding: .5rem 1.1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: .82rem;
        font-weight: 600;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .settings-tabs-track .settings-tab-pill:hover,
    a.settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
        text-decoration: none;
    }

    .settings-tabs-track .settings-tab-pill.active,
    a.settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tabs-track .settings-tab-pill.active:hover,
    a.settings-tab-pill.active:hover {
        background: #124f7c;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
        cursor: pointer;
        transition: all .15s ease;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }

    /* ---------- Hold Filter Bar ---------- */
    .hold-filter-bar {
        display: flex;
        flex-wrap: nowrap;
        align-items: center;
        gap: 8px;
        width: 100%;
    }

    .hold-filter-search {
        width: 250px;
    }

    .hold-filter-select {
        min-width: 220px;
    }

    .hold-filter-btn {
        white-space: nowrap;
        flex-shrink: 0;
        font-size: 12px;
        padding: 5px 12px;
    }

    .hold-filter-bar .input-group-sm .form-control,
    .hold-filter-bar .input-group-sm .form-select,
    .hold-filter-bar .input-group-sm .input-group-text {
        font-size: 12px;
        min-height: 32px;
        padding: 4px 8px;
    }

    /* ---------- TABLE ---------- */
    .hold-table {
        table-layout: fixed;
        width: 100%;
    }

    .hold-table th,
    .hold-table td {
        vertical-align: middle !important;
    }

    .hold-table thead th.hold-th {
        font-size: 9.5px;
        letter-spacing: .03em;
        padding: 12px 8px;
        white-space: normal;
        line-height: 1.3;
        vertical-align: middle;
        word-break: normal;
        overflow-wrap: normal;
    }

    .hold-table thead th.hold-th br {
        display: block;
        content: "";
        margin: 0;
        line-height: 1.3;
    }

    .hold-table tbody td.hold-td {
        padding: 14px 8px;
        vertical-align: middle;
        word-wrap: break-word;
        overflow-wrap: break-word;
    }

    .hold-table tbody td.hold-td .category-badge {
        display: inline-block;
        white-space: normal;
        line-height: 1.2;
        text-align: center;
        word-break: normal;
    }

    .hold-table tbody td.hold-td .hold-status-select {
        width: 100%;
        min-width: 118px;
        max-width: 100% !important;
        font-size: 10.5px;
        text-align: center;
        text-align-last: center;
        padding: 5px 6px;
        white-space: nowrap;
    }

    .hold-table tbody td.hold-td .maturity-text {
        white-space: nowrap;
        font-size: 11px;
    }

    /* ---------- Project cell: single straight line ---------- */
    .hold-table tbody td.hold-td .project-name {
        display: block;
        line-height: 1.35;
        white-space: nowrap;
        word-break: normal;
        overflow-wrap: normal;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 100%;
    }

    /* ---------- Bank account cell ---------- */
    .hold-table tbody td.hold-td .bank-cell {
        align-items: flex-start;
        line-height: 1.35;
    }

    .hold-table tbody td.hold-td .bank-cell .bank-icon {
        margin-top: 2px;
        flex-shrink: 0;
    }

    .hold-table tbody td.hold-td .bank-cell .bank-name {
        display: block;
        line-height: 1.35;
        white-space: nowrap;
        word-break: normal;
        overflow-wrap: normal;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    /* ---------- Table base styles ---------- */
    .table > :not(caption) > * > * {
        border-bottom-width: 1px;
        border-color: #eef0f4;
    }

    .table thead th {
        border-bottom: 1px solid #eef0f4 !important;
    }

    .badge.bg-success-subtle {
        background-color: #e6f7ee !important;
    }

    .badge.bg-danger-subtle {
        background-color: #fdecec !important;
    }

    .badge.bg-light {
        background-color: #f4f6f9 !important;
    }

    .form-select-sm,
    .input-group-sm .form-control,
    .input-group-sm .form-select {
        font-size: 12px;
    }

    .form-select-sm {
        min-height: 31px;
    }

    .input-group-sm .form-control,
    .input-group-sm .form-select {
        min-height: 31px;
    }

    .card {
        border: 1px solid #eef0f4 !important;
    }

    .text-primary {
        color: #16659E !important;
    }

    .bg-primary {
        background-color: #16659E !important;
    }

    .btn-primary {
        background-color: #16659E !important;
        border-color: #16659E !important;
    }

    .btn-primary:hover {
        background-color: #124f7c !important;
        border-color: #124f7c !important;
    }

    .btn-outline-secondary {
        color: #6c757d;
        border-color: #d0d5dd;
    }

    .btn-outline-secondary:hover {
        background-color: #f8f9fa;
        color: #16659E;
        border-color: #16659E;
    }

    .btn-outline-secondary.active {
        background-color: #16659E !important;
        border-color: #16659E !important;
        color: #fff !important;
    }

    /* ---------- Status dropdown (list view) ---------- */
    .hold-status-select {
        border-radius: 6px;
        border: 1px solid #d0d5dd;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
    }

    .hold-status-select:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    .hold-status-select[data-current="Active Hold"] {
        background: #fff4d6;
        color: #a06b00;
        border-color: #f5d78a;
    }

    .hold-status-select[data-current="Pending Release"] {
        background: #e3edff;
        color: #1e4d99;
        border-color: #b9cffb;
    }

    .hold-status-select[data-current="Released"] {
        background: #e6f7ee;
        color: #0f7a4a;
        border-color: #a8e0c0;
    }

    /* ---------- Card view status select (same look as list view) ---------- */
    #cardsViewWrapper .hold-status-select {
        border-radius: 6px;
        border: 1px solid #d0d5dd;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
        text-align-last: center;
        padding: 5px 6px;
        white-space: nowrap;
    }

    #cardsViewWrapper .hold-status-select:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    #cardsViewWrapper .hold-status-select[data-current="Active Hold"] {
        background: #fff4d6;
        color: #a06b00;
        border-color: #f5d78a;
    }

    #cardsViewWrapper .hold-status-select[data-current="Pending Release"] {
        background: #e3edff;
        color: #1e4d99;
        border-color: #b9cffb;
    }

    #cardsViewWrapper .hold-status-select[data-current="Released"] {
        background: #e6f7ee;
        color: #0f7a4a;
        border-color: #a8e0c0;
    }

    /* ---------- Hold Entry Modal ---------- */
    #holdEntryModal .modal-dialog {
        max-width: 820px;
        width: calc(100% - 40px);
        margin: 1.75rem auto;
    }

    #holdEntryModal .modal-content {
        border-radius: 14px;
        max-height: calc(100vh - 3.5rem);
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    #holdEntryModal .modal-header {
        padding: 22px 26px 8px 26px;
        flex-shrink: 0;
    }

    #holdEntryModal .modal-body {
        padding: 12px 26px 8px 26px;
        overflow-y: auto;
        flex-grow: 1;
    }

    #holdEntryModal .modal-footer {
        padding: 8px 26px 20px 26px;
        flex-shrink: 0;
        gap: 8px;
    }

    #holdEntryModal .form-label {
        font-size: 12.5px;
        color: #1a2332;
        margin-bottom: 6px;
    }

    #holdEntryModal .form-control-sm,
    #holdEntryModal .form-select-sm {
        font-size: 12.5px;
        padding: 8px 12px;
        border-radius: 8px;
        border: 1px solid #d0d5dd;
        min-height: 40px;
        width: 100%;
    }

    #holdEntryModal .form-control-sm:focus,
    #holdEntryModal .form-select-sm:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
    }

    #holdEntryModal .form-control-sm::placeholder {
        color: #adb5bd;
        font-size: 12.5px;
    }

    /* ---------- Responsive ---------- */
    @media (max-width: 992px) {

        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 700px;
        }

        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }

        .hold-filter-bar {
            flex-wrap: wrap;
        }

        .hold-filter-search,
        .hold-filter-select {
            flex: 1 1 calc(50% - 8px);
            width: auto;
            min-width: 0;
        }

        .hold-filter-btn {
            flex: 1 1 auto;
            justify-content: center;
        }

        .hold-filter-bar .btn-group {
            flex: 0 0 auto;
            margin-left: auto !important;
        }

        .container-fluid > .card > .card-body > .d-flex.flex-nowrap {
            flex-wrap: wrap;
        }
    }

    @media (max-width: 768px) {

        .settings-tabs-wrapper {
            width: 100%;
            flex: 0 1 100%;
        }

        .settings-tabs-scroller {
            max-width: 100%;
            flex: 1;
        }

        .hold-filter-bar {
            flex-direction: column;
            align-items: stretch;
        }

        .hold-filter-search,
        .hold-filter-select {
            width: 100%;
            flex: 1 1 100%;
            min-width: 0;
        }

        .hold-filter-btn {
            width: 100%;
            justify-content: center;
            flex: 1 1 100%;
        }

        .hold-filter-bar .btn-group {
            width: 100%;
            justify-content: center;
            margin-left: 0 !important;
        }

        .container-fluid > .card > .card-body > .d-flex.flex-nowrap {
            flex-direction: column;
            align-items: flex-start !important;
            gap: 12px !important;
        }

        .container-fluid > .card > .card-body > .d-flex.flex-nowrap > .flex-shrink-0,
        .container-fluid > .card > .card-body > .d-flex.flex-nowrap > .settings-tabs-wrapper {
            width: 100%;
            flex: 1 1 100% !important;
        }

        .hold-table {
            min-width: 900px;
        }

        #holdEntryModal .modal-dialog {
            margin: 0.75rem auto;
            width: calc(100% - 16px);
        }

        #holdEntryModal .modal-header,
        #holdEntryModal .modal-body,
        #holdEntryModal .modal-footer {
            padding-left: 16px;
            padding-right: 16px;
        }

        .fs-4 {
            font-size: 1.15rem !important;
        }

        .container-fluid {
            padding-left: 10px;
            padding-right: 10px;
        }
    }

    @media (max-width: 576px) {

        .hold-table {
            min-width: 860px;
        }

        .container-fluid {
            padding-left: 6px;
            padding-right: 6px;
        }

        .card-body {
            padding: 12px !important;
        }

        .fs-4 {
            font-size: 1rem !important;
        }

        .hold-filter-bar .input-group-sm .form-control,
        .hold-filter-bar .input-group-sm .form-select,
        .hold-filter-bar .input-group-sm .input-group-text {
            min-height: 36px;
            font-size: 12.5px;
        }

        #holdEntryModal .form-control-sm,
        #holdEntryModal .form-select-sm {
            min-height: 42px;
            font-size: 13px;
        }
    }

</style>

<script>

document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Tabs Scroll ---------- */
    const tabsTrack = document.getElementById('ledgerTabsTrack');
    const scrollLeftBtn = document.getElementById('ledgerTabScrollLeft');
    const scrollRightBtn = document.getElementById('ledgerTabScrollRight');

    if (scrollLeftBtn && tabsTrack) {
        scrollLeftBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (scrollRightBtn && tabsTrack) {
        scrollRightBtn.addEventListener('click', function () {
            tabsTrack.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

    /* ============================================================= */
    /* ---------- LOCAL STORAGE PERSISTENCE ---------- */
    /* ============================================================= */
    const HOLD_STORAGE_KEY       = 'bank_hold_entries_v1';
    const HOLD_CARDS_STORAGE_KEY = 'bank_hold_cards_v1';

    /* Helper: badge classes for category */
    function categoryBadgeStyle(category) {
        switch (category) {
            case 'Bank Guarantee Hold':
                return 'background:#fff4d6; color:#a06b00; border:1px solid #f5d78a;';
            case 'Letter of Credit (LC) Margin':
                return 'background:#e3edff; color:#1e4d99; border:1px solid #b9cffb;';
            case 'Earnest Money Deposit (EMD)':
                return 'background:#f4e3ff; color:#7a1fa6; border:1px solid #d8b6f0;';
            case 'Fixed Deposit (FD) Lien':
                return 'background:#e6f7ee; color:#0f7a4a; border:1px solid #a8e0c0;';
            default:
                return 'background:#f4f6f9; color:#495057; border:1px solid #d0d5dd;';
        }
    }

    /* ---------- Save / Restore list rows ---------- */
    function saveHoldState() {
        const rowsData = [];
        document.querySelectorAll('#holdTable tbody .hold-row').forEach(function (row) {
            const purposeWrap = row.querySelector('.purpose-text')?.parentElement;
            const noteEl = purposeWrap
                ? purposeWrap.querySelector('span[style*="italic"]')
                : null;
            const notes = noteEl
                ? noteEl.textContent.replace(/^\s*Note:\s*/, '').trim()
                : '';

            rowsData.push({
                bank:     row.dataset.bank     || '',
                category: row.dataset.category || '',
                status:   row.dataset.status   || '',
                project:  row.dataset.project  || '',
                ref:      row.dataset.ref      || '',
                purpose:  row.dataset.purpose  || '',
                amount:   row.dataset.amount   || '',
                yield:    row.dataset.yield    || '',
                maturity: row.dataset.maturity || '',
                refId:    row.querySelector('.ref-id')?.textContent || '',
                notes:    notes
            });
        });
        localStorage.setItem(HOLD_STORAGE_KEY, JSON.stringify(rowsData));
    }

    function buildRowFromData(d) {
        const tr = document.createElement('tr');
        tr.className = 'border-bottom hold-row';
        tr.dataset.bank     = d.bank;
        tr.dataset.category = d.category;
        tr.dataset.status   = d.status;
        tr.dataset.project  = d.project;
        tr.dataset.ref      = d.ref;
        tr.dataset.purpose  = d.purpose;
        tr.dataset.amount   = d.amount;
        tr.dataset.yield    = d.yield;
        tr.dataset.maturity = d.maturity;

        const badgeStyle = categoryBadgeStyle(d.category);
        const amountNum  = parseFloat(d.amount || 0);

        tr.innerHTML =
            '<td class="hold-td">' +
                '<span class="fw-bold text-dark d-block ref-id">' + (d.refId || '') + '</span>' +
                '<span class="text-muted small ref-no">' + (d.ref || '—') + '</span>' +
            '</td>' +
            '<td class="hold-td">' +
                '<div class="d-flex align-items-start gap-2 bank-cell">' +
                    '<i class="mdi mdi-bank-outline text-primary bank-icon"></i>' +
                    '<span class="fw-semibold text-dark bank-name">' + d.bank + '</span>' +
                '</div>' +
            '</td>' +
            '<td class="hold-td">' +
                '<span class="badge rounded-pill px-3 py-2 category-badge" style="' + badgeStyle + ' font-size:11px; font-weight:600;">' +
                    d.category +
                '</span>' +
            '</td>' +
            '<td class="hold-td">' +
                '<span class="text-dark project-name">' + d.project + '</span>' +
            '</td>' +
            '<td class="hold-td">' +
                '<span class="text-dark d-block fw-semibold purpose-text">' + d.purpose + '</span>' +
                (d.notes ? '<span class="text-muted" style="font-size:10px; font-style: italic;">Note: ' + d.notes + '</span>' : '') +
            '</td>' +
            '<td class="hold-td text-end">' +
                '<span class="fw-bold text-dark amount-text">$' + amountNum.toLocaleString() + '</span>' +
            '</td>' +
            '<td class="hold-td text-center">' +
                '<span class="fw-semibold text-dark yield-text">' + (d.yield || '—') + '</span>' +
            '</td>' +
            '<td class="hold-td text-center">' +
                '<span class="text-muted small d-inline-flex align-items-center gap-1 maturity-text">' +
                    '<i class="mdi mdi-calendar-outline"></i> ' + (d.maturity || '—') +
                '</span>' +
            '</td>' +
            '<td class="hold-td text-center">' +
                '<select class="form-select form-select-sm hold-status-select" data-row-status="' + d.status + '">' +
                    '<option value="Active Hold"' + (d.status === 'Active Hold' ? ' selected' : '') + '>Active Hold</option>' +
                    '<option value="Pending Release"' + (d.status === 'Pending Release' ? ' selected' : '') + '>Pending Release</option>' +
                    '<option value="Released"' + (d.status === 'Released' ? ' selected' : '') + '>Released</option>' +
                '</select>' +
            '</td>' +
            '<td class="hold-td text-center">' +
                '<div class="d-inline-flex align-items-center gap-1">' +
                    '<button type="button" class="btn btn-link p-0 text-primary edit-hold-btn" title="Edit" style="font-size: 17px; line-height: 1;">' +
                        '<i class="mdi mdi-pencil-outline"></i>' +
                    '</button>' +
                    '<button type="button" class="btn btn-link p-0 text-muted delete-hold-btn" title="Delete" style="font-size: 17px; line-height: 1;">' +
                        '<i class="mdi mdi-delete-outline"></i>' +
                    '</button>' +
                '</div>' +
            '</td>';

        return tr;
    }

    function restoreHoldState() {
        const raw = localStorage.getItem(HOLD_STORAGE_KEY);
        if (!raw) return;

        let saved;
        try { saved = JSON.parse(raw); } catch (e) { return; }
        if (!Array.isArray(saved)) return;

        const tbody = document.querySelector('#holdTable tbody');
        if (!tbody) return;
        tbody.innerHTML = '';

        saved.forEach(function (d) {
            tbody.appendChild(buildRowFromData(d));
        });
    }

    /* ---------- Save / Restore cards ---------- */
    function saveHoldCardsState() {
        const cardsData = [];
        document.querySelectorAll('#cardsViewWrapper .hold-card-item').forEach(function (card) {
            const d = card.dataset;
            cardsData.push({
                refId:    d.refId    || '',
                bank:     d.bank     || '',
                category: d.category || '',
                status:   d.status   || '',
                project:  card.querySelector('.text-primary.fw-semibold + .text-dark')?.textContent.trim() || '',
                purpose:  card.querySelector('.text-muted.mb-2')?.textContent.trim() || '',
                ref:      card.querySelector('.mb-3 .text-dark')?.textContent.trim() || '',
                amount:   card.querySelector('.fw-bold.text-dark[style*="16px"]')?.textContent.trim() || '',
                maturity: card.querySelector('.fw-semibold.text-dark[style*="12px"]')?.textContent.trim() || ''
            });
        });
        localStorage.setItem(HOLD_CARDS_STORAGE_KEY, JSON.stringify(cardsData));
    }

    function buildCardEl(d) {
        const badgeStyle = categoryBadgeStyle(d.category);
        const col = document.createElement('div');
        col.className = 'col-12 col-md-6 col-xl-4 hold-card-item';
        col.dataset.refId    = d.refId;
        col.dataset.bank     = d.bank;
        col.dataset.category = d.category;
        col.dataset.status   = d.status;

        const statusOptions = ['Active Hold', 'Pending Release', 'Released']
            .map(function (s) {
                return '<option value="' + s + '"' + (d.status === s ? ' selected' : '') + '>' + s + '</option>';
            }).join('');

        col.innerHTML =
            '<div class="card shadow-sm border-0 rounded-3 h-100">' +
                '<div class="card-body p-3">' +
                    '<div class="d-flex justify-content-between align-items-start mb-3">' +
                        '<span class="badge rounded-pill px-3 py-2" style="' + badgeStyle + ' font-size:10px; font-weight:700;">' +
                            (d.category || '').toUpperCase() +
                        '</span>' +
                        '<div class="d-flex align-items-center gap-2">' +
                            '<span class="text-muted" style="font-size:11px;">' + d.refId + '</span>' +
                            '<button type="button" class="btn btn-link p-0 text-primary edit-hold-card-btn" title="Edit" style="font-size:15px; line-height:1;">' +
                                '<i class="mdi mdi-pencil-outline"></i>' +
                            '</button>' +
                            '<button type="button" class="btn btn-link p-0 text-muted delete-hold-card-btn" title="Delete" style="font-size:15px; line-height:1;">' +
                                '<i class="mdi mdi-delete-outline"></i>' +
                            '</button>' +
                        '</div>' +
                    '</div>' +
                    '<div class="d-flex align-items-center gap-2 mb-2">' +
                        '<i class="mdi mdi-bank-outline text-primary"></i>' +
                        '<span class="fw-bold text-dark" style="font-size:13px;">' + d.bank + '</span>' +
                    '</div>' +
                    '<div class="text-muted mb-2" style="font-size:12px;">' + d.purpose + '</div>' +
                    '<div class="mb-1" style="font-size:11.5px;">' +
                        '<span class="text-primary fw-semibold">Project:</span> ' +
                        '<span class="text-dark">' + d.project + '</span>' +
                    '</div>' +
                    '<div class="mb-3" style="font-size:11px;">' +
                        '<span class="text-muted">Ref Guarantee #:</span> ' +
                        '<span class="text-dark">' + d.ref + '</span>' +
                    '</div>' +
                    '<div class="d-flex justify-content-between align-items-end mb-2">' +
                        '<div>' +
                            '<span class="text-muted d-block" style="font-size:10.5px;">Amount On Hold</span>' +
                            '<span class="fw-bold text-dark" style="font-size:16px;">' + d.amount + '</span>' +
                        '</div>' +
                        '<div class="text-end">' +
                            '<span class="text-muted d-block" style="font-size:10.5px;">Maturity / Yield</span>' +
                            '<span class="fw-semibold text-dark" style="font-size:12px;">' + d.maturity + '</span>' +
                        '</div>' +
                    '</div>' +
                    '<div class="d-flex justify-content-end align-items-center mt-3 pt-2 border-top">' +
                        '<select class="form-select form-select-sm hold-status-select" data-row-status="' + d.status + '" style="font-size:11px; min-width:130px; max-width:150px;">' +
                            statusOptions +
                        '</select>' +
                    '</div>' +
                '</div>' +
            '</div>';

        return col;
    }

    function restoreHoldCardsState() {
        const raw = localStorage.getItem(HOLD_CARDS_STORAGE_KEY);
        if (!raw) return;

        let saved;
        try { saved = JSON.parse(raw); } catch (e) { return; }
        if (!Array.isArray(saved)) return;

        const wrapper = document.getElementById('cardsViewWrapper');
        if (!wrapper) return;

        wrapper.querySelectorAll('.hold-card-item').forEach(function (c) { c.remove(); });

        saved.forEach(function (d) {
            wrapper.appendChild(buildCardEl(d));
        });
    }

    /* ---------- View Toggle ---------- */
    const viewListBtn  = document.getElementById('viewListBtn');
    const viewCardsBtn = document.getElementById('viewCardsBtn');
    const listWrapper  = document.getElementById('listViewWrapper');
    const cardsWrapper = document.getElementById('cardsViewWrapper');

    viewListBtn.addEventListener('click', function () {
        listWrapper.classList.remove('d-none');
        cardsWrapper.classList.add('d-none');
        viewListBtn.classList.add('active');
        viewCardsBtn.classList.remove('active');
        applyFilter();
    });

    viewCardsBtn.addEventListener('click', function () {
        cardsWrapper.classList.remove('d-none');
        listWrapper.classList.add('d-none');
        viewCardsBtn.classList.add('active');
        viewListBtn.classList.remove('active');
        applyFilter();
    });

    /* ---------- Filter Elements ---------- */
    const searchInput    = document.getElementById('holdSearch');
    const bankFilter     = document.getElementById('holdBankFilter');
    const categoryFilter = document.getElementById('holdCategoryFilter');
    const statusFilter   = document.getElementById('holdStatusFilter');

    const footerText = document.getElementById('listFooterText');

    function applyFilter() {

        const search   = (searchInput?.value || '').toLowerCase().trim();
        const bank     = (bankFilter?.value || '').toLowerCase().trim();
        const category = (categoryFilter?.value || '').toLowerCase().trim();
        const status   = (statusFilter?.value || '').toLowerCase().trim();

        let visibleRows = 0;
        const rows = document.querySelectorAll('#holdTable tbody .hold-row');

        rows.forEach(function (row) {
            const rowBank     = (row.getAttribute('data-bank') || '').toLowerCase();
            const rowCategory = (row.getAttribute('data-category') || '').toLowerCase();
            const rowStatus   = (row.getAttribute('data-status') || '').toLowerCase();
            const rowText     = row.innerText.toLowerCase();

            const match =
                (search === ''   || rowText.includes(search)) &&
                (bank === ''     || rowBank.includes(bank)) &&
                (category === '' || rowCategory.includes(category)) &&
                (status === ''   || rowStatus.includes(status));

            row.style.display = match ? '' : 'none';
            if (match) visibleRows++;
        });

        if (footerText) {
            footerText.textContent =
                'Showing ' + visibleRows + ' of ' + rows.length + ' Bank Hold Entries';
        }

        const cards = document.querySelectorAll('#cardsViewWrapper .hold-card-item');
        cards.forEach(function (card) {
            const cardBank     = (card.getAttribute('data-bank') || '').toLowerCase();
            const cardCategory = (card.getAttribute('data-category') || '').toLowerCase();
            const cardStatus   = (card.getAttribute('data-status') || '').toLowerCase();
            const cardText     = card.innerText.toLowerCase();

            const match =
                (search === ''   || cardText.includes(search)) &&
                (bank === ''     || cardBank.includes(bank)) &&
                (category === '' || cardCategory.includes(category)) &&
                (status === ''   || cardStatus.includes(status));

            card.style.display = match ? '' : 'none';
        });
    }

    if (searchInput)    searchInput.addEventListener('input', applyFilter);
    if (bankFilter)     bankFilter.addEventListener('change', applyFilter);
    if (categoryFilter) categoryFilter.addEventListener('change', applyFilter);
    if (statusFilter)   statusFilter.addEventListener('change', applyFilter);


    function bindStatusDropdown(sel) {
        if (sel.dataset.bound === '1') return;
        sel.dataset.bound = '1';

        const current = sel.getAttribute('data-row-status') || sel.value;
        sel.setAttribute('data-current', current);

        sel.addEventListener('change', function () {
            const newStatus = sel.value;

            /* List row? */
            const row = sel.closest('.hold-row');
            if (row) {
                row.setAttribute('data-status', newStatus);
                sel.setAttribute('data-current', newStatus);
                saveHoldState();
                applyFilter();
                return;
            }

            /* Card? */
            const card = sel.closest('.hold-card-item');
            if (card) {
                card.setAttribute('data-status', newStatus);
                sel.setAttribute('data-current', newStatus);
                saveHoldCardsState();
                applyFilter();
            }
        });
    }

    document.querySelectorAll('.hold-status-select').forEach(bindStatusDropdown);

    /* ============================================================= */
    /* ---------- EXPORT CSV ---------- */
    /* ============================================================= */
    const exportCsvBtn = document.getElementById('holdExportCsvBtn');
    if (exportCsvBtn) {
        exportCsvBtn.addEventListener('click', function () {
            const headers = [
                'Ref ID', 'Guarantee #', 'Bank Account', 'Hold Category',
                'Project Site', 'Purpose', 'Hold Amount', 'Interest',
                'Maturity', 'Status'
            ];

            const csvRows = [headers.join(',')];

            document.querySelectorAll('#holdTable tbody .hold-row').forEach(function (row) {
                if (row.style.display === 'none') return;

                const cells = row.querySelectorAll('td');
                const refId = (cells[0].innerText || '').split('\n')[0].trim();
                const refNo = (cells[0].innerText || '').split('\n')[1]?.trim() || '';
                const bank  = cells[1].innerText.trim();
                const cat   = cells[2].innerText.trim();
                const proj  = cells[3].innerText.trim();
                const purp  = cells[4].innerText.trim().replace(/\s+/g, ' ').replace(/,/g, ';');
                const amt   = cells[5].innerText.trim();
                const rate  = cells[6].innerText.trim();
                const mat   = cells[7].innerText.trim();
                const stat  = cells[8].querySelector('select')?.value || cells[8].innerText.trim();

                csvRows.push([
                    '"' + refId + '"',
                    '"' + refNo + '"',
                    '"' + bank + '"',
                    '"' + cat + '"',
                    '"' + proj + '"',
                    '"' + purp + '"',
                    '"' + amt + '"',
                    '"' + rate + '"',
                    '"' + mat + '"',
                    '"' + stat + '"'
                ].join(','));
            });

            const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const url  = URL.createObjectURL(blob);
            const a    = document.createElement('a');
            a.href     = url;
            a.download = 'bank_hold_entries_' + new Date().toISOString().slice(0,10) + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }

    /* ============================================================= */
    /* ---------- HOLD ENTRY MODAL (Create / Edit) ---------- */
    /* ============================================================= */
    const holdEntryModalEl = document.getElementById('holdEntryModal');
    const holdEntryTitle   = document.getElementById('holdEntryTitle');
    const holdEntryForm    = document.getElementById('holdEntryForm');
    const heBank           = document.getElementById('heBank');
    const heCategory       = document.getElementById('heCategory');
    const heProject        = document.getElementById('heProject');
    const heRef            = document.getElementById('heRef');
    const hePurpose        = document.getElementById('hePurpose');
    const heAmount         = document.getElementById('heAmount');
    const heYield          = document.getElementById('heYield');
    const heMaturity       = document.getElementById('heMaturity');
    const heStatus         = document.getElementById('heStatus');
    const heNotes          = document.getElementById('heNotes');
    const holdEntrySubmitBtn   = document.getElementById('holdEntrySubmitBtn');
    const holdEntrySubmitLabel = document.getElementById('holdEntrySubmitLabel');

    let editingRow = null;
    let holdCounter = 205;

    function resetHoldEntryForm() {
        editingRow = null;

        if (heBank)      heBank.selectedIndex     = 0;
        if (heCategory)  heCategory.selectedIndex = 0;
        if (heProject)   heProject.selectedIndex  = 0;
        if (heRef)       heRef.value              = '';
        if (hePurpose)   hePurpose.value          = '';
        if (heAmount)    heAmount.value           = '';
        if (heYield)     heYield.value            = '';
        if (heMaturity)  heMaturity.value         = '';
        if (heStatus)    heStatus.selectedIndex   = 0;
        if (heNotes)     heNotes.value            = '';

        if (holdEntryTitle)        holdEntryTitle.textContent = 'Log New Bank Hold Amount / Margin Entry';
        if (holdEntrySubmitLabel)  holdEntrySubmitLabel.textContent = 'Record Bank Hold Amount';
    }

    function openHoldEntryModal(row) {
        if (row) {
            /* Edit mode (row) */
            editingRow = row;
            const d = row.dataset;

            if (heBank)     heBank.value        = d.bank     || '';
            if (heCategory) heCategory.value    = d.category || '';
            if (heProject)  heProject.value     = d.project  || '';
            if (heRef)      heRef.value         = d.ref      || '';
            if (hePurpose)  hePurpose.value     = d.purpose  || '';
            if (heAmount)   heAmount.value      = d.amount   || '';
            if (heYield)    heYield.value       = d.yield    || '';
            if (heMaturity) heMaturity.value    = d.maturity || '';
            if (heStatus)   heStatus.value      = d.status   || 'Active Hold';
            if (heNotes)    heNotes.value       = '';

            if (holdEntryTitle)        holdEntryTitle.textContent = 'Update Bank Hold Amount / Margin Entry';
            if (holdEntrySubmitLabel)  holdEntrySubmitLabel.textContent = 'Update Bank Hold Amount';
        } else {
            /* Create mode */
            resetHoldEntryForm();
        }

        if (holdEntryModalEl) {
            bootstrap.Modal.getOrCreateInstance(holdEntryModalEl).show();
        }
    }

    /* Open modal from "+ Record Bank Hold Amount" */
    const addBtn = document.getElementById('holdAddBtn');
    if (addBtn) {
        addBtn.addEventListener('click', function () {
            openHoldEntryModal(null);
        });
    }

    /* Build new table row from modal data */
    function buildHoldRowFromModal() {
        const bank      = heBank.value;
        const category  = heCategory.value;
        const project   = heProject.value;
        const ref       = heRef.value.trim() || '—';
        const purpose   = hePurpose.value.trim() || '—';
        const amount    = parseFloat(heAmount.value || 0);
        const yieldPct  = heYield.value.trim() || '—';
        const maturity  = heMaturity.value || '—';
        const status    = heStatus.value;
        const notes     = heNotes.value.trim();

        const refId = 'BH-' + holdCounter;

        return buildRowFromData({
            bank: bank,
            category: category,
            status: status,
            project: project,
            ref: ref,
            purpose: purpose,
            amount: amount,
            yield: yieldPct,
            maturity: maturity,
            refId: refId,
            notes: notes
        });
    }

    /* Bind edit/delete events to a list row */
    function bindHoldRowEvents(row) {
        const editBtn   = row.querySelector('.edit-hold-btn');
        const deleteBtn = row.querySelector('.delete-hold-btn');
        const statusSel = row.querySelector('.hold-status-select');

        if (editBtn) {
            editBtn.addEventListener('click', function () {
                openHoldEntryModal(row);
            });
        }

        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                const refId = row.querySelector('.ref-id')?.textContent || 'this entry';
                if (confirm('Delete Bank Hold ' + refId + '?')) {
                    row.remove();
                    saveHoldState();
                    applyFilter();
                }
            });
        }

        if (statusSel) {
            bindStatusDropdown(statusSel);
        }
    }

    /* ============================================================= */
    /* ---------- CARD VIEW: edit / delete ---------- */
    /* ============================================================= */
    function openHoldCardModal(card) {
        const d = card.dataset;

        /* Fake a row-like object so existing modal edit flow works */
        const proxyRow = {
            dataset: {
                bank:     d.bank     || '',
                category: d.category || '',
                project:  card.querySelector('.text-primary.fw-semibold + .text-dark')?.textContent.trim() || '',
                ref:      card.querySelector('.mb-3 .text-dark')?.textContent.trim() || '',
                purpose:  card.querySelector('.text-muted.mb-2')?.textContent.trim() || '',
                amount:   (card.querySelector('.fw-bold.text-dark[style*="16px"]')?.textContent || '').replace(/[^0-9.]/g, ''),
                yield:    (card.querySelector('.fw-semibold.text-dark[style*="12px"] .text-muted')?.textContent || '').replace(/[()]/g, '').trim(),
                maturity: (card.querySelector('.fw-semibold.text-dark[style*="12px"]')?.textContent || '').trim().split(' ')[0] || '',
                status:   card.dataset.status || 'Active Hold'
            },
            _isCard: true,
            _cardEl: card
        };

        editingRow = proxyRow;

        if (heBank)     heBank.value     = proxyRow.dataset.bank;
        if (heCategory) heCategory.value = proxyRow.dataset.category;
        if (heProject)  heProject.value  = proxyRow.dataset.project;
        if (heRef)      heRef.value      = proxyRow.dataset.ref;
        if (hePurpose)  hePurpose.value  = proxyRow.dataset.purpose;
        if (heAmount)   heAmount.value   = proxyRow.dataset.amount;
        if (heYield)    heYield.value    = proxyRow.dataset.yield;
        if (heMaturity) heMaturity.value = proxyRow.dataset.maturity;
        if (heStatus)   heStatus.value   = proxyRow.dataset.status;
        if (heNotes)    heNotes.value    = '';

        if (holdEntryTitle)       holdEntryTitle.textContent       = 'Update Bank Hold Amount / Margin Entry';
        if (holdEntrySubmitLabel) holdEntrySubmitLabel.textContent = 'Update Bank Hold Amount';

        bootstrap.Modal.getOrCreateInstance(holdEntryModalEl).show();
    }

    function bindHoldCardEvents(card) {
        if (card.dataset.bound === '1') return;
        card.dataset.bound = '1';

        const editBtn   = card.querySelector('.edit-hold-card-btn');
        const deleteBtn = card.querySelector('.delete-hold-card-btn');
        const statusSel = card.querySelector('.hold-status-select');

        if (editBtn) {
            editBtn.addEventListener('click', function () {
                openHoldCardModal(card);
            });
        }

        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                const refId = card.dataset.refId || 'this card';
                if (confirm('Delete Bank Hold ' + refId + '?')) {
                    card.remove();
                    saveHoldCardsState();
                    applyFilter();
                }
            });
        }

        if (statusSel) {
            bindStatusDropdown(statusSel);
        }
    }

    /* ---------- Restore & bind on load ---------- */
    restoreHoldState();
    document.querySelectorAll('#holdTable tbody .hold-row').forEach(bindHoldRowEvents);

    restoreHoldCardsState();
    document.querySelectorAll('#cardsViewWrapper .hold-card-item').forEach(bindHoldCardEvents);

    /* Re-bind any status dropdowns that appeared after restore */
    document.querySelectorAll('.hold-status-select').forEach(bindStatusDropdown);

    /* Submit from modal */
    if (holdEntrySubmitBtn && holdEntryModalEl) {
        holdEntrySubmitBtn.addEventListener('click', function () {

            const bank      = heBank.value;
            const category  = heCategory.value;
            const project   = heProject.value;
            const ref       = heRef.value.trim();
            const purpose   = hePurpose.value.trim();
            const amount    = parseFloat(heAmount.value || 0);
            const yieldPct  = heYield.value.trim() || '—';
            const maturity  = heMaturity.value;
            const status    = heStatus.value;
            const notes     = heNotes.value.trim();

            if (!bank || !category || !project || !purpose || !amount || !maturity) {
                alert('Please fill all required fields.');
                return;
            }

            /* -------- CARD EDIT PATH -------- */
            if (editingRow && editingRow._isCard && editingRow._cardEl) {
                const card = editingRow._cardEl;

                card.dataset.bank     = bank;
                card.dataset.category = category;
                card.dataset.status   = status;
                card.dataset.project  = project;
                card.dataset.ref      = ref || '—';

                const badgeStyle = categoryBadgeStyle(category);

                const badgeEl = card.querySelector('.badge.rounded-pill');
                if (badgeEl) {
                    badgeEl.outerHTML =
                        '<span class="badge rounded-pill px-3 py-2" style="' + badgeStyle + ' font-size:10px; font-weight:700;">' +
                            category.toUpperCase() +
                        '</span>';
                }

                const bankEl = card.querySelector('.fw-bold.text-dark[style*="13px"]');
                if (bankEl) bankEl.textContent = bank;

                const purposeEl = card.querySelector('.text-muted.mb-2');
                if (purposeEl) purposeEl.textContent = purpose;

                const projectEl = card.querySelector('.text-primary.fw-semibold + .text-dark');
                if (projectEl) projectEl.textContent = project;

                const refEl = card.querySelector('.mb-3 .text-dark');
                if (refEl) refEl.textContent = ref || '—';

                const amountEl = card.querySelector('.fw-bold.text-dark[style*="16px"]');
                if (amountEl) amountEl.textContent = '$' + amount.toLocaleString();

                const maturityWrap = card.querySelector('.fw-semibold.text-dark[style*="12px"]');
                if (maturityWrap) {
                    maturityWrap.innerHTML = maturity +
                        (yieldPct && yieldPct !== '—' ? ' <span class="text-muted">(' + yieldPct + ')</span>' : '');
                }

                const sel = card.querySelector('.hold-status-select');
                if (sel) {
                    sel.value = status;
                    sel.setAttribute('data-row-status', status);
                    sel.setAttribute('data-current', status);
                }

                saveHoldCardsState();
                applyFilter();

                bootstrap.Modal.getOrCreateInstance(holdEntryModalEl).hide();
                editingRow = null;
                return;
            }

            /* -------- LIST EDIT PATH -------- */
            if (editingRow) {
                const d = editingRow.dataset;

                d.bank     = bank;
                d.category = category;
                d.project  = project;
                d.ref      = ref || '—';
                d.purpose  = purpose;
                d.amount   = amount;
                d.yield    = yieldPct;
                d.maturity = maturity;
                d.status   = status;

                const cells = editingRow.querySelectorAll('td');

                cells[0].innerHTML =
                    '<span class="fw-bold text-dark d-block ref-id">' + (editingRow.querySelector('.ref-id')?.textContent || 'BH-XXX') + '</span>' +
                    '<span class="text-muted small ref-no">' + (d.ref || '—') + '</span>';

                cells[1].innerHTML =
                    '<div class="d-flex align-items-start gap-2 bank-cell">' +
                        '<i class="mdi mdi-bank-outline text-primary bank-icon"></i>' +
                        '<span class="fw-semibold text-dark bank-name">' + bank + '</span>' +
                    '</div>';

                const badgeStyle = categoryBadgeStyle(category);
                cells[2].innerHTML =
                    '<span class="badge rounded-pill px-3 py-2 category-badge" style="' + badgeStyle + ' font-size:11px; font-weight:600;">' +
                        category +
                    '</span>';

                cells[3].innerHTML = '<span class="text-dark project-name">' + project + '</span>';

                cells[4].innerHTML =
                    '<span class="text-dark d-block fw-semibold purpose-text">' + purpose + '</span>' +
                    (notes ? '<span class="text-muted" style="font-size:10px; font-style: italic;">Note: ' + notes + '</span>' : '');

                cells[5].innerHTML = '<span class="fw-bold text-dark amount-text">$' + amount.toLocaleString() + '</span>';
                cells[6].innerHTML = '<span class="fw-semibold text-dark yield-text">' + yieldPct + '</span>';

                cells[7].innerHTML =
                    '<span class="text-muted small d-inline-flex align-items-center gap-1 maturity-text">' +
                        '<i class="mdi mdi-calendar-outline"></i> ' + maturity +
                    '</span>';

                const sel = cells[8].querySelector('select');
                if (sel) {
                    sel.value = status;
                    sel.setAttribute('data-row-status', status);
                    sel.setAttribute('data-current', status);
                }

                saveHoldState();
                applyFilter();
            } else {
                /* -------- CREATE new row -------- */
                const newRow = buildHoldRowFromModal();
                holdCounter++;

                document.getElementById('holdTable').querySelector('tbody').appendChild(newRow);
                bindHoldRowEvents(newRow);
                saveHoldState();
                applyFilter();
            }

            bootstrap.Modal.getOrCreateInstance(holdEntryModalEl).hide();
            editingRow = null;
        });
    }

});

</script>

@endsection
