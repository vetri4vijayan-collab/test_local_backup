@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="row g-3 g-lg-4 mb-4 ">

    <!-- Gross Billed Value -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-lg-4">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Gross Billed Value
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-primary text-break">
                        ₹ 12,80,00,000
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small">
                    4 Client RA Bills
                </span>

            </div>
        </div>
    </div>


    <!-- Certified Value -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-lg-4">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Certified Value
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-success text-break">
                        ₹ 12,37,00,000
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-dark small">
                    From Planning &amp; QS
                </span>

            </div>
        </div>
    </div>


    <!-- Retention Deposit Held -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-lg-4">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Retention Deposit Held
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-danger text-break">
                        ₹ 61,85,000
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small">
                    5% Contractual Hold
                </span>

            </div>
        </div>
    </div>


    <!-- Realized Cash -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-lg-4">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Realized Cash
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-warning text-break">
                        ₹ 5,52,27,000
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small">
                    Credited to Escrow
                </span>

            </div>
        </div>
    </div>


    <!-- Outstanding Receivable -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-lg-4">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Outstanding Receivable
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-primary text-break">
                        ₹ 5,73,40,000
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small">
                    Pending Payouts
                </span>

            </div>
        </div>
    </div>

</div>

<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
    <div class="card-body p-3">

       <div class="filter-layout d-flex flex-column flex-md-row align-items-stretch align-items-md-center justify-content-between gap-3">

    {{-- Search --}}
    <div class="filter-search flex-grow-1" style="max-width: 500px;">
        <div class="position-relative">

            <span
                class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                style="pointer-events: none;"
            >
                <i class="mdi mdi-magnify fs-5"></i>
            </span>

            <input
                id="hr-search-field"
                type="text"
                placeholder="Search staff, designation or email"
                class="form-control form-control-sm ps-7 bg-light border-0 rounded-3 text-secondary"
            />

        </div>
    </div>


    {{-- Right Filters --}}
    <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2">

        {{-- Project Filter --}}
        <div class="filter-project">
            <select
                id="projectFilter"
                class="form-select form-select-sm bg-light border-0 rounded-3"
                style="min-width: 200px;"
            >
                <option value="">All Projects</option>
                <option value="maa-met-c4">MAA-MET-C4 - Chennai Metro Phase 2 Corridor 4</option>
                <option value="ady-res">ADY-RES - Adyar Residential Project</option>
                <option value="ecr-brg">ECR-BRG - ECR Bridge Works</option>
                <option value="sip-log">SIP-LOG - SIP Logistics Project</option>
                <option value="elc-hq">ELC-HQ - Elysium Head Office</option>
            </select>
        </div>


        {{-- Status Filter --}}
        <div class="filter-status">
            <select
                id="statusFilter"
                class="form-select form-select-sm bg-light border-0 rounded-3"
                style="min-width: 160px;"
            >
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="pending">Pending</option>
                <option value="completed">Completed</option>
                <option value="on-hold">On Hold</option>
                <option value="cancelled">Cancelled</option>
            </select>
        </div>

    </div>

</div>
    </div>
</div>

<div class="deployment-table-wrapper table-responsive">

    <table class="table table-hover align-middle mb-0 ra-bill-table">

        <thead class="table-light">
            <tr>
                <th scope="col" class="text-nowrap">RA Bill No</th>
                <th scope="col" class="text-nowrap">Date</th>
                <th scope="col">Client &amp; Project</th>
                <th scope="col" class="text-end text-nowrap">Gross Claim</th>
                <th scope="col" class="text-end text-nowrap">Certified Amt</th>
                <th scope="col" class="text-end text-nowrap">Retention (5%)</th>
                <th scope="col" class="text-end text-nowrap">TDS (194C + GST)</th>
                <th scope="col" class="text-end text-nowrap">Net Certified</th>
                <th scope="col" class="text-end text-nowrap">Amount Realized</th>
                <th scope="col" class="text-end text-nowrap">Balance Due</th>
                <th scope="col" class="text-center text-nowrap">Status</th>
                <th scope="col" class="text-center text-nowrap">Actions</th>
            </tr>
        </thead>

        <tbody>

            {{-- RA Bill #06 --}}
            <tr>

                <td>
                    <span class="text-primary fw-bold text-nowrap">
                        RA Bill #06
                    </span>
                </td>

                <td>
                    <span class="text-muted text-nowrap">
                        2026-07-05
                    </span>
                </td>

                <td>
                    <div class="fw-semibold text-dark text-nowrap">
                        Chennai Metro Rail Limited
                    </div>

                    <small class="text-muted text-nowrap">
                        Metro Line Extension - Phase 3
                    </small>
                </td>

                <td class="text-end">
                    <span class="fw-semibold text-nowrap">
                        ₹ 4,20,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-semibold text-nowrap">
                        ₹ 4,05,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="text-muted text-nowrap">
                        ₹ 20,25,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="text-muted text-nowrap">
                        ₹ 16,20,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-dark text-nowrap">
                        ₹ 3,68,55,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-success text-nowrap">
                        ₹ 3,68,55,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-success text-nowrap">
                        ₹ 0
                    </span>
                </td>

                <td class="text-center">
                    <span class="badge rounded-pill bg-success-subtle text-success px-3 py-2">
                        Received
                    </span>
                </td>

                <td class="text-center">
                   <button
                            type="button"
                            class="btn btn-sm btn-light border"
                            title="View"
                            data-bs-toggle="modal"
                            data-bs-target="#raBillViewModal"
                        >
                            <i class="mdi mdi-eye-outline"></i>
                        </button>
                </td>

            </tr>


            {{-- RA Bill #07 --}}
            <tr>

                <td>
                    <span class="text-primary fw-bold text-nowrap">
                        RA Bill #07
                    </span>
                </td>

                <td>
                    <span class="text-muted text-nowrap">
                        2026-07-20
                    </span>
                </td>

                <td>
                    <div class="fw-semibold text-dark text-nowrap">
                        National Highways Authority (NHAI)
                    </div>

                    <small class="text-muted text-nowrap">
                        Coastal Expressway Bridge
                    </small>
                </td>

                <td class="text-end">
                    <span class="fw-semibold text-nowrap">
                        ₹ 4,85,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-semibold text-nowrap">
                        ₹ 4,70,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="text-muted text-nowrap">
                        ₹ 23,50,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="text-muted text-nowrap">
                        ₹ 18,80,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-dark text-nowrap">
                        ₹ 4,27,70,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-warning text-nowrap">
                        ₹ 0
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-danger text-nowrap">
                        ₹ 4,27,70,000
                    </span>
                </td>

                <td class="text-center">
                    <span class="badge rounded-pill bg-warning-subtle text-warning px-3 py-2 text-nowrap">
                        Certified - Pending Payout
                    </span>
                </td>

                <td class="text-center">
                    <div class="d-flex justify-content-center gap-1">

                         <button
                            type="button"
                            class="btn btn-sm btn-light border"
                            title="View"
                            data-bs-toggle="modal"
                            data-bs-target="#raBillViewModal"
                        >
                            <i class="mdi mdi-eye-outline"></i>
                        </button>

                        <button
                            type="button"
                            class="btn btn-sm btn-primary"
                            title="Realize"
                            data-bs-toggle="modal"
                            data-bs-target="#clientRARealizationModal"
                        >
                            <i class="mdi mdi-cash-check"></i>
                        </button>
                    </div>
                </td>
            </tr>


            {{-- RA Bill #12 --}}
            <tr>

                <td>
                    <span class="text-primary fw-bold text-nowrap">
                        RA Bill #12
                    </span>
                </td>

                <td>
                    <span class="text-muted text-nowrap">
                        2026-07-18
                    </span>
                </td>

                <td>
                    <div class="fw-semibold text-dark text-nowrap">
                        State Metro Rail Corp
                    </div>

                    <small class="text-muted text-nowrap">
                        Metro Line Extension - Phase 3
                    </small>
                </td>

                <td class="text-end">
                    <span class="fw-semibold text-nowrap">
                        ₹ 2,80,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-semibold text-nowrap">
                        ₹ 2,70,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="text-muted text-nowrap">
                        ₹ 13,50,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="text-muted text-nowrap">
                        ₹ 10,80,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-dark text-nowrap">
                        ₹ 2,45,70,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-success text-nowrap">
                        ₹ 1,00,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-danger text-nowrap">
                        ₹ 1,45,70,000
                    </span>
                </td>

                <td class="text-center">
                    <span class="badge rounded-pill bg-info-subtle text-info px-3 py-2 text-nowrap">
                        Partially Received
                    </span>
                </td>

                <td class="text-center">
                    <div class="d-flex justify-content-center gap-1">

                        <button
                            type="button"
                            class="btn btn-sm btn-light border"
                            title="View"
                            data-bs-toggle="modal"
                            data-bs-target="#raBillViewModal"
                        >
                            <i class="mdi mdi-eye-outline"></i>
                        </button>

                        <button
                            type="button"
                            class="btn btn-sm btn-primary"
                            title="Realize"
                            data-bs-toggle="modal"
                            data-bs-target="#clientRARealizationModal"
                        >
                            <i class="mdi mdi-cash-check"></i>
                        </button>

                    </div>
                </td>

            </tr>
            {{-- RA Bill #08 --}}
            <tr>

                <td>
                    <span class="text-primary fw-bold text-nowrap">
                        RA Bill #08
                    </span>
                </td>

                <td>
                    <span class="text-muted text-nowrap">
                        2026-07-10
                    </span>
                </td>

                <td>
                    <div class="fw-semibold text-dark text-nowrap">
                        Urban Infrastructure Developers
                    </div>

                    <small class="text-muted text-nowrap">
                        Skyline Premium Residences
                    </small>
                </td>

                <td class="text-end">
                    <span class="fw-semibold text-nowrap">
                        ₹ 95,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-semibold text-nowrap">
                        ₹ 92,00,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="text-muted text-nowrap">
                        ₹ 4,60,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="text-muted text-nowrap">
                        ₹ 3,68,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-dark text-nowrap">
                        ₹ 83,72,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-success text-nowrap">
                        ₹ 83,72,000
                    </span>
                </td>

                <td class="text-end">
                    <span class="fw-bold text-success text-nowrap">
                        ₹ 0
                    </span>
                </td>

                <td class="text-center">
                    <span class="badge rounded-pill bg-success-subtle text-success px-3 py-2">
                        Received
                    </span>
                </td>

                <td class="text-center">
                     <button
                            type="button"
                            class="btn btn-sm btn-light border"
                            title="View"
                            data-bs-toggle="modal"
                            data-bs-target="#raBillViewModal"
                        >
                            <i class="mdi mdi-eye-outline"></i>
                        </button>
                </td>

            </tr>
        </tbody>

    </table>

</div>

<div
    class="modal fade"
    id="raBillViewModal"
    tabindex="-1"
    aria-labelledby="raBillViewModalLabel"
    aria-hidden="true">
<div class="modal-dialog modal-dialog-centered modal-lg">

<div class="modal-content border-0 rounded-4 shadow">

    {{-- Header --}}
    <div class="modal-header border-0 px-4 pt-4 pb-2 bg-primary ">

        <div>
            <h5
                class="modal-title fw-bold text-white mb-1"
                id="raBillViewModalLabel"
            >
                RA Bill #06
            </h5>

            <h6 class="fw-bold mb-1 text-white">
                Chennai Metro Rail Limited
            </h6>

            <p class="text-muted small mb-0">
                Metro Line Extension - Phase 3
            </p>
        </div>

        <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
        ></button>

    </div>


    {{-- Body --}}
    <div class="modal-body px-4 py-3">

        <div class="border rounded-3 p-3 mb-3 bg-light">

            <div class="row g-3">

                {{-- Gross --}}
                <div class="col-12 col-md-6">
                    <div class="text-muted small mb-1">
                        Gross Claimed Value
                    </div>

                    <div class="fw-bold fs-6">
                        ₹ 4,20,00,000
                    </div>
                </div>


                {{-- Certified --}}
                <div class="col-12 col-md-6">
                    <div class="text-muted small mb-1">
                        Certified Amount
                    </div>

                    <div class="fw-bold fs-6 text-success">
                        ₹ 4,05,00,000
                    </div>
                </div>


                {{-- Retention --}}
                <div class="col-12 col-md-6">
                    <div class="text-muted small mb-1">
                        Retention Deducted (5%)
                    </div>

                    <div class="fw-semibold">
                        - ₹ 20,25,000
                    </div>
                </div>


                {{-- TDS --}}
                <div class="col-12 col-md-6">
                    <div class="text-muted small mb-1">
                        TDS u/s 194C &amp; GST TDS
                    </div>

                    <div class="fw-semibold">
                        - ₹ 16,20,000
                    </div>
                </div>

            </div>

        </div>


        {{-- Net Certified --}}
        <div
            class="d-flex justify-content-between align-items-center
                    border rounded-3 px-3 py-3 mb-4"
        >
            <span class="fw-bold">
                Net Payable Certified
            </span>

            <span class="fw-bold fs-5 text-primary">
                ₹ 3,68,55,000
            </span>
        </div>


        {{-- Bank Realization Voucher --}}
        <div class="mb-3">

            <div class="d-flex align-items-center gap-2 mb-3">

                <i class="mdi mdi-bank-check fs-5 text-primary"></i>

                <h6 class="fw-bold mb-0">
                    Bank Realization Voucher
                </h6>

            </div>


            <div class="border rounded-3 p-3">

                <div class="row g-3">

                    {{-- Total Realized --}}
                    <div class="col-12 col-md-6">

                        <div class="text-muted small mb-1">
                            Total Realized &amp; Credited
                        </div>

                        <div class="fw-bold text-success">
                            ₹ 3,68,55,000
                        </div>

                    </div>


                    {{-- Bank --}}
                    <div class="col-12 col-md-6">

                        <div class="text-muted small mb-1">
                            Bank Escrow Account
                        </div>

                        <div class="fw-semibold">
                            ICICI Bank Ltd - 269805000359
                        </div>

                    </div>


                    {{-- UTR --}}
                    <div class="col-12">

                        <div class="text-muted small mb-1">
                            Bank UTR Ref No
                        </div>

                        <div class="fw-semibold font-monospace">
                            CMRLUTR998210
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Footer --}}
    <div class="modal-footer border-0 px-4 pb-4 pt-2">

        <button
            type="button"
            class="btn btn-primary rounded-3"
        >
            <i class="mdi mdi-printer-outline me-1"></i>
            Print Receipt Voucher
        </button>

        <button
            type="button"
            class="btn btn-light border rounded-3"
            data-bs-dismiss="modal"
        >
            Close
        </button>

    </div>

</div>

</div>

    
</div>

<div
    class="modal fade"
    id="clientRARealizationModal"
    tabindex="-1"
    aria-labelledby="clientRARealizationModalLabel"
    aria-hidden="true"
>
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-4 shadow">

            <div class="modal-header border-0 px-4 pt-4 pb-2 bg-primary">
                <div>
                    <h5
                        class="modal-title fw-bold text-white mb-1"
                        id="clientRARealizationModalLabel"
                    >
                        Record Client RA Payment Realization
                    </h5>

                    <p class="text-muted small mb-0">
                        Post incoming cash bank transfer against RA Bill #07
                    </p>
                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>

            <div class="modal-body px-4 py-3">

                <div class="border rounded-3 p-3 mb-4 bg-light">
                    <div class="row g-3">

                        <div class="col-12 col-md-6">
                            <div class="text-muted small mb-1">
                                Client &amp; Project
                            </div>

                            <div class="fw-semibold">
                                National Highways Authority (NHAI)
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <div class="text-muted small mb-1">
                                Net Certified Value
                            </div>

                            <div class="fw-bold text-primary">
                                ₹ 4,27,70,000
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <div class="text-muted small mb-1">
                                Already Realized
                            </div>

                            <div class="fw-semibold text-success">
                                ₹ 0
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <div class="text-muted small mb-1">
                                Current Outstanding Balance
                            </div>

                            <div class="fw-bold text-danger">
                                ₹ 4,27,70,000
                            </div>
                        </div>

                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">
                        Realized Amount Credited (₹)
                    </label>

                    <input
                        type="number"
                        class="form-control"
                        placeholder="Enter realized amount"
                        min="0"
                        step="0.01"
                    >
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">
                        Deposit Bank Escrow Account
                    </label>

                    <select class="form-select">
                        <option value="">
                            Select Deposit Bank Escrow Account
                        </option>
                        <option value="icici">
                            ICICI Bank Escrow A/c - 269805000359
                        </option>
                        <option value="hdfc">
                            HDFC Corporate Escrow A/c - 502000889123
                        </option>
                        <option value="sbi">
                            SBI Commercial Project A/c - 302819001
                        </option>
                        <option value="axis">
                            Axis Bank Term Loan A/c - 918020011
                        </option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">
                        Bank UTR / Chq Ref No
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        placeholder="Enter bank UTR / cheque reference number"
                    >
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">
                        Realization Credit Date
                    </label>

                    <input
                        type="date"
                        class="form-control"
                        value="2026-09-15"
                    >
                </div>

                <div class="mb-0">
                    <label class="form-label fw-semibold">
                        Remarks / Voucher Note
                    </label>

                    <textarea
                        class="form-control"
                        rows="2"
                        placeholder="Enter remarks or voucher note"
                    ></textarea>
                </div>

            </div>

            <div class="modal-footer border-0 px-4 pb-2  pt-2">

                <button
                    type="button"
                    class="btn btn-light border rounded-3"
                    data-bs-dismiss="modal"
                >
                    <i class="mdi mdi-close me-1"></i>
                    Cancel
                </button>

                <button
                    type="button"
                    class="btn btn-primary rounded-3"
                >
                    <i class="mdi mdi-cash-check me-1"></i>
                    Post Cash Receipt Voucher
                </button>

            </div>

        </div>
    </div>
</div>
<style>

    
    .deployment-table-wrapper {
        width: 100%;
        max-width: 100%;
        overflow-x: auto;
        overflow-y: hidden;
        -webkit-overflow-scrolling: touch;
    }

    .ra-bill-table {
        width: 100%;
        min-width: 1500px;
        table-layout: auto;
        margin-bottom: 0;
    }

    .ra-bill-table th,
    .ra-bill-table td {
        padding: 13px 12px;
        vertical-align: middle;
    }

    /* Table Header */
    .ra-bill-table thead th {
        white-space: nowrap;
        font-size: 12px;
        font-weight: 700;
        vertical-align: middle;
    }

    /* Table Body */
    .ra-bill-table tbody td {
        font-size: 13px;
        vertical-align: middle;
    }

    /* RA Bill Number */
    .ra-bill-table th:nth-child(1),
    .ra-bill-table td:nth-child(1) {
        min-width: 110px;
        white-space: nowrap;
    }

    /* Date */
    .ra-bill-table th:nth-child(2),
    .ra-bill-table td:nth-child(2) {
        min-width: 110px;
        white-space: nowrap;
    }

    /* Client & Project */
    .ra-bill-table th:nth-child(3),
    .ra-bill-table td:nth-child(3) {
        min-width: 240px;
        width: 240px;
    }

    /* Financial Columns */
    .ra-bill-table th:nth-child(4),
    .ra-bill-table td:nth-child(4),
    .ra-bill-table th:nth-child(5),
    .ra-bill-table td:nth-child(5),
    .ra-bill-table th:nth-child(6),
    .ra-bill-table td:nth-child(6),
    .ra-bill-table th:nth-child(7),
    .ra-bill-table td:nth-child(7),
    .ra-bill-table th:nth-child(8),
    .ra-bill-table td:nth-child(8),
    .ra-bill-table th:nth-child(9),
    .ra-bill-table td:nth-child(9),
    .ra-bill-table th:nth-child(10),
    .ra-bill-table td:nth-child(10) {
        min-width: 125px;
        white-space: nowrap;
    }

    /* Status */
    .ra-bill-table th:nth-child(11),
    .ra-bill-table td:nth-child(11) {
        min-width: 190px;
        white-space: nowrap;
        text-align: center;
    }

    /* Actions */
    .ra-bill-table th:nth-child(12),
    .ra-bill-table td:nth-child(12) {
        min-width: 90px;
        width: 90px;
        white-space: nowrap;
        text-align: center;
    }

    /* Client Name */
    .ra-bill-table .machine-name {
        line-height: 1.4;
        font-weight: 600;
        white-space: normal;
    }

    /* Project Name */
    .ra-bill-table .supervisor-name {
        margin-top: 3px;
        font-size: 11px;
        line-height: 1.4;
        white-space: normal;
    }

    /* Money Values */
    .ra-bill-table .output-text,
    .ra-bill-table .diesel-value {
        white-space: nowrap;
    }

    /* Status Badge */
    .ra-bill-table .badge {
        white-space: nowrap;
        font-size: 11px;
        font-weight: 600;
    }

    /* Action Buttons */
    .ra-bill-table .btn {
        width: 32px;
        height: 32px;
        padding: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    /* Keep action buttons together */
    .ra-bill-table td:last-child > div {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
    }
</style>
@endsection