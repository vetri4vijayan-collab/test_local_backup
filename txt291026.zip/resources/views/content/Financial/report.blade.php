@extends('layouts.layoutMaster')

@section('title', 'HO Financial Report')

@section('content')

<div class="container-fluid py-3">

    <div class="card shadow-sm rounded-2 mb-4">

        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3">

                <div>

                    <h4 class="mb-1 fw-bold text-black fs-3">
                        Planning & Quantity Surveying (QS) Engine
                    </h4>

                    <p class="text-muted mb-0 fs-7">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>

                </div>

                <div class="settings-tabs-wrapper">

                    <div class="d-flex align-items-center gap-2">

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">

                            <i class="mdi mdi-chevron-left"></i>

                        </button>

                        <div class="settings-tabs-scroller">

                            <div class="settings-tabs-track"
                                 id="qsTabsTrack">

                                <a href="{{ route('planning-qs.client') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.client') ? 'active' : '' }}">
                                    Client RA Bill
                                </a>

                                <a href="{{ route('planning-qs.financial.contractor') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.contractor') ? 'active' : '' }}">
                                    Contractor RA Bill
                                </a>

                                <a href="{{ route('planning-qs.financial.credit') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.credit') ? 'active' : '' }}">
                                    Credit/Debit Note
                                </a>

                                <a href="{{ route('planning-qs.financial.security') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.security') ? 'active' : '' }}">
                                    Security Deployment Bill
                                </a>

                              <a href="{{ route('planning-qs.financial.report') }}"
                                  class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.report') ? 'active' : '' }}">
                                         HO Financial Report
                                 </a>

                            </div>

                        </div>

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">

                            <i class="mdi mdi-chevron-right"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    </div>
<div class="card border-0 shadow-sm rounded-4 bg-white mb-3">

    <div class="card-body p-3">

        <div class="row g-2 align-items-end">

            <div class="col-12 col-md-3">
                <label class="ho-filter-label">
                    Search
                </label>

                <div class="position-relative">

                    <span class="position-absolute top-50 start-0
                                 translate-middle-y ps-2 text-muted"
                          style="pointer-events:none;">

                        <i class="mdi mdi-magnify"></i>

                    </span>

                    <input type="text"
                           id="hoSearchInput"
                           placeholder="Search..."
                           class="form-control form-control-sm ps-4
                                  bg-light border-0 rounded-3"
                           autocomplete="off">

                </div>
            </div>


            <!-- Project -->
            <div class="col-12 col-md-3">
                <label class="ho-filter-label">
                    Project
                </label>

                <select id="hoProjectFilter"
                        class="form-select form-select-sm
                               bg-light border-0 rounded-3">

                    <option value="">
                        All Project
                    </option>

                    <option value="Commercial Complex - Block">
                        Commercial Complex - Block
                    </option>

                    <option value="Industrial Warehouse Construction">
                        Industrial Warehouse Construction
                    </option>

                    <option value="MMRP">
                        MMRP
                    </option>

                    <option value="KWRP">
                        KWRP
                    </option>

                </select>
            </div>


            <!-- From Date -->
            <div class="col-6 col-md-2">
                <label class="ho-filter-label">
                    From Date
                </label>

                <input type="date"
                       id="hoFromDate"
                       class="form-control form-control-sm
                              bg-light border-0 rounded-3"
                       placeholder="dd-mm-yyyy">
            </div>


            <!-- To Date -->
            <div class="col-6 col-md-2">
                <label class="ho-filter-label">
                    To Date
                </label>

                <input type="date"
                       id="hoToDate"
                       class="form-control form-control-sm
                              bg-light border-0 rounded-3"
                       placeholder="dd-mm-yyyy">
            </div>


            <!-- GO Button -->
            <div class="col-12 col-md-2">

                <button type="button"
                        id="hoGoBtn"
                        class="btn btn-primary text-white btn-sm rounded-3 w-100"
                        style="height:38px;">

                    GO

                </button>

            </div>

        </div>

    </div>

</div>

    <div class="card border-0 shadow-sm rounded-4 bg-white">

        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table ho-report-table align-middle mb-0">

                    <thead>

                        <tr>

                            <th class="sortable">
                                DATE
                            </th>

                            <th class="sortable">
                                PROJECT NAME
                
                            </th>

                            <th class="text-end sortable">
                                ACTIONS
                            </th>

                        </tr>

                    </thead>

                    <tbody id="hoReportTableBody">

                        <tr class="ho-report-row"
                            data-date="2026-06-08"
                            data-project="Commercial Complex - Block">

                            <td class="ho-date-cell">08-06-2026</td>
                            <td class="ho-project-cell">Commercial Complex - Block</td>
                            <td class="text-end">
                                <button type="button" class="ho-view-btn" title="View Report">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                            </td>

                        </tr>


                        <tr class="ho-report-row"
                            data-date="2026-06-01"
                            data-project="Commercial Complex - Block">

                            <td class="ho-date-cell">01-06-2026</td>
                            <td class="ho-project-cell">Commercial Complex - Block</td>
                            <td class="text-end">
                                <button type="button" class="ho-view-btn" title="View Report">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                            </td>

                        </tr>


                        <tr class="ho-report-row"
                            data-date="2026-04-16"
                            data-project="Industrial Warehouse Construction">

                            <td class="ho-date-cell">16-04-2026</td>
                            <td class="ho-project-cell">Industrial Warehouse Construction</td>
                            <td class="text-end">
                                <button type="button" class="ho-view-btn" title="View Report">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                            </td>

                        </tr>


                        <tr class="ho-report-row"
                            data-date="2026-03-17"
                            data-project="MMRP">

                            <td class="ho-date-cell">17-03-2026</td>
                            <td class="ho-project-cell">MMRP</td>
                            <td class="text-end">
                                <button type="button" class="ho-view-btn" title="View Report">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                            </td>

                        </tr>


                        <tr class="ho-report-row"
                            data-date="2025-11-04"
                            data-project="KWRP">

                            <td class="ho-date-cell">04-11-2025</td>
                            <td class="ho-project-cell">KWRP</td>
                            <td class="text-end">
                                <button type="button" class="ho-view-btn" title="View Report">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>
  

</div>


<div class="modal fade"
     id="viewHoReportModal"
     tabindex="-1"
     aria-labelledby="viewHoReportModalLabel"
     aria-hidden="true">

    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">

        <div class="modal-content border-0 shadow-lg rounded-4">

            <div class="modal-header bg-primary">

                <h5 class="modal-title fw-bold text-white" id="viewHoReportModalLabel">
                    HO FINANCIAL REPORT
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>

            </div>

            <div class="modal-body p-4">

                <div class="d-flex justify-content-end mb-3 no-print report-toolbar-btns">
                    <button class="btn btn-sm me-2" id="hoReportPrintBtn">
                        <i class="mdi mdi-printer me-1"></i>Print
                    </button>
                    <button class="btn btn-sm" id="hoReportExportBtn">
                        <i class="mdi mdi-file-export-outline me-1"></i>Export
                    </button>
                </div>

                <div class="report-box" id="hoReportPrintArea">

                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div class="report-meta">
                            <div><strong>Company :</strong> SRK Infra Developers</div>
                            <div><strong>Address :</strong> Door No. 5/288, Flat No. 14, B. Kalavathy Apartments, Loganathan Nagar, Mannivakkam, Chennai - 600 048</div>
                            <div><strong>Project :</strong> <span id="pnHoProject"></span></div>
                            <div><strong>Date :</strong> <span id="pnHoDate"></span></div>
                            <div><strong>Reporting Date :</strong> <span id="pnHoReportingDate"></span></div>
                        </div>
                        
                    </div>

                    <div class="report-title">
                        HO Financial Report - Daily
                    </div>

                    <div class="table-responsive">
                        <table class="report-table" id="hoReportBillTable">
                            <thead>
                                <tr>
                                    <th rowspan="2">Sr.No</th>
                                    <th rowspan="2">Structure</th>
                                    <th rowspan="2">Item</th>
                                    <th rowspan="2">Unit</th>
                                    <th rowspan="2">Rate</th>
                                    <th colspan="3">Quantity</th>
                                    <th colspan="2">Amount</th>
                                </tr>
                                <tr>
                                    <th>Upto Date</th>
                                    <th>Today</th>
                                    <th>Cumulative</th>
                                    <th>Today</th>
                                    <th>As on Date</th>
                                </tr>
                            </thead>
                            <tbody id="hoReportBillBody">
                                <!-- rows injected by JS -->
                            </tbody>
                        </table>
                    </div>

                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-light border rounded-3" data-bs-dismiss="modal">
                    Close
                </button>
            </div>

        </div>

    </div>

</div>
<!-- ===================== END VIEW REPORT MODAL ===================== -->


<style>

.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}


.ho-filter-label {
    display: block;
    font-size: 11px;
    font-weight: 700;
    color: #64748b;
    margin-bottom: 5px;
    text-transform: uppercase;
    letter-spacing: .3px;
}

#hoProjectFilter,
#hoFromDate,
#hoToDate,
#hoSearchInput {
    height: 38px;
    font-size: 12.5px;
}

#hoProjectFilter:focus,
#hoFromDate:focus,
#hoToDate:focus,
#hoSearchInput:focus {
    border-color: #0d6efd !important;
    box-shadow: 0 0 0 .15rem rgba(13, 110, 253, .08) !important;
}
.ho-report-table {
    font-size: 13px;
}

.ho-report-table thead th {
    background-color: #f8fafc;
    color: #16659E; /* primary color */
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .4px;
    text-transform: uppercase;
    border-bottom: 1px solid #e2e8f0;
    padding: 14px 18px;
    white-space: nowrap;
}


.ho-report-table thead th.sortable {
    cursor: pointer;
    user-select: none;
}

.ho-report-table .sort-icon {
    font-size: 13px;
    color: rgba(255, 255, 255, 0.75);
    margin-left: 2px;
    vertical-align: middle;
}

.ho-report-table tbody td {
    padding: 14px 18px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}

.ho-report-table tbody tr:last-child td {
    border-bottom: none;
}

.ho-report-table tbody tr:hover {
    background-color: #f8fafc;
}

.ho-date-cell {
    color: #475569;
    font-weight: 500;
    white-space: nowrap;
}

.ho-project-cell {
    color: #0f172a;
    font-weight: 700;
}

.ho-view-btn {
    width: 30px;
    height: 30px;
    border: 1px solid #dbeafe;
    background: #eff6ff;
    color: #16659E;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all .15s ease;
}

.ho-view-btn i {
    font-size: 15px;
}

.ho-view-btn:hover {
    background-color: #16659E;
    border-color: #16659E;
    color: #fff;
}

@media (min-width: 1200px) {

    .settings-tabs-scroller {
        max-width: 700px;
    }

}

@media (max-width: 1199.98px) {

    .settings-tabs-scroller {
        max-width: 500px;
    }

}

@media (max-width: 991.98px) {

    .settings-tabs-scroller {
        max-width: 100%;
    }

}

@media (max-width: 767px) {

    .settings-tabs-scroller {
        max-width: 220px;
    }

    .settings-tab-pill {
        padding: .4rem .8rem;
        font-size: .78rem;
    }

    .settings-tab-scroll-btn {
        width: 28px;
        height: 28px;
    }

    .ho-report-table thead th,
    .ho-report-table tbody td {
        padding: 10px 12px;
    }

}


/* ===================== VIEW REPORT MODAL BILL STYLES (new) ===================== */

#viewHoReportModal .modal-dialog {
    max-width: 1000px;
}

.report-toolbar-btns .btn {
    background-color: #29a8dc;
    border-color: #29a8dc;
    color: #fff;
    font-weight: 500;
}

.report-toolbar-btns .btn:hover {
    background-color: #1f93c4;
    border-color: #1f93c4;
    color: #fff;
}

.report-box {
    border: 2px solid #333;
    padding: 20px;
    background: #fff;
}

.report-meta {
    font-size: 0.9rem;
    color: #222;
    line-height: 1.7;
}

.report-meta strong {
    font-weight: 700;
}

.report-logo {
    height: 55px;
}

.report-title {
    text-align: center;
    font-weight: 700;
    font-size: 1rem;
    margin: 12px 0 10px 0;
    color: #222;
}

table.report-table {
    width: 100%;
    border-collapse: collapse;
    margin: 0;
}

table.report-table th,
table.report-table td {
    border: 1px solid #333;
    padding: 9px 8px;
    font-size: 0.88rem;
    vertical-align: middle;
}

table.report-table thead th {
    background-color: #29a8dc;
    color: #fff;
    text-align: center;
    font-weight: 700;
}

table.report-table tbody td {
    text-align: right;
}

table.report-table tbody td.text-left {
    text-align: left;
}

table.report-table tbody td.text-center {
    text-align: center;
}

table.report-table tbody tr.totals-row td {
    font-weight: 700;
    background-color: #f8f9fa;
}

@media print {

    body * {
        visibility: hidden;
    }

    #viewHoReportModal,
    #viewHoReportModal * {
        visibility: visible;
    }

    #viewHoReportModal {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
    }

    #viewHoReportModal .modal-dialog {
        max-width: 100%;
        margin: 0;
    }

    #viewHoReportModal .modal-header .btn-close,
    #viewHoReportModal .modal-footer,
    #viewHoReportModal .no-print {
        display: none !important;
    }

}
.ho-view-btn {
    background: transparent !important;
    border: 0 !important;
    box-shadow: none !important;
    padding: 0 !important;
    width: auto !important;
    height: auto !important;
    line-height: 1 !important;
    color: #16659E;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.ho-view-btn:hover,
.ho-view-btn:focus,
.ho-view-btn:active {
    background: transparent !important;
    border: 0 !important;
    box-shadow: none !important;
    color: #124f7c;
}

.ho-view-btn i {
    font-size: 18px;
    line-height: 1;
}
/* ===================== END VIEW REPORT MODAL BILL STYLES ===================== */

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const tabsTrack =
        document.getElementById('qsTabsTrack');

    const leftButton =
        document.getElementById('qsTabScrollLeft');

    const rightButton =
        document.getElementById('qsTabScrollRight');


    if (tabsTrack) {

        if (leftButton) {

            leftButton.addEventListener('click', function () {

                tabsTrack.scrollBy({
                    left: -220,
                    behavior: 'smooth'
                });

            });

        }


        if (rightButton) {

            rightButton.addEventListener('click', function () {

                tabsTrack.scrollBy({
                    left: 220,
                    behavior: 'smooth'
                });

            });

        }

    }


    const projectFilter =
        document.getElementById('hoProjectFilter');

    const fromDateInput =
        document.getElementById('hoFromDate');

    const toDateInput =
        document.getElementById('hoToDate');

    const goBtn =
        document.getElementById('hoGoBtn');

    const searchInput =
        document.getElementById('hoSearchInput');


    function filterRows() {

        const projectValue =
            projectFilter ? projectFilter.value : '';

        const fromValue =
            fromDateInput && fromDateInput.value
                ? fromDateInput.value
                : null;

        const toValue =
            toDateInput && toDateInput.value
                ? toDateInput.value
                : null;

        const searchValue =
            searchInput
                ? searchInput.value.toLowerCase().trim()
                : '';

        const rows =
            document.querySelectorAll('.ho-report-row');


        rows.forEach(function (row) {

            const rowDate =
                row.dataset.date || '';

            const rowProject =
                row.dataset.project || '';

            const rowText =
                row.innerText.toLowerCase();


            const matchesProject =
                projectValue === '' ||
                rowProject === projectValue;

            const matchesFrom =
                !fromValue || rowDate >= fromValue;

            const matchesTo =
                !toValue || rowDate <= toValue;

            const matchesSearch =
                searchValue === '' ||
                rowText.includes(searchValue);


            row.style.display =
                matchesProject &&
                matchesFrom &&
                matchesTo &&
                matchesSearch
                    ? ''
                    : 'none';

        });

    }


    if (goBtn) {

        goBtn.addEventListener('click', filterRows);

    }


    if (searchInput) {

        searchInput.addEventListener('input', filterRows);

    }


    if (projectFilter) {

        projectFilter.addEventListener('change', filterRows);

    }


    /* ===================== NEW: View Report modal wiring ===================== */

    const viewHoReportModalElement =
        document.getElementById('viewHoReportModal');

    const viewHoReportModal =
        bootstrap.Modal.getOrCreateInstance(viewHoReportModalElement);


    // Sample line-item data per report row.
    // Keyed by "date|project" so each row in the table can show its own bill items.
    // Replace this with data fetched from your backend for the selected date/project.
    const hoReportItemsData = {

        '2026-06-08|Commercial Complex - Block': [
            { structure: 'Rooftop Solar Structure', item: 'Steel', unit: 'Nos.', rate: 0.00, uptoDate: 60.000, today: 48.000, cumulative: 108.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Rooftop Solar Structure', item: 'Return Wall', unit: 'Kgs.', rate: 0.00, uptoDate: 4200.000, today: 4250.000, cumulative: 8450.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Rooftop Solar Structure', item: 'PCC', unit: 'Nos.', rate: 0.00, uptoDate: 1.000, today: 1.000, cumulative: 2.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Rooftop Solar Structure', item: 'Raft', unit: 'Nos.', rate: 0.00, uptoDate: 2.000, today: 4.000, cumulative: 6.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Rooftop Solar Structure', item: 'Wall', unit: 'Rmt.', rate: 0.00, uptoDate: 125.000, today: 150.000, cumulative: 275.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Column', item: 'Abutment (Circular Type)', unit: 'MT', rate: 0.00, uptoDate: 6.500, today: 6.800, cumulative: 13.300, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Column', item: 'Pier (Circular Type)', unit: 'Sq.m', rate: 0.00, uptoDate: 180.000, today: 185.000, cumulative: 365.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Column', item: 'Abutment Cap', unit: 'CuM', rate: 0.00, uptoDate: 11.880, today: 32.500, cumulative: 44.380, amountToday: 0.00, amountAsOnDate: 0.00 }
        ],

        '2026-06-01|Commercial Complex - Block': [
            { structure: 'Foundation', item: 'PCC', unit: 'CuM', rate: 0.00, uptoDate: 45.000, today: 12.000, cumulative: 57.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Foundation', item: 'Footing Reinforcement', unit: 'MT', rate: 0.00, uptoDate: 18.500, today: 4.200, cumulative: 22.700, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Foundation', item: 'Footing Concrete', unit: 'CuM', rate: 0.00, uptoDate: 96.000, today: 24.000, cumulative: 120.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Column', item: 'Column Reinforcement', unit: 'MT', rate: 0.00, uptoDate: 9.750, today: 2.100, cumulative: 11.850, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Column', item: 'Column Shuttering', unit: 'Sq.m', rate: 0.00, uptoDate: 210.000, today: 48.000, cumulative: 258.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Slab', item: 'Slab Reinforcement', unit: 'MT', rate: 0.00, uptoDate: 14.200, today: 3.600, cumulative: 17.800, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Slab', item: 'Slab Concrete', unit: 'CuM', rate: 0.00, uptoDate: 132.000, today: 36.000, cumulative: 168.000, amountToday: 0.00, amountAsOnDate: 0.00 }
        ],

        '2026-04-16|Industrial Warehouse Construction': [
            { structure: 'Site Development', item: 'Earthwork Excavation', unit: 'CuM', rate: 0.00, uptoDate: 3200.000, today: 450.000, cumulative: 3650.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Site Development', item: 'Soil Filling & Compaction', unit: 'CuM', rate: 0.00, uptoDate: 1800.000, today: 300.000, cumulative: 2100.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Foundation', item: 'Isolated Footing', unit: 'Nos.', rate: 0.00, uptoDate: 28.000, today: 6.000, cumulative: 34.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Foundation', item: 'PCC Bedding', unit: 'CuM', rate: 0.00, uptoDate: 85.000, today: 15.000, cumulative: 100.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Structural Steel', item: 'PEB Columns', unit: 'MT', rate: 0.00, uptoDate: 42.500, today: 8.200, cumulative: 50.700, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Structural Steel', item: 'PEB Roof Trusses', unit: 'MT', rate: 0.00, uptoDate: 36.800, today: 7.500, cumulative: 44.300, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Roofing', item: 'Metal Roof Sheeting', unit: 'Sq.m', rate: 0.00, uptoDate: 1250.000, today: 220.000, cumulative: 1470.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Flooring', item: 'Industrial Floor Concrete', unit: 'CuM', rate: 0.00, uptoDate: 210.000, today: 0.000, cumulative: 210.000, amountToday: 0.00, amountAsOnDate: 0.00 }
        ],

        '2026-03-17|MMRP': [
            { structure: 'Pile Foundation', item: 'Bored Cast-in-situ Pile', unit: 'Nos.', rate: 0.00, uptoDate: 64.000, today: 8.000, cumulative: 72.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Pile Foundation', item: 'Pile Reinforcement Cage', unit: 'MT', rate: 0.00, uptoDate: 96.500, today: 12.400, cumulative: 108.900, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Pier', item: 'Pier Concrete', unit: 'CuM', rate: 0.00, uptoDate: 480.000, today: 60.000, cumulative: 540.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Pier', item: 'Pier Cap Reinforcement', unit: 'MT', rate: 0.00, uptoDate: 32.700, today: 4.100, cumulative: 36.800, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Superstructure', item: 'Precast Segment Erection', unit: 'Nos.', rate: 0.00, uptoDate: 145.000, today: 18.000, cumulative: 163.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Superstructure', item: 'Deck Slab Concrete', unit: 'CuM', rate: 0.00, uptoDate: 620.000, today: 85.000, cumulative: 705.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Track Works', item: 'Ballastless Track Bed', unit: 'Rmt.', rate: 0.00, uptoDate: 850.000, today: 0.000, cumulative: 850.000, amountToday: 0.00, amountAsOnDate: 0.00 }
        ],

        '2025-11-04|KWRP': [
            { structure: 'Canal Works', item: 'Canal Excavation', unit: 'CuM', rate: 0.00, uptoDate: 15400.000, today: 1200.000, cumulative: 16600.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Canal Works', item: 'Canal Lining Concrete', unit: 'CuM', rate: 0.00, uptoDate: 2850.000, today: 320.000, cumulative: 3170.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Head Regulator', item: 'RCC Structure', unit: 'CuM', rate: 0.00, uptoDate: 640.000, today: 45.000, cumulative: 685.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Head Regulator', item: 'Gate Fabrication & Erection', unit: 'MT', rate: 0.00, uptoDate: 22.400, today: 3.100, cumulative: 25.500, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Distribution System', item: 'Pipeline Laying (HDPE)', unit: 'Rmt.', rate: 0.00, uptoDate: 6200.000, today: 480.000, cumulative: 6680.000, amountToday: 0.00, amountAsOnDate: 0.00 },
            { structure: 'Distribution System', item: 'Valve Chamber Construction', unit: 'Nos.', rate: 0.00, uptoDate: 34.000, today: 4.000, cumulative: 38.000, amountToday: 0.00, amountAsOnDate: 0.00 }
        ]

        // Add more "date|project" keys here as needed for other rows.

    };


    function formatNumber(value, decimals) {

        decimals = decimals === undefined ? 3 : decimals;

        return Number(value || 0).toLocaleString('en-US', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        });

    }


    function openViewHoReportModal(row) {

        const project =
            row.dataset.project || '';

        const date =
            row.dataset.date || '';

        // Convert yyyy-mm-dd to dd-mm-yyyy for display
        const dateParts =
            date.split('-');

        const displayDate =
            dateParts.length === 3
                ? `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`
                : date;


        document.getElementById('pnHoProject').textContent =
            project;

        document.getElementById('pnHoDate').textContent =
            displayDate;

        document.getElementById('pnHoReportingDate').textContent =
            new Date().toLocaleDateString('en-GB').split('/').join('-');


        const items =
            hoReportItemsData[date + '|' + project] || [];

        const tbody =
            document.getElementById('hoReportBillBody');

        let rowsHtml = '';

        let cumulativeTotal = 0;
        let amountTodayTotal = 0;

        items.forEach(function (line, index) {

            cumulativeTotal += Number(line.cumulative || 0);
            amountTodayTotal += Number(line.amountToday || 0);

            rowsHtml += `
                <tr>
                    <td class="text-center">${index + 1}</td>
                    <td class="text-left">${line.structure}</td>
                    <td class="text-left">${line.item}</td>
                    <td class="text-center">${line.unit}</td>
                    <td>${formatNumber(line.rate, 2)}</td>
                    <td>${formatNumber(line.uptoDate)}</td>
                    <td>${formatNumber(line.today)}</td>
                    <td>${formatNumber(line.cumulative)}</td>
                    <td>${formatNumber(line.amountToday, 2)}</td>
                    <td>${formatNumber(line.amountAsOnDate, 2)}</td>
                </tr>
            `;

        });

        rowsHtml += `
            <tr class="totals-row">
                <td colspan="7"></td>
                <td>${formatNumber(cumulativeTotal)}</td>
                <td>${formatNumber(amountTodayTotal, 3)}</td>
                <td></td>
            </tr>
        `;

        tbody.innerHTML = rowsHtml;

        viewHoReportModal.show();

    }


    document.addEventListener('click', function (event) {

        const viewButton =
            event.target.closest('.ho-view-btn');

        if (viewButton) {

            const row =
                viewButton.closest('.ho-report-row');

            if (row) {

                openViewHoReportModal(row);

            }

        }

    });


    const hoReportPrintBtn =
        document.getElementById('hoReportPrintBtn');

    if (hoReportPrintBtn) {

        hoReportPrintBtn.addEventListener('click', function () {

            window.print();

        });

    }


    const hoReportExportBtn =
        document.getElementById('hoReportExportBtn');

    if (hoReportExportBtn) {

        hoReportExportBtn.addEventListener('click', function () {

            const table =
                document.getElementById('hoReportBillTable');

            const rows =
                table.querySelectorAll('tr');

            const csv = [];

            rows.forEach(function (tr) {

                const cols =
                    tr.querySelectorAll('td, th');

                const rowData = [];

                cols.forEach(function (col) {

                    let text =
                        col.innerText.replace(/\s+/g, ' ').trim();

                    text =
                        text.replace(/"/g, '""');

                    rowData.push('"' + text + '"');

                });

                csv.push(rowData.join(','));

            });

            const csvContent =
                csv.join('\n');

            const blob =
                new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });

            const link =
                document.createElement('a');

            link.href =
                URL.createObjectURL(blob);

            link.setAttribute(
                'download',
                'HO_Financial_Report.csv'
            );

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

        });

    }


});

</script>

@endsection