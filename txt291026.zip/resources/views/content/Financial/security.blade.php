@extends('layouts.layoutMaster')

@section('title', 'Security Deployment Bill')

@section('content')

<div class="container-fluid py-3">

    <div class="card shadow-sm rounded-2 mb-4">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

                <div>
                    <h4 class="mb-1 fw-bold text-black fs-3">
                        Planning & Quantity Surveying (QS) Engine
                    </h4>

                    <p class="text-muted mb-0 fs-7">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>
                </div>

                <div class="settings-tabs-wrapper">

                    <div class="d-flex align-items-center gap-2">

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">
                            <i class="mdi mdi-chevron-left"></i>
                        </button>

                        <div class="settings-tabs-scroller">

                            <div class="settings-tabs-track"
                                 id="qsTabsTrack">

                                <a href="{{ route('planning-qs.client') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.client') ? 'active' : '' }}">
                                    Client RA Bill
                                </a>

                                <a href="{{ route('planning-qs.financial.contractor') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.contractor') ? 'active' : '' }}">
                                    Contractor RA Bill
                                </a>

                                <a href="{{ route('planning-qs.financial.credit') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.credit') ? 'active' : '' }}">
                                    Credit/Debit Note
                                </a>

                                <a href="{{ route('planning-qs.financial.security') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.security') ? 'active' : '' }}">
                                    Security Deployment Bill
                                </a>

                             <a href="{{ route('planning-qs.financial.report') }}"
                                  class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.report') ? 'active' : '' }}">
                                         HO Financial Report
                                 </a>

                            </div>

                        </div>

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">
                            <i class="mdi mdi-chevron-right"></i>
                        </button>

                    </div>

                </div>

            </div>

        </div>
    </div>


    <div class="card border-0 shadow-sm rounded-4 bg-white mb-3">

        <div class="card-body p-3">

            <div class="row g-2 align-items-center">

                <div class="col-12 col-lg-4">

                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                              style="pointer-events:none;">

                            <i class="mdi mdi-magnify"></i>

                        </span>

                        <input
                            id="securityBillSearch"
                            type="text"
                            placeholder="Search Bill No, Project, Vendor..."
                            class="form-control form-control-sm ps-4 bg-light border-0 rounded-3"
                            style="height:38px;font-size:11px;"
                            autocomplete="off">

                    </div>

                </div>

                <div class="col-12 col-md-6 col-lg-2">

                    <select id="securityMonthFilter"
                            class="form-select form-select-sm bg-light border-0 rounded-3">

                        <option value="">
                            All Months
                        </option>

                        <option value="2026-07">
                            July 2026
                        </option>

                        <option value="2026-06">
                            June 2026
                        </option>

                        <option value="2026-05">
                            May 2026
                        </option>

                    </select>

                </div>

                <div class="col-12 col-lg-3">

                    <button type="button"
                            class="btn btn-primary btn-sm rounded-3 d-inline-flex align-items-center justify-content-center px-3 w-100"
                            style="height:38px;white-space:nowrap;"
                            id="newSecurityBillBtn"
                            data-bs-toggle="modal"
                            data-bs-target="#newSecurityBillModal">

                        <i class="mdi mdi-plus me-1"></i>

                        <span>
                            Create Security Deployment Bill
                        </span>

                    </button>

                </div>

            </div>

        </div>

    </div>


    <div class="row g-3"
         id="securityBillCards">

        <div class="col-12 security-bill-card"
             data-bill-no="SEC-B-07"
             data-project="Metro Central Yard & Corridor 4"
             data-vendor="Apex Guarding Services Pvt Ltd"
             data-month="2026-07"
             data-security-count="24"
             data-security-amount="480000"
             data-aso-count="0"
             data-aso-amount="0"
             data-gst="18"
             data-tds="2">

            <div class="card border rounded-3 shadow-sm bg-white">

                <div class="card-body p-3">

                    <div class="security-card-layout">

                        <div class="security-card-left">

                            <div class="d-flex align-items-center mb-2">

                                <span class="security-bill-number">
                                    SEC-B-07
                                </span>

                            </div>

                            <h6 class="vendor-title security-vendor">
                                Apex Guarding Services Pvt Ltd
                            </h6>

                            <div class="security-project">
                                Metro Central Yard & Corridor 4
                            </div>

                            <div class="security-details">

                                <div class="security-detail-item">

                                    <span class="security-detail-label">
                                        Counts:
                                    </span>

                                    <strong class="security-count-value">
                                        24 Officers
                                    </strong>

                                </div>

                                <div class="security-detail-item">

                                    <span class="security-detail-label">
                                        Period:
                                    </span>

                                    <strong class="security-month-value">
                                        July 2026
                                    </strong>

                                </div>

                            </div>

                        </div>


                        <div class="security-card-right">

                            <div class="security-card-actions">

                                <button type="button"
                                        class="security-view-btn"
                                        title="View Security Bill">

                                    <i class="mdi mdi-eye-outline"></i>

                                </button>

                                <button type="button"
                                        class="security-edit-btn"
                                        title="Edit Security Bill">

                                    <i class="mdi mdi-pencil"></i>

                                </button>

                                <button type="button"
                                        class="security-delete-btn"
                                        title="Delete Security Bill">

                                    <i class="mdi mdi-delete-outline"></i>

                                </button>

                            </div>

                            <div class="security-payment-box">

                                <span class="security-net-label">
                                    Net Payment
                                </span>

                                <div class="security-net-payment-display">
                                    $556,800.00
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="modal fade"
         id="newSecurityBillModal"
         tabindex="-1"
         aria-labelledby="newSecurityBillModalLabel"
         aria-hidden="true">

        <div class="modal-dialog modal-xl modal-dialog-centered">

            <div class="modal-content border-0 shadow-lg rounded-4">

                <div class="modal-header bg-primary">

                    <h5 class="modal-title fw-bold text-white"
                        id="newSecurityBillModalLabel">

                        CREATE SECURITY DEPLOYMENT BILL

                    </h5>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                    </button>

                </div>

                <div class="modal-body p-3 p-md-4">

                    <div class="row g-3">

                        <div class="col-md-4">

                            <label class="form-label">
                                Bill Number *
                            </label>

                            <input type="text"
                                   class="form-control"
                                   id="securityBillNumber"
                                   value="SEC-B-08">

                        </div>

                        <div class="col-md-4">

                            <label class="form-label">
                                Month *
                            </label>

                            <input type="month"
                                   class="form-control"
                                   id="securityMonth"
                                   value="2026-09">

                        </div>

                        <div class="col-md-4">

                            <label class="form-label">
                                Project *
                            </label>

                            <select class="form-select"
                                    id="securityProject">

                                <option value="">
                                    Select Project
                                </option>

                                <option value="Metro Central Yard & Corridor 4">
                                    Metro Central Yard & Corridor 4
                                </option>

                                <option value="Adyar Residential Yard B">
                                    Adyar Residential Yard B
                                </option>

                                <option value="Smart City Drainage Upgrade">
                                    Smart City Drainage Upgrade
                                </option>

                                <option value="Highway Road Expansion Phase 2">
                                    Highway Road Expansion Phase 2
                                </option>

                                <option value="Water Treatment Plant Setup">
                                    Water Treatment Plant Setup
                                </option>

                                <option value="IT Park Infrastructure Development">
                                    IT Park Infrastructure Development
                                </option>

                            </select>

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Vendor *
                            </label>

                            <select class="form-select"
                                    id="securityVendor">

                                <option value="">
                                    Select Vendor
                                </option>

                                <option value="Apex Guarding Services Pvt Ltd">
                                    Apex Guarding Services Pvt Ltd
                                </option>

                                <option value="Vanguard Site Security Systems">
                                    Vanguard Site Security Systems
                                </option>

                                <option value="TechNova Solutions Pvt Ltd">
                                    TechNova Solutions Pvt Ltd
                                </option>

                                <option value="FastTrack Logistics">
                                    FastTrack Logistics
                                </option>

                                <option value="Sri Sai Facility Services">
                                    Sri Sai Facility Services
                                </option>

                            </select>

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Security Count *
                            </label>

                            <input type="number"
                                   min="0"
                                   class="form-control"
                                   id="securityCount"
                                   value="0">

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Security Amount *
                            </label>

                            <input type="number"
                                   min="0"
                                   step="0.01"
                                   class="form-control"
                                   id="securityAmount"
                                   value="0">

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                ASO Count *
                            </label>

                            <input type="number"
                                   min="0"
                                   class="form-control"
                                   id="asoCount"
                                   value="0">

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                ASO Amount *
                            </label>

                            <input type="number"
                                   min="0"
                                   step="0.01"
                                   class="form-control"
                                   id="asoAmount"
                                   value="0">

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Total Count *
                            </label>

                            <input type="number"
                                   class="form-control calculated-field"
                                   id="totalCount"
                                   readonly>

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Total Amount *
                            </label>

                            <input type="number"
                                   class="form-control calculated-field"
                                   id="totalAmount"
                                   readonly>

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Sub Total *
                            </label>

                            <input type="number"
                                   class="form-control calculated-field"
                                   id="subTotal"
                                   readonly>

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                GST % *
                            </label>

                            <select class="form-select"
                                    id="gstPercent">

                                <option value="">
                                    Select GST%
                                </option>

                                <option value="5">
                                    5%
                                </option>

                                <option value="12">
                                    12%
                                </option>

                                <option value="18">
                                    18%
                                </option>

                                <option value="28">
                                    28%
                                </option>

                            </select>

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                GST Amount *
                            </label>

                            <input type="number"
                                   class="form-control calculated-field"
                                   id="gstAmount"
                                   readonly>

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                TDS % *
                            </label>

                            <input type="number"
                                   min="0"
                                   max="100"
                                   step="0.01"
                                   class="form-control"
                                   id="tdsPercent"
                                   value="2">

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                TDS Amount *
                            </label>

                            <input type="number"
                                   class="form-control calculated-field"
                                   id="tdsAmount"
                                   readonly>

                        </div>

                        <div class="col-12">

                            <div class="net-payment-box">

                                <div>

                                    <span class="net-payment-title">
                                        Net Payment
                                    </span>

                                    <small class="d-block text-muted">
                                        Sub Total + GST - TDS
                                    </small>

                                </div>

                                <strong id="netPayment">
                                    $0.00
                                </strong>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button"
                            class="btn btn-light border rounded-3"
                            data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button"
                            class="btn btn-primary rounded-3"
                            id="saveSecurityBillBtn">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="securitySaveText">
                            Create Security Deployment Bill
                        </span>

                    </button>

                </div>

            </div>

        </div>

    </div>


    <div class="modal fade"
         id="viewSecurityBillModal"
         tabindex="-1"
         aria-labelledby="viewSecurityBillModalLabel"
         aria-hidden="true">

        <div class="modal-dialog modal-lg modal-dialog-centered">

            <div class="modal-content border-0 shadow-lg rounded-4">

                <div class="modal-header bg-primary">

                    <h5 class="modal-title fw-bold text-white"
                        id="viewSecurityBillModalLabel">

                        SECURITY DEPLOYMENT BILL DETAILS

                    </h5>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                    </button>

                </div>

                <div class="modal-body p-3 p-md-4">

                    <div class="row g-3">

                        <div class="col-md-6">
                            <div class="view-detail-box">
                                <span>Bill Number</span>
                                <strong id="viewBillNumber"></strong>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="view-detail-box">
                                <span>Month</span>
                                <strong id="viewMonth"></strong>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="view-detail-box">
                                <span>Project</span>
                                <strong id="viewProject"></strong>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="view-detail-box">
                                <span>Vendor</span>
                                <strong id="viewVendor"></strong>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="view-detail-box">
                                <span>Security Count</span>
                                <strong id="viewSecurityCount"></strong>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="view-detail-box">
                                <span>Security Amount</span>
                                <strong id="viewSecurityAmount"></strong>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="view-detail-box">
                                <span>ASO Count</span>
                                <strong id="viewAsoCount"></strong>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="view-detail-box">
                                <span>ASO Amount</span>
                                <strong id="viewAsoAmount"></strong>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="view-detail-box">
                                <span>Total Count</span>
                                <strong id="viewTotalCount"></strong>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="view-detail-box">
                                <span>Total Amount</span>
                                <strong id="viewTotalAmount"></strong>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="view-detail-box">
                                <span>Sub Total</span>
                                <strong id="viewSubTotal"></strong>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="view-detail-box">
                                <span>GST</span>
                                <strong id="viewGst"></strong>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="view-detail-box">
                                <span>GST Amount</span>
                                <strong id="viewGstAmount"></strong>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="view-detail-box">
                                <span>TDS</span>
                                <strong id="viewTds"></strong>
                            </div>
                        </div>

                        <div class="col-12">

                            <div class="view-net-payment-box">

                                <div>

                                    <span>
                                        Net Payment
                                    </span>

                                    <small>
                                        Sub Total + GST - TDS
                                    </small>

                                </div>

                                <strong id="viewNetPayment">
                                    $0.00
                                </strong>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button"
                            class="btn btn-light border rounded-3"
                            data-bs-dismiss="modal">

                        Close

                    </button>

                </div>

            </div>

        </div>

    </div>


    <div id="securityPrintArea">

        <div class="print-header">

            <div class="print-company-title">
                Planning & Quantity Surveying (QS) Engine
            </div>

            <div class="print-document-title"
                 id="printSecurityTitle">
                SECURITY DEPLOYMENT BILL
            </div>

        </div>

        <table class="print-info-table">

            <tr>
                <td class="print-label">Bill Number</td>
                <td id="printSecurityBillNumber"></td>
                <td class="print-label">Month</td>
                <td id="printSecurityMonth"></td>
            </tr>

            <tr>
                <td class="print-label">Project</td>
                <td id="printSecurityProject"></td>
                <td class="print-label">Vendor</td>
                <td id="printSecurityVendor"></td>
            </tr>

            <tr>
                <td class="print-label">Security Count</td>
                <td id="printSecurityCount"></td>
                <td class="print-label">Security Amount</td>
                <td id="printSecurityAmount"></td>
            </tr>

            <tr>
                <td class="print-label">ASO Count</td>
                <td id="printAsoCount"></td>
                <td class="print-label">ASO Amount</td>
                <td id="printAsoAmount"></td>
            </tr>

            <tr>
                <td class="print-label">Total Count</td>
                <td id="printTotalCount"></td>
                <td class="print-label">Total Amount</td>
                <td id="printTotalAmount"></td>
            </tr>

            <tr>
                <td class="print-label">Sub Total</td>
                <td id="printSubTotal"></td>
                <td class="print-label">GST</td>
                <td id="printGst"></td>
            </tr>

            <tr>
                <td class="print-label">GST Amount</td>
                <td id="printGstAmount"></td>
                <td class="print-label">TDS</td>
                <td id="printTds"></td>
            </tr>

        </table>

        <div class="print-amount-box">

            <span class="print-amount-label">
                Net Payment:
            </span>

            <span class="print-amount"
                  id="printNetPayment">
            </span>

        </div>

        <div class="print-signature">

            <div class="print-signature-box">
                Prepared By
            </div>

            <div class="print-signature-box">
                Checked By
            </div>

            <div class="print-signature-box">
                Approved By
            </div>

        </div>

    </div>

</div>


<style>

.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}

#securityBillSearch,
#securityMonthFilter {
    height: 38px;
    font-size: 12px;
}

.security-bill-number {
    font-size: 10px;
    font-weight: 700;
    padding: 4px 7px;
    border-radius: 4px;
    background: #f1f5f9;
    color: #475569;
    border: 1px solid #e2e8f0;
    font-family: monospace;
}

.security-card-layout {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    width: 100%;
}

.security-card-left {
    flex: 1 1 auto;
    min-width: 0;
}

.security-card-right {
    min-width: 150px;
    flex-shrink: 0;
    text-align: right;
    margin-left: 20px;
}

.security-card-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 4px;
}

.security-payment-box {
    margin-top: 7px;
    text-align: right;
}

.security-vendor {
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
    margin-bottom: 5px;
}

.security-project {
    font-size: 12px;
    color: #64748b;
    margin-bottom: 12px;
}

.security-details {
    display: flex;
    flex-wrap: wrap;
    gap: 22px;
    padding: 10px 12px;
    background: #f8fafc;
    border: 1px solid #f1f5f9;
    border-radius: 7px;
}

.security-detail-item {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 11px;
    color: #334155;
}

.security-detail-label {
    color: #64748b;
}

.security-net-label {
    font-size: 10px;
    color: #64748b;
    display: block;
}

.security-net-payment-display {
    font-size: 15px;
    font-weight: 800;
    color: #059669;
    white-space: nowrap;
}

.security-edit-btn,
.security-view-btn,
.security-delete-btn {
    width: 26px;
    height: 26px;
    padding: 0;
    border: 0;
    background: transparent;
    color: #64748b;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    border-radius: 5px;
}

.security-edit-btn:hover,
.security-view-btn:hover {
    background: #f1f5f9;
    color: #16659E;
}

.security-delete-btn:hover {
    background: #fef2f2;
    color: #dc2626;
}

.security-edit-btn i,
.security-view-btn i,
.security-delete-btn i {
    font-size: 15px;
}

#newSecurityBillModal .modal-dialog {
    max-width: 1050px;
}

#newSecurityBillModal .modal-content {
    overflow: hidden;
}

#newSecurityBillModal .modal-header {
    padding: 13px 18px;
}

#newSecurityBillModal .modal-title {
    font-size: 14px;
}

#newSecurityBillModal .modal-body {
    background: #fff;
}

#newSecurityBillModal .form-label {
    color: #334155;
    font-size: 11px;
    font-weight: 700;
    margin-bottom: 5px;
}

#newSecurityBillModal .form-control,
#newSecurityBillModal .form-select {
    height: 36px;
    border-color: #dbe2ea;
    border-radius: 7px;
    font-size: 11px;
}

#newSecurityBillModal .modal-footer {
    padding: 10px 18px;
}

#newSecurityBillModal .modal-footer .btn {
    height: 34px;
    font-size: 11px;
    font-weight: 600;
}

.calculated-field {
    background: #f8fafc !important;
    font-weight: 700;
}

.net-payment-box {
    margin-top: 5px;
    padding: 14px 16px;
    border-radius: 9px;
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.net-payment-title {
    font-size: 12px;
    font-weight: 700;
    color: #166534;
}

#netPayment {
    font-size: 19px;
    font-weight: 800;
    color: #059669;
}

.view-detail-box {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 11px 13px;
    min-height: 60px;
}

.view-detail-box span {
    display: block;
    font-size: 10px;
    color: #64748b;
    font-weight: 600;
    margin-bottom: 4px;
}

.view-detail-box strong {
    display: block;
    font-size: 12px;
    color: #0f172a;
    font-weight: 700;
    word-break: break-word;
}

.view-net-payment-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px 17px;
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 9px;
}

.view-net-payment-box span {
    display: block;
    color: #166534;
    font-size: 13px;
    font-weight: 700;
}

.view-net-payment-box small {
    display: block;
    color: #64748b;
    font-size: 10px;
    margin-top: 2px;
}

.view-net-payment-box strong {
    color: #059669;
    font-size: 20px;
    font-weight: 800;
}

#securityPrintArea {
    display: none;
}

.print-header {
    text-align: center;
    margin-bottom: 30px;
    border-bottom: 2px solid #000;
    padding-bottom: 15px;
}

.print-company-title {
    font-size: 22px;
    font-weight: 700;
    margin-bottom: 5px;
}

.print-document-title {
    font-size: 18px;
    font-weight: 700;
}

.print-info-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 25px;
}

.print-info-table td {
    border: 1px solid #333;
    padding: 10px;
    font-size: 13px;
}

.print-label {
    font-weight: 700;
    width: 20%;
    background: #f5f5f5;
}

.print-amount-box {
    border: 2px solid #000;
    padding: 15px;
    text-align: right;
    margin-bottom: 50px;
}

.print-amount-label {
    font-size: 13px;
    margin-right: 15px;
}

.print-amount {
    font-size: 20px;
    font-weight: 700;
}

.print-signature {
    display: flex;
    justify-content: space-between;
    margin-top: 60px;
}

.print-signature-box {
    width: 220px;
    text-align: center;
    font-size: 12px;
    padding-top: 45px;
    border-top: 1px solid #000;
}

@media print {

    body * {
        visibility: hidden !important;
    }

    #securityPrintArea,
    #securityPrintArea * {
        visibility: visible !important;
    }

    #securityPrintArea {
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
        width: 100% !important;
        display: block !important;
        padding: 30px !important;
        background: #fff !important;
        color: #000 !important;
    }

}

@media (max-width: 767px) {

    .settings-tabs-scroller {
        max-width: 220px;
    }

    .settings-tab-pill {
        padding: .4rem .8rem;
        font-size: .78rem;
    }

    .settings-tab-scroll-btn {
        width: 28px;
        height: 28px;
    }

    .security-card-right {
        min-width: 125px;
        margin-left: 10px;
    }

    .security-details {
        gap: 10px;
    }

}

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const tabsTrack =
        document.getElementById('qsTabsTrack');

    const leftButton =
        document.getElementById('qsTabScrollLeft');

    const rightButton =
        document.getElementById('qsTabScrollRight');


    if (leftButton && tabsTrack) {

        leftButton.addEventListener('click', function () {

            tabsTrack.scrollBy({
                left: -220,
                behavior: 'smooth'
            });

        });

    }


    if (rightButton && tabsTrack) {

        rightButton.addEventListener('click', function () {

            tabsTrack.scrollBy({
                left: 220,
                behavior: 'smooth'
            });

        });

    }


    const modalElement =
        document.getElementById(
            'newSecurityBillModal'
        );

    const modal =
        bootstrap.Modal.getOrCreateInstance(
            modalElement
        );


    const newButton =
        document.getElementById(
            'newSecurityBillBtn'
        );

    const saveButton =
        document.getElementById(
            'saveSecurityBillBtn'
        );

    const saveText =
        document.getElementById(
            'securitySaveText'
        );


    const billNumber =
        document.getElementById(
            'securityBillNumber'
        );

    const month =
        document.getElementById(
            'securityMonth'
        );

    const project =
        document.getElementById(
            'securityProject'
        );

    const vendor =
        document.getElementById(
            'securityVendor'
        );

    const securityCount =
        document.getElementById(
            'securityCount'
        );

    const securityAmount =
        document.getElementById(
            'securityAmount'
        );

    const asoCount =
        document.getElementById(
            'asoCount'
        );

    const asoAmount =
        document.getElementById(
            'asoAmount'
        );

    const totalCount =
        document.getElementById(
            'totalCount'
        );

    const totalAmount =
        document.getElementById(
            'totalAmount'
        );

    const subTotal =
        document.getElementById(
            'subTotal'
        );

    const gstPercent =
        document.getElementById(
            'gstPercent'
        );

    const gstAmount =
        document.getElementById(
            'gstAmount'
        );

    const tdsPercent =
        document.getElementById(
            'tdsPercent'
        );

    const tdsAmount =
        document.getElementById(
            'tdsAmount'
        );

    const netPayment =
        document.getElementById(
            'netPayment'
        );


    let editingCard = null;


    const STORAGE_KEY =
        'securityDeploymentBills';


    function getStoredBills() {

        try {

            return JSON.parse(
                localStorage.getItem(
                    STORAGE_KEY
                )
            ) || [];

        } catch (error) {

            return [];

        }

    }


    function saveStoredBills(bills) {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(bills)
        );

    }


    function formatAmount(value) {

        const number =
            Number(value || 0);

        return '$' +
            number.toLocaleString(
                'en-US',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );

    }


    function formatMonth(value) {

        if (!value) {
            return '';
        }

        const parts =
            value.split('-');

        if (parts.length !== 2) {
            return value;
        }

        const date =
            new Date(
                Number(parts[0]),
                Number(parts[1]) - 1,
                1
            );

        return date.toLocaleDateString(
            'en-US',
            {
                month: 'long',
                year: 'numeric'
            }
        );

    }


    function calculateValues(data) {

        const securityCountValue =
            Number(
                data.securityCount || 0
            );

        const securityAmountValue =
            Number(
                data.securityAmount || 0
            );

        const asoCountValue =
            Number(
                data.asoCount || 0
            );

        const asoAmountValue =
            Number(
                data.asoAmount || 0
            );

        const gstValue =
            Number(
                data.gst || 0
            );

        const tdsValue =
            Number(
                data.tds || 0
            );


        const totalCountValue =
            securityCountValue +
            asoCountValue;


        const totalAmountValue =
            securityAmountValue +
            asoAmountValue;


        const subTotalValue =
            totalAmountValue;


        const gstAmountValue =
            subTotalValue *
            gstValue /
            100;


        const tdsAmountValue =
            subTotalValue *
            tdsValue /
            100;


        const netPaymentValue =
            subTotalValue +
            gstAmountValue -
            tdsAmountValue;


        return {

            totalCount:
                totalCountValue,

            totalAmount:
                totalAmountValue,

            subTotal:
                subTotalValue,

            gstAmount:
                gstAmountValue,

            tdsAmount:
                tdsAmountValue,

            netPayment:
                netPaymentValue

        };

    }


    function calculateBill() {

        const values =
            calculateValues({

                securityCount:
                    securityCount.value,

                securityAmount:
                    securityAmount.value,

                asoCount:
                    asoCount.value,

                asoAmount:
                    asoAmount.value,

                gst:
                    gstPercent.value,

                tds:
                    tdsPercent.value

            });


        totalCount.value =
            values.totalCount;

        totalAmount.value =
            values.totalAmount.toFixed(2);

        subTotal.value =
            values.subTotal.toFixed(2);

        gstAmount.value =
            values.gstAmount.toFixed(2);

        tdsAmount.value =
            values.tdsAmount.toFixed(2);

        netPayment.textContent =
            formatAmount(
                values.netPayment
            );

    }


    [
        securityCount,
        securityAmount,
        asoCount,
        asoAmount,
        gstPercent,
        tdsPercent
    ].forEach(function (element) {

        element.addEventListener(
            'input',
            calculateBill
        );

        element.addEventListener(
            'change',
            calculateBill
        );

    });


    function getNextBillNumber() {

        const cards =
            document.querySelectorAll(
                '.security-bill-card'
            );

        let highest =
            0;


        cards.forEach(function (card) {

            const value =
                card.dataset.billNo || '';

            const match =
                value.match(
                    /SEC-B-(\d+)/
                );

            if (match) {

                highest =
                    Math.max(
                        highest,
                        Number(match[1])
                    );

            }

        });


        getStoredBills().forEach(function (bill) {

            const value =
                bill.billNo || '';

            const match =
                value.match(
                    /SEC-B-(\d+)/
                );

            if (match) {

                highest =
                    Math.max(
                        highest,
                        Number(match[1])
                    );

            }

        });


        return 'SEC-B-' +
            String(
                highest + 1
            ).padStart(2, '0');

    }


    function resetModal() {

        editingCard = null;


        document.getElementById(
            'newSecurityBillModalLabel'
        ).textContent =
            'CREATE SECURITY DEPLOYMENT BILL';


        saveText.textContent =
            'Create Security Deployment Bill';


        saveButton.style.display =
            '';


        billNumber.disabled = false;
        month.disabled = false;
        project.disabled = false;
        vendor.disabled = false;
        securityCount.disabled = false;
        securityAmount.disabled = false;
        asoCount.disabled = false;
        asoAmount.disabled = false;
        gstPercent.disabled = false;
        tdsPercent.disabled = false;


        billNumber.value =
            getNextBillNumber();


        month.value =
            '2026-09';


        project.value =
            '';


        vendor.value =
            '';


        securityCount.value =
            '0';


        securityAmount.value =
            '0';


        asoCount.value =
            '0';


        asoAmount.value =
            '0';


        gstPercent.value =
            '';


        tdsPercent.value =
            '2';


        calculateBill();

    }


    function openEditModal(card) {

        editingCard =
            card;


        document.getElementById(
            'newSecurityBillModalLabel'
        ).textContent =
            'EDIT SECURITY DEPLOYMENT BILL';


        saveText.textContent =
            'Save Changes';


        saveButton.style.display =
            '';


        billNumber.disabled = false;
        month.disabled = false;
        project.disabled = false;
        vendor.disabled = false;
        securityCount.disabled = false;
        securityAmount.disabled = false;
        asoCount.disabled = false;
        asoAmount.disabled = false;
        gstPercent.disabled = false;
        tdsPercent.disabled = false;


        billNumber.value =
            card.dataset.billNo || '';


        month.value =
            card.dataset.month || '';


        project.value =
            card.dataset.project || '';


        vendor.value =
            card.dataset.vendor || '';


        securityCount.value =
            card.dataset.securityCount || '0';


        securityAmount.value =
            card.dataset.securityAmount || '0';


        asoCount.value =
            card.dataset.asoCount || '0';


        asoAmount.value =
            card.dataset.asoAmount || '0';


        gstPercent.value =
            card.dataset.gst || '';


        tdsPercent.value =
            card.dataset.tds || '2';


        calculateBill();


        modal.show();

    }


    function getFormData() {

        return {

            billNo:
                billNumber.value.trim(),

            month:
                month.value,

            project:
                project.value,

            vendor:
                vendor.value,

            securityCount:
                Number(
                    securityCount.value || 0
                ),

            securityAmount:
                Number(
                    securityAmount.value || 0
                ),

            asoCount:
                Number(
                    asoCount.value || 0
                ),

            asoAmount:
                Number(
                    asoAmount.value || 0
                ),

            gst:
                Number(
                    gstPercent.value || 0
                ),

            tds:
                Number(
                    tdsPercent.value || 0
                )

        };

    }


    function escapeHtml(value) {

        return String(value || '')
            .replace(
                /&/g,
                '&amp;'
            )
            .replace(
                /</g,
                '&lt;'
            )
            .replace(
                />/g,
                '&gt;'
            )
            .replace(
                /"/g,
                '&quot;'
            )
            .replace(
                /'/g,
                '&#039;'
            );

    }


    function createCard(data) {

        const column =
            document.createElement('div');


        column.className =
            'col-12 security-bill-card';


        column.dataset.billNo =
            data.billNo || '';

        column.dataset.project =
            data.project || '';

        column.dataset.vendor =
            data.vendor || '';

        column.dataset.month =
            data.month || '';

        column.dataset.securityCount =
            data.securityCount || 0;

        column.dataset.securityAmount =
            data.securityAmount || 0;

        column.dataset.asoCount =
            data.asoCount || 0;

        column.dataset.asoAmount =
            data.asoAmount || 0;

        column.dataset.gst =
            data.gst || 0;

        column.dataset.tds =
            data.tds || 0;


        const values =
            calculateValues(data);


        const monthText =
            formatMonth(
                data.month
            );


        column.innerHTML = `

            <div class="card border rounded-3 shadow-sm bg-white">

                <div class="card-body p-3">

                    <div class="security-card-layout">

                        <div class="security-card-left">

                            <div class="d-flex align-items-center mb-2">

                                <span class="security-bill-number">
                                    ${escapeHtml(data.billNo)}
                                </span>

                            </div>

                            <h6 class="vendor-title security-vendor">
                                ${escapeHtml(data.vendor)}
                            </h6>

                            <div class="security-project">
                                ${escapeHtml(data.project)}
                            </div>

                            <div class="security-details">

                                <div class="security-detail-item">

                                    <span class="security-detail-label">
                                        Counts:
                                    </span>

                                    <strong class="security-count-value">
                                        ${values.totalCount} Officers
                                    </strong>

                                </div>

                                <div class="security-detail-item">

                                    <span class="security-detail-label">
                                        Period:
                                    </span>

                                    <strong class="security-month-value">
                                        ${escapeHtml(monthText)}
                                    </strong>

                                </div>

                            </div>

                        </div>


                        <div class="security-card-right">

                            <div class="security-card-actions">

                                <button type="button"
                                        class="security-view-btn"
                                        title="View Security Bill">

                                    <i class="mdi mdi-eye-outline"></i>

                                </button>

                                <button type="button"
                                        class="security-edit-btn"
                                        title="Edit Security Bill">

                                    <i class="mdi mdi-pencil"></i>

                                </button>

                                <button type="button"
                                        class="security-delete-btn"
                                        title="Delete Security Bill">

                                    <i class="mdi mdi-delete-outline"></i>

                                </button>

                            </div>

                            <div class="security-payment-box">

                                <span class="security-net-label">
                                    Net Payment
                                </span>

                                <div class="security-net-payment-display">
                                    ${formatAmount(values.netPayment)}
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        `;


        document
            .getElementById(
                'securityBillCards'
            )
            .appendChild(
                column
            );


        return column;

    }


    function updateCard(card, data) {

        const oldBillNo =
            card.dataset.billNo;


        card.dataset.billNo =
            data.billNo;

        card.dataset.project =
            data.project;

        card.dataset.vendor =
            data.vendor;

        card.dataset.month =
            data.month;

        card.dataset.securityCount =
            data.securityCount;

        card.dataset.securityAmount =
            data.securityAmount;

        card.dataset.asoCount =
            data.asoCount;

        card.dataset.asoAmount =
            data.asoAmount;

        card.dataset.gst =
            data.gst;

        card.dataset.tds =
            data.tds;


        const values =
            calculateValues(data);


        card.querySelector(
            '.security-bill-number'
        ).textContent =
            data.billNo;


        card.querySelector(
            '.security-vendor'
        ).textContent =
            data.vendor;


        card.querySelector(
            '.security-project'
        ).textContent =
            data.project;


        const countElement =
            card.querySelector(
                '.security-count-value'
            );


        if (countElement) {

            countElement.textContent =
                values.totalCount +
                ' Officers';

        }


        const monthElement =
            card.querySelector(
                '.security-month-value'
            );


        if (monthElement) {

            monthElement.textContent =
                formatMonth(
                    data.month
                );

        }


        card.querySelector(
            '.security-net-payment-display'
        ).textContent =
            formatAmount(
                values.netPayment
            );


        return oldBillNo;

    }


    function getDataFromCard(card) {

        return {

            billNo:
                card.dataset.billNo || '',

            month:
                card.dataset.month || '',

            project:
                card.dataset.project || '',

            vendor:
                card.dataset.vendor || '',

            securityCount:
                Number(
                    card.dataset.securityCount || 0
                ),

            securityAmount:
                Number(
                    card.dataset.securityAmount || 0
                ),

            asoCount:
                Number(
                    card.dataset.asoCount || 0
                ),

            asoAmount:
                Number(
                    card.dataset.asoAmount || 0
                ),

            gst:
                Number(
                    card.dataset.gst || 0
                ),

            tds:
                Number(
                    card.dataset.tds || 0
                )

        };

    }


    function openViewModal(card) {

        const data =
            getDataFromCard(card);


        const values =
            calculateValues(data);


        document.getElementById(
            'viewBillNumber'
        ).textContent =
            data.billNo;


        document.getElementById(
            'viewMonth'
        ).textContent =
            formatMonth(
                data.month
            );


        document.getElementById(
            'viewProject'
        ).textContent =
            data.project;


        document.getElementById(
            'viewVendor'
        ).textContent =
            data.vendor;


        document.getElementById(
            'viewSecurityCount'
        ).textContent =
            data.securityCount +
            ' Officers';


        document.getElementById(
            'viewSecurityAmount'
        ).textContent =
            formatAmount(
                data.securityAmount
            );


        document.getElementById(
            'viewAsoCount'
        ).textContent =
            data.asoCount +
            ' Officers';


        document.getElementById(
            'viewAsoAmount'
        ).textContent =
            formatAmount(
                data.asoAmount
            );


        document.getElementById(
            'viewTotalCount'
        ).textContent =
            values.totalCount +
            ' Officers';


        document.getElementById(
            'viewTotalAmount'
        ).textContent =
            formatAmount(
                values.totalAmount
            );


        document.getElementById(
            'viewSubTotal'
        ).textContent =
            formatAmount(
                values.subTotal
            );


        document.getElementById(
            'viewGst'
        ).textContent =
            data.gst +
            '%';


        document.getElementById(
            'viewGstAmount'
        ).textContent =
            formatAmount(
                values.gstAmount
            );


        document.getElementById(
            'viewTds'
        ).textContent =
            data.tds +
            '% / ' +
            formatAmount(
                values.tdsAmount
            );


        document.getElementById(
            'viewNetPayment'
        ).textContent =
            formatAmount(
                values.netPayment
            );


        const viewModalElement =
            document.getElementById(
                'viewSecurityBillModal'
            );


        const viewModal =
            bootstrap.Modal.getOrCreateInstance(
                viewModalElement
            );


        viewModal.show();

    }


    function loadStoredBills() {

        const bills =
            getStoredBills();


        bills.forEach(function (bill) {

            createCard(bill);

        });

    }


    function filterBills() {

        const searchValue =
            document.getElementById(
                'securityBillSearch'
            ).value
            .trim()
            .toLowerCase();


        const selectedMonth =
            document.getElementById(
                'securityMonthFilter'
            ).value;


        const cards =
            document.querySelectorAll(
                '.security-bill-card'
            );


        cards.forEach(function (card) {

            const searchableText = [

                card.dataset.billNo,

                card.dataset.project,

                card.dataset.vendor

            ]
                .join(' ')
                .toLowerCase();


            const matchesSearch =
                !searchValue ||
                searchableText.includes(
                    searchValue
                );


            const matchesMonth =
                !selectedMonth ||
                card.dataset.month ===
                selectedMonth;


            card.style.display =
                matchesSearch &&
                matchesMonth
                    ? ''
                    : 'none';

        });

    }


    document.addEventListener(
        'click',
        function (event) {

            const editButton =
                event.target.closest(
                    '.security-edit-btn'
                );


            const viewButton =
                event.target.closest(
                    '.security-view-btn'
                );


            const deleteButton =
                event.target.closest(
                    '.security-delete-btn'
                );


            if (editButton) {

                const card =
                    editButton.closest(
                        '.security-bill-card'
                    );


                if (card) {

                    openEditModal(
                        card
                    );

                }

            }


            if (viewButton) {

                const card =
                    viewButton.closest(
                        '.security-bill-card'
                    );


                if (card) {

                    openViewModal(
                        card
                    );

                }

            }


            if (deleteButton) {

                const card =
                    deleteButton.closest(
                        '.security-bill-card'
                    );


                if (!card) {
                    return;
                }


                const billNo =
                    card.dataset.billNo;


                const confirmed =
                    confirm(
                        'Are you sure you want to delete ' +
                        billNo +
                        '?'
                    );


                if (!confirmed) {
                    return;
                }


                const bills =
                    getStoredBills().filter(
                        function (bill) {

                            return (
                                bill.billNo !==
                                billNo
                            );

                        }
                    );


                saveStoredBills(
                    bills
                );


                card.remove();


                filterBills();

            }

        }
    );


    newButton.addEventListener(
        'click',
        function () {

            resetModal();

        }
    );


    saveButton.addEventListener(
        'click',
        function () {

            const data =
                getFormData();


            if (!data.billNo) {

                alert(
                    'Please enter Bill Number.'
                );

                return;

            }


            if (!data.month) {

                alert(
                    'Please select Month.'
                );

                return;

            }


            if (!data.project) {

                alert(
                    'Please select Project.'
                );

                return;

            }


            if (!data.vendor) {

                alert(
                    'Please select Vendor.'
                );

                return;

            }


            if (!data.gst) {

                alert(
                    'Please select GST %.'
                );

                return;

            }


            if (editingCard) {

                const oldBillNo =
                    editingCard.dataset.billNo;


                const duplicate =
                    Array.from(
                        document.querySelectorAll(
                            '.security-bill-card'
                        )
                    ).some(function (card) {

                        return (
                            card !== editingCard &&
                            card.dataset.billNo ===
                            data.billNo
                        );

                    });


                if (duplicate) {

                    alert(
                        'Bill Number already exists.'
                    );

                    return;

                }


                updateCard(
                    editingCard,
                    data
                );


                const bills =
                    getStoredBills();


                const index =
                    bills.findIndex(
                        function (bill) {

                            return (
                                bill.billNo ===
                                oldBillNo
                            );

                        }
                    );


                if (index !== -1) {

                    bills[index] =
                        data;

                } else {

                    bills.push(
                        data
                    );

                }


                saveStoredBills(
                    bills
                );

            } else {

                const existing =
                    Array.from(
                        document.querySelectorAll(
                            '.security-bill-card'
                        )
                    ).some(function (card) {

                        return (
                            card.dataset.billNo ===
                            data.billNo
                        );

                    });


                if (existing) {

                    alert(
                        'Bill Number already exists.'
                    );

                    return;

                }


                createCard(
                    data
                );


                const bills =
                    getStoredBills();


                bills.push(
                    data
                );


                saveStoredBills(
                    bills
                );

            }


            modal.hide();


            filterBills();

        }
    );


    const searchInput =
        document.getElementById(
            'securityBillSearch'
        );


    const monthFilter =
        document.getElementById(
            'securityMonthFilter'
        );


    if (searchInput) {

        searchInput.addEventListener(
            'input',
            filterBills
        );

    }


    if (monthFilter) {

        monthFilter.addEventListener(
            'change',
            filterBills
        );

    }


    loadStoredBills();


    calculateBill();

});

</script>

@endsection