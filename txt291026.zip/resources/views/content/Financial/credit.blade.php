@extends('layouts.layoutMaster')

@section('title', 'Credit/Debit Note')

@section('content')

<div class="container-fluid py-3">

    <div class="card shadow-sm rounded-2 mb-4">

        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3">

                <div>

                    <h4 class="mb-1 fw-bold text-black fs-3">
                        Planning & Quantity Surveying (QS) Engine
                    </h4>

                    <p class="text-muted mb-0 fs-7">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>

                </div>

                <div class="settings-tabs-wrapper">

                    <div class="d-flex align-items-center gap-2">

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">

                            <i class="mdi mdi-chevron-left"></i>

                        </button>

                        <div class="settings-tabs-scroller">

                            <div class="settings-tabs-track"
                                 id="qsTabsTrack">

                                <a href="{{ route('planning-qs.client') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.client') ? 'active' : '' }}">
                                    Client RA Bill
                                </a>

                                <a href="{{ route('planning-qs.financial.contractor') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.contractor') ? 'active' : '' }}">
                                    Contractor RA Bill
                                </a>

                                <a href="{{ route('planning-qs.financial.credit') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.credit') ? 'active' : '' }}">
                                    Credit/Debit Note
                                </a>

                                <a href="{{ route('planning-qs.financial.security') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.security') ? 'active' : '' }}">
                                    Security Deployment Bill
                                </a>

                              <a href="{{ route('planning-qs.financial.report') }}"
                                  class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.report') ? 'active' : '' }}">
                                         HO Financial Report
                                 </a>
                            </div>

                        </div>

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">

                            <i class="mdi mdi-chevron-right"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="card border-0 shadow-sm rounded-4 bg-white mb-3">

        <div class="card-body p-3">

            <div class="row g-2 align-items-center">

                <div class="col-12 col-lg-3">

                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0
                                     translate-middle-y ps-2 text-muted"
                              style="pointer-events:none;">

                            <i class="mdi mdi-magnify"></i>

                        </span>

                        <input
                            id="creditDebitSearch"
                            type="text"
                            placeholder="Search Note No, Vendor, Description..."
                            class="form-control form-control-sm ps-4
                                   bg-light border-0 rounded-3"
                            style="height:34px;font-size:11px;"
                            autocomplete="off">

                    </div>

                </div>


                <div class="col-12 col-md-4 col-lg-4">

                    <select id="noteTypeFilter"
                            class="form-select form-select-sm
                                   bg-light border-0 rounded-3">

                        <option value="">
                            All Types
                        </option>

                        <option value="Credit Note">
                            Credit Note
                        </option>

                        <option value="Debit Note">
                            Debit Note
                        </option>

                    </select>

                </div>


                <div class="col-12 col-md-4 col-lg-2">

                    <select id="noteDateFilter"
                            class="form-select form-select-sm
                                   bg-light border-0 rounded-3">

                        <option value="">
                            All Dates
                        </option>

                        <option value="2026-07">
                            July 2026
                        </option>

                        <option value="2026-06">
                            June 2026
                        </option>

                        <option value="2026-05">
                            May 2026
                        </option>

                    </select>

                </div>


                <div class="col-12 col-lg-3">

                    <button type="button"
                            class="btn btn-primary btn-sm rounded-3
                                   d-inline-flex align-items-center
                                   justify-content-center
                                   px-3 w-100"
                            style="height:38px;white-space:nowrap;"
                            id="newCreditDebitBtn"
                            data-bs-toggle="modal"
                            data-bs-target="#newCreditDebitModal">

                        <i class="mdi mdi-plus me-1"></i>

                        <span>
                            New Credit/Debit Note
                        </span>

                    </button>

                </div>

            </div>

        </div>

    </div>


    <div class="row g-3 g-md-4" id="creditDebitCards">

        <div class="col-12 col-lg-6 note-card"
             data-note-no="CDN-001"
             data-work-order="CTR-WO-2026-012"
             data-contractor="UltraTech Cement Corp"
             data-type="Credit Note"
             data-date="2026-07-10"
             data-amount="145000"
             data-description="Bulk purchase volume rebate applied">

            <div class="card border rounded-3 h-100 shadow-sm bg-white">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center mb-2">

                        <span class="note-number badge bg-light text-secondary border font-monospace note-number-value">
                            CDN-001
                        </span>

                        <span class="note-number badge bg-light text-primary border font-monospace ms-2 work-order-value">
                            CTR-WO-2026-012
                        </span>

                        <div class="d-flex align-items-center gap-1 ms-auto">

                            <span class="note-type-pill credit-pill note-type-value">
                                Credit Note
                            </span>

                            <button type="button"
                                    class="note-view-btn"
                                    title="View Credit Note">

                                <i class="mdi mdi-eye-outline"></i>

                            </button>

                            <button type="button"
                                    class="note-edit-btn"
                                    title="Edit Credit Note">

                                <i class="mdi mdi-pencil"></i>

                            </button>

                        </div>

                    </div>


                    <h6 class="vendor-title contractor-value">
                        UltraTech Cement Corp
                    </h6>


                    <div class="desc-box description-value">
                        Bulk purchase volume rebate applied
                    </div>


                    <div class="d-flex align-items-center justify-content-between">

                        <div class="d-flex align-items-center">

                            <span class="amount-label">
                                Amount:
                            </span>

                            <span class="amount-value credit-amount amount-value-display">
                                $145,000
                            </span>

                        </div>

                        <span class="note-date date-value">
                            2026-07-10
                        </span>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-lg-6 note-card"
             data-note-no="CDN-002"
             data-work-order="WO-CON-IND-001"
             data-contractor="Star Bar-Bending Works"
             data-type="Debit Note"
             data-date="2026-07-15"
             data-amount="38000"
             data-description="Rebar scrap wastage exceeded 2.5% threshold">

            <div class="card border rounded-3 h-100 shadow-sm bg-white">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center mb-2">

                        <span class="note-number badge bg-light text-primary border font-monospace note-number-value">
                            CDN-002
                        </span>

                        <span class="note-number badge bg-light text-primary border font-monospace ms-2 work-order-value">
                            WO-CON-IND-001
                        </span>

                        <div class="d-flex align-items-center gap-1 ms-auto">

                            <span class="note-type-pill debit-pill note-type-value">
                                Debit Note
                            </span>

                            <button type="button"
                                    class="note-view-btn"
                                    title="View Debit Note">

                                <i class="mdi mdi-eye-outline"></i>

                            </button>

                            <button type="button"
                                    class="note-edit-btn"
                                    title="Edit Debit Note">

                                <i class="mdi mdi-pencil"></i>

                            </button>

                        </div>

                    </div>


                    <h6 class="vendor-title contractor-value">
                        Star Bar-Bending Works
                    </h6>


                    <div class="desc-box description-value">
                        Rebar scrap wastage exceeded 2.5% threshold
                    </div>


                    <div class="d-flex align-items-center justify-content-between">

                        <div class="d-flex align-items-center">

                            <span class="amount-label">
                                Amount:
                            </span>

                            <span class="amount-value debit-amount amount-value-display">
                                $38,000
                            </span>

                        </div>

                        <span class="note-date date-value">
                            2026-07-15
                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="modal fade"
         id="newCreditDebitModal"
         tabindex="-1"
         aria-labelledby="newCreditDebitModalLabel"
         aria-hidden="true">

        <div class="modal-dialog modal-lg modal-dialog-centered">

            <div class="modal-content border-0 shadow-lg rounded-4">

                <div class="modal-header bg-primary">

                    <h5 class="modal-title fw-bold text-white"
                        id="newCreditDebitModalLabel">

                        NEW CREDIT/DEBIT NOTE

                    </h5>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                    </button>

                </div>


                <div class="modal-body p-3 p-md-6">

                    <div class="row g-3">

                        <div class="col-md-4">

                            <label class="form-label">
                                Contractor *
                            </label>

                            <select class="form-select"
                                    id="noteContractor">

                                <option value="">
                                    Select contractor
                                </option>

                                <option value="UltraTech Cement Corp">
                                    UltraTech Cement Corp
                                </option>

                                <option value="Star Bar-Bending Works">
                                    Star Bar-Bending Works
                                </option>

                                <option value="Apex Structural Sub-Contractors">
                                    Apex Structural Sub-Contractors
                                </option>

                                <option value="Ram construction">
                                    Ram construction
                                </option>

                            </select>

                        </div>


                        <div class="col-md-4">

                            <label class="form-label">
                                Contractor Work Order *
                            </label>

                            <select class="form-select"
                                    id="noteWorkOrder">

                                <option value="">
                                    Select Work Order
                                </option>

                                <option value="CTR-WO-2026-012">
                                    CTR-WO-2026-012
                                </option>

                                <option value="WO-CON-IND-001">
                                    WO-CON-IND-001
                                </option>

                                <option value="CTR-WO-2026-015">
                                    CTR-WO-2026-015
                                </option>

                            </select>

                        </div>


                        <div class="col-md-4">

                            <label class="form-label">
                                Credit/Debit*
                            </label>

                            <select class="form-select"
                                    id="noteType">

                                <option value="">
                                    Select Credit/Debit
                                </option>

                                <option value="Credit">
                                    Credit
                                </option>

                                <option value="Debit">
                                    Debit
                                </option>

                            </select>

                        </div>


                        <div class="col-md-4">

                            <label class="form-label">
                                Bill Number *
                            </label>

                            <input type="text"
                                   class="form-control"
                                   id="noteBillNumber"
                                   value="CDN-003">

                        </div>


                        <div class="col-md-4">

                            <label class="form-label">
                                Note Date *
                            </label>

                            <input type="date"
                                   class="form-control"
                                   id="noteDate"
                                   value="2026-09-10">

                        </div>


                        <div class="col-md-4">

                            <label class="form-label">
                                Amount *
                            </label>

                            <div class="input-group">


                                <input type="number"
                                       class="form-control"
                                       id="noteAmount"
                                       placeholder="0.00">

                            </div>

                        </div>


                        <div class="col-12">

                            <label class="form-label">
                                Description *
                            </label>

                            <textarea class="form-control"
                                      id="noteDescription"
                                      rows="3"
                                      placeholder="Enter reason for credit/debit note"></textarea>

                        </div>

                    </div>

                </div>


                <div class="modal-footer">

                    <button type="button"
                            class="btn btn-light border rounded-3"
                            data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button"
                            class="btn btn-primary rounded-3"
                            id="createNoteBtn">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="noteSaveText">
                            Create Note
                        </span>

                    </button>

                </div>

            </div>

        </div>

    </div>


   
    <div class="modal fade"
         id="viewCreditDebitModal"
         tabindex="-1"
         aria-labelledby="viewCreditDebitModalLabel"
         aria-hidden="true">

        <div class="modal-dialog modal-xl modal-dialog-centered">

            <div class="modal-content border-0 shadow-lg rounded-4">

                <div class="modal-header bg-primary">

                    <h5 class="modal-title fw-bold text-white"
                        id="viewCreditDebitModalLabel">

                        CREDIT/DEBIT NOTE

                    </h5>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                    </button>

                </div>


                <div class="modal-body p-4">

                    <div class="print-note">

                        <div class="print-note-header">
                            <div>
                                <strong id="pnCompanyName">Planning & Quantity Surveying (QS) Engine</strong><br>
                                <span id="pnCompanyAddress" class="text-muted" style="font-size:11px;">
                                    Master Schedules, Work Orders, RA Billing & Material Verification
                                </span>
                            </div>
                            <div><strong id="pnNoteType">Debit Note</strong></div>
                        </div>

                        <div class="print-note-row">
                            <div class="pn-cell"><strong>Contractor Name :</strong> <span id="pnContractor"></span></div>
                            <div class="pn-cell"><strong>Project / Work Order :</strong> <span id="pnWorkOrder"></span></div>
                            <div class="pn-cell text-end"><strong>Date :</strong> <span id="pnDate"></span></div>
                        </div>

                        <div class="print-note-row">
                            <div class="pn-cell"><strong>Note No :</strong> <span id="pnNoteNo"></span></div>
                        </div>

                        <table class="print-note-table">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Bill No.</th>
                                    <th>Description</th>
                                    <th>Unit</th>
                                    <th>Quantity</th>
                                    <th>Rate</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody id="pnItemsBody">
                                <!-- rows injected by JS -->
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="6" class="text-end"><strong>Total Amount:</strong></td>
                                    <td class="text-end" id="pnTotal"></td>
                                </tr>
                            </tfoot>
                        </table>

                        <div class="print-note-signatures">
                            <div>Prepared By</div>
                            <div>Checked By</div>
                            <div>Authorised By</div>
                            <div>Received &amp; Accepted By</div>
                        </div>

                    </div>

                </div>


                <div class="modal-footer">

                    <button type="button"
                            class="btn btn-light border rounded-3"
                            data-bs-dismiss="modal">

                        Close

                    </button>

                    <button type="button"
                            class="btn btn-primary rounded-3"
                            id="printNoteBtn">

                        <i class="mdi mdi-printer me-1"></i>
                        Print

                    </button>

                </div>

            </div>

        </div>

    </div>
</div>


<style>

.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}

#creditDebitSearch,
#noteTypeFilter,
#noteDateFilter {
    height: 38px;
    font-size: 12px;
}

#creditDebitSearch {
    height: 34px !important;
    font-size: 11px !important;
}

#creditDebitSearch:focus,
#noteTypeFilter:focus,
#noteDateFilter:focus {
    border-color: #0d6efd !important;
    box-shadow: 0 0 0 .15rem rgba(13, 110, 253, .08) !important;
}

.note-number {
    font-size: 10px;
    font-weight: 600;
    padding: 3px 6px;
    border-radius: 4px;
    background-color: #f1f5f9 !important;
    color: #475569 !important;
    border: 1px solid #e2e8f0 !important;
}

.note-type-pill {
    font-size: 10px;
    font-weight: 600;
    padding: 3px 8px;
    border-radius: 50rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    white-space: nowrap;
}

.credit-pill {
    background-color: #ecfdf5;
    color: #059669;
    border: 1px solid #a7f3d0;
}

.debit-pill {
    background-color: #fef2f2;
    color: #dc2626;
    border: 1px solid #fecaca;
}

.note-edit-btn,
.note-view-btn {
    width: 24px;
    height: 24px;
    padding: 0;
    border: 0;
    background: transparent;
    color: #64748b;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    border-radius: 4px;
    transition: all 0.15s ease;
}

.note-edit-btn i,
.note-view-btn i {
    font-size: 15px;
}

.note-edit-btn:hover,
.note-view-btn:hover {
    background-color: #f1f5f9;
    color: #16659E;
}

.note-date {
    font-size: 11px;
    color: #64748b;
    font-weight: 500;
    white-space: nowrap;
}

.vendor-title {
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
    margin-bottom: 8px;
}

.desc-box {
    background-color: #f8fafc;
    border: 1px solid #f1f5f9;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 12px;
    color: #475569;
    margin-bottom: 10px;
}

.amount-label {
    font-size: 12px;
    color: #64748b;
    margin-right: 6px;
}

.amount-value {
    font-size: 14px;
    font-weight: 800;
}

.credit-amount {
    color: #059669;
}

.debit-amount {
    color: #dc2626;
}

#newCreditDebitModal .modal-dialog,
#viewCreditDebitModal .modal-dialog {
    max-width: 900px;
}

#newCreditDebitModal .modal-content,
#viewCreditDebitModal .modal-content {
    overflow: hidden;
}

#newCreditDebitModal .modal-header,
#viewCreditDebitModal .modal-header {
    padding: 13px 18px;
}

#newCreditDebitModal .modal-title,
#viewCreditDebitModal .modal-title {
    font-size: 14px;
}

#newCreditDebitModal .modal-body {
    background: #fff;
}

#newCreditDebitModal .form-label {
    color: #334155;
    font-size: 11px;
    font-weight: 700;
    margin-bottom: 5px;
}

#newCreditDebitModal .form-control,
#newCreditDebitModal .form-select {
    height: 36px;
    border-color: #dbe2ea;
    border-radius: 7px;
    font-size: 11px;
}

#newCreditDebitModal textarea.form-control {
    height: auto;
    resize: vertical;
}

#newCreditDebitModal .input-group-text {
    height: 36px;
    font-size: 11px;
    background: #f8fafc;
    border-color: #dbe2ea;
}

#newCreditDebitModal .modal-footer,
#viewCreditDebitModal .modal-footer {
    padding: 10px 18px;
}

#newCreditDebitModal .modal-footer .btn,
#viewCreditDebitModal .modal-footer .btn {
    height: 34px;
    font-size: 11px;
    font-weight: 600;
}


/* ===================== PRINTED NOTE STYLES (new) ===================== */

.print-note {
    border: 1px solid #333;
    padding: 0;
}

.print-note-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 15px;
    border-bottom: 2px solid #333;
    padding: 12px 14px;
}

.print-note-row {
    display: flex;
    border: 1px solid #333;
    border-top: none;
}

.pn-cell {
    flex: 1;
    padding: 8px 12px;
    border-right: 1px solid #333;
    font-size: 13px;
}

.pn-cell:last-child {
    border-right: none;
}

.print-note-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: -1px;
}

.print-note-table th {
    background: #29a8dc;
    color: #fff;
    border: 1px solid #333;
    padding: 8px;
    font-size: 12px;
    text-align: center;
}

.print-note-table td {
    border: 1px solid #333;
    padding: 8px;
    font-size: 12px;
    vertical-align: top;
}

.print-note-signatures {
    display: flex;
    border: 1px solid #333;
    border-top: none;
    margin-top: -1px;
}

.print-note-signatures div {
    flex: 1;
    padding: 60px 12px 12px;
    border-right: 1px solid #333;
    font-size: 12px;
    color: #444;
}

.print-note-signatures div:last-child {
    border-right: none;
}

@media print {

    body * {
        visibility: hidden;
    }

    #viewCreditDebitModal,
    #viewCreditDebitModal * {
        visibility: visible;
    }

    #viewCreditDebitModal {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
    }
#viewCreditDebitModal .modal-dialog {
    max-width: 1000px;
    width: 90%;
    margin: 1.75rem auto;
}


    #viewCreditDebitModal .modal-header .btn-close,
    #viewCreditDebitModal .modal-footer {
        display: none !important;
    }

}



@media (min-width: 1200px) {

    .settings-tabs-scroller {
        max-width: 700px;
    }

}

@media (max-width: 1199.98px) {

    .settings-tabs-scroller {
        max-width: 500px;
    }

}

@media (max-width: 991.98px) {

    .settings-tabs-scroller {
        max-width: 100%;
    }

}

@media (max-width: 767px) {

    .settings-tabs-scroller {
        max-width: 220px;
    }

    .settings-tab-pill {
        padding: .4rem .8rem;
        font-size: .78rem;
    }

    .settings-tab-scroll-btn {
        width: 28px;
        height: 28px;
    }

    .desc-box {
        max-width: 100%;
    }

    .print-note-header {
        flex-direction: column;
    }

    .print-note-row {
        flex-direction: column;
    }

    .pn-cell {
        border-right: none;
        border-bottom: 1px solid #333;
    }

    .pn-cell:last-child {
        border-bottom: none;
    }

    .print-note-signatures {
        flex-direction: column;
    }

    .print-note-signatures div {
        border-right: none;
        border-bottom: 1px solid #333;
    }

    .print-note-signatures div:last-child {
        border-bottom: none;
    }

}

@media (max-width: 575.98px) {

    .card-body {
        padding: 12px !important;
    }

    .amount-value {
        font-size: 13px;
    }

}

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const tabsTrack =
        document.getElementById('qsTabsTrack');

    const leftButton =
        document.getElementById('qsTabScrollLeft');

    const rightButton =
        document.getElementById('qsTabScrollRight');


    if (tabsTrack) {

        if (leftButton) {

            leftButton.addEventListener('click', function () {

                tabsTrack.scrollBy({
                    left: -220,
                    behavior: 'smooth'
                });

            });

        }


        if (rightButton) {

            rightButton.addEventListener('click', function () {

                tabsTrack.scrollBy({
                    left: 220,
                    behavior: 'smooth'
                });

            });

        }

    }


    const searchInput =
        document.getElementById('creditDebitSearch');

    const typeFilter =
        document.getElementById('noteTypeFilter');

    const dateFilter =
        document.getElementById('noteDateFilter');

    const modalElement =
        document.getElementById('newCreditDebitModal');

    const viewModalElement =
        document.getElementById('viewCreditDebitModal');

    const modal =
        bootstrap.Modal.getOrCreateInstance(modalElement);

    const viewModal =
        bootstrap.Modal.getOrCreateInstance(viewModalElement);

    const newButton =
        document.getElementById('newCreditDebitBtn');

    const createNoteBtn =
        document.getElementById('createNoteBtn');

    const noteSaveText =
        document.getElementById('noteSaveText');

    const modalTitle =
        document.getElementById('newCreditDebitModalLabel');

    const noteContractor =
        document.getElementById('noteContractor');

    const noteWorkOrder =
        document.getElementById('noteWorkOrder');

    const noteType =
        document.getElementById('noteType');

    const noteBillNumber =
        document.getElementById('noteBillNumber');

    const noteDate =
        document.getElementById('noteDate');

    const noteAmount =
        document.getElementById('noteAmount');

    const noteDescription =
        document.getElementById('noteDescription');


    let editingCard = null;


    const STORAGE_KEY = 'creditDebitNotes';


    function getStoredNotes() {

        try {

            return JSON.parse(
                localStorage.getItem(STORAGE_KEY)
            ) || [];

        } catch (error) {

            return [];

        }

    }


    function saveStoredNotes(notes) {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(notes)
        );

    }


    function saveCurrentCardsToStorage() {

        const cards =
            document.querySelectorAll('.note-card');

        const notes =
            Array.from(cards).map(function (card) {

                return {

                    noteNo:
                        card.dataset.noteNo || '',

                    workOrder:
                        card.dataset.workOrder || '',

                    contractor:
                        card.dataset.contractor || '',

                    type:
                        card.dataset.type || '',

                    date:
                        card.dataset.date || '',

                    amount:
                        card.dataset.amount || '',

                    description:
                        card.dataset.description || ''

                };

            });

        saveStoredNotes(notes);

    }


    function loadNotesFromStorage() {

        const storedNotes =
            getStoredNotes();

        if (!storedNotes.length) {

            saveCurrentCardsToStorage();

            return;

        }

        const cardsContainer =
            document.getElementById(
                'creditDebitCards'
            );

        cardsContainer.innerHTML = '';

        storedNotes.forEach(function (note) {

            createCard(
                note.noteNo,
                note.workOrder,
                note.contractor,
                note.type === 'Credit Note'
                    ? 'Credit'
                    : 'Debit',
                note.date,
                note.amount,
                note.description
            );

        });

    }


    function resetModal() {

        editingCard = null;

        modalTitle.textContent =
            'NEW CREDIT/DEBIT NOTE';

        noteSaveText.textContent =
            'Create Note';

        createNoteBtn.style.display =
            '';

        noteContractor.disabled =
            false;

        noteWorkOrder.disabled =
            false;

        noteType.disabled =
            false;

        noteBillNumber.disabled =
            false;

        noteDate.disabled =
            false;

        noteAmount.disabled =
            false;

        noteDescription.disabled =
            false;

        noteContractor.value =
            '';

        noteWorkOrder.value =
            '';

        noteType.value =
            '';

        noteBillNumber.value =
            '';

        noteDate.value =
            '2026-09-10';

        noteAmount.value =
            '';

        noteDescription.value =
            '';

    }


    function openEditModal(card) {

        editingCard = card;

        modalTitle.textContent =
            'EDIT CREDIT/DEBIT NOTE';

        noteSaveText.textContent =
            'Save Changes';

        createNoteBtn.style.display =
            '';

        noteContractor.disabled =
            false;

        noteWorkOrder.disabled =
            false;

        noteType.disabled =
            false;

        noteBillNumber.disabled =
            false;

        noteDate.disabled =
            false;

        noteAmount.disabled =
            false;

        noteDescription.disabled =
            false;

        noteContractor.value =
            card.dataset.contractor || '';

        noteWorkOrder.value =
            card.dataset.workOrder || '';

        noteType.value =
            card.dataset.type === 'Credit Note'
                ? 'Credit'
                : 'Debit';

        noteBillNumber.value =
            card.dataset.noteNo || '';

        noteDate.value =
            card.dataset.date || '';

        noteAmount.value =
            card.dataset.amount || '';

        noteDescription.value =
            card.dataset.description || '';

        modal.show();

    }


    
    function openViewModal(card) {

        const type =
            card.dataset.type || '';

        document.getElementById(
            'pnNoteType'
        ).textContent =
            type;


        document.getElementById(
            'viewCreditDebitModalLabel'
        ).textContent =
            type.toUpperCase();


        document.getElementById(
            'pnContractor'
        ).textContent =
            card.dataset.contractor || '';


        document.getElementById(
            'pnWorkOrder'
        ).textContent =
            card.dataset.workOrder || '';


        document.getElementById(
            'pnDate'
        ).textContent =
            card.dataset.date || '';


        document.getElementById(
            'pnNoteNo'
        ).textContent =
            card.dataset.noteNo || '';


        const amount =
            Number(card.dataset.amount || 0);


        document.getElementById(
            'pnItemsBody'
        ).innerHTML = `
            <tr>
                <td class="text-center">1</td>
                <td class="text-center">${card.dataset.noteNo || ''}</td>
                <td>${card.dataset.description || ''}</td>
                <td class="text-center">-</td>
                <td class="text-center">1</td>
                <td class="text-end">${amount.toFixed(2)}</td>
                <td class="text-end">${amount.toFixed(2)}</td>
            </tr>
        `;


        document.getElementById(
            'pnTotal'
        ).textContent =
            amount.toFixed(2);


        viewModal.show();

    }
 


    function formatAmount(value) {

        const number =
            Number(value || 0);

        return '$' +
            number.toLocaleString('en-US', {
                maximumFractionDigits: 2
            });

    }


    function createCard(
        noteNo,
        workOrder,
        contractor,
        type,
        date,
        amount,
        description
    ) {

        const column =
            document.createElement('div');

        column.className =
            'col-12 col-lg-6 note-card';

        column.dataset.noteNo =
            noteNo;

        column.dataset.workOrder =
            workOrder;

        column.dataset.contractor =
            contractor;

        column.dataset.type =
            type === 'Credit'
                ? 'Credit Note'
                : 'Debit Note';

        column.dataset.date =
            date;

        column.dataset.amount =
            amount;

        column.dataset.description =
            description;


        const typeClass =
            type === 'Credit'
                ? 'credit-pill'
                : 'debit-pill';

        const amountClass =
            type === 'Credit'
                ? 'credit-amount'
                : 'debit-amount';

        const typeText =
            type === 'Credit'
                ? 'Credit Note'
                : 'Debit Note';


        column.innerHTML = `

            <div class="card border rounded-3 h-100 shadow-sm bg-white">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center mb-2">

                        <span class="note-number badge bg-light text-secondary border font-monospace note-number-value">
                            ${noteNo}
                        </span>

                        <span class="note-number badge bg-light text-primary border font-monospace ms-2 work-order-value">
                            ${workOrder}
                        </span>

                        <div class="d-flex align-items-center gap-1 ms-auto">

                            <span class="note-type-pill ${typeClass} note-type-value">
                                ${typeText}
                            </span>

                            <button type="button"
                                    class="note-view-btn"
                                    title="View ${typeText}">

                                <i class="mdi mdi-eye-outline"></i>

                            </button>

                            <button type="button"
                                    class="note-edit-btn"
                                    title="Edit ${typeText}">

                                <i class="mdi mdi-pencil"></i>

                            </button>

                        </div>

                    </div>

                    <h6 class="vendor-title contractor-value">
                        ${contractor}
                    </h6>

                    <div class="desc-box description-value">
                        ${description}
                    </div>

                    <div class="d-flex align-items-center justify-content-between">

                        <div class="d-flex align-items-center">

                            <span class="amount-label">
                                Amount:
                            </span>

                            <span class="amount-value ${amountClass} amount-value-display">
                                ${formatAmount(amount)}
                            </span>

                        </div>

                        <span class="note-date date-value">
                            ${date}
                        </span>

                    </div>

                </div>

            </div>

        `;


        document
            .getElementById('creditDebitCards')
            .appendChild(column);


        return column;

    }


    function updateCard(
        card,
        noteNo,
        workOrder,
        contractor,
        type,
        date,
        amount,
        description
    ) {

        card.dataset.noteNo =
            noteNo;

        card.dataset.workOrder =
            workOrder;

        card.dataset.contractor =
            contractor;

        card.dataset.type =
            type === 'Credit'
                ? 'Credit Note'
                : 'Debit Note';

        card.dataset.date =
            date;

        card.dataset.amount =
            amount;

        card.dataset.description =
            description;


        const noteNumber =
            card.querySelector('.note-number-value');

        const workOrderElement =
            card.querySelector('.work-order-value');

        const typeElement =
            card.querySelector('.note-type-value');

        const contractorElement =
            card.querySelector('.contractor-value');

        const descriptionElement =
            card.querySelector('.description-value');

        const amountElement =
            card.querySelector('.amount-value-display');

        const dateElement =
            card.querySelector('.date-value');


        const typeText =
            type === 'Credit'
                ? 'Credit Note'
                : 'Debit Note';


        noteNumber.textContent =
            noteNo;

        workOrderElement.textContent =
            workOrder;

        typeElement.textContent =
            typeText;


        typeElement.classList.remove(
            'credit-pill',
            'debit-pill'
        );


        typeElement.classList.add(
            type === 'Credit'
                ? 'credit-pill'
                : 'debit-pill'
        );


        contractorElement.textContent =
            contractor;

        descriptionElement.textContent =
            description;

        amountElement.textContent =
            formatAmount(amount);


        amountElement.classList.remove(
            'credit-amount',
            'debit-amount'
        );


        amountElement.classList.add(
            type === 'Credit'
                ? 'credit-amount'
                : 'debit-amount'
        );


        dateElement.textContent =
            date;

    }


    createNoteBtn.addEventListener(
        'click',
        function () {

            const contractor =
                noteContractor.value.trim();

            const workOrder =
                noteWorkOrder.value.trim();

            const type =
                noteType.value.trim();

            const noteNo =
                noteBillNumber.value.trim();

            const date =
                noteDate.value.trim();

            const amount =
                noteAmount.value.trim();

            const description =
                noteDescription.value.trim();


            if (
                !contractor ||
                !workOrder ||
                !type ||
                !noteNo ||
                !date ||
                !amount ||
                !description
            ) {

                alert(
                    'Please fill all required fields.'
                );

                return;

            }


            if (editingCard) {

                const oldNoteNo =
                    editingCard.dataset.noteNo;

                updateCard(
                    editingCard,
                    noteNo,
                    workOrder,
                    contractor,
                    type,
                    date,
                    amount,
                    description
                );


                const storedNotes =
                    getStoredNotes();

                const noteIndex =
                    storedNotes.findIndex(
                        function (note) {
                            return note.noteNo === oldNoteNo;
                        }
                    );


                if (noteIndex !== -1) {

                    storedNotes[noteIndex] = {

                        noteNo:
                            noteNo,

                        workOrder:
                            workOrder,

                        contractor:
                            contractor,

                        type:
                            type === 'Credit'
                                ? 'Credit Note'
                                : 'Debit Note',

                        date:
                            date,

                        amount:
                            amount,

                        description:
                            description

                    };

                    saveStoredNotes(
                        storedNotes
                    );

                }

            } else {

                createCard(
                    noteNo,
                    workOrder,
                    contractor,
                    type,
                    date,
                    amount,
                    description
                );


                const storedNotes =
                    getStoredNotes();


                storedNotes.push({

                    noteNo:
                        noteNo,

                    workOrder:
                        workOrder,

                    contractor:
                        contractor,

                    type:
                        type === 'Credit'
                            ? 'Credit Note'
                            : 'Debit Note',

                    date:
                        date,

                    amount:
                        amount,

                    description:
                        description

                });


                saveStoredNotes(
                    storedNotes
                );

            }


            modal.hide();

            filterNotes();

        }
    );


    newButton.addEventListener(
        'click',
        function () {

            resetModal();

        }
    );


    document.addEventListener(
        'click',
        function (event) {

            const editButton =
                event.target.closest(
                    '.note-edit-btn'
                );

            const viewButton =
                event.target.closest(
                    '.note-view-btn'
                );


            if (editButton) {

                const card =
                    editButton.closest(
                        '.note-card'
                    );

                if (card) {

                    openEditModal(card);

                }

            }


            if (viewButton) {

                const card =
                    viewButton.closest(
                        '.note-card'
                    );

                if (card) {

                    openViewModal(card);

                }

            }

        }
    );


    modalElement.addEventListener(
        'hidden.bs.modal',
        function () {

            resetModal();

        }
    );


    /* ===================== NEW: Print button handler ===================== */
    const printNoteBtn =
        document.getElementById('printNoteBtn');

    if (printNoteBtn) {

        printNoteBtn.addEventListener(
            'click',
            function () {

                window.print();

            }
        );

    }
    


    function filterNotes() {

        const searchValue =
            searchInput
                ? searchInput.value
                    .toLowerCase()
                    .trim()
                : '';

        const typeValue =
            typeFilter
                ? typeFilter.value
                    .toLowerCase()
                    .trim()
                : '';

        const dateValue =
            dateFilter
                ? dateFilter.value.trim()
                : '';


        const noteCards =
            document.querySelectorAll(
                '.note-card'
            );


        noteCards.forEach(
            function (card) {

                const cardText =
                    card.innerText
                        .toLowerCase();

                const cardType =
                    (
                        card.dataset.type ||
                        ''
                    ).toLowerCase();

                const cardDate =
                    card.dataset.date || '';


                const matchesSearch =
                    searchValue === '' ||
                    cardText.includes(
                        searchValue
                    );


                const matchesType =
                    typeValue === '' ||
                    cardType === typeValue;


                const matchesDate =
                    dateValue === '' ||
                    cardDate.startsWith(
                        dateValue
                    );


                card.style.display =
                    matchesSearch &&
                    matchesType &&
                    matchesDate
                        ? ''
                        : 'none';

            }
        );

    }


    if (searchInput) {

        searchInput.addEventListener(
            'input',
            filterNotes
        );

    }


    if (typeFilter) {

        typeFilter.addEventListener(
            'change',
            filterNotes
        );

    }


    if (dateFilter) {

        dateFilter.addEventListener(
            'change',
            filterNotes
        );

    }


    loadNotesFromStorage();

});

</script>

@endsection