@extends('layouts.layoutMaster')

@section('title', 'Contractor RA Billing Register')

@section('content')

<div class="container-fluid py-3">

    <div class="card shadow-sm rounded-2 mb-4">

        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3">

                <div>

                    <h4 class="mb-1 fw-bold text-black fs-3">
                        Planning & Quantity Surveying (QS) Engine
                    </h4>

                    <p class="text-muted mb-0 fs-7">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>

                </div>

                <div class="settings-tabs-wrapper">

                    <div class="d-flex align-items-center gap-2">

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">

                            <i class="mdi mdi-chevron-left"></i>

                        </button>

                        <div class="settings-tabs-scroller">

                            <div class="settings-tabs-track"
                                 id="qsTabsTrack">

               <a href="{{ route('planning-qs.client') }}"
               class="settings-tab-pill {{ request()->routeIs('planning-qs.client') ? 'active' : '' }}">
               Client RA Bill
              </a>

<a href="{{ route('planning-qs.financial.contractor') }}"
   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.contractor') ? 'active' : '' }}">
    Contractor RA Bill
</a>
                             <a href="{{ route('planning-qs.financial.credit') }}"
   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.credit') ? 'active' : '' }}">
                                    Credit/Debit Note
                                </a>

                                <a href="{{ route('planning-qs.financial.security') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.security') ? 'active' : '' }}">
                                    Security Deployment Bill
                                </a>

                                <a href="#"
                                   class="settings-tab-pill">
                                    HO Financial Report
                                </a>

                            </div>

                        </div>

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">

                            <i class="mdi mdi-chevron-right"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="row g-3 g-md-4 mb-4">

        {{-- Total Gross Claims --}}
        <div class="col-12 col-sm-6 col-lg-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2">
                        Total Gross Claims
                    </span>

                    <span class="d-block fw-bold font-monospace fs-5"
                          style="color:black;">
                        ₹ 63,00,000
                    </span>

                    <span class="d-block fw-semibold font-monospace text-secondary small mt-1">
                        2 contractor claims registered
                    </span>

                </div>

            </div>

        </div>


        {{-- Total GST Taxes --}}
        <div class="col-12 col-sm-6 col-lg-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2">
                        Total GST Taxes
                    </span>

                    <span class="d-block fw-bold font-monospace fs-5 text-success">
                        ₹ 11,34,000
                    </span>

                    <span class="d-block fw-semibold font-monospace text-secondary small mt-1">
                        Input Tax Credit (ITC) claimable
                    </span>

                </div>

            </div>

        </div>


        {{-- Total SD / Retention --}}
        <div class="col-12 col-sm-6 col-lg-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2">
                        Total SD / Retention Held
                    </span>

                    <span class="d-block fw-bold font-monospace fs-5 text-warning">
                        ₹ 3,15,000
                    </span>

                    <span class="d-block fw-semibold font-monospace text-secondary small mt-1">
                        Withheld until DLP expiry
                    </span>

                </div>

            </div>

        </div>


        {{-- Total Net Payable --}}
        <div class="col-12 col-sm-6 col-lg-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2">
                        Total Net Payable
                    </span>

                    <span class="d-block fw-bold font-monospace fs-5 text-primary">
                        ₹ 69,93,000
                    </span>

                    <span class="d-block fw-semibold font-monospace text-secondary small mt-1">
                        <i class="mdi mdi-sync me-1"></i>
                        Synced with Accounts Payables
                    </span>

                </div>

            </div>

        </div>

    </div>


    <div class="card border-0 shadow-sm rounded-4 bg-white mb-3">

        <div class="card-body p-3">

            <div class="row g-2 align-items-center">

                {{-- Search --}}
                <div class="col-12 col-lg-4">

                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0
                                     translate-middle-y ps-2 text-muted"
                              style="pointer-events:none;">

                            <i class="mdi mdi-magnify"></i>

                        </span>

                        <input
                            id="contractorRaSearch"
                            type="text"
                            placeholder="Search RA No, Contractor, Project, Work Order..."
                            class="form-control form-control-sm ps-4
                                   bg-light border-0 rounded-3"
                            style="height:34px;font-size:11px;"
                            autocomplete="off">

                    </div>

                </div>


                {{-- Project Filter --}}
                <div class="col-12 col-md-4 col-lg-3">

                    <select id="contractorProjectFilter"
                            class="form-select form-select-sm
                                   bg-light border-0 rounded-3">

                        <option value="">
                            All Projects
                        </option>

                        <option value="ELCOT IT Park">
                            ELCOT IT Park
                        </option>

                        <option value="East Coast Road Elevated Bridge">
                            East Coast Road Elevated Bridge
                        </option>

                        <option value="Chennai Metro Phase 2 - Corridor 4">
                            Chennai Metro Phase 2 - Corridor 4
                        </option>

                        <option value="Metro Line Extension - Phase 3">
                            Metro Line Extension - Phase 3
                        </option>

                    </select>

                </div>


                {{-- Status Filter --}}
                <div class="col-12 col-md-4 col-lg-3">

                    <select id="contractorStatusFilter"
                            class="form-select form-select-sm
                                   bg-light border-0 rounded-3">

                        <option value="">
                            All Statuses
                        </option>

                        <option value="Passed for Payment">
                            Passed for Payment
                        </option>

                        <option value="Under Verification">
                            Under Verification
                        </option>

                        <option value="Paid">
                            Paid
                        </option>

                    </select>

                </div>


                {{-- Create Contractor RA Bill --}}
                <div class="col-12 col-md-4 col-lg-2">

                    <button type="button"
                            class="btn btn-primary btn-sm rounded-3
                                   d-inline-flex align-items-center
                                   justify-content-center
                                   px-3 w-100"
                            style="height:38px;white-space:nowrap;"
                            data-bs-toggle="modal"
                            data-bs-target="#createContractorRaModal"
                            id="createContractorRaToolbarBtn">

                        <i class="mdi mdi-plus me-1"></i>

                        <span>
                            Create Contractor RA Bill
                        </span>

                    </button>

                </div>

            </div>

        </div>

    </div>



    <div class="modal fade"
         id="createContractorRaModal"
         tabindex="-1"
         aria-labelledby="createContractorRaModalLabel"
         aria-hidden="true">

        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">

            <div class="modal-content border-0 shadow-lg rounded-4">

                {{-- Header --}}
                <div class="modal-header view-ra-header bg-primary">

                    <div>

                        <h5 class="modal-title fw-bold mb-1 text-white"
                            id="createContractorRaModalLabel">

                            CREATE CONTRACTOR RA BILL

                        </h5>



                    </div>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                    </button>

                </div>


                {{-- Body --}}
                <div class="modal-body px-3 py-3">

                    <form id="contractorRaBillForm">

                        <div class="row g-2">

                        {{-- Month --}}
<div class="col-md-4">

    <label class="form-label">
        Month *
    </label>

    <select class="form-select"
            id="contractorMonth"
            name="month">

        <option value="2026-Jul" selected>
            2026-Jul
        </option>

        <option value="2026-Jun">
            2026-Jun
        </option>

        <option value="2026-May">
            2026-May
        </option>

        <option value="2026-Apr">
            2026-Apr
        </option>

    </select>

</div>

{{-- Project --}}
<div class="col-md-4">

    <label class="form-label">
        Project *
    </label>

    <select class="form-select"
            id="contractorProject"
            name="project">

        <option value="">
            Select Project
        </option>

        <option value="Chennai Metro Phase 2 - Corridor 4" selected>
            Chennai Metro Phase 2 - Corridor 4
        </option>

        <option value="ELCOT IT Park">
            ELCOT IT Park
        </option>

        <option value="East Coast Road Elevated Bridge">
            East Coast Road Elevated Bridge
        </option>

        <option value="Metro Line Extension - Phase 3">
            Metro Line Extension - Phase 3
        </option>

        <option value="Chennai Outer Ring Road Flyover">
            Chennai Outer Ring Road Flyover
        </option>

    </select>

</div>

{{-- Contractor --}}
<div class="col-md-4">

    <label class="form-label">
        Contractor *
    </label>

    <select class="form-select"
            id="contractorName"
            name="contractor">

        <option value="">
            Select Contractor
        </option>

        <option value="Apex Structural Sub-Contractors" selected>
            Apex Structural Sub-Contractors
        </option>

        <option value="Star Bar-Bending Works">
            Star Bar-Bending Works
        </option>

        <option value="Prime Civil Contractors">
            Prime Civil Contractors
        </option>

        <option value="Metro Infra Works">
            Metro Infra Works
        </option>

    </select>

</div>

                            {{-- Work Order --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    Contractor Work Order *
                                </label>

                                <select class="form-select"
                                        id="contractorWorkOrder"
                                        name="work_order">

                                    <option value="">
                                        Select Work Order
                                    </option>

                                    <option value="SCWO/APEX/088"
                                            selected>
                                        SCWO/APEX/088
                                    </option>

                                    <option value="SCWO/STAR/042">
                                        SCWO/STAR/042
                                    </option>

                                    <option value="SCWO/PRIME/021">
                                        SCWO/PRIME/021
                                    </option>

                                </select>

                            </div>


                            {{-- RA Bill Number --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    Contractor RA Bill No *
                                </label>

                                <input type="text"
                                       class="form-control"
                                       id="contractorRaBillNo"
                                       name="ra_bill_number"
                                       value="RA-CON-16">

                            </div>


                            {{-- Bill Date --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    Bill Date *
                                </label>

                                <input type="date"
                                       class="form-control"
                                       id="contractorBillDate"
                                       name="bill_date"
                                       value="2026-09-09">

                            </div>


                            {{-- GST Type --}}
                            <div class="col-md-3">

                                <label class="form-label">
                                    GST Type *
                                </label>

                                <select class="form-select"
                                        id="gstType"
                                        name="gst_type">

                                    <option value="CGST/SGST" selected>
                                        CGST/SGST
                                    </option>

                                    <option value="IGST">
                                        IGST
                                    </option>

                                    <option value="No GST">
                                        No GST
                                    </option>

                                </select>

                            </div>


                            {{-- GST --}}
                            <div class="col-md-3">

                                <label class="form-label">
                                    GST % *
                                </label>

                                <div class="input-group">

                                    <input type="number"
                                           class="form-control"
                                           id="gstPercent"
                                           name="gst_percent"
                                           value="18"
                                           min="0"
                                           step="0.01">

                                    <span class="input-group-text">
                                        %
                                    </span>

                                </div>

                            </div>


                            {{-- TDS --}}
                            <div class="col-md-3">

                                <label class="form-label">
                                    TDS % *
                                </label>

                                <div class="input-group">

                                    <input type="number"
                                           class="form-control"
                                           id="contractorTdsPercent"
                                           name="tds_percent"
                                           value="0"
                                           min="0"
                                           step="0.01">

                                    <span class="input-group-text">
                                        %
                                    </span>

                                </div>

                            </div>


                            {{-- SD --}}
                            <div class="col-md-3">

                                <label class="form-label">
                                    SD % *
                                </label>

                                <div class="input-group">

                                    <input type="number"
                                           class="form-control"
                                           id="sdPercent"
                                           name="sd_percent"
                                           value="0"
                                           min="0"
                                           step="0.01">

                                    <span class="input-group-text">
                                        %
                                    </span>

                                </div>

                            </div>


                            {{-- Gross --}}
                            <div class="col-6">

                                <label class="form-label">
                                    Work Done / Gross Claim Amount (₹) *
                                </label>

                                <input type="number"
                                       class="form-control"
                                       id="contractorGrossAmount"
                                       name="gross_claim_amount"
                                       value="3200000"
                                       min="0"
                                       step="0.01">

                            </div>


                            {{-- Remarks --}}
                            <div class="col-6">

                                <label class="form-label">
                                    Remarks / Notes
                                </label>

                                <textarea class="form-control"
                                          id="contractorRemarks"
                                          name="remarks"
                                          rows="2">Monthly contractor work execution claim</textarea>

                            </div>


                            {{-- Financial Summary --}}
                            <div class="col-12 mt-2">

                                <div class="ra-form-section-title">
                                    Bill Financial Summary
                                </div>

                            </div>


                            {{-- Summary --}}
                            <div class="col-12">

                                <div class="contractor-financial-summary">

                                    <div class="contractor-summary-row">

                                        <span>
                                            Gross Work Done
                                        </span>

                                        <strong id="summaryGross">
                                            ₹ 32,00,000
                                        </strong>

                                    </div>


                                    <div class="contractor-summary-row">

                                        <span>
                                            GST (<span id="summaryGstRate">18</span>%)
                                        </span>

                                        <strong class="text-success"
                                                id="summaryGst">
                                            + ₹ 5,76,000
                                        </strong>

                                    </div>


                                    <div class="contractor-summary-row">

                                        <span>
                                            TDS (<span id="summaryTdsRate">0</span>%)
                                        </span>

                                        <strong class="text-danger"
                                                id="summaryTds">
                                            - ₹ 0
                                        </strong>

                                    </div>


                                    <div class="contractor-summary-row">

                                        <span>
                                            SD (<span id="summarySdRate">0</span>%)
                                        </span>

                                        <strong class="text-danger"
                                                id="summarySd">
                                            - ₹ 0
                                        </strong>

                                    </div>


                                    <div class="contractor-summary-total">

                                        <span>
                                            Net Payable
                                        </span>

                                        <strong id="summaryNet">
                                            ₹ 37,76,000
                                        </strong>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </form>

                </div>


                {{-- Footer --}}
                <div class="modal-footer px-3 py-2 border-top">

                    <button type="button"
                            class="btn btn-light border rounded-3 px-3 btn-sm"
                            data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button"
                            class="btn btn-primary rounded-3 px-3 btn-sm"
                            id="createContractorRaBill">

                        <i class="mdi mdi-send-check-outline me-1"></i>

                        Create Contractor RA Bill

                    </button>

                </div>

            </div>

        </div>

    </div>



    <div class="card border-0 shadow-sm rounded-4 bg-white mb-3">

        <div class="card-body p-0">

            <div class="contractor-ra-table-wrapper">

                <table class="table contractor-ra-table mb-0">

                    <colgroup>

                        <col class="col-bill">
                        <col class="col-contractor">
                        <col class="col-work-order">

                        <col class="col-amount">
                        <col class="col-amount">
                        <col class="col-amount">
                        <col class="col-amount">
                        <col class="col-amount">

                        <col class="col-status">
                        <col class="col-actions">

                    </colgroup>


                    <thead>

                        <tr>

                            <th class="text-start">
                                BILL NO & DATE
                            </th>

                            <th class="text-start">
                                CONTRACTOR & PROJECT
                            </th>

                            <th class="text-start">
                                WORK ORDER
                            </th>

                            <th class="text-end">
                                GROSS CLAIM
                            </th>

                            <th class="text-end">
                                GST
                            </th>

                            <th class="text-end">
                                TDS (-)
                            </th>

                            <th class="text-end">
                                SD (-)
                            </th>

                            <th class="text-end">
                                NET PAYABLE
                            </th>

                            <th class="text-center">
                                STATUS
                            </th>

                            <th class="text-center">
                                ACTIONS
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        {{-- =================================================
                            ROW 1
                        ================================================== --}}
                        <tr>

                            <td>

                                <div class="bill-no">
                                    RA-CON-14
                                </div>

                                <div class="bill-date">
                                    2026-07-18
                                </div>

                                <div class="period-text mt-1">
                                    2026-Jul
                                </div>

                            </td>


                            <td>

                                <div class="contractor-name">
                                    Apex Structural Sub-Contractors
                                </div>

                                <div class="project-name">
                                    Metro Line Extension - Phase 3
                                </div>

                            </td>


                            <td>

                                <span class="work-order-text">
                                    SCWO/APEX/088
                                </span>

                            </td>


                            <td class="amount-cell">
                                ₹ 42,00,000
                            </td>


                            <td class="amount-cell gst-amount">
                                ₹ 7,56,000
                            </td>


                            <td class="amount-cell deduction-amount-cell">
                                -₹ 84,000
                            </td>


                            <td class="amount-cell deduction-amount-cell">
                                -₹ 2,10,000
                            </td>


                            <td class="amount-cell net-payable-amount">
                                ₹ 46,62,000
                            </td>


                            <td class="status-cell">

                                <select class="status-pill status-payment contractor-status-select"
                                        data-current="Passed for Payment">
                                    <option value="Passed for Payment" selected>Passed for Payment</option>
                                    <option value="Under Verification">Under Verification</option>
                                    <option value="Paid">Paid</option>
                                </select>

                            </td>


                            <td class="action-cell">

                                <div class="action-buttons">

                                    <button type="button"
                                            class="action-btn action-view"
                                            title="View">

                                        <i class="mdi mdi-eye-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-edit"
                                            title="Edit">

                                        <i class="mdi mdi-pencil-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-delete"
                                            title="Delete">

                                        <i class="mdi mdi-trash-can-outline"></i>

                                    </button>

                                </div>

                            </td>

                        </tr>


                        {{-- =================================================
                            ROW 2
                        ================================================== --}}
                        <tr>

                            <td>

                                <div class="bill-no">
                                    RA-CON-15
                                </div>

                                <div class="bill-date">
                                    2026-07-21
                                </div>

                                <div class="period-text mt-1">
                                    2026-Jul
                                </div>

                            </td>


                            <td>

                                <div class="contractor-name">
                                    Star Bar-Bending Works
                                </div>

                                <div class="project-name">
                                    Metro Line Extension - Phase 3
                                </div>

                            </td>


                            <td>

                                <span class="work-order-text">
                                    SCWO/STAR/042
                                </span>

                            </td>


                            <td class="amount-cell">
                                ₹ 21,00,000
                            </td>


                            <td class="amount-cell gst-amount">
                                ₹ 3,78,000
                            </td>


                            <td class="amount-cell deduction-amount-cell">
                                -₹ 42,000
                            </td>


                            <td class="amount-cell deduction-amount-cell">
                                -₹ 1,05,000
                            </td>


                            <td class="amount-cell net-payable-amount">
                                ₹ 23,31,000
                            </td>


                            <td class="status-cell">

                                <select class="status-pill status-verification contractor-status-select"
                                        data-current="Under Verification">
                                    <option value="Passed for Payment">Passed for Payment</option>
                                    <option value="Under Verification" selected>Under Verification</option>
                                    <option value="Paid">Paid</option>
                                </select>

                            </td>


                            <td class="action-cell">

                                <div class="action-buttons">

                                    <button type="button"
                                            class="action-btn action-view"
                                            title="View">

                                        <i class="mdi mdi-eye-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-edit"
                                            title="Edit">

                                        <i class="mdi mdi-pencil-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-delete"
                                            title="Delete">

                                        <i class="mdi mdi-trash-can-outline"></i>

                                    </button>

                                </div>

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

    <div class="modal fade"
         id="viewContractorRaModal"
         tabindex="-1"
         aria-labelledby="viewContractorRaModalLabel"
         aria-hidden="true">

        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">

            <div class="modal-content view-ra-modal-content">

                {{-- Header --}}
                <div class="modal-header view-ra-header bg-primary">

                    <div class="d-flex flex-column gap-2">

    <span class="badge rounded-pill badge-outline-secondary
                 text-primary small bg-primary-subtle align-self-start"
          id="viewContractorBillNo">

        RA-CON-14

    </span>


    <div class="view-ra-client text-white"
         id="viewContractorName"
         style="font-size:16px;">

        Apex Structural Sub-Contractors

    </div>


    <div class="view-ra-project text-white"
         id="viewContractorProject">

        Metro Line Extension - Phase 3

    </div>

</div>


                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                    </button>

                </div>


                {{-- Body --}}
                <div class="modal-body view-ra-body">


                    {{-- Financial Summary --}}
                    <div class="view-single-card mb-2">

                        <div class="view-financial-grid">

                            <div class="view-financial-item">

                                <span class="view-financial-label"
                                      style="font-size:13px;">
                                    Gross Work Done
                                </span>

                                <strong id="viewContractorGross">
                                    ₹ 42,00,000
                                </strong>

                            </div>


                            <div class="view-financial-item">

                                <span class="view-financial-label"
                                      style="font-size:13px;">
                                    GST
                                </span>

                                <strong id="viewContractorGst"
                                        class="text-success">
                                    ₹ 7,56,000
                                </strong>

                            </div>


                            <div class="view-financial-item">

                                <span class="view-financial-label"
                                      style="font-size:13px;">
                                    TDS
                                </span>

                                <strong id="viewContractorTds"
                                        class="text-danger">
                                    -₹ 84,000
                                </strong>

                            </div>


                            <div class="view-financial-item">

                                <span class="view-financial-label"
                                      style="font-size:13px;">
                                    Net Payable
                                </span>

                                <strong id="viewContractorNet"
                                        class="text-primary">
                                    ₹ 46,62,000
                                </strong>

                            </div>

                        </div>

                    </div>


                    {{-- Calculation Breakdown --}}
                    <div class="view-single-card mb-2">

                        <div class="view-card-heading text-black"
                             style="font-size:13px;">

                            Calculation Breakdown

                        </div>


                        <div class="view-breakdown-list">

                            <div class="view-breakdown-row">

                                <span style="font-size:13px;">
                                    Gross Work Done:
                                </span>

                                <strong id="viewBreakdownGross"
                                        style="font-size:13px;">

                                    ₹ 42,00,000

                                </strong>

                            </div>


                            <div class="view-breakdown-row">

                                <span style="font-size:13px;">
                                    (+) GST (18% - CGST/SGST):
                                </span>

                                <strong id="viewBreakdownGst"
                                        class="text-success"
                                        style="font-size:13px;">

                                    + ₹ 7,56,000

                                </strong>

                            </div>


                            <div class="view-breakdown-row deduction">

                                <span style="font-size:13px;">
                                    (-) Statutory TDS (2%):
                                </span>

                                <strong id="viewBreakdownTds"
                                        style="font-size:13px;">

                                    - ₹ 84,000

                                </strong>

                            </div>


                            <div class="view-breakdown-row deduction">

                                <span style="font-size:13px;">
                                    (-) Security Deposit / Retention (5%):
                                </span>

                                <strong id="viewBreakdownSd"
                                        style="font-size:13px;">

                                    - ₹ 2,10,000

                                </strong>

                            </div>

                        </div>


                        {{-- Net Payable inside same card --}}
                        <div class="view-breakdown-total text-black">

                            <span style="font-size:13px;">
                              Net Amount Payable to Contractor
                            </span>

                            <strong id="viewBreakdownNet"
                                    class="text-black"
                                    style="font-size:13px;">

                                ₹ 46,62,000

                            </strong>

                        </div>

                    </div>

                    <div class="view-single-card">




                        <div class="view-realization-list">

                            <div class="view-realization-row">

                                <span style="font-size:13px;">
                                    Remarks & Voucher Details
                                </span>
                            </div>


                            <div class="view-realization-row">

                                <span style="font-size:13px;">
                                  Piling & substructure measurement book #12 verified
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- Footer --}}
                <div class="modal-footer view-ra-footer">

                    <button type="button"
                            class="btn btn-primary btn-sm rounded-3 px-3"
                            id="printContractorVoucher">

                        <i class="mdi mdi-printer-outline me-1"></i>

                        Print Voucher

                    </button>


                    <button type="button"
                            class="btn btn-light border btn-sm rounded-3 px-3"
                            data-bs-dismiss="modal">

                        Close

                    </button>

                </div>

            </div>

        </div>

    </div>


</div>


<style>

.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}
.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}


#contractorRaSearch,
#contractorProjectFilter,
#contractorStatusFilter {
    height: 38px;
    font-size: 12px;
}

#contractorRaSearch {
    height: 34px !important;
    font-size: 11px !important;
}

#contractorRaSearch:focus,
#contractorProjectFilter:focus,
#contractorStatusFilter:focus {
    border-color: #0d6efd !important;
    box-shadow: 0 0 0 .15rem rgba(13, 110, 253, .08) !important;
}



#createContractorRaModal .modal-dialog {
    max-width: 850px;
}

#createContractorRaModal .modal-content {
    max-height: 90vh;
    overflow: hidden;
}

#createContractorRaModal .modal-body {
    overflow-y: auto;
}

#createContractorRaModal .form-label {
    color: #334155;
    font-size: 11px;
    font-weight: 700;
    margin-bottom: 4px;
}

#createContractorRaModal .form-control,
#createContractorRaModal .form-select {
    height: 34px;
    font-size: 11px;
    border-color: #dbe2ea;
    border-radius: 7px;
}

#createContractorRaModal textarea.form-control {
    height: auto;
    min-height: 55px;
    resize: vertical;
}

#createContractorRaModal .input-group-text {
    height: 34px;
    font-size: 11px;
    background: #f8fafc;
    border-color: #dbe2ea;
}

#createContractorRaModal .form-control:focus,
#createContractorRaModal .form-select:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 .12rem rgba(13, 110, 253, .08);
}

#createContractorRaModal .modal-footer .btn {
    height: 34px;
    font-size: 11px;
    font-weight: 600;
}

.ra-form-section-title {
    color: #16659E;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
    padding-bottom: 5px;
    border-bottom: 1px solid #e5eaf0;
}



.contractor-financial-summary {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 9px;
    padding: 9px 12px;
}

.contractor-summary-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    min-height: 27px;
    padding: 3px 0;
    color: #475569;
    font-size: 11px;
}

.contractor-summary-row strong {
    color: #111827;
    font-family: monospace;
    font-size: 12px;
    font-weight: 800;
    white-space: nowrap;
}

.contractor-summary-total {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-top: 5px;
    padding-top: 8px;
    border-top: 1px solid #dfe6ee;
    color: #334155;
    font-size: 12px;
    font-weight: 800;
}

.contractor-summary-total strong {
    color: #008f68;
    font-size: 14px;
    font-family: monospace;
    white-space: nowrap;
}




.contractor-ra-table-wrapper {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.contractor-ra-table {
    width: 100% !important;
    min-width: 1250px;
    margin: 0 !important;
    border-collapse: separate !important;
    border-spacing: 0 !important;
    table-layout: fixed !important;
}

.contractor-ra-table .col-bill {
    width: 10%;
}

.contractor-ra-table .col-contractor {
    width: 20%;
}

.contractor-ra-table .col-work-order {
    width: 11%;
}

.contractor-ra-table .col-amount {
    width: 9%;
}

.contractor-ra-table .col-status {
    width: 11%;
}

.contractor-ra-table .col-actions {
    width: 6%;
}

.contractor-ra-table thead tr {
    background: #f8fafc !important;
}

.contractor-ra-table thead th {
    height: 46px;
    padding: 12px 11px !important;
    background: #f8fafc !important;
    color: #294a78 !important;
    border: 0 !important;
    border-bottom: 1px solid #dce4ed !important;
    font-size: 11px !important;
    font-weight: 800 !important;
    line-height: 14px !important;
    white-space: nowrap !important;
    vertical-align: middle !important;
}

.contractor-ra-table tbody tr {
    background: #fff;
    transition: background-color .15s ease;
}

.contractor-ra-table tbody tr:hover {
    background: #fbfdff;
}

.contractor-ra-table tbody td {
    height: 72px;
    padding: 10px 11px !important;
    background: #fff !important;
    border: 0 !important;
    border-bottom: 1px solid #edf1f5 !important;
    color: #111827;
    font-size: 12px !important;
    line-height: 16px !important;
    vertical-align: middle !important;
}

.contractor-ra-table tbody tr:last-child td {
    border-bottom: 0 !important;
}



.bill-no {
    display: block;
    color: #173d72;
    font-size: 12px;
    font-weight: 800;
    line-height: 16px;
    white-space: nowrap;
}

.bill-date {
    display: block;
    margin-top: 3px;
    color: #8b98a9;
    font-size: 10px;
    font-weight: 500;
    line-height: 13px;
    white-space: nowrap;
}

.contractor-name {
    display: block;
    color: #111827;
    font-size: 12px;
    font-weight: 800;
    line-height: 16px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.project-name {
    display: block;
    margin-top: 3px;
    color: #64748b;
    font-size: 10px;
    font-weight: 600;
    line-height: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.work-order-text {
    display: inline-block;
    color: #334155;
    font-family: monospace;
    font-size: 10px;
    font-weight: 700;
    white-space: nowrap;
}

.period-text {
    display: inline-block;
    color: #111827;
    font-size: 10px;
    font-weight: 600;
    white-space: nowrap;
}

.amount-cell {
    text-align: right !important;
    color: #111827 !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    white-space: nowrap !important;
    font-variant-numeric: tabular-nums;
}

.gst-amount {
    color: #008f5a !important;
}

.deduction-amount-cell {
    color: #dc5a11 !important;
}

.net-payable-amount {
    color: #1565c0 !important;
    font-weight: 800 !important;
}


.status-cell {
    text-align: center !important;
    vertical-align: middle !important;
    white-space: nowrap !important;
}

.status-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 26px;
    padding: 5px 11px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 800;
    line-height: 13px;
    white-space: nowrap;
    border: 1px solid;
}

.status-payment {
    color: #008f68;
    background: #effff8;
    border-color: #8be1c1;
}

.status-verification {
    color: #d97706;
    background: #fffaf0;
    border-color: #f3cf67;
}

.status-paid {
    color: #2563eb;
    background: #eff6ff;
    border-color: #93c5fd;
}

/* ---------- Convert the status pill into a working dropdown, same look ---------- */
select.contractor-status-select {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-image: none;
    cursor: pointer;
    text-align: center;
    text-align-last: center;
    outline: none;
    width: 100%;
    max-width: 100%;
}

select.contractor-status-select:focus {
    box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
}

select.contractor-status-select option {
    color: #111827;
    background: #ffffff;
    font-weight: 600;
}



.action-cell {
    text-align: center !important;
    vertical-align: middle !important;
    white-space: nowrap !important;
}

.action-buttons {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 14px;
}

.action-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    margin: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    background: transparent;
    cursor: pointer;
    font-size: 20px;
    line-height: 1;
    transition: all .15s ease;
}

.action-view {
    color: #1565c0;
}

.action-view:hover {
    color: #0d47a1;
    transform: scale(1.12);
}

.action-edit {
    color: #2563eb;
}

.action-edit:hover {
    color: #1d4ed8;
    transform: scale(1.12);
}

.action-delete {
    color: #94a3b8;
}

.action-delete:hover {
    color: #dc2626;
    transform: scale(1.12);
}


#viewContractorRaModal .modal-dialog {
    max-width: 850px;
}

#viewContractorRaModal .view-ra-modal-content {
    max-height: 90vh;
    overflow: hidden;
    border: 0;
    border-radius: 16px;
    box-shadow: 0 15px 45px rgba(15, 23, 42, .18);
    background: #fff;
}

#viewContractorRaModal .view-ra-header {
    padding: 12px 16px;
    border-bottom: 1px solid #e5eaf0;
    background: #fff;
}

#viewContractorRaModal .view-ra-client {
    color: #111827;
    font-size: 11px;
    font-weight: 700;
    line-height: 15px;
}

#viewContractorRaModal .view-ra-project {
    color: #64748b;
    font-size: 10px;
    font-weight: 500;
    line-height: 14px;
}

#viewContractorRaModal .view-ra-body {
    padding: 12px 16px;
    overflow-y: auto;
    background: #f8fafc;
}



.view-single-card {
    width: 100%;
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 11px 13px;
    box-shadow: 0 1px 3px rgba(15, 23, 42, .03);
}

.view-financial-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 0;
}

.view-financial-item {
    padding: 2px 13px;
    border-right: 1px solid #e8edf3;
}

.view-financial-item:first-child {
    padding-left: 2px;
}

.view-financial-item:last-child {
    border-right: 0;
    padding-right: 2px;
}

.view-financial-label {
    display: block;
    color: #64748b;
    font-size: 9px;
    font-weight: 700;
    line-height: 13px;
    margin-bottom: 3px;
}

.view-financial-item strong {
    display: block;
    color: #0f172a;
    font-size: 13px;
    font-family: monospace;
    font-weight: 800;
    white-space: nowrap;
}


.view-card-heading {
    color: #294a78;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .035em;
    padding-bottom: 7px;
    margin-bottom: 2px;
    border-bottom: 1px solid #edf1f5;
}




.view-breakdown-list {
    width: 100%;
}

.view-breakdown-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    min-height: 25px;
    padding: 3px 0;
    color: #475569;
    font-size: 10px;
    line-height: 14px;
}

.view-breakdown-row span {
    font-weight: 500;
}

.view-breakdown-row strong {
    color: #111827;
    font-size: 10px;
    font-family: monospace;
    font-weight: 700;
    white-space: nowrap;
}

.view-breakdown-row.deduction strong {
    color: #dc5a11;
}

.view-breakdown-total {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin-top: 5px;
    padding-top: 8px;
    border-top: 1px solid #dfe6ee;
    color: #334155;
    font-size: 10px;
    font-weight: 800;
}

.view-breakdown-total strong {
    color: #008f68;
    font-size: 13px;
    font-family: monospace;
    white-space: nowrap;
}




.view-realization-list {
    width: 100%;
}

.view-realization-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    min-height: 27px;
    padding: 3px 0;
    color: #475569;
    font-size: 10px;
    line-height: 14px;
}

.view-realization-row span {
    font-weight: 500;
}

.view-realization-row strong {
    color: #111827;
    font-size: 10px;
    font-family: monospace;
    font-weight: 700;
    text-align: right;
}

.view-status-text {
    color: #d97706 !important;
    font-family: inherit !important;
}

.view-realization-row.outstanding {
    margin-top: 4px;
    padding-top: 8px;
    border-top: 1px solid #dfe6ee;
}

.view-realization-row.outstanding strong {
    color: #dc2626;
    font-size: 12px;
}




#viewContractorRaModal .view-ra-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 9px 16px;
    border-top: 1px solid #e5eaf0;
    background: #fff;
}

#viewContractorRaModal .view-ra-footer .btn {
    height: 34px;
    min-width: 90px;
    font-size: 11px;
    font-weight: 700;
}




@media (min-width:1200px) {

    .settings-tabs-scroller {
        max-width: 700px;
    }

}

@media (max-width:1199.98px) {

    .settings-tabs-scroller {
        max-width: 500px;
    }

    .contractor-ra-table {
        min-width: 1250px !important;
    }

}

@media (max-width:991.98px) {

    .settings-tabs-scroller {
        max-width: 100%;
    }

}

@media (max-width:767px) {

    .settings-tabs-scroller {
        max-width: 220px;
    }

    .settings-tab-pill {
        padding: .4rem .8rem;
        font-size: .78rem;
    }

    .settings-tab-scroll-btn {
        width: 28px;
        height: 28px;
    }

    #createContractorRaModal .modal-dialog,
    #viewContractorRaModal .modal-dialog {
        margin: 10px;
    }

    #createContractorRaModal .modal-content,
    #viewContractorRaModal .view-ra-modal-content {
        max-height: 95vh;
    }

    .view-financial-grid {
        grid-template-columns: repeat(2, 1fr);
        row-gap: 10px;
    }

    .view-financial-item {
        border-right: 0;
        padding: 2px 8px;
    }

    .view-financial-item:nth-child(odd) {
        border-right: 1px solid #e8edf3;
        padding-left: 2px;
    }

    .view-financial-item:nth-child(even) {
        padding-right: 2px;
    }

}

@media (max-width:575.98px) {

    .card-body {
        padding: 12px !important;
    }

    #viewContractorRaModal .view-ra-header {
        padding: 10px 12px;
    }

    #viewContractorRaModal .view-ra-body {
        padding: 10px 12px;
    }

    #viewContractorRaModal .view-ra-footer {
        padding: 8px 12px;
    }

    .view-financial-grid {
        grid-template-columns: 1fr 1fr;
    }

    .view-financial-item:nth-child(odd) {
        border-right: 1px solid #e8edf3;
    }

    .view-breakdown-row,
    .view-realization-row,
    .view-breakdown-total {
        align-items: flex-start;
    }

    .view-breakdown-row span,
    .view-realization-row span {
        max-width: 62%;
    }

}

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    /* ============================================================= */
    /* ---------- PERSIST CONTRACTOR RA ROWS IN localStorage ---------- */
    /* ============================================================= */
    const CONTRACTOR_RA_STORAGE_KEY = 'contractor_ra_rows_v1';

    function serializeContractorRow(row) {
        const cells = row.querySelectorAll('td');
        function txt(el)      { return el ? el.innerText.trim() : ''; }
        function cellText(i)  { return cells[i] ? cells[i].innerText.trim() : ''; }

        let status = '';
        const sel = cells[8] ? cells[8].querySelector('select.contractor-status-select') : null;
        if (sel) status = sel.value;

        return {
            billNo:     txt(row.querySelector('.bill-no')),
            billDate:   txt(row.querySelector('.bill-date')),
            month:      txt(row.querySelector('.period-text')),
            contractor: txt(row.querySelector('.contractor-name')),
            project:    txt(row.querySelector('.project-name')),
            workOrder:  txt(row.querySelector('.work-order-text')),
            gross:      cellText(3),
            gst:        cellText(4),
            tds:        cellText(5),
            sd:         cellText(6),
            net:        cellText(7),
            status:     status
        };
    }

    function saveContractorRows() {
        const table = document.querySelector('.contractor-ra-table');
        if (!table) return;
        const rows = table.querySelectorAll('tbody tr');
        const data = [];
        rows.forEach(function (row) { data.push(serializeContractorRow(row)); });
        localStorage.setItem(CONTRACTOR_RA_STORAGE_KEY, JSON.stringify(data));
    }

    function applySavedContractorRows() {
        const raw = localStorage.getItem(CONTRACTOR_RA_STORAGE_KEY);
        if (!raw) return;

        let data;
        try { data = JSON.parse(raw); } catch (e) { return; }
        if (!Array.isArray(data) || data.length === 0) return;

        const table = document.querySelector('.contractor-ra-table');
        if (!table) return;
        const tbody = table.querySelector('tbody');
        if (!tbody) return;

        const template = tbody.querySelector('tr');
        if (!template) return;
        const tpl = template.cloneNode(true);

        tbody.innerHTML = '';

        data.forEach(function (item) {
            const tr = tpl.cloneNode(true);
            const cells = tr.querySelectorAll('td');

            function setText(el, v) { if (el) el.innerText = v; }

            setText(tr.querySelector('.bill-no'),          item.billNo     || '');
            setText(tr.querySelector('.bill-date'),        item.billDate   || '');
            setText(tr.querySelector('.period-text'),      item.month      || '');
            setText(tr.querySelector('.contractor-name'),  item.contractor || '');
            setText(tr.querySelector('.project-name'),     item.project    || '');
            setText(tr.querySelector('.work-order-text'),  item.workOrder  || '');

            if (cells[3]) cells[3].innerText = item.gross || '₹ 0';
            if (cells[4]) cells[4].innerText = item.gst   || '₹ 0';
            if (cells[5]) cells[5].innerText = item.tds   || '-₹ 0';
            if (cells[6]) cells[6].innerText = item.sd    || '-₹ 0';
            if (cells[7]) cells[7].innerText = item.net   || '₹ 0';

            const statusSel = cells[8] ? cells[8].querySelector('select.contractor-status-select') : null;
            if (statusSel && item.status) {
                statusSel.value = item.status;
                statusSel.setAttribute('data-current', item.status);

                statusSel.classList.remove('status-payment', 'status-verification', 'status-paid');

                if (item.status === 'Passed for Payment') {
                    statusSel.classList.add('status-payment');
                } else if (item.status === 'Under Verification') {
                    statusSel.classList.add('status-verification');
                } else if (item.status === 'Paid') {
                    statusSel.classList.add('status-paid');
                }
            }

            tbody.appendChild(tr);
        });
    }

    /* Restore saved rows FIRST, before handlers bind */
    applySavedContractorRows();


    const tabsTrack =
        document.getElementById('qsTabsTrack');

    const leftButton =
        document.getElementById('qsTabScrollLeft');

    const rightButton =
        document.getElementById('qsTabScrollRight');


    if (tabsTrack) {

        if (leftButton) {

            leftButton.addEventListener('click', function () {

                tabsTrack.scrollBy({
                    left: -220,
                    behavior: 'smooth'
                });

            });

        }


        if (rightButton) {

            rightButton.addEventListener('click', function () {

                tabsTrack.scrollBy({
                    left: 220,
                    behavior: 'smooth'
                });

            });

        }

    }




    const searchInput =
        document.getElementById('contractorRaSearch');

    const projectFilter =
        document.getElementById('contractorProjectFilter');

    const statusFilter =
        document.getElementById('contractorStatusFilter');

    const table =
        document.querySelector('.contractor-ra-table');


    if (table) {

        const rows =
            table.querySelectorAll('tbody tr');


        function filterTable() {

            const searchValue =
                searchInput
                    ? searchInput.value.toLowerCase().trim()
                    : '';


            const projectValue =
                projectFilter
                    ? projectFilter.value.toLowerCase().trim()
                    : '';


            const statusValue =
                statusFilter
                    ? statusFilter.value.toLowerCase().trim()
                    : '';


            rows.forEach(function (row) {

                const cells =
                    row.querySelectorAll('td');


                const billData =
                    cells[0]
                        ? cells[0].innerText.toLowerCase()
                        : '';


                const contractorProjectData =
                    cells[1]
                        ? cells[1].innerText.toLowerCase()
                        : '';


                const workOrderData =
                    cells[2]
                        ? cells[2].innerText.toLowerCase()
                        : '';


                /* ---- status read from the inline dropdown ---- */
                let statusData = '';
                if (cells[8]) {
                    const sel = cells[8].querySelector('select.contractor-status-select');
                    if (sel) {
                        statusData = (sel.value || '').toLowerCase().trim();
                    } else {
                        statusData = cells[8].innerText.toLowerCase().trim();
                    }
                }


                const searchableText =
                    billData +
                    ' ' +
                    contractorProjectData +
                    ' ' +
                    workOrderData;


                const matchesSearch =
                    searchValue === '' ||
                    searchableText.includes(searchValue);


                const matchesProject =
                    projectValue === '' ||
                    contractorProjectData.includes(projectValue);


                const matchesStatus =
                    statusValue === '' ||
                    statusData === statusValue;


                row.style.display =
                    matchesSearch &&
                    matchesProject &&
                    matchesStatus
                        ? ''
                        : 'none';

            });

        }


        if (searchInput) {

            searchInput.addEventListener(
                'input',
                filterTable
            );

        }


        if (projectFilter) {

            projectFilter.addEventListener(
                'change',
                filterTable
            );

        }


        if (statusFilter) {

            statusFilter.addEventListener(
                'change',
                filterTable
            );

        }


        filterTable();




        /* ---------- Inline Contractor Status Dropdown (keeps pill colour) ---------- */
        document.querySelectorAll('.contractor-status-select').forEach(function (sel) {
            if (sel.dataset.bound === '1') return;
            sel.dataset.bound = '1';

            const initial = sel.getAttribute('data-current') || sel.value;
            sel.setAttribute('data-current', initial);

            sel.addEventListener('change', function () {

                /* Remove old colour classes and apply the one matching the new value */
                sel.classList.remove('status-payment', 'status-verification', 'status-paid');

                if (sel.value === 'Passed for Payment') {
                    sel.classList.add('status-payment');
                } else if (sel.value === 'Under Verification') {
                    sel.classList.add('status-verification');
                } else if (sel.value === 'Paid') {
                    sel.classList.add('status-paid');
                }

                sel.setAttribute('data-current', sel.value);

                /* Persist the change */
                saveContractorRows();

                /* Keep the row's status filter in sync */
                if (typeof filterTable === 'function') {
                    filterTable();
                }
            });
        });




        document.querySelectorAll('.action-view')
            .forEach(function (button) {

                button.addEventListener(
                    'click',
                    function () {

                        const row =
                            this.closest('tr');


                        if (!row) {
                            return;
                        }


                        const cells =
                            row.querySelectorAll('td');


                        const billNo =
                            row.querySelector('.bill-no')
                               ?.innerText
                               .trim() || '-';


                        const billDate =
                            row.querySelector('.bill-date')
                               ?.innerText
                               .trim() || '-';


                        const month =
                            row.querySelector('.period-text')
                               ?.innerText
                               .trim() || '-';


                        const contractor =
                            row.querySelector('.contractor-name')
                               ?.innerText
                               .trim() || '-';


                        const project =
                            row.querySelector('.project-name')
                               ?.innerText
                               .trim() || '-';


                        const workOrder =
                            row.querySelector('.work-order-text')
                               ?.innerText
                               .trim() || '-';


                        const gross =
                            cells[3]
                                ? cells[3].innerText.trim()
                                : '₹ 0';


                        const gst =
                            cells[4]
                                ? cells[4].innerText.trim()
                                : '₹ 0';


                        const tds =
                            cells[5]
                                ? cells[5].innerText.trim()
                                : '-₹ 0';


                        const sd =
                            cells[6]
                                ? cells[6].innerText.trim()
                                : '-₹ 0';


                        const net =
                            cells[7]
                                ? cells[7].innerText.trim()
                                : '₹ 0';


                        /* ---- status read from the inline dropdown ---- */
                        let status = 'Under Verification';
                        if (cells[8]) {
                            const sel = cells[8].querySelector('select.contractor-status-select');
                            if (sel) {
                                status = sel.value || status;
                            } else {
                                status = cells[8].innerText.trim() || status;
                            }
                        }




                        function parseCurrency(value) {

                            if (!value) {
                                return 0;
                            }

                            return Number(
                                value
                                    .replace(/[₹,\s]/g, '')
                                    .replace(/-/g, '')
                            ) || 0;

                        }


                        function formatIndianCurrency(value) {

                            value =
                                Number(value) || 0;

                            return '₹ ' +
                                value.toLocaleString(
                                    'en-IN',
                                    {
                                        maximumFractionDigits: 0
                                    }
                                );

                        }


                        const grossNumber =
                            parseCurrency(gross);


                        const gstNumber =
                            parseCurrency(gst);


                        const tdsNumber =
                            parseCurrency(tds);


                        const sdNumber =
                            parseCurrency(sd);


                        const netNumber =
                            parseCurrency(net);




                        const billNoElement =
                            document.getElementById(
                                'viewContractorBillNo'
                            );


                        const contractorElement =
                            document.getElementById(
                                'viewContractorName'
                            );


                        const projectElement =
                            document.getElementById(
                                'viewContractorProject'
                            );


                        if (billNoElement) {

                            billNoElement.innerText =
                                billNo;

                        }


                        if (contractorElement) {

                            contractorElement.innerText =
                                contractor;

                        }


                        if (projectElement) {

                            projectElement.innerText =
                                project;

                        }


                        const viewGross =
                            document.getElementById(
                                'viewContractorGross'
                            );


                        const viewGst =
                            document.getElementById(
                                'viewContractorGst'
                            );


                        const viewTds =
                            document.getElementById(
                                'viewContractorTds'
                            );


                        const viewNet =
                            document.getElementById(
                                'viewContractorNet'
                            );


                        if (viewGross) {

                            viewGross.innerText =
                                gross;

                        }


                        if (viewGst) {

                            viewGst.innerText =
                                gst;

                        }


                        if (viewTds) {

                            viewTds.innerText =
                                tds;

                        }


                        if (viewNet) {

                            viewNet.innerText =
                                net;

                        }




                        const breakdownBillNo =
                            document.getElementById(
                                'viewBreakdownBillNo'
                            );


                        const breakdownDate =
                            document.getElementById(
                                'viewBreakdownDate'
                            );


                        const breakdownMonth =
                            document.getElementById(
                                'viewBreakdownMonth'
                            );


                        const breakdownWorkOrder =
                            document.getElementById(
                                'viewBreakdownWorkOrder'
                            );


                        if (breakdownBillNo) {

                            breakdownBillNo.innerText =
                                billNo;

                        }


                        if (breakdownDate) {

                            breakdownDate.innerText =
                                billDate;

                        }


                        if (breakdownMonth) {

                            breakdownMonth.innerText =
                                month;

                        }


                        if (breakdownWorkOrder) {

                            breakdownWorkOrder.innerText =
                                workOrder;

                        }




                        const breakdownGross =
                            document.getElementById(
                                'viewBreakdownGross'
                            );


                        const breakdownGst =
                            document.getElementById(
                                'viewBreakdownGst'
                            );


                        const breakdownTds =
                            document.getElementById(
                                'viewBreakdownTds'
                            );


                        const breakdownSd =
                            document.getElementById(
                                'viewBreakdownSd'
                            );


                        const breakdownNet =
                            document.getElementById(
                                'viewBreakdownNet'
                            );


                        if (breakdownGross) {

                            breakdownGross.innerText =
                                gross;

                        }


                        if (breakdownGst) {

                            breakdownGst.innerText =
                                '+ ' +
                                formatIndianCurrency(
                                    gstNumber
                                );

                        }


                        if (breakdownTds) {

                            breakdownTds.innerText =
                                '- ' +
                                formatIndianCurrency(
                                    tdsNumber
                                );

                        }


                        if (breakdownSd) {

                            breakdownSd.innerText =
                                '- ' +
                                formatIndianCurrency(
                                    sdNumber
                                );

                        }


                        if (breakdownNet) {

                            breakdownNet.innerText =
                                net;

                        }



                        const paymentStatus =
                            document.getElementById(
                                'viewPaymentStatus'
                            );


                        const apRef =
                            document.getElementById(
                                'viewApRef'
                            );


                        const itc =
                            document.getElementById(
                                'viewItc'
                            );


                        const outstanding =
                            document.getElementById(
                                'viewOutstanding'
                            );


                        if (paymentStatus) {

                            paymentStatus.innerText =
                                status;


                            paymentStatus.classList.remove(
                                'view-status-text'
                            );


                            if (
                                status.toLowerCase()
                                    .includes('verification')
                            ) {

                                paymentStatus.classList.add(
                                    'view-status-text'
                                );

                            }

                        }


                        if (apRef) {

                            apRef.innerText =
                                'AP-' +
                                billNo.replace(
                                    /[^A-Z0-9-]/gi,
                                    ''
                                );

                        }


                        if (itc) {

                            itc.innerText =
                                formatIndianCurrency(
                                    gstNumber
                                );

                        }


                        if (outstanding) {

                            outstanding.innerText =
                                formatIndianCurrency(
                                    netNumber
                                );

                        }



                        const modalElement =
                            document.getElementById(
                                'viewContractorRaModal'
                            );


                        if (modalElement) {

                            const viewModal =
                                bootstrap.Modal.getOrCreateInstance(
                                    modalElement
                                );


                            viewModal.show();

                        }

                    }
                );

            });




        document.querySelectorAll('.action-delete')
            .forEach(function (button) {

                button.addEventListener(
                    'click',
                    function () {

                        const row =
                            this.closest('tr');


                        if (!row) {
                            return;
                        }


                        const billNo =
                            row.querySelector('.bill-no')
                               ?.innerText
                               .trim() || 'this bill';


                        if (
                            confirm(
                                'Are you sure you want to delete ' +
                                billNo +
                                '?'
                            )
                        ) {

                            row.remove();

                            /* Persist the deletion */
                            saveContractorRows();

                        }

                    }
                );

            });




        /* ---------- Edit: reuse the Create Contractor RA Bill modal ---------- */
        document.querySelectorAll('.action-edit')
            .forEach(function (button) {

                button.addEventListener(
                    'click',
                    function () {

                        const row =
                            this.closest('tr');

                        if (!row) return;

                        const cells =
                            row.querySelectorAll('td');

                        const billNo =
                            row.querySelector('.bill-no')
                               ?.innerText
                               .trim() || '';

                        const billDate =
                            row.querySelector('.bill-date')
                               ?.innerText
                               .trim() || '';

                        const month =
                            row.querySelector('.period-text')
                               ?.innerText
                               .trim() || '';

                        const contractor =
                            row.querySelector('.contractor-name')
                               ?.innerText
                               .trim() || '';

                        const project =
                            row.querySelector('.project-name')
                               ?.innerText
                               .trim() || '';

                        const workOrder =
                            row.querySelector('.work-order-text')
                               ?.innerText
                               .trim() || '';

                        const gross =
                            cells[3]
                                ? cells[3].innerText.trim()
                                : '';

                        const gst =
                            cells[4]
                                ? cells[4].innerText.trim()
                                : '';

                        function parseCurrency(value) {
                            return Number(
                                String(value || '')
                                    .replace(/[₹,\s]/g, '')
                                    .replace(/-/g, '')
                            ) || 0;
                        }

                        const grossNum =
                            parseCurrency(gross);

                        const gstNum =
                            parseCurrency(gst);

                        const gstRate =
                            grossNum > 0
                                ? Math.round((gstNum / grossNum) * 100)
                                : 18;

                        const tdsNum =
                            parseCurrency(
                                cells[5]?.innerText.trim() || '0'
                            );

                        const sdNum =
                            parseCurrency(
                                cells[6]?.innerText.trim() || '0'
                            );

                        const tdsRate =
                            grossNum > 0
                                ? Math.round((tdsNum / grossNum) * 100)
                                : 0;

                        const sdRate =
                            grossNum > 0
                                ? Math.round((sdNum / grossNum) * 100)
                                : 0;


                        /* Change modal title */
                        const modalTitle =
                            document.getElementById(
                                'createContractorRaModalLabel'
                            );

                        if (modalTitle) {

                            modalTitle.innerText =
                                'UPDATE CONTRACTOR RA BILL';

                        }


                        /* Change submit button label */
                        const submitBtn =
                            document.getElementById(
                                'createContractorRaBill'
                            );

                        if (submitBtn) {

                            submitBtn.innerHTML =
                                '<i class="mdi mdi-content-save-outline me-1"></i> Update Contractor RA Bill';

                        }


                        /* Fill month */
                        const monthSel =
                            document.getElementById('contractorMonth');

                        if (monthSel) {

                            Array.from(monthSel.options)
                                .forEach(function (opt) {
                                    if (opt.value === month) {
                                        monthSel.value = opt.value;
                                    }
                                });

                        }


                        /* Fill project */
                        const projectSel =
                            document.getElementById('contractorProject');

                        if (projectSel) {

                            Array.from(projectSel.options)
                                .forEach(function (opt) {
                                    if (opt.value === project) {
                                        projectSel.value = opt.value;
                                    }
                                });

                        }


                        /* Fill contractor */
                        const contractorSel =
                            document.getElementById('contractorName');

                        if (contractorSel) {

                            Array.from(contractorSel.options)
                                .forEach(function (opt) {
                                    if (opt.value === contractor) {
                                        contractorSel.value = opt.value;
                                    }
                                });

                        }


                        /* Fill work order */
                        const woSel =
                            document.getElementById('contractorWorkOrder');

                        if (woSel) {

                            Array.from(woSel.options)
                                .forEach(function (opt) {
                                    if (opt.value === workOrder) {
                                        woSel.value = opt.value;
                                    }
                                });

                        }


                        /* Fill RA bill no */
                        const raNoInput =
                            document.getElementById('contractorRaBillNo');

                        if (raNoInput) {
                            raNoInput.value = billNo;
                        }


                        /* Fill bill date */
                        const billDateInput =
                            document.getElementById('contractorBillDate');

                        if (billDateInput) {
                            billDateInput.value = billDate;
                        }


                        /* Fill gross */
                        const grossInput =
                            document.getElementById('contractorGrossAmount');

                        if (grossInput) {
                            grossInput.value = grossNum;
                        }


                        /* Fill GST % */
                        const gstPercentInput =
                            document.getElementById('gstPercent');

                        if (gstPercentInput) {
                            gstPercentInput.value = gstRate;
                        }


                        /* Fill TDS % */
                        const tdsPercentInput =
                            document.getElementById('contractorTdsPercent');

                        if (tdsPercentInput) {
                            tdsPercentInput.value = tdsRate;
                        }


                        /* Fill SD % */
                        const sdPercentInput =
                            document.getElementById('sdPercent');

                        if (sdPercentInput) {
                            sdPercentInput.value = sdRate;
                        }


                        /* Recompute the financial summary */
                        if (typeof calculateContractorRaBill === 'function') {
                            calculateContractorRaBill();
                        }


                        /* Remember which row is being edited */
                        window.__editingContractorRow = row;


                        /* Open the modal */
                        const modalEl =
                            document.getElementById('createContractorRaModal');

                        if (modalEl) {

                            bootstrap.Modal
                                .getOrCreateInstance(modalEl)
                                .show();

                        }

                    }
                );

            });

    }




    const grossInput =
        document.getElementById(
            'contractorGrossAmount'
        );


    const gstPercentInput =
        document.getElementById(
            'gstPercent'
        );


    const tdsPercentInput =
        document.getElementById(
            'contractorTdsPercent'
        );


    const sdPercentInput =
        document.getElementById(
            'sdPercent'
        );


    const summaryGross =
        document.getElementById(
            'summaryGross'
        );


    const summaryGst =
        document.getElementById(
            'summaryGst'
        );


    const summaryTds =
        document.getElementById(
            'summaryTds'
        );


    const summarySd =
        document.getElementById(
            'summarySd'
        );


    const summaryNet =
        document.getElementById(
            'summaryNet'
        );


    const summaryGstRate =
        document.getElementById(
            'summaryGstRate'
        );


    const summaryTdsRate =
        document.getElementById(
            'summaryTdsRate'
        );


    const summarySdRate =
        document.getElementById(
            'summarySdRate'
        );


    function formatIndianCurrency(value) {

        value =
            Number(value) || 0;

        return '₹ ' +
            value.toLocaleString(
                'en-IN',
                {
                    maximumFractionDigits: 0
                }
            );

    }


    function calculateContractorRaBill() {

        const gross =
            parseFloat(
                grossInput?.value
            ) || 0;


        const gstRate =
            parseFloat(
                gstPercentInput?.value
            ) || 0;


        const tdsRate =
            parseFloat(
                tdsPercentInput?.value
            ) || 0;


        const sdRate =
            parseFloat(
                sdPercentInput?.value
            ) || 0;


        const gst =
            gross *
            gstRate /
            100;


        const tds =
            gross *
            tdsRate /
            100;


        const sd =
            gross *
            sdRate /
            100;




        const net =
            gross +
            gst -
            tds -
            sd;


        if (summaryGross) {

            summaryGross.innerText =
                formatIndianCurrency(
                    gross
                );

        }


        if (summaryGst) {

            summaryGst.innerText =
                '+ ' +
                formatIndianCurrency(
                    gst
                );

        }


        if (summaryTds) {

            summaryTds.innerText =
                '- ' +
                formatIndianCurrency(
                    tds
                );

        }


        if (summarySd) {

            summarySd.innerText =
                '- ' +
                formatIndianCurrency(
                    sd
                );

        }


        if (summaryNet) {

            summaryNet.innerText =
                formatIndianCurrency(
                    net
                );

        }


        if (summaryGstRate) {

            summaryGstRate.innerText =
                gstRate;

        }


        if (summaryTdsRate) {

            summaryTdsRate.innerText =
                tdsRate;

        }


        if (summarySdRate) {

            summarySdRate.innerText =
                sdRate;

        }

    }


    if (grossInput) {

        grossInput.addEventListener(
            'input',
            calculateContractorRaBill
        );

    }


    if (gstPercentInput) {

        gstPercentInput.addEventListener(
            'input',
            calculateContractorRaBill
        );

    }


    if (tdsPercentInput) {

        tdsPercentInput.addEventListener(
            'input',
            calculateContractorRaBill
        );

    }


    if (sdPercentInput) {

        sdPercentInput.addEventListener(
            'input',
            calculateContractorRaBill
        );

    }


    /* Initial calculation */
    calculateContractorRaBill();




    const createButton =
        document.getElementById(
            'createContractorRaBill'
        );


    if (createButton) {

        createButton.addEventListener(
            'click',
            function () {

                const project =
                    document.getElementById(
                        'contractorProject'
                    );


                const contractor =
                    document.getElementById(
                        'contractorName'
                    );


                const workOrder =
                    document.getElementById(
                        'contractorWorkOrder'
                    );


                const billNo =
                    document.getElementById(
                        'contractorRaBillNo'
                    );


                const billDate =
                    document.getElementById(
                        'contractorBillDate'
                    );


                const gross =
                    document.getElementById(
                        'contractorGrossAmount'
                    );


                if (
                    !project ||
                    project.value === ''
                ) {

                    alert(
                        'Please select a Project.'
                    );

                    project.focus();

                    return;

                }


                if (
                    !contractor ||
                    contractor.value === ''
                ) {

                    alert(
                        'Please select a Contractor.'
                    );

                    contractor.focus();

                    return;

                }


                if (
                    !workOrder ||
                    workOrder.value === ''
                ) {

                    alert(
                        'Please select a Contractor Work Order.'
                    );

                    workOrder.focus();

                    return;

                }


                if (
                    !billNo ||
                    billNo.value.trim() === ''
                ) {

                    alert(
                        'Please enter Contractor RA Bill No.'
                    );

                    billNo.focus();

                    return;

                }


                if (
                    !billDate ||
                    billDate.value === ''
                ) {

                    alert(
                        'Please select Bill Date.'
                    );

                    billDate.focus();

                    return;

                }


                if (
                    !gross ||
                    parseFloat(gross.value) <= 0
                ) {

                    alert(
                        'Please enter a valid Gross Claim Amount.'
                    );

                    gross.focus();

                    return;

                }


                const editingRow =
                    window.__editingContractorRow;


                /* -------- UPDATE existing row -------- */
                if (editingRow) {

                    const cells =
                        editingRow.querySelectorAll('td');


                    const newGross =
                        parseFloat(gross.value) || 0;


                    const gstRate =
                        parseFloat(
                            document.getElementById('gstPercent')?.value
                        ) || 0;


                    const tdsRate =
                        parseFloat(
                            document.getElementById('contractorTdsPercent')?.value
                        ) || 0;


                    const sdRate =
                        parseFloat(
                            document.getElementById('sdPercent')?.value
                        ) || 0;


                    const newGst =
                        newGross * gstRate / 100;


                    const newTds =
                        newGross * tdsRate / 100;


                    const newSd =
                        newGross * sdRate / 100;


                    const newNet =
                        newGross + newGst - newTds - newSd;


                    function fmt(v) {

                        return '₹ ' +
                            Number(v || 0).toLocaleString(
                                'en-IN',
                                {
                                    maximumFractionDigits: 0
                                }
                            );

                    }


                    /* Bill no */
                    const billEl =
                        editingRow.querySelector('.bill-no');

                    if (billEl) {
                        billEl.innerText = billNo.value;
                    }


                    /* Bill date */
                    const dateEl =
                        editingRow.querySelector('.bill-date');

                    if (dateEl) {
                        dateEl.innerText = billDate.value;
                    }


                    /* Month */
                    const monthEl =
                        editingRow.querySelector('.period-text');

                    if (monthEl) {
                        monthEl.innerText =
                            document.getElementById('contractorMonth')?.value || '';
                    }


                    /* Contractor */
                    const cName =
                        editingRow.querySelector('.contractor-name');

                    if (cName) {
                        cName.innerText = contractor.value;
                    }


                    /* Project */
                    const pName =
                        editingRow.querySelector('.project-name');

                    if (pName) {
                        pName.innerText = project.value;
                    }


                    /* Work order */
                    const woEl =
                        editingRow.querySelector('.work-order-text');

                    if (woEl) {
                        woEl.innerText = workOrder.value;
                    }


                    /* Amount cells */
                    if (cells[3]) {
                        cells[3].innerText = fmt(newGross);
                    }

                    if (cells[4]) {
                        cells[4].innerText = fmt(newGst);
                    }

                    if (cells[5]) {
                        cells[5].innerText = '-' + fmt(newTds);
                    }

                    if (cells[6]) {
                        cells[6].innerText = '-' + fmt(newSd);
                    }

                    if (cells[7]) {
                        cells[7].innerText = fmt(newNet);
                    }


                    /* Persist the change */
                    saveContractorRows();


                    /* Clear editing state */
                    window.__editingContractorRow = null;


                    /* Reset modal title + submit button for next "create" */
                    const modalTitle =
                        document.getElementById(
                            'createContractorRaModalLabel'
                        );

                    if (modalTitle) {
                        modalTitle.innerText = 'CREATE CONTRACTOR RA BILL';
                    }


                    if (createButton) {
                        createButton.innerHTML =
                            '<i class="mdi mdi-send-check-outline me-1"></i> Create Contractor RA Bill';
                    }


                    /* Close modal */
                    const modalEl =
                        document.getElementById(
                            'createContractorRaModal'
                        );

                    if (modalEl) {

                        bootstrap.Modal
                            .getOrCreateInstance(modalEl)
                            .hide();

                    }


                    /* Re-apply filters */
                    if (typeof filterTable === 'function') {
                        filterTable();
                    }


                    return;

                }


                /* -------- CREATE new bill (original behaviour) -------- */
                const net =
                    summaryNet
                        ? summaryNet.innerText
                        : '₹ 0';


                alert(
                    'Contractor RA Bill ' +
                    billNo.value +
                    ' is ready to be created.\n\n' +
                    'Net Payable: ' +
                    net
                );

            }
        );

    }




    /* ---------- Toolbar "Create Contractor RA Bill" — always in create mode ---------- */
    const createToolbarBtn =
        document.getElementById('createContractorRaToolbarBtn');

    if (createToolbarBtn) {

        createToolbarBtn.addEventListener(
            'click',
            function () {

                window.__editingContractorRow = null;

                const modalTitle =
                    document.getElementById(
                        'createContractorRaModalLabel'
                    );

                if (modalTitle) {
                    modalTitle.innerText = 'CREATE CONTRACTOR RA BILL';
                }

                const submitBtn =
                    document.getElementById(
                        'createContractorRaBill'
                    );

                if (submitBtn) {
                    submitBtn.innerHTML =
                        '<i class="mdi mdi-send-check-outline me-1"></i> Create Contractor RA Bill';
                }

            }
        );

    }




    const printVoucher =
        document.getElementById(
            'printContractorVoucher'
        );


    if (printVoucher) {

        printVoucher.addEventListener(
            'click',
            function () {

                window.print();

            }
        );

    }

});

</script>

@endsection