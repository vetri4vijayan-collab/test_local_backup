@extends('layouts.layoutMaster')

@section('title', 'Client RA Billing Register')

@section('content')

<div class="container-fluid py-3">

    <div class="card shadow-sm rounded-2 mb-4">

        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3">

                <div>

                    <h4 class="mb-1 fw-bold text-black fs-3">
                        Planning & Quantity Surveying (QS) Engine
                    </h4>

                    <p class="text-muted mb-0 fs-7">
                        Master Schedules, Work Orders, RA Billing & Material Verification
                    </p>

                </div>


                <div class="settings-tabs-wrapper">

                    <div class="d-flex align-items-center gap-2">

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollLeft">

                            <i class="mdi mdi-chevron-left"></i>

                        </button>

                        <div class="settings-tabs-scroller">

                            <div class="settings-tabs-track"
                                 id="qsTabsTrack">

                                <a href="{{ route('planning-qs.client') }}"
                                class="settings-tab-pill {{ request()->routeIs('planning-qs.client') ? 'active' : '' }}">
                                Client RA Bill
                                </a>

                       <a href="{{ route('planning-qs.financial.contractor') }}"
                        class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.contractor') ? 'active' : '' }}">
                             Contractor RA Bill
                             </a>
                                <a href="{{ route('planning-qs.financial.credit') }}"
                                  class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.credit') ? 'active' : '' }}">
                                    Credit/Debit Note
                                </a>

                                <a href="{{ route('planning-qs.financial.security') }}"
                                   class="settings-tab-pill {{ request()->routeIs('planning-qs.financial.security') ? 'active' : '' }}">
                                    Security Deployment Bill
                                </a>

                                <a href="#"
                                   class="settings-tab-pill">
                                    HO Financial Report
                                </a>

                            </div>

                        </div>

                        <button type="button"
                                class="settings-tab-scroll-btn"
                                id="qsTabScrollRight">

                            <i class="mdi mdi-chevron-right"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="row g-3 g-md-4 mb-4">

        <div class="col-12 col-sm-6 col-lg-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2">
                        Total Gross Billed
                    </span>

                    <span class="d-block fw-bold font-monospace fs-5"
                          style="color:black;">
                        ₹ 12,80,00,000
                    </span>

                    <span class="d-block fw-semibold font-monospace text-secondary small mt-1">
                        4 total RA bill claims generated
                    </span>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-lg-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2">
                        Total Certified Amount
                    </span>

                    <span class="d-block fw-bold font-monospace fs-5 text-success">
                        ₹ 12,37,00,000
                    </span>

                    <span class="d-block fw-semibold font-monospace text-secondary small mt-1">
                        Certified by client Resident Engineers
                    </span>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-lg-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2">
                        Total Retention Held (5%)
                    </span>

                    <span class="d-block fw-bold font-monospace fs-5 text-warning">
                        ₹ 61,85,000
                    </span>

                    <span class="d-block fw-semibold font-monospace text-secondary small mt-1">
                        Withheld until Defect Liability Period
                    </span>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-lg-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2">
                        Net Receivable Certified
                    </span>

                    <span class="d-block fw-bold font-monospace fs-5 text-primary">
                        ₹ 11,25,67,000
                    </span>

                    <span class="d-block fw-semibold font-monospace text-secondary small mt-1">
                        <i class="mdi mdi-sync me-1"></i>
                        Live synced with Accounts Receivable
                    </span>

                </div>

            </div>

        </div>

    </div>



    <div class="card border-0 shadow-sm rounded-4 bg-white mb-3">

        <div class="card-body p-3">

            <div class="row g-2 align-items-center">

                {{-- Search --}}
                <div class="col-12 col-lg-4">

                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0
                                     translate-middle-y ps-2 text-muted"
                              style="pointer-events:none;">

                            <i class="mdi mdi-magnify"></i>

                        </span>

                        <input
                            id="raSearch"
                            type="text"
                            placeholder="Search RA No, Client, Project, Date..."
                            class="form-control form-control-sm ps-4
                                   bg-light border-0 rounded-3"
                            style="height:34px;font-size:11px;"
                            autocomplete="off">

                    </div>

                </div>


                {{-- Project Filter --}}
                <div class="col-12 col-md-4 col-lg-3">

                    <select id="projectFilter"
                            class="form-select form-select-sm
                                   bg-light border-0 rounded-3">

                        <option value="">
                            All Projects
                        </option>

                        <option value="ELCOT IT Park">
                            ELCOT IT Park
                        </option>

                        <option value="East Coast Road Elevated Bridge">
                            East Coast Road Elevated Bridge
                        </option>

                        <option value="Chennai Metro Phase 2 - Corridor 4">
                            Chennai Metro Phase 2 - Corridor 4
                        </option>

                        <option value="Metro Line Extension - Phase 3">
                            Metro Line Extension - Phase 3
                        </option>

                    </select>

                </div>


                {{-- Status Filter --}}
                <div class="col-12 col-md-4 col-lg-3">

                    <select id="statusFilter"
                            class="form-select form-select-sm
                                   bg-light border-0 rounded-3">

                        <option value="">
                            All Statuses
                        </option>

                        <option value="received">
                            Received
                        </option>

                        <option value="partially received">
                            Partially Received
                        </option>

                        <option value="certified - pending payout">
                            Certified - Pending Payout
                        </option>

                        <option value="submitted">
                            Submitted
                        </option>

                        <option value="under verification">
                            Under verification
                        </option>

                        <option value="rejected">
                            Rejected
                        </option>

                    </select>

                </div>


                {{-- Generate Client RA Bill --}}
                <div class="col-12 col-md-4 col-lg-2">

                    <button type="button"
                            class="btn btn-primary btn-sm rounded-3
                                   d-inline-flex align-items-center
                                   justify-content-center
                                   px-3 w-100"
                            style="height:38px;white-space:nowrap;"
                            data-bs-toggle="modal"
                            data-bs-target="#generateClientRaModal"
                            id="generateClientRaBtn">

                        <i class="mdi mdi-plus me-1"></i>

                        <span>
                            Generate Client RA Bill
                        </span>

                    </button>

                </div>

            </div>

        </div>

    </div>


    <div class="modal fade"
         id="generateClientRaModal"
         tabindex="-1"
         aria-labelledby="generateClientRaModalLabel"
         aria-hidden="true">

        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">

            <div class="modal-content border-0 shadow-lg rounded-4">

           <div class="modal-header view-ra-header bg-primary">


                    <div>

                        <h5 class="modal-title fw-bold mb-1 text-white"
                            id="generateClientRaModalLabel">

                            Generate New Client RA Bill

                        </h5>

                        <p class="text-white mb-0"
                           style="font-size:11px;">

                            Post certified work measurement claims to Accounts Receivable

                        </p>

                    </div>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                    </button>

                </div>


                <div class="modal-body px-3 py-3">

                    <form id="clientRaBillForm">

                        <div class="row g-2">

                            <div class="col-12">

                                <div class="ra-form-section-title">
                                    Project & Billing Details
                                </div>

                            </div>


                            {{-- Project --}}
                            <div class="col-md-6">

                                <label class="form-label">
                                    Select Project Site
                                </label>

                                <select class="form-select"
                                        id="projectSite"
                                        name="project_site">

                                    <option value="">
                                        Select Project Site
                                    </option>

                                    <option value="MAA-MET-C4" selected>
                                        [MAA-MET-C4] Chennai Metro Phase 2 - Corridor 4
                                    </option>

                                    <option value="ELCOT-IT">
                                        [ELCOT-IT] ELCOT IT Park
                                    </option>

                                    <option value="ECR-BRIDGE">
                                        [ECR-BRIDGE] East Coast Road Elevated Bridge
                                    </option>

                                    <option value="METRO-P3">
                                        [METRO-P3] Metro Line Extension - Phase 3
                                    </option>

                                    <option value="CHN-FLY">
                                        [CHN-FLY] Chennai Outer Ring Road Flyover
                                    </option>

                                    <option value="MAD-MET">
                                        [MAD-MET] Madurai Metro Infrastructure Project
                                    </option>

                                    <option value="TRI-HWY">
                                        [TRI-HWY] Trichy Highway Development Project
                                    </option>

                                    <option value="CBE-RD">
                                        [CBE-RD] Coimbatore Road Development Project
                                    </option>

                                </select>

                            </div>


                            {{-- Client --}}
                            <div class="col-md-6">

                                <label class="form-label">
                                    Client Organization Name
                                </label>

                                <input type="text"
                                       class="form-control"
                                       name="client_name"
                                       value="Chennai Metro Rail Limited">

                            </div>


                            {{-- RA Number --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    RA Bill Number
                                </label>

                                <input type="text"
                                       class="form-control"
                                       name="ra_bill_number"
                                       value="RA Bill #08">

                            </div>


                            {{-- Billing Period --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    Billing Period
                                </label>

                                <select class="form-select"
                                        name="billing_period">

                                    <option value="July 2026" selected>
                                        July 2026
                                    </option>

                                    <option value="June 2026">
                                        June 2026
                                    </option>

                                    <option value="May 2026">
                                        May 2026
                                    </option>

                                    <option value="April 2026">
                                        April 2026
                                    </option>

                                    <option value="March 2026">
                                        March 2026
                                    </option>

                                </select>

                            </div>


                            {{-- Submission Date --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    Submission Date
                                </label>

                                <input type="date"
                                       class="form-control"
                                       name="submission_date"
                                       value="2026-09-09">

                            </div>


                            {{-- Billing Amounts --}}
                            <div class="col-12 mt-2">

                                <div class="ra-form-section-title">
                                    Billing Amounts
                                </div>

                            </div>


                            {{-- Gross --}}
                            <div class="col-md-6">

                                <label class="form-label">
                                    Gross Claimed Amount (₹)
                                </label>

                                <input type="number"
                                       class="form-control"
                                       id="grossClaimedAmount"
                                       name="gross_claimed_amount"
                                       value="15000000"
                                       min="0"
                                       step="0.01">

                            </div>


                            {{-- Certified --}}
                            <div class="col-md-6">

                                <div class="d-flex justify-content-between
                                            align-items-center">

                                    <label class="form-label mb-0">
                                        Certified Amount (₹)
                                    </label>

                                    <div class="form-check">

                                        <input class="form-check-input"
                                               type="checkbox"
                                               id="setEqualGross"
                                               checked>

                                        <label class="form-check-label"
                                               for="setEqualGross"
                                               style="font-size:10px;">

                                            Set equal to Gross

                                        </label>

                                    </div>

                                </div>

                                <input type="number"
                                       class="form-control mt-1"
                                       id="certifiedAmount"
                                       name="certified_amount"
                                       value="14500000"
                                       min="0"
                                       step="0.01">

                            </div>


                            {{-- Deductions --}}
                            <div class="col-12 mt-2">

                                <div class="ra-form-section-title">
                                    Contractual Statutory Deductions
                                </div>

                            </div>


                            {{-- Retention --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    Retention Deposit (%)
                                </label>

                                <div class="input-group">

                                    <input type="number"
                                           class="form-control"
                                           id="retentionPercent"
                                           value="5"
                                           min="0"
                                           step="0.01">

                                    <span class="input-group-text">
                                        %
                                    </span>

                                </div>

                                <div class="deduction-amount"
                                     id="retentionAmount">
                                    ₹ 7,25,000
                                </div>

                            </div>


                            {{-- TDS --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    TDS u/s 194C (%)
                                </label>

                                <div class="input-group">

                                    <input type="number"
                                           class="form-control"
                                           id="tdsPercent"
                                           value="2"
                                           min="0"
                                           step="0.01">

                                    <span class="input-group-text">
                                        %
                                    </span>

                                </div>

                                <div class="deduction-amount"
                                     id="tdsAmount">
                                    ₹ 2,90,000
                                </div>

                            </div>


                            {{-- GST TDS --}}
                            <div class="col-md-4">

                                <label class="form-label">
                                    GST TDS (%)
                                </label>

                                <div class="input-group">

                                    <input type="number"
                                           class="form-control"
                                           id="gstTdsPercent"
                                           value="2"
                                           min="0"
                                           step="0.01">

                                    <span class="input-group-text">
                                        %
                                    </span>

                                </div>

                                <div class="deduction-amount"
                                     id="gstTdsAmount">
                                    ₹ 2,90,000
                                </div>

                            </div>


                            {{-- Net Receivable --}}
                            <div class="col-12">

                                <div class="net-receivable-box">

                                    <span class="net-label">
                                        Net Receivable Certified:
                                    </span>

                                    <strong id="netReceivable">
                                        ₹ 1,31,95,000
                                    </strong>

                                </div>

                            </div>

                            {{-- Remarks --}}
                            <div class="col-md-12">

                                <label class="form-label">
                                    Remarks / Notes
                                </label>

                                <textarea class="form-control"
                                          name="remarks"
                                          rows="2">Certified site measurement claims</textarea>

                            </div>

                        </div>

                    </form>

                </div>


                <div class="modal-footer px-3 py-2 border-top">

                    <button type="button"
                            class="btn btn-light border rounded-3 px-3 btn-sm"
                            data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button"
                            class="btn btn-primary rounded-3 px-3 btn-sm"
                            id="postClientRaBill">

                        <i class="mdi mdi-send-check-outline me-1"></i>

                        Post to Accounts Receivable

                    </button>

                </div>

            </div>

        </div>

    </div>

    <div class="card border-0 shadow-sm rounded-4 bg-white mb-3">

        <div class="card-body p-0">

            <div class="ra-table-wrapper">

                <table class="table ra-table mb-0">

                    <colgroup>

                        <col class="col-bill">
                        <col class="col-client">
                        <col class="col-period">

                        <col class="col-amount">
                        <col class="col-amount">
                        <col class="col-amount">
                        <col class="col-amount">
                        <col class="col-amount">

                        <col class="col-status">
                        <col class="col-actions">

                    </colgroup>


                    <thead>

                        <tr>

                            <th class="text-start">
                                RA BILL NO & DATE
                            </th>

                            <th class="text-start">
                                CLIENT & PROJECT
                            </th>

                            <th class="text-start">
                                PERIOD
                            </th>

                            <th class="text-end">
                                GROSS CLAIM
                            </th>

                            <th class="text-end">
                                CERTIFIED AMT
                            </th>

                            <th class="text-end">
                                RETENTION (5%)
                            </th>

                            <th class="text-end">
                                NET RECEIVABLE
                            </th>

                            <th class="text-end">
                                REALIZED CASH
                            </th>

                            <th class="text-center">
                                STATUS
                            </th>

                            <th class="text-center">
                                ACTIONS
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        {{-- ROW 1 --}}
                        <tr>

                            <td>
                                <div class="bill-no">
                                    RA Bill #08
                                </div>

                                <div class="bill-date">
                                    2026-09-09
                                </div>
                            </td>

                            <td>
                                <div class="client-name">
                                    Chennai Metro Rail Limited
                                </div>

                                <div class="project-name">
                                    ELCOT IT Park
                                </div>
                            </td>

                            <td>
                                <span class="period-text">
                                    July 2026
                                </span>
                            </td>

                            <td class="amount-cell">
                                ₹ 1,50,00,000
                            </td>

                            <td class="amount-cell certified-amount">
                                ₹ 1,45,00,000
                            </td>

                            <td class="amount-cell retention-amount">
                                ₹ 7,25,000
                            </td>

                            <td class="amount-cell">
                                ₹ 1,31,95,000
                            </td>

                            <td class="amount-cell">
                                ₹ 0
                            </td>

                            <td class="status-cell">

                                <select class="form-select form-select-sm status-select"
                                        data-current="Certified - Pending Payout">
                                    <option value="Certified - Pending Payout" selected>Certified - Pending Payout</option>
                                    <option value="Received">Received</option>
                                    <option value="Partially Received">Partially Received</option>
                                    <option value="Submitted">Submitted</option>
                                    <option value="Under verification">Under verification</option>
                                    <option value="Rejected">Rejected</option>
                                </select>

                            </td>

                            <td class="action-cell">

                                <div class="action-buttons">

                                    <button type="button"
                                            class="action-btn action-view"
                                            title="View">

                                        <i class="mdi mdi-eye-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-edit"
                                            title="Edit">

                                        <i class="mdi mdi-pencil-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-delete"
                                            title="Delete">

                                        <i class="mdi mdi-trash-can-outline"></i>

                                    </button>

                                </div>

                            </td>

                        </tr>


                        {{-- ROW 2 --}}
                        <tr>

                            <td>
                                <div class="bill-no">
                                    RA Bill #07
                                </div>

                                <div class="bill-date">
                                    2026-08-15
                                </div>
                            </td>

                            <td>
                                <div class="client-name">
                                    Rail limited
                                </div>

                                <div class="project-name">
                                    East Coast Road Elevated Bridge
                                </div>
                            </td>

                            <td>
                                <span class="period-text">
                                    June 2026
                                </span>
                            </td>

                            <td class="amount-cell">
                                ₹ 1,50,00,000
                            </td>

                            <td class="amount-cell certified-amount">
                                ₹ 1,45,00,000
                            </td>

                            <td class="amount-cell retention-amount">
                                ₹ 7,25,000
                            </td>

                            <td class="amount-cell">
                                ₹ 1,31,95,000
                            </td>

                            <td class="amount-cell realized-amount">
                                ₹ 1,31,95,000
                            </td>

                            <td class="status-cell">

                                <select class="form-select form-select-sm status-select"
                                        data-current="Received">
                                    <option value="Certified - Pending Payout">Certified - Pending Payout</option>
                                    <option value="Received" selected>Received</option>
                                    <option value="Partially Received">Partially Received</option>
                                    <option value="Submitted">Submitted</option>
                                    <option value="Under verification">Under verification</option>
                                    <option value="Rejected">Rejected</option>
                                </select>

                            </td>

                            <td class="action-cell">

                                <div class="action-buttons">

                                    <button type="button"
                                            class="action-btn action-view"
                                            title="View">

                                        <i class="mdi mdi-eye-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-edit"
                                            title="Edit">

                                        <i class="mdi mdi-pencil-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-delete"
                                            title="Delete">

                                        <i class="mdi mdi-trash-can-outline"></i>

                                    </button>

                                </div>

                            </td>

                        </tr>


                        {{-- ROW 3 --}}
                        <tr>

                            <td>
                                <div class="bill-no">
                                    RA Bill #06
                                </div>

                                <div class="bill-date">
                                    2026-07-20
                                </div>
                            </td>

                            <td>
                                <div class="client-name">
                                    madurai private limited
                                </div>

                                <div class="project-name">
                                    East Coast Road Elevated Bridge
                                </div>
                            </td>

                            <td>
                                <span class="period-text">
                                    May 2026
                                </span>
                            </td>

                            <td class="amount-cell">
                                ₹ 1,50,00,000
                            </td>

                            <td class="amount-cell certified-amount">
                                ₹ 1,45,00,000
                            </td>

                            <td class="amount-cell retention-amount">
                                ₹ 7,25,000
                            </td>

                            <td class="amount-cell">
                                ₹ 1,31,95,000
                            </td>

                            <td class="amount-cell">
                                ₹ 0
                            </td>

                            <td class="status-cell">

                                <select class="form-select form-select-sm status-select"
                                        data-current="Certified - Pending Payout">
                                    <option value="Certified - Pending Payout" selected>Certified - Pending Payout</option>
                                    <option value="Received">Received</option>
                                    <option value="Partially Received">Partially Received</option>
                                    <option value="Submitted">Submitted</option>
                                    <option value="Under verification">Under verification</option>
                                    <option value="Rejected">Rejected</option>
                                </select>

                            </td>

                            <td class="action-cell">

                                <div class="action-buttons">

                                    <button type="button"
                                            class="action-btn action-view"
                                            title="View">

                                        <i class="mdi mdi-eye-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-edit"
                                            title="Edit">

                                        <i class="mdi mdi-pencil-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-delete"
                                            title="Delete">

                                        <i class="mdi mdi-trash-can-outline"></i>

                                    </button>

                                </div>

                            </td>

                        </tr>


                        {{-- ROW 4 --}}
                        <tr>

                            <td>
                                <div class="bill-no">
                                    RA Bill #05
                                </div>

                                <div class="bill-date">
                                    2026-06-10
                                </div>
                            </td>

                            <td>
                                <div class="client-name">
                                    Chennai Metro Rail Limited
                                </div>

                                <div class="project-name">
                                    Chennai Metro Phase 2 - Corridor 4
                                </div>
                            </td>

                            <td>
                                <span class="period-text">
                                    April 2026
                                </span>
                            </td>

                            <td class="amount-cell">
                                ₹ 1,50,00,000
                            </td>

                            <td class="amount-cell certified-amount">
                                ₹ 1,45,00,000
                            </td>

                            <td class="amount-cell retention-amount">
                                ₹ 7,25,000
                            </td>

                            <td class="amount-cell">
                                ₹ 1,31,95,000
                            </td>

                            <td class="amount-cell">
                                ₹ 0
                            </td>

                            <td class="status-cell">

                                <select class="form-select form-select-sm status-select"
                                        data-current="Certified - Pending Payout">
                                    <option value="Certified - Pending Payout" selected>Certified - Pending Payout</option>
                                    <option value="Received">Received</option>
                                    <option value="Partially Received">Partially Received</option>
                                    <option value="Submitted">Submitted</option>
                                    <option value="Under verification">Under verification</option>
                                    <option value="Rejected">Rejected</option>
                                </select>

                            </td>

                            <td class="action-cell">

                                <div class="action-buttons">

                                    <button type="button"
                                            class="action-btn action-view"
                                            title="View">

                                        <i class="mdi mdi-eye-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-edit"
                                            title="Edit">

                                        <i class="mdi mdi-pencil-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-delete"
                                            title="Delete">

                                        <i class="mdi mdi-trash-can-outline"></i>

                                    </button>

                                </div>

                            </td>

                        </tr>


                        {{-- ROW 5 --}}
                        <tr>

                            <td>
                                <div class="bill-no">
                                    RA Bill #04
                                </div>

                                <div class="bill-date">
                                    2026-07-05
                                </div>
                            </td>

                            <td>
                                <div class="client-name">
                                    Chennai Metro Rail Limited
                                </div>

                                <div class="project-name">
                                    Metro Line Extension - Phase 3
                                </div>
                            </td>

                            <td>
                                <span class="period-text">
                                    June 2026
                                </span>
                            </td>

                            <td class="amount-cell">
                                ₹ 4,20,00,000
                            </td>

                            <td class="amount-cell certified-amount">
                                ₹ 4,05,00,000
                            </td>

                            <td class="amount-cell retention-amount">
                                ₹ 20,25,000
                            </td>

                            <td class="amount-cell">
                                ₹ 3,68,55,000
                            </td>

                            <td class="amount-cell realized-amount">
                                ₹ 3,68,55,000
                            </td>

                            <td class="status-cell">

                                <select class="form-select form-select-sm status-select"
                                        data-current="Received">
                                    <option value="Certified - Pending Payout">Certified - Pending Payout</option>
                                    <option value="Received" selected>Received</option>
                                    <option value="Partially Received">Partially Received</option>
                                    <option value="Submitted">Submitted</option>
                                    <option value="Under verification">Under verification</option>
                                    <option value="Rejected">Rejected</option>
                                </select>

                            </td>

                            <td class="action-cell">

                                <div class="action-buttons">

                                    <button type="button"
                                            class="action-btn action-view"
                                            title="View">

                                        <i class="mdi mdi-eye-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-edit"
                                            title="Edit">

                                        <i class="mdi mdi-pencil-outline"></i>

                                    </button>

                                    <button type="button"
                                            class="action-btn action-delete"
                                            title="Delete">

                                        <i class="mdi mdi-trash-can-outline"></i>

                                    </button>

                                </div>

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>



<div class="modal fade"
     id="viewRaBillModal"
     tabindex="-1"
     aria-labelledby="viewRaBillModalLabel"
     aria-hidden="true">

    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">

        <div class="modal-content view-ra-modal-content">

            {{-- Header --}}
            <div class="modal-header view-ra-header bg-primary">

          <div class="d-flex flex-column gap-2">

    <span class="badge rounded-pill badge-outline-secondary text-primary small bg-primary-subtle align-self-start">
        RA Bill #08
    </span>

    <div class="view-ra-client text-white" style="font-size: 16px;">
        Chennai Metro Rail Limited
    </div>

    <div class="view-ra-project text-white">
        ELCOT IT Park
    </div>

</div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>

            </div>


            {{-- Body --}}
            <div class="modal-body view-ra-body">


                <div class="view-single-card mb-2">

                    <div class="view-financial-grid">

                        <div class="view-financial-item">

                            <span class="view-financial-label" style="font-size: 13px;">
                                Claimed Gross
                            </span>

                            <strong id="viewGross">
                                ₹ 1,50,00,000
                            </strong>

                        </div>


                        <div class="view-financial-item">

                            <span class="view-financial-label" style="font-size: 13px;">
                                Certified Amt
                            </span>

                            <strong id="viewCertified"
                                    class="text-success">
                                ₹ 1,45,00,000
                            </strong>

                        </div>


                        <div class="view-financial-item">

                            <span class="view-financial-label" style="font-size: 13px;">
                                Retention (5%)
                            </span>

                            <strong id="viewRetention"
                                    class="text-warning">
                                ₹ 7,25,000
                            </strong>

                        </div>


                        <div class="view-financial-item">

                            <span class="view-financial-label" style="font-size: 13px;">
                                Net Receivable
                            </span>

                            <strong id="viewNetReceivable"
                                    class="text-primary">
                                ₹ 1,31,95,000
                            </strong>

                        </div>

                    </div>

                </div>


<div class="view-single-card mb-2">

    <div class="view-card-heading text-black" style="font-size: 13px;">
        Calculation Breakdown
    </div>

    <div class="view-breakdown-list">

        <div class="view-breakdown-row">
            <span style="font-size: 13px;">
                Gross Billed Claim:
            </span>
            <strong id="viewBreakdownGross" style="font-size: 13px;">
                ₹ 1,50,00,000
            </strong>
        </div>

        <div class="view-breakdown-row">
            <span style="font-size: 13px;">
                Certified Amount:
            </span>
            <strong id="viewBreakdownCertified" style="font-size: 13px;">
                ₹ 1,45,00,000
            </strong>
        </div>

        <div class="view-breakdown-row deduction">
            <span style="font-size: 13px;">
                (-) Retention Money Deposit (5%):
            </span>
            <strong id="viewBreakdownRetention" style="font-size: 13px;">
                - ₹ 7,25,000
            </strong>
        </div>

        <div class="view-breakdown-row deduction">
            <span style="font-size: 13px;">
                (-) Statutory TDS u/s 194C:
            </span>
            <strong id="viewBreakdownTds" style="font-size: 13px;">
                - ₹ 2,90,000
            </strong>
        </div>

        <div class="view-breakdown-row deduction">
            <span style="font-size: 13px;">
                (-) Statutory GST TDS:
            </span>
            <strong id="viewBreakdownGst" style="font-size: 13px;">
                - ₹ 2,90,000
            </strong>
        </div>

    </div>

    <!-- Net Receivable inside the same card -->
    <div class="view-breakdown-total text-black">
        <span style="font-size: 13px;">
            Net Receivable Certified:
        </span>

        <strong class="text-black" id="viewBreakdownNet" style="font-size: 13px;">
            ₹ 1,31,95,000
        </strong>
    </div>

</div>



                <div class="view-single-card">

               <div class="view-card-heading text-black" style="font-size: 13px;">


                        Accounts Realization Status

                    </div>


                    <div class="view-realization-list">

                        <div class="view-realization-row">

                               <span style="font-size: 13px;">
                                Payment Status:
                            </span>

                      <strong class="text-black" id="viewPaymentStatus" style="font-size: 13px;">

                                Certified - Pending Payout
                            </strong>

                        </div>


                        <div class="view-realization-row">

                             <span style="font-size: 13px;">
                                Bank UTR Ref:
                            </span>

                            <strong id="viewUtr" style="font-size: 13px;">
                                -
                            </strong>

                        </div>


                        <div class="view-realization-row">

                             <span style="font-size: 13px;">
                                Realized Amount Received:
                            </span>

                            <strong id="viewRealized" style="font-size: 13px;">
                                ₹ 0
                            </strong>

                        </div>


                        <div class="view-realization-row outstanding">

                               <span style="font-size: 13px;">
                                Outstanding Balance:
                            </span>

                            <strong id="viewOutstanding" style="font-size: 13px;">
                                ₹ 1,31,95,000
                            </strong>

                        </div>

                    </div>

                </div>

            </div>



            <div class="modal-footer view-ra-footer">

                <button type="button"
                        class="btn btn-primary btn-sm rounded-3 px-3"
                        id="printRaVoucher">

                    <i class="mdi mdi-printer-outline me-1"></i>

                    Print Voucher

                </button>

                <button type="button"
                        class="btn btn-light border btn-sm rounded-3 px-3"
                        data-bs-dismiss="modal">

                    Close

                </button>

            </div>

        </div>

    </div>

</div>



<style>



.settings-tabs-wrapper {
    max-width: 100%;
}

.settings-tabs-scroller {
    overflow: hidden;
    max-width: 700px;
}

.settings-tabs-track {
    display: flex;
    gap: .5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.settings-tabs-track::-webkit-scrollbar {
    display: none;
}

.settings-tab-pill {
    white-space: nowrap;
    padding: .45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: .85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
    text-decoration: none;
}

.settings-tab-pill.active {
    background: #16659E;
    color: #fff;
}
.settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
}

.settings-tab-scroll-btn:hover {
    background: #f8f9fa;
    color: #16659E;
}




#raSearch,
#projectFilter,
#statusFilter {
    height: 38px;
    font-size: 12px;
}

#raSearch {
    height: 34px !important;
    font-size: 11px !important;
}

#raSearch:focus,
#projectFilter:focus,
#statusFilter:focus {
    border-color: #0d6efd !important;
    box-shadow: 0 0 0 .15rem rgba(13, 110, 253, .08) !important;
}



#generateClientRaModal .modal-dialog {
    max-width: 850px;
}

#generateClientRaModal .modal-content {
    max-height: 90vh;
    overflow: hidden;
}

#generateClientRaModal .modal-body {
    overflow-y: auto;
}

#generateClientRaModal .modal-title {
    color: #173d72;
    font-size: 16px;
}

#generateClientRaModal .form-label {
    color: #334155;
    font-size: 11px;
    font-weight: 700;
    margin-bottom: 4px;
}

#generateClientRaModal .form-control,
#generateClientRaModal .form-select {
    height: 34px;
    font-size: 11px;
    border-color: #dbe2ea;
    border-radius: 7px;
}

#generateClientRaModal textarea.form-control {
    height: auto;
    min-height: 55px;
    resize: vertical;
}

#generateClientRaModal .input-group-text {
    height: 34px;
    font-size: 11px;
    background: #f8fafc;
    border-color: #dbe2ea;
}

#generateClientRaModal .form-control:focus,
#generateClientRaModal .form-select:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 .12rem rgba(13, 110, 253, .08);
}

.ra-form-section-title {
    color: #16659E;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
    padding-bottom: 5px;
    border-bottom: 1px solid #e5eaf0;
}

.deduction-amount {
    margin-top: 4px;
    color: #ea580c;
    font-size: 11px;
    font-weight: 700;
}

.net-receivable-box {
    margin-top: 2px;
    padding: 9px 12px;
    border-radius: 8px;
    background: #eef8f4;
    border: 1px solid #cce9dc;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
}

.net-label {
    color: #334155;
    font-size: 11px;
    font-weight: 700;
}

.net-receivable-box strong {
    color: #008f68;
    font-size: 14px;
    font-family: monospace;
    white-space: nowrap;
}

#generateClientRaModal .modal-footer .btn {
    height: 34px;
    font-size: 11px;
    font-weight: 600;
}



.ra-table-wrapper {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.ra-table {
    width: 100% !important;
    min-width: 1300px;
    margin: 0 !important;
    border-collapse: separate !important;
    border-spacing: 0 !important;
    table-layout: fixed !important;
}

.ra-table .col-bill {
    width: 8%;
}

.ra-table .col-client {
    width: 15%;
}

.ra-table .col-period {
    width: 7.5%;
}

.ra-table .col-amount {
    width: 7.6%;
}

.ra-table .col-status {
    width: 19%;
}

.ra-table .col-actions {
    width: 8%;
}

.ra-table thead tr {
    background: #f8fafc !important;
}
.ra-table thead th {
    height: 46px;
    padding: 10px 8px !important;
    background: #f8fafc !important;
    color: #294a78 !important;
    border: 0 !important;
    border-bottom: 1px solid #dce4ed !important;
    font-size: 11px !important;
    font-weight: 800 !important;
    line-height: 14px !important;
    letter-spacing: 0 !important;
    white-space: nowrap !important;
    vertical-align: middle !important;
}

.ra-table thead th:last-child,
.ra-table tbody td:last-child {
    text-align: center !important;
    padding-left: 6px !important;
    padding-right: 6px !important;
}

.ra-table tbody tr {
    background: #fff;
    transition: background-color .15s ease;
}

.ra-table tbody tr:hover {
    background: #fbfdff;
}

.ra-table tbody td {
    height: 68px;
    padding: 10px 11px !important;
    background: #fff !important;
    border: 0 !important;
    border-bottom: 1px solid #edf1f5 !important;
    color: #111827;
    font-size: 12px !important;
    line-height: 16px !important;
    vertical-align: middle !important;
}

.ra-table tbody tr:last-child td {
    border-bottom: 0 !important;
}
.bill-no {
    display: block;
    color: #173d72;
    font-size: 12px;
    font-weight: 800;
    line-height: 16px;
    white-space: nowrap;
}

.bill-date {
    display: block;
    margin-top: 3px;
    color: #8b98a9;
    font-size: 10px;
    font-weight: 500;
    line-height: 13px;
    white-space: nowrap;
}
.client-name {
    display: block;
    color: #111827;
    font-size: 12px;
    font-weight: 800;
    line-height: 16px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.project-name {
    display: block;
    margin-top: 3px;
    color: #64748b;
    font-size: 10px;
    font-weight: 600;
    line-height: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}


.period-text {
    display: inline-block;
    color: #111827;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
}


.amount-cell {
    text-align: right !important;
    color: #111827 !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    white-space: nowrap !important;
    font-variant-numeric: tabular-nums;
}

.certified-amount {
    color: #008f5a !important;
}

.retention-amount {
    color: #ea580c !important;
}

.realized-amount {
    color: #009b63 !important;
}

.status-cell {
    text-align: center !important;
    vertical-align: middle !important;
    white-space: nowrap !important;
    padding-left: 4px !important;
    padding-right: 4px !important;
}

.status-cell .status-pill {
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* ---------- Inline Status Dropdown (full text fits) ---------- */
.status-select {
    width: 100%;
    min-width: 100%;
    max-width: 100%;
    height: 30px;
    font-size: 10px;
    font-weight: 800;
    text-align: center;
    text-align-last: center;
    padding: 2px 4px;
    border-radius: 999px;
    border: 1px solid #d0d5dd;
    background-color: #fff;
    color: #111827;
    cursor: pointer;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-image: none;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: clip;
}

.status-select:focus {
    outline: 0;
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
}

.status-select[data-current="Certified - Pending Payout"] {
    color: #d97706;
    background-color: #fffaf0;
    border-color: #f3cf67;
}

.status-select[data-current="Received"] {
    color: #008f68;
    background-color: #effff8;
    border-color: #8be1c1;
}

.status-select[data-current="Partially Received"] {
    color: #2563eb;
    background-color: #eff6ff;
    border-color: #93c5fd;
}

.status-select[data-current="Submitted"] {
    color: #1d4ed8;
    background-color: #eef2ff;
    border-color: #c7d2fe;
}

.status-select[data-current="Under verification"] {
    color: #7c3aed;
    background-color: #f5f3ff;
    border-color: #ddd6fe;
}

.status-select[data-current="Rejected"] {
    color: #dc2626;
    background-color: #fef2f2;
    border-color: #fca5a5;
}


.status-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 26px;
    padding: 5px 11px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 800;
    line-height: 13px;
    white-space: nowrap;
    border: 1px solid;
}


.status-pending {
    color: #d97706;
    background: #fffaf0;
    border-color: #f3cf67;
}

.status-received {
    color: #008f68;
    background: #effff8;
    border-color: #8be1c1;
}

.status-partial {
    color: #2563eb;
    background: #eff6ff;
    border-color: #93c5fd;
}

.action-cell {
    text-align: center !important;
    vertical-align: middle !important;
    white-space: nowrap !important;
    padding-left: 4px !important;
    padding-right: 4px !important;
}

.action-buttons {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.action-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    margin: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    background: transparent;
    cursor: pointer;
    font-size: 20px;
    line-height: 1;
    transition: all .15s ease;
}

.action-view {
    color: #1565c0;
}

.action-view:hover {
    color: #0d47a1;
    transform: scale(1.12);
}

.action-edit {
    color: #2563eb;
}

.action-edit:hover {
    color: #1d4ed8;
    transform: scale(1.12);
}

.action-delete {
    color: #94a3b8;
}

.action-delete:hover {
    color: #dc2626;
    transform: scale(1.12);
}




.accounts-integration-note {
    background: #eef4ff;
    border: 1px solid #dbe6fb;
    border-radius: 12px;
    padding: 12px 15px;
    color: #1f2937;
    font-size: 12px;
    line-height: 18px;
}

.accounts-integration-note strong {
    color: #1c2e63;
}

.note-dot {
    width: 8px;
    height: 8px;
    min-width: 8px;
    border-radius: 50%;
    background: #2563eb;
    margin-top: 5px;
}



#viewRaBillModal .modal-dialog {
    max-width: 850px;
}

#viewRaBillModal .view-ra-modal-content {
    max-height: 90vh;
    overflow: hidden;
    border: 0;
    border-radius: 16px;
    box-shadow: 0 15px 45px rgba(15, 23, 42, .18);
    background: #fff;
}

#viewRaBillModal .view-ra-header {
    padding: 12px 16px;
    border-bottom: 1px solid #e5eaf0;
    background: #fff;
}

#viewRaBillModal .view-ra-title {
    color: #173d72;
    font-size: 16px;
    font-weight: 800;
    line-height: 20px;
}

#viewRaBillModal .view-ra-client {
    color: #111827;
    font-size: 11px;
    font-weight: 700;
    line-height: 15px;
}

#viewRaBillModal .view-ra-project {
    color: #64748b;
    font-size: 10px;
    font-weight: 500;
    line-height: 14px;
}

#viewRaBillModal .view-ra-body {
    padding: 12px 16px;
    overflow-y: auto;
    background: #f8fafc;
}




.view-single-card {
    width: 100%;
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 11px 13px;
    box-shadow: 0 1px 3px rgba(15, 23, 42, .03);
}



.view-financial-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 0;
}

.view-financial-item {
    padding: 2px 13px;
    border-right: 1px solid #e8edf3;
}

.view-financial-item:first-child {
    padding-left: 2px;
}

.view-financial-item:last-child {
    border-right: 0;
    padding-right: 2px;
}

.view-financial-label {
    display: block;
    color: #64748b;
    font-size: 9px;
    font-weight: 700;
    line-height: 13px;
    margin-bottom: 3px;
}

.view-financial-item strong {
    display: block;
    color: #0f172a;
    font-size: 13px;
    font-family: monospace;
    font-weight: 800;
    white-space: nowrap;
}




.view-card-heading {
    color: #294a78;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .035em;
    padding-bottom: 7px;
    margin-bottom: 2px;
    border-bottom: 1px solid #edf1f5;
}



.view-breakdown-list {
    width: 100%;
}

.view-breakdown-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    min-height: 25px;
    padding: 3px 0;
    color: #475569;
    font-size: 10px;
    line-height: 14px;
}

.view-breakdown-row span {
    font-weight: 500;
}

.view-breakdown-row strong {
    color: #111827;
    font-size: 10px;
    font-family: monospace;
    font-weight: 700;
    white-space: nowrap;
}

.view-breakdown-row.deduction strong {
    color: #dc5a11;
}

.view-breakdown-total {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin-top: 5px;
    padding-top: 8px;
    border-top: 1px solid #dfe6ee;
    color: #334155;
    font-size: 10px;
    font-weight: 800;
}

.view-breakdown-total strong {
    color: #008f68;
    font-size: 13px;
    font-family: monospace;
    white-space: nowrap;
}



.view-realization-list {
    width: 100%;
}

.view-realization-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    min-height: 27px;
    padding: 3px 0;
    color: #475569;
    font-size: 10px;
    line-height: 14px;
}

.view-realization-row span {
    font-weight: 500;
}

.view-realization-row strong {
    color: #111827;
    font-size: 10px;
    font-family: monospace;
    font-weight: 700;
    text-align: right;
}

.view-status-text {
    color: #d97706 !important;
    font-family: inherit !important;
}

.view-realization-row.outstanding {
    margin-top: 4px;
    padding-top: 8px;
    border-top: 1px solid #dfe6ee;
}

.view-realization-row.outstanding strong {
    color: #dc2626;
    font-size: 12px;
}

#viewRaBillModal .view-ra-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 9px 16px;
    border-top: 1px solid #e5eaf0;
    background: #fff;
}

#viewRaBillModal .view-ra-footer .btn {
    height: 34px;
    min-width: 90px;
    font-size: 11px;
    font-weight: 700;
}



@media (min-width:1200px) {

    .settings-tabs-scroller {
        max-width: 700px;
    }

}

@media (max-width:1199.98px) {

    .settings-tabs-scroller {
        max-width: 500px;
    }

    .ra-table {
        min-width: 1300px !important;
    }

}

@media (max-width:991.98px) {

    .settings-tabs-scroller {
        max-width: 100%;
    }

}

@media (max-width:767px) {

    .settings-tabs-scroller {
        max-width: 220px;
    }

    .settings-tab-pill {
        padding: .4rem .8rem;
        font-size: .78rem;
    }

    .settings-tab-scroll-btn {
        width: 28px;
        height: 28px;
    }

    #generateClientRaModal .modal-dialog,
    #viewRaBillModal .modal-dialog {
        margin: 10px;
    }

    #generateClientRaModal .modal-content,
    #viewRaBillModal .view-ra-modal-content {
        max-height: 95vh;
    }

    .net-receivable-box {
        flex-direction: column;
        align-items: flex-start;
        gap: 4px;
    }

    .view-financial-grid {
        grid-template-columns: repeat(2, 1fr);
        row-gap: 10px;
    }

    .view-financial-item {
        border-right: 0;
        padding: 2px 8px;
    }

    .view-financial-item:nth-child(odd) {
        border-right: 1px solid #e8edf3;
        padding-left: 2px;
    }

    .view-financial-item:nth-child(even) {
        padding-right: 2px;
    }

}

@media (max-width:575.98px) {

    .card-body {
        padding: 12px !important;
    }

    .accounts-integration-note {
        font-size: 11px;
        line-height: 17px;
    }

    #viewRaBillModal .view-ra-header {
        padding: 10px 12px;
    }

    #viewRaBillModal .view-ra-body {
        padding: 10px 12px;
    }

    #viewRaBillModal .view-ra-footer {
        padding: 8px 12px;
    }

    .view-financial-grid {
        grid-template-columns: 1fr 1fr;
    }

    .view-financial-item:nth-child(odd) {
        border-right: 1px solid #e8edf3;
    }

    .view-breakdown-row,
    .view-realization-row,
    .view-breakdown-total {
        align-items: flex-start;
    }

    .view-breakdown-row span,
    .view-realization-row span {
        max-width: 62%;
    }

}

</style>



<script>

document.addEventListener('DOMContentLoaded', function () {



    const tabsTrack =
        document.getElementById('qsTabsTrack');

    const leftButton =
        document.getElementById('qsTabScrollLeft');

    const rightButton =
        document.getElementById('qsTabScrollRight');


    if (tabsTrack) {

        if (leftButton) {

            leftButton.addEventListener('click', function () {

                tabsTrack.scrollBy({
                    left: -220,
                    behavior: 'smooth'
                });

            });

        }


        if (rightButton) {

            rightButton.addEventListener('click', function () {

                tabsTrack.scrollBy({
                    left: 220,
                    behavior: 'smooth'
                });

            });

        }

    }



    const searchInput =
        document.getElementById('raSearch');

    const projectFilter =
        document.getElementById('projectFilter');

    const statusFilter =
        document.getElementById('statusFilter');

    const table =
        document.querySelector('.ra-table');




    if (table) {

        const rows =
            table.querySelectorAll('tbody tr');


        function filterTable() {

            const searchValue =
                searchInput
                    ? searchInput.value.toLowerCase().trim()
                    : '';


            const projectValue =
                projectFilter
                    ? projectFilter.value.toLowerCase().trim()
                    : '';


            const statusValue =
                statusFilter
                    ? statusFilter.value.toLowerCase().trim()
                    : '';


            rows.forEach(function (row) {

                const cells =
                    row.querySelectorAll('td');


                const billData =
                    cells[0]
                        ? cells[0].innerText.toLowerCase()
                        : '';


                const clientProjectData =
                    cells[1]
                        ? cells[1].innerText.toLowerCase()
                        : '';


                const periodData =
                    cells[2]
                        ? cells[2].innerText.toLowerCase()
                        : '';


                /* ---- status read from the inline dropdown ---- */
                let statusData = '';
                if (cells[8]) {
                    const sel = cells[8].querySelector('select.status-select');
                    if (sel) {
                        statusData = (sel.value || '').toLowerCase().trim();
                    } else {
                        statusData = cells[8].innerText.toLowerCase().trim();
                    }
                }


                const searchableText =
                    billData +
                    ' ' +
                    clientProjectData +
                    ' ' +
                    periodData;


                const matchesSearch =
                    searchValue === '' ||
                    searchableText.includes(searchValue);


                const matchesProject =
                    projectValue === '' ||
                    clientProjectData.includes(projectValue);


                const matchesStatus =
                    statusValue === '' ||
                    statusData === statusValue;


                row.style.display =
                    matchesSearch &&
                    matchesProject &&
                    matchesStatus
                        ? ''
                        : 'none';

            });

        }


        if (searchInput) {

            searchInput.addEventListener(
                'input',
                filterTable
            );

        }


        if (projectFilter) {

            projectFilter.addEventListener(
                'change',
                filterTable
            );

        }


        if (statusFilter) {

            statusFilter.addEventListener(
                'change',
                filterTable
            );

        }


        filterTable();




        /* ---------- Inline Status Dropdown ---------- */
        document.querySelectorAll('.status-select').forEach(function (sel) {
            if (sel.dataset.bound === '1') return;
            sel.dataset.bound = '1';

            const initial = sel.getAttribute('data-current') || sel.value;
            sel.setAttribute('data-current', initial);

            sel.addEventListener('change', function () {
                const newStatus = sel.value;
                sel.setAttribute('data-current', newStatus);

                if (typeof filterTable === 'function') {
                    filterTable();
                }
            });
        });




        document.querySelectorAll('.action-view')
            .forEach(function (button) {

                button.addEventListener(
                    'click',
                    function () {

                        const row =
                            this.closest('tr');

                        if (!row) {
                            return;
                        }


                        const cells =
                            row.querySelectorAll('td');




                        const billNo =
                            row.querySelector('.bill-no')
                               ?.innerText
                               .trim() || '-';


                        const billDate =
                            row.querySelector('.bill-date')
                               ?.innerText
                               .trim() || '-';


                        const client =
                            row.querySelector('.client-name')
                               ?.innerText
                               .trim() || '-';


                        const project =
                            row.querySelector('.project-name')
                               ?.innerText
                               .trim() || '-';


                        const gross =
                            cells[3]
                                ? cells[3].innerText.trim()
                                : '₹ 0';


                        const certified =
                            cells[4]
                                ? cells[4].innerText.trim()
                                : '₹ 0';


                        const retention =
                            cells[5]
                                ? cells[5].innerText.trim()
                                : '₹ 0';


                        const net =
                            cells[6]
                                ? cells[6].innerText.trim()
                                : '₹ 0';


                        const realized =
                            cells[7]
                                ? cells[7].innerText.trim()
                                : '₹ 0';


                        /* status reads from the dropdown */
                        let status = 'Certified - Pending Payout';
                        if (cells[8]) {
                            const sel = cells[8].querySelector('select.status-select');
                            if (sel) {
                                status = sel.value || status;
                            } else {
                                status = cells[8].innerText.trim() || status;
                            }
                        }




                        function parseCurrency(value) {

                            if (!value) {
                                return 0;
                            }

                            return Number(
                                value
                                    .replace(/[₹,\s]/g, '')
                                    .replace(/-/g, '')
                            ) || 0;

                        }


                        function formatIndianCurrency(value) {

                            value =
                                Number(value) || 0;

                            return '₹ ' +
                                value.toLocaleString(
                                    'en-IN',
                                    {
                                        maximumFractionDigits: 0
                                    }
                                );

                        }


                        const grossNumber =
                            parseCurrency(gross);


                        const certifiedNumber =
                            parseCurrency(certified);


                        const retentionNumber =
                            parseCurrency(retention);


                        const netNumber =
                            parseCurrency(net);


                        const realizedNumber =
                            parseCurrency(realized);



                        const tdsNumber =
                            certifiedNumber * 2 / 100;


                        const gstTdsNumber =
                            certifiedNumber * 2 / 100;




                        const outstandingNumber =
                            Math.max(
                                netNumber - realizedNumber,
                                0
                            );




                        const titleElement =
                            document.getElementById(
                                'viewRaBillModalLabel'
                            );


                        const clientElement =
                            document.querySelector(
                                '#viewRaBillModal .view-ra-client'
                            );


                        const projectElement =
                            document.querySelector(
                                '#viewRaBillModal .view-ra-project'
                            );


                        if (titleElement) {

                            titleElement.innerText =
                                billNo;

                        }


                        if (clientElement) {

                            clientElement.innerText =
                                client;

                        }


                        if (projectElement) {

                            projectElement.innerText =
                                project;

                        }




                        const viewGross =
                            document.getElementById('viewGross');

                        const viewCertified =
                            document.getElementById('viewCertified');

                        const viewRetention =
                            document.getElementById('viewRetention');

                        const viewNetReceivable =
                            document.getElementById(
                                'viewNetReceivable'
                            );


                        if (viewGross) {

                            viewGross.innerText =
                                gross;

                        }


                        if (viewCertified) {

                            viewCertified.innerText =
                                certified;

                        }


                        if (viewRetention) {

                            viewRetention.innerText =
                                retention;

                        }


                        if (viewNetReceivable) {

                            viewNetReceivable.innerText =
                                net;

                        }


                        const breakdownGross =
                            document.getElementById(
                                'viewBreakdownGross'
                            );

                        const breakdownCertified =
                            document.getElementById(
                                'viewBreakdownCertified'
                            );

                        const breakdownRetention =
                            document.getElementById(
                                'viewBreakdownRetention'
                            );

                        const breakdownTds =
                            document.getElementById(
                                'viewBreakdownTds'
                            );

                        const breakdownGst =
                            document.getElementById(
                                'viewBreakdownGst'
                            );

                        const breakdownNet =
                            document.getElementById(
                                'viewBreakdownNet'
                            );


                        if (breakdownGross) {

                            breakdownGross.innerText =
                                gross;

                        }


                        if (breakdownCertified) {

                            breakdownCertified.innerText =
                                certified;

                        }


                        if (breakdownRetention) {

                            breakdownRetention.innerText =
                                '- ' +
                                formatIndianCurrency(
                                    retentionNumber
                                );

                        }


                        if (breakdownTds) {

                            breakdownTds.innerText =
                                '- ' +
                                formatIndianCurrency(
                                    tdsNumber
                                );

                        }


                        if (breakdownGst) {

                            breakdownGst.innerText =
                                '- ' +
                                formatIndianCurrency(
                                    gstTdsNumber
                                );

                        }


                        if (breakdownNet) {

                            breakdownNet.innerText =
                                net;

                        }


                        const paymentStatus =
                            document.getElementById(
                                'viewPaymentStatus'
                            );

                        const utr =
                            document.getElementById(
                                'viewUtr'
                            );

                        const realizedElement =
                            document.getElementById(
                                'viewRealized'
                            );

                        const outstandingElement =
                            document.getElementById(
                                'viewOutstanding'
                            );


                        if (paymentStatus) {

                            paymentStatus.innerText =
                                status;

                            paymentStatus.classList.remove(
                                'view-status-text'
                            );


                            if (
                                status.toLowerCase()
                                    .includes('pending')
                            ) {

                                paymentStatus.classList.add(
                                    'view-status-text'
                                );

                            }

                        }


                        if (utr) {

                            utr.innerText =
                                realizedNumber > 0
                                    ? 'UTR-REF-' + billNo.replace(
                                        /[^0-9]/g,
                                        ''
                                      )
                                    : '-';

                        }


                        if (realizedElement) {

                            realizedElement.innerText =
                                realized;

                        }


                        if (outstandingElement) {

                            outstandingElement.innerText =
                                formatIndianCurrency(
                                    outstandingNumber
                                );

                        }




                        const modalElement =
                            document.getElementById(
                                'viewRaBillModal'
                            );


                        if (modalElement) {

                            const viewModal =
                                bootstrap.Modal.getOrCreateInstance(
                                    modalElement
                                );

                            viewModal.show();

                        }

                    }
                );

            });


        document.querySelectorAll('.action-delete')
            .forEach(function (button) {

                button.addEventListener(
                    'click',
                    function () {

                        const row =
                            this.closest('tr');

                        const billNo =
                            row.querySelector('.bill-no')
                               ?.innerText
                               .trim();


                        if (
                            confirm(
                                'Are you sure you want to delete ' +
                                billNo +
                                '?'
                            )
                        ) {

                            row.remove();

                        }

                    }
                );

            });




        /* ---------- Edit: reuse the Generate Client RA Bill modal ---------- */
        document.querySelectorAll('.action-edit')
            .forEach(function (button) {

                button.addEventListener(
                    'click',
                    function () {

                        const row =
                            this.closest('tr');

                        if (!row) return;

                        const cells =
                            row.querySelectorAll('td');

                        const billNo =
                            row.querySelector('.bill-no')
                               ?.innerText
                               .trim() || '';

                        const billDate =
                            row.querySelector('.bill-date')
                               ?.innerText
                               .trim() || '';

                        const client =
                            row.querySelector('.client-name')
                               ?.innerText
                               .trim() || '';

                        const project =
                            row.querySelector('.project-name')
                               ?.innerText
                               .trim() || '';

                        const period =
                            row.querySelector('.period-text')
                               ?.innerText
                               .trim() || '';

                        const gross =
                            cells[3]
                                ? cells[3].innerText.trim()
                                : '';

                        const certified =
                            cells[4]
                                ? cells[4].innerText.trim()
                                : '';

                        function parseCurrency(value) {
                            return Number(
                                String(value || '')
                                    .replace(/[₹,\s]/g, '')
                                    .replace(/-/g, '')
                            ) || 0;
                        }

                        const grossNum =
                            parseCurrency(gross);

                        const certifiedNum =
                            parseCurrency(certified);


                        /* Change modal title */
                        const modalTitle =
                            document.getElementById(
                                'generateClientRaModalLabel'
                            );

                        if (modalTitle) {

                            modalTitle.innerText =
                                'Edit Client RA Bill';

                        }


                        /* Change modal header subtitle */
                        const modalSubtitle =
                            document.querySelector(
                                '#generateClientRaModal .modal-header p'
                            );

                        if (modalSubtitle) {

                            modalSubtitle.innerText =
                                'Update certified work measurement claims and post to Accounts Receivable';

                        }


                        /* Change the submit button label to Update */
                        const postBtn =
                            document.getElementById(
                                'postClientRaBill'
                            );

                        if (postBtn) {

                            postBtn.innerHTML =
                                '<i class="mdi mdi-content-save-outline me-1"></i> Update';

                        }


                        /* Fill project */
                        const projectSite =
                            document.getElementById('projectSite');

                        if (projectSite) {

                            let matched = false;

                            Array.from(projectSite.options)
                                .forEach(function (opt) {

                                    if (
                                        opt.textContent
                                            .toLowerCase()
                                            .includes(project.toLowerCase())
                                    ) {

                                        projectSite.value = opt.value;
                                        matched = true;

                                    }

                                });

                            if (!matched) {
                                projectSite.selectedIndex = 0;
                            }

                        }


                        /* Fill client */
                        const clientInput =
                            document.querySelector(
                                '#clientRaBillForm [name="client_name"]'
                            );

                        if (clientInput) {
                            clientInput.value = client;
                        }


                        /* Fill RA number */
                        const raNoInput =
                            document.querySelector(
                                '#clientRaBillForm [name="ra_bill_number"]'
                            );

                        if (raNoInput) {
                            raNoInput.value = billNo;
                        }


                        /* Fill billing period */
                        const billingPeriod =
                            document.querySelector(
                                '#clientRaBillForm [name="billing_period"]'
                            );

                        if (billingPeriod) {

                            const m = period.split(' ')[0];

                            Array.from(billingPeriod.options)
                                .forEach(function (opt) {

                                    if (opt.value.startsWith(m)) {
                                        billingPeriod.value = opt.value;
                                    }

                                });

                        }


                        /* Fill submission date */
                        const subDate =
                            document.querySelector(
                                '#clientRaBillForm [name="submission_date"]'
                            );

                        if (subDate && billDate) {
                            subDate.value = billDate;
                        }


                        /* Fill gross & certified */
                        const grossInput =
                            document.getElementById(
                                'grossClaimedAmount'
                            );

                        const certifiedInput =
                            document.getElementById(
                                'certifiedAmount'
                            );

                        const equalGross =
                            document.getElementById('setEqualGross');

                        if (grossInput) {
                            grossInput.value = grossNum;
                        }

                        if (certifiedInput) {
                            certifiedInput.value = certifiedNum;
                        }

                        if (equalGross) {
                            equalGross.checked =
                                (grossNum === certifiedNum);
                        }


                        if (typeof calculateRaBill === 'function') {
                            calculateRaBill();
                        }


                        window.__editingRaRow = row;


                        const modalEl =
                            document.getElementById(
                                'generateClientRaModal'
                            );

                        if (modalEl) {

                            bootstrap.Modal
                                .getOrCreateInstance(modalEl)
                                .show();

                        }

                    }
                );

            });

    }




    const grossInput =
        document.getElementById('grossClaimedAmount');

    const certifiedInput =
        document.getElementById('certifiedAmount');

    const equalGrossCheckbox =
        document.getElementById('setEqualGross');

    const retentionPercent =
        document.getElementById('retentionPercent');

    const tdsPercent =
        document.getElementById('tdsPercent');

    const gstTdsPercent =
        document.getElementById('gstTdsPercent');

    const retentionAmount =
        document.getElementById('retentionAmount');

    const tdsAmount =
        document.getElementById('tdsAmount');

    const gstTdsAmount =
        document.getElementById('gstTdsAmount');

    const netReceivable =
        document.getElementById('netReceivable');



    function formatIndianCurrency(value) {

        value =
            Number(value) || 0;

        return '₹ ' +
            value.toLocaleString(
                'en-IN',
                {
                    maximumFractionDigits: 0
                }
            );

    }




    function calculateRaBill() {

        const certified =
            parseFloat(
                certifiedInput?.value
            ) || 0;


        const retentionRate =
            parseFloat(
                retentionPercent?.value
            ) || 0;


        const tdsRate =
            parseFloat(
                tdsPercent?.value
            ) || 0;


        const gstTdsRate =
            parseFloat(
                gstTdsPercent?.value
            ) || 0;


        const retention =
            certified *
            retentionRate /
            100;


        const tds =
            certified *
            tdsRate /
            100;


        const gstTds =
            certified *
            gstTdsRate /
            100;


        const net =
            certified -
            retention -
            tds -
            gstTds;


        if (retentionAmount) {

            retentionAmount.innerText =
                formatIndianCurrency(
                    retention
                );

        }


        if (tdsAmount) {

            tdsAmount.innerText =
                formatIndianCurrency(
                    tds
                );

        }


        if (gstTdsAmount) {

            gstTdsAmount.innerText =
                formatIndianCurrency(
                    gstTds
                );

        }


        if (netReceivable) {

            netReceivable.innerText =
                formatIndianCurrency(
                    net
                );

        }

    }


    if (equalGrossCheckbox) {

        equalGrossCheckbox.addEventListener(
            'change',
            function () {

                if (
                    this.checked &&
                    grossInput &&
                    certifiedInput
                ) {

                    certifiedInput.value =
                        grossInput.value;

                    calculateRaBill();

                }

            }
        );

    }


    /* Gross Amount */
    if (grossInput) {

        grossInput.addEventListener(
            'input',
            function () {

                if (
                    equalGrossCheckbox &&
                    equalGrossCheckbox.checked &&
                    certifiedInput
                ) {

                    certifiedInput.value =
                        this.value;

                }

                calculateRaBill();

            }
        );

    }


    /* Certified Amount */
    if (certifiedInput) {

        certifiedInput.addEventListener(
            'input',
            function () {

                if (equalGrossCheckbox) {

                    equalGrossCheckbox.checked =
                        false;

                }

                calculateRaBill();

            }
        );

    }


    /* Retention */
    if (retentionPercent) {

        retentionPercent.addEventListener(
            'input',
            calculateRaBill
        );

    }


    /* TDS */
    if (tdsPercent) {

        tdsPercent.addEventListener(
            'input',
            calculateRaBill
        );

    }


    /* GST TDS */
    if (gstTdsPercent) {

        gstTdsPercent.addEventListener(
            'input',
            calculateRaBill
        );

    }


    /* Initial calculation */
    calculateRaBill();


    /* ---------- Toolbar Generate button — always in "create" mode ---------- */
    const generateBtn =
        document.getElementById('generateClientRaBtn');

    if (generateBtn) {

        generateBtn.addEventListener(
            'click',
            function () {

                window.__editingRaRow = null;

                const modalTitle =
                    document.getElementById(
                        'generateClientRaModalLabel'
                    );

                if (modalTitle) {

                    modalTitle.innerText =
                        'Generate New Client RA Bill';

                }


                const modalSubtitle =
                    document.querySelector(
                        '#generateClientRaModal .modal-header p'
                    );

                if (modalSubtitle) {

                    modalSubtitle.innerText =
                        'Post certified work measurement claims to Accounts Receivable';

                }


                const postBtn =
                    document.getElementById(
                        'postClientRaBill'
                    );

                if (postBtn) {

                    postBtn.innerHTML =
                        '<i class="mdi mdi-send-check-outline me-1"></i> Post to Accounts Receivable';

                }

            }
        );

    }


    const postButton =
        document.getElementById(
            'postClientRaBill'
        );


    if (postButton) {

        postButton.addEventListener(
            'click',
            function () {

                const form =
                    document.getElementById(
                        'clientRaBillForm'
                    );


                if (!form) {
                    return;
                }


                const project =
                    document.getElementById(
                        'projectSite'
                    );


                const gross =
                    document.getElementById(
                        'grossClaimedAmount'
                    );


                if (
                    project &&
                    project.value === ''
                ) {

                    alert(
                        'Please select a Project Site.'
                    );

                    project.focus();

                    return;

                }


                if (
                    !gross ||
                    parseFloat(gross.value) <= 0
                ) {

                    alert(
                        'Please enter a valid Gross Claimed Amount.'
                    );

                    gross.focus();

                    return;

                }


                const editingRow =
                    window.__editingRaRow;


                if (editingRow) {

                    /* -------- UPDATE existing row -------- */

                    const cells =
                        editingRow.querySelectorAll('td');


                    const newBillNo =
                        document.querySelector(
                            '#clientRaBillForm [name="ra_bill_number"]'
                        )?.value.trim() || '';


                    const newClient =
                        document.querySelector(
                            '#clientRaBillForm [name="client_name"]'
                        )?.value.trim() || '';


                    const newGross =
                        parseFloat(gross.value) || 0;


                    const newCertified =
                        parseFloat(certifiedInput?.value || 0) || 0;


                    const newRetention =
                        newCertified * 0.05;


                    const newNet =
                        newCertified -
                        newRetention -
                        (newCertified * 0.02) -
                        (newCertified * 0.02);


                    function fmt(v) {

                        return '₹ ' +
                            Number(v || 0).toLocaleString(
                                'en-IN',
                                {
                                    maximumFractionDigits: 0
                                }
                            );

                    }


                    const billEl =
                        editingRow.querySelector('.bill-no');

                    if (billEl && newBillNo) {
                        billEl.innerText = newBillNo;
                    }


                    const clientEl =
                        editingRow.querySelector('.client-name');

                    if (clientEl && newClient) {
                        clientEl.innerText = newClient;
                    }


                    if (cells[3]) {
                        cells[3].innerText = fmt(newGross);
                    }

                    if (cells[4]) {
                        cells[4].innerText = fmt(newCertified);
                    }

                    if (cells[5]) {
                        cells[5].innerText = fmt(newRetention);
                    }

                    if (cells[6]) {
                        cells[6].innerText = fmt(newNet);
                    }


                    window.__editingRaRow = null;


                    /* Reset modal title / subtitle / button */
                    const modalTitle =
                        document.getElementById(
                            'generateClientRaModalLabel'
                        );

                    if (modalTitle) {

                        modalTitle.innerText =
                            'Generate New Client RA Bill';

                    }


                    const modalSubtitle =
                        document.querySelector(
                            '#generateClientRaModal .modal-header p'
                        );

                    if (modalSubtitle) {

                        modalSubtitle.innerText =
                            'Post certified work measurement claims to Accounts Receivable';

                    }


                    if (postButton) {

                        postButton.innerHTML =
                            '<i class="mdi mdi-send-check-outline me-1"></i> Post to Accounts Receivable';

                    }


                    const modalEl =
                        document.getElementById(
                            'generateClientRaModal'
                        );

                    if (modalEl) {

                        bootstrap.Modal
                            .getOrCreateInstance(modalEl)
                            .hide();

                    }


                    if (typeof filterTable === 'function') {
                        filterTable();
                    }


                    return;

                }


                /* -------- CREATE new bill (original behaviour) -------- */
                alert(
                    'Client RA Bill is ready to be posted to Accounts Receivable.'
                );

            }
        );

    }


    const printVoucher =
        document.getElementById(
            'printRaVoucher'
        );


    if (printVoucher) {

        printVoucher.addEventListener(
            'click',
            function () {

                window.print();

            }
        );

    }

});

</script>

@endsection
