@extends('layouts/layoutMaster')

@section('title', 'Credit Card Settings - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

<div class="row">

    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            {{-- Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded">
                        <i class="mdi mdi-credit-card-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Credit Card Settings</h5>
                        <small class="text-muted">
                            Manage credit card details and payment configurations
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#creditCardModal" onclick="resetCardForm()">

                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Credit Card</span>
                </button>
            </div>

            {{-- Body --}}
            <div class="card-body pt-4">
                {{-- Search --}}
                <div class="row mb-4">
                    <div class="col-12 col-md-5 col-lg-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="cardSearch" class="form-control"
                                placeholder="Search card, holder or bank...">
                        </div>
                    </div>
                </div>

                {{-- Table --}}
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0" id="creditCardTable">
                        <thead>
                            <tr class="bg-light">
                                <th class="text-nowrap">Card Type</th>
                                <th class="text-nowrap">Credit Card No.</th>
                                <th class="text-nowrap">Card Holder Name</th>
                                <th class="text-nowrap">Bank</th>
                                <th class="text-nowrap">Expiry Date</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{-- Row 1 --}}
                            <tr>
                                <td class="text-nowrap">Visa</td>

                                <td class="text-nowrap fw-semibold"> •••• •••• •••• 1111 </td>
                                <td class="text-nowrap"> John Smith </td>
                                <td class="text-nowrap"> HDFC Bank </td>
                                <td class="text-nowrap"> 12/2028 </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        {{-- Edit --}}
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#creditCardModal" title="Edit"
                                            onclick="editCard(1)">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        {{-- Delete --}}
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCreditCardModal"
                                            title="Delete" onclick="setDeleteCard('•••• 1111')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 2 --}}
                            <tr>
                                <td class="text-nowrap"> Mastercard </td>
                                <td class="text-nowrap fw-semibold"> •••• •••• •••• 4444 </td>
                                <td class="text-nowrap"> Robert Wilson </td>
                                <td class="text-nowrap"> ICICI Bank </td>
                                <td class="text-nowrap"> 08/2027 </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#creditCardModal" title="Edit"
                                            onclick="editCard(2)">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCreditCardModal"
                                            title="Delete" onclick="setDeleteCard('•••• 4444')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 3 --}}
                            <tr>
                                <td class="text-nowrap"> American Express </td>
                                <td class="text-nowrap fw-semibold"> •••• •••• •••• 1005 </td>
                                <td class="text-nowrap"> Sarah Johnson </td>
                                <td class="text-nowrap"> Axis Bank </td>
                                <td class="text-nowrap"> 05/2029 </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#creditCardModal" title="Edit"
                                            onclick="editCard(3)">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCreditCardModal"
                                            title="Delete" onclick="setDeleteCard('•••• 1005')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Add / Edit Credit Card Modal --}}
<div class="modal fade" id="creditCardModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="creditCardModalTitle">
                    Add Credit Card
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>

            <form id="creditCardForm">
                <div class="modal-body">
                    {{-- Card Type --}}
                    <div class="mb-3">
                        <label for="card_type" class="form-label fw-semibold">
                            Credit Card Type
                            <span class="text-danger">*</span>
                        </label>
                        <select id="card_type" class="form-select select3" required>
                            <option value=""> Select card type </option>
                            <option value="Visa"> Visa </option>
                            <option value="Mastercard"> Mastercard </option>
                            <option value="American Express"> American Express </option>
                            <option value="Discover"> Discover </option>
                        </select>
                    </div>
                    {{-- Card Number --}}
                    <div class="mb-3">
                        <label for="card_number" class="form-label fw-semibold">
                            Credit Card No.
                            <span class="text-danger">*</span>
                        </label>
                        <input type="text" id="card_number" class="form-control" placeholder="Enter credit card number"
                            maxlength="19" required>
                    </div>
                    {{-- Card Holder --}}
                    <div class="mb-3">
                        <label for="card_holder" class="form-label fw-semibold">
                            Card Holder Name
                            <span class="text-danger">*</span>
                        </label>
                        <input type="text" id="card_holder" class="form-control" placeholder="Enter card holder name"
                            required>
                    </div>
                    {{-- Bank --}}
                    <div class="mb-3">
                        <label for="bank" class="form-label fw-semibold">Bank <span class="text-danger">*</span>
                        </label>
                        <select id="bank" class="form-select select3" required>
                            <option value=""> Select bank </option>
                            <option value="HDFC Bank"> HDFC Bank </option>
                            <option value="ICICI Bank"> ICICI Bank </option>
                            <option value="Axis Bank"> Axis Bank </option>
                            <option value="State Bank of India"> State Bank of India </option>
                            <option value="Kotak Mahindra Bank"> Kotak Mahindra Bank </option>
                            <option value="Bank of America"> Bank of America </option>
                        </select>
                    </div>

                    {{-- Expiry --}}
                    <div>
                        <label for="expiry_date" class="form-label fw-semibold">
                            Expiry Date
                            <span class="text-danger">*</span>
                        </label>
                        <input type="month" id="expiry_date" class="form-control" required>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="mdi mdi-check me-1"></i>
                        <span id="saveCardButtonText">
                            Save Card
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="deleteCreditCardModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Credit Card
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>

            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-credit-card-remove-outline fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="deleteCardNumber">
                        this card
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>

            </div>

        </div>

    </div>

</div>


@endsection


@push('scripts')

<script>
$(document).ready(function() {

    /*
    |--------------------------------------------------------------------------
    | Select2
    |--------------------------------------------------------------------------
    */

    $('.select2').select2({
        width: '100%',
        dropdownParent: $('#creditCardModal')
    });


    /*
    |--------------------------------------------------------------------------
    | Search
    |--------------------------------------------------------------------------
    */

    $('#cardSearch').on('keyup', function() {

        const value = $(this)
            .val()
            .toLowerCase();

        $('#creditCardTable tbody tr').each(function() {

            $(this).toggle(
                $(this)
                .text()
                .toLowerCase()
                .includes(value)
            );

        });

    });


    /*
    |--------------------------------------------------------------------------
    | Card Number Formatting
    |--------------------------------------------------------------------------
    */

    $('#card_number').on('input', function() {

        let value = $(this)
            .val()
            .replace(/\D/g, '')
            .substring(0, 16);

        value = value
            .replace(/(.{4})/g, '$1 ')
            .trim();

        $(this).val(value);

    });


    /*
    |--------------------------------------------------------------------------
    | Prevent Form Submit
    |--------------------------------------------------------------------------
    */

    $('#creditCardForm').on('submit', function(e) {

        e.preventDefault();

        $('#creditCardModal').modal('hide');

    });

});


/*
|--------------------------------------------------------------------------
| Reset Form
|--------------------------------------------------------------------------
*/

function resetCardForm() {

    $('#creditCardModalTitle')
        .text('Add Credit Card');

    $('#saveCardButtonText')
        .text('Save Card');

    $('#creditCardForm')[0].reset();

    $('#card_type')
        .val('')
        .trigger('change');

    $('#bank')
        .val('')
        .trigger('change');

}


/*
|--------------------------------------------------------------------------
| Edit Dummy Card
|--------------------------------------------------------------------------
*/

function editCard(id) {

    const cards = {

        1: {
            type: 'Visa',
            number: '4111111111111111',
            holder: 'John Smith',
            bank: 'HDFC Bank',
            expiry: '2028-12'
        },

        2: {
            type: 'Mastercard',
            number: '5555555555554444',
            holder: 'Robert Wilson',
            bank: 'ICICI Bank',
            expiry: '2027-08'
        },

        3: {
            type: 'American Express',
            number: '371449635398431',
            holder: 'Sarah Johnson',
            bank: 'Axis Bank',
            expiry: '2029-05'
        }

    };


    const card = cards[id];

    if (!card) return;


    $('#creditCardModalTitle')
        .text('Edit Credit Card');

    $('#saveCardButtonText')
        .text('Update Card');

    $('#card_type')
        .val(card.type)
        .trigger('change');

    $('#card_number')
        .val(
            card.number
            .replace(/\D/g, '')
            .replace(/(.{4})/g, '$1 ')
            .trim()
        );

    $('#card_holder')
        .val(card.holder);

    $('#bank')
        .val(card.bank)
        .trigger('change');

    $('#expiry_date')
        .val(card.expiry);

}


/*
|--------------------------------------------------------------------------
| Delete Dummy Card
|--------------------------------------------------------------------------
*/

function setDeleteCard(cardNumber) {

    $('#deleteCardNumber')
        .text(cardNumber);

}
</script>

@endpush
