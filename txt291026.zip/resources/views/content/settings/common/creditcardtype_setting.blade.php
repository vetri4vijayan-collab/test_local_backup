@extends('layouts/layoutMaster')

@section('title', 'Credit Card Type Settings - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

<div class="row">

    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9 px-1 px-md-3">
        <div class="card">
            {{-- Card Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-credit-card-settings-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Credit Card Type Settings</h5>
                        <small class="text-muted">
                            Manage available credit card types and descriptions
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#creditCardTypeModal" onclick="resetCreditCardTypeForm()">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Credit Card Type</span>
                </button>
            </div>

            {{-- Card Body --}}
            <div class="card-body pt-4">
                {{-- Search --}}
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-5 col-lg-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search card type or description...">
                        </div>
                    </div>
                </div>

                {{-- Data Table --}}
                <div class="table-responsive rounded border">

                    <table class="table table-hover align-middle mb-0" id="creditCardTypeTable">

                        <thead>
                            <tr class="bg-light">
                                <th class="text-nowrap"> Credit Card Type </th>
                                <th> Description </th>
                                <th> Status </th>
                                <th class="text-end"> Actions </th>
                            </tr>
                        </thead>
                        <tbody>
                            {{-- Row 1 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            Visa
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <span class="d-block text-truncate" style="max-width:400px;">
                                        International payment card accepted
                                        worldwide for credit and debit transactions.
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        {{-- Edit --}}
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#creditCardTypeModal" title="Edit"
                                            onclick="editCreditCardType(1)">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        {{-- Delete --}}
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCreditCardTypeModal"
                                            title="Delete" onclick="setDeleteCreditCardType('Visa')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            {{-- Row 2 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            Mastercard
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <span class="d-block text-truncate" style="max-width:400px;">
                                        Global payment card network used for
                                        secure domestic and international payments.
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#creditCardTypeModal" title="Edit"
                                            onclick="editCreditCardType(2)">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>


                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCreditCardTypeModal"
                                            title="Delete" onclick="setDeleteCreditCardType('Mastercard')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            {{-- Row 3 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-semibold">
                                            American Express
                                        </span>
                                    </div>
                                </td>
                                <td>

                                    <span class="d-block text-truncate" style="max-width:400px;">
                                        Premium payment card designed for
                                        personal and business transactions.
                                    </span>

                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#creditCardTypeModal" title="Edit"
                                            onclick="editCreditCardType(3)">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCreditCardTypeModal"
                                            title="Delete" onclick="setDeleteCreditCardType('American Express')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 4 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-semibold">
                                            Discover
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <span class="d-block text-truncate" style="max-width:400px;">
                                        Credit card network providing consumer
                                        payment and financial services.
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#creditCardTypeModal" title="Edit"
                                            onclick="editCreditCardType(4)">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCreditCardTypeModal"
                                            title="Delete" onclick="setDeleteCreditCardType('Discover')">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Add / Edit Credit Card Type Modal --}}
<div class="modal fade" id="creditCardTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="creditCardTypeModalTitle">
                    Credit Card Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>


            {{-- Form --}}
            <form id="creditCardTypeForm">

                <div class="modal-body">

                    {{-- Credit Card Type --}}
                    <div class="mb-3">

                        <label for="credit_card_type" class="form-label fw-semibold">

                            Credit Card Type
                            <span class="text-danger">*</span>

                        </label>

                        <input type="text" id="credit_card_type" class="form-control"
                            placeholder="Enter credit card type" required>

                    </div>


                    {{-- Description --}}
                    <div>

                        <label for="description" class="form-label fw-semibold">

                            Description

                        </label>

                        <textarea id="description" class="form-control" rows="3"
                            placeholder="Enter description..."></textarea>

                    </div>

                </div>


                {{-- Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="saveCreditCardTypeText">
                            Save Type
                        </span>

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="deleteCreditCardTypeModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            {{-- Header --}}
            <div class="modal-header border-bottom">

                <h5 class="modal-title fw-bold">
                    Delete Credit Card Type
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>


            {{-- Body --}}
            <div class="modal-body text-center py-4">

                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">

                    <i class="mdi mdi-credit-card-remove-outline fs-3 text-danger"></i>

                </div>

                <h5 class="mb-2">
                    Are you sure?
                </h5>

                <p class="text-muted mb-0">

                    You are about to delete

                    <strong id="deleteCreditCardTypeName">
                        this credit card type
                    </strong>.

                    This action cannot be undone.

                </p>

            </div>


            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">

                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">

                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete

                </button>

            </div>

        </div>

    </div>

</div>

@endsection