@extends('layouts/layoutMaster')

@section('title', 'Brand Settings - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])


<div class="row">
    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">

            {{-- Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between gap-2 flex-wrap">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded">
                        <i class="mdi mdi-store-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Brand Settings</h5>
                        <small class="text-muted">
                            Manage brand names and operating status
                        </small>
                    </div>
                </div>

                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#brandSettingModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Brand</span>
                </button>
            </div>

            {{-- Body --}}
            <div class="card-body">

                {{-- Search --}}
                <div class="row mb-4 pt-3">
                    <div class="col-12 col-md-5 col-lg-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" class="form-control" placeholder="Search brand name...">
                        </div>
                    </div>
                </div>

                {{-- Table --}}
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th class=" text-nowrap" style="">Brand Name</th>
                                <th class=" text-nowrap" style="width:150px;">Status</th>
                                <th class=" text-end" style="width:100px;">Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            {{-- Row 1: Birla --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-semibold">Birla</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#brandSettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBrandModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 2: Konark --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-semibold">Konark</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#brandSettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBrandModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 3: Polymak --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-semibold">Polymak</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#brandSettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBrandModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 4: Others --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-semibold">Others</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#brandSettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBrandModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            {{-- Row 5: Ken --}}
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-semibold">Ken</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#brandSettingModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBrandModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


{{-- Add / Edit Modal --}}
<div class="modal fade" id="brandSettingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">Add / Edit Brand</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="brand_name" class="form-label fw-semibold">
                        Brand Name <span class="text-danger">*</span>
                    </label>
                    <input type="text" id="brand_name" class="form-control" placeholder="e.g. Birla">
                </div>

            </div>

            <div class="modal-footer border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">
                    <i class="mdi mdi-check me-1"></i>
                    Save Brand
                </button>
            </div>

        </div>
    </div>
</div>


{{-- Delete Modal --}}
<div class="modal fade" id="deleteBrandModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">Delete Brand</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-delete-outline fs-3 text-danger"></i>
                </div>
                <h5>Are you sure?</h5>
                <p class="text-muted mb-0">
                    You are about to delete this brand. This action cannot be undone.
                </p>
            </div>

            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>

        </div>
    </div>
</div>

@endsection