@extends('layouts/layoutMaster')

@section('title', 'Probation Period - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

{{-- Probation Period Settings Main Content --}}
<div class="row g-4">

    {{-- Left Area: Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Right Area: Main Settings Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">

            {{-- Card Header --}}
            <div class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2 text-start">

                {{-- Icon + Title + Description --}}
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-calendar-clock-outline fs-4 text-primary"></i>
                    </div>

                    <div>
                        <h5 class="mb-0 fw-bold">Probation Period Settings</h5>
                        <small class="text-muted">
                            Manage employee probation periods and confirmation timelines
                        </small>
                    </div>
                </div>

                {{-- Add Button --}}
                <button type="button"
                    class="btn btn-primary d-flex align-items-center gap-1"
                    data-bs-toggle="modal"
                    data-bs-target="#probationPeriodModal">

                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Probation Period</span>
                </button>
            </div>

            {{-- Card Body --}}
            <div class="card-body pt-4">
                {{-- Search --}}
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between mb-2 ">
                        <div>
                            <span>Show</span>
                            <select id="perpage" class="form-select form-select-sm w-75px"
                                onchange="loadThemes(1)">
                                @php $options = [5,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="country-search-box">
                              <div class="input-group input-group-merge">
                                  <span class="input-group-text">
                                      <i class="mdi mdi-magnify"></i>
                                  </span>
                                  <input type="text" id="search_filter" class="form-control"
                                      placeholder="Search country or description..." value="{{ $search_filter }}" />
                              </div>
                          </div>
                        </div>
                    </div>
                </div>
                {{-- Probation Period Table --}}
                <div class="table-responsive text-nowrap rounded border">
                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">
                            <tr>
                                <th>No. of Days</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>

                        <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                  <div class="text-center my-3" id="pagination-container">
                  <!-- Pagination buttons will appear here -->
              </div>
            </div>
        </div>
    </div>
</div>

{{-- Create / Edit Probation Period Modal --}}
<div class="modal fade" id="probationPeriodModal" tabindex="-1"
    aria-labelledby="probationPeriodModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="probationPeriodModalLabel">
                    Add Probation Period
                </h5>

                <button type="button" class="btn-close"
                    data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            {{-- Form --}}
             <form id="categoryaddform_id">
               @csrf
                {{-- Modal Body --}}
                <div class="modal-body">
                    <div class="row g-4">

                        {{-- No. of Days --}}
                        <div class="col-12">
                            <label for="probation_days" class="form-label fw-semibold">
                                No. of Days
                                <span class="text-danger">*</span>
                            </label>

                            <input type="number"
                                id="category_name_id"
                                name="days"
                                class="form-control"
                                placeholder="Enter number of days"
                                min="1"
                                required>
                        </div>
                        <div class="text-danger" id="category_name_err"></div>
                        {{-- Description --}}
                        <div class="col-12">
                            <label for="probation_description" class="form-label fw-semibold">
                                Description
                            </label>
                            <textarea id="description_id" name="description" class="form-control" rows="2"></textarea>
                        </div>

                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">
                    <button type="button"
                        class="btn btn-outline-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button  id="add_submit_btn"
                        class="btn btn-primary"
                        onclick="addValidateForm()">
                        <i class="mdi mdi-check"></i>
                        <span id="probationSaveButtonText">Save Probation Period</span>
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editHiredMaterialModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="probationPeriodModalLabel">
                    Add Probation Period
                </h5>

                <button type="button" class="btn-close"
                    data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            {{-- Form --}}
          <form action="{{ route('probation-period.update') }}" method="POST" id="categoryeditForm" novalidate>
               @csrf
                <input type="hidden" id="edit_id" name="edit_id">
                {{-- Modal Body --}}
                <div class="modal-body">
                    <div class="row g-4">

                        {{-- No. of Days --}}
                        <div class="col-12">
                            <label for="probation_days" class="form-label fw-semibold">
                                No. of Days
                                <span class="text-danger">*</span>
                            </label>

                            <input type="number"
                               id="days"
                                name="days"
                                class="form-control"
                                placeholder="Enter number of days"
                                min="1"
                                required>
                            <div class="text-danger" id="category_name_edit_err"></div>
                        </div>
                        {{-- Description --}}
                        <div class="col-12">
                            <label for="probation_description" class="form-label fw-semibold">
                                Description
                            </label>

                            <textarea
                              id="description_edit"
                              name="description"
                              class="form-control"
                              rows="2"
                          ></textarea>
                        </div>

                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">
                    <button type="button"
                        class="btn btn-outline-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                      <i class="mdi mdi-check me-1"></i>Update Probation Period</span>
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="deleteHiredMaterialModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">

            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3
                    d-flex align-items-center justify-content-center"
                    style="width: 56px; height: 56px;">

                    <i class="mdi mdi-calendar-remove-outline fs-2 text-danger"></i>
                </div>

                <h6 class="fw-bold mb-1" id="deleteProbationModalLabel">
                    Delete Probation Period?
                </h6>

                 <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="deleteBankName">
                        this Hired Material
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button"
                    class="btn btn-sm btn-outline-secondary px-3"
                    data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger me-3" onclick="deletelevel()"><i class="mdi mdi-delete-outline me-1"></i>Delete</button>
            </div>

        </div>
    </div>
</div>


@push('styles')
<style>
/* =========================================================
   Probation Period Settings - Alignment
   ========================================================= */

.row {
    align-items: stretch;
}

.settings-sidebar,
.settings-sidebar-wrapper {
    min-width: 0 !important;
    max-width: 100% !important;
}

/* Main Content */
.col-12.col-md-8.col-lg-9 {
    min-width: 0 !important;
    display: flex;
    flex-direction: column;
}

.col-12.col-md-8.col-lg-9 > .card {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
}

/* Card Header */
.col-12.col-md-8.col-lg-9 .card-header {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    flex-wrap: wrap;
    gap: 1rem;
}

.col-12.col-md-8.col-lg-9 .card-header > div:first-child {
    display: flex !important;
    align-items: center !important;
    gap: 1rem !important;
    min-width: 0;
    flex: 1 1 auto;
}

.col-12.col-md-8.col-lg-9 .card-header .avatar {
    flex-shrink: 0 !important;
}

.col-12.col-md-8.col-lg-9 .card-header > div:first-child > div:last-child {
    min-width: 0;
}

.col-12.col-md-8.col-lg-9 .card-header h5 {
    margin-bottom: 0 !important;
    white-space: normal;
    overflow-wrap: anywhere;
}

.col-12.col-md-8.col-lg-9 .card-header small {
    display: block;
    white-space: normal;
    overflow-wrap: anywhere;
}

.col-12.col-md-8.col-lg-9 .card-header > button {
    flex: 0 0 auto;
    white-space: nowrap;
}

/* Card Body */
.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}

.col-12.col-md-8.col-lg-9 .card-body > .row {
    width: 100%;
    align-items: center;
}

.col-12.col-md-8.col-lg-9 #tableSearch {
    width: 100%;
}

/* Table */
.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
}

.col-12.col-md-8.col-lg-9 table {
    width: 100%;
}

.col-12.col-md-8.col-lg-9 table th,
.col-12.col-md-8.col-lg-9 table td {
    vertical-align: middle;
}

/* Status Toggle */
.col-12.col-md-8.col-lg-9 .form-check.form-switch {
    min-width: 60px;
}

/* Tablet */
@media (max-width: 991.98px) {
    .col-12.col-md-8.col-lg-9 .card-header {
        align-items: flex-start !important;
    }
}

/* Mobile */
@media (max-width: 767.98px) {
    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
    }

    .col-12.col-md-8.col-lg-9 .card-header {
        flex-direction: column !important;
        align-items: stretch !important;
        justify-content: flex-start !important;
    }

    .col-12.col-md-8.col-lg-9 .card-header > div:first-child {
        width: 100%;
        flex: 1 1 100%;
    }

    .col-12.col-md-8.col-lg-9 .card-header > button {
        width: 100%;
        flex: 1 1 100%;
        justify-content: center;
    }

    .col-12.col-md-8.col-lg-9 .card-body .row > div {
        width: 100%;
        max-width: 100%;
    }

    .col-12.col-md-8.col-lg-9 .table-responsive {
        overflow-x: auto;
    }

    .col-12.col-md-8.col-lg-9 table {
        min-width: 750px;
    }
}

/* Very Small Screens */
@media (max-width: 320px) {
    .col-12.col-md-8.col-lg-9 .card-header {
        padding: .75rem !important;
    }

    .col-12.col-md-8.col-lg-9 .card-header > div:first-child {
        gap: .5rem !important;
        align-items: flex-start !important;
    }

    .col-12.col-md-8.col-lg-9 .card-header h5 {
        font-size: .9rem;
    }

    .col-12.col-md-8.col-lg-9 .card-header small {
        font-size: .7rem;
        line-height: 1.3;
    }

    .col-12.col-md-8.col-lg-9 .card-header > button {
        font-size: .75rem;
        padding: .5rem;
    }
}

/* Large Screens */
@media (min-width: 992px) {
    .col-12.col-md-8.col-lg-9 {
        min-width: 0 !important;
    }
}
</style>
@endpush

<script>
   const editForm = document.getElementById('categoryeditForm');

if (editForm) {
    editForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const nameInput = document.getElementById('days');
        const errorElement = document.getElementById('category_name_edit_err');
        const submitBtn = editForm.querySelector('button[type="submit"]');

        if (!nameInput || !errorElement || !submitBtn) {
            console.error('Required edit form elements are missing.');
            return;
        }

        const materialName = nameInput.value.trim();

        errorElement.textContent = '';
        nameInput.classList.remove('error_msg');

        if (!materialName) {
            errorElement.textContent = 'Probation Days is required!';
            nameInput.classList.add('error_msg');
            nameInput.focus();
            return;
        }

        submitBtn.disabled = true;

        try {
            const response = await fetch(editForm.action, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: new FormData(editForm)
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.message || 'Unable to update hired material.'
                );
            }

            if (data.message === 'Already Exist') {
                toastr.warning('Probation Days already exists.');
                return;
            }

            if (data.status === 200) {
                toastr.success(
                    data.message || 'Probation Days updated successfully.'
                );

                bootstrap.Modal.getOrCreateInstance(
                    document.getElementById('editHiredMaterialModal')
                ).hide();

                loadThemes(1);
            } else {
                toastr.error(
                    data.message || 'Unable to update hired material.'
                );
            }
        } catch (error) {
            console.error('Update error:', error);
            toastr.error(error.message || 'Something went wrong.');
        } finally {
            submitBtn.disabled = false;
        }
    });
}

document.getElementById('days')?.addEventListener('input', function () {
    if (this.value.trim()) {
        document.getElementById('category_name_edit_err').textContent = '';
        this.classList.remove('error_msg');
    }
});
</script>

<!-- list page handling start-->
<script>
      let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index) {
        return `<tr>
                          <td>
                      <span class="fw-bold text-heading">${item.days}</span>
                  </td>

                  <td>
                      <span class="text-truncate d-inline-block"
                            style="max-width:350px"
                            title="${item.description || '-' }">
                            ${item.description || '-'}
                      </span>
                  </td>

                  <td>
                      <div class="form-check form-switch mb-0">
                          <input class="form-check-input country-status"
                                  type="checkbox"
                                ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"">
                      </div>
                  </td>

                  <td class="text-end">
                      <div class="d-inline-flex gap-1">
                      <button
                          type="button"
                          class="btn btn-sm btn-icon btn-outline-secondary border-0"
                          onclick="edit_vechicle_fetch_func(${item.sno})"
                          title="Edit">
                          <i class="mdi mdi-pencil-outline"></i>
                      </button>
                        <button
                          type="button"
                          class="btn btn-sm btn-icon btn-outline-danger border-0"
                          onclick='confirmDelete(${Number(item.sno)}, ${JSON.stringify(item.days || "")})'
                          title="Delete">
                          <i class="mdi mdi-delete-outline"></i>
                      </button>
                      </div>
                  </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/probation_period?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                res.data.forEach((item, index) => {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                });
                $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }
    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    function NoDataFound() {
        return `
            <tr><td colspan="4" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;

    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });


    // Initial load
    loadThemes(1);
</script>
<!-- list page handling End-->
<script>
 function edit_vechicle_fetch_func(id) {
    fetch(`/probation_period/edit/${id}`, {
        headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Unable to fetch hired material.');
        }
        return response.json();
    })
    .then(data => {
        if (data.status !== 200 || !data.data) {
            throw new Error(data.message || 'Hired material not found.');
        }

        const item = data.data;

        document.getElementById('edit_id').value = item.sno ?? '';
        document.getElementById('days').value =
            item.days ?? '';
        document.getElementById('description_edit').value =
            item.description ?? '';

        document.getElementById('category_name_edit_err').textContent = '';

        const modalElement = document.getElementById('editHiredMaterialModal');

        bootstrap.Modal.getOrCreateInstance(modalElement).show();
    })
    .catch(error => {
        console.error('Edit error:', error);
        toastr.error(error.message || 'Unable to load hired material.');
    });
}
let currentCategoryId;
function populateUpdateModal(id) {
    currentCategoryId = id;
    fetch(`/probation_period/edit/${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                const vechicle = data.data;


                document.getElementById('edit_id').value = vechicle.sno;
                document.getElementById('description_edit').value = vechicle.description;
                document.getElementById('category_name_edit').value = vechicle.days;

            } else {
                console.error('Error fetching category:', data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching category:', error);
        });
}
function updatelevelStatus(categoryId, isChecked) {
    const status = isChecked ? 0 : 1; // Set status based on checkbox state

    fetch(`/probation_period/status/${categoryId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
            },
            body: JSON.stringify({
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success('Probation Period status Updated successfully!');
                  loadThemes(1);
            } else {
                console.error('Error updating Job Time status:', data.message);
            }
        })
        .catch(error => {
            console.error('Error updating Job Time status:', error);
        });
}

function confirmDelete(id, name) {
    const modalElement = document.getElementById('deleteHiredMaterialModal');

    if (!modalElement) {
        console.error('Delete modal not found.');
        toastr.error('Delete confirmation modal is missing.');
        return;
    }

    const deleteButton = modalElement.querySelector('.btn-danger');

    if (!deleteButton) {
        console.error('Delete button not found inside modal.');
        return;
    }

    // Store the selected material ID
    deleteButton.setAttribute('data-id', id);

    // Display the selected material name safely
    document.getElementById('deleteBankName').textContent =
        name || 'this Hired Material';

    // Open the Bootstrap modal
    const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
    modal.show();
}


function deletelevel() {
    const deleteButton = document.querySelector(
        '#deleteHiredMaterialModal .btn-danger'
    );

    const categoryId = deleteButton.getAttribute('data-id');

    if (!categoryId) {
        toastr.error('Please select a hired material to delete.');
        return;
    }

    deleteButton.disabled = true;

    fetch(`/probation_period/delete/${categoryId}`, {
        method: 'DELETE',
        headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(async response => {
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || 'Unable to delete Probation Period.');
        }

        return data;
    })
    .then(data => {
        if (data.status === 200) {
            toastr.success('Probation Period deleted successfully.');

            bootstrap.Modal.getOrCreateInstance(
                document.getElementById('deleteHiredMaterialModal')
            ).hide();

            loadThemes(1);
        } else {
            toastr.error(data.message || 'Unable to delete Probation Period.');
        }
    })
    .catch(error => {
        console.error('Delete error:', error);
        toastr.error(error.message || 'Something went wrong.');
    })
    .finally(() => {
        deleteButton.disabled = false;
    });
}
function addValidateForm() {
    var err = 0;
    // Validate knowledge Name
    var category_name_id = document.getElementById("category_name_id").value.trim();
    var description_id = document.getElementById("description_id").value.trim();
    if (category_name_id === "") {
        document.getElementById('category_name_err').innerHTML = 'Probation Days is required...!';
        document.getElementById('category_name_id').classList.add('error_msg');
        err++;
    } else {
        document.getElementById('category_name_id').classList.remove('error_msg');
        document.getElementById('category_name_err').innerHTML = '';
    }
    if(err > 0){
      return false;
    }else{
      submit_form()
    }
    return err === 0;
}

    function submit_form() {
    const form = document.getElementById('categoryaddform_id');
    const submitBtn = document.getElementById('add_submit_btn');

    if (!form || !submitBtn) return;

    submitBtn.disabled = true;

    const formData = new FormData(form);

    $.ajax({
        url: "{{ route('probation-period.store') }}",
        method: "POST",
        data: formData,
        processData: false,
        contentType: false,

        success: function (response) {
            if (response.status === 200) {
                if (response.message === 'Already Exist') {
                    toastr.warning('Probation Days already exists.');
                    submitBtn.disabled = false;
                    return;
                }

                toastr.success(response.message);
                window.location.reload();
            } else {
                toastr.error(response.message || 'Unable to save Probation Days.');
                submitBtn.disabled = false;
            }
        },

        error: function (xhr) {
            submitBtn.disabled = false;

            if (xhr.status === 422) {
                const message =
                    xhr.responseJSON?.message ||
                    'Please check the required fields.';

                toastr.error(message);
            } else {
                toastr.error('Something went wrong while saving Probation Days.');
                console.error(xhr.responseJSON || xhr.responseText);
            }
        }
    });
}
 </script>
  @endsection
