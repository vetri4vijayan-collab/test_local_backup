@extends('layouts/layoutMaster')

@section('title', 'Language Settings - Common Settings')

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

<div class="row g-4">


    {{-- Left Area: Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Right Area: Main Settings Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">

            {{-- Card Header --}}
            <div class="card-header border-bottom py-3">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">

                    <div class="d-flex align-items-center gap-3">
                        <div
                            class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center flex-shrink-0">
                            <i class="mdi mdi-translate fs-4 text-primary"></i>
                        </div>

                        <div>
                            <h5 class="mb-0 fw-bold">Language Settings</h5>
                            <small class="text-muted">
                                Manage available languages and their status
                            </small>
                        </div>
                    </div>

                    <button type="button" class="btn btn-primary d-flex align-items-center justify-content-center gap-1"
                        data-bs-toggle="modal" data-bs-target="#languageModal">
                        <i class="mdi mdi-plus fs-5"></i>
                        <span>Add Language</span>
                    </button>

                </div>
            </div>

            {{-- Card Body --}}
            <div class="card-body pt-4">

                {{-- Search Toolbar --}}
                <div class="row g-3 mb-2 align-items-center">
                    <div class="col-12">
                        <div class="d-flex align-items-center justify-content-between  ">
                            <div>
                                <span>Show</span>
                                <select id="perpage" class="form-select form-select-sm w-75px"
                                    onchange="loadThemes(1)">
                                    @php $options = [5,10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                            {{ $option }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mt-2">
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                    <input type="text" id="search_filter" class="form-control"
                                        placeholder="Search language..." />
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                {{-- Language Table --}}
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">
                            <tr class="bg-light">
                                <th>Language</th>
                                <th>Status</th>
                                <th class="text-end">
                                    Actions
                                </th>
                            </tr>
                        </thead>

                        <tbody class="table-border-bottom-0" id="list-table-body">
                            {{-- Dummy Row 1 --}}
                            <!-- <tr>

                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span
                                            class="avatar avatar-xs bg-label-primary rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="mdi mdi-translate text-primary"></i>
                                        </span>

                                        <span class="fw-bold text-heading">
                                            English
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#languageModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteLanguageModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>

                                    </div>
                                </td>
                            </tr> -->
                            <tr class="skeleton-loader" id="skeleton-loader">
                                  <td class="skeleton-cell">
                                      <div class="skeleton"></div>
                                  </td>
                                  <td class="skeleton-cell">
                                      <div class="skeleton"></div>
                                  </td>
                                  <td class="skeleton-cell">
                                      <div class="skeleton"></div>
                                  </td>
                              </tr>
                        </tbody>

                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                  <!-- Pagination buttons will appear here -->
                </div>

            </div>
        </div>
    </div>
    ```

</div>

{{-- Add / Edit Language Modal --}}

<div class="modal fade" id="languageModal" tabindex="-1" aria-labelledby="languageModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="languageModalTitle">
                    Language
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            <form id="languageSettingForm" action="{{ route('language_settings.store') }}" method="POST" novalidate>
               @csrf
               <input type="hidden" id="language_id" name="language_id" value="">
                <div class="modal-body text-start">

                    {{-- Language --}}
                    <div class="mb-3">
                        <label for="language" class="form-label fw-semibold">
                            Language
                            <span class="text-danger">*</span>
                        </label>
                        <input type="text" id="language" name="name" class="form-control" placeholder="Enter language name" required>
                        <div id="language_err" class="invalid-feedback"></div>
                    </div>

                </div>

                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" id="languageSubmitBtn" class="btn btn-primary d-flex align-items-center gap-1"> <i class="mdi mdi-check"></i><span id="languageSubmitText">Save Language</span></button>
                </div>

            </form>

        </div>
    </div>
</div>

{{-- Delete Confirmation Modal --}}

<div class="modal fade" id="deleteLanguageModal" tabindex="-1" aria-labelledby="deleteLanguageModalTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">

        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="deleteLanguageModalTitle">
                    Delete Language
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            <div class="modal-body text-center py-4">

                <div
                    class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-delete-outline fs-3 text-danger"></i>
                </div>

                <h6 class="fw-bold mb-2">
                    Are you sure?
                </h6>
            <p id="deleteLanguageMessage" class="text-muted mb-0">
                Do you really want to delete this language?
                This action cannot be undone.
            </p>

            </div>

            <div class="modal-footer border-top justify-content-center">

                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" id="confirmDeleteLanguageBtn" class="btn btn-danger"><i class="mdi mdi-delete-outline me-1"></i>Delete</button>

            </div>

        </div>

    </div>
</div>

<!-- list page handling start-->
<script>
    
    const LANGUAGE_STORE_URL = @json(route('language_settings.store'));
    const LANGUAGE_EDIT_URL = @json(url('/settings/language/edit'));
    const LANGUAGE_UPDATE_URL = @json(url('/settings/language/update'));
    const LANGUAGE_STATUS_URL = @json(url('/settings/language/status'));
    const LANGUAGE_DELETE_URL = @json(url('/settings/language/delete'));
    const LANGUAGE_CSRF = @json(csrf_token());
    let abortController = new AbortController();
    let currentPage = 1;

    let tableState = {
        currentPage: 1
    };

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item, index) {
      const id = Number(item.sno);
      const name = escapeHtml(item.name);
      const active = Number(item.status) === 0;

        let isLoading = false;

        return `
            <tr>
                <td>
                    <div class="d-flex align-items-center gap-2">
                        <span class="avatar avatar-xs bg-label-primary rounded-circle
                                    d-flex align-items-center justify-content-center">
                            <i class="mdi mdi-translate text-primary"></i>
                        </span>
                        <span class="fw-bold text-heading">${name}</span>
                    </div>
                </td>

                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox"
                            ${active ? 'checked' : ''}
                            aria-label="Change status for ${name}"
                            onchange="updateLanguageStatus(${id}, this.checked, this)">
                    </div>
                </td>

                <td class="text-end">
                    <div class="d-inline-flex gap-1">
                        <button type="button"
                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                            onclick="editLanguage(${id})" title="Edit">
                            <i class="mdi mdi-pencil-outline"></i>
                        </button>

                        <button type="button"
                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                            onclick="confirmDeleteLanguage(${id})" title="Delete">
                            <i class="mdi mdi-delete-outline"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
         const url = `/settings/language_settings?page=${page}&sorting_filter=${perpage}&search_filter=${encodeURIComponent(search)}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    function NoDataFound() {
        return `
            <tr><td colspan="4" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;

    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });


    // Initial load
    loadThemes(1);
</script>
<!-- list page handling End-->
<script>
function resetLanguageForm() {
    const form = document.getElementById('languageSettingForm');

    form.reset();
    document.getElementById('language_id').value = '';
    document.getElementById('language_err').textContent = '';
    document.getElementById('language').classList.remove('is-invalid');

    document.getElementById('languageModalTitle').textContent = 'Add Language';
    document.getElementById('languageSubmitText').textContent = 'Save Language';

    form.action = LANGUAGE_STORE_URL;
}

async function editLanguage(id) {
    try {
        const response = await fetch(`${LANGUAGE_EDIT_URL}/${id}`, {
            headers: { 'Accept': 'application/json' }
        });

        const result = await response.json();

        if (!response.ok || !result.data) {
            throw new Error(result.message || 'Unable to load language.');
        }

        resetLanguageForm();

        document.getElementById('language_id').value = result.data.sno;
        document.getElementById('language').value = result.data.name ?? '';

        document.getElementById('languageSettingForm').action =
            `${LANGUAGE_UPDATE_URL}/${id}`;

        document.getElementById('languageModalTitle').textContent =
            'Edit Language';

        document.getElementById('languageSubmitText').textContent =
            'Update Language';

        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('languageModal')
        ).show();
    } catch (error) {
        toastr.error(error.message || 'Unable to edit language.');
    }
}
</script>

    <!-- status Change -->
 <script>
    async function updateLanguageStatus(id, checked, checkbox) {
    checkbox.disabled = true;

    try {
        const response = await fetch(`${LANGUAGE_STATUS_URL}/${id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': LANGUAGE_CSRF,
                'Accept': 'application/json'
            },
            body: JSON.stringify({ status: checked ? 0 : 1 })
        });

        const result = await response.json();

        if (!response.ok || result.status !== 200) {
            throw new Error(result.message || 'Unable to update status.');
        }

        toastr.success(result.message || 'Language status updated.');
    } catch (error) {
        checkbox.checked = !checked;
        toastr.error(error.message || 'Unable to update status.');
    } finally {
        checkbox.disabled = false;
    }
}

</script>

<!-- Delete Function -->
<script>
    function confirmDeleteLanguage(id) {
    deleteLanguageId = id;

    document.getElementById('deleteLanguageMessage').textContent =
        'This action cannot be undone.';

    bootstrap.Modal.getOrCreateInstance(
        document.getElementById('deleteLanguageModal')
    ).show();
}

async function deleteLanguage() {
   
    if (!deleteLanguageId) return;

    const button = document.getElementById('confirmDeleteLanguageBtn');
    button.disabled = true;

    try {
        const response = await fetch(
            `${LANGUAGE_DELETE_URL}/${deleteLanguageId}`,
            {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': LANGUAGE_CSRF,
                    'Accept': 'application/json'
                }
            }
        );

        const result = await response.json();

        if (!response.ok || result.status !== 200) {
            throw new Error(result.message || 'Unable to delete language.');
        }

        toastr.success(result.message || 'Language deleted successfully.');

        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('deleteLanguageModal')
        ).hide();

        deleteLanguageId = null;
        await loadThemes(1);
    } catch (error) {
        toastr.error(error.message || 'Unable to delete language.');
    } finally {
        button.disabled = false;
    }
}

</script>

<!-- add validate -->
 <script>
    document.getElementById('languageSettingForm')
        .addEventListener('submit', async function (event) {
            event.preventDefault();
            const form = this;
            const input = document.getElementById('language');
            const errorElement = document.getElementById('language_err');
            const button = document.getElementById('languageSubmitBtn');
            const submitText = document.getElementById('languageSubmitText');
            errorElement.textContent = '';
            input.classList.remove('is-invalid');
            const name = input.value.trim();
            if (!name) {
                errorElement.textContent = 'Language name is required.';
                input.classList.add('is-invalid');
                input.focus();
                return;
            }
            input.value = name;
            const isEdit = document.getElementById('language_id').value !== '';
            const originalText = isEdit ? 'Update Language' : 'Save Language';
            button.disabled = true;
            submitText.textContent = isEdit ? 'Updating...' : 'Saving...';
            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json'
                    },
                    body: new FormData(form)
                });
                const result = await response.json();
                if (response.status === 422) {
                    errorElement.textContent =
                        result.errors?.name?.[0] ||
                        result.message ||
                        'Please check the language name.';
                    input.classList.add('is-invalid');
                    return;
                }

                if (!response.ok || result.status !== 200) {
                    throw new Error(result.message || 'Unable to save language.');
                }
                toastr.success(result.message || 'Language saved successfully.');
                bootstrap.Modal.getOrCreateInstance(
                    document.getElementById('languageModal')
                ).hide();
                resetLanguageForm();
                await loadThemes(1);
            } catch (error) {
                toastr.error(error.message || 'Unable to save language.');
            } finally {
                button.disabled = false;
                submitText.textContent = originalText;
            }
        });
    document.getElementById('language').addEventListener('input', function () {
        document.getElementById('language_err').textContent = '';
        this.classList.remove('is-invalid');
    });

    document.getElementById('languageModal').addEventListener(
        'hidden.bs.modal',
        resetLanguageForm
    );
    document.getElementById('confirmDeleteLanguageBtn').addEventListener('click', deleteLanguage);
 </script>
  <!-- edit Validate -->

@endsection