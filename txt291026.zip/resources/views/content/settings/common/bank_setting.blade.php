@extends('layouts/layoutMaster')

@section('title', 'Bank Settings - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

<div class="row">

    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-bank-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Bank Settings</h5>
                        <small class="text-muted">
                            Manage bank names, branches and account details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#bankModal" onclick="resetBankForm()">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Bank</span>
                </button>
            </div>
            <div class="card-body pt-4">
                {{-- Search --}}
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search bank, branch or account...">
                        </div>
                    </div>
                </div>
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0" id="bankTable">
                        <thead >
                            <tr class="bg-light text-black">
                                <th class="text-nowrap"> Bank Name </th>
                                <th class="text-nowrap"> Bank Branch </th>
                                <th class="text-nowrap"> Account No </th>
                                <th class="text-nowrap"> IFSC Code </th>
                                <th class="text-nowrap"> Status </th>
                                <th class="text-end" style="width:110px; "> Actions </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            State Bank of India
                                        </span>
                                    </div>
                                </td>
                                <td class="text-nowrap">
                                    Chennai Main Branch
                                </td>
                                <td class="text-nowrap">
                                    <span class="fw-medium">
                                        123456789012
                                    </span>
                                </td>
                                <td class="text-nowrap">
                                    <span class="badge text-black">
                                        SBIN0001234
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        {{-- Edit --}}
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#bankModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        {{-- Delete --}}
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBankModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            HDFC Bank
                                        </span>
                                    </div>
                                </td>
                                <td class="text-nowrap">
                                    T Nagar Branch
                                </td>
                                <td class="text-nowrap">
                                    <span class="fw-medium">
                                        50200012345678
                                    </span>
                                </td>
                                <td class="text-nowrap">
                                    <span class="badge text-black">
                                        HDFC0000123
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#bankModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBankModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            ICICI Bank
                                        </span>
                                    </div>
                                </td>
                                <td class="text-nowrap">
                                    Anna Nagar Branch
                                </td>
                                <td class="text-nowrap">
                                    <span class="fw-medium">
                                        987654321012
                                    </span>
                                </td>
                                <td class="text-nowrap">
                                    <span class="badge text-black">
                                        ICIC0000456
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#bankModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBankModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>

                                    </div>

                                </td>

                            </tr>
                            <tr>
                                <td class="text-nowrap">
                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            Axis Bank
                                        </span>
                                    </div>
                                </td>
                                <td class="text-nowrap">
                                    Adyar Branch
                                </td>
                                <td class="text-nowrap">
                                    <span class="fw-medium">
                                        123450987654
                                    </span>
                                </td>
                                <td class="text-nowrap">
                                    <span class="badge text-black">
                                        UTIB0000789
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#bankModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteBankModal" title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="bankModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="bankModalTitle">
                    Bank
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="bankForm">
                <div class="modal-body">
                    <div class="row g-3">
                        {{-- Bank Name --}}
                        <div class="col-12 col-md-6">
                            <label for="bank_name" class="form-label fw-semibold">
                                Bank Name
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="bank_name" class="form-control" placeholder="Enter bank name"
                                required>
                        </div>

                        {{-- Bank Branch --}}
                        <div class="col-12 col-md-6">
                            <label for="bank_branch" class="form-label fw-semibold">
                                Bank Branch
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="bank_branch" class="form-control" placeholder="Enter bank branch"
                                required>
                        </div>

                        {{-- Account Number --}}
                        <div class="col-12 col-md-6">
                            <label for="account_no" class="form-label fw-semibold">
                                Account No
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="account_no" class="form-control" placeholder="Enter account number"
                                inputmode="numeric" required>
                        </div>
                        {{-- IFSC Code --}}
                        <div class="col-12 col-md-6">
                            <label for="ifsc_code" class="form-label fw-semibold">
                                IFSC Code
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="ifsc_code" class="form-control text-uppercase"
                                placeholder="Enter IFSC code" maxlength="11" required>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="saveBankButtonText">
                            Save Bank
                        </span>

                    </button>

                </div>
            </form>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- Delete Confirmation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="deleteBankModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Bank
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-bank-remove-outline fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="deleteBankName">
                        this bank
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>



@push('styles')
<style>
/* =========================================================
   Bank Settings - Full Width + Zoom Safe
   ========================================================= */

/* Main content always uses available row width */
.col-12.col-md-8.col-lg-9 {
    min-width: 0;
    margin-left: 20%;
}


/* Desktop and above */
@media (min-width: 768px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        min-width: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
    }

}


/* Card */
.col-12.col-md-8.col-lg-9 .card {
    width: 100%;
    max-width: 100%;
}


/* Card body */
.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}


/* Table container */
.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}


/* Table */
.col-12.col-md-8.col-lg-9 #bankTable {
    width: 100%;
    min-width: 850px;
}


/* =========================================================
   Mobile
   ========================================================= */

@media (max-width: 767.98px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
    }

    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

}


/* =========================================================
   Small Mobile
   ========================================================= */

@media (max-width: 575.98px) {

    .col-12.col-md-8.col-lg-9 {
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .card-header {
        align-items: flex-start !important;
    }

    .card-header>div:first-child {
        width: 100%;
    }

    .card-header>button {
        width: 100%;
        justify-content: center;
    }

}


/* =========================================================
   Modal - Zoom / Small Screen Safe
   ========================================================= */

.modal-dialog {
    max-width: calc(100% - 2rem);
}

.modal-content {
    width: 100%;
    max-width: 100%;
}


/* Modal form columns */
@media (max-width: 767.98px) {

    #bankModal .row.g-3>[class*="col-md-6"] {
        width: 100%;
    }

}


/* =========================================================
   Prevent flex children from creating unexpected width
   ========================================================= */

.row {
    min-width: 0;
}

.row>[class*="col-"] {
    min-width: 0;
}
</style>
@endpush



@endsection
