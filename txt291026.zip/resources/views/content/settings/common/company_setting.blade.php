@extends('layouts/layoutMaster')

@section('title', 'Company Mobile - Common Settings')
@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

{{-- Company Mobile Settings Main Content --}}
<div class="row g-4">

    {{-- Left Area: Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Right Area: Main Settings Content & Table --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">

            {{-- Card Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2 text-start">

                {{-- Left: Icon + Title + Description --}}
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-cellphone fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">
                            Company Mobile Settings
                        </h5>
                        <small class="text-muted">
                            Manage company mobile numbers, networks, and operating status
                        </small>
                    </div>
                </div>
                {{-- Add Button --}}
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#companyMobileModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>
                        Add Mobile
                    </span>
                </button>
            </div>

            {{-- Card Body --}}
            <div class="card-body pt-4">
                {{-- Search --}}
                <div class="row g-3 mb-4 justify-content-between align-items-center">
                    <div class="col-12 col-md-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search mobile number or network..." />
                        </div>
                    </div>
                </div>
                {{-- Company Mobile Table --}}
                <div class="table-responsive text-nowrap rounded border">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr class="bg-light">
                                <th>
                                    Mobile Number
                                </th>
                                <th>
                                    Mobile Network
                                </th>
                                <th >
                                    Status
                                </th>
                                <th class="text-end">
                                    Actions
                                </th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            {{-- Dummy Row 1 --}}
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-bold text-heading">
                                            +91 98765 43210
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <span class="fw-semibold">
                                        Airtel
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        {{-- Edit --}}
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#companyMobileModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        {{-- Delete --}}
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCompanyMobileModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>

                            </tr>
                            {{-- Dummy Row 2 --}}
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-bold text-heading">
                                            +91 91234 56789
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <span class="fw-semibold">
                                        Jio
                                    </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#companyMobileModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCompanyMobileModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            {{-- Dummy Row 3 --}}
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-bold text-heading">
                                            +91 99887 76655
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <span class="fw-semibold"> Vi </span>
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#companyMobileModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteCompanyMobileModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Create / Edit Company Mobile Modal --}}
<div class="modal fade" id="companyMobileModal" tabindex="-1" aria-labelledby="companyMobileModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="companyMobileModalLabel">
                    Company Mobile
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="companyMobileForm">
                @csrf
                <input type="hidden" id="company_mobile_id" name="company_mobile_id" value="">
                {{-- Modal Body --}}
                <div class="modal-body">
                    <div class="row g-4">
                        {{-- Mobile Number --}}
                        <div class="col-12">
                            <label for="mobile_number" class="form-label fw-semibold">
                                Mobile Number
                                <span class="text-danger"> * </span>
                            </label>
                            <input type="tel" id="mobile_number" name="mobile_number" class="form-control"
                                placeholder="Enter mobile number" maxlength="15" required>
                        </div>

                        {{-- Mobile Network --}}
                        <div class="col-12">
                            <label for="mobile_network" class="form-label fw-semibold">
                                Mobile Network
                                <span class="text-danger">* </span>
                            </label>
                            <select id="mobile_network" name="mobile_network" class="form-select select3" required>
                                <option value="" selected disabled> Select Mobile Network </option>
                                <option value="Airtel"> Airtel </option>
                                <option value="Jio"> Jio </option>
                                <option value="Vi"> Vi </option>
                                <option value="BSNL"> BSNL </option>
                                <option value="Other"> Other </option>
                            </select>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="  " class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span>
                            Save Mobile
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="deleteCompanyMobileModal" tabindex="-1" aria-labelledby="deleteCompanyMobileModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">
            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                    style="width: 56px; height: 56px;">
                    <i class="mdi mdi-cellphone-remove fs-2 text-danger"></i>
                </div>
                <h6 class="fw-bold mb-1">
                    Delete Company Mobile?
                </h6>
                <p class="text-muted text-xs mb-0">
                    This action cannot be undone.
                </p>
            </div>
            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button" class="btn btn-sm btn-outline-secondary px-3" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-sm btn-danger px-3" data-bs-dismiss="modal">
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>

@endsection


@push('styles')
<style>
/* =========================================================
   Company Mobile Settings - Alignment Only
   ========================================================= */


/* Main settings row alignment */
.row {
    align-items: stretch;
}


/* =========================================================
   Settings Sidebar
   ========================================================= */

.settings-sidebar,
.settings-sidebar-wrapper {
    min-width: 0 !important;
    max-width: 100% !important;
}


/* =========================================================
   Main Content Alignment
   ========================================================= */

.col-12.col-md-8.col-lg-9 {
    min-width: 0 !important;
    display: flex;
    flex-direction: column;
}

.col-12.col-md-8.col-lg-9>.card {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
}


/* =========================================================
   Card Header
   ========================================================= */

.col-12.col-md-8.col-lg-9 .card-header {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    flex-wrap: wrap;
    gap: 1rem;
}


/* Left side: Icon + Title + Description */
.col-12.col-md-8.col-lg-9 .card-header>div:first-child {
    display: flex !important;
    align-items: center !important;
    gap: 1rem !important;
    min-width: 0;
    flex: 1 1 auto;
}


/* Icon should never shrink */
.col-12.col-md-8.col-lg-9 .card-header .avatar {
    flex-shrink: 0 !important;
}


/* Title / Description container */
.col-12.col-md-8.col-lg-9 .card-header>div:first-child>div:last-child {
    min-width: 0;
}


/* Title */
.col-12.col-md-8.col-lg-9 .card-header h5 {
    margin-bottom: 0 !important;
    white-space: normal;
    overflow-wrap: anywhere;
}


/* Description */
.col-12.col-md-8.col-lg-9 .card-header small {
    display: block;
    white-space: normal;
    overflow-wrap: anywhere;
}


/* Add button */
.col-12.col-md-8.col-lg-9 .card-header>button {
    flex: 0 0 auto;
    white-space: nowrap;
}

/* === Card Body === */

.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}

/* = Search Alignment = */
.col-12.col-md-8.col-lg-9 .card-body>.row {
    width: 100%;
    align-items: center;
}

/* Search field */
.col-12.col-md-8.col-lg-9 #tableSearch {
    width: 100%;
}

/* == Table Alignment == */
.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
}

.col-12.col-md-8.col-lg-9 table {
    width: 100%;
}

.col-12.col-md-8.col-lg-9 table th,
.col-12.col-md-8.col-lg-9 table td {
    vertical-align: middle;
}

/* ==== Status Alignment ==== */
.col-12.col-md-8.col-lg-9 .form-check.form-switch {
    min-width: 100px;
}

/* === Tablet === */

@media (max-width: 991.98px) {
    .col-12.col-md-8.col-lg-9 .card-header {
        align-items: flex-start !important;
    }
}

/* === Mobile === */
@media (max-width: 767.98px) {
    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
    }

    /* Header becomes stacked */
    .col-12.col-md-8.col-lg-9 .card-header {
        display: flex !important;
        flex-direction: column !important;
        align-items: stretch !important;
        justify-content: flex-start !important;
    }

    /* Header left content */
    .col-12.col-md-8.col-lg-9 .card-header>div:first-child {
        width: 100%;
        flex: 1 1 100%;
    }

    /* Add button */
    .col-12.col-md-8.col-lg-9 .card-header>button {
        width: 100%;
        flex: 1 1 100%;
        justify-content: center;
    }

    /* Search */
    .col-12.col-md-8.col-lg-9 .card-body .row>div {
        width: 100%;
        max-width: 100%;
    }

    /* Table */
    .col-12.col-md-8.col-lg-9 .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

    .col-12.col-md-8.col-lg-9 table {
        min-width: 750px;
    }

}


/* == Very Small Screens ===*/

@media (max-width: 320px) {
    .col-12.col-md-8.col-lg-9 .card-header {
        padding: .75rem !important;
    }

    .col-12.col-md-8.col-lg-9 .card-header>div:first-child {
        gap: .5rem !important;
        align-items: flex-start !important;
    }

    .col-12.col-md-8.col-lg-9 .card-header h5 {
        font-size: .9rem;
    }

    .col-12.col-md-8.col-lg-9 .card-header small {
        font-size: .7rem;
        line-height: 1.3;
    }

    .col-12.col-md-8.col-lg-9 .card-header>button {
        font-size: .75rem;
        padding: .5rem;
    }
}

/* ===== Large Screens / Zoom Out  ===== */
@media (min-width: 992px) {

    .col-12.col-md-8.col-lg-9 {
        min-width: 0 !important;
    }

}
</style>
@endpush