@extends('layouts/layoutMaster')

@section('title', 'Remuneration Type')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'admin_hr'])

<div class="row">

    <div class="col-md-3">
        @include('layouts.sections.settings.adminsettings-sidebar')
    </div>
    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-credit-card-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Remuneration Type</h5>
                        <small class="text-muted">
                            Manage remuneration type details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#addRemunerationTypeModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Remuneration Type</span>
                </button>
            </div>
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <div>
                    <span>Show</span>
                    <select id="perpage" class="form-select form-select-sm w-75px"
                        onchange="loadThemes(1)">
                             @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                             <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                    </select>
                    </div>
                    <div class="col-12 col-md-6 col-lg-5 mt-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="search_filter" class="form-control"
                                placeholder="Search renumeration" value="{{ $search_filter }}">
                        </div>
                    </div>
                </div>
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0" id="bankTable">
                        <thead>
                            <tr class="bg-light">
                                <th class="text-nowrap">Remuneration Type</th>
                                <th class="text-nowrap">Component Type</th>
                                <th class="text-nowrap">Description</th>
                                <th class="text-nowrap">Status</th>
                                <th class="text-end"> Actions </th>
                                
                            </tr>
                        </thead>
                       
                        <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                
                            </tr> 
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addRemunerationTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="addRemunerationTypeModalTitle">
                    Add Remuneration Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form action="{{ route('add_renumeration_setting') }}" method="POST" enctype="multipart/form-data" autocomplete="off" id="addrenumerationForm">
                @csrf
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-12">
                            <label for="renumeration_name" class="form-label fw-semibold">
                                Remuneration Type Name
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="renumeration_name" name="renumeration_name" class="form-control" placeholder="Enter Remuneration Type name"
                                >
                                 <div class="text-danger" id="renumeration_name_err"></div>
                        </div>
                        <div class="col-12 col-md-12">
                            <label class="form-label fw-semibold text-dark">
                                Component Type
                                <span class="text-danger">*</span>
                            </label>
                            <select id="component_type" name="component_type" class="form-select" >
                                <option value="">Select Type</option>
                                <option value="earning">Earning</option>
                                <option value="detection">Detection</option>
                                <option value="employer_contribution">Employer_Contribution</option>
                            </select>
                            <div class="text-danger" id="component_type_err"></div>
                        </div>
                        <div class="col-12 col-md-12">
                            <label for="ifsc_code" class="form-label fw-semibold">
                                Description
                                <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" id="renumeration_desc" name="renumeration_desc" rows="2"></textarea>
                            <div class="text-danger" id="renumeration_desc_err"></div>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button" class="btn btn-primary" id="saveRenumeration" onclick="AddvalidationForm()">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="">
                            Save Remuneration Type
                        </span>

                    </button>

                </div>
            </form>

        </div>

    </div>

</div>

<div class="modal fade" id="editRemunerationTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="addRemunerationTypeModalTitle">
                    Update Remuneration Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="bankForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-12">
                            <label for="renumeration_name" class="form-label fw-semibold">
                                Remuneration Type Name
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="edit_renumeration_name" name="edit_renumeration_name" class="form-control" placeholder="Enter Remuneration Type name"
                                required>
                        </div>
                        <div class="col-12 col-md-12">
                            <label class="form-label fw-semibold text-dark">
                                Component Type
                                <span class="text-danger">*</span>
                            </label>
                            <select id="edit_component_type" name="edit_component_type" class="form-select" >
                                <option value="">Select Type</option>
                                <option value="earning">Earning</option>
                                <option value="detection">Detection</option>
                                <option value="employer_contribution">Employer_Contribution</option>
                            </select>
                            <div class="text-danger" id="edit_component_type_err"></div>
                        </div>
                        <div class="col-12 col-md-12">
                            <label for="ifsc_code" class="form-label fw-semibold">
                                Description
                                <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" rows="2" id="edit_renumeration_desc" name="edit_renumeration_desc"></textarea>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button" class="btn btn-primary" id="saverenumeration" onclick="updaterenumeration()">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="">
                            Update Remuneration Type
                        </span>

                    </button>

                </div>
            </form>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- Delete Confirmation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="deleteRemunerationTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Remuneration Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-credit-card-outline fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0" id="delete_message">
                    You are about to delete
                    <strong id="deleteBankName">
                        this Remuneration Type
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" onclick="deletelevel()">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>



@push('styles')
<style>
/* =========================================================
   Bank Settings - Full Width + Zoom Safe
   ========================================================= */

/* Main content always uses available row width */
.col-12.col-md-8.col-lg-9 {
    min-width: 0;
    margin-left: 20%;
}


/* Desktop and above */
@media (min-width: 768px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        min-width: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
    }

}


/* Card */
.col-12.col-md-8.col-lg-9 .card {
    width: 100%;
    max-width: 100%;
}


/* Card body */
.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}


/* Table container */
.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}


/* Table */
.col-12.col-md-8.col-lg-9 #bankTable {
    width: 100%;
    min-width: 850px;
}


/* =========================================================
   Mobile
   ========================================================= */

@media (max-width: 767.98px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
    }

    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

}


/* =========================================================
   Small Mobile
   ========================================================= */

@media (max-width: 575.98px) {

    .col-12.col-md-8.col-lg-9 {
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .card-header {
        align-items: flex-start !important;
    }

    .card-header>div:first-child {
        width: 100%;
    }

    .card-header>button {
        width: 100%;
        justify-content: center;
    }

}


/* =========================================================
   Modal - Zoom / Small Screen Safe
   ========================================================= */

.modal-dialog {
    max-width: calc(100% - 2rem);
}

.modal-content {
    width: 100%;
    max-width: 100%;
}


/* Modal form columns */
@media (max-width: 767.98px) {

    #addRemunerationTypeModal .row.g-3>[class*="col-md-6"] {
        width: 100%;
    }

}


/* =========================================================
   Prevent flex children from creating unexpected width
   ========================================================= */

.row {
    min-width: 0;
}

.row>[class*="col-"] {
    min-width: 0;
}
</style>
@endpush




<!-- list Handling start-->
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    

    let tableState = {
        currentPage: 1
    };

    function formatDate(date,generalDateFormat) {
        
        if (!date) return '';

        const parsedDate = date instanceof Date
            ? date
            : new Date(date);

        if (isNaN(parsedDate.getTime())) return '';

        const day = String(parsedDate.getDate()).padStart(2, '0');
        const month = String(parsedDate.getMonth() + 1).padStart(2, '0');
        const year = parsedDate.getFullYear();

        const monthShort = parsedDate.toLocaleString('en-GB', {
            month: 'short'
        });

        const formats = {
            'd-m-Y': `${day}-${month}-${year}`,
            'Y-m-d': `${year}-${month}-${day}`,
            'Y/m/d': `${year}/${month}/${day}`,
            'd-M-Y': `${day}-${monthShort}-${year}`,
            'd/M/Y': `${day}/${monthShort}/${year}`
        };

        return formats[generalDateFormat] || formats['d-m-Y'];
    }


    

   

    function buildRow(item,index,common_date_format) {
        
        return `
            <tr>
                <td><label class="fs-7 fw-medium">${item.renumeration_name}</label></td>               
                <td><label class="fs-7 fw-medium">${item.component_type}</label></td>               
                <td><label class="fs-7 fw-medium">${item.renumeration_desc}</label></td>               
                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" id="RemunerationStatus1" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)">
                    </div>
                </td>
                <td>
                <div class="d-flex dropdown">
                <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0" data-bs-toggle="modal"
                            data-bs-target="#editRemunerationTypeModal" title="Edit" onclick="editmodel('${item.sno}')">
                    <i class="mdi mdi-pencil fs-5"></i>
                </button>
                <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0" data-bs-toggle="modal"
                        data-bs-target="#deleteRemunerationTypeModal" onclick="confirmDelete('${item.sno}','${item.renumeration_name}')">
                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                </button>
                </div>
                </td>
                
            </tr>
        `;
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;

        const url = `/settings/remuneration_type?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1,res.common_date_format));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="5" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

</script>
<!-- list Handling End-->


<script>
    function editmodel(categoryId) {

            currentCategoryId = categoryId;
            fetch(`/renumeration_edit/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const dept = data.data;

                        document.getElementById('edit_renumeration_name').value = dept.renumeration_name;
                        document.getElementById('edit_renumeration_desc').value = dept.renumeration_desc;
           
                    } else {
                        console.error('Error fetching renumeration:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching renumeration:', error);
                });
        }

        function updaterenumeration() {
            const id = currentCategoryId;
            const renumeration_name = document.getElementById('edit_renumeration_name').value;
            const component_type = document.getElementById('edit_component_type').value;
            const renumeration_desc = document.getElementById('edit_renumeration_desc').value;

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/renumeration_update/${id}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        renumeration_name: renumeration_name,
                        component_type: component_type,
                        renumeration_desc: renumeration_desc,

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Renumeration Updated successfully!');
                         location.reload();
                    } else {
                        toastr.error('Renumeration Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating renumeration:', error);

                });
        }

        document.getElementById('saverenumeration').addEventListener('button', function(event) {
            event.preventDefault();
            updaterenumeration();
        });
</script>

<script>
    function updatelevelStatus(id, isChecked) {
        const reloadPage = tableState.currentPage;
            const status = isChecked ? 0 : 1; // Set status based on checkbox state
            console.log(id);
            fetch(`/renumeration_status/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Department status Updated successfully!');
                         loadThemes(reloadPage); 
                    } else {
                        console.error('Error updating department status:', data.message);
                        toastr.error('Failed to update department');
                    }
                })
                .catch(error => {
                    console.error('Error updating department status:', error);
                });
        }


        function confirmDelete(id, name) {
            document.querySelector('#deleteRemunerationTypeModal .btn-danger').setAttribute(
                'data-id', id);
            $('#delete_message').html('You want to delete <br> <b class="text-danger"> ' + name +
                '</b> Renumeration ?');
        }

        function deletelevel() {

            var id = document.querySelector('#deleteRemunerationTypeModal .btn-danger').getAttribute('data-id');

            fetch('/delete_renumeration/' + id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Renumeration Deleted successfully!');
                        // location.reload();

                    } else {
                        toastr.error('Failed to delete renumeration');
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
</script>

<script>
    function AddvalidationForm() {
            let err=0;  
            var renumeration_name=$('#renumeration_name').val();
            var component_type=$('#component_type').val();
            var renumeration_desc=$('#renumeration_desc').val();
                        
            
            if(renumeration_name == ""){
                $('#renumeration_name_err').text('Renumeration Name is required')
                err++
            }
            if(component_type == ""){
                $('#component_type_err').text('Type is required')
                err++
            }
            if(renumeration_desc == ""){
                $('#renumeration_desc_err').text('Renumeration Description is required')
                err++
            }
            if (err>0){
            return false;
            }
            else{ 
                Addrenumertion();
            }
}

 
     function Addrenumertion() {
   
        const form = document.getElementById("addrenumerationForm");
        
        const submitBtn = document.getElementById("saveRenumeration");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                 url: "{{ route('add_renumeration_setting') }}",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    toastr.success('Renumeration Added successfully!');
                      location.reload();
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    toastr.error('Renumeration Failed to Add!');
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

@endsection
