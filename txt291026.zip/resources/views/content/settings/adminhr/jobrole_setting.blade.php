@extends('layouts/layoutMaster')

@section('title', 'Job Role')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Settings Header --}}
@include('layouts.sections.settings.settings-header', [
    'activeTab' => 'admin_hr'
])

<style>
    .department-status {
        width: 50px !important;
        height: 26px !important;
        cursor: pointer;
    }

    .department-status:checked {
        background-color: #1976ad;
        border-color: #1976ad;
    }

    .table > :not(caption) > * > * {
        border-bottom-color: #e5e5e5;
    }

    .table tbody tr {
        height: 50px;
    }

    .table tbody td {
        color: #333;
        font-size: 14px;
    }

    .table thead th {
        color: #212529;
        font-size: 14px;
        font-weight: 600;
    }

    .table tbody tr:nth-child(odd) {
        background-color: #fafafa;
    }

    .btn-link:hover {
        text-decoration: none;
    }
</style>

<div class="row mt-4">

    {{-- LEFT SIDEBAR --}}
    <div class="col-md-3">
        @include('layouts.sections.settings.adminsettings-sidebar')
    </div>

    {{-- RIGHT CONTENT --}}
    <div class="col-md-9">
        <div class="card ">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-account-tie-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Job Role Settings</h5>
                        <small class="text-muted">
                            Manage job role and its details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#createJobroleModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Job Role</span>
                </button>
            </div>
            <div class="card-body p-3">
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search Job role">
                        </div>
                    </div>
                </div>

              <div class="table-responsive rounded border">
                  <table class="table table-hover align-middle mb-0 border">
                      <thead class="table-light">
                          <tr class="bg-light">
                              <th >
                                  Job Role
                              </th>

                              <th >
                                  Status
                              </th>

                              <th >
                                  Actions
                              </th>
                          </tr>
                      </thead>

                      <tbody>

                          <tr>
                              <td class="px-3">
                                  Permanent
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#jobRoleModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteJobRoleModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Temporary
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#jobRoleModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteJobRoleModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Retirementship
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#jobRoleModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteJobRoleModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Contractual
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#jobRoleModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteJobRoleModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Management
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#jobRoleModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteJobRoleModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Intern
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#jobRoleModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteJobRoleModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  Site Engineer
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#jobRoleModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteJobRoleModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>

                          <tr>
                              <td class="px-3">
                                  QA/QC Engineer
                              </td>

                              <td class="px-3">
                                  <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                              </td>

                              <td class="px-3">
                                  <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#jobRoleModal"
                                        title="Edit">
                                    <i class="mdi mdi-pencil fs-5"></i>
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-outline-danger border-0"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteJobRoleModal">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                              </td>
                          </tr>
                      </tbody>
                  </table>
              </div>
            </div>
        </div>
    </div>
</div>

{{-- ========================================================= --}}
{{-- CREATE JOB ROLE MODAL --}}
{{-- ========================================================= --}}

<div
    class="modal fade"
    id="createJobRoleModal"
    tabindex="-1"
    aria-labelledby="createJobRoleModalLabel"
    aria-hidden="true"
>

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header border-bottom">

                <h5
                    class="modal-title"
                    id="createJobRoleModalLabel"
                >
                    Create Job Role
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>

            </div>

            <div class="modal-body">

                <div class="mb-3">

                    <label
                        for="create_job_role"
                        class="form-label"
                    >
                        Job Role <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="create_job_role"
                        name="job_role"
                        placeholder="Enter job role"
                        required
                    >

                </div>

                <div class="mb-3">

                    <label
                        for="create_description"
                        class="form-label"
                    >
                        Description
                    </label>

                    <textarea
                        class="form-control"
                        id="create_description"
                        name="description"
                        rows="4"
                        placeholder="Enter job role description"
                    ></textarea>

                </div>

            </div>

            <div class="modal-footer">

                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    class="btn btn-primary"
                    id="saveJobRole"
                >
                    <i class="mdi mdi-content-save-outline me-1"></i>
                    Save Job Role
                </button>

            </div>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- EDIT JOB ROLE MODAL --}}
{{-- ========================================================= --}}

<div
    class="modal fade"
    id="jobRoleModal"
    tabindex="-1"
    aria-labelledby="jobRoleModalLabel"
    aria-hidden="true"
>

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header border-bottom">

                <h5
                    class="modal-title"
                    id="jobRoleModalLabel"
                >
                    Update Job Role
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>

            </div>

            <div class="modal-body">

                <input
                    type="hidden"
                    id="job_role_id"
                >

                <div class="mb-3">

                    <label
                        for="edit_job_role"
                        class="form-label"
                    >
                        Job Role <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="edit_job_role"
                        name="job_role"
                        placeholder="Enter job role"
                        required
                    >

                </div>

                <div class="mb-3">

                    <label
                        for="edit_description"
                        class="form-label"
                    >
                        Description
                    </label>

                    <textarea
                        class="form-control"
                        id="edit_description"
                        name="description"
                        rows="4"
                        placeholder="Enter job role description"
                    ></textarea>

                </div>

            </div>

            <div class="modal-footer">

                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    class="btn btn-primary"
                    id="updateJobRole"
                >
                    <i class="mdi mdi-content-save-outline me-1"></i>

                    <span id="updateJobRoleText">
                        Update Job Role
                    </span>

                </button>

            </div>

        </div>

    </div>

</div>

<div class="modal fade" id="deleteJobRoleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Job Role
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto">
                    <i class="mdi mdi-account-tie-outline fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="">
                        this job role
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>

@endsection
