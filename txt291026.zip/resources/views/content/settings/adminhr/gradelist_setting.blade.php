@extends('layouts/layoutMaster')

@section('title', 'Grade List')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Settings Header --}}
@include('layouts.sections.settings.settings-header', [
    'activeTab' => 'admin_hr'
])

<style>
    .department-status {
        width: 50px !important;
        height: 26px !important;
        cursor: pointer;
    }

    .department-status:checked {
        background-color: #1976ad;
        border-color: #1976ad;
    }

    .table > :not(caption) > * > * {
        border-bottom-color: #e5e5e5;
    }

    .table tbody tr {
        height: 50px;
    }

    .table tbody td {
        color: #333;
        font-size: 14px;
    }

    .table thead th {
        color: #212529;
        font-size: 14px;
        font-weight: 600;
    }

    .table tbody tr:nth-child(odd) {
        background-color: #fafafa;
    }

    .btn-link:hover {
        text-decoration: none;
    }
</style>

<div class="row mt-4">

    {{-- LEFT SIDEBAR --}}
    <div class="col-md-3">
        @include('layouts.sections.settings.adminsettings-sidebar')
    </div>

    {{-- RIGHT CONTENT --}}
    <div class="col-md-9">
        <div class="card ">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-format-list-numbered fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Grade Settings</h5>
                        <small class="text-muted">
                            Manage grade and its details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#createGradeModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Grade</span>
                </button>
            </div>

          
            <div class="card-body p-3">
               <div class="d-flex align-items-center justify-content-between mb-2 ">
                    <div>
                    <span>Show</span>
                    <select id="perpage" class="form-select form-select-sm w-75px"
                        onchange="loadThemes(1)">
                             @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                             <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                    </select>
                    </div>
                    <div class="col-12 col-md-6 col-lg-5 mt-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="search_filter" class="form-control"
                                placeholder="Search grade" value="{{ $search_filter }}">
                        </div>
                    </div>
                </div>
              <div class="table-responsive rounded border">
                  <table class="table table-hover align-middle mb-0 border">
                      <thead class="table-light">
                          <tr class="bg-light">
                                       <th class="min-w-50px">Grade</th>
                                            <th class="min-w-100px">Status</th>
                                            <th class="min-w-50px">Action</th>
                                    </tr>
                            </thead>
                      <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                        <tr class="skeleton-loader" id="skeleton-loader">
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                           
                                        </tr> 
                                    </tbody>
                  </table>
              </div>
              <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>
            </div>
        </div>
    </div>
</div>

{{-- ================= CREATE GRADE MODAL ================= --}}
<div class="modal fade" id="createGradeModal" tabindex="-1" aria-labelledby="createGradeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="createGradeModalLabel">
                    Create Grade
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>

            <form action="{{ route('add_grade_setting') }}" method="POST" enctype="multipart/form-data" autocomplete="off" id="addgradesettingForm">
                @csrf

                <div class="modal-body">

                    {{-- Grade --}}
                    <div class="mb-3">
                        <label for="create_grade" class="form-label">
                            Grade <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            name="grade_name"
                            id="grade_name"
                            class="form-control"
                            placeholder="Enter grade"
                            maxlength="100"
                            required
                        >
                        <div class="text-danger" id="grade_name_err"></div>
                    </div>

                    <div class="mb-3">
                        <label for="edit_grade_description" class="form-label">
                            Description
                        </label>

                        <textarea
                            name="grade_desc"
                            id="grade_desc"
                            class="form-control"
                            rows="3"
                            placeholder="Enter description"
                        ></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button
                        type="button"
                        class="btn btn-primary" id="saveGrade" onclick="AddvalidationForm()">
                        <i class="mdi mdi-content-save me-1"></i>
                        Save Grade
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

{{-- ================= EDIT GRADE MODAL ================= --}}
<div class="modal fade" id="editgradeModal" tabindex="-1" aria-labelledby="editGradeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="editGradeModalLabel">
                    Edit Grade
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>
            </div>

            <form action="#" method="POST" id="editGradeForm">
                @csrf
                @method('PUT')

                <div class="modal-body">

                    {{-- Grade --}}
                    <div class="mb-3">
                        <label for="edit_grade" class="form-label">
                            Grade <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            name="edit_grade_name"
                            id="edit_grade_name"
                            class="form-control"
                            placeholder="Enter grade"
                            maxlength="100"
                            required
                        >
                    </div>

                    <div class="mb-3">
                        <label for="edit_grade_description" class="form-label">
                            Description
                        </label>

                        <textarea
                            name="edit_grade_desc"
                            id="edit_grade_desc"
                            class="form-control"
                            rows="3"
                            placeholder="Enter description"
                        ></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary" id="savegrade" onclick="updategrade()">
                        <i class="mdi mdi-content-save me-1"></i>
                        Update Grade
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<div class="modal fade" id="kt_modal_delete_grade" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Grade
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto">
                    <i class="mdi mdi-format-list-numbered fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0" id="delete_message">
                    You are about to delete
                    <strong id="">
                        this grade
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" onclick="deletelevel()">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>


<!-- list Handling start-->
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    

    let tableState = {
        currentPage: 1
    };

    function formatDate(date,generalDateFormat) {
        
        if (!date) return '';

        const parsedDate = date instanceof Date
            ? date
            : new Date(date);

        if (isNaN(parsedDate.getTime())) return '';

        const day = String(parsedDate.getDate()).padStart(2, '0');
        const month = String(parsedDate.getMonth() + 1).padStart(2, '0');
        const year = parsedDate.getFullYear();

        const monthShort = parsedDate.toLocaleString('en-GB', {
            month: 'short'
        });

        const formats = {
            'd-m-Y': `${day}-${month}-${year}`,
            'Y-m-d': `${year}-${month}-${day}`,
            'Y/m/d': `${year}/${month}/${day}`,
            'd-M-Y': `${day}-${monthShort}-${year}`,
            'd/M/Y': `${day}/${monthShort}/${year}`
        };

        return formats[generalDateFormat] || formats['d-m-Y'];
    }


    function buildRow(item,index,common_date_format) {
        
        return `
            <tr>
                <td><label class="fs-7 fw-medium">${item.grade_name}</label></td>               
                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" id="RemunerationStatus1" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)">
                    </div>
                </td>
                <td>
                <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0" data-bs-toggle="modal"
                            data-bs-target="#editgradeModal" title="Edit" onclick="editmodel('${item.sno}')">
                    <i class="mdi mdi-pencil fs-5"></i>
                </button>
                <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_delete_grade" onclick="confirmDelete('${item.sno}','${item.grade_name}')">
                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                </button>
                </td>
                
            </tr>
        `;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;

        const url = `/settings/gradelist-setting?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1,res.common_date_format));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="3" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

</script>
<!-- list Handling End-->


<script>
    function editmodel(categoryId) {

            currentCategoryId = categoryId;
            fetch(`/grade_edit/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const dept = data.data;

                        document.getElementById('edit_grade_name').value = dept.grade_name;
                        document.getElementById('edit_grade_desc').value = dept.grade_desc;
           
                    } else {
                        console.error('Error fetching internet:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching internet:', error);
                });
        }


        function updategrade() {
            const id = currentCategoryId;
            const grade_name = document.getElementById('edit_grade_name').value;
            const grade_desc = document.getElementById('edit_grade_desc').value;

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/grade_update/${id}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        grade_name: grade_name,
                        grade_desc: grade_desc,

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Grade Updated successfully!');
                         location.reload();
                    } else {
                        toastr.error('Grade Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating internet:', error);

                });
        }

        document.getElementById('savegrade').addEventListener('button', function(event) {
            event.preventDefault();
            updategrade();
        });
</script>

<script>
    function updatelevelStatus(id, isChecked) {
        const reloadPage = tableState.currentPage;
            const status = isChecked ? 0 : 1; // Set status based on checkbox state
            console.log(id);
            fetch(`/grade_status/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Grade status Updated successfully!');
                        console.log("success");
                         loadThemes(reloadPage); 
                    } else {
                        console.error('Error updating Grade status:', data.message);
                        toastr.error('Failed to update Grade');
                    }
                })
                .catch(error => {
                    console.error('Error updating grade status:', error);
                });
        }


        function confirmDelete(id, name) {
            document.querySelector('#kt_modal_delete_grade .btn-danger').setAttribute(
                'data-id', id);
            $('#delete_message').html('You want to delete <br> <b class="text-danger"> ' + name +
                '</b> Grade ?');
        }

        function deletelevel() {

            var id = document.querySelector('#kt_modal_delete_grade .btn-danger').getAttribute('data-id');

            fetch('/delete_grade/' + id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Grade Deleted successfully!');
                        location.reload();

                    } else {
                        toastr.error('Failed to deleted Grade');
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
</script>

<script>
    function AddvalidationForm() {
            let err=0;  
            var grade_name=$('#grade_name').val();
            var grade_desc=$('#grade_desc').val();
                        
            
            if(grade_name == ""){
                $('#grade_name_err').text('Grade Name is required')
                err++
            }
            if (err>0){
            return false;
            }
            else{ 
                AddGrade();
            }
    }

 
     function AddGrade() {
   
        const form = document.getElementById("addgradesettingForm");
        
        const submitBtn = document.getElementById("saveGrade");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                 url: "{{ route('add_grade_setting') }}",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    toastr.success('Grade Added successfully!');
                      location.reload();
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    toastr.error('Grade Failed to Add!');
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>
@endsection
