@extends('layouts/layoutMaster')

@section('title', 'Department')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Settings Header --}}
@include('layouts.sections.settings.settings-header', [
    'activeTab' => 'admin_hr'
])

<style>
    .department-status {
        width: 50px !important;
        height: 26px !important;
        cursor: pointer;
    }

    .department-status:checked {
        background-color: #1976ad;
        border-color: #1976ad;
    }

    .table > :not(caption) > * > * {
        border-bottom-color: #e5e5e5;
    }

    .table tbody tr {
        height: 50px;
    }

    .table tbody td {
        color: #333;
        font-size: 14px;
    }

    .table thead th {
        color: #212529;
        font-size: 14px;
        font-weight: 600;
    }

    .table tbody tr:nth-child(odd) {
        background-color: #fafafa;
    }

    .btn-link:hover {
        text-decoration: none;
    }
</style>

<div class="row mt-4">

    {{-- LEFT SIDEBAR --}}
    <div class="col-md-3">
        @include('layouts.sections.settings.adminsettings-sidebar')
    </div>

    {{-- RIGHT CONTENT --}}
    <div class="col-md-9">
        <div class="card ">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-domain fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Department Settings</h5>
                        <small class="text-muted">
                            Manage department and its details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#createDepartmentModal" >
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Department</span>
                </button>
            </div>
            
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                    <span>Show</span>
                    <select id="perpage" class="form-select form-select-sm w-75px"
                        onchange="loadThemes(1)">
                             @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                             <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                    </select>
                    </div>
                    <div class="col-12 col-md-6 col-lg-5 mt-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="search_filter" class="form-control"
                                placeholder="Search department" value="{{ $search_filter }}">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="table-responsive rounded border">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                    <tr class="bg-light">
                                       <th class="min-w-50px">Department</th>
                                            <th class="min-w-100px">Status</th>
                                            <th class="min-w-100px">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                        <tr class="skeleton-loader" id="skeleton-loader">
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                           
                                        </tr> 
                                    </tbody>
                            </table>
                        </div>
                        <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Create Department Modal -->
<div class="modal fade" id="createDepartmentModal" tabindex="-1" aria-labelledby="createDepartmentModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">

          <!-- Modal Header -->
          <div class="modal-header border-bottom">
              <h5 class="modal-title" id="createDepartmentModalLabel">
                  Create Department
              </h5>

              <button type="button"
                      class="btn-close"
                      data-bs-dismiss="modal"
                      aria-label="Close">
              </button>
          </div>

          <!-- Modal Body -->
          <div class="modal-body">
            <form action="{{ route('add_department_setting') }}" method="POST" enctype="multipart/form-data" autocomplete="off" id="adddepartmentsettingForm">
                @csrf
              <div class="mb-3">
                  <label for="department" class="form-label">
                      Department <span class="text-danger">*</span>
                  </label>
                  <input type="text"
                        class="form-control"
                        id="department_name"
                        name="department_name"
                        placeholder="Enter department name"
                        required>
                    <div class="text-danger" id="department_name_err"></div>
              </div>

              <div class="mb-3">
                  <label for="description" class="form-label">
                      Description
                  </label>

                  <textarea class="form-control"
                            id="department_desc"
                            name="department_desc"
                            rows="4"
                            placeholder="Enter department description"></textarea>
              </div>
</form>
          </div>

          <!-- Modal Footer -->
          <div class="modal-footer">
              <button type="button"
                      class="btn btn-light"
                      data-bs-dismiss="modal">
                  Cancel
              </button>

              <button type="button" class="btn btn-primary" id="saveDepartment" onclick="AddvalidationForm()">
                  <i class="mdi mdi-content-save-outline me-1"></i>
                  Save Department
              </button>
          </div>

      </div>
  </div>
</div>

<!-- Edit Department Modal -->
<div class="modal fade" id="editdepartmentModal" tabindex="-1"
     aria-labelledby="departmentModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <!-- Header -->
            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="departmentModalLabel">
                    Update Department
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <!-- Body -->
            <div class="modal-body">

                <input type="hidden" id="department_id">

                <div class="mb-3">
                    <label for="department" class="form-label">
                        Department <span class="text-danger">*</span>
                    </label>

                    <input type="text"
                           class="form-control"
                           id="edit_department_name"
                           name="edit_department_name"
                           placeholder="Enter department name"
                           required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">
                        Description
                    </label>

                    <textarea class="form-control"
                      id="edit_department_desc"
                      name="edit_department_desc"
                      rows="4"
                      placeholder="Enter department description"></textarea>
                </div>

            </div>

            <!-- Footer -->
            <div class="modal-footer">

                <button type="button"
                        class="btn btn-light"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button"
                        class="btn btn-primary"
                        id="saveDepartment" onclick="updatedepartment()">

                    <i class="mdi mdi-content-save-outline me-1"></i>

                    <span id="saveDepartmentText">
                        Save Department
                    </span>

                </button>

            </div>

        </div>
    </div>
</div>


<div class="modal fade" id="kt_modal_delete_department" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Department
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto">
                    <i class="mdi mdi-domain-remove fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0" id="delete_message">
                    You are about to delete
                    <strong id="">
                        this department
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal" onclick="deletelevel()">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>


<!-- list Handling start-->
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    

    let tableState = {
        currentPage: 1
    };

    function formatDate(date,generalDateFormat) {
        
        if (!date) return '';

        const parsedDate = date instanceof Date
            ? date
            : new Date(date);

        if (isNaN(parsedDate.getTime())) return '';

        const day = String(parsedDate.getDate()).padStart(2, '0');
        const month = String(parsedDate.getMonth() + 1).padStart(2, '0');
        const year = parsedDate.getFullYear();

        const monthShort = parsedDate.toLocaleString('en-GB', {
            month: 'short'
        });

        const formats = {
            'd-m-Y': `${day}-${month}-${year}`,
            'Y-m-d': `${year}-${month}-${day}`,
            'Y/m/d': `${year}/${month}/${day}`,
            'd-M-Y': `${day}-${monthShort}-${year}`,
            'd/M/Y': `${day}/${monthShort}/${year}`
        };

        return formats[generalDateFormat] || formats['d-m-Y'];
    }

    function buildRow(item,index,common_date_format) {
        
        return `
            <tr>
                <td>
                    <label class="fs-7 fw-medium">${item.department_name}</label>
                </td>               
                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" id="RemunerationStatus1" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)">
                    </div>
                </td>
                <td>
                <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0" data-bs-toggle="modal"
                            data-bs-target="#editdepartmentModal" title="Edit" onclick="editmodel('${item.sno}')">
                    <i class="mdi mdi-pencil fs-5"></i>
                </button>
                <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_delete_department" onclick="confirmDelete('${item.sno}','${item.department_name}')">
                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                </button>
                </td>
                
            </tr>
        `;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;

        const url = `/settings/department-setting?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1,res.common_date_format));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="3" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

</script>
<!-- list Handling End-->

<script>
    function editmodel(categoryId) {

            currentCategoryId = categoryId;
            fetch(`/department_edit/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const dept = data.data;

                        document.getElementById('edit_department_name').value = dept.department_name;
                        document.getElementById('edit_department_desc').value = dept.department_desc;
           
                    } else {
                        console.error('Error fetching internet:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching internet:', error);
                });
        }


        function updatedepartment() {
            const id = currentCategoryId;
            const department_name = document.getElementById('edit_department_name').value;
            const department_desc = document.getElementById('edit_department_desc').value;

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/department_update/${id}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        department_name: department_name,
                        department_desc: department_desc,

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Department Updated successfully!');
                         location.reload();
                    } else {
                        toastr.error('Department Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating internet:', error);

                });
        }

        document.getElementById('saveDepartment').addEventListener('button', function(event) {
            event.preventDefault();
            updatedepartment();
        });
</script>

<script>
    function updatelevelStatus(id, isChecked) {
        const reloadPage = tableState.currentPage;
        const status = isChecked ? 0 : 1; // Set status based on checkbox state
        console.log(id);
        fetch(`/department_status/${id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Department status Updated successfully!');
                        loadThemes(reloadPage);
                } else {
                    console.error('Error updating department status:', data.message);
                    toastr.error('Failed to update department');
                }
            })
            .catch(error => {
                console.error('Error updating department status:', error);
            });
    }


    function confirmDelete(id, name) {
        document.querySelector('#kt_modal_delete_department .btn-danger').setAttribute(
            'data-id', id);
        $('#delete_message').html('You want to delete <br> <b class="text-danger"> ' + name +
            '</b> Department ?');
    }

    function deletelevel() {

        var id = document.querySelector('#kt_modal_delete_department .btn-danger').getAttribute('data-id');

        fetch('/delete_department/' + id, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Department Deleted successfully!');
                    location.reload();

                } else {

                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
</script>

<script>
    function AddvalidationForm() {
        let err=0;  
        var department_name=$('#department_name').val();
        var department_desc=$('#department_desc').val();
        
        if(department_name == ""){
            $('#department_name_err').text('Department Name is required')
            err++
        }

        if (err>0){
            return false;
        }else{ 
            AddDepartment();
        }
    }

 
    function AddDepartment() {
   
        const form = document.getElementById("adddepartmentsettingForm");
        
        const submitBtn = document.getElementById("saveDepartment");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                 url: "{{ route('add_department_setting') }}",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    toastr.success('Department Added successfully!');
                      location.reload();
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    toastr.error('Department Failed to Add!');
                    submitBtn.disabled = false;
                }
            });
        }
    }
</script>

@endsection
