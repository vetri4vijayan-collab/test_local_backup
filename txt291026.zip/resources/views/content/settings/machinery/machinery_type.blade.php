@extends('layouts/layoutMaster')

@section('title', 'Machinery Type')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'machinery'])

<div class="row">

    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.machinery-settings-header')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-state-machine fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Machinery Type</h5>
                        <small class="text-muted">
                            Manage machinery type details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#addMachineryTypeModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Machinery Type</span>
                </button>
            </div>
            <div class="card-body p-3">
                {{-- Search --}}
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search Machinery Type">
                        </div>
                    </div>
                </div>
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0" id="bankTable">
                        <thead>
                            <tr class="bg-light">
                                <th class="text-nowrap">Machinery Type</th>
                                <th class="text-nowrap">Description</th>
                                <th class="text-nowrap">Status</th>
                                <th class="text-end"> Actions </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Excavator</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Heavy equipment used for digging, trenching, earthmoving, and excavation works.">
                                        Heavy equipment used for digging, trenching, earthmoving, and excavation works.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus1"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Backhoe Loader</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Versatile machine used for excavation, loading, trenching, and general site work.">
                                        Versatile machine used for excavation, loading, trenching, and general site work.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus2"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Wheel Loader</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Machine used for loading, transporting, and handling loose construction materials.">
                                        Machine used for loading, transporting, and handling loose construction materials.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus3"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Bulldozer</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Heavy equipment used for earthmoving, grading, leveling, and site preparation.">
                                        Heavy equipment used for earthmoving, grading, leveling, and site preparation.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus4"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Motor Grader</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Machine used for leveling, grading, and preparing surfaces for roads and construction works.">
                                        Machine used for leveling, grading, and preparing surfaces for roads and construction works.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus5"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Crane</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Lifting equipment used to move and position heavy materials and equipment at construction sites.">
                                        Lifting equipment used to move and position heavy materials and equipment at construction sites.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus6"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Forklift</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Material-handling machine used for lifting, moving, and stacking materials over short distances.">
                                        Material-handling machine used for lifting, moving, and stacking materials over short distances.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus7"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Concrete Mixer</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Equipment used for mixing cement, aggregates, sand, and water to produce concrete.">
                                        Equipment used for mixing cement, aggregates, sand, and water to produce concrete.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus8"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Concrete Pump</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Machine used to transport and place concrete through pipelines to difficult-to-reach locations.">
                                        Machine used to transport and place concrete through pipelines to difficult-to-reach locations.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus9"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">Road Roller</span>
                                </td>

                                <td style="min-width: 100px; max-width: 250px;">
                                    <span class="d-block text-truncate"
                                        title="Compaction equipment used to compact soil, gravel, asphalt, and other road construction surfaces.">
                                        Compaction equipment used to compact soil, gravel, asphalt, and other road construction surfaces.
                                    </span>
                                </td>

                                <td class="text-nowrap">
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="MachineryStatus10"
                                            checked>
                                    </div>
                                </td>

                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#editMachineryTypeModal"
                                            title="Edit">
                                            <i class="mdi mdi-pencil-outline"></i>
                                        </button>

                                        <button type="button"
                                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal"
                                            data-bs-target="#deleteMachineryTypeModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addMachineryTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="addMachineryTypeModalTitle">
                    Add Machinery Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="bankForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-12">
                            <label for="bank_name" class="form-label fw-semibold">
                                Machinery Type Name
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="bank_name" class="form-control" placeholder="Enter Machinery Type name"
                                required>
                        </div>
                        <div class="col-12 col-md-12">
                            <label for="ifsc_code" class="form-label fw-semibold">
                                Description
                                <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="">
                            Save Machinery Type
                        </span>

                    </button>

                </div>
            </form>

        </div>

    </div>

</div>

<div class="modal fade" id="editMachineryTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="addMachineryTypeModalTitle">
                    Update Machinery Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="bankForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-12">
                            <label for="bank_name" class="form-label fw-semibold">
                                Machinery Type Name
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="bank_name" class="form-control" placeholder="Enter Machinery Type name"
                                required>
                        </div>
                        <div class="col-12 col-md-12">
                            <label for="ifsc_code" class="form-label fw-semibold">
                                Description
                                <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="">
                            Update Machinery Type
                        </span>

                    </button>

                </div>
            </form>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- Delete Confirmation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="deleteMachineryTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Machinery Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-state-machine fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="deleteBankName">
                        this Machinery Type
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>



@push('styles')
<style>
/* =========================================================
   Bank Settings - Full Width + Zoom Safe
   ========================================================= */

/* Main content always uses available row width */
.col-12.col-md-8.col-lg-9 {
    min-width: 0;
    margin-left: 20%;
}


/* Desktop and above */
@media (min-width: 768px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        min-width: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
    }

}


/* Card */
.col-12.col-md-8.col-lg-9 .card {
    width: 100%;
    max-width: 100%;
}


/* Card body */
.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}


/* Table container */
.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}


/* Table */
.col-12.col-md-8.col-lg-9 #bankTable {
    width: 100%;
    min-width: 850px;
}


/* =========================================================
   Mobile
   ========================================================= */

@media (max-width: 767.98px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
    }

    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

}


/* =========================================================
   Small Mobile
   ========================================================= */

@media (max-width: 575.98px) {

    .col-12.col-md-8.col-lg-9 {
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .card-header {
        align-items: flex-start !important;
    }

    .card-header>div:first-child {
        width: 100%;
    }

    .card-header>button {
        width: 100%;
        justify-content: center;
    }

}


/* =========================================================
   Modal - Zoom / Small Screen Safe
   ========================================================= */

.modal-dialog {
    max-width: calc(100% - 2rem);
}

.modal-content {
    width: 100%;
    max-width: 100%;
}


/* Modal form columns */
@media (max-width: 767.98px) {

    #addMachineryTypeModal .row.g-3>[class*="col-md-6"] {
        width: 100%;
    }

}


/* =========================================================
   Prevent flex children from creating unexpected width
   ========================================================= */

.row {
    min-width: 0;
}

.row>[class*="col-"] {
    min-width: 0;
}
</style>
@endpush



@endsection
