
@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="row g-3 g-md-4 mb-4">

    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Total Fleet Size
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-break"
                        style="color:#0C3C62;">
                        5 Heavy Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Monitored in Master Register
                </span>

            </div>

        </div>

    </div>


    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Operational Ratio
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-success">
                        40%
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-dark small text-break">
                    2 Units Active on Site
                </span>

            </div>

        </div>

    </div>


    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Active Site Deployments
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-danger">
                        3 Projects
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Engineers &amp; Operators assigned
                </span>

            </div>

        </div>

    </div>


    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Maintenance Overhaul
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-warning">
                        2 Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small">
                    In Workshop / Service Bay
                </span>

            </div>

        </div>

    </div>

</div>


<div class="card shadow-sm rounded-2 mb-0">

   
<div class="card-body pt-3 pb-0 p-md-4">

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">

        <div class="flex-grow-1">

            <h5 class="mb-1 fw-bold text-primary">
                Maintenance &amp; Workshop Service Register
            </h5>

            <p class="text-muted mb-0 small">
                Overhauls, component replacements, preventive maintenance &amp; breakdown logs
            </p>

        </div>

        <button type="button"
            class="btn btn-primary btn-sm settings-tab-pill d-inline-flex align-items-center flex-shrink-0"
            data-bs-toggle="modal"
            data-bs-target="#serviceBayModal">

            <span class="mdi mdi-plus me-2"></span>

            Dispatch to Service Bay

        </button>

    </div>
</div>


    <div class="deployment-table-wrapper">

        <table class="table deployment-table maintenance-table align-middle mb-0">

            <thead class="fw-semibold text-black bg-light">

                <tr>

                    <th class="text-start">
                        Service ID
                    </th>

                    <th class="text-start">
                        Date
                    </th>

                    <th class="text-start">
                        Machine Ref
                    </th>

                    <th class="text-start">
                        Service Type
                    </th>

                    <th class="text-start">
                        Workshop / Mechanic
                    </th>

                    <th class="text-start">
                        Parts Replaced
                    </th>

                    <th class="text-start">
                        Total Cost
                    </th>

                    <th class="text-start">
                        Status
                    </th>

                </tr>

            </thead>


            <tbody>

                <tr>

                    <td>
                        <span class="assignment-id text-primary fw-bold">
                            SRV-301
                        </span>
                    </td>

                    <td>
                        <span class="date-value">
                            2026-07-15
                        </span>
                    </td>

                    <td>
                        <div class="machine-name">
                            Caterpillar 320D Excavator
                        </div>
                    </td>

                    <td>
                        <span class="service-type-badge">
                            Scheduled 500-Hr Overhaul
                        </span>
                    </td>

                    <td>
                        <div class="workshop-name">
                            Central Equipment Maintenance Yard
                        </div>

                        <div class="mechanic-name">
                            M. Senthil (Lead Heavy Mechanic)
                        </div>
                    </td>

                    <td>
                        <span class="parts-text">
                            Hydraulic Filters, Engine Oil 15W40, Air Filter Cartridge
                        </span>
                    </td>

                    <td>
                        <span class="cost-value">
                            $1,250
                        </span>
                    </td>

                    <td>
                        <span class="maintenance-status completed">
                            Completed &amp; Certified
                        </span>
                    </td>

                </tr>


                <tr>

                    <td>
                        <span class="assignment-id text-primary fw-bold">
                            SRV-302
                        </span>
                    </td>

                    <td>
                        <span class="date-value">
                            2026-07-18
                        </span>
                    </td>

                    <td>
                        <div class="machine-name">
                            JCB 3DX Super Backhoe
                        </div>
                    </td>

                    <td>
                        <span class="service-type-badge emergency">
                            Emergency Hydraulic Hose Repair
                        </span>
                    </td>

                    <td>
                        <div class="workshop-name">
                            Villupuram Site Mobile Service Van
                        </div>

                        <div class="mechanic-name">
                            R. Murugan
                        </div>
                    </td>

                    <td>
                        <span class="parts-text">
                            High Pressure Hose 3/4&quot; x 2.5m, O-Rings
                        </span>
                    </td>

                    <td>
                        <span class="cost-value">
                            $420
                        </span>
                    </td>

                    <td>
                        <span class="maintenance-status in-service">
                            In Service Bay
                        </span>
                    </td>

                </tr>

            </tbody>

        </table>

    </div>

</div>



</div>

<div class="modal fade"
    id="serviceBayModal"
    tabindex="-1"
    aria-labelledby="serviceBayModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content border-0 shadow-lg rounded-3">

            <div class="modal-header bg-primary text-white">

                <div>

                    <h5 class="modal-title fw-bold mb-1 text-white"
                        id="serviceBayModalLabel">
                        New Entry - Machine / Vehicle Maintenance &amp; Service Details
                    </h5>

                    <small class="opacity-75">
                        Create a new maintenance and service record
                    </small>

                </div>

                <button type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            <div class="modal-body p-3 p-md-4">

                <form id="serviceBayForm">

                    <div class="row g-3">

                        <div class="col-12">

                            <label for="serviceMachineVehicle"
                                class="form-label fw-semibold">
                                Select Machine / Vehicle
                            </label>

                            <select id="serviceMachineVehicle"
                                name="machine_vehicle"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Machine / Vehicle
                                </option>

                                <option value="EQ-401">
                                    [EQ-401] Caterpillar 320 Excavator
                                </option>

                                <option value="EQ-402">
                                    [EQ-402] Liebherr LTM 1050 Mobile Crane
                                </option>

                                <option value="EQ-403">
                                    [EQ-403] Volvo FMX 440 Tipper Truck
                                </option>

                                <option value="EQ-404">
                                    [EQ-404] Schwing Stetter Concrete Pump
                                </option>

                                <option value="EQ-405">
                                    [EQ-405] Atlas Copco Air Compressor
                                </option>

                            </select>

                        </div>


                        <div class="col-12">

                            <label for="serviceType"
                                class="form-label fw-semibold">
                                Service Type
                            </label>

                            <select id="serviceType"
                                name="service_type"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Service Type
                                </option>

                                <option value="Scheduled Maintenance">
                                    Scheduled Maintenance
                                </option>

                                <option value="Breakdown Repair">
                                    Breakdown Repair
                                </option>

                                <option value="Engine Overhaul">
                                    Engine Overhaul
                                </option>

                                <option value="Hydraulic Pipeline Rectification">
                                    Hydraulic Pipeline Rectification
                                </option>

                            </select>

                        </div>


                        <div class="col-md-6">

                            <label for="workshopServiceVan"
                                class="form-label fw-semibold">
                                Workshop / Service Van
                            </label>

                            <input type="text"
                                id="workshopServiceVan"
                                name="workshop_service_van"
                                class="form-control"
                                placeholder="Enter workshop / service van"
                                required>

                        </div>


                        <div class="col-md-6">

                            <label for="estimatedServiceCost"
                                class="form-label fw-semibold">
                                Est. Service Cost ($)
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    $
                                </span>

                                <input type="number"
                                    id="estimatedServiceCost"
                                    name="estimated_service_cost"
                                    class="form-control"
                                    placeholder="Enter estimated cost"
                                    min="0"
                                    step="0.01"
                                    required>

                            </div>

                        </div>

                    </div>

                </form>

            </div>


            <div class="modal-footer border-top-0 px-3 px-md-4 pb-3">

                <button type="button"
                    class="btn btn-light border"
                    data-bs-dismiss="modal">

                    Close

                </button>

                <button type="submit"
                    form="serviceBayForm"
                    class="btn btn-primary d-inline-flex align-items-center">

                    <span class="mdi mdi-truck-check-outline me-2"></span>

                    Dispatch to Service Bay

                </button>

            </div>

        </div>

    </div>

</div>




<style>

.maintenance-table {
    width: 100%;
    table-layout: fixed;
}

.maintenance-table th:nth-child(1),
.maintenance-table td:nth-child(1) {
    width: 9%;
}

.maintenance-table th:nth-child(2),
.maintenance-table td:nth-child(2) {
    width: 10%;
}

.maintenance-table th:nth-child(3),
.maintenance-table td:nth-child(3) {
    width: 15%;
}

.maintenance-table th:nth-child(4),
.maintenance-table td:nth-child(4) {
    width: 16%;
}

.maintenance-table th:nth-child(5),
.maintenance-table td:nth-child(5) {
    width: 17%;
}

.maintenance-table th:nth-child(6),
.maintenance-table td:nth-child(6) {
    width: 17%;
}

.maintenance-table th:nth-child(7),
.maintenance-table td:nth-child(7) {
    width: 7%;
}

.maintenance-table th:nth-child(8),
.maintenance-table td:nth-child(8) {
    width: 9%;
}

.service-type-badge {
    display: inline-block;
    padding: 0.3rem 0.55rem;
    border-radius: 50rem;
    background: #e7f1ff;
    color: #0d6efd;
    font-size: 0.68rem;
    font-weight: 700;
    line-height: 1.35;
}

.service-type-badge.emergency {
    background: #fff3cd;
    color: #997404;
}

.settings-tab-pill {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex-shrink: 0;
    min-height: 38px;
    padding: 0.5rem 1rem !important;
    border-radius: 50rem !important;
    white-space: nowrap;
    font-size: 0.85rem;
    font-weight: 600;
    line-height: 1;
    text-decoration: none !important;
    transition: all 0.15s ease-in-out;
}
.workshop-name {
    display: block;
    color: #212529;
    font-size: 0.74rem;
    font-weight: 600;
    line-height: 1.4;
}

.mechanic-name {
    display: block;
    margin-top: 0.3rem;
    color: #6c757d;
    font-size: 0.68rem;
    font-weight: 500;
    line-height: 1.35;
}

.parts-text {
    display: block;
    color: #343a40;
    font-size: 0.72rem;
    font-weight: 500;
    line-height: 1.45;
}

.cost-value {
    display: inline-block;
    font-family: monospace;
    color: #212529;
    font-size: 0.75rem;
    font-weight: 700;
    white-space: nowrap;
}

.maintenance-status {
    display: inline-block;
    padding: 0.3rem 0.6rem;
    border-radius: 50rem;
    font-size: 0.68rem;
    font-weight: 700;
    line-height: 1.35;
}

.maintenance-status.completed {
    background: #d1e7dd;
    color: #146c43;
}

.maintenance-status.in-service {
    background: #fff3cd;
    color: #997404;
}

@media (max-width: 1199.98px) {

    .maintenance-table {
        min-width: 1250px;
        table-layout: auto;
    }

}

@media (max-width: 767.98px) {

    .maintenance-table {
        min-width: 1250px;
        font-size: 0.75rem;
    }

    .maintenance-table thead th,
    .maintenance-table tbody td {
        padding: 0.7rem 0.6rem;
    }

}

</style>

@endsection

