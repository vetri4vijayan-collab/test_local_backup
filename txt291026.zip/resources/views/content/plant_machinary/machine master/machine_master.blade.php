@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3 p-md-4">
        <div
            class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">

            <div class="d-flex align-items-center gap-3">
                <i class="mdi mdi-cog-outline fs-1 text-primary"></i>

                <div>
                    <h4 class="mb-1 fw-bold text-primary fs-3">
                        Machine Master
                    </h4>

                    <p class="text-muted mb-0 fs-7">
                        Machinery & Equipment Management
                    </p>
                </div>
            </div>

                        
            <div class="nav-scroll-wrapper">
                <div class="nav-scroll-container d-flex justify-content-end gap-2">

                    @php
                        $isMachineMasterActive = request()->is('plant-machinery/machine-master');
                        $isMachineAllocationActive = request()->is('plant-machinery/manage_flate');
                        $isMachineMaintenanceActive = request()->is('site/manage-store/machine_maintenance');
                    @endphp

                    <a href="{{ url('/plant-machinery/machine-master') }}"
                        class="btn btn-sm settings-tab-pill text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold {{ $isMachineMasterActive ? 'btn-primary' : 'btn-light border' }}">
                        <span class="mdi mdi-cog-outline me-2"></span>
                        Machine/Vehicle List
                    </a>

                    <a href="{{ url('/plant-machinery/manage_flate') }}"
                        class="btn btn-sm settings-tab-pill text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold {{ $isMachineAllocationActive ? 'btn-primary' : 'btn-light border' }}">
                        <span class="mdi mdi-truck-outline me-2"></span>
                        Manage Fleet View
                    </a>

                </div>
            </div>
        </div>
    </div>
</div>


<div class="row g-3 g-md-4 mb-4">

    <div class="col-12 col-sm-6 col-lg-3">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Total Fleet Size
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-break" style="color:#0C3C62;">
                        5 Heavy Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Monitored in Master Register
                </span>

            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-lg-3">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Operational Ratio
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-success">
                        40%
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-dark small text-break">
                    2 Units Active on Site
                </span>

            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-lg-3">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Active Site Deployments
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-danger">
                        3 Projects
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Engineers & Operators assigned
                </span>

            </div>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-lg-3">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Maintenance Overhaul
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-warning">
                        2 Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small ">
                    In Workshop / Service Bay
                </span>

            </div>
        </div>
    </div>

</div>


<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
    <div class="card-body p-3">

        <div
            class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center justify-content-between gap-2">

            {{-- Search --}}
            <div class="position-relative flex-shrink-0" style="width: 300px;">

                <span class="position-absolute top-50 start-0 translate-middle-y ps-3 text-muted"
                    style="pointer-events: none;">
                    <i class="mdi mdi-magnify"></i>
                </span>

                <input id="hr-search-field" type="text" placeholder="Search fleet record..."
                    class="form-control form-control-sm ps-5 bg-light border-0 rounded-3" autocomplete="off">

            </div>


            {{-- Create Button --}}
            <button type="button"
                class="btn btn-primary btn-sm settings-tab-pill d-inline-flex align-items-center justify-content-center px-3 flex-shrink-0"
                data-bs-toggle="modal" data-bs-target="#machineVehicleModal">

                <i class="mdi mdi-plus me-1"></i>
                Create Record

            </button>

        </div>

    </div>
</div>


<div class="row g-3">

    {{-- Card 1 --}}
    <div class="col-12 col-md-6 col-lg-4">
        <div class="card fleet-card border-0 shadow-sm rounded-4 bg-white h-100">

            <div class="card-body p-3 p-md-4">

                {{-- Header --}}
                <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start gap-3 mb-4">

                    <div class="d-flex align-items-start gap-3">

                        <div class="bg-primary bg-opacity-10 text-white rounded-3
                                    d-flex align-items-center justify-content-center flex-shrink-0"
                            style="width: 48px; height: 48px;">
                            <i class="mdi mdi-excavator fs-2"></i>
                        </div>

                        <div>
                            <div class="text-muted small mb-1">
                                EQ-401
                            </div>

                            <h5 class="fw-bold mb-1">
                                Caterpillar 320 Excavator
                            </h5>

                            <p class="text-muted small mb-0">
                                Excavation & Heavy Moving
                            </p>
                        </div>

                    </div>

                    <span class="badge rounded-pill bg-success bg-opacity-10 text-success px-3 py-2">
                        <i class="mdi mdi-circle me-1" style="font-size: 7px;"></i>
                        Operating
                    </span>

                </div>

                {{-- Fleet Metrics --}}
                <div class="row g-2 mb-4">

                    <div class="col-6">
                        <div class="bg-secondary-subtle rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Runtime Today
                            </div>
                            <div class="fw-bold fs-5">
                                6.5 hrs
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Lifetime Hours
                            </div>
                            <div class="fw-bold fs-5">
                                2450 hrs
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Fuel Rating
                            </div>
                            <div class="fw-bold fs-5">
                                18.5 L/hr
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Fuel Refilled Today
                            </div>
                            <div class="fw-bold fs-5">
                                150 L
                            </div>
                        </div>
                    </div>

                </div>

                {{-- Assignment & Maintenance --}}
                <div class="row g-3 border-top pt-3">

                    <div class="col-12">

                        <div class="text-muted small mb-1">
                            Assigned Operator
                        </div>

                        <div class="d-flex align-items-center gap-2">

                            <div class="rounded-circle bg-primary bg-opacity-10 text-white
                                        d-flex align-items-center justify-content-center flex-shrink-0"
                                style="width: 32px; height: 32px;">
                                <i class="mdi mdi-account-outline"></i>
                            </div>

                            <span class="fw-medium">
                                @Jayachandran Arumugam
                            </span>

                        </div>

                    </div>

                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-end">

                            {{-- Left: Next Overhaul --}}
                            <div>
                                <div class="text-muted small mb-1">
                                    Next Overhaul Due
                                </div>

                                <div class="small fw-semibold text-danger">
                                    <i class="mdi mdi-calendar-alert-outline me-1"></i>
                                    2026-09-15
                                </div>
                            </div>

                            {{-- Right: Manage Fleet --}}
                            <a href="/plant-machinery/manage_flate"
                                class="text-primary small fw-semibold text-decoration-none d-inline-flex align-items-center">
                                Manage Fleet
                                <i class="mdi mdi-arrow-right ms-1"></i>
                            </a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{-- Card 2 --}}
    <div class="col-12 col-md-6 col-lg-4">
        <div class="card fleet-card border-0 shadow-sm rounded-4 bg-white h-100">

            <div class="card-body p-3 p-md-4">

                <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start gap-3 mb-4">

                    <div class="d-flex align-items-start gap-3">

                        <div class="bg-primary bg-opacity-10 text-white rounded-3
                                    d-flex align-items-center justify-content-center flex-shrink-0"
                            style="width: 48px; height: 48px;">
                            <i class="mdi mdi-excavator fs-2"></i>
                        </div>

                        <div>
                            <div class="text-muted small mb-1">
                                EQ-402
                            </div>

                            <h5 class="fw-bold mb-1">
                                Komatsu PC210 Excavator
                            </h5>

                            <p class="text-muted small mb-0">
                                Earthwork & Excavation
                            </p>
                        </div>

                    </div>

                    <span class="badge rounded-pill bg-success bg-opacity-10 text-success px-3 py-2">
                        <i class="mdi mdi-circle me-1" style="font-size: 7px;"></i>
                        Operating
                    </span>

                </div>

                <div class="row g-2 mb-4">

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Runtime Today
                            </div>
                            <div class="fw-bold fs-5">
                                7.2 hrs
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Lifetime Hours
                            </div>
                            <div class="fw-bold fs-5">
                                3120 hrs
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Fuel Rating
                            </div>
                            <div class="fw-bold fs-5">
                                20.2 L/hr
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Fuel Refilled Today
                            </div>
                            <div class="fw-bold fs-5">
                                165 L
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row g-3 border-top pt-3">

                    <div class="col-12">

                        <div class="text-muted small mb-1">
                            Assigned Operator
                        </div>

                        <div class="d-flex align-items-center gap-2">

                            <div class="rounded-circle bg-primary bg-opacity-10 text-white
                                        d-flex align-items-center justify-content-center flex-shrink-0"
                                style="width: 32px; height: 32px;">
                                <i class="mdi mdi-account-outline"></i>
                            </div>

                            <span class="fw-medium">
                                @Suresh Kumar
                            </span>

                        </div>

                    </div>


                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-end">

                            {{-- Left: Next Overhaul --}}
                            <div>
                                <div class="text-muted small mb-1">
                                    Next Overhaul Due
                                </div>

                                <div class="small fw-semibold text-danger">
                                    <i class="mdi mdi-calendar-alert-outline me-1"></i>
                                    2026-09-15
                                </div>
                            </div>

                            {{-- Right: Manage Fleet --}}
                            <a href="/plant-machinery/manage_flate"
                                class="text-primary small fw-semibold text-decoration-none d-inline-flex align-items-center">
                                Manage Fleet
                                <i class="mdi mdi-arrow-right ms-1"></i>
                            </a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{-- Card 3 --}}
    <div class="col-12 col-md-6 col-lg-4">
        <div class="card fleet-card border-0 shadow-sm rounded-4 bg-white h-100">

            <div class="card-body p-3 p-md-4">

                <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start gap-3 mb-4">

                    <div class="d-flex align-items-start gap-3">

                        <div class="bg-primary bg-opacity-10 text-white rounded-3
                                    d-flex align-items-center justify-content-center flex-shrink-0"
                            style="width: 48px; height: 48px;">
                            <i class="mdi mdi-excavator fs-2"></i>
                        </div>

                        <div>
                            <div class="text-muted small mb-1">
                                EQ-403
                            </div>

                            <h5 class="fw-bold mb-1">
                                Volvo EC220 Excavator
                            </h5>

                            <p class="text-muted small mb-0">
                                Heavy Excavation
                            </p>
                        </div>

                    </div>

                    <span class="badge rounded-pill bg-warning bg-opacity-10 text-warning px-3 py-2">
                        <i class="mdi mdi-circle me-1" style="font-size: 7px;"></i>
                        Maintenance
                    </span>

                </div>

                <div class="row g-2 mb-4">

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Runtime Today
                            </div>
                            <div class="fw-bold fs-5">
                                4.8 hrs
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Lifetime Hours
                            </div>
                            <div class="fw-bold fs-5">
                                1890 hrs
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Fuel Rating
                            </div>
                            <div class="fw-bold fs-5">
                                17.8 L/hr
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded-3 p-3 h-100">
                            <div class="text-muted small mb-1">
                                Fuel Refilled Today
                            </div>
                            <div class="fw-bold fs-5">
                                120 L
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row g-3 border-top pt-3">

                    <div class="col-12">

                        <div class="text-muted small mb-1">
                            Assigned Operator
                        </div>

                        <div class="d-flex align-items-center gap-2">

                            <div class="rounded-circle bg-primary bg-opacity-10 text-white
                                        d-flex align-items-center justify-content-center flex-shrink-0"
                                style="width: 32px; height: 32px;">
                                <i class="mdi mdi-account-outline"></i>
                            </div>

                            <span class="fw-medium">
                                @Arun Prakash
                            </span>

                        </div>

                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        {{-- Next Overhaul --}}
                        <div>
                            <div class="text-muted small mb-1">
                                Next Overhaul Due
                            </div>
                            <div class="small fw-semibold text-danger">
                                <i class="mdi mdi-calendar-alert-outline me-1"></i>
                                2026-09-15
                            </div>
                        </div>
                        {{-- Manage Fleet --}}
                        <a href="/plant-machinery/manage_flate"
                            class="text-primary small fw-semibold text-decoration-none d-inline-flex align-items-center">
                            Manage Fleet
                            <i class="mdi mdi-arrow-right ms-1"></i>
                        </a>
                    </div>


                </div>
            </div>
        </div>

    </div>
</div>

<div class="modal fade" id="machineVehicleModal" tabindex="-1" aria-labelledby="machineVehicleModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-md">

        <div class="modal-content border-0 shadow-lg rounded-4">

            {{-- Modal Header --}}
            <div class="modal-header border-0 px-4 pt-4 pb-2">

                <div>
                    <h5 class="modal-title fw-bold mb-1" id="machineVehicleModalLabel">
                        New Entry - Machine / Vehicle Master Registry
                    </h5>

                    <p class="text-muted small mb-0">
                        Register a new machine or vehicle
                    </p>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>

            {{-- Modal Body --}}
            <div class="modal-body px-4 py-3">

                <form id="machineVehicleForm">

                    {{-- Machine / Vehicle Name --}}
                    <div class="mb-3">

                        <label for="machine_vehicle_name" class="form-label small fw-semibold">
                            Machine / Vehicle Name
                        </label>

                        <input type="text" class="form-control form-control-sm rounded-3" id="machine_vehicle_name"
                            name="machine_vehicle_name" placeholder="e.g. Komatsu PC300 Excavator" required>

                    </div>

                    {{-- Machine Type --}}
                    <div class="mb-3">

                        <label for="machine_type" class="form-label small fw-semibold">
                            Machine Type
                        </label>

                        <select class="form-select form-select-sm rounded-3" id="machine_type" name="machine_type"
                            required>

                            <option value="" selected disabled>
                                Select machine type
                            </option>

                            <option value="Excavator">
                                Excavator
                            </option>

                            <option value="Bulldozer">
                                Bulldozer
                            </option>

                            <option value="Loader">
                                Loader
                            </option>

                            <option value="Crane">
                                Crane
                            </option>

                            <option value="Tipper">
                                Tipper
                            </option>

                            <option value="Truck">
                                Truck
                            </option>

                            <option value="Other">
                                Other
                            </option>

                        </select>

                    </div>

                    {{-- Assigned Operator --}}
                    <div class="mb-3">

                        <label for="assigned_operator" class="form-label small fw-semibold">
                            Assigned Operator
                        </label>

                        <input type="text" class="form-control form-control-sm rounded-3" id="assigned_operator"
                            name="assigned_operator" placeholder="e.g. M. Sundaram" required>

                    </div>

                    {{-- Fuel Efficiency --}}
                    <div class="mb-3">

                        <label for="fuel_efficiency" class="form-label small fw-semibold">
                            Fuel Efficiency
                            <span class="text-muted fw-normal">
                                (L/hr)
                            </span>
                        </label>

                        <input type="number" class="form-control form-control-sm rounded-3" id="fuel_efficiency"
                            name="fuel_efficiency" placeholder="18" min="0" step="0.1" required>

                    </div>

                </form>

            </div>

            {{-- Modal Footer --}}
            <div class="modal-footer border-0 px-4 pb-4 pt-2">

                <button type="button" class="btn btn-light btn-sm rounded-3 px-3" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="submit" form="machineVehicleForm" class="btn btn-primary btn-sm rounded-3 px-4">

                    <i class="mdi mdi-plus me-1"></i>
                    Register Machine / Vehicle

                </button>

            </div>

        </div>

    </div>
</div>



<style>
.fleet-card {
    border: 1px solid transparent !important;
    transition: all 0.25s ease-in-out;
}

.fleet-card:hover {
    border-color: #0d3e88 !important;
    box-shadow: 0 0.5rem 1.5rem rgba(13, 110, 253, 0.15) !important;
    transform: translateY(-2px);
}


.nav-scroll-wrapper {
    width: 100%;
    overflow-x: auto;
    overflow-y: hidden;
    padding-bottom: 2px;
    scrollbar-width: thin;
}

.nav-scroll-container {
    width: max-content;
    min-width: 100%;
    white-space: nowrap;
}

.settings-tab-pill {
    min-height: 38px;
    white-space: nowrap;
    flex-shrink: 0;
    padding: 0.45rem 1rem !important;
    border-radius: 50rem !important;
    font-size: 0.85rem;
    font-weight: 500;
    line-height: 1.2;
    text-decoration: none;
    transition: all 0.15s ease;
}

.settings-tab-pill .mdi {
    font-size: 17px;
    line-height: 1;
}

.settings-tab-pill:hover {
    text-decoration: none;
}

</style>




<script>
document.addEventListener('DOMContentLoaded', function() {

    const searchInput = document.getElementById('hr-search-field');
    const fleetCards = document.querySelectorAll('.fleet-card');

    if (!searchInput || !fleetCards.length) {
        return;
    }

    searchInput.addEventListener('input', function() {

        const searchValue = this.value.trim().toLowerCase();

        fleetCards.forEach(function(card) {

            // Get all text inside the card
            const cardText = card.textContent.toLowerCase();

            // Show card if search text exists in card content
            if (cardText.includes(searchValue)) {
                card.closest('.col-12').style.display = '';
            } else {
                card.closest('.col-12').style.display = 'none';
            }

        });

    });

});

// Popup modal
document.addEventListener('DOMContentLoaded', function() {

    const form = document.getElementById('machineVehicleForm');

    form.addEventListener('submit', function(event) {

        event.preventDefault();

        const machineName = document.getElementById('machine_vehicle_name').value;
        const machineType = document.getElementById('machine_type').value;
        const operator = document.getElementById('assigned_operator').value;
        const fuelEfficiency = document.getElementById('fuel_efficiency').value;

        console.log({
            machineName,
            machineType,
            operator,
            fuelEfficiency
        });

        // Add your AJAX / Laravel submission here.
    });

});
</script>


@endsection