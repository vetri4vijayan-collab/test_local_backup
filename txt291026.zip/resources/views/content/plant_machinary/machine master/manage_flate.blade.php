@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3 p-md-4">
        <div
            class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">

            <div class="d-flex align-items-center gap-3">
                <i class="mdi mdi-cog-outline fs-1 text-primary"></i>

                <div>
                    <h4 class="mb-1 fw-bold text-primary fs-3">
                        Machine Master
                    </h4>

                    <p class="text-muted mb-0 fs-7">
                        Machinery & Equipment Management
                    </p>
                </div>
            </div>

             <div class="nav-scroll-wrapper">
                <div class="nav-scroll-container d-flex justify-content-end gap-2">

                    @php
                        $isMachineMasterActive = request()->is('plant-machinery/machine-master');
                        $isMachineAllocationActive = request()->is('plant-machinery/manage_flate');
                        $isMachineMaintenanceActive = request()->is('site/manage-store/machine_maintenance');
                    @endphp

                    <a href="{{ url('/plant-machinery/machine-master') }}"
                        class="btn btn-sm settings-tab-pill text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold {{ $isMachineMasterActive ? 'btn-primary' : 'btn-light border' }}">
                        <span class="mdi mdi-cog-outline me-2"></span>
                        Machine/Vehicle List
                    </a>

                    <a href="{{ url('/plant-machinery/manage_flate') }}"
                        class="btn btn-sm settings-tab-pill text-decoration-none d-inline-flex align-items-center justify-content-center fw-semibold {{ $isMachineAllocationActive ? 'btn-primary' : 'btn-light border' }}">
                        <span class="mdi mdi-truck-outline me-2"></span>
                        Manage Fleet View
                    </a>

                </div>
            </div>  

        </div>
    </div>
</div>


<div class="row g-3 g-md-4 mb-4">

    {{-- Total Fleet --}}
    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Total Fleet Size
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-break" style="color:#0C3C62;">
                        5 Heavy Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Monitored in Master Register
                </span>

            </div>

        </div>

    </div>


    {{-- Operational Ratio --}}
    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Operational Ratio
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-success">
                        40%
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-dark small text-break">
                    2 Units Active on Site
                </span>

            </div>

        </div>

    </div>


    {{-- Active Deployments --}}
    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Active Site Deployments
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-danger">
                        3 Projects
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Engineers & Operators assigned
                </span>

            </div>

        </div>

    </div>


    {{-- Maintenance --}}
    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Maintenance Overhaul
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-warning">
                        2 Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small">
                    In Workshop / Service Bay
                </span>

            </div>

        </div>

    </div>

</div>

<div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
    <div class="card-body p-3">
        <div
            class="d-flex flex-column flex-lg-row align-items-stretch align-items-lg-center justify-content-between gap-3">
            {{-- Search --}}
            <div class="position-relative flex-shrink-0 w-100 w-lg-auto" style="max-width: 300px;">
                <span class="position-absolute top-50 start-0 translate-middle-y ps-3 text-muted"
                    style="pointer-events: none;">

                    <i class="mdi mdi-magnify"></i>
                </span>
                <input id="hr-search-field" type="text" placeholder="Search fleet record..."
                    class="form-control form-control-sm ps-5 bg-light border-0 rounded-3" autocomplete="off">
            </div>

            {{-- Filter + Button --}}
            <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2 ms-lg-auto">
                {{-- Manage Fleet Unit --}}
                <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2">
                    <label for="fleet-unit-select" class="form-label mb-0 text-nowrap fw-semibold text-muted">
                        Manage Fleet Unit
                    </label>
                    <select id="fleet-unit-select" class="form-select form-select-sm bg-light border-0 rounded-3"
                        style="min-width: 250px; max-width: 450px;">
                        <option value="">
                            Select Fleet Unit
                        </option>
                        <option value="EQ-401">
                            [EQ-401] Caterpillar 320D Excavator (TN-09-CB-4821) - Operating
                        </option>
                        <option value="EQ-402">
                            [EQ-402] Komatsu PC210 Excavator (TN-10-CC-5732) - Operating
                        </option>
                        <option value="EQ-403">
                            [EQ-403] Volvo EC210 Excavator (TN-11-CD-6843) - Maintenance
                        </option>
                    </select>
                </div>
                {{-- New Fleet Unit --}}
                <button type="button"
                    class="btn btn-primary btn-sm settings-tab-pill d-inline-flex align-items-center justify-content-center px-3 flex-shrink-0"
                    data-bs-toggle="modal" data-bs-target="#machineVehicleModal">
                    <i class="mdi mdi-plus me-1"></i>
                    New Fleet Unit
                </button>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-12 col-lg-3">
        <div class="card border-0 shadow-sm rounded-4 bg-white h-100">
            <div class="card-body p-3">
                {{-- Sidebar Header --}}
                <div class="d-flex align-items-center justify-content-between mb-0 px-0">

                    <div>
                        <h6 class="mb-1 fw-bold text-dark">
                            Fleet Unit Details
                        </h6>

                        <small class="text-muted">
                            Consolidated & Section-wise Information
                        </small>
                    </div>

                    <!-- <button type="button" id="fleetEditBtn"
                        class="btn rounded-3 d-flex align-items-center justify-content-center fleet-edit-btn"
                        title="Edit Fleet Unit">

                        <i class="mdi mdi-pencil-outline fs-7"></i>
                    </button> -->

                    <div class="d-flex align-items-center gap-2">

                        <button type="button" id="fleetCancelBtn" class="btn btn-light btn-sm rounded-3 d-none">
                            Cancel
                        </button>

                        <button type="button" id="fleetSaveBtn" class="btn btn-primary btn-sm rounded-3 d-none">
                            <i class="mdi mdi-content-save-outline me-1"></i>
                            Save Changes
                        </button>

                        <button type="button" id="fleetEditBtn"
                            class="btn rounded-3 d-flex align-items-center justify-content-center fleet-edit-btn">
                            <i class="mdi mdi-pencil-outline fs-7"></i>
                        </button>

                    </div>





                </div>



                {{-- Sidebar Navigation --}}
                <ul class="nav nav-pills flex-column w-100 gap-1 fleet-details-nav" id="fleet-details-sidebar">



                    {{-- Base Details --}}
                    <li class="nav-item w-100">

                        <a href="#full-details" class="nav-link active d-flex align-items-center justify-content-start
                          w-100 gap-2 px-3 py-2 rounded text-start" data-section="full-details">

                            <i class="mdi mdi-file-document-outline fs-5 flex-shrink-0"></i>

                            <span class="fw-semibold text-start">
                                Full Consolidated View
                            </span>

                        </a>

                    </li>



                    {{-- Base Details --}}
                    <li class="nav-item w-100">

                        <a href="#base-details"
                            class="nav-link active d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start"
                            data-section="base-details">

                            <i class="mdi mdi-file-document-outline fs-5 flex-shrink-0"></i>

                            <span class="fw-semibold text-start">
                                Base Details
                            </span>

                        </a>

                    </li>


                    {{-- Owned Details --}}
                    <li class="nav-item w-100">

                        <a href="#owned-details"
                            class="nav-link text-muted d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start"
                            data-section="owned-details">

                            <i class="mdi mdi-domain fs-5 flex-shrink-0"></i>

                            <span class="fw-semibold text-start">
                                Owned Details
                            </span>

                        </a>

                    </li>


                    {{-- Insurance Details --}}
                    <li class="nav-item w-100">

                        <a href="#insurance-details"
                            class="nav-link text-muted d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start"
                            data-section="insurance-details">

                            <i class="mdi mdi-shield-check-outline fs-5 flex-shrink-0"></i>

                            <span class="fw-semibold text-start">
                                Insurance Details
                            </span>

                        </a>

                    </li>


                    {{-- EMI Details --}}
                    <li class="nav-item w-100">

                        <a href="#emi-details"
                            class="nav-link text-muted d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start"
                            data-section="emi-details">

                            <i class="mdi mdi-cash-multiple fs-5 flex-shrink-0"></i>

                            <span class="fw-semibold text-start">
                                EMI Details
                            </span>

                        </a>

                    </li>


                    {{-- Service Details --}}
                    <li class="nav-item w-100">

                        <a href="#service-details"
                            class="nav-link text-muted d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start"
                            data-section="service-details">

                            <i class="mdi mdi-wrench-outline fs-5 flex-shrink-0"></i>

                            <span class="fw-semibold text-start">
                                Service Details
                            </span>

                        </a>

                    </li>

                </ul>

            </div>

        </div>

    </div>
    <div class="col-12 col-lg-9">
        <div class="card border-0 shadow-sm rounded-4 bg-white">
            <div class="card-body p-3 p-md-4">
                <div id="fleet-content">
                    <div id="base-details" class="fleet-section" data-section-content>

                        {{-- Section Header --}}
                        <div
                            class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-3 mb-4">

                            {{-- Left --}}
                            <div class="d-flex align-items-center gap-3">

                                <div class="d-flex align-items-center justify-content-center bg-primary-subtle text-primary rounded-3 flex-shrink-0"
                                    style="width:42px;height:42px;">

                                    <i class="mdi mdi-file-document-outline fs-3"></i>

                                </div>

                                <div>

                                    <h5 class="mb-1 fw-bold text-dark">
                                        Section 1: Base Machine & Technical Identification Details
                                    </h5>

                                </div>

                            </div>


                            {{-- Reference --}}
                            <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2 flex-shrink-0">
                                REF: EQ-401
                            </span>

                        </div>


                        {{-- Machine Details --}}
                        <div class="row g-4">


                            {{-- Machine / Fleet Code --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Machine / Fleet Code
                                    </label>

                                    <div class="fw-semibold text-dark " data-field="machine_code">
                                        EQ-401
                                    </div>

                                </div>

                            </div>


                            {{-- Machine / Vehicle Name --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Machine / Vehicle Name
                                    </label>

                                    <div class="fw-bold text-dark" data-field="machine_name">
                                        Caterpillar 320D Excavator
                                    </div>

                                </div>

                            </div>


                            {{-- Machine Type --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Machine Type / Category
                                    </label>

                                    <div class="fw-semibold text-dark " data-field="machine_type">
                                        Excavator
                                    </div>

                                </div>

                            </div>


                            {{-- Registration --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Registration Number
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="registration_number">
                                        TN-09-CB-4821
                                    </div>

                                </div>

                            </div>


                            {{-- Chassis --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Chassis VIN Number
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="chassis_vin">
                                        CHS-CAT-9920184
                                    </div>

                                </div>

                            </div>


                            {{-- Engine --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Engine Serial Number
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="engine_serial">
                                        ENG-CAT-4820193
                                    </div>

                                </div>

                            </div>


                            {{-- Brand --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Make & Brand
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="brand">
                                        Caterpillar Inc.
                                    </div>

                                </div>

                            </div>


                            {{-- Model --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Model Variant
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="model">
                                        320D Series II Heavy Earthmover
                                    </div>

                                </div>

                            </div>


                            {{-- Manufacturing Year --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Manufacturing Year
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="manufacturing_year">
                                        2023
                                    </div>

                                </div>

                            </div>


                            {{-- Capacity --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Capacity & Specifications
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="capacity">
                                        20.5 Tons / 1.2 Cu.m Bucket
                                    </div>

                                </div>

                            </div>


                            {{-- Fuel --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Fuel Engine Type
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="fuel_type">
                                        Diesel
                                    </div>

                                </div>

                            </div>


                            {{-- Runtime --}}
                            <div class="col-12 col-md-6 col-xl-4">

                                <div class="bg-light rounded-3 px-3 py-2">

                                    <label class="text-muted small mb-1 d-block">
                                        Total Lifetime Runtime
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="runtime">
                                        1248 Hours / Km
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div id="owned-details" class="fleet-section d-none" data-section-content>
                        {{-- Section Header --}}
                        <div
                            class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-3 mb-4">
                            {{-- Left --}}
                            <div class="d-flex align-items-center gap-3">
                                <div class="d-flex align-items-center justify-content-center bg-primary-subtle text-primary rounded-3 flex-shrink-0"
                                    style="width:42px;height:42px;">
                                    <i class="mdi mdi-domain fs-3"></i>
                                </div>
                                <div>
                                    <h5 class="mb-1 fw-bold text-dark">
                                        Section 2: Ownership, Procurement & Asset Valuation Details
                                    </h5>
                                </div>
                            </div>
                            {{-- Reference --}}
                            <span class="badge bg-primary-subtle text-primary rounded-pill px-3 py-2 flex-shrink-0">
                                Company Owned
                            </span>

                        </div>


                        {{-- Ownership Details --}}
                        <div class="row g-3 g-md-4">

                            {{-- Ownership Classification --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Ownership Classification
                                    </label>

                                    <div class="fw-semibold text-dark text-break" data-field="ownership_type">
                                        Company Owned
                                    </div>

                                </div>
                            </div>


                            {{-- Acquisition Date --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Acquisition / Purchase Date
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="purchase_date">
                                        15-Apr-2023
                                    </div>

                                </div>
                            </div>


                            {{-- Supplying Vendor --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Supplying Vendor / Dealer
                                    </label>

                                    <div class="fw-semibold text-dark text-break" data-field="vendor">
                                        GMMCO Caterpillar South India
                                    </div>

                                </div>
                            </div>


                            {{-- Purchase Cost --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Purchase Cost (Invoice Value)
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="purchase_cost">
                                        ₹7,800,000
                                    </div>

                                </div>
                            </div>


                            {{-- Invoice / PO --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Invoice / PO Reference
                                    </label>

                                    <div class="fw-semibold text-dark text-break" data-field="invoice_reference">
                                        INV-GMM-2023-882
                                    </div>

                                </div>
                            </div>


                            {{-- Current Location --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Current Deployed Location
                                    </label>

                                    <div class="fw-semibold text-dark text-break" data-field="current_location">
                                        NH-45 Bridge Expansion (Pier P4 Foundation Site)
                                    </div>

                                </div>
                            </div>


                            {{-- Assigned Operator --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Assigned Operator
                                    </label>

                                    <div class="fw-semibold text-dark text-break" data-field="assigned_operator">
                                        K. Velu (Senior Operator)
                                    </div>

                                </div>
                            </div>


                            {{-- Current Book Value --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Current Book Value (Depreciated)
                                    </label>

                                    <div class="fw-semibold text-success" data-field="book_value">
                                        ₹6,250,000
                                        <span class="text-muted fw-normal small">
                                            (15% p.a.)
                                        </span>
                                    </div>

                                </div>
                            </div>

                        </div>


                    </div>

                    <div id="insurance-details" class="fleet-section d-none" data-section-content>
                        {{-- Section Header --}}
                        <div class="d-flex flex-column flex-sm-row
                          align-items-start align-items-sm-center
                          justify-content-between gap-3 mb-4">

                            {{-- Left: Icon + Title --}}
                            <div class="d-flex align-items-center gap-3">

                                <div class="d-flex align-items-center justify-content-center
                                    bg-primary-subtle text-primary rounded-3 flex-shrink-0"
                                    style="width:42px;height:42px;">

                                    <i class="mdi mdi-shield-check-outline fs-3"></i>

                                </div>

                                <div>
                                    <h5 class="mb-1 fw-bold text-dark">
                                        Section 3: Insurance Policy Coverage & Compliance Details
                                    </h5>
                                </div>

                            </div>

                            {{-- Right: Reference / Status --}}
                            <span class="badge bg-success-subtle text-success
                                    rounded-pill px-3 py-2 flex-shrink-0">
                                Active & Valid
                            </span>

                        </div>


                        {{-- Insurance Details --}}
                        <div class="row g-3 g-md-4">

                            {{-- Insurance Company --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Insurance Company
                                    </label>

                                    <div class="fw-semibold text-dark text-break" data-field="insurance_provider">
                                        ICICI Lombard General Insurance
                                    </div>

                                </div>
                            </div>


                            {{-- Policy Number --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Policy Number
                                    </label>

                                    <div class="fw-semibold text-dark text-break" data-field="policy_number">
                                        POL-2026-9920148
                                    </div>

                                </div>
                            </div>


                            {{-- Coverage Type --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Coverage Type
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="coverage_type">
                                        Comprehensive
                                    </div>

                                </div>
                            </div>


                            {{-- Insured Declared Value --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Insured Declared Value (IDV)
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="idv">
                                        ₹7,000,000
                                    </div>

                                </div>
                            </div>


                            {{-- Annual Premium --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Annual Premium Amount
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="annual_premium">
                                        ₹85,000
                                    </div>

                                </div>
                            </div>


                            {{-- Policy Commencement Date --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Policy Commencement Date
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="policy_start">
                                        10-Jan-2026
                                    </div>

                                </div>
                            </div>


                            {{-- Policy Expiry Date --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Policy Expiry Date
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="policy_expiry">
                                        09-Jan-2027
                                    </div>

                                </div>
                            </div>


                            {{-- Claim Contact Desk --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Claim Contact Desk
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="claim_contact">
                                        +91 98401 22334
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                    <div id="emi-details" class="fleet-section d-none" data-section-content>

                        {{-- Section Header --}}
                        <div
                            class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-3 mb-4">

                            <div class="d-flex align-items-center gap-3">

                                <div class="d-flex align-items-center justify-content-center
                        bg-primary-subtle text-primary rounded-3 flex-shrink-0" style="width:42px;height:42px;">

                                    <i class="mdi mdi-cash-multiple fs-3"></i>

                                </div>

                                <div>
                                    <h5 class="mb-1 fw-bold text-dark">
                                        Section 4: Equipment Loan & EMI Schedule Details
                                    </h5>
                                </div>

                            </div>

                            <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2">
                                Active EMI
                            </span>

                        </div>


                        {{-- EMI Details --}}
                        <div class="row g-4">

                            {{-- Financing Bank / NBFC --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Financing Bank / NBFC
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="financing_bank">
                                        Sundaram Finance Heavy Fleet Division
                                    </div>

                                </div>
                            </div>


                            {{-- Loan Account Number --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Loan Account Number
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="loan_account">
                                        LA-SUN-4820194
                                    </div>

                                </div>
                            </div>


                            {{-- Total Loan Sanctioned --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Total Loan Sanctioned
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="loan_sanctioned">
                                        ₹5,000,000
                                    </div>

                                </div>
                            </div>


                            {{-- Down Payment Paid --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Down Payment Paid
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="down_payment">
                                        ₹2,800,000
                                    </div>

                                </div>
                            </div>


                            {{-- Monthly EMI --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Monthly EMI Outflow
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="monthly_emi">
                                        ₹118,500
                                    </div>

                                </div>
                            </div>


                            {{-- EMI Due Cycle --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        EMI Due Cycle Day
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="emi_due_day">
                                        5th of Month
                                    </div>

                                </div>
                            </div>


                            {{-- Tenure Progress --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Tenure Paid Progress
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="tenure_progress">
                                        28 of 48 Months
                                    </div>

                                </div>
                            </div>


                            {{-- Next EMI Due Date --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Next EMI Due Date
                                    </label>

                                    <div class="fw-semibold text-danger" data-field="next_emi_date">
                                        05-Aug-2026
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                    <div id="service-details" class="fleet-section d-none" data-section-content>

                        {{-- Section Header --}}
                        <div
                            class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-3 mb-4">

                            <div class="d-flex align-items-center gap-3">

                                <div class="d-flex align-items-center justify-content-center bg-primary-subtle text-primary rounded-3 flex-shrink-0"
                                    style="width:42px;height:42px;">

                                    <i class="mdi mdi-wrench-outline fs-3"></i>

                                </div>

                                <div>
                                    <h5 class="mb-1 fw-bold text-dark">
                                        Section 5: Preventive Maintenance, Service & Overhaul Details
                                    </h5>

                                    <small class="text-muted">
                                        Track service logs, component repairs, meter hours & workshop records
                                    </small>
                                </div>

                            </div>

                            {{-- Service Action --}}
                            <button type="button"
                                class="btn btn-primary btn-sm rounded-3 d-inline-flex align-items-center justify-content-center px-3 flex-shrink-0"
                                data-bs-toggle="modal" data-bs-target="#serviceLogModal">
                                <i class="mdi mdi-plus me-1"></i>
                                Record New Service Log
                            </button>

                        </div>


                        {{-- Maintenance Details --}}
                        <div class="row g-4">

                            {{-- Recommended Service Interval --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Recommended Service Interval
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="service_interval">
                                        Every 250 Operating Hours / 3 Months
                                    </div>

                                </div>
                            </div>


                            {{-- Last Service Date & Meter --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Last Service Date & Meter
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="last_service">
                                        15-Jul-2026 @ 1240 Hrs
                                    </div>

                                </div>
                            </div>


                            {{-- Next Due Service --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Next Due Service Date & Target
                                    </label>

                                    <div class="fw-semibold text-warning" data-field="next_service">
                                        15-Sep-2026 @ 1490 Hrs
                                    </div>

                                </div>
                            </div>


                            {{-- Preferred Workshop --}}
                            <div class="col-12 col-md-6 col-xl-8">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Preferred Workshop / Service Yard
                                    </label>

                                    <div class="fw-semibold text-dark" data-field="workshop">
                                        Central Equipment Maintenance Yard, Villupuram
                                    </div>

                                </div>
                            </div>


                            {{-- Warranty --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <div class="bg-light rounded-3 px-3 py-2 h-100">

                                    <label class="text-muted small mb-1 d-block">
                                        Factory / Dealer Warranty
                                    </label>

                                    <div class="fw-semibold text-success" data-field="warranty">
                                        Extended Warranty
                                    </div>

                                </div>
                            </div>


                            {{-- Service History --}}
                            <div class="col-12">
                                <div class="bg-light rounded-3 px-3 py-3">

                                    <div class="col-12">
                                        <div class="bg-light rounded-3 px-3 py-3">

                                            {{-- Existing Header --}}
                                            <div
                                                class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-2">

                                                <div>
                                                    <label class="text-muted small mb-1 d-block">
                                                        Service & Maintenance Overhaul History
                                                    </label>

                                                    <div class="fw-semibold text-dark">
                                                        2 Service Records
                                                    </div>
                                                </div>

                                                <div class="d-flex align-items-center gap-2">

                                                    <span
                                                        class="badge bg-primary-subtle text-primary rounded-pill px-3 py-2">
                                                        2 Records
                                                    </span>

                                                    {{-- Dropdown Icon --}}
                                                    <button type="button"
                                                        class="btn btn-sm p-1 border-0 bg-transparent text-muted"
                                                        data-bs-toggle="collapse" data-bs-target="#serviceHistoryTable"
                                                        aria-expanded="false" aria-controls="serviceHistoryTable"
                                                        title="View Service Records">
                                                        <i class="mdi mdi-chevron-down fs-5 service-history-icon"></i>
                                                    </button>

                                                </div>

                                            </div>


                                            {{-- Service Table --}}
                                            <div id="serviceHistoryTable" class="collapse mt-3">

                                                <div class="table-responsive">

                                                    <table
                                                        class="table table-sm table-bordered align-middle mb-0 bg-white">

                                                        <thead class="table-light">
                                                            <tr>

                                                                <th class="text-nowrap small">
                                                                    Service Ref
                                                                </th>

                                                                <th class="text-nowrap small">
                                                                    Service Date
                                                                </th>

                                                                <th class="text-nowrap small">
                                                                    Service Type
                                                                </th>

                                                                <th class="text-nowrap small">
                                                                    Workshop / Lead Mechanic
                                                                </th>

                                                                <th class="text-nowrap small">
                                                                    Parts Replaced
                                                                </th>

                                                                <th class="text-nowrap small text-end">
                                                                    Total Cost
                                                                </th>

                                                                <th class="text-nowrap small">
                                                                    Meter Hrs
                                                                </th>

                                                                <th class="text-nowrap small">
                                                                    Status
                                                                </th>

                                                            </tr>
                                                        </thead>

                                                        <tbody>

                                                            {{-- Record 1 --}}
                                                            <tr>

                                                                <td class="fw-semibold text-primary">
                                                                    SRV-301
                                                                </td>

                                                                <td class="text-nowrap">
                                                                    15-Jul-2026
                                                                </td>

                                                                <td>
                                                                    Scheduled 500-Hr Overhaul
                                                                </td>

                                                                <td>
                                                                    <div class="fw-semibold">
                                                                        Central Yard Service Bay
                                                                    </div>

                                                                    <small class="text-muted">
                                                                        M. Senthil (Lead Heavy Mechanic)
                                                                    </small>
                                                                </td>

                                                                <td>
                                                                    Hydraulic Filters, Engine Oil 15W40,
                                                                    Air Filter Cartridge
                                                                </td>

                                                                <td class="text-end text-nowrap fw-semibold">
                                                                    ₹12,500
                                                                </td>

                                                                <td class="text-nowrap">
                                                                    1240 Hrs
                                                                </td>

                                                                <td>
                                                                    <span
                                                                        class="badge bg-success-subtle text-success rounded-pill px-2 py-1">
                                                                        Completed
                                                                    </span>
                                                                </td>

                                                            </tr>


                                                            {{-- Record 2 --}}
                                                            <tr>

                                                                <td class="fw-semibold text-primary">
                                                                    SRV-201
                                                                </td>

                                                                <td class="text-nowrap">
                                                                    10-Apr-2026
                                                                </td>

                                                                <td>
                                                                    Hydraulic Pressure Calibration
                                                                </td>

                                                                <td>
                                                                    <div class="fw-semibold">
                                                                        Mobile Van Yard
                                                                    </div>

                                                                    <small class="text-muted">
                                                                        R. Murugan
                                                                    </small>
                                                                </td>

                                                                <td>
                                                                    O-Rings & High Pressure Seals
                                                                </td>

                                                                <td class="text-end text-nowrap fw-semibold">
                                                                    ₹4,500
                                                                </td>

                                                                <td class="text-nowrap">
                                                                    980 Hrs
                                                                </td>

                                                                <td>
                                                                    <span
                                                                        class="badge bg-success-subtle text-success rounded-pill px-2 py-1">
                                                                        Completed
                                                                    </span>
                                                                </td>

                                                            </tr>

                                                        </tbody>

                                                    </table>

                                                </div>

                                            </div>

                                        </div>
                                    </div>


                                </div>
                            </div>

                        </div>

                    </div>



                </div>

            </div>

        </div>

    </div>

</div>

<div class="modal fade" id="machineVehicleModal" tabindex="-1" aria-labelledby="machineVehicleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 rounded-4 shadow">

            <!-- Header -->
            <div class="modal-header px-4 py-3 border-bottom bg-primary">
                <div>
                    <h5 class="modal-title fw-bold mb-1 text-white" id="machineVehicleModalLabel">
                        Create New Fleet Machine / Vehicle Unit
                    </h5>

                    <p class="small mb-0 text-white">
                        Update base, owned, insurance, EMI and service specs
                    </p>
                </div>

                <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Body -->
            <div class="modal-body p-4">

                <!-- 1. Base Details -->
                <div class="mb-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span
                            class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width: 28px; height: 28px;">
                            1
                        </span>

                        <h6 class="fw-bold mb-0">
                            Base Details
                        </h6>
                    </div>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Fleet / Machine Code
                            </label>

                            <input type="text" class="form-control" value="EQ-405" placeholder="e.g. EQ-405" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Machine Name
                            </label>

                            <input type="text" class="form-control" placeholder="e.g. Caterpillar 320D" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Machine Category
                            </label>

                            <select class="form-select">
                                <option value="">
                                    Select category
                                </option>
                                <option>Excavator</option>
                                <option>Backhoe Loader</option>
                                <option>Crane</option>
                                <option>Bulldozer</option>
                                <option>Loader</option>
                                <option>Truck</option>
                                <option>Van</option>
                                <option>Car</option>
                                <option>Other</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Registration No
                            </label>

                            <input type="text" class="form-control" placeholder="e.g. TN-09-CB-4821" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Chassis VIN No
                            </label>

                            <input type="text" class="form-control" placeholder="Enter chassis VIN number" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Engine No
                            </label>

                            <input type="text" class="form-control" placeholder="Enter engine number" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Make / Brand
                            </label>

                            <input type="text" class="form-control" value="Caterpillar Inc."
                                placeholder="e.g. Caterpillar Inc." />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Model Variant
                            </label>

                            <input type="text" class="form-control" placeholder="Enter model variant" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Mfg Year
                            </label>

                            <input type="number" class="form-control" value="2026" placeholder="YYYY" />
                        </div>

                    </div>
                </div>

                <hr class="my-4">

                <!-- 2. Owned Details -->
                <div class="mb-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span
                            class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width: 28px; height: 28px;">
                            2
                        </span>

                        <h6 class="fw-bold mb-0">
                            Owned Details
                        </h6>
                    </div>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Ownership Type
                            </label>

                            <select class="form-select">
                                <option>Company Owned</option>
                                <option>Leased</option>
                                <option>Financed</option>
                                <option>Rented</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Purchase Date
                            </label>

                            <input type="date" class="form-control" value="2026-09-07" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Purchase Cost (₹)
                            </label>

                            <input type="number" class="form-control" value="5000000"
                                placeholder="Enter purchase cost" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Vendor / Dealer Name
                            </label>

                            <input type="text" class="form-control" placeholder="Enter vendor / dealer name" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Current Site Location
                            </label>

                            <input type="text" class="form-control" value="Central Store Yard"
                                placeholder="Enter current location" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Assigned Operator
                            </label>

                            <select class="form-select">
                                <option>Unassigned</option>
                                <option>Operator 1</option>
                                <option>Operator 2</option>
                                <option>Operator 3</option>
                            </select>
                        </div>

                    </div>
                </div>

                <hr class="my-4">

                <!-- 3. Insurance Details -->
                <div class="mb-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span
                            class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width: 28px; height: 28px;">
                            3
                        </span>

                        <h6 class="fw-bold mb-0">
                            Insurance Details
                        </h6>
                    </div>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Insurance Provider
                            </label>

                            <input type="text" class="form-control" value="ICICI Lombard"
                                placeholder="Enter insurance provider" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Policy Number
                            </label>

                            <input type="text" class="form-control" placeholder="Enter policy number" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Annual Premium (₹)
                            </label>

                            <input type="number" class="form-control" value="65000"
                                placeholder="Enter annual premium" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Policy Expiry Date
                            </label>

                            <input type="date" class="form-control" value="2027-07-30" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Insurance Status
                            </label>

                            <select class="form-select">
                                <option>Active & Valid</option>
                                <option>Expiring Soon</option>
                                <option>Expired</option>
                                <option>Cancelled</option>
                            </select>
                        </div>

                    </div>
                </div>

                <hr class="my-4">

                <!-- 4. EMI Details -->
                <div class="mb-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span
                            class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width: 28px; height: 28px;">
                            4
                        </span>

                        <h6 class="fw-bold mb-0">
                            EMI Details
                        </h6>
                    </div>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Financing Bank
                            </label>

                            <input type="text" class="form-control" value="Sundaram Finance"
                                placeholder="Enter financing bank" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Monthly EMI (₹)
                            </label>

                            <input type="number" class="form-control" value="85000" placeholder="Enter monthly EMI" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                EMI Due Cycle Day
                            </label>

                            <select class="form-select">
                                <option>5th of Month</option>
                                <option>10th of Month</option>
                                <option>15th of Month</option>
                                <option>20th of Month</option>
                                <option>25th of Month</option>
                            </select>
                        </div>

                    </div>
                </div>

                <hr class="my-4">

                <!-- 5. Service Details -->
                <div>
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span
                            class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width: 28px; height: 28px;">
                            5
                        </span>

                        <h6 class="fw-bold mb-0">
                            Service Details
                        </h6>
                    </div>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Service Interval
                            </label>

                            <input type="text" class="form-control" value="Every 250 Operating Hours"
                                placeholder="e.g. Every 250 Operating Hours" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Preferred Workshop
                            </label>

                            <input type="text" class="form-control" value="Central Yard Service Bay"
                                placeholder="Enter preferred workshop" />
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">
                                Warranty Status
                            </label>

                            <select class="form-select">
                                <option>
                                    Active Under Warranty
                                </option>
                                <option>
                                    Warranty Expiring Soon
                                </option>
                                <option>
                                    Warranty Expired
                                </option>
                                <option>
                                    Not Under Warranty
                                </option>
                            </select>
                        </div>

                    </div>
                </div>

            </div>

            <!-- Footer -->
            <div class="modal-footer border-top px-4 py-3">
                <button type="button" class="btn btn-light border rounded-3 px-4" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" class="btn btn-primary rounded-3 px-4">
                    <i class="mdi mdi-content-save-outline me-1"></i>
                    Save Fleet Master Record
                </button>
            </div>

        </div>
    </div>
</div>


<div class="modal fade" id="editFleetModal" tabindex="-1" aria-labelledby="editFleetModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-xl modal-dialog-scrollable">

        <div class="modal-content border-0 rounded-4 shadow">

            {{-- Header --}}
            <div class="modal-header border-bottom">

                <div>
                    <h5 class="modal-title fw-bold text-dark" id="editFleetModalLabel">
                        Edit Fleet Machine / Vehicle Unit
                    </h5>

                    <small class="text-muted">
                        Update base, ownership, insurance, EMI and service details
                    </small>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>


            <form id="editFleetForm">

                <div class="modal-body p-4">

                    {{-- ================================================= --}}
                    {{-- 1. BASE DETAILS --}}
                    {{-- ================================================= --}}

                    <div class="mb-4">

                        <div class="d-flex align-items-center gap-2 mb-3">

                            <div class="d-flex align-items-center justify-content-center
                                bg-primary-subtle text-primary rounded-3" style="width:40px;height:40px;">

                                <i class="mdi mdi-file-document-outline fs-4"></i>

                            </div>

                            <div>
                                <h6 class="mb-0 fw-bold text-dark">
                                    1. Base Details
                                </h6>

                                <small class="text-muted">
                                    Machine and technical identification
                                </small>
                            </div>

                        </div>


                        <div class="row g-3">

                            {{-- Fleet Code --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Fleet / Machine Code
                                </label>

                                <input type="text" class="form-control" name="machine_code" value="EQ-401">
                            </div>


                            {{-- Machine Name --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Machine / Vehicle Name
                                </label>

                                <input type="text" class="form-control" name="machine_name"
                                    value="Caterpillar 320D Excavator">
                            </div>


                            {{-- Category --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Machine Type / Category
                                </label>

                                <select class="form-select" name="machine_type">

                                    <option value="Excavator" selected>
                                        Excavator
                                    </option>

                                    <option value="Loader">
                                        Loader
                                    </option>

                                    <option value="Crane">
                                        Crane
                                    </option>

                                    <option value="Truck">
                                        Truck
                                    </option>

                                    <option value="Vehicle">
                                        Vehicle
                                    </option>

                                </select>
                            </div>


                            {{-- Registration --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Registration Number
                                </label>

                                <input type="text" class="form-control" name="registration_number"
                                    value="TN-09-CB-4821">
                            </div>


                            {{-- Chassis --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Chassis VIN Number
                                </label>

                                <input type="text" class="form-control" name="chassis_vin" value="CHS-CAT-9920184">
                            </div>


                            {{-- Engine --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Engine Serial Number
                                </label>

                                <input type="text" class="form-control" name="engine_serial" value="ENG-CAT-4820193">
                            </div>


                            {{-- Brand --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Make & Brand
                                </label>

                                <input type="text" class="form-control" name="brand" value="Caterpillar Inc.">
                            </div>


                            {{-- Model --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Model Variant
                                </label>

                                <input type="text" class="form-control" name="model"
                                    value="320D Series II Heavy Earthmover">
                            </div>


                            {{-- Manufacturing Year --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Manufacturing Year
                                </label>

                                <input type="number" class="form-control" name="manufacturing_year" value="2023">
                            </div>


                            {{-- Capacity --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Capacity & Specifications
                                </label>

                                <input type="text" class="form-control" name="capacity"
                                    value="20.5 Tons / 1.2 Cu.m Bucket">
                            </div>


                            {{-- Fuel --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Fuel Engine Type
                                </label>

                                <select class="form-select" name="fuel_type">

                                    <option value="Diesel" selected>
                                        Diesel
                                    </option>

                                    <option value="Petrol">
                                        Petrol
                                    </option>

                                    <option value="Electric">
                                        Electric
                                    </option>

                                    <option value="Hybrid">
                                        Hybrid
                                    </option>

                                </select>
                            </div>


                            {{-- Runtime --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Total Lifetime Runtime
                                </label>

                                <input type="text" class="form-control" name="runtime" value="1248 Hours / Km">
                            </div>

                        </div>

                    </div>


                    <hr class="my-4">


                    {{-- ================================================= --}}
                    {{-- 2. OWNED DETAILS --}}
                    {{-- ================================================= --}}

                    <div class="mb-4">

                        <div class="d-flex align-items-center gap-2 mb-3">

                            <div class="d-flex align-items-center justify-content-center
                                bg-primary-subtle text-primary rounded-3" style="width:40px;height:40px;">

                                <i class="mdi mdi-domain fs-4"></i>

                            </div>

                            <div>
                                <h6 class="mb-0 fw-bold text-dark">
                                    2. Owned Details
                                </h6>

                                <small class="text-muted">
                                    Ownership and procurement information
                                </small>
                            </div>

                        </div>


                        <div class="row g-3">

                            {{-- Ownership --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Ownership Type
                                </label>

                                <select class="form-select" name="ownership_type">

                                    <option value="Company Owned" selected>
                                        Company Owned
                                    </option>

                                    <option value="Leased">
                                        Leased
                                    </option>

                                    <option value="Rented">
                                        Rented
                                    </option>

                                </select>
                            </div>


                            {{-- Purchase Date --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Purchase Date
                                </label>

                                <input type="date" class="form-control" name="purchase_date" value="2023-04-15">
                            </div>


                            {{-- Purchase Cost --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Purchase Cost (₹)
                                </label>

                                <input type="number" class="form-control" name="purchase_cost" value="7800000">
                            </div>


                            {{-- Vendor --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Vendor / Dealer Name
                                </label>

                                <input type="text" class="form-control" name="vendor"
                                    value="GMMCO Caterpillar South India">
                            </div>


                            {{-- Invoice --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Invoice / PO Reference
                                </label>

                                <input type="text" class="form-control" name="invoice_reference"
                                    value="INV-GMM-2023-882">
                            </div>


                            {{-- Location --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Current Site Location
                                </label>

                                <input type="text" class="form-control" name="current_location"
                                    value="NH-45 Bridge Expansion (Pier P4 Foundation Site)">
                            </div>


                            {{-- Operator --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Assigned Operator
                                </label>

                                <input type="text" class="form-control" name="assigned_operator"
                                    value="K. Velu (Senior Operator)">
                            </div>


                            {{-- Book Value --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Current Book Value (₹)
                                </label>

                                <input type="number" class="form-control" name="book_value" value="6250000">
                            </div>

                        </div>

                    </div>


                    <hr class="my-4">


                    {{-- ================================================= --}}
                    {{-- 3. INSURANCE DETAILS --}}
                    {{-- ================================================= --}}

                    <div class="mb-4">

                        <div class="d-flex align-items-center gap-2 mb-3">

                            <div class="d-flex align-items-center justify-content-center
                                bg-primary-subtle text-primary rounded-3" style="width:40px;height:40px;">

                                <i class="mdi mdi-shield-check-outline fs-4"></i>

                            </div>

                            <div>
                                <h6 class="mb-0 fw-bold text-dark">
                                    3. Insurance Details
                                </h6>

                                <small class="text-muted">
                                    Insurance policy and compliance information
                                </small>
                            </div>

                        </div>


                        <div class="row g-3">

                            {{-- Provider --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Insurance Provider
                                </label>

                                <input type="text" class="form-control" name="insurance_provider"
                                    value="ICICI Lombard General Insurance">
                            </div>


                            {{-- Policy --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Policy Number
                                </label>

                                <input type="text" class="form-control" name="policy_number" value="POL-2026-9920148">
                            </div>


                            {{-- Coverage --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Coverage Type
                                </label>

                                <input type="text" class="form-control" name="coverage_type" value="Comprehensive">
                            </div>


                            {{-- IDV --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Insured Declared Value (₹)
                                </label>

                                <input type="number" class="form-control" name="idv" value="7000000">
                            </div>


                            {{-- Premium --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Annual Premium (₹)
                                </label>

                                <input type="number" class="form-control" name="annual_premium" value="85000">
                            </div>


                            {{-- Start Date --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Policy Commencement Date
                                </label>

                                <input type="date" class="form-control" name="policy_start" value="2026-01-10">
                            </div>


                            {{-- Expiry --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Policy Expiry Date
                                </label>

                                <input type="date" class="form-control" name="policy_expiry" value="2027-01-09">
                            </div>


                            {{-- Claim Contact --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Claim Contact Desk
                                </label>

                                <input type="text" class="form-control" name="claim_contact" value="+91 98401 22334">
                            </div>


                            {{-- Status --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Insurance Status
                                </label>

                                <select class="form-select" name="insurance_status">

                                    <option value="Active & Valid" selected>
                                        Active & Valid
                                    </option>

                                    <option value="Expiring Soon">
                                        Expiring Soon
                                    </option>

                                    <option value="Expired">
                                        Expired
                                    </option>

                                </select>
                            </div>

                        </div>

                    </div>


                    <hr class="my-4">


                    {{-- ================================================= --}}
                    {{-- 4. EMI DETAILS --}}
                    {{-- ================================================= --}}

                    <div class="mb-4">

                        <div class="d-flex align-items-center gap-2 mb-3">

                            <div class="d-flex align-items-center justify-content-center
                                bg-primary-subtle text-primary rounded-3" style="width:40px;height:40px;">

                                <i class="mdi mdi-cash-multiple fs-4"></i>

                            </div>

                            <div>
                                <h6 class="mb-0 fw-bold text-dark">
                                    4. EMI Details
                                </h6>

                                <small class="text-muted">
                                    Financing and repayment information
                                </small>
                            </div>

                        </div>


                        <div class="row g-3">

                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Financing Bank / NBFC
                                </label>

                                <input type="text" class="form-control" name="financing_bank"
                                    value="Sundaram Finance Heavy Fleet Division">
                            </div>


                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Loan Account Number
                                </label>

                                <input type="text" class="form-control" name="loan_account" value="LA-SUN-4820194">
                            </div>


                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Total Loan Sanctioned (₹)
                                </label>

                                <input type="number" class="form-control" name="loan_sanctioned" value="5000000">
                            </div>


                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Down Payment Paid (₹)
                                </label>

                                <input type="number" class="form-control" name="down_payment" value="2800000">
                            </div>


                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Monthly EMI (₹)
                                </label>

                                <input type="number" class="form-control" name="monthly_emi" value="118500">
                            </div>


                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    EMI Due Cycle Day
                                </label>

                                <input type="text" class="form-control" name="emi_due_day" value="5th of Month">
                            </div>


                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Tenure Paid Progress
                                </label>

                                <input type="text" class="form-control" name="tenure_progress" value="28 of 48 Months">
                            </div>


                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Next EMI Due Date
                                </label>

                                <input type="date" class="form-control" name="next_emi_date" value="2026-08-05">
                            </div>

                        </div>

                    </div>


                    <hr class="my-4">


                    {{-- ================================================= --}}
                    {{-- 5. SERVICE DETAILS --}}
                    {{-- ================================================= --}}

                    <div>

                        <div class="d-flex align-items-center gap-2 mb-3">

                            <div class="d-flex align-items-center justify-content-center
                                bg-primary-subtle text-primary rounded-3" style="width:40px;height:40px;">

                                <i class="mdi mdi-wrench-outline fs-4"></i>

                            </div>

                            <div>
                                <h6 class="mb-0 fw-bold text-dark">
                                    5. Service Details
                                </h6>

                                <small class="text-muted">
                                    Maintenance, workshop and warranty information
                                </small>
                            </div>

                        </div>


                        <div class="row g-3">

                            {{-- Interval --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Service Interval
                                </label>

                                <input type="text" class="form-control" name="service_interval"
                                    value="Every 250 Operating Hours / 3 Months">
                            </div>


                            {{-- Last Service --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Last Service Date & Meter
                                </label>

                                <input type="text" class="form-control" name="last_service"
                                    value="15-Jul-2026 @ 1240 Hrs">
                            </div>


                            {{-- Next Service --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Next Due Service Date & Target
                                </label>

                                <input type="text" class="form-control" name="next_service"
                                    value="15-Sep-2026 @ 1490 Hrs">
                            </div>


                            {{-- Workshop --}}
                            <div class="col-12 col-md-6 col-xl-8">
                                <label class="form-label fw-semibold">
                                    Preferred Workshop / Service Yard
                                </label>

                                <input type="text" class="form-control" name="workshop"
                                    value="Central Equipment Maintenance Yard, Villupuram">
                            </div>


                            {{-- Warranty --}}
                            <div class="col-12 col-md-6 col-xl-4">
                                <label class="form-label fw-semibold">
                                    Factory / Dealer Warranty
                                </label>

                                <select class="form-select" name="warranty">

                                    <option value="Active Under Warranty">
                                        Active Under Warranty
                                    </option>

                                    <option value="Extended Warranty" selected>
                                        Extended Warranty
                                    </option>

                                    <option value="Expired">
                                        Expired
                                    </option>

                                </select>
                            </div>


                            {{-- Service Records --}}
                            <div class="col-12">

                                <label class="form-label fw-semibold">
                                    Service & Maintenance Overhaul History
                                </label>

                                <input type="text" class="form-control" name="service_history"
                                    value="2 Service Records">

                            </div>

                        </div>

                    </div>

                </div>


                {{-- Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="submit" class="btn btn-primary rounded-3 px-4">

                        <i class="mdi mdi-content-save-outline me-1"></i>

                        Save Changes

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<div class="modal fade" id="serviceLogModal" tabindex="-1" aria-labelledby="serviceLogModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content border-0 rounded-4 shadow">

            {{-- Header --}}
            <div class="modal-header border-bottom bg-primary">

                <div>
                    <h5 class="modal-title fw-bold text-white" id="serviceLogModalLabel">
                        Record Maintenance / Service Log
                    </h5>

                    <small class="text-white p-3">
                        Unit:
                        <span class="fw-semibold text-white">
                            [EQ-401] Caterpillar 320D Excavator
                        </span>
                    </small>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

            </div>


            {{-- Form --}}
            <form id="serviceLogForm">

                <div class="modal-body p-4">

                    <div class="row g-3">

                        {{-- Service Type --}}
                        <div class="col-12 col-md-6">

                            <label class="form-label fw-semibold">
                                Service Type
                            </label>

                            <select class="form-select" name="service_type" required>
                                <option value="">
                                    Select Service Type
                                </option>

                                <option value="Scheduled Maintenance">
                                    Scheduled Maintenance
                                </option>

                                <option value="Preventive Maintenance">
                                    Preventive Maintenance
                                </option>

                                <option value="Breakdown Repair">
                                    Breakdown Repair
                                </option>

                                <option value="Major Overhaul">
                                    Major Overhaul
                                </option>

                                <option value="Inspection">
                                    Inspection
                                </option>

                                <option value="Calibration">
                                    Calibration
                                </option>
                            </select>

                        </div>


                        {{-- Service Date --}}
                        <div class="col-12 col-md-6">

                            <label class="form-label fw-semibold">
                                Service Date
                            </label>

                            <input type="date" class="form-control" name="service_date" value="2026-09-07" required>

                        </div>


                        {{-- Workshop --}}
                        <div class="col-12 col-md-6">

                            <label class="form-label fw-semibold">
                                Workshop / Service Bay
                            </label>

                            <input type="text" class="form-control" name="workshop" value="Central Equipment Yard"
                                placeholder="Enter workshop / service bay" required>

                        </div>


                        {{-- Lead Mechanic --}}
                        <div class="col-12 col-md-6">

                            <label class="form-label fw-semibold">
                                Lead Mechanic
                            </label>

                            <input type="text" class="form-control" name="lead_mechanic" value="Senior Heavy Mechanic"
                                placeholder="Enter lead mechanic" required>

                        </div>

                        <div class="col-12 col-md-6">

                            <label class="form-label fw-semibold">
                                Meter Hrs
                            </label>

                            <input type="text" class="form-control" name="meter_Hrs" value="meter_Hrs"
                                placeholder="1240 Hrs" required>

                        </div>


                        {{-- Parts --}}
                        <div class="col-12">

                            <label class="form-label fw-semibold">
                                Parts & Consumables Replaced
                            </label>

                            <textarea class="form-control" name="parts_replaced" rows="3"
                                placeholder="e.g. High Pressure Hose, O-Rings, Oil 15W40"></textarea>

                        </div>


                        {{-- Total Cost --}}
                        <div class="col-12 col-md-6">

                            <label class="form-label fw-semibold">
                                Total Service Cost (₹)
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    ₹
                                </span>

                                <input type="number" class="form-control" name="total_service_cost" value="15000"
                                    min="0" step="0.01" placeholder="Enter service cost" required>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="submit" class="btn btn-primary rounded-3 px-4">
                        <i class="mdi mdi-content-save-outline me-1"></i>
                        Add Service Record
                    </button>

                </div>

            </form>

        </div>

    </div>
</div>


<style>
#fleet-details-sidebar .nav-link {
    color: #6c757d;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s ease;
}

#fleet-details-sidebar .nav-link:hover {
    background-color: #f5f7fa;
    color: #154997;
}

#fleet-details-sidebar .nav-link.active {
    background-color: var(--bs-primary);
    color: #fff !important;
    font-weight: 600;
}

#fleet-details-sidebar .nav-link i {
    width: 22px;
    text-align: center;
}


#fleet-content .fleet-section {
    margin-bottom: 2rem;
}

#fleet-content .fleet-section:last-child {
    margin-bottom: 0;
}

.fleet-edit-btn {
    width: 25px;
    height: 28px;
    padding: 0;
    background-color: transparent;
    border: 1px solid transparent;
    color: #696cff;
    transition: all 0.2s ease;
}

.fleet-edit-btn:hover {

    border-color: #1c1ea1;
    color: #1d4ff5;
}

.nav-scroll-wrapper {
    width: 100%;
    overflow-x: auto;
    overflow-y: hidden;
    padding-bottom: 2px;
    scrollbar-width: thin;
}

.nav-scroll-container {
    width: max-content;
    min-width: 100%;
    white-space: nowrap;
}

.settings-tab-pill {
    min-height: 38px;
    white-space: nowrap;
    flex-shrink: 0;
    padding: 0.45rem 1rem !important;
    border-radius: 50rem !important;
    font-size: 0.85rem;
    font-weight: 500;
    line-height: 1.2;
    text-decoration: none;
    transition: all 0.15s ease;
}

.settings-tab-pill .mdi {
    font-size: 17px;
    line-height: 1;
}

.settings-tab-pill:hover {
    text-decoration: none;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {

    const sidebar = document.getElementById('fleet-details-sidebar');
    const fleetContent = document.getElementById('fleet-content');

    if (!sidebar || !fleetContent) {
        return;
    }

    const navLinks = sidebar.querySelectorAll('.nav-link');
    const sections = fleetContent.querySelectorAll('.fleet-section');

    function showSection(sectionId) {

        // Hide all sections first
        if (!document.body.classList.contains('fleet-editing')) {
            sections.forEach(section => {
                section.classList.add('d-none');
            });
        }

        // FULL VIEW
        if (sectionId === 'full-details') {

            sections.forEach(function(section) {
                section.classList.remove('d-none');
            });

        } else {

            // Show only selected section
            const selectedSection = document.getElementById(sectionId);

            if (selectedSection) {
                selectedSection.classList.remove('d-none');
            }
        }

        // Update active sidebar link
        navLinks.forEach(function(link) {

            link.classList.remove('active');

            const linkSection = link.getAttribute('data-section');

            if (linkSection === sectionId) {
                link.classList.add('active');
            }

        });
    }


    // Sidebar click event
    navLinks.forEach(function(link) {

        link.addEventListener('click', function(event) {

            event.preventDefault();

            const sectionId = this.getAttribute('data-section');

            if (sectionId) {
                showSection(sectionId);
            }

        });

    });


    // Default view
    showSection('full-details');

});


// edit mode
document.addEventListener('DOMContentLoaded', function() {

    const editBtn = document.getElementById('fleetEditBtn');
    const saveBtn = document.getElementById('fleetSaveBtn');
    const cancelBtn = document.getElementById('fleetCancelBtn');
    const editActions = document.getElementById('fleetEditActions');

    const sections = document.querySelectorAll(
        '#base-details, #owned-details, #insurance-details, #emi-details, #service-details'
    );

    let originalValues = {};

    editBtn.addEventListener('click', function() {

        originalValues = {};

        // Show all 5 sections
        sections.forEach(function(section) {
            section.classList.remove('d-none');
            section.classList.add('edit-mode');
        });

        // Convert all editable values into inputs
        document.querySelectorAll('.fleet-editable').forEach(function(element) {
            const field = element.dataset.field;
            const value = element.textContent.trim();
            originalValues[field] = value;
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'fleet-edit-input';
            input.name = field;
            input.value = value;
            element.innerHTML = '';
            element.appendChild(input);
        });

        // Show Save / Cancel
        editActions.classList.remove('d-none');

        // Change edit button appearance
        editBtn.classList.add('d-none');

    });
    cancelBtn.addEventListener('click', function() {
        document.querySelectorAll('.fleet-editable').forEach(function(element) {
            const field = element.dataset.field;

            if (originalValues[field] !== undefined) {
                element.textContent = originalValues[field];
            }

        });
        // Hide all sections except currently selected section
        sections.forEach(function(section) {
            section.classList.remove('edit-mode');
            if (section.id !== 'base-details') {
                section.classList.add('d-none');
            }
        });
        editActions.classList.add('d-none');
        editBtn.classList.remove('d-none');

    });

    saveBtn.addEventListener('click', function() {
        const formData = {};
        document.querySelectorAll('.fleet-editable').forEach(function(element) {
            const field = element.dataset.field;
            const input = element.querySelector('.fleet-edit-input');
            if (input) {
                formData[field] = input.value.trim();
            }
        });
        console.log('Fleet Data:', formData);
        document.querySelectorAll('.fleet-editable').forEach(function(element) {
            const field = element.dataset.field;
            if (formData[field] !== undefined) {
                element.textContent = formData[field];
            }
        });
        // Exit edit mode
        sections.forEach(function(section) {
            section.classList.remove('edit-mode');
        });
        editActions.classList.add('d-none');
        editBtn.classList.remove('d-none');
    });

});

document.addEventListener("DOMContentLoaded", function() {

    const editBtn = document.getElementById("fleetEditBtn");
    const saveBtn = document.getElementById("fleetSaveBtn");
    const cancelBtn = document.getElementById("fleetCancelBtn");

    let isEditing = false;
    let originalValues = {};

    const fieldTypes = {

        // Base
        machine_code: "text",
        machine_name: "text",
        machine_type: "select",
        registration_number: "text",
        chassis_vin: "text",
        engine_serial: "text",
        brand: "text",
        model: "text",
        manufacturing_year: "number",
        capacity: "text",
        fuel_type: "select",
        runtime: "text",

        // Owned
        ownership_type: "select",
        purchase_date: "date",
        purchase_cost: "number",
        vendor: "text",
        invoice_reference: "text",
        current_location: "text",
        assigned_operator: "text",
        book_value: "number",

        // Insurance
        insurance_provider: "text",
        policy_number: "text",
        coverage_type: "text",
        idv: "number",
        annual_premium: "number",
        policy_start: "date",
        policy_expiry: "date",
        claim_contact: "text",
        insurance_status: "select",

        // EMI
        financing_bank: "text",
        loan_account: "text",
        loan_sanctioned: "number",
        down_payment: "number",
        monthly_emi: "number",
        emi_due_day: "text",
        tenure_progress: "text",
        next_emi_date: "date",

        // Service
        service_interval: "text",
        last_service: "text",
        next_service: "text",
        workshop: "text",
        warranty: "select",
        service_history: "text"
    };


    function getSelectOptions(field, value) {

        const options = {
            machine_type: [
                "Excavator",
                "Loader",
                "Crane",
                "Truck",
                "Vehicle"
            ],

            fuel_type: [
                "Diesel",
                "Petrol",
                "Electric",
                "Hybrid"
            ],

            ownership_type: [
                "Company Owned",
                "Leased",
                "Rented"
            ],

            insurance_status: [
                "Active & Valid",
                "Expiring Soon",
                "Expired"
            ],

            warranty: [
                "Active Under Warranty",
                "Extended Warranty",
                "Expired"
            ]
        };

        return (options[field] || [value])
            .map(option => `
                <option value="${option}"
                    ${option === value ? "selected" : ""}>
                    ${option}
                </option>
            `)
            .join("");
    }


    function convertToInput(element, field) {

        const value = element.textContent.trim();

        originalValues[field] = value;

        const type = fieldTypes[field] || "text";

        if (type === "select") {

            element.innerHTML = `
                <select
                    class="form-select form-select-sm fleet-edit-input"
                    data-edit-field="${field}">
                    ${getSelectOptions(field, value)}
                </select>
            `;

            return;
        }


        let inputValue = value;

        /*
         * Remove ₹ and commas from number fields
         */
        if (type === "number") {
            inputValue = value
                .replace(/₹/g, "")
                .replace(/,/g, "")
                .trim();
        }


        /*
         * Convert displayed dates to yyyy-mm-dd
         */
        if (type === "date") {

            const date = new Date(value);

            if (!isNaN(date.getTime())) {
                inputValue = date.toISOString().split("T")[0];
            }
        }


        element.innerHTML = `
            <input
                type="${type}"
                class="form-control form-control-sm fleet-edit-input"
                data-edit-field="${field}"
                value="${inputValue}">
        `;
    }


    function enableEditMode() {

        isEditing = true;

        document
            .querySelectorAll("[data-field]")
            .forEach(element => {

                const field = element.dataset.field;

                if (fieldTypes[field]) {
                    convertToInput(element, field);
                }

            });


        editBtn.classList.add("d-none");
        saveBtn.classList.remove("d-none");
        cancelBtn.classList.remove("d-none");
    }


    function cancelEdit() {

        isEditing = false;

        document
            .querySelectorAll("[data-field]")
            .forEach(element => {

                const field = element.dataset.field;

                if (originalValues[field] !== undefined) {

                    element.textContent =
                        originalValues[field];

                }

            });


        originalValues = {};

        editBtn.classList.remove("d-none");
        saveBtn.classList.add("d-none");
        cancelBtn.classList.add("d-none");
    }


    function saveChanges() {

        const updatedData = {};

        document
            .querySelectorAll("[data-edit-field]")
            .forEach(input => {

                const field =
                    input.dataset.editField;

                updatedData[field] =
                    input.value.trim();

            });


        console.log("Updated Fleet Data:", updatedData);


        /*
         * Replace inputs with saved values
         */
        document
            .querySelectorAll("[data-field]")
            .forEach(element => {

                const field =
                    element.dataset.field;

                if (updatedData[field] !== undefined) {

                    let value =
                        updatedData[field];


                    /*
                     * Format number values
                     */
                    if (
                        [
                            "purchase_cost",
                            "book_value",
                            "idv",
                            "annual_premium",
                            "loan_sanctioned",
                            "down_payment",
                            "monthly_emi"
                        ].includes(field)
                    ) {

                        value =
                            "₹" +
                            Number(value).toLocaleString("en-IN");
                    }


                    element.textContent = value;
                }

            });


        /*
         * Here you can send updatedData
         * to your Laravel backend using fetch/AJAX.
         */


        isEditing = false;
        originalValues = {};

        editBtn.classList.remove("d-none");
        saveBtn.classList.add("d-none");
        cancelBtn.classList.add("d-none");
    }


    editBtn.addEventListener(
        "click",
        enableEditMode
    );

    cancelBtn.addEventListener(
        "click",
        cancelEdit
    );

    saveBtn.addEventListener(
        "click",
        saveChanges
    );

});
</script>

@endsection
