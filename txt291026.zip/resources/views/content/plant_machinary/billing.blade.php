@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="row g-3 g-md-4 mb-4">

    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Total Fleet Size
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-break"
                        style="color:#0C3C62;">
                        5 Heavy Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Monitored in Master Register
                </span>

            </div>

        </div>

    </div>


    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Operational Ratio
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-success">
                        40%
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-dark small text-break">
                    2 Units Active on Site
                </span>

            </div>

        </div>

    </div>


    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Active Site Deployments
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-danger">
                        3 Projects
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Engineers &amp; Operators assigned
                </span>

            </div>

        </div>

    </div>


    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Maintenance Overhaul
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-warning">
                        2 Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small">
                    In Workshop / Service Bay
                </span>

            </div>

        </div>

    </div>

</div>



<div class="card shadow-sm rounded-2 mb-4">

    <div class="card-body p-3 p-md-4">

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

            <div>

                <h5 class="mb-1 fw-bold text-primary">
                    Machine / Vehicle Commercial Bills &amp; Hire Invoices
                </h5>

                <p class="text-muted mb-0 small">
                    Audit machinery rental bills, internal equipment cross-charges &amp; vendor invoices
                </p>

            </div>

      
                <button type="button"
                    class="btn btn-primary btn-sm settings-tab-pill d-inline-flex align-items-center flex-shrink-0"
                    data-bs-toggle="modal"
                    data-bs-target="#machineBillModal">
                    <span class="mdi mdi-plus me-2"></span>
                    Generate Machine Bill
                </button>
        </div>
    </div>




<div class="deployment-table-wrapper">

    <table class="table deployment-table commercial-bills-table align-middle mb-0">

        <thead class="fw-semibold text-black uppercase bg-light">

            <tr>
                <th>Bill Ref ID</th>
                <th>Bill Date</th>
                <th>Machine / Vehicle</th>
                <th>Vendor / Owner</th>
                <th>Billable Runtime</th>
                <th>Agreed Rate</th>
                <th>Grand Total Bill</th>
                <th>Payment Clearance</th>
            </tr>

        </thead>

        <tbody>

            <tr>

                <td>
                    <span class="assignment-id text-primary fw-bold">
                        MB-2026-801
                    </span>
                </td>

                <td>
                    <span class="date-value">
                        2026-07-20
                    </span>
                </td>

                <td>
                    <div class="machine-name">
                        Liebherr LTM 1050 Crane
                    </div>
                </td>

                <td>
                    <div class="workshop-name">
                        Tamilnad Heavy Lift &amp; Crane Services
                    </div>
                </td>

                <td>
                    <span class="runtime-badge">
                        160 Hours
                    </span>
                </td>

                <td>
                    <span class="cost-value">
                        $65 / hr
                    </span>
                </td>

                <td>
                    <span class="cost-value">
                        $12,272
                    </span>
                </td>

                <td>
                    <span class="maintenance-status completed">
                        Approved for Payment
                    </span>
                </td>

            </tr>


            <tr>

                <td>
                    <span class="assignment-id text-primary fw-bold">
                        MB-2026-802
                    </span>
                </td>

                <td>
                    <span class="date-value">
                        2026-07-18
                    </span>
                </td>

                <td>
                    <div class="machine-name">
                        Caterpillar 320D Excavator
                    </div>
                </td>

                <td>
                    <div class="workshop-name">
                        SRK Machinery Division
                    </div>
                </td>

                <td>
                    <span class="runtime-badge">
                        110 Hours
                    </span>
                </td>

                <td>
                    <span class="cost-value">
                        $45 / hr
                    </span>
                </td>

                <td>
                    <span class="cost-value">
                        $4,950
                    </span>
                </td>

                <td>
                    <span class="maintenance-status in-service">
                        Internal Settled
                    </span>
                </td>

            </tr>

        </tbody>

    </table>

</div>
</div>


<div class="modal fade"
    id="machineBillModal"
    tabindex="-1"
    aria-labelledby="machineBillModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content border-0 shadow-lg rounded-3">

            <div class="modal-header bg-primary text-white">

                <div>

                    <h5 class="modal-title fw-bold mb-1 text-white"
                        id="machineBillModalLabel">
                        New Entry - Machine / Vehicle Commercial &amp; Hire Billing
                    </h5>

                    <small class="opacity-75">
                        Generate commercial hire and machinery billing details
                    </small>

                </div>

                <button type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>

            <div class="modal-body p-3 p-md-4">

                <form id="machineBillForm">

                    <div class="row g-3">

                        <div class="col-12">

                            <label for="billMachineVehicle"
                                class="form-label fw-semibold">
                                Select Machine / Vehicle
                            </label>

                            <select id="billMachineVehicle"
                                name="machine_vehicle"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Machine / Vehicle
                                </option>

                                <option value="EQ-401">
                                    [EQ-401] Caterpillar 320 Excavator
                                </option>

                                <option value="EQ-402">
                                    [EQ-402] Liebherr LTM 1050 Mobile Crane
                                </option>

                                <option value="EQ-403">
                                    [EQ-403] Volvo FMX 440 Tipper Truck
                                </option>

                                <option value="EQ-404">
                                    [EQ-404] Schwing Stetter Concrete Pump
                                </option>

                                <option value="EQ-405">
                                    [EQ-405] Atlas Copco Air Compressor
                                </option>

                            </select>

                        </div>

                        <div class="col-12">

                            <label for="vendorOwnerName"
                                class="form-label fw-semibold">
                                Vendor / Owner Name
                            </label>

                            <input type="text"
                                id="vendorOwnerName"
                                name="vendor_owner_name"
                                class="form-control"
                                placeholder="Enter vendor / owner name"
                                required>

                        </div>

                        <div class="col-md-6">

                            <label for="billableHoursDays"
                                class="form-label fw-semibold">
                                Billable Hours / Days
                            </label>

                            <input type="number"
                                id="billableHoursDays"
                                name="billable_hours_days"
                                class="form-control"
                                placeholder="Enter hours / days"
                                min="0"
                                step="0.5"
                                required>

                        </div>

                        <div class="col-md-6">

                            <label for="ratePerHourDay"
                                class="form-label fw-semibold">
                                Rate per Hour/Day ($)
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    $
                                </span>

                                <input type="number"
                                    id="ratePerHourDay"
                                    name="rate_per_hour_day"
                                    class="form-control"
                                    placeholder="Enter rate"
                                    min="0"
                                    step="0.01"
                                    required>

                            </div>

                        </div>

                    </div>

                </form>

            </div>

            <div class="modal-footer border-top-0 px-3 px-md-4 pb-3">

                <button type="button"
                    class="btn btn-light border"
                    data-bs-dismiss="modal">
                    Close
                </button>

                <button type="submit"
                    form="machineBillForm"
                    class="btn btn-primary d-inline-flex align-items-center">

                    <span class="mdi mdi-file-document-check-outline me-2"></span>

                    Generate Machine Bill

                </button>

            </div>

        </div>

    </div>

</div>


<style>
    .settings-tab-pill {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex-shrink: 0;
    min-height: 38px;
    padding: 0.5rem 1rem !important;
    border-radius: 50rem !important;
    white-space: nowrap;
    font-size: 0.85rem;
    font-weight: 600;
    line-height: 1;
    text-decoration: none !important;
    transition: all 0.15s ease-in-out;
}
</style>

@endsection