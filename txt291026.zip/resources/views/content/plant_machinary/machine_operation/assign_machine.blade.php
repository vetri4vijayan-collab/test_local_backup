
@extends('layouts.layoutMaster')

@section('title', 'Machine Master - Plant and Machinary')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3 p-md-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

            <div class="d-flex align-items-center gap-3">
                <i class="mdi mdi-cog-outline fs-1 text-primary"></i>

                <div>
                    <h4 class="mb-1 fw-bold text-primary fs-3">
                        Machine Master
                    </h4>

                    <p class="text-muted mb-0 fs-7">
                        Machinery & Equipment Management
                    </p>
                </div>
            </div>

            <div class="nav-scroll-wrapper">
                <div class="nav-scroll-container d-flex align-items-center gap-2">

                    @php
                        $isMachineMasterActive = request()->is('plant-machinery/machine-operations');
                        $isMachineAllocationActive = request()->is('/plant-machinery/machine-operations/machine_log');

                    @endphp

                    <a href="{{ url('/plant-machinery/machine-operations') }}"
                        class="btn btn-sm settings-tab-pill text-decoration-none d-inline-flex align-items-center fw-semibold {{ $isMachineMasterActive ? 'btn-primary' : 'btn-light border' }}">
                        <span class="mdi mdi-cog-outline me-2"></span>
                        Assign Machine/Vehicle
                    </a>

                    <a href="{{ url('/plant-machinery/machine-operations/machine_log') }}"
                        class="btn btn-sm settings-tab-pill text-decoration-none d-inline-flex align-items-center fw-semibold {{ $isMachineAllocationActive ? 'btn-primary' : 'btn-light border' }}">
                        <span class="mdi mdi-truck-outline me-2"></span>
                        Machine/Vehicle Log
                    </a>

                </div>
            </div>

        </div>
    </div>
</div>

<div class="row g-3 g-md-4 mb-4">

    {{-- Total Fleet --}}
    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Total Fleet Size
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-break" style="color:#0C3C62;">
                        5 Heavy Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Monitored in Master Register
                </span>

            </div>

        </div>

    </div>


    {{-- Operational Ratio --}}
    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Operational Ratio
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-success">
                        40%
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-dark small text-break">
                    2 Units Active on Site
                </span>

            </div>

        </div>

    </div>


    {{-- Active Deployments --}}
    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Active Site Deployments
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-danger">
                        3 Projects
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small text-break">
                    Engineers & Operators assigned
                </span>

            </div>

        </div>

    </div>


    {{-- Maintenance --}}
    <div class="col-12 col-sm-6 col-lg-3">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4 d-flex flex-column">

                <div class="mb-2">
                    <span class="d-block text-uppercase fw-bold text-secondary small">
                        Maintenance Overhaul
                    </span>
                </div>

                <div class="mb-1">
                    <span class="d-block fw-bold font-monospace fs-5 text-warning">
                        2 Units
                    </span>
                </div>

                <span class="d-block fw-semibold font-monospace text-secondary small">
                    In Workshop / Service Bay
                </span>

            </div>

        </div>

    </div>

</div>



<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3 p-md-4">

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
            <div>
                <h5 class="mb-1 fw-bold text-primary">
                    Site Deployments & Machine Assignments
                </h5>

                <p class="text-muted mb-0 small">
                    Track equipment allocations across active highway and bridge construction sites
                </p>
            </div>

           <button type="button" class="btn btn-primary btn-sm settings-tab-pill d-inline-flex align-items-center flex-shrink-0" 
           data-bs-toggle="modal" data-bs-target="#assignMachineModal">
            <span class="mdi mdi-plus me-2"></span> Assign Machine to Site
         </button>
        </div>

        <div class="deployment-table-wrapper">
            <table class="table deployment-table align-middle mb-0">

                <thead>
                    <tr>
                        <th>Assignment ID</th>
                        <th>Machine / Fleet Unit</th>
                        <th>Target Project Site</th>
                        <th>Assigned Operator</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Duty Shift</th>
                        <th>Deployment Purpose</th>
                        <th>Site Status</th>
                    </tr>
                </thead>

                <tbody>

                    <tr>
                        <td>
                            <span class="assignment-id text-primary fw-bold">
                                ASN-101
                            </span>
                        </td>

                        <td>
                            <div class="machine-name">
                                Caterpillar 320D Excavator
                            </div>
                            <div class="machine-ref">
                                REF: EQ-401
                            </div>
                        </td>

                        <td>
                            <span class="site-name">
                                NH-45 Bridge Expansion
                            </span>
                        </td>

                        <td>
                            <span class="operator-name">
                                @K. Velu
                            </span>
                        </td>

                        <td>
                            <span class="date-value">
                                2026-07-01
                            </span>
                        </td>

                        <td>
                            <span class="date-value">
                                2026-08-15
                            </span>
                        </td>

                        <td>
                            <span class="shift-badge text-primary ">
                                Day Shift
                            </span>
                            <span class="shift-time">
                                08:00 - 18:00
                            </span>
                        </td>

                        <td>
                            <span class="purpose-text">
                                Pier P4 Deep Foundation Excavation
                            </span>
                        </td>

                        <td>
                            <span class="status-badge">
                                Active Site
                            </span>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <span class="assignment-id text-primary fw-bold">
                                ASN-102
                            </span>
                        </td>

                        <td>
                            <div class="machine-name">
                                Liebherr LTM 1050 Crane
                            </div>
                            <div class="machine-ref">
                                REF: EQ-402
                            </div>
                        </td>

                        <td>
                            <span class="site-name">
                                Elevated Highway Block C
                            </span>
                        </td>

                        <td>
                            <span class="operator-name">
                                @S. Loganathan
                            </span>
                        </td>

                        <td>
                            <span class="date-value">
                                2026-06-20
                            </span>
                        </td>

                        <td>
                            <span class="date-value">
                                2026-07-30
                            </span>
                        </td>

                        <td>
                            <span class="shift-badge text-primary">
                                Day Shift
                            </span>
                            <span class="shift-time">
                                08:00 - 18:00
                            </span>
                        </td>

                        <td>
                            <span class="purpose-text">
                                Precast Segment Girders Erection
                            </span>
                        </td>

                        <td>
                            <span class="status-badge">
                                Active Site
                            </span>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <span class="assignment-id text-primary fw-bold">
                                ASN-103
                            </span>
                        </td>

                        <td>
                            <div class="machine-name">
                                Volvo FMX 440 Tipper Truck
                            </div>
                            <div class="machine-ref">
                                REF: EQ-403
                            </div>
                        </td>

                        <td>
                            <span class="site-name">
                                Madurai Bypass Flyover
                            </span>
                        </td>

                        <td>
                            <span class="operator-name">
                                @R. Saravanan
                            </span>
                        </td>

                        <td>
                            <span class="date-value">
                                2026-07-10
                            </span>
                        </td>

                        <td>
                            <span class="date-value">
                                2026-09-01
                            </span>
                        </td>

                        <td>
                            <span class="shift-badge night">
                                Night Shift
                            </span>
                            <span class="shift-time">
                                18:00 - 04:00
                            </span>
                        </td>

                        <td>
                            <span class="purpose-text">
                                Aggregate &amp; Subgrade Soil Muck Hauling
                            </span>
                        </td>

                        <td>
                            <span class="status-badge">
                                Active Site
                            </span>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>

    </div>
</div>


<div class="modal fade"
    id="assignMachineModal"
    tabindex="-1"
    aria-labelledby="assignMachineModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content border-0 shadow-lg rounded-3">

            <div class="modal-header bg-primary text-white">

                <div>
                    <h5 class="modal-title fw-bold mb-1 text-white"
                        id="assignMachineModalLabel">
                        New Entry - Assign Machine / Vehicle to Site
                    </h5>

                    <small class="opacity-75">
                        Create a new machine or vehicle site assignment
                    </small>
                </div>

                <button type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>

            <div class="modal-body p-3 p-md-4">

                <form id="assignMachineForm">

                    <div class="row g-3">

                        <div class="col-12">

                            <label for="machineVehicle"
                                class="form-label fw-semibold">
                                Select Machine / Vehicle
                            </label>

                            <select id="machineVehicle"
                                name="machine_vehicle"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Machine / Vehicle
                                </option>

                                <option value="EQ-401">
                                    [EQ-401] Caterpillar 320 Excavator
                                </option>

                                <option value="EQ-402">
                                    [EQ-402] Liebherr LTM 1050 Mobile Crane
                                </option>

                                <option value="EQ-403">
                                    [EQ-403] Volvo FMX 440 Tipper Truck
                                </option>

                                <option value="EQ-404">
                                    [EQ-404] Schwing Stetter Concrete Pump
                                </option>

                                <option value="EQ-405">
                                    [EQ-405] Atlas Copco Air Compressor
                                </option>

                            </select>

                        </div>

                        <div class="col-12">

                            <label for="targetProjectSite"
                                class="form-label fw-semibold">
                                Target Project Site
                            </label>

                            <select id="targetProjectSite"
                                name="target_project_site"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Target Project Site
                                </option>

                                <option value="NH-45 Bridge Expansion">
                                    NH-45 Bridge Expansion
                                </option>

                                <option value="Elevated Highway Block C">
                                    Elevated Highway Block C
                                </option>

                                <option value="Madurai Bypass Flyover">
                                    Madurai Bypass Flyover
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <label for="operatorName"
                                class="form-label fw-semibold">
                                Operator Name
                            </label>

                            <input type="text"
                                id="operatorName"
                                name="operator_name"
                                class="form-control"
                                placeholder="Enter operator name"
                                required>

                        </div>

                        <div class="col-md-6">

                            <label for="assignmentStartDate"
                                class="form-label fw-semibold">
                                Assignment Start Date
                            </label>

                            <input type="date"
                                id="assignmentStartDate"
                                name="assignment_start_date"
                                class="form-control"
                                required>

                        </div>

                        <div class="col-md-6">

                            <label for="assignmentEndDate"
                                class="form-label fw-semibold">
                                Assignment End Date
                            </label>

                            <input type="date"
                                id="assignmentEndDate"
                                name="assignment_end_date"
                                class="form-control"
                                required>

                        </div>

                        <div class="col-md-6">

                            <label for="assignmentPurpose"
                                class="form-label fw-semibold">
                                Purpose / Structure
                            </label>

                            <input type="text"
                                id="assignmentPurpose"
                                name="purpose_structure"
                                class="form-control"
                                placeholder="Enter purpose / structure"
                                required>

                        </div>

                    </div>

                </form>

            </div>

            <div class="modal-footer border-top-0 px-3 px-md-4 pb-3 pb-md-4">

                <button type="button"
                    class="btn btn-light border"
                    data-bs-dismiss="modal">
                    Close
                </button>

                <button type="submit"
                    form="assignMachineForm"
                    class="btn btn-primary d-inline-flex align-items-center">

                    <span class="mdi mdi-truck-check-outline me-2"></span>

                    Assign Machine to Site

                </button>

            </div>

        </div>

    </div>

</div>




<style>


.deployment-table-wrapper {
    width: 100%;
    overflow-x: auto;
    border: 1px solid #e9ecef;
    border-radius: 0.5rem;
}

.deployment-table {
    width: 100%;
    table-layout: fixed;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 0.78rem;
}

.deployment-table thead th {
    background: #f8f9fa;
    color: #495057;
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    white-space: normal;
    vertical-align: middle;
    padding: 0.85rem 0.7rem;
    border-bottom: 1px solid #dee2e6;
}

.deployment-table tbody td {
    padding: 0.9rem 0.7rem;
    vertical-align: middle;
    color: #495057;
    border-bottom: 1px solid #f0f1f2;
    line-height: 1.45;
    word-break: normal;
    overflow-wrap: anywhere;
}

.deployment-table tbody tr:last-child td {
    border-bottom: 0;
}

.deployment-table tbody tr:hover {
    background-color: #f8f9fa;
}

.deployment-table th:nth-child(1),
.deployment-table td:nth-child(1) {
    width: 8%;
}

.deployment-table th:nth-child(2),
.deployment-table td:nth-child(2) {
    width: 14%;
}

.deployment-table th:nth-child(3),
.deployment-table td:nth-child(3) {
    width: 12%;
}

.deployment-table th:nth-child(4),
.deployment-table td:nth-child(4) {
    width: 10%;
}

.deployment-table th:nth-child(5),
.deployment-table td:nth-child(5) {
    width: 8%;
}

.deployment-table th:nth-child(6),
.deployment-table td:nth-child(6) {
    width: 8%;
}

.deployment-table th:nth-child(7),
.deployment-table td:nth-child(7) {
    width: 12%;
}

.deployment-table th:nth-child(8),
.deployment-table td:nth-child(8) {
    width: 18%;
}

.deployment-table th:nth-child(9),
.deployment-table td:nth-child(9) {
    width: 10%;
}

/* .assignment-id {
    display: inline-block;
    font-family: monospace;
    font-size: 0.78rem;
    font-weight: 700;
    color: #0d6efd;
    white-space: nowrap;
} */

    .settings-tab-pill {
    min-height: 38px;
    white-space: nowrap;
    flex-shrink: 0;
    padding: 0.45rem 1rem !important;
    border-radius: 50rem !important;
    font-size: 0.85rem;
    font-weight: 500;
    line-height: 1.2;
    text-decoration: none;
    transition: all 0.15s ease;
}
.machine-name {
    font-weight: 600;
    color: #212529;
    line-height: 1.4;
}

.machine-ref {
    margin-top: 0.3rem;
    font-family: monospace;
    font-size: 0.68rem;
    color: #6c757d;
}

.site-name {
    display: block;
    font-weight: 600;
    color: #212529;
}

.operator-name {
    display: block;
    font-weight: 600;
    color: #495057;
}

.date-value {
    display: block;
    font-family: monospace;
    font-size: 0.72rem;
    white-space: nowrap;
    color: #495057;
}

.shift-badge {
    display: inline-block;
    padding: 0.3rem 0.55rem;
    border-radius: 50rem;
    background: #e7f1ff;
    color: #0d6efd;
    font-size: 0.68rem;
    font-weight: 700;
    white-space: nowrap;
}

.shift-badge.night {
    background: #fff3cd;
    color: #997404;
}

.shift-time {
    display: block;
    margin-top: 0.35rem;
    font-family: monospace;
    font-size: 0.67rem;
    color: #6c757d;
    white-space: nowrap;
}

.purpose-text {
    display: block;
    color: #343a40;
    font-weight: 500;
}

.status-badge {
    display: inline-block;
    padding: 0.3rem 0.6rem;
    border-radius: 50rem;
    background: #d1e7dd;
    color: #146c43;
    font-size: 0.68rem;
    font-weight: 700;
    white-space: nowrap;
}

@media (max-width: 1199.98px) {
    .deployment-table {
        min-width: 1100px;
        table-layout: auto;
    }

    .deployment-table th,
    .deployment-table td {
        white-space: normal;
    }
}

@media (max-width: 767.98px) {
    .deployment-table-wrapper {
        border-radius: 0.4rem;
    }

    .deployment-table {
        min-width: 1100px;
        font-size: 0.75rem;
    }

    .deployment-table thead th,
    .deployment-table tbody td {
        padding: 0.7rem 0.6rem;
    }
}



.nav-scroll-wrapper {
    width: auto;
    max-width: 100%;
    overflow-x: auto;
    overflow-y: hidden;
    padding-bottom: 2px;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: thin;
}

.nav-scroll-container {
    display: flex;
    align-items: center;
    flex-wrap: nowrap !important;
    gap: 0.5rem;
    width: max-content;
}

.settings-tab-pill {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex-shrink: 0;
    min-height: 38px;
    padding: 0.5rem 1rem !important;
    border-radius: 50rem !important;
    white-space: nowrap;
    font-size: 0.85rem;
    font-weight: 600;
    line-height: 1;
    text-decoration: none !important;
    transition: all 0.15s ease-in-out;
}

.settings-tab-pill .mdi {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    line-height: 1;
}

.settings-tab-pill.btn-primary {
    border-color: var(--bs-primary);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.08);
}

.settings-tab-pill.btn-light {
    background-color: #f8f9fa;
    color: #495057;
}

.settings-tab-pill.btn-light:hover {
    background-color: #eef0f2;
    border-color: #adb5bd;
    color: #212529;
}

.settings-tab-pill:focus {
    box-shadow: 0 0 0 0.15rem rgba(13, 110, 253, 0.15);
}

@media (max-width: 767.98px) {
    .nav-scroll-wrapper {
        width: 100%;
    }

    .nav-scroll-container {
        width: max-content;
        min-width: 100%;
    }

    .settings-tab-pill {
        min-height: 36px;
        padding: 0.45rem 0.85rem !important;
        font-size: 0.8rem;
    }

    .settings-tab-pill .mdi {
        font-size: 16px;
    }
}
</style>

@endsection

