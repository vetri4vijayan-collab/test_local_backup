@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')


<div class="container-fluid">
    <div class="row g-3">

        <!-- EPF Total Outflow Card -->
        <div class="col-12 col-sm-6 col-lg-3">
            <div
                class="bg-white border rounded-4 shadow-sm p-4 d-flex flex-column justify-content-between  card-grid-item ">
                <div class="d-flex align-items-center justify-content-between ">
                    <span class="fs-6 fw-bold text-uppercase tracking-wider text-black">EPF Total Outflow</span>
                    <span class="mdi mdi-office-building-outline fs-3 text-primary"></span>
                </div>
                <div class="mb-3">
                    <span class="fs-2 fw-black font-monospace d-block text-primary">
                        ₹1,45,200
                    </span>
                    <span class="small text-secondary d-block mt-1">
                        Emp: ₹72,600 | Employer: ₹72,600
                    </span>
                </div>
                <div>
                    <span class="small fw-bold d-inline-block ">
                        12% Employee + 12% Employer Rate
                    </span>
                </div>
            </div>
        </div>

        <!-- ESI Health Fund Total Card -->
        <div class="col-12 col-sm-6 col-lg-3">
            <div
                class="bg-white border rounded-4 shadow-sm p-4 d-flex flex-column justify-content-between  card-grid-item ">
                <div class="d-flex align-items-center justify-content-between ">
                    <span class="fs-6 fw-bold text-uppercase tracking-wider text-black">ESI Health Fund Total</span>
                    <span class="mdi mdi-shield-check-outline fs-3 text-success"></span>
                </div>
                <div class="mb-3">
                    <span class="fs-2 fw-black font-monospace text-success d-block">
                        ₹24,650
                    </span>
                    <span class="small text-secondary d-block mt-1">
                        Emp: ₹4,650 | Employer: ₹20,000
                    </span>
                </div>
                <div>
                    <span class="small fw-bold  d-inline-block">
                        0.75% Employee + 3.25% Employer Rate
                    </span>
                </div>
            </div>
        </div>

        <!-- Gratuity & LWF Provision Card -->
        <div class="col-12 col-sm-6 col-lg-3">
            <div
                class="bg-white border rounded-4 shadow-sm p-4 d-flex flex-column justify-content-between  card-grid-item ">
                <div class="d-flex align-items-center justify-content-between ">
                    <span class="fs-6 fw-bold text-uppercase tracking-wider text-dark">Gratuity & LWF Provision</span>
                    <span class="mdi mdi-file-document-outline fs-3" style="color: #581c87;"></span>
                </div>
                <div class="mb-3">
                    <span class="fs-2 fw-black font-monospace d-block" style="color: #581c87;">
                        ₹38,400
                    </span>
                    <span class="small text-secondary d-block mt-1">
                        Accrued across 45 personnel
                    </span>
                </div>
                <div>
                    <span class="small fw-bold d-inline-block">
                        4.81% Basic Accrual + Labor Fund
                    </span>
                </div>
            </div>
        </div>

        <!-- Enrolled Personnel Card -->
        <div class="col-12 col-sm-6 col-lg-3">
            <div
                class="bg-white border rounded-4 shadow-sm p-4 d-flex flex-column justify-content-between  card-grid-item ">
                <div class="d-flex align-items-center justify-content-between ">
                    <span class="fs-6 fw-bold text-uppercase tracking-wider text-dark">Enrolled Personnel</span>
                    <span class="mdi mdi-account-multiple-outline fs-3" style="color: #4f46e5;"></span>
                </div>
                <div class="mb-3">
                    <span class="fs-2 fw-black font-monospace text-[#16659E] d-block">
                        45 Staff Members
                    </span>
                    <span class="small text-secondary d-block mt-1">
                        Mapped to EPFO & ESIC portals
                    </span>
                </div>
                <div>
                    <span class="small fw-bold  d-inline-block">
                        100% Statutory Compliant
                    </span>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="bg-white p-3 shadow-sm rounded-3 mb-4 toolbar-container">
    <!-- Toolbar -->
    <div class="row g-3 align-items-center">
        <!-- Search -->
        <div class="col-12 col-lg">
            <div class="position-relative">
                <span class="position-absolute top-50 start-0 translate-middle-y ps-3 text-muted"
                    style="pointer-events: none;">
                    <i class="mdi mdi-magnify fs-5"></i>
                </span>
                <input id="hr-search-field" type="text"
                    placeholder="Search by Employee Name, Code, ESI No, PF No, or UAN..."
                    class="form-control form-control-sm ps-5 border border-light border-2 rounded-3 text-secondary"
                    style="height: 38px; width:500px; " />
            </div>
        </div>

        <!-- Actions -->
        <div class="col-12 col-lg-auto">
            <div class="d-flex flex-wrap align-items-center gap-2 action-wrapper">
                <!-- Department Filter -->
                <select class="select3 form-select form-select-sm dept-select w-200" aria-label="Department Filter">
                    <option selected>All Departments (45)</option>
                    <option value="hr">Human Resources</option>
                    <option value="finance">Finance</option>
                    <option value="operations">Operations</option>
                    <option value="it">Information Technology</option>
                    <option value="sales">Sales</option>
                </select>
                <!-- Export -->
                <button type="button" class="btn btn-sm btn-primary d-inline-flex align-items-center gap-2 export-btn"
                    title="Export ECR Return Data">
                    <i class="mdi mdi-file-document-outline"></i>
                    <span>Export ECR Data</span>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm esi-pf-ledger-card mb-4">
    <!-- Header -->
    <div
        class="card-header bg-white py-3 px-4 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 esi-pf-ledger-header">
        <div class="esi-pf-ledger-title-section">
            <h3 class="h5 fw-bold mb-1 d-flex align-items-center gap-2 text-dark esi-pf-ledger-title">
                <span class="mdi mdi-shield-check-outline"></span>
                <span>ESI, PF & UAN Statutory Employee Deductions Ledger</span>
            </h3>
            <p class="text-muted small mb-0 esi-pf-ledger-description">
                Compliant with Employees Provident Fund & Miscellaneous Provisions Act & ESIC Portal Regulations
            </p>
        </div>
        <span
            class="badge bg-light text-secondary border px-3 py-2 fs-6 fw-normal align-self-start align-self-md-center esi-pf-ledger-count">
            Showing 3 of 45 Staff
        </span>
    </div>

    <!-- Responsive Table -->
    <div class="table-responsive esi-pf-ledger-table-wrapper">
        <table class="table table-hover align-middle esi-pf-ledger-table mb-0 text-nowrap">
            <thead class="fw-semibold text-black fs-8 uppercase table-secondary ">
                <tr>
                    <th class="py-2 px-4 min-w-100px text-black esi-pf-col-employee">Employee Details</th>
                    <th class="py-2 px-3 min-w-100px text-black esi-pf-col-id">ESI Number</th>
                    <th class="py-2 px-3 min-w-100px text-black text-center esi-pf-col-id">PF Number</th>
                    <th class="py-2 px-3 min-w-100px text-black esi-pf-col-id">UAN Number</th>
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 120px;">
                        <div>EPF</div>
                        <div class="extra-small lh-1">Employee</div>
                        <div class="extra-small lh-1 mt-1">(12%)</div>
                    </th>
                    <!-- <th class="py-2 px-2 min-w-100px text-black text-end esi-pf-col-amount">EPF Employee (12%)</th> -->
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 120px;">
                        <div>EPF</div>
                        <div class="extra-small lh-1">Employer</div>
                        <div class="extra-small lh-1 mt-1">(12%)</div>
                    </th>
                    <!-- <th class="py-2 px-2 min-w-100px text-black text-end esi-pf-col-amount">EPF Employer (12%)</th> -->
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 120px;">
                        <div>ESI</div>
                        <div class="extra-small lh-1">Employee</div>
                        <div class="extra-small lh-1 mt-1">(0.75%)</div>
                    </th>
                    <!-- <th class="py-2 px-2 min-w-100px text-black text-end esi-pf-col-amount">ESI Employee (0.75%)</th> -->
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 120px;">
                        <div>ESI</div>
                        <div class="extra-small lh-1">Employer</div>
                        <div class="extra-small lh-1 mt-1">(3.25%)</div>
                    </th>
                    <!-- <th class="py-2 px-2 min-w-100px text-black text-end esi-pf-col-amount">ESI Employer (3.25%)</th> -->
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 120px;">
                        <div>Gratuity &</div>
                        <div class="extra-small lh-1"> LWF</div>
                    </th>
                    <!-- <th class="py-2 px-2 min-w-100px text-black text-end esi-pf-col-amount">Gratuity & LWF</th> -->
                    <th class="py-2 px-4 min-w-100px text-black text-center esi-pf-col-action">Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Dummy Row 1 -->
                <tr class="esi-pf-ledger-row">
                    <td class="py-3 esi-pf-employee-cell">
                        <div class="d-flex align-items-center gap-3 esi-pf-employee">
                            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold esi-pf-employee-avatar"
                                style="width: 38px; height: 38px; font-size: 14px;">
                                RA
                            </div>
                            <div class="esi-pf-employee-info">
                                <span class="d-block fw-semibold text-dark esi-pf-employee-name">Rahul Sharma</span>
                                <div class="d-flex align-items-center gap-1 small text-muted esi-pf-employee-meta">
                                    <span class="esi-pf-employee-id">EMP001</span>
                                    <span class="esi-pf-meta-separator">•</span>
                                    <span class="esi-pf-department">Finance</span>

                                </div>
                            </div>
                        </div>
                    </td>
                    <td class="py-1 px-3 esi-pf-id-cell">
                        <div class="d-flex align-items-center justify-center text-secondary  esi-pf-id-badge">
                            <span>33-89745-12</span>
                        </div>
                    </td>
                    <td class="py-3 px-3   esi-pf-id-cell">
                        <div class="d-flex align-items-center text-center text-secondary small esi-pf-id-badge">

                            <span>TN/MAS/87410/001</span>
                        </div>
                    </td>
                    <td class="py-3 px-3 esi-pf-id-cell">
                        <div class="d-flex align-items-center gap-1 text-secondary small esi-pf-id-badge">

                            <span>101245897412</span>
                        </div>
                    </td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-amount-cell esi-pf-employer-share">₹1,800
                    </td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-amount-cell esi-pf-employee-share">₹225</td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-amount-cell esi-pf-employer-share">₹975</td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-amount-cell esi-pf-gratuity">₹1,154</td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-amount-cell esi-pf-employee-share">₹1,800
                    </td>
                    <td class="py-3 px-4 text-center esi-pf-action-cell">
                        <span class="mdi mdi-pencil-box fs-2" data-bs-toggle="offcanvas"
                            data-bs-target="#employeeDrawer" role="button" title="Edit Remuneration"></span>
                    </td>
                </tr>

                <!-- Dummy Row 2 -->
                <tr class="esi-pf-ledger-row">
                    <td class="py-3  esi-pf-employee-cell">
                        <div class="d-flex align-items-center gap-3 esi-pf-employee">
                            <div class="rounded-circle bg-info text-white d-flex align-items-center justify-content-center fw-bold esi-pf-employee-avatar"
                                style="width: 38px; height: 38px; font-size: 14px;">
                                AP
                            </div>
                            <div class="esi-pf-employee-info">
                                <span class="d-block fw-semibold text-dark esi-pf-employee-name">Ananya Patel</span>
                                <div class="d-flex align-items-center gap-1 small text-muted esi-pf-employee-meta">
                                    <span class="esi-pf-employee-id">EMP002</span>
                                    <span class="esi-pf-meta-separator">•</span>
                                    <span class="esi-pf-department">Human Resources</span>

                                </div>
                            </div>
                        </div>
                    </td>
                    <td class="py-3 px-2 esi-pf-id-cell">
                        <div class="d-flex align-items-center justify-center text-secondary small esi-pf-id-badge">
                            <span>33-89745-13</span>
                        </div>
                    </td>
                    <td class="py-3 px-2 esi-pf-id-cell">
                        <div class="d-flex align-items-center gap-1 text-secondary small esi-pf-id-badge">
                            <span>TN/MAS/87410/002</span>
                        </div>
                    </td>
                    <td class="py-3 px-3 esi-pf-id-cell">
                        <div class="d-flex align-items-center gap-1 text-secondary small esi-pf-id-badge">

                            <span>101245897413</span>
                        </div>
                    </td>
                    <td class="py-3 px-3 text-center font-monospace  esi-pf-amount-cell esi-pf-employee-share">₹2,160
                    </td>
                    <td class="py-3 px-3 text-center font-monospace  esi-pf-amount-cell esi-pf-employer-share">₹2,160
                    </td>
                    <td class="py-3 px-3 text-center font-monospace  esi-pf-amount-cell esi-pf-employee-share">₹270</td>
                    <td class="py-3 px-3 text-center font-monospace  esi-pf-amount-cell esi-pf-employer-share">₹1,170
                    </td>
                    <td class="py-3 px-3 text-center font-monospace  esi-pf-amount-cell esi-pf-gratuity">₹1,385</td>
                    <td class="py-3 px-4 text-center esi-pf-action-cell">
                        <span class="mdi mdi-pencil-box fs-2" data-bs-toggle="offcanvas"
                            data-bs-target="#employeeDrawer" role="button" title="Edit Remuneration"></span>
                    </td>
                </tr>
            </tbody>

            <!-- Totals Footer -->
            <tfoot class="table-light fw-bold">
                <tr class="esi-pf-total-row">
                    <td colspan="4" class="py-3 px-4 esi-pf-total-label text-dark">
                        Total Cumulative Statutory Allocation (3 Staff)
                    </td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-total-employee ">₹3,960</td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-total-employer ">₹3,960</td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-total-employee ">₹495</td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-total-employer ">₹2,145</td>
                    <td class="py-3 px-3 text-center font-monospace esi-pf-total-gratuity">₹2,539</td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

{{-- EMPLOYEE DETAILS DRAWER --}}
<div class="offcanvas offcanvas-end employee-drawer" tabindex="-1" id="employeeDrawer"
    aria-labelledby="employeeDrawerLabel" data-bs-backdrop="true" style="width:1500px; max-width:100%;">
    {{-- HEADER --}}
    <div class="offcanvas-header border-bottom px-4 py-3 bg-primary">

        <div class="d-flex align-items-center gap-3">

            {{-- Employee Avatar --}}
            <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="
                width:46px;
                height:46px;
                background:#eff6ff;
                color:#16659E;
            ">
                <i class="mdi mdi-account fs-5"></i>
            </div>

            {{-- Employee Information --}}
            <div class="d-flex flex-column">

                <h5 class="mb-1 fw-bold text-white">
                    Madhavan Krishnan
                </h5>

                <span class="small text-white-50">
                    Lead Site Engineer
                </span>

                <span class="small text-white-50">
                    Engineering
                </span>

            </div>

        </div>


        {{-- Header Actions --}}
        <div class="d-flex align-items-center gap-2">
            {{-- Edit / Save Button --}}
            <button type="button" class="btn btn-sm d-flex align-items-center gap-1 px-3 py-2" id="employeeEditBtn"
                style=" background:rgba(224, 0, 0, 0.12); border:1px solid rgba(255,255,255,0.25); border-radius:6px; font-size:12px;
                font-weight:600; color:#ffffff;">
                <i class="mdi mdi-pencil-outline" id="employeeEditIcon"></i>
                <span id="employeeEditText">
                    Edit
                </span>
            </button>

            {{-- Close --}}
            <button type="button" class="btn-close btn-close-white ms-1" data-bs-dismiss="offcanvas" aria-label="Close">
            </button>
        </div>

    </div>

    {{--   BODY --}}
    <div class="offcanvas-body p-0">
        <div class="d-flex h-100 employee-drawer-layout">
            {{--  LEFT SIDEBAR --}}
            <div class="employee-sidebar border-end" style="
                    width:220px;
                    min-width:220px;
                    background:#f8fafc;">
                <div class="p-3">
                    <small class="text-uppercase fw-bold text-muted" style="
                            font-size:10px;
                            letter-spacing:.5px;">
                        Employee Dossier
                    </small>
                </div>

                <div id="employeeTabMenu">
                    <button type="button" class="employee-tab active" data-tab="personal">
                        <i class="mdi mdi-account-outline"></i>
                        <span>
                            KYC & Personal
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="education">
                        <i class="mdi mdi-school-outline"></i>
                        <span>
                            Education Details
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="experience">
                        <i class="mdi mdi-briefcase-outline"></i>
                        <span>
                            Work Experience
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="training">
                        <i class="mdi mdi-certificate-outline"></i>
                        <span>
                            Training Induction
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="references">
                        <i class="mdi mdi-shield-check-outline"></i>
                        <span>
                            Ref Checks
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="interview">
                        <i class="mdi mdi-file-sign"></i>
                        <span>
                            Interview Notes
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="family"> <i
                            class="mdi mdi-account-group-outline"></i>
                        <span>
                            Family & Dependents
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="remuneration">
                        <i class="mdi mdi-credit-card-outline"></i>
                        <span>
                            Remuneration
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="documents">
                        <i class="mdi mdi-file-document-outline"></i>
                        <span>
                            Employee Files
                        </span>
                    </button>
                </div>
            </div>

            {{--  RIGHT CONTENT --}}
            <div class="employee-content flex-grow-1" style="overflow-y:auto;">
                {{--  PERSONAL / KYC --}}
                <div class="employee-panel p-4" data-panel="personal">
                    <div class="employee-section-title">
                        <i class="mdi mdi-account-outline me-1"></i>
                        Personal Profile & KYC
                    </div>
                    <div class="employee-card">
                        <div class="row g-4">
                            {{-- Full Name --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Full Name
                                </span>
                                <span class="employee-value">
                                    Madhavan Krishnan
                                </span>
                            </div>
                            {{-- Email --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Email
                                </span>
                                <span class="employee-value">
                                    madhavan@example.com
                                </span>
                            </div>

                            {{-- Phone --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Phone
                                </span>
                                <span class="employee-value">
                                    +91 98765 43210
                                </span>
                            </div>
                            {{-- DOB --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Date of Birth
                                </span>
                                <span class="employee-value">
                                    15 Aug 1990
                                </span>
                            </div>
                            {{-- Gender --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Gender
                                </span>
                                <span class="employee-value">
                                    Male
                                </span>
                            </div>

                            {{-- Nationality --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Nationality
                                </span>
                                <span class="employee-value">
                                    Indian
                                </span>
                            </div>

                            {{-- Marital Status --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Marital Status
                                </span>
                                <span class="employee-value">
                                    Married
                                </span>
                            </div>
                            {{-- Aadhaar --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Aadhaar
                                </span>
                                <span class="employee-value">
                                    XXXX XXXX 4521
                                </span>
                            </div>
                            {{-- PAN --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    PAN
                                </span>
                                <span class="employee-value">
                                    ABCDE1234F
                                </span>
                            </div>
                            {{-- Address --}}
                            <div class="col-12">
                                <span class="employee-label">
                                    Address
                                </span>
                                <span class="employee-value">
                                    Chennai, Tamil Nadu
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- EDUCATION --}}
                <div class="employee-panel p-4 d-none" data-panel="education">
                    <div class="employee-section-title">
                        <i class="mdi mdi-school-outline me-1"></i>
                        Education Details
                    </div>
                    {{-- B.E --}}
                    <div class="employee-card education-card mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="row g-4 flex-grow-1">
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Qualification
                                    </span>
                                    <span class="employee-value">
                                        B.E. Civil Engineering
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Institution
                                    </span>
                                    <span class="employee-value">
                                        Anna University (CEG Campus), Chennai
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Passing Year
                                    </span>
                                    <span class="employee-value">
                                        2000
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Grade
                                    </span>
                                    <span class="employee-value">
                                        84%
                                    </span>
                                </div>
                            </div>
                            {{-- DELETE --}}
                            <button type="button" class="education-delete-btn" title="Delete Education">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </div>

                    {{-- M.Tech --}}
                    <div class="employee-card education-card mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="row g-4 flex-grow-1">
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Qualification
                                    </span>
                                    <span class="employee-value">
                                        M.Tech Construction Management
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Institution
                                    </span>
                                    <span class="employee-value">
                                        Indian Institute of Technology (IIT) Madras
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Passing Year
                                    </span>
                                    <span class="employee-value">
                                        2002
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Grade
                                    </span>
                                    <span class="employee-value">
                                        9.2 CGPA
                                    </span>
                                </div>
                            </div>


                            {{-- DELETE --}}
                            <button type="button" class="education-delete-btn" title="Delete Education">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </div>


                    <div class="education-add-box">
                        <div class="education-add-title mb-3">
                            ADD EDUCATION
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input" placeholder="Qualification">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input" placeholder="Institution">
                            </div>
                            <div class="col-md-6">
                                <input type="number" class="form-control education-input" placeholder="Passing Year">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input"
                                    placeholder="Grade / Percentage / CGPA">
                            </div>
                            <div class="col-12">
                                <button type="button" class="btn education-add-btn">
                                    <i class="mdi mdi-plus me-1"></i>
                                    Append Education
                                </button>
                            </div>
                        </div>
                    </div>
                </div>


                {{-- WORK EXPERIENCE PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="experience">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-briefcase-outline me-2 fs-5"></i>
                        Work Experience
                    </div>

                    {{-- Container for All Experience Cards --}}
                    <div id="experienceContainer">

                        {{-- Experience Item 1 --}}
                        <div class="card mb-3 p-3 position-relative experience-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-exp-btn py-0 px-1"
                                title="Delete Experience" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="exp-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fw-bold exp-view-designation"
                                        style="font-size: 14px; color: #1e293b;">Site Engineer</span>
                                    <span class="badge rounded-1 exp-view-duration"
                                        style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        2014 - 2018
                                    </span>
                                </div>
                                <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;">
                                    ABC Constructions
                                </div>
                                <div class="exp-view-roles mt-2"
                                    style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                    Managed daily site operations, supervised workforce, and ensured quality control
                                    compliance.
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="exp-edit-mode d-none mt-2 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm exp-input-designation"
                                            style="font-size: 11px;" value="Site Engineer">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Company
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm exp-input-company"
                                            style="font-size: 11px;" value="ABC Constructions">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Duration</label>
                                        <input type="text" class="form-control form-control-sm exp-input-duration"
                                            style="font-size: 11px;" value="2014 - 2018" placeholder="e.g. 2014 - 2018">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles &
                                            Responsibilities</label>
                                        <textarea class="form-control form-control-sm exp-input-roles" rows="2"
                                            style="font-size: 11px;"
                                            placeholder="Describe key responsibilities...">Managed daily site operations, supervised workforce, and ensured quality control compliance.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Experience Item 2 --}}
                        <div class="card mb-3 p-3 position-relative experience-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-exp-btn py-0 px-1"
                                title="Delete Experience" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            <div class="exp-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fw-bold exp-view-designation"
                                        style="font-size: 14px; color: #1e293b;">Senior Site Engineer</span>
                                    <span class="badge rounded-1 exp-view-duration"
                                        style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        2018 - 2022
                                    </span>
                                </div>
                                <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;">
                                    XYZ Infrastructure
                                </div>
                                <div class="exp-view-roles mt-2"
                                    style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                    Overseeing structural bridge construction and vendor management.
                                </div>
                            </div>

                            <div class="exp-edit-mode d-none mt-2 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm exp-input-designation"
                                            style="font-size: 11px;" value="Senior Site Engineer">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Company
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm exp-input-company"
                                            style="font-size: 11px;" value="XYZ Infrastructure">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Duration</label>
                                        <input type="text" class="form-control form-control-sm exp-input-duration"
                                            style="font-size: 11px;" value="2018 - 2022">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles &
                                            Responsibilities</label>
                                        <textarea class="form-control form-control-sm exp-input-roles" rows="2"
                                            style="font-size: 11px;">Overseeing structural bridge construction and vendor management.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- TRAINING INDUCTION PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="training">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-certificate-outline me-2 fs-5"></i>
                        Training Induction
                    </div>

                    {{-- Container for All Training Cards --}}
                    <div id="trainingContainer">

                        {{-- Item 1 --}}
                        <div class="card mb-3 p-3 position-relative training-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-training-btn py-0 px-1"
                                title="Delete Training" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="training-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="fw-bold training-view-title"
                                            style="font-size: 14px; color: #1e293b;">Site Safety Induction</span>
                                        <small class="d-block text-muted mt-1 training-view-date"
                                            style="font-size: 12px; color: #94a3b8;">10 Jan 2024</small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success training-view-status"
                                        style="font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        Completed
                                    </span>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="training-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Training
                                            Title</label>
                                        <input type="text" class="form-control form-control-sm training-input-title"
                                            style="font-size: 11px;" value="Site Safety Induction">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Completion
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm training-input-date"
                                            style="font-size: 11px;" value="10 Jan 2024" placeholder="e.g. 10 Jan 2024">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Status</label>
                                        <select class="form-select form-select-sm training-input-status"
                                            style="font-size: 11px;">
                                            <option value="Completed" selected>Completed</option>
                                            <option value="Pending">Pending</option>
                                            <option value="In Progress">In Progress</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Item 2 --}}
                        <div class="card mb-3 p-3 position-relative training-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-training-btn py-0 px-1"
                                title="Delete Training" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            <div class="training-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="fw-bold training-view-title"
                                            style="font-size: 14px; color: #1e293b;">Construction Safety</span>
                                        <small class="d-block text-muted mt-1 training-view-date"
                                            style="font-size: 12px; color: #94a3b8;">15 Mar 2024</small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success training-view-status"
                                        style="font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        Completed
                                    </span>
                                </div>
                            </div>

                            <div class="training-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Training
                                            Title</label>
                                        <input type="text" class="form-control form-control-sm training-input-title"
                                            style="font-size: 11px;" value="Construction Safety">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Completion
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm training-input-date"
                                            style="font-size: 11px;" value="15 Mar 2024">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Status</label>
                                        <select class="form-select form-select-sm training-input-status"
                                            style="font-size: 11px;">
                                            <option value="Completed" selected>Completed</option>
                                            <option value="Pending">Pending</option>
                                            <option value="In Progress">In Progress</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- REFERENCE CHECKS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="references">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-shield-check-outline me-2 fs-5"></i>
                        Reference Checks
                    </div>

                    {{-- Container for All Reference Cards --}}
                    <div id="referenceContainer">

                        {{-- Reference Item 1 --}}
                        <div class="card mb-3 p-3 position-relative reference-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-ref-btn py-0 px-1"
                                title="Delete Reference" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="ref-view-mode">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-bold ref-view-name"
                                            style="font-size: 14px; color: #1e293b;">Rajesh Kumar</span>
                                        <span class="badge bg-success-subtle text-success ref-view-status"
                                            style="font-weight: 600; font-size: 10px; padding: 3px 6px;">
                                            VERIFIED
                                        </span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center gap-3 text-secondary"
                                    style="font-size: 13px; color: #64748b;">
                                    <div>
                                        <small class="text-muted">Designation:</small>
                                        <span class="ref-view-designation fw-medium" style="color: #334155;">Project
                                            Manager</span>
                                    </div>
                                    <span style="border-right: 1px solid #cbd5e1; height: 12px;"></span>
                                    <div>
                                        <small class="text-muted">Phone:</small>
                                        <span class="ref-view-phone fw-medium" style="color: #334155;">+91 98765
                                            12345</span>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="ref-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm ref-input-name"
                                            style="font-size: 11px;" value="Rajesh Kumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Verification
                                            Status</label>
                                        <select class="form-select form-select-sm ref-input-status"
                                            style="font-size: 11px;">
                                            <option value="VERIFIED" selected>VERIFIED</option>
                                            <option value="PENDING">PENDING</option>
                                            <option value="UNVERIFIED">UNVERIFIED</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm ref-input-designation"
                                            style="font-size: 11px;" value="Project Manager">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Phone
                                            Number</label>
                                        <input type="text" class="form-control form-control-sm ref-input-phone"
                                            style="font-size: 11px;" value="+91 98765 12345">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- INTERVIEW LOGS & ASSESSMENT PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="interview">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-file-sign me-2 fs-5"></i>
                        Recruiter Interview Logs & Assessment Comments
                    </div>

                    {{-- Container for All Interview Log Cards --}}
                    <div id="interviewContainer">

                        {{-- Interview Item 1 --}}
                        <div class="card mb-3 p-3 position-relative interview-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-interview-btn py-0 px-1"
                                title="Delete Interview Log" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="interview-view-mode">
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Screening
                                            Recruiter</small>
                                        <span class="fw-semibold interview-view-recruiter"
                                            style="font-size: 13px; color: #1e293b;">Suresh Kumar</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Evaluation
                                            Date</small>
                                        <span class="fw-medium interview-view-date"
                                            style="font-size: 13px; color: #334155;">12 Dec 2023</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Rating</small>
                                        <span class="fw-medium interview-view-rating"
                                            style="font-size: 13px; color: #334155;">4.5 / 5</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">HR Decision
                                            Verdict</small>
                                        <span class="badge bg-success-subtle text-success interview-view-verdict"
                                            style="font-weight: 600; font-size: 11px; padding: 4px 8px;">
                                            Selected
                                        </span>
                                    </div>
                                    <div class="col-12 mt-2">
                                        <small class="text-muted d-block" style="font-size: 11px;">Comments</small>
                                        <p class="mb-0 interview-view-comments"
                                            style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                            Strong technical knowledge and excellent site management skills.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="interview-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Screening
                                            Recruiter</label>
                                        <input type="text"
                                            class="form-control form-control-sm interview-input-recruiter"
                                            style="font-size: 11px;" value="Suresh Kumar">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Evaluation
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm interview-input-date"
                                            style="font-size: 11px;" value="12 Dec 2023" placeholder="e.g. 12 Dec 2023">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Rating</label>
                                        <input type="text" class="form-control form-control-sm interview-input-rating"
                                            style="font-size: 11px;" value="4.5 / 5" placeholder="e.g. 4.5 / 5">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">HR Decision
                                            Verdict</label>
                                        <select class="form-select form-select-sm interview-input-verdict"
                                            style="font-size: 11px;">
                                            <option value="Selected" selected>Selected</option>
                                            <option value="On Hold">On Hold</option>
                                            <option value="Rejected">Rejected</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Assessment
                                            Comments</label>
                                        <textarea class="form-control form-control-sm interview-input-comments" rows="2"
                                            style="font-size: 11px;"
                                            placeholder="Enter assessment comments...">Strong technical knowledge and excellent site management skills.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- FAMILY & EMERGENCY CONTACTS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="family">
                    {{-- Section Header --}}
                    <div class="employee-section-title mb-3">
                        <i class="mdi mdi-account-group-outline me-1"></i>
                        Family Members & Emergency Contacts Info
                    </div>

                    {{-- Container for Existing Family Members --}}
                    <div id="familyContainer">

                        {{-- Family Member 1 --}}
                        <div class="family-member-card mb-3 family-item position-relative">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="family-delete-btn d-none position-absolute top-0 end-0 m-3 delete-family-btn"
                                title="Remove Family Member">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="family-view-mode">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <span class="family-member-name family-view-name">Sundari Sivakumar</span>
                                            <span class="family-relation-badge family-view-relation">SPOUSE</span>
                                        </div>
                                        <div class="family-member-details">
                                            <span>
                                                <small>Age:</small>
                                                <span class="family-view-age">44</span> Years
                                            </span>
                                            <span class="family-divider"></span>
                                            <span>
                                                <small>Occupation:</small>
                                                <span class="family-view-occupation">Homemaker</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="family-edit-mode d-none pe-4">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm family-input-name"
                                            style="font-size: 11px;" value="Sundari Sivakumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Relation</label>
                                        <input type="text" class="form-control form-control-sm family-input-relation"
                                            style="font-size: 11px;" value="SPOUSE">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                                        <input type="number" class="form-control form-control-sm family-input-age"
                                            style="font-size: 11px;" value="44">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Occupation</label>
                                        <input type="text" class="form-control form-control-sm family-input-occupation"
                                            style="font-size: 11px;" value="Homemaker">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Family Member 2 --}}
                        <div class="family-member-card mb-4 family-item position-relative">
                            <button type="button"
                                class="family-delete-btn d-none position-absolute top-0 end-0 m-3 delete-family-btn"
                                title="Remove Family Member">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="family-view-mode">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <span class="family-member-name family-view-name">Kavin Sivakumar</span>
                                            <span class="family-relation-badge family-view-relation">SON</span>
                                        </div>
                                        <div class="family-member-details">
                                            <span>
                                                <small>Age:</small>
                                                <span class="family-view-age">16</span> Years
                                            </span>
                                            <span class="family-divider"></span>
                                            <span>
                                                <small>Occupation:</small>
                                                <span class="family-view-occupation">Student</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="family-edit-mode d-none pe-4">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm family-input-name"
                                            style="font-size: 11px;" value="Kavin Sivakumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Relation</label>
                                        <input type="text" class="form-control form-control-sm family-input-relation"
                                            style="font-size: 11px;" value="SON">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                                        <input type="number" class="form-control form-control-sm family-input-age"
                                            style="font-size: 11px;" value="16">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Occupation</label>
                                        <input type="text" class="form-control form-control-sm family-input-occupation"
                                            style="font-size: 11px;" value="Student">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    {{-- ADD FAMILY MEMBER BOX (EDIT MODE ONLY) --}}
                    <div class="family-add-box d-none" id="familyAddBox">
                        <div class="family-add-title mb-3">
                            ADD FAMILY MEMBER / EMERGENCY CONTACT
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" id="newFamilyName" class="form-control family-input"
                                    placeholder="Full Name">
                            </div>
                            <div class="col-md-6">
                                <input type="text" id="newFamilyRelation" class="form-control family-input"
                                    placeholder="Relation (e.g. Spouse / Father / Sister)">
                            </div>
                            <div class="col-md-6">
                                <input type="number" id="newFamilyAge" class="form-control family-input"
                                    placeholder="Age">
                            </div>
                            <div class="col-md-6">
                                <input type="text" id="newFamilyOccupation" class="form-control family-input"
                                    placeholder="Occupation (e.g. Homemaker / Farmer)">
                            </div>
                            <div class="col-12">
                                <button type="button" class="btn family-add-btn" id="appendFamilyBtn">
                                    <i class="mdi mdi-plus me-1"></i>
                                    Append Family Member
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                {{--  REMUNERATION --}}
                <div class="employee-panel p-4 d-none" data-panel="remuneration">
                    <!-- Section Title -->
                    <div class="employee-section-title mb-4">
                        <i class="mdi mdi-credit-card-outline me-1"></i>
                        Compensation, Mapped Salary Structure & Statutory Remuneration
                    </div>
                    <!-- SUMMARY METRIC CARDS -->
                    <div class="row g-3 mb-4">
                        <!-- Net Monthly Take Home -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#ecfdf5; border:1px solid #d1fae5;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#047857;">
                                    Net Monthly Take-Home
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#047857;">
                                    Rs. 17,850
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#059669;">
                                    Component A - Component B
                                </small>

                            </div>
                        </div>


                        <!-- Gross Earnings -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#eff6ff; border:1px solid #dbeafe;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#16659E;">
                                    Gross Earnings (Comp A)
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#16659E;">
                                    Rs. 22,500
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#16659E;">
                                    Basic + HRA + Special
                                </small>

                            </div>
                        </div>


                        <!-- Deductions -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#fff1f2; border:1px solid #ffe4e6;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#be123c;">
                                    Deductions (Comp B)
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#be123c;">
                                    Rs. 4,650
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#e11d48;">
                                    PF + ESI + PT + TDS
                                </small>

                            </div>
                        </div>


                        <!-- Total CTC -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#eef2ff; border:1px solid #e0e7ff;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#0C3C62;">
                                    Total Monthly CTC
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#0C3C62;">
                                    Rs. 25,850
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#4f46e5;">
                                    Comp A + Employer Share
                                </small>

                            </div>
                        </div>

                    </div>


                    <!-- MAPPED SALARY STRUCTURE LEDGER-->
                    <div class="p-3 p-md-4 rounded-3 mb-4" style="background:#f8fafc; border:1px solid #e2e8f0;">

                        <!-- Ledger Header -->
                        <div
                            class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-3 mb-3">

                            <div>
                                <h6 class="mb-1 fw-bold text-uppercase"
                                    style="font-size:11px; letter-spacing:.6px; color:#1e293b;">
                                    Mapped Salary Structure Ledger
                                </h6>

                                <small class="text-muted" style="font-size:10px;">
                                    Indian Labour Law 2026 Compliant Wage Component Breakdown
                                </small>
                            </div>

                            <span class="badge rounded-pill" style="font-size:9px; background:#dbeafe; color:#16659E;">
                                Staff Category
                            </span>

                        </div>


                        <div class="row g-3">

                            <!-- COMPONENT A - EARNINGS -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">

                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">

                                        <span class="fw-bold text-uppercase" style="font-size:10px; color:#1e40af;">
                                            Component A • Earnings
                                        </span>

                                        <!-- Editable Total -->
                                        <div id="componentATotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px; color:#1e3a8a;">
                                                ₹ 22,500
                                            </span>
                                        </div>

                                        <div id="componentATotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace p-0"
                                                value="22500" style="width:70px;font-size:11px;">
                                        </div>

                                    </div>

                                    <!-- Content -->
                                    <div class="small">

                                        <!-- Basic -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                Basic Pay + DA
                                            </span>

                                            <div id="basicView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 12,000
                                                </span>
                                            </div>

                                            <div id="basicEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="12000" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- HRA -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                HRA & Other Allowance
                                            </span>

                                            <div id="hraView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 6,000
                                                </span>
                                            </div>

                                            <div id="hraEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="6000" style="width:70px;font-size:10px;">
                                            </div>
                                        </div>
                                        <!-- Special Allowance -->
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="text-dark" style="font-size:10px;">
                                                Special Allowance
                                            </span>
                                            <div id="specialView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 4,500
                                                </span>
                                            </div>
                                            <div id="specialEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="4500" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>


                            <!-- COMPONENT B - DEDUCTIONS -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">
                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                                        <span class="fw-bold text-uppercase" style="font-size:10px;color:#9f1239;">
                                            Component B • Deductions
                                        </span>
                                        <div id="componentBTotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px;color:#9f1239;">
                                                ₹ 4,650
                                            </span>
                                        </div>
                                        <div id="componentBTotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace"
                                                value="4650" style="width:70px;font-size:11px;">
                                        </div>
                                    </div>

                                    <div class="small">

                                        <!-- EPF -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                EPF Employee (12%)
                                            </span>

                                            <div id="epfEmployeeView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 1,440
                                                </span>
                                            </div>

                                            <div id="epfEmployeeEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1440" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- ESI -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                ESI Employee (0.75%)
                                            </span>
                                            <div id="esiEmployeeView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 169
                                                </span>
                                            </div>
                                            <div id="esiEmployeeEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="169" style="width:70px;font-size:10px;">
                                            </div>
                                        </div>

                                        <!-- PT -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                Professional Tax (PT)
                                            </span>
                                            <div id="ptView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 200
                                                </span>
                                            </div>
                                            <div id="ptEdit" class="d-none ">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace "
                                                    value="200" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- TDS -->
                                        <div class="d-flex justify-content-between align-items-center">

                                            <span class="text-dark" style="font-size:10px;">
                                                Income Tax / TDS
                                            </span>

                                            <div id="tdsView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 2,841
                                                </span>
                                            </div>

                                            <div id="tdsEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="2841" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>


                            <!-- COMPONENT C - EMPLOYER SHARE -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">

                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                                        <span class="fw-bold text-uppercase" style="font-size:10px;color:#3730a3;">
                                            Component C • Employer Share
                                        </span>
                                        <div id="componentCTotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px;color:#312e81;">
                                                ₹ 3,350
                                            </span>
                                        </div>
                                        <div id="componentCTotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace"
                                                value="3350" style="width:70px;font-size:11px;">
                                        </div>
                                    </div>

                                    <div class="small">
                                        <!-- EPF Employer -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                EPF Employer (12%)
                                            </span>
                                            <div id="epfEmployerView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 1,440
                                                </span>
                                            </div>

                                            <div id="epfEmployerEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1440" style="width:70px;;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- ESI Employer -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                ESI Employer (3.25%)
                                            </span>

                                            <div id="esiEmployerView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 731
                                                </span>
                                            </div>

                                            <div id="esiEmployerEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="731" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- Gratuity -->
                                        <div class="d-flex justify-content-between align-items-center">

                                            <span class="text-dark" style="font-size:10px;">
                                                Gratuity & LWF
                                            </span>

                                            <div id="gratuityView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 1,179
                                                </span>
                                            </div>

                                            <div id="gratuityEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1179" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>



                        <!--STATUTORY & BANKING DETAILS-->
                        <div class="border-top pt-4 mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <i class="mdi mdi-bank-outline me-2" style="font-size:18px; color:#16659E;"></i>
                                <h6 class="mb-0 fw-bold text-uppercase" style="font-size:11px; letter-spacing:.6px;">
                                    Statutory & Banking Registration Details
                                </h6>
                            </div>

                            <div class="row g-3">

                                <!-- Base Daily Wage -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Base Month Rate
                                    </label>
                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        Rs. 13,500/ month rate
                                    </div>

                                </div>
                                <!-- Special Allowance -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Special Monthly Allowance
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        Rs. 4,500 / month
                                    </div>

                                </div>


                                <!-- EPF / UAN -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        EPF / UAN Account Number
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        TN/MAS/87410/001
                                    </div>

                                </div>


                                <!-- ESI -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        ESI (State Insurance) Code
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        33-89745-12
                                    </div>

                                </div>


                                <!-- Bank -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Bank Partner Name
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2">
                                        State Bank of India
                                    </div>

                                </div>


                                <!-- Account / IFSC -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Bank Account Number / IFSC Code
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        AC: 30456123456
                                        <span class="text-muted mx-1">•</span>
                                        SBIN0000845
                                    </div>

                                </div>

                            </div>

                        </div>


                        <!--   PROMOTION & APPRAISAL CAREER HISTORY  -->
                        <div class="p-3 p-md-4 rounded-3" style="background:#f8fafc; border:1px solid #e2e8f0;">
                            <!-- Header -->
                            <div
                                class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-3 mb-3">
                                <div>
                                    <h6 class="mb-1 fw-bold text-uppercase d-flex align-items-center"
                                        style="font-size:11px; letter-spacing:.6px; color:#1e293b;">
                                        <i class="mdi mdi-trending-up me-1" style="font-size:17px; color:#059669;"></i>
                                        Promotion & Appraisal Career History
                                    </h6>
                                    <small class="text-muted" style="font-size:10px;">
                                        Historical Wage Revisions, Designations, and Performance Appraisals Mapped to
                                        Profile
                                    </small>
                                </div>
                                <span class="badge rounded-pill d-flex align-items-center gap-1"
                                    style="font-size:9px; background:#d1fae5; color:#065f46;">
                                    <i class="mdi mdi-auto-fix"></i>
                                    3 Records Mapped
                                </span>
                            </div>


                            <!--  PROMOTION RECORD 1   -->
                            <div
                                class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-2 mb-3">

                                <div class="d-flex flex-wrap align-items-center gap-2">

                                    <span class="badge" style="font-size:9px; background:#f3e8ff; color:#7e22ce;">
                                        Promotion
                                    </span>

                                    <span class="text-muted font-monospace" style="font-size:10px;">
                                        Effective: 01 Jan 2025 (January)
                                    </span>

                                </div>


                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge" style="font-size:9px; background:#fffbeb; color:#b45309;">
                                        <i class="mdi mdi-star me-1"></i>
                                        4.8 / 5
                                    </span>
                                    <span class="badge" style="font-size:9px; background:#eff6ff; color:#1d4ed8;">
                                        Approved
                                    </span>

                                </div>

                            </div>


                            <div class="row g-3">

                                <!-- Designation -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Designation / Role Shift
                                        </span>

                                        <div class="d-flex align-items-center gap-2">

                                            <span class="text-muted text-decoration-line-through"
                                                style="font-size:10px;">
                                                Site Engineer
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold" style="font-size:11px; color:#065f46;">
                                                Senior Site Engineer
                                            </span>

                                        </div>

                                    </div>

                                </div>


                                <!-- Basic Revision -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Base Pay Revision
                                        </span>

                                        <div class="d-flex align-items-center flex-wrap gap-2">

                                            <span class="text-muted text-decoration-line-through font-monospace"
                                                style="font-size:10px;">
                                                Rs. 10,000
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold font-monospace" style="font-size:11px; color:#047857;">
                                                Rs. 12,000
                                            </span>

                                            <span class="badge"
                                                style="font-size:8px; background:#d1fae5; color:#065f46;">
                                                +20%
                                            </span>

                                        </div>

                                    </div>

                                </div>


                                <!-- Gross Revision -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Gross Monthly Revision
                                        </span>

                                        <div class="d-flex align-items-center flex-wrap gap-2">

                                            <span class="text-muted text-decoration-line-through font-monospace"
                                                style="font-size:10px;">
                                                Rs. 19,000
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold font-monospace" style="font-size:11px; color:#065f46;">
                                                Rs. 22,500
                                            </span>

                                            <span class="text-success font-monospace fw-bold" style="font-size:10px;">
                                                (+Rs. 3,500)
                                            </span>

                                        </div>

                                    </div>

                                </div>

                            </div>


                            <!-- Remarks -->
                            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3 p-2 rounded-2"
                                style="background:#f8fafc; border:1px solid #e2e8f0;">

                                <div style="font-size:11px; color:#475569;">

                                    <span class="fw-bold text-dark">
                                        Remarks:
                                    </span>

                                    Promoted based on excellent project performance.

                                    <small class="d-block text-muted mt-1">
                                        Approved By: Suresh Kumar - Project Manager
                                    </small>

                                </div>


                                <div class="d-flex align-items-center gap-2">

                                    <span class="badge font-monospace"
                                        style="font-size:9px; background:#e2e8f0; color:#334155;">
                                        Ref: APP-2025-001
                                    </span>

                                    <button type="button" class="btn btn-sm text-white d-flex align-items-center gap-1"
                                        style="
                            background:#16659E;
                            font-size:10px;
                            font-weight:700;
                            border-radius:6px;
                        ">

                                        <i class="mdi mdi-download-outline"></i>
                                        Letter
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- COMPLIANCE & DOCUMENTS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="documents">
                    {{-- Section Header --}}
                    <div class="employee-section-title mb-3">
                        <i class="mdi mdi-file-document-outline me-1"></i>
                        Compliance Folders & Verified Documents
                    </div>

                    {{-- Documents Grid --}}
                    <div class="documents-grid" id="documentsGrid">

                        {{-- Document Card 1: Aadhaar --}}
                        <div
                            class="document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        Aadhaar_Card_Sivakumar.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        Aadhaar
                                        <span class="document-meta-divider mx-1">•</span>
                                        1.2 MB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                {{-- Hidden by default; visible only in Edit mode --}}
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                        {{-- Document Card 2: PAN --}}
                        <div
                            class="document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        PAN_Card_Sivakumar.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        PAN
                                        <span class="document-meta-divider mx-1">•</span>
                                        980 KB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                        {{-- Document Card 3: Experience --}}
                        <div
                            class="document-card mb-4 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        IT_Experience_Certificate.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        Experience
                                        <span class="document-meta-divider mx-1">•</span>
                                        1.8 MB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                    </div>

                    {{-- UPLOAD SUPPORTING DOCUMENT BOX --}}
                    <div class="document-upload-box p-3 border rounded bg-light d-none" id="documentUploadBox">
                        <div class="document-upload-title font-monospace text-uppercase fw-bold text-muted mb-3"
                            style="font-size: 11px; letter-spacing: 0.5px;">
                            UPLOAD SUPPORTING DOCUMENT
                        </div>

                        <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2">
                            {{-- Document Type Dropdown --}}
                            <div style="flex: 1; min-width: 160px;">
                                <select id="documentType" class="form-select form-select-sm w-100"
                                    style="font-size: 12px; height: 38px;">
                                    <option value="KYC Document">KYC Document</option>
                                    <option value="Experience">Experience Certificate</option>
                                    <option value="Education">Education Certificate</option>
                                    <option value="Other Certificate" selected>Other Certificate</option>
                                </select>
                            </div>

                            {{-- Select File Button --}}
                            <div style="flex: 1.5; min-width: 150px;">
                                <input type="file" id="documentFileInput" class="d-none"
                                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                                <button type="button" id="triggerFileSelectBtn"
                                    class="btn btn-sm btn-outline-secondary w-100 d-flex align-items-center justify-content-center text-truncate px-3"
                                    style="font-size: 12px; height: 38px;">
                                    <i class="mdi mdi-paperclip me-1 fs-6"></i>
                                    <span class="text-truncate">Select File...</span>
                                </button>
                            </div>

                            {{-- Upload Action Button --}}
                            <div style="flex: 0 0 auto;">
                                <button type="button" id="documentUploadBtn"
                                    class="btn btn-sm btn-primary w-100 d-flex align-items-center justify-content-center text-nowrap px-3"
                                    style="font-size: 12px; height: 38px;">
                                    <i class="mdi mdi-cloud-upload-outline me-1 fs-6"></i> Upload Document
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


<style>
/* Custom CSS Alignment & Support Styles */
.card-grid-item {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 100%;
    border-radius: 9%;
}

.emp_info {
    font-size: 12px;
}

.emp_rate {
    font-size: 12px;

}


/* Container Spacing & Alignment */
.toolbar-container {
    width: 100%;
    margin-top: 20px;
}

/* Search Container */
.search-group {
    width: 100%;
    max-width: 500px;
}

/* .input-group ,.search-group{
  width:250%;
} */
/* Search Input */
.search-input {
    width: 210%;
    height: 38px;
    font-size: 13px;
    border: 1px solid #dee2e6;
    border-left: 0;
    border-radius: 0 6px 6px 0;
}

/* Search Icon */
.search-icon {
    width: 40px;
    height: 38px;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 0;

    color: #6c757d;

    border: 1px solid #dee2e6;
    border-right: 0;

    border-radius: 6px 0 0 6px;
}

/* Focus */
.search-input:focus {
    border-color: #dee2e6;
    box-shadow: none;
    background-color: #fff;
}

/* Keep icon area unchanged when input is focused */
.search-group:focus-within .search-icon {
    border-color: #dee2e6;
    background-color: #fff;
}


/* Medium / Large */
@media (min-width: 992px) {
    .search-group {
        width: 380px;
    }
}


/* Small devices */
@media (max-width: 991.98px) {
    .search-group {
        width: 100%;
        max-width: 100%;
    }
}


/* Action Controls & Responsive Behavior */
.dept-select {
    min-width: 300px;
}

/* Responsive collapse alignment for mobile screens */
@media (max-width: 991.98px) {
    .action-wrapper {
        width: 100%;
        justify-content: space-between;
    }

    .dept-select {
        flex: 1;
        width: auto !important;
    }
}

/* list table  */
/* Main Card & Header Container */

.esi-pf-ledger-card {
    margin-top: 25px;
    overflow: hidden;
    background-color: #ffffff;
}

.esi-pf-ledger-header {}

.esi-pf-ledger-title {
    font-size: 1.1rem;
    color: #0f172a;
}

.esi-pf-ledger-description {
    font-size: 0.825rem;
    color: #64748b;
}

.esi-pf-ledger-count {
    font-size: 0.8rem;
    font-weight: 500;
    color: #475569;
}

/* Table Wrapper & Layout */
.esi-pf-ledger-table-wrapper {
    width: 100%;


}

.esi-pf-ledger-table {
    width: 100%;
    margin-bottom: 0;
    white-space: nowrap;
    vertical-align: middle;
}

.esi-pf-ledger-table th {
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 0.05em;
    color: #64748b;

    border-bottom: 2px solid #e2e8f0;
}

.esi-pf-ledger-row {
    transition: background-color 0.15s ease-in-out;
}

.esi-pf-ledger-row:hover {
    background-color: #f8fafc;
}

/* Employee Column Styling */
.esi-pf-employee-cell {
    min-width: 250px;
    padding: 0px;
}

.esi-pf-employee {
    display: flex;
    align-items: center;
    gap: 12px;
}

.esi-pf-employee-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background-color: #e0f2fe;
    color: #0369a1;
    font-size: 0.8rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.esi-pf-employee-name {
    font-size: 0.75rem;
    font-weight: 600;
    color: #1e293b;
    display: block;
}

.esi-pf-employee-meta {
    font-size: 0.65rem;
    color: #64748b;
    display: flex;
    align-items: center;
    gap: 6px;
}

.esi-pf-employment-type {
    font-size: 9px !important;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 600;
}

.esi-pf-permanent {
    background-color: #dcfce7;
    color: #166534;
}

.esi-pf-contract {
    background-color: #fef9c3;
    color: #854d0e;
}

/* ID Badges (ESI, PF, UAN) */
.esi-pf-id-cell {
    font-size: 0.825rem;
    color: #475569;
}

.esi-pf-id-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-family: var(--bs-font-monospace);
    font-size: 0.8rem;
    color: #334155;
}

/* Amount & Numeric Cells */
.esi-pf-amount-cell {
    font-family: var(--bs-font-monospace);
    font-size: 0.85rem;
    font-weight: 200;
    color: #1e293b;
}

.esi-pf-employee-share {
    color: #0369a1;
}

.esi-pf-employer-share {
    color: #047857;
}

.esi-pf-gratuity {
    color: #7e22ce;
}

/* Action Button */
/* Action Icon Hover Effect */
.esi-pf-action-cell .mdi-pencil-box {
    color: #15171a;
    /* Default muted icon color */
    cursor: pointer;
    transition: all 0.2s ease-in-out;
}

.esi-pf-action-cell .mdi-pencil-box:hover {
    color: #98acc9;
    transform: scale(1.15);
}

/* Totals Footer Row */
.esi-pf-total-row td {
    background-color: #f1f5f9 !important;
    font-weight: 700;
    border-top: 2px solid #cbd5e1;
}

.esi-pf-total-label {
    font-size: 0.85rem;
    color: #0f172a;
}

/* Emp - drawer start */
/* TABLE */

.table> :not(caption)>*>* {
    border-bottom-color: #f1f5f9;
}

.table thead th {
    white-space: nowrap;
}

.table tbody tr:last-child td {
    border-bottom: 0;
}



.employee-drawer {
    width: min(900px, 90vw) !important;
}

.employee-drawer-layout {
    min-height: calc(100vh - 80px);
}

/* Sidebar */
.employee-tab {
    width: 100%;
    border: 0;
    background: transparent;
    padding: 11px 16px;
    display: flex;
    align-items: center;
    gap: 10px;
    text-align: left;
    color: #64748b;
    font-size: 12px;
    font-weight: 600;
    transition: all .2s ease;
    position: relative;
}

.employee-tab i {
    font-size: 17px;
    width: 20px;
    text-align: center;
}

.employee-tab:hover {
    background: #eef6ff;
    color: #16659E;
}

.employee-tab.active {
    background: #e8f2ff;
    color: #0C3C62;
}

.employee-tab.active::before {
    content: "";
    position: absolute;
    left: 0;
    top: 6px;
    bottom: 6px;
    width: 3px;
    border-radius: 0 4px 4px 0;
    background: #16659E;
}

/* Content */
.employee-content {
    background: #ffffff;
    overflow-y: auto;
}



.employee-card {
    border: 1px solid #0f172a;
    border-radius: 10px;
    padding: 16px;
    margin-bottom: 15px;
    background: #fff;
}

.employee-label {
    display: block;
    color: #94a3b8;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    margin-bottom: 4px;
}

.employee-value {
    color: #334155;
    font-size: 13px;
    font-weight: 600;
}

.employee-row:hover {
    background-color: #f8fbff;
}


/* Editable input style */
.employee-edit-input {
    width: 100%;
    border: 1px solid #d7dee8;
    border-radius: 6px;
    padding: 8px 10px;
    font-size: 13px;
    color: #334155;
    background: #ffffff;
    outline: none;
    transition: all .2s ease;
}

.employee-edit-input:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, .08);
}

textarea.employee-edit-input {
    min-height: 90px;
    resize: vertical;
}

.employee-editing .employee-card {
    background: #fbfdff;
}

.employee-editing .employee-label {
    margin-bottom: 6px;
}

/* Save button */
#employeeEditBtn.is-saving {
    background: #059669 !important;
    color: #ffffff !important;
}

/* FAMILY MEMBERS */

.family-member-card {
    border: 1px solid #0f172a;
    border-radius: 12px;
    padding: 17px 16px;
    background: #ffffff;
    transition: all 0.2s ease;
}

.family-member-card:hover {
    border-color: #16659E;
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05);
}


/* Member Name */

.family-member-name {
    font-size: 12px;
    font-weight: 700;
    color: #0f172a;
}


/* Relationship Badge */

.family-relation-badge {
    display: inline-flex;
    align-items: center;
    padding: 3px 8px;
    border-radius: 6px;
    background: #eff6ff;
    color: #16659E;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 0.3px;
}


/* Member Details */

.family-member-details {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #16659E;
    font-size: 10px;
}

.family-member-details small {
    color: #94a3b8;
    font-size: 9px;
    margin-right: 4px;
}


/* Divider */

.family-divider {
    width: 1px;
    height: 14px;
    background: #cbd5e1;
}


/* Delete Button */

.family-delete-btn {
    border: 0;
    background: transparent;
    color: #f43f5e;
    font-size: 17px;
    padding: 2px;
    cursor: pointer;
    transition: color 0.2s ease;
}

.family-delete-btn:hover {
    color: #be123c;
}


/*             ===
   ADD FAMILY MEMBER BOX
            === */

.family-add-box {
    border: 1px dashed #dbe3ec;
    border-radius: 12px;
    padding: 18px 16px;
    background: #fbfdff;
}


/* Add Box Title */

.family-add-title {
    color: #476989;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.5px;
}


/* Inputs */

.family-input {
    height: 35px;
    border: 1px solid #dbe3ec;
    border-radius: 7px;
    background: #ffffff;
    color: #334155;
    font-size: 11px;
    padding: 7px 10px;
    box-shadow: none;
}

.family-input::placeholder {
    color: #94a3b8;
    opacity: 1;
}

.family-input:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, 0.08);
}


/* Add Button */

.family-add-btn {
    background: #16659E;
    color: #ffffff;
    border: none;
    border-radius: 7px;
    font-size: 10px;
    font-weight: 700;
    padding: 8px 13px;
}

.family-add-btn:hover {
    background: #0C3C62;
    color: #ffffff;
}


/* DOCUMENT  */

.documents-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 15px;
    width: 100%;
}


/*    DOCUMENT CARD*/

.document-card {
    min-width: 0;
    min-height: 70px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 12px;

    padding: 12px 14px;

    background: #ffffff;

    border: 1px solid #0f172a;
    border-radius: 12px;

    transition:
        border-color 0.2s ease,
        box-shadow 0.2s ease,
        background-color 0.2s ease;
}

.document-card:hover {
    border-color: #16659E;
    background: #fbfdff;
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05);
}


/*  DOCUMENT INFO */

.document-info {
    min-width: 0;

    display: flex;
    align-items: center;

    gap: 12px;

    flex: 1;
}


/* File Icon */

.document-icon {
    flex: 0 0 38px;
    width: 38px;
    height: 38px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    background: #eff6ff;
    color: #16659E;
    font-size: 18px;
}

/*  DOCUMENT DETAILS */
.document-details {
    min-width: 0;
    flex: 1;
}

.document-name {
    min-width: 0;
    color: #0f172a;

    font-size: 12px;
    font-weight: 700;
    line-height: 1.35;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.document-meta {
    margin-top: 3px;

    color: #7b94ad;

    font-size: 9px;
    font-weight: 500;

    line-height: 1.3;
}

.document-meta-divider {
    margin: 0 4px;
    color: #a8b6c4;
}


/*  DOCUMENT ACTIONS */

.document-actions {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    gap: 10px;
}


/* Verified Badge */
.document-status {
    display: inline-flex;
    align-items: center;
    padding: 4px 7px;
    border-radius: 4px;
    background: #f1f5f9;
    color: #476989;
    font-size: 9px;
    font-weight: 600;
    white-space: nowrap;
}


/* Delete */
.document-delete-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 24px;
    padding: 0;
    border: 0;
    background: transparent;
    color: #f43f5e;
    font-size: 15px;
    cursor: pointer;
    transition: color 0.2s ease;
}

.document-delete-btn:hover {
    color: #be123c;
}

/* UPLOAD BOX */

.document-upload-box {
    width: 100%;
    margin-top: 24px;
    padding: 18px 16px;
    border: 1px dashed #dbe3ec;
    border-radius: 12px;
    background: #fbfdff;
}

/* Upload title */
.document-upload-title {
    margin-bottom: 14px;
    color: #476989;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 0.6px;
}


/*  UPLOAD FORM */
.document-upload-form {
    display: grid;
    grid-template-columns:
        minmax(0, 1fr) 176px 136px;
    gap: 12px;
    align-items: center;
    width: 100%;
}


/* Inputs */
.document-input {
    width: 100%;
    height: 36px;
    border: 1px solid #dbe3ec;
    border-radius: 7px;
    background: #ffffff;
    color: #334155;
    font-size: 10px;
    box-shadow: none;
}

.document-input::placeholder {
    color: #94a3b8;
    opacity: 1;
}

.document-input:focus {
    border-color: #16659E;
    box-shadow:
        0 0 0 2px rgba(22, 101, 158, 0.08);
}

/*  UPLOAD BUTTON */
.document-upload-btn {
    width: 100%;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 12px;
    border: 0;
    border-radius: 7px;
    background: #16659E;
    color: #ffffff;
    font-size: 10px;
    font-weight: 700;
    white-space: nowrap;
    transition: background-color 0.2s ease;
}

.document-upload-btn:hover {
    background: #0C3C62;
    color: #ffffff;
}


/* TABLET */

@media (max-width: 767.98px) {

    .documents-grid {
        grid-template-columns: 1fr;
        gap: 12px;
    }

    .document-upload-form {
        grid-template-columns: 1fr;
    }

    .document-upload-action {
        width: 100%;
    }

    .document-upload-btn {
        width: 100%;
    }

}


/* VERY SMALL MOBILE*/

@media (max-width: 399.98px) {
    .document-card {
        padding: 11px;
    }

    .document-info {
        gap: 9px;
    }

    .document-icon {
        flex-basis: 34px;
        width: 34px;
        height: 34px;
        font-size: 16px;
    }

    .document-name {
        font-size: 11px;
    }

    .document-meta {
        font-size: 8px;
    }

    .document-actions {
        gap: 6px;
    }

    .document-status {
        padding: 3px 5px;
        font-size: 8px;
    }

    .document-delete-btn {
        font-size: 14px;
    }
}

/*                                                                                                                               =
   EDUCATION
                                                                                                                              = */

.education-card {
    position: relative;
}

.education-card>.d-flex {
    width: 100%;
}

.education-card .row {
    min-width: 0;
}


/* Delete button */

.education-delete-btn {
    display: none;

    flex: 0 0 auto;

    border: 0;
    background: transparent;

    color: #f43f5e;

    font-size: 17px;

    padding: 2px 0 2px 12px;

    cursor: pointer;

    transition: color 0.2s ease;
}

.education-delete-btn:hover {
    color: #be123c;
}


/* Show delete icons only in Edit mode */

.employee-editing .education-delete-btn {
    display: block;
}


/* ADD EDUCATION
                                                                                                                              = */

.education-add-box {
    display: none;

    border: 1px dashed #dbe3ec;
    border-radius: 12px;
    padding: 18px 16px;
    background: #fbfdff;
}

/* Show only when Edit mode is active */
.employee-editing .education-add-box {
    display: block;
}

.education-add-title {
    color: #476989;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.5px;
}

.education-input {
    height: 35px;
    border: 1px solid #dbe3ec;
    border-radius: 7px;
    background: #ffffff;
    color: #334155;
    font-size: 11px;
    padding: 7px 10px;
    box-shadow: none;
}

.education-input::placeholder {
    color: #94a3b8;
    opacity: 1;
}

.education-input:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, 0.08);
}

.education-add-btn {
    background: #16659E;
    color: #ffffff;
    border: none;
    border-radius: 7px;
    font-size: 10px;
    font-weight: 700;
    padding: 8px 13px;
}

.education-add-btn:hover {
    background: #0C3C62;
    color: #ffffff;
}

/* EMPLOYEE DRAWER RESPONSIVE ONLY FOR SMALL + MEDIUM DEVICES == */
/*   MEDIUM DEVICES 768px - 991px */

@media (min-width: 768px) and (max-width: 991.98px) {

    /* Drawer */
    .employee-drawer {
        width: 92vw !important;
        max-width: 92vw !important;
    }

    /* Main Layout */
    .employee-drawer-layout {
        display: flex;
        height: 100%;
    }

    /* Sidebar */
    .employee-sidebar {
        width: 190px !important;
        min-width: 190px !important;
        flex: 0 0 190px;
        overflow-y: auto;
    }

    .employee-tab {
        padding: 10px 12px !important;
        font-size: 11px !important;
        gap: 7px !important;
    }

    .employee-tab i {
        font-size: 16px !important;
        width: 18px;
        min-width: 18px;
    }

    /* Content */
    .employee-content {
        min-width: 0;
        overflow-x: hidden;
        overflow-y: auto;
    }

    .employee-panel {
        padding: 18px !important;
        width: 100%;
    }

    /* Header */
    .employee-drawer .offcanvas-header {
        padding: 12px 16px !important;
    }

    .employee-drawer .offcanvas-header h5 {
        font-size: 15px !important;
    }

    .employee-drawer .offcanvas-header .small {
        font-size: 10px !important;
    }

    /* Personal / KYC */
    .emp_personal {
        width: 50%;
    }

    /* Education */
    .emp_education {
        width: 50%;
    }

    /* Experience */
    .exp-edit-mode .emp_experience {
        width: 50%;
    }

    /* Training */
    .training-edit-mode .emp_traine,
    .training-edit-mode .emp_trainee {
        width: 50%;
    }

    /* References */
    .ref-edit-mode .emp_ref {
        width: 50%;
    }

    /* Interview */
    .interview-edit-mode .emp_interview {
        width: 50%;
    }

    /* Family */
    .family-edit-mode .emp_fam {
        width: 50%;
    }

    /* Remuneration Summary */
    .row.g-3.mb-4>.emp_remuneration {
        width: 50%;
    }

    /* Remuneration Components */
    .row.g-3>.emp_remuneration {
        width: 50%;
    }

    /* Last remuneration card full width */
    .row.g-3>..emp_remuneration {
        width: 100%;
    }

    /* Statutory / Banking */
    .col-md-6 {
        width: 50%;
    }

    /* Promotion History */
    .row.g-3 .col-md-4 {
        width: 50%;
    }

    /* Documents */
    .document-card {
        padding: 12px !important;
    }

    .document-name {
        font-size: 12px !important;
    }

}


/* SMALL DEVICES <= 767px  */

@media (max-width: 767.98px) {

    /* DRAWER  */

    .employee-drawer {
        width: 100vw !important;
        max-width: 100vw !important;
    }

    /*   HEADER  */

    .employee-drawer .offcanvas-header {
        padding: 10px 12px !important;
    }

    .employee-drawer .offcanvas-header h5 {
        font-size: 13px !important;
    }

    .employee-drawer .offcanvas-header .small {
        font-size: 9px !important;
    }

    /* Avatar */
    .employee-drawer .offcanvas-header .rounded-circle {
        width: 38px !important;
        height: 38px !important;
    }

    /* Edit button */
    #employeeEditBtn {
        padding: 6px 9px !important;
        font-size: 10px !important;
    }

    /*                                                                                                                      ==
       MAIN LAYOUT
                                                                                                                            == */

    .employee-drawer-layout {
        display: flex !important;
        flex-direction: column !important;
        height: 100%;
    }

    /*                                                                                                                      ==
       SIDEBAR -> HORIZONTAL TABS
                                                                                                                            == */

    .employee-sidebar {
        width: 100% !important;
        min-width: 100% !important;
        flex: 0 0 auto !important;

        height: auto !important;
        overflow-x: auto !important;
        overflow-y: hidden !important;

        border-right: 0 !important;
        border-bottom: 1px solid #dee2e6;

        background: #f8fafc !important;
    }

    /* Hide "Employee Dossier" heading */
    .employee-sidebar>.p-3 {
        display: none;
    }

    /* Tab container */
    #employeeTabMenu {
        display: flex !important;
        flex-direction: row !important;

        width: max-content;
        min-width: 100%;

        padding: 5px !important;
        gap: 3px;
    }

    /* Individual tabs */
    .employee-tab {
        flex: 0 0 auto !important;
        width: auto !important;

        padding: 8px 11px !important;

        border: 0 !important;
        border-radius: 5px;

        font-size: 10px !important;
        gap: 5px !important;

        white-space: nowrap;
    }

    .employee-tab i {
        font-size: 14px !important;
        width: auto;
        min-width: auto;
    }

    .employee-tab.active {
        background: #16659E !important;
        color: #fff !important;
        border: 0 !important;
    }

    /*                                                                                                                      ==
       CONTENT
                                                                                                                            == */

    .employee-content {
        width: 100%;
        min-width: 0;

        overflow-x: hidden !important;
        overflow-y: auto !important;
    }

    .employee-panel {
        width: 100%;
        padding: 14px !important;
    }

    /* Section title */
    .employee-section-title {
        font-size: 13px !important;
        margin-bottom: 12px !important;
    }

    /*  PERSONAL / KYC  */

    [data-panel="personal"] .col-md-6,
    [data-panel="personal"] .col-12 {
        width: 100%;
    }

    .employee-card {
        padding: 13px;
    }

    .employee-label {
        font-size: 9px;
    }

    .employee-value {
        font-size: 12px;
        overflow-wrap: anywhere;
    }

    /*        EDUCATION  */

    .emp_education {
        width: 100%;
    }

    .education-card {
        padding: 12px;
    }

    .education-add-box {
        padding: 12px !important;
    }

    .education-add-box .col-md-6 {
        width: 100% !important;
    }

    .education-add-btn {
        width: 100%;
    }

    /*      EXPERIENCE  */

    .experience-item {
        padding: 12px !important;
    }

    .exp-view-mode .d-flex {
        align-items: flex-start !important;
    }

    .exp-view-designation {
        font-size: 13px !important;
    }

    .exp-view-duration {
        font-size: 9px !important;
        white-space: nowrap;
    }

    .exp-view-company {
        font-size: 11px !important;
    }

    .exp-view-roles {
        font-size: 11px !important;
        line-height: 1.5 !important;
    }

    .exp-edit-mode {
        padding-right: 0 !important;
    }

    .exp-edit-mode .col-md-6,
    .exp-edit-mode .col-md-12 {
        width: 100% !important;
    }

    /*        TRAINING  */

    .training-item {
        padding: 12px !important;
    }

    .training-view-title {
        font-size: 12px !important;
    }

    .training-view-date {
        font-size: 10px !important;
    }

    .training-view-status {
        font-size: 9px !important;
        white-space: nowrap;
    }

    .training-edit-mode {
        padding-right: 0 !important;
    }

    .training-edit-mode .col-md-6,
    .training-edit-mode .col-md-3 {
        width: 100% !important;
    }

    /*     REFERENCE CHECKS  */

    .reference-item {
        padding: 12px !important;
    }

    .ref-view-name {
        font-size: 12px !important;
    }

    .ref-view-status {
        font-size: 9px !important;
    }

    .ref-view-mode .gap-3 {
        flex-direction: column !important;
        align-items: flex-start !important;
        gap: 6px !important;
    }

    .ref-view-mode .gap-3>span {
        display: none;
    }

    .ref-edit-mode {
        padding-right: 0 !important;
    }

    .ref-edit-mode .col-md-6 {
        width: 100% !important;
    }

    /*                                                                                                                      ==
       INTERVIEW
                                                                                                                            == */

    .interview-item {
        padding: 12px !important;
    }

    .interview-view-mode .col-md-3 {
        width: 50% !important;
    }

    .interview-view-recruiter,
    .interview-view-date,
    .interview-view-rating {
        font-size: 11px !important;
    }

    .interview-view-comments {
        font-size: 11px !important;
    }

    .interview-edit-mode {
        padding-right: 0 !important;
    }

    .interview-edit-mode .col-md-3,
    .interview-edit-mode .col-12 {
        width: 100% !important;
    }

    /*   FAMILY  */

    .family-member-card {
        padding: 12px !important;
    }

    .family-edit-mode {
        padding-right: 0 !important;
    }

    .family-edit-mode .col-md-6 {
        width: 100%;
    }

    .family-add-box {
        padding: 12px;
    }

    .family-add-box .col-md-6 {
        width: 100% !important;
    }

    .family-add-btn {
        width: 100%;
    }

    .family-member-details {
        display: flex;
        flex-direction: column;
        gap: 5px;
        font-size: 11px;
    }

    .family-divider {
        display: none;
    }

    /*     REMUNERATION  */

    .emp_remuneration {
        padding: 12px !important;
    }

    /* Summary cards - 2 per row */
    .row.g-3.mb-4>.emp_remuneration,
    .row.g-3.mb-4>.emp_remuneration {
        width: 50% !important;
    }

    .row.g-3.mb-4>.emp_remuneration>div {
        padding: 10px !important;
    }

    /* Salary components - one per row */
    .row.g-3>.emp_remuneration {
        width: 100% !important;
    }

    /* Statutory / Banking */
    .emp_remuneration {
        width: 100% !important;
    }

    /* Promotion history */
    .row.g-3 .emp_remuneration {
        width: 100% !important;
    }

    /* Salary inputs */
    input[type="number"] {
        width: 75px !important;
    }

    /*   DOCUMENTS   */
    .document-card {
        padding: 10px !important;
        gap: 8px;
    }

    .document-info {
        min-width: 0;
        flex: 1;
    }

    .document-icon {
        font-size: 25px !important;
    }

    .document-name {
        font-size: 11px;
        overflow-wrap: anywhere;
    }

    .document-meta {
        font-size: 9px;
    }

    .document-status {
        font-size: 8px;
    }

    /* Upload section */
    .document-upload-box {
        padding: 12px;
    }

    .document-upload-box>.d-flex {
        flex-direction: column
    }

    .document-upload-box>.d-flex>div {
        width: 100%;
        min-width: 100%;
    }

    #triggerFileSelectBtn,
    #documentUploadBtn {
        width: 100%;
    }

    /* PREVENT HORIZONTAL OVERFLOW  */

    .employee-drawer * {
        max-width: 100%;
    }

    .employee-drawer .row {
        margin-left: 0;
        margin-right: 0;
    }

    .employee-drawer .font-monospace {
        overflow-wrap: anywhere;
    }
}

/* Emp - drawer end */
</style>

<script>
// search filter
document.addEventListener("DOMContentLoaded", function() {
    const searchInput = document.querySelector("#hr-search-field");
    const tableRows = document.querySelectorAll(".esi-pf-ledger-table tbody tr");

    if (searchInput) {
        searchInput.addEventListener("keyup", function() {
            const query = searchInput.value.toLowerCase().trim();

            tableRows.forEach(row => {
                const textContent = row.textContent.toLowerCase();

                // Show row if it contains the search query, hide otherwise
                if (textContent.includes(query)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });
    }
});



document.addEventListener('DOMContentLoaded', function() {
    const drawerElement = document.getElementById('employeeDrawer');
    if (!drawerElement) {
        return;
    }
    const drawer = new bootstrap.Offcanvas(drawerElement);

    /* Employee Row Click */
    document.querySelectorAll('.employee-row .employee-click').forEach(cell => {
        cell.addEventListener('click', function(event) {
            // Prevent accidental drawer opening from dropdown/buttons
            if (
                event.target.closest('.dropdown') ||
                event.target.closest('button') ||
                event.target.closest('a')
            ) {
                return;
            }
            const row = this.closest('.employee-row');
            if (!row) {
                return;
            }

            /* Employee ID  */
            const employeeId = row.dataset.employeeId;
            console.log('Opening employee:', employeeId);
            /* Update drawer header from clicked row*/
            const name = row.querySelector('td:first-child .fw-semibold')?.textContent
                .trim();
            const designation = row.querySelector('td:nth-child(2) span')?.textContent
                .trim();
            const department = row.querySelector('td:nth-child(2) small')?.textContent
                .trim();
            document.getElementById('employeeDrawerName').textContent =
                name || '';
            document.getElementById('employeeDrawerDesignation').textContent =
                designation || '';
            document.getElementById('employeeDrawerDepartment').textContent =
                department || '';

            /* Always show Personal tab first */
            showEmployeeTab('personal');
            /* Open Drawer */
            drawer.show();
        });
    });


    /* Sidebar Tab Click  */
    document.querySelectorAll('.employee-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.dataset.tab;
            showEmployeeTab(tabName);
        });
    });

    /*  Show Employee Tab  */
    function showEmployeeTab(tabName) {
        // Remove active state
        document.querySelectorAll('.employee-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        // Add active state
        const activeTab = document.querySelector(
            `.employee-tab[data-tab="${tabName}"]`
        );
        if (activeTab) {
            activeTab.classList.add('active');
        }
        // Hide all panels
        document.querySelectorAll('.employee-panel').forEach(panel => {
            panel.classList.add('d-none');
        });
        // Show selected panel
        const selectedPanel = document.querySelector(
            `.employee-panel[data-panel="${tabName}"]`
        );
        if (selectedPanel) {
            selectedPanel.classList.remove('d-none');
        }
    }
});

// Drawer editable
document.addEventListener('DOMContentLoaded', function() {
    const drawer = document.getElementById('employeeDrawer');
    const editBtn = document.getElementById('employeeEditBtn');
    const editText = document.getElementById('employeeEditText');
    const editIcon = document.getElementById('employeeEditIcon');
    let isEditing = false;
    /* Start / Stop Editing  */
    editBtn.addEventListener('click', function() {
        if (!isEditing) {
            enableEmployeeEditing();
        } else {
            saveEmployeeEditing();
        }
    });
    /* ENABLE EDIT MODE  */
    function enableEmployeeEditing() {
        isEditing = true;
        drawer.classList.add('employee-editing');
        editText.textContent = 'Save';
        editIcon.classList.remove('mdi-pencil-outline');
        editIcon.classList.add('mdi-content-save-outline');
        editBtn.classList.add('is-saving');

        /*  Convert employee values to inputs */
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            // Prevent converting the same element twice
            if (element.dataset.editing === 'true') {
                return;
            }
            const value = element.textContent.trim();
            element.dataset.originalValue = value;
            element.dataset.editing = 'true';

            /*  Interview comments / long text */
            if (
                element.tagName.toLowerCase() === 'p' ||
                value.length > 100
            ) {
                const textarea = document.createElement('textarea');
                textarea.className = 'employee-edit-input';
                textarea.value = value;
                element.innerHTML = '';
                element.appendChild(textarea);
            }
            /*  Normal fields   */
            else {
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'employee-edit-input';
                input.value = value;
                element.innerHTML = '';
                element.appendChild(input);
            }
        });

        /* Convert header employee information to inputs    */
        convertHeaderFields();
    }
    /* SAVE / EXIT EDIT MODE  */
    function saveEmployeeEditing() {
        /* Employee fields */
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            const input = element.querySelector(
                '.employee-edit-input'
            );
            if (!input) {
                return;
            }
            const value = input.value.trim();
            element.textContent = value;
            element.dataset.editing = 'false';
        });

        /* Header fields    */
        const header = drawer.querySelector('.offcanvas-header');
        const nameElement = header.querySelector('h5');
        if (nameElement) {
            const input = nameElement.querySelector(
                '.employee-edit-input'
            );
            if (input) {
                nameElement.textContent = input.value.trim();
            }
            nameElement.dataset.editing = 'false';
        }

        header.querySelectorAll(
            '.d-flex.flex-column > span'
        ).forEach(function(span) {
            const input = span.querySelector(
                '.employee-edit-input'
            );
            if (input) {
                span.textContent = input.value.trim();
            }
            span.dataset.editing = 'false';
        });


        /* Change button back to Edit */
        isEditing = false;
        drawer.classList.remove('employee-editing');
        editText.textContent = 'Edit';
        editIcon.classList.remove('mdi-content-save-outline');
        editIcon.classList.add('mdi-pencil-outline');
        editBtn.classList.remove('is-saving');
    }

    /* Reset edit mode when drawer closes */

    drawer.addEventListener('hidden.bs.offcanvas', function() {
        if (isEditing) {
            cancelEditing();
        }
    });

    /* Cancel Editing  */
    function cancelEditing() {
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            const originalValue =
                element.dataset.originalValue;

            if (originalValue !== undefined) {
                element.textContent = originalValue;
            }
            element.dataset.editing = 'false';
        });
        const header = drawer.querySelector('.offcanvas-header');
        const nameElement = header.querySelector('h5');
        if (nameElement) {
            const originalValue =
                nameElement.dataset.originalValue;
            if (originalValue !== undefined) {
                nameElement.textContent = originalValue;
            }
            nameElement.dataset.editing = 'false';
        }

        header.querySelectorAll(
            '.d-flex.flex-column > span'
        ).forEach(function(span) {
            const originalValue =
                span.dataset.originalValue;
            if (originalValue !== undefined) {
                span.textContent = originalValue;
            }
            span.dataset.editing = 'false';
        });
        isEditing = false;
        drawer.classList.remove('employee-editing');
        editText.textContent = 'Edit';
        editIcon.classList.remove('mdi-content-save-outline');
        editIcon.classList.add('mdi-pencil-outline');
        editBtn.classList.remove('is-saving');
    }
});

// for work experience
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const container = document.getElementById('experienceContainer');

    let isEditing = false;

    // Template matching exact UI structure
    function createNewExperienceCard() {
        return `
            <div class="card mb-3 p-3 position-relative experience-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-exp-btn py-0 px-1" title="Delete Experience" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="exp-view-mode d-none">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-bold exp-view-designation" style="font-size: 14px; color: #1e293b;"></span>
                        <span class="badge rounded-1 exp-view-duration" style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;"></span>
                    </div>
                    <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;"></div>
                    <div class="exp-view-roles mt-2" style="font-size: 13px; color: #64748b; line-height: 1.4;"></div>
                </div>

                <div class="exp-edit-mode mt-2 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Designation</label>
                            <input type="text" class="form-control form-control-sm exp-input-designation" style="font-size: 11px;" placeholder="e.g. Lead Engineer">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Company Name</label>
                            <input type="text" class="form-control form-control-sm exp-input-company" style="font-size: 11px;" placeholder="e.g. SRK Infrastructure">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Duration</label>
                            <input type="text" class="form-control form-control-sm exp-input-duration" style="font-size: 11px;" placeholder="e.g. 2022 - Present">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles & Responsibilities</label>
                            <textarea class="form-control form-control-sm exp-input-roles" rows="2" style="font-size: 11px;" placeholder="Describe key roles..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Toggle Edit / Save State
    editBtn.addEventListener('click', function() {
        isEditing = !isEditing;

        if (isEditing) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show Edit Mode for existing items
            document.querySelectorAll('.experience-item').forEach(item => {
                item.querySelector('.exp-view-mode').classList.add('d-none');
                item.querySelector('.exp-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-exp-btn').classList.remove('d-none');
            });

            // Automatically append new entry input block
            container.insertAdjacentHTML('beforeend', createNewExperienceCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            document.querySelectorAll('.experience-item').forEach(item => {
                const designation = item.querySelector('.exp-input-designation').value.trim();
                const company = item.querySelector('.exp-input-company').value.trim();
                const duration = item.querySelector('.exp-input-duration').value.trim();
                const roles = item.querySelector('.exp-input-roles').value.trim();

                // If user left a newly generated card completely blank, remove it
                if (!designation && !company && !duration && !roles) {
                    item.remove();
                    return;
                }

                // Sync inputs back into View Mode format
                item.querySelector('.exp-view-designation').textContent = designation || 'N/A';
                item.querySelector('.exp-view-company').textContent = company || 'N/A';
                item.querySelector('.exp-view-duration').textContent = duration || 'N/A';
                item.querySelector('.exp-view-roles').textContent = roles;

                item.querySelector('.exp-edit-mode').classList.add('d-none');
                item.querySelector('.exp-view-mode').classList.remove('d-none');
                item.querySelector('.delete-exp-btn').classList.add('d-none');
            });
        }
    });

    // Delete item functionality
    container.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-exp-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.experience-item');
            card.remove();
        }
    });
});

// for training induction
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const trainingContainer = document.getElementById('trainingContainer');

    let isEditing = false;

    if (editBtn && trainingContainer) {
        editBtn.addEventListener('click', function() {
            isEditing = !isEditing;
            const trainingItems = trainingContainer.querySelectorAll('.training-item');

            if (isEditing) {
                // UI: Switch button to "Save" (Success state)
                editText.textContent = 'Save';
                editIcon.className = 'mdi mdi-check-bold';
                editBtn.style.background = '#198754';
                editBtn.style.borderColor = '#198754';

                // Reveal edit fields and trash icons
                trainingItems.forEach(item => {
                    item.querySelector('.training-view-mode').classList.add('d-none');
                    item.querySelector('.training-edit-mode').classList.remove('d-none');
                    item.querySelector('.delete-training-btn').classList.remove('d-none');
                });
            } else {
                // UI: Switch button back to "Edit" (Default state)
                editText.textContent = 'Edit';
                editIcon.className = 'mdi mdi-pencil-outline';
                editBtn.style.background = 'rgba(255,255,255,0.12)';
                editBtn.style.borderColor = 'rgba(255,255,255,0.25)';

                // Sync data and return to view mode
                trainingItems.forEach(item => {
                    // 1. Read updated values from inputs
                    const titleVal = item.querySelector('.training-input-title').value;
                    const dateVal = item.querySelector('.training-input-date').value;
                    const statusVal = item.querySelector('.training-input-status').value;

                    // 2. Inject updated values into the view text
                    item.querySelector('.training-view-title').textContent = titleVal;
                    item.querySelector('.training-view-date').textContent = dateVal;

                    const statusBadge = item.querySelector('.training-view-status');
                    statusBadge.textContent = statusVal;

                    // 3. Dynamically update badge styling based on dropdown selection
                    statusBadge.className = 'badge training-view-status ';
                    if (statusVal === 'Completed') {
                        statusBadge.className += 'bg-success-subtle text-success';
                    } else if (statusVal === 'Pending') {
                        statusBadge.className += 'bg-warning-subtle text-warning';
                    } else {
                        statusBadge.className +=
                            'bg-info-subtle text-info'; // For "In Progress"
                    }

                    // 4. Hide edit fields and trash icons
                    item.querySelector('.training-view-mode').classList.remove('d-none');
                    item.querySelector('.training-edit-mode').classList.add('d-none');
                    item.querySelector('.delete-training-btn').classList.add('d-none');
                });
            }
        });

        // Event delegation for dynamic deletion of training cards
        trainingContainer.addEventListener('click', function(e) {
            const deleteBtn = e.target.closest('.delete-training-btn');
            if (deleteBtn) {
                // Optional: add a confirmation dialogue here if needed
                deleteBtn.closest('.training-item').remove();
            }
        });
    }
});

// for Reference
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const referenceContainer = document.getElementById('referenceContainer');

    let isEditingReference = false;

    // Status badge formatting function
    function getRefStatusBadgeClass(status) {
        switch (status) {
            case 'VERIFIED':
                return 'bg-success-subtle text-success';
            case 'PENDING':
                return 'bg-warning-subtle text-warning';
            case 'UNVERIFIED':
                return 'bg-danger-subtle text-danger';
            default:
                return 'bg-secondary-subtle text-secondary';
        }
    }

    // Dynamic template for appending blank reference fields
    function createNewReferenceCard() {
        return `
            <div class="card mb-3 p-3 position-relative reference-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-ref-btn py-0 px-1" title="Delete Reference" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="ref-view-mode d-none">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex align-items-center gap-2">
                            <span class="fw-bold ref-view-name" style="font-size: 14px; color: #1e293b;"></span>
                            <span class="badge ref-view-status" style="font-weight: 600; font-size: 10px; padding: 3px 6px;"></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-3 text-secondary" style="font-size: 13px; color: #64748b;">
                        <div>
                            <small class="text-muted">Designation:</small>
                            <span class="ref-view-designation fw-medium" style="color: #334155;"></span>
                        </div>
                        <span style="border-right: 1px solid #cbd5e1; height: 12px;"></span>
                        <div>
                            <small class="text-muted">Phone:</small>
                            <span class="ref-view-phone fw-medium" style="color: #334155;"></span>
                        </div>
                    </div>
                </div>

                <div class="ref-edit-mode mt-1 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Full Name</label>
                            <input type="text" class="form-control form-control-sm ref-input-name" style="font-size: 11px;" placeholder="e.g. Suresh Raina">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Verification Status</label>
                            <select class="form-select form-select-sm ref-input-status" style="font-size: 11px;">
                                <option value="PENDING" selected>PENDING</option>
                                <option value="VERIFIED">VERIFIED</option>
                                <option value="UNVERIFIED">UNVERIFIED</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Designation</label>
                            <input type="text" class="form-control form-control-sm ref-input-designation" style="font-size: 11px;" placeholder="e.g. Site Supervisor">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Phone Number</label>
                            <input type="text" class="form-control form-control-sm ref-input-phone" style="font-size: 11px;" placeholder="e.g. +91 98765 00000">
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Single Edit Button Listener (Handles Reference Panel Active State)
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'references') return;

        isEditingReference = !isEditingReference;

        if (isEditingReference) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Switch existing cards to edit mode
            referenceContainer.querySelectorAll('.reference-item').forEach(item => {
                item.querySelector('.ref-view-mode').classList.add('d-none');
                item.querySelector('.ref-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-ref-btn').classList.remove('d-none');
            });

            // Automatically insert blank card inputs for fresh reference
            referenceContainer.insertAdjacentHTML('beforeend', createNewReferenceCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            referenceContainer.querySelectorAll('.reference-item').forEach(item => {
                const name = item.querySelector('.ref-input-name').value.trim();
                const status = item.querySelector('.ref-input-status').value;
                const designation = item.querySelector('.ref-input-designation').value.trim();
                const phone = item.querySelector('.ref-input-phone').value.trim();

                // If new card is left empty, automatically clean it up
                if (!name && !designation && !phone) {
                    item.remove();
                    return;
                }

                // Update View UI Elements
                item.querySelector('.ref-view-name').textContent = name || 'N/A';
                item.querySelector('.ref-view-designation').textContent = designation || 'N/A';
                item.querySelector('.ref-view-phone').textContent = phone || 'N/A';

                const statusBadge = item.querySelector('.ref-view-status');
                statusBadge.textContent = status;
                statusBadge.className =
                    `badge ${getRefStatusBadgeClass(status)} ref-view-status`;

                item.querySelector('.ref-edit-mode').classList.add('d-none');
                item.querySelector('.ref-view-mode').classList.remove('d-none');
                item.querySelector('.delete-ref-btn').classList.add('d-none');
            });
        }
    });

    // Delete item listener
    referenceContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-ref-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.reference-item');
            card.remove();
        }
    });
});

// for interview
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const interviewContainer = document.getElementById('interviewContainer');

    let isEditingInterview = false;

    // Helper badge styling function for HR Verdict
    function getVerdictBadgeClass(verdict) {
        switch (verdict) {
            case 'Selected':
                return 'bg-success-subtle text-success';
            case 'On Hold':
                return 'bg-warning-subtle text-warning';
            case 'Rejected':
                return 'bg-danger-subtle text-danger';
            default:
                return 'bg-secondary-subtle text-secondary';
        }
    }

    // Dynamic template for appending blank interview card inputs
    function createNewInterviewCard() {
        return `
            <div class="card mb-3 p-3 position-relative interview-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-interview-btn py-0 px-1" title="Delete Interview Log" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="interview-view-mode d-none">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Screening Recruiter</small>
                            <span class="fw-semibold interview-view-recruiter" style="font-size: 13px; color: #1e293b;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Evaluation Date</small>
                            <span class="fw-medium interview-view-date" style="font-size: 13px; color: #334155;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Rating</small>
                            <span class="fw-medium interview-view-rating" style="font-size: 13px; color: #334155;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">HR Decision Verdict</small>
                            <span class="badge interview-view-verdict" style="font-weight: 600; font-size: 11px; padding: 4px 8px;"></span>
                        </div>
                        <div class="col-12 mt-2">
                            <small class="text-muted d-block" style="font-size: 11px;">Comments</small>
                            <p class="mb-0 interview-view-comments" style="font-size: 13px; color: #64748b; line-height: 1.4;"></p>
                        </div>
                    </div>
                </div>

                <div class="interview-edit-mode mt-1 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Screening Recruiter</label>
                            <input type="text" class="form-control form-control-sm interview-input-recruiter" style="font-size: 11px;" placeholder="e.g. Ramesh Chandra">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Evaluation Date</label>
                            <input type="text" class="form-control form-control-sm interview-input-date" style="font-size: 11px;" placeholder="e.g. 15 Aug 2024">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Rating</label>
                            <input type="text" class="form-control form-control-sm interview-input-rating" style="font-size: 11px;" placeholder="e.g. 4.0 / 5">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">HR Decision Verdict</label>
                            <select class="form-select form-select-sm interview-input-verdict" style="font-size: 11px;">
                                <option value="Selected" selected>Selected</option>
                                <option value="On Hold">On Hold</option>
                                <option value="Rejected">Rejected</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Assessment Comments</label>
                            <textarea class="form-control form-control-sm interview-input-comments" rows="2" style="font-size: 11px;" placeholder="Enter assessment comments..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Toggle Edit / Save State for Interview Panel
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'interview') return;

        isEditingInterview = !isEditingInterview;

        if (isEditingInterview) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show edit mode for all existing entries
            interviewContainer.querySelectorAll('.interview-item').forEach(item => {
                item.querySelector('.interview-view-mode').classList.add('d-none');
                item.querySelector('.interview-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-interview-btn').classList.remove('d-none');
            });

            // Automatically append new entry inputs
            interviewContainer.insertAdjacentHTML('beforeend', createNewInterviewCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            interviewContainer.querySelectorAll('.interview-item').forEach(item => {
                const recruiter = item.querySelector('.interview-input-recruiter').value.trim();
                const date = item.querySelector('.interview-input-date').value.trim();
                const rating = item.querySelector('.interview-input-rating').value.trim();
                const verdict = item.querySelector('.interview-input-verdict').value;
                const comments = item.querySelector('.interview-input-comments').value.trim();

                // If user left a newly appended card completely empty, remove it
                if (!recruiter && !date && !rating && !comments) {
                    item.remove();
                    return;
                }

                // Sync view content with inputs
                item.querySelector('.interview-view-recruiter').textContent = recruiter ||
                    'N/A';
                item.querySelector('.interview-view-date').textContent = date || 'N/A';
                item.querySelector('.interview-view-rating').textContent = rating || 'N/A';
                item.querySelector('.interview-view-comments').textContent = comments ||
                    'No comments provided.';

                const verdictBadge = item.querySelector('.interview-view-verdict');
                verdictBadge.textContent = verdict;
                verdictBadge.className =
                    `badge ${getVerdictBadgeClass(verdict)} interview-view-verdict`;

                item.querySelector('.interview-edit-mode').classList.add('d-none');
                item.querySelector('.interview-view-mode').classList.remove('d-none');
                item.querySelector('.delete-interview-btn').classList.add('d-none');
            });
        }
    });

    // Delete item event listener
    interviewContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-interview-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.interview-item');
            card.remove();
        }
    });
});
// for family
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const familyContainer = document.getElementById('familyContainer');
    const familyAddBox = document.getElementById('familyAddBox');
    const appendFamilyBtn = document.getElementById('appendFamilyBtn');

    let isEditingFamily = false;

    // Build standard structure for dynamically added family members
    function createFamilyCardElement(name, relation, age, occupation) {
        const card = document.createElement('div');
        card.className = 'family-member-card mb-3 family-item position-relative';
        card.innerHTML = `
            <button type="button" class="family-delete-btn position-absolute top-0 end-0 m-3 delete-family-btn" title="Remove Family Member">
                <i class="mdi mdi-trash-can-outline"></i>
            </button>

            <div class="family-view-mode d-none">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="family-member-name family-view-name">${name}</span>
                            <span class="family-relation-badge family-view-relation">${relation.toUpperCase()}</span>
                        </div>
                        <div class="family-member-details">
                            <span>
                                <small>Age:</small>
                                <span class="family-view-age">${age}</span> Years
                            </span>
                            <span class="family-divider"></span>
                            <span>
                                <small>Occupation:</small>
                                <span class="family-view-occupation">${occupation}</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="family-edit-mode pe-4">
                <div class="row g-2">
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full Name</label>
                        <input type="text" class="form-control form-control-sm family-input-name" style="font-size: 11px;" value="${name}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Relation</label>
                        <input type="text" class="form-control form-control-sm family-input-relation" style="font-size: 11px;" value="${relation}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                        <input type="number" class="form-control form-control-sm family-input-age" style="font-size: 11px;" value="${age}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Occupation</label>
                        <input type="text" class="form-control form-control-sm family-input-occupation" style="font-size: 11px;" value="${occupation}">
                    </div>
                </div>
            </div>
        `;
        return card;
    }

    // Single Edit Button Listener (Handles Family Panel Active State)
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'family') return;

        isEditingFamily = !isEditingFamily;

        if (isEditingFamily) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show edit modes & action panel
            familyContainer.querySelectorAll('.family-item').forEach(item => {
                item.querySelector('.family-view-mode').classList.add('d-none');
                item.querySelector('.family-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-family-btn').classList.remove('d-none');
            });

            familyAddBox.classList.remove('d-none');

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            // Sync input values back to view mode elements
            familyContainer.querySelectorAll('.family-item').forEach(item => {
                const name = item.querySelector('.family-input-name').value.trim();
                const relation = item.querySelector('.family-input-relation').value.trim();
                const age = item.querySelector('.family-input-age').value.trim();
                const occupation = item.querySelector('.family-input-occupation').value.trim();

                // Clear blank entries
                if (!name && !relation && !age && !occupation) {
                    item.remove();
                    return;
                }

                item.querySelector('.family-view-name').textContent = name || 'N/A';
                item.querySelector('.family-view-relation').textContent = (relation || 'N/A')
                    .toUpperCase();
                item.querySelector('.family-view-age').textContent = age || 'N/A';
                item.querySelector('.family-view-occupation').textContent = occupation || 'N/A';

                item.querySelector('.family-edit-mode').classList.add('d-none');
                item.querySelector('.family-view-mode').classList.remove('d-none');
                item.querySelector('.delete-family-btn').classList.add('d-none');
            });

            familyAddBox.classList.add('d-none');
        }
    });

    // Handle "Append Family Member" action button
    appendFamilyBtn.addEventListener('click', function() {
        const nameInput = document.getElementById('newFamilyName');
        const relationInput = document.getElementById('newFamilyRelation');
        const ageInput = document.getElementById('newFamilyAge');
        const occupationInput = document.getElementById('newFamilyOccupation');

        const name = nameInput.value.trim();
        const relation = relationInput.value.trim();
        const age = ageInput.value.trim();
        const occupation = occupationInput.value.trim();

        if (!name && !relation) {
            alert('Please enter at least a name and relation.');
            return;
        }

        const newCard = createFamilyCardElement(name, relation, age, occupation);
        familyContainer.appendChild(newCard);

        // Reset inputs
        nameInput.value = '';
        relationInput.value = '';
        ageInput.value = '';
        occupationInput.value = '';
    });

    // Delete item listener
    familyContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-family-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.family-item');
            card.remove();
        }
    });
});
// Remuneration
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    if (!editBtn) return;
    editBtn.addEventListener('click', function() {
        const isEditing = editBtn.dataset.editing === 'true';
        const fields = [
            'componentATotal',
            'basic',
            'hra',
            'special',
            'componentBTotal',
            'epfEmployee',
            'esiEmployee',
            'pt',
            'tds',
            'componentCTotal',
            'epfEmployer',
            'esiEmployer',
            'gratuity'
        ];
        fields.forEach(function(field) {
            const view = document.getElementById(field + 'View');
            const edit = document.getElementById(field + 'Edit');
            if (!view || !edit) return;
            if (!isEditing) {
                // View → Edit
                view.classList.add('d-none');
                edit.classList.remove('d-none');
            } else {
                // Edit → View
                const input = edit.querySelector('input');
                if (input) {
                    const value = Number(input.value || 0);
                    view.querySelector('span').textContent =
                        '₹ ' + value.toLocaleString('en-IN');
                }
                edit.classList.add('d-none');
                view.classList.remove('d-none');
            }
        });
        // Update button state
        editBtn.dataset.editing = (!isEditing).toString();
        const icon = document.getElementById('employeeEditIcon');
        const text = document.getElementById('employeeEditText');
        if (!isEditing) {
            // Edit mode
            icon.className = 'mdi mdi-content-save-outline';
            text.textContent = 'Save';
        } else {
            // View mode
            icon.className = 'mdi mdi-pencil-outline';
            text.textContent = 'Edit';
        }
    });
});

// document upload for employee files
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');

    const documentsGrid = document.getElementById('documentsGrid');
    const documentUploadBox = document.getElementById('documentUploadBox');
    const fileInput = document.getElementById('documentFileInput');
    const triggerFileBtn = document.getElementById('triggerFileSelectBtn');
    const uploadBtn = document.getElementById('documentUploadBtn');
    const documentTypeSelect = document.getElementById('documentType');

    let isEditing = false;

    // Toggle Edit / Save Mode
    if (editBtn) {
        editBtn.addEventListener('click', function() {
            isEditing = !isEditing;

            if (isEditing) {
                // Update button state to Save
                editText.textContent = 'Save';
                editIcon.className = 'mdi mdi-check-bold';
                editBtn.style.background = '#198754';
                editBtn.style.borderColor = '#198754';

                // Reveal upload section and document deletion buttons
                if (documentUploadBox) documentUploadBox.classList.remove('d-none');
                if (documentsGrid) {
                    documentsGrid.querySelectorAll('.document-delete-btn').forEach(btn => btn.classList
                        .remove('d-none'));
                }
            } else {
                // Reset button state to Edit
                editText.textContent = 'Edit';
                editIcon.className = 'mdi mdi-pencil-outline';
                editBtn.style.background = 'rgba(255,255,255,0.12)';
                editBtn.style.borderColor = 'rgba(255,255,255,0.25)';

                // Hide upload section and document deletion buttons
                if (documentUploadBox) documentUploadBox.classList.add('d-none');
                if (documentsGrid) {
                    documentsGrid.querySelectorAll('.document-delete-btn').forEach(btn => btn.classList
                        .add('d-none'));
                }
            }
        });
    }

    // File selection trigger
    if (triggerFileBtn && fileInput) {
        triggerFileBtn.addEventListener('click', function() {
            fileInput.click();
        });

        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                triggerFileBtn.textContent = this.files[0].name;
                triggerFileBtn.classList.remove('btn-outline-secondary');
                triggerFileBtn.classList.add('btn-outline-primary');
            } else {
                triggerFileBtn.innerHTML = '<i class="mdi mdi-paperclip me-1"></i> Select File...';
                triggerFileBtn.classList.remove('btn-outline-primary');
                triggerFileBtn.classList.add('btn-outline-secondary');
            }
        });
    }

    // Helper for formatting file size
    function formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    // Append new uploaded file card
    if (uploadBtn) {
        uploadBtn.addEventListener('click', function() {
            if (!fileInput.files || !fileInput.files[0]) {
                alert('Please select a file to upload.');
                return;
            }

            const file = fileInput.files[0];
            const docName = file.name;
            const docSize = formatBytes(file.size);
            const docCategory = documentTypeSelect.options[documentTypeSelect.selectedIndex].text;
            const deleteBtnVisibility = isEditing ? '' : 'd-none';

            const card = document.createElement('div');
            card.className =
                'document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between';
            card.innerHTML = `
                <div class="document-info d-flex align-items-center gap-3">
                    <div class="document-icon text-primary fs-3">
                        <i class="mdi mdi-file-document-outline"></i>
                    </div>
                    <div class="document-details">
                        <div class="document-name fw-semibold" style="font-size: 13px;">${docName}</div>
                        <div class="document-meta text-muted" style="font-size: 11px;">
                            ${docCategory}
                            <span class="document-meta-divider mx-1">•</span>
                            ${docSize}
                        </div>
                    </div>
                </div>
                <div class="document-actions d-flex align-items-center gap-2">
                    <span class="document-status badge bg-warning-subtle text-warning px-2 py-1" style="font-size: 10px;">
                        Pending
                    </span>
                    <button type="button" class="btn btn-sm btn-link text-danger p-0 document-delete-btn ${deleteBtnVisibility}" title="Remove Document">
                        <i class="mdi mdi-trash-can-outline fs-5"></i>
                    </button>
                </div>
            `;

            documentsGrid.appendChild(card);

            // Reset inputs
            fileInput.value = '';
            triggerFileBtn.innerHTML = '<i class="mdi mdi-paperclip me-1"></i> Select File...';
            triggerFileBtn.classList.remove('btn-outline-primary');
            triggerFileBtn.classList.add('btn-outline-secondary');
        });
    }

    // Dynamic document deletion
    if (documentsGrid) {
        documentsGrid.addEventListener('click', function(e) {
            const deleteBtn = e.target.closest('.document-delete-btn');
            if (deleteBtn) {
                deleteBtn.closest('.document-card').remove();
            }
        });
    }
});
</script>
@endsection