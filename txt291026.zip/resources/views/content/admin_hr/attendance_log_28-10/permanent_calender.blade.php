@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@php
$employmentType = 'Permanent';
$viewMode = 'List';

// ============================
// DEPARTMENTS
// ============================
$departments = [
'ALL',
'Management',
'Engineering',
'Quality Control',
'Accounts',
'Purchase',
'Skilled Labor',
'General Labor',
];

$selectedDept = 'ALL';

// ============================
// CALENDAR
// ============================
$calendarMonth = (int) request()->query('month', now()->month);
$calendarMonth = max(1, min(12, $calendarMonth));
$calendarYear = (int) request()->query('year', now()->year);
$calendarYear = max(2000, min(2100, $calendarYear));

$calendarDate = \Carbon\Carbon::create(
$calendarYear,
$calendarMonth,
1
);

$daysInMonth = $calendarDate->daysInMonth;

// Carbon:
// Sunday = 0
// Monday = 1
// ...
// Saturday = 6
$startDay = $calendarDate->dayOfWeek;

$calendarMonthName = $calendarDate->format('F');

// ============================
// SAMPLE EMPLOYEES
// ============================
$employees = [
[
'id' => 1,
'name' => 'Arun Kumar',
'role' => 'Project Manager',
'employeeCode' => 'SRK-EMP-001',
'department' => 'Management',
'employmentType' => 'Permanent',
],
[
'id' => 2,
'name' => 'Suresh Raj',
'role' => 'Civil Engineer',
'employeeCode' => 'SRK-EMP-002',
'department' => 'Engineering',
'employmentType' => 'Permanent',
],
[
'id' => 3,
'name' => 'Priya Devi',
'role' => 'Supervisor',
'employeeCode' => 'SRK-EMP-003',
'department' => 'General Labor',
'employmentType' => 'Permanent',
],
[
'id' => 4,
'name' => 'Karthik Kumar',
'role' => 'Quality Inspector',
'employeeCode' => 'SRK-EMP-004',
'department' => 'Quality Control',
'employmentType' => 'Permanent',
],
[
'id' => 5,
'name' => 'Meena Devi',
'role' => 'Accountant',
'employeeCode' => 'SRK-EMP-005',
'department' => 'Accounts',
'employmentType' => 'Permanent',
],
];
@endphp


<div class="container-fluid px-0">

    {{--     SUMMARY CARDS  --}}
    <div class="row g-3 mb-4">

        {{-- Permanent Pool --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">

                <div class="card-body p-3">

                    <span class="d-block text-uppercase fw-bold text-secondary summary-card-label">
                        Permanent Pool
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value" style="color:#0C3C62;">
                        10 Staff
                    </span>

                </div>
            </div>
        </div>


        {{-- Present --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">

                <div class="card-body p-3">

                    <span class="d-block text-uppercase fw-bold text-success summary-card-label">
                        Checked In (Present)
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-success">
                        8 Present
                    </span>

                </div>
            </div>
        </div>


        {{-- Absent --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">

                <div class="card-body p-3">

                    <span class="d-block text-uppercase fw-bold text-danger summary-card-label">
                        Unexcused Absences
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-danger">
                        1 Absent
                    </span>

                </div>
            </div>
        </div>


        {{-- Leave --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">

                <div class="card-body p-3">

                    <span class="d-block text-uppercase fw-bold text-warning summary-card-label">
                        Sabbatical & Leaves
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-warning">
                        1 On Leave
                    </span>

                </div>
            </div>
        </div>

    </div>


    {{-- STAFF HEADER --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="d-flex flex-column flex-md-row
                       justify-content-between
                       align-items-start
                       align-items-md-center
                       gap-3">

                {{-- TITLE --}}
                <div class="w-100 w-md-auto">

                    <div class="px-3 py-2 bg-white">

                        <span class="fw-bold" style="font-size:20px;color:#0C3C62;">
                            Permanent Staff
                        </span>

                    </div>

                </div>


                {{-- VIEW SWITCH --}}
                <div class="d-flex justify-content-start justify-content-md-end w-100 w-md-auto">

                    <div class="btn-group responsive-view-buttons" role="group">

                        {{-- LIST --}}
                        <a href="{{ url('/admin-hr/permanent-log') }}" class="btn btn-sm btn-outline-primary
                                {{ request()->is('admin-hr/permanent-log') ? 'active' : '' }}">
                            <span class="mdi mdi-format-list-bulleted me-1"></span>
                            List View
                        </a>


                        {{-- TABLE --}}
                        <a href="{{ url('/admin-hr/permanent-log/table') }}" class="btn btn-sm btn-outline-primary
                                {{ request()->is('admin-hr/permanent-log/table') ? 'active' : '' }}">
                            <span class="mdi mdi-table me-1"></span>
                            Table View
                        </a>


                        {{-- CALENDAR --}}
                        <a href="{{ url('/admin-hr/permanent-log/calender') }}" class="btn btn-sm btn-outline-primary
                                {{ request()->is('admin-hr/permanent-log/calender') ? 'active' : '' }}">
                            <span class="mdi mdi-calendar-month me-1"></span>
                            Calendar View
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{--  CALENDAR SECTION  --}}
    <div class="row g-3">

        {{--       LEFT : CALENDAR     --}}
        <div class="col-12 col-xl-8">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3 p-md-4">

                    {{-- CALENDAR HEADER --}}
                    <div class="d-flex flex-column flex-lg-row
                               justify-content-between
                               align-items-start
                               align-items-lg-center
                               gap-3
                               border-bottom
                               pb-3 mb-3">

                        {{-- TITLE --}}
                        <div>

                            <div class="d-flex align-items-center gap-2">

                                <span class="calendar-live-dot"></span>

                                <h6 class="mb-0 fw-bold text-dark calendar-title">
                                    {{ $calendarMonthName }} {{ $calendarYear }} Attendance
                                </h6>

                            </div>

                            <p class="mb-0 mt-1 text-muted calendar-description">
                                Active ledger tracking period.
                                Select dates to view or modify logs.
                            </p>

                        </div>


                        {{-- TARGET EMPLOYEE --}}
                        <div class="calendar-target-wrapper">

                            <label for="calendarEmployeeSelect" class="calendar-command-label">
                                Target Focus
                            </label>

                            <select id="calendarEmployeeSelect" class="form-select form-select-sm calendar-select">

                                <option value="ALL">
                                    All Personnel
                                </option>

                                @foreach($employees as $employee)

                                @if(
                                $employee['employmentType'] === $employmentType &&
                                (
                                $selectedDept === 'ALL' ||
                                $employee['department'] === $selectedDept
                                )
                                )

                                <option value="{{ $employee['id'] }}">
                                    {{ $employee['name'] }} - {{ $employee['role'] }}
                                </option>

                                @endif

                                @endforeach

                            </select>

                        </div>

                    </div>


                    {{--               DAY HEADER              --}}
                    <div class="calendar-week-header">

                        <div>Sun</div>
                        <div>Mon</div>
                        <div>Tue</div>
                        <div>Wed</div>
                        <div>Thu</div>
                        <div>Fri</div>
                        <div>Sat</div>

                    </div>


                    {{--                   CALENDAR GRID              --}}
                    <div class="calendar-grid">

                        {{-- EMPTY DAYS --}}
                        @for($i = 0; $i < $startDay; $i++) <div class="calendar-empty-cell">
                    </div>

                    @endfor


                    {{-- MONTH DAYS --}}
                    @for($day = 1; $day <= $daysInMonth; $day++) @php $date=\Carbon\Carbon::create( $calendarYear,
                        $calendarMonth, $day ); $dateStr=$date->format('Y-m-d');

                        $isSunday = $date->isSunday();

                        $isToday = $date->isToday();
                        @endphp


                        <div class="
                                    calendar-day-cell
                                    {{ $isSunday ? 'calendar-rest-day' : '' }}
                                    {{ $isToday ? 'calendar-today' : '' }}
                                " data-day="{{ $day }}" data-date="{{ $dateStr }}">

                            {{-- DAY NUMBER --}}
                            <div class="calendar-day-top">

                                <span class="calendar-day-number">
                                    {{ $day }}
                                </span>

                                @if($isToday)

                                <span class="calendar-today-label">
                                    Today
                                </span>

                                @endif

                            </div>


                            {{-- DAY CONTENT --}}
                            @if($isSunday)

                            <div class="calendar-rest-text">
                                Rest Day
                            </div>

                            @else

                            <div class="calendar-overview">

                                <span class="calendar-status present-status">
                                    P:0
                                </span>

                                <span class="calendar-status absent-status">
                                    A:0
                                </span>

                                <span class="calendar-status leave-status">
                                    L:0
                                </span>

                            </div>

                            @endif

                        </div>

                        @endfor

                </div>


                {{--           LEGEND            --}}
                <div class="calendar-legend">

                    <div class="calendar-legend-item">

                        <span class="legend-dot present-dot"></span>

                        Present

                    </div>


                    <div class="calendar-legend-item">

                        <span class="legend-dot absent-dot"></span>

                        Absent

                    </div>


                    <div class="calendar-legend-item">

                        <span class="legend-dot leave-dot"></span>

                        On Leave

                    </div>


                    <div class="calendar-legend-item">

                        <span class="legend-rest"></span>

                        Sunday / Rest

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{--   RIGHT : DETAIL SIDEBAR      --}}
    <div class="col-12 col-xl-4">

        <div class="card border-0 shadow-sm rounded-4 h-100">

            <div class="card-body p-3 p-md-4">

                {{-- SIDEBAR HEADER --}}
                <div class="mb-3">

                    <div class="d-flex align-items-center gap-2">

                        <i class="mdi mdi-account-group-outline calendar-sidebar-icon"></i>

                        <span class="calendar-sidebar-label">
                            Workforce Roster
                        </span>

                    </div>

                    <h6 class="fw-bold text-dark mt-2 mb-1 calendar-sidebar-title">

                        Ledger for

                        <span id="selectedCalendarDate">
                            {{ $calendarMonthName }} 1, {{ $calendarYear }}
                        </span>

                    </h6>

                    <p class="text-muted mb-0 calendar-description">
                        Directly toggle attendance for employees
                        on the selected date.
                    </p>

                </div>


                {{--                    DAY SUMMARY                    --}}
                <div class="calendar-day-summary">

                    {{-- PRESENT --}}
                    <div class="calendar-summary-box">

                        <span>
                            Present
                        </span>

                        <strong id="calendarPresentCount" class="text-success">
                            0
                        </strong>

                    </div>


                    {{-- ABSENT --}}
                    <div class="calendar-summary-box">

                        <span>
                            Absent
                        </span>

                        <strong id="calendarAbsentCount" class="text-danger">
                            0
                        </strong>

                    </div>


                    {{-- LEAVE --}}
                    <div class="calendar-summary-box">

                        <span>
                            Leave
                        </span>

                        <strong id="calendarLeaveCount" class="text-warning">
                            0
                        </strong>

                    </div>
                </div>


                {{--                        EMPLOYEE                      --}}
                <div class="calendar-roster-list">

                    @foreach($employees as $employee)

                    @if(
                    $employee['employmentType'] === $employmentType &&
                    (
                    $selectedDept === 'ALL' ||
                    $employee['department'] === $selectedDept
                    )
                    )

                    <div class="calendar-roster-item">

                        {{-- EMPLOYEE INFO --}}
                        <div class="calendar-roster-info">

                            <div class="calendar-avatar">

                                {{
                                                collect(explode(' ', $employee['name']))
                                                    ->map(
                                                        fn($name) =>
                                                            strtoupper(substr($name, 0, 1))
                                                    )
                                                    ->join('')
                                            }}

                            </div>


                            <div class="min-w-0">

                                <div class="calendar-employee-name">
                                    {{ $employee['name'] }}
                                </div>

                                <div class="calendar-employee-role">
                                    {{ $employee['role'] }}
                                </div>

                            </div>

                        </div>


                        {{-- STATUS --}}
                        <select class="form-select form-select-sm calendar-status-select status-select"
                            data-employee="{{ $employee['id'] }}">

                            <option value="Present">
                                Present
                            </option>

                            <option value="Absent">
                                Absent
                            </option>

                            <option value="On Leave">
                                On Leave
                            </option>

                        </select>

                    </div>

                    @endif

                    @endforeach

                </div>

            </div>

        </div>

    </div>

</div>

</div>


{{-- STYLES--}}
<style>
.summary-card .card-body {
    min-height: 75px;
}

.summary-card-label {
    font-size: 9px;
    letter-spacing: .5px;
    line-height: 1.4;
}

.summary-card-value {
    font-size: 1.25rem;
    line-height: 1.3;
    margin-top: 4px;
}


/* CALENDAR HEADER */

.calendar-live-dot {
    width: 9px;
    height: 9px;
    border-radius: 50%;
    background: #10b981;
    display: inline-block;
    animation: calendarPulse 1.5s infinite;
    flex-shrink: 0;
}

@keyframes calendarPulse {

    0% {
        box-shadow: 0 0 0 0 rgba(16, 185, 129, .4);
    }

    70% {
        box-shadow: 0 0 0 6px rgba(16, 185, 129, 0);
    }

    100% {
        box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
    }

}


.calendar-title {
    font-size: 14px;
}

.calendar-description {
    font-size: 9px;
    line-height: 1.5;
}

.calendar-target-wrapper {
    display: flex;
    align-items: center;
    gap: 8px;
}

.calendar-command-label {
    font-size: 9px;
    font-weight: 800;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: .08em;
    white-space: nowrap;
    margin-bottom: 0;
}

.calendar-select {
    width: 220px;
    font-size: 10px;
    font-weight: 700;
    color: #16659E;
    background-color: #f8fafc;
}


/*  WEEK HEADER */

.calendar-week-header {
    display: grid;
    grid-template-columns: repeat(7, minmax(0, 1fr));
    gap: 5px;
    text-align: center;
    font-size: 9px;
    font-weight: 800;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: .08em;
    padding-bottom: 8px;
    border-bottom: 1px solid #f1f5f9;
}


/* CALENDAR GRID  */

.calendar-grid {
    display: grid;
    grid-template-columns: repeat(7, minmax(0, 1fr));
    gap: 7px;
    margin-top: 10px;
}

.calendar-empty-cell {
    min-height: 82px;
    background: rgba(248, 250, 252, .5);
    border: 1px dashed #e2e8f0;
    border-radius: 12px;
}


.calendar-day-cell {
    min-height: 82px;
    padding: 8px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    background: #fff;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: all .15s ease;
    cursor: pointer;
    user-select: none;
}

.calendar-day-cell:hover {
    background: #f8fafc;
    border-color: #cbd5e1;
    transform: translateY(-1px);
}


/*  DAY TOP */

.calendar-day-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 4px;
}

.calendar-day-number {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
    font-weight: 900;
    color: #334155;
}


/* TODAY  */

.calendar-today {
    border-color: #16659E;
    box-shadow: 0 0 0 1px rgba(22, 101, 158, .15);
}

.calendar-today .calendar-day-number {
    background: #16659E;
    color: #fff;
}

.calendar-today-label {
    font-size: 7px;
    font-weight: 900;
    background: #dbeafe;
    color: #16659E;
    padding: 2px 4px;
    border-radius: 4px;
    text-transform: uppercase;
    white-space: nowrap;
}


/* SUNDAY  */

.calendar-rest-day {
    background: #f8fafc;
    border-color: #e2e8f0;
}

.calendar-rest-day:hover {
    background: #f1f5f9;
}

.calendar-rest-text {
    text-align: center;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 700;
    margin-bottom: 5px;
}


/* OVERVIEW STATUS  */

.calendar-overview {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 3px;
    width: 100%;
}

.calendar-status {
    display: block;
    text-align: center;
    border-radius: 4px;
    padding: 3px 1px;
    font-size: 8px;
    font-weight: 900;
    line-height: 1.1;
}

.present-status {
    color: #047857;
    background: #ecfdf5;
}

.absent-status {
    color: #be123c;
    background: #fff1f2;
}

.leave-status {
    color: #b45309;
    background: #fffbeb;
}


/* LEGEND  */

.calendar-legend {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 15px;
    margin-top: 18px;
    padding-top: 14px;
    border-top: 1px solid #f1f5f9;
    font-size: 9px;
    color: #94a3b8;
    font-weight: 700;
}

.calendar-legend-item {
    display: flex;
    align-items: center;
    gap: 6px;
}

.legend-dot {
    width: 9px;
    height: 9px;
    border-radius: 50%;
    display: inline-block;
    flex-shrink: 0;
}

.present-dot {
    background: #10b981;
}

.absent-dot {
    background: #ef4444;
}

.leave-dot {
    background: #f59e0b;
}

.legend-rest {
    width: 9px;
    height: 9px;
    border-radius: 3px;
    background: #f1f5f9;
    border: 1px solid #e2e8f0;
    display: inline-block;
    flex-shrink: 0;
}


/*   SIDEBAR   */

.calendar-sidebar-icon {
    font-size: 16px;
    color: #16659E;
}

.calendar-sidebar-label {
    font-size: 9px;
    font-weight: 900;
    color: #16659E;
    text-transform: uppercase;
    letter-spacing: .08em;
}

.calendar-sidebar-title {
    font-size: 12px;
}


/*  DAY SUMMARY  */

.calendar-day-summary {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 7px;
    background: #f8fafc;
    border: 1px solid #f1f5f9;
    padding: 10px;
    border-radius: 12px;
    margin-bottom: 15px;
}

.calendar-summary-box {
    background: #fff;
    border: 1px solid #f1f5f9;
    padding: 8px 5px;
    border-radius: 8px;
    text-align: center;
}

.calendar-summary-box span {
    display: block;
    font-size: 8px;
    font-weight: 800;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: .05em;
}

.calendar-summary-box strong {
    display: block;
    font-family: monospace;
    font-size: 16px;
    margin-top: 2px;
}


/*  ROSTER */

.calendar-roster-list {
    border: 1px solid #f1f5f9;
    border-radius: 12px;
    overflow: hidden;
    max-height: 350px;
    overflow-y: auto;
}

.calendar-roster-item {
    padding: 10px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    border-bottom: 1px solid #f1f5f9;
}

.calendar-roster-item:last-child {
    border-bottom: 0;
}

.calendar-roster-item:hover {
    background: #f8fafc;
}

.calendar-roster-info {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.calendar-avatar {
    width: 32px;
    height: 32px;
    min-width: 32px;
    border-radius: 50%;
    background: #f1f5f9;
    border: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #475569;
    font-size: 9px;
    font-weight: 800;
}

.calendar-employee-name {
    color: #1e293b;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.calendar-employee-role {
    color: #94a3b8;
    font-size: 8px;
    margin-top: 2px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.calendar-status-select {
    width: auto;
    min-width: 90px;
    max-width: 100px;
    font-size: 8px;
    font-weight: 800;
    padding: 5px 20px 5px 7px;
    flex-shrink: 0;
}


/* VIEW BUTTONS */

.responsive-view-buttons {
    white-space: nowrap;
}

.responsive-view-buttons .btn {
    font-size: 10px;
}


/*  TABLET */

@media (max-width: 991.98px) {

    .calendar-target-wrapper {
        width: 100%;
        flex-direction: column;
        align-items: stretch;
    }

    .calendar-select {
        width: 100%;
    }

    .calendar-command-label {
        font-size: 8px;
    }

    .responsive-view-buttons .btn {
        padding-left: 9px;
        padding-right: 9px;
        font-size: 9px;
    }

}


/*  MOBILE  */

@media (max-width: 575.98px) {

    .calendar-grid {
        gap: 4px;
    }

    .calendar-day-cell,
    .calendar-empty-cell {
        min-height: 65px;
        padding: 5px;
        border-radius: 8px;
    }

    .calendar-day-number {
        width: 18px;
        height: 18px;
        font-size: 8px;
    }

    .calendar-week-header {
        font-size: 7px;
        gap: 3px;
    }

    .calendar-status {
        font-size: 6px;
        padding: 2px 0;
    }

    .calendar-rest-text {
        font-size: 7px;
    }

    .calendar-today-label {
        display: none;
    }

    .calendar-legend {
        gap: 10px;
        font-size: 8px;
    }

    .calendar-roster-item {
        padding: 8px;
    }

    .calendar-avatar {
        width: 28px;
        height: 28px;
        min-width: 28px;
        font-size: 8px;
    }

    .calendar-employee-name {
        font-size: 9px;
    }

    .calendar-employee-role {
        font-size: 7px;
    }

    .calendar-status-select {
        min-width: 75px;
        max-width: 85px;
        font-size: 7px;
    }

    .responsive-view-buttons {
        width: 100%;
        display: flex;
    }

    .responsive-view-buttons .btn {
        flex: 1 1 0;
        padding: 7px 3px !important;
        font-size: 8px;
        white-space: nowrap;
    }

    .responsive-view-buttons .mdi {
        display: none;
    }

}


/* VERY SMALL MOBILE*/

@media (max-width: 400px) {

    .calendar-grid {
        gap: 2px;
    }

    .calendar-day-cell,
    .calendar-empty-cell {
        min-height: 58px;
        padding: 4px;
    }

    .calendar-day-number {
        width: 16px;
        height: 16px;
        font-size: 7px;
    }

    .calendar-status {
        font-size: 5px;
    }

    .calendar-rest-text {
        font-size: 6px;
    }

}
</style>

<script>
(() => {
 const type='permanent', api='/admin-hr/api/attendance/'+type+'/matrix', csrf=document.querySelector('meta[name="csrf-token"]')?.content||'';
 const grid=document.querySelector('.calendar-grid'), roster=document.querySelector('.calendar-roster-list'), empSel=document.getElementById('calendarEmployeeSelect');
 if(!grid||!roster)return;
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const state={month:Number(new URLSearchParams(location.search).get('month')||new Date().getMonth()+1),year:Number(new URLSearchParams(location.search).get('year')||new Date().getFullYear()),focused:null,staff:[],attendance:{}};
 async function req(url,opts={}){const r=await fetch(url,{credentials:'same-origin',...opts,headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest',...(opts.body?{'Content-Type':'application/json'}:{}),...(csrf?{'X-CSRF-TOKEN':csrf}:{}),...(opts.headers||{})}});const j=await r.json().catch(()=>({}));if(!r.ok||j.success===false)throw new Error(j.message||'Request failed ('+r.status+')');return j;}
 const codeText=c=>({P:'Present',A:'Absent',L:'On Leave',PR:'Present',OD:'On Duty',H:'Holiday'}[String(c||'').toUpperCase()]||'Not marked');
 const codeFrom=t=>({Present:'P',Absent:'A','On Leave':'L','On Duty':'OD',Holiday:'H'})[t]||'P';
 function addControls(){
  let controls=document.getElementById('hrCalendarControls');if(controls)return controls;
  controls=document.createElement('div');controls.id='hrCalendarControls';controls.className='d-flex align-items-center gap-2 flex-wrap mt-2';
  controls.innerHTML='<button class="btn btn-sm btn-outline-primary" id="hrCalendarPrev" type="button">‹</button><select class="form-select form-select-sm" id="hrCalendarMonth" style="width:135px">'+Array.from({length:12},(_,i)=>'<option value="'+(i+1)+'">'+new Date(2000,i,1).toLocaleString(undefined,{month:'long'})+'</option>').join('')+'</select><select class="form-select form-select-sm" id="hrCalendarYear" style="width:95px">'+Array.from({length:7},(_,i)=>'<option value="'+(new Date().getFullYear()-3+i)+'">'+(new Date().getFullYear()-3+i)+'</option>').join('')+'</select><button class="btn btn-sm btn-outline-primary" id="hrCalendarNext" type="button">›</button><input class="form-control form-control-sm" id="hrCalendarSearch" placeholder="Search staff" style="width:150px">';
  const title=document.querySelector('.calendar-title')?.parentElement||document.querySelector('.calendar-title')?.parentNode; if(title)title.appendChild(controls);else grid.parentElement.insertBefore(controls,grid);
  controls.querySelector('#hrCalendarMonth').value=String(state.month);controls.querySelector('#hrCalendarYear').value=String(state.year);
  controls.querySelector('#hrCalendarMonth').addEventListener('change',()=>{state.month=Number(controls.querySelector('#hrCalendarMonth').value);state.year=Number(controls.querySelector('#hrCalendarYear').value);load();});
  controls.querySelector('#hrCalendarYear').addEventListener('change',()=>{state.month=Number(controls.querySelector('#hrCalendarMonth').value);state.year=Number(controls.querySelector('#hrCalendarYear').value);load();});
  controls.querySelector('#hrCalendarPrev').addEventListener('click',()=>shift(-1));controls.querySelector('#hrCalendarNext').addEventListener('click',()=>shift(1));
  let timer;controls.querySelector('#hrCalendarSearch').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(load,250);});return controls;
 }
 function shift(step){state.month+=step;if(state.month<1){state.month=12;state.year--;}if(state.month>12){state.month=1;state.year++;}load();}
 function setCounts(date){const rows=state.staff.filter(s=>!empSel?.value||empSel.value==='ALL'||String(s.id)===String(empSel.value));let p=0,a=0,l=0;rows.forEach(s=>{const item=(state.attendance[s.id]||{})[date];if(item?.attendance==='P'||item?.attendance==='PR'||item?.attendance==='OD')p++;if(item?.attendance==='A')a++;if(item?.attendance==='L')l++;});document.getElementById('calendarPresentCount')&&(document.getElementById('calendarPresentCount').textContent=p);document.getElementById('calendarAbsentCount')&&(document.getElementById('calendarAbsentCount').textContent=a);document.getElementById('calendarLeaveCount')&&(document.getElementById('calendarLeaveCount').textContent=l);const selected=document.getElementById('selectedCalendarDate');if(selected)selected.textContent=new Date(date+'T00:00:00').toLocaleDateString(undefined,{month:'long',day:'numeric',year:'numeric'});}
 function renderCalendar(){const month=state.month,year=state.year,days=new Date(year,month,0).getDate(),firstDay=new Date(year,month-1,1).getDay();let html=Array.from({length:firstDay},()=>'<div class="calendar-empty-cell"></div>').join('');for(let day=1;day<=days;day++){const date=year+'-'+String(month).padStart(2,'0')+'-'+String(day).padStart(2,'0'),isSunday=new Date(year,month-1,day).getDay()===0;const rows=state.staff.filter(s=>!empSel?.value||empSel.value==='ALL'||String(s.id)===String(empSel.value));let p=0,a=0,l=0;rows.forEach(s=>{const c=(state.attendance[s.id]||{})[date]?.attendance;if(c==='P'||c==='PR'||c==='OD')p++;else if(c==='A')a++;else if(c==='L')l++;});html+='<div class="calendar-day-cell '+(isSunday?'calendar-rest-day ':'')+(date===state.focused?'calendar-today':'')+'" data-date="'+date+'" role="button" tabindex="0"><div class="calendar-day-top"><span class="calendar-day-number">'+day+'</span></div>'+(isSunday?'<div class="calendar-rest-text">Rest Day</div>':'<div class="calendar-overview"><span class="calendar-status present-status">P:'+p+'</span><span class="calendar-status absent-status">A:'+a+'</span><span class="calendar-status leave-status">L:'+l+'</span></div>')+'</div>';}grid.innerHTML=html;if(!state.focused||!state.focused.startsWith(year+'-'+String(month).padStart(2,'0')))state.focused=year+'-'+String(month).padStart(2,'0')+'-01';grid.querySelectorAll('.calendar-day-cell').forEach(c=>c.addEventListener('click',()=>{state.focused=c.dataset.date;renderCalendar();renderRoster();}));}
 async function save(staffId,date,value){try{const current=(state.attendance[staffId]||{})[date]||{};await req(api.replace(/\/matrix$/,''),{method:'POST',body:JSON.stringify({staff_id:Number(staffId),date,attendance:codeFrom(value),in_time:['Present','On Duty'].includes(value)&&current.in_time?String(current.in_time).slice(0,5):null,out_time:['Present','On Duty'].includes(value)&&current.out_time?String(current.out_time).slice(0,5):null,type:'Manual',reason:value==='On Leave'?'Leave':null})});await load(false);}catch(e){alert(e.message);}}
 function renderRoster(){const selected=state.staff.filter(s=>!empSel?.value||empSel.value==='ALL'||String(s.id)===String(empSel.value));const date=state.focused;roster.innerHTML=selected.map(s=>{const item=(state.attendance[s.id]||{})[date]||{},status=codeText(item.attendance);return '<div class="calendar-roster-item"><div class="calendar-roster-info"><div class="calendar-avatar">'+esc((s.name||'?').split(/\s+/).map(w=>w[0]).join('').slice(0,2).toUpperCase())+'</div><div class="min-w-0"><div class="calendar-employee-name">'+esc(s.name)+'</div><div class="calendar-employee-role">'+esc(s.designation||s.department||s.staff_id||'')+'</div></div></div><select class="form-select form-select-sm calendar-status-select" data-staff-id="'+s.id+'"><option '+(status==='Present'?'selected':'')+'>Present</option><option '+(status==='Absent'?'selected':'')+'>Absent</option><option '+(status==='On Leave'?'selected':'')+'>On Leave</option><option '+(status==='On Duty'?'selected':'')+'>On Duty</option></select></div>';}).join('')||'<div class="text-muted small p-3">No staff found for this filter.</div>';roster.querySelectorAll('select[data-staff-id]').forEach(sel=>sel.addEventListener('change',()=>save(sel.dataset.staffId,date,sel.value)));setCounts(date);}
 async function load(rebuildOptions=true){
  addControls();
  const month=String(state.month).padStart(2,'0');
  const baseQuery={month:state.year+'-'+month,per_page:'100',search:document.getElementById('hrCalendarSearch')?.value||''};
  grid.innerHTML='<div class="placeholder col-12" style="height:100px"></div>';
  try{
    const firstQuery=new URLSearchParams({...baseQuery,page:'1'});
    const first=await req(api+'?'+firstQuery);
    const pages=Number(first.meta?.last_page||1);
    const rest=pages>1?await Promise.all(Array.from({length:pages-1},(_,i)=>{
      const q=new URLSearchParams({...baseQuery,page:String(i+2)});
      return req(api+'?'+q);
    })):[];
    state.staff=[...(first.data||[])];
    state.attendance={...(first.attendance||{})};
    rest.forEach(page=>{state.staff.push(...(page.data||[]));Object.assign(state.attendance,page.attendance||{});});
    if(rebuildOptions&&empSel){const old=empSel.value;empSel.innerHTML='<option value="ALL">All Personnel</option>'+state.staff.map(s=>'<option value="'+s.id+'">'+esc(s.name)+' · '+esc(s.designation||s.department||'')+'</option>').join('');if([...empSel.options].some(o=>o.value===old))empSel.value=old;}
    const title=document.querySelector('.calendar-title');if(title)title.textContent=new Date(state.year,state.month-1,1).toLocaleString(undefined,{month:'long',year:'numeric'})+' Attendance';
    renderCalendar();renderRoster();
  }catch(e){grid.innerHTML='<div class="text-danger p-3">'+esc(e.message)+'</div>';}
 }
 empSel?.addEventListener('change',()=>{renderCalendar();renderRoster();});document.addEventListener('DOMContentLoaded',()=>load());if(document.readyState!=='loading')load();
})();
</script>

@endsection
