@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@php
$employmentType = 'Permanent';
$viewMode = 'List';

// ======= DEPARTMENTS =======
$departments = [
'ALL',
'Management',
'Engineering',
'Quality Control',
'Accounts',
'Purchase',
'Skilled Labor',
'General Labor',
];


$attendance = (object) [
    'in_time'  => '2026-10-21 09:15:00',
    'out_time' => '2026-10-21 18:30:00',
    'status'   => 'present',
];


$selectedDept = 'ALL';
@endphp

<div class="container-fluid px-0">

    {{-- ================= SUMMARY CARDS ================= --}}
    <div class="row g-3 mb-4">

        {{-- Permanent Pool --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary summary-card-label">
                        Permanent Pool
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value" style="color:#0C3C62;">
                        10 Staff
                    </span>
                </div>
            </div>
        </div>

        {{-- Present --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-success summary-card-label">
                        Checked In (Present)
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-success">
                        8 Present
                    </span>
                </div>
            </div>
        </div>

        {{-- Absent --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-danger summary-card-label">
                        Unexcused Absences
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-danger">
                        1 Absent
                    </span>
                </div>
            </div>
        </div>

        {{-- Leave --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-warning summary-card-label">
                        Sabbatical & Leaves
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-warning">
                        1 On Leave
                    </span>
                </div>
            </div>
        </div>

    </div>

    {{-- ================= STAFF HEADER ================= --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="d-flex flex-column flex-md-row
                    justify-content-between
                    align-items-start
                    align-items-md-center
                    gap-3">

                {{-- TITLE --}}
                <div class="w-100 w-md-auto">
                    <div class="px-3 py-2 bg-white">

                        <span class="fw-bold" style="font-size:20px;color:#0C3C62;">
                            Permanent Staff
                        </span>

                    </div>
                </div>


                {{-- VIEW SWITCH --}}
                <div class="d-flex justify-content-start justify-content-md-end w-100 w-md-auto">

                    <div class="btn-group responsive-view-buttons" role="group">

                        {{-- LIST --}}
                        <a href="{{ url('/admin-hr/permanent-log') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log') ? 'active' : '' }}">

                            <span class="mdi mdi-format-list-bulleted me-1"></span>
                            List View

                        </a>


                        {{-- TABLE --}}
                        <a href="{{ url('/admin-hr/permanent-log/table') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log/table') ? 'active' : '' }}">

                            <span class="mdi mdi-table me-1"></span>
                            Table View

                        </a>


                        {{-- CALENDAR --}}
                        <a href="{{ url('admin-hr/permanent-log/calender') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log/calender') ? 'active' : '' }}">

                            <span class="mdi mdi-calendar-month me-1"></span>
                            Calendar View

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

    {{-- ================= MINI DASHBOARD STYLES ================= --}}
    <style>
    .summary-card .card-body {
        min-height: 75px;
    }

    .summary-card-label {
        font-size: 9px;
        letter-spacing: .5px;
        line-height: 1.4;
    }

    .summary-card-value {
        font-size: 1.25rem;
        line-height: 1.3;
        margin-top: 4px;
    }

    .view-mode-container {
        background: #f1f5f9;
    }
    </style>

    {{-- ================= FILTER SECTION ================= --}}
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-3">

            <div class="attendance-filter-row">

                {{-- ================= SEARCH ================= --}}
                <div class="attendance-search">
                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                            style="pointer-events:none;">
                            <i class="mdi mdi-magnify"></i>
                        </span>

                        <input id="hr-search-field" type="text" placeholder="Search personnel..."
                            class="form-control form-control-sm ps-5 bg-light border-0 rounded-3">

                    </div>
                </div>

                {{-- ================= DEPARTMENT FILTERS ================= --}}
                <div class="attendance-departments">

                    <div class="department-scroll">

                        @foreach ($departments as $dept)

                        <button type="button" id="hr-dept-tab-{{ Str::slug($dept) }}" data-department="{{ $dept }}"
                            class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn
                                        {{ $selectedDept === $dept ? 'active' : '' }}">
                            {{ $dept === 'ALL' ? 'All' : $dept }}
                        </button>

                        @endforeach

                    </div>

                </div>

            </div>

        </div>
    </div>

    {{-- ================= ATTENDANCE TABLE ================= --}}
    <div class="card border-0 shadow-sm rounded-4">

        <div class="table-responsive">

            <table class="table table-hover mb-0" id="attendance-table">

                <thead>
                    <tr style="background-color:#f8fafc;">

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Personnel Information
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Department Unit
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Attendance Date
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            In / Out Time
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Daily Actions
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Attendance Status
                        </th>

                    </tr>
                </thead>

                <tbody>

                    {{-- ================= EMPLOYEE 1 ================= --}}
                    <tr data-department="Management">

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-3">

                                <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                                    style="
                                            width:36px;
                                            height:36px;
                                            background:#f1f5f9;
                                            color:#475569;
                                        ">
                                    <i class="mdi mdi-account"></i>
                                </div>

                                <div>
                                    <div class="fw-bold text-dark">
                                        Arun Kumar
                                    </div>

                                    <small class="text-muted">
                                        SRK-EMP-001 • Project Manager
                                    </small>
                                </div>

                            </div>
                        </td>

                        <td class="py-3">
                            <span class="badge rounded-2" style="
                                        background:#f1f5f9;
                                        color:#475569;
                                        font-size:9px;
                                    ">
                                Management
                            </span>
                        </td>

                        <td class="py-3 fw-semibold text-secondary">
                            Chennai Metro Phase 1
                        </td>

                        <td class="py-3 fw-bold font-monospace" style="color:#0C3C62;">
                            $250
                        </td>

                       <td class="py-3">
                            <div class="d-flex flex-wrap gap-1">
                                <button type="button" class="btn btn-sm attendance-btn present-btn active-status"
                                        data-bs-toggle="modal" data-bs-target="#presentModal">
                                    Present
                                </button>
                                <button type="button" class="btn btn-sm attendance-btn absent-btn">
                                    Absent
                                </button>
                                <button type="button" class="btn btn-sm attendance-btn leave-btn"
                                        data-bs-toggle="modal" data-bs-target="#leaveModal">
                                    Leave
                                </button>
                            </div>
                        </td>

                        <td class="py-3 px-4 text-center">
                            <span class="status-text present-status">
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Attended Site
                            </span>
                        </td>

                    </tr>

                     {{-- ================= EMPLOYEE 2 ================= --}}
                    <tr data-department="Management">

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-3">

                                <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                                    style="
                                            width:36px;
                                            height:36px;
                                            background:#f1f5f9;
                                            color:#475569;
                                        ">
                                    <i class="mdi mdi-account"></i>
                                </div>

                                <div>
                                    <div class="fw-bold text-dark">
                                        Arun Kumar
                                    </div>

                                    <small class="text-muted">
                                        SRK-EMP-001 • Project Manager
                                    </small>
                                </div>

                            </div>
                        </td>

                        <td class="py-3">
                            <span class="badge rounded-2" style="
                                        background:#f1f5f9;
                                        color:#475569;
                                        font-size:9px;
                                    ">
                                Management
                            </span>
                        </td>

                        <td class="py-3 fw-semibold text-secondary">
                            Chennai Metro Phase 1
                        </td>

                        <td class="py-3 fw-bold font-monospace" style="color:#0C3C62;">
                            $250
                        </td>

                     <td class="py-3 align-middle text-center">
                        <button type="button"
                                class="btn btn-sm btn-warning checkout-btn"
                                data-bs-toggle="modal"
                                data-bs-target="#checkoutModal"
                                
                                data-in-time="{{ $attendance->in_time ? \Carbon\Carbon::parse($attendance->in_time)->format('h:i A') : '—' }}">
                            <span class="mdi mdi-logout me-1"></span> Checkout
                        </button>
                    </td>

                        <td class="py-3 px-4 text-center">
                            <span class="status-text present-status">
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Attended Site
                            </span>
                        </td>

                    </tr>
                    {{-- ================= EMPLOYEE 2 ================= --}}
                    <tr data-department="Engineering">

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-3">

                                <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                                    style="
                                            width:36px;
                                            height:36px;
                                            background:#f1f5f9;
                                            color:#475569;
                                        ">
                                    <i class="mdi mdi-account"></i>
                                </div>

                                <div>
                                    <div class="fw-bold text-dark">
                                        Suresh Raj
                                    </div>

                                    <small class="text-muted">
                                        SRK-EMP-002 • Civil Engineer
                                    </small>
                                </div>

                            </div>
                        </td>

                        <td class="py-3">
                            <span class="badge rounded-2" style="
                                        background:#f1f5f9;
                                        color:#475569;
                                        font-size:9px;
                                    ">
                                Engineering
                            </span>
                        </td>

                        <td class="py-3 fw-semibold text-secondary">
                            Chennai Metro Phase 2
                        </td>

                        <td class="py-3 fw-bold font-monospace" style="color:#0C3C62;">
                            $180
                        </td>

                        <td class="py-3">
                            <div class="d-flex flex-wrap gap-1">
                                <button type="button" class="btn btn-sm attendance-btn present-btn "
                                        data-bs-toggle="modal" data-bs-target="#presentModal">
                                    Present
                                </button>
                                <button type="button" class="btn btn-sm attendance-btn absent-btn active-status">
                                    Absent
                                </button>
                                <button type="button" class="btn btn-sm attendance-btn leave-btn"
                                        data-bs-toggle="modal" data-bs-target="#leaveModal">
                                    Leave
                                </button>
                            </div>
                        </td>

                        <td class="py-3 px-4 text-center">
                            <span class="status-text absent-status">
                                <i class="mdi mdi-close-circle-outline me-1"></i>
                                Deducted Wage
                            </span>
                        </td>

                    </tr>

                    {{-- ================= EMPLOYEE 3 ================= --}}
                    <tr data-department="General Labor">

                        <td class="px-4 py-3">
                            <div class="d-flex align-items-center gap-3">

                                <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                                    style="
                                            width:36px;
                                            height:36px;
                                            background:#f1f5f9;
                                            color:#475569;
                                        ">
                                    <i class="mdi mdi-account"></i>
                                </div>

                                <div>
                                    <div class="fw-bold text-dark">
                                        Priya Devi
                                    </div>

                                    <small class="text-muted">
                                        SRK-EMP-003 • Supervisor
                                    </small>
                                </div>

                            </div>
                        </td>

                        <td class="py-3">
                            <span class="badge rounded-2" style="
                                        background:#f1f5f9;
                                        color:#475569;
                                        font-size:9px;
                                    ">
                                General Labor
                            </span>
                        </td>

                        <td class="py-3 fw-semibold text-secondary">
                            Chennai Metro Phase 1
                        </td>

                        <td class="py-3 fw-bold font-monospace" style="color:#0C3C62;">
                            $145
                        </td>

                       <td class="py-3">
                            <div class="d-flex flex-wrap gap-1">
                                <button type="button" class="btn btn-sm attendance-btn present-btn "
                                        data-bs-toggle="modal" data-bs-target="#presentModal">
                                    Present
                                </button>
                                <button type="button" class="btn btn-sm attendance-btn absent-btn">
                                    Absent
                                </button>
                                <button type="button" class="btn btn-sm attendance-btn leave-btn active-status"
                                        data-bs-toggle="modal" data-bs-target="#leaveModal">
                                    Leave
                                </button>
                            </div>
                        </td>

                        <td class="py-3 px-4 text-center">
                            <span class="status-text leave-status">
                                <i class="mdi mdi-alert-circle-outline me-1"></i>
                                Excused Rest
                            </span>
                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

    </div>

</div>


<!-- Present Modal -->
<div class="modal fade" id="presentModal" tabindex="-1" aria-labelledby="presentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="presentModalLabel">Mark Present</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label fw-semibold">In Time <span class="text-danger">*</span></label>
                        <input type="time" class="form-control" id="inTime">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="savePresentBtn">Save</button>
            </div>
        </div>
    </div>
</div>

<!-- Leave Modal -->
<div class="modal fade" id="leaveModal" tabindex="-1" aria-labelledby="leaveModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="leaveModalLabel">Mark Leave</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label class="form-label fw-semibold">Leave Type <span class="text-danger">*</span></label>
                <select class="form-select" id="leaveType">
                    <option value="">Select leave type</option>
                    <option value="Sick Leave">Sick Leave</option>
                    <option value="Paid Leave">Paid Leave</option>
                    <option value="Casual Leave">Casual Leave</option>
                </select>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="saveLeaveBtn">Save</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="checkoutModal" tabindex="-1" aria-labelledby="checkoutModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="checkoutForm"  action="">
                @csrf
              

                <div class="modal-header">
                    <h5 class="modal-title" id="checkoutModalLabel">
                        <span class="mdi mdi-logout me-1"></span> Checkout
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label text-muted small">In-time</label>
                        <div id="displayInTime" class="fw-semibold">09:30</div>
                    </div>

                    <div class="mb-3">
                        <label for="outTime" class="form-label">Out-time <span class="text-danger">*</span></label>
                        <input type="time"
                               class="form-control"
                               id="outTime"
                               name="out_time"
                               required>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">
                        <span class="mdi mdi-logout me-1"></span> Confirm Checkout
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
{{-- ================= FILTER STYLES ================= --}}
<style>
.attendance-filter-row {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    min-width: 0;
}

.attendance-search {
    flex: 0 0 180px;
    width: 180px;
    min-width: 180px;
}

.attendance-search .position-relative {
    width: 100%;
}

/* Present – Green */
.present-btn {
    color: #198754;
    border: 1px solid #198754;
    background-color: #fff;
}
.present-btn:hover,
.present-btn.active-status {
    background-color: #198754;
    color: #fff;
    border-color: #198754;
}

/* Absent – Red */
.absent-btn {
    color: #dc3545;
    border: 1px solid #dc3545;
    background-color: #fff;
}
.absent-btn:hover,
.absent-btn.active-status {
    background-color: #dc3545;
    color: #fff;
    border-color: #dc3545;
}

/* Leave – Amber / Warning */
.leave-btn {
    color: #d97706;
    border: 1px solid #d97706;
    background-color: #fff;
}
.leave-btn:hover,
.leave-btn.active-status {
    background-color: #d97706;
    color: #fff;
    border-color: #d97706;
}

#hr-search-field {
    width: 100%;
    height: 36px;
    font-size: 11px;
    padding-right: 8px;
}

.attendance-departments {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
}

.department-scroll {
    display: flex;
    align-items: center;
    gap: 5px;
    width: 100%;
    min-width: 0;
    overflow-x: auto;
    overflow-y: hidden;
    white-space: nowrap;
    scrollbar-width: none;
    -ms-overflow-style: none;
    padding: 1px 0;
}

.department-scroll::-webkit-scrollbar {
    display: none;
}

.dept-filter-btn {
    flex: 0 0 auto;
    height: 36px;
    padding: 0 12px !important;
    font-size: 10px;
    background-color: #f8fafc;
    color: #475569;
    border: 1px solid transparent;
    white-space: nowrap;
    transition: all 0.2s ease;
}

.dept-filter-btn:hover {
    background-color: #e2e8f0;
    color: #0f172a;
}

.dept-filter-btn.active {
    background-color: #16659E !important;
    color: #ffffff !important;
    border-color: #16659E;
    box-shadow: 0 2px 5px rgba(22, 101, 158, 0.20);
}

/* ================= LARGE DESKTOP ================= */
@media (min-width: 1400px) {
    .attendance-search {
        flex: 0 0 180px;
        width: 180px;
        min-width: 180px;
    }

    .attendance-filter-row {
        gap: 8px;
    }

    .dept-filter-btn {
        padding-left: 10px !important;
        padding-right: 10px !important;
    }
}

/* ================= DESKTOP ================= */
@media (min-width: 1200px) and (max-width: 1399.98px) {
    .attendance-search {
        flex: 0 0 160px;
        width: 160px;
        min-width: 160px;
    }

    .dept-filter-btn {
        padding-left: 8px !important;
        padding-right: 8px !important;
        font-size: 9px;
    }
}

/* ================= TABLET ================= */
@media (min-width: 768px) and (max-width: 1199.98px) {
    .attendance-search {
        flex: 0 0 150px;
        width: 150px;
        min-width: 150px;
    }

    .dept-filter-btn {
        padding-left: 9px !important;
        padding-right: 9px !important;
        font-size: 9px;
    }
}

/* ================= MOBILE ================= */
@media (max-width: 767.98px) {
    .attendance-filter-row {
        flex-direction: column;
        align-items: stretch;
        gap: 10px;
    }

    .attendance-search {
        width: 100%;
        min-width: 0;
        flex: none;
    }

    .attendance-departments {
        width: 100%;
    }

    .department-scroll {
        overflow-x: auto;
    }

    .dept-filter-btn {
        font-size: 10px;
        padding-left: 10px !important;
        padding-right: 10px !important;
    }
}

/* ===============================
   RESPONSIVE VIEW SWITCH
================================ */

.responsive-view-buttons {
    white-space: nowrap;
}

/* Tablet */
@media (max-width: 991.98px) {

    .responsive-view-buttons .btn {
        padding-left: 10px !important;
        padding-right: 10px !important;
        font-size: 11px;
    }

}

/* Mobile */
@media (max-width: 575.98px) {

    .responsive-view-buttons {
        width: 100%;
        display: flex;
    }

    .responsive-view-buttons .btn {
        flex: 1 1 0;
        padding: 8px 5px !important;
        font-size: 10px;
        white-space: nowrap;
    }

    .responsive-view-buttons .mdi {
        margin-right: 2px !important;
    }

}

/* Very small mobile */
@media (max-width: 400px) {

    .responsive-view-buttons .btn {
        padding: 7px 3px !important;
        font-size: 9px;
    }

    .responsive-view-buttons .mdi {
        display: none;
    }

}
</style>

<script>
(function () {
  'use strict';
  const type = 'permanent';
  const api = '/admin-hr/api/attendance/' + type;
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
  const state = { page: 1, perPage: 10, search: '', department: 'ALL', date: localDate(), rows: [], selected: null };
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function localDate() { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0'); }
  function codeLabel(code) { return ({P:'Present',PR:'Present',A:'Absent',L:'On Leave',OD:'On Duty',H:'Holiday'})[String(code || '').toUpperCase()] || 'Not marked'; }
  function currentFor(staffId) { return state.rows.find(row => Number(row.staff_pk) === Number(staffId)) || {}; }
  async function request(url, options = {}) {
    const response = await fetch(url, { credentials:'same-origin', ...options, headers:{
      Accept:'application/json', 'X-Requested-With':'XMLHttpRequest',
      ...(csrf ? {'X-CSRF-TOKEN':csrf} : {}),
      ...(options.body ? {'Content-Type':'application/json'} : {}), ...(options.headers || {})
    }});
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload.success === false) throw new Error(payload.message || Object.values(payload.errors || {}).flat()[0] || `Request failed (${response.status}).`);
    return payload;
  }
  function statusHtml(code) {
    const label = codeLabel(code);
    const klass = label === 'Present' || label === 'On Duty' ? 'present-status' : label === 'Absent' ? 'absent-status' : label === 'On Leave' ? 'leave-status' : 'text-muted';
    const icon = label === 'Present' || label === 'On Duty' ? 'mdi-check-circle-outline' : label === 'Absent' ? 'mdi-close-circle-outline' : label === 'On Leave' ? 'mdi-alert-circle-outline' : 'mdi-minus-circle-outline';
    return '<span class="status-text ' + klass + '"><i class="mdi ' + icon + ' me-1"></i>' + esc(label) + '</span>';
  }
  function actionHtml(row) {
    const id = Number(row.staff_pk), date = row.date || state.date;
    const attrs = ' data-staff-id="' + id + '" data-date="' + esc(date) + '"';
    return '<div class="d-flex flex-wrap gap-1">' +
      '<button type="button" class="btn btn-sm attendance-btn present-btn" data-attendance-action="present"' + attrs + ' data-bs-toggle="modal" data-bs-target="#presentModal">Present</button>' +
      '<button type="button" class="btn btn-sm attendance-btn absent-btn" data-attendance-action="absent"' + attrs + '>Absent</button>' +
      '<button type="button" class="btn btn-sm attendance-btn leave-btn" data-attendance-action="leave"' + attrs + ' data-bs-toggle="modal" data-bs-target="#leaveModal">Leave</button>' +
      (row.in_time ? '<button type="button" class="btn btn-sm btn-warning checkout-btn" data-attendance-action="checkout"' + attrs + ' data-in-time="' + esc(String(row.in_time).slice(0,5)) + '" data-bs-toggle="modal" data-bs-target="#checkoutModal"><i class="mdi mdi-logout me-1"></i>Checkout</button>' : '') +
      '</div>';
  }
  function renderRows() {
    const body = document.querySelector('#attendance-table tbody');
    if (!body) return;
    body.innerHTML = state.rows.map(row => {
      const department = row.department_name || '—';
      const designation = row.designation || 'Staff';
      const name = row.staff_name || '—';
      const code = row.staff_code || '';
      const date = row.date || state.date;
      const time = (row.in_time ? String(row.in_time).slice(0,5) : '—') + ' / ' + (row.out_time ? String(row.out_time).slice(0,5) : '—');
      return '<tr data-staff-id="' + Number(row.staff_pk) + '" data-date="' + esc(date) + '">' +
        '<td class="px-4 py-3"><div class="d-flex align-items-center gap-3"><div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:36px;height:36px;background:#f1f5f9;color:#475569"><i class="mdi mdi-account"></i></div><div><div class="fw-bold text-dark">' + esc(name) + '</div><small class="text-muted">' + esc(code) + ' • ' + esc(designation) + '</small></div></div></td>' +
        '<td class="py-3"><span class="badge rounded-2" style="background:#f1f5f9;color:#475569;font-size:9px">' + esc(department) + '</span></td>' +
        '<td class="py-3 fw-semibold text-secondary">' + esc(date) + '</td>' +
        '<td class="py-3 fw-bold font-monospace" style="color:#0C3C62">' + esc(time) + '</td>' +
        '<td class="py-3">' + actionHtml(row) + '</td>' +
        '<td class="py-3 px-4 text-center">' + statusHtml(row.attendance) + '</td>' +
      '</tr>';
    }).join('') || '<tr><td colspan="6" class="text-center text-muted py-4">No active staff records found.</td></tr>';
  }
  function updateSummary(summary) {
    const values = document.querySelectorAll('.summary-card-value');
    if (values[0]) values[0].textContent = Number(summary.staff_count || 0) + ' Staff';
    if (values[1]) values[1].textContent = Number(summary.present_count || 0) + ' Present';
    if (values[2]) values[2].textContent = Number(summary.absent_count || 0) + ' Absent';
    if (values[3]) values[3].textContent = Number(summary.leave_count || 0) + ' On Leave';
  }
  function renderPager(meta) {
    const table = document.getElementById('attendance-table');
    if (!table) return;
    let host = document.getElementById('attendance-ajax-pagination');
    if (!host) { host = document.createElement('div'); host.id = 'attendance-ajax-pagination'; host.className = 'd-flex justify-content-between align-items-center flex-wrap gap-2 p-3'; table.closest('.card')?.append(host); }
    if (!host) return;
    host.innerHTML = '<small class="text-muted">' + Number(meta.total || 0) + ' staff · Page ' + Number(meta.current_page || 1) + ' / ' + Number(meta.last_page || 1) + '</small><div class="d-flex gap-2 align-items-center"><select id="attPageSize" class="form-select form-select-sm" style="width:82px"><option>10</option><option>25</option><option>50</option><option>100</option></select><button type="button" class="btn btn-sm btn-outline-secondary" id="attPrev" ' + (Number(meta.current_page || 1) <= 1 ? 'disabled' : '') + '>Previous</button><button type="button" class="btn btn-sm btn-outline-secondary" id="attNext" ' + (Number(meta.current_page || 1) >= Number(meta.last_page || 1) ? 'disabled' : '') + '>Next</button></div>';
    const size = host.querySelector('#attPageSize'); size.value = String(meta.per_page || state.perPage); size.onchange = () => { state.perPage = Number(size.value); state.page = 1; load(); };
    host.querySelector('#attPrev').onclick = () => { state.page = Math.max(1, state.page - 1); load(); };
    host.querySelector('#attNext').onclick = () => { state.page = Math.min(Number(meta.last_page || 1), state.page + 1); load(); };
  }
  async function load() {
    const body = document.querySelector('#attendance-table tbody'); if (!body) return;
    body.innerHTML = '<tr><td colspan="6" class="py-4"><div class="placeholder-glow"><span class="placeholder col-12 mb-2"></span><span class="placeholder col-8"></span></div></td></tr>';
    const query = new URLSearchParams({ page:state.page, per_page:state.perPage, search:state.search, department:state.department, date:state.date, sort:'staff', direction:'asc' });
    try { const payload = await request(api + '?' + query.toString()); state.rows = payload.data || []; renderRows(); renderPager(payload.meta || {}); updateSummary(payload.summary || {}); }
    catch (error) { body.innerHTML = '<tr><td colspan="6" class="text-danger text-center py-4">' + esc(error.message) + '</td></tr>'; }
  }
  function setSelected(trigger) {
    if (!trigger) return;
    const staffId = Number(trigger.dataset.staffId), date = trigger.dataset.date || state.date;
    if (staffId && date) state.selected = { staff_id:staffId, date };
  }
  async function saveAttendance(attendance, values = {}) {
    if (!state.selected) throw new Error('Select a staff member first.');
    const current = currentFor(state.selected.staff_id);
    const isPresent = ['P','PR','OD'].includes(attendance);
    const payload = {
      staff_id:state.selected.staff_id, date:state.selected.date, attendance,
      in_time:isPresent ? (values.in_time !== undefined ? values.in_time : (current.in_time ? String(current.in_time).slice(0,5) : null)) : null,
      out_time:isPresent ? (values.out_time !== undefined ? values.out_time : (current.out_time ? String(current.out_time).slice(0,5) : null)) : null,
      type:'Manual', reason:values.reason ?? null
    };
    await request(api, { method:'POST', body:JSON.stringify(payload) });
    window.toastr?.success?.('Daily attendance saved.');
    await load();
  }
  const presentModal = document.getElementById('presentModal');
  presentModal?.addEventListener('show.bs.modal', event => { setSelected(event.relatedTarget); const current = state.selected ? currentFor(state.selected.staff_id) : {}; const input = document.getElementById('inTime'); if (input) input.value = current.in_time ? String(current.in_time).slice(0,5) : '09:00'; });
  document.getElementById('savePresentBtn')?.addEventListener('click', async event => { const btn = event.currentTarget, inTime = document.getElementById('inTime')?.value || null; if (!inTime) { alert('Enter the check-in time.'); return; } btn.disabled = true; try { await saveAttendance('P', { in_time:inTime }); bootstrap.Modal.getInstance(presentModal)?.hide(); } catch (error) { alert(error.message); } finally { btn.disabled = false; } });
  const leaveModal = document.getElementById('leaveModal');
  leaveModal?.addEventListener('show.bs.modal', event => { setSelected(event.relatedTarget); });
  document.getElementById('saveLeaveBtn')?.addEventListener('click', async event => { const btn = event.currentTarget, leaveType = document.getElementById('leaveType')?.value; if (!leaveType) { alert('Select a leave type.'); return; } btn.disabled = true; try { await saveAttendance('L', { reason:leaveType, in_time:null, out_time:null }); bootstrap.Modal.getInstance(leaveModal)?.hide(); } catch (error) { alert(error.message); } finally { btn.disabled = false; } });
  const checkoutModal = document.getElementById('checkoutModal');
  checkoutModal?.addEventListener('show.bs.modal', event => { setSelected(event.relatedTarget); const current = state.selected ? currentFor(state.selected.staff_id) : {}; const input = document.getElementById('outTime'); const display = document.getElementById('displayInTime'); if (display) display.textContent = current.in_time ? String(current.in_time).slice(0,5) : '—'; if (input) { input.value = current.out_time ? String(current.out_time).slice(0,5) : ''; input.min = current.in_time ? String(current.in_time).slice(0,5) : ''; } });
  document.getElementById('checkoutForm')?.addEventListener('submit', async event => { event.preventDefault(); const out = document.getElementById('outTime')?.value; if (!out) { alert('Enter the check-out time.'); return; } const current = state.selected ? currentFor(state.selected.staff_id) : {}; const code = ['P','PR','OD'].includes(String(current.attendance || '').toUpperCase()) ? String(current.attendance).toUpperCase() : 'P'; const form = event.currentTarget; const submit = form.querySelector('[type="submit"]'); if (submit) submit.disabled = true; try { await saveAttendance(code, { in_time:current.in_time ? String(current.in_time).slice(0,5) : null, out_time:out, reason:current.reason || null }); bootstrap.Modal.getInstance(checkoutModal)?.hide(); } catch (error) { alert(error.message); } finally { if (submit) submit.disabled = false; } });
  document.addEventListener('click', async event => { const button = event.target.closest('[data-attendance-action="absent"]'); if (!button) return; event.preventDefault(); setSelected(button); button.disabled = true; try { await saveAttendance('A', { in_time:null, out_time:null, reason:null }); } catch (error) { alert(error.message); } finally { button.disabled = false; } });
  document.querySelectorAll('.dept-filter-btn').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('.dept-filter-btn').forEach(item => item.classList.toggle('active', item === button));
    state.department = button.dataset.department || 'ALL'; state.page = 1; load();
  }));
  const searchInput = document.getElementById('hr-search-field') || document.querySelector('.attendance-search input');
  let searchTimer; searchInput?.addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(() => { state.search = searchInput.value.trim(); state.page = 1; load(); }, 250); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', load, { once:true }); else load();
})();
</script>
@endsection
