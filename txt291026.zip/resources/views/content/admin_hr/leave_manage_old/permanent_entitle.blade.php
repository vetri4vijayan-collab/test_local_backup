@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('content')

@php

$permanentEmployees = [
[
'id' => 1,
'name' => 'Arun Kumar',
'role' => 'Project Manager',
'department' => 'Management',
'status' => 'Present',
],
[
'id' => 2,
'name' => 'Suresh Raj',
'role' => 'Civil Engineer',
'department' => 'Engineering',
'status' => 'On Leave',
],
[
'id' => 3,
'name' => 'Priya Devi',
'role' => 'Supervisor',
'department' => 'General Labor',
'status' => 'Present',
],
[
'id' => 4,
'name' => 'Karthik Kumar',
'role' => 'Quality Inspector',
'department' => 'Quality Control',
'status' => 'Present',
],
[
'id' => 5,
'name' => 'Meena Devi',
'role' => 'Accountant',
'department' => 'Accounts',
'status' => 'Present',
],
];

$leaveRequests = [
[
'id' => 1,
'employeeId' => 2,
'employeeName' => 'Suresh Raj',
'leaveType' => 'Casual',
'startDate' => '2026-07-22',
'endDate' => '2026-07-23',
'days' => 2,
'appliedDate' => '2026-07-20',
'reason' => 'Personal work',
'status' => 'Pending',
],
[
'id' => 2,
'employeeId' => 1,
'employeeName' => 'Arun Kumar',
'leaveType' => 'Privilege',
'startDate' => '2026-07-10',
'endDate' => '2026-07-12',
'days' => 3,
'appliedDate' => '2026-07-05',
'reason' => 'Family function',
'status' => 'Approved',
],
[
'id' => 3,
'employeeId' => 4,
'employeeName' => 'Karthik Kumar',
'leaveType' => 'Sick',
'startDate' => '2026-07-15',
'endDate' => '2026-07-15',
'days' => 1,
'appliedDate' => '2026-07-15',
'reason' => 'Medical leave',
'status' => 'Approved',
],
];

$totalPersonnel = count($permanentEmployees);

$onLeaveToday = count(array_filter($permanentEmployees, function ($employee) {
return $employee['status'] === 'On Leave';
}));

$pendingRequests = count(array_filter($leaveRequests, function ($request) {
return $request['status'] === 'Pending';
}));

$approvedThisMonth = count(array_filter($leaveRequests, function ($request) {
return $request['status'] === 'Approved';
}));

@endphp


<div class="container-fluid px-0 leave-page">

    {{-- ============================================================
        PAGE HEADER
    ============================================================= --}}
    <div class="card border-0 shadow-sm leave-header-card mb-3">
        <div class="card-body px-3 py-3">

            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start
                        align-items-md-center  gap-2">
                <div>
                    <h4 class="mb-1 fw-bold" style="color:#0C3C62;">
                        Leave Management
                    </h4>
                </div>

                <button type="button" class="btn btn-primary btn-sm rounded-2 px-3" data-bs-toggle="modal"
                    data-bs-target="#applyLeaveModal">
                    <i class="mdi mdi-plus me-1"></i>
                    Apply Leave
                </button>
            </div>
        </div>
    </div>


    {{--  LEAVE POLICY --}}
    <div class="row leave-policy-row">
        {{-- Casual Leave --}}
        <div class="col-12 col-md-6 col-xl-4 leave-policy-col">
            <div class="leave-policy-card">
                <div class="leave-policy-title">
                    <span class="leave-type-badge leave-type-cl fs-7">
                        CL
                    </span>
                    <h4 class="fs-4">
                        Casual Leave Eligibility
                    </h4>
                </div>
                <div class="leave-policy-details">
                    <div class="leave-policy-item fs-6">
                        <span>Permanent Quota</span>
                        <strong class="leave-blue">
                            12 Days / Year
                        </strong>
                    </div>
                    <div class="leave-policy-item fs-6">
                        <span>Contract Quota</span>
                        <strong>
                            7 Days / Year
                        </strong>
                    </div>
                </div>
            </div>
        </div>

        {{-- Privilege Leave --}}
        <div class="col-12 col-md-6 col-xl-4 leave-policy-col">
            <div class="leave-policy-card">
                <div class="leave-policy-title">
                    <span class="leave-type-badge leave-type-pl fs-7">
                        PL
                    </span>
                    <h4 class="fs-4">
                        Privilege / Earned Leave
                    </h4>
                </div>
                <div class="leave-policy-details">
                    <div class="leave-policy-item fs-6">
                        <span>Permanent Quota</span>
                        <strong class="leave-green">
                            15 Days / Year
                        </strong>
                    </div>
                    <div class="leave-policy-item fs-6">
                        <span>Contract Quota</span>
                        <strong>
                            10 Days / Year
                        </strong>
                    </div>
                </div>
            </div>
        </div>
        {{-- Sick Leave --}}
        <div class="col-12 col-md-12 col-xl-4 leave-policy-col">
            <div class="leave-policy-card">
                <div class="leave-policy-title">
                    <span class="leave-type-badge leave-type-sl fs-7 ">
                        SL
                    </span>
                    <h4 class="fs-4">
                        Sick / Medical Leave
                    </h4>
                </div>

                <div class="leave-policy-details">
                    <div class="leave-policy-item fs-6">
                        <span>Permanent Quota</span>
                        <strong class="leave-amber">
                            12 Days / Year
                        </strong>
                    </div>
                    <div class="leave-policy-item fs-6">
                        <span>Contract Quota</span>
                        <strong>
                            7 Days / Year
                        </strong>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{--  NAVIGATION --}}
    <div class="card border-0 shadow-sm leave-navigation-card mb-3">
        <div class="card-body p-2">
            <div class="d-flex flex-column flex-lg-row justify-content-between gap-2">
                <div class="d-flex flex-wrap gap-2">
                    <a href="{{ route('admin-hr.leave.permanent') }}" class="btn btn-light btn-sm rounded-2">
                        <i class="mdi mdi-calendar-check-outline me-1"></i>
                        Leave Applications
                        <span class="badge bg-secondary ms-1">
                            {{ count($leaveRequests) }}
                        </span>
                    </a>


                    <a href="{{ route('admin-hr.leave.permanent_entitle') }}" class="btn btn-primary btn-sm rounded-2">

                        <i class="mdi mdi-table me-1"></i>

                        Leave Entitlement

                        <span class="badge bg-light text-primary ms-1">
                            {{ $totalPersonnel }}
                        </span>
                    </a>
                </div>
                <div>
                    <button type="button" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="modal"
                        data-bs-target="#leaveSettingsModal">
                        <i class="mdi mdi-cog-outline me-1"></i>
                        Configure Settings
                    </button>
                </div>
            </div>
        </div>
    </div>


    {{-- LEAVE LEDGER --}}
    <div class="leave-ledger-card">
        {{-- Header --}}
        <div class="leave-ledger-header">
            <div class="leave-ledger-heading">
                <h3 class="fs-6">
                    <i class="mdi mdi-calendar-check-outline"></i>
                    Employee Leave Entitlements & Balances
                </h3>

            </div>


            {{-- Controls --}}
            <div class="leave-ledger-controls">
                <div class="leave-search-box">
                    <i class="mdi mdi-magnify"></i>
                    <input type="text" placeholder="Search employee...">
                </div>
                <button type="button" class="leave-action-btn leave-credit-btn" data-bs-toggle="modal"
                    data-bs-target="#batchCreditModal">
                    <i class="mdi mdi-plus"></i>
                    <span>Batch Credit Leaves</span>
                </button>
                <button type="button" class="leave-action-btn leave-export-btn">
                    <i class="mdi mdi-download"></i>
                    <span>
                        Export CSV
                    </span>
                </button>
            </div>
        </div>


        {{-- TABLE--}}
        <div class="leave-table-wrapper">
            <table class="table leave-balance-table table-hover mb-0">
                <colgroup>
                    <col class="employee">
                    <col class="leave">
                    <col class="leave">
                    <col class="leave">
                    <col class="total">
                    <col class="health">
                    <col class="action">
                </colgroup>


                <thead class="fw-semibold text-black  uppercase bg-light">
                    <tr>
                        <th class="employee-column min-w-100px text-black">
                            Employee
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Casual Leave
                            <small>
                                Entitled / Availed / Balance
                            </small>
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Privilege Leave
                            <small>
                                Entitled / Availed / Balance
                            </small>
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Sick Leave
                            <small>
                                Entitled / Availed / Balance
                            </small>
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Total Allocation
                            <small>
                                Balance / Total
                            </small>
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Balance Health
                        </th>
                        <th class="employee-column min-w-100px text-black text-center">
                            Actions
                        </th>
                    </tr>
                </thead>

                <tbody>
                    {{--EMPLOYEE 1  --}}
                    <tr>
                        <td class="employee-column">
                            <div class="employee-profile">
                                <div class="employee-avatar">
                                    J
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name">
                                        Jayachandran Arumugam
                                    </div>
                                    <div class="employee-meta">
                                        Project Engineer
                                        <span>•</span>
                                        SRK-EMP-001
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    3
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-blue">
                                    9d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    18
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    5
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-green">
                                    13d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    2
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-amber">
                                    10d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="total-allocation">
                                <strong>
                                    32
                                    <span>/ 42 Days</span>
                                </strong>
                                <small>
                                    Availed: 10 Days
                                </small>
                            </div>
                        </td>
                        <td>
                            <span class="balance-health health-healthy">
                                Healthy (32d)
                            </span>
                        </td>
                        <td class="text-center">
                            <button type="button" class="adjust-quota-btn text-center" title="Adjust Quota"
                                data-employee-id="1">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                        </td>
                    </tr>

                    {{-- EMPLOYEE 2 --}}
                    <tr>
                        <td class="employee-column">
                            <div class="employee-profile">
                                <div class="employee-avatar">
                                    F
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name">
                                        Francis Xavier
                                    </div>
                                    <div class="employee-meta">
                                        Project Manager
                                        <span>•</span>
                                        SRK-EMP-002
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    7
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    3
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-blue">
                                    4d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    10
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    2
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-green">
                                    8d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    7
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    4
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-amber">
                                    3d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="total-allocation">
                                <strong>
                                    15
                                    <span>/ 24 Days</span>
                                </strong>
                                <small>
                                    Availed: 9 Days
                                </small>
                            </div>
                        </td>
                        <td>
                            <span class="balance-health health-moderate">
                                Moderate (15d)
                            </span>
                        </td>
                        <td class="text-center">
                            <button type="button" class="adjust-quota-btn text-center" title="Adjust Quota"
                                data-employee-id="1">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                        </td>
                    </tr>


                    {{--EMPLOYEE 3 --}}
                    <tr>
                        <td class="employee-column">
                            <div class="employee-profile">
                                <div class="employee-avatar">
                                    A
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name">
                                        Anbu Selvan

                                    </div>

                                    <div class="employee-meta">
                                        Crane Operator
                                        <span>•</span>
                                        SRK-EMP-003
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    8
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-blue">
                                    4d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    15
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    11
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-green">
                                    4d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    8
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-amber">
                                    4d
                                </span>
                            </div>
                        </td>

                        <td>
                            <div class="total-allocation">
                                <strong>
                                    12
                                    <span>/ 39 Days</span>
                                </strong>
                                <small>
                                    Availed: 27 Days
                                </small>
                            </div>
                        </td>
                        <td>
                            <span class="balance-health health-low">
                                Low Balance (12d)
                            </span>
                        </td>

                        <td class="text-center">
                            <button type="button" class="adjust-quota-btn text-center" title="Adjust Quota"
                                data-employee-id="1">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                        </td>

                    </tr>


                    {{-- EMPLOYEE 4 --}}
                    <tr>
                        <td class="employee-column">
                            <div class="employee-profile">
                                <div class="employee-avatar">
                                    P
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name">
                                        Priya Devi
                                    </div>
                                    <div class="employee-meta">
                                        Supervisor
                                        <span>•</span>
                                        SRK-EMP-004
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    1
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-blue">
                                    11d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    15
                                </span>
                                <span class="leave-separator">/</span>

                                <span class="leave-availed">
                                    4
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-green">
                                    11d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    2
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-amber">
                                    10d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="total-allocation">
                                <strong>
                                    32
                                    <span>/ 39 Days</span>
                                </strong>
                                <small>
                                    Availed: 7 Days
                                </small>
                            </div>
                        </td>
                        <td>
                            <span class="balance-health health-healthy">
                                Healthy (32d)
                            </span>
                        </td>
                        <td class="text-center">
                            <button type="button" class="adjust-quota-btn text-center" title="Adjust Quota"
                                data-employee-id="1">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>


    {{-- APPLY LEAVE MODAL--}}
    <div class="modal fade" id="applyLeaveModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">
                        Apply Permanent Staff Leave
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                    </button>
                </div>
                <form>
                    @csrf
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label small fw-bold">
                                    Employee
                                </label>

                                <select name="employee_id" class="select3 form-select" required>

                                    <option value="">
                                        Select Employee
                                    </option>

                                    @foreach($permanentEmployees as $employee)

                                    <option value="{{ $employee['id'] }}">
                                        {{ $employee['name'] }}
                                        - {{ $employee['role'] }}
                                    </option>

                                    @endforeach

                                </select>

                            </div>


                            <div class="col-12">

                                <label class="form-label small fw-bold">
                                    Leave Type
                                </label>

                                <select name="leave_type" class="form-select form-select-sm" required>

                                    <option value="">
                                        Select Leave Type
                                    </option>

                                    <option value="Casual">
                                        Casual Leave
                                    </option>

                                    <option value="Privilege">
                                        Privilege Leave
                                    </option>

                                    <option value="Sick">
                                        Sick Leave
                                    </option>

                                </select>

                            </div>


                            <div class="col-6">

                                <label class="form-label small fw-bold">
                                    From Date
                                </label>

                                <input type="date" name="start_date" class="form-control form-control-sm" required>

                            </div>


                            <div class="col-6">
                                <label class="form-label small fw-bold">
                                    To Date
                                </label>
                                <input type="date" name="end_date" class="form-control form-control-sm" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">
                                    Reason / Remarks
                                </label>
                                <textarea name="reason" rows="3" class="form-control form-control-sm"
                                    placeholder="Enter leave reason..."></textarea>
                            </div>
                        </div>
                    </div>


                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="mdi mdi-check me-1"></i>
                            Submit Leave
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

    <!-- Adjust Leave Modal -->
    <div class="modal fade" id="adjustBalanceModal" tabindex="-1" aria-labelledby="adjustBalanceModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered ">
            <div class="modal-content rounded-3 overflow-hidden border-0 shadow">

                <form id="adjustBalanceForm" class="adjust-balance-form">
                    <!-- Modal Header -->
                    <div class="adjust-balance-header p-3 p-md-4 d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-3">
                            <div class="header-icon-wrapper p-2 rounded-3">
                                <i class="bi bi-award text-white fs-5"></i>
                            </div>
                            <div>
                                <h3 class="header-title m-0 text-white fw-bold fs-6" id="adjustBalanceModalLabel">Adjust
                                    Leave Entitlement Quota</h3>
                                <p class="header-subtitle m-0 text-white-50">Configure annual CL, PL, and SL days for
                                    staff member</p>
                            </div>
                        </div>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>

                    <!-- Modal Body -->
                    <div class="adjust-balance-body p-3 p-md-4">

                        <!-- Employee Select -->
                        <div class="mb-3">
                            <label for="adjustBalanceEmpSelect"
                                class="form-label-custom text-uppercase fw-bold text-muted mb-1">
                                Select Employee
                            </label>
                            <select id="adjustBalanceEmpSelect" name="adjustBalanceEmpId"
                                class="form-select custom-input">
                                <option value="1">John Doe (SRK-EMP-001) — Project Engineer</option>
                                <option value="2">Jane Smith (SRK-EMP-002) — Senior Developer</option>
                            </select>
                        </div>

                        <!-- Quota Inputs Row 1 -->
                        <div class="row g-3 mb-3">
                            <div class="col-12 col-md-6">
                                <label for="adjustCL"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">Casual Leave
                                    (CL)</label>
                                <input type="number" id="adjustCL" name="adjustCL" min="0" value="0"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="adjustPL"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">Privilege Leave
                                    (PL)</label>
                                <input type="number" id="adjustPL" name="adjustPL" min="0" value="0"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                        </div>

                        <!-- Quota Inputs Row 2 -->
                        <div class="row g-3 mb-4">
                            <div class="col-12 col-md-6">
                                <label for="adjustPrevPL"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">Prev PL Carry
                                    Forward</label>
                                <input type="number" id="adjustPrevPL" name="adjustPrevPL" min="0" value="0"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="adjustSL"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">Sick Leave
                                    (SL)</label>
                                <input type="number" id="adjustSL" name="adjustSL" min="0" value="0"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                        </div>

                        <!-- Actions -->
                        <div class="form-footer pt-3 d-flex justify-content-end gap-2 border-top">
                            <button type="button" class="btn btn-outline-secondary px-4 fw-bold"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="submit"
                                class="btn-submit btn text-white px-4 fw-bold d-inline-flex align-items-center gap-2">
                                <i class="bi bi-check-circle-fill"></i>
                                <span>Save Leave Quotas</span>
                            </button>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>

    {{-- LEAVE SETTINGS MODAL --}}
    <div class="modal fade" id="leaveSettingsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">
                        Permanent Staff Leave Policy
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-sm-4">
                            <label class="form-label small fw-bold">
                                Casual Leave
                            </label>
                            <input type="number" class="form-control form-control-sm" value="12">
                            <small class="text-muted">
                                Days / Year
                            </small>
                        </div>
                        <div class="col-12 col-sm-4">
                            <label class="form-label small fw-bold">
                                Privilege Leave
                            </label>
                            <input type="number" class="form-control form-control-sm" value="15">
                            <small class="text-muted">
                                Days / Year
                            </small>
                        </div>
                        <div class="col-12 col-sm-4">
                            <label class="form-label small fw-bold">
                                Sick Leave
                            </label>
                            <input type="number" class="form-control form-control-sm" value="10">
                            <small class="text-muted">
                                Days / Year
                            </small>
                        </div>
                    </div>
                </div>


                <div class="modal-footer">

                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button" class="btn btn-primary btn-sm">

                        Save Settings

                    </button>

                </div>

            </div>

        </div>

    </div>

    <!-- Batchsection -->
   <div class="modal fade" id="batchCreditModal" tabindex="-1" aria-labelledby="batchCreditModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-3 overflow-hidden border-0 shadow">

      <form id="batchCreditForm" class="batch-credit-form">

        <!-- Modal Header -->
        <div class="batch-credit-header p-3 p-md-4 d-flex justify-content-between align-items-center">
          <div class="d-flex align-items-center gap-3">
            <div class="header-icon-wrapper p-2 rounded-3">
              <i class="mdi mdi-plus text-white fs-5"></i>
            </div>
            <div>
              <h3 class="header-title m-0 text-white fw-bold fs-6" id="batchCreditModalLabel">Batch Credit Annual Leaves</h3>
              <p class="header-subtitle m-0 text-white-50" style="font-size: 0.75rem;">Bulk credit bonus or carry-over leave days</p>
            </div>
          </div>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <!-- Modal Body -->
        <div class="batch-credit-body p-3 p-md-4">

          <!-- Target Staff Group -->
          <div class="mb-3">
            <label for="batchCreditStaffType" class="form-label-custom text-uppercase fw-bold text-muted mb-1">
              Target Staff Group
            </label>
            <select id="batchCreditStaffType" name="batchCreditStaffType" class="form-select custom-input">
              <option value="Permanent">Permanent Personnel Only</option>
              <option value="Contract">Contract Workers Only</option>
              <option value="ALL">All Staff</option>
            </select>
          </div>

          <!-- Leave Category & Days Grid -->
          <div class="row g-3 mb-4">
            <div class="col-12 col-md-6">
              <label for="batchCreditType" class="form-label-custom text-uppercase fw-bold text-muted mb-1">
                Leave Category
              </label>
              <select id="batchCreditType" name="batchCreditType" class="form-select custom-input">
                <option value="Casual">Casual Leave (CL)</option>
                <option value="Privilege">Privilege Leave (PL)</option>
                <option value="Sick">Sick Leave (SL)</option>
              </select>
            </div>

            <div class="col-12 col-md-6">
              <label for="batchCreditDays" class="form-label-custom text-uppercase fw-bold text-muted mb-1">
                Days to Credit
              </label>
              <input
                type="number"
                id="batchCreditDays"
                name="batchCreditDays"
                min="1"
                value="1"
                class="form-control custom-input font-monospace fw-bold"
                required
              />
            </div>
          </div>

          <!-- Actions Footer -->
          <div class="form-footer pt-3 d-flex justify-content-end gap-2 border-top">
            <button type="button" class="btn btn-outline-secondary px-4 fw-bold" data-bs-dismiss="modal">
              Cancel
            </button>
            <button type="submit" class="btn-submit btn text-white px-4 fw-bold d-inline-flex align-items-center gap-2">
              <i class="bi bi-check-circle-fill"></i>
              <span>Apply Batch Credit</span>
            </button>
          </div>

        </div>
      </form>

    </div>
  </div>
</div>
    <style>
    /* PAGE */

    .leave-page {
        color: #475569;
    }

    .leave-header-card,
    .leave-navigation-card {
        border-radius: 10px !important;
    }

    .leave-page-title {
        color: #0C3C62;
        font-size: 18px;
    }


    /* ============================================================
           POLICY CARDS
        ============================================================ */

    .leave-policy-row {
        margin-left: -5px;
        margin-right: -5px;
        margin-bottom: 12px;
    }

    .leave-policy-col {
        padding-left: 5px;
        padding-right: 5px;
        margin-bottom: 10px;
    }

    .leave-policy-card {
        min-height: 130px;
        background: #fff;
        border: 1px solid #edf0f3;
        border-radius: 10px;
        padding: 14px;
        box-shadow: 0 2px 6px rgba(15, 23, 42, .04);
    }

    .leave-policy-title {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 10px;
    }

    .leave-policy-title h4 {
        margin: 0;
        color: #475569;
        font-size: 13px;
        font-weight: 700;
    }

    .leave-type-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 30px;
        height: 20px;
        padding: 0 7px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 700;
    }

    .leave-type-cl {
        color: #16659e;
        background: #eff6ff;
        border: 1px solid #dbeafe;
    }

    .leave-type-pl {
        color: #059669;
        background: #ecfdf5;
        border: 1px solid #d1fae5;
    }

    .leave-type-sl {
        color: #d97706;
        background: #fff7ed;
        border: 1px solid #fed7aa;
    }

    .leave-policy-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 7px 0;
        border-bottom: 1px solid #f1f3f5;
        font-size: 11px;
    }

    .leave-policy-item span {
        color: #94a3b8;
        font-weight: 500;
    }

    .leave-policy-item strong {
        font-size: 11px;
        color: #475569;
    }

    .leave-blue {
        color: #16659e !important;
    }

    .leave-green {
        color: #059669 !important;
    }

    .leave-amber {
        color: #d97706 !important;
    }


    /* ============================================================
           LEDGER
        ============================================================ */

    .leave-ledger-card {
        width: 100%;
        background: #fff;
        border: 1px solid #e9edf1;
        border-radius: 10px;
        box-shadow: 0 2px 7px rgba(15, 23, 42, .04);
        overflow: hidden;
    }


    /* ============================================================
           LEDGER HEADER
        ============================================================ */

    .leave-ledger-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        padding: 14px 16px;
        border-bottom: 1px solid #e9edf1;
    }

    .leave-ledger-heading {
        flex: 1;
        min-width: 250px;
    }

    .leave-ledger-heading h3 {
        display: flex;
        align-items: center;
        gap: 7px;
        margin: 0;
        color: #475569;
        font-size: 15px;
        font-weight: 700;
    }

    .leave-ledger-heading h3 i {
        color: #16659e;
        font-size: 16px;
    }


    /* ============================================================
           CONTROLS
        ============================================================ */

    .leave-ledger-controls {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 6px;
    }

    .leave-search-box {
        position: relative;
        width: 210px;
    }

    .leave-search-box i {
        position: absolute;
        left: 9px;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 14px;
    }

    .leave-search-box input {
        width: 100%;
        height: 32px;
        padding: 5px 9px 5px 28px;
        border: 1px solid #e2e8f0;
        border-radius: 5px;
        background: #f8fafc;
        color: #475569;
        font-size: 11px;
        outline: none;
    }

    .leave-search-box input:focus {
        border-color: #16659e;
        background: #fff;
    }

    .leave-action-btn {
        height: 32px;
        padding: 5px 10px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        border-radius: 5px;
        font-size: 10px;
        font-weight: 600;
        white-space: nowrap;
        cursor: pointer;
    }

    .leave-credit-btn {
        background: #eff6ff;
        color: #16659e;
        border: 1px solid #dbeafe;
    }

    .leave-export-btn {
        background: #16659e;
        color: #fff;
        border: 1px solid #16659e;
    }


    /* ============================================================
           TABLE WRAPPER
        ============================================================ */

    .leave-table-wrapper {
        width: 100%;
        overflow-x: auto;
        overflow-y: hidden;
        -webkit-overflow-scrolling: touch;
    }


    /* ============================================================
           TABLE
        ============================================================ */

    .leave-balance-table {
        width: 100%;
        min-width: 1000px;
        table-layout: fixed;
        border-collapse: collapse;
        margin: 0;
    }


    /* Fixed column widths */

    .leave-balance-table .employee {
        width: 27%;
    }

    .leave-balance-table .leave {
        width: 13%;
    }

    .leave-balance-table .total {
        width: 13%;
    }

    .leave-balance-table .health {
        width: 12%;
    }

    .leave-balance-table .action {
        width: 9%;
    }


    /* ============================================================
           TABLE HEADER
        ============================================================ */

    .leave-balance-table thead th {
        height: 58px;
        padding: 9px 10px;
        background: #f8fafc;
        border-bottom: 1px solid #e2e8f0;
        color: #475569;
        font-size: 11px;
        font-weight: 700;
        line-height: 1.3;
        text-align: center;
        vertical-align: middle;
        white-space: nowrap;
    }

    .leave-balance-table thead th.employee-column {
        text-align: left;
        font-size: 12px;
    }

    .leave-balance-table thead th small {
        display: block;
        margin-top: 3px;
        color: #94a3b8;
        font-size: 8px;
        font-weight: 400;
        white-space: normal;
    }


    /* ============================================================
           TABLE BODY
        ============================================================ */

    .leave-balance-table tbody tr {
        height: 68px;
    }

    .leave-balance-table tbody tr:hover {
        background: #fafcff;
    }

    .leave-balance-table tbody td {
        padding: 9px 10px;
        border-bottom: 1px solid #edf0f3;
        color: #475569;
        font-size: 13px;

        vertical-align: middle;
    }

    .leave-balance-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .leave-balance-table tbody td.employee-column {
        text-align: left;
    }


    /* ============================================================
           EMPLOYEE
        ============================================================ */

    .employee-profile {
        display: flex;
        align-items: center;
        gap: 9px;
        width: 100%;
        min-width: 0;
    }

    .employee-avatar {
        width: 34px;
        height: 34px;
        min-width: 34px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: #eaf3fa;
        color: #16659e;
        font-size: 11px;
        font-weight: 800;
    }

    .employee-info {
        min-width: 0;
        overflow: hidden;


    }

    .employee-name {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 5px;
        color: #334155;
        font-size: 14px;
        font-weight: 700;
        line-height: 1.35;
    }

    .employee-meta {
        margin-top: 3px;
        color: #94a3b8;
        font-size: 9px;
        white-space: nowrap;
    }

    .employee-meta span {
        margin: 0 3px;
        color: #cbd5e1;
    }


    /* ============================================================
           LEAVE VALUES
        ============================================================ */

    .leave-values {
        display: inline-flex;
        gap: 4px;
        white-space: nowrap;
        font-family: monospace;
        font-size: 13px;
    }

    .leave-entitled {
        color: #64748b;
    }

    .leave-availed {
        color: #d97706;
        font-weight: 700;
    }

    .leave-separator {
        color: #cbd5e1;
    }


    /* ============================================================
           BALANCE BADGES
        ============================================================ */

    .leave-balance {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 28px;
        padding: 3px 6px;
        border-radius: 4px;
        font-size: 10px;
        font-weight: 700;
        line-height: 1;
    }

    .leave-balance-blue {
        color: #16659e;
        background: #eff6ff;
        border: 1px solid #dbeafe;
    }

    .leave-balance-green {
        color: #047857;
        background: #ecfdf5;
        border: 1px solid #d1fae5;
    }

    .leave-balance-amber {
        color: #b45309;
        background: #fffbeb;
        border: 1px solid #fde68a;
    }


    /* ============================================================
           TOTAL ALLOCATION
        ============================================================ */

    .total-allocation {
        display: flex;
        flex-direction: column;

        gap: 2px;
        white-space: nowrap;
    }

    .total-allocation strong {
        color: #334155;
        font-size: 14px;
        font-family: monospace;
    }

    .total-allocation strong span {
        color: #94a3b8;
        font-size: 9px;
        font-weight: 400;
    }

    .total-allocation small {
        color: #94a3b8;
        font-size: 8px;
    }


    /* BALANCE HEALTH*/

    .balance-health {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 4px 7px;
        border-radius: 10px;
        font-size: 12px;
        font-weight: 700;
        white-space: nowrap;
    }

    /* ACTION   */
    .adjust-quota-btn {
        height: 30px;
        min-width: 30px;
        padding: 5px 4px;
        display: inline-flex;

        gap: 4px;
        background: #f8fafc;
        color: #64748b;
        border: 1px solid #e2e8f0;
        border-radius: 5px;
        font-size: 9px;
        font-weight: 600;
        white-space: nowrap;
        cursor: pointer;
    }

    .adjust-quota-btn:hover {
        background: #16659e;
        color: #fff;
        border-color: #16659e;
    }


    /* ============================================================
           TABLET
        ============================================================ */

    @media (max-width: 1199.98px) {

        .leave-ledger-header {
            align-items: flex-start;
            flex-direction: column;
        }

        .leave-ledger-heading {
            width: 100%;
        }

        .leave-ledger-controls {
            width: 100%;
            justify-content: flex-start;
        }

        .leave-search-box {
            flex: 1;
            min-width: 200px;
        }

    }


    /* ============================================================
           MOBILE
        ============================================================ */

    @media (max-width: 767.98px) {

        .leave-page-title {
            font-size: 16px;
        }

        .leave-policy-card {
            min-height: auto;
        }

        .leave-ledger-header {
            padding: 12px;
        }

        .leave-ledger-heading h3 {
            font-size: 13px;
        }

        .leave-ledger-controls {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 6px;
        }

        .leave-search-box {
            width: 100%;
            grid-column: 1 / -1;
        }

        .leave-action-btn {
            width: 100%;
        }

        .leave-balance-table {
            min-width: 1050px;
        }

    }


    /* SMALL MOBILE*/

    @media (max-width: 480px) {

        .leave-ledger-controls {
            grid-template-columns: 1fr;
        }

        .leave-search-box {
            grid-column: auto;
        }

        .leave-policy-item {
            font-size: 10px;
        }

        .leave-policy-item strong {
            font-size: 10px;
        }

    }

    /* Header styling with gradient */
    .adjust-balance-header {
        background: linear-gradient(to right, #0C3C62, #16659E, #1e78b8);
    }

    .header-icon-wrapper {
        background-color: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(4px);
    }

    .header-subtitle {
        font-size: 0.75rem;
    }

    .btn-close-modal {
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 0.5rem;
        transition: background-color 0.2s ease;
    }

    .btn-close-modal:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }

    /* Label & Input styling */
    .form-label-custom {
        font-size: 0.65rem;
        letter-spacing: 0.05em;
    }

    .custom-input {
        background-color: #f8fafc;
        border-color: #e2e8f0;
        border-radius: 0.75rem;
        font-size: 0.85rem;
    }

    .custom-input:focus {
        background-color: #ffffff;
        border-color: #16659E;
        box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.25);
    }

    /* Button styling */
    .btn-cancel {
        border-radius: 0.75rem;
        font-size: 0.8rem;
    }

    .btn-submit {
        background-color: #16659E;
        border-color: #16659E;
        border-radius: 0.75rem;
        font-size: 0.8rem;
        transition: background-color 0.2s ease;
    }

    .btn-submit:hover {
        background-color: #0C3C62;
        border-color: #0C3C62;
    }

    /* Header styling with gradient */
    .batch-credit-header {
        background: linear-gradient(to right, #0C3C62, #16659E, #1e78b8);
    }

    .header-icon-wrapper {
        background-color: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(4px);
    }

    .header-subtitle {
        font-size: 0.75rem;
    }

    .btn-close-modal {
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 0.5rem;
        transition: background-color 0.2s ease;
    }

    .btn-close-modal:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }

    /* Label & Input styling */
    .form-label-custom {
        font-size: 0.65rem;
        letter-spacing: 0.05em;
    }

    .custom-input {
        background-color: #f8fafc;
        border-color: #e2e8f0;
        border-radius: 0.75rem;
        font-size: 0.85rem;
    }

    .custom-input:focus {
        background-color: #ffffff;
        border-color: #16659E;
        box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.25);
    }

    /* Button styling */
    .btn-cancel {
        border-radius: 0.75rem;
        font-size: 0.8rem;
    }

    .btn-submit {
        background-color: #16659E;
        border-color: #16659E;
        border-radius: 0.75rem;
        font-size: 0.8rem;
        transition: background-color 0.2s ease;
    }

    .btn-submit:hover {
        background-color: #0C3C62;
        border-color: #0C3C62;
    }
    </style>

</div>
<script>
// table search functionality
document.addEventListener('DOMContentLoaded', () => {
    // Select the search input field and table rows
    const searchInput = document.querySelector('.leave-search-box input');
    const tableRows = document.querySelectorAll('.leave-table-wrapper tbody tr');

    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase().trim();

        tableRows.forEach(row => {
            // Check content of the employee details column (Name, ID, Role, Type)
            const employeeCell = row.querySelector('.employee-column');

            if (employeeCell) {
                const text = employeeCell.textContent.toLowerCase();

                // Show or hide row depending on whether input query matches
                if (text.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    });
});
// Script for adjust quota
document.addEventListener('DOMContentLoaded', () => {
    // Initialize Bootstrap Modal instance
    const modalElement = document.getElementById('adjustBalanceModal');
    const adjustModal = new bootstrap.Modal(modalElement);

    // Attach click listener using event delegation for table buttons
    document.addEventListener('click', (event) => {
        const button = event.target.closest('.adjust-quota-btn');

        if (button) {
            // Optional: Get employee ID from button data attribute
            const employeeId = button.getAttribute('data-employee-id');

            if (employeeId) {
                document.getElementById('adjustBalanceEmpSelect').value = employeeId;
            }

            // Show modal
            adjustModal.show();
        }
    });
});
// For batch section
document.addEventListener('DOMContentLoaded', () => {
  const modalElement = document.getElementById('batchCreditModal');
  const batchModal = new bootstrap.Modal(modalElement);

  // Attach click listener to button
  document.addEventListener('click', (event) => {
    const button = event.target.closest('.leave-credit-btn');
    if (button) {
      batchModal.show();
    }
  });
});
</script>
@endsection
