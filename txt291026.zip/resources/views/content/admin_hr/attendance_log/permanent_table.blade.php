@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('content')

@php
/*
|--------------------------------------------------------------------------
| MONTH / YEAR
|--------------------------------------------------------------------------
| You can replace these with values coming from your controller:
|
| $selectedMonth = request('month', now()->month);
| $selectedYear = request('year', now()->year);
|
*/
$selectedMonth = request('month', now()->month);
$selectedYear = request('year', now()->year);

$monthStart = \Carbon\Carbon::create($selectedYear, $selectedMonth, 1);
$daysInMonth = $monthStart->daysInMonth;
$monthName = $monthStart->format('F');
$year = $monthStart->format('Y');

@endphp


<div class="container-fluid px-0">

    {{-- ============================================================
        SUMMARY CARDS
    ============================================================= --}}

    <div class="row g-3 mb-4">

        {{-- Permanent Pool --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary summary-label summary-card-label">
                        Permanent Pool
                    </span>

                    <span id="totalStaff" class="d-block fw-bold font-monospace summary-value summary-card-value" style="color:#0C3C62;">
                        Loading…
                    </span>
                </div>
            </div>
        </div>

        {{-- Present --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-success summary-label summary-card-label">
                        Checked In (Present)
                    </span>

                    <span id="presentCount" class="d-block fw-bold font-monospace summary-value summary-card-value text-success">
                        Loading…
                    </span>
                </div>
            </div>
        </div>

        {{-- Absent --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-danger summary-label summary-card-label">
                        Unexcused Absences
                    </span>

                    <span id="absentCount" class="d-block fw-bold font-monospace summary-value summary-card-value text-danger">
                        Loading…
                    </span>
                </div>
            </div>
        </div>

        {{-- Leave --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-warning summary-label summary-card-label">
                        Sabbatical & Leaves
                    </span>

                    <span id="leaveCount" class="d-block fw-bold font-monospace summary-value summary-card-value text-warning">
                        Loading…
                    </span>
                </div>
            </div>
        </div>

    </div>


    {{-- ============================================================
        STAFF HEADER + VIEW SWITCH
    ============================================================= --}}

    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="d-flex flex-column flex-md-row
                    justify-content-between
                    align-items-start
                    align-items-md-center
                    gap-3">

                {{-- TITLE --}}
                <div class="w-100 w-md-auto">
                    <div class="px-3 py-2 bg-white">

                        <span class="fw-bold" style="font-size:20px;color:#0C3C62;">
                            Permanent Staff
                        </span>

                    </div>
                </div>


                {{-- VIEW SWITCH --}}
                <div class="d-flex justify-content-start justify-content-md-end w-100 w-md-auto">

                    <div class="btn-group responsive-view-buttons" role="group">

                        {{-- LIST --}}
                        <a href="{{ url('/admin-hr/permanent-log') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log') ? 'active' : '' }}">

                            <span class="mdi mdi-format-list-bulleted me-1"></span>
                            List View

                        </a>


                        {{-- TABLE --}}
                        <a href="{{ url('/admin-hr/permanent-log/table') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log/table') ? 'active' : '' }}">

                            <span class="mdi mdi-table me-1"></span>
                            Table View

                        </a>


                        {{-- CALENDAR --}}
                        <a href="{{ url('admin-hr/permanent-log/calender') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log/calender') ? 'active' : '' }}">

                            <span class="mdi mdi-calendar-month me-1"></span>
                            Calendar View

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>



    {{--  MONTH / FILTER HEADER --}}

    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="d-flex flex-column flex-lg-row
                        justify-content-between
                        align-items-lg-center
                        gap-3">

                {{-- MONTH INFORMATION --}}
                <div>

                    <h5 class="mb-1 fw-bold" style="color:#0C3C62;">

                        Monthly Attendance Matrix —
                        {{ $monthName }} {{ $year }}

                    </h5>

                    <p class="mb-0 text-muted" style="font-size:10px;">

                        Interactive attendance ledger.
                        Click any working-day cell to change
                        Present / Absent / Leave status.

                    </p>

                </div>


                {{-- MONTH SELECTOR --}}
                <div class="d-flex align-items-center gap-2">

                    <label class="mb-0 fw-bold text-secondary" style="font-size:10px;">
                        Month
                    </label>

                    <select id="monthSelector" name="month" class="form-select form-select-sm" style="width: 140px;">

                        @for($m = 1; $m <= 12; $m++) <option value="{{ $m }}"
                            {{ $selectedMonth == $m ? 'selected' : '' }}>
                            {{ \Carbon\Carbon::create()->month($m)->format('F') }}
                            </option>
                            @endfor

                    </select>


                    <select id="yearSelector" class="form-select form-select-sm" style="width:90px;">

                        @for($y = now()->year - 2; $y <= now()->year + 2; $y++)

                            <option value="{{ $y }}" {{ $selectedYear == $y ? 'selected' : '' }}>

                                {{ $y }}

                            </option>

                            @endfor

                    </select>

                    <button type="button" id="changeMonthBtn" class="btn btn-sm btn-primary">

                        <i class="mdi mdi-calendar-search me-1"></i>
                        View

                    </button>

                </div>

            </div>

        </div>

    </div>



    {{-- ============================================================
        DEPARTMENT FILTER
    ============================================================= --}}

    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="attendance-filter-row">

                {{-- SEARCH --}}
                <div class="attendance-search">

                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0
                                     translate-middle-y ps-2 text-muted" style="pointer-events:none;">

                            <i class="mdi mdi-magnify"></i>

                        </span>

                        <input id="employeeSearch" type="text" class="form-control form-control-sm
                                      ps-5 bg-light border-0 rounded-3" placeholder="Search personnel...">

                    </div>

                </div>


                {{-- DEPARTMENTS --}}
                <div class="attendance-departments">

                    <div class="department-scroll">
                        {{-- Department buttons are loaded from /admin-hr/api/staff/options, matching List View. --}}
                    </div>

                </div>

            </div>

        </div>

    </div>



    {{-- ============================================================
        ATTENDANCE MATRIX
    ============================================================= --}}

    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-0">

            <div class="attendance-table-wrapper">

                <table class="attendance-matrix" id="attendance-table">

                    <thead>

                        <tr>

                            {{-- EMPLOYEE --}}
                            <th class="employee-column">

                                Personnel Information

                            </th>


                            {{-- DAYS ARE GENERATED FROM PHP --}}
                            @for($day = 1; $day <= $daysInMonth; $day++) @php $date=\Carbon\Carbon::create(
                                $selectedYear, $selectedMonth, $day ); $isSunday=$date->isSunday();
                                @endphp

                                <th class="day-column
                                    {{ $isSunday ? 'sunday-column' : '' }}">

                                    <div class="day-number">
                                        {{ $day }}
                                    </div>

                                    <div class="day-name">
                                        {{ $date->format('D') }}
                                    </div>

                                </th>

                                @endfor

                        </tr>

                    </thead>


                    <tbody id="attendanceBody">
                        <tr>
                            <td colspan="{{ $daysInMonth + 1 }}" class="text-center text-muted py-4">
                                Loading attendance records…
                            </td>
                        </tr>
                    </tbody>

                </table>

            </div>

        </div>


        {{-- ============================================================
            LEGEND
        ============================================================= --}}

        <div class="card-footer bg-light border-0">

            <div class="d-flex flex-wrap align-items-center gap-4">

                <div class="legend-item">

                    <span class="attendance-badge present">
                        P
                    </span>

                    <span>Present</span>

                </div>


                <div class="legend-item">

                    <span class="attendance-badge absent">
                        A
                    </span>

                    <span>Absent</span>

                </div>


                <div class="legend-item">

                    <span class="attendance-badge leave">
                        L
                    </span>

                    <span>On Leave</span>

                </div>


                <div class="legend-item">

                    <span class="attendance-badge rest">
                        R
                    </span>

                    <span>Rest / Sunday</span>

                </div>

                <div class="legend-item">

                    <span class="attendance-badge holiday">
                        H
                    </span>

                    <span>Holiday</span>

                </div>


                <span class="text-muted small">
                    Click any non-rest cell to modify attendance.
                </span>

            </div>

        </div>

    </div>

</div>



{{-- ================================================================
    ATTENDANCE MODAL
================================================================ --}}

<div class="modal fade" id="attendanceModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content border-0 shadow-lg rounded-4">

            <div class="modal-header" style="background:#16659E;color:white;">

                <div>

                    <h6 class="mb-1 fw-bold">
                        Update Daily Attendance
                    </h6>

                    <small id="modalDate">
                        -
                    </small>

                </div>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal">
                </button>

            </div>


            <div class="modal-body p-4">

                {{-- EMPLOYEE --}}
                <div class="bg-light rounded-3 p-3 mb-4">

                    <div class="d-flex align-items-center gap-3">

                        <div class="employee-avatar">
                            <i class="mdi mdi-account"></i>
                        </div>

                        <div>

                            <div id="modalEmployee" class="fw-bold text-dark">
                                -
                            </div>

                            <small id="modalEmployeeCode" class="text-muted">
                                -
                            </small>

                        </div>

                    </div>

                </div>


                {{-- STATUS --}}
                <label class="form-label fw-bold small">
                    Attendance Status
                </label>

                <div class="row g-2 mb-4">

                    <div class="col-4">

                        <button type="button" class="status-select-btn present-option" data-status="Present">

                            <span class="attendance-badge present">
                                P
                            </span>

                            <span>Present</span>

                        </button>

                    </div>


                    <div class="col-4">

                        <button type="button" class="status-select-btn absent-option" data-status="Absent">

                            <span class="attendance-badge absent">
                                A
                            </span>

                            <span>Absent</span>

                        </button>

                    </div>


                    <div class="col-4">

                        <button type="button" class="status-select-btn leave-option" data-status="On Leave">

                            <span class="attendance-badge leave">
                                L
                            </span>

                            <span>Leave</span>

                        </button>

                    </div>

                    {{-- LEAVE TYPE --}}
                    <div id="leaveTypeSection" class="mb-4" style="display:none;">

                        <label class="form-label fw-bold small">
                            Leave Type
                        </label>

                        <div class="row g-2">

                            {{-- CASUAL LEAVE --}}
                            <div class="col-12 col-md-4">

                                <button type="button" class="leave-type-btn" data-leave-type="Casual Leave">

                                    <i class="mdi mdi-calendar-outline"></i>

                                    <span>Casual Leave</span>

                                </button>

                            </div>


                            {{-- PAID LEAVE --}}
                            <div class="col-12 col-md-4">

                                <button type="button" class="leave-type-btn" data-leave-type="Paid Leave">

                                    <i class="mdi mdi-cash-check"></i>

                                    <span>Paid Leave</span>

                                </button>

                            </div>


                            {{-- SICK LEAVE --}}
                            <div class="col-12 col-md-4">

                                <button type="button" class="leave-type-btn" data-leave-type="Sick Leave">

                                    <i class="mdi mdi-medical-bag"></i>

                                    <span>Sick Leave</span>

                                </button>

                            </div>

                        </div>

                    </div>
                </div>


                {{-- TIME --}}
                <div id="timeSection" class="row g-3 bg-light rounded-3 p-3">

                    <div class="col-6">

                        <label class="form-label small fw-bold">
                            In Time
                        </label>

                        <input type="time" id="inTime" class="form-control form-control-sm" value="09:00">

                    </div>


                    <div class="col-6">

                        <label class="form-label small fw-bold">
                            Out Time
                        </label>

                        <input type="time" id="outTime" class="form-control form-control-sm" value="18:00">

                    </div>

                </div>

            </div>


            <div class="modal-footer bg-light border-0">

                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button" id="saveAttendance" class="btn btn-sm text-white" style="background:#16659E;">

                    Apply & Close

                </button>

            </div>

        </div>

    </div>

</div>



{{-- ================================================================
    CSS
================================================================ --}}

<style>
.summary-card .card-body {
    min-height: 75px;
}

.summary-label,
.summary-card-label {
    font-size: 9px;
    letter-spacing: .5px;
    line-height: 1.4;
}

.summary-value,
.summary-card-value {
    font-size: 1.25rem;
    line-height: 1.3;
    margin-top: 4px;
}


/* FILTER */

.attendance-filter-row {
    display: flex;
    align-items: center;
    gap: 10px;
}

.attendance-search {
    width: 200px;
    flex-shrink: 0;
}

.attendance-departments {
    flex: 1;
    min-width: 0;
}

.department-scroll {
    display: flex;
    gap: 5px;
    overflow-x: auto;
    scrollbar-width: none;
}

.department-scroll::-webkit-scrollbar {
    display: none;
}

.dept-filter-btn {
    flex: 0 0 auto;
    background: #f8fafc;
    color: #475569;
    border: 1px solid transparent;
    font-size: 10px;
    padding: 7px 12px;
}

.dept-filter-btn:hover {
    background: #e2e8f0;
}

.dept-filter-btn.active {
    background: #16659E !important;
    color: white !important;
    border-color: #16659E;
}



/* ================================================================
   ATTENDANCE TABLE
================================================================ */

.attendance-table-wrapper {
    width: 100%;
    overflow-x: auto;
    overflow-y: auto;
    max-height: 650px;
}

.attendance-matrix {
    width: max-content;
    min-width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 11px;
}

.attendance-matrix th,
.attendance-matrix td {
    border-right: 1px solid #e2e8f0;
    border-bottom: 1px solid #e2e8f0;
}


/* HEADER */

.attendance-matrix thead th {
    background: #f8fafc;
    height: 55px;
    text-align: center;
    vertical-align: middle;
    position: sticky;
    top: 0;
    z-index: 20;
}

.employee-column {
    width: 230px;
    min-width: 230px;
    max-width: 230px;
}

.attendance-matrix thead .employee-column {
    text-align: left;
    padding-left: 18px;
    z-index: 40;
    left: 0;
}


.day-column {
    width: 58px;
    min-width: 58px;
    max-width: 58px;
}

.day-number {
    font-weight: 800;
    font-size: 11px;
    color: #334155;
}

.day-name {
    font-size: 8px;
    color: #94a3b8;
    font-weight: 700;
    text-transform: uppercase;
    margin-top: 2px;
}


/* SUNDAY */

.sunday-column {
    background: #fff1f2 !important;
    color: #e11d48;
}


/* EMPLOYEE CELL */

.employee-cell {
    position: sticky;
    left: 0;
    z-index: 10;
    background: white;
    padding: 12px 18px;
}

.employee-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.employee-avatar {
    width: 36px;
    height: 36px;
    min-width: 36px;
    border-radius: 50%;
    background: #f1f5f9;
    color: #475569;
    display: flex;
    align-items: center;
    justify-content: center;
}

.employee-name {
    font-weight: 800;
    color: #0f172a;
    font-size: 11px;
}

.employee-code {
    color: #94a3b8;
    font-size: 8px;
    margin-top: 2px;
}


/* ATTENDANCE CELL */

.attendance-cell {
    width: 58px;
    min-width: 58px;
    height: 70px;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    background: white;
    transition: all .15s ease;
}

.attendance-cell:hover {
    background: #f8fafc;
}

.attendance-cell.rest-cell {
    cursor: default;
    background: #f8fafc;
}


/* BADGES */

.attendance-badge {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 9px;
    font-weight: 900;
}

.attendance-badge.present {
    background: #10b981;
    color: white;
}

.attendance-badge.absent {
    background: #ef4444;
    color: white;
}

.attendance-badge.leave {
    background: #fbbf24;
    color: #422006;
}

.attendance-badge.holiday {
    background: #8b5cf6;
    color: white;
}

.attendance-cell.holiday-cell {
    background: #f5f3ff;
    cursor: default;
}

.attendance-cell.holiday-cell:hover {
    background: #ede9fe;
}

.attendance-badge.rest {
    background: #e2e8f0;
    color: #64748b;
}


.attendance-time {
    font-size: 7px;
    line-height: 1.3;
    color: #64748b;
    margin-top: 3px;
    font-family: monospace;
}

.attendance-dash {
    font-size: 7px;
    color: #cbd5e1;
    margin-top: 3px;
    font-family: monospace;
}


/* LEGEND */

.legend-item {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 10px;
    font-weight: 600;
    color: #64748b;
}


/* MODAL STATUS BUTTON */

.status-select-btn {
    width: 100%;
    border: 1px solid #e2e8f0;
    background: white;
    border-radius: 10px;
    padding: 10px 5px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 5px;
    font-size: 10px;
    font-weight: 700;
    color: #64748b;
    transition: .2s;
}

.status-select-btn:hover {
    background: #f8fafc;
}

.status-select-btn.active {
    box-shadow: 0 0 0 2px #16659E;
}

.leave-type-btn {
    width: 100%;
    min-height: 75px;
    border: 1px solid #e2e8f0;
    background: white;
    border-radius: 10px;
    padding: 10px 5px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    font-size: 10px;
    font-weight: 700;
    color: #64748b;
    transition: all .2s ease;
}

.leave-type-btn i {
    font-size: 18px;
    color: #f59e0b;
}

.leave-type-btn:hover {
    background: #fffbeb;
    border-color: #fbbf24;
}

.leave-type-btn.active {
    background: #fffbeb;
    border-color: #f59e0b;
    color: #92400e;
    box-shadow: 0 0 0 2px rgba(245, 158, 11, .15);
}

/* MOBILE */

@media(max-width:767px) {

    .attendance-filter-row {
        flex-direction: column;
        align-items: stretch;
    }

    .attendance-search {
        width: 100%;
    }

    .employee-column {
        width: 190px;
        min-width: 190px;
        max-width: 190px;
    }

    .day-column,
    .attendance-cell {
        width: 52px;
        min-width: 52px;
        max-width: 52px;
    }

}

/* ===============================
   RESPONSIVE VIEW SWITCH
================================ */

.responsive-view-buttons {
    white-space: nowrap;
}

/* Tablet */
@media (max-width: 991.98px) {

    .responsive-view-buttons .btn {
        padding-left: 10px !important;
        padding-right: 10px !important;
        font-size: 11px;
    }

}

/* Mobile */
@media (max-width: 575.98px) {

    .responsive-view-buttons {
        width: 100%;
        display: flex;
    }

    .responsive-view-buttons .btn {
        flex: 1 1 0;
        padding: 8px 5px !important;
        font-size: 10px;
        white-space: nowrap;
    }

    .responsive-view-buttons .mdi {
        margin-right: 2px !important;
    }

}

/* Very small mobile */
@media (max-width: 400px) {

    .responsive-view-buttons .btn {
        padding: 7px 3px !important;
        font-size: 9px;
    }

    .responsive-view-buttons .mdi {
        display: none;
    }

}
</style>



<script>
    const type = 'permanent';
    const api = '/admin-hr/api/attendance/' + type;
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
    const monthSelector = document.getElementById('monthSelector');
    const yearSelector = document.getElementById('yearSelector');
    const changeMonthBtn = document.getElementById('changeMonthBtn');
    const searchInput = document.getElementById('employeeSearch');
    const body = document.getElementById('attendanceBody');
    const modalElement = document.getElementById('attendanceModal');

    const state = {
        page: 1,
        perPage: 10,
        search: '',
        department_id: '',
        month: '',
        selected: null,
        cache: null,
        options: null
    };

    let selectedLeave = '';
    let searchTimer = null;

    function esc(value) {
        return String(value ?? '').replace(/[&<>"']/g, character => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        })[character]);
    }

    function attendanceLocalDate() {
        const date = new Date();
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    }

    function getModal() {
        if (!modalElement || !window.bootstrap?.Modal) return null;
        return window.bootstrap.Modal.getOrCreateInstance(modalElement);
    }

    async function request(url, options = {}) {
        const response = await fetch(url, {
            credentials: 'same-origin',
            ...options,
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                ...(options.body ? { 'Content-Type': 'application/json' } : {}),
                ...(csrf ? { 'X-CSRF-TOKEN': csrf } : {}),
                ...(options.headers || {})
            }
        });

        const payload = await response.json().catch(() => ({}));
        if (!response.ok || payload.success === false) {
            throw new Error(
                payload.message ||
                Object.values(payload.errors || {}).flat()[0] ||
                (response.status === 401 ? 'Please sign in again.' : `Request failed (${response.status}).`)
            );
        }

        return payload;
    }

    function statusMeta(code) {
        return ({
            P: ['P', 'present', 'Present'],
            A: ['A', 'absent', 'Absent'],
            L: ['L', 'leave', 'On Leave'],
            PR: ['PR', 'present', 'Present'],
            OD: ['OD', 'present', 'On Duty'],
            H: ['H', 'holiday', 'Holiday']
        })[String(code || '').toUpperCase()] || ['—', '', 'Not marked'];
    }

    function statusCode(label) {
        return ({
            Present: 'P',
            Absent: 'A',
            'On Leave': 'L',
            'On Duty': 'OD',
            Holiday: 'H'
        })[label] || label;
    }

    function showLoading() {
        const columns = Math.max(1, document.querySelectorAll('.attendance-matrix thead th').length);
        body.innerHTML = Array.from({ length: 5 }, () => `
            <tr class="skeleton-loader">
                ${Array.from({ length: columns }, () => `
                    <td class="skeleton-cell"><div class="skeleton-loader-view"></div></td>
                `).join('')}
            </tr>
        `).join('');
    }

    function buildRows(payload) {
        const staff = payload.data || [];
        const daysInMonth = Number(payload.days_in_month || 30);
        const attendance = payload.attendance || {};
        const holidays = payload.holidays || {};
        const month = String(payload.month || state.month);
        const [year, monthNumber] = month.split('-').map(Number);

        if (!staff.length) {
            body.innerHTML = `
                <tr>
                    <td colspan="${daysInMonth + 1}" class="text-center py-5 text-muted">
                        No attendance records found.
                    </td>
                </tr>
            `;
            return;
        }

        body.innerHTML = staff.map(person => {
            let cells = '';

            for (let day = 1; day <= daysInMonth; day++) {
                const date = `${year}-${String(monthNumber).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const sunday = new Date(year, monthNumber - 1, day).getDay() === 0;
                const item = (attendance[person.id] || {})[date];

                if (holidays[date] && !item) {
                    cells += `
                        <td class="attendance-cell holiday-cell" data-date="${date}"
                            data-staff-id="${Number(person.id)}" data-holiday="1"
                            role="button" tabindex="0" title="${esc(holidays[date])}">
                            <span class="attendance-badge holiday">H</span>
                            <div class="attendance-dash">Holiday</div>
                        </td>
                    `;
                    continue;
                }

                if (sunday && !item) {
                    cells += `
                        <td class="attendance-cell rest-cell" data-date="${date}"
                            data-staff-id="${Number(person.id)}" role="button" tabindex="0">
                            <span class="attendance-dash">Rest</span>
                        </td>
                    `;
                    continue;
                }

                const meta = statusMeta(item?.attendance);
                const times = item?.in_time || item?.out_time
                    ? `<div class="attendance-time">${esc(item.in_time ? String(item.in_time).slice(0, 5) : '—')}<br>${esc(item.out_time ? String(item.out_time).slice(0, 5) : '—')}</div>`
                    : `<div class="attendance-dash">${item ? '' : '—'}</div>`;

                cells += `
                    <td class="attendance-cell ${sunday ? 'rest-cell' : ''}"
                        data-date="${date}" data-staff-id="${Number(person.id)}"
                        data-status="${esc(meta[2])}" role="button" tabindex="0"
                        title="${esc(meta[2])} — click to edit">
                        <span class="attendance-badge ${esc(meta[1])}">${esc(meta[0])}</span>
                        ${times}
                    </td>
                `;
            }

            return `
                <tr data-staff-id="${Number(person.id)}"
                    data-department="${esc(person.department || '')}"
                    data-employee="${esc(person.name || '')}">
                    <td class="employee-column employee-cell" data-staff-id="${Number(person.id)}">
                        <div class="employee-info">
                            <div class="employee-avatar"><i class="mdi mdi-account"></i></div>
                            <div>
                                <div class="employee-name">${esc(person.name || '—')}</div>
                                <div class="employee-code">${esc(person.staff_id || '')} · ${esc(person.designation || person.department || '')}</div>
                            </div>
                        </div>
                    </td>
                    ${cells}
                </tr>
            `;
        }).join('');
    }

    async function loadOptions() {
        // Match List View: load departments from the common staff-options API only once.
        if (state.options !== null) return;

        const response = await request('/admin-hr/api/staff/options');
        state.options = response.data || {};
        window.hrStaffOptions = state.options;

        const departments = state.options.departments || [];
        const departmentHost = document.querySelector('.department-scroll');
        const selectedDepartmentId = String(state.department_id || '');

        if (departmentHost) {
            departmentHost.innerHTML = `
                <button type="button"
                    data-department="ALL"
                    class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn ${selectedDepartmentId === '' ? 'active' : ''}">
                    All Roles
                </button>
                ${departments.map(department => {
                    const departmentId = String(department.id);
                    const activeClass = departmentId === selectedDepartmentId ? 'active' : '';
                    return `<button type="button"
                        data-department="${esc(department.name)}"
                        data-department-id="${esc(departmentId)}"
                        class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn ${activeClass}">${esc(department.name)}</button>`;
                }).join('')}
            `;
        }
    }

    function attendanceRenderPager(meta) {
        const table = document.getElementById('attendance-table');
        if (!table) return;

        let host = document.getElementById('attendance-ajax-pagination');
        if (!host) {
            host = document.createElement('div');
            host.id = 'attendance-ajax-pagination';
            host.className = 'd-flex flex-wrap align-items-center justify-content-between gap-2 p-3';
            table.closest('.card')?.appendChild(host);
        }
        if (!host) return;

        const currentPage = Math.max(1, Number(meta.current_page || 1));
        const lastPage = Math.max(1, Number(meta.last_page || 1));
        const total = Number(meta.total || 0);
        const perPage = Number(meta.per_page || state.perPage);
        const start = total === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
        const end = Math.min(currentPage * perPage, total);
        const firstPage = Math.max(1, currentPage - 2);
        const finalPage = Math.min(lastPage, currentPage + 2);

        const pageButtons = Array.from(
            { length: finalPage - firstPage + 1 },
            (_, index) => {
                const page = firstPage + index;
                return `
                    <li class="page-item ${page === currentPage ? 'active' : ''}">
                        <button type="button" class="page-link"
                            data-attendance-page="${page}"
                            ${page === currentPage ? 'aria-current="page"' : ''}>${page}</button>
                    </li>
                `;
            }
        ).join('');

        host.innerHTML = `
            <div class="small text-muted">Showing ${start} to ${end} of ${total} results</div>
            <div class="d-flex flex-wrap align-items-center gap-2">
                <label for="attendancePageSize" class="small text-muted mb-0">Rows</label>
                <select id="attendancePageSize" class="form-select form-select-sm" style="width:82px">
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
                <nav aria-label="Attendance table pagination">
                    <ul class="pagination pagination-sm mb-0">
                        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                            <button type="button" class="page-link" data-attendance-page="1"
                                aria-label="First page" ${currentPage === 1 ? 'disabled' : ''}>«</button>
                        </li>
                        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                            <button type="button" class="page-link"
                                data-attendance-page="${Math.max(1, currentPage - 1)}"
                                aria-label="Previous page" ${currentPage === 1 ? 'disabled' : ''}>‹</button>
                        </li>
                        ${pageButtons}
                        <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}">
                            <button type="button" class="page-link"
                                data-attendance-page="${Math.min(lastPage, currentPage + 1)}"
                                aria-label="Next page" ${currentPage === lastPage ? 'disabled' : ''}>›</button>
                        </li>
                        <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}">
                            <button type="button" class="page-link" data-attendance-page="${lastPage}"
                                aria-label="Last page" ${currentPage === lastPage ? 'disabled' : ''}>»</button>
                        </li>
                    </ul>
                </nav>
            </div>
        `;

        const pageSizeSelect = host.querySelector('#attendancePageSize');
        if (pageSizeSelect) {
            pageSizeSelect.value = String(perPage);
            pageSizeSelect.addEventListener('change', event => {
                state.perPage = Number(event.currentTarget.value);
                state.page = 1;
                attendanceLoad();
            });
        }

        host.querySelectorAll('[data-attendance-page]').forEach(button => {
            button.addEventListener('click', () => {
                if (button.disabled) return;
                state.page = Number(button.dataset.attendancePage);
                attendanceLoad();
            });
        });
    }

    function attendanceUpdateSummary(summary) {
        const values = document.querySelectorAll('.summary-card-value');
        if (values[0]) values[0].textContent = `${Number(summary.staff_count || 0)} Staff`;
        if (values[1]) values[1].textContent = `${Number(summary.present_count || 0)} Present`;
        if (values[2]) values[2].textContent = `${Number(summary.absent_count || 0)} Absent`;
        if (values[3]) values[3].textContent = `${Number(summary.leave_count || 0)} On Leave`;
    }

    async function attendanceLoadTodaySummary() {
        const query = new URLSearchParams({
            date: attendanceLocalDate(),
            page: '1',
            per_page: '10',
            sort: 'staff',
            direction: 'asc'
        });

        const payload = await request(`${api}?${query.toString()}`);
        attendanceUpdateSummary(payload.summary || {});
    }

    async function attendanceLoad() {
        if (!body || !monthSelector || !yearSelector) return;

        try {
            await loadOptions();
        } catch (error) {
            console.error('HR department options could not be loaded:', error);
        }

        state.month = `${yearSelector.value}-${String(monthSelector.value).padStart(2, '0')}`;
        showLoading();

        const query = new URLSearchParams({
            month: state.month,
            search: state.search,
            page: String(state.page),
            per_page: String(state.perPage)
        });

        // Match List View: filter by the department primary key.
        if (state.department_id) query.set('department_id', String(state.department_id));

        try {
            const payload = await request(`${api}/matrix?${query.toString()}`);
            state.cache = payload;
            buildRows(payload);
            attendanceRenderPager(payload.meta || {});
        } catch (error) {
            const columns = document.querySelectorAll('.attendance-matrix thead th').length || 8;
            body.innerHTML = `
                <tr><td colspan="${columns}" class="text-center text-danger py-5">${esc(error.message)}</td></tr>
            `;
        }
    }

    function handleHrDocumentClick(event) {
        const departmentButton = event.target.closest('.dept-filter-btn');
        if (!departmentButton) return;

        document.querySelectorAll('.dept-filter-btn').forEach(button => {
            button.classList.toggle('active', button === departmentButton);
        });

        state.department_id = departmentButton.dataset.department === 'ALL'
            ? ''
            : String(departmentButton.dataset.departmentId || '');
        state.page = 1;
        attendanceLoad();
    }

    function dateForStaffRow() {
        const year = Number(yearSelector.value);
        const month = Number(monthSelector.value);
        const today = new Date();
        const day = year === today.getFullYear() && month === today.getMonth() + 1
            ? today.getDate()
            : 1;
        return `${year}-${String(month).padStart(2, '0')}-${String(Math.min(day, new Date(year, month, 0).getDate())).padStart(2, '0')}`;
    }

    function openCell(cell) {
        const person = Number(cell?.dataset?.staffId || cell?.closest('tr')?.dataset?.staffId);
        const date = cell?.dataset?.date || dateForStaffRow();
        const modal = getModal();
        if (!person || !date || !modal || !modalElement) return;

        const current = ((state.cache?.attendance || {})[person] || {})[date] || {};
        state.selected = { staff_id: person, date };

        const row = cell?.closest('tr') || body.querySelector(`tr[data-staff-id="${person}"]`);
        const staff = (state.cache?.data || []).find(item => Number(item.id) === person) || {};
        const name = row?.querySelector('.employee-name')?.textContent || staff.name || 'Staff';
        const codeNode = document.getElementById('modalEmployeeCode');
        const employeeNode = document.getElementById('modalEmployee');
        const dateNode = document.getElementById('modalDate');

        if (employeeNode) employeeNode.textContent = name;
        if (codeNode) codeNode.textContent = `${staff.staff_id || ''} • ${staff.designation || staff.department || ''}`;
        if (dateNode) {
            dateNode.textContent = new Date(`${date}T00:00:00`).toLocaleDateString(undefined, {
                month: 'long', day: 'numeric', year: 'numeric'
            });
        }

        const code = String(current.attendance || '').toUpperCase();
        const label = ({ P: 'Present', A: 'Absent', L: 'On Leave', PR: 'Present', OD: 'On Duty', H: 'Holiday' })[code] || '';
        modalElement.querySelectorAll('.status-select-btn').forEach(button => {
            button.classList.toggle('active', button.dataset.status === label);
        });

        const inInput = document.getElementById('inTime');
        const outInput = document.getElementById('outTime');
        if (inInput) inInput.value = current.in_time ? String(current.in_time).slice(0, 5) : '09:00';
        if (outInput) outInput.value = current.out_time ? String(current.out_time).slice(0, 5) : '18:00';

        selectedLeave = '';
        if (code === 'L' && current.reason) {
            const reason = String(current.reason).replace(/^Leave request #\d+\s*[—-]\s*/, '');
            selectedLeave = ['Casual Leave', 'Paid Leave', 'Sick Leave'].find(
                item => item.toLowerCase() === reason.toLowerCase()
            ) || '';
        }
        document.querySelectorAll('.leave-type-btn').forEach(button => {
            button.classList.toggle('active', button.dataset.leaveType === selectedLeave);
        });

        const leaveSection = document.getElementById('leaveTypeSection');
        const timeSection = document.getElementById('timeSection');
        if (leaveSection) leaveSection.style.display = label === 'On Leave' ? '' : 'none';
        if (timeSection) timeSection.style.display = ['Present', 'On Duty'].includes(label) ? '' : 'none';
        modal.show();
    }

    function onAttendanceStatusClick(event) {
        const button = event.target.closest('.status-select-btn');
        if (!button) return;

        document.querySelectorAll('.status-select-btn').forEach(item => {
            item.classList.toggle('active', item === button);
        });

        const label = button.dataset.status;
        const timeSection = document.getElementById('timeSection');
        const leaveSection = document.getElementById('leaveTypeSection');
        if (timeSection) timeSection.style.display = ['Present', 'On Duty'].includes(label) ? '' : 'none';
        if (leaveSection) leaveSection.style.display = label === 'On Leave' ? '' : 'none';
    }

    function onLeaveTypeClick(event) {
        const button = event.target.closest('.leave-type-btn');
        if (!button) return;
        selectedLeave = button.dataset.leaveType || '';
        document.querySelectorAll('.leave-type-btn').forEach(item => {
            item.classList.toggle('active', item === button);
        });
    }

    async function saveAttendance() {
        const button = document.getElementById('saveAttendance');
        if (!state.selected || !button) return;

        const label = modalElement.querySelector('.status-select-btn.active')?.dataset.status || '';
        if (!label) {
            window.alert('Select an attendance status before saving.');
            return;
        }

        const inTime = document.getElementById('inTime')?.value || null;
        const outTime = document.getElementById('outTime')?.value || null;
        if (label === 'On Leave' && !selectedLeave) {
            window.alert('Select a leave type.');
            return;
        }

        button.disabled = true;
        try {
            await request(api, {
                method: 'POST',
                body: JSON.stringify({
                    staff_id: state.selected.staff_id,
                    date: state.selected.date,
                    attendance: statusCode(label),
                    in_time: ['Present', 'On Duty'].includes(label) ? inTime : null,
                    out_time: ['Present', 'On Duty'].includes(label) ? outTime : null,
                    type: 'Manual',
                    reason: label === 'On Leave' ? selectedLeave : null
                })
            });
            getModal()?.hide();
            await attendanceLoad();
            await attendanceLoadTodaySummary();
        } catch (error) {
            window.alert(error.message);
        } finally {
            button.disabled = false;
        }
    }

    function attendanceTableInit() {
        if (!body || !monthSelector || !yearSelector || !changeMonthBtn) return;

        changeMonthBtn.addEventListener('click', () => {
            const url = new URL(window.location.href);
            url.searchParams.set('month', monthSelector.value);
            url.searchParams.set('year', yearSelector.value);
            window.location.href = url.toString();
        });

        searchInput?.addEventListener('input', () => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                state.search = searchInput.value.trim();
                state.page = 1;
                attendanceLoad();
            }, 250);
        });

        body.addEventListener('click', event => {
            const cell = event.target.closest('td.attendance-cell[data-staff-id]');
            if (cell) {
                openCell(cell);
                return;
            }

            const target = event.target.closest('td.employee-cell[data-staff-id], .employee-name, .employee-info');
            const row = target?.closest('tr[data-staff-id]');
            if (row) {
                const staffId = Number(row.dataset.staffId || target?.dataset?.staffId);
                if (staffId) openCell({ dataset: { staffId, date: dateForStaffRow() }, closest: () => row });
            }
        });

        body.addEventListener('keydown', event => {
            if (event.key !== 'Enter' && event.key !== ' ') return;
            const cell = event.target.closest('td.attendance-cell[data-staff-id]');
            if (!cell) return;
            event.preventDefault();
            openCell(cell);
        });

        document.addEventListener('click', handleHrDocumentClick);
        document.addEventListener('click', onAttendanceStatusClick);
        document.addEventListener('click', onLeaveTypeClick);
        document.getElementById('saveAttendance')?.addEventListener('click', saveAttendance);

        attendanceLoad();
        attendanceLoadTodaySummary().catch(error => {
            console.error('Today attendance summary could not be loaded:', error);
            document.querySelectorAll('.summary-card-value').forEach(value => {
                value.textContent = '—';
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attendanceTableInit, { once: true });
    } else {
        attendanceTableInit();
    }
</script>

@endsection