@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@php
$employmentType = 'Permanent';
$viewMode = 'List';

@endphp

<div class="container-fluid px-0">

    {{-- ================= SUMMARY CARDS ================= --}}
    <div class="row g-3 mb-4">

        {{-- Permanent Pool --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary summary-card-label">
                        Permanent Pool
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value" style="color:#0C3C62;">
                        Loading…
                    </span>
                </div>
            </div>
        </div>

        {{-- Present --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-success summary-card-label">
                        Checked In (Present)
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-success">
                        Loading…
                    </span>
                </div>
            </div>
        </div>

        {{-- Absent --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-danger summary-card-label">
                        Unexcused Absences
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-danger">
                        Loading…
                    </span>
                </div>
            </div>
        </div>

        {{-- Leave --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 summary-card">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-warning summary-card-label">
                        Sabbatical & Leaves
                    </span>

                    <span class="d-block fw-bold font-monospace summary-card-value text-warning">
                        Loading…
                    </span>
                </div>
            </div>
        </div>

    </div>

    {{-- ================= STAFF HEADER ================= --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="d-flex flex-column flex-md-row
                    justify-content-between
                    align-items-start
                    align-items-md-center
                    gap-3">

                {{-- TITLE --}}
                <div class="w-100 w-md-auto">
                    <div class="px-3 py-2 bg-white">

                        <span class="fw-bold" style="font-size:20px;color:#0C3C62;">
                            Permanent Staff
                        </span>

                    </div>
                </div>


                {{-- VIEW SWITCH --}}
                <div class="d-flex justify-content-start justify-content-md-end w-100 w-md-auto">

                    <div class="btn-group responsive-view-buttons" role="group">

                        {{-- LIST --}}
                        <a href="{{ url('/admin-hr/permanent-log') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log') ? 'active' : '' }}">

                            <span class="mdi mdi-format-list-bulleted me-1"></span>
                            List View

                        </a>


                        {{-- TABLE --}}
                        <a href="{{ url('/admin-hr/permanent-log/table') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log/table') ? 'active' : '' }}">

                            <span class="mdi mdi-table me-1"></span>
                            Table View

                        </a>


                        {{-- CALENDAR --}}
                        <a href="{{ url('admin-hr/permanent-log/calender') }}" class="btn btn-sm btn-outline-primary
                       {{ request()->is('admin-hr/permanent-log/calender') ? 'active' : '' }}">

                            <span class="mdi mdi-calendar-month me-1"></span>
                            Calendar View

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

    {{-- ================= MINI DASHBOARD STYLES ================= --}}
    <style>
    .summary-card .card-body {
        min-height: 75px;
    }

    .summary-card-label {
        font-size: 9px;
        letter-spacing: .5px;
        line-height: 1.4;
    }

    .summary-card-value {
        font-size: 1.25rem;
        line-height: 1.3;
        margin-top: 4px;
    }

    .view-mode-container {
        background: #f1f5f9;
    }
    </style>

    {{-- ================= FILTER SECTION ================= --}}
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-3">

            <div class="attendance-filter-row">

                {{-- ================= SEARCH ================= --}}
                <div class="attendance-search">
                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                            style="pointer-events:none;">
                            <i class="mdi mdi-magnify"></i>
                        </span>

                        <input id="hr-search-field" type="text" placeholder="Search personnel..."
                            class="form-control form-control-sm ps-5 bg-light border-0 rounded-3">

                    </div>
                </div>

                {{-- ================= DEPARTMENT FILTERS ================= --}}
                <div class="attendance-departments">

                    <div class="department-scroll">

                    </div>

                </div>

            </div>

        </div>
    </div>

    {{-- ================= ATTENDANCE TABLE ================= --}}
    <div class="card border-0 shadow-sm rounded-4">

        <div class="table-responsive">

            <table class="table table-hover mb-0" id="attendance-table">

                <thead>
                    <tr style="background-color:#f8fafc;">

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Personnel Information
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Department Unit
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Attendance Date
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            In / Out Time
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Daily Actions
                        </th>

                        <th class="fw-semibold text-black fs-8 uppercase bg-light">
                            Attendance Status
                        </th>

                    </tr>
                </thead>

                <tbody>

                    <tr class="skeleton-loader" id="skeleton-loader">
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                    </tr>

                </tbody>

            </table>

        </div>

    </div>

</div>


<!-- Present Modal -->
<div class="modal fade" id="presentModal" tabindex="-1" aria-labelledby="presentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="presentModalLabel">Mark Present</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label fw-semibold">In Time <span class="text-danger">*</span></label>
                        <input type="time" class="form-control" id="inTime">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="savePresentBtn">Save</button>
            </div>
        </div>
    </div>
</div>

<!-- Leave Modal -->
<div class="modal fade" id="leaveModal" tabindex="-1" aria-labelledby="leaveModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="leaveModalLabel">Mark Leave</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label class="form-label fw-semibold">Leave Type <span class="text-danger">*</span></label>
                <select class="form-select" id="leaveType">
                    <option value="">Select leave type</option>
                    <option value="Sick Leave">Sick Leave</option>
                    <option value="Paid Leave">Paid Leave</option>
                    <option value="Casual Leave">Casual Leave</option>
                </select>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="saveLeaveBtn">Save</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="checkoutModal" tabindex="-1" aria-labelledby="checkoutModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="checkoutForm"  action="">
                @csrf
              

                <div class="modal-header">
                    <h5 class="modal-title" id="checkoutModalLabel">
                        <span class="mdi mdi-logout me-1"></span> Checkout
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label text-muted small">In-time</label>
                        <div id="displayInTime" class="fw-semibold">09:30</div>
                    </div>

                    <div class="mb-3">
                        <label for="outTime" class="form-label">Out-time <span class="text-danger">*</span></label>
                        <input type="time"
                               class="form-control"
                               id="outTime"
                               name="out_time"
                               required>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">
                        <span class="mdi mdi-logout me-1"></span> Confirm Checkout
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
{{-- ================= FILTER STYLES ================= --}}
<style>
.attendance-filter-row {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    min-width: 0;
}

.attendance-search {
    flex: 0 0 180px;
    width: 180px;
    min-width: 180px;
}

.attendance-search .position-relative {
    width: 100%;
}

/* Present – Green */
.present-btn {
    color: #198754;
    border: 1px solid #198754;
    background-color: #fff;
}
.present-btn:hover,
.present-btn.active-status {
    background-color: #198754;
    color: #fff;
    border-color: #198754;
}

/* Absent – Red */
.absent-btn {
    color: #dc3545;
    border: 1px solid #dc3545;
    background-color: #fff;
}
.absent-btn:hover,
.absent-btn.active-status {
    background-color: #dc3545;
    color: #fff;
    border-color: #dc3545;
}

/* Leave – Amber / Warning */
.leave-btn {
    color: #d97706;
    border: 1px solid #d97706;
    background-color: #fff;
}
.leave-btn:hover,
.leave-btn.active-status {
    background-color: #d97706;
    color: #fff;
    border-color: #d97706;
}

#hr-search-field {
    width: 100%;
    height: 36px;
    font-size: 11px;
    padding-right: 8px;
}

.attendance-departments {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
}

.department-scroll {
    display: flex;
    align-items: center;
    gap: 5px;
    width: 100%;
    min-width: 0;
    overflow-x: auto;
    overflow-y: hidden;
    white-space: nowrap;
    scrollbar-width: none;
    -ms-overflow-style: none;
    padding: 1px 0;
}

.department-scroll::-webkit-scrollbar {
    display: none;
}

.dept-filter-btn {
    flex: 0 0 auto;
    height: 36px;
    padding: 0 12px !important;
    font-size: 10px;
    background-color: #f8fafc;
    color: #475569;
    border: 1px solid transparent;
    white-space: nowrap;
    transition: all 0.2s ease;
}

.dept-filter-btn:hover {
    background-color: #e2e8f0;
    color: #0f172a;
}

.dept-filter-btn.active {
    background-color: #16659E !important;
    color: #ffffff !important;
    border-color: #16659E;
    box-shadow: 0 2px 5px rgba(22, 101, 158, 0.20);
}

/* ================= LARGE DESKTOP ================= */
@media (min-width: 1400px) {
    .attendance-search {
        flex: 0 0 180px;
        width: 180px;
        min-width: 180px;
    }

    .attendance-filter-row {
        gap: 8px;
    }

    .dept-filter-btn {
        padding-left: 10px !important;
        padding-right: 10px !important;
    }
}

/* ================= DESKTOP ================= */
@media (min-width: 1200px) and (max-width: 1399.98px) {
    .attendance-search {
        flex: 0 0 160px;
        width: 160px;
        min-width: 160px;
    }

    .dept-filter-btn {
        padding-left: 8px !important;
        padding-right: 8px !important;
        font-size: 9px;
    }
}

/* ================= TABLET ================= */
@media (min-width: 768px) and (max-width: 1199.98px) {
    .attendance-search {
        flex: 0 0 150px;
        width: 150px;
        min-width: 150px;
    }

    .dept-filter-btn {
        padding-left: 9px !important;
        padding-right: 9px !important;
        font-size: 9px;
    }
}

/* ================= MOBILE ================= */
@media (max-width: 767.98px) {
    .attendance-filter-row {
        flex-direction: column;
        align-items: stretch;
        gap: 10px;
    }

    .attendance-search {
        width: 100%;
        min-width: 0;
        flex: none;
    }

    .attendance-departments {
        width: 100%;
    }

    .department-scroll {
        overflow-x: auto;
    }

    .dept-filter-btn {
        font-size: 10px;
        padding-left: 10px !important;
        padding-right: 10px !important;
    }
}

/* ===============================
   RESPONSIVE VIEW SWITCH
================================ */

.responsive-view-buttons {
    white-space: nowrap;
}

/* Tablet */
@media (max-width: 991.98px) {

    .responsive-view-buttons .btn {
        padding-left: 10px !important;
        padding-right: 10px !important;
        font-size: 11px;
    }

}

/* Mobile */
@media (max-width: 575.98px) {

    .responsive-view-buttons {
        width: 100%;
        display: flex;
    }

    .responsive-view-buttons .btn {
        flex: 1 1 0;
        padding: 8px 5px !important;
        font-size: 10px;
        white-space: nowrap;
    }

    .responsive-view-buttons .mdi {
        margin-right: 2px !important;
    }

}

/* Very small mobile */
@media (max-width: 400px) {

    .responsive-view-buttons .btn {
        padding: 7px 3px !important;
        font-size: 9px;
    }

    .responsive-view-buttons .mdi {
        display: none;
    }

}
</style>

<script >
    
    const type = 'permanent';
    const api = `/admin-hr/api/attendance/${type}`;
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    const attendanceState = {
        page: 1,
        perPage: 10,
        search: '',
        department_id: '',
        date: attendanceLocalDate(),
        rows: [],
        selected: null,
        direction: 'asc',
        options: null,
        current: null,
    };


    function attendanceEscape(value) {
        return String(value ?? '').replace(/[&<>"']/g, character => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        })[character]);
    }

    function attendanceLocalDate() {
        const date = new Date();

        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    }

    function attendanceCodeLabel(code) {
        return ({
            P: 'Present',
            PR: 'Present',
            A: 'Absent',
            L: 'On Leave',
            OD: 'On Duty',
            H: 'Holiday'
        })[String(code || '').toUpperCase()] || 'Not marked';
    }

    function attendanceCurrentFor(staffId) {
        return attendanceState.rows.find(
            row => Number(row.staff_pk) === Number(staffId)
        ) || {};
    }

    async function attendanceRequest(url, options = {}) {
        const response = await fetch(url, {
            credentials: 'same-origin',
            ...options,
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                ...(csrf
                    ? { 'X-CSRF-TOKEN': csrf }
                    : {}),
                ...(options.body
                    ? { 'Content-Type': 'application/json' }
                    : {}),
                ...(options.headers || {})
            }
        });

        const payload = await response.json().catch(() => ({}));

        if (!response.ok || payload.success === false) {
            throw new Error(
                payload.message ||
                Object.values(payload.errors || {}).flat()[0] ||
                `Request failed (${response.status}).`
            );
        }

        return payload;
    }

    function attendanceStatusHtml(code) {
        const label = attendanceCodeLabel(code);

        const className =
            label === 'Present' || label === 'On Duty'
                ? 'present-status'
                : label === 'Absent'
                    ? 'absent-status'
                    : label === 'On Leave'
                        ? 'leave-status'
                        : 'text-muted';

        const icon =
            label === 'Present' || label === 'On Duty'
                ? 'mdi-check-circle-outline'
                : label === 'Absent'
                    ? 'mdi-close-circle-outline'
                    : label === 'On Leave'
                        ? 'mdi-alert-circle-outline'
                        : 'mdi-minus-circle-outline';

        return `
            <span class="status-text ${className}">
                <i class="mdi ${icon} me-1"></i>${attendanceEscape(label)}
            </span>
        `;
    }

    function attendanceActionHtml(row) {
        const id = Number(row.staff_pk);
        const date = row.date || attendanceState.date;
        const attendance = row.attendance;
        const in_time = row.in_time;
        const out_time = row.out_time;

        const attrs = ` data-staff-id="${id}" data-date="${attendanceEscape(date)}"`;

        return `
            <div class="d-flex flex-wrap gap-1">
                <button
                    type="button"
                    class="btn btn-sm attendance-btn present-btn"
                    data-attendance-action="present"${attrs}
                    data-bs-toggle="modal"
                    data-bs-target="#presentModal">
                    Present
                </button>

                <button
                    type="button"
                    class="btn btn-sm attendance-btn absent-btn"
                    data-attendance-action="absent"${attrs}>
                    Absent
                </button>

                <button
                    type="button"
                    class="btn btn-sm attendance-btn leave-btn"
                    data-attendance-action="leave"${attrs}
                    data-bs-toggle="modal"
                    data-bs-target="#leaveModal">
                    Leave
                </button>

                ${(row.in_time && !out_time) ? `
                    <button
                        type="button"
                        class="btn btn-sm btn-warning checkout-btn"
                        data-attendance-action="checkout"${attrs}
                        data-in-time="${attendanceEscape(String(row.in_time).slice(0, 5))}"
                        data-bs-toggle="modal"
                        data-bs-target="#checkoutModal">
                        <i class="mdi mdi-logout me-1"></i>Checkout
                    </button>
                ` : ''}
            </div>
        `;
    }

    function attendanceRenderRows() {
        const body = document.querySelector('#attendance-table tbody');

        if (!body) return;

        body.innerHTML = attendanceState.rows.map(row => {
            const department = row.department_name || '—';
            const designation = row.designation || 'Staff';
            const name = row.staff_name || '—';
            const code = row.staff_code || '';
            const date = row.date || attendanceState.date;
            const staffImage =row.staff_image ?  `/admin-hr/api/staff/${row.staff_pk}/photo` : '';
             const staff_profile_src = staffImage || `https://ui-avatars.com/api/?name=${encodeURIComponent(row.staff_name || 'Staff')}&background=f8f9fa&color=0d6efd&size=100`;

            const time = `
                ${row.in_time ? String(row.in_time).slice(0, 5) : '—'}
                /
                ${row.out_time ? String(row.out_time).slice(0, 5) : '—'}
            `;

            return `
                <tr
                    data-staff-id="${Number(row.staff_pk)}"
                    data-date="${attendanceEscape(date)}" data-department="${attendanceEscape(row.department || '')}">

                    <td class="px-4 py-3">
                        <div class="d-flex align-items-center gap-3">
                            <div >
                                <img src="${staff_profile_src}" style="width:36px;height:36px;background:#eff6ff;color:#475569" class="rounded-circle" alt="Profile" >
                            </div>

                            <div>
                                <div class="fw-bold text-dark">
                                    ${attendanceEscape(name)}
                                </div>
                                <small class="text-muted">
                                    ${attendanceEscape(code)} • ${attendanceEscape(designation)}
                                </small>
                            </div>
                        </div>
                    </td>

                    <td class="py-3">
                        <span
                            class="badge rounded-2"
                            style="background:#f1f5f9;color:#475569;font-size:9px">
                            ${attendanceEscape(department)}
                        </span>
                    </td>

                    <td class="py-3 fw-semibold text-secondary">
                        ${attendanceEscape(date)}
                    </td>

                    <td
                        class="py-3 fw-bold font-monospace"
                        style="color:#0C3C62">
                        ${attendanceEscape(time)}
                    </td>

                    <td class="py-3">
                        ${attendanceActionHtml(row)}
                    </td>

                    <td class="py-3 px-4 text-center">
                        ${attendanceStatusHtml(row.attendance)}
                    </td>
                </tr>
            `;
        }).join('') || `
            <tr>
                <td colspan="6" class="text-center text-muted py-4">
                    No active staff records found.
                </td>
            </tr>
        `;
    }

    function attendanceUpdateSummary(summary) {
        const values = document.querySelectorAll('.summary-card-value');

        if (values[0]) {
            values[0].textContent = `${Number(summary.staff_count || 0)} Staff`;
        }

        if (values[1]) {
            values[1].textContent = `${Number(summary.present_count || 0)} Present`;
        }

        if (values[2]) {
            values[2].textContent = `${Number(summary.absent_count || 0)} Absent`;
        }

        if (values[3]) {
            values[3].textContent = `${Number(summary.leave_count || 0)} On Leave`;
        }
    }

    function refreshSelect2(select) {
        if (window.jQuery && jQuery.fn.select2 && jQuery(select).hasClass('select3')) jQuery(select).trigger('change.select2');
    }
    function setOptions(select, items, placeholder, selected = '') {
        if (!select) return;
        const previous = selected !== '' && selected !== null ? String(selected) : String(select.value || '');
        select.innerHTML = `<option value="">${attendanceEscape(placeholder)}</option>${(items || []).map(item => `<option value="${attendanceEscape(item.id)}">${attendanceEscape(item.name || item.relationship_name || item.blood_group)}</option>`).join('')}`;
        select.value = previous;
        refreshSelect2(select);
    }
    async function loadOptions() {
        // Department options are static for this page session. Do not rebuild the
        // buttons on every table reload, otherwise the active filter is reset.
        if (attendanceState.options !== null) return;

        const response = await attendanceRequest('/admin-hr/api/staff/options');
        attendanceState.options = response.data || {};
        window.hrStaffOptions = attendanceState.options;

        const departments = attendanceState.options.departments || [];
        const departmentHost = document.querySelector('.department-scroll');
        const selectedDepartmentId = String(attendanceState.department_id || '');

        if (departmentHost) {
            departmentHost.innerHTML = `
                <button type="button"
                    data-department="ALL"
                    class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn ${selectedDepartmentId === '' ? 'active' : ''}">
                    All Roles
                </button>
                ${departments.map(department => {
                    const departmentId = String(department.id);
                    const activeClass = departmentId === selectedDepartmentId ? 'active' : '';
                    return `<button type="button"
                        data-department="${attendanceEscape(department.name)}"
                        data-department-id="${attendanceEscape(departmentId)}"
                        class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn ${activeClass}">${attendanceEscape(department.name)}</button>`;
                }).join('')}
            `;
        }
    }

    function attendanceRenderPager(meta) {
        const table = document.getElementById('attendance-table');

        if (!table) return;

        let host = document.getElementById('attendance-ajax-pagination');

        if (!host) {
            host = document.createElement('div');
            host.id = 'attendance-ajax-pagination';
            host.className = 'd-flex flex-wrap align-items-center justify-content-between gap-2 p-3';

            table.closest('.card')?.appendChild(host);
        }

        if (!host) return;

        const currentPage = Math.max( 1, Number(meta.current_page || 1) );
        const lastPage = Math.max( 1, Number(meta.last_page || 1) );

        const total = Number(meta.total || 0);
        const perPage = Number( meta.per_page || attendanceState.perPage);
        const start = total === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
        const end = Math.min(currentPage * perPage, total );
        const firstPage = Math.max( 1, currentPage - 2);
        const finalPage = Math.min( lastPage,currentPage + 2);

        const pageButtons = Array.from(
            { length: finalPage - firstPage + 1 },
            (_, index) => {
                const page = firstPage + index;

                return `
                    <li class="page-item ${page === currentPage ? 'active' : ''}">
                        <button
                            type="button"
                            class="page-link"
                            data-attendance-page="${page}"
                            ${page === currentPage ? 'aria-current="page"' : ''}>
                            ${page}
                        </button>
                    </li>
                `;
            }
        ).join('');

        host.innerHTML = `
            <div class="small text-muted">
                Showing ${start} to ${end} of ${total} results
            </div>

            <div class="d-flex flex-wrap align-items-center gap-2">

                <label
                    for="attendancePageSize"
                    class="small text-muted mb-0">
                    Rows
                </label>

                <select
                    id="attendancePageSize"
                    class="form-select form-select-sm"
                    style="width:82px">
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>

                <nav aria-label="Attendance table pagination">
                    <ul class="pagination pagination-sm mb-0">

                        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                            <button
                                type="button"
                                class="page-link"
                                data-attendance-page="1"
                                aria-label="First page"
                                ${currentPage === 1 ? 'disabled' : ''}>
                                «
                            </button>
                        </li>

                        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                            <button
                                type="button"
                                class="page-link"
                                data-attendance-page="${Math.max(1, currentPage - 1)}"
                                aria-label="Previous page"
                                ${currentPage === 1 ? 'disabled' : ''}>
                                ‹
                            </button>
                        </li>

                        ${pageButtons}

                        <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}">
                            <button
                                type="button"
                                class="page-link"
                                data-attendance-page="${Math.min(lastPage, currentPage + 1)}"
                                aria-label="Next page"
                                ${currentPage === lastPage ? 'disabled' : ''}>
                                ›
                            </button>
                        </li>

                        <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}">
                            <button
                                type="button"
                                class="page-link"
                                data-attendance-page="${lastPage}"
                                aria-label="Last page"
                                ${currentPage === lastPage ? 'disabled' : ''}>
                                »
                            </button>
                        </li>

                    </ul>
                </nav>
            </div>
        `;

        // Rows per page
        const pageSizeSelect = host.querySelector('#attendancePageSize');

        pageSizeSelect.value = String(perPage);

        pageSizeSelect.addEventListener('change', event => {
            attendanceState.perPage = Number(event.currentTarget.value);
            attendanceState.page = 1;

            attendanceLoad();
        });

        // First, previous, numbered, next and last page buttons
        host.querySelectorAll('[data-attendance-page]').forEach(button => {
            button.addEventListener('click', () => {
                if (button.disabled) return;

                attendanceState.page = Number(
                    button.dataset.attendancePage
                );

                attendanceLoad();
            });
        });
    }

    async function attendanceLoad() {

        try {
            await loadOptions();
        } catch (error) {
            console.error('HR settings dropdowns failed:', error);
        }

        const body = document.querySelector('#attendance-table tbody');

        if (!body) return;

        body.innerHTML = Array.from({ length: 5 }, () => `
            <tr class="skeleton-loader">
                ${Array.from({ length: 6 }, () => `
                    <td class="skeleton-cell">
                        <div class="skeleton-loader-view"></div>
                    </td>
                `).join('')}
            </tr>
        `).join('');

        const query = new URLSearchParams({
            page: String(attendanceState.page),
            per_page: String(attendanceState.perPage),
            search: attendanceState.search,
            date: attendanceState.date,
            sort: 'staff',
            direction: 'asc'
        });

        // Match the staff directory: filter by the department's primary key,
        // not by its display label (which may be renamed or duplicated).
        if (attendanceState.department_id) {
            query.set('department_id', String(attendanceState.department_id));
        }

        try {
            const payload = await attendanceRequest(
                `${api}?${query.toString()}`
            );

            attendanceState.rows = payload.data || [];

            attendanceRenderRows();
            attendanceRenderPager(payload.meta || {});
            attendanceUpdateSummary(payload.summary || {});
        } catch (error) {
            body.innerHTML = `
                <tr>
                    <td colspan="6" class="text-danger text-center py-4">
                        ${attendanceEscape(error.message)}
                    </td>
                </tr>
            `;

            document.querySelectorAll('.summary-card-value').forEach(value => {
                value.textContent = '—';
            });
        }
    }

    function attendanceSetSelected(trigger) {
        if (!trigger) return;

        const staffId = Number(trigger.dataset.staffId);
        const date = trigger.dataset.date || attendanceState.date;

        if (staffId && date) {
            attendanceState.selected = {
                staff_id: staffId,
                date
            };
        }
    }

    function handleHrDocumentClick(event) {
        const departmentButton = event.target.closest('.dept-filter-btn');
        if (!departmentButton) return;

        document.querySelectorAll('.dept-filter-btn').forEach(button => {
            button.classList.toggle('active', button === departmentButton);
        });

        attendanceState.department_id = departmentButton.dataset.department === 'ALL'
            ? ''
            : String(departmentButton.dataset.departmentId || '');
        attendanceState.page = 1;
        attendanceLoad();
    }

    async function attendanceSave(attendance, values = {}) {
        if (!attendanceState.selected) {
            throw new Error('Select a staff member first.');
        }

        const current = attendanceCurrentFor(
            attendanceState.selected.staff_id
        );

        const isPresent = ['P', 'PR', 'OD'].includes(attendance);

        const payload = {
            staff_id: attendanceState.selected.staff_id,
            date: attendanceState.selected.date,
            attendance,

            in_time: isPresent
                ? (
                    values.in_time !== undefined
                        ? values.in_time
                        : (
                            current.in_time
                                ? String(current.in_time).slice(0, 5)
                                : null
                        )
                )
                : null,

            out_time: isPresent
                ? (
                    values.out_time !== undefined
                        ? values.out_time
                        : (
                            current.out_time
                                ? String(current.out_time).slice(0, 5)
                                : null
                        )
                )
                : null,

            type: 'Manual',
            reason: values.reason ?? null
        };

        await attendanceRequest(api, {
            method: 'POST',
            body: JSON.stringify(payload)
        });

        window.toastr?.success?.('Daily attendance saved.');

        await attendanceLoad();
    }

    // Present modal
    const attendancePresentModal = document.getElementById('presentModal');

    attendancePresentModal?.addEventListener('show.bs.modal', event => {
        attendanceSetSelected(event.relatedTarget);

        const current = attendanceState.selected
            ? attendanceCurrentFor(attendanceState.selected.staff_id)
            : {};

        const input = document.getElementById('inTime');

        if (input) {
            input.value = current.in_time
                ? String(current.in_time).slice(0, 5)
                : '09:00';
        }
    });

    document.getElementById('savePresentBtn')?.addEventListener(
        'click',
        async event => {
            const button = event.currentTarget;
            const inTime = document.getElementById('inTime')?.value || null;

            if (!inTime) {
                alert('Enter the check-in time.');
                return;
            }

            button.disabled = true;

            try {
                await attendanceSave('P', {
                    in_time: inTime
                });

                bootstrap.Modal.getInstance(attendancePresentModal)?.hide();
            } catch (error) {
                alert(error.message);
            } finally {
                button.disabled = false;
            }
        }
    );

    // Leave modal
    const attendanceLeaveModal = document.getElementById('leaveModal');

    attendanceLeaveModal?.addEventListener('show.bs.modal', event => {
        attendanceSetSelected(event.relatedTarget);
    });

    document.getElementById('saveLeaveBtn')?.addEventListener(
        'click',
        async event => {
            const button = event.currentTarget;
            const leaveType = document.getElementById('leaveType')?.value;

            if (!leaveType) {
                alert('Select a leave type.');
                return;
            }

            button.disabled = true;

            try {
                await attendanceSave('L', {
                    reason: leaveType,
                    in_time: null,
                    out_time: null
                });

                bootstrap.Modal.getInstance(attendanceLeaveModal)?.hide();
            } catch (error) {
                alert(error.message);
            } finally {
                button.disabled = false;
            }
        }
    );

    // Checkout modal
    const attendanceCheckoutModal = document.getElementById('checkoutModal');

    attendanceCheckoutModal?.addEventListener('show.bs.modal', event => {
        attendanceSetSelected(event.relatedTarget);

        const current = attendanceState.selected
            ? attendanceCurrentFor(attendanceState.selected.staff_id)
            : {};

        const input = document.getElementById('outTime');
        const display = document.getElementById('displayInTime');

        if (display) {
            display.textContent = current.in_time
                ? String(current.in_time).slice(0, 5)
                : '—';
        }

        if (input) {
            input.value = current.out_time
                ? String(current.out_time).slice(0, 5)
                : '';

            input.min = current.in_time
                ? String(current.in_time).slice(0, 5)
                : '';
        }
    });

    document.getElementById('checkoutForm')?.addEventListener(
        'submit',
        async event => {
            event.preventDefault();

            const outTime = document.getElementById('outTime')?.value;

            if (!outTime) {
                alert('Enter the check-out time.');
                return;
            }

            const current = attendanceState.selected
                ? attendanceCurrentFor(attendanceState.selected.staff_id)
                : {};

            const code = ['P', 'PR', 'OD'].includes(
                String(current.attendance || '').toUpperCase()
            )
                ? String(current.attendance).toUpperCase()
                : 'P';

            const form = event.currentTarget;
            const submitButton = form.querySelector('[type="submit"]');

            if (submitButton) {
                submitButton.disabled = true;
            }

            try {
                await attendanceSave(code, {
                    in_time: current.in_time
                        ? String(current.in_time).slice(0, 5)
                        : null,

                    out_time: outTime,
                    reason: current.reason || null
                });

                bootstrap.Modal.getInstance(attendanceCheckoutModal)?.hide();
            } catch (error) {
                alert(error.message);
            } finally {
                if (submitButton) {
                    submitButton.disabled = false;
                }
            }
        }
    );

    // Absent action
    document.addEventListener('click', async event => {
        const button = event.target.closest(
            '[data-attendance-action="absent"]'
        );

        if (!button) return;

        event.preventDefault();

        attendanceSetSelected(button);
        button.disabled = true;

        try {
            await attendanceSave('A', {
                in_time: null,
                out_time: null,
                reason: null
            });
        } catch (error) {
            alert(error.message);
        } finally {
            button.disabled = false;
        }
    });

    // Search
    const attendanceSearchInput =
        document.getElementById('hr-search-field') ||
        document.querySelector('.attendance-search input');

    let attendanceSearchTimer;

    attendanceSearchInput?.addEventListener('input', () => {
        clearTimeout(attendanceSearchTimer);

        attendanceSearchTimer = setTimeout(() => {
            attendanceState.search = attendanceSearchInput.value.trim();
            attendanceState.page = 1;

            attendanceLoad();
        }, 250);
    });

    // Delegation is required because department buttons are rendered from API options.
    document.addEventListener('click', handleHrDocumentClick);
    // Initial load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attendanceLoad, {
            once: true
        });
    } else {
        attendanceLoad();
    }
</script>




@endsection
