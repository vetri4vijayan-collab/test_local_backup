@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('content')

{{-- ============================================================
    PERMANENT STAFF - LEAVE MANAGEMENT
============================================================= --}}

@php

/*
|--------------------------------------------------------------------------
| Permanent Employee Leave Data
|--------------------------------------------------------------------------
*/

$permanentEmployees = [
[
'id' => 1,
'name' => 'Arun Kumar',
'role' => 'Project Manager',
'department' => 'Management',
'status' => 'Present',
],
[
'id' => 2,
'name' => 'Suresh Raj',
'role' => 'Civil Engineer',
'department' => 'Engineering',
'status' => 'On Leave',
],
[
'id' => 3,
'name' => 'Priya Devi',
'role' => 'Supervisor',
'department' => 'General Labor',
'status' => 'Present',
],
[
'id' => 4,
'name' => 'Karthik Kumar',
'role' => 'Quality Inspector',
'department' => 'Quality Control',
'status' => 'Present',
],
[
'id' => 5,
'name' => 'Meena Devi',
'role' => 'Accountant',
'department' => 'Accounts',
'status' => 'Present',
],
];

$leaveRequests = [
[
'id' => 1,
'employeeId' => 2,
'employeeName' => 'Suresh Raj',
'leaveType' => 'Casual',
'startDate' => '2026-07-22',
'endDate' => '2026-07-23',
'days' => 2,
'appliedDate' => '2026-07-20',
'reason' => 'Personal work',
'status' => 'Pending',
],
[
'id' => 2,
'employeeId' => 1,
'employeeName' => 'Arun Kumar',
'leaveType' => 'Privilege',
'startDate' => '2026-07-10',
'endDate' => '2026-07-12',
'days' => 3,
'appliedDate' => '2026-07-05',
'reason' => 'Family function',
'status' => 'Approved',
],
[
'id' => 3,
'employeeId' => 4,
'employeeName' => 'Karthik Kumar',
'leaveType' => 'Sick',
'startDate' => '2026-07-15',
'endDate' => '2026-07-15',
'days' => 1,
'appliedDate' => '2026-07-15',
'reason' => 'Medical leave',
'status' => 'Approved',
],
];

/*
|--------------------------------------------------------------------------
| KPI Counts
|--------------------------------------------------------------------------
*/

$totalPersonnel = count($permanentEmployees);

$onLeaveToday = count(array_filter($permanentEmployees, function ($employee) {
return $employee['status'] === 'On Leave';
}));

$pendingRequests = count(array_filter($leaveRequests, function ($request) {
return $request['status'] === 'Pending';
}));

$approvedThisMonth = count(array_filter($leaveRequests, function ($request) {
return $request['status'] === 'Approved';
}));

@endphp


<div class="container-fluid px-0">

    {{-- ============================================================
        PAGE HEADER
    ============================================================= --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3">

                <div>
                    <span class="text-uppercase fw-bold text-muted" style="font-size:10px; letter-spacing:1px;">
                        Contract Staff
                    </span>

                    <h4 class="mb-1 fw-bold" style="color:#0C3C62;">
                        Leave Management
                    </h4>

                    <p class="mb-0 text-muted small">
                        Manage leave applications, approvals and employee leave balances.
                    </p>
                </div>

                <button type="button" class="btn btn-primary btn-sm rounded-3 px-3" data-bs-toggle="modal"
                    data-bs-target="#applyLeaveModal">

                    <i class="mdi mdi-plus me-1"></i>
                    Apply Leave

                </button>

            </div>

        </div>
    </div>


    {{-- ============================================================
        LEAVE MANAGEMENT KPI CARDS
    ============================================================= --}}
    <div class="row g-3 mb-4">

        {{-- Total Personnel --}}
        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center gap-3">

                        <div class="leave-kpi-icon bg-primary-subtle text-primary">
                            <i class="mdi mdi-account-group-outline"></i>
                        </div>

                        <div class="min-w-0">

                            <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                Total Personnel
                            </span>

                            <span class="d-block fw-bold font-monospace leave-kpi-value" style="color:#0C3C62;">
                                {{ $totalPersonnel }} Staff
                            </span>

                            <span class="d-block text-muted leave-kpi-description">
                                Permanent employees
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- On Leave Today --}}
        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center gap-3">

                        <div class="leave-kpi-icon bg-warning-subtle text-warning">
                            <i class="mdi mdi-calendar-account-outline"></i>
                        </div>

                        <div class="min-w-0">

                            <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                On Leave Today
                            </span>

                            <span class="d-block fw-bold font-monospace leave-kpi-value text-warning">
                                {{ $onLeaveToday }} Personnel
                            </span>

                            <span class="d-block text-muted leave-kpi-description">
                                Active leave records
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- Pending Requests --}}
        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center gap-3">

                        <div class="leave-kpi-icon bg-warning-subtle text-warning">
                            <i class="mdi mdi-alert-circle-outline"></i>
                        </div>

                        <div class="min-w-0">

                            <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                Pending Requests
                            </span>

                            <span class="d-block fw-bold font-monospace leave-kpi-value text-warning">
                                {{ $pendingRequests }} Pending
                            </span>

                            <span class="d-block text-muted leave-kpi-description">
                                Awaiting HR review
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- Approved --}}
        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center gap-3">

                        <div class="leave-kpi-icon bg-success-subtle text-success">
                            <i class="mdi mdi-check-circle-outline"></i>
                        </div>

                        <div class="min-w-0">

                            <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                Approved This Month
                            </span>

                            <span class="d-block fw-bold font-monospace leave-kpi-value text-success">
                                {{ $approvedThisMonth }} Approved
                            </span>

                            <span class="d-block text-muted leave-kpi-description">
                                July 2026
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- ============================================================
        LEAVE MANAGEMENT NAVIGATION
    ============================================================= --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-2">

            <div class="row g-2 align-items-center">

                <div class="col-12 col-lg">

                    <div class="d-flex flex-wrap gap-2">
                        {{-- Leave Applications Link --}}
                        <a href="{{ url('/admin-hr/leave_management/contract') }}"
                            class="btn btn-sm rounded-3 text-decoration-none
                        {{ !request()->is('/admin-hr/leave_management/contract') || request()->is('/admin-hr/leave_management/contract') ? 'btn-primary' : 'btn-light' }}">

                            <i class="mdi mdi-calendar-check-outline me-1"></i>
                            Leave Applications

                            <span
                                class="badge {{ !request()->is('/admin-hr/leave_management/contract') || request()->is('/admin-hr/leave_management/contract') ? 'bg-white text-primary' : 'bg-secondary text-white' }} ms-1">
                                {{ count($leaveRequests) }}
                            </span>
                        </a>

                        {{-- Leave Entitlement / Table View Link --}}
                        <a href="{{ url('/admin-hr/leave_management/contract/leave_entitle') }}"
                            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center gap-1
                          {{ request()->is('/admin-hr/leave_management/contract/leave_entitle') ? 'btn-danger' : 'btn-light' }}">

                            <i class="mdi mdi-table me-1"></i>
                            Leave Entitlement

                            <span
                                class="badge {{ request()->is('/admin-hr/leave_management/contract/leave_entitle') ? 'bg-white text-primary' : 'bg-secondary text-white' }} ms-1">
                                {{ $totalPersonnel }}
                            </span>
                        </a>
                    </div>

                </div>

                <div class="col-12 col-lg-auto">

                    <div class="d-flex flex-wrap align-items-center gap-2">

                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-3" data-bs-toggle="modal"
                            data-bs-target="#leaveSettingsModal">

                            <i class="mdi mdi-cog-outline me-1"></i>
                            Configure Settings

                        </button>

                        <!-- <span class="small text-muted">

                            <span class="text-success me-1">●</span>

                            Annual Cycle:
                            <strong class="font-monospace text-dark">
                                2026–2027
                            </strong>

                        </span> -->

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{--   LEAVE APPLICATIONS  --}}
    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-3 p-md-4">
            {{-- SECTION HEADER --}}
            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3
                        border-bottom pb-3 mb-3">
                <div>

                    <h5 class="mb-1 fw-bold text-dark">

                        <i class="mdi mdi-calendar-text-outline text-primary me-1"></i>

                        Leave Applications & Calendar Logs

                    </h5>

                    <p class="mb-0 text-muted small">
                        Review and manage leave requests for permanent employees.
                    </p>

                </div>



            </div>


            {{--   FILTER AREA     --}}
            <div class="bg-light border rounded-4 p-3 mb-4">
                <form>
                    <div class="row g-2 align-items-end">
                        {{-- SEARCH --}}
                        <div class="col-12 col-md-6 col-lg-3">
                            <label class="form-label small fw-bold text-muted mb-1">
                                Employee
                            </label>

                            <input type="text" name="employee" value="{{ request('employee') }}"
                                class="form-control form-control-sm" placeholder="Search employee...">

                        </div>


                        {{-- LEAVE TYPE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                Leave Type
                            </label>

                            <select name="leave_type" class="form-select form-select-sm">

                                <option value="ALL">
                                    All Types
                                </option>

                                <option value="Casual">
                                    Casual Leave
                                </option>

                                <option value="Privilege">
                                    Privilege Leave
                                </option>

                                <option value="Sick">
                                    Sick Leave
                                </option>

                            </select>

                        </div>


                        {{-- STATUS --}}
                        <div class="col-12 col-md-6 col-lg-2">
                            <label class="form-label small fw-bold text-muted mb-1">
                                Status
                            </label>
                            <select name="status" class="form-select form-select-sm">
                                <option value="ALL">
                                    All Status
                                </option>
                                <option value="Pending">
                                    Pending
                                </option>
                                <option value="Approved">
                                    Approved
                                </option>
                                <option value="Rejected">
                                    Rejected
                                </option>
                            </select>

                        </div>


                        {{-- FROM DATE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                From Date
                            </label>

                            <input type="date" name="from_date" value="{{ request('from_date') }}"
                                class="form-control form-control-sm">

                        </div>


                        {{-- TO DATE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                To Date
                            </label>

                            <input type="date" name="to_date" value="{{ request('to_date') }}"
                                class="form-control form-control-sm">

                        </div>


                        {{-- FILTER BUTTON --}}
                        <div class="col-12 col-lg-1">

                            <button type="submit" class="btn btn-primary btn-sm w-100">

                                <i class="mdi mdi-filter-outline"></i>

                            </button>

                        </div>

                    </div>

                </form>

            </div>


            {{-- LEAVE TABLE  --}}
            <div class="table-responsive border rounded-4">
                <table id="leave-requests-table" class="table table-hover mb-0">
                    <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                        <tr>
                            <th class="min-w-100px text-black">
                                Employee
                            </th>
                            <th class="min-w-100px text-black">
                                Leave Type
                            </th>
                            <th class="min-w-100px text-black">
                                Leave Date
                            </th>
                            <th class="min-w-100px text-black">
                                Duration
                            </th>
                            <th class="min-w-100px text-black">
                                Applied Date
                            </th>
                            <th class="min-w-100px text-black">
                                Reason
                            </th>
                            <th class="min-w-100px text-black">
                                Status / Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($leaveRequests as $request)


                        <tr>

                            {{-- EMPLOYEE --}}
                            <td>
                                <div class="fw-bold text-dark small">
                                    {{ $request['employeeName'] }}
                                </div>
                                <div class="text-muted" style="font-size:10px;">
                                    {{ $employee['role'] ?? 'Staff' }}
                                    <span class="mx-1">•</span>
                                    {{ $employee['department'] ?? 'General' }}
                                </div>
                            </td>

                            {{-- LEAVE TYPE --}}
                            <td>
                                @if($request['leaveType'] === 'Casual')
                                <span class="badge bg-primary-subtle text-primary">
                                    Casual Leave
                                </span>
                                @elseif($request['leaveType'] === 'Sick')
                                <span class="badge bg-danger-subtle text-danger">
                                    Sick Leave
                                </span>
                                @else
                                <span class="badge bg-success-subtle text-success">
                                    Privilege Leave
                                </span>
                                @endif
                            </td>


                            {{-- DATE RANGE --}}
                            <td>

                                <span class="font-monospace small fw-bold">

                                    {{ \Carbon\Carbon::parse($request['startDate'])->format('d-m-Y') }}

                                    <span class="text-muted">
                                        to
                                    </span>

                                    {{ \Carbon\Carbon::parse($request['endDate'])->format('d-m-Y') }}

                                </span>

                            </td>


                            {{-- DURATION --}}
                            <td class="text-center">

                                <span class="badge bg-light text-dark border">
                                    {{ $request['days'] }}
                                    {{ $request['days'] == 1 ? 'Day' : 'Days' }}
                                </span>

                            </td>


                            {{-- APPLIED DATE --}}
                            <td>

                                <span class="small font-monospace text-muted">

                                    {{ $request['appliedDate'] ?? 'N/A' }}

                                </span>

                            </td>


                            {{-- REASON --}}
                            <td>

                                <span class="small text-muted d-block leave-reason" title="{{ $request['reason'] }}">

                                    {{ $request['reason'] }}

                                </span>

                            </td>


                            {{-- STATUS --}}
                            <td class="text-center">

                                @if($request['status'] === 'Pending')

                                <div class="d-flex justify-content-center gap-1">

                                    <form>

                                        @csrf

                                        <button type="submit" class="btn btn-success btn-sm px-2" title="Approve">

                                            <i class="mdi mdi-check"></i>

                                            <span class="d-none d-xl-inline">
                                                Approve
                                            </span>

                                        </button>

                                    </form>


                                    <form>
                                        @csrf
                                        <button type="submit" class="btn btn-outline-danger btn-sm px-2" title="Reject">
                                            <i class="mdi mdi-close"></i>
                                            <span class="d-none d-xl-inline">
                                                Reject
                                            </span>
                                        </button>
                                    </form>
                                </div>

                                @elseif($request['status'] === 'Approved')

                                <span class="badge bg-success-subtle text-success">
                                    Approved
                                </span>

                                @else

                                <span class="badge bg-danger-subtle text-danger">
                                    Rejected
                                </span>

                                @endif
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <i class="mdi mdi-calendar-remove-outline text-muted" style="font-size:40px;"></i>
                                <p class="fw-bold text-muted mb-1">
                                    No Leave Records Found
                                </p>
                                <small class="text-muted">
                                    No permanent employee leave applications are available.
                                </small>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


{{-- APPLY LEAVE MODAL --}}
<div class="modal fade" id="applyLeaveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    Apply Permanent Staff Leave
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form>

                @csrf

                <div class="modal-body">

                    <div class="row g-3">

                        <div class="col-12">

                            <label class="form-label small fw-bold">
                                Employee
                            </label>

                            <select name="employee_id" class="select3 form-select" required>

                                <option value="">
                                    Select Employee
                                </option>

                                @foreach($permanentEmployees as $employee)

                                <option value="{{ $employee['id'] }}">
                                    {{ $employee['name'] }}
                                    - {{ $employee['role'] }}
                                </option>

                                @endforeach

                            </select>

                        </div>


                        <div class="col-12">
                            <label class="form-label small fw-bold">
                                Leave Type
                            </label>
                            <select name="leave_type" class="form-select form-select-sm" required>
                                <option value="">
                                    Select Leave Type
                                </option>
                                <option value="Casual">
                                    Casual Leave
                                </option>
                                <option value="Privilege">
                                    Privilege Leave
                                </option>
                                <option value="Sick">
                                    Sick Leave
                                </option>
                            </select>
                        </div>


                        <div class="col-6">
                            <label class="form-label small fw-bold">
                                From Date
                            </label>
                            <input type="date" name="start_date" class="form-control form-control-sm" required>
                        </div>


                        <div class="col-6">
                            <label class="form-label small fw-bold">
                                To Date
                            </label>
                            <input type="date" name="end_date" class="form-control form-control-sm" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label small fw-bold">
                                Reason / Remarks
                            </label>
                            <textarea name="reason" rows="3" class="form-control form-control-sm"
                                placeholder="Enter leave reason..."></textarea>
                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary btn-sm">

                        <i class="mdi mdi-check me-1"></i>
                        Submit Leave

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


{{-- LEAVE SETTINGS MODAL--}}
<div class="modal fade" id="leaveSettingsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    Permanent Staff Leave Policy
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-12 col-sm-4">
                        <label class="form-label small fw-bold">
                            Casual Leave
                        </label>
                        <input type="number" class="form-control form-control-sm" value="12">
                        <small class="text-muted">
                            Days / Year
                        </small>
                    </div>
                    <div class="col-12 col-sm-4">
                        <label class="form-label small fw-bold">
                            Privilege Leave
                        </label>
                        <input type="number" class="form-control form-control-sm" value="15">

                        <small class="text-muted">
                            Days / Year
                        </small>

                    </div>

                    <div class="col-12 col-sm-4">

                        <label class="form-label small fw-bold">
                            Sick Leave
                        </label>

                        <input type="number" class="form-control form-control-sm" value="10">

                        <small class="text-muted">
                            Days / Year
                        </small>

                    </div>

                </div>

            </div>

            <div class="modal-footer">

                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" class="btn btn-primary btn-sm">
                    Save Settings
                </button>

            </div>

        </div>

    </div>

</div>


<style>
/* LEAVE MANAGEMENT */

.leave-kpi-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    font-size: 20px;
}

.leave-kpi-label {
    font-size: 9px;
    letter-spacing: .5px;
    line-height: 1.4;
}

.leave-kpi-value {
    font-size: 18px;
    line-height: 1.3;
    margin-top: 2px;
}

.leave-kpi-description {
    font-size: 9px;
    margin-top: 2px;
}

.leave-reason {
    max-width: 180px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}


/* RESPONSIVE */
@media (max-width: 767.98px) {
    .leave-kpi-value {
        font-size: 16px;
    }

    .leave-kpi-description {
        font-size: 8px;
    }

    .table {
        min-width: 900px;
    }
}
</style>

<script>
(function () {
  'use strict';
  const type='contract', base='/admin-hr/api/leave/'+type, csrf=document.querySelector('meta[name="csrf-token"]')?.content||'';
  const state={page:1,perPage:10,search:'',year:new Date().getFullYear()};
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function request(url,opts={}){const r=await fetch(url,{credentials:'same-origin',...opts,headers:{Accept:'application/json','X-Requested-With':'XMLHttpRequest','X-CSRF-TOKEN':csrf,...(opts.headers||{})}});let j={};try{j=await r.json()}catch(_){}if(!r.ok||j.success===false)throw Error(j.message||Object.values(j.errors||{}).flat()[0]||'Request failed');return j;}
  function params(extra={}){const q=new URLSearchParams({page:state.page,per_page:state.perPage,search:state.search,...extra});return q.toString();}
  function addPager(table,meta,kind){let box=document.getElementById(kind+'-ajax-pager');if(!box){box=document.createElement('div');box.id=kind+'-ajax-pager';box.className='d-flex flex-wrap justify-content-between align-items-center gap-2 p-3';table.parentElement.appendChild(box);}box.innerHTML='<small class="text-muted">'+Number(meta.total||0)+' records · Page '+Number(meta.current_page||1)+' of '+Number(meta.last_page||1)+'</small><div class="d-flex gap-2 align-items-center"><select class="form-select form-select-sm" id="'+kind+'PageSize" style="width:82px"><option>10</option><option>25</option><option>50</option><option>100</option></select><button class="btn btn-sm btn-outline-secondary" id="'+kind+'Prev" '+(meta.current_page<=1?'disabled':'')+'>Previous</button><button class="btn btn-sm btn-outline-secondary" id="'+kind+'Next" '+(meta.current_page>=meta.last_page?'disabled':'')+'>Next</button></div>';const select=box.querySelector('select');select.value=String(meta.per_page||state.perPage);select.onchange=()=>{state.perPage=Number(select.value);state.page=1;loadRequests();};box.querySelector('#'+kind+'Prev').onclick=()=>{state.page=Math.max(1,state.page-1);loadRequests();};box.querySelector('#'+kind+'Next').onclick=()=>{state.page=Math.min(Number(meta.last_page||1),state.page+1);loadRequests();};}
  async function loadRequests(){const table=document.getElementById('leave-requests-table');if(!table)return;const body=table.tBodies[0];body.innerHTML='<tr><td colspan="7" class="py-4"><span class="placeholder col-12"></span><span class="placeholder col-8"></span></td></tr>';try{const j=await request(base+'?'+params());body.innerHTML=(j.data||[]).map(x=>'<tr><td><strong>'+esc(x.staff_name)+'</strong><small class="d-block text-muted">'+esc(x.staff_code)+'</small></td><td>'+esc(x.leave_type)+'</td><td>'+esc(x.from_date)+' – '+esc(x.to_date)+'</td><td>'+esc(x.days)+'</td><td>'+esc((x.created_at||'').slice(0,10))+'</td><td>'+esc(x.reason)+'</td><td><span class="badge bg-light text-dark">'+esc(x.approval_status)+'</span>'+(x.approval_status==='Pending'?'<div class="btn-group btn-group-sm mt-1"><button class="btn btn-outline-success leave-review" data-id="'+esc(x.id)+'" data-status="Approved">Approve</button><button class="btn btn-outline-danger leave-review" data-id="'+esc(x.id)+'" data-status="Rejected">Reject</button></div>':'')+'</td></tr>').join('')||'<tr><td colspan="7" class="text-center text-muted py-4">No leave requests found.</td></tr>';addPager(table,j.meta||{},'leaveReq');}catch(e){body.innerHTML='<tr><td colspan="7" class="text-danger text-center py-4">'+esc(e.message)+'</td></tr>';}}


  async function loadStaffOptions(){
    const selects=[...document.querySelectorAll('#applyLeaveModal select[name="employee_id"],#applyLeaveModal select[name="staff_id"]')];
    if(!selects.length)return;
    try{const j=await request('/admin-hr/api/staff/'+type+'?per_page=100&sort=name&direction=asc');const options=(j.data||[]).map(x=>'<option value="'+esc(x.id)+'">'+esc(x.name)+' · '+esc(x.staff_id||'')+'</option>').join('');selects.forEach(select=>{const prior=select.value;select.innerHTML='<option value="">Select Staff</option>'+options;select.value=prior;});}
    catch(error){console.error('Could not load staff list for leave request:',error.message);}
  }
  function initLeaveDirectory(){
    const search=document.querySelector('.leave-kpi-scroll ~ .leave-search-box input,.leave-search-box input');let timer;if(search)search.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>{state.search=search.value.trim();state.page=1;loadRequests();},300);});
    document.addEventListener('click',async e=>{const b=e.target.closest('.leave-review');if(b){if(!confirm(b.dataset.status+' this leave request?'))return;try{await request('/admin-hr/api/leave/'+type+'/'+b.dataset.id+'/review',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({approval_status:b.dataset.status})});await loadRequests();}catch(err){alert(err.message);}}});
    const forms=[...document.querySelectorAll('#applyLeaveModal form')];for(const form of forms){form.addEventListener('submit',async e=>{if(!form.querySelector('[name="employee_id"],[name="staff_id"]'))return;e.preventDefault();const fd=new FormData(form),staffId=fd.get('staff_id')||fd.get('employee_id');const payload={staff_id:staffId,leave_type:fd.get('leave_type'),from_date:fd.get('from_date')||fd.get('start_date'),to_date:fd.get('to_date')||fd.get('end_date'),reason:fd.get('reason')||'Admin-created leave request'};try{const j=await request(base,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});alert(j.message||'Leave submitted');bootstrap.Modal.getInstance(form.closest('.modal'))?.hide();form.reset();state.page=1;loadRequests();}catch(err){alert(err.message);}});}
    loadStaffOptions();
    loadRequests();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initLeaveDirectory,{once:true});else initLeaveDirectory();
})();
</script>
@endsection