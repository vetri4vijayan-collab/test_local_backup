@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('content')

@php
/*
|--------------------------------------------------------------------------
| MONTH / YEAR
|--------------------------------------------------------------------------
| You can replace these with values coming from your controller:
|
| $selectedMonth = request('month', now()->month);
| $selectedYear = request('year', now()->year);
|
*/
$selectedMonth = request('month', now()->month);
$selectedYear = request('year', now()->year);

$monthStart = \Carbon\Carbon::create($selectedYear, $selectedMonth, 1);
$daysInMonth = $monthStart->daysInMonth;
$monthName = $monthStart->format('F');
$year = $monthStart->format('Y');

$departments = [
'ALL',
'Management',
'Engineering',
'Quality Control',
'Accounts',
'Purchase',
'Skilled Labor',
'General Labor'
];

$holidays = [
'2026-01-26' => 'Republic Day',
'2026-05-01' => 'May Day',
'2026-08-15' => 'Independence Day',
'2026-10-02' => 'Gandhi Jayanti',
'2026-12-25' => 'Christmas',
];
@endphp


<div class="container-fluid px-0">

    {{-- ============================================================
        SUMMARY CARDS
    ============================================================= --}}

    <div class="row g-3 mb-4">

        {{-- Permanent Pool --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary summary-label">
                        Permanent Pool
                    </span>

                    <span id="totalStaff" class="d-block fw-bold font-monospace summary-value" style="color:#0C3C62;">
                        10 Staff
                    </span>
                </div>
            </div>
        </div>

        {{-- Present --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-success summary-label">
                        Checked In (Present)
                    </span>

                    <span id="presentCount" class="d-block fw-bold font-monospace summary-value text-success">
                        0 Present
                    </span>
                </div>
            </div>
        </div>

        {{-- Absent --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-danger summary-label">
                        Unexcused Absences
                    </span>

                    <span id="absentCount" class="d-block fw-bold font-monospace summary-value text-danger">
                        0 Absent
                    </span>
                </div>
            </div>
        </div>

        {{-- Leave --}}
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-warning summary-label">
                        Sabbatical & Leaves
                    </span>

                    <span id="leaveCount" class="d-block fw-bold font-monospace summary-value text-warning">
                        0 On Leave
                    </span>
                </div>
            </div>
        </div>

    </div>


    {{-- ============================================================
        STAFF HEADER + VIEW SWITCH
    ============================================================= --}}

    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="d-flex flex-column flex-md-row
                    justify-content-between
                    align-items-start
                    align-items-md-center
                    gap-3">

                {{-- TITLE --}}
                <div class="w-100 w-md-auto">
                    <div class="px-3 py-2 bg-white">

                        <span class="fw-bold" style="font-size:20px;color:#0C3C62;">
                            Contract Staff
                        </span>

                    </div>
                </div>


                {{-- VIEW SWITCH --}}
                <div class="d-flex justify-content-start justify-content-md-end w-100 w-md-auto">
    <div class="btn-group responsive-view-buttons" role="group">

        {{-- LIST --}}
        <a href="{{ url('/admin-hr/contract-log') }}"
           class="btn btn-sm btn-outline-primary
           {{ request()->is('admin-hr/contract-log') ? 'active' : '' }}">
            <span class="mdi mdi-format-list-bulleted me-1"></span>
            List View
        </a>

        {{-- TABLE --}}
        <a href="{{ url('/admin-hr/contract-log/table') }}"
           class="btn btn-sm btn-outline-primary
           {{ request()->is('admin-hr/contract-log/table') ? 'active' : '' }}">
            <span class="mdi mdi-table me-1"></span>
            Table View
        </a>

        {{-- CALENDAR --}}
        <a href="{{ url('/admin-hr/contract-log/calender') }}"
           class="btn btn-sm btn-outline-primary
           {{ request()->is('admin-hr/contract-log/calender') ? 'active' : '' }}">
            <span class="mdi mdi-calendar-month me-1"></span>
            Calendar View
        </a>

    </div>
</div>

            </div>

        </div>

    </div>



    {{--  MONTH / FILTER HEADER --}}

    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="d-flex flex-column flex-lg-row
                        justify-content-between
                        align-items-lg-center
                        gap-3">

                {{-- MONTH INFORMATION --}}
                <div>

                    <h5 class="mb-1 fw-bold" style="color:#0C3C62;">

                        Monthly Attendance Matrix —
                        {{ $monthName }} {{ $year }}

                    </h5>

                    <p class="mb-0 text-muted" style="font-size:10px;">

                        Interactive attendance ledger.
                        Click any working-day cell to change
                        Present / Absent / Leave status.

                    </p>

                </div>


                {{-- MONTH SELECTOR --}}
                <div class="d-flex align-items-center gap-2">

                    <label class="mb-0 fw-bold text-secondary" style="font-size:10px;">
                        Month
                    </label>

                    <select id="monthSelector" name="month" class="form-select form-select-sm" style="width: 140px;">

                        @for($m = 1; $m <= 12; $m++) <option value="{{ $m }}"
                            {{ $selectedMonth == $m ? 'selected' : '' }}>
                            {{ \Carbon\Carbon::create()->month($m)->format('F') }}
                            </option>
                            @endfor

                    </select>


                    <select id="yearSelector" class="form-select form-select-sm" style="width:90px;">

                        @for($y = now()->year - 2; $y <= now()->year + 2; $y++)

                            <option value="{{ $y }}" {{ $selectedYear == $y ? 'selected' : '' }}>

                                {{ $y }}

                            </option>

                            @endfor

                    </select>

                    <button type="button" id="changeMonthBtn" class="btn btn-sm btn-primary">

                        <i class="mdi mdi-calendar-search me-1"></i>
                        View

                    </button>

                </div>

            </div>

        </div>

    </div>



    {{-- ============================================================
        DEPARTMENT FILTER
    ============================================================= --}}

    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-3">

            <div class="attendance-filter-row">

                {{-- SEARCH --}}
                <div class="attendance-search">

                    <div class="position-relative">

                        <span class="position-absolute top-50 start-0
                                     translate-middle-y ps-2 text-muted" style="pointer-events:none;">

                            <i class="mdi mdi-magnify"></i>

                        </span>

                        <input id="employeeSearch" type="text" class="form-control form-control-sm
                                      ps-5 bg-light border-0 rounded-3" placeholder="Search personnel...">

                    </div>

                </div>


                {{-- DEPARTMENTS --}}
                <div class="attendance-departments">

                    <div class="department-scroll">

                        @foreach($departments as $department)

                        <button type="button" class="btn btn-sm dept-filter-btn
                                    {{ $department === 'ALL' ? 'active' : '' }}" data-department="{{ $department }}">

                            {{ $department === 'ALL' ? 'All' : $department }}

                        </button>

                        @endforeach

                    </div>

                </div>

            </div>

        </div>

    </div>



    {{-- ============================================================
        ATTENDANCE MATRIX
    ============================================================= --}}

    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-0">

            <div class="attendance-table-wrapper">

                <table class="attendance-matrix">

                    <thead>

                        <tr>

                            {{-- EMPLOYEE --}}
                            <th class="employee-column">

                                Personnel Information

                            </th>


                            {{-- DAYS ARE GENERATED FROM PHP --}}
                            @for($day = 1; $day <= $daysInMonth; $day++) @php $date=\Carbon\Carbon::create(
                                $selectedYear, $selectedMonth, $day ); $isSunday=$date->isSunday();
                                @endphp

                                <th class="day-column
                                    {{ $isSunday ? 'sunday-column' : '' }}">

                                    <div class="day-number">
                                        {{ $day }}
                                    </div>

                                    <div class="day-name">
                                        {{ $date->format('D') }}
                                    </div>

                                </th>

                                @endfor

                        </tr>

                    </thead>


                    <tbody id="attendanceBody">


                        {{-- =================================================
                            EMPLOYEE 1
                        ================================================== --}}

                        <tr data-department="Management" data-employee="Arun Kumar">

                            <td class="employee-column employee-cell">

                                <div class="employee-info">

                                    <div class="employee-avatar">
                                        <i class="mdi mdi-account"></i>
                                    </div>

                                    <div>

                                        <div class="employee-name">
                                            Arun Kumar
                                        </div>

                                        <div class="employee-code">
                                            SRK-EMP-001 • Project Manager
                                        </div>

                                    </div>

                                </div>

                            </td>


                            @for($day = 1; $day <= $daysInMonth; $day++) @php $date=\Carbon\Carbon::create(
                                $selectedYear, $selectedMonth, $day ); $isSunday=$date->isSunday();

                                /*
                                * Sample initial attendance.
                                * You can replace this with DB data later.
                                */
                                $dateKey = $date->format('Y-m-d');

                                if ($isSunday) {
                                $status = 'Rest';
                                } elseif (isset($holidays[$dateKey])) {
                                $status = 'Holiday';
                                } elseif ($day % 7 == 0) {
                                $status = 'Absent';
                                } else {
                                $status = 'Present';
                                }
                                @endphp

                                <td class="attendance-cell
                                  {{ $isSunday ? 'rest-cell' : '' }}
                                  {{ $status === 'Holiday' ? 'holiday-cell' : '' }}" data-status="{{ $status }}"
                                    data-employee="Arun Kumar" data-date="{{ $date->format('Y-m-d') }}">

                                    @if($status === 'Present')

                                    <span class="attendance-badge present">
                                        P
                                    </span>

                                    <div class="attendance-time">
                                        09:00
                                        <br>
                                        18:00
                                    </div>

                                    @elseif($status === 'Absent')

                                    <span class="attendance-badge absent">
                                        A
                                    </span>

                                    <div class="attendance-dash">
                                        —
                                    </div>

                                    @elseif($status === 'Rest')

                                    <span class="attendance-badge rest">
                                        R
                                    </span>

                                    <div class="attendance-dash">
                                        Rest
                                    </div>

                                    @endif

                                </td>

                                @endfor

                        </tr>



                        {{-- =================================================
                            EMPLOYEE 2
                        ================================================== --}}

                        <tr data-department="Engineering" data-employee="Suresh Raj">

                            <td class="employee-column employee-cell">

                                <div class="employee-info">

                                    <div class="employee-avatar">
                                        <i class="mdi mdi-account"></i>
                                    </div>

                                    <div>

                                        <div class="employee-name">
                                            Suresh Raj
                                        </div>

                                        <div class="employee-code">
                                            SRK-EMP-002 • Civil Engineer
                                        </div>

                                    </div>

                                </div>

                            </td>


                            @for($day = 1; $day <= $daysInMonth; $day++) @php $date=\Carbon\Carbon::create(
                                $selectedYear, $selectedMonth, $day ); $isSunday=$date->isSunday();

                                $dateKey = $date->format('Y-m-d');

                                if ($isSunday) {
                                $status = 'Rest';
                                } elseif (isset($holidays[$dateKey])) {
                                $status = 'Holiday';
                                } elseif ($day % 6 == 0) {
                                $status = 'On Leave';
                                } elseif ($day % 8 == 0) {
                                $status = 'Absent';
                                } else {
                                $status = 'Present';
                                }
                                @endphp

                                <td class="attendance-cell
                                    {{ $isSunday ? 'rest-cell' : '' }}" data-status="{{ $status }}"
                                    data-employee="Suresh Raj" data-date="{{ $date->format('Y-m-d') }}">

                                    @if($status === 'Present')

                                    <span class="attendance-badge present">
                                        P
                                    </span>

                                    <div class="attendance-time">
                                        09:15
                                        <br>
                                        18:10
                                    </div>

                                    @elseif($status === 'Absent')

                                    <span class="attendance-badge absent">
                                        A
                                    </span>

                                    <div class="attendance-dash">
                                        —
                                    </div>

                                    @elseif($status === 'On Leave')

                                    <span class="attendance-badge leave">
                                        L
                                    </span>

                                    <div class="attendance-dash">
                                        Leave
                                    </div>

                                    @elseif($status === 'Rest')

                                    <span class="attendance-badge rest">
                                        R
                                    </span>

                                    <div class="attendance-dash">
                                        Rest
                                    </div>

                                    @endif

                                </td>

                                @endfor

                        </tr>



                        {{-- =================================================
                            EMPLOYEE 3
                        ================================================== --}}

                        <tr data-department="General Labor" data-employee="Priya Devi">

                            <td class="employee-column employee-cell">

                                <div class="employee-info">

                                    <div class="employee-avatar">
                                        <i class="mdi mdi-account"></i>
                                    </div>

                                    <div>

                                        <div class="employee-name">
                                            Priya Devi
                                        </div>

                                        <div class="employee-code">
                                            SRK-EMP-003 • Supervisor
                                        </div>

                                    </div>

                                </div>

                            </td>


                            @for($day = 1; $day <= $daysInMonth; $day++) @php $date=\Carbon\Carbon::create(
                                $selectedYear, $selectedMonth, $day ); $isSunday=$date->isSunday();

                                $dateKey = $date->format('Y-m-d');

                                if ($isSunday) {
                                $status = 'Rest';
                                } elseif (isset($holidays[$dateKey])) {
                                $status = 'Holiday';
                                } elseif ($day % 5 == 0) {
                                $status = 'On Leave';
                                } else {
                                $status = 'Present';
                                }
                                @endphp

                                <td class="attendance-cell
                                    {{ $isSunday ? 'rest-cell' : '' }}" data-status="{{ $status }}"
                                    data-employee="Priya Devi" data-date="{{ $date->format('Y-m-d') }}">

                                    @if($status === 'Present')

                                    <span class="attendance-badge present">
                                        P
                                    </span>

                                    <div class="attendance-time">
                                        08:50
                                        <br>
                                        17:45
                                    </div>

                                    @elseif($status === 'On Leave')

                                    <span class="attendance-badge leave">
                                        L
                                    </span>

                                    <div class="attendance-dash">
                                        Leave
                                    </div>
                                    @elseif($status === 'Rest')

                                    <span class="attendance-badge rest">
                                        R
                                    </span>

                                    <div class="attendance-dash">
                                        Rest
                                    </div>

                                    @elseif($status === 'Holiday')

                                    <span class="attendance-badge holiday">
                                        H
                                    </span>

                                    <div class="attendance-dash">
                                        Holiday
                                    </div>

                                    @endif

                                </td>

                                @endfor

                        </tr>


                    </tbody>

                </table>

            </div>

        </div>


        {{-- ============================================================
            LEGEND
        ============================================================= --}}

        <div class="card-footer bg-light border-0">

            <div class="d-flex flex-wrap align-items-center gap-4">

                <div class="legend-item">

                    <span class="attendance-badge present">
                        P
                    </span>

                    <span>Present</span>

                </div>


                <div class="legend-item">

                    <span class="attendance-badge absent">
                        A
                    </span>

                    <span>Absent</span>

                </div>


                <div class="legend-item">

                    <span class="attendance-badge leave">
                        L
                    </span>

                    <span>On Leave</span>

                </div>


                <div class="legend-item">

                    <span class="attendance-badge rest">
                        R
                    </span>

                    <span>Rest / Sunday</span>

                </div>

                <div class="legend-item">

                    <span class="attendance-badge holiday">
                        H
                    </span>

                    <span>Holiday</span>

                </div>


                <span class="text-muted small">
                    Click any non-rest cell to modify attendance.
                </span>

            </div>

        </div>

    </div>

</div>



{{-- ================================================================
    ATTENDANCE MODAL
================================================================ --}}

<div class="modal fade" id="attendanceModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content border-0 shadow-lg rounded-4">

            <div class="modal-header" style="background:#16659E;color:white;">

                <div>

                    <h6 class="mb-1 fw-bold">
                        Update Daily Attendance
                    </h6>

                    <small id="modalDate">
                        -
                    </small>

                </div>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal">
                </button>

            </div>


            <div class="modal-body p-4">

                {{-- EMPLOYEE --}}
                <div class="bg-light rounded-3 p-3 mb-4">

                    <div class="d-flex align-items-center gap-3">

                        <div class="employee-avatar">
                            <i class="mdi mdi-account"></i>
                        </div>

                        <div>

                            <div id="modalEmployee" class="fw-bold text-dark">
                                -
                            </div>

                            <small id="modalEmployeeCode" class="text-muted">
                                -
                            </small>

                        </div>

                    </div>

                </div>


                {{-- STATUS --}}
                <label class="form-label fw-bold small">
                    Attendance Status
                </label>

                <div class="row g-2 mb-4">

                    <div class="col-4">

                        <button type="button" class="status-select-btn present-option" data-status="Present">

                            <span class="attendance-badge present">
                                P
                            </span>

                            <span>Present</span>

                        </button>

                    </div>


                    <div class="col-4">

                        <button type="button" class="status-select-btn absent-option" data-status="Absent">

                            <span class="attendance-badge absent">
                                A
                            </span>

                            <span>Absent</span>

                        </button>

                    </div>


                    <div class="col-4">

                        <button type="button" class="status-select-btn leave-option" data-status="On Leave">

                            <span class="attendance-badge leave">
                                L
                            </span>

                            <span>Leave</span>

                        </button>

                    </div>

                    {{-- LEAVE TYPE --}}
                    <div id="leaveTypeSection" class="mb-4" style="display:none;">

                        <label class="form-label fw-bold small">
                            Leave Type
                        </label>

                        <div class="row g-2">

                            {{-- CASUAL LEAVE --}}
                            <div class="col-12 col-md-4">

                                <button type="button" class="leave-type-btn" data-leave-type="Casual Leave">

                                    <i class="mdi mdi-calendar-outline"></i>

                                    <span>Casual Leave</span>

                                </button>

                            </div>


                            {{-- PAID LEAVE --}}
                            <div class="col-12 col-md-4">

                                <button type="button" class="leave-type-btn" data-leave-type="Paid Leave">

                                    <i class="mdi mdi-cash-check"></i>

                                    <span>Paid Leave</span>

                                </button>

                            </div>


                            {{-- SICK LEAVE --}}
                            <div class="col-12 col-md-4">

                                <button type="button" class="leave-type-btn" data-leave-type="Sick Leave">

                                    <i class="mdi mdi-medical-bag"></i>

                                    <span>Sick Leave</span>

                                </button>

                            </div>

                        </div>

                    </div>
                </div>


                {{-- TIME --}}
                <div id="timeSection" class="row g-3 bg-light rounded-3 p-3">

                    <div class="col-6">

                        <label class="form-label small fw-bold">
                            In Time
                        </label>

                        <input type="time" id="inTime" class="form-control form-control-sm" value="09:00">

                    </div>


                    <div class="col-6">

                        <label class="form-label small fw-bold">
                            Out Time
                        </label>

                        <input type="time" id="outTime" class="form-control form-control-sm" value="18:00">

                    </div>

                </div>

            </div>


            <div class="modal-footer bg-light border-0">

                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button" id="saveAttendance" class="btn btn-sm text-white" style="background:#16659E;">

                    Apply & Close

                </button>

            </div>

        </div>

    </div>

</div>



{{-- ================================================================
    CSS
================================================================ --}}

<style>
.summary-label {
    font-size: 9px;
    letter-spacing: .5px;
}

.summary-value {
    font-size: 1.25rem;
    margin-top: 4px;
}


/* FILTER */

.attendance-filter-row {
    display: flex;
    align-items: center;
    gap: 10px;
}

.attendance-search {
    width: 200px;
    flex-shrink: 0;
}

.attendance-departments {
    flex: 1;
    min-width: 0;
}

.department-scroll {
    display: flex;
    gap: 5px;
    overflow-x: auto;
    scrollbar-width: none;
}

.department-scroll::-webkit-scrollbar {
    display: none;
}

.dept-filter-btn {
    flex: 0 0 auto;
    background: #f8fafc;
    color: #475569;
    border: 1px solid transparent;
    font-size: 10px;
    padding: 7px 12px;
}

.dept-filter-btn:hover {
    background: #e2e8f0;
}

.dept-filter-btn.active {
    background: #16659E !important;
    color: white !important;
    border-color: #16659E;
}



/* ================================================================
   ATTENDANCE TABLE
================================================================ */

.attendance-table-wrapper {
    width: 100%;
    overflow-x: auto;
    overflow-y: auto;
    max-height: 650px;
}

.attendance-matrix {
    width: max-content;
    min-width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 11px;
}

.attendance-matrix th,
.attendance-matrix td {
    border-right: 1px solid #e2e8f0;
    border-bottom: 1px solid #e2e8f0;
}


/* HEADER */

.attendance-matrix thead th {
    background: #f8fafc;
    height: 55px;
    text-align: center;
    vertical-align: middle;
    position: sticky;
    top: 0;
    z-index: 20;
}

.employee-column {
    width: 230px;
    min-width: 230px;
    max-width: 230px;
}

.attendance-matrix thead .employee-column {
    text-align: left;
    padding-left: 18px;
    z-index: 40;
    left: 0;
}


.day-column {
    width: 58px;
    min-width: 58px;
    max-width: 58px;
}

.day-number {
    font-weight: 800;
    font-size: 11px;
    color: #334155;
}

.day-name {
    font-size: 8px;
    color: #94a3b8;
    font-weight: 700;
    text-transform: uppercase;
    margin-top: 2px;
}


/* SUNDAY */

.sunday-column {
    background: #fff1f2 !important;
    color: #e11d48;
}


/* EMPLOYEE CELL */

.employee-cell {
    position: sticky;
    left: 0;
    z-index: 10;
    background: white;
    padding: 12px 18px;
}

.employee-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.employee-avatar {
    width: 36px;
    height: 36px;
    min-width: 36px;
    border-radius: 50%;
    background: #f1f5f9;
    color: #475569;
    display: flex;
    align-items: center;
    justify-content: center;
}

.employee-name {
    font-weight: 800;
    color: #0f172a;
    font-size: 11px;
}

.employee-code {
    color: #94a3b8;
    font-size: 8px;
    margin-top: 2px;
}


/* ATTENDANCE CELL */

.attendance-cell {
    width: 58px;
    min-width: 58px;
    height: 70px;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    background: white;
    transition: all .15s ease;
}

.attendance-cell:hover {
    background: #f8fafc;
}

.attendance-cell.rest-cell {
    cursor: default;
    background: #f8fafc;
}


/* BADGES */

.attendance-badge {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 9px;
    font-weight: 900;
}

.attendance-badge.present {
    background: #10b981;
    color: white;
}

.attendance-badge.absent {
    background: #ef4444;
    color: white;
}

.attendance-badge.leave {
    background: #fbbf24;
    color: #422006;
}

.attendance-badge.holiday {
    background: #8b5cf6;
    color: white;
}

.attendance-cell.holiday-cell {
    background: #f5f3ff;
    cursor: default;
}

.attendance-cell.holiday-cell:hover {
    background: #ede9fe;
}

.attendance-badge.rest {
    background: #e2e8f0;
    color: #64748b;
}


.attendance-time {
    font-size: 7px;
    line-height: 1.3;
    color: #64748b;
    margin-top: 3px;
    font-family: monospace;
}

.attendance-dash {
    font-size: 7px;
    color: #cbd5e1;
    margin-top: 3px;
    font-family: monospace;
}


/* LEGEND */

.legend-item {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 10px;
    font-weight: 600;
    color: #64748b;
}


/* MODAL STATUS BUTTON */

.status-select-btn {
    width: 100%;
    border: 1px solid #e2e8f0;
    background: white;
    border-radius: 10px;
    padding: 10px 5px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 5px;
    font-size: 10px;
    font-weight: 700;
    color: #64748b;
    transition: .2s;
}

.status-select-btn:hover {
    background: #f8fafc;
}

.status-select-btn.active {
    box-shadow: 0 0 0 2px #16659E;
}

.leave-type-btn {
    width: 100%;
    min-height: 75px;
    border: 1px solid #e2e8f0;
    background: white;
    border-radius: 10px;
    padding: 10px 5px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    font-size: 10px;
    font-weight: 700;
    color: #64748b;
    transition: all .2s ease;
}

.leave-type-btn i {
    font-size: 18px;
    color: #f59e0b;
}

.leave-type-btn:hover {
    background: #fffbeb;
    border-color: #fbbf24;
}

.leave-type-btn.active {
    background: #fffbeb;
    border-color: #f59e0b;
    color: #92400e;
    box-shadow: 0 0 0 2px rgba(245, 158, 11, .15);
}

/* MOBILE */

@media(max-width:767px) {

    .attendance-filter-row {
        flex-direction: column;
        align-items: stretch;
    }

    .attendance-search {
        width: 100%;
    }

    .employee-column {
        width: 190px;
        min-width: 190px;
        max-width: 190px;
    }

    .day-column,
    .attendance-cell {
        width: 52px;
        min-width: 52px;
        max-width: 52px;
    }

}

/* ===============================
   RESPONSIVE VIEW SWITCH
================================ */

.responsive-view-buttons {
    white-space: nowrap;
}

/* Tablet */
@media (max-width: 991.98px) {

    .responsive-view-buttons .btn {
        padding-left: 10px !important;
        padding-right: 10px !important;
        font-size: 11px;
    }

}

/* Mobile */
@media (max-width: 575.98px) {

    .responsive-view-buttons {
        width: 100%;
        display: flex;
    }

    .responsive-view-buttons .btn {
        flex: 1 1 0;
        padding: 8px 5px !important;
        font-size: 10px;
        white-space: nowrap;
    }

    .responsive-view-buttons .mdi {
        margin-right: 2px !important;
    }

}

/* Very small mobile */
@media (max-width: 400px) {

    .responsive-view-buttons .btn {
        padding: 7px 3px !important;
        font-size: 9px;
    }

    .responsive-view-buttons .mdi {
        display: none;
    }

}
</style>



{{-- ================================================================
    JAVASCRIPT
================================================================ --}}

<script>
document.addEventListener('DOMContentLoaded', function() {

    /* ============================================================
       VARIABLES
    ============================================================ */

    let selectedCell = null;
    let selectedLeaveType = null;

    const attendanceModalElement =
        document.getElementById('attendanceModal');

    const attendanceModal =
        new bootstrap.Modal(attendanceModalElement);

    const monthSelector =
        document.getElementById('monthSelector');

    const yearSelector =
        document.getElementById('yearSelector');

    const changeMonthBtn =
        document.getElementById('changeMonthBtn');

    const employeeSearch =
        document.getElementById('employeeSearch');

    const attendanceBody =
        document.getElementById('attendanceBody');

    const saveAttendance =
        document.getElementById('saveAttendance');

    const timeSection =
        document.getElementById('timeSection');

    const leaveTypeSection =
        document.getElementById('leaveTypeSection');

    const inTime =
        document.getElementById('inTime');

    const outTime =
        document.getElementById('outTime');


    /* ============================================================
       MONTH / YEAR
    ============================================================ */

    if (changeMonthBtn) {

        changeMonthBtn.addEventListener('click', function() {

            const month = monthSelector.value;
            const year = yearSelector.value;

            window.location.href =
                "{{ url('/admin-hr/permanent-log/table') }}" +
                "?month=" + encodeURIComponent(month) +
                "&year=" + encodeURIComponent(year);

        });

    }


    /* ============================================================
       HELPER - SHOW / HIDE TIME
    ============================================================ */

    function showTimeSection(show) {

        timeSection.style.display =
            show ? 'flex' : 'none';

    }


    /* ============================================================
       HELPER - SHOW / HIDE LEAVE TYPE
    ============================================================ */

    function showLeaveTypeSection(show) {

        leaveTypeSection.style.display =
            show ? 'block' : 'none';

    }


    /* ============================================================
       HELPER - CLEAR LEAVE TYPE
    ============================================================ */

    function clearLeaveTypeSelection() {

        selectedLeaveType = null;

        document.querySelectorAll('.leave-type-btn')
            .forEach(function(button) {

                button.classList.remove('active');

            });

    }


    /* ============================================================
       HELPER - SET ACTIVE STATUS
    ============================================================ */

    function setActiveStatus(status) {

        document.querySelectorAll('.status-select-btn')
            .forEach(function(button) {

                button.classList.remove('active');

                if (button.dataset.status === status) {
                    button.classList.add('active');
                }

            });

    }


    /* ============================================================
       ATTENDANCE CELL CLICK
    ============================================================ */

    document.querySelectorAll('.attendance-cell')
        .forEach(function(cell) {

            cell.addEventListener('click', function() {

                const status = cell.dataset.status;

                /*
                 * Sunday / Holiday cannot be edited
                 */
                if (
                    status === 'Rest' ||
                    status === 'Holiday'
                ) {
                    return;
                }


                selectedCell = cell;

                const employee =
                    cell.dataset.employee || '-';

                const date =
                    cell.dataset.date || '';

                selectedLeaveType =
                    cell.dataset.leaveType || null;


                /* ------------------------------------------------
                   EMPLOYEE NAME
                ------------------------------------------------ */

                document.getElementById('modalEmployee')
                    .innerText = employee;


                /* ------------------------------------------------
                   EMPLOYEE CODE / DESIGNATION
                ------------------------------------------------ */

                const row = cell.closest('tr');

                const employeeCodeElement =
                    row ?
                    row.querySelector('.employee-code') :
                    null;

                document.getElementById('modalEmployeeCode')
                    .innerText =
                    employeeCodeElement ?
                    employeeCodeElement.innerText.trim() :
                    '';


                /* ------------------------------------------------
                   DATE
                ------------------------------------------------ */

                document.getElementById('modalDate')
                    .innerText = formatDate(date);


                /* ------------------------------------------------
                   ACTIVE STATUS
                ------------------------------------------------ */

                setActiveStatus(status);


                /* ------------------------------------------------
                   PRESENT
                ------------------------------------------------ */

                if (status === 'Present') {

                    showTimeSection(true);
                    showLeaveTypeSection(false);

                    /*
                     * Read existing attendance time if available
                     */
                    const timeElement =
                        cell.querySelector('.attendance-time');

                    if (timeElement) {

                        const times =
                            timeElement.innerText
                            .trim()
                            .split(/\s+/);

                        if (times[0]) {
                            inTime.value = times[0];
                        }

                        if (times[1]) {
                            outTime.value = times[1];
                        }

                    }

                    clearLeaveTypeSelection();

                }


                /* ------------------------------------------------
                   ON LEAVE
                ------------------------------------------------ */
                else if (status === 'On Leave') {

                    showTimeSection(false);
                    showLeaveTypeSection(true);


                    document.querySelectorAll('.leave-type-btn')
                        .forEach(function(button) {

                            button.classList.remove('active');

                            if (
                                button.dataset.leaveType ===
                                selectedLeaveType
                            ) {

                                button.classList.add('active');

                            }

                        });

                }


                /* ------------------------------------------------
                   ABSENT
                ------------------------------------------------ */
                else {

                    showTimeSection(false);
                    showLeaveTypeSection(false);

                    clearLeaveTypeSelection();

                }


                attendanceModal.show();

            });

        });


    /* ============================================================
       STATUS BUTTONS
    ============================================================ */

    document.querySelectorAll('.status-select-btn')
        .forEach(function(button) {

            button.addEventListener('click', function() {

                const selectedStatus =
                    button.dataset.status;


                /*
                 * Remove active from all
                 */
                document.querySelectorAll('.status-select-btn')
                    .forEach(function(btn) {

                        btn.classList.remove('active');

                    });


                /*
                 * Set active
                 */
                button.classList.add('active');


                /* ---------------------------------------------
                   PRESENT
                --------------------------------------------- */

                if (selectedStatus === 'Present') {

                    showTimeSection(true);
                    showLeaveTypeSection(false);

                    clearLeaveTypeSelection();

                }


                /* ---------------------------------------------
                   ON LEAVE
                --------------------------------------------- */
                else if (selectedStatus === 'On Leave') {

                    showTimeSection(false);
                    showLeaveTypeSection(true);

                    clearLeaveTypeSelection();

                }


                /* ---------------------------------------------
                   ABSENT
                --------------------------------------------- */
                else {

                    showTimeSection(false);
                    showLeaveTypeSection(false);

                    clearLeaveTypeSelection();

                }

            });

        });


    /* ============================================================
       LEAVE TYPE BUTTONS
    ============================================================ */

    document.querySelectorAll('.leave-type-btn')
        .forEach(function(button) {

            button.addEventListener('click', function() {

                document.querySelectorAll('.leave-type-btn')
                    .forEach(function(btn) {

                        btn.classList.remove('active');

                    });


                button.classList.add('active');


                selectedLeaveType =
                    button.dataset.leaveType;

            });

        });


    /* ============================================================
       SAVE ATTENDANCE
    ============================================================ */

    if (saveAttendance) {

        saveAttendance.addEventListener('click', function() {

            /*
             * Make sure a cell is selected
             */
            if (!selectedCell) {

                alert('Please select an attendance day.');

                return;

            }


            /*
             * Get active status button FIRST
             */
            const activeButton =
                document.querySelector(
                    '.status-select-btn.active'
                );


            if (!activeButton) {

                alert('Please select attendance status.');

                return;

            }


            /*
             * Get selected status
             */
            const status =
                activeButton.dataset.status;


            /* ------------------------------------------------
               LEAVE VALIDATION
            ------------------------------------------------ */

            if (
                status === 'On Leave' &&
                !selectedLeaveType
            ) {

                alert(
                    'Please select Casual Leave, Paid Leave or Sick Leave.'
                );

                return;

            }


            /* ------------------------------------------------
               UPDATE CELL DATA
            ------------------------------------------------ */

            selectedCell.dataset.status =
                status;

            selectedCell.dataset.leaveType =
                status === 'On Leave' ?
                selectedLeaveType :
                '';


            /*
             * Clear old cell content
             */
            selectedCell.innerHTML = '';


            /* =================================================
               PRESENT
            ================================================= */

            if (status === 'Present') {

                const badge =
                    document.createElement('span');

                badge.className =
                    'attendance-badge present';

                badge.innerText = 'P';


                const time =
                    document.createElement('div');

                time.className =
                    'attendance-time';


                const selectedInTime =
                    inTime.value || '09:00';

                const selectedOutTime =
                    outTime.value || '18:00';


                time.innerHTML =
                    selectedInTime +
                    '<br>' +
                    selectedOutTime;


                selectedCell.appendChild(badge);
                selectedCell.appendChild(time);

            }


            /* =================================================
               ABSENT
            ================================================= */
            else if (status === 'Absent') {

                const badge =
                    document.createElement('span');

                badge.className =
                    'attendance-badge absent';

                badge.innerText = 'A';


                const dash =
                    document.createElement('div');

                dash.className =
                    'attendance-dash';

                dash.innerText = '—';


                selectedCell.appendChild(badge);
                selectedCell.appendChild(dash);

            }


            /* =================================================
               ON LEAVE
            ================================================= */
            else if (status === 'On Leave') {

                const badge =
                    document.createElement('span');

                badge.className =
                    'attendance-badge leave';

                badge.innerText = 'L';


                const text =
                    document.createElement('div');

                text.className =
                    'attendance-dash';

                text.innerText =
                    selectedLeaveType;


                selectedCell.appendChild(badge);
                selectedCell.appendChild(text);

            }


            /* ------------------------------------------------
               CLOSE MODAL
            ------------------------------------------------ */

            attendanceModal.hide();


            /* ------------------------------------------------
               UPDATE SUMMARY
            ------------------------------------------------ */
            updateSummary();

            /*
             * Reset selected cell after saving
             */
            selectedCell = null;
        });
    }


    /* SEARCH + DEPARTMENT FILTER */

    let selectedDepartment = 'ALL';


    function applyFilters() {

        const search =
            employeeSearch.value
            .toLowerCase()
            .trim();


        document.querySelectorAll(
            '#attendanceBody tr'
        ).forEach(function(row) {

            const employee =
                (row.dataset.employee || '')
                .toLowerCase();


            const department =
                row.dataset.department || '';


            const matchesSearch =
                employee.includes(search);


            const matchesDepartment =
                selectedDepartment === 'ALL' ||
                department === selectedDepartment;


            if (
                matchesSearch &&
                matchesDepartment
            ) {

                row.style.display = '';

            } else {

                row.style.display = 'none';
            }
        });

    }


    /* SEARCH */

    if (employeeSearch) {

        employeeSearch.addEventListener(
            'input',
            function() {
                applyFilters();
            }
        );

    }


    /*  DEPARTMENT FILTER  */
    document.querySelectorAll('.dept-filter-btn')
        .forEach(function(button) {
            button.addEventListener('click', function() {
                document.querySelectorAll('.dept-filter-btn')
                    .forEach(function(btn) {
                        btn.classList.remove('active');
                    });
                button.classList.add('active');
                selectedDepartment =
                    button.dataset.department;
                applyFilters();

            });

        });


    /*  SUMMARY COUNTS   */

    function updateSummary() {
        let present = 0;
        let absent = 0;
        let leave = 0;
        document.querySelectorAll('.attendance-cell')
            .forEach(function(cell) {
                const status =
                    cell.dataset.status;

                if (status === 'Present') {
                    present++;
                } else if (status === 'Absent') {
                    absent++;
                } else if (status === 'On Leave') {
                    leave++;
                }
            });
        document.getElementById('presentCount')
            .innerText =
            present + ' Present';
        document.getElementById('absentCount')
            .innerText =
            absent + ' Absent';
        document.getElementById('leaveCount')
            .innerText =
            leave + ' On Leave';

    }

    /*  DATE FORMAT   */

    function formatDate(dateString) {

        if (!dateString) {
            return '-';
        }

        const date =
            new Date(dateString + 'T00:00:00');

        return date.toLocaleDateString(
            'en-US', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            }
        );

    }


    /*   MODAL RESET  */

    attendanceModalElement.addEventListener(
        'hidden.bs.modal',
        function() {

            selectedCell = null;

            selectedLeaveType = null;

            document.querySelectorAll(
                '.status-select-btn'
            ).forEach(function(button) {

                button.classList.remove('active');

            });


            document.querySelectorAll(
                '.leave-type-btn'
            ).forEach(function(button) {

                button.classList.remove('active');

            });


            showTimeSection(false);
            showLeaveTypeSection(false);

        }
    );


    /* INITIAL SUMMARY */

    updateSummary();

});
</script>
@endsection