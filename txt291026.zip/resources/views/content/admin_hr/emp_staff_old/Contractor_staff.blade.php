@extends('layouts.layoutMaster')

@section('title', 'Contract Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@php
// Dummy Data
$totalEmployees = 128;
$presentEmployees = 104;
$activePresenceRate = round(($presentEmployees / $totalEmployees) * 100);
$totalWagesToday = 5420;

// ===== Department Data ======
$departments = ['ALL','Management','Engineering','Quality Control','Accounts','Purchase','Skilled Labor','General
Labor'];

$selectedDept = 'ALL';

// ======= Action =======
$attendance = 'Present';

$attendanceStyles = [
'Present' => [
'bg' => '#ecfdf5',
'color' => '#059669',
'icon' => 'mdi-check-circle-outline',
],
'Absent' => [
'bg' => '#fef2f2',
'color' => '#dc2626',
'icon' => 'mdi-close-circle-outline',
],
'On Leave' => [
'bg' => '#fffbeb',
'color' => '#d97706',
'icon' => 'mdi-calendar-remove-outline',
],
];

$employeeStatus = $employee['status'] ?? 'Active';

$statusStyle = match ($employeeStatus) {
'Active' => [
'bg' => '#ecfdf5',
'color' => '#059669',
'icon' => 'mdi-check-circle-outline'
],
'Inactive' => [
'bg' => '#fef2f2',
'color' => '#dc2626',
'icon' => 'mdi-pause-circle-outline'
],
'Exit' => [
'bg' => '#fff7ed',
'color' => '#ea580c',
'icon' => 'mdi-exit-run'
],
default => [
'bg' => '#f1f5f9',
'color' => '#64748b',
'icon' => 'mdi-help-circle-outline'
],
};

$currentStyle = $attendanceStyles[$attendance];
@endphp


<div class="container-fluid px-0">
    {{-- ==== SUMMARY CARDS =======--}}
    <div class="summary-scroll-wrapper mb-4">
        <div class="row g-3 flex-nowrap custom-summary-scroll">
            {{--   = WORKFORCE REGISTRY   = --}}
            <div class="summary-card-col">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            {{-- Icon --}}
                            <div class="summary-icon d-flex align-items-center justify-content-center flex-shrink-0"
                                style=" width: 48px; height: 48px; border-radius: 12px; background-color: #eff6ff;color: #16659E;">
                                <i class="mdi mdi-account-group fs-4"></i>
                            </div>
                            {{-- Content --}}
                            <div class="min-w-0">
                                <span class="d-block text-uppercase fw-bold text-secondary summary-label">
                                    SRK Workforce Registry
                                </span>
                                <span class="d-block fs-4 fw-extrabold font-monospace summary-value"
                                    style="color: #0C3C62;">
                                    {{ $totalEmployees }} Engineers &amp; Staff
                                </span>
                                <small class="text-muted summary-description">
                                    Mapped to current active infrastructures
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {{--   = Monthly ACTIVE PRESENCE   = --}}
            <div class="summary-card-col">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            {{-- Icon --}}
                            <div class="summary-icon d-flex align-items-center justify-content-center flex-shrink-0"
                                style="width: 48px;height: 48px;border-radius: 12px;background-color: #ecfdf5;color: #059669;">
                                <i class="mdi mdi-account-check fs-4"></i>
                            </div>

                            {{-- Content --}}
                            <div class="min-w-0">
                                <span class="d-block text-uppercase fw-bold text-secondary summary-label">
                                    Monthly Active Presence
                                </span>
                                <span class="d-block fs-4 fw-extrabold font-monospace text-success summary-value">
                                    {{ $presentEmployees }} Present
                                </span>
                                <span class="badge rounded-1 fw-semibold mt-1" style="
                                        font-size: 10px;
                                        background-color: #ecfdf5;
                                        color: #059669;
                                    ">
                                    {{ $activePresenceRate }}% Attendance Rate Today
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{--   = Monthly WAGE ALLOCATION   = --}}
            <div class="summary-card-col">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            {{-- Icon --}}
                            <div class="summary-icon d-flex align-items-center justify-content-center flex-shrink-0"
                                style="
                                    width: 48px;
                                    height: 48px;
                                    border-radius: 12px;
                                    background-color: #fff7ed;
                                    color: #E86A33;
                                ">
                                <i class="mdi mdi-credit-card-outline fs-4"></i>
                            </div>
                            {{-- Content --}}
                            <div class="min-w-0">
                                <span class="d-block text-uppercase fw-bold text-secondary summary-label">
                                    Monthly Wage Allocation
                                </span>
                                <span class="d-block fs-4 fw-extrabold font-monospace summary-value"
                                    style="color: #0C3C62;">
                                    ${{ number_format($totalWagesToday) }}
                                </span>
                                <small class="text-muted d-block summary-description">
                                    Drawn from present workforce logs
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{--             ===
        FILTER / SEARCH SECTION
                ==== --}}
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-3">
            <div class="filter-layout">
                {{--   ======== SEARCH   ======== --}}
                <div class="filter-search ">
                    <div class="position-relative">
                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                            style="pointer-events: none;">
                            <i class="mdi mdi-magnify fs-5"></i>
                        </span>

                        <input id="hr-search-field" type="text" placeholder="Search staff, designation or email"
                            class="form-control form-control-sm ps-7  bg-light border-0 rounded-3 text-secondary" />

                    </div>
                </div>
                {{--   ======== DEPARTMENT FILTER   ======== --}}
                <div class="filter-departments">
                    <div class="department-scroll">
                        @foreach ($departments as $dept)
                        <button type="button" id="hr-dept-tab-{{ Str::slug($dept) }}" data-department="{{ $dept }}"
                            class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn
                                {{ $selectedDept === $dept ? 'active' : '' }}">
                            {{ $dept === 'ALL' ? 'All Roles' : $dept }}
                        </button>
                        @endforeach
                    </div>
                </div>

                {{--   ======== ADD STAFF   ======== --}}
                <div class="filter-action">
                    <button type="button" id="hr-add-staff-btn"
                        class="btn text-white d-flex align-items-center justify-content-center gap-2 rounded-3 px-3 py-2 shadow-sm fw-bold border-0"
                        data-bs-toggle="offcanvas" data-bs-target="#staffDrawer">
                        <i class="mdi mdi-account-plus fs-6"></i>
                        <span>
                            Add Staff Member
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- ======  STAFF TABLE ====== --}}
    <div class="card border-0 shadow-sm rounded-4">
        {{-- Card Header --}}
        <div class="card-header bg-white border-0 px-4 py-3">
            <div class="d-flex align-items-center justify-content-between gap-3">
                <div>
                    <h5 class="mb-1 fw-bold" style="color: #0C3C62;">
                        Contract Staff
                    </h5>
                    <small class="text-muted">
                        Manage and monitor Contract workforce members
                    </small>
                </div>
                <span class="badge rounded-3 px-3 py-2" style="
                        background-color: #eff6ff; color: #16659E; font-size: 11px;">
                    {{ $totalEmployees }} Staff
                </span>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-between mb-2 px-4">
            <div>
            <span>Show</span>
            <select id="perpage" class="form-select form-select-sm w-75px"
                onchange="loadThemes(1)">
                        @php $options = [5,10, 25, 100, 500]; @endphp
                    @foreach ($options as $option)
                        <option value="{{ $option }}" {{ ($perpage ?? '25') == $option ? 'selected' : '' }}>
                        {{ $option }}
                    </option>
                    @endforeach
            </select>
            </div>
            <div class="col-12 col-md-6 col-lg-5 mt-4">
                <div class="input-group input-group-merge">
                    <span class="input-group-text">
                        <i class="mdi mdi-magnify"></i>
                    </span>
                    <input type="text" id="search_filter" class="form-control"
                        placeholder="Search Staff" value="">
                </div>
            </div>
        </div>
        {{-- Table --}}
        <div class="table-responsive">
            <table class="table table-hover mb-0" id="staff-table">
                <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                    <tr>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Staff Member
                        </th>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Designation
                        </th>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Department
                        </th>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Wages
                        </th>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Status
                        </th>
                    </tr>
                </thead>
                <tbody id="list-table-body" class="table-border-bottom-0">
                    <tr class="skeleton-loader" id="skeleton-loader">
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="text-center px-4 my-2" id="pagination-container">
            <!-- Pagination buttons will appear here -->
        </div>
    </div>
</div>


{{--   ======== EXIT EMPLOYEE MODAL   ======== --}}
<div class="modal fade" id="employeeExitModal" tabindex="-1" aria-labelledby="employeeExitModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow rounded-4">
            {{-- Modal Header --}}
            <div class="modal-header border-0 pb-2">
                <div>
                    <h6 class="modal-title fw-bold text-dark" id="employeeExitModalLabel">
                        <i class="mdi mdi-exit-run text-warning me-1"></i>
                        Employee Exit
                    </h6>
                    <small class="text-muted">
                        Enter employee exit details
                    </small>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Modal Body --}}
            <div class="modal-body pt-2">
                <form id="employeeExitForm">
                    {{-- Employee ID --}}
                    <input type="hidden" id="exit_employee_id" name="employee_id">
                    {{-- Status --}}
                    <input type="hidden" name="status" value="Exit">
                    {{-- Date of Exit --}}
                    <div class="mb-3">
                        <label for="exit_date" class="form-label fw-semibold" style="font-size: 11px;">
                            Date of Exit
                            <span class="text-danger">*</span>
                        </label>
                        <input type="date" class="form-control form-control-sm rounded-3" id="exit_date"
                            name="exit_date" required>
                    </div>
                    {{-- Remark --}}
                    <div class="mb-3">
                        <label for="exit_remark" class="form-label fw-semibold" style="font-size: 11px;">
                            Remark
                            <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control form-control-sm rounded-3" id="exit_remark" name="exit_remark"
                            rows="3" placeholder="Enter exit reason / remark..." required></textarea>
                    </div>
                </form>
            </div>

            {{-- Modal Footer --}}
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-sm btn-light rounded-3" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-sm btn-warning rounded-3 fw-semibold" id="confirmEmployeeExit">
                    <i class="mdi mdi-check me-1"></i>
                    Confirm Exit
                </button>
            </div>
        </div>
    </div>
</div>

{{-- ADD STAFF OFFCANVAS DRAWER --}}
<div class="offcanvas offcanvas-end staff-drawer" tabindex="-1" id="staffDrawer" aria-labelledby="staffDrawerLabel"
    style="width: 700px;">
    {{-- HEADER --}}
    <div class="offcanvas-header border-bottom bg-primary ">
        <div>
            <h5 class="offcanvas-title fw-bold text-white" id="staffDrawerLabel">
                Add Staff Member
            </h5>
            <small class="text-muted">
                Add Contract staff details
            </small>
        </div>
        <button type="button" class="btn-close text-white" data-bs-dismiss="offcanvas">
        </button>
    </div>
    {{-- BODY --}}
    <div class="offcanvas-body d-flex flex-column pl-4">
        <div class="flex-grow-1 overflow-auto p-3">
            <form id="staffForm">
                {{-- 1. PERSONAL INFORMATION --}}
               <div class="mb-4">
                    <h6 class="fw-bold mb-1" style="color:#0C3C62;">
                        1. Personal Information
                    </h6>
                    <small class="text-muted d-block mb-3">
                        Enter the basic personal details of the staff member.
                    </small>

                    {{-- PROFILE PHOTO UPLOAD (Compact Format) --}}
                    <div class="p-3 mb-4 border rounded-3 bg-white shadow-sm">
                        
                        <h6 class="fw-bold mb-1" style="color: #212529; font-size: 14px;">Profile Photo</h6>
                        <p class="text-muted small mb-3" style="font-size: 12px;">This photo will appear on your profile and in the portal header.</p>

                        <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-3">
                            {{-- Avatar with Upload Badge --}}
                            <div class="avatar-upload-wrapper flex-shrink-0">
                                <div class="avatar-preview" id="profilePreview">
                                    {{-- Default Placeholder --}}
                                    <img src="https://ui-avatars.com/api/?name=PAIGE&background=f8f9fa&color=0d6efd&size=100" alt="Profile" id="avatarImage">
                                </div>
                                <label for="profilePhoto" class="avatar-upload-badge" title="Upload Photo">
                                    <i class="mdi mdi-camera-outline"></i>
                                </label>
                                <input type="file" id="profilePhoto" name="profile_photo" accept="image/jpeg, image/png, image/webp" class="d-none">
                            </div>

                            {{-- Details & Buttons --}}
                            <div class="flex-grow-1 min-w-0">
                                <h6 class="fw-bold mb-1 text-truncate" style="color: #0c3c62; font-size: 15px;">Aarav Mehta</h6>
                                <p class="text-muted small mb-2 text-truncate" style="font-size: 12px;">superadmin@paige.demo</p>

                                <div class="d-flex align-items-center flex-wrap gap-2 mb-2">
                                    <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-1 px-2 py-1" style="font-size: 12px;" onclick="document.getElementById('profilePhoto').click();">
                                        <i class="mdi mdi-camera-outline"></i> Upload Photo
                                    </button>
                                    <button type="button" class="btn btn-sm btn-link text-danger text-decoration-none d-inline-flex align-items-center gap-1 d-none px-1 py-1" style="font-size: 12px;" id="removeProfilePhotoBtn">
                                        <i class="mdi mdi-trash-can-outline"></i> Remove
                                    </button>
                                </div>

                                <p class="text-muted mb-0" style="font-size: 10px;">
                                    JPG, PNG or WebP &middot; Maximum 2 MB &middot; Recommended 400 &times; 400 px
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Employee Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="employeeName" placeholder="Enter employee name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Date of Birth</label>
                            <input type="date" class="form-control" id="employeeDob">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Gender</label>
                            <select class="select3 form-select" id="employeeGender">
                                <option value="">Select gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Mobile</label>
                            <input type="tel" class="form-control" id="employeeMobile" placeholder="Enter mobile number">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Alternate Mobile Number</label>
                            <input type="tel" class="form-control" id="employeeAltMobile" placeholder="Enter alternate mobile number">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email ID</label>
                            <input type="email" class="form-control" id="employeeEmail" placeholder="example@email.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Date of Joining <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="dateOfJoining">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Date of Exit</label>
                            <input type="date" class="form-control" id="dateOfExit">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Address</label>
                            <textarea class="form-control" id="employeeAddress" rows="3" placeholder="Enter complete address"></textarea>
                        </div>
                    </div>

                    {{-- EMERGENCY CONTACT DETAILS --}}
                <div class="mt-4">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <h6 class="fw-bold mb-0" style="color:#0C3C62;">
                            Emergency Contact Details
                        </h6>
                        {{-- Plus Icon Button --}}
                        <button type="button" class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center shadow-sm" 
                                id="addEmergencyContactBtn" title="Add Emergency Contact" style="width: 32px; height: 32px; padding: 0;">
                            <i class="mdi mdi-plus" style="font-size: 18px;"></i>
                        </button>
                    </div>
                    <small class="text-muted d-block mb-3">
                        Provide details of the person to be contacted in case of an emergency.
                    </small>

                    {{-- Container for dynamically added contacts --}}
                    <div id="emergencyContactContainer">
                        
                        {{-- First Default Contact Row --}}
                        <div class="row g-3 emergency-contact-row mb-2 align-items-center">
                            <div class="col-md-5">
                                <label class="form-label fw-semibold">Contact Name</label>
                                <input type="text" class="form-control" name="emergency_contacts[0][name]" placeholder="Enter contact name">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Relation</label>
                                <select class="select3 form-select" name="emergency_contacts[0][relation]">
                                    <option value="">Select relation</option>
                                    <option value="Parent">Parent</option>
                                    <option value="Child">Child</option>
                                    <option value="Spouse">Spouse</option>
                                    <option value="Sibling">Sibling</option>
                                    <option value="Guardian">Guardian</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label fw-semibold">Contact Number</label>
                                <input type="tel" class="form-control" name="emergency_contacts[0][number]" placeholder="Enter contact number">
                            </div>
                        </div>

                    </div>
                </div>
                </div>
                <hr>
               

                {{-- 2. GOVERNMENT / IDENTITY DETAILS --}}
                <div class="my-4">
                    <h6 class="fw-bold mb-1" style="color:#0C3C62;">
                        2. Government / Identity Details
                    </h6>
                    <small class="text-muted d-block mb-3">
                        Enter government identification and basic identity details.
                    </small>
                    <div class="row g-3">
                        <!-- Aadhaar -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Aadhaar No</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="aadhaarNumber" placeholder="Enter Aadhaar number" maxlength="12">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('aadhaarUpload').click()" title="Upload Aadhaar">
                                    <i class="mdi mdi-file-upload-outline text-white fs-4"></i>
                                </button>
                                <input type="file" id="aadhaarUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'aadhaarFileName')">
                            </div>
                            <small id="aadhaarFileName" class="text-success d-block mt-1"></small>
                        </div>

                        <!-- PAN -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">PAN Number</label>
                            <div class="input-group">
                                <input type="text" class="form-control " id="panNumber" placeholder="Enter PAN number" maxlength="10">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('panUpload').click()" title="Upload PAN">
                                    <i class="mdi mdi-file-upload-outline fs-4 text-white"></i>
                                </button>
                                <input type="file" id="panUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'panFileName')">
                            </div>
                            <small id="panFileName" class="text-success d-block mt-1"></small>
                        </div>

                        <!-- ESI (No upload) -->
                      
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">ESI No</label>
                            <div class="input-group">
                                <input type="text" class="form-control " id="esiNumber" placeholder="Enter ESI No" maxlength="10">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('esiUpload').click()" title="Upload ESI">
                                    <i class="mdi mdi-file-upload-outline text-white fs-4"></i>
                                </button>
                                <input type="file" id="esiUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'esiFileName')">
                            </div>
                            <small id="esiFileName" class="text-success d-block mt-1"></small>
                        </div>

                        <!-- Blood Group -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Blood Group</label>
                            <select class="select3 form-select" id="bloodGroup">
                                <option value="">Select blood group</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </div>

                        <!-- UAN -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">UAN Number</label>
                            <div class="input-group">
                                <input type="text" class="form-control " id="uanNumber" placeholder="Enter UAN number" maxlength="12">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('uanUpload').click()" title="Upload UAN">
                                    <i class="mdi mdi-file-upload-outline fs-4 text-white"></i>
                                </button>
                                <input type="file" id="uanUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'uanFileName')">
                            </div>
                            <small id="uanFileName" class="text-success d-block mt-1"></small>
                        </div>

                        <!-- Voter ID -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Voter ID</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="voterId" placeholder="Enter Voter ID" maxlength="10">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('voterUpload').click()" title="Upload Voter ID">
                                    <i class="mdi mdi-file-upload-outline text-white fs-4"></i>
                                </button>
                                <input type="file" id="voterUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'voterFileName')">
                            </div>
                            <small id="voterFileName" class="text-success d-block mt-1"></small>
                        </div>
                    </div>
                </div>
                <hr>

                {{-- 3. LOGIN CREDENTIAL --}}
                <div class="mt-4">
                    <div class="mb-3">
                        <h6 class="fw-bold mb-1" style="color:#0C3C62;">
                            3. Login Credential
                        </h6>
                        <p class="text-muted mb-0" style="font-size:11px;">
                            Configure system login access for this employee.
                        </p>
                    </div>
                    <div class="border rounded-3 p-3 bg-light">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="isLoginRequired" name="is_login_required" value="1">
                            <label class="form-check-label fw-semibold" for="isLoginRequired" style="color:#0C3C62;">
                                Is login required?
                            </label>
                        </div>
                        <div class="ms-4 mt-1">
                            <small class="text-muted">
                                Enabling login access generates secure user credentials
                                and triggers dynamic role authorizations in accordance
                                with standard ERP policies.
                            </small>
                        </div>
                        <div id="loginCredentialFields" class="row g-3 mt-2 d-none">
                            <div class="col-12 col-md-6">
                                <label for="loginUsername" class="form-label fw-semibold">
                                    Username <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white"><i class="mdi mdi-account-outline"></i></span>
                                    <input type="text" class="form-control" id="loginUsername" name="username" placeholder="Enter username" autocomplete="off">
                                </div>
                                <small class="text-muted">Username used to access the ERP system.</small>
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="loginPin" class="form-label fw-semibold">
                                    Login PIN <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white"><i class="mdi mdi-lock-outline"></i></span>
                                    <input type="password" class="form-control" id="loginPin" name="login_pin" placeholder="Enter secure PIN" maxlength="6" inputmode="numeric" autocomplete="new-password">
                                    <button type="button" class="btn btn-outline-secondary" id="toggleLoginPin">
                                        <i class="mdi mdi-eye-outline" id="loginPinIcon"></i>
                                    </button>
                                </div>
                                <small class="text-muted">Use a secure 4–6 digit PIN.</small>
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="user_role" class="form-label fw-semibold">
                                    User Role<span class="text-danger">*</span>
                                </label>
                                <select class="select3 form-select" id="user_role" name="user_role">
                                    <option value="">Select User Role</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <div class="alert alert-primary border-0 mb-0 py-2 px-3" style="font-size:11px;">
                                    <div class="d-flex align-items-start gap-2">
                                        <i class="mdi mdi-information-outline" style="font-size:18px;"></i>
                                        <div>
                                            <strong>Login Access Enabled</strong>
                                            <div class="mt-1">
                                                This employee will receive system login
                                                access based on the roles and permissions
                                                assigned by the administrator.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>

                {{-- 4. PROFESSIONAL DETAILS --}}
                <div class="my-4">
                    <h6 class="fw-bold mb-1" style="color:#0C3C62;">
                        4. Professional Details
                    </h6>
                    <small class="text-muted d-block mb-3">
                        Configure the staff member's role, department and project allocation.
                    </small>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="department" class="form-label fw-semibold">
                                Department / Unit <span class="text-danger">*</span>
                            </label>
                            <select class="select3 form-select" id="department">
                                <option value="">Select department</option>
                                <option value="Management">Management</option>
                                <option value="Accounts">Accounts</option>
                                <option value="Purchase">Purchase</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="role_designation" class="form-label fw-semibold">
                                Role Designation <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" id="role_designation" placeholder="Enter the role designation">
                        </div>
                    
                       <div class="col-md-6">
                            <!-- Label stays on top -->
                            <label class="form-label fw-semibold" for="ctcInput">
                                CTC <span class="text-danger">*</span>
                            </label>
                            
                            <!-- Input and Button in the same row with proper padding -->
                            <div class="d-flex gap-2 align-items-center">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="ctcInput" 
                                    placeholder="Enter CTC amount" 
                                    style="flex: 1;" 
                                />
                                
                               <button 
                                    type="button" 
                                    class="btn bg-primary text-nowrap d-flex align-items-center justify-content-center gap-2 px-3" 
                                    id="monthlyWages" 
                                    style="height: 38px;"
                                    data-bs-toggle="modal" 
                                    data-bs-target="#wagesModal">
                                    <span class="text-white fw-semibold">Wages</span>
                                    <i class="mdi mdi-arrow-right text-white fs-5"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Grade <span class="text-danger">*</span>
                            </label>
                            <select class="select3 form-select" id="grade">
                                <option value="">Select Grade</option>
                                <option value="Grade A">Grade A</option>
                                <option value="Grade B">Grade B</option>
                                <option value="Grade C">Grade C</option>
                                <option value="Grade E">Grade E</option>
                            </select>
                        </div>

                       
                        <div class="col-md-6">
                            <label for="probationPeriod" class="form-label fw-semibold">
                                Probation Period
                            </label>
                            <select class="select3 form-select" id="probationPeriod" name="probation_period">
                                <option value="">Select probation period</option>
                                <option value="0">No Probation</option>
                                <option value="30">30 Days</option>
                                <option value="60">60 Days</option>
                                <option value="90">90 Days</option>
                                
                            </select>
                        </div>

                        {{-- Workplace Leave Balance Configuration --}}
                        <div class="mt-4">
                            <div class="mb-3">
                                <h6 class="mb-1">Workplace Leave Balance Configuration</h6>
                                <p class="text-muted small mb-0">Configure the employee's annual leave balance and previous leave carry-forward.</p>
                            </div>
                          <div class="border rounded-3 p-3 bg-light">
    <div class="row g-3">
        <!-- Casual Leave Dropdown -->
        <div class="col-12 col-sm-6 col-md-4">
            <label for="casualLeave" class="form-label fw-semibold">Casual Leave (CL)</label>
            <select class="form-select" id="casualLeave" name="casual_leave">
                <!-- <option value="0" selected>1</option> -->
                <!-- Using a PHP loop to generate options 1 to 30 -->
                @for ($i = 1; $i <= 14; $i++)
                    <option value="{{ $i }}">{{ $i }}</option>
                @endfor
            </select>
        </div>

        <!-- Paid Leave Dropdown -->
        <div class="col-12 col-sm-6 col-md-4">
            <label for="paidLeave" class="form-label fw-semibold">Paid Leave (PL)</label>
            <select class="form-select" id="paidLeave" name="paid_leave">
                <!-- <option value="0" selected>0</option> -->
                @for ($i = 1; $i <= 16; $i++)
                    <option value="{{ $i }}">{{ $i }}</option>
                @endfor
            </select>
        </div>

        <!-- Sick Leave Dropdown -->
        <div class="col-12 col-sm-6 col-md-4">
            <label for="sickLeave" class="form-label fw-semibold">Sick Leave (SL)</label>
            <select class="form-select" id="sickLeave" name="sick_leave">
                <!-- <option value="0" selected>0</option> -->
                @for ($i = 1; $i <= 9; $i++)
                    <option value="{{ $i }}">{{ $i }}</option>
                @endfor
            </select>
        </div>
    </div>
</div>
                        </div>

                        {{-- 5. Language Skills --}}
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <label class="fw-bold mb-0" style="color:#0C3C62;">5. Language Skills</label>
                                    <small class="d-block text-muted mt-1">Add languages and specify the employee's reading, writing and speaking skills.</small>
                                </div>
                                <!-- <button type="button" class="btn btn-primary btn-sm" id="addLanguageBtn">
                                    <i class="mdi mdi-plus me-1"></i> Add Language
                                </button> -->
                            </div>
                            <div>
                                <select class="form-select select3" id="languages" name="languages" multiple>
                                    <option value="" >select Languages</option>
                                </select>
                            </div>
                            <!-- <div id="languageInputSection" class="border rounded-3 bg-light p-3 mb-3" style="display: none;">
                                <div class="row g-3 align-items-end">
                                    <div class="col-12 col-md-6">
                                        <label for="languageSkills" class="form-label fw-semibold mb-1">Language</label>
                                        <input type="text" class="form-control" id="languageSkills" placeholder="Enter language" autocomplete="off">
                                    </div>
                                    <div class="col-12 col-md-auto">
                                        <button type="button" class="btn btn-primary" id="saveLanguageBtn">
                                            <i class="mdi mdi-check me-1"></i> Add
                                        </button>
                                    </div>
                                </div>
                            </div> -->
                            <!-- <div class="table-responsive border rounded-3" id="languageTableWrapper" style="display: none;">
                                <table class="table table-hover align-middle mb-0" id="languageSkillsTable">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="fw-bold text-dark" style="min-width: 180px;">Language</th>
                                            <th class="fw-bold text-dark text-center" style="width: 120px;">Read</th>
                                            <th class="fw-bold text-dark text-center" style="width: 120px;">Write</th>
                                            <th class="fw-bold text-dark text-center" style="width: 120px;">Speak</th>
                                            <th class="fw-bold text-dark text-center" style="width: 80px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="languageSkillsBody"></tbody>
                                </table>
                            </div> -->
                        </div>

                        

                        <style>
                        .hover-bg-light { transition: background-color 0.2s ease; }
                        .hover-bg-light:hover { background-color: #f1f5f9 !important; }
                        </style>
                    </div>
                </div>

            </form>
        </div>
    </div>
    {{-- FOOTER --}}
    <div class="border-top p-3 d-flex justify-content-end gap-2 bg-white" style="position:sticky;bottom:0;">
        <button type="button" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">
            Cancel
        </button>
        <button type="button" class="btn btn-primary px-4" id="saveStaff">
            <i class="mdi mdi-content-save-outline me-1"></i>
            Save Staff
        </button>
    </div>
</div>
</div>


{{-- EMPLOYEE DETAILS DRAWER --}}
<div class="offcanvas offcanvas-end employee-drawer" tabindex="-1" id="employeeDrawer"
    aria-labelledby="employeeDrawerLabel" data-bs-backdrop="true" style="width:1500px; max-width:100%;">
    {{-- HEADER --}}
    <div class="offcanvas-header border-bottom px-4 py-3 bg-primary">

        <div class="d-flex align-items-center gap-3">

            {{-- Employee Avatar --}}
            <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="
                width:46px;
                height:46px;
                background:#eff6ff;
                color:#16659E;
            ">
                <i class="mdi mdi-account fs-5"></i>
            </div>

            {{-- Employee Information --}}
            <div class="d-flex flex-column">

                <h5 class="mb-1 fw-bold text-white">
                    Madhavan Krishnan
                </h5>

                <span class="small text-white-50">
                    Lead Site Engineer
                </span>

                <span class="small text-white-50">
                    Engineering
                </span>

            </div>

        </div>


        {{-- Header Actions --}}
        <div class="d-flex align-items-center gap-2">
            {{-- Edit / Save Button --}}
            <button type="button" class="btn btn-sm d-flex align-items-center gap-1 px-3 py-2" id="employeeEditBtn"
                style=" background:rgba(224, 0, 0, 0.12); border:1px solid rgba(255,255,255,0.25); border-radius:6px; font-size:12px;
                font-weight:600; color:#ffffff;">
                <i class="mdi mdi-pencil-outline" id="employeeEditIcon"></i>
                <span id="employeeEditText">
                    Edit
                </span>
            </button>

            {{-- Close --}}
            <button type="button" class="btn-close btn-close-white ms-1" data-bs-dismiss="offcanvas" aria-label="Close">
            </button>
        </div>

    </div>

    {{--   BODY --}}
    <div class="offcanvas-body p-0">
        <div class="d-flex h-100 employee-drawer-layout">
            {{--  LEFT SIDEBAR --}}
            <div class="employee-sidebar border-end" style="
                    width:220px;
                    min-width:220px;
                    background:#f8fafc;">
                <div class="p-3">
                    <small class="text-uppercase fw-bold text-muted" style="
                            font-size:10px;
                            letter-spacing:.5px;">
                        Employee Dossier
                    </small>
                </div>

                <div id="employeeTabMenu">
                    <button type="button" class="employee-tab active" data-tab="personal">
                        <i class="mdi mdi-account-outline"></i>
                        <span>
                            KYC & Personal
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="education">
                        <i class="mdi mdi-school-outline"></i>
                        <span>
                            Education Details
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="experience">
                        <i class="mdi mdi-briefcase-outline"></i>
                        <span>
                            Work Experience
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="training">
                        <i class="mdi mdi-certificate-outline"></i>
                        <span>
                            Training Induction
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="references">
                        <i class="mdi mdi-shield-check-outline"></i>
                        <span>
                            Ref Checks
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="interview">
                        <i class="mdi mdi-file-sign"></i>
                        <span>
                            Interview Notes
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="family"> <i
                            class="mdi mdi-account-group-outline"></i>
                        <span>
                            Family & Dependents
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="remuneration">
                        <i class="mdi mdi-credit-card-outline"></i>
                        <span>
                            Remuneration
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="documents">
                        <i class="mdi mdi-file-document-outline"></i>
                        <span>
                            Employee Files
                        </span>
                    </button>
                </div>
            </div>

            {{--  RIGHT CONTENT --}}
            <div class="employee-content flex-grow-1" style="overflow-y:auto;">
                {{--  PERSONAL / KYC --}}
                <div class="employee-panel p-4" data-panel="personal">
                    <div class="employee-section-title">
                        <i class="mdi mdi-account-outline me-1"></i>
                        Personal Profile & KYC
                    </div>
                    <div class="employee-card">
                        <div class="row g-4">
                            {{-- Full Name --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Full Name
                                </span>
                                <span class="employee-value">
                                    Madhavan Krishnan
                                </span>
                            </div>
                            {{-- Email --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Email
                                </span>
                                <span class="employee-value">
                                    madhavan@example.com
                                </span>
                            </div>

                            {{-- Phone --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Phone
                                </span>
                                <span class="employee-value">
                                    +91 98765 43210
                                </span>
                            </div>
                            {{-- DOB --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Date of Birth
                                </span>
                                <span class="employee-value">
                                    15 Aug 1990
                                </span>
                            </div>
                            {{-- Gender --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Gender
                                </span>
                                <span class="employee-value">
                                    Male
                                </span>
                            </div>

                            {{-- Nationality --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Nationality
                                </span>
                                <span class="employee-value">
                                    Indian
                                </span>
                            </div>

                            {{-- Marital Status --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Marital Status
                                </span>
                                <span class="employee-value">
                                    Married
                                </span>
                            </div>
                            {{-- Aadhaar --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Aadhaar
                                </span>
                                <span class="employee-value">
                                    XXXX XXXX 4521
                                </span>
                            </div>
                            {{-- PAN --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    PAN
                                </span>
                                <span class="employee-value">
                                    ABCDE1234F
                                </span>
                            </div>
                            {{-- Address --}}
                            <div class="col-12">
                                <span class="employee-label">
                                    Address
                                </span>
                                <span class="employee-value">
                                    Chennai, Tamil Nadu
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- EDUCATION --}}
                <div class="employee-panel p-4 d-none" data-panel="education">
                    <div class="employee-section-title">
                        <i class="mdi mdi-school-outline me-1"></i>
                        Education Details
                    </div>
                    {{-- B.E --}}
                    <div class="employee-card education-card mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="row g-4 flex-grow-1">
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Qualification
                                    </span>
                                    <span class="employee-value">
                                        B.E. Civil Engineering
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Institution
                                    </span>
                                    <span class="employee-value">
                                        Anna University (CEG Campus), Chennai
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Passing Year
                                    </span>
                                    <span class="employee-value">
                                        2000
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Grade
                                    </span>
                                    <span class="employee-value">
                                        84%
                                    </span>
                                </div>
                            </div>
                            {{-- DELETE --}}
                            <button type="button" class="education-delete-btn" title="Delete Education">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </div>

                    {{-- M.Tech --}}
                    <div class="employee-card education-card mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="row g-4 flex-grow-1">
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Qualification
                                    </span>
                                    <span class="employee-value">
                                        M.Tech Construction Management
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Institution
                                    </span>
                                    <span class="employee-value">
                                        Indian Institute of Technology (IIT) Madras
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Passing Year
                                    </span>
                                    <span class="employee-value">
                                        2002
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Grade
                                    </span>
                                    <span class="employee-value">
                                        9.2 CGPA
                                    </span>
                                </div>
                            </div>


                            {{-- DELETE --}}
                            <button type="button" class="education-delete-btn" title="Delete Education">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </div>


                    <div class="education-add-box">
                        <div class="education-add-title mb-3">
                            ADD EDUCATION
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input" placeholder="Qualification">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input" placeholder="Institution">
                            </div>
                            <div class="col-md-6">
                                <input type="number" class="form-control education-input" placeholder="Passing Year">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input"
                                    placeholder="Grade / Percentage / CGPA">
                            </div>
                            <div class="col-12">
                                <button type="button" class="btn education-add-btn">
                                    <i class="mdi mdi-plus me-1"></i>
                                    Append Education
                                </button>
                            </div>
                        </div>
                    </div>
                </div>


                {{-- WORK EXPERIENCE PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="experience">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-briefcase-outline me-2 fs-5"></i>
                        Work Experience
                    </div>

                    {{-- Container for All Experience Cards --}}
                    <div id="experienceContainer">

                        {{-- Experience Item 1 --}}
                        <div class="card mb-3 p-3 position-relative experience-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-exp-btn py-0 px-1"
                                title="Delete Experience" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="exp-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fw-bold exp-view-designation"
                                        style="font-size: 14px; color: #1e293b;">Site Engineer</span>
                                    <span class="badge rounded-1 exp-view-duration"
                                        style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        2014 - 2018
                                    </span>
                                </div>
                                <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;">
                                    ABC Constructions
                                </div>
                                <div class="exp-view-roles mt-2"
                                    style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                    Managed daily site operations, supervised workforce, and ensured quality control
                                    compliance.
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="exp-edit-mode d-none mt-2 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm exp-input-designation"
                                            style="font-size: 11px;" value="Site Engineer">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Company
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm exp-input-company"
                                            style="font-size: 11px;" value="ABC Constructions">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Duration</label>
                                        <input type="text" class="form-control form-control-sm exp-input-duration"
                                            style="font-size: 11px;" value="2014 - 2018" placeholder="e.g. 2014 - 2018">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles &
                                            Responsibilities</label>
                                        <textarea class="form-control form-control-sm exp-input-roles" rows="2"
                                            style="font-size: 11px;"
                                            placeholder="Describe key responsibilities...">Managed daily site operations, supervised workforce, and ensured quality control compliance.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Experience Item 2 --}}
                        <div class="card mb-3 p-3 position-relative experience-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-exp-btn py-0 px-1"
                                title="Delete Experience" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            <div class="exp-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fw-bold exp-view-designation"
                                        style="font-size: 14px; color: #1e293b;">Senior Site Engineer</span>
                                    <span class="badge rounded-1 exp-view-duration"
                                        style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        2018 - 2022
                                    </span>
                                </div>
                                <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;">
                                    XYZ Infrastructure
                                </div>
                                <div class="exp-view-roles mt-2"
                                    style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                    Overseeing structural bridge construction and vendor management.
                                </div>
                            </div>

                            <div class="exp-edit-mode d-none mt-2 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm exp-input-designation"
                                            style="font-size: 11px;" value="Senior Site Engineer">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Company
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm exp-input-company"
                                            style="font-size: 11px;" value="XYZ Infrastructure">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Duration</label>
                                        <input type="text" class="form-control form-control-sm exp-input-duration"
                                            style="font-size: 11px;" value="2018 - 2022">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles &
                                            Responsibilities</label>
                                        <textarea class="form-control form-control-sm exp-input-roles" rows="2"
                                            style="font-size: 11px;">Overseeing structural bridge construction and vendor management.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- TRAINING INDUCTION PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="training">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-certificate-outline me-2 fs-5"></i>
                        Training Induction
                    </div>

                    {{-- Container for All Training Cards --}}
                    <div id="trainingContainer">

                        {{-- Item 1 --}}
                        <div class="card mb-3 p-3 position-relative training-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-training-btn py-0 px-1"
                                title="Delete Training" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="training-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="fw-bold training-view-title"
                                            style="font-size: 14px; color: #1e293b;">Site Safety Induction</span>
                                        <small class="d-block text-muted mt-1 training-view-date"
                                            style="font-size: 12px; color: #94a3b8;">10 Jan 2024</small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success training-view-status"
                                        style="font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        Completed
                                    </span>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="training-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Training
                                            Title</label>
                                        <input type="text" class="form-control form-control-sm training-input-title"
                                            style="font-size: 11px;" value="Site Safety Induction">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Completion
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm training-input-date"
                                            style="font-size: 11px;" value="10 Jan 2024" placeholder="e.g. 10 Jan 2024">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Status</label>
                                        <select class="form-select form-select-sm training-input-status"
                                            style="font-size: 11px;">
                                            <option value="Completed" selected>Completed</option>
                                            <option value="Pending">Pending</option>
                                            <option value="In Progress">In Progress</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Item 2 --}}
                        <div class="card mb-3 p-3 position-relative training-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-training-btn py-0 px-1"
                                title="Delete Training" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            <div class="training-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="fw-bold training-view-title"
                                            style="font-size: 14px; color: #1e293b;">Construction Safety</span>
                                        <small class="d-block text-muted mt-1 training-view-date"
                                            style="font-size: 12px; color: #94a3b8;">15 Mar 2024</small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success training-view-status"
                                        style="font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        Completed
                                    </span>
                                </div>
                            </div>

                            <div class="training-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Training
                                            Title</label>
                                        <input type="text" class="form-control form-control-sm training-input-title"
                                            style="font-size: 11px;" value="Construction Safety">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Completion
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm training-input-date"
                                            style="font-size: 11px;" value="15 Mar 2024">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Status</label>
                                        <select class="form-select form-select-sm training-input-status"
                                            style="font-size: 11px;">
                                            <option value="Completed" selected>Completed</option>
                                            <option value="Pending">Pending</option>
                                            <option value="In Progress">In Progress</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- REFERENCE CHECKS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="references">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-shield-check-outline me-2 fs-5"></i>
                        Reference Checks
                    </div>

                    {{-- Container for All Reference Cards --}}
                    <div id="referenceContainer">

                        {{-- Reference Item 1 --}}
                        <div class="card mb-3 p-3 position-relative reference-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-ref-btn py-0 px-1"
                                title="Delete Reference" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="ref-view-mode">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-bold ref-view-name"
                                            style="font-size: 14px; color: #1e293b;">Rajesh Kumar</span>
                                        <span class="badge bg-success-subtle text-success ref-view-status"
                                            style="font-weight: 600; font-size: 10px; padding: 3px 6px;">
                                            VERIFIED
                                        </span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center gap-3 text-secondary"
                                    style="font-size: 13px; color: #64748b;">
                                    <div>
                                        <small class="text-muted">Designation:</small>
                                        <span class="ref-view-designation fw-medium" style="color: #334155;">Project
                                            Manager</span>
                                    </div>
                                    <span style="border-right: 1px solid #cbd5e1; height: 12px;"></span>
                                    <div>
                                        <small class="text-muted">Phone:</small>
                                        <span class="ref-view-phone fw-medium" style="color: #334155;">+91 98765
                                            12345</span>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="ref-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm ref-input-name"
                                            style="font-size: 11px;" value="Rajesh Kumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Verification
                                            Status</label>
                                        <select class="form-select form-select-sm ref-input-status"
                                            style="font-size: 11px;">
                                            <option value="VERIFIED" selected>VERIFIED</option>
                                            <option value="PENDING">PENDING</option>
                                            <option value="UNVERIFIED">UNVERIFIED</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm ref-input-designation"
                                            style="font-size: 11px;" value="Project Manager">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Phone
                                            Number</label>
                                        <input type="text" class="form-control form-control-sm ref-input-phone"
                                            style="font-size: 11px;" value="+91 98765 12345">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- INTERVIEW LOGS & ASSESSMENT PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="interview">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-file-sign me-2 fs-5"></i>
                        Recruiter Interview Logs & Assessment Comments
                    </div>

                    {{-- Container for All Interview Log Cards --}}
                    <div id="interviewContainer">

                        {{-- Interview Item 1 --}}
                        <div class="card mb-3 p-3 position-relative interview-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-interview-btn py-0 px-1"
                                title="Delete Interview Log" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="interview-view-mode">
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Screening
                                            Recruiter</small>
                                        <span class="fw-semibold interview-view-recruiter"
                                            style="font-size: 13px; color: #1e293b;">Suresh Kumar</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Evaluation
                                            Date</small>
                                        <span class="fw-medium interview-view-date"
                                            style="font-size: 13px; color: #334155;">12 Dec 2023</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Rating</small>
                                        <span class="fw-medium interview-view-rating"
                                            style="font-size: 13px; color: #334155;">4.5 / 5</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">HR Decision
                                            Verdict</small>
                                        <span class="badge bg-success-subtle text-success interview-view-verdict"
                                            style="font-weight: 600; font-size: 11px; padding: 4px 8px;">
                                            Selected
                                        </span>
                                    </div>
                                    <div class="col-12 mt-2">
                                        <small class="text-muted d-block" style="font-size: 11px;">Comments</small>
                                        <p class="mb-0 interview-view-comments"
                                            style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                            Strong technical knowledge and excellent site management skills.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="interview-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Screening
                                            Recruiter</label>
                                        <input type="text"
                                            class="form-control form-control-sm interview-input-recruiter"
                                            style="font-size: 11px;" value="Suresh Kumar">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Evaluation
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm interview-input-date"
                                            style="font-size: 11px;" value="12 Dec 2023" placeholder="e.g. 12 Dec 2023">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Rating</label>
                                        <input type="text" class="form-control form-control-sm interview-input-rating"
                                            style="font-size: 11px;" value="4.5 / 5" placeholder="e.g. 4.5 / 5">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">HR Decision
                                            Verdict</label>
                                        <select class="form-select form-select-sm interview-input-verdict"
                                            style="font-size: 11px;">
                                            <option value="Selected" selected>Selected</option>
                                            <option value="On Hold">On Hold</option>
                                            <option value="Rejected">Rejected</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Assessment
                                            Comments</label>
                                        <textarea class="form-control form-control-sm interview-input-comments" rows="2"
                                            style="font-size: 11px;"
                                            placeholder="Enter assessment comments...">Strong technical knowledge and excellent site management skills.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- FAMILY & EMERGENCY CONTACTS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="family">
                    {{-- Section Header --}}
                    <div class="employee-section-title mb-3">
                        <i class="mdi mdi-account-group-outline me-1"></i>
                        Family Members & Emergency Contacts Info
                    </div>

                    {{-- Container for Existing Family Members --}}
                    <div id="familyContainer">

                        {{-- Family Member 1 --}}
                        <div class="family-member-card mb-3 family-item position-relative">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="family-delete-btn d-none position-absolute top-0 end-0 m-3 delete-family-btn"
                                title="Remove Family Member">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="family-view-mode">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <span class="family-member-name family-view-name">Sundari Sivakumar</span>
                                            <span class="family-relation-badge family-view-relation">SPOUSE</span>
                                        </div>
                                        <div class="family-member-details">
                                            <span>
                                                <small>Age:</small>
                                                <span class="family-view-age">44</span> Years
                                            </span>
                                            <span class="family-divider"></span>
                                            <span>
                                                <small>Occupation:</small>
                                                <span class="family-view-occupation">Homemaker</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="family-edit-mode d-none pe-4">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm family-input-name"
                                            style="font-size: 11px;" value="Sundari Sivakumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Relation</label>
                                        <input type="text" class="form-control form-control-sm family-input-relation"
                                            style="font-size: 11px;" value="SPOUSE">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                                        <input type="number" class="form-control form-control-sm family-input-age"
                                            style="font-size: 11px;" value="44">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Occupation</label>
                                        <input type="text" class="form-control form-control-sm family-input-occupation"
                                            style="font-size: 11px;" value="Homemaker">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Family Member 2 --}}
                        <div class="family-member-card mb-4 family-item position-relative">
                            <button type="button"
                                class="family-delete-btn d-none position-absolute top-0 end-0 m-3 delete-family-btn"
                                title="Remove Family Member">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="family-view-mode">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <span class="family-member-name family-view-name">Kavin Sivakumar</span>
                                            <span class="family-relation-badge family-view-relation">SON</span>
                                        </div>
                                        <div class="family-member-details">
                                            <span>
                                                <small>Age:</small>
                                                <span class="family-view-age">16</span> Years
                                            </span>
                                            <span class="family-divider"></span>
                                            <span>
                                                <small>Occupation:</small>
                                                <span class="family-view-occupation">Student</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="family-edit-mode d-none pe-4">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm family-input-name"
                                            style="font-size: 11px;" value="Kavin Sivakumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Relation</label>
                                        <input type="text" class="form-control form-control-sm family-input-relation"
                                            style="font-size: 11px;" value="SON">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                                        <input type="number" class="form-control form-control-sm family-input-age"
                                            style="font-size: 11px;" value="16">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Occupation</label>
                                        <input type="text" class="form-control form-control-sm family-input-occupation"
                                            style="font-size: 11px;" value="Student">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    {{-- ADD FAMILY MEMBER BOX (EDIT MODE ONLY) --}}
                    <div class="family-add-box d-none" id="familyAddBox">
                        <div class="family-add-title mb-3">
                            ADD FAMILY MEMBER / EMERGENCY CONTACT
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" id="newFamilyName" class="form-control family-input"
                                    placeholder="Full Name">
                            </div>
                            <div class="col-md-6">
                                <input type="text" id="newFamilyRelation" class="form-control family-input"
                                    placeholder="Relation (e.g. Spouse / Father / Sister)">
                            </div>
                            <div class="col-md-6">
                                <input type="number" id="newFamilyAge" class="form-control family-input"
                                    placeholder="Age">
                            </div>
                            <div class="col-md-6">
                                <input type="text" id="newFamilyOccupation" class="form-control family-input"
                                    placeholder="Occupation (e.g. Homemaker / Farmer)">
                            </div>
                            <div class="col-12">
                                <button type="button" class="btn family-add-btn" id="appendFamilyBtn">
                                    <i class="mdi mdi-plus me-1"></i>
                                    Append Family Member
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                {{--  REMUNERATION --}}
                <div class="employee-panel p-4 d-none" data-panel="remuneration">
                    <!-- Section Title -->
                    <div class="employee-section-title mb-4">
                        <i class="mdi mdi-credit-card-outline me-1"></i>
                        Compensation, Mapped Salary Structure & Statutory Remuneration
                    </div>
                    <!-- SUMMARY METRIC CARDS -->
                    <div class="row g-3 mb-4">
                        <!-- Net Monthly Take Home -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#ecfdf5; border:1px solid #d1fae5;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#047857;">
                                    Net Monthly Take-Home
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#047857;">
                                    Rs. 17,850
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#059669;">
                                    Component A - Component B
                                </small>

                            </div>
                        </div>


                        <!-- Gross Earnings -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#eff6ff; border:1px solid #dbeafe;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#16659E;">
                                    Gross Earnings (Comp A)
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#16659E;">
                                    Rs. 22,500
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#16659E;">
                                    Basic + HRA + Special
                                </small>

                            </div>
                        </div>


                        <!-- Deductions -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#fff1f2; border:1px solid #ffe4e6;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#be123c;">
                                    Deductions (Comp B)
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#be123c;">
                                    Rs. 4,650
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#e11d48;">
                                    PF + ESI + PT + TDS
                                </small>

                            </div>
                        </div>


                        <!-- Total CTC -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#eef2ff; border:1px solid #e0e7ff;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#0C3C62;">
                                    Total Monthly CTC
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#0C3C62;">
                                    Rs. 25,850
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#4f46e5;">
                                    Comp A + Employer Share
                                </small>

                            </div>
                        </div>

                    </div>


                    <!-- MAPPED SALARY STRUCTURE LEDGER-->
                    <div class="p-3 p-md-4 rounded-3 mb-4" style="background:#f8fafc; border:1px solid #e2e8f0;">

                        <!-- Ledger Header -->
                        <div
                            class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-3 mb-3">

                            <div>
                                <h6 class="mb-1 fw-bold text-uppercase"
                                    style="font-size:11px; letter-spacing:.6px; color:#1e293b;">
                                    Mapped Salary Structure Ledger
                                </h6>

                                <small class="text-muted" style="font-size:10px;">
                                    Indian Labour Law 2026 Compliant Wage Component Breakdown
                                </small>
                            </div>

                            <span class="badge rounded-pill" style="font-size:9px; background:#dbeafe; color:#16659E;">
                                Staff Category
                            </span>

                        </div>


                        <div class="row g-3">

                            <!-- COMPONENT A - EARNINGS -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">

                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">

                                        <span class="fw-bold text-uppercase" style="font-size:10px; color:#1e40af;">
                                            Component A • Earnings
                                        </span>

                                        <!-- Editable Total -->
                                        <div id="componentATotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px; color:#1e3a8a;">
                                                ₹ 22,500
                                            </span>
                                        </div>

                                        <div id="componentATotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace p-0"
                                                value="22500" style="width:70px;font-size:11px;">
                                        </div>

                                    </div>

                                    <!-- Content -->
                                    <div class="small">

                                        <!-- Basic -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                Basic Pay + DA
                                            </span>

                                            <div id="basicView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 12,000
                                                </span>
                                            </div>

                                            <div id="basicEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="12000" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- HRA -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                HRA & Other Allowance
                                            </span>

                                            <div id="hraView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 6,000
                                                </span>
                                            </div>

                                            <div id="hraEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="6000" style="width:70px;font-size:10px;">
                                            </div>
                                        </div>
                                        <!-- Special Allowance -->
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="text-dark" style="font-size:10px;">
                                                Special Allowance
                                            </span>
                                            <div id="specialView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 4,500
                                                </span>
                                            </div>
                                            <div id="specialEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="4500" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>


                            <!-- COMPONENT B - DEDUCTIONS -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">
                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                                        <span class="fw-bold text-uppercase" style="font-size:10px;color:#9f1239;">
                                            Component B • Deductions
                                        </span>
                                        <div id="componentBTotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px;color:#9f1239;">
                                                ₹ 4,650
                                            </span>
                                        </div>
                                        <div id="componentBTotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace"
                                                value="4650" style="width:70px;font-size:11px;">
                                        </div>
                                    </div>

                                    <div class="small">

                                        <!-- EPF -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                EPF Employee (12%)
                                            </span>

                                            <div id="epfEmployeeView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 1,440
                                                </span>
                                            </div>

                                            <div id="epfEmployeeEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1440" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- ESI -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                ESI Employee (0.75%)
                                            </span>
                                            <div id="esiEmployeeView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 169
                                                </span>
                                            </div>
                                            <div id="esiEmployeeEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="169" style="width:70px;font-size:10px;">
                                            </div>
                                        </div>

                                        <!-- PT -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                Professional Tax (PT)
                                            </span>
                                            <div id="ptView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 200
                                                </span>
                                            </div>
                                            <div id="ptEdit" class="d-none ">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace "
                                                    value="200" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- TDS -->
                                        <div class="d-flex justify-content-between align-items-center">

                                            <span class="text-dark" style="font-size:10px;">
                                                Income Tax / TDS
                                            </span>

                                            <div id="tdsView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 2,841
                                                </span>
                                            </div>

                                            <div id="tdsEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="2841" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>


                            <!-- COMPONENT C - EMPLOYER SHARE -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">

                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                                        <span class="fw-bold text-uppercase" style="font-size:10px;color:#3730a3;">
                                            Component C • Employer Share
                                        </span>
                                        <div id="componentCTotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px;color:#312e81;">
                                                ₹ 3,350
                                            </span>
                                        </div>
                                        <div id="componentCTotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace"
                                                value="3350" style="width:70px;font-size:11px;">
                                        </div>
                                    </div>

                                    <div class="small">
                                        <!-- EPF Employer -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                EPF Employer (12%)
                                            </span>
                                            <div id="epfEmployerView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 1,440
                                                </span>
                                            </div>

                                            <div id="epfEmployerEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1440" style="width:70px;;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- ESI Employer -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                ESI Employer (3.25%)
                                            </span>

                                            <div id="esiEmployerView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 731
                                                </span>
                                            </div>

                                            <div id="esiEmployerEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="731" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- Gratuity -->
                                        <div class="d-flex justify-content-between align-items-center">

                                            <span class="text-dark" style="font-size:10px;">
                                                Gratuity & LWF
                                            </span>

                                            <div id="gratuityView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 1,179
                                                </span>
                                            </div>

                                            <div id="gratuityEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1179" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>



                        <!--STATUTORY & BANKING DETAILS-->
                        <div class="border-top pt-4 mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <i class="mdi mdi-bank-outline me-2" style="font-size:18px; color:#16659E;"></i>
                                <h6 class="mb-0 fw-bold text-uppercase" style="font-size:11px; letter-spacing:.6px;">
                                    Statutory & Banking Registration Details
                                </h6>
                            </div>

                            <div class="row g-3">

                                <!-- Base Daily Wage -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Base Month Rate
                                    </label>
                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        Rs. 13,500/ month rate
                                    </div>

                                </div>
                                <!-- Special Allowance -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Special Monthly Allowance
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        Rs. 4,500 / month
                                    </div>

                                </div>


                                <!-- EPF / UAN -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        EPF / UAN Account Number
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        TN/MAS/87410/001
                                    </div>

                                </div>


                                <!-- ESI -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        ESI (State Insurance) Code
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        33-89745-12
                                    </div>

                                </div>


                                <!-- Bank -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Bank Partner Name
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2">
                                        State Bank of India
                                    </div>

                                </div>


                                <!-- Account / IFSC -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Bank Account Number / IFSC Code
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        AC: 30456123456
                                        <span class="text-muted mx-1">•</span>
                                        SBIN0000845
                                    </div>

                                </div>

                            </div>

                        </div>


                        <!--   PROMOTION & APPRAISAL CAREER HISTORY  -->
                        <div class="p-3 p-md-4 rounded-3" style="background:#f8fafc; border:1px solid #e2e8f0;">
                            <!-- Header -->
                            <div
                                class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-3 mb-3">
                                <div>
                                    <h6 class="mb-1 fw-bold text-uppercase d-flex align-items-center"
                                        style="font-size:11px; letter-spacing:.6px; color:#1e293b;">
                                        <i class="mdi mdi-trending-up me-1" style="font-size:17px; color:#059669;"></i>
                                        Promotion & Appraisal Career History
                                    </h6>
                                    <small class="text-muted" style="font-size:10px;">
                                        Historical Wage Revisions, Designations, and Performance Appraisals Mapped to
                                        Profile
                                    </small>
                                </div>
                                <span class="badge rounded-pill d-flex align-items-center gap-1"
                                    style="font-size:9px; background:#d1fae5; color:#065f46;">
                                    <i class="mdi mdi-auto-fix"></i>
                                    3 Records Mapped
                                </span>
                            </div>


                            <!--  PROMOTION RECORD 1   -->
                            <div
                                class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-2 mb-3">

                                <div class="d-flex flex-wrap align-items-center gap-2">

                                    <span class="badge" style="font-size:9px; background:#f3e8ff; color:#7e22ce;">
                                        Promotion
                                    </span>

                                    <span class="text-muted font-monospace" style="font-size:10px;">
                                        Effective: 01 Jan 2025 (January)
                                    </span>

                                </div>


                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge" style="font-size:9px; background:#fffbeb; color:#b45309;">
                                        <i class="mdi mdi-star me-1"></i>
                                        4.8 / 5
                                    </span>
                                    <span class="badge" style="font-size:9px; background:#eff6ff; color:#1d4ed8;">
                                        Approved
                                    </span>

                                </div>

                            </div>


                            <div class="row g-3">

                                <!-- Designation -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Designation / Role Shift
                                        </span>

                                        <div class="d-flex align-items-center gap-2">

                                            <span class="text-muted text-decoration-line-through"
                                                style="font-size:10px;">
                                                Site Engineer
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold" style="font-size:11px; color:#065f46;">
                                                Senior Site Engineer
                                            </span>

                                        </div>

                                    </div>

                                </div>


                                <!-- Basic Revision -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Base Pay Revision
                                        </span>

                                        <div class="d-flex align-items-center flex-wrap gap-2">

                                            <span class="text-muted text-decoration-line-through font-monospace"
                                                style="font-size:10px;">
                                                Rs. 10,000
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold font-monospace" style="font-size:11px; color:#047857;">
                                                Rs. 12,000
                                            </span>

                                            <span class="badge"
                                                style="font-size:8px; background:#d1fae5; color:#065f46;">
                                                +20%
                                            </span>

                                        </div>

                                    </div>

                                </div>


                                <!-- Gross Revision -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Gross Monthly Revision
                                        </span>

                                        <div class="d-flex align-items-center flex-wrap gap-2">

                                            <span class="text-muted text-decoration-line-through font-monospace"
                                                style="font-size:10px;">
                                                Rs. 19,000
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold font-monospace" style="font-size:11px; color:#065f46;">
                                                Rs. 22,500
                                            </span>

                                            <span class="text-success font-monospace fw-bold" style="font-size:10px;">
                                                (+Rs. 3,500)
                                            </span>

                                        </div>

                                    </div>

                                </div>

                            </div>


                            <!-- Remarks -->
                            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3 p-2 rounded-2"
                                style="background:#f8fafc; border:1px solid #e2e8f0;">

                                <div style="font-size:11px; color:#475569;">

                                    <span class="fw-bold text-dark">
                                        Remarks:
                                    </span>

                                    Promoted based on excellent project performance.

                                    <small class="d-block text-muted mt-1">
                                        Approved By: Suresh Kumar - Project Manager
                                    </small>

                                </div>


                                <div class="d-flex align-items-center gap-2">

                                    <span class="badge font-monospace"
                                        style="font-size:9px; background:#e2e8f0; color:#334155;">
                                        Ref: APP-2025-001
                                    </span>

                                    <button type="button" class="btn btn-sm text-white d-flex align-items-center gap-1"
                                        style="
                            background:#16659E;
                            font-size:10px;
                            font-weight:700;
                            border-radius:6px;
                        ">

                                        <i class="mdi mdi-download-outline"></i>
                                        Letter
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- COMPLIANCE & DOCUMENTS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="documents">
                    {{-- Section Header --}}
                    <div class="employee-section-title mb-3">
                        <i class="mdi mdi-file-document-outline me-1"></i>
                        Compliance Folders & Verified Documents
                    </div>

                    {{-- Documents Grid --}}
                    <div class="documents-grid" id="documentsGrid">

                        {{-- Document Card 1: Aadhaar --}}
                        <div
                            class="document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        Aadhaar_Card_Sivakumar.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        Aadhaar
                                        <span class="document-meta-divider mx-1">•</span>
                                        1.2 MB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                {{-- Hidden by default; visible only in Edit mode --}}
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                        {{-- Document Card 2: PAN --}}
                        <div
                            class="document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        PAN_Card_Sivakumar.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        PAN
                                        <span class="document-meta-divider mx-1">•</span>
                                        980 KB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                        {{-- Document Card 3: Experience --}}
                        <div
                            class="document-card mb-4 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        IT_Experience_Certificate.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        Experience
                                        <span class="document-meta-divider mx-1">•</span>
                                        1.8 MB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                    </div>

                    {{-- UPLOAD SUPPORTING DOCUMENT BOX --}}
                    <div class="document-upload-box p-3 border rounded bg-light d-none" id="documentUploadBox">
                        <div class="document-upload-title font-monospace text-uppercase fw-bold text-muted mb-3"
                            style="font-size: 11px; letter-spacing: 0.5px;">
                            UPLOAD SUPPORTING DOCUMENT
                        </div>

                        <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2">
                            {{-- Document Type Dropdown --}}
                            <div style="flex: 1; min-width: 160px;">
                                <select id="documentType" class="form-select form-select-sm w-100"
                                    style="font-size: 12px; height: 38px;">
                                    <option value="KYC Document">KYC Document</option>
                                    <option value="Experience">Experience Certificate</option>
                                    <option value="Education">Education Certificate</option>
                                    <option value="Other Certificate" selected>Other Certificate</option>
                                </select>
                            </div>

                            {{-- Select File Button --}}
                            <div style="flex: 1.5; min-width: 150px;">
                                <input type="file" id="documentFileInput" class="d-none"
                                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                                <button type="button" id="triggerFileSelectBtn"
                                    class="btn btn-sm btn-outline-secondary w-100 d-flex align-items-center justify-content-center text-truncate px-3"
                                    style="font-size: 12px; height: 38px;">
                                    <i class="mdi mdi-paperclip me-1 fs-6"></i>
                                    <span class="text-truncate">Select File...</span>
                                </button>
                            </div>

                            {{-- Upload Action Button --}}
                            <div style="flex: 0 0 auto;">
                                <button type="button" id="documentUploadBtn"
                                    class="btn btn-sm btn-primary w-100 d-flex align-items-center justify-content-center text-nowrap px-3"
                                    style="font-size: 12px; height: 38px;">
                                    <i class="mdi mdi-cloud-upload-outline me-1 fs-6"></i> Upload Document
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


<!-- Wages Modal -->
<div class="modal fade modal-blur" id="wagesModal" tabindex="-2" aria-labelledby="wagesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content  m-1 ">
            
            <!-- Header -->
            <div class="modal-header bg-primary border-bottom p-3">
                <h5 class="modal-title fw-bold text-white d-flex align-items-center gap-2" id="wagesModalLabel">
                    <i class="mdi mdi-account-hard-hat text-white fs-3"></i> 
                    Salary Structure & Wages
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Body -->
            <div class="modal-body p-4">
                
                <!-- Employee Profile Banner -->
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center text-primary p-3  mb-4 ">
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center text-white fw-bold fs-4" style="width: 50px; height: 50px;">
                            RK
                        </div>
                        <div>
                            <h5 class="mb-0 fw-bold">Rajesh Kumar</h5>
                            <div class="small text-primary-100">RI0016 &bull; Asst. Manager &bull; Structure</div>
                        </div>
                    </div>
                    <div class="text-md-end mt-3 mt-md-0">
                        <small class="text-primary-50 d-block">Total Cost to Company (CTC)</small>
                        <h4 class="mb-0 fw-bold">₹58,250/month</h4>
                    </div>
                </div>

                <!-- Success Alert -->
                <!-- <div class="alert alert-success d-flex justify-content-between align-items-center py-2">
                    <span class="small"><i class="mdi mdi-check-circle me-1"></i> Salary Structure saved successfully for B. Parthiban! Live payroll updated.</span>
                    <span class="badge bg-success">COMPLIANT</span>
                </div> -->

                <!-- Employee Details Grid -->
                <div class="row g-3 mb-4 m-1 p-5 pt-3 border rounded-3 bg-light small">
                    <div class="col-md-6"><strong>Project:</strong> KKRP</div>
                    <div class="col-md-6"><strong>Bank:</strong> Axis Bank</div>
                    <div class="col-md-6"><strong>A/C No:</strong> 913010055218739</div>
                    <div class="col-md-6"><strong>PAN No:</strong> 100542318789</div>
                    <div class="col-md-6"><strong>UAN No:</strong> BZTPP0534R</div>
                    <div class="col-md-6"><strong>Location:</strong> Nagarcoil</div>
                    <div class="col-md-6"><strong>Grade:</strong> F</div>
                    <div class="col-12 mt-2 pt-2 border-top">
                        <strong>Date of Joining : </strong> 19/10/2026
                    </div>
                </div>

                <!-- Auto-Calculator Header -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="fw-bold mb-0 text-dark"><i class="mdi mdi-calculator text-primary"></i> Indian Labour Code Auto-Calculator (50-30-20 Rule)</h6>
                    <span class="badge bg-secondary">2026 Wage Code Mandate</span>
                </div>

                <!-- Target Earnings Input -->
                <div class="mb-4">
                    <label class="form-label fw-semibold small text-muted">Target Monthly Gross Earnings (₹)</label>
                    <input type="text" class="form-control" value="₹ 49,599">
                </div>

                <!-- Component A -->
             <div class="card mb-3 border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                        <span class="fw-bold text-primary"><span class="badge bg-primary me-2">A</span> Component A - Employee Gross Earnings</span>
                        <span class="fw-bold text-success small">Total A: ₹49,599/mo</span>
                    </div>
                    
                    <div class="card-body p-3">
                        <!-- Use a grid layout for 2 columns -->
                        <div class="row g-3">
                            
                            <!-- 1. Basic Pay + DA -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">Basic Pay + DA</label>
                                            
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Min 50% CTC per Wage Code</div>
                                    </div>
                                    
                                    <!-- Gray Input Group -->
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="24790">
                                    </div>
                                </div>
                            </div>

                            <!-- 2. HRA + OA -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">HRA + OA</label>
                                            
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">House Rent & Other Allowance</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="14884">
                                    </div>
                                </div>
                            </div>

                            <!-- 3. Special Allowance -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">Special Allowance</label>
                                            
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Balancing Component</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="2339">
                                    </div>
                                </div>
                            </div>

                            <!-- 4. Conveyance Allowance -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">Conveyance Allowance</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Transport/Conveyance</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="1497">
                                    </div>
                                </div>
                            </div>

                            <!-- 5. Project Allowance -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">Project Allowance</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Project Specific</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="4210">
                                    </div>
                                </div>
                            </div>

                            <!-- 6. Medical Allowance -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">Medical Allowance</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Medical Reimbursement</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="1879">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
              </div>

                <!-- Component B (Deductions) -->
               <div class="card mb-3 border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                        <span class="fw-bold text-danger"><span class="badge bg-danger me-2">B</span> Component B - Employee Share (Deductions)</span>
                        <span class="fw-bold text-danger small">Total Deductions B: ₹4,280/mo</span>
                    </div>
                    
                    <div class="card-body p-3">
                        <!-- 2 Column Grid -->
                        <div class="row g-3">
                            
                            <!-- 1. EPF Share -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">EPF Share (12%)</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">12% of Basic + DA</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="1800">
                                    </div>
                                </div>
                            </div>

                            <!-- 2. ESI Share -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">ESI Share (0.75%)</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Gross ≤ ₹21k limit</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="0">
                                    </div>
                                </div>
                            </div>

                            <!-- 3. Prof. Tax (PT) -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">Prof. Tax (PT)</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">State Statutory PT</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="0">
                                    </div>
                                </div>
                            </div>

                            <!-- 4. TDS / Income Tax -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">TDS / Income Tax</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Direct Tax Deduction</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="0">
                                    </div>
                                </div>
                            </div>

                            <!-- 5. System Allowance -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">System Allowance</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Deduction</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="2480">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!-- Net Take-Home -->
                <div class="bg-success bg-opacity-10 border border-success rounded-3 p-3 mb-3 d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="fw-bold text-success mb-0"><i class="mdi mdi-cash-multiple"></i> NET TAKE-HOME SALARY</h6>
                        <small class="text-muted">Component A - Component B</small>
                    </div>
                    <div class="text-end">
                        <h4 class="fw-bold text-success mb-0">₹45,319/mo</h4>
                        <small class="text-muted">≈ ₹1,462/day</small>
                    </div>
                </div>

                <!-- Component C -->
              <div class="card mb-4 border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                        <span class="fw-bold text-info"><span class="badge bg-info me-2">C</span> Component C - Employer Share (Contributions & Benefits)</span>
                        <span class="fw-bold text-info small">Total Employer Share C: ₹8,651/mo</span>
                    </div>
                    
                    <div class="card-body p-3">
                        <!-- 2 Column Grid -->
                        <div class="row g-3">
                            
                            <!-- 1. EPF Employer Share -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">EPF Employer Share (12%)</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">EPS 8.33% + PF 3.67% + EDLI</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="1800">
                                    </div>
                                </div>
                            </div>

                            <!-- 2. ESI Employer Share -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">ESI Employer Share (3.25%)</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">Employer ESI Statutory Contribution</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="0">
                                    </div>
                                </div>
                            </div>

                            <!-- 3. Gratuity & LWF -->
                            <div class="col-md-6">
                                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <label class="fw-bold text-dark text-uppercase" style="font-size: 12px; letter-spacing: 0.5px;">Gratuity & LWF</label>
                                        </div>
                                        <div class="text-muted mb-3" style="font-size: 11px;">4.81% Accrual + Labor Welfare</div>
                                    </div>
                                    
                                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                                        <input type="text" class="form-control border-0 shadow-none fw-bold text-dark bg-white" value="6851">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!-- Total CTC -->
                <div class="bg-primary text-white rounded-3 p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="fw-bold mb-0"><i class="mdi mdi-briefcase"></i> TOTAL COST TO COMPANY</h5>
                        <small class="text-white-50">CTC = Component A + Component C</small>
                    </div>
                    <h3 class="fw-bold mb-0">₹58,250/month</h3>
                </div>

            </div>

            <!-- Footer -->
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn bg-primary text-white"><i class="mdi mdi-content-save me-1"></i> Save Structure</button>
            </div>

        </div>
    </div>
</div>
{{-- STYLES   --}}
<style>
/*          == SUMMARY CARDS          == */
.summary-scroll-wrapper {
    width: 100%;
    overflow: hidden;
}

.custom-summary-scroll {
    width: 100%;
    flex-wrap: nowrap !important;
    overflow-x: auto;
    overflow-y: hidden;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.custom-summary-scroll::-webkit-scrollbar {
    display: none;
}

.summary-card-col {
    flex: 0 0 33.333333%;
    width: 33.333333%;
    max-width: 33.333333%;
}

.summary-label {
    font-size: 10px;
    letter-spacing: 0.5px;
    line-height: 1.4;
}

.summary-value {
    line-height: 1.35;
    margin-top: 2px;
}

.summary-description {
    font-size: 10px;
    line-height: 1.4;
}

.min-w-0 {
    min-width: 0;
}


/*          ==  FILTER SECTION  DESKTOP 100% VIEW          = */
.filter-layout {
    display: grid;
    grid-template-columns:
        220px minmax(0, 1fr) 180px;
    align-items: center;
    gap: 10px;
    width: 100%;
    min-width: 0;
}

/*             FILTER SEARCH          == */

.filter-search {
    width: 100%;
    min-width: 0;
}

.filter-search .position-relative {
    width: 100%;
    min-width: 0;
}

#hr-search-field {
    display: block;
    width: 100%;
    min-width: 0;
    height: 40px;
    font-size: 0.78rem;
    padding-top: 0.5rem;
    padding-bottom: 0.5rem;
    overflow: hidden;
    text-overflow: ellipsis;
}


/*   DEPARTMENT FILTER  */

.filter-departments {
    width: 100%;
    min-width: 0;

    overflow: hidden;
}

.department-scroll {
    display: flex;
    align-items: center;
    gap: 6px;
    width: 100%;
    min-width: 0;
    overflow-x: auto;
    overflow-y: hidden;
    white-space: nowrap;
    padding: 1px 0 3px 0;
    scrollbar-width: none;
    -ms-overflow-style: none;
    -webkit-overflow-scrolling: touch;
}

.department-scroll::-webkit-scrollbar {
    display: none;
}


/*    DEPARTMENT BUTTONS  */

.dept-filter-btn {
    flex: 0 0 auto;

    min-height: 36px;

    padding-left: 10px !important;
    padding-right: 10px !important;

    font-size: 0.72rem;

    background-color: #f8fafc;
    color: #475569;

    border: none;

    white-space: nowrap;

    box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);

    transition:
        background-color 0.2s ease,
        color 0.2s ease,
        box-shadow 0.2s ease;
}

.dept-filter-btn:hover {
    background-color: #e2e8f0;
    color: #0f172a;
}

.dept-filter-btn.active {
    background-color: #16659E !important;
    color: #ffffff !important;

    box-shadow: 0 2px 5px rgba(22, 101, 158, 0.22);
}



/* Profile Photo Upload Styles */
.avatar-upload-wrapper {
    position: relative;
    width: 64px;   /* Reduced size */
    height: 64px;
}

.avatar-preview {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-color: #f8f9fa;
    border: 2px solid #fff;
    box-shadow: 0 0 0 1px #e9ecef;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
}

.avatar-preview img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.avatar-upload-badge {
    position: absolute;
    bottom: -2px;
    right: -2px;
    width: 24px;   /* Reduced size */
    height: 24px;
    background-color: #fff;
    border: 1px solid #dee2e6;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    transition: all 0.2s ease;
}

.avatar-upload-badge:hover {
    background-color: #f8f9fa;
    transform: scale(1.05);
}

.avatar-upload-badge i {
    font-size: 13px;
    color: #6c757d;
}
/*  ADD STAFF */

.filter-action {
    width: 100%;
    min-width: 0;
}

#hr-add-staff-btn {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 100%;
    height: 40px;

    padding-left: 10px !important;
    padding-right: 10px !important;

    background-color: #16659E;

    font-size: 0.76rem;

    white-space: nowrap;

    overflow: hidden;
}

#hr-add-staff-btn span {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

#hr-add-staff-btn:hover {
    background-color: #0f5687;
}


/*  VERY LARGE DESKTOP  1400px+ */

@media (min-width: 1400px) {

    .filter-layout {
        grid-template-columns:
            220px minmax(0, 1fr) 180px;
        gap: 12px;
    }

    .dept-filter-btn {
        padding-left: 11px !important;
        padding-right: 11px !important;

        font-size: 0.73rem;
    }

}


/* 1200px - 1399px */

@media (min-width: 1200px) and (max-width: 1399.98px) {

    .filter-layout {
        grid-template-columns:
            210px minmax(0, 1fr) 175px;

        gap: 10px;
    }

    .dept-filter-btn {
        padding-left: 9px !important;
        padding-right: 9px !important;

        font-size: 0.70rem;
    }

    #hr-add-staff-btn {
        font-size: 0.74rem;
    }

}


/* TABLET 768px - 1199px */

@media (min-width: 768px) and (max-width: 1199.98px) {

    .filter-layout {
        grid-template-columns:
            minmax(200px, 1fr) minmax(0, 1.5fr);

        gap: 12px;
    }

    .filter-search {
        grid-column: 1;
    }

    .filter-departments {
        grid-column: 2;
    }

    .filter-action {
        grid-column: 1 / -1;

        display: flex;

        justify-content: flex-end;

        width: 100%;
    }

    #hr-add-staff-btn {
        width: 180px;
        min-width: 180px;
    }


    /* Summary Cards */
    .custom-summary-scroll {
        scroll-snap-type: x mandatory;
    }

    .summary-card-col {
        flex: 0 0 48%;
        width: 48%;
        max-width: 48%;
        scroll-snap-align: start;
    }
}


/*  MOBILE Below 768px */

@media (max-width: 767.98px) {

    /* Filter Layout */
    .filter-layout {
        display: flex;
        flex-direction: column;
        align-items: stretch;
        gap: 12px;
        width: 100%;
    }


    /* Search */
    .filter-search {
        width: 100%;
        min-width: 0;
    }

    .filter-search .position-relative {
        width: 100%;
    }

    #hr-search-field {
        width: 100%;
        min-width: 0;
    }


    /* Department */

    .filter-departments {
        width: 100%;
        min-width: 0;

        overflow: hidden;
    }

    .department-scroll {
        width: 100%;

        padding-bottom: 3px;

        scroll-behavior: smooth;
    }

    /* Add Staff */
    .filter-action {
        width: 100%;
    }

    #hr-add-staff-btn {
        width: 100%;
        min-width: 0;
    }


    /* Summary Cards */

    .custom-summary-scroll {
        scroll-snap-type: x mandatory;

        padding-left: 2px;
        padding-right: 2px;
        padding-bottom: 4px;
    }

    .summary-card-col {
        flex: 0 0 88%;
        width: 88%;
        max-width: 88%;

        scroll-snap-align: start;
    }

    .custom-summary-scroll .card {
        min-height: 100px;
    }


    /* Summary Text */

    .summary-value {
        font-size: 1.15rem !important;
    }

    .summary-label {
        font-size: 9px;
    }

    .summary-description {
        font-size: 9px;
    }


    /* Table */

    .table-responsive {
        overflow-x: auto;

        -webkit-overflow-scrolling: touch;
    }

    .table {
        min-width: 800px;
    }

}


/*  VERY SMALL MOBILE Below 400px */

@media (max-width: 399.98px) {

    .summary-card-col {
        flex: 0 0 92%;
        width: 92%;
        max-width: 92%;
    }

    .summary-value {
        font-size: 1.05rem !important;
    }

    .card-body {
        padding: 12px !important;
    }

    .filter-layout {
        gap: 10px;
    }

    .dept-filter-btn {
        padding-left: 9px !important;
        padding-right: 9px !important;

        font-size: 0.70rem;
    }

    #hr-add-staff-btn {
        font-size: 0.74rem;
    }

}


/* TABLE */

.table> :not(caption)>*>* {
    border-bottom-color: #f1f5f9;
}

.table thead th {
    white-space: nowrap;
}

.table tbody tr:last-child td {
    border-bottom: 0;
}



.employee-drawer {
    width: min(900px, 90vw) !important;
}

.employee-drawer-layout {
    min-height: calc(100vh - 80px);
}

/* Sidebar */
.employee-tab {
    width: 100%;
    border: 0;
    background: transparent;
    padding: 11px 16px;
    display: flex;
    align-items: center;
    gap: 10px;
    text-align: left;
    color: #64748b;
    font-size: 12px;
    font-weight: 600;
    transition: all .2s ease;
    position: relative;
}

.employee-tab i {
    font-size: 17px;
    width: 20px;
    text-align: center;
}

.employee-tab:hover {
    background: #eef6ff;
    color: #16659E;
}

.employee-tab.active {
    background: #e8f2ff;
    color: #0C3C62;
}

.employee-tab.active::before {
    content: "";
    position: absolute;
    left: 0;
    top: 6px;
    bottom: 6px;
    width: 3px;
    border-radius: 0 4px 4px 0;
    background: #16659E;
}

/* Content */
.employee-content {
    background: #ffffff;
    overflow-y: auto;
}



.employee-card {
    border: 1px solid #0f172a;
    border-radius: 10px;
    padding: 16px;
    margin-bottom: 15px;
    background: #fff;
}

.employee-label {
    display: block;
    color: #94a3b8;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    margin-bottom: 4px;
}

.employee-value {
    color: #334155;
    font-size: 13px;
    font-weight: 600;
}

.employee-row:hover {
    background-color: #f8fbff;
}


/* Editable input style */
.employee-edit-input {
    width: 100%;
    border: 1px solid #d7dee8;
    border-radius: 6px;
    padding: 8px 10px;
    font-size: 13px;
    color: #334155;
    background: #ffffff;
    outline: none;
    transition: all .2s ease;
}

.employee-edit-input:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, .08);
}

textarea.employee-edit-input {
    min-height: 90px;
    resize: vertical;
}

.employee-editing .employee-card {
    background: #fbfdff;
}

.employee-editing .employee-label {
    margin-bottom: 6px;
}

/* Save button */
#employeeEditBtn.is-saving {
    background: #059669 !important;
    color: #ffffff !important;
}

/* FAMILY MEMBERS */

.family-member-card {
    border: 1px solid #0f172a;
    border-radius: 12px;
    padding: 17px 16px;
    background: #ffffff;
    transition: all 0.2s ease;
}

.family-member-card:hover {
    border-color: #16659E;
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05);
}


/* Member Name */

.family-member-name {
    font-size: 12px;
    font-weight: 700;
    color: #0f172a;
}


/* Relationship Badge */

.family-relation-badge {
    display: inline-flex;
    align-items: center;
    padding: 3px 8px;
    border-radius: 6px;
    background: #eff6ff;
    color: #16659E;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 0.3px;
}


/* Member Details */

.family-member-details {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #16659E;
    font-size: 10px;
}

.family-member-details small {
    color: #94a3b8;
    font-size: 9px;
    margin-right: 4px;
}


/* Divider */

.family-divider {
    width: 1px;
    height: 14px;
    background: #cbd5e1;
}


/* Delete Button */

.family-delete-btn {
    border: 0;
    background: transparent;
    color: #f43f5e;
    font-size: 17px;
    padding: 2px;
    cursor: pointer;
    transition: color 0.2s ease;
}

.family-delete-btn:hover {
    color: #be123c;
}


/*             ===
   ADD FAMILY MEMBER BOX
            === */

.family-add-box {
    border: 1px dashed #dbe3ec;
    border-radius: 12px;
    padding: 18px 16px;
    background: #fbfdff;
}


/* Add Box Title */

.family-add-title {
    color: #476989;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.5px;
}


/* Inputs */

.family-input {
    height: 35px;
    border: 1px solid #dbe3ec;
    border-radius: 7px;
    background: #ffffff;
    color: #334155;
    font-size: 11px;
    padding: 7px 10px;
    box-shadow: none;
}

.family-input::placeholder {
    color: #94a3b8;
    opacity: 1;
}

.family-input:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, 0.08);
}


/* Add Button */

.family-add-btn {
    background: #16659E;
    color: #ffffff;
    border: none;
    border-radius: 7px;
    font-size: 10px;
    font-weight: 700;
    padding: 8px 13px;
}

.family-add-btn:hover {
    background: #0C3C62;
    color: #ffffff;
}


/* DOCUMENT  */

.documents-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 15px;
    width: 100%;
}


/*    DOCUMENT CARD*/

.document-card {
    min-width: 0;
    min-height: 70px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 12px;

    padding: 12px 14px;

    background: #ffffff;

    border: 1px solid #0f172a;
    border-radius: 12px;

    transition:
        border-color 0.2s ease,
        box-shadow 0.2s ease,
        background-color 0.2s ease;
}

.document-card:hover {
    border-color: #16659E;
    background: #fbfdff;
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05);
}


/*  DOCUMENT INFO */

.document-info {
    min-width: 0;

    display: flex;
    align-items: center;

    gap: 12px;

    flex: 1;
}


/* File Icon */

.document-icon {
    flex: 0 0 38px;
    width: 38px;
    height: 38px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    background: #eff6ff;
    color: #16659E;
    font-size: 18px;
}

/*  DOCUMENT DETAILS */
.document-details {
    min-width: 0;
    flex: 1;
}

.document-name {
    min-width: 0;
    color: #0f172a;

    font-size: 12px;
    font-weight: 700;
    line-height: 1.35;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.document-meta {
    margin-top: 3px;

    color: #7b94ad;

    font-size: 9px;
    font-weight: 500;

    line-height: 1.3;
}

.document-meta-divider {
    margin: 0 4px;
    color: #a8b6c4;
}


/*  DOCUMENT ACTIONS */

.document-actions {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    gap: 10px;
}


/* Verified Badge */
.document-status {
    display: inline-flex;
    align-items: center;
    padding: 4px 7px;
    border-radius: 4px;
    background: #f1f5f9;
    color: #476989;
    font-size: 9px;
    font-weight: 600;
    white-space: nowrap;
}


/* Delete */
.document-delete-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 24px;
    padding: 0;
    border: 0;
    background: transparent;
    color: #f43f5e;
    font-size: 15px;
    cursor: pointer;
    transition: color 0.2s ease;
}

.document-delete-btn:hover {
    color: #be123c;
}

/* UPLOAD BOX */

.document-upload-box {
    width: 100%;
    margin-top: 24px;
    padding: 18px 16px;
    border: 1px dashed #dbe3ec;
    border-radius: 12px;
    background: #fbfdff;
}

/* Upload title */
.document-upload-title {
    margin-bottom: 14px;
    color: #476989;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 0.6px;
}


/*  UPLOAD FORM */
.document-upload-form {
    display: grid;
    grid-template-columns:
        minmax(0, 1fr) 176px 136px;
    gap: 12px;
    align-items: center;
    width: 100%;
}


/* Inputs */
.document-input {
    width: 100%;
    height: 36px;
    border: 1px solid #dbe3ec;
    border-radius: 7px;
    background: #ffffff;
    color: #334155;
    font-size: 10px;
    box-shadow: none;
}

.document-input::placeholder {
    color: #94a3b8;
    opacity: 1;
}

.document-input:focus {
    border-color: #16659E;
    box-shadow:
        0 0 0 2px rgba(22, 101, 158, 0.08);
}

/*  UPLOAD BUTTON */
.document-upload-btn {
    width: 100%;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 12px;
    border: 0;
    border-radius: 7px;
    background: #16659E;
    color: #ffffff;
    font-size: 10px;
    font-weight: 700;
    white-space: nowrap;
    transition: background-color 0.2s ease;
}

.document-upload-btn:hover {
    background: #0C3C62;
    color: #ffffff;
}


/* TABLET */

@media (max-width: 767.98px) {

    .documents-grid {
        grid-template-columns: 1fr;
        gap: 12px;
    }

    .document-upload-form {
        grid-template-columns: 1fr;
    }

    .document-upload-action {
        width: 100%;
    }

    .document-upload-btn {
        width: 100%;
    }

}


/* VERY SMALL MOBILE*/

@media (max-width: 399.98px) {
    .document-card {
        padding: 11px;
    }

    .document-info {
        gap: 9px;
    }

    .document-icon {
        flex-basis: 34px;
        width: 34px;
        height: 34px;
        font-size: 16px;
    }

    .document-name {
        font-size: 11px;
    }

    .document-meta {
        font-size: 8px;
    }

    .document-actions {
        gap: 6px;
    }

    .document-status {
        padding: 3px 5px;
        font-size: 8px;
    }

    .document-delete-btn {
        font-size: 14px;
    }
}

/*                                                                                                                               =
   EDUCATION
                                                                                                                              = */

.education-card {
    position: relative;
}

.education-card>.d-flex {
    width: 100%;
}

.education-card .row {
    min-width: 0;
}


/* Delete button */

.education-delete-btn {
    display: none;

    flex: 0 0 auto;

    border: 0;
    background: transparent;

    color: #f43f5e;

    font-size: 17px;

    padding: 2px 0 2px 12px;

    cursor: pointer;

    transition: color 0.2s ease;
}

.education-delete-btn:hover {
    color: #be123c;
}


/* Show delete icons only in Edit mode */

.employee-editing .education-delete-btn {
    display: block;
}


/* ADD EDUCATION
                                                                                                                              = */

.education-add-box {
    display: none;

    border: 1px dashed #dbe3ec;
    border-radius: 12px;
    padding: 18px 16px;
    background: #fbfdff;
}

/* Show only when Edit mode is active */
.employee-editing .education-add-box {
    display: block;
}

.education-add-title {
    color: #476989;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.5px;
}

.education-input {
    height: 35px;
    border: 1px solid #dbe3ec;
    border-radius: 7px;
    background: #ffffff;
    color: #334155;
    font-size: 11px;
    padding: 7px 10px;
    box-shadow: none;
}

.education-input::placeholder {
    color: #94a3b8;
    opacity: 1;
}

.education-input:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, 0.08);
}

.education-add-btn {
    background: #16659E;
    color: #ffffff;
    border: none;
    border-radius: 7px;
    font-size: 10px;
    font-weight: 700;
    padding: 8px 13px;
}

.education-add-btn:hover {
    background: #0C3C62;
    color: #ffffff;
}

/* EMPLOYEE DRAWER RESPONSIVE ONLY FOR SMALL + MEDIUM DEVICES == */
/*   MEDIUM DEVICES 768px - 991px */

@media (min-width: 768px) and (max-width: 991.98px) {

    /* Drawer */
    .employee-drawer {
        width: 92vw !important;
        max-width: 92vw !important;
    }

    /* Main Layout */
    .employee-drawer-layout {
        display: flex;
        height: 100%;
    }

    /* Sidebar */
    .employee-sidebar {
        width: 190px !important;
        min-width: 190px !important;
        flex: 0 0 190px;
        overflow-y: auto;
    }

    .employee-tab {
        padding: 10px 12px !important;
        font-size: 11px !important;
        gap: 7px !important;
    }

    .employee-tab i {
        font-size: 16px !important;
        width: 18px;
        min-width: 18px;
    }

    /* Content */
    .employee-content {
        min-width: 0;
        overflow-x: hidden;
        overflow-y: auto;
    }

    .employee-panel {
        padding: 18px !important;
        width: 100%;
    }

    /* Header */
    .employee-drawer .offcanvas-header {
        padding: 12px 16px !important;
    }

    .employee-drawer .offcanvas-header h5 {
        font-size: 15px !important;
    }

    .employee-drawer .offcanvas-header .small {
        font-size: 10px !important;
    }

    /* Personal / KYC */
    .emp_personal {
        width: 50%;
    }

    /* Education */
    .emp_education {
        width: 50%;
    }

    /* Experience */
    .exp-edit-mode .emp_experience {
        width: 50%;
    }

    /* Training */
    .training-edit-mode .emp_traine,
    .training-edit-mode .emp_trainee {
        width: 50%;
    }

    /* References */
    .ref-edit-mode .emp_ref {
        width: 50%;
    }

    /* Interview */
    .interview-edit-mode .emp_interview {
        width: 50%;
    }

    /* Family */
    .family-edit-mode .emp_fam {
        width: 50%;
    }

    /* Remuneration Summary */
    .row.g-3.mb-4>.emp_remuneration {
        width: 50%;
    }

    /* Remuneration Components */
    .row.g-3>.emp_remuneration {
        width: 50%;
    }

    /* Last remuneration card full width */
    .row.g-3>..emp_remuneration {
        width: 100%;
    }

    /* Statutory / Banking */
    .col-md-6 {
        width: 50%;
    }

    /* Promotion History */
    .row.g-3 .col-md-4 {
        width: 50%;
    }

    /* Documents */
    .document-card {
        padding: 12px !important;
    }

    .document-name {
        font-size: 12px !important;
    }

}


/* SMALL DEVICES <= 767px  */

@media (max-width: 767.98px) {

    /* DRAWER  */

    .employee-drawer {
        width: 100vw !important;
        max-width: 100vw !important;
    }

    /*   HEADER  */

    .employee-drawer .offcanvas-header {
        padding: 10px 12px !important;
    }

    .employee-drawer .offcanvas-header h5 {
        font-size: 13px !important;
    }

    .employee-drawer .offcanvas-header .small {
        font-size: 9px !important;
    }

    /* Avatar */
    .employee-drawer .offcanvas-header .rounded-circle {
        width: 38px !important;
        height: 38px !important;
    }

    /* Edit button */
    #employeeEditBtn {
        padding: 6px 9px !important;
        font-size: 10px !important;
    }

    /*                                                                                                                      ==
       MAIN LAYOUT
                                                                                                                            == */

    .employee-drawer-layout {
        display: flex !important;
        flex-direction: column !important;
        height: 100%;
    }

    /*                                                                                                                      ==
       SIDEBAR -> HORIZONTAL TABS
                                                                                                                            == */

    .employee-sidebar {
        width: 100% !important;
        min-width: 100% !important;
        flex: 0 0 auto !important;

        height: auto !important;
        overflow-x: auto !important;
        overflow-y: hidden !important;

        border-right: 0 !important;
        border-bottom: 1px solid #dee2e6;

        background: #f8fafc !important;
    }

    /* Hide "Employee Dossier" heading */
    .employee-sidebar>.p-3 {
        display: none;
    }

    /* Tab container */
    #employeeTabMenu {
        display: flex !important;
        flex-direction: row !important;

        width: max-content;
        min-width: 100%;

        padding: 5px !important;
        gap: 3px;
    }

    /* Individual tabs */
    .employee-tab {
        flex: 0 0 auto !important;
        width: auto !important;

        padding: 8px 11px !important;

        border: 0 !important;
        border-radius: 5px;

        font-size: 10px !important;
        gap: 5px !important;

        white-space: nowrap;
    }

    .employee-tab i {
        font-size: 14px !important;
        width: auto;
        min-width: auto;
    }

    .employee-tab.active {
        background: #16659E !important;
        color: #fff !important;
        border: 0 !important;
    }

    /*                                                                                                                      ==
       CONTENT
                                                                                                                            == */

    .employee-content {
        width: 100%;
        min-width: 0;

        overflow-x: hidden !important;
        overflow-y: auto !important;
    }

    .employee-panel {
        width: 100%;
        padding: 14px !important;
    }

    /* Section title */
    .employee-section-title {
        font-size: 13px !important;
        margin-bottom: 12px !important;
    }

    /*  PERSONAL / KYC  */

    [data-panel="personal"] .col-md-6,
    [data-panel="personal"] .col-12 {
        width: 100%;
    }

    .employee-card {
        padding: 13px;
    }

    .employee-label {
        font-size: 9px;
    }

    .employee-value {
        font-size: 12px;
        overflow-wrap: anywhere;
    }

    /*        EDUCATION  */

    .emp_education {
        width: 100%;
    }

    .education-card {
        padding: 12px;
    }

    .education-add-box {
        padding: 12px !important;
    }

    .education-add-box .col-md-6 {
        width: 100% !important;
    }

    .education-add-btn {
        width: 100%;
    }

    /*      EXPERIENCE  */

    .experience-item {
        padding: 12px !important;
    }

    .exp-view-mode .d-flex {
        align-items: flex-start !important;
    }

    .exp-view-designation {
        font-size: 13px !important;
    }

    .exp-view-duration {
        font-size: 9px !important;
        white-space: nowrap;
    }

    .exp-view-company {
        font-size: 11px !important;
    }

    .exp-view-roles {
        font-size: 11px !important;
        line-height: 1.5 !important;
    }

    .exp-edit-mode {
        padding-right: 0 !important;
    }

    .exp-edit-mode .col-md-6,
    .exp-edit-mode .col-md-12 {
        width: 100% !important;
    }

    /*        TRAINING  */

    .training-item {
        padding: 12px !important;
    }

    .training-view-title {
        font-size: 12px !important;
    }

    .training-view-date {
        font-size: 10px !important;
    }

    .training-view-status {
        font-size: 9px !important;
        white-space: nowrap;
    }

    .training-edit-mode {
        padding-right: 0 !important;
    }

    .training-edit-mode .col-md-6,
    .training-edit-mode .col-md-3 {
        width: 100% !important;
    }

    /*     REFERENCE CHECKS  */

    .reference-item {
        padding: 12px !important;
    }

    .ref-view-name {
        font-size: 12px !important;
    }

    .ref-view-status {
        font-size: 9px !important;
    }

    .ref-view-mode .gap-3 {
        flex-direction: column !important;
        align-items: flex-start !important;
        gap: 6px !important;
    }

    .ref-view-mode .gap-3>span {
        display: none;
    }

    .ref-edit-mode {
        padding-right: 0 !important;
    }

    .ref-edit-mode .col-md-6 {
        width: 100% !important;
    }

    /*                                                                                                                      ==
       INTERVIEW
                                                                                                                            == */

    .interview-item {
        padding: 12px !important;
    }

    .interview-view-mode .col-md-3 {
        width: 50% !important;
    }

    .interview-view-recruiter,
    .interview-view-date,
    .interview-view-rating {
        font-size: 11px !important;
    }

    .interview-view-comments {
        font-size: 11px !important;
    }

    .interview-edit-mode {
        padding-right: 0 !important;
    }

    .interview-edit-mode .col-md-3,
    .interview-edit-mode .col-12 {
        width: 100% !important;
    }

    /*   FAMILY  */

    .family-member-card {
        padding: 12px !important;
    }

    .family-edit-mode {
        padding-right: 0 !important;
    }

    .family-edit-mode .col-md-6 {
        width: 100%;
    }

    .family-add-box {
        padding: 12px;
    }

    .family-add-box .col-md-6 {
        width: 100% !important;
    }

    .family-add-btn {
        width: 100%;
    }

    .family-member-details {
        display: flex;
        flex-direction: column;
        gap: 5px;
        font-size: 11px;
    }

    .family-divider {
        display: none;
    }

    /*     REMUNERATION  */

    .emp_remuneration {
        padding: 12px !important;
    }

    /* Summary cards - 2 per row */
    .row.g-3.mb-4>.emp_remuneration,
    .row.g-3.mb-4>.emp_remuneration {
        width: 50% !important;
    }

    .row.g-3.mb-4>.emp_remuneration>div {
        padding: 10px !important;
    }

    /* Salary components - one per row */
    .row.g-3>.emp_remuneration {
        width: 100% !important;
    }

    /* Statutory / Banking */
    .emp_remuneration {
        width: 100% !important;
    }

    /* Promotion history */
    .row.g-3 .emp_remuneration {
        width: 100% !important;
    }

    /* Salary inputs */
    input[type="number"] {
        width: 75px !important;
    }

    /*   DOCUMENTS   */
    .document-card {
        padding: 10px !important;
        gap: 8px;
    }

    .document-info {
        min-width: 0;
        flex: 1;
    }

    .document-icon {
        font-size: 25px !important;
    }

    .document-name {
        font-size: 11px;
        overflow-wrap: anywhere;
    }

    .document-meta {
        font-size: 9px;
    }

    .document-status {
        font-size: 8px;
    }

    /* Upload section */
    .document-upload-box {
        padding: 12px;
    }

    .document-upload-box>.d-flex {
        flex-direction: column
    }

    .document-upload-box>.d-flex>div {
        width: 100%;
        min-width: 100%;
    }

    #triggerFileSelectBtn,
    #documentUploadBtn {
        width: 100%;
    }

    /* PREVENT HORIZONTAL OVERFLOW  */

    .employee-drawer * {
        max-width: 100%;
    }

    .employee-drawer .row {
        margin-left: 0;
        margin-right: 0;
    }

    .employee-drawer .font-monospace {
        overflow-wrap: anywhere;
    }
}
</style>


<!-- list Handling start-->
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    let tableState = {
        currentPage: 1
    };

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index,common_date_format) {

        return `
            <tr data-department="Management">
                <!-- Employee -->
                <td class="px-4 py-3" data-bs-toggle="offcanvas" data-bs-target="#employeeDrawer"
                    aria-controls="employeeDrawer" style="cursor:pointer;">
                    <div class="d-flex align-items-center gap-3">
                        <div class="avatar rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                            style="width: 40px; height: 40px; background-color: #eff6ff;color: #16659E;">
                            <i class="mdi mdi-account"></i>
                        </div>
                        <div>
                            <span class="d-block fw-semibold">
                                Arun Kumar
                            </span>
                            <small class="text-muted">
                                arun@example.com
                            </small>
                        </div>
                    </div>
                </td>

                <!-- Designation -->
                <td class="px-4 py-3 hidden md:table-cell">
                    <span class="d-block text-secondary">
                        Project Manager
                    </span>
                    <small class="text-primary">
                        Management
                    </small>
                </td>

                <!-- Site Allocation -->
                <td class="px-4 py-3 hidden sm:table-cell">
                    <div>
                        <span class="d-block fw-semibold text-secondary">
                            SRK Infrastructure Project
                        </span>

                        <small class="text-muted">
                            Bangalore Site
                        </small>
                    </div>
                </td>

                <!-- Wage -->
                <td class="px-4 py-3 text-start">
                    <span class="fw-semibold" style="color: #0C3C62;">
                        Rs.19,000
                    </span>

                    <small class="d-block text-muted" style="font-size: 10px;">
                        Monthly
                    </small>
                </td>

                <!-- Employee Status -->
                <td class="px-4 py-3 text-start">
                    <div class="dropdown">
                        <button type="button" class="btn  dropdown-toggle rounded-2 border-0 fw-semibold"
                            data-bs-toggle="dropdown" aria-expanded="false" style="background-color: {{ $statusStyle['bg'] }};
                                color: {{ $statusStyle['color'] }};font-size: 10px;padding: 6px 10px;">
                            <i class="mdi {{ $statusStyle['icon'] }} me-1"></i>
                            {{ $employeeStatus }}
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 p-1"
                            style="min-width: 145px;">
                            <!-- Active -->
                            <li>
                                <a href="javascript:void(0)"
                                    class="dropdown-item rounded-2 fw-semibold employee-status-option"
                                    data-status="Active" data-employee-id="{{ $employee['id'] ?? '' }}"
                                    style="font-size: 11px; color: #059669;">
                                    <i class="mdi mdi-check-circle-outline me-2"></i>
                                    Active
                                </a>
                            </li>
                            <!-- Inactive -->
                            <li>
                                <a href="javascript:void(0)"
                                    class="dropdown-item rounded-2 fw-semibold employee-status-option"
                                    data-status="Inactive" data-employee-id="{{ $employee['id'] ?? '' }}"
                                    style="font-size: 11px; color: #dc2626;">
                                    <i class="mdi mdi-pause-circle-outline me-2"></i>
                                    Inactive
                                </a>
                            </li>
                            <!-- Exit -->
                            <li>
                                <a href="javascript:void(0)"
                                    class="dropdown-item rounded-2 fw-semibold employee-status-option"
                                    data-status="Exit" data-employee-id="{{ $employee['id'] ?? '' }}"
                                    style="font-size: 11px; color: #ea580c;">
                                    <i class="mdi mdi-exit-run me-2"></i>
                                    Exit
                                </a>
                            </li>
                        </ul>
                    </div>
                </td>

            </tr> 
        `;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;

        const url = `/settings/common_settings?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1,res.common_date_format));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="4" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

</script>
<!-- list Handling End-->


<script>
document.addEventListener('DOMContentLoaded', function() {
    /*  SEARCH   */
    const searchField = document.getElementById('hr-search-field');
    if (searchField) {
        searchField.addEventListener('input', function() {
            const searchValue = this.value
                .toLowerCase()
                .trim();
            const tableRows = document.querySelectorAll(
                '#staff-table tbody tr'
            );

            tableRows.forEach(function(row) {
                const rowText = row.textContent
                    .toLowerCase();
                if (rowText.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
    /*  DEPARTMENT FILTER  */
    const departmentButtons = document.querySelectorAll(
        '.dept-filter-btn'
    );
    departmentButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            /* Remove active state */
            departmentButtons.forEach(function(btn) {
                btn.classList.remove('active');
            });
            /* Add active state */
            this.classList.add('active');
            const selectedDepartment =
                this.getAttribute('data-department');
            const tableRows = document.querySelectorAll(
                '#staff-table tbody tr'
            );
            tableRows.forEach(function(row) {
                const rowDepartment =
                    row.getAttribute('data-department');
                /* ALL = show everything */
                if (
                    selectedDepartment === 'ALL' ||
                    rowDepartment === selectedDepartment
                ) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    });
    /* ADD STAFF   */
    const addStaffButton =
        document.getElementById('hr-add-staff-btn');
    if (addStaffButton) {
        addStaffButton.addEventListener('click', function() {
            console.log('Add Staff Member clicked');
        });
    }
});

// status exit
document.addEventListener('DOMContentLoaded', function() {
    const exitModalElement = document.getElementById('employeeExitModal');
    if (!exitModalElement) {
        return;
    }
    const exitModal = new bootstrap.Modal(exitModalElement);
    const exitEmployeeId = document.getElementById('exit_employee_id');
    const exitDate = document.getElementById('exit_date');
    const exitRemark = document.getElementById('exit_remark');
    /*   Status Selection   */
    document.querySelectorAll('.employee-status-option').forEach(function(option) {
        option.addEventListener('click', function() {
            const status = this.dataset.status;
            const employeeId = this.dataset.employeeId;
            /*    Exit        */
            if (status === 'Exit') {
                exitEmployeeId.value = employeeId;
                // Default date = today
                exitDate.value = new Date().toISOString().split('T')[0];
                exitRemark.value = '';
                exitModal.show();
                return;
            }
            /*       Active / Inactive   */
            updateEmployeeStatus(employeeId, status);
        });
    });
    /*   Confirm Exit    */
    document.getElementById('confirmEmployeeExit')
        .addEventListener('click', function() {
            const employeeId = exitEmployeeId.value;
            const dateOfExit = exitDate.value;
            const remark = exitRemark.value.trim();
            if (!dateOfExit) {
                alert('Please select the Date of Exit.');
                exitDate.focus();
                return;
            }
            if (!remark) {
                alert('Please enter the exit remark.');
                exitRemark.focus();
                return;
            }
            /*  Send Exit Details   */
            updateEmployeeStatus(
                employeeId,
                'Exit',
                dateOfExit,
                remark
            );
            exitModal.hide();
        });
    /* Update Employee Status   */
    function updateEmployeeStatus(
        employeeId,
        status,
        exitDate = null,
        remark = null
    ) {
        console.log({
            employee_id: employeeId,
            status: status,
            exit_date: exitDate,
            remark: remark
        });
        if (status === 'Exit') {
            console.log('Employee Exit Confirmed');
        } else {
            console.log('Employee status changed to:', status);
        }
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const fileInput = document.getElementById('profilePhoto');
    const previewImg = document.getElementById('avatarImage');
    const removeBtn = document.getElementById('removeProfilePhotoBtn');
    const defaultImageSrc = "https://ui-avatars.com/api/?name=PAIGE&background=f8f9fa&color=0d6efd&size=100";

    if (fileInput) {
        fileInput.addEventListener('change', function (event) {
            const file = event.target.files[0];
            if (!file) return;

            if (file.size > 2 * 1024 * 1024) {
                alert('File size exceeds 2 MB. Please upload a smaller image.');
                fileInput.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
                previewImg.src = e.target.result;
                removeBtn.classList.remove('d-none'); 
            };
            reader.readAsDataURL(file);
        });
    }

    if (removeBtn) {
        removeBtn.addEventListener('click', function () {
            fileInput.value = ''; 
            previewImg.src = defaultImageSrc; 
            removeBtn.classList.add('d-none'); 
        });
    }
});

// language selection
// document.addEventListener('DOMContentLoaded', function() {
//     const addLanguageBtn = document.getElementById('addLanguageBtn');
//     const saveLanguageBtn = document.getElementById('saveLanguageBtn');
//     const languageInputSection = document.getElementById('languageInputSection');
//     const languageInput = document.getElementById('languageSkills');
//     const languageTableWrapper = document.getElementById('languageTableWrapper');
//     const languageSkillsBody = document.getElementById('languageSkillsBody');
//     let languageIndex = 0;

//     // SHOW LANGUAGE INPUT
//     addLanguageBtn.addEventListener('click', function() {
//         languageInputSection.style.display = 'block';
//         languageInput.focus();
//     });

//     // ADD LANGUAGE
//     saveLanguageBtn.addEventListener('click', function() {

//         const language = languageInput.value.trim();
//         // Validation
//         if (!language) {
//             alert('Please enter a language.');
//             languageInput.focus();
//             return;

//         }
//         // CHECK DUPLICATE LANGUAGE
//         const existingLanguages =
//             document.querySelectorAll('.language-row');
//         let alreadyExists = false;
//         existingLanguages.forEach(function(row) {
//             const existingLanguage =
//                 row.getAttribute('data-language');
//             if (
//                 existingLanguage &&
//                 existingLanguage.toLowerCase() === language.toLowerCase()
//             ) {
//                 alreadyExists = true;
//             }
//         });
//         if (alreadyExists) {
//             alert(language + ' has already been added.');
//             languageInput.focus();
//             return;
//         }
//         // CREATE TABLE ROW
//         const row = document.createElement('tr');
//         row.classList.add('language-row');
//         row.setAttribute('data-language', language);

//         row.innerHTML = `
//             {{-- LANGUAGE --}}
//             <td>
//                 <span class="fw-semibold text-dark">
//                     ${language}
//                 </span>
//                 <input
//                     type="hidden"
//                     name="languages[${languageIndex}][language]"
//                     value="${language}"
//                 >
//             </td>
//             {{-- READ --}}
//             <td class="text-center">
//                 <div class="form-check d-flex justify-content-center mb-0">
//                     <input
//                         class="form-check-input"
//                         type="checkbox"
//                         name="languages[${languageIndex}][read]"
//                         value="1"
//                     >
//                 </div>
//             </td>
//             {{-- WRITE --}}
//             <td class="text-center">
//                 <div class="form-check d-flex justify-content-center mb-0">
//                     <input
//                         class="form-check-input"
//                         type="checkbox"
//                         name="languages[${languageIndex}][write]"
//                         value="1"
//                     >
//                 </div>
//             </td>
//             {{-- SPEAK --}}
//             <td class="text-center">
//                 <div class="form-check d-flex justify-content-center mb-0">
//                     <input
//                         class="form-check-input"
//                         type="checkbox"
//                         name="languages[${languageIndex}][speak]"
//                         value="1"
//                     >
//                 </div>
//             </td>

//             {{-- ACTION --}}
//             <td class="text-center">
//                 <button
//                     type="button"
//                     class="btn btn-sm btn-outline-danger remove-language"
//                     title="Remove Language"
//                 >
//                     <i class="mdi mdi-delete-outline"></i>
//                 </button>
//             </td>
//         `;

//         // Add row
//         languageSkillsBody.appendChild(row);
//         languageIndex++;

//         // Show table
//         languageTableWrapper.style.display = 'block';

//         // Clear input
//         languageInput.value = '';
//         languageInput.focus();
//     });

//     // REMOVE LANGUAGE
//     languageSkillsBody.addEventListener('click', function(e) {
//         const removeButton =
//             e.target.closest('.remove-language');
//         if (!removeButton) {
//             return;
//         }
//         const row =
//             removeButton.closest('.language-row');
//         if (row) {
//             row.remove();
//         }
//         // Hide table when no languages remain
//         const remainingRows =
//             languageSkillsBody.querySelectorAll('.language-row');
//         if (remainingRows.length === 0) {
//             languageTableWrapper.style.display = 'none';
//         }
//     });
// });

// Login checkbox
document.addEventListener('DOMContentLoaded', function() {

    const loginCheckbox = document.getElementById('isLoginRequired');
    const loginFields = document.getElementById('loginCredentialFields');

    const usernameInput = document.getElementById('loginUsername');
    const pinInput = document.getElementById('loginPin');

    const togglePinButton = document.getElementById('toggleLoginPin');
    const pinIcon = document.getElementById('loginPinIcon');


    // SHOW / HIDE LOGIN FIELDS
    loginCheckbox.addEventListener('change', function() {

        if (this.checked) {
            loginFields.classList.remove('d-none');
            usernameInput.required = true;
            pinInput.required = true;
        } else {
            loginFields.classList.add('d-none');
            usernameInput.required = false;
            pinInput.required = false;
            usernameInput.value = '';
            pinInput.value = '';
            // Reset PIN visibility
            pinInput.type = 'password';
            pinIcon.classList.remove('mdi-eye-off-outline');
            pinIcon.classList.add('mdi-eye-outline');
        }

    });

    // SHOW / HIDE PIN
    togglePinButton.addEventListener('click', function() {
        if (pinInput.type === 'password') {
            pinInput.type = 'text';
            pinIcon.classList.remove('mdi-eye-outline');
            pinIcon.classList.add('mdi-eye-off-outline');
        } else {
            pinInput.type = 'password';
            pinIcon.classList.remove('mdi-eye-off-outline');
            pinIcon.classList.add('mdi-eye-outline');
        }
    });
    // ALLOW ONLY NUMBERS IN PIN
    pinInput.addEventListener('input', function() {

        this.value = this.value.replace(/\D/g, '');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const drawerElement = document.getElementById('employeeDrawer');
    if (!drawerElement) {
        return;
    }
    const drawer = new bootstrap.Offcanvas(drawerElement);

    /* Employee Row Click */
    document.querySelectorAll('.employee-row .employee-click').forEach(cell => {
        cell.addEventListener('click', function(event) {
            // Prevent accidental drawer opening from dropdown/buttons
            if (
                event.target.closest('.dropdown') ||
                event.target.closest('button') ||
                event.target.closest('a')
            ) {
                return;
            }
            const row = this.closest('.employee-row');
            if (!row) {
                return;
            }

            /* Employee ID  */
            const employeeId = row.dataset.employeeId;
            console.log('Opening employee:', employeeId);
            /* Update drawer header from clicked row*/
            const name = row.querySelector('td:first-child .fw-semibold')?.textContent
                .trim();
            const designation = row.querySelector('td:nth-child(2) span')?.textContent
                .trim();
            const department = row.querySelector('td:nth-child(2) small')?.textContent
                .trim();
            document.getElementById('employeeDrawerName').textContent =
                name || '';
            document.getElementById('employeeDrawerDesignation').textContent =
                designation || '';
            document.getElementById('employeeDrawerDepartment').textContent =
                department || '';

            /* Always show Personal tab first */
            showEmployeeTab('personal');
            /* Open Drawer */
            drawer.show();
        });
    });


    /* Sidebar Tab Click  */
    document.querySelectorAll('.employee-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.dataset.tab;
            showEmployeeTab(tabName);
        });
    });

    /*  Show Employee Tab  */
    function showEmployeeTab(tabName) {
        // Remove active state
        document.querySelectorAll('.employee-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        // Add active state
        const activeTab = document.querySelector(
            `.employee-tab[data-tab="${tabName}"]`
        );
        if (activeTab) {
            activeTab.classList.add('active');
        }
        // Hide all panels
        document.querySelectorAll('.employee-panel').forEach(panel => {
            panel.classList.add('d-none');
        });
        // Show selected panel
        const selectedPanel = document.querySelector(
            `.employee-panel[data-panel="${tabName}"]`
        );
        if (selectedPanel) {
            selectedPanel.classList.remove('d-none');
        }
    }
});

// Drawer editable
document.addEventListener('DOMContentLoaded', function() {
    const drawer = document.getElementById('employeeDrawer');
    const editBtn = document.getElementById('employeeEditBtn');
    const editText = document.getElementById('employeeEditText');
    const editIcon = document.getElementById('employeeEditIcon');
    let isEditing = false;
    /* Start / Stop Editing  */
    editBtn.addEventListener('click', function() {
        if (!isEditing) {
            enableEmployeeEditing();
        } else {
            saveEmployeeEditing();
        }
    });
    /* ENABLE EDIT MODE  */
    function enableEmployeeEditing() {
        isEditing = true;
        drawer.classList.add('employee-editing');
        editText.textContent = 'Save';
        editIcon.classList.remove('mdi-pencil-outline');
        editIcon.classList.add('mdi-content-save-outline');
        editBtn.classList.add('is-saving');

        /*  Convert employee values to inputs */
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            // Prevent converting the same element twice
            if (element.dataset.editing === 'true') {
                return;
            }
            const value = element.textContent.trim();
            element.dataset.originalValue = value;
            element.dataset.editing = 'true';

            /*  Interview comments / long text */
            if (
                element.tagName.toLowerCase() === 'p' ||
                value.length > 100
            ) {
                const textarea = document.createElement('textarea');
                textarea.className = 'employee-edit-input';
                textarea.value = value;
                element.innerHTML = '';
                element.appendChild(textarea);
            }
            /*  Normal fields   */
            else {
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'employee-edit-input';
                input.value = value;
                element.innerHTML = '';
                element.appendChild(input);
            }
        });

        /* Convert header employee information to inputs    */
        convertHeaderFields();
    }
    /* SAVE / EXIT EDIT MODE  */
    function saveEmployeeEditing() {
        /* Employee fields */
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            const input = element.querySelector(
                '.employee-edit-input'
            );
            if (!input) {
                return;
            }
            const value = input.value.trim();
            element.textContent = value;
            element.dataset.editing = 'false';
        });

        /* Header fields    */
        const header = drawer.querySelector('.offcanvas-header');
        const nameElement = header.querySelector('h5');
        if (nameElement) {
            const input = nameElement.querySelector(
                '.employee-edit-input'
            );
            if (input) {
                nameElement.textContent = input.value.trim();
            }
            nameElement.dataset.editing = 'false';
        }

        header.querySelectorAll(
            '.d-flex.flex-column > span'
        ).forEach(function(span) {
            const input = span.querySelector(
                '.employee-edit-input'
            );
            if (input) {
                span.textContent = input.value.trim();
            }
            span.dataset.editing = 'false';
        });


        /* Change button back to Edit */
        isEditing = false;
        drawer.classList.remove('employee-editing');
        editText.textContent = 'Edit';
        editIcon.classList.remove('mdi-content-save-outline');
        editIcon.classList.add('mdi-pencil-outline');
        editBtn.classList.remove('is-saving');
    }

    /* Reset edit mode when drawer closes */

    drawer.addEventListener('hidden.bs.offcanvas', function() {
        if (isEditing) {
            cancelEditing();
        }
    });

    /* Cancel Editing  */
    function cancelEditing() {
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            const originalValue =
                element.dataset.originalValue;

            if (originalValue !== undefined) {
                element.textContent = originalValue;
            }
            element.dataset.editing = 'false';
        });
        const header = drawer.querySelector('.offcanvas-header');
        const nameElement = header.querySelector('h5');
        if (nameElement) {
            const originalValue =
                nameElement.dataset.originalValue;
            if (originalValue !== undefined) {
                nameElement.textContent = originalValue;
            }
            nameElement.dataset.editing = 'false';
        }

        header.querySelectorAll(
            '.d-flex.flex-column > span'
        ).forEach(function(span) {
            const originalValue =
                span.dataset.originalValue;
            if (originalValue !== undefined) {
                span.textContent = originalValue;
            }
            span.dataset.editing = 'false';
        });
        isEditing = false;
        drawer.classList.remove('employee-editing');
        editText.textContent = 'Edit';
        editIcon.classList.remove('mdi-content-save-outline');
        editIcon.classList.add('mdi-pencil-outline');
        editBtn.classList.remove('is-saving');
    }
});

// for work experience
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const container = document.getElementById('experienceContainer');

    let isEditing = false;

    // Template matching exact UI structure
    function createNewExperienceCard() {
        return `
            <div class="card mb-3 p-3 position-relative experience-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-exp-btn py-0 px-1" title="Delete Experience" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="exp-view-mode d-none">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-bold exp-view-designation" style="font-size: 14px; color: #1e293b;"></span>
                        <span class="badge rounded-1 exp-view-duration" style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;"></span>
                    </div>
                    <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;"></div>
                    <div class="exp-view-roles mt-2" style="font-size: 13px; color: #64748b; line-height: 1.4;"></div>
                </div>

                <div class="exp-edit-mode mt-2 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Designation</label>
                            <input type="text" class="form-control form-control-sm exp-input-designation" style="font-size: 11px;" placeholder="e.g. Lead Engineer">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Company Name</label>
                            <input type="text" class="form-control form-control-sm exp-input-company" style="font-size: 11px;" placeholder="e.g. SRK Infrastructure">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Duration</label>
                            <input type="text" class="form-control form-control-sm exp-input-duration" style="font-size: 11px;" placeholder="e.g. 2022 - Present">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles & Responsibilities</label>
                            <textarea class="form-control form-control-sm exp-input-roles" rows="2" style="font-size: 11px;" placeholder="Describe key roles..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Toggle Edit / Save State
    editBtn.addEventListener('click', function() {
        isEditing = !isEditing;

        if (isEditing) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show Edit Mode for existing items
            document.querySelectorAll('.experience-item').forEach(item => {
                item.querySelector('.exp-view-mode').classList.add('d-none');
                item.querySelector('.exp-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-exp-btn').classList.remove('d-none');
            });

            // Automatically append new entry input block
            container.insertAdjacentHTML('beforeend', createNewExperienceCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            document.querySelectorAll('.experience-item').forEach(item => {
                const designation = item.querySelector('.exp-input-designation').value.trim();
                const company = item.querySelector('.exp-input-company').value.trim();
                const duration = item.querySelector('.exp-input-duration').value.trim();
                const roles = item.querySelector('.exp-input-roles').value.trim();

                // If user left a newly generated card completely blank, remove it
                if (!designation && !company && !duration && !roles) {
                    item.remove();
                    return;
                }

                // Sync inputs back into View Mode format
                item.querySelector('.exp-view-designation').textContent = designation || 'N/A';
                item.querySelector('.exp-view-company').textContent = company || 'N/A';
                item.querySelector('.exp-view-duration').textContent = duration || 'N/A';
                item.querySelector('.exp-view-roles').textContent = roles;

                item.querySelector('.exp-edit-mode').classList.add('d-none');
                item.querySelector('.exp-view-mode').classList.remove('d-none');
                item.querySelector('.delete-exp-btn').classList.add('d-none');
            });
        }
    });

    // Delete item functionality
    container.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-exp-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.experience-item');
            card.remove();
        }
    });
});

// for training induction
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const trainingContainer = document.getElementById('trainingContainer');

    let isEditing = false;

    if (editBtn && trainingContainer) {
        editBtn.addEventListener('click', function() {
            isEditing = !isEditing;
            const trainingItems = trainingContainer.querySelectorAll('.training-item');

            if (isEditing) {
                // UI: Switch button to "Save" (Success state)
                editText.textContent = 'Save';
                editIcon.className = 'mdi mdi-check-bold';
                editBtn.style.background = '#198754';
                editBtn.style.borderColor = '#198754';

                // Reveal edit fields and trash icons
                trainingItems.forEach(item => {
                    item.querySelector('.training-view-mode').classList.add('d-none');
                    item.querySelector('.training-edit-mode').classList.remove('d-none');
                    item.querySelector('.delete-training-btn').classList.remove('d-none');
                });
            } else {
                // UI: Switch button back to "Edit" (Default state)
                editText.textContent = 'Edit';
                editIcon.className = 'mdi mdi-pencil-outline';
                editBtn.style.background = 'rgba(255,255,255,0.12)';
                editBtn.style.borderColor = 'rgba(255,255,255,0.25)';

                // Sync data and return to view mode
                trainingItems.forEach(item => {
                    // 1. Read updated values from inputs
                    const titleVal = item.querySelector('.training-input-title').value;
                    const dateVal = item.querySelector('.training-input-date').value;
                    const statusVal = item.querySelector('.training-input-status').value;

                    // 2. Inject updated values into the view text
                    item.querySelector('.training-view-title').textContent = titleVal;
                    item.querySelector('.training-view-date').textContent = dateVal;

                    const statusBadge = item.querySelector('.training-view-status');
                    statusBadge.textContent = statusVal;

                    // 3. Dynamically update badge styling based on dropdown selection
                    statusBadge.className = 'badge training-view-status ';
                    if (statusVal === 'Completed') {
                        statusBadge.className += 'bg-success-subtle text-success';
                    } else if (statusVal === 'Pending') {
                        statusBadge.className += 'bg-warning-subtle text-warning';
                    } else {
                        statusBadge.className +=
                            'bg-info-subtle text-info'; // For "In Progress"
                    }

                    // 4. Hide edit fields and trash icons
                    item.querySelector('.training-view-mode').classList.remove('d-none');
                    item.querySelector('.training-edit-mode').classList.add('d-none');
                    item.querySelector('.delete-training-btn').classList.add('d-none');
                });
            }
        });

        // Event delegation for dynamic deletion of training cards
        trainingContainer.addEventListener('click', function(e) {
            const deleteBtn = e.target.closest('.delete-training-btn');
            if (deleteBtn) {
                // Optional: add a confirmation dialogue here if needed
                deleteBtn.closest('.training-item').remove();
            }
        });
    }
});

// for Reference
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const referenceContainer = document.getElementById('referenceContainer');

    let isEditingReference = false;

    // Status badge formatting function
    function getRefStatusBadgeClass(status) {
        switch (status) {
            case 'VERIFIED':
                return 'bg-success-subtle text-success';
            case 'PENDING':
                return 'bg-warning-subtle text-warning';
            case 'UNVERIFIED':
                return 'bg-danger-subtle text-danger';
            default:
                return 'bg-secondary-subtle text-secondary';
        }
    }

    // Dynamic template for appending blank reference fields
    function createNewReferenceCard() {
        return `
            <div class="card mb-3 p-3 position-relative reference-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-ref-btn py-0 px-1" title="Delete Reference" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="ref-view-mode d-none">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex align-items-center gap-2">
                            <span class="fw-bold ref-view-name" style="font-size: 14px; color: #1e293b;"></span>
                            <span class="badge ref-view-status" style="font-weight: 600; font-size: 10px; padding: 3px 6px;"></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-3 text-secondary" style="font-size: 13px; color: #64748b;">
                        <div>
                            <small class="text-muted">Designation:</small>
                            <span class="ref-view-designation fw-medium" style="color: #334155;"></span>
                        </div>
                        <span style="border-right: 1px solid #cbd5e1; height: 12px;"></span>
                        <div>
                            <small class="text-muted">Phone:</small>
                            <span class="ref-view-phone fw-medium" style="color: #334155;"></span>
                        </div>
                    </div>
                </div>

                <div class="ref-edit-mode mt-1 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Full Name</label>
                            <input type="text" class="form-control form-control-sm ref-input-name" style="font-size: 11px;" placeholder="e.g. Suresh Raina">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Verification Status</label>
                            <select class="form-select form-select-sm ref-input-status" style="font-size: 11px;">
                                <option value="PENDING" selected>PENDING</option>
                                <option value="VERIFIED">VERIFIED</option>
                                <option value="UNVERIFIED">UNVERIFIED</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Designation</label>
                            <input type="text" class="form-control form-control-sm ref-input-designation" style="font-size: 11px;" placeholder="e.g. Site Supervisor">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Phone Number</label>
                            <input type="text" class="form-control form-control-sm ref-input-phone" style="font-size: 11px;" placeholder="e.g. +91 98765 00000">
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Single Edit Button Listener (Handles Reference Panel Active State)
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'references') return;

        isEditingReference = !isEditingReference;

        if (isEditingReference) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Switch existing cards to edit mode
            referenceContainer.querySelectorAll('.reference-item').forEach(item => {
                item.querySelector('.ref-view-mode').classList.add('d-none');
                item.querySelector('.ref-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-ref-btn').classList.remove('d-none');
            });

            // Automatically insert blank card inputs for fresh reference
            referenceContainer.insertAdjacentHTML('beforeend', createNewReferenceCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            referenceContainer.querySelectorAll('.reference-item').forEach(item => {
                const name = item.querySelector('.ref-input-name').value.trim();
                const status = item.querySelector('.ref-input-status').value;
                const designation = item.querySelector('.ref-input-designation').value.trim();
                const phone = item.querySelector('.ref-input-phone').value.trim();

                // If new card is left empty, automatically clean it up
                if (!name && !designation && !phone) {
                    item.remove();
                    return;
                }

                // Update View UI Elements
                item.querySelector('.ref-view-name').textContent = name || 'N/A';
                item.querySelector('.ref-view-designation').textContent = designation || 'N/A';
                item.querySelector('.ref-view-phone').textContent = phone || 'N/A';

                const statusBadge = item.querySelector('.ref-view-status');
                statusBadge.textContent = status;
                statusBadge.className =
                    `badge ${getRefStatusBadgeClass(status)} ref-view-status`;

                item.querySelector('.ref-edit-mode').classList.add('d-none');
                item.querySelector('.ref-view-mode').classList.remove('d-none');
                item.querySelector('.delete-ref-btn').classList.add('d-none');
            });
        }
    });

    // Delete item listener
    referenceContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-ref-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.reference-item');
            card.remove();
        }
    });
});

// for interview
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const interviewContainer = document.getElementById('interviewContainer');

    let isEditingInterview = false;

    // Helper badge styling function for HR Verdict
    function getVerdictBadgeClass(verdict) {
        switch (verdict) {
            case 'Selected':
                return 'bg-success-subtle text-success';
            case 'On Hold':
                return 'bg-warning-subtle text-warning';
            case 'Rejected':
                return 'bg-danger-subtle text-danger';
            default:
                return 'bg-secondary-subtle text-secondary';
        }
    }

    // Dynamic template for appending blank interview card inputs
    function createNewInterviewCard() {
        return `
            <div class="card mb-3 p-3 position-relative interview-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-interview-btn py-0 px-1" title="Delete Interview Log" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="interview-view-mode d-none">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Screening Recruiter</small>
                            <span class="fw-semibold interview-view-recruiter" style="font-size: 13px; color: #1e293b;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Evaluation Date</small>
                            <span class="fw-medium interview-view-date" style="font-size: 13px; color: #334155;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Rating</small>
                            <span class="fw-medium interview-view-rating" style="font-size: 13px; color: #334155;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">HR Decision Verdict</small>
                            <span class="badge interview-view-verdict" style="font-weight: 600; font-size: 11px; padding: 4px 8px;"></span>
                        </div>
                        <div class="col-12 mt-2">
                            <small class="text-muted d-block" style="font-size: 11px;">Comments</small>
                            <p class="mb-0 interview-view-comments" style="font-size: 13px; color: #64748b; line-height: 1.4;"></p>
                        </div>
                    </div>
                </div>

                <div class="interview-edit-mode mt-1 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Screening Recruiter</label>
                            <input type="text" class="form-control form-control-sm interview-input-recruiter" style="font-size: 11px;" placeholder="e.g. Ramesh Chandra">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Evaluation Date</label>
                            <input type="text" class="form-control form-control-sm interview-input-date" style="font-size: 11px;" placeholder="e.g. 15 Aug 2024">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Rating</label>
                            <input type="text" class="form-control form-control-sm interview-input-rating" style="font-size: 11px;" placeholder="e.g. 4.0 / 5">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">HR Decision Verdict</label>
                            <select class="form-select form-select-sm interview-input-verdict" style="font-size: 11px;">
                                <option value="Selected" selected>Selected</option>
                                <option value="On Hold">On Hold</option>
                                <option value="Rejected">Rejected</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Assessment Comments</label>
                            <textarea class="form-control form-control-sm interview-input-comments" rows="2" style="font-size: 11px;" placeholder="Enter assessment comments..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Toggle Edit / Save State for Interview Panel
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'interview') return;

        isEditingInterview = !isEditingInterview;

        if (isEditingInterview) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show edit mode for all existing entries
            interviewContainer.querySelectorAll('.interview-item').forEach(item => {
                item.querySelector('.interview-view-mode').classList.add('d-none');
                item.querySelector('.interview-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-interview-btn').classList.remove('d-none');
            });

            // Automatically append new entry inputs
            interviewContainer.insertAdjacentHTML('beforeend', createNewInterviewCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            interviewContainer.querySelectorAll('.interview-item').forEach(item => {
                const recruiter = item.querySelector('.interview-input-recruiter').value.trim();
                const date = item.querySelector('.interview-input-date').value.trim();
                const rating = item.querySelector('.interview-input-rating').value.trim();
                const verdict = item.querySelector('.interview-input-verdict').value;
                const comments = item.querySelector('.interview-input-comments').value.trim();

                // If user left a newly appended card completely empty, remove it
                if (!recruiter && !date && !rating && !comments) {
                    item.remove();
                    return;
                }

                // Sync view content with inputs
                item.querySelector('.interview-view-recruiter').textContent = recruiter ||
                    'N/A';
                item.querySelector('.interview-view-date').textContent = date || 'N/A';
                item.querySelector('.interview-view-rating').textContent = rating || 'N/A';
                item.querySelector('.interview-view-comments').textContent = comments ||
                    'No comments provided.';

                const verdictBadge = item.querySelector('.interview-view-verdict');
                verdictBadge.textContent = verdict;
                verdictBadge.className =
                    `badge ${getVerdictBadgeClass(verdict)} interview-view-verdict`;

                item.querySelector('.interview-edit-mode').classList.add('d-none');
                item.querySelector('.interview-view-mode').classList.remove('d-none');
                item.querySelector('.delete-interview-btn').classList.add('d-none');
            });
        }
    });

    // Delete item event listener
    interviewContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-interview-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.interview-item');
            card.remove();
        }
    });
});
// for family
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const familyContainer = document.getElementById('familyContainer');
    const familyAddBox = document.getElementById('familyAddBox');
    const appendFamilyBtn = document.getElementById('appendFamilyBtn');

    let isEditingFamily = false;

    // Build standard structure for dynamically added family members
    function createFamilyCardElement(name, relation, age, occupation) {
        const card = document.createElement('div');
        card.className = 'family-member-card mb-3 family-item position-relative';
        card.innerHTML = `
            <button type="button" class="family-delete-btn position-absolute top-0 end-0 m-3 delete-family-btn" title="Remove Family Member">
                <i class="mdi mdi-trash-can-outline"></i>
            </button>

            <div class="family-view-mode d-none">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="family-member-name family-view-name">${name}</span>
                            <span class="family-relation-badge family-view-relation">${relation.toUpperCase()}</span>
                        </div>
                        <div class="family-member-details">
                            <span>
                                <small>Age:</small>
                                <span class="family-view-age">${age}</span> Years
                            </span>
                            <span class="family-divider"></span>
                            <span>
                                <small>Occupation:</small>
                                <span class="family-view-occupation">${occupation}</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="family-edit-mode pe-4">
                <div class="row g-2">
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full Name</label>
                        <input type="text" class="form-control form-control-sm family-input-name" style="font-size: 11px;" value="${name}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Relation</label>
                        <input type="text" class="form-control form-control-sm family-input-relation" style="font-size: 11px;" value="${relation}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                        <input type="number" class="form-control form-control-sm family-input-age" style="font-size: 11px;" value="${age}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Occupation</label>
                        <input type="text" class="form-control form-control-sm family-input-occupation" style="font-size: 11px;" value="${occupation}">
                    </div>
                </div>
            </div>
        `;
        return card;
    }

    // Single Edit Button Listener (Handles Family Panel Active State)
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'family') return;

        isEditingFamily = !isEditingFamily;

        if (isEditingFamily) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show edit modes & action panel
            familyContainer.querySelectorAll('.family-item').forEach(item => {
                item.querySelector('.family-view-mode').classList.add('d-none');
                item.querySelector('.family-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-family-btn').classList.remove('d-none');
            });

            familyAddBox.classList.remove('d-none');

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            // Sync input values back to view mode elements
            familyContainer.querySelectorAll('.family-item').forEach(item => {
                const name = item.querySelector('.family-input-name').value.trim();
                const relation = item.querySelector('.family-input-relation').value.trim();
                const age = item.querySelector('.family-input-age').value.trim();
                const occupation = item.querySelector('.family-input-occupation').value.trim();

                // Clear blank entries
                if (!name && !relation && !age && !occupation) {
                    item.remove();
                    return;
                }

                item.querySelector('.family-view-name').textContent = name || 'N/A';
                item.querySelector('.family-view-relation').textContent = (relation || 'N/A')
                    .toUpperCase();
                item.querySelector('.family-view-age').textContent = age || 'N/A';
                item.querySelector('.family-view-occupation').textContent = occupation || 'N/A';

                item.querySelector('.family-edit-mode').classList.add('d-none');
                item.querySelector('.family-view-mode').classList.remove('d-none');
                item.querySelector('.delete-family-btn').classList.add('d-none');
            });

            familyAddBox.classList.add('d-none');
        }
    });

    // Handle "Append Family Member" action button
    appendFamilyBtn.addEventListener('click', function() {
        const nameInput = document.getElementById('newFamilyName');
        const relationInput = document.getElementById('newFamilyRelation');
        const ageInput = document.getElementById('newFamilyAge');
        const occupationInput = document.getElementById('newFamilyOccupation');

        const name = nameInput.value.trim();
        const relation = relationInput.value.trim();
        const age = ageInput.value.trim();
        const occupation = occupationInput.value.trim();

        if (!name && !relation) {
            alert('Please enter at least a name and relation.');
            return;
        }

        const newCard = createFamilyCardElement(name, relation, age, occupation);
        familyContainer.appendChild(newCard);

        // Reset inputs
        nameInput.value = '';
        relationInput.value = '';
        ageInput.value = '';
        occupationInput.value = '';
    });

    // Delete item listener
    familyContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-family-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.family-item');
            card.remove();
        }
    });
});
// Remuneration
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    if (!editBtn) return;
    editBtn.addEventListener('click', function() {
        const isEditing = editBtn.dataset.editing === 'true';
        const fields = [
            'componentATotal',
            'basic',
            'hra',
            'special',
            'componentBTotal',
            'epfEmployee',
            'esiEmployee',
            'pt',
            'tds',
            'componentCTotal',
            'epfEmployer',
            'esiEmployer',
            'gratuity'
        ];
        fields.forEach(function(field) {
            const view = document.getElementById(field + 'View');
            const edit = document.getElementById(field + 'Edit');
            if (!view || !edit) return;
            if (!isEditing) {
                // View → Edit
                view.classList.add('d-none');
                edit.classList.remove('d-none');
            } else {
                // Edit → View
                const input = edit.querySelector('input');
                if (input) {
                    const value = Number(input.value || 0);
                    view.querySelector('span').textContent =
                        '₹ ' + value.toLocaleString('en-IN');
                }
                edit.classList.add('d-none');
                view.classList.remove('d-none');
            }
        });
        // Update button state
        editBtn.dataset.editing = (!isEditing).toString();
        const icon = document.getElementById('employeeEditIcon');
        const text = document.getElementById('employeeEditText');
        if (!isEditing) {
            // Edit mode
            icon.className = 'mdi mdi-content-save-outline';
            text.textContent = 'Save';
        } else {
            // View mode
            icon.className = 'mdi mdi-pencil-outline';
            text.textContent = 'Edit';
        }
    });
});

// document upload for employee files
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');

    const documentsGrid = document.getElementById('documentsGrid');
    const documentUploadBox = document.getElementById('documentUploadBox');
    const fileInput = document.getElementById('documentFileInput');
    const triggerFileBtn = document.getElementById('triggerFileSelectBtn');
    const uploadBtn = document.getElementById('documentUploadBtn');
    const documentTypeSelect = document.getElementById('documentType');

    let isEditing = false;

    // Toggle Edit / Save Mode
    if (editBtn) {
        editBtn.addEventListener('click', function() {
            isEditing = !isEditing;

            if (isEditing) {
                // Update button state to Save
                editText.textContent = 'Save';
                editIcon.className = 'mdi mdi-check-bold';
                editBtn.style.background = '#198754';
                editBtn.style.borderColor = '#198754';

                // Reveal upload section and document deletion buttons
                if (documentUploadBox) documentUploadBox.classList.remove('d-none');
                if (documentsGrid) {
                    documentsGrid.querySelectorAll('.document-delete-btn').forEach(btn => btn.classList
                        .remove('d-none'));
                }
            } else {
                // Reset button state to Edit
                editText.textContent = 'Edit';
                editIcon.className = 'mdi mdi-pencil-outline';
                editBtn.style.background = 'rgba(255,255,255,0.12)';
                editBtn.style.borderColor = 'rgba(255,255,255,0.25)';

                // Hide upload section and document deletion buttons
                if (documentUploadBox) documentUploadBox.classList.add('d-none');
                if (documentsGrid) {
                    documentsGrid.querySelectorAll('.document-delete-btn').forEach(btn => btn.classList
                        .add('d-none'));
                }
            }
        });
    }

    // File selection trigger
    if (triggerFileBtn && fileInput) {
        triggerFileBtn.addEventListener('click', function() {
            fileInput.click();
        });

        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                triggerFileBtn.textContent = this.files[0].name;
                triggerFileBtn.classList.remove('btn-outline-secondary');
                triggerFileBtn.classList.add('btn-outline-primary');
            } else {
                triggerFileBtn.innerHTML = '<i class="mdi mdi-paperclip me-1"></i> Select File...';
                triggerFileBtn.classList.remove('btn-outline-primary');
                triggerFileBtn.classList.add('btn-outline-secondary');
            }
        });
    }

    // Helper for formatting file size
    function formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    // Append new uploaded file card
    if (uploadBtn) {
        uploadBtn.addEventListener('click', function() {
            if (!fileInput.files || !fileInput.files[0]) {
                alert('Please select a file to upload.');
                return;
            }

            const file = fileInput.files[0];
            const docName = file.name;
            const docSize = formatBytes(file.size);
            const docCategory = documentTypeSelect.options[documentTypeSelect.selectedIndex].text;
            const deleteBtnVisibility = isEditing ? '' : 'd-none';

            const card = document.createElement('div');
            card.className =
                'document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between';
            card.innerHTML = `
                <div class="document-info d-flex align-items-center gap-3">
                    <div class="document-icon text-primary fs-3">
                        <i class="mdi mdi-file-document-outline"></i>
                    </div>
                    <div class="document-details">
                        <div class="document-name fw-semibold" style="font-size: 13px;">${docName}</div>
                        <div class="document-meta text-muted" style="font-size: 11px;">
                            ${docCategory}
                            <span class="document-meta-divider mx-1">•</span>
                            ${docSize}
                        </div>
                    </div>
                </div>
                <div class="document-actions d-flex align-items-center gap-2">
                    <span class="document-status badge bg-warning-subtle text-warning px-2 py-1" style="font-size: 10px;">
                        Pending
                    </span>
                    <button type="button" class="btn btn-sm btn-link text-danger p-0 document-delete-btn ${deleteBtnVisibility}" title="Remove Document">
                        <i class="mdi mdi-trash-can-outline fs-5"></i>
                    </button>
                </div>
            `;

            documentsGrid.appendChild(card);

            // Reset inputs
            fileInput.value = '';
            triggerFileBtn.innerHTML = '<i class="mdi mdi-paperclip me-1"></i> Select File...';
            triggerFileBtn.classList.remove('btn-outline-primary');
            triggerFileBtn.classList.add('btn-outline-secondary');
        });
    }

    // Dynamic document deletion
    if (documentsGrid) {
        documentsGrid.addEventListener('click', function(e) {
            const deleteBtn = e.target.closest('.document-delete-btn');
            if (deleteBtn) {
                deleteBtn.closest('.document-card').remove();
            }
        });
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('emergencyContactContainer');
    const addBtn = document.getElementById('addEmergencyContactBtn');
    let contactIndex = 1;

    // Function to create a new contact row
    addBtn.addEventListener('click', function() {
        const newRow = document.createElement('div');
        newRow.className = 'row g-3 emergency-contact-row mb-2 align-items-center';
        
        newRow.innerHTML = `
            <div class="col-md-5">
                <label class="form-label fw-semibold">Contact Name</label>
                <input type="text" class="form-control" name="emergency_contacts[${contactIndex}][name]" placeholder="Enter contact name">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Relation</label>
                <select class="select3 form-select" name="emergency_contacts[${contactIndex}][relation]">
                    <option value="">Select relation</option>
                    <option value="Parent">Parent</option>
                    <option value="Child">Child</option>
                    <option value="Spouse">Spouse</option>
                    <option value="Sibling">Sibling</option>
                    <option value="Guardian">Guardian</option>
                </select>
            </div>
            <div class="col-md-3 position-relative">
                <label class="form-label fw-semibold">Contact Number</label>
                <div class="d-flex align-items-center">
                    <input type="tel" class="form-control" name="emergency_contacts[${contactIndex}][number]" placeholder="Enter contact number">
                    {{-- Remove Button neatly nested inside the row --}}
                    <button type="button" class="btn btn-sm btn-link text-danger p-0 ms-2 remove-contact-btn" title="Remove Contact">
                        <i class="mdi mdi-trash-can-outline fs-5"></i>
                    </button>
                </div>
            </div>
        `;

        // Initialize Select2 if it exists
        const newSelect = newRow.querySelector('.select3');
        if (typeof $ !== 'undefined' && $.fn.select2) {
            $(newSelect).select2({ 
                placeholder: "Select relation", 
                allowClear: true,
                dropdownParent: $('#staffDrawer') 
            });
        }

        container.appendChild(newRow);
        contactIndex++;
    });

    // Event delegation for removing rows
    container.addEventListener('click', function(e) {
        const removeBtn = e.target.closest('.remove-contact-btn');
        if (removeBtn) {
            removeBtn.closest('.emergency-contact-row').remove();
        }
    });
});

function showFileName(inputElement, targetId) {
    const file = inputElement.files[0];
    const target = document.getElementById(targetId);
    
    if (file) {
        // Add a checkmark icon and the file name
        target.innerHTML = `<i class="mdi mdi-check-circle me-1"></i> ${file.name}`;
    } else {
        // Clear if no file is selected
        target.innerHTML = '';
    }
}
</script>

@endsection
