@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('content')

@php

$permanentEmployees = [
[
'id' => 1,
'name' => 'Arun Kumar',
'role' => 'Project Manager',
'department' => 'Management',
'status' => 'Present',
],
[
'id' => 2,
'name' => 'Suresh Raj',
'role' => 'Civil Engineer',
'department' => 'Engineering',
'status' => 'On Leave',
],
[
'id' => 3,
'name' => 'Priya Devi',
'role' => 'Supervisor',
'department' => 'General Labor',
'status' => 'Present',
],
[
'id' => 4,
'name' => 'Karthik Kumar',
'role' => 'Quality Inspector',
'department' => 'Quality Control',
'status' => 'Present',
],
[
'id' => 5,
'name' => 'Meena Devi',
'role' => 'Accountant',
'department' => 'Accounts',
'status' => 'Present',
],
];

$leaveRequests = [
[
'id' => 1,
'employeeId' => 2,
'employeeName' => 'Suresh Raj',
'leaveType' => 'Casual',
'startDate' => '2026-07-22',
'endDate' => '2026-07-23',
'days' => 2,
'appliedDate' => '2026-07-20',
'reason' => 'Personal work',
'status' => 'Pending',
],
[
'id' => 2,
'employeeId' => 1,
'employeeName' => 'Arun Kumar',
'leaveType' => 'Privilege',
'startDate' => '2026-07-10',
'endDate' => '2026-07-12',
'days' => 3,
'appliedDate' => '2026-07-05',
'reason' => 'Family function',
'status' => 'Approved',
],
[
'id' => 3,
'employeeId' => 4,
'employeeName' => 'Karthik Kumar',
'leaveType' => 'Sick',
'startDate' => '2026-07-15',
'endDate' => '2026-07-15',
'days' => 1,
'appliedDate' => '2026-07-15',
'reason' => 'Medical leave',
'status' => 'Approved',
],
];

$totalPersonnel = count($permanentEmployees);

$onLeaveToday = count(array_filter($permanentEmployees, function ($employee) {
return $employee['status'] === 'On Leave';
}));

$pendingRequests = count(array_filter($leaveRequests, function ($request) {
return $request['status'] === 'Pending';
}));

$approvedThisMonth = count(array_filter($leaveRequests, function ($request) {
return $request['status'] === 'Approved';
}));

@endphp


<div class="container-fluid px-0 leave-page">

    {{-- ============================================================
        PAGE HEADER
    ============================================================= --}}
    <div class="card border-0 shadow-sm leave-header-card mb-3">
        <div class="card-body px-3 py-3">

            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start
                        align-items-md-center  gap-2">
                <div>
                    <h4 class="mb-1 fw-bold" style="color:#0C3C62;">
                        Leave Management
                    </h4>
                </div>

                <button type="button" class="btn btn-primary btn-sm rounded-2 px-3" data-bs-toggle="modal"
                    data-bs-target="#applyLeaveModal">
                    <i class="mdi mdi-plus me-1"></i>
                    Apply Leave
                </button>
            </div>
        </div>
    </div>


    {{--  LEAVE POLICY --}}
    <div class="row leave-policy-row">
        {{-- Casual Leave --}}
        <div class="col-12 col-md-6 col-xl-4 leave-policy-col">
            <div class="leave-policy-card">
                <div class="leave-policy-title">
                    <span class="leave-type-badge leave-type-cl fs-7">
                        CL
                    </span>
                    <h4 class="fs-4">
                        Casual Leave Eligibility
                    </h4>
                </div>
                <div class="leave-policy-details">
                    <div class="leave-policy-item fs-6">
                        <span>Permanent Quota</span>
                        <strong class="leave-blue">
                            12 Days / Year
                        </strong>
                    </div>
                    <div class="leave-policy-item fs-6">
                        <span>Contract Quota</span>
                        <strong>
                            7 Days / Year
                        </strong>
                    </div>
                </div>
            </div>
        </div>

        {{-- Privilege Leave --}}
        <div class="col-12 col-md-6 col-xl-4 leave-policy-col">
            <div class="leave-policy-card">
                <div class="leave-policy-title">
                    <span class="leave-type-badge leave-type-pl fs-7">
                        PL
                    </span>
                    <h4 class="fs-4">
                        Privilege / Earned Leave
                    </h4>
                </div>
                <div class="leave-policy-details">
                    <div class="leave-policy-item fs-6">
                        <span>Permanent Quota</span>
                        <strong class="leave-green">
                            15 Days / Year
                        </strong>
                    </div>
                    <div class="leave-policy-item fs-6">
                        <span>Contract Quota</span>
                        <strong>
                            10 Days / Year
                        </strong>
                    </div>
                </div>
            </div>
        </div>
        {{-- Sick Leave --}}
        <div class="col-12 col-md-12 col-xl-4 leave-policy-col">
            <div class="leave-policy-card">
                <div class="leave-policy-title">
                    <span class="leave-type-badge leave-type-sl fs-7 ">
                        SL
                    </span>
                    <h4 class="fs-4">
                        Sick / Medical Leave
                    </h4>
                </div>

                <div class="leave-policy-details">
                    <div class="leave-policy-item fs-6">
                        <span>Permanent Quota</span>
                        <strong class="leave-amber">
                            12 Days / Year
                        </strong>
                    </div>
                    <div class="leave-policy-item fs-6">
                        <span>Contract Quota</span>
                        <strong>
                            7 Days / Year
                        </strong>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{--  NAVIGATION --}}
    <div class="card border-0 shadow-sm leave-navigation-card mb-3">
        <div class="card-body p-2">
            <div class="d-flex flex-column flex-lg-row justify-content-between gap-2">
                <div class="d-flex flex-wrap gap-2">
                    <a href="{{ route('admin-hr.leave.permanent') }}" class="btn btn-light btn-sm rounded-2">
                        <i class="mdi mdi-calendar-check-outline me-1"></i>
                        Leave Applications
                        <span class="badge bg-secondary ms-1">
                            {{ count($leaveRequests) }}
                        </span>
                    </a>


                    <a href="{{ route('admin-hr.leave.permanent_entitle') }}" class="btn btn-primary btn-sm rounded-2">

                        <i class="mdi mdi-table me-1"></i>

                        Leave Entitlement

                        <span class="badge bg-light text-primary ms-1">
                            {{ $totalPersonnel }}
                        </span>
                    </a>
                </div>
                <div>
                    <button type="button" class="btn btn-outline-secondary btn-sm rounded-2" data-bs-toggle="modal"
                        data-bs-target="#leaveSettingsModal">
                        <i class="mdi mdi-cog-outline me-1"></i>
                        Configure Settings
                    </button>
                </div>
            </div>
        </div>
    </div>


    {{-- LEAVE LEDGER --}}
    <div class="leave-ledger-card">
        {{-- Header --}}
        <div class="leave-ledger-header">
            <div class="leave-ledger-heading">
                <h3 class="fs-6">
                    <i class="mdi mdi-calendar-check-outline"></i>
                    Employee Leave Entitlements & Balances
                </h3>

            </div>


            {{-- Controls --}}
            <div class="leave-ledger-controls">
                <div class="leave-search-box">
                    <i class="mdi mdi-magnify"></i>
                    <input type="text" placeholder="Search employee...">
                </div>
                <button type="button" class="leave-action-btn leave-credit-btn" data-bs-toggle="modal"
                    data-bs-target="#batchCreditModal">
                    <i class="mdi mdi-plus"></i>
                    <span>Batch Credit Leaves</span>
                </button>
                <button type="button" class="leave-action-btn leave-export-btn">
                    <i class="mdi mdi-download"></i>
                    <span>
                        Export CSV
                    </span>
                </button>
            </div>
        </div>


        {{-- TABLE--}}
        <div class="leave-table-wrapper">
            <table id="leave-balance-table" class="table leave-balance-table table-hover mb-0">
                <colgroup>
                    <col class="employee">
                    <col class="leave">
                    <col class="leave">
                    <col class="leave">
                    <col class="total">
                    <col class="health">
                    <col class="action">
                </colgroup>


                <thead class="fw-semibold text-black  uppercase bg-light">
                    <tr>
                        <th class="employee-column min-w-100px text-black">
                            Employee
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Casual Leave
                            <small>
                                Entitled / Availed / Balance
                            </small>
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Privilege Leave
                            <small>
                                Entitled / Availed / Balance
                            </small>
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Sick Leave
                            <small>
                                Entitled / Availed / Balance
                            </small>
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Total Allocation
                            <small>
                                Balance / Total
                            </small>
                        </th>
                        <th class="employee-column min-w-100px text-black">
                            Balance Health
                        </th>
                        <th class="employee-column min-w-100px text-black text-center">
                            Actions
                        </th>
                    </tr>
                </thead>

                <tbody>
                    {{--EMPLOYEE 1  --}}
                    <tr>
                        <td class="employee-column">
                            <div class="employee-profile">
                                <div class="employee-avatar">
                                    J
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name">
                                        Jayachandran Arumugam
                                    </div>
                                    <div class="employee-meta">
                                        Project Engineer
                                        <span>•</span>
                                        SRK-EMP-001
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    3
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-blue">
                                    9d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    18
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    5
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-green">
                                    13d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    2
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-amber">
                                    10d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="total-allocation">
                                <strong>
                                    32
                                    <span>/ 42 Days</span>
                                </strong>
                                <small>
                                    Availed: 10 Days
                                </small>
                            </div>
                        </td>
                        <td>
                            <span class="balance-health health-healthy">
                                Healthy (32d)
                            </span>
                        </td>
                        <td class="text-center">
                            <button type="button" class="adjust-quota-btn text-center" title="Adjust Quota"
                                data-employee-id="1">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                        </td>
                    </tr>

                    {{-- EMPLOYEE 2 --}}
                    <tr>
                        <td class="employee-column">
                            <div class="employee-profile">
                                <div class="employee-avatar">
                                    F
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name">
                                        Francis Xavier
                                    </div>
                                    <div class="employee-meta">
                                        Project Manager
                                        <span>•</span>
                                        SRK-EMP-002
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    7
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    3
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-blue">
                                    4d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    10
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    2
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-green">
                                    8d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    7
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    4
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-amber">
                                    3d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="total-allocation">
                                <strong>
                                    15
                                    <span>/ 24 Days</span>
                                </strong>
                                <small>
                                    Availed: 9 Days
                                </small>
                            </div>
                        </td>
                        <td>
                            <span class="balance-health health-moderate">
                                Moderate (15d)
                            </span>
                        </td>
                        <td class="text-center">
                            <button type="button" class="adjust-quota-btn text-center" title="Adjust Quota"
                                data-employee-id="1">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                        </td>
                    </tr>


                    {{--EMPLOYEE 3 --}}
                    <tr>
                        <td class="employee-column">
                            <div class="employee-profile">
                                <div class="employee-avatar">
                                    A
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name">
                                        Anbu Selvan

                                    </div>

                                    <div class="employee-meta">
                                        Crane Operator
                                        <span>•</span>
                                        SRK-EMP-003
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    8
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-blue">
                                    4d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    15
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    11
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-green">
                                    4d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    8
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-amber">
                                    4d
                                </span>
                            </div>
                        </td>

                        <td>
                            <div class="total-allocation">
                                <strong>
                                    12
                                    <span>/ 39 Days</span>
                                </strong>
                                <small>
                                    Availed: 27 Days
                                </small>
                            </div>
                        </td>
                        <td>
                            <span class="balance-health health-low">
                                Low Balance (12d)
                            </span>
                        </td>

                        <td class="text-center">
                            <button type="button" class="adjust-quota-btn text-center" title="Adjust Quota"
                                data-employee-id="1">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                        </td>

                    </tr>


                    {{-- EMPLOYEE 4 --}}
                    <tr>
                        <td class="employee-column">
                            <div class="employee-profile">
                                <div class="employee-avatar">
                                    P
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name">
                                        Priya Devi
                                    </div>
                                    <div class="employee-meta">
                                        Supervisor
                                        <span>•</span>
                                        SRK-EMP-004
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    1
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-blue">
                                    11d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    15
                                </span>
                                <span class="leave-separator">/</span>

                                <span class="leave-availed">
                                    4
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-green">
                                    11d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="leave-values">
                                <span class="leave-entitled">
                                    12
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-availed">
                                    2
                                </span>
                                <span class="leave-separator">/</span>
                                <span class="leave-balance leave-balance-amber">
                                    10d
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="total-allocation">
                                <strong>
                                    32
                                    <span>/ 39 Days</span>
                                </strong>
                                <small>
                                    Availed: 7 Days
                                </small>
                            </div>
                        </td>
                        <td>
                            <span class="balance-health health-healthy">
                                Healthy (32d)
                            </span>
                        </td>
                        <td class="text-center">
                            <button type="button" class="adjust-quota-btn text-center" title="Adjust Quota"
                                data-employee-id="1">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>


    {{-- APPLY LEAVE MODAL--}}
    <div class="modal fade" id="applyLeaveModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">
                        Apply Permanent Staff Leave
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                    </button>
                </div>
                <form>
                    @csrf
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label small fw-bold">
                                    Employee
                                </label>

                                <select name="employee_id" class="select3 form-select" required>

                                    <option value="">
                                        Select Employee
                                    </option>

                                    @foreach($permanentEmployees as $employee)

                                    <option value="{{ $employee['id'] }}">
                                        {{ $employee['name'] }}
                                        - {{ $employee['role'] }}
                                    </option>

                                    @endforeach

                                </select>

                            </div>


                            <div class="col-12">

                                <label class="form-label small fw-bold">
                                    Leave Type
                                </label>

                                <select name="leave_type" class="form-select form-select-sm" required>

                                    <option value="">
                                        Select Leave Type
                                    </option>

                                    <option value="Casual">
                                        Casual Leave
                                    </option>

                                    <option value="Privilege">
                                        Privilege Leave
                                    </option>

                                    <option value="Sick">
                                        Sick Leave
                                    </option>

                                </select>

                            </div>


                            <div class="col-6">

                                <label class="form-label small fw-bold">
                                    From Date
                                </label>

                                <input type="date" name="start_date" class="form-control form-control-sm" required>

                            </div>


                            <div class="col-6">
                                <label class="form-label small fw-bold">
                                    To Date
                                </label>
                                <input type="date" name="end_date" class="form-control form-control-sm" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">
                                    Reason / Remarks
                                </label>
                                <textarea name="reason" rows="3" class="form-control form-control-sm"
                                    placeholder="Enter leave reason..."></textarea>
                            </div>
                        </div>
                    </div>


                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="mdi mdi-check me-1"></i>
                            Submit Leave
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

    <!-- Adjust Leave Modal -->
    <div class="modal fade" id="adjustBalanceModal" tabindex="-1" aria-labelledby="adjustBalanceModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered ">
            <div class="modal-content rounded-3 overflow-hidden border-0 shadow">

                <form id="adjustBalanceForm" class="adjust-balance-form">
                    <!-- Modal Header -->
                    <div class="adjust-balance-header p-3 p-md-4 d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-3">
                            <div class="header-icon-wrapper p-2 rounded-3">
                                <i class="bi bi-award text-white fs-5"></i>
                            </div>
                            <div>
                                <h3 class="header-title m-0 text-white fw-bold fs-6" id="adjustBalanceModalLabel">Adjust
                                    Leave Entitlement Quota</h3>
                                <p class="header-subtitle m-0 text-white-50">Configure annual CL, PL, and SL days for
                                    staff member</p>
                            </div>
                        </div>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>

                    <!-- Modal Body -->
                    <div class="adjust-balance-body p-3 p-md-4">

                        <!-- Employee Select -->
                        <div class="mb-3">
                            <label for="adjustBalanceEmpSelect"
                                class="form-label-custom text-uppercase fw-bold text-muted mb-1">
                                Select Employee
                            </label>
                            <select id="adjustBalanceEmpSelect" name="adjustBalanceEmpId"
                                class="form-select custom-input">
                                <option value="1">John Doe (SRK-EMP-001) — Project Engineer</option>
                                <option value="2">Jane Smith (SRK-EMP-002) — Senior Developer</option>
                            </select>
                        </div>

                        <!-- Quota Inputs Row 1 -->
                        <div class="row g-3 mb-3">
                            <div class="col-12 col-md-6">
                                <label for="adjustCL"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">Casual Leave
                                    (CL)</label>
                                <input type="number" id="adjustCL" name="adjustCL" min="0" value="0"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="adjustPL"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">Privilege Leave
                                    (PL)</label>
                                <input type="number" id="adjustPL" name="adjustPL" min="0" value="0"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                        </div>

                        <!-- Quota Inputs Row 2 -->
                        <div class="row g-3 mb-4">
                            <div class="col-12 col-md-6">
                                <label for="adjustPrevPL"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">Prev PL Carry
                                    Forward</label>
                                <input type="number" id="adjustPrevPL" name="adjustPrevPL" min="0" value="0"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="adjustSL"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">Sick Leave
                                    (SL)</label>
                                <input type="number" id="adjustSL" name="adjustSL" min="0" value="0"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                        </div>

                        <!-- Actions -->
                        <div class="form-footer pt-3 d-flex justify-content-end gap-2 border-top">
                            <button type="button" class="btn btn-outline-secondary px-4 fw-bold"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="submit"
                                class="btn-submit btn text-white px-4 fw-bold d-inline-flex align-items-center gap-2">
                                <i class="bi bi-check-circle-fill"></i>
                                <span>Save Leave Quotas</span>
                            </button>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>

    {{-- LEAVE SETTINGS MODAL --}}
    <div class="modal fade" id="leaveSettingsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">
                        Permanent Staff Leave Policy
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-sm-4">
                            <label class="form-label small fw-bold">
                                Casual Leave
                            </label>
                            <input type="number" id="leavePolicyCasualDays" name="casual_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="7">
                            <small class="text-muted">
                                Days / Year
                            </small>
                        </div>
                        <div class="col-12 col-sm-4">
                            <label class="form-label small fw-bold">
                                Privilege Leave
                            </label>
                            <input type="number" id="leavePolicyPaidDays" name="paid_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="10">
                            <small class="text-muted">
                                Days / Year
                            </small>
                        </div>
                        <div class="col-12 col-sm-4">
                            <label class="form-label small fw-bold">
                                Sick Leave
                            </label>
                            <input type="number" id="leavePolicySickDays" name="sick_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="7">
                            <small class="text-muted">
                                Days / Year
                            </small>
                        </div>
                    </div>
                </div>


                <div class="modal-footer">

                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="button" id="saveLeavePolicyButton" class="btn btn-primary btn-sm">

                        Save Settings

                    </button>

                </div>

            </div>

        </div>

    </div>

    <!-- Batchsection -->
    <div class="modal fade" id="batchCreditModal" tabindex="-1" aria-labelledby="batchCreditModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-3 overflow-hidden border-0 shadow">

                <form id="batchCreditForm" class="batch-credit-form">

                    <!-- Modal Header -->
                    <div class="batch-credit-header p-3 p-md-4 d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-3">
                            <div class="header-icon-wrapper p-2 rounded-3">
                                <i class="mdi mdi-plus text-white fs-5"></i>
                            </div>
                            <div>
                                <h3 class="header-title m-0 text-white fw-bold fs-6" id="batchCreditModalLabel">Batch
                                    Credit Annual Leaves</h3>
                                <p class="header-subtitle m-0 text-white-50" style="font-size: 0.75rem;">Bulk credit
                                    bonus or carry-over leave days</p>
                            </div>
                        </div>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>

                    <!-- Modal Body -->
                    <div class="batch-credit-body p-3 p-md-4">

                        <!-- Target Staff Group -->
                        <div class="mb-3">
                            <label for="batchCreditStaffType"
                                class="form-label-custom text-uppercase fw-bold text-muted mb-1">
                                Target Staff Group
                            </label>
                            <select id="batchCreditStaffType" name="batchCreditStaffType"
                                class="form-select custom-input">
                                <option value="Permanent">Permanent Personnel Only</option>
                                <option value="Contract">Contract Workers Only</option>
                                <option value="ALL">All Staff</option>
                            </select>
                        </div>

                        <!-- Leave Category & Days Grid -->
                        <div class="row g-3 mb-4">
                            <div class="col-12 col-md-6">
                                <label for="batchCreditType"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">
                                    Leave Category
                                </label>
                                <select id="batchCreditType" name="batchCreditType" class="form-select custom-input">
                                    <option value="Casual">Casual Leave (CL)</option>
                                    <option value="Privilege">Privilege Leave (PL)</option>
                                    <option value="Sick">Sick Leave (SL)</option>
                                </select>
                            </div>

                            <div class="col-12 col-md-6">
                                <label for="batchCreditDays"
                                    class="form-label-custom text-uppercase fw-bold text-muted mb-1">
                                    Days to Credit
                                </label>
                                <input type="number" id="batchCreditDays" name="batchCreditDays" min="1" value="1"
                                    class="form-control custom-input font-monospace fw-bold" required />
                            </div>
                        </div>

                        <!-- Actions Footer -->
                        <div class="form-footer pt-3 d-flex justify-content-end gap-2 border-top">
                            <button type="button" class="btn btn-outline-secondary px-4 fw-bold"
                                data-bs-dismiss="modal">
                                Cancel
                            </button>
                            <button type="submit"
                                class="btn-submit btn text-white px-4 fw-bold d-inline-flex align-items-center gap-2">
                                <i class="bi bi-check-circle-fill"></i>
                                <span>Apply Batch Credit</span>
                            </button>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>
    <style>
    /* PAGE */

    .leave-page {
        color: #475569;
    }

    .leave-header-card,
    .leave-navigation-card {
        border-radius: 10px !important;
    }

    .leave-page-title {
        color: #0C3C62;
        font-size: 18px;
    }


    /* ============================================================
           POLICY CARDS
        ============================================================ */

    .leave-policy-row {
        margin-left: -5px;
        margin-right: -5px;
        margin-bottom: 12px;
    }

    .leave-policy-col {
        padding-left: 5px;
        padding-right: 5px;
        margin-bottom: 10px;
    }

    .leave-policy-card {
        min-height: 130px;
        background: #fff;
        border: 1px solid #edf0f3;
        border-radius: 10px;
        padding: 14px;
        box-shadow: 0 2px 6px rgba(15, 23, 42, .04);
    }

    .leave-policy-title {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 10px;
    }

    .leave-policy-title h4 {
        margin: 0;
        color: #475569;
        font-size: 13px;
        font-weight: 700;
    }

    .leave-type-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 30px;
        height: 20px;
        padding: 0 7px;
        border-radius: 4px;
        font-size: 9px;
        font-weight: 700;
    }

    .leave-type-cl {
        color: #16659e;
        background: #eff6ff;
        border: 1px solid #dbeafe;
    }

    .leave-type-pl {
        color: #059669;
        background: #ecfdf5;
        border: 1px solid #d1fae5;
    }

    .leave-type-sl {
        color: #d97706;
        background: #fff7ed;
        border: 1px solid #fed7aa;
    }

    .leave-policy-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 7px 0;
        border-bottom: 1px solid #f1f3f5;
        font-size: 11px;
    }

    .leave-policy-item span {
        color: #94a3b8;
        font-weight: 500;
    }

    .leave-policy-item strong {
        font-size: 11px;
        color: #475569;
    }

    .leave-blue {
        color: #16659e !important;
    }

    .leave-green {
        color: #059669 !important;
    }

    .leave-amber {
        color: #d97706 !important;
    }


    /* ============================================================
           LEDGER
        ============================================================ */

    .leave-ledger-card {
        width: 100%;
        background: #fff;
        border: 1px solid #e9edf1;
        border-radius: 10px;
        box-shadow: 0 2px 7px rgba(15, 23, 42, .04);
        overflow: hidden;
    }


    /* ============================================================
           LEDGER HEADER
        ============================================================ */

    .leave-ledger-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        padding: 14px 16px;
        border-bottom: 1px solid #e9edf1;
    }

    .leave-ledger-heading {
        flex: 1;
        min-width: 250px;
    }

    .leave-ledger-heading h3 {
        display: flex;
        align-items: center;
        gap: 7px;
        margin: 0;
        color: #475569;
        font-size: 15px;
        font-weight: 700;
    }

    .leave-ledger-heading h3 i {
        color: #16659e;
        font-size: 16px;
    }


    /* ============================================================
           CONTROLS
        ============================================================ */

    .leave-ledger-controls {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 6px;
    }

    .leave-search-box {
        position: relative;
        width: 210px;
    }

    .leave-search-box i {
        position: absolute;
        left: 9px;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 14px;
    }

    .leave-search-box input {
        width: 100%;
        height: 32px;
        padding: 5px 9px 5px 28px;
        border: 1px solid #e2e8f0;
        border-radius: 5px;
        background: #f8fafc;
        color: #475569;
        font-size: 11px;
        outline: none;
    }

    .leave-search-box input:focus {
        border-color: #16659e;
        background: #fff;
    }

    .leave-action-btn {
        height: 32px;
        padding: 5px 10px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        border-radius: 5px;
        font-size: 10px;
        font-weight: 600;
        white-space: nowrap;
        cursor: pointer;
    }

    .leave-credit-btn {
        background: #eff6ff;
        color: #16659e;
        border: 1px solid #dbeafe;
    }

    .leave-export-btn {
        background: #16659e;
        color: #fff;
        border: 1px solid #16659e;
    }


    /* ============================================================
           TABLE WRAPPER
        ============================================================ */

    .leave-table-wrapper {
        width: 100%;
        overflow-x: auto;
        overflow-y: hidden;
        -webkit-overflow-scrolling: touch;
    }


    /* ============================================================
           TABLE
        ============================================================ */

    .leave-balance-table {
        width: 100%;
        min-width: 1000px;
        table-layout: fixed;
        border-collapse: collapse;
        margin: 0;
    }


    /* Fixed column widths */

    .leave-balance-table .employee {
        width: 27%;
    }

    .leave-balance-table .leave {
        width: 13%;
    }

    .leave-balance-table .total {
        width: 13%;
    }

    .leave-balance-table .health {
        width: 12%;
    }

    .leave-balance-table .action {
        width: 9%;
    }


    /* ============================================================
           TABLE HEADER
        ============================================================ */

    .leave-balance-table thead th {
        height: 58px;
        padding: 9px 10px;
        background: #f8fafc;
        border-bottom: 1px solid #e2e8f0;
        color: #475569;
        font-size: 11px;
        font-weight: 700;
        line-height: 1.3;
        text-align: center;
        vertical-align: middle;
        white-space: nowrap;
    }

    .leave-balance-table thead th.employee-column {
        text-align: left;
        font-size: 12px;
    }

    .leave-balance-table thead th small {
        display: block;
        margin-top: 3px;
        color: #94a3b8;
        font-size: 8px;
        font-weight: 400;
        white-space: normal;
    }


    /* ============================================================
           TABLE BODY
        ============================================================ */

    .leave-balance-table tbody tr {
        height: 68px;
    }

    .leave-balance-table tbody tr:hover {
        background: #fafcff;
    }

    .leave-balance-table tbody td {
        padding: 9px 10px;
        border-bottom: 1px solid #edf0f3;
        color: #475569;
        font-size: 13px;

        vertical-align: middle;
    }

    .leave-balance-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .leave-balance-table tbody td.employee-column {
        text-align: left;
    }


    /* ============================================================
           EMPLOYEE
        ============================================================ */

    .employee-profile {
        display: flex;
        align-items: center;
        gap: 9px;
        width: 100%;
        min-width: 0;
    }

    .employee-avatar {
        width: 34px;
        height: 34px;
        min-width: 34px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: #eaf3fa;
        color: #16659e;
        font-size: 11px;
        font-weight: 800;
    }

    .employee-info {
        min-width: 0;
        overflow: hidden;


    }

    .employee-name {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 5px;
        color: #334155;
        font-size: 14px;
        font-weight: 700;
        line-height: 1.35;
    }

    .employee-meta {
        margin-top: 3px;
        color: #94a3b8;
        font-size: 9px;
        white-space: nowrap;
    }

    .employee-meta span {
        margin: 0 3px;
        color: #cbd5e1;
    }


    /* ============================================================
           LEAVE VALUES
        ============================================================ */

    .leave-values {
        display: inline-flex;
        gap: 4px;
        white-space: nowrap;
        font-family: monospace;
        font-size: 13px;
    }

    .leave-entitled {
        color: #64748b;
    }

    .leave-availed {
        color: #d97706;
        font-weight: 700;
    }

    .leave-separator {
        color: #cbd5e1;
    }


    /* ============================================================
           BALANCE BADGES
        ============================================================ */

    .leave-balance {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 28px;
        padding: 3px 6px;
        border-radius: 4px;
        font-size: 10px;
        font-weight: 700;
        line-height: 1;
    }

    .leave-balance-blue {
        color: #16659e;
        background: #eff6ff;
        border: 1px solid #dbeafe;
    }

    .leave-balance-green {
        color: #047857;
        background: #ecfdf5;
        border: 1px solid #d1fae5;
    }

    .leave-balance-amber {
        color: #b45309;
        background: #fffbeb;
        border: 1px solid #fde68a;
    }


    /* ============================================================
           TOTAL ALLOCATION
        ============================================================ */

    .total-allocation {
        display: flex;
        flex-direction: column;

        gap: 2px;
        white-space: nowrap;
    }

    .total-allocation strong {
        color: #334155;
        font-size: 14px;
        font-family: monospace;
    }

    .total-allocation strong span {
        color: #94a3b8;
        font-size: 9px;
        font-weight: 400;
    }

    .total-allocation small {
        color: #94a3b8;
        font-size: 8px;
    }


    /* BALANCE HEALTH*/

    .balance-health {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 4px 7px;
        border-radius: 10px;
        font-size: 12px;
        font-weight: 700;
        white-space: nowrap;
    }

    /* ACTION   */
    .adjust-quota-btn {
        height: 30px;
        min-width: 30px;
        padding: 5px 4px;
        display: inline-flex;

        gap: 4px;
        background: #f8fafc;
        color: #64748b;
        border: 1px solid #e2e8f0;
        border-radius: 5px;
        font-size: 9px;
        font-weight: 600;
        white-space: nowrap;
        cursor: pointer;
    }

    .adjust-quota-btn:hover {
        background: #16659e;
        color: #fff;
        border-color: #16659e;
    }


    /* ============================================================
           TABLET
        ============================================================ */

    @media (max-width: 1199.98px) {

        .leave-ledger-header {
            align-items: flex-start;
            flex-direction: column;
        }

        .leave-ledger-heading {
            width: 100%;
        }

        .leave-ledger-controls {
            width: 100%;
            justify-content: flex-start;
        }

        .leave-search-box {
            flex: 1;
            min-width: 200px;
        }

    }


    /* ============================================================
           MOBILE
        ============================================================ */

    @media (max-width: 767.98px) {

        .leave-page-title {
            font-size: 16px;
        }

        .leave-policy-card {
            min-height: auto;
        }

        .leave-ledger-header {
            padding: 12px;
        }

        .leave-ledger-heading h3 {
            font-size: 13px;
        }

        .leave-ledger-controls {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 6px;
        }

        .leave-search-box {
            width: 100%;
            grid-column: 1 / -1;
        }

        .leave-action-btn {
            width: 100%;
        }

        .leave-balance-table {
            min-width: 1050px;
        }

    }


    /* SMALL MOBILE*/

    @media (max-width: 480px) {

        .leave-ledger-controls {
            grid-template-columns: 1fr;
        }

        .leave-search-box {
            grid-column: auto;
        }

        .leave-policy-item {
            font-size: 10px;
        }

        .leave-policy-item strong {
            font-size: 10px;
        }

    }

    /* Header styling with gradient */
    .adjust-balance-header {
        background: linear-gradient(to right, #0C3C62, #16659E, #1e78b8);
    }

    .header-icon-wrapper {
        background-color: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(4px);
    }

    .header-subtitle {
        font-size: 0.75rem;
    }

    .btn-close-modal {
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 0.5rem;
        transition: background-color 0.2s ease;
    }

    .btn-close-modal:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }

    /* Label & Input styling */
    .form-label-custom {
        font-size: 0.65rem;
        letter-spacing: 0.05em;
    }

    .custom-input {
        background-color: #f8fafc;
        border-color: #e2e8f0;
        border-radius: 0.75rem;
        font-size: 0.85rem;
    }

    .custom-input:focus {
        background-color: #ffffff;
        border-color: #16659E;
        box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.25);
    }

    /* Button styling */
    .btn-cancel {
        border-radius: 0.75rem;
        font-size: 0.8rem;
    }

    .btn-submit {
        background-color: #16659E;
        border-color: #16659E;
        border-radius: 0.75rem;
        font-size: 0.8rem;
        transition: background-color 0.2s ease;
    }

    .btn-submit:hover {
        background-color: #0C3C62;
        border-color: #0C3C62;
    }

    /* Header styling with gradient */
    .batch-credit-header {
        background: linear-gradient(to right, #0C3C62, #16659E, #1e78b8);
    }

    .header-icon-wrapper {
        background-color: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(4px);
    }

    .header-subtitle {
        font-size: 0.75rem;
    }

    .btn-close-modal {
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 0.5rem;
        transition: background-color 0.2s ease;
    }

    .btn-close-modal:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }

    /* Label & Input styling */
    .form-label-custom {
        font-size: 0.65rem;
        letter-spacing: 0.05em;
    }

    .custom-input {
        background-color: #f8fafc;
        border-color: #e2e8f0;
        border-radius: 0.75rem;
        font-size: 0.85rem;
    }

    .custom-input:focus {
        background-color: #ffffff;
        border-color: #16659E;
        box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.25);
    }

    /* Button styling */
    .btn-cancel {
        border-radius: 0.75rem;
        font-size: 0.8rem;
    }

    .btn-submit {
        background-color: #16659E;
        border-color: #16659E;
        border-radius: 0.75rem;
        font-size: 0.8rem;
        transition: background-color 0.2s ease;
    }

    .btn-submit:hover {
        background-color: #0C3C62;
        border-color: #0C3C62;
    }
    </style>

</div>
<script>
// table search functionality
document.addEventListener('DOMContentLoaded', () => {
    // Select the search input field and table rows
    const searchInput = document.querySelector('.leave-search-box input');
    const tableRows = document.querySelectorAll('.leave-table-wrapper tbody tr');

    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase().trim();

        tableRows.forEach(row => {
            // Check content of the employee details column (Name, ID, Role, Type)
            const employeeCell = row.querySelector('.employee-column');

            if (employeeCell) {
                const text = employeeCell.textContent.toLowerCase();

                // Show or hide row depending on whether input query matches
                if (text.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    });
});
// Script for adjust quota
document.addEventListener('DOMContentLoaded', () => {
    // Initialize Bootstrap Modal instance
    const modalElement = document.getElementById('adjustBalanceModal');
    const adjustModal = new bootstrap.Modal(modalElement);

    // Attach click listener using event delegation for table buttons
    document.addEventListener('click', (event) => {
        const button = event.target.closest('.adjust-quota-btn');

        if (button) {
            // Optional: Get employee ID from button data attribute
            const employeeId = button.getAttribute('data-employee-id');

            if (employeeId) {
                document.getElementById('adjustBalanceEmpSelect').value = employeeId;
            }

            // Show modal
            adjustModal.show();
        }
    });
});
// For batch section
document.addEventListener('DOMContentLoaded', () => {
    const modalElement = document.getElementById('batchCreditModal');
    const batchModal = new bootstrap.Modal(modalElement);

    // Attach click listener to button
    document.addEventListener('click', (event) => {
        const button = event.target.closest('.leave-credit-btn');
        if (button) {
            batchModal.show();
        }
    });
});
</script>
<script>
(function () {
  'use strict';
  const type = 'contract';
  const api = '/admin-hr/api/leave/' + type;
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
  const today = () => { const d = new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); };
  const state = { page: 1, perPage: 10, search: '', asOf: today(), rows: [], allStaff: [] };
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = v => Number(v || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  function balance(row, key) { return row.leave_balances?.[key] || { entitled: 0, availed: 0, balance: 0 }; }
  function balanceCell(value) { return '<div class="small d-flex flex-wrap align-items-center gap-1"><span class="fw-semibold">'+money(value.entitled)+'</span><span class="text-muted">/</span><span class="text-warning">'+money(value.availed)+'</span><span class="text-muted">/</span><span class="fw-bold text-primary">'+money(value.balance)+'d</span></div>'; }
  async function request(url, options = {}) {
    const response = await fetch(url, { credentials: 'same-origin', ...options, headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest', ...(csrf ? {'X-CSRF-TOKEN': csrf} : {}), ...(options.body ? {'Content-Type':'application/json'} : {}), ...(options.headers || {}) } });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload.success === false) throw new Error(payload.message || Object.values(payload.errors || {}).flat()[0] || 'Request failed ('+response.status+').');
    return payload;
  }
  function showError(message) {
    let alert = document.getElementById('hrLeaveEntitlementError');
    if (!alert) { alert=document.createElement('div'); alert.id='hrLeaveEntitlementError'; alert.className='alert alert-danger mx-3 mt-3'; document.querySelector('.leave-table-wrapper')?.before(alert); }
    if (alert) { alert.textContent=message; alert.classList.remove('d-none'); }
  }
  function renderRows(rows) {
    const table = document.getElementById('leave-balance-table'); if (!table) return;
    const body = table.tBodies[0];
    if (!rows.length) { body.innerHTML='<tr><td colspan="7" class="text-center text-muted py-5">No staff records found.</td></tr>'; return; }
    body.innerHTML = rows.map(row => {
      const cl=balance(row,'Casual'), pl=balance(row,'Privilege'), sl=balance(row,'Sick');
      const pct=Math.max(0,Math.min(100,Number(row.balance_health||0)));
      const cycle=(row.cycle_start_date||'—')+' to '+(row.cycle_end_date||'—');
      return '<tr data-staff-id="'+esc(row.staff_pk)+'">'+
       '<td class="employee-column"><div class="employee-profile"><div class="employee-avatar">'+esc((row.staff_name||'S').slice(0,1).toUpperCase())+'</div><div class="employee-info"><div class="employee-name">'+esc(row.staff_name||'—')+'</div><div class="employee-meta">'+esc(row.designation||'Staff')+' · '+esc(row.staff_code||'')+'</div><small class="text-muted d-block">'+esc(row.department_name||'')+'</small><small class="text-primary d-block mt-1" title="Individual joining-date leave cycle"><i class="mdi mdi-calendar-sync"></i> '+esc(cycle)+'</small></div></div></td>'+
       '<td>'+balanceCell(cl)+'</td><td>'+balanceCell(pl)+'<small class="text-muted d-block mt-1">Includes '+money(row.leave_entitlement_values?.['Privilege Carry Forward']||0)+' carry-forward and '+money(row.leave_entitlement_values?.['Privilege Adjustment']||0)+' credit</small></td><td>'+balanceCell(sl)+'</td>'+
       '<td><strong>'+money(row.total_balance)+'</strong><small class="d-block text-muted">of '+money(row.total_entitled)+' days</small><small class="d-block text-muted">Used: '+money(row.total_availed)+' days</small></td>'+
       '<td><div class="d-flex align-items-center gap-2"><div class="progress flex-grow-1" style="height:6px;min-width:55px"><div class="progress-bar" role="progressbar" style="width:'+pct+'%" aria-valuenow="'+pct+'" aria-valuemin="0" aria-valuemax="100"></div></div><small>'+pct+'%</small></div></td>'+
       '<td class="text-center"><div class="d-flex gap-1 justify-content-center flex-wrap"><button type="button" class="btn btn-sm btn-outline-primary adjust-quota-btn" data-staff-id="'+esc(row.staff_pk)+'">Adjust Quota</button><button type="button" class="btn btn-sm btn-outline-secondary leave-history-btn" data-staff-id="'+esc(row.staff_pk)+'" data-staff-name="'+esc(row.staff_name)+'">History</button></div></td></tr>';
    }).join('');
  }
  function renderPager(meta) {
    let host=document.getElementById('leave-balance-pager');
    if (!host) { host=document.createElement('div'); host.id='leave-balance-pager'; host.className='d-flex flex-wrap justify-content-between align-items-center gap-2 p-3'; document.querySelector('.leave-table-wrapper')?.appendChild(host); }
    if (!host) return;
    host.innerHTML='<small class="text-muted">'+Number(meta.total||0)+' staff · Page '+Number(meta.current_page||1)+' of '+Number(meta.last_page||1)+'</small><div class="d-flex gap-2 align-items-center flex-wrap"><small class="text-muted">Cycle as of '+esc(state.asOf)+'</small><select class="form-select form-select-sm" id="leaveEntPageSize" style="width:80px"><option>10</option><option>25</option><option>50</option><option>100</option></select><button type="button" class="btn btn-sm btn-outline-secondary" id="leaveEntPrev" '+(meta.current_page<=1?'disabled':'')+'>Previous</button><button type="button" class="btn btn-sm btn-outline-secondary" id="leaveEntNext" '+(meta.current_page>=meta.last_page?'disabled':'')+'>Next</button></div>';
    const size=host.querySelector('#leaveEntPageSize'); size.value=String(meta.per_page||state.perPage); size.onchange=()=>{state.perPage=Number(size.value);state.page=1;load();};
    host.querySelector('#leaveEntPrev').onclick=()=>{state.page=Math.max(1,state.page-1);load();};
    host.querySelector('#leaveEntNext').onclick=()=>{state.page=Math.min(Number(meta.last_page||1),state.page+1);load();};
  }
  function fillYearLabel() { const label=document.querySelector('.leave-year-label'); if(label) label.textContent='Joining-date cycles · '+state.asOf; }
  async function load() {
    const table=document.getElementById('leave-balance-table'); if(!table) return;
    const body=table.tBodies[0]; body.innerHTML='<tr><td colspan="7" class="p-4"><div class="placeholder-glow"><span class="placeholder col-12 mb-2"></span><span class="placeholder col-10 mb-2"></span><span class="placeholder col-8"></span></div></td></tr>';
    document.getElementById('hrLeaveEntitlementError')?.classList.add('d-none');
    const query=new URLSearchParams({page:String(state.page),per_page:String(state.perPage),search:state.search,as_of:state.asOf});
    try { const result=await request(api+'/entitlements?'+query.toString()); state.rows=result.data||[]; renderRows(state.rows); renderPager(result.meta||{}); fillYearLabel(); }
    catch(error) { body.innerHTML='<tr><td colspan="7" class="text-danger text-center py-4">'+esc(error.message)+'</td></tr>'; }
  }
  async function loadAllStaffOptions() {
    try {
      let all=[],page=1,last=1;
      do { const j=await request('/admin-hr/api/staff/'+type+'?per_page=100&sort=name&direction=asc&page='+page); all=all.concat(j.data||[]);last=Number(j.meta?.last_page||1);page++; } while(page<=last && page<=100);
      state.allStaff=all;
      document.querySelectorAll('#adjustBalanceEmpSelect,select[name="employee_id"],select[name="staff_id"]').forEach(select=>{ if(!select.closest('#applyLeaveModal') && select.id!=='adjustBalanceEmpSelect') return; const old=select.value;select.innerHTML='<option value="">Select Staff</option>'+all.map(x=>'<option value="'+esc(x.id)+'">'+esc(x.name)+' · '+esc(x.staff_id||'')+'</option>').join('');select.value=old; });
    } catch(error) { console.warn('Could not load staff options:',error.message); }
  }
  function openAdjust(staffId) {
    const row=state.rows.find(item=>Number(item.staff_pk)===Number(staffId)); if(!row) return;
    const values=row.leave_entitlement_values||{}; const select=document.getElementById('adjustBalanceEmpSelect');if(select)select.value=String(staffId);
    const set=(id,v)=>{const el=document.getElementById(id);if(el)el.value=String(v??0);};
    set('adjustCL',values['Casual']??0);set('adjustPL',values['Paid Leave']??values['Privilege']??0);set('adjustPrevPL',values['Privilege Carry Forward']??0);set('adjustSL',values['Sick']??0);
    const cycle=document.getElementById('adjustBalanceModal')?.querySelector('.modal-title');if(cycle)cycle.textContent='Adjust Leave Quota — '+row.staff_name+' ('+row.cycle_start_date+' to '+row.cycle_end_date+')';
    const modal=document.getElementById('adjustBalanceModal');if(modal&&window.bootstrap)bootstrap.Modal.getOrCreateInstance(modal).show();
  }
  async function saveAdjust(form) {
    const staffId=Number(document.getElementById('adjustBalanceEmpSelect')?.value);if(!staffId)throw new Error('Select a staff member.');
    const read=id=>Number(document.getElementById(id)?.value||0);
    const entitlements=[
      {leave_type:'Casual Leave',annual_days:read('adjustCL')},
      {leave_type:'Paid Leave',annual_days:read('adjustPL'),carry_forward_days:read('adjustPrevPL')},
      {leave_type:'Sick Leave',annual_days:read('adjustSL')}
    ];
    const result=await request(api+'/entitlements/bulk',{method:'POST',body:JSON.stringify({staff_id:staffId,as_of:state.asOf,entitlements})});
    bootstrap.Modal.getInstance(form.closest('.modal'))?.hide();await load();alert(result.message||'Leave quota saved for this staff member’s current cycle.');
  }
  async function saveBatch(form) {
    const group=document.getElementById('batchCreditStaffType')?.value||'Permanent';
    const leaveType=document.getElementById('batchCreditType')?.value||'Casual Leave';
    const days=Number(document.getElementById('batchCreditDays')?.value||0);
    if(!Number.isFinite(days)||days<=0||days>366)throw new Error('Enter days to credit between 0 and 366.');
    const result=await request('/admin-hr/api/leave/batch-credit',{method:'POST',body:JSON.stringify({staff_group:group,leave_type:leaveType,annual_days:days})});
    bootstrap.Modal.getInstance(form.closest('.modal'))?.hide();await load();alert(result.message||'Credit saved. Annual quotas remain unchanged; credits are logged separately.');
  }
  function ensureHistoryModal() {
    let modal=document.getElementById('leaveCycleHistoryModal');if(modal)return modal;
    modal=document.createElement('div');modal.id='leaveCycleHistoryModal';modal.className='modal fade';modal.tabIndex=-1;modal.setAttribute('aria-hidden','true');
    modal.innerHTML='<div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><div><h5 class="modal-title fw-bold">Leave History</h5><small id="leaveCycleHistorySubtitle" class="text-muted"></small></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div id="leaveCycleHistoryContent"><div class="placeholder-glow"><span class="placeholder col-12"></span></div></div><div id="leaveCycleHistoryPager" class="d-flex justify-content-between align-items-center mt-3"></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div></div></div>';
    document.body.appendChild(modal);return modal;
  }
  async function openHistory(staffId,staffName) {
    const modal=ensureHistoryModal();let page=1;const subtitle=modal.querySelector('#leaveCycleHistorySubtitle');if(subtitle)subtitle.textContent=staffName+' · allocation, rollover, approvals, credits and attendance sync';
    const instance=bootstrap.Modal.getOrCreateInstance(modal);instance.show();
    async function loadHistory(){const host=modal.querySelector('#leaveCycleHistoryContent');host.innerHTML='<div class="placeholder-glow"><span class="placeholder col-12 mb-3"></span><span class="placeholder col-10"></span></div>';try{const j=await request(api+'/history?staff_id='+encodeURIComponent(staffId)+'&per_page=20&page='+page);const rows=j.data||[];host.innerHTML=rows.length?'<div class="table-responsive"><table class="table table-sm table-hover align-middle"><thead><tr><th>Date</th><th>Event</th><th>Leave Type</th><th>Cycle</th><th>Change</th><th>Balance After</th><th>Details</th></tr></thead><tbody>'+rows.map(x=>{let details=x.details_json||{};if(typeof details==='string'){try{details=JSON.parse(details)}catch(_){details={raw:details}}}return '<tr><td>'+esc(x.created_at||'—')+'</td><td><span class="badge bg-light text-dark">'+esc(x.event_type)+'</span></td><td>'+esc(x.leave_type||'—')+'</td><td><small>'+esc(x.cycle_start_date||'—')+'<br>to '+esc(x.cycle_end_date||'—')+'</small></td><td>'+Number(x.days_delta||0).toLocaleString('en-IN',{maximumFractionDigits:2})+'</td><td>'+esc(x.balance_after??'—')+'</td><td><details><summary class="text-primary" style="cursor:pointer">View</summary><pre class="small text-wrap" style="max-width:360px;white-space:pre-wrap">'+esc(JSON.stringify(details,null,2))+'</pre></details></td></tr>'}).join('')+'</tbody></table></div>':'<div class="text-muted text-center py-4">No history has been recorded for this staff member yet.</div>';const meta=j.meta||{};const pager=modal.querySelector('#leaveCycleHistoryPager');pager.innerHTML='<small class="text-muted">'+Number(meta.total||0)+' history entries · page '+Number(meta.current_page||1)+' of '+Number(meta.last_page||1)+'</small><div class="btn-group btn-group-sm"><button type="button" id="historyPrev" class="btn btn-outline-secondary" '+(Number(meta.current_page||1)<=1?'disabled':'')+'>Previous</button><button type="button" id="historyNext" class="btn btn-outline-secondary" '+(Number(meta.current_page||1)>=Number(meta.last_page||1)?'disabled':'')+'>Next</button></div>';pager.querySelector('#historyPrev').onclick=()=>{page=Math.max(1,page-1);loadHistory();};pager.querySelector('#historyNext').onclick=()=>{page=Math.min(Number(meta.last_page||1),page+1);loadHistory();};}catch(e){host.innerHTML='<div class="alert alert-danger">'+esc(e.message)+'</div>';}}
    await loadHistory();
  }
  async function loadPolicy() {
    try {const j=await request(api+'/policies');const rows=j.data||[];const find=typeName=>rows.find(p=>String(p.leave_type).toLowerCase().replace(/[^a-z]/g,'')===typeName);const set=(id,value)=>{const el=document.getElementById(id);if(el&&value!==undefined)el.value=value;};set('leavePolicyCasualDays',find('casualleave')?.annual_days??(type==='permanent'?12:7));set('leavePolicyPaidDays',(find('paidleave')||find('privilegeleave'))?.annual_days??(type==='permanent'?15:10));set('leavePolicySickDays',find('sickleave')?.annual_days??(type==='permanent'?12:7));}catch(e){console.warn('Leave policy could not be loaded:',e.message);}
  }
  async function savePolicy(button) {
    const read=id=>Number(document.getElementById(id)?.value||0);
    const policies=[{leave_type:'Casual Leave',annual_days:read('leavePolicyCasualDays'),carry_forward_enabled:0,max_carry_forward_days:0,accrual_method:'annual'},{leave_type:'Paid Leave',annual_days:read('leavePolicyPaidDays'),carry_forward_enabled:1,max_carry_forward_days:30,accrual_method:'annual'},{leave_type:'Sick Leave',annual_days:read('leavePolicySickDays'),carry_forward_enabled:0,max_carry_forward_days:0,accrual_method:'annual'}];
    button.disabled=true;try{const j=await request(api+'/policies',{method:'PUT',body:JSON.stringify({policies})});bootstrap.Modal.getInstance(document.getElementById('leaveSettingsModal'))?.hide();alert(j.message||'Leave policy saved for future cycle initialization.');}catch(e){alert(e.message);}finally{button.disabled=false;}
  }
  document.addEventListener('click',event=>{
    const adjust=event.target.closest('.adjust-quota-btn');if(adjust){event.preventDefault();openAdjust(Number(adjust.dataset.staffId));return;}
    const history=event.target.closest('.leave-history-btn');if(history){event.preventDefault();openHistory(Number(history.dataset.staffId),history.dataset.staffName||'Staff').catch(e=>alert(e.message));return;}
    const save=event.target.closest('#saveLeavePolicyButton');if(save){event.preventDefault();event.stopPropagation();event.stopImmediatePropagation();savePolicy(save);}
  },true);
  document.addEventListener('submit',event=>{
    const form=event.target;
    if(form?.id==='adjustBalanceForm'){event.preventDefault();event.stopPropagation();event.stopImmediatePropagation();saveAdjust(form).catch(e=>alert(e.message));return;}
    if(form?.id==='batchCreditForm'){event.preventDefault();event.stopPropagation();event.stopImmediatePropagation();saveBatch(form).catch(e=>alert(e.message));}
  },true);
  function init(){
    const search=document.querySelector('.leave-search-box input');let timer;
    if(search)search.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>{state.search=search.value.trim();state.page=1;load();},250);});
    loadAllStaffOptions();loadPolicy();load();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
</script>


@endsection