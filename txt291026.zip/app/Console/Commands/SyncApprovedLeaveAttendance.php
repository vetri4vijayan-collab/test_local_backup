<?php

namespace App\Console\Commands;

use App\Services\HR\LeaveCycleService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * Reconcile approved leave requests created before attendance synchronization was enabled.
 * Safe by default: no database writes occur unless --apply is provided.
 */
class SyncApprovedLeaveAttendance extends Command
{
    protected $signature = 'hr:sync-approved-leave-attendance
                            {--apply : Apply the reconciliation (default is a dry run)}';

    protected $description = 'Reconcile existing approved HR leave requests with staff attendance';

    public function handle(LeaveCycleService $leaveCycleService): int
    {
        $requests = DB::table('ryans_leave_requests')
            ->where('status', 0)
            ->where('approval_status', 'Approved')
            ->orderBy('sno')
            ->get(['sno', 'staff_id', 'leave_type', 'from_date', 'to_date']);

        if ($requests->isEmpty()) {
            $this->info('No active approved leave requests found.');
            return self::SUCCESS;
        }

        if (!$this->option('apply')) {
            $this->info(sprintf('Dry run: found %d active approved leave request(s). No rows were changed.', $requests->count()));
            $this->line('Review this result, take a database backup, then run with --apply to reconcile missing attendance rows.');
            foreach ($requests as $leave) {
                $this->line(sprintf('#%d | staff #%d | %s to %s | %s',
                    (int) $leave->sno,
                    (int) $leave->staff_id,
                    (string) $leave->from_date,
                    (string) $leave->to_date,
                    (string) $leave->leave_type
                ));
            }
            return self::SUCCESS;
        }

        $synced = 0;
        $failed = 0;
        foreach ($requests as $leave) {
            try {
                DB::transaction(function () use ($leaveCycleService, $leave): void {
                    $leaveCycleService->synchroniseApprovedLeaveToAttendance(
                        (int) $leave->staff_id,
                        (string) $leave->leave_type,
                        (string) $leave->from_date,
                        (string) $leave->to_date,
                        (int) $leave->sno,
                        0
                    );
                }, 3);
                $synced++;
                $this->line(sprintf('Reconciled request #%d for staff #%d.', (int) $leave->sno, (int) $leave->staff_id));
            } catch (Throwable $e) {
                $failed++;
                report($e);
                $this->error(sprintf('Skipped request #%d (staff #%d): %s',
                    (int) $leave->sno,
                    (int) $leave->staff_id,
                    $e->getMessage()
                ));
            }
        }

        $this->newLine();
        $this->info(sprintf('Completed: %d request(s) processed, %d failed/conflicted.', $synced, $failed));
        if ($failed > 0) {
            $this->warn('Resolve reported attendance conflicts manually before retrying those requests.');
            return self::FAILURE;
        }

        return self::SUCCESS;
    }
}
