<?php

namespace App\Http\Controllers\Manage_structure;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class manageController extends Controller
{
    public function structure()
    {
        return view('content.sitelog.manage_structure.manage');
    }

    public function structureView()
    {
        return view('content.sitelog.manage_structure.view');
    }
}