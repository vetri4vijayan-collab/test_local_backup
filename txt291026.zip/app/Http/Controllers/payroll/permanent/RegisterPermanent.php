<?php

namespace App\Http\Controllers\payroll\permanent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RegisterPermanent extends Controller
{
  public function register_pcontroller ()
  {
    return view('content.admin_hr.payroll.permanent.register_permanent');
  }
}
