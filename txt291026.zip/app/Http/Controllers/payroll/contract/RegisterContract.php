<?php

namespace App\Http\Controllers\payroll\contract;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RegisterContract extends Controller
{
  public function register_ccontroller ()
  {
    return view('content.admin_hr.payroll.contract.register_contract');
  }
}
