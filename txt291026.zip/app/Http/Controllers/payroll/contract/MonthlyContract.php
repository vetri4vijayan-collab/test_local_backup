<?php

namespace App\Http\Controllers\payroll\contract;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MonthlyContract extends Controller
{
  public function monthly_ccontroller ()
  {
    return view('content.admin_hr.payroll.contract.monthly_contract');
  }
}