<?php

namespace App\Http\Controllers\wages\permanent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SalaryController extends Controller
{
  public function p_controller ()
  {
    return view('content.admin_hr.wages.Permanent.salary_permanent');
  }
}
