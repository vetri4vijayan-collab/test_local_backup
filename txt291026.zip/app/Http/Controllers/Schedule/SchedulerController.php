<?php

namespace App\Http\Controllers\Schedule;

use App\Http\Controllers\Controller;

class SchedulerController extends Controller
{

    public function index()
    {
        return view('content.Schedule.month');
    }


    public function balance()
    {
        return view('content.Schedule.Balance');
    }
}
