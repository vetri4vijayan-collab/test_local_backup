<?php

namespace App\Http\Controllers\Workorders;

use App\Http\Controllers\Controller;

class WorkordersController extends Controller
{
    public function index()
    {
        return view('content.Work orders.index');
    }

    public function sub()
    {
        return view('content.Work orders.sub');
    }
}
