<?php

namespace App\Http\Controllers\warehouse;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MaterialAllocation extends Controller
{
  public function index ()
  {
    return view('content.store_purchase.warehouse.allocation_returns.material_allocation');
  }

  public function unused_material ()
  {
    return view('content.store_purchase.warehouse.allocation_returns.unused_material_return');
  }
}