<?php

namespace App\Http\Controllers\warehouse;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class InventoryLedgerBalance extends Controller
{
  public function index ()
  {
    return view('content.store_purchase.warehouse.inventory_ledger.ledger_balance');
  }
}