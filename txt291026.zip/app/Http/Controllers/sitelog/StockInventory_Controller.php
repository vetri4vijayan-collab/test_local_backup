<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class StockInventory_Controller extends Controller
{
  public function stock_inventory_controller ()
  {
    return view('content.sitelog.manage_store.stock_inventory');
  }
}