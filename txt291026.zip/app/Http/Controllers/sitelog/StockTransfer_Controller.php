<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class StockTransfer_Controller extends Controller
{
  public function stock_transfer_controller ()
  {
    return view('content.sitelog.manage_store.stock_transfer');
  }
}
