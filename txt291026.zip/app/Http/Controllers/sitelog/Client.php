<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;
use App\Models\ClientModel;

class Client extends Controller
{
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $search_filter = $request->search_filter ?? '';
        
        $helper = new \App\Helpers\Helpers();

        $level = ClientModel::where('ryans_clients.status', '!=', 2)
        ->select('ryans_clients.*', 'ryans_countries.country_name as country_name', 'ryans_states.state_name as state_name','ryans_cities.city_name as city_name')
        ->Join('ryans_countries', 'ryans_clients.country_id', 'ryans_countries.sno')
        ->Join('ryans_states', 'ryans_clients.state_id', 'ryans_states.sno')
        ->Join('ryans_cities', 'ryans_clients.city_id', 'ryans_cities.sno');
        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('client_name', 'LIKE', "%{$search_filter}%");
                  $subquery->where('contact_person', 'LIKE', "%{$search_filter}%");
              });
          }

          $level=$level->orderBy('sno', 'ASC')->paginate($perpage);

          if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {   
                return [
                    'sno' => $item->sno,
                    'client_name'=>$item->client_name,
                    'contact_person'=>$item->contact_person,
                    'contact_no'=>$item->contact_no,
                    'email_id'=>$item->email_id,
                    'alter_contact_person'=>$item->alter_contact_person,
                    'alter_contact_no'=>$item->alter_contact_no,
                    'address'=>$item->address,
                    'country_name'=>$item->country_name,
                    'state_name'=>$item->state_name,
                    'city_name'=>$item->city_name,
                    'pan_number'=>$item->pan_number,
                    'gst_number'=>$item->gst_number,
                    'status' => $item->status,
                    'item' => $item,
               
                ];
            });
        
            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }

         $country_list = CountryModel::where('status', 0)
            ->select('sno', 'country_name')
            ->orderBy('country_name', 'asc')
            ->get();

            $count=ClientModel::where('ryans_clients.status','!=',2)
            ->count('ryans_clients.sno');
        return view('content.sitelog.manageclient',[
            'level' => $level,
            'country_list'=>$country_list,
            'count'=>$count,
            'perpage'=>$perpage,
            'search_filter' => $search_filter,
        ]);
    }

    public function StateList(Request $request)
  {
      $country_id = $request->country_id;
      $country = StateModel::where('status', 0)->where('country_id',$country_id)->get();
         
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $country
      ], 200);
  }
  public function CityList(Request $request)
  {
      $state_id = $request->state_id;
      $state = CityModel::where('status', 0)->where('state_id',$state_id)->get();
      
      
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $state
      ], 200);
  }

  public function Add(Request $request){
 
    $user_id = $request->user()->user_id ?? 1;
    $validator = Validator::make($request->all(), [
      'country_id' => 'required|exists:ryans_countries,sno',
        'state_id' => 'required|exists:ryans_states,sno',
        'city_id' => 'required|exists:ryans_cities,sno',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    $country_id = $request->input('country_id'); 
    $state_id = $request->input('state_id');
    $city_id = $request->input('city_id');
    $client_name=$request->client_name;
    $contact_person=$request->contact_person;
    $contact_no =$request->contact_no;
    $client_doc = '';
    
            if ($request->hasFile('client_doc')) {
      
                $image = $request->file('client_doc');
                $extension = $image->extension();
                $folderPath = public_path('site_log/clients');
              // Create directory if not exists
                if (!File::exists($folderPath)) {
                    File::makeDirectory($folderPath, 0777, true, true);
                }
                  // Build file name
                    $client_document = 'client_' . $sno . '.' . $extension;
                  // Move uploaded image
                    $image->move($folderPath, $client_document);
                    $client_doc = $client_document;
            }
           
            
    $check_client_name=ClientModel::where('client_name',$client_name)->where('contact_person',$contact_person)->where('status','!=',2)->first();
    if($check_client_name){
        session()->flash('toastr',[
            'type' => 'error',
            'message' => 'Client has been already created!',
        ]);
    }else{
    
    $category_check = ClientModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();
    
            if ( !$category_check ) {
              $year = substr( date( 'y' ), -2 );
              $client_code = 'CLI-0001/' . $year;
            } else {
              $data = $category_check->client_code;
              $slice = explode( '/', $data );
              $result = preg_replace( '/[^0-9]/', '', $slice[ 0 ] );

              $next_number = ( int ) $result + 1;
              $code_request = sprintf( 'CLI-%04d', $next_number );

              $year = substr( date( 'y' ), -2 );
              $client_code = $code_request . '/' . $year;
            }
        
    $add_client=new ClientModel();
    $add_client->client_name=$client_name;
     $add_client->client_code=$client_code ?? 0;
    $add_client->contact_person=$contact_person;
    $add_client->contact_no=$request->contact_no;
    $add_client->email_id=$request->email_id;
    $add_client->alter_contact_no=$request->alter_contact_no;
    $add_client->alter_contact_person=$request->alter_contact_person;
    $add_client->address=$request->address;
    $add_client->country_id=$country_id;
    $add_client->state_id=$state_id;
    $add_client->city_id=$city_id;
    $add_client->gst_number=$request->gst_number;
    $add_client->pan_number=$request->pan_number;
    $add_client->created_by=$user_id;    
    $add_client->updated_by=$user_id;
    $add_client->upload_doc=$client_doc;
    $add_client->save();  

    // return redirect()->back();
    }
  }

  public function View($id)
  {
   
    $data = ClientModel::where('ryans_clients.status', '!=', 2)
        ->select('ryans_clients.*', 'ryans_countries.country_name as country_name', 'ryans_states.state_name as state_name','ryans_cities.city_name as city_name')
        ->Join('ryans_countries', 'ryans_clients.country_id', 'ryans_countries.sno')
        ->Join('ryans_states', 'ryans_clients.state_id', 'ryans_states.sno')
        ->Join('ryans_cities', 'ryans_clients.city_id', 'ryans_cities.sno')
        ->orderBy('ryans_clients.sno', 'ASC')->where('ryans_clients.sno', $id)->first();
     
      
    if ($data) {
      return response([
        'status' => 200,
        'message' => 'Client Fetched Successfully!',
        'data' => $data,
      ], 200);
    }
  }
  public function Update($id, Request $request)
  {
    $user_id = $request->user()->user_id ?? 1;
    $validator = Validator::make($request->all(), [
      'country_id' => 'required|exists:ryans_countries,sno',
      'state_id' => 'required|exists:ryans_states,sno',
      'city_id' => 'required|exists:ryans_cities,sno',
      'updateclientDocuments' => 'required|string',
    ]);

    $country_id = $request->input('country_id');
    $state_id = $request->input('state_id');
    $city_id = $request->input('city_id');
    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    } else {
      
      $client_name=$request->client_name;
      
        $upd_ClientModel = ClientModel::where('sno', $id)->first();
        $upd_ClientModel->country_id = $country_id;
        $upd_ClientModel->state_id = $state_id;
        $upd_ClientModel->city_id = $city_id;
        $upd_ClientModel->client_name = $client_name;
        $upd_ClientModel->contact_person = $request->contact_person;
        $upd_ClientModel->contact_no = $request->contact_no;
        $upd_ClientModel->email_id = $request->email_id;
        $upd_ClientModel->alter_contact_person = $request->alter_contact_person;
        $upd_ClientModel->alter_contact_no = $request->alter_contact_no;
        $upd_ClientModel->address=$request->address;
        $upd_ClientModel->gst_number=$request->gst_number;
        $upd_ClientModel->pan_number=$request->pan_number;
        $upd_ClientModel->updated_by=$user_id;
        $upd_ClientModel->update();

        if ($upd_ClientModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Client updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Client !'
          ]);
        }
      }
    }

    public function Delete($id)
    {
        $upd_clientModel = ClientModel::where('sno', $id)->first();
        $upd_clientModel->status = 2;
        $upd_clientModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {
        $upd_clientModel = ClientModel::where('sno', $id)->first();

        $upd_clientModel->status = $request->input('status', 0);
        $upd_clientModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
  }