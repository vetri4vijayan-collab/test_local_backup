<?php

namespace App\Http\Controllers\sitelog;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ContractorSettingsModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;
use App\Models\ContractorModel;

class ContractorList extends Controller
{
    
public function index(Request $request)
{
    $perpage = (int) $request->input('sorting_filter', 10);
     $page = $request->input('page', 1);

    $search_filter = $request->input('search_filter', '');
    $tradefilter = $request->input('tradefilter', '');

    $helper = new \App\Helpers\Helpers();

    $level = ContractorModel::where('ryans_contractors.status', '!=', 2)
        ->select('ryans_contractors.*','ryans_countries.country_name as country_name','ryans_states.state_name as state_name',
            'ryans_cities.city_name as city_name','ryans_contractor_type.contractor_type as contractor_type')
        ->join('ryans_countries','ryans_contractors.country_id','=','ryans_countries.sno')
        ->join('ryans_states','ryans_contractors.state_id', '=', 'ryans_states.sno')
        ->join('ryans_cities','ryans_contractors.city_id','=','ryans_cities.sno')
        ->join( 'ryans_contractor_type','ryans_contractors.contractor_type_id','=','ryans_contractor_type.sno');

    // Search filter
    if ($search_filter !== '') {
        $level->where(function ($query) use ($search_filter) {
            $query->where('ryans_contractors.contract_company_name', 'LIKE', "%{$search_filter}%")
            ->orWhere('ryans_contractors.gst_number','LIKE',"%{$search_filter}%")
            ->orWhere('ryans_contractors.pan_number','LIKE',"%{$search_filter}%")
            ->orWhere('ryans_contractors.address','LIKE',"%{$search_filter}%");
        });
    }
    if ($tradefilter !== '') {
        $level->where('ryans_contractors.contractor_type_id',
            $tradefilter
        );
    }

    $level = $level
        ->orderBy('ryans_contractors.sno', 'ASC')
        ->paginate($perpage);

    if ($request->ajax()) {
        $items = $level->getCollection();

        $items->transform(function ($item) {
            $banks = $item->banks ?? [];
            
            if (is_string($banks)) {
                $banks = json_decode($banks, true) ?? [];
            }
            if (!is_array($banks)) {
                $banks = [];
            }
            $item->primary_bank = $banks[0] ?? [];

            $persons = $item->persons ?? [];
            if (is_string($persons)) {
                $persons = json_decode($persons, true) ?? [];
            }
            if (!is_array($persons)) {
                $persons = [];
            }
            $item->primary_person = $persons[0] ?? [];

            return $item;
        });
        $countryIds = [];
        $stateIds = [];
        $cityIds = [];


        foreach ($items as $item) {
            $bank = $item->primary_bank;

            if (!empty($bank['bank_country'])) {
                $countryIds[] = $bank['bank_country'];
            }

            if (!empty($bank['bank_state'])) {
                $stateIds[] = $bank['bank_state'];
            }

            if (!empty($bank['bank_city'])) {
                $cityIds[] = $bank['bank_city'];
            }
        }

        // Fetch location names
        $countries = \DB::table('ryans_countries')
            ->whereIn('sno', array_unique($countryIds))
            ->pluck('country_name', 'sno');

        $states = \DB::table('ryans_states')
            ->whereIn('sno', array_unique($stateIds))
            ->pluck('state_name', 'sno');

        $cities = \DB::table('ryans_cities')
            ->whereIn('sno', array_unique($cityIds))
            ->pluck('city_name', 'sno');

     
        // Prepare AJAX response
        $data = $items->map(function ($item) use (
            $countries,
            $states,
            $cities,
        ) {
            $bank = $item->primary_bank;
            $persons =$item->primary_person;
            $countryId = $bank['bank_country'] ?? null;
            $stateId = $bank['bank_state'] ?? null;
            $cityId = $bank['bank_city'] ?? null;


            return [
                'sno' => $item->sno,
                'contractor_code' => $item->contractor_code,
                'contractor_type' => $item->contractor_type,
                'contract_company_name' => $item->contract_company_name,
                'contract_name' => $item->contract_name,
                'country_name' => $item->country_name,
                'state_name' => $item->state_name,
                'city_name' => $item->city_name,
                'address' => $item->address,
                'gst_number' => $item->gst_number,
                'pan_number' => $item->pan_number,
                'pin_code' => $item->pin_code,
                'aadhar_no' => $item->aadhar_no,
                'esi_no' => $item->esi_no,
                'epf_no' => $item->epf_no,
                'primary_person_type' => $persons['person_type'] ?? null,
                'primary_person_name' => $persons['person_name'] ?? null,
                'primary_person_email' => $persons['person_email'] ?? null,
                'primary_person_number' => $persons['person_number'] ?? null,
                'primary_person_teleno' => $persons['person_teleno'] ?? null,
                'primary_bank_name' => $bank['bank_name'] ?? null,
                'primary_bank_branch' => $bank['bank_branch'] ?? null,
                'primary_bank_country_id' => $countryId,
                'primary_bank_country_name' => $countries->get($countryId),
                'primary_bank_state_id' => $stateId,
                'primary_bank_state_name' => $states->get($stateId),
                'primary_bank_city_id' => $cityId,
                'primary_bank_city_name' => $cities->get($cityId),
                'primary_bank_address' => $bank['bank_address'] ?? null,
                'primary_bank_pincode' => $bank['bank_pincode'] ?? null,
                'primary_acc_name' => $bank['bank_acc_name'] ?? null,
                'primary_acc_type' => $bank['bank_acc_type'] ?? null,
                'primary_acc_no' => $bank['bank_acc_number'] ?? null,
                'primary_bank_micr' => $bank['bank_micr'] ?? null,
                'primary_bank_ifsc' => $bank['bank_ifsc'] ?? null,

                'status' => $item->status,
                'item' => $item,
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $level->currentPage(),
            'last_page' => $level->lastPage(),
            'total' => $level->total(),
        ]);
    }

    $country_list = CountryModel::where('status', 0)
        ->select('sno', 'country_name')
        ->orderBy('country_name', 'asc')
        ->get();

    $contract_list = ContractorSettingsModel::where('status', 0)
        ->select('sno', 'contractor_type')
        ->orderBy('contractor_type', 'asc')
        ->get();

    return view('content.sitelog.managecontractor', [
        'contract_list' => $contract_list,
        'country_list' => $country_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
    ]);
}


    public function ContractStateList(Request $request)
  {
      $country_id = $request->country_id;
      $country = StateModel::where('status', 0)->where('country_id',$country_id)->get();
         
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $country
      ], 200);
  }
  public function ContractCityList(Request $request)
  {
      $state_id = $request->state_id;
      $state = CityModel::where('status', 0)->where('state_id',$state_id)->get();
      
      
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $state
      ], 200);
  }
  public function Add(Request $request)
{
    $user_id = $request->user()->user_id ?? 1;

    // Validation
    $validator = Validator::make($request->all(), [
        'country_id' => 'required|exists:ryans_countries,sno',
        'state_id' => 'required|exists:ryans_states,sno',
        'city_id' => 'required|exists:ryans_cities,sno',
        'contract_type' => 'required|exists:ryans_contractor_type,sno',

        'contract_company_name' => 'required|string|max:255',
        'contract_name' => 'nullable|string|max:255',
        'pin_code' => 'required|digits:6',
        'pan_number' => 'required|string|max:10',
        'gst_number' => 'required|string|max:15',
        'aadhar_no' => 'required|string',

        // Primary and Secondary persons
        'persons' => 'required|array|min:1',
        'persons.0.person_type' => 'required|in:1,2,3',
        'persons.0.person_name' => 'required|string|max:255',
        'persons.0.person_number' => 'required|string|max:20',

        'persons.*.person_type' => 'required|in:1,2,3',
        'persons.*.person_name' => 'required|string|max:255',
        'persons.*.person_number' => 'required|string|max:20',
        'persons.*.person_email' => 'nullable|email|max:255',
        'persons.*.person_teleno' => 'nullable|string|max:30',

        'banks' => 'required|array|min:1',
        'banks.0.bank_name' => 'required|string|max:255',
        'banks.0.bank_branch' => 'required|string|max:255',

        'banks.*.bank_name' => 'required|string|max:255',
        'banks.*.bank_branch' => 'required|string|max:255',
        'banks.*.bank_country' => 'required|exists:ryans_countries,sno',
        'banks.*.bank_state' => 'required|exists:ryans_states,sno',
        'banks.*.bank_city' => 'required|exists:ryans_cities,sno',
        'banks.*.bank_address' => 'required|string|max:255',
        'banks.*.bank_pincode' => 'required|digits:6',
        'banks.*.bank_acc_name' => 'required|string|max:255',
        'banks.*.bank_acc_type' => 'required|in:1,2,3',
        'banks.*.bank_acc_number' => 'required|string|max:50',
        'banks.*.bank_micr' => 'required|string|max:20',
        'banks.*.bank_ifsc' => 'required|string|max:20',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 401,
            'message' => 'Validation failed',
            'error_msg' => $validator->errors()->all(),
            'errors' => $validator->errors(),
            'data' => null,
        ], 200);
    }

    $contractor_type = $request->input('contract_type');
    $contract_company_name = $request->input('contract_company_name');

    // Check duplicate contractor
    $check_contractor = ContractorModel::where(
        'contractor_type_id',
        $contractor_type
    )
        ->where('contract_company_name', $contract_company_name)
        ->where('status', '!=', 2)
        ->first();

    if ($check_contractor) {
        return response()->json([
            'status' => 409,
            'message' => 'Contractor has already been created!',
            'data' => null,
        ], 200);
    }

    // Generate contractor code
    $category_check = ContractorModel::where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->first();

    $year = date('y');
    $month = date('m');

    if (!$category_check) {
        $contractor_code = 'CON-001/' . $month . '/' . $year;
    } else {
        $data = $category_check->contractor_code;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int) $result + 1;
        $code_request = sprintf('CON-%03d', $next_number);

        $contractor_code = $code_request . '/' . $month . '/' . $year;
    }

    // Create contractor
    $add_contractor = new ContractorModel();

    $add_contractor->contractor_code = $contractor_code;
    $add_contractor->contractor_type_id = $contractor_type;
    $add_contractor->contract_company_name = $contract_company_name;
    $add_contractor->contract_name = $request->contract_name;

    $add_contractor->country_id = $request->country_id;
    $add_contractor->state_id = $request->state_id;
    $add_contractor->city_id = $request->city_id;
    $add_contractor->address = $request->address;
    $add_contractor->pin_code = $request->pin_code;

    $add_contractor->gst_number = $request->gst_number;
    $add_contractor->pan_number = $request->pan_number;
    $add_contractor->aadhar_no = $request->aadhar_no;
    $add_contractor->esi_no = $request->esi_no;
    $add_contractor->epf_no = $request->epf_no;

    // Store Primary and Secondary persons in one JSON column
    $persons = array_values($request->input('persons', []));

    // Mark the first person as Primary and the rest as Secondary
    foreach ($persons as $index => &$person) {
        $person['person_role'] = $index === 0 ? 'Primary' : 'Secondary';
    }
    unset($person);

    $banks = array_values($request->input('banks', []));
    foreach ($banks as $index => &$bank) {
        $bank['bank_role'] = $index === 0 ? 'Primary' : 'Secondary';
    }
    unset($bank);
    $add_contractor->persons = $persons;
    $add_contractor->banks = $banks;

    $add_contractor->created_by = $user_id;
    $add_contractor->updated_by = $user_id;

    $add_contractor->save();

    return response()->json([
        'status' => 200,
        'message' => 'Contractor added successfully',
        'data' => $add_contractor,
    ]);
}

 
  public function Status($id, Request $request)
    {
        $upd_contractorModel = ContractorModel::where('sno', $id)->first();

        $upd_contractorModel->status = $request->input('status', 0);
        $upd_contractorModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function View($id){
      
    $data = ContractorModel::where('ryans_contractors.status', '!=', 2)
        ->select(
            'ryans_contractors.*',
            'ryans_countries.country_name as country_name',
            'ryans_states.state_name as state_name',
            'ryans_cities.city_name as city_name',
            'ryans_contractor_type.contractor_type as contractor_type'
        )
        ->join('ryans_countries','ryans_contractors.country_id','=','ryans_countries.sno')
        ->join('ryans_states','ryans_contractors.state_id','=','ryans_states.sno')
        ->join('ryans_cities', 'ryans_contractors.city_id', '=','ryans_cities.sno')
        ->join('ryans_contractor_type','ryans_contractors.contractor_type_id','=','ryans_contractor_type.sno')
        ->where('ryans_contractors.sno', $id)
        ->first();

    if (!$data) {
        return response([
            'status' => 404,
            'message' => 'Contractor not found!',
        ], 404);
    }

    // Decode the bank JSON array
    $banks = is_array($data->banks)
        ? $data->banks
        : json_decode($data->banks ?? '[]', true);

    // Get the first bank
    $primaryBank = $banks[0] ?? [];

    // Fetch primary bank country, state and city names
    $primaryBank['country_name'] = \DB::table('ryans_countries')
        ->where('sno', $primaryBank['bank_country'] ?? null)
        ->value('country_name');

    $primaryBank['state_name'] = \DB::table('ryans_states')
        ->where('sno', $primaryBank['bank_state'] ?? null)
        ->value('state_name');

    $primaryBank['city_name'] = \DB::table('ryans_cities')
        ->where('sno', $primaryBank['bank_city'] ?? null)
        ->value('city_name');

        $persons = is_array($data->persons)
        ? $data->persons
        : json_decode($data->persons ?? '[]', true);

    $primaryPerson = $persons[0] ?? [];
    $data->primary_bank = $primaryBank;
    $data->primary_person = $primaryPerson;

    return response([
        'status' => 200,
        'message' => 'Contractor fetched successfully!',
        'data' => $data,
    ], 200);
}

  

  public function BankStateList(Request $request)
  {
      $country_id = $request->country_id;
      $country = StateModel::where('status', 0)->where('country_id',$country_id)->get();
         
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $country
      ], 200);
  }
  public function BankCityList(Request $request)
  {
      $state_id = $request->state_id;
      $state = CityModel::where('status', 0)->where('state_id',$state_id)->get();
      
      
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $state
      ], 200);
  }

   public function Delete($id)
    {
        $upd_clientModel = ContractorModel::where('sno', $id)->first();
        $upd_clientModel->status = 2;
        $upd_clientModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
  //   public function Update($id, Request $request)
  // {
  //   $user_id = $request->user()->user_id ?? 1;
  //   $validator = Validator::make($request->all(), [
  //     'country_id' => 'required|exists:ryans_countries,sno',
  //     'state_id' => 'required|exists:ryans_states,sno',
  //     'city_id' => 'required|exists:ryans_cities,sno',
          
  //   ]);

  //   $country_id = $request->input('country_id');
  //   $state_id = $request->input('state_id');
  //   $city_id = $request->input('city_id');
      
  //   if ($validator->fails()) {
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Incorrect format input fields'
  //     ]);
  //   //   return redirect()->back();
  //   } else {
      
  //       $upd_ContractModel = ContractorModel::where('sno', $id)->first();
        
  //       $upd_ContractModel->country_id = $country_id;
  //       $upd_ContractModel->state_id = $state_id;
  //       $upd_ContractModel->city_id = $city_id;
  //       $upd_ContractModel->contractor_type_id = $request->contract_type;
  //       $upd_ContractModel->contract_company_name = $request->contract_company_name;
  //       $upd_ContractModel->contract_name = $request->contract_name;
  //       $upd_ContractModel->primary_person_name = $request->primary_person_name;
  //       $upd_ContractModel->primary_person_number = $request->primary_person_number;
  //       $upd_ContractModel->primary_person_email = $request->primary_person_email;
  //       $upd_ContractModel->primary_person_teleno = $request->primary_person_teleno;
  //       $upd_ContractModel->address=$request->address;
  //       $upd_ContractModel->gst_number=$request->gst_number;
  //       $upd_ContractModel->pan_number=$request->pan_number;
  //       $upd_ContractModel->aadhar_no=$request->aadhar_no;
  //       $upd_ContractModel->esi_no=$request->esi_no;
  //       $upd_ContractModel->epf_no=$request->epf_no;
  //       $upd_ContractModel->primary_bank_name=$request->primary_bank_name;
  //       $upd_ContractModel->primary_bank_branch=$request->primary_bank_branch;
  //       $upd_ContractModel->primary_bank_address=$request->primary_bank_address;
  //       $upd_ContractModel->primary_bank_country_id=$request->primary_bank_country_id;
  //       $upd_ContractModel->primary_bank_state_id=$request->primary_bank_state_id;
  //       $upd_ContractModel->primary_bank_city_id=$request->primary_bank_city_id;
  //       $upd_ContractModel->primary_acc_name=$request->primary_acc_name;
  //       $upd_ContractModel->primary_acc_no=$request->primary_acc_no;
  //       $upd_ContractModel->primary_bank_micr=$request->primary_bank_micr;
  //       $upd_ContractModel->primary_bank_ifsc=$request->primary_bank_ifsc;
  //       $upd_ContractModel->updated_by=$user_id;
  //       $upd_ContractModel->update();

        // if ($upd_ContractModel) {
        //   session()->flash('toastr', [
        //     'type' => 'success',
        //     'message' => 'Contractor updated Successfully!'
        //   ]);
        // } else {
        //   session()->flash('toastr', [
        //     'type' => 'error',
        //     'message' => 'Could not update the Contractor !'
        //   ]);
        // }
  //     }
  //   }
        

public function Update($id, Request $request)
{
  
    $user_id = $request->user()->user_id ?? 1;

    $validator = Validator::make($request->all(), [
        'country_id' => 'required|exists:ryans_countries,sno',
        'state_id' => 'required|exists:ryans_states,sno',
        'city_id' => 'required|exists:ryans_cities,sno',
        'contract_type' => 'required|exists:ryans_contractor_type,sno',

        'contract_company_name' => 'required|string|max:255',
        'contract_name' => 'nullable|string|max:255',
        'pin_code' => 'required|digits:6',
        'pan_number' => 'required|string|max:10',
        'gst_number' => 'required|string|max:15',
        'aadhar_no' => 'required|string',

        // Primary and Secondary persons
        'persons' => 'required|array|min:1',
        'persons.0.person_type' => 'required|in:1,2,3',
        'persons.0.person_name' => 'required|string|max:255',
        'persons.0.person_number' => 'required|string|max:20',

        'persons.*.person_type' => 'required|in:1,2,3',
        'persons.*.person_name' => 'required|string|max:255',
        'persons.*.person_number' => 'required|string|max:20',
        'persons.*.person_email' => 'nullable|email|max:255',
        'persons.*.person_teleno' => 'nullable|string|max:30',

        'banks' => 'required|array|min:1',
        'banks.0.bank_name' => 'required|string|max:255',
        'banks.0.bank_branch' => 'required|string|max:255',

        'banks.*.bank_name' => 'required|string|max:255',
        'banks.*.bank_branch' => 'required|string|max:255',
        'banks.*.bank_country' => 'required|exists:ryans_countries,sno',
        'banks.*.bank_state' => 'required|exists:ryans_states,sno',
        'banks.*.bank_city' => 'required|exists:ryans_cities,sno',
        'banks.*.bank_address' => 'required|string|max:255',
        'banks.*.bank_pincode' => 'required|digits:6',
        'banks.*.bank_acc_name' => 'required|string|max:255',
        'banks.*.bank_acc_type' => 'required|in:1,2,3',
        'banks.*.bank_acc_number' => 'required|string|max:50',
        'banks.*.bank_micr' => 'required|string|max:20',
        'banks.*.bank_ifsc' => 'required|string|max:20',
    ]);

    if ($validator->fails()) {
        return redirect()->back()
            ->withErrors($validator)
            ->withInput();
    }

    $upd_ContractModel = ContractorModel::where('sno', $id)
        ->where('status', '!=', 2)
        ->first();

    if (!$upd_ContractModel) {
        return redirect()->back()
            ->with('toastr', [
                'type' => 'error',
                'message' => 'Contractor not found!'
            ]);
    }

     

            $upd_ContractModel->country_id = $request->country_id;
            $upd_ContractModel->state_id = $request->state_id;
            $upd_ContractModel->city_id = $request->city_id;

            $upd_ContractModel->contractor_type_id = $request->contract_type;
            $upd_ContractModel->contract_company_name =$request->contract_company_name;
            $upd_ContractModel->contract_name = $request->contract_name;

            $upd_ContractModel->address = $request->address;
            $upd_ContractModel->gst_number = $request->gst_number;
            $upd_ContractModel->pan_number = $request->pan_number;
            $upd_ContractModel->aadhar_no = $request->aadhar_no;
            $upd_ContractModel->esi_no = $request->esi_no;
            $upd_ContractModel->epf_no = $request->epf_no;

            $persons = array_values($request->input('persons', []));
            foreach ($persons as $index => &$person) {
                $person['person_role'] = $index === 0 ? 'Primary' : 'Secondary';
            }
            // unset($person);

            $banks = array_values($request->input('banks', []));
            foreach ($banks as $index => &$bank) {
                $bank['bank_role'] = $index === 0 ? 'Primary' : 'Secondary';
            }
            // unset($bank);

            // $contractor->persons = json_encode($persons);

            // $banks = array_values($request->input('banks', []));

            // $contractor->banks = json_encode($banks);

            $upd_ContractModel->persons = $persons;
            $upd_ContractModel->banks = $banks;

            $upd_ContractModel->created_by = $user_id;

            $upd_ContractModel->updated_by = $user_id;

            $upd_ContractModel->update();
        
        if ($upd_ContractModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Contractor updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Contractor !'
          ]);
        }
     
}


}
