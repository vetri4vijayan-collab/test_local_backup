<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageStore_Controller extends Controller
{
  public function manage_store_controller ()
  {
    return view('content.sitelog.manage_store.site_warehouse');
  }
}
