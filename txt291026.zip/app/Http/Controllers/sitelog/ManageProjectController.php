<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;

class ManageProjectController extends Controller
{
    public function manage_project_controller()
    {
        return view('content.sitelog.manage_project.index');
    }
    public function view_project()
    {
        return view('content.sitelog.manage_project.view_project');
    }
     public function create_client_work_order()
    {
        return view('content.sitelog.manage_project.tabs.page.create-client-work-order');
    }
}
