<?php

namespace App\Http\Controllers\settings;
use App\Models\ProbationSettingModel;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class ProbationSetting extends Controller
{
  public function probation(Request $request)
{
    $search = trim($request->input('search_filter', ''));
    $perPage = (int) $request->input('sorting_filter', 10);
    $perPage = max(1, min($perPage, 100));
    $countries = ProbationSettingModel::query()->where('status', '!=', 2)
        ->when($search !== '', function ($query) use ($search) {
            $query->where(function ($subquery) use ($search) {
                $subquery->where('days', 'LIKE', "%{$search}%")
                    ->orWhere('description', 'LIKE', "%{$search}%");
            });
        })
        ->orderBy('sno', 'desc')->paginate($perPage)->appends($request->query());
    if ($request->ajax() || $request->expectsJson()) {
        $data = $countries->getCollection()->map(function ($item) {
            return [
                'sno' => $item->sno,
                'days' => $item->days,
                'description' => $item->description,
                'status' => $item->status,
            ];
        })->values();
        return response()->json([
            'data' => $data,
            'current_page' => $countries->currentPage(),
            'last_page' => $countries->lastPage(),
            'total' => $countries->total(),
        ]);
    }

    return view('content.settings.common.probation_setting', [
        'perpage' => $perPage,
        'search_filter' => $search,
        'categorylist' => $countries,
    ]);
}
public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [
        'days' => 'required|string|max:255',
        'description' => 'nullable|string',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
        ], 422);
    }
    $countryName = ucfirst(trim($request->days));
    $exists = ProbationSettingModel::whereRaw('LOWER(days) = ?',[strtolower($countryName)])->where('status', '!=', 2)->exists();
    if ($exists) {
        return response()->json([
            'status' => 200,
            'message' => 'Already Exist',
        ]);
    }
    $country = new ProbationSettingModel();
    $country->days = $countryName;
    $country->description = $request->description;
    $country->created_by = 1;
    $country->updated_by = 1;
    $country->save();
    return response()->json([
        'status' => 200,
        'message' => 'Probation Period added successfully!',
    ]);
}
    public function Status($id, Request $request)
{
    $request->validate([
        'status' => 'required|in:0,1',
    ]);

    $country = ProbationSettingModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$country) {
        return response()->json([
            'status' => 404,
            'message' => 'Probation Period not found.',
        ], 404);
    }

    $country->status = (int) $request->status;
    $country->updated_by = 1;
    $country->save();

    return response()->json([
        'status' => 200,
        'message' => 'Probation Period updated successfully!',
    ]);
}
public function Delete($id)
{
    $country = ProbationSettingModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$country) {
        return response()->json([
            'status' => 404,
            'message' => 'Probation Period not found.',
        ], 404);
    }
    $country->status = 2;
    $country->save();
    return response()->json([
        'status' => 200,
        'message' => 'Probation Period deleted successfully!',
    ]);
}
     public function Edit($edit_id)
  {
    $itemcategoryedit = ProbationSettingModel::where('sno', $edit_id)->first();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $itemcategoryedit
    ], 200);
  }
  public function update(Request $request)
{
    $validator = Validator::make($request->all(), [
        'edit_id' => 'required|integer',
        'days' => 'required|string|max:255',
        'description' => 'nullable|string',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
        ], 422);
    }
    $country = ProbationSettingModel::where('sno', $request->edit_id)->where('status', '!=', 2)->first();
    if (!$country) {
        return response()->json([
            'status' => 404,
            'message' => 'Probation Period not found.',
        ], 404);
    }
    $countryName = ucfirst(trim($request->days));
    $exists = ProbationSettingModel::whereRaw('LOWER(days) = ?',[strtolower($countryName)])->where('sno', '!=', $country->sno)->where('status', '!=', 2)->exists();
    if ($exists) {
        return response()->json([
            'status' => 200,
            'message' => 'Already Exist',
        ]);
    }
    $country->days = $countryName;
    $country->description = $request->description;
    $country->updated_by = 1;
    $country->save();
    return response()->json([
        'status' => 200,
        'message' => 'Probation Period updated successfully!',
    ]);
}
}
