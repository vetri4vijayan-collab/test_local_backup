<?php
namespace App\Http\Controllers\settings;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\HiredMaterialModel;

class HiredMaterial extends Controller
{
   public function index(Request $request)
{
    $search = trim($request->input('search_filter', ''));
    $perPage = (int) $request->input('sorting_filter', 10);
    $perPage = max(1, min($perPage, 100));
    $countries = HiredMaterialModel::query()->where('status', '!=', 2)
        ->when($search !== '', function ($query) use ($search) {
            $query->where(function ($subquery) use ($search) {
                $subquery->where('hired_material_name', 'LIKE', "%{$search}%")
                    ->orWhere('description', 'LIKE', "%{$search}%");
            });
        })
        ->orderBy('sno', 'desc')->paginate($perPage)->appends($request->query());
    if ($request->ajax() || $request->expectsJson()) {
        $data = $countries->getCollection()->map(function ($item) {
            return [
                'sno' => $item->sno,
                'hired_material_name' => $item->hired_material_name,
                'description' => $item->description,
                'status' => $item->status,
            ];
        })->values();
        return response()->json([
            'data' => $data,
            'current_page' => $countries->currentPage(),
            'last_page' => $countries->lastPage(),
            'total' => $countries->total(),
        ]);
    }

    return view('content.settings.store_purchase.hired_material', [
        'perpage' => $perPage,
        'search_filter' => $search,
        'categorylist' => $countries,
    ]);
}
public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [
        'hired_material_name' => 'required|string|max:255',
        'description' => 'nullable|string',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
        ], 422);
    }
    $countryName = ucfirst(trim($request->hired_material_name));
    $exists = HiredMaterialModel::whereRaw('LOWER(hired_material_name) = ?',[strtolower($countryName)])->where('status', '!=', 2)->exists();
    if ($exists) {
        return response()->json([
            'status' => 200,
            'message' => 'Already Exist',
        ]);
    }
    $country = new HiredMaterialModel();
    $country->hired_material_name = $countryName;
    $country->description = $request->description;
    $country->created_by = 1;
    $country->updated_by = 1;
    $country->save();
    return response()->json([
        'status' => 200,
        'message' => 'Hired Material added successfully!',
    ]);
}
    public function Status($id, Request $request)
{
    $request->validate([
        'status' => 'required|in:0,1',
    ]);

    $country = HiredMaterialModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$country) {
        return response()->json([
            'status' => 404,
            'message' => 'Hired Material setting not found.',
        ], 404);
    }

    $country->status = (int) $request->status;
    $country->updated_by = 1;
    $country->save();

    return response()->json([
        'status' => 200,
        'message' => 'Hired Material status updated successfully!',
    ]);
}
public function Delete($id)
{
    $country = HiredMaterialModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$country) {
        return response()->json([
            'status' => 404,
            'message' => 'Hired Material setting not found.',
        ], 404);
    }
    $country->status = 2;
    $country->save();
    return response()->json([
        'status' => 200,
        'message' => 'Hired Material deleted successfully!',
    ]);
}
     public function Edit($edit_id)
  {
    $itemcategoryedit = HiredMaterialModel::where('sno', $edit_id)->first();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $itemcategoryedit
    ], 200);
  }
  public function update(Request $request)
{
    $validator = Validator::make($request->all(), [
        'edit_id' => 'required|integer',
        'hired_material_name' => 'required|string|max:255',
        'description' => 'nullable|string',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
        ], 422);
    }
    $country = HiredMaterialModel::where('sno', $request->edit_id)->where('status', '!=', 2)->first();
    if (!$country) {
        return response()->json([
            'status' => 404,
            'message' => 'Hired Material setting not found.',
        ], 404);
    }
    $countryName = ucfirst(trim($request->hired_material_name));
    $exists = HiredMaterialModel::whereRaw('LOWER(hired_material_name) = ?',[strtolower($countryName)])->where('sno', '!=', $country->sno)->where('status', '!=', 2)->exists();
    if ($exists) {
        return response()->json([
            'status' => 200,
            'message' => 'Already Exist',
        ]);
    }
    $country->hired_material_name = $countryName;
    $country->description = $request->description;
    $country->updated_by = 1;
    $country->save();
    return response()->json([
        'status' => 200,
        'message' => 'Hired Material setting updated successfully!',
    ]);
}
}

