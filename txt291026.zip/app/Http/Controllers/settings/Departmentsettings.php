<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DepartmentSettingsModel;

class Departmentsettings extends Controller
{
    public function index(Request $request)
    {
        
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $search_filter = $request->search_filter ?? '';

        $helper = new \App\Helpers\Helpers();

        $level = DepartmentSettingsModel::where('ryans_department.status', '!=', 2);
        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('department_name', 'LIKE', "%{$search_filter}%");
                      
              });
          }

          $level=$level->orderBy('sno', 'ASC')->paginate($perpage);

          if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {   
                return [
                    'sno' => $item->sno,
                    'department_name'=>$item->department_name,
                    'status' => $item->status,
                    'department_desc' => $item->department_desc,
                    'item' => $item,
                    'created_at' => $item->created_at,
               
                ];
            });
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
                'common_date_format' => $common_date_format,
            ]);
        }


        return view('content.settings.adminhr.department_setting', [
          'level' => $level,
          'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function Add(Request $request)
    {
         $user_id = $request->user()->user_id ?? 1;
        $validator = Validator::make($request->all(), [
            'department_name' => 'required|max:255',
            
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $department_name = $request->input('department_name');
            
            $chk = DepartmentSettingsModel::where('department_name', ucwords($department_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Department has been  already created!',
                ]);
            } else {
                $category_check = DepartmentSettingsModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $add_category = new DepartmentSettingsModel();
                $add_category->department_name = $department_name;
                $add_category->department_desc = $request->department_desc;
                $add_category->created_by = $user_id;
                $add_category->updated_by = 1;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Department added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Department!',
                    ]);
                }
            }
            
            // return redirect()->back();
        }
    }

    public function View($id)
    {
        
        $data = DepartmentSettingsModel::where('ryans_department.sno', $id)->first();
       
      if (!$data) { 
      return response([
        'status' => 404,
        'message' => 'Department not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'department_name' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $department_name = $request->input('department_name');            

            $upd_CourseCategoryModel = DepartmentSettingsModel::where('sno', $id)->first();

             $chk = DepartmentSettingsModel::where('department_name', ucwords($department_name))->where('status', '!=', 2)->where('sno', '!=', $id)->first();


            if ($chk) {
                if ($chk->sno != $id) {
                    $result = response([
                        'status' => 401,
                        'message' => 'Error',
                        'error_msg' => 'Department has been already assigned!',
                        'data' => null,

                    ], 200);
                } else {
                }
            }
            $upd_CourseCategoryModel->department_name = $department_name;
            $upd_CourseCategoryModel->department_desc = $request->department_desc;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel = DepartmentSettingsModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {
        $upd_CourseCategoryModel = DepartmentSettingsModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
