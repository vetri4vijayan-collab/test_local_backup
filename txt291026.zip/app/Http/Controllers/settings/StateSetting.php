<?php

namespace App\Http\Controllers\settings;
use App\Models\CountryModel;
use App\Models\StateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;

class StateSetting extends Controller
{
  public function index(Request $request)
{
    $search = trim($request->input('search_filter', ''));
    $filterCountry = $request->input('filterCountry', '');
    $perPage = (int) $request->input('sorting_filter', 10);
    $perPage = max(1, min($perPage, 100));

    // Active countries for the dropdown
    $countries = CountryModel::where('status', 0)
    ->select('sno', 'country_name')
    ->orderBy('country_name', 'asc')
    ->get();

    // Fetch states with their associated country names

    $states = StateModel::select('ryans_states.*','ryans_countries.country_name')->where('ryans_states.status', '!=', 2)
      ->join('ryans_countries','ryans_countries.sno','=','ryans_states.country_id');

      if ($search != '') {
          $states->where(function ($subquery) use ($search) {
              $subquery->where('ryans_states.state_name', 'LIKE', "%{$search}%")
                  ->orWhere('ryans_states.description', 'LIKE', "%{$search}%")
                  ->orWhere('ryans_countries.country_name', 'LIKE', "%{$search}%");  
          });
      }

      if($filterCountry != ''){
          $states->where('ryans_states.country_id', $filterCountry);
      }
      
      $states = $states->orderBy('ryans_states.sno', 'desc')->paginate($perPage);

    if ($request->ajax() ) {

        $data = $states->map(function ($item) {
            return [
                'sno' => $item->id,
                'status' => $item->status,
                'state_name' => $item->state_name,
                'country_id' => $item->country_id,
                'country_name' => $item->country_name,
                'description' => $item->description,
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $states->currentPage(),
            'last_page' => $states->lastPage(),
            'total' => $states->total(),
        ]);

       
    }

    return view('content.settings.common.state_setting', [
        'perpage' => $perPage,
        'search_filter' => $search,
        'categorylist' => $states,
        'countries' => $countries,
    ]);
}

  public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [
        'country_id' => [
            'required',
            'integer',
            'exists:ryans_countries,sno',
        ],
        'state_name' => 'required|string|max:255',
        'description' => 'nullable|string',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
            'errors' => $validator->errors(),
        ], 422);
    }

    // Verify that the selected country is active
    $countryExists = CountryModel::where('sno', $request->country_id)
        ->where('status', 0)
        ->exists();

    if (!$countryExists) {
        return response()->json([
            'status' => 422,
            'message' => 'Please select an active country.',
        ], 422);
    }

    $stateName = ucfirst(trim($request->state_name));

    // Prevent duplicate state names within the same country
    $exists = StateModel::where('country_id', $request->country_id)
        ->whereRaw('LOWER(state_name) = ?', [strtolower($stateName)])
        ->where('status', '!=', 2)
        ->exists();

    if ($exists) {
        return response()->json([
            'status' => 409,
            'message' => 'This state already exists in the selected country.',
        ], 409);
    }

    $state = new StateModel();
    $state->country_id = $request->country_id;
    $state->state_name = $stateName;
    $state->description = $request->description;
    $state->created_by = 1;
    $state->updated_by = 1;
    $state->status = 0;
    $state->save();

    return response()->json([
        'status' => 200,
        'message' => 'State setting added successfully!',
    ]);
}

public function countryList()
{
    $countries = CountryModel::where('status', 0)
        ->select('sno as id', 'country_name as name')
        ->orderBy('country_name', 'asc')
        ->get();

    return response()->json([
        'status' => 200,
        'message' => 'Countries fetched successfully.',
        'data' => $countries,
    ]);
}
     public function Status($id, Request $request)
{
    $request->validate([
        'status' => 'required|in:0,1',
    ]);

    $country = StateModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$country) {
        return response()->json([
            'status' => 404,
            'message' => 'State setting not found.',
        ], 404);
    }

    $country->status = (int) $request->status;
    $country->updated_by = 1;
    $country->save();

    return response()->json([
        'status' => 200,
        'message' => 'Country status updated successfully!',
    ]);
}

     public function Edit($edit_id)
  {
    $itemcategoryedit = StateModel::where('sno', $edit_id)->first();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $itemcategoryedit
    ], 200);
  }
    public function Delete($id)
  {
      $country = StateModel::where('sno', $id)->where('status', '!=', 2)->first();
      if (!$country) {
          return response()->json([
              'status' => 404,
              'message' => 'Country setting not found.',
          ], 404);
      }
      $country->status = 2;
      $country->save();
      return response()->json([
          'status' => 200,
          'message' => 'Country setting deleted successfully!',
      ]);
  }

  public function update(Request $request)
  {
      $validator = Validator::make($request->all(), [
          'edit_id' => 'required|integer',
          'country_id' => [
              'required',
              'integer',
              'exists:ryans_countries,sno',
          ],
          'state_name' => 'required|string|max:255',
          'description' => 'nullable|string',
      ]);

      if ($validator->fails()) {
          return response()->json([
              'status' => 422,
              'message' => $validator->errors()->first(),
              'errors' => $validator->errors(),
          ], 422);
      }

      $state = StateModel::where('sno', $request->edit_id)
          ->where('status', '!=', 2)
          ->first();

      if (!$state) {
          return response()->json([
              'status' => 404,
              'message' => 'State setting not found.',
          ], 404);
      }

      $countryExists = CountryModel::where('sno', $request->country_id)
          ->where('status', 0)
          ->exists();

      if (!$countryExists) {
          return response()->json([
              'status' => 422,
              'message' => 'Please select an active country.',
          ], 422);
      }

      $stateName = ucfirst(trim($request->state_name));

      $exists = StateModel::where('country_id', $request->country_id)
          ->whereRaw('LOWER(state_name) = ?', [strtolower($stateName)])
          ->where('sno', '!=', $state->sno)
          ->where('status', '!=', 2)
          ->exists();

      if ($exists) {
          return response()->json([
              'status' => 409,
              'message' => 'This state already exists in the selected country.',
          ], 409);
      }

      $state->country_id = $request->country_id;
      $state->state_name = $stateName;
      $state->description = $request->description;
      $state->updated_by = 1;
      $state->save();

      return response()->json([
          'status' => 200,
          'message' => 'State setting updated successfully!',
      ]);
  }

  public function List(Request $request)
  {

      $countryId = $request->input('country_id');
      $city = StateModel::where('status', 0)->where('country_id', $countryId)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }
}
