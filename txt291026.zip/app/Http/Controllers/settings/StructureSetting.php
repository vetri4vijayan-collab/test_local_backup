<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class StructureSetting extends Controller
{
  public function index()
  {
    return view('content.settings.site_log.structure_setting');
  }

}
