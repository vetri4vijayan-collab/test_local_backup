<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ShiftTimeSettingsModel;

class Shiftsettings extends Controller
{
   
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $search_filter = $request->search_filter ?? '';
        
        $helper = new \App\Helpers\Helpers();

        $level = ShiftTimeSettingsModel::where('ryans_shift_time.status', '!=', 2);
        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('shift_time_name', 'LIKE', "%{$search_filter}%");
              });
          }

          $level=$level->orderBy('sno', 'ASC')->paginate($perpage);

          if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {   
                $shift_start_time=$item->shift_start_time;
                return [
                    'sno' => $item->sno,
                    'shift_time_name'=>$item->shift_time_name,
                    'shift_start_time'=>$item->shift_start_time,
                    'shift_end_time'=>$item->shift_end_time,
                    'status' => $item->status,
                    'item' => $item,
               
                ];
            });
        
            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }


        return view('content.settings.adminhr.shift_setting', [
          'level' => $level,
          'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function Add(Request $request)
    {
         $user_id = $request->user()->user_id ?? 1;
        $validator = Validator::make($request->all(), [
            'shift_time_name' => 'required|max:255',
            
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $shift_time_name = $request->input('shift_time_name');
            $shift_start_time = $request->shift_start_time;
            $shift_end_time = $request->shift_end_time;
            if($shift_start_time>$shift_end_time){
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Shift has been already created!',
                ]);
            }
            $chk = ShiftTimeSettingsModel::where('shift_time_name', ucwords($shift_time_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Shift has been already created!',
                ]);
            } else {
                $category_check = ShiftTimeSettingsModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $add_category = new ShiftTimeSettingsModel();
                $add_category->shift_time_name = $shift_time_name;
                $add_category->shift_start_time = $shift_start_time;
                $add_category->shift_end_time = $shift_end_time;
                $add_category->created_by = $user_id;
                $add_category->updated_by = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'renumeration added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the renumeration!',
                    ]);
                }
            }
            
        }
    }

    public function View($id)
    {
        
        $data = ShiftTimeSettingsModel::where('ryans_shift_time.sno', $id)->first();
       
      if (!$data) { 
      return response([
        'status' => 404,
        'message' => 'Shift not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function Update($id, Request $request)
    {
        $user_id = $request->user()->user_id ?? 1;
        $validator = Validator::make($request->all(), [
            'shift_time_name' => 'required|max:255',
            'shift_start_time' => 'required|max:255',
            'shift_end_time' => 'required|max:255',
            
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $shift_time_name = $request->input('shift_time_name');       
            $shift_start_time = $request->input('shift_start_time');
            $shift_end_time = $request->input('shift_end_time');     
            

            $upd_CourseCategoryModel = ShiftTimeSettingsModel::where('sno', $id)->first();

             $chk = ShiftTimeSettingsModel::where('shift_time_name', ucwords($shift_time_name))->where('status', '!=', 2)->where('sno', '!=', $id)->first();


            if ($chk) {
                if ($chk->sno != $id) {
                    $result = response([
                        'status' => 401,
                        'message' => 'Error',
                        'error_msg' => 'Shift has been already assigned!',
                        'data' => null,

                    ], 200);
                } 
            }
            $upd_CourseCategoryModel->shift_time_name = $shift_time_name;
            $upd_CourseCategoryModel->shift_start_time = $shift_start_time;
            $upd_CourseCategoryModel->shift_end_time = $shift_end_time;
            $upd_CourseCategoryModel->updated_by = $user_id;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => $upd_CourseCategoryModel,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel = ShiftTimeSettingsModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {
        $upd_CourseCategoryModel = ShiftTimeSettingsModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}

