<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Throwable;

class UserRole extends Controller
{
    private const UI_ACTIONS = ['view', 'create', 'edit', 'delete'];

    /** Show only the existing page shell; the table and menu are loaded by AJAX. */
    public function index()
    {
        return view('content.settings.users_role');
    }

    /**
     * Initial page data. The menu is read at request time so verticalMenu.json
     * remains the single source of truth for the permission tree.
     */
    public function data(): JsonResponse
    {
        try {
            $menu = $this->readVerticalMenu();
            $modules = $this->buildUiModules($menu);

            $roles = UserRoleModel::query()
                ->where('status', '!=', 2)
                ->orderByDesc('sno')
                ->get(['sno', 'role_id', 'role_name', 'status']);

            $roleIds = $roles->pluck('sno')->map(static fn ($id) => (int) $id)->all();

            $permissionByRole = empty($roleIds)
                ? collect()
                : UserRolePermissionModel::query()
                    ->whereIn('role_id', $roleIds)
                    ->where('status', '!=', 2)
                    ->orderByDesc('sno')
                    ->get()
                    ->unique('role_id')
                    ->keyBy(static fn ($permission) => (string) $permission->role_id);

            $userCounts = empty($roleIds)
                ? collect()
                : DB::table('users')
                    ->select('role_id', DB::raw('COUNT(*) AS total'))
                    ->whereIn('role_id', $roleIds)
                    ->groupBy('role_id')
                    ->pluck('total', 'role_id');

            $roleData = $roles->map(function (UserRoleModel $role) use ($permissionByRole, $userCounts) {
                $permission = $permissionByRole->get((string) $role->sno);

                return [
                    'id' => (int) $role->sno,
                    'role_code' => (string) $role->role_id,
                    'name' => (string) $role->role_name,
                    'users' => (int) ($userCounts->get($role->sno) ?? $userCounts->get((string) $role->sno) ?? 0),
                    'site_management_access' => $this->siteManagementEnabled($permission),
                    'status' => (int) $role->status,
                    'has_permissions' => (bool) $permission,
                ];
            })->values();

            return response()->json([
                'success' => true,
                'data' => [
                    'roles' => $roleData,
                    'modules' => $modules,
                ],
            ]);
        } catch (Throwable $exception) {
            report($exception);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load roles and menu permissions. Please verify resources/menu/verticalMenu.json and the database connection.',
            ], 500);
        }
    }

    /** Return one role and map saved JSON back to the UI checkboxes. */
    public function show(int $id): JsonResponse
    {
        $role = UserRoleModel::query()->where('status', '!=', 2)->find($id);
        if (!$role) {
            return response()->json(['success' => false, 'message' => 'Role not found.'], 404);
        }

        $permission = UserRolePermissionModel::query()
            ->where('role_id', $role->sno)
            ->where('status', '!=', 2)
            ->orderByDesc('sno')
            ->first();

        return response()->json([
            'success' => true,
            'data' => [
                'id' => (int) $role->sno,
                'name' => (string) $role->role_name,
                'status' => (int) $role->status,
                'site_management_access' => $this->siteManagementEnabled($permission),
                'permissions' => $permission
                    ? $this->permissionArrayToUiMap($permission->decodedPermissions())
                    : [],
            ],
        ]);
    }

    /** Create the role and its permission JSON atomically. */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'role_name' => ['required', 'string', 'max:255'],
            'site_management_access' => ['required', 'boolean'],
            'permissions' => ['present', 'array'],
            'permissions.*.key' => ['required', 'string', 'size:64'],
            'permissions.*.actions' => ['required', 'array'],
            'permissions.*.actions.view' => ['required', 'boolean'],
            'permissions.*.actions.create' => ['required', 'boolean'],
            'permissions.*.actions.edit' => ['required', 'boolean'],
            'permissions.*.actions.delete' => ['required', 'boolean'],
        ]);

        $name = trim($validated['role_name']);
        $siteManagementAccess = (bool) $validated['site_management_access'];
        $actorId = $this->actorId($request);

        try {
            $menu = $this->readVerticalMenu();
            $modules = $this->buildUiModules($menu);
            $permissionMap = $this->normalizeSubmittedPermissions($validated['permissions'], $modules);
            $permissionsJson = $this->encodePermissions($this->buildStoredPermissionTree($menu, $permissionMap, $siteManagementAccess));

            $result = DB::transaction(function () use ($name, $siteManagementAccess, $actorId, $permissionsJson) {
                $duplicate = UserRoleModel::query()
                    ->where('status', '!=', 2)
                    ->whereRaw('LOWER(TRIM(role_name)) = ?', [mb_strtolower($name)])
                    ->lockForUpdate()
                    ->exists();

                if ($duplicate) {
                    throw ValidationException::withMessages([
                        'role_name' => ['A role with this name already exists.'],
                    ]);
                }

                $role = new UserRoleModel();
                // A temporary unique code is used until the auto-increment key is available.
                $role->role_id = 'TMP-' . Str::uuid();
                $role->role_name = $name;
                $role->map_under = 0;
                $role->user_role_id = 0;
                $role->created_by = $actorId;
                $role->updated_by = $actorId;
                $role->status = 0;
                $role->save();

                $role->role_id = $this->generateRoleCode((int) $role->sno);
                $role->updated_by = $actorId;
                $role->save();

                $permission = new UserRolePermissionModel();
                $permission->role_id = (int) $role->sno;
                $permission->branch_id = null;
                // The legacy schema defines 1 = Single Manage and 2 = Multi Manage.
                $permission->manage_branch = $siteManagementAccess ? 2 : 1;
                $permission->access_head = null;
                $permission->permissions = $permissionsJson;
                $permission->created_by = $actorId;
                $permission->updated_by = $actorId;
                $permission->status = 0;
                $permission->save();

                return $role;
            });

            return response()->json([
                'success' => true,
                'message' => 'Role created successfully.',
                'data' => ['id' => (int) $result->sno],
            ], 201);
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (Throwable $exception) {
            report($exception);

            return response()->json([
                'success' => false,
                'message' => 'Unable to save the role. No changes were committed. Please try again or check the application log.',
            ], 500);
        }
    }

    /** Update role name, scope and permission JSON atomically. */
    public function update(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'role_name' => ['required', 'string', 'max:255'],
            'site_management_access' => ['required', 'boolean'],
            'permissions' => ['present', 'array'],
            'permissions.*.key' => ['required', 'string', 'size:64'],
            'permissions.*.actions' => ['required', 'array'],
            'permissions.*.actions.view' => ['required', 'boolean'],
            'permissions.*.actions.create' => ['required', 'boolean'],
            'permissions.*.actions.edit' => ['required', 'boolean'],
            'permissions.*.actions.delete' => ['required', 'boolean'],
        ]);

        $name = trim($validated['role_name']);
        $siteManagementAccess = (bool) $validated['site_management_access'];
        $actorId = $this->actorId($request);

        try {
            $menu = $this->readVerticalMenu();
            $modules = $this->buildUiModules($menu);
            $permissionMap = $this->normalizeSubmittedPermissions($validated['permissions'], $modules);
            $permissionsJson = $this->encodePermissions($this->buildStoredPermissionTree($menu, $permissionMap, $siteManagementAccess));

            DB::transaction(function () use ($id, $name, $siteManagementAccess, $actorId, $permissionsJson) {
                $role = UserRoleModel::query()->where('status', '!=', 2)->lockForUpdate()->find($id);
                if (!$role) {
                    throw ValidationException::withMessages(['role_name' => ['The requested role no longer exists. Refresh and try again.']]);
                }

                $duplicate = UserRoleModel::query()
                    ->where('status', '!=', 2)
                    ->where('sno', '!=', $id)
                    ->whereRaw('LOWER(TRIM(role_name)) = ?', [mb_strtolower($name)])
                    ->lockForUpdate()
                    ->exists();

                if ($duplicate) {
                    throw ValidationException::withMessages(['role_name' => ['A role with this name already exists.']]);
                }

                $role->role_name = $name;
                $role->updated_by = $actorId;
                $role->save();

                $permission = UserRolePermissionModel::query()
                    ->where('role_id', $role->sno)
                    ->orderByDesc('sno')
                    ->lockForUpdate()
                    ->first();

                if (!$permission) {
                    $permission = new UserRolePermissionModel();
                    $permission->role_id = (int) $role->sno;
                    $permission->created_by = $actorId;
                }

                $permission->branch_id = null;
                $permission->manage_branch = $siteManagementAccess ? 2 : 1;
                $permission->access_head = null;
                $permission->permissions = $permissionsJson;
                $permission->updated_by = $actorId;
                $permission->status = (int) $role->status === 0 ? 0 : 1;
                $permission->save();
            });

            return response()->json(['success' => true, 'message' => 'Role updated successfully.']);
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (Throwable $exception) {
            report($exception);

            return response()->json([
                'success' => false,
                'message' => 'Unable to update the role. No changes were committed. Please try again or check the application log.',
            ], 500);
        }
    }

    /** Enable/disable a role. Status 2 is reserved for soft-deleted rows. */
    public function status(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate(['status' => ['required', 'integer', 'in:0,1']]);
        $actorId = $this->actorId($request);
        $status = (int) $validated['status'];

        $role = UserRoleModel::query()->where('status', '!=', 2)->find($id);
        if (!$role) {
            return response()->json(['success' => false, 'message' => 'Role not found.'], 404);
        }

        DB::transaction(function () use ($role, $status, $actorId) {
            $role->status = $status;
            $role->updated_by = $actorId;
            $role->save();

            UserRolePermissionModel::query()
                ->where('role_id', $role->sno)
                ->where('status', '!=', 2)
                ->update([
                    'status' => $status,
                    'updated_by' => $actorId,
                    'updated_at' => now(),
                ]);
        });

        return response()->json([
            'success' => true,
            'message' => $status === 0 ? 'Role enabled successfully.' : 'Role disabled successfully.',
        ]);
    }

    /** Soft-delete a role, but do not orphan assigned users. */
    public function destroy(Request $request, int $id): JsonResponse
    {
        $role = UserRoleModel::query()->where('status', '!=', 2)->find($id);
        if (!$role) {
            return response()->json(['success' => false, 'message' => 'Role not found.'], 404);
        }

        $assignedUsers = DB::table('users')->where('role_id', $role->sno)->count();
        if ($assignedUsers > 0) {
            return response()->json([
                'success' => false,
                'message' => "This role is assigned to {$assignedUsers} user(s). Reassign those users before deleting the role.",
            ], 422);
        }

        $actorId = $this->actorId($request);
        DB::transaction(function () use ($role, $actorId) {
            $role->status = 2;
            $role->updated_by = $actorId;
            $role->save();

            UserRolePermissionModel::query()
                ->where('role_id', $role->sno)
                ->update([
                    'status' => 2,
                    'updated_by' => $actorId,
                    'updated_at' => now(),
                ]);
        });

        return response()->json(['success' => true, 'message' => 'Role deleted successfully.']);
    }

    /** Parse the actual menu JSON, failing closed when it is missing or malformed. */
    private function readVerticalMenu(): array
    {
        $path = resource_path('menu/verticalMenu.json');
        if (!File::exists($path)) {
            throw new \RuntimeException('resources/menu/verticalMenu.json was not found.');
        }

        $decoded = json_decode(File::get($path), true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded) || !isset($decoded['menu']) || !is_array($decoded['menu'])) {
            throw new \RuntimeException('resources/menu/verticalMenu.json is invalid or does not contain a menu array.');
        }

        return array_values(array_filter($decoded['menu'], 'is_array'));
    }

    /** Build the table rows from each module's current submenu/leaf structure. */
    private function buildUiModules(array $menu): array
    {
        $modules = [];

        foreach ($menu as $menuItem) {
            $moduleName = trim((string) ($menuItem['name'] ?? 'Unnamed module'));
            $children = isset($menuItem['submenu']) && is_array($menuItem['submenu'])
                ? array_values(array_filter($menuItem['submenu'], 'is_array'))
                : [];
            $rows = [];

            if (empty($children)) {
                $path = [$moduleName];
                $rows[] = [
                    'key' => $this->permissionKey($path),
                    'label' => $moduleName,
                    'level' => 'menu',
                ];
            } else {
                foreach ($children as $child) {
                    $childName = trim((string) ($child['name'] ?? 'Unnamed submenu'));
                    $leaves = isset($child['submenu']) && is_array($child['submenu'])
                        ? array_values(array_filter($child['submenu'], 'is_array'))
                        : [];

                    if (empty($leaves)) {
                        $path = [$moduleName, $childName];
                        $rows[] = [
                            'key' => $this->permissionKey($path),
                            'label' => $childName,
                            'level' => 'submenu',
                        ];
                        continue;
                    }

                    foreach ($leaves as $leaf) {
                        $leafName = trim((string) ($leaf['name'] ?? 'Unnamed item'));
                        $path = [$moduleName, $childName, $leafName];
                        $rows[] = [
                            'key' => $this->permissionKey($path),
                            'label' => $childName . ' / ' . $leafName,
                            'level' => 'lastmenu',
                        ];
                    }
                }
            }

            $modules[] = [
                'name' => $moduleName,
                'icon' => (string) ($menuItem['icon'] ?? 'mdi mdi-folder-outline'),
                'rows' => $rows,
            ];
        }

        return $modules;
    }

    /** Validate incoming permission keys against the current vertical menu. */
    private function normalizeSubmittedPermissions(array $submitted, array $modules): array
    {
        $allowed = [];
        foreach ($modules as $module) {
            foreach ($module['rows'] as $row) {
                $allowed[$row['key']] = true;
            }
        }

        $normalized = [];
        foreach ($submitted as $entry) {
            $key = (string) ($entry['key'] ?? '');
            if ($key === '' || !isset($allowed[$key])) {
                throw ValidationException::withMessages([
                    'permissions' => ['The permission list no longer matches verticalMenu.json. Refresh the page and try again.'],
                ]);
            }

            $actionValues = [];
            foreach (self::UI_ACTIONS as $action) {
                $actionValues[$action] = filter_var($entry['actions'][$action] ?? false, FILTER_VALIDATE_BOOLEAN);
            }
            $normalized[$key] = $actionValues;
        }

        // Missing rows default to denied; an omitted client row cannot grant access.
        foreach ($allowed as $key => $_) {
            $normalized[$key] = $normalized[$key] ?? array_fill_keys(self::UI_ACTIONS, false);
        }

        return $normalized;
    }

    /** Build old-project-compatible menuName/submenuName/lastmenuName JSON. */
    private function buildStoredPermissionTree(array $menu, array $permissionMap, bool $siteManagementAccess): array
    {
        $stored = [];

        foreach ($menu as $menuItem) {
            $menuName = trim((string) ($menuItem['name'] ?? 'Unnamed module'));
            $menuSlug = $menuItem['slug'] ?? null;
            $children = isset($menuItem['submenu']) && is_array($menuItem['submenu'])
                ? array_values(array_filter($menuItem['submenu'], 'is_array'))
                : [];

            $node = [
                'menuName' => $menuName,
                'menuSlug' => $menuSlug,
                'menuChecked' => 0,
            ];
            // Store the UI's exact boolean without changing the legacy table schema.
            // Legacy consumers ignore this extra field and continue reading menu/action keys.
            if (empty($stored)) {
                $node['siteManagementAccess'] = $siteManagementAccess;
            }

            if (empty($children)) {
                $key = $this->permissionKey([$menuName]);
                $actions = $this->storedActions($permissionMap[$key] ?? []);
                $node['permissionKey'] = $key;
                $node['actions'] = $actions;
                $node['menuChecked'] = $this->hasCheckedAction($actions) ? 1 : 0;
                $stored[] = $node;
                continue;
            }

            $submenuNodes = [];
            $menuChecked = false;
            foreach ($children as $child) {
                $submenuName = trim((string) ($child['name'] ?? 'Unnamed submenu'));
                $submenuSlug = $child['slug'] ?? null;
                $leaves = isset($child['submenu']) && is_array($child['submenu'])
                    ? array_values(array_filter($child['submenu'], 'is_array'))
                    : [];

                if (empty($leaves)) {
                    $key = $this->permissionKey([$menuName, $submenuName]);
                    $actions = $this->storedActions($permissionMap[$key] ?? []);
                    $submenuNode = [
                        'submenuName' => $submenuName,
                        'submenuSlug' => $submenuSlug,
                        'permissionKey' => $key,
                        'submenuChecked' => $this->hasCheckedAction($actions) ? 1 : 0,
                        'actions' => $actions,
                    ];
                    $menuChecked = $menuChecked || $this->hasCheckedAction($actions);
                    $submenuNodes[] = $submenuNode;
                    continue;
                }

                $lastmenuNodes = [];
                $submenuChecked = false;
                foreach ($leaves as $leaf) {
                    $leafName = trim((string) ($leaf['name'] ?? 'Unnamed item'));
                    $key = $this->permissionKey([$menuName, $submenuName, $leafName]);
                    $actions = $this->storedActions($permissionMap[$key] ?? []);
                    $lastmenuNodes[] = [
                        'lastmenuName' => $leafName,
                        'lastmenuSlug' => $leaf['slug'] ?? null,
                        'permissionKey' => $key,
                        'lastmenuChecked' => $this->hasCheckedAction($actions) ? 1 : 0,
                        'actions' => $actions,
                    ];
                    $submenuChecked = $submenuChecked || $this->hasCheckedAction($actions);
                }

                $submenuNodes[] = [
                    'submenuName' => $submenuName,
                    'submenuSlug' => $submenuSlug,
                    'submenuChecked' => $submenuChecked ? 1 : 0,
                    'lastmenu' => $lastmenuNodes,
                ];
                $menuChecked = $menuChecked || $submenuChecked;
            }

            $node['submenu'] = $submenuNodes;
            $node['menuChecked'] = $menuChecked ? 1 : 0;
            $stored[] = $node;
        }

        return $stored;
    }

    /** Convert UI permission data into the legacy List/Add/Edit/Delete actions. */
    private function storedActions(array $actions): array
    {
        $mapping = [
            'view' => 'List',
            'create' => 'Add',
            'edit' => 'Edit',
            'delete' => 'Delete',
        ];
        $stored = [];

        foreach ($mapping as $uiAction => $legacyAction) {
            $checked = !empty($actions[$uiAction]);
            $stored[] = [
                'actionName' => $legacyAction,
                'actionKey' => $uiAction,
                'actionChecked' => $checked ? 1 : 0,
            ];
        }

        return $stored;
    }

    private function hasCheckedAction(array $actions): bool
    {
        foreach ($actions as $action) {
            if (!empty($action['actionChecked'])) {
                return true;
            }
        }

        return false;
    }

    /** Flatten a stored JSON tree to checkbox values, also accepting legacy records without permissionKey. */
    private function permissionArrayToUiMap(array $stored): array
    {
        $map = [];

        foreach ($stored as $menuItem) {
            if (!is_array($menuItem)) {
                continue;
            }
            $menuName = (string) ($menuItem['menuName'] ?? '');
            if ($menuName === '') {
                continue;
            }
            $menuPath = [$menuName];
            $this->captureNodeActions($map, $menuItem, $menuPath, 'actions', 'menu');

            $submenus = isset($menuItem['submenu']) && is_array($menuItem['submenu']) ? $menuItem['submenu'] : [];
            foreach ($submenus as $submenu) {
                if (!is_array($submenu)) {
                    continue;
                }
                $submenuName = (string) ($submenu['submenuName'] ?? '');
                if ($submenuName === '') {
                    continue;
                }
                $submenuPath = [$menuName, $submenuName];
                $this->captureNodeActions($map, $submenu, $submenuPath, 'actions', 'submenu');

                $lastmenus = isset($submenu['lastmenu']) && is_array($submenu['lastmenu']) ? $submenu['lastmenu'] : [];
                foreach ($lastmenus as $lastmenu) {
                    if (!is_array($lastmenu)) {
                        continue;
                    }
                    $lastmenuName = (string) ($lastmenu['lastmenuName'] ?? '');
                    if ($lastmenuName !== '') {
                        $this->captureNodeActions($map, $lastmenu, [$menuName, $submenuName, $lastmenuName], 'actions', 'lastmenu');
                    }
                }
            }
        }

        return $map;
    }

    private function captureNodeActions(array &$map, array $node, array $path, string $actionsField, string $level): void
    {
        $key = (string) ($node['permissionKey'] ?? $this->permissionKey($path));
        $actions = array_fill_keys(self::UI_ACTIONS, false);
        $items = isset($node[$actionsField]) && is_array($node[$actionsField]) ? $node[$actionsField] : [];

        foreach ($items as $action) {
            if (!is_array($action)) {
                continue;
            }
            $name = strtolower(trim((string) ($action['actionKey'] ?? $action['actionName'] ?? '')));
            $uiAction = match ($name) {
                'view', 'list', 'read', 'index' => 'view',
                'create', 'add', 'store', 'insert' => 'create',
                'edit', 'update', 'modify' => 'edit',
                'delete', 'remove', 'destroy' => 'delete',
                default => null,
            };

            if ($uiAction !== null) {
                $actions[$uiAction] = $actions[$uiAction] || filter_var($action['actionChecked'] ?? false, FILTER_VALIDATE_BOOLEAN);
            }
        }

        // A later legacy node can use a slug-based key; the path-derived key remains the fallback.
        $map[$key] = $actions;
        $map[$this->permissionKey($path)] = $actions;
    }

    private function siteManagementEnabled(?UserRolePermissionModel $permission): bool
    {
        if (!$permission) {
            return false;
        }

        $stored = $permission->decodedPermissions();
        if (isset($stored[0]) && is_array($stored[0]) && array_key_exists('siteManagementAccess', $stored[0])) {
            return filter_var($stored[0]['siteManagementAccess'], FILTER_VALIDATE_BOOLEAN);
        }

        // Backward compatibility for existing records created before this UI flag existed.
        return (int) $permission->manage_branch === 2;
    }

    private function permissionKey(array $path): string
    {
        $canonicalPath = array_values(array_map(static fn ($part) => trim((string) $part), $path));
        return hash('sha256', json_encode($canonicalPath, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    private function encodePermissions(array $permissions): string
    {
        $json = json_encode($permissions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            throw new \RuntimeException('Unable to encode role permissions as JSON.');
        }

        return $json;
    }

    private function generateRoleCode(int $roleSno): string
    {
        $sequence = max(1, $roleSno);
        $year = date('y');

        // The schema has no unique index on role_id; check before writing the generated legacy-style code.
        while (UserRoleModel::query()->where('role_id', sprintf('UR-%04d/%s', $sequence, $year))->exists()) {
            $sequence++;
        }

        return sprintf('UR-%04d/%s', $sequence, $year);
    }

    private function actorId(Request $request): int
    {
        $user = $request->user();

        // Existing Ryan Infra controllers use user_id as the actor ID and fall back to system user 1.
        return (int) ($user->user_id ?? $user->id ?? 1);
    }
}
