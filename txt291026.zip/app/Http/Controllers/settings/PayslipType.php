<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PayslipType extends Controller
{
  public function index()
  {
    return view('content.settings.accounts.payslip_type');
  }
}
