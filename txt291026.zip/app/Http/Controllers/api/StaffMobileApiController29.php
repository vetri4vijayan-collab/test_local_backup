<?php

namespace App\Http\Controllers\api;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Laravel\Passport\HasApiTokens;
use App\Models\OtpModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\SmsTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\HR\StaffModel;
use App\Models\StaffAttendanceModel;
use App\Models\AttendanceLogModel;
use Illuminate\Support\Facades\Config;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Laravel\Sanctum\PersonalAccessToken;
use Illuminate\Support\Str;
use App\Models\NotificationMobileModel;
use App\Traits\NotifiableTrait;
use App\Models\HolidayModel;
use App\Models\LeavePermissionModel;
use App\Models\LeaveApprovalModel;
use App\Models\ApprovalHierarchyModel;
use App\Models\LeaveReasonModel;
use App\Models\PermissionReasonModel;
use App\Models\TrainingPlannerModel;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Log;

/**
 * @OA\Info(
 *   title="Employee App API",
 *   version="1.0.0",
 *   description="API documentation for Employee App"
 * )
 *
 * @OA\Server(
 *   url="/",
 *   description="Dev API Server"
 * )
 *
 * @OA\Tag(
 *   name="Employee",
 *   description="Employee related APIs"
 * )
 */
class StaffMobileApiController extends Controller
{
    //  use NotifiableTrait;
/**
     * @OA\Post(
     *     path="/employee_login",
     *     summary="Employee login",
     *     tags={"Employee"},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"mobile_no",},
     *             @OA\Property(property="mobile_no", type="string", example="9089788990"),
     *             @OA\Property(property="device_id", type="string", example="device123"),
     *             @OA\Property(property="latitude", type="string", example="12.9716"),
     *             @OA\Property(property="longitude", type="string", example="77.5946")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="OTP Sent Successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="status", type="integer", example=200),
     *             @OA\Property(property="message", type="string", example="OTP Sent Successfully"),
     *             @OA\Property(property="otp", type="string")
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation Error"
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="User inactive or deactivated"
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Invalid credentials or user not found"
     *     )
     * )
     */

  public function login(Request $request)
  {

    $user_name = $request->user_name;
    // $mobile_no = $request->mobile_no;
    $password      = $request->password ;

    $device_id = $request->device_id;
    $latitude = $request->latitude;
    $longitude = $request->longitude;

    $validator = Validator::make($request->all(), [
      'user_name' => 'required',
      'password' => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
    } else {

        $user = User::select('users.*', 'ryans_staff.status as staff_status')
            ->where('users.username', $user_name)
            ->leftJoin('ryans_staff', 'users.user_id', '=', 'ryans_staff.sno')
            ->whereIn('ryans_staff.status', [0,1])
            ->first();

        if ($user->staff_status == 1) {
        return response()->json([
            'status' => 410,
            'message' =>'This user is inactive. Please contact the administrator.'
            ],410);
        } 

        if ($user->username !== $user_name) {
            return response()->json([
                'status' => 410,
                'message' =>'Username is case-sensitive. Please enter the correct case.'
                ],410);
        }

        if (!Hash::check($password, $user->password)) {
            return response()->json([
                'status' => 410,
                'message' =>'Invalid credentials Password'
                ],200);
        }

        if (!$user) {
            DB::table('mobile_user_login_logs')->insert([
                'user_id'    => 0,        
                'login_at'   => Carbon::now('Asia/Kolkata'),
                'ip_address' => $request->ip(),
                'user_agent' => $request->header('User-Agent'),
                'user_name'  => $user_name,
                // 'mobile_no'  => $mobile_no,
                'latitude'   => $latitude,
                'longitude'   => $longitude,
                'device_id'   => $device_id,
                'type'       => 1, // failed
                'created_at' => Carbon::now('Asia/Kolkata'),
                'updated_at' => Carbon::now('Asia/Kolkata'),
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'User not found.',
                'error_msg'=>'User not found.',
                'data' => NULL
            ]);
        }
        $staff_id =$user->user_id;
        $secret_key = env('JWT_SECRET', 'RYAN$INFR@EMPLOYEE@PP2026'); // Add JWT_SECRET in .env
        $issuer_claim = "Employee App"; // this can be your app name
        $audience_claim = "mobile-app";
        $issued_at = time();
        $expiry_time = $issued_at + (60*60*168); // 7 day expiry, 

        $payload = [
            "iss" => $issuer_claim,
            "aud" => $audience_claim,
            "iat" => $issued_at,
            "exp" => $expiry_time,
            "staff_sno" => $staff_id
        ];


        $jwt_token = JWT::encode($payload, $secret_key, 'HS256');

        $token = new PersonalAccessToken();
        $token->forceFill([
            'tokenable_type' => \App\Models\HR\StaffModel::class,
            'tokenable_id'   => $staff_id,
            'name'           => 'jwt_token',
            'token'          => hash('sha256', $jwt_token),
            'abilities'      => ['*'],
            'expires_at'     => Carbon::createFromTimestamp($expiry_time),
        ])->save();
            
        DB::table('mobile_user_login_logs')->insert([
            'user_id'    => $user->sno,
            'login_at'   => Carbon::now('Asia/Kolkata'),
            'ip_address' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'user_name'  => $user_name,
            // 'mobile_no'  => $mobile_no,
            // 'otp'  => $otpInput,
            'latitude'   => $latitude,
            'longitude'   => $longitude,
            'device_id'   => $device_id,
            'type'       => 0, // success
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);


        // $this->sendNotification(
        //             $user->branch_id,
        //             $user->sno,
        //             "Logged in Successfully",
        //             "Employee App",
        //             $user->sno
        //         );

         return response()->json([
            'status' => 200,
            'message' => 'Logged in Successfully',
            'error_msg'=>NULL,
            'user_id' => $staff_id,
            'token' => $jwt_token,
            'expires_at' => date('Y-m-d H:i:s', $expiry_time),
        ], 200);

    }
  }



   /**
 * @OA\Get(
 *     path="/get_staff_data",
 *     summary="Get staff data",
 *     tags={"Employee"},
 *     security={{"bearerAuth":{}}},
 *     @OA\Response(
 *         response=200,
 *         description="Staff data fetched successfully",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=200),
 *             @OA\Property(property="message", type="string", example="Staff data fetched successfully"),
 *             @OA\Property(property="data", type="object")
 *         )
 *     ),
 *     @OA\Response(
 *         response=401,
 *         description="Token missing or invalid",
 *         @OA\JsonContent(
 *             @OA\Property(property="status", type="integer", example=401),
 *             @OA\Property(property="message", type="string", example="Token invalid or expired")
 *         )
 *     )
 * )
 */
   

    public function profile(Request $request)
    {

        $user = $request->user();

        return $user;

        $staff = StaffModel::where('sno', $user->sno)
            ->where('status', '!=', 2)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }

        
        $detail = $this->staffService->find($staff->sno);

        $staff = (array) $detail['staff'];
        foreach ([
            'password', 'credential', 'user_name', 'super_user_token', 'remember_token',
            'login_pin', 'otp',
        ] as $sensitive) {
            unset($staff[$sensitive]);
        }
        // The web-only staff image route is not usable by a bearer-token mobile app.
        $staff['staff_image_url'] = !empty($staff['staff_image'])
            ? url('/api/v1/staff/profile/photo')
            : null;

        unset($staff['attachment']);
        $attachments = collect($detail['attachments'] ?? [])->map(function ($item) {
            $record = (array) $item;
            if (isset($record['attachment_name'])) {
                $record['file_name'] = basename(str_replace('\\', '/', (string) $record['attachment_name']));
                unset($record['attachment_name']);
            }
            return $record;
        });

        return response()->json([
            'success' => true,
            'message' => 'Staff profile fetched successfully.',
            'data' => [
                'staff' => $staff,
                'profile' => $detail['profile'] ?? [],
                'remuneration' => $detail['remuneration'] ?? [],
                'education' => $detail['education'] ?? [],
                'experience' => $detail['experience'] ?? [],
                'family' => $detail['family'] ?? null,
                'attachments' => $attachments,
            ],
        ]);
    }

    /** Stream the current staff member's profile image under bearer-token authorization. */
    public function photo(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->sno)
            ->where('status', '!=', 2)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }
        
        $path = trim((string) ($staff->staff_image ?? ''));
        if ($path === '' || !str_starts_with($path, 'staff/profile/') || str_contains($path, '..') || !Storage::disk('local')->exists($path)) {
            abort(404, 'Profile image not found.');
        }

        $absolutePath = Storage::disk('local')->path($path);
        $mime = function_exists('mime_content_type') ? mime_content_type($absolutePath) : 'application/octet-stream';
        if (!is_string($mime) || !str_starts_with($mime, 'image/')) {
            abort(404, 'Profile image not found.');
        }

        return response()->file($absolutePath, [
            'Content-Type' => $mime,
            'Cache-Control' => 'private, no-store, max-age=0',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    /** Submit a leave request for the authenticated employee only. */
    public function leaveRequest(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->sno)
            ->where('status', '!=', 2)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }

        $validated = $request->validate([
            'leave_type' => ['required', 'string', 'max:80'],
            'from_date' => ['required', 'date_format:Y-m-d', 'after_or_equal:today'],
            'to_date' => ['required', 'date_format:Y-m-d', 'after_or_equal:from_date'],
            'reason' => ['required', 'string', 'max:2000'],
        ]);

        $type = $staff->employment_type === 1 ? 'permanent' : 'contract';
        $leave = $this->leaveService->createRequest(
            $staff->sno,
            $validated,
            $type,
            $staff->sno
        );

        return response()->json([
            'success' => true,
            'message' => 'Leave request submitted for approval.',
            'data' => [
                'id' => (int) $leave->sno,
                'leave_type' => $leave->leave_type,
                'from_date' => (string) $leave->from_date,
                'to_date' => (string) $leave->to_date,
                'days' => (float) $leave->days,
                'reason' => $leave->reason,
                'approval_status' => $leave->approval_status,
                'created_at' => optional($leave->created_at)->toIso8601String(),
            ],
        ], 201);
    }

    /** Store server-generated check-in time and the phone's validated GPS fix atomically. */
    public function checkIn(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->sno)
            ->where('status', '!=', 2)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }
        $validated = $this->validateLocation($request);

        $result = $this->attendanceService->checkIn(
            $staff->sno,
            $staff->employment_type,
            $staff->sno,
            (float) $validated['latitude'],
            (float) $validated['longitude'],
            isset($validated['accuracy_m']) ? (float) $validated['accuracy_m'] : null,
            $validated['device_id'] ?? null
        );

        return response()->json([
            'success' => true,
            'message' => 'Check-in recorded successfully.',
            'data' => $result,
        ]);
    }

    /** Store server-generated check-out time and GPS fix on the same attendance row. */
    public function checkOut(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->sno)
            ->where('status', '!=', 2)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }

        $validated = $this->validateLocation($request);

        $result = $this->attendanceService->checkOut(
            $staff->sno,
            $staff->employment_type,
            $staff->sno,
            (float) $validated['latitude'],
            (float) $validated['longitude'],
            isset($validated['accuracy_m']) ? (float) $validated['accuracy_m'] : null,
            $validated['device_id'] ?? null
        );

        return response()->json([
            'success' => true,
            'message' => 'Check-out recorded successfully.',
            'data' => $result,
        ]);
    }

    /** Return paginated records for one requested month; the staff id always comes from the token. */
    public function attendanceHistory(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->sno)
            ->where('status', '!=', 2)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }
        $validated = $request->validate([
            'month' => ['required', 'date_format:Y-m'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $page = $this->attendanceService->history(
            $staff->sno,
            $validated['month'],
            (int) ($validated['per_page'] ?? 31)
        );

        $records = collect($page->items())->map(function (StaffAttendanceModel $row) {
            return [
                'id' => (int) $row->sno,
                'date' => $row->date ? $row->date->format('Y-m-d') : null,
                'attendance' => (string) $row->attendance,
                'in_time' => $row->in_time,
                'out_time' => $row->out_time,
                'type' => $row->type,
                'reason' => $row->reason,
                'check_in' => [
                    'latitude' => $row->check_in_latitude === null ? null : (float) $row->check_in_latitude,
                    'longitude' => $row->check_in_longitude === null ? null : (float) $row->check_in_longitude,
                    'accuracy_m' => $row->check_in_accuracy_m === null ? null : (float) $row->check_in_accuracy_m,
                ],
                'check_out' => [
                    'latitude' => $row->check_out_latitude === null ? null : (float) $row->check_out_latitude,
                    'longitude' => $row->check_out_longitude === null ? null : (float) $row->check_out_longitude,
                    'accuracy_m' => $row->check_out_accuracy_m === null ? null : (float) $row->check_out_accuracy_m,
                ],
            ];
        });

        return response()->json([
            'success' => true,
            'message' => 'Monthly attendance history fetched successfully.',
            'data' => $records,
            'meta' => [
                'month' => $validated['month'],
                'current_page' => $page->currentPage(),
                'last_page' => $page->lastPage(),
                'per_page' => $page->perPage(),
                'total' => $page->total(),
            ],
        ]);
    }

    /** Revoke only the token used to call this endpoint. */
    public function logout(Request $request)
    {
        $token = $request->user()?->currentAccessToken();
        if ($token && method_exists($token, 'delete')) $token->delete();

        return response()->json(['success' => true, 'message' => 'Logged out successfully.']);
    }

    

    private function validateLocation(Request $request): array
    {
        return $request->validate([
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'accuracy_m' => ['nullable', 'numeric', 'min:0', 'max:100000'],
            'device_id' => ['nullable', 'string', 'max:255'],
        ]);
    }
  
  
}