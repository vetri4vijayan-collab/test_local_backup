<?php

namespace App\Http\Controllers\auth;

use App\Http\Controllers\Controller;
use App\Services\Auth\WebLoginService;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class WebAuthController extends Controller
{
    public function __construct(private WebLoginService $loginService) {}

    public function login(Request $request)
    {
        $data = $request->validate([
            'identifier' => ['required', 'string', 'max:190'],
            'password' => ['required', 'string', 'max:200'],
            'remember' => ['nullable', 'boolean'],
        ]);

        try {
            $this->loginService->login($data['identifier'], $data['password'], (bool) ($data['remember'] ?? false));
        } catch (ValidationException $exception) {
            return back()->withErrors($exception->errors())->withInput($request->only('identifier'));
        }

        return redirect()->intended(route('admin-hr.staff.permanent'));
    }

    public function logout(Request $request)
    {
        $this->loginService->logout();
        return redirect()->route('login');
    }
}
