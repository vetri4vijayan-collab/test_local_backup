<?php

namespace App\Http\Controllers\material_master;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SiteIndent extends Controller
{
  public function index ()
  {
    return view('content.store_purchase.material.site_indent');
  }
}