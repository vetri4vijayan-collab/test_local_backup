<?php

namespace App\Http\Controllers\material_master;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MaterialMaster extends Controller
{
  public function index ()
  {
    return view('content.store_purchase.material.material_master');
  }
}