<?php

namespace App\Http\Controllers\purchase;

use App\Http\Controllers\Controller;

class Quotation extends Controller
{
    public function quotationComparison()
    {
        return view('content.store_purchase.purchase-management.quotation-comparison');
    }

    public function receiptInspect()
    {
        return view('content.store_purchase.purchase-management.receipt-inspect');
    }

    public function analyticalReport()
    {
        return view('content.store_purchase.purchase-management.analytical-report');
    }
}