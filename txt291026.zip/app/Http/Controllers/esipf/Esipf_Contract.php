<?php

namespace App\Http\Controllers\esipf;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Esipf_Contract extends Controller
{
  public function esi_contract ()
  {
    return view('content.admin_hr.esi&pf.esipf_contract');
  }
}
