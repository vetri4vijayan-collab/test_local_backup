<?php

namespace App\Http\Controllers\esipf;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Esipf_Permanent extends Controller
{
  public function esi_permanent ()
  {
    return view('content.admin_hr.esi&pf.esipf_permanent');
  }
}
