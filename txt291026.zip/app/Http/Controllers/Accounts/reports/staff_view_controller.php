<?php

namespace App\Http\Controllers\accounts\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class staff_view_controller extends Controller
{
    public function staff_view()
    {
        return view('content.accounts.reports.staff_view_report');
    }
}