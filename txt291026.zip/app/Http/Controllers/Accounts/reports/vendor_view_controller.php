<?php

namespace App\Http\Controllers\accounts\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class vendor_view_controller extends Controller
{
    public function vendor()
    {
        return view('content.accounts.reports.vendor_view');
    }
}