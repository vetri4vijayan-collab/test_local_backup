<?php

namespace App\Http\Controllers\accounts\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class client_controller extends Controller
{
    public function client()
    {
        return view('content.accounts.reports.client_report');
    }
}
