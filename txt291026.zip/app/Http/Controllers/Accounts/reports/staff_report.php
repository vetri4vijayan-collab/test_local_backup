<?php

namespace App\Http\Controllers\accounts\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class staff_report extends Controller
{
    public function staff_report()
    {
        return view('content.accounts.reports.staff_report');
    }
}