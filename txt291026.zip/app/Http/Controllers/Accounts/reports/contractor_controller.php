<?php

namespace App\Http\Controllers\accounts\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class contractor_controller extends Controller
{
    public function contract()
    {
        return view('content.accounts.reports.contractor');
    }
}
