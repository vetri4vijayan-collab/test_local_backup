<?php

namespace App\Http\Controllers\accounts\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class profit_loss_controller extends Controller
{
    public function profit_loss()
    {
        return view('content.accounts.reports.profit&loss');
    }
}
