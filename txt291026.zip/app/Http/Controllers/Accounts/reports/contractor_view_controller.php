<?php

namespace App\Http\Controllers\accounts\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class contractor_view_controller extends Controller
{
    public function contract_view()
    {
        return view('content.accounts.reports.contractor_view');
    }
}
