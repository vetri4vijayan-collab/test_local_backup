<?php

namespace App\Http\Controllers\accounts\reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class client_view_controller extends Controller
{
    public function client_view()
    {
        return view('content.accounts.reports.client_view');
    }
}
