<?php

namespace App\Http\Controllers\accounts\taxmanage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class file_controller extends Controller
{
    public function file_return()
    {
        return view('content.accounts.tax_manage.file_return');
    }
}
