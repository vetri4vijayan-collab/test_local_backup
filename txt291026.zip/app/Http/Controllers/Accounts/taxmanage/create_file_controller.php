<?php

namespace App\Http\Controllers\accounts\taxmanage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class create_file_controller extends Controller
{
    public function create_file()
    {
        return view('content.accounts.tax_manage.create_file_return');
    }
}
