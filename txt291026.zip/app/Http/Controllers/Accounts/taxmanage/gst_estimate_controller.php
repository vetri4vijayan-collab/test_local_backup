<?php

namespace App\Http\Controllers\accounts\taxmanage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class gst_estimate_controller extends Controller
{
    public function gst_estimate()
    {
        return view('content.accounts.tax_manage.gst_estimate');
    }
}
