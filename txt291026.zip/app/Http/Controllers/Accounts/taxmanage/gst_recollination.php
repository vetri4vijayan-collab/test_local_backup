<?php

namespace App\Http\Controllers\accounts\taxmanage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class gst_recollination extends Controller
{
    public function gst_recol()
    {
        return view('content.accounts.tax_manage.gst_recollination');
    }
}
