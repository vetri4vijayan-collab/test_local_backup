<?php

namespace App\Http\Controllers\accounts\taxmanage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class gst_payable extends Controller
{
    public function gst_pay()
    {
        return view('content.accounts.tax_manage.gst_payable');
    }
}
