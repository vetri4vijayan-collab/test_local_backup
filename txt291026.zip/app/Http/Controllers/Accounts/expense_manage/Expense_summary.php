<?php

namespace App\Http\Controllers\accounts\expense_manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Expense_summary extends Controller
{
    public function expense_summary()
    {
        return view('content.accounts.expense_manage.expense_summary');
    }
}