<?php

namespace App\Http\Controllers\accounts\expense_manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Expense_list extends Controller
{
    public function expense_list()
    {
        return view('content.accounts.expense_manage.expense_list');
    }
}