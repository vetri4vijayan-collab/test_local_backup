<?php

namespace App\Http\Controllers\Accounts\Banking\Accounts\Banking;

use App\Http\Controllers\Controller;

class CashflowController extends Controller
{
    public function cash()
    {
        return view('content.accounts.banking.cash');
    }
}
