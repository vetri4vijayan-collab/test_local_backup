<?php

namespace App\Http\Controllers\Accounts\Banking\Accounts\Banking;

use App\Http\Controllers\Controller;

class AccountsController extends Controller
{
    public function index()
    {
        return view('content.accounts.banking.banking');
    }
    public function ledger()
    {
          return view('content.accounts.banking.ledger');
    }
}
