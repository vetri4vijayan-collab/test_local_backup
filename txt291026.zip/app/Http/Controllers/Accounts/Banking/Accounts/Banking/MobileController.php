<?php

namespace App\Http\Controllers\Accounts\Banking\Accounts\Banking;

use App\Http\Controllers\Controller;

class MobileController extends Controller
{
    public function mobile()
    {
        return view('content.accounts.banking.mobile');
    }
}
