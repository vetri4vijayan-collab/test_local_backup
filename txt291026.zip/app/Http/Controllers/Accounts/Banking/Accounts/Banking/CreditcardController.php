<?php

namespace App\Http\Controllers\Accounts\Banking\Accounts\Banking;

use App\Http\Controllers\Controller;

class CreditcardController extends Controller
{
    public function card()
    {
        return view('content.accounts.banking.card');
    }
}
