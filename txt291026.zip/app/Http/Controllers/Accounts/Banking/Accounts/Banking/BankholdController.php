<?php

namespace App\Http\Controllers\Accounts\Banking\Accounts\Banking;

use App\Http\Controllers\Controller;

class BankholdController extends Controller
{
    public function hold()
    {
        return view('content.accounts.banking.hold');
    }
}
