<?php

namespace App\Http\Controllers\accounts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Receivable_Controller extends Controller
{
  public function Receive ()
  {
    return view('content.accounts.accounts_receivable');
  }
}