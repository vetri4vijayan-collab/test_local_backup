<?php

namespace App\Http\Controllers\accounts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Accounts_Controller extends Controller
{
  public function accounts_pay ()
  {
    return view('content.accounts.accounts_payable');
  }
}