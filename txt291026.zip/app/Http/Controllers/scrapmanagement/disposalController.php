<?php

namespace App\Http\Controllers\scrapmanagement;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class disposalController extends Controller
{
    public function disposal()
    {
        return view('content.store_purchase.scrap.disposal');
    }

    public function disposalEntry()
    {
        return view('content.store_purchase.scrap.disposal-entry');
    }

    public function disposalView()
    {
        return view('content.store_purchase.scrap.disposal-view');
    }
  
}