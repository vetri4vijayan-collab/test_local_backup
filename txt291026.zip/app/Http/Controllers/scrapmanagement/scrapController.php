<?php

namespace App\Http\Controllers\scrapmanagement;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class scrapController extends Controller
{
    public function scrap()
    {
        return view('content.store_purchase.scrap.inventory');
    }

    public function materialView()
    {
        return view('content.store_purchase.scrap.materialview');
    }
}