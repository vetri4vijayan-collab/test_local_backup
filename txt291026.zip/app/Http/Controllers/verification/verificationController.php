<?php

namespace App\Http\Controllers\verification;

use App\Http\Controllers\Controller;

class verificationController extends Controller
{
    public function index()
    {
        return view('content.verification.reconciliation');
    }

    public function passing()
    {
        return view('content.verification.passing');
    }
}



