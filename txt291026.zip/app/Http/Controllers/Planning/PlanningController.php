<?php

namespace App\Http\Controllers\Planning;

use App\Http\Controllers\Controller;

class PlanningController extends Controller
{
    public function index()
    {
        return view('content.planning.management');
    }

    public function dailyProgress()
    {
        return view('content.planning.daily');
    }

    public function plannedVsAchieved()
    {
        return view('content.planning.achieved');
    }
}
