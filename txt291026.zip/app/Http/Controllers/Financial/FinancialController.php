<?php

namespace App\Http\Controllers\Financial;

use App\Http\Controllers\Controller;

class FinancialController extends Controller
{

    public function index()
    {
        return view('content.Financial.client');
    }

       public function contractor()
    {
        return view('content.Financial.contractor');
    }

    public function credit()
    {
      return view('content.Financial.credit');
    }

    public function security()
    {
       return view('content.Financial.security');
    }
     
    public function report()
    {
       return view('content.Financial.report');
    }


}
