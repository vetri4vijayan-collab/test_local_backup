<?php

namespace App\Http\Controllers\attendance_log;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ContractTable extends Controller
{
  public function contract_table ()
  {
    return view('content.admin_hr.attendance_log.contract_table');
  }
}