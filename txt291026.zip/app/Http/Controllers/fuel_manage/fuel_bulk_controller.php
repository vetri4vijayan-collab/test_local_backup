<?php

namespace App\Http\Controllers\fuel_manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class fuel_bulk_controller extends Controller
{
    public function fuel_bulk()
    {
        return view('content.store_purchase.fuel_management.fuel_bulk');
    }
}