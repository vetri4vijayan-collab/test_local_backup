<?php

namespace App\Http\Controllers\fuel_manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class fuel_summary_controller extends Controller
{
    public function fuel_summary()
    {
        return view('content.store_purchase.fuel_management.fuel_reconciliation_summary');
    }
}