<?php

namespace App\Http\Controllers\fuel_manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Equipment_controller extends Controller
{
    public function fuel_log()
    {
        return view('content.store_purchase.fuel_management.Equipment_log');
    }
}