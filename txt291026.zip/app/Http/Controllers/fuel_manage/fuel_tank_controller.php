<?php

namespace App\Http\Controllers\fuel_manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class fuel_tank_controller extends Controller
{
    public function fuel_tank()
    {
        return view('content.store_purchase.fuel_management.fuel_tank');
    }
}