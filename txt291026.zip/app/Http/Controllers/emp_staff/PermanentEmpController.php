<?php

namespace App\Http\Controllers\emp_staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PermanentEmpController extends Controller
{
  public function index ()
  {
    return view('content.admin_hr.emp_staff.permanent_staff');
  }
}
