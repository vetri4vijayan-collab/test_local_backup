<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserRolePermissionModel;
use App\Models\User;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Http;
use App\Models\HR\StaffModel;

class Login extends Controller
{
  public function index(Request $request)
  {
    $user = Auth::user();

    Auth::guard('web')->logout();
    $request->session()->invalidate();

    $request->session()->regenerateToken();
    
    return view('content.dashboard.login');
  }
  public function get_staff()
  {
    return view('content.dashboard.get_staff');
  }
  public function forgot_password()
  {
    return view('content.dashboard.forgot_password');
  }
  public function new_password()
  {
    return view('content.dashboard.new_password');
  }
  public function dashboards()
  {
    return view('content.dashboard.dashboards-analytics');
  }

  public function login(Request $request)
  {
      // return $request;
      $validator = Validator::make($request->all(), [
        'name' => 'required|max:255',
        'password' => 'required',
      ]);

      if ($validator->fails()) {
        return response()->json([
          'status' => 410,
          'message' => $validator->errors(),
        ],200);
      }

      $remember = $request->has('remember');

      $user = User::select('users.*', 'ryans_staff.status as staff_status')
        ->where('users.username', $request->name)
        ->leftJoin('ryans_staff', 'users.user_id', '=', 'ryans_staff.sno')
        ->whereIn('ryans_staff.status', [0,1])
        ->first();

    if (!$user) {
        DB::table('user_login_logs')->insert([
            'user_id'    => 0,        
            'login_at'   => Carbon::now('Asia/Kolkata'),
            'ip_address' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'user_name'  => $request->name,
            'password'   => $request->password,
            'type'       => 1, // failed
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);

        return response()->json([
          'status' => 401,
          'message' =>'User not found.'
        ],200);
    }

    if ($user->staff_status == 1) {
      return response()->json([
          'status' => 402,
          'message' =>'This user is inactive. Please contact the administrator.'
        ],200);
    } 

    if ($user->username !== $request->name) {
     
      return response()->json([
          'status' => 410,
          'message' =>'Username is case-sensitive. Please enter the correct case.'
        ],200);
    }

    if (!Hash::check($request->password, $user->password)) {
       return response()->json([
          'status' => 410,
          'message' =>'Invalid credentials Password'
        ],200);
    }

    Auth::login($user, $remember);
    
    session(['user_id' => $user->id]);
    
    // ✅ Log login info to user_login_logs
        DB::table('user_login_logs')->insert([
            'user_id'    => $user->id,
            'login_at'   => Carbon::now('Asia/Kolkata'),
            'ip_address' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'user_name'  => $request->name,
            'password'   => $request->password,
            'type'       => 0, // success
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);

    $staff = StaffModel::where('sno', $user->user_id)->first();
    // Carbon::parse($staff->updated_at)->timezone('Asia/Kolkata')->format('Y-m-d h:i A');
    // $staff->save();
    if ($staff) {
        $staff->updated_at = Carbon::now('Asia/Kolkata');
        $staff->save();
    }

    $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();

    // dd($permissions);
    // Assuming you have a method in the User model to check role permissions
    if (!$permissions) {
      // Redirect to the role_permission_error page if the user doesn't have the role
      return redirect()->route('role_permission_error');
    }
    // Create a personal access token
    $token = $user->createToken('auth_token')->plainTextToken;

    // Set the cookie with the token, valid for 1 day
    // Cookie::queue('auth_token', $token, 1440);

    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Logged in Successfully!'
    ]);

    if ($request->expectsJson()) {
      return response()->json([
        'status' => 200,
        'message' => 'Logged in Successfully',
        'data' => [
          'redirect_url' => route('dashboards'),
          'token' => $token,
        ]
      ],200);
    } else {
      return response()->json([
        'status' => 200,
        'message' => 'Logged in Successfully',
        'data' => [
          'redirect_url' => route('dashboards'),
          'token' => $token,
        ]
      ],200);  // Ensure correct route name
    }
  }

  public function destroy(Request $request)
  {
      
      // Get the current authenticated user
    $user = Auth::user();

    if ($user) {
        // Update the latest login log with logout time
        DB::table('user_login_logs')
            ->where('user_id', $user->id)
            ->whereNull('logout_at') // Ensure we only update the last active session
            ->latest('login_at')
            ->limit(1)
            ->update([
                'logout_at' => now(),
                'updated_at' => now()
            ]);
    }
    Auth::guard('web')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    $cookieName = config('session.cookie'); // Get the session cookie name from configuration
    \Cookie::queue(\Cookie::forget($cookieName));

    return redirect('/');
  }
}
