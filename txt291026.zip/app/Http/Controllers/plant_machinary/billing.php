<?php

namespace App\Http\Controllers\plant_machinary;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class billing extends Controller
{
  public function bill ()
  {
    return view('content.plant_machinary.billing');
  }
}