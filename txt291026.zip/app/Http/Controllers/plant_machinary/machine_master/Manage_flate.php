<?php

namespace App\Http\Controllers\plant_machinary\machine_master;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Manage_flate extends Controller
{
  public function manage_controller ()
  {
    return view('content.plant_machinary..machine master.manage_flate');
  }
}
