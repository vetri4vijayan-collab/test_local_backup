<?php

namespace App\Http\Controllers\plant_machinary\machine_master;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Machine_Controller extends Controller
{
  public function machine_controller ()
  {
    return view('content.plant_machinary.machine master.machine_master');
  }
}