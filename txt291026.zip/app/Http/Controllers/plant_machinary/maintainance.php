<?php

namespace App\Http\Controllers\plant_machinary;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class maintainance extends Controller
{
  public function maintain ()
  {
    return view('content.plant_machinary.maintainance');
  }
}