<?php

namespace App\Http\Controllers\plant_machinary\machine_operation;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class machine_log extends Controller
{
  public function log ()
  {
    return view('content.plant_machinary.machine_operation.machine_log');
  }
}