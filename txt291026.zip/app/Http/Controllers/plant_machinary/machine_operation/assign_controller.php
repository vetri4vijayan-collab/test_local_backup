<?php

namespace App\Http\Controllers\plant_machinary\machine_operation;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class assign_controller extends Controller
{
  public function assign ()
  {
    return view('content.plant_machinary.machine_operation.assign_machine');
  }
}