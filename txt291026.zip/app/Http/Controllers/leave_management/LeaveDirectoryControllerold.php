<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use App\Services\HR\LeaveService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class LeaveDirectoryController extends Controller
{
    public function __construct(private LeaveService $leaveService) {}

    public function index(Request $request, string $type)
    {
        $filters = $request->validate(['search' => ['nullable', 'string', 'max:120'], 'leave_status' => ['nullable', Rule::in(['Pending', 'Approved', 'Rejected'])], 'page' => ['nullable', 'integer', 'min:1'], 'per_page' => ['nullable', 'integer', 'min:5', 'max:100']]);
        $p = $this->leaveService->paginate($type, array_merge(['per_page' => 10], $filters));
        return response()->json(['success' => true, 'data' => $p->items(), 'meta' => $this->meta($p)]);
    }

    public function entitlements(Request $request, string $type)
    {
        $filters = $request->validate(['search' => ['nullable', 'string', 'max:120'], 'year' => ['nullable', 'integer', 'min:2000', 'max:2100'], 'page' => ['nullable', 'integer', 'min:1'], 'per_page' => ['nullable', 'integer', 'min:5', 'max:100']]);
        $p = $this->leaveService->entitlements($type, array_merge(['per_page' => 10], $filters));
        return response()->json(['success' => true, 'data' => $p->items(), 'meta' => $this->meta($p)]);
    }

    public function storeRequest(Request $request, string $type)
    {
        $v = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'],
            'leave_type' => ['required', 'string', 'max:80'],
            'from_date' => ['required', 'date'],
            'to_date' => ['required', 'date', 'after_or_equal:from_date'],
            'reason' => ['required', 'string', 'max:2000'],
        ]);
        $leave = $this->leaveService->createRequest((int) $v['staff_id'], $v, $type);
        return response()->json(['success' => true, 'message' => 'Leave request created.', 'data' => $leave], 201);
    }

    public function review(Request $request, string $type, int $id)
    {
        $v = $request->validate(['approval_status' => ['required', Rule::in(['Approved', 'Rejected'])], 'review_note' => ['nullable', 'string', 'max:1000']]);
        $this->leaveService->review($id, $v['approval_status'], $v['review_note'] ?? null, $this->actor($request), $type);
        return response()->json(['success' => true, 'message' => 'Leave request reviewed.']);
    }

    public function saveEntitlement(Request $request, string $type)
    {
        $v = $request->validate(['staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'], 'leave_type' => ['required', 'string', 'max:80'], 'annual_days' => ['required', 'numeric', 'min:0', 'max:366'], 'year' => ['required', 'integer', 'min:2000', 'max:2100']]);
        $this->leaveService->saveEntitlement($type, $v, $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Leave entitlement saved.']);
    }

    public function saveEntitlementsBulk(Request $request, string $type)
    {
        $v = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'],
            'year' => ['required', 'integer', 'min:2000', 'max:2100'],
            'entitlements' => ['required', 'array', 'min:1', 'max:20'],
            'entitlements.*.leave_type' => ['required', 'string', 'max:80'],
            'entitlements.*.annual_days' => ['required', 'numeric', 'min:0', 'max:366'],
        ]);
        $this->leaveService->saveEntitlementsBulk($type, (int) $v['staff_id'], (int) $v['year'], $v['entitlements'], $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Leave balances saved.']);
    }

    public function batchCredit(Request $request, string $type)
    {
        $v = $request->validate([
            'leave_type' => ['required', 'string', 'max:80'],
            'year' => ['required', 'integer', 'min:2000', 'max:2100'],
            'annual_days' => ['required', 'numeric', 'min:0', 'max:366'],
        ]);
        $count = $this->leaveService->creditEntitlementForCategory($type, $v['leave_type'], (int) $v['year'], (float) $v['annual_days'], $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Batch credit applied to ' . $count . ' staff.', 'data' => ['updated_staff' => $count]]);
    }

    private function actor(Request $request): int { return (int) (($request->user()->user_id ?? 0) ?: ($request->user()->id ?? session('user_id', 1))); }
    private function meta($p): array { return ['current_page' => $p->currentPage(), 'last_page' => $p->lastPage(), 'per_page' => $p->perPage(), 'total' => $p->total()]; }
}
