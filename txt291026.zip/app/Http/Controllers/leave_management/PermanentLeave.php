<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PermanentLeave extends Controller
{
  public function leave ()
  {
    return view('content.admin_hr.leave_manage.permanent_lisst');
  }
}