<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Contract_Entitle extends Controller
{
  public function c_entitle ()
  {
    return view('content.admin_hr.leave_manage.contract_entitle');
  }
}