<?php

namespace App\Http\Controllers\GeneralLedger;

use App\Http\Controllers\Controller;

class DailyAccountsController extends Controller
{
    public function account()
    {
        return view('content.generalledger.general');
    }
}
