<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class DepotYardModel extends Model
{
    use HasFactory;
    protected $table = 'rayans_depot_yard';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'project_site',
        'head_office',
        'distance',
        'address',
        'country_id',
        'state_id',
        'city_id',
        'zip_code',
        'response_officer_name',
        'contact_number',
        'desigination',
        'mail_id',
        'created_by',
        'updated_by',
        'status',
    ];
}
