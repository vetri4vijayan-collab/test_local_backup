<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class CountryModel extends Model
{
    use HasFactory;
    protected $table = 'ryans_countries';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'country_sortname',
        'country_name',
        'description',
        'phonecode',
        'created_by',
        'updated_by',
        'status',
    ];
}
