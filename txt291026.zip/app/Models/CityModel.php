<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class CityModel extends Model
{
    use HasFactory;
    protected $table = 'ryans_cities';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'state_id',
        'city_name',
        'cid',
        'country_id',
        'description',
        'created_by',
        'updated_by',
        'status',
    ];
}
