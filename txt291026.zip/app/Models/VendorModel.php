<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VendorModel extends Model
{
    use HasFactory;
    public $table = "ryans_vendors";
    public $primaryKey = 'sno';

    protected $fillable = [
    'vendor_code',
    'vendor_type_id',
    'vendor_company_name',
    'vendor_name',
    'country_id',
    'state_id',
    'city_id',
    'address',
    'gst_number',
    'pan_number',
    'pin_code',
    
    'persons',
    'banks',
    'created_by',
    'updated_by',
    'created_at',
    'updated_at',
    'status',
];

protected $casts = [
    'persons' => 'array',
    'banks' => 'array',
];
}
