<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class LanguageSettingModel extends Model
{
    use HasFactory;
    protected $table = 'ryans_languages';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'name',
        'iso_639_1',
        'native_name',
        'script',
        'is_rtl',
        'created_by',
        'updated_by',
        'status',
    ];
}
