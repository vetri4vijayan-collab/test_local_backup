<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

/** Adapter for the existing mobile_user_login_logs audit table. */
class MobileLoginLogModel extends Model
{
    protected $table = 'mobile_user_login_logs';
    protected $primaryKey = 'id';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;

    protected $guarded = ['id'];
}
