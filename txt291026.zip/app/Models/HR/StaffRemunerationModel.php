<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class StaffRemunerationModel extends Model
{
    protected $table = 'ryans_staff_remuneration';
    protected $primaryKey = 'sno';
    protected $guarded = ['sno'];
    public $timestamps = true;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $casts = ['amount' => 'decimal:2', 'status' => 'integer'];
}
