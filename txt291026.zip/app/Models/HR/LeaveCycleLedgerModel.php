<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

/** Append-only audit record for leave balance, approval, rollover and attendance changes. */
class LeaveCycleLedgerModel extends Model
{
    protected $table = 'ryans_leave_cycle_ledger';
    protected $primaryKey = 'sno';
    protected $guarded = ['sno'];
    public $timestamps = false;
}
