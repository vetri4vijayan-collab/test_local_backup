<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class StaffRemunerationHistoryModel extends Model
{
    protected $table = 'ryans_staff_remuneration_history';
    protected $primaryKey = 'sno';
    protected $guarded = ['sno'];
    public $timestamps = true;
    protected $casts = ['previous_json' => 'array', 'current_json' => 'array'];
}
