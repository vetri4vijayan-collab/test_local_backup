<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContractorModel extends Model
{
    use HasFactory;
    public $table = "ryans_contractors";
    public $primaryKey = 'sno';

    protected $fillable = [
    'contractor_code',
    'contractor_type_id',
    'contract_company_name',
    'contract_name',
    'country_id',
    'state_id',
    'city_id',
    'address',
    'gst_number',
    'pan_number',
    'pin_code',
    'aadhar_no',
    'esi_no',
    'epf_no',
    'persons',
    'banks',
    'created_by',
    'updated_by',
    'created_at',
    'updated_at',
    'status',
];

protected $casts = [
    'persons' => 'array',
    'banks' => 'array',
];
}
