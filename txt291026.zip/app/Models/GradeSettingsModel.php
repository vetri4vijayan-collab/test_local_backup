<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GradeSettingsModel extends Model
{
    use HasFactory;
    public $table = "ryans_grade";
    public $primaryKey = 'sno';

    protected $fillable = [
        'grade_name',
        'grade_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',   
        'status',
    ];
}
