<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class DocumentTypeModel extends Model
{
    use HasFactory;
    protected $table = 'ryans_documents';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'document_name',
        'description',
        'created_by',
        'updated_by',
        'status',
    ];
}
