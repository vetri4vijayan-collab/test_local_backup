<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class ProbationSettingModel extends Model
{
    use HasFactory;
    protected $table = 'rayans_probation_period';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'days',
        'description',
        'created_by',
        'updated_by',
        'status',
    ];
}
