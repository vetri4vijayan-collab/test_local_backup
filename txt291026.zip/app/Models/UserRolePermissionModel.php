<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Role permission document stored as JSON in ryans_user_role_permission.
 */
class UserRolePermissionModel extends Model
{
    use HasFactory;

    protected $table = 'ryans_user_role_permission';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'branch_id',
        'role_id',
        'permissions',
        'manage_branch',
        'access_head',
        'created_by',
        'updated_by',
        'status',
    ];

    protected $casts = [
        'sno' => 'integer',
        'branch_id' => 'integer',
        'role_id' => 'integer',
        'manage_branch' => 'integer',
        'access_head' => 'integer',
        'created_by' => 'integer',
        'updated_by' => 'integer',
        'status' => 'integer',
    ];

    /** Return permissions as an array whether the database value is JSON or an array. */
    public function decodedPermissions(): array
    {
        $value = $this->getRawOriginal('permissions');

        if (is_array($value)) {
            return $value;
        }

        if (!is_string($value) || trim($value) === '') {
            return [];
        }

        $decoded = json_decode($value, true);
        if (is_string($decoded)) {
            $decoded = json_decode($decoded, true);
        }

        return is_array($decoded) ? $decoded : [];
    }

    /** Keep compatibility with existing helper calls in the old MVC code. */
    public function getPermissionsByRole($roleId): array
    {
        $record = static::query()
            ->where('role_id', $roleId)
            ->where('status', '!=', 2)
            ->first();

        return $record ? $record->decodedPermissions() : [];
    }
}
