<?php

namespace App\Http\Controllers\attendance_log;

use App\Http\Controllers\Controller;
use App\Services\HR\AttendanceService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AttendanceDirectoryController extends Controller
{
    public function __construct(private AttendanceService $attendanceService) {}

    public function index(Request $request, string $type)
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:120'],
            'month' => ['nullable', 'date_format:Y-m'],
            'date' => ['nullable', 'date_format:Y-m-d'],
            'department' => ['nullable', 'string', 'max:100'],
            'sort' => ['nullable', Rule::in(['date', 'staff', 'department', 'status', 'in_time', 'out_time'])],
            'direction' => ['nullable', Rule::in(['asc', 'desc'])],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        $filters['date'] = $filters['date'] ?? now()->toDateString();
        $p = $this->attendanceService->paginate($type, array_merge(['per_page' => 10], $filters));
        return response()->json([
            'success' => true,
            'data' => $p->items(),
            'meta' => ['current_page' => $p->currentPage(), 'last_page' => $p->lastPage(), 'per_page' => $p->perPage(), 'total' => $p->total()],
            'summary' => $this->attendanceService->dailySummary($type, $filters['date']),
        ]);
    }

    public function matrix(Request $request, string $type)
    {
        $this->attendanceService; // Resolve service via constructor; category is checked in StaffService scope.
        $filters = $request->validate([
            'month' => ['nullable', 'date_format:Y-m'],
            'search' => ['nullable', 'string', 'max:120'],
            'department_id' => ['nullable', 'integer', 'min:1'],
            'department' => ['nullable', 'string', 'max:100'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        return response()->json(['success' => true] + $this->attendanceService->matrix($type, array_merge(['per_page' => 50], $filters)));
    }

    public function save(Request $request, string $type)
    {
        $data = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'], 'date' => ['required', 'date'],
            'attendance' => ['required', Rule::in(['P', 'L', 'A', 'PR', 'OD', 'H'])], 'in_time' => ['nullable', 'date_format:H:i'],
            'out_time' => ['nullable', 'date_format:H:i', 'after_or_equal:in_time'], 'type' => ['nullable', 'string', 'max:80'], 'reason' => ['nullable', 'string', 'max:1000'],
        ]);
        $this->attendanceService->saveManual($type, $data, $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Attendance saved.']);
    }

    private function actor(Request $request): int { return (int) (($request->user()->user_id ?? 0) ?: ($request->user()->id ?? session('user_id', 1))); }
}
