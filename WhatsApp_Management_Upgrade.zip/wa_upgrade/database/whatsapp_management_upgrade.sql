-- WhatsApp management upgrade for the Laravel ERP (MySQL 5.7+/8.0).
-- Additive only: existing za_whatsapp_api_configure / za_whatsapp_template / za_wb_* tables are not altered.
-- Take a production DB backup and apply once during a maintenance window. Test on a staging clone first.

CREATE TABLE IF NOT EXISTS `za_whatsapp_automation_settings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT UNSIGNED NOT NULL,
  `provider` VARCHAR(40) NOT NULL DEFAULT 'meta_cloud_api',
  `waba_id` VARCHAR(64) NULL,
  `phone_number_id` VARCHAR(64) NULL,
  `graph_api_version` VARCHAR(16) NOT NULL DEFAULT 'v26.0',
  `access_token_encrypted` LONGTEXT NULL,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `kill_switch` TINYINT(1) NOT NULL DEFAULT 0,
  `min_send_interval_seconds` SMALLINT UNSIGNED NOT NULL DEFAULT 10,
  `next_send_at` DATETIME NULL,
  `last_tested_at` DATETIME NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_settings_branch` (`branch_id`),
  UNIQUE KEY `uq_wa_settings_phone_id` (`phone_number_id`),
  KEY `idx_wa_settings_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Branch 0 is the global kill-switch row; no token/phone fields are used for this row.
INSERT INTO `za_whatsapp_automation_settings`
  (`branch_id`, `provider`, `is_enabled`, `kill_switch`, `min_send_interval_seconds`, `created_at`, `updated_at`)
SELECT 0, 'system', 0, 0, 10, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM `za_whatsapp_automation_settings` WHERE `branch_id` = 0);

CREATE TABLE IF NOT EXISTS `za_whatsapp_template_registry` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT UNSIGNED NOT NULL,
  `waba_id` VARCHAR(64) NOT NULL,
  `meta_template_id` VARCHAR(64) NULL,
  `template_key` CHAR(40) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `language` VARCHAR(20) NOT NULL,
  `category` VARCHAR(40) NOT NULL DEFAULT 'UNKNOWN',
  `approval_status` VARCHAR(40) NOT NULL DEFAULT 'UNKNOWN',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `components_json` LONGTEXT NULL,
  `raw_json` LONGTEXT NULL,
  `last_synced_at` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_template_branch_waba_key` (`branch_id`, `waba_id`, `template_key`),
  KEY `idx_wa_template_branch_status` (`branch_id`, `approval_status`, `is_enabled`),
  KEY `idx_wa_template_name_lang` (`name`, `language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_workflow_rules` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT UNSIGNED NOT NULL,
  `event_key` VARCHAR(100) NOT NULL,
  `template_name` VARCHAR(191) NOT NULL,
  `language` VARCHAR(20) NOT NULL DEFAULT 'en_US',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `notes` VARCHAR(500) NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_workflow_branch_event` (`branch_id`, `event_key`),
  KEY `idx_wa_workflow_branch_enabled` (`branch_id`, `is_enabled`),
  KEY `idx_wa_workflow_template` (`template_name`, `language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_consents` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT UNSIGNED NOT NULL,
  `phone_e164` VARCHAR(16) NOT NULL,
  `category` VARCHAR(24) NOT NULL DEFAULT 'all',
  `consent_status` VARCHAR(16) NOT NULL DEFAULT 'opted_out',
  `source` VARCHAR(100) NOT NULL,
  `evidence_ref` VARCHAR(1000) NOT NULL,
  `opted_in_at` DATETIME NULL,
  `opted_out_at` DATETIME NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_consent_phone_category` (`branch_id`, `phone_e164`, `category`),
  KEY `idx_wa_consent_status` (`branch_id`, `consent_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_sessions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT UNSIGNED NOT NULL,
  `phone_e164` VARCHAR(16) NOT NULL,
  `last_inbound_at` DATETIME NULL,
  `last_inbound_meta_message_id` VARCHAR(191) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_session_branch_phone` (`branch_id`, `phone_e164`),
  KEY `idx_wa_session_last_inbound` (`last_inbound_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_outbox` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT UNSIGNED NOT NULL,
  `phone_e164` VARCHAR(16) NOT NULL,
  `message_type` VARCHAR(16) NOT NULL,
  `template_name` VARCHAR(191) NULL,
  `language` VARCHAR(20) NULL,
  `template_category` VARCHAR(24) NULL,
  `components_json` LONGTEXT NULL,
  `text_body` TEXT NULL,
  `source_type` VARCHAR(80) NOT NULL DEFAULT 'unknown',
  `workflow_event_key` VARCHAR(100) NULL,
  `source_id` BIGINT NULL,
  `created_by` BIGINT NULL,
  `idempotency_key` VARCHAR(191) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'queued',
  `scheduled_at` DATETIME NULL,
  `meta_message_id` VARCHAR(191) NULL,
  `attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `request_json` LONGTEXT NULL,
  `response_json` LONGTEXT NULL,
  `error_code` VARCHAR(100) NULL,
  `error_message` VARCHAR(2000) NULL,
  `sent_at` DATETIME NULL,
  `delivered_at` DATETIME NULL,
  `read_at` DATETIME NULL,
  `failed_at` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_outbox_idempotency` (`idempotency_key`),
  KEY `idx_wa_outbox_branch_status_date` (`branch_id`, `status`, `created_at`),
  KEY `idx_wa_outbox_meta_id` (`meta_message_id`),
  KEY `idx_wa_outbox_phone_date` (`phone_e164`, `created_at`),
  KEY `idx_wa_outbox_scheduled` (`status`, `scheduled_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_audiences` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT UNSIGNED NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `description` VARCHAR(500) NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_audience_branch_name` (`branch_id`, `name`),
  KEY `idx_wa_audience_active` (`branch_id`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_audience_members` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `audience_id` BIGINT UNSIGNED NOT NULL,
  `branch_id` BIGINT UNSIGNED NOT NULL,
  `phone_e164` VARCHAR(16) NOT NULL,
  `created_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_audience_member_phone` (`audience_id`, `phone_e164`),
  KEY `idx_wa_audience_member_branch` (`branch_id`, `audience_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
