<?php

use App\Http\Controllers\WhatsAppManagementController;
use Illuminate\Support\Facades\Route;

// Merge these routes into the existing authenticated web route group in routes/web.php.
// The controller also enforces WHATSAPP_ADMIN_USER_IDS and fails closed when it is empty.
Route::prefix('wa-management')->name('wa-management.')->group(function () {
    Route::get('/', [WhatsAppManagementController::class, 'index'])->name('index');
    Route::get('/overview', [WhatsAppManagementController::class, 'overview'])->name('overview');
    Route::get('/configs', [WhatsAppManagementController::class, 'configs'])->name('configs');
    Route::post('/config', [WhatsAppManagementController::class, 'saveConfig'])->name('config.save');
    Route::post('/config/test', [WhatsAppManagementController::class, 'testConfig'])->name('config.test');
    Route::post('/config/{branchId}/toggle', [WhatsAppManagementController::class, 'toggleConfig'])->name('config.toggle');
    Route::post('/kill-switch', [WhatsAppManagementController::class, 'killSwitch'])->name('kill-switch');
    Route::get('/templates', [WhatsAppManagementController::class, 'templates'])->name('templates');
    Route::post('/templates/sync', [WhatsAppManagementController::class, 'syncTemplates'])->name('templates.sync');
    Route::post('/templates/{id}/toggle', [WhatsAppManagementController::class, 'toggleTemplate'])->name('templates.toggle');
    Route::get('/workflows', [WhatsAppManagementController::class, 'workflowRules'])->name('workflows');
    Route::post('/workflows', [WhatsAppManagementController::class, 'saveWorkflowRule'])->name('workflows.save');
    Route::post('/workflows/{id}/toggle', [WhatsAppManagementController::class, 'toggleWorkflowRule'])->name('workflows.toggle');
    Route::get('/outbox', [WhatsAppManagementController::class, 'outbox'])->name('outbox');
    Route::post('/send/template', [WhatsAppManagementController::class, 'sendTemplate'])->name('send.template');
    Route::post('/send/text', [WhatsAppManagementController::class, 'sendText'])->name('send.text');
    Route::post('/send/bulk', [WhatsAppManagementController::class, 'bulkSend'])->name('send.bulk');
    Route::get('/conversations', [WhatsAppManagementController::class, 'conversations'])->name('conversations');
    Route::get('/conversations/{phone}/messages', [WhatsAppManagementController::class, 'conversationMessages'])->name('conversation.messages');
    Route::post('/consent', [WhatsAppManagementController::class, 'recordConsent'])->name('consent');
    Route::get('/audiences', [WhatsAppManagementController::class, 'audiences'])->name('audiences');
    Route::post('/audiences', [WhatsAppManagementController::class, 'createAudience'])->name('audiences.create');
    Route::post('/audiences/{id}/members', [WhatsAppManagementController::class, 'addAudienceMembers'])->name('audiences.members');
    Route::get('/audiences/{id}/recipients', [WhatsAppManagementController::class, 'bulkFromAudience'])->name('audiences.recipients');
});
