<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WhatsappContactModel;
use App\Models\WhatsappMessageModel;
use App\Models\WhatsappTemplateLogModel;
use App\Events\NewMessage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http; // Import Http facade
use Carbon\Carbon;

class WhatsAppConfig extends Controller
{
   
public function receiveWhatsAppMessageold(Request $request)
{
    // Raw webhook bodies may contain personal data; do not log them.
    // Handle verification challenge
    if ($request->method() === 'GET') {
        $mode = $request->query('hub_mode');
        $token = $request->query('hub_verify_token');
        $challenge = $request->query('hub_challenge');

        if ($mode === 'subscribe' && (string) config('whatsapp.verify_token') !== '' && hash_equals((string) config('whatsapp.verify_token'), (string) $token)) {
            return response($challenge, 200); // Return hub.challenge
        }
        return response()->json(['error' => 'Verification failed'], 403);
    }

    // Process message data
    $entry = $request->json('entry');
    if (empty($entry)) {
        return response()->json(['message' => 'Invalid data format'], 400);
    }

    $messageData = $entry[0]['changes'][0]['value']['messages'][0] ?? null;
    $contactData = $entry[0]['changes'][0]['value']['contacts'][0] ?? null;

    if (!$messageData || !$contactData) {
        return response()->json(['message' => 'No message received'], 400);
    }

    $phone = $contactData['wa_id'];
    $messageText = $messageData['text']['body'] ?? null;
    $messageType = $messageData['type'] ?? 'text';
    $messageTimestamp = $messageData['timestamp'] ?? null;
    
    if (!$messageTimestamp) {
        return response()->json(['message' => 'Missing message timestamp'], 400);
    }
    $messageDateTime = Carbon::createFromTimestamp((int) $messageTimestamp, config('app.timezone', 'UTC'))->toDateTimeString();
    
    // Log::info("Message received from {$phone}: {$messageText}");

    // Save to database
   $contact = WhatsappContactModel::where('phone', $phone)->first();

    if ($contact) {
        $contact->increment('msg_count');
    } else {
        $contact = WhatsappContactModel::create([
            'phone' => $phone,
            'msg_count' => 1, 
        ]);
    }

    $message = WhatsappMessageModel::create([
        'contact_id' => $contact->sno,
        'message' => $messageText,
        'type' => $messageType,
        'from' => 0,
    ]);

    // Broadcast event with proper formatting
    event(new NewMessage($message, $entry));

    return response()->json(['success' => true]);
}


public function receiveWhatsAppMessage14(Request $request)
{
    // Raw webhook bodies may contain personal data; do not log them.
    
        $accessToken = app(\App\Services\WhatsAppManagerService::class)->getAccessTokenForPhoneNumber($request->input('entry.0.changes.0.value.metadata.phone_number_id'));
    
      // Handle verification challenge
        if ($request->method() === 'GET') {
            $mode = $request->query('hub_mode');
            $token = $request->query('hub_verify_token');
            $challenge = $request->query('hub_challenge');
    
            if ($mode === 'subscribe' && (string) config('whatsapp.verify_token') !== '' && hash_equals((string) config('whatsapp.verify_token'), (string) $token)) {
                return response($challenge, 200); // Return hub.challenge
            }
            return response()->json(['error' => 'Verification failed'], 403);
        }
    
    

    $entry = $request->json('entry');
    if (empty($entry)) {
        return response()->json(['message' => 'Invalid data format'], 400);
    }

    $changes = $entry[0]['changes'][0]['value'] ?? null;
    if (!$changes) {
        return response()->json(['message' => 'No changes found'], 400);
    }

    // Handle message statuses
    if (isset($changes['statuses'])) {
        foreach ($changes['statuses'] as $status) {
            $messageId = $status['id'] ?? null;
            $statusType = $status['status'] ?? null;

            if ($messageId && $statusType) {
                app(\App\Services\WhatsAppManagerService::class)->updateOutboxStatus($messageId, $statusType, $status['errors'][0] ?? null);
                WhatsappMessageModel::where('wama_id', $messageId)->update(['message_status' => $statusType]);
                Log::info("Message status updated: ID {$messageId} -> {$statusType}");
                
            }
        }
        return response()->json(['success' => true]);
    }

    // Handle received messages (including from Meta Dashboard)
    $messageData = $changes['messages'][0] ?? null;
    $contactData = $changes['contacts'][0] ?? null;

    if (!$messageData || !$contactData) {
        return response()->json(['message' => 'No message received'], 400);
    }

    $phone = $contactData['wa_id'];
    $messageType = $messageData['type'] ?? 'text';
    $messageId = $messageData['id'] ?? null;
    $messageStatus = $messageData['status'] ?? 'sent';
    $messageText = $messageType === 'text' ? ($messageData['text']['body'] ?? null) : null;

    $messageTimestamp = $messageData['timestamp'] ?? null;

    if (!$messageTimestamp) {
        return response()->json(['message' => 'Missing message timestamp'], 400);
    }
    $messageDateTime = Carbon::createFromTimestamp((int) $messageTimestamp, config('app.timezone', 'UTC'))->toDateTimeString();

    // Save to database
    $contact = WhatsappContactModel::where('phone', $phone)->first();

    if ($contact) {
        $contact->increment('msg_count');
    } else {
        $contact = WhatsappContactModel::create([
            'phone' => $phone,
            'msg_count' => 1,
        ]);
    }

    // Prepare data for saving the message
    $messageDataToSave = [
        'contact_id' => $contact->sno,
        'message' => $messageText,
        'type' => $messageType,
        'from' => 0,
        'wama_id' => $messageId,
        'message_status' => $messageStatus,
    ];
     // Deliberately do not log message payloads or recipient content.
        // Handling media files (images, videos, documents, etc.)
        if (in_array($messageType, ['image', 'video', 'document', 'audio', 'sticker'])) {
            $mediaId = $messageData[$messageType]['id'] ?? null;
        
            if ($mediaId && $accessToken) {
                // Get media URL
                $mediaUrlResponse = Http::withHeaders([
                    'Authorization' => "Bearer $accessToken"
                ])->get("https://graph.facebook.com/" . ltrim(config('whatsapp.api_version', 'v26.0'), '/') . "/{$mediaId}");
        
                $mediaUrl = $mediaUrlResponse->json()['url'] ?? null;
        
                if ($mediaUrl) {
                    // Get media file content
                    $mediaContentResponse = Http::withHeaders([
                        'Authorization' => "Bearer $accessToken"
                    ])->get($mediaUrl);
        
                    if ($mediaContentResponse->successful()) {
                        $mimeType = $mediaContentResponse->header('Content-Type');
                        $extension = $this->getMediaExtension($mimeType);
                        $mediaFolder = $this->getMediaFolder($messageType);
        
                        // Ensure directory exists
                        $filePath = public_path("whatsapp/{$mediaFolder}");
                        if (!file_exists($filePath)) {
                            mkdir($filePath, 0777, true);
                        }
        
                        // Generate unique filename based on extension
                        $fileName = uniqid() . '.' . $extension;
                        file_put_contents("$filePath/$fileName", $mediaContentResponse->body());
        
                        // Store media details in message data
                        $messageDataToSave['media_url'] = "whatsapp/{$mediaFolder}/{$fileName}";
                        $messageDataToSave['media_type'] = $messageType;
                        $messageDataToSave['mime_type'] = $mimeType;
        
                        // Store caption or filename for documents
                        if ($messageType === 'document') {
                            $messageDataToSave['media_caption'] = $messageData[$messageType]['filename'] ?? null;
                            $messageDataToSave['message'] = $messageData[$messageType]['caption'] ?? null;
                        } else {
                            $messageDataToSave['media_caption'] = $messageData[$messageType]['caption'] ?? null;
                        }
                    }
                }
            }
        }
        if ($messageData['type'] === 'reaction') {
            $reactionMessageId = $messageData['reaction']['message_id'];
            $reactionEmoji = $messageData['reaction']['emoji'];
            $originalMessage = WhatsappMessageModel::where('wama_id', $reactionMessageId)->first();
             if ($originalMessage) {
                  $originalMessage->update([
                        'reaction_emoji' => $reactionEmoji,
                        'reaction_status' => 1,
                  ]);
                Log::info("Updated reaction for message ID {$reactionMessageId}: {$reactionEmoji}");
             }else {
                $reactionMessageData = [
                    'contact_id' => $contact->sno,
                    'message' => $reactionEmoji,
                    'type' => 'reaction',
                    'from' => 0,
                    'wama_id' => $messageId,
                    'message_status' => 'sent',
                    'reaction_emoji' => $reactionEmoji,
                ];
    
                // Save reaction message in the database
                WhatsappMessageModel::create($reactionMessageData);
                // Log::info("Inserted new reaction for message ID {$reactionMessageId}: {$reactionEmoji}");
            }
        }else {
             $message = WhatsappMessageModel::create($messageDataToSave);
             event(new NewMessage($message, $entry));
        }

    return response()->json(['success' => true]);
}


public function receiveWhatsAppMessage(Request $request)
{
    $accessToken = app(\App\Services\WhatsAppManagerService::class)->getAccessTokenForPhoneNumber($request->input('entry.0.changes.0.value.metadata.phone_number_id'));
    // Use Laravel's configured timezone; do not mutate the PHP process-wide timezone.
    
    

    // Handle verification challenge
    if ($request->method() === 'GET') {
        $mode = $request->query('hub_mode');
        $token = $request->query('hub_verify_token');
        $challenge = $request->query('hub_challenge');
        
        

        if ($mode === 'subscribe' && (string) config('whatsapp.verify_token') !== '' && hash_equals((string) config('whatsapp.verify_token'), (string) $token)) {
            return response($challenge, 200)->header('Content-Type', 'text/plain');
        }
        Log::warning('Meta WhatsApp webhook verification rejected.');
        return response()->json(['error' => 'Verification failed'], 403);
    }

    $appSecret = (string) config('whatsapp.app_secret', '');
    if ($request->isMethod('POST')) {
        if ($appSecret === '') {
            Log::critical('META_APP_SECRET is missing; refusing unsigned WhatsApp webhook POSTs.');
            return response()->json(['error' => 'Webhook signature validation is not configured'], 503);
        }
        $signature = (string) $request->header('X-Hub-Signature-256', '');
        $expectedSignature = 'sha256=' . hash_hmac('sha256', $request->getContent(), $appSecret);
        if ($signature === '' || !hash_equals($expectedSignature, $signature)) {
            Log::warning('Meta WhatsApp webhook signature rejected.');
            return response()->json(['error' => 'Invalid signature'], 401);
        }
    }
    Log::info('Meta WhatsApp webhook received.', ['method' => $request->method()]);


    $entry = $request->json('entry');
    if (empty($entry)) {
        return response()->json(['message' => 'Invalid data format'], 400);
    }

    $changes = $entry[0]['changes'][0]['value'] ?? null;
    if (!$changes) {
        return response()->json(['message' => 'No changes found'], 400);
    }

    // Handle message statuses
    if (isset($changes['statuses'])) {
        foreach ($changes['statuses'] as $status) {
            $messageId = $status['id'] ?? null;
            $statusType = $status['status'] ?? null;

            if ($messageId && $statusType) {
                app(\App\Services\WhatsAppManagerService::class)->updateOutboxStatus($messageId, $statusType, $status['errors'][0] ?? null);
                WhatsappMessageModel::where('wama_id', $messageId)->update(['message_status' => $statusType]);
                
                if($statusType == 'delivered'){
                    WhatsappTemplateLogModel::where('wama_id', $messageId)->update([
                        'message_status' => $statusType,
                        'delivered_date_time' =>  Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                        ]);
                }elseif($statusType == 'read'){
                    WhatsappTemplateLogModel::where('wama_id', $messageId)->update([
                        'message_status' => $statusType,
                        'read_date_time' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                        ]);
                }elseif($statusType == 'failed'){
                     $errorCode = null;
                            $errorTitle = null;
                            $errorMessage = null;
                            $errorDetails = null;
                             $errorData = null;
 
                            if (!empty($status['errors'][0])) {
                                $errorCode = $status['errors'][0]['code'] ?? null;
                                $errorTitle = $status['errors'][0]['title'] ?? null;
                                $errorMessage = $status['errors'][0]['message'] ?? null;
                                $errorDetails = $status['errors'][0]['error_data']['details'] ?? null;
                                 $errorData = $status['errors'][0] ?? null;
                            }
 
                            Log::info("WhatsApp message failed", [
                                'wama_id' => $messageId,
                                'code' => $errorCode,
                                'title' => $errorTitle,
                                'message' => $errorMessage,
                                'details' => $errorDetails,
                            ]);
                    
                    WhatsappTemplateLogModel::where('wama_id', $messageId)->update([
                        'message_status' => $statusType,
                        'failed_date_time' =>  Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                         'failed_data' => $errorData ? json_encode($errorData) : null,
                        ]);
                       
                            
                }
                
                Log::info("Message status updated: ID {$messageId} -> {$statusType}");
            }
        }
        return response()->json(['success' => true]);
    }

    $messageData = $changes['messages'][0] ?? null;
    $contactData = $changes['contacts'][0] ?? null;

    if (!$messageData || !$contactData) {
        return response()->json(['message' => 'No message received'], 400);
    }

    $phone = $contactData['wa_id'];
    $messageType = $messageData['type'] ?? 'text';
    $messageId = $messageData['id'] ?? null;
    $messageStatus = $messageData['status'] ?? 'sent';
    $messageTimestamp = $messageData['timestamp'] ?? null;
    $messageText = $messageType === 'text' ? ($messageData['text']['body'] ?? null) : null;
     Log::info("Message status updated Template data: ID {$messageId} -> {$messageType}");

    if (!$messageTimestamp || !$messageId) {
        return response()->json(['message' => 'Missing timestamp or ID'], 400);
    }

    app(\App\Services\WhatsAppManagerService::class)->recordInboundSession(
        (string) $phone,
        (string) $messageTimestamp,
        $changes['metadata']['phone_number_id'] ?? null,
        is_string($messageText) ? $messageText : null,
        (string) $messageId
    );

    $messageDateTime = Carbon::createFromTimestamp((int) $messageTimestamp, config('app.timezone', 'UTC'))->toDateTimeString();

    // Check for duplicate message using wama_id
    $existing = WhatsappMessageModel::where('wama_id', $messageId)->where('type', $messageType)->first();
    if ($existing) {
        Log::info("Duplicate message skipped for wama_id: {$messageId}");
        return response()->json(['message' => 'Duplicate message skipped'], 200);
    }

    // Contact handling
    $contact = WhatsappContactModel::firstOrCreate(
        ['phone' => $phone],
        ['msg_count' => 0]
    );
    $contact->increment('msg_count');

    // REACTION TYPE HANDLING
    if ($messageType === 'reaction') {
        $reactionMessageId = $messageData['reaction']['message_id'] ?? null;
        $reactionEmoji = $messageData['reaction']['emoji'] ?? null;

        if ($reactionMessageId && $reactionEmoji) {
            $originalMessage = WhatsappMessageModel::where('wama_id', $reactionMessageId)->first();
            
          $originalTemplateMessage = WhatsappTemplateLogModel::where('wama_id', $reactionMessageId)->first();


            if ($originalMessage) {
                $originalMessage->update([
                    'reaction_emoji' => $reactionEmoji,
                    'reaction_status' => 1,
                ]);
                Log::info("Updated reaction for message ID {$reactionMessageId}: {$reactionEmoji}");
            } else {
                // Save reaction as a new entry (only if not already saved)
                WhatsappMessageModel::create([
                    'contact_id' => $contact->sno,
                    'message' => $reactionEmoji,
                    'type' => 'reaction',
                    'from' => 0,
                    'wama_id' => $messageId,
                    'message_status' => 'sent',
                    'reaction_emoji' => $reactionEmoji,
                ]);
                Log::info("New reaction saved for unknown original message: {$reactionEmoji}");
                Log::info("Updated reaction for message ID {$reactionMessageId}: {$reactionEmoji}");
            }
            
            if ($originalTemplateMessage) {
                $originalTemplateMessage->update([
                    'reaction_emoji' => $reactionEmoji,
                    'reaction_status' => 1,
                    'reaction_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                ]);
                Log::info("Updated Template reaction for message ID {$reactionMessageId}: {$reactionEmoji}");
            } 
        }
            
        return response()->json(['success' => true]);
    }

    // Prepare data for saving the message
    $messageDataToSave = [
        'contact_id' => $contact->sno,
        'message' => $messageText,
        'type' => $messageType,
        'from' => 0,
        'wama_id' => $messageId,
        'message_status' => $messageStatus,
    ];

    // Handle media messages
    if (in_array($messageType, ['image', 'video', 'document', 'audio', 'sticker'])) {
        $mediaId = $messageData[$messageType]['id'] ?? null;

        if ($mediaId && $accessToken) {
            $mediaUrlResponse = Http::withHeaders([
                'Authorization' => "Bearer $accessToken"
            ])->get("https://graph.facebook.com/" . ltrim(config('whatsapp.api_version', 'v26.0'), '/') . "/{$mediaId}");

            $mediaUrl = $mediaUrlResponse->json()['url'] ?? null;

            if ($mediaUrl) {
                $mediaContentResponse = Http::withHeaders([
                    'Authorization' => "Bearer $accessToken"
                ])->get($mediaUrl);

                if ($mediaContentResponse->successful()) {
                    $mimeType = $mediaContentResponse->header('Content-Type');
                    $extension = $this->getMediaExtension($mimeType);
                    $mediaFolder = $this->getMediaFolder($messageType);
                    $filePath = public_path("whatsapp/{$mediaFolder}");

                    if (!file_exists($filePath)) {
                        mkdir($filePath, 0777, true);
                    }

                    $fileName = uniqid() . '.' . $extension;
                    file_put_contents("$filePath/$fileName", $mediaContentResponse->body());

                    $messageDataToSave['media_url'] = "whatsapp/{$mediaFolder}/{$fileName}";
                    $messageDataToSave['media_type'] = $messageType;
                    $messageDataToSave['mime_type'] = $mimeType;

                    if ($messageType === 'document') {
                        $messageDataToSave['media_caption'] = $messageData[$messageType]['filename'] ?? null;
                        $messageDataToSave['message'] = $messageData[$messageType]['caption'] ?? null;
                    } else {
                        $messageDataToSave['media_caption'] = $messageData[$messageType]['caption'] ?? null;
                    }
                }
            }
        }
    }

    // Save message and dispatch event
    $message = WhatsappMessageModel::create($messageDataToSave);
    event(new NewMessage($message, $entry));

    return response()->json(['success' => true]);
}




public function handleWebhookold(Request $request)
{
    // Raw webhook bodies may contain personal data; do not log them.
    
        $accessToken = app(\App\Services\WhatsAppManagerService::class)->getAccessTokenForPhoneNumber($request->input('entry.0.changes.0.value.metadata.phone_number_id'));
    
 // Handle verification challenge
    if ($request->isMethod('get')) {
        $mode = $request->query('hub_mode');
        $verifyToken = $request->query('hub_verify_token');
        $challenge = $request->query('hub_challenge');

        if ($mode === 'subscribe' && (string) config('whatsapp.verify_token') !== '' && hash_equals((string) config('whatsapp.verify_token'), (string) $verifyToken)) {
            return response($challenge);
        }

        return response()->json(['error' => 'Invalid token'], 403);
    }
    


    $entry = $request->json('entry');
    if (empty($entry)) {
        return response()->json(['message' => 'Invalid data format'], 400);
    }

    $changes = $entry[0]['changes'][0]['value'] ?? null;
    if (!$changes) {
        return response()->json(['message' => 'No changes found'], 400);
    }

    // Handle message statuses
    if (isset($changes['statuses'])) {
        foreach ($changes['statuses'] as $status) {
            $messageId = $status['id'] ?? null;
            $statusType = $status['status'] ?? null;

            if ($messageId && $statusType) {
                WhatsappMessageModel::where('wama_id', $messageId)->update(['message_status' => $statusType]);
                // Log::info("Message status updated: ID {$messageId} -> {$statusType}");
            }
        }
        return response()->json(['success' => true]);
    }

    // Handle received messages (including from Meta Dashboard)
    $messageData = $changes['messages'][0] ?? null;
    $contactData = $changes['contacts'][0] ?? null;

    if (!$messageData || !$contactData) {
        return response()->json(['message' => 'No message received'], 400);
    }

    $phone = $contactData['wa_id'];
    $messageType = $messageData['type'] ?? 'text';
    $messageId = $messageData['id'] ?? null;
    $messageStatus = $messageData['status'] ?? 'sent';
    $messageText = $messageType === 'text' ? ($messageData['text']['body'] ?? null) : null;

    $messageTimestamp = $messageData['timestamp'] ?? null;

    if (!$messageTimestamp) {
        return response()->json(['message' => 'Missing message timestamp'], 400);
    }
    $messageDateTime = Carbon::createFromTimestamp((int) $messageTimestamp, config('app.timezone', 'UTC'))->toDateTimeString();

    // Save to database
    $contact = WhatsappContactModel::where('phone', $phone)->first();

    if ($contact) {
        $contact->increment('msg_count');
    } else {
        $contact = WhatsappContactModel::create([
            'phone' => $phone,
            'msg_count' => 1,
        ]);
    }

    // Prepare data for saving the message
    $messageDataToSave = [
        'contact_id' => $contact->sno,
        'message' => $messageText,
        'type' => $messageType,
        'from' => 0,
        'wama_id' => $messageId,
        'message_status' => $messageStatus,
    ];
     // Deliberately do not log message payloads or recipient content.
        // Handling media files (images, videos, documents, etc.)
       if (in_array($messageType, ['image', 'video', 'document', 'audio', 'sticker'])) {
            $mediaId = $messageData[$messageType]['id'] ?? null;
        
            if ($mediaId && $accessToken) {
                // Get media URL
                $mediaUrlResponse = Http::withHeaders([
                    'Authorization' => "Bearer $accessToken"
                ])->get("https://graph.facebook.com/" . ltrim(config('whatsapp.api_version', 'v26.0'), '/') . "/{$mediaId}");
        
                $mediaUrl = $mediaUrlResponse->json()['url'] ?? null;
        
                if ($mediaUrl) {
                    // Get media file content
                    $mediaContentResponse = Http::withHeaders([
                        'Authorization' => "Bearer $accessToken"
                    ])->get($mediaUrl);
        
                    if ($mediaContentResponse->successful()) {
                        $mimeType = $mediaContentResponse->header('Content-Type');
                        $extension = $this->getMediaExtension($mimeType);
                        $mediaFolder = $this->getMediaFolder($messageType);
        
                        // Ensure directory exists
                        $filePath = public_path("whatsapp/{$mediaFolder}");
                        if (!file_exists($filePath)) {
                            mkdir($filePath, 0777, true);
                        }
        
                        // Generate unique filename based on extension
                        $fileName = uniqid() . '.' . $extension;
                        file_put_contents("$filePath/$fileName", $mediaContentResponse->body());
        
                        // Store media details in message data
                        $messageDataToSave['media_url'] = "whatsapp/{$mediaFolder}/{$fileName}";
                        $messageDataToSave['media_type'] = $messageType;
                        $messageDataToSave['mime_type'] = $mimeType;
        
                        // Store caption or filename for documents
                        if ($messageType === 'document') {
                            $messageDataToSave['media_caption'] = $messageData[$messageType]['filename'] ?? null;
                        } else {
                            $messageDataToSave['media_caption'] = $messageData[$messageType]['caption'] ?? null;
                        }
                    }
                }
            }
        }


    // Save message record in the database
    $message = WhatsappMessageModel::create($messageDataToSave);
    event(new NewMessage($message, $entry));

    return response()->json(['success' => true]);
}


  private function getMediaExtension($mimeType)
{
    $mimeMap = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
        'video/mp4' => 'mp4',
        'video/avi' => 'avi',
        'video/3gpp' => '3gp',
        'audio/mpeg' => 'mp3',
        'audio/ogg' => 'ogg',
        'audio/wav' => 'wav',
        'audio/webm' => 'webm',
        'application/pdf' => 'pdf',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'application/vnd.ms-excel' => 'xls',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
        'application/zip' => 'zip',
        'application/x-rar-compressed' => 'rar',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
    ];

    return $mimeMap[$mimeType] ?? 'bin'; // Default to 'bin' if no match
}

    
    /**
     * Get media folder based on type.
     */
    private function getMediaFolder($messageType)
    {
        return match ($messageType) {
            'image' => 'images',
            'video' => 'videos',
            'document' => 'documents',
            'audio' => 'audios',
            'sticker' => 'stickers',
            default => 'other',
        };
    }

}
