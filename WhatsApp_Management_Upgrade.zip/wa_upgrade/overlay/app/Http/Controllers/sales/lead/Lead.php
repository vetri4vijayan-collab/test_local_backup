<?php

namespace App\Http\Controllers\sales\lead;

use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\Communication_config_Model;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\LeadExportModel;
use App\Models\StudentpointsModel;
use App\Models\ContactDetailsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\PotentialReasonModel;
use App\Models\LeadsExport;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\RawLeadModel;
use App\Models\StaffModel;
use App\Models\WhatsappApiConfigureModel;
use App\Services\DoubletickService;
use App\Models\LeadAppointmentModel;
use App\Models\SmsTemplateModel;
use DateTime;
use App\Models\FollowupReasonModel;
use App\Models\LeadExportExcel;
use App\Mail\DynamicTemplateEmail;
use App\Models\PointsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Pagination\CursorPaginator;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use App\Models\SlotModel;
use App\Models\StaffpointsModel;
use App\Models\SpamReasonModel;
use App\Models\DropReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadTransferLogModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use App\Models\WhatsappTemplateLogModel;

class Lead extends Controller
{

  protected $doubletickService;
  protected $client;
  protected $accessToken;
  protected $businessId;
  protected $baseUrl;
  protected $phoneNumberId;

  public function __construct(DoubletickService $doubletickService)
  {
    $this->doubletickService = $doubletickService;
    $whatsappConfig = WhatsappApiConfigureModel::where('sno', 3)->first();
    // Legacy sends still present elsewhere in this controller need a safe null fallback.
    // The new Lead::Add welcome send uses WhatsAppManagerService and encrypted central profiles.
    $this->phoneNumberId = $whatsappConfig->phonenumber_id ?? null;
    $this->accessToken = $whatsappConfig->access_tokken ?? null;
    $this->baseUrl = 'https://graph.facebook.com/' . ltrim(config('whatsapp.api_version', 'v26.0'), '/');
    $this->businessId = $whatsappConfig->waba_id ?? null;
  }

  // ************************************* Lead List Pages **************************
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $startTime = microtime(true);
    // Retrieve leads with joins and filters
    // Retrieve leads with joins and filters
    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.created_at',
      'za_lead.created_by',
      'za_lead.inter_calls',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.dialed_count',
      'za_lead.document_send_count',
      'za_lead.incoming_count',
      'za_lead.outgoing_count',
      'za_lead.missed_reject_count',
      'za_lead.spam_verified',
      'za_lead.drop_verified',
      'za_lead.spam_tl_verified',
      'za_lead.drop_tl_verified',
      'za_lead.sulekha_id',
      'za_lead.phone_verify_status',
      'za_lead.phone_verify_content',

      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.website_id',
      'za_lead.call_tracker_id',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_event_id',
      //   'za_lead_appointment.appointment_status as lead_appointment_status',
      //   'za_lead_appointment.lead_id as appointment_lead_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color',
      'appointment_counts.lead_id as followup_id',
      'latest_appointment.lead_id as latest_lead_id',
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
          SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
          FROM za_appointment
          WHERE (lead_id, appointment_date) IN (
              SELECT lead_id, MAX(appointment_date) AS appointment_date
              FROM za_appointment

              GROUP BY lead_id
          )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
          FROM za_appointment
          GROUP BY lead_id) AS appointment_counts'), 'za_lead.sno', '=', 'appointment_counts.lead_id')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      //   ->leftJoin('za_lead_appointment', 'za_lead.sno', '=', 'za_lead_appointment.lead_id')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->where('za_lead.internal_status', '!=', 1)
      //   ->where('za_lead.created_by', '>', 1)
      ->where('za_lead.branch_id', $branch_id)
      //   ->where('za_lead.sno', 5076)
      ->whereIn('za_lead.status', [0, 1, 4, 5, 7]);

    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.incoming_count',
      'za_lead.dialed_count',
      'za_lead.created_by',
      'za_lead.sulekha_id',
      'za_lead.outgoing_count',
      'za_lead.missed_reject_count',
      'za_lead.spam_verified',
      'za_lead.drop_verified',
      'za_lead.spam_tl_verified',
      'za_lead.drop_tl_verified',
      'za_lead.document_send_count',
      'za_lead.phone_verify_status',
      'za_lead.phone_verify_content',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.website_id',
      'za_lead.call_tracker_id',
      'za_lead.registered_date',
      //   'za_lead_appointment.appointment_status',
      //   'za_lead_appointment.lead_id',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.inter_calls',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.lead_event_id',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'latest_appointment.appointment_date',
      'latest_appointment.total_app_score',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'appointment_counts.lead_id',
      'latest_appointment.lead_id',
      'za_potential_type.emoji_color',
      'appointment_counts.total_appointments'
    );

    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leads = $leads->where('za_lead.created_by', $user_id)->where('za_lead.wallet_status', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.spam_verified', 0);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data

      $leads = $leads;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }


    // Cursor Pagination for optimized results
    $leads = $leads->orderBy('za_lead.registered_date', 'desc')
      ->paginate($perpage);

    foreach ($leads as $singleLead) {
      $normalizedPhoneNo    = ltrim($singleLead->lead_mobile, '0'); // Remove leading zero if present
      $phoneWithCountryCode = '+91' . $normalizedPhoneNo;           // Add the country code
      $lead                 = DB::table('za_contact_book')
        ->where('phone_no', $singleLead->lead_mobile)
        ->orWhere('phone_no', $phoneWithCountryCode) // Check both formats
        ->orderBy('contact_book_id', 'desc')
        ->first();
      $singleLead->staff_id = $lead->staff_id ?? "0";
      $lead                 = DB::table('za_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $leadapp = DB::table('za_lead_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
      $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
      $singleLead->appointment_status = $lead->status ?? "0";
      $chk1day         = false;
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      if ($createdAt->diffInHours($currentDateTime) >= 24) {
        $chk1day = true;
      } else {
        $chk1day = false;
      }
      $alert_status = 0;
      if ($chk1day) {
        if ($singleLead->followup_latest_id) {
          $alert_status = 0;
        } else if ($singleLead->followup_id) {
          $alert_status = 0;
        } else {
          $alert_status = 1;
        }
      }

      $singleLead->alert_status = $alert_status;
      $registeredDate = Carbon::parse($singleLead->registered_date);
      $diff = $registeredDate->diff(Carbon::now());

      $years = $diff->y;
      $months = $diff->m;
      $days = $diff->d;

      // Build the formatted difference string
      $parts = [];

      if ($years > 0) {
        $parts[] = "{$years} year" . ($years > 1 ? 's' : '');
      }
      if ($months > 0) {
        $parts[] = "{$months} month" . ($months > 1 ? 's' : '');
      }
      if ($days > 0 || empty($parts)) {
        // If all other parts are zero, still show "0 days"
        $parts[] = "{$days} day" . ($days > 1 ? 's' : '');
      }

      $singleLead->formattedDifference = implode(' and ', $parts);
      $singleLead->formattedDayDifference = $days;
      
       $before48Hours   = Carbon::now()->subHours(48);
      $usersWithPendingAppointments = DB::table('za_appointment')
        ->join('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->whereIn('za_lead.status', [0])
        ->where('za_lead.is_dc', 1)
        ->where('za_appointment.status', 1)
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.appointment_date', '<=', $before48Hours)
        ->distinct('za_appointment.sno')
        ->pluck('za_appointment.created_by')
        ->toArray();
 
      if (in_array($singleLead->created_by, $usersWithPendingAppointments)) {
 
        $singleLead->not_closed = 1;
      } else {
        $singleLead->not_closed = 0;
      }
      $usersWithPendingSpamApproval = DB::table('za_lead')
        ->select('created_by', DB::raw('COUNT(*) as total'))
        ->where('za_lead.status', 7)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.branch_id', $branch_id)
        ->groupBy('created_by')
        ->having('total', '>=', 5)
        ->pluck('created_by')
        ->toArray();
 
      if (in_array($singleLead->created_by, $usersWithPendingSpamApproval)) {
        $singleLead->spam_not_closed = 1;
      } else {
        $singleLead->spam_not_closed = 0;
      }
 
      $usersWithPendingDeadApproval = DB::table('za_lead')
        ->select('created_by', DB::raw('COUNT(*) as total'))
          ->where('za_lead.status', 5)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.branch_id', $branch_id)
        ->groupBy('created_by')
        ->having('total', '>=', 5)
        ->pluck('created_by')
        ->toArray();
 
      if (in_array($singleLead->created_by, $usersWithPendingDeadApproval)) {
        $singleLead->dead_not_closed = 1;
      } else {
        $singleLead->dead_not_closed = 0;
      }
    
    }


    // End timing
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;

    // Calculate the sum of app_score
    $sumAppScore = $leads->sum('total_app_score');



    // Transform the leads and add the sum of app_score to each lead
    $leads->getCollection()->transform(function ($item, $key) use ($sumAppScore) {
      $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1)); // Only keeps and capitalizes the first letter
      $item->app_score = $sumAppScore; // Add sum of app_score to each lead
      return $item;
    });

    // Continue with other operations and calculations for totalLeadCount, percentage calculations, etc.
    // Get the total count of leads
    $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
    if ($branch_id != 0) {
      $totalLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $totalLeadCount = $totalLeadCounts->count();

    // Get the count of leads for the current month
    $currentMonthLeadCounts = LeadModel::whereNotIn('za_lead.status', [2, 6])->where('za_lead.spam_verified', 0)->where('za_lead.internal_status', 0);
    if ($branch_id != 0) {
      $currentMonthLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCounts = $currentMonthLeadCounts
      ->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'));
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $currentMonthLeadCount = $currentMonthLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $currentMonthLeadCount = $currentMonthLeadCounts->count();

    $totalCustomerCount = LeadModel::where('status', 4)->where('za_lead.internal_status', '!=', 1)->where('za_lead.registered_date', '!=', 0);
    if ($branch_id != 0) {
      $totalCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    // Get the count of leads for the current month
    $currentMonthCustomerCount = LeadModel::where('status', 4)->where('za_lead.internal_status', '!=', 1)->where('za_lead.registered_date', '!=', 0);
    if ($branch_id != 0) {
      $currentMonthCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthCustomerCount = $currentMonthCustomerCount->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'))
      ->count();

    // Calculate the percentage
    $percentageover = 0;
    $percentagecurrentmonth = 0;
    if ($totalLeadCount > 0) {
      $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
    }
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    // Format the percentage to 2 decimal places
    $percentageover = round($percentageover) . '%';
    $percentagecurrentmonth = round($percentagecurrentmonth) . '%';

    $rawLead = RawLeadModel::select('za_raw_lead.sno', 'za_raw_lead.lead_name', 'za_raw_lead.lead_gender', 'za_raw_lead.lead_dob', 'za_raw_lead.lead_email_id', 'lead_mobile', 'za_lead_type.lead_type_name', 'za_lead_type.sno as lead_type_id', 'za_lead_source.lead_source_name', 'za_lead_source.sno as lead_source_id')
      ->where('za_raw_lead.status', 6)->join('za_lead_type', 'za_raw_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->join('za_lead_source', 'za_raw_lead.lead_source_id', '=', 'za_lead_source.sno')->orderBy('za_raw_lead.sno', 'desc');
    if ($branch_id != 0) {
      $rawLead->where('za_raw_lead.branch_id', $branch_id);
    }
    $pageConfigs = ['myLayout' => 'default'];

    $lead_type_fill = '';
    $lead_source_fill = '';
    $course_fill = '';
    $potential_type_fill = '';
    $lead_status_fill = '';
    $date_filter = '';
    $staff_fill = '';
    $lead_fill = '';
    $fin_yr_fill = '';


    $staff_filter_list = StaffModel::where('status', 0);
    if ($branch_id != 0) {
      $staff_filter_list = $staff_filter_list->where('branch_id', $branch_id);
    }
    $staff_filter_list = $staff_filter_list->where('department_id', 1)->orderBy('nick_name', 'ASC')->get();
    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    $course_type = LeadTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $CourseCategory = LeadSourceModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $lead = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $PotentialType = LeadPotentialModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Lead_status_list = LeadStatusModel::where('status', 0)->where('legend_status', 0)->orderBy('lead_status_name', 'ASC')->get();


    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_internal = InternalReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();


    $followupReasonList = FollowupReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();



    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    //   $leadall = DB::table('za_lead')->select('za_lead.created_at','latest_appointment.lead_id as followup_latest_id',
    //             'appointment_counts.lead_id as followup_id')
    //     ->where('za_lead.branch_id',$branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])
    //       ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
    //           SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
    //           FROM za_appointment
    //           WHERE (lead_id, appointment_date) IN (
    //               SELECT lead_id, MAX(appointment_date) AS appointment_date
    //               FROM za_appointment
    //               GROUP BY lead_id
    //           )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
    //             ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
    //           FROM za_appointment
    //           GROUP BY lead_id) AS appointment_counts'), 'za_lead.sno', '=', 'appointment_counts.lead_id')
    //           ->get();


    $leadall = DB::table('za_lead')
      ->select(
        'za_lead.created_at',
        'za_lead.sno',
        'latest_appointment.lead_id as followup_latest_id',
        'appointment_counts.lead_id as followup_id'
      )
      ->where('za_lead.branch_id', $branch_id)->where('za_lead.created_by', '!=', 0)
      ->where('za_lead.status', 0)->where('za_lead.internal_status', '!=', 1)
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                status,
                appointment_date,
                SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
            FROM za_appointment
            WHERE (lead_id, appointment_date) IN (
                SELECT
                    lead_id,
                    MAX(appointment_date) AS appointment_date
                FROM za_appointment
                GROUP BY lead_id
            )
        ) AS latest_appointment'),
        'za_lead.sno',
        '=',
        'latest_appointment.lead_id'
      )
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                COUNT(*) as total_appointments
            FROM za_appointment
            GROUP BY lead_id
        ) AS appointment_counts'),
        'za_lead.sno',
        '=',
        'appointment_counts.lead_id'
      );

    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadall = $leadall->where('za_lead.created_by', $user_id);
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)
      // Do nothing as $leadall already includes all data
    }

    // Execute the query
    $leadall = $leadall->get();

    // return $leadall;
    // vasanth

    $follwup_count = 0;
    $not_follow_up_ids = [];
    foreach ($leadall as $singleLead) {
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day         = $createdAt->diffInHours($currentDateTime) >= 24;

      if ($chk1day) {
        // Increment only if follow-up IDs do not exist
        if (!$singleLead->followup_latest_id && !$singleLead->followup_id) {
          $follwup_count++;
          // $lead_names[] = $singleLead->sno;
        }
      }
    }

    // return $lead_names;

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    // return  $follwup_count;
    $walkIn = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')->where('za_lead_appointment.appointment_category', 'walk-in')->where('za_lead_appointment.branch_id', $branch_id)->where('za_lead_appointment.appointment_status', 1)->where('za_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now());
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $walkInCount = $walkIn->where('za_lead_appointment.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $walkInCount = $walkIn->count();
    $reasonList_potential = PotentialReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    return view('content.sales.lead.lead_list', compact(
      'leads',
      'totalLeadCount',
      'leadOriginalCount',
      'walkInCount',
      'reasonList_potential',
      'follwup_count',
      'totalFollowup',
      'not_verified_spam_count',
      'not_verified_drop_count',

      'perpage',
      'currentMonthLeadCount',
      'percentageover',
      'walletCount',
      'percentagecurrentmonth',
      'pageConfigs',
      'course_type',
      'CourseCategory',
      'lead_type_fill',
      'lead_source_fill',
      'course_fill',
      'lead',
      'potential_type_fill',
      'PotentialType',
      'date_filter',
      'lead_status_fill',
      'staff_filter_list',
      'staff_fill',
      'login_branch_data',
      'Lead_status_list',
      'fin_yr_fill',
      'reasonList',
      'reasonList_internal',
      'leadbankCount',
      'followupReasonList',
      'reasonList_drop'

    ));
  }

  public function filter_lead(Request $request)
  {
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    $lead_type_fill      = $request->lead_type_fill ?? '';
    $lead_source_fill    = $request->lead_source_fill ?? '';
    $course_fill         = $request->course_fill ?? '';
    $potential_type_fill = $request->potential_type_fill ?? '';
    $lead_status_fill    = $request->lead_status_fill ?? '';
    $staff_fill          = $request->staff_fill ?? '';
    $date_filter         = $request->dt_fill_issue_rpt;
    $from_date_filter    = $request->from_date_fillter_textbox;
    $to_date_filter      = $request->to_date_fillter_textbox;
    $lead_fill           = $request->lead_fill ?? '';
    $fin_yr_fill         = $request->fin_yr_fill ?? '';
    $pending_followUp_fill         = $request->pending_followUp_fill ?? '';
    $walkin_fill         = $request->walkin_fill ?? '';
    $walkin_fill_ids = DB::table('za_lead_appointment')->where('za_lead_appointment.appointment_category', 'walk-in')->where('za_lead_appointment.branch_id', $branch_id)->where('za_lead_appointment.appointment_status', 1)->where('za_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now())->pluck('za_lead_appointment.lead_id');
    


    $leadall = DB::table('za_lead')
      ->select(
        'za_lead.created_at',
        'za_lead.sno',
        'latest_appointment.lead_id as followup_latest_id',
        'appointment_counts.lead_id as followup_id'
      )
      ->where('za_lead.branch_id', $branch_id)->where('za_lead.created_by', '!=', 0)
      ->where('za_lead.status', 0)->where('za_lead.internal_status', '!=', 1)
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                status,
                appointment_date,
                SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
            FROM za_appointment
            WHERE (lead_id, appointment_date) IN (
                SELECT
                    lead_id,
                    MAX(appointment_date) AS appointment_date
                FROM za_appointment
                GROUP BY lead_id
            )
        ) AS latest_appointment'),
        'za_lead.sno',
        '=',
        'latest_appointment.lead_id'
      )
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                COUNT(*) as total_appointments
            FROM za_appointment
            GROUP BY lead_id
        ) AS appointment_counts'),
        'za_lead.sno',
        '=',
        'appointment_counts.lead_id'
      );

    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadall = $leadall->where('za_lead.created_by', $user_id);
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)
      // Do nothing as $leadall already includes all data
    }


    if ($staff_fill != '') {
      $leadall->where('created_by', $staff_fill);
    }
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $leadall->whereDate('za_lead.registered_date', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $leadall->whereBetween('za_lead.registered_date', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth  = date('Y-m-t');
      $leadall->whereBetween('za_lead.registered_date', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate   = date('Y-m-d', strtotime($to_date_filter));
        $leadall->whereBetween('za_lead.registered_date', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $leadall->where('za_lead.registered_date', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $leadall->where('za_lead.registered_date', '<=', $toDate);
      }
    }
    $selectedMonthsText = '';
    if ($fin_yr_fill != '') {
      $helper            = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);

        if (is_array($monthsArray) && ! empty($monthsArray)) {
          // Map the months numbers to their names
          $months = [
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4      => 'April',
            5    => 'May',
            6       => 'June',
            7 => 'July',
            8    => 'August',
            9   => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December',
          ];

          // Collect the selected month names
          $selectedMonths = [];
          foreach ($monthsArray as $month) {
            if (isset($months[$month])) {
              $selectedMonths[] = $months[$month];
            }
          }

          // Prepare the selected months text for the view
          $selectedMonthsText = implode(', ', $selectedMonths);
        }
      }
    }
    // Other Filters
    if ($lead_type_fill != '') {
      $leadall->where('za_lead.lead_type_id', $lead_type_fill);
    }
    if ($staff_fill != '') {
      $leadall->where('za_lead.created_by', $staff_fill);
    }
    if ($lead_source_fill != '') {
      $leadall->where('za_lead.lead_source_id', $lead_source_fill);
    }
    if ($course_fill != '') {
      $leadall->whereJsonContains('za_lead.course_id', $course_fill)->whereRaw('JSON_LENGTH(za_lead.course_id) = 1');
    }
    if ($potential_type_fill != '') {
      $leadall->where('za_lead.lead_score', $potential_type_fill);
    }
    if ($lead_status_fill != '') {
      $leadall->where('za_lead.status', $lead_status_fill);
    }
    if ($lead_fill != '') {
      $leadall->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    $leadall       = $leadall->get();
    $follwup_count = 0;
    $not_follow_up_ids = [];
    // return $leadall;


    foreach ($leadall as $singleLead) {
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day         = $createdAt->diffInHours($currentDateTime) >= 24;

      if ($chk1day) {
        // Increment only if follow-up IDs do not exist
        if (!$singleLead->followup_latest_id && !$singleLead->followup_id) {
          $follwup_count++;
          // $lead_names[] = $singleLead->sno;
          $not_follow_up_ids[] = $singleLead->sno;
        }
      }
    }
    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.created_at',
      'za_lead.created_by',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.inter_calls',
      'za_lead.incoming_count',
      'za_lead.outgoing_count',
      'za_lead.missed_reject_count',
      'za_lead.phone_verify_status',
      'za_lead.phone_verify_content',
      'za_lead.dialed_count',
      'za_lead.spam_verified',
      'za_lead.drop_verified',
      'za_lead.spam_tl_verified',
      'za_lead.document_send_count',
      'za_lead.drop_tl_verified',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.sulekha_id',
      'za_lead.website_id',
      'za_lead.call_tracker_id',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_event_id',
      //   'za_lead_appointment.appointment_status as lead_appointment_status',
      //   'za_lead_appointment.lead_id as appointment_lead_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color',
      'appointment_counts.lead_id as followup_id',
      'latest_appointment.lead_id as latest_lead_id',
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
        SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
        FROM za_appointment
        WHERE (lead_id, appointment_date) IN (
            SELECT lead_id, MAX(appointment_date) AS appointment_date
            FROM za_appointment
            GROUP BY lead_id
        )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
        FROM za_appointment
        GROUP BY lead_id) AS appointment_counts'), 'za_lead.sno', '=', 'appointment_counts.lead_id')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      //   ->leftJoin('za_lead_appointment', 'za_lead.sno', '=', 'za_lead_appointment.lead_id')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->where('za_lead.internal_status', '!=', 1)
      //   ->where('za_lead.created_by', '>', 1)
      ->where('za_lead.branch_id', $branch_id)
      ->whereIn('za_lead.status', [0, 1, 4, 5, 7]);
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $leads->whereDate('za_lead.registered_date', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $leads->whereBetween('za_lead.registered_date', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth  = date('Y-m-t');
      $leads->whereBetween('za_lead.registered_date', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate   = date('Y-m-d', strtotime($to_date_filter));
        $leads->whereBetween('za_lead.registered_date', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $leads->where('za_lead.registered_date', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $leads->where('za_lead.registered_date', '<=', $toDate);
      }
    }
    // if ($fin_yr_fill  != '') {
    //   $helper = new \App\Helpers\Helpers();
    //   $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

    //   if ($selected_fin_year) {
    //     $monthsArray = json_decode($selected_fin_year->financial_month, true);

    //     if (is_array($monthsArray) && !empty($monthsArray)) {
    //       $monthConditions = [];

    //       foreach ($monthsArray as $month) {
    //         if (is_numeric($month) && $month >= 1 && $month <= 12) {
    //           $monthConditions[] = [
    //             'year' => date('Y'),
    //             'month' => (int)$month,
    //           ];
    //         }
    //       }
    //       if (!empty($monthConditions)) {
    //         $leads->where(function ($query) use ($monthConditions) {
    //           foreach ($monthConditions as $condition) {
    //             $query->orWhere(function ($q) use ($condition) {
    //               $q->whereYear('za_lead.created_at', $condition['year'])
    //                 ->whereMonth('za_lead.created_at', $condition['month']);
    //             });
    //           }
    //         });
    //       }
    //     }
    //   }
    // }
    $selectedMonthsText = '';
    if ($fin_yr_fill != '') {
      $helper            = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);

        if (is_array($monthsArray) && ! empty($monthsArray)) {
          // Map the months numbers to their names
          $months = [
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4      => 'April',
            5    => 'May',
            6       => 'June',
            7 => 'July',
            8    => 'August',
            9   => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December',
          ];

          // Collect the selected month names
          $selectedMonths = [];
          foreach ($monthsArray as $month) {
            if (isset($months[$month])) {
              $selectedMonths[] = $months[$month];
            }
          }

          // Prepare the selected months text for the view
          $selectedMonthsText = implode(', ', $selectedMonths);
        }
      }
    }
    // Other Filters
    if ($lead_type_fill != '') {
      $leads->where('za_lead.lead_type_id', $lead_type_fill);
    }
    if ($staff_fill != '') {
      $leads->where('za_lead.created_by', $staff_fill);
    }
    if ($lead_source_fill != '') {
      $leads->where('za_lead.lead_source_id', $lead_source_fill);
    }
    if ($course_fill != '') {
      $leads->whereJsonContains('za_lead.course_id', $course_fill)->whereRaw('JSON_LENGTH(za_lead.course_id) = 1');
    }
    if ($potential_type_fill != '') {
      $leads->where('za_lead.lead_score', $potential_type_fill);
    }
    if ($lead_status_fill != '') {
      $leads->where('za_lead.status', $lead_status_fill);
    }
    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    if ($pending_followUp_fill == 1) {
      $leads->whereIn('za_lead.sno', $not_follow_up_ids);
    }
    if ($walkin_fill == 1) {
      $leads->whereIn('za_lead.sno', $walkin_fill_ids);
    }
    

    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.document_send_count',
      'za_lead.created_by',
      'za_lead.registered_date',
      'za_lead.inter_calls',
      'za_lead.lead_event_id',
      //   'za_lead_appointment.appointment_status',
      //   'za_lead_appointment.lead_id',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.incoming_count',
      'za_lead.outgoing_count',
      'za_lead.missed_reject_count',
      'za_lead.dialed_count',
      'za_lead.phone_verify_status',
      'za_lead.phone_verify_content',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.website_id',
      'za_lead.call_tracker_id',
      'za_lead.spam_verified',
      'za_lead.drop_verified',
      'za_lead.spam_tl_verified',
      'za_lead.drop_tl_verified',
      'za_lead.sulekha_id',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'latest_appointment.appointment_date',
      'latest_appointment.total_app_score',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'appointment_counts.lead_id',
      'latest_appointment.lead_id',
      'za_potential_type.emoji_color',
      'appointment_counts.total_appointments'
    );

    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leads = $leads->where('za_lead.created_by', $user_id)->where('za_lead.wallet_status', 0)->where('za_lead.drop_verified', 0)->where('za_lead.spam_verified', 0);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $leads = $leads;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }
    // Ordering and Fetching
    $leads = $leads->orderBy('za_lead.registered_date', 'desc')->paginate($perpage);

    foreach ($leads as $singleLead) {
      $normalizedPhoneNo    = ltrim($singleLead->lead_mobile, '0'); // Remove leading zero if present
      $phoneWithCountryCode = '+91' . $normalizedPhoneNo;           // Add the country code
      $lead                 = DB::table('za_contact_book')
        ->where('phone_no', $singleLead->lead_mobile)
        ->orWhere('phone_no', $phoneWithCountryCode) // Check both formats
        ->orderBy('contact_book_id', 'desc')
        ->first();
      $singleLead->staff_id = $lead->staff_id ?? "0";

      $lead = DB::table('za_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $leadapp = DB::table('za_lead_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
      $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
      $singleLead->appointment_status = $lead->status ?? "0";
      $chk1day                        = false;
      $createdAt                      = Carbon::parse($singleLead->created_at);
      $currentDateTime                = Carbon::now();
      if ($createdAt->diffInHours($currentDateTime) >= 24) {
        $chk1day = true;
      } else {
        $chk1day = false;
      }
      $alert_status = 0;
      if ($chk1day) {
        if ($singleLead->followup_latest_id) {
          $alert_status = 0;
        } else if ($singleLead->followup_id) {
          $alert_status = 0;
        } else {
          $alert_status = 1;
        }
      }

      $singleLead->alert_status = $alert_status;
      $registeredDate = Carbon::parse($singleLead->registered_date);
      $diff = $registeredDate->diff(Carbon::now());

      $years = $diff->y;
      $months = $diff->m;
      $days = $diff->d;

      // Build the formatted difference string
      $parts = [];

      if ($years > 0) {
        $parts[] = "{$years} year" . ($years > 1 ? 's' : '');
      }
      if ($months > 0) {
        $parts[] = "{$months} month" . ($months > 1 ? 's' : '');
      }
      if ($days > 0 || empty($parts)) {
        // If all other parts are zero, still show "0 days"
        $parts[] = "{$days} day" . ($days > 1 ? 's' : '');
      }

      $singleLead->formattedDifference = implode(' and ', $parts);
      $singleLead->formattedDayDifference = $days;
      
       $before48Hours   = Carbon::now()->subHours(48);
      $usersWithPendingAppointments = DB::table('za_appointment')
        ->join('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->whereIn('za_lead.status', [0])
        ->where('za_lead.is_dc', 1)
        ->where('za_appointment.status', 1)
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.appointment_date', '<=', $before48Hours)
        ->distinct('za_appointment.sno')
        ->pluck('za_appointment.created_by')
        ->toArray();
 
      if (in_array($singleLead->created_by, $usersWithPendingAppointments)) {
 
        $singleLead->not_closed = 1;
      } else {
        $singleLead->not_closed = 0;
      }
       $usersWithPendingSpamApproval = DB::table('za_lead')
        ->select('created_by', DB::raw('COUNT(*) as total'))
          ->where('za_lead.status', 7)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.branch_id', $branch_id)
        ->groupBy('created_by')
        ->having('total', '>=', 5)
        ->pluck('created_by')
        ->toArray();
 
      if (in_array($singleLead->created_by, $usersWithPendingSpamApproval)) {
        $singleLead->spam_not_closed = 1;
      } else {
        $singleLead->spam_not_closed = 0;
      }
 
      $usersWithPendingDeadApproval = DB::table('za_lead')
        ->select('created_by', DB::raw('COUNT(*) as total'))
         ->where('za_lead.status', 5)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.branch_id', $branch_id)
        ->groupBy('created_by')
        ->having('total', '>=', 5)
        ->pluck('created_by')
        ->toArray();
 
      if (in_array($singleLead->created_by, $usersWithPendingDeadApproval)) {
        $singleLead->dead_not_closed = 1;
      } else {
        $singleLead->dead_not_closed = 0;
      }
      
      
    }

    // Calculate the sum of app_score
    $sumAppScore = $leads->sum('total_app_score');

    // Transform the leads and add the sum of app_score to each lead
    $leads->getCollection()->transform(function ($item, $key) use ($sumAppScore) {
      $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1)); // Only keeps and capitalizes the first letter
      $item->app_score    = $sumAppScore;                               // Add sum of app_score to each lead
      return $item;
    });
    // Get the total count of leads
    $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
    if ($branch_id != 0) {
      $totalLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $totalLeadCount = $totalLeadCounts->count();

    // Get the count of leads for the current month
    $currentMonthLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7]);
    if ($branch_id != 0) {
      $currentMonthLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCounts = $currentMonthLeadCounts->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'));
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $currentMonthLeadCount = $currentMonthLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $currentMonthLeadCount = $currentMonthLeadCounts->count();

    $totalCustomerCount = LeadModel::where('status', 4);
    if ($branch_id != 0) {
      $totalCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    // Get the count of leads for the current month
    $currentMonthCustomerCount = LeadModel::where('status', 4);
    if ($branch_id != 0) {
      $currentMonthCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthCustomerCount = $currentMonthCustomerCount->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'))
      ->count();

    // Calculate the percentage
    $percentageover         = 0;
    $percentagecurrentmonth = 0;
    if ($totalLeadCount > 0) {
      $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
    }
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    // Format the percentage to 2 decimal places
    $percentageover         = round($percentageover) . '%';
    $percentagecurrentmonth = round($percentagecurrentmonth) . '%';

    $staff_filter_list = StaffModel::where('status', 0)->where('department_id', 1);

    if ($branch_id != 0) {
      $staff_filter_list = $staff_filter_list->where('branch_id', $branch_id);
    }

    $staff_filter_list = $staff_filter_list->orderBy('nick_name', 'ASC')->get();

    // Additional Data for View
    $course_type       = LeadTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $CourseCategory    = LeadSourceModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $lead              = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $PotentialType     = LeadPotentialModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    $Lead_status_list  = LeadStatusModel::where('status', 0)->where('legend_status', 0)->orderBy('lead_status_name', 'ASC')->get();

    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();
    $followupReasonList = FollowupReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_internal = InternalReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();



    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();


    // return $lead_names;
    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->where('za_lead.created_by', '!=', 0)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)
      ->distinct('za_lead.sno');
    // if ($staff_fill != '') {
    //   $leadOriginal->where('created_by', $staff_fill);
    // }
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();

    $walkIn = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')->where('za_lead_appointment.appointment_category', 'walk-in')->where('za_lead_appointment.branch_id', $branch_id)->where('za_lead_appointment.appointment_status', 1)->where('za_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now());
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $walkInCount = $walkIn->where('za_lead_appointment.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $walkInCount = $walkIn->count();
    // Return view with data
    return view('content.sales.lead.lead_list', compact(
      'leads',
      'leadOriginalCount',
      'walkInCount',
      'walletCount',
      'leadbankCount',
      'followupReasonList',
      'from_date_filter',
      'reasonList_internal',
      'to_date_filter',
      'selectedMonthsText',
      'follwup_count',
      'perpage',
      'page',
      'not_verified_spam_count',
      'not_verified_drop_count',
      'totalLeadCount',
      'totalFollowup',
      'fin_yr_fill',
      'currentMonthLeadCount',
      'percentageover',
      'percentagecurrentmonth',
      'course_type',
      'CourseCategory',
      'lead_type_fill',
      'lead_source_fill',
      'lead',
      'course_fill',
      'potential_type_fill',
      'PotentialType',
      'lead_status_fill',
      'date_filter',
      'staff_filter_list',
      'staff_fill',
      'login_branch_data',
      'Lead_status_list',
      'lead_fill',
      'reasonList',
      'reasonList_drop'
    ))->with('filter_on', true);
  }

//   public function raw_lead(Request $request)
//   {
//     $branch_id = $request->user()->branch_id;
//     // return $branch_id;
//     $user_id   = $request->user()->user_id;

//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;
//     $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
//     // return $login_branch_data;

//     $rawLeadQuery = RawLeadModel::select('za_raw_lead.sno', 'za_raw_lead.lead_name', 'za_raw_lead.registered_date', 'za_raw_lead.lead_gender', 'za_raw_lead.lead_dob', 'za_raw_lead.lead_email_id', 'za_raw_lead.lead_mobile', 'za_raw_lead.lead_group', 'za_lead_source.lead_source_name', 'za_lead_source.sno as lead_source_id')
//       ->where('za_raw_lead.status', 6)
//       // ->join('za_lead_type', 'za_raw_lead.lead_type_id', '=', 'za_lead_type.sno')
//       ->join('za_lead_source', 'za_raw_lead.lead_source_id', '=', 'za_lead_source.sno')
//       ->where('za_raw_lead.branch_id', $branch_id)
//       ->orderBy('za_raw_lead.sno', 'desc');


//     // return $rawLeadQuery;
//     // Paginate the results
//     $rawLeads = $rawLeadQuery->paginate($perpage);

//     // Get all lead mobile numbers from raw leads
//     $leadMobiles = $rawLeads->pluck('lead_mobile')->toArray();

//     // Check which mobile numbers exist in za_lead table
//     $existingMobiles = LeadModel::whereIn('lead_mobile', $leadMobiles)->pluck('lead_mobile')->toArray();

//     // Map to add lead_initial and mobile_exists
//     $rawLeads->getCollection()->transform(function ($item) use ($existingMobiles) {
//       $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1));
//       $item->mobile_exists = in_array($item->lead_mobile, $existingMobiles) ? true : false;
//       return $item;
//     });

//     // // Map to add lead_initial
//     // $rawLeads->getCollection()->transform(function ($item) {
//     //   $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1));
//     //   return $item;
//     // });
//     // dd($rawLeads);

//     $totalLeadCount = RawLeadModel::where('status', 6);
//     // if ($branch_id != 0) {
//     $totalLeadCount->where('za_raw_lead.branch_id', $branch_id);
//     // }
//     $totalLeadCount = $totalLeadCount->count();

//     // return $totalLeadCount;

//     $lead_grp_fill = '';
//     // return $reasonList_internal;
//     if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
//       // User can only view their own data
//       $totalFollowup = DB::table('za_appointment')
//         ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
//         ->where('za_appointment.branch_id', $branch_id)
//         ->where('za_appointment.status', '!=', 4)
//         ->where('za_lead.status', '=', 0)
//         ->where('za_appointment.created_by', $user_id)
//         ->whereDate('za_appointment.appointment_date', '=', today())
//         ->count();
//       // return "view_self_lead";
//     } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
//       // User can view all data
//       $totalFollowup = DB::table('za_appointment')
//         ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
//         ->where('za_appointment.branch_id', $branch_id)
//         ->where('za_appointment.status', '!=', 4)
//         ->where('za_lead.status', '=', 0)
//         ->whereDate('za_appointment.appointment_date', '=', today())
//         ->count();
//       // return "global_lead";
//     }

//     $leadbankCount = DB::table('za_raw_lead')
//       ->where('za_raw_lead.branch_id', $branch_id)
//       ->where('za_raw_lead.status', '=', 7)
//       ->count();

//     $walletCount = DB::table('za_lead')
//       ->where('za_lead.created_by', $user_id)
//       ->where('za_lead.branch_id', $branch_id)
//       ->where('za_lead.wallet_status', '=', 1)
//       ->count();

//     $not_verified_spam_count = 0;
//     $not_verified_drop_count = 0;

//     $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

//     $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

//     $reasonList = SpamReasonModel::select('*')
//       ->where('status', 0)
//       ->orderBy('sno', 'desc')->get();

//     $reasonList_drop = DropReasonModel::select('*')
//       ->where('status', 0)
//       ->orderBy('sno', 'desc')->get();

//     $leadOriginal = DB::table('za_lead')
//       ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
//       ->distinct('za_lead.sno');
//     // Apply permission-based filtering
//     if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
//       // User can only view their own data
//       $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
//     } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
//       // User can view all data (no additional filters needed)

//     }
//     $leadOriginalCount = $leadOriginal->count();

//     return view('content.sales.lead.raw_lead_list', compact('rawLeads', 'leadOriginalCount', 'walletCount', 'leadbankCount', 'totalLeadCount', 'reasonList_drop', 'reasonList', 'not_verified_spam_count', 'not_verified_drop_count', 'perpage', 'login_branch_data', 'lead_grp_fill', 'totalFollowup'))->with('filter_on', false);;
//   }

//   public function raw_filter(Request $request)
//   {
//     $user_id   = $request->user()->user_id;
//     $user_id   = $request->user()->user_id;
//     $branch_id = $request->user()->branch_id;
//     $lead_grp_fill = $request->lead_grp_fill ?? '';
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;

//     $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
//     // return $login_branch_data;

//     $rawLeadQuery = RawLeadModel::select('za_raw_lead.sno', 'za_raw_lead.lead_name', 'za_raw_lead.registered_date', 'za_raw_lead.lead_gender', 'za_raw_lead.lead_dob', 'za_raw_lead.lead_email_id', 'za_raw_lead.lead_mobile', 'za_lead_source.lead_source_name', 'za_raw_lead.lead_group', 'za_lead_source.sno as lead_source_id')
//       ->where('za_raw_lead.status', 6)
//       // ->join('za_lead_type', 'za_raw_lead.lead_type_id', '=', 'za_lead_type.sno')
//       ->where('za_raw_lead.branch_id', $branch_id)
//       ->join('za_lead_source', 'za_raw_lead.lead_source_id', '=', 'za_lead_source.sno');



//     if ($lead_grp_fill  != '') {
//       $rawLeadQuery->where(function ($query) use ($lead_grp_fill) {
//         $query->where('za_raw_lead.lead_name', 'LIKE', "%{$lead_grp_fill}%")
//           ->orWhere('za_raw_lead.registered_date', 'LIKE', "%{$lead_grp_fill}%")
//           ->orWhere('za_raw_lead.lead_mobile', 'LIKE', "%{$lead_grp_fill}%")
//           ->orWhere('za_lead_source.lead_source_name', 'LIKE', "%{$lead_grp_fill}%");
//       });
//     }

//     // Paginate the results
//     $rawLeads = $rawLeadQuery->orderBy('za_raw_lead.sno', 'desc')->paginate($perpage);


//     $totalLeadCount = RawLeadModel::where('status', 6);
//     if ($branch_id != 0) {
//       $totalLeadCount->where('za_raw_lead.branch_id', $branch_id);
//     }
//     $totalLeadCount = $totalLeadCount->count();

//     // return $reasonList_internal;
//     if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
//       // User can only view their own data
//       $totalFollowup = DB::table('za_appointment')
//         ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
//         ->where('za_appointment.branch_id', $branch_id)
//         ->where('za_appointment.status', '!=', 4)
//         ->where('za_lead.status', '=', 0)
//         ->where('za_appointment.created_by', $user_id)
//         ->whereDate('za_appointment.appointment_date', '=', today())
//         ->count();
//       // return "view_self_lead";
//     } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
//       // User can view all data
//       $totalFollowup = DB::table('za_appointment')
//         ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
//         ->where('za_appointment.branch_id', $branch_id)
//         ->where('za_appointment.status', '!=', 4)
//         ->where('za_lead.status', '=', 0)
//         ->whereDate('za_appointment.appointment_date', '=', today())
//         ->count();
//       // return "global_lead";
//     }
//     $leadbankCount = DB::table('za_raw_lead')
//       ->where('za_raw_lead.branch_id', $branch_id)
//       ->where('za_raw_lead.status', '=', 7)
//       ->count();

//     $walletCount = DB::table('za_lead')
//       ->where('za_lead.created_by', $user_id)
//       ->where('za_lead.branch_id', $branch_id)
//       ->where('za_lead.wallet_status', '=', 1)
//       ->count();

//     $not_verified_spam_count = 0;
//     $not_verified_drop_count = 0;

//     $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

//     $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

//     $reasonList = SpamReasonModel::select('*')
//       ->where('status', 0)
//       ->orderBy('sno', 'desc')->get();

//     $reasonList_drop = DropReasonModel::select('*')
//       ->where('status', 0)
//       ->orderBy('sno', 'desc')->get();

//     $leadOriginal = DB::table('za_lead')
//       ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
//       ->distinct('za_lead.sno');
//     // Apply permission-based filtering
//     if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
//       // User can only view their own data
//       $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
//     } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
//       // User can view all data (no additional filters needed)

//     }
//     $leadOriginalCount = $leadOriginal->count();


//     // Return view with data
//     return view('content.sales.lead.raw_lead_list', compact('rawLeads', 'leadOriginalCount', 'walletCount', 'leadbankCount', 'reasonList_drop', 'reasonList', 'not_verified_spam_count', 'not_verified_drop_count', 'totalLeadCount', 'login_branch_data', 'perpage', 'totalFollowup', 'lead_grp_fill'))->with('filter_on', true);
//   }

public function raw_lead(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    // return $branch_id;
    $user_id   = $request->user()->user_id;

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    // return $login_branch_data;

    $rawLeadQuery = RawLeadModel::select('za_raw_lead.sno', 'za_raw_lead.lead_name', 'za_raw_lead.registered_date', 'za_raw_lead.lead_gender', 'za_raw_lead.lead_dob', 'za_raw_lead.lead_email_id', 'za_raw_lead.lead_mobile', 'za_raw_lead.lead_group', 'za_lead_source.lead_source_name', 'za_lead_source.sno as lead_source_id')
    ->selectRaw("
      CASE 
        WHEN EXISTS (
          SELECT 1 FROM za_lead 
          WHERE za_lead.lead_mobile = za_raw_lead.lead_mobile
        )
        THEN 1 ELSE 0
      END as mobile_exists
    ")
      ->where('za_raw_lead.status', 6)
      // ->join('za_lead_type', 'za_raw_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->join('za_lead_source', 'za_raw_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->orderBy('mobile_exists', 'asc')
      ->orderBy('za_raw_lead.sno', 'desc');


    // return $rawLeadQuery;
    // Paginate the results
    $rawLeads = $rawLeadQuery->paginate($perpage);

    // Get all lead mobile numbers from raw leads
    $leadMobiles = $rawLeads->pluck('lead_mobile')->toArray();

    // Check which mobile numbers exist in za_lead table
    $existingMobiles = LeadModel::whereIn('lead_mobile', $leadMobiles)->pluck('lead_mobile')->toArray();

    // Map to add lead_initial and mobile_exists
    $rawLeads->getCollection()->transform(function ($item) use ($existingMobiles) {
      $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1));
      // $item->mobile_exists = in_array($item->lead_mobile, $existingMobiles) ? true : false;
      return $item;
    });

    // // Map to add lead_initial
    // $rawLeads->getCollection()->transform(function ($item) {
    //   $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1));
    //   return $item;
    // });
    // dd($rawLeads);

    $totalLeadCount = RawLeadModel::where('status', 6);
    // if ($branch_id != 0) {
    $totalLeadCount->where('za_raw_lead.branch_id', $branch_id);
    // }
    $totalLeadCount = $totalLeadCount->count();

    // return $totalLeadCount;

    $lead_grp_fill = '';
    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();

    return view('content.sales.lead.raw_lead_list', compact('rawLeads', 'leadOriginalCount', 'walletCount', 'leadbankCount', 'totalLeadCount', 'reasonList_drop', 'reasonList', 'not_verified_spam_count', 'not_verified_drop_count', 'perpage', 'login_branch_data', 'lead_grp_fill', 'totalFollowup'))->with('filter_on', false);;
  }

  public function raw_filter(Request $request)
  {
    $user_id   = $request->user()->user_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $lead_grp_fill = $request->lead_grp_fill ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    // return $login_branch_data;

    $rawLeadQuery = RawLeadModel::select('za_raw_lead.sno', 'za_raw_lead.lead_name', 'za_raw_lead.registered_date', 'za_raw_lead.lead_gender', 'za_raw_lead.lead_dob', 'za_raw_lead.lead_email_id', 'za_raw_lead.lead_mobile', 'za_lead_source.lead_source_name', 'za_raw_lead.lead_group', 'za_lead_source.sno as lead_source_id')
    ->selectRaw("
      CASE 
        WHEN EXISTS (
          SELECT 1 FROM za_lead 
          WHERE za_lead.lead_mobile = za_raw_lead.lead_mobile
        )
        THEN 1 ELSE 0
      END as mobile_exists
    ")
      ->where('za_raw_lead.status', 6)
      // ->join('za_lead_type', 'za_raw_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->join('za_lead_source', 'za_raw_lead.lead_source_id', '=', 'za_lead_source.sno');



    if ($lead_grp_fill  != '') {
      $rawLeadQuery->where(function ($query) use ($lead_grp_fill) {
        $query->where('za_raw_lead.lead_name', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('za_raw_lead.registered_date', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('za_raw_lead.lead_mobile', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('za_lead_source.lead_source_name', 'LIKE', "%{$lead_grp_fill}%");
      });
    }

    // Paginate the results
    $rawLeads = $rawLeadQuery->orderBy('mobile_exists', 'asc')->orderBy('za_raw_lead.sno', 'desc')->paginate($perpage);


    $totalLeadCount = RawLeadModel::where('status', 6);
    if ($branch_id != 0) {
      $totalLeadCount->where('za_raw_lead.branch_id', $branch_id);
    }
    $totalLeadCount = $totalLeadCount->count();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }
    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();


    // Return view with data
    return view('content.sales.lead.raw_lead_list', compact('rawLeads', 'leadOriginalCount', 'walletCount', 'leadbankCount', 'reasonList_drop', 'reasonList', 'not_verified_spam_count', 'not_verified_drop_count', 'totalLeadCount', 'login_branch_data', 'perpage', 'totalFollowup', 'lead_grp_fill'))->with('filter_on', true);
  }
  
  public function Lead_bank_list(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $lead_grp_fill = $request->lead_grp_fill ?? '';
    $user_id   = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    // return $login_branch_data;

    $rawLeadQuery = RawLeadModel::select('za_raw_lead.sno', 'za_raw_lead.lead_name', 'za_raw_lead.registered_date', 'za_raw_lead.lead_gender', 'za_raw_lead.lead_dob', 'za_raw_lead.lead_email_id', 'za_raw_lead.lead_mobile', 'za_lead_source.lead_source_name', 'za_raw_lead.lead_group','za_raw_lead.approved_by', 'za_raw_lead.referral_by', 'za_lead_source.sno as lead_source_id')
      ->where('za_raw_lead.status', 7)
      // ->join('za_lead_type', 'za_raw_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->join('za_lead_source', 'za_raw_lead.lead_source_id', '=', 'za_lead_source.sno');

    if ($branch_id != 0) {
      $rawLeadQuery->where('za_raw_lead.branch_id', $branch_id);
    }

    if ($lead_grp_fill  != '') {
      $rawLeadQuery->where(function ($query) use ($lead_grp_fill) {
        $query->where('za_raw_lead.lead_name', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('za_raw_lead.registered_date', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('za_raw_lead.lead_mobile', 'LIKE', "%{$lead_grp_fill}%")
          ->orWhere('za_lead_source.lead_source_name', 'LIKE', "%{$lead_grp_fill}%");
      });
    }

    // Paginate the results
    $rawLeads = $rawLeadQuery->orderBy('za_raw_lead.sno', 'desc')->paginate($perpage);


    $totalLeadCount = RawLeadModel::where('status', 6);
    if ($branch_id != 0) {
      $totalLeadCount->where('za_raw_lead.branch_id', $branch_id);
    }
    $totalLeadCount = $totalLeadCount->count();

    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();
    $reasonList_internal = InternalReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }
    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    $staff_check = StaffModel::select('lead_bank_count')->where('sno', $request->user()->user_id)
      ->where('status', 0)
      ->first(); // Get the first matching staff record

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    // Return view with data
    return view('content.sales.lead.bank_lead_list', compact('rawLeads', 'leadOriginalCount', 'walletCount', 'staff_check', 'reasonList', 'leadbankCount', 'reasonList_drop', 'reasonList_internal', 'not_verified_spam_count', 'not_verified_drop_count', 'totalLeadCount', 'login_branch_data', 'perpage', 'totalFollowup', 'lead_grp_fill'))->with('filter_on', true);
  }

    public function approveRejectLead(Request $request)
  {
    try {
      $request->validate([
        'sno' => 'required|integer',
        'status' => 'required|in:1,2',
        'lead_name' => 'required|string'
      ]);
 
      DB::beginTransaction();
 
      $lead = RawLeadModel::find($request->sno);
 
      if (!$lead) {
        DB::rollBack();
        return response()->json([
          'success' => false,
          'message' => 'Lead not found.'
        ], 404);
      }
 
      // Update lead status
      $lead->approved_by = $request->status; // 1 = Approved, 2 = Rejected
      $lead->updated_by = auth()->user()->user_id;
      $lead->save();
 
      $action = $request->status == 1 ? 'approved' : 'rejected';
 
      // If rejected, insert points deduction record
      if ($request->status == 2) {
        $this->deductPointsForRejectedLead($lead);
      }
 
      DB::commit();
 
      return response()->json([
        'success' => true,
        'message' => "Lead has been {$action} successfully.",
        'data' => $lead
      ]);
    } catch (\Exception $e) {
      DB::rollBack();
      \Log::error('Lead approval error: ' . $e->getMessage(), [
        'trace' => $e->getTraceAsString(),
        'request_data' => $request->all()
      ]);
 
      return response()->json([
        'success' => false,
        'message' => 'Failed to process request: ' . $e->getMessage()
      ], 500);
    }
  }
 
  /**
   * Deduct points when a lead is rejected
   */
  private function deductPointsForRejectedLead($lead)
  {
    // Check if referral_by exists
    if (empty($lead->referral_by)) {
      \Log::warning('No referral_by found for lead', [
        'lead_id' => $lead->sno ?? $lead->id
      ]);
      return;
    }
 
 
 
    // Insert points deduction record
    $insertData = [
      'branch_id' => $lead->branch_id ?? 0,
      'student_id' => $lead->referral_by,
      'points_id' => 0,
      'points' => -2,
      'reason' => 'Lead rejected: ' . ($lead->lead_name ?? 'Unknown') . ' (Mobile: ' . ($lead->lead_mobile ?? 'N/A') . ')',
    ];
 
    DB::table('za_students_points')->insert($insertData);
  }
  
  
  public function internal_calls(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;

    // Filters
    $lead_fill = $request->input('lead_fill', '');

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.inter_calls',
      'za_lead.internal_status',
      'za_lead.internal_verify',
      'za_lead.internal_veri_reason',
      'za_lead.spam_reason',
      'za_lead.internal_comments',
      'za_lead.internal_reason',
      'za_lead.registered_date',
      'za_lead.created_at',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_staff.sno as staff_id',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color'
    )
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->where('internal_verify', '!=', 2)
      ->where('za_lead.potential_verify', 0)
      ->where('internal_status', 1);
    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.spam_reason',
      'za_lead.internal_status',
      'za_lead.internal_verify',
      'za_lead.internal_veri_reason',
      'za_lead.internal_reason',
      'za_lead.internal_comments',
      'za_lead.inter_calls',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_staff.sno',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color'
    );

    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    $leads = $leads->orderBy('za_lead.sno', 'desc')->paginate($perpage);
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();
    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();

    // return $leads;
    return view('content.sales.lead.internal_list', compact(
      'leads',
      'totalFollowup',
      'walletCount',
      'leadbankCount',
      'not_verified_spam_count',
      'not_verified_drop_count',
      'perpage',
      'lead_fill',
      'leadOriginalCount'
    ));
  }

  public function TodayFollowup(Request $request)
  {
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    // Filters
    $lead_fill = $request->input('lead_fill', '');

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.registered_date',
      'za_lead.inter_calls',
      'za_lead.created_at',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_appointment.appointment_time',
      'za_appointment.appointment_date',
      'za_appointment.created_by as appointment_staff',
      'za_appointment.lead_id as appointment_lead',
      'za_appointment.progressed',
      'za_appointment.status as appointment_status'
    )
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_appointment', 'za_lead.sno', '=', 'za_appointment.lead_id')
      ->where('za_appointment.status', 1)
      ->whereNotIn('za_lead.status', [2, 5, 6, 7])
      ->where('za_appointment.appointment_date', date('y-m-d'))
      ->where('za_appointment.branch_id', $branch_id);
      

    // Branch-specific filter
    if ($branch_id != 0) {
      $leads->where('za_lead.branch_id', $branch_id);
    }

    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.inter_calls',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'za_appointment.appointment_time',
      'za_appointment.created_by',
      'za_appointment.lead_id',
      'za_appointment.progressed',
      'za_appointment.status',
      'za_appointment.appointment_date'
    );

    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }

    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leads = $leads->where('za_lead.created_by', $user_id);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $leads = $leads;
      // return "global_lead";
    }

    $leads = $leads->orderBy('za_lead.sno', 'desc')->paginate($perpage);

    // return $reasonList_internal;


    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.status', 1)
        ->whereNotIn('za_lead.status', [2, 5, 6, 7])
        ->where('za_appointment.appointment_date', date('y-m-d'))
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.status', 1)
        ->whereNotIn('za_lead.status', [2, 5, 6, 7])
        ->where('za_appointment.appointment_date', date('y-m-d'))
        ->where('za_appointment.branch_id', $branch_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }
    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();


    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    // return $leads;
    return view('content.sales.lead.today_followup_list', compact(
      'leads',
      'perpage',
      'not_verified_spam_count',
      'not_verified_drop_count',
      'leadbankCount',
      'totalFollowup',
      'walletCount',
      'lead_fill',
      'leadOriginalCount'
    ));
  }

  public function spamLeadList(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;

    // Filters
    $lead_fill = $request->input('lead_fill', '');
    $bulk_action_fill = $request->input('bulk_action_fill', '');

    if (!empty($bulk_action_fill)) {
      if($bulk_action_fill == 1){
        $page      = $request->input('page', 1);
        $perpage   = (int)400;
        $offset    = ($page - 1) * $perpage;
      }
    }

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.spam_reason',
      'za_lead.spam_tl_verified',
      'za_lead.spam_tl_reason',
      'za_lead.spam_bh_reason',
      'za_lead.inter_calls',
      'za_lead.raw_lead_check',
      'za_lead.raw_lead_group',
      'za_lead.is_hot_lead',


      'za_lead.spam_comments',
      'za_lead.spam_verified',
      'za_lead.registered_date',
      'za_lead.created_at',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.sno as staff_id',
      'za_staff.nick_name as sales_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color'

    )
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->where('za_lead.status', 7);

    // Branch-specific filter
    if ($branch_id != 0) {
      $leads->where('za_lead.branch_id', $branch_id);
    }

    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.spam_reason',
      'za_lead.spam_tl_verified',
      'za_lead.spam_comments',
      'za_lead.spam_verified',
      'za_lead.spam_tl_reason',
      'za_lead.is_hot_lead',
      'za_lead.spam_bh_reason',
      'za_lead.inter_calls',
      'za_lead.raw_lead_check',
      'za_lead.raw_lead_group',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.sno',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color'
    );




    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }

    if (!empty($bulk_action_fill)) {
      if($bulk_action_fill == 1){
          $leads->where(function ($query) use ($lead_fill) {
            $query->where('za_lead.spam_tl_verified', '=', 1)->Where('za_lead.spam_verified', '!=', 1);
          });
      }
    }

    
    $leads = $leads->orderBy('za_lead.spam_verified', 'asc')->paginate($perpage);

    $verified_spam_count     = 0;
    $not_verified_spam_count = 0;

    $verified_drop_count     = 0;
    $not_verified_drop_count = 0;

    $verified_spam_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 1)->count();
    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $verified_drop_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 1)->count();
    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();


    // return $leads;
    return view('content.sales.lead.spam_lead_list', compact(
      'leads',
      'leadOriginalCount',
      'perpage',
      'totalFollowup',
      'walletCount',
      'verified_spam_count',
      'not_verified_spam_count',
      'verified_drop_count',
      'leadbankCount',
      'not_verified_drop_count',
      'lead_fill',
      'bulk_action_fill'
    ));
  }

  public function dropLeadList(Request $request)
  {
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;

    // Filters
    $lead_fill = $request->input('lead_fill', '');
    $bulk_action_fill = $request->input('bulk_action_fill', '');

    if (!empty($bulk_action_fill)) {
      if($bulk_action_fill == 1){
        $page      = $request->input('page', 1);
        $perpage   = (int)400;
        $offset    = ($page - 1) * $perpage;
      }
    }

    // return $lead_fill;

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.drop_verified',
      'za_lead.is_hot_lead',
      'za_lead.drop_tl_verified',
      'za_lead.drop_reason',
      'za_lead.inter_calls',
      'za_lead.drop_bh_reason',
      'za_lead.drop_tl_reason',
      'za_lead.registered_date',
      'za_lead.created_at',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.sno as staff_id',
      'za_staff.nick_name as sales_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color'

    )
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->where('za_lead.branch_id', $branch_id)
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->where('za_lead.status', 5);

    if (isset($lead_fill)) {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }

    if (!empty($bulk_action_fill)) {
      if($bulk_action_fill == 1){
        $leads->where(function ($query) use ($lead_fill) {
          $query->where('za_lead.drop_tl_verified', '=', 1)->Where('za_lead.drop_verified', '!=', 1);
        });
      }
    }

    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.drop_verified',
      'za_lead.drop_reason',
      'za_lead.drop_tl_verified',
      'za_lead.registered_date',
      'za_lead.inter_calls',
      'za_lead.drop_bh_reason',
      'za_lead.drop_tl_reason',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_staff.sno',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color'
    );


    $leads = $leads->orderBy('za_lead.drop_verified', 'asc')->paginate($perpage);

    $verified_spam_count     = 0;
    $not_verified_spam_count = 0;

    $verified_drop_count     = 0;
    $not_verified_drop_count = 0;

    $verified_spam_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 1)->count();
    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $verified_drop_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 1)->count();
    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();


    // return $leads;
    return view('content.sales.lead.drop_lead_list', compact(
      'leads',
      'leadOriginalCount',
      'totalFollowup',
      'leadbankCount',
      'walletCount',
      'verified_spam_count',
      'not_verified_spam_count',
      'verified_drop_count',
      'not_verified_drop_count',
      'perpage',
      'lead_fill',
      'bulk_action_fill'
    ));
  }

  public function LeadWallet(Request $request)
  {
    $user_id   = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $startTime = microtime(true);
    $lead_fill = $request->input('lead_fill', '');
    // Retrieve leads with joins and filters
    // Retrieve leads with joins and filters
    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.wallet_status',
      'za_lead.created_at',
      'za_lead.created_by',
      'za_lead.inter_calls',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead_appointment.appointment_status as lead_appointment_status',
      'za_lead_appointment.lead_id as appointment_lead_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color',
      'appointment_counts.lead_id as followup_id',
      'latest_appointment.lead_id as latest_lead_id',
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
          SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
          FROM za_appointment
          WHERE (lead_id, appointment_date) IN (
              SELECT lead_id, MAX(appointment_date) AS appointment_date
              FROM za_appointment
              GROUP BY lead_id
          )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
          FROM za_appointment
          GROUP BY lead_id) AS appointment_counts'), 'za_lead.sno', '=', 'appointment_counts.lead_id')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_appointment', 'za_lead.sno', '=', 'za_lead_appointment.lead_id')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->where('wallet_status', '=', 1);

    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.wallet_status',
      'za_lead.lead_id',
      'za_lead.lead_mobile',
      'za_lead.inter_calls',
      'za_lead.created_at',
      'za_lead.created_by',
      'za_lead.registered_date',
      'za_lead_appointment.appointment_status',
      'za_lead_appointment.lead_id',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'latest_appointment.appointment_date',
      'latest_appointment.total_app_score',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'appointment_counts.lead_id',
      'latest_appointment.lead_id',
      'za_potential_type.emoji_color',
      'appointment_counts.total_appointments'
    );

    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leads = $leads->where('za_lead.created_by', $user_id)->where('za_lead.wallet_status', 1);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $leads = $leads;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }




    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    // Cursor Pagination for optimized results
    $leads = $leads->orderBy('za_lead.sno', 'desc')
      ->paginate($perpage);

    //  dd($leads);
    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    // return $leadbankCount;
    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

    // return $totalFollowup;
    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();



    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();



    return view('content.sales.lead.lead_wallet_list', compact(
      'leads',
      'totalFollowup',
      'leadbankCount',
      'walletCount',
      'login_branch_data',
      'not_verified_spam_count',
      'not_verified_drop_count',
      'perpage',
      'leadbankCount',
      'lead_fill',
      'leadOriginalCount'
    ));
  }

  public function Lead_source_list(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $year  = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));

    if ($year == date('Y') || $year > date('Y')) {
      $year_chk = 0;
    } else {
      $year_chk = 1;
    }
    // Get the current date
    $currentDate = now()->toDateString();
    $months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    $results = LeadSourceModel::select(
      DB::raw("COALESCE(za_lead_source.lead_source_name, 'No Source') as lead_source_name"), // Handle NULL as 'No Source'
      DB::raw("months.month_name")
    )
      ->crossJoin(DB::raw("(SELECT 'January' as month_name UNION ALL SELECT 'February'
                UNION ALL SELECT 'March' UNION ALL SELECT 'April' UNION ALL SELECT 'May'
                UNION ALL SELECT 'June' UNION ALL SELECT 'July' UNION ALL SELECT 'August'
                UNION ALL SELECT 'September' UNION ALL SELECT 'October' UNION ALL SELECT 'November'
                UNION ALL SELECT 'December') as months"))
      ->groupBy('za_lead_source.lead_source_name', 'months.month_name')
      ->orderBy('za_lead_source.lead_source_name', 'ASC')
      ->orderBy(DB::raw("FIELD(months.month_name, '" . implode("','", $months) . "')"))
      ->get();

    // return $results;
    // Map through the results and calculate customer_count for each row
    $results = $results->map(function ($single) use ($year, $request) {

      $currentMonth = $single->month_name;
      $branch_id = $request->user()->branch_id;

      $lead_count = DB::table('za_lead')
        ->join('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno') // Correct lead source join
        ->whereYear('za_lead.registered_date', $year)
        ->whereRaw("MONTHNAME(za_lead.registered_date) = ?", [$currentMonth]) // Match current month
        ->where('za_lead.internal_status', '!=', 1)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.created_by', '>', 0)
        ->where('za_lead.branch_id', '=', $branch_id)
        ->where('za_lead_source.lead_source_name', $single->lead_source_name)
        ->count(); // Get count instead of retrieving records


      $customer_count = DB::table('za_customer')
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id') // Assuming lead_id relates customers to leads
        ->join('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno') // Correct lead source join
        ->whereYear('za_customer.created_at', $year)
        ->whereRaw("MONTHNAME(za_customer.created_at) = ?", [$currentMonth]) // Match current month
        ->where('za_customer.status', 0)
        ->where('za_lead.created_by', '>', 0)
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_lead_source.lead_source_name', $single->lead_source_name)
        ->count(); // Get count instead of retrieving records

      // Add customer_count to the single result object
      $single->customer_count = $customer_count;
      $single->total_lead     = $lead_count;
      return $single;
    });

    // Ensure $results is a collection
    $results = collect($results);

    // Return the view with the data and total count
    return view('content.sales.lead_source.lead_source_list', [
      'perpage' => $perpage,
      'year_chk' => $year_chk,
      'results' => $results,
    ])->with('filter_on', false);
  }




  // ************************************* Lead List Pages **************************



  public function checkMobileExists(Request $request)
  {
    $lead_mobile = $request->input('mobile');

    // Assuming you have a Lead model with a mobile field
    $exists = LeadModel::where('lead_mobile', $lead_mobile)->exists();

    return response()->json(['exists' => $exists]);
  }

  public function List()
  {
    $lead = LeadModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead
    ], 200);
  }

  public function exportExcel(Request $request)
  {
    // return $request;
    $branchId = $request->user()->branch_id;
    $filters = $request->all();
    return Excel::download(new LeadExportExcel($branchId, $filters), 'leads-export.xlsx');
  }

  public function LeadExportExcel()
  {
    return Excel::download(new LeadExportModel, 'leads-sample-export.xlsx'); // Adjust filename and extension as needed
  }

  public function QuickAdd(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name       = $request->lead_name;
      $lead_mobile       = $request->lead_mobile;
      $lead_email_id       = $request->lead_email_id;
      $course_id       = $request->course_id;
      $lead_source_id       = $request->lead_source_id;
      $lead_type_id       = $request->lead_type_id;
      $lead_comments       = $request->lead_comments;
      $user_id            = $request->user()->user_id;
      $branch_id       = $request->user()->branch_id;
      $chk = LeadModel::where('lead_mobile', $lead_mobile)->where('za_lead.branch_id', $branch_id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Mobile has been  already created!'
        ]);
      } else {
        $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;

        $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $request_pay = sprintf("LED%04d", $next_number);
          $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
        }


        $add_category = new LeadModel();
        $add_category->lead_id                 = $lead_id;
        $add_category->lead_name               = Ucfirst($lead_name);
        $add_category->lead_mobile             = $lead_mobile;
        $add_category->lead_email_id           = $lead_email_id;
        $add_category->course_id               = json_encode($course_id);
        $add_category->lead_source_id          = $lead_source_id;
        $add_category->lead_type_id            = $lead_type_id;
        $add_category->lead_comments           = $lead_comments;
        $add_category->branch_id               = $branch_id;
        $add_category->created_by              = $user_id;
        $add_category->updated_by              = $user_id;
        $add_category->lead_status_id          = 1; //new lead
        $add_category->lead_condition          = 1; //quick or raw lead

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Lead Created successfully!');
    }
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|max:255',
      'lead_mobile_create' => 'required|max:255'

    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name           = $request->lead_name;
      $inter_calls = $request->country_code_name;
      $lead_mobile         = $request->lead_mobile_create;
      $lead_alternate_mobile       = $request->lead_alternate_mobile;
      $lead_email_id       = $request->lead_email_id;
      $lead_gender         = $request->lead_gender;
      $lead_marital_status            = $request->lead_marital_status;
      $Know_tag = is_array($request->lead_KnowledgeTag) ? json_encode($request->lead_KnowledgeTag) : $request->lead_KnowledgeTag;

      $country              = $request->country;
      $state                = $request->state;
      $city                 = $request->city;
      $address              = $request->address;
      $course_id            = $request->course_id;
      $lead_type_id            = $request->lead_type_id;
      $lead_source_id            = $request->lead_source_id;
      $lead_question_id            = $request->lead_question_id;
      $lead_comments            = $request->lead_comments;
      $branch_id       = $request->user()->branch_id;
      $lead_dob = isset($request->lead_dob) ? date('Y-m-d', strtotime($request->lead_dob)) : null;
      $lead_reg_date = date('Y-m-d');


      $user_id            = $request->user()->user_id;
      // dd($request);
      $chk = LeadModel::where('lead_mobile', ucwords($lead_mobile))->where('za_lead.branch_id', $branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Mobile Number already created!'
        ]);
      } else {
        $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;

        $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $request_pay = sprintf("LED%04d", $next_number);
          $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
        }


        $add_category = new LeadModel();
        $add_category->lead_id                 = $lead_id;
        $add_category->lead_name               = Ucfirst($lead_name);
        $add_category->lead_mobile             = $lead_mobile;
        $add_category->inter_calls             = $inter_calls;
        $add_category->lead_alternate_mobile   = $lead_alternate_mobile;
        $add_category->lead_email_id           = $lead_email_id;
        $add_category->lead_gender             = $lead_gender;
        $add_category->lead_dob                = $lead_dob;
        $add_category->registered_date         = $lead_reg_date;
        $add_category->lead_marital_status     = $lead_marital_status;
        $add_category->country                 = $country;
        $add_category->state                   = $state;

        $add_category->city                    = $city;
        $add_category->address                 = $address;
        $add_category->course_id               = json_encode($course_id);
        $add_category->lead_source_id          = $lead_source_id;
        $add_category->lead_type_id            = $lead_type_id;
        $add_category->lead_question_id        = $lead_question_id;
        $add_category->lead_comments           = $lead_comments;
        $add_category->lead_knowledge_tags     = $Know_tag;
        $add_category->branch_id               = $branch_id;
        $add_category->created_by              = $user_id;
        $add_category->updated_by              = $user_id;
        $add_category->lead_status_id          = 1; //new lead
        $add_category->lead_condition          = 2; //standard lead
        $add_category->save();



        if ($add_category) {

          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->transferred_from = 0; // from Bulk transfer
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();

          //****************** */ Update Staff Sales Person Points
          // Define point category:
          // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
          $helper = new \App\Helpers\Helpers();
          $pointsData = $helper->get_points_by_id(1);
          $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
          $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
          // Save new points for the staff
          $newPoints = new StaffpointsModel();
          $newPoints->branch_id = $branch_id;
          $newPoints->staff_id = $user_id;
          $newPoints->points_by = $add_category->sno;
          $newPoints->points_id = 1;
          $newPoints->points = $point;
          $newPoints->reason = $reason;
          $newPoints->save();

          // Update staff's available points
          $staff_points = StaffModel::where('sno', $user_id)->first();
          if ($staff_points) {
            $staff_points->avaiable_points += $point; // Increment the available points
            $staff_points->save();
          }
          //****************** */ Update Staff Sales Person Points

          $comm_get = Communication_config_Model::where('status', 0)->where('work_flow_id', 1)->orderBy('sno', 'desc')->get();
          if (isset($comm_get) && count($comm_get) > 0) {
            foreach ($comm_get as $comm) {
              $sourceTypeId = 1;
              $sourceId = $add_category->sno;
              $configId = $comm->sno;
              $branchId = $branch_id;
              $userId   = $user_id;
              $helper = new \App\Helpers\Helpers();
              $helper->scheduleMessages($sourceTypeId, $sourceId, $configId, $branchId, $userId);
            }
          }
        }

        if ($add_category) {
          $notificationData = [
            'branch_id' => $branch_id,
            'notification_content' => ' <div class="d-flex align-items-center">
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account-multiple-outline fs-3 text-black"></i></span>
              </div>
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
                <div class="text-secondary fs-8 fw-semibold">New Lead Created</div>
              </div>
            </div>',
            'who' => $user_id,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'status' => 0
          ];
          $notificationtype = 'Lead';
          $newNotification = new \App\Helpers\Helpers();

          $newNotification->createNotification($notificationData, $notificationtype);
        }

        $branch_data = BranchModel::where('sno', $request->user()->branch_id)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        // sms thank you lead
        if ($add_category) {

          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
          $authkey = $result_sms ? $result_sms->authkey : '';
          $sender_id = $result_sms ? $result_sms->sender_id : '';
          $template_id = $result_sms ? $result_sms->template_id : '';
          $country_code = $result_sms ? $result_sms->country_code : '';
          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
          $mobile_number = $country_code . $lead_mobile;

          $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

          // Replace placeholders with actual values
          $replacement_values = [$lead_name, $cre_mobile];
          $message_content = preg_replace_callback(
            '/\{#var#\}/',
            function () use (&$replacement_values) {
              return array_shift($replacement_values);
            },
            $message_content
          );

          $route = "default";
          $postData = array(
            'authkey' => $authkey,
            'mobiles' => $mobile_number,
            'message' => $message_content,
            'sender' => $sender_id,
            'route' => $route,
          );

          // API URL
          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

          // Initialize the resource
          $ch = curl_init();
          curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
          ));

          // Get response
          $response = curl_exec($ch);
          // return $response;
          $err = curl_error($ch);
          curl_close($ch);
        }
        // Thank you email send
        if ($add_category && $lead_email_id) {
          $email_template_id = 6; // thank you template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $lead_name, $content);
          $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
          $branchNo = $branch_data->mobile;
          $branchemail = $branch_data->mail;
          $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
          $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
          $content = str_replace('#salesNo', $branch_data->sales_mobile ? $branch_data->sales_mobile : '9677781155', $content);
          $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
          $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

          $mailData = [
            'url' => 'Eapl.com',
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo' => $branchNo,
            'branchemail' => $branchemail, // Use the message content from the request
            'fbLink' => $fbLink, // Use the message content from the request
            'instaLink' => $instaLink, // Use the message content from the request
            'salesMobile' => $branch_data->sales_mobile,
          ];

          $to_address = $lead_email_id;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name = 'Elysium Academy ' . "\xC2\xAE";
          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
        }

        // Central WhatsApp manager integration (replaces direct Graph API call).
        // Never fail lead creation because WhatsApp is unavailable or policy checks block a send.
        if ($add_category) {
          try {
            $rawLeadPhone = trim((string) $lead_mobile);
            $leadDigits = preg_replace('/\D+/', '', $rawLeadPhone);
            if (str_starts_with($rawLeadPhone, '+')) {
              $welcomePhone = '+' . $leadDigits;
            } elseif (strlen($leadDigits) === 10) {
              // This ERP's domestic lead form is India-focused; international numbers must include country code.
              $welcomePhone = '+91' . $leadDigits;
            } elseif (strlen($leadDigits) >= 11 && strlen($leadDigits) <= 15) {
              $welcomePhone = '+' . $leadDigits;
            } else {
              $welcomePhone = '';
            }

            $currentHour = (int) now('Asia/Kolkata')->format('H');
            $greeting = $currentHour >= 5 && $currentHour < 12
              ? 'Good Morning'
              : ($currentHour >= 12 && $currentHour < 18 ? 'Good Afternoon' : 'Good Evening');

            $welcomeComponents = [
              [
                'type' => 'header',
                'parameters' => [[
                  'type' => 'image',
                  'image' => ['link' => asset('assets/Welcome_Message_Header.jpg')],
                ]],
              ],
              [
                'type' => 'body',
                'parameters' => [
                  ['type' => 'text', 'text' => $greeting, 'parameter_name' => 'greet_msg'],
                  ['type' => 'text', 'text' => (string) $lead_name, 'parameter_name' => 'customer_name'],
                  ['type' => 'text', 'text' => (string) ($branch_data->website ?? 'https://elysiumacademy.org'), 'parameter_name' => 'web_link'],
                  ['type' => 'text', 'text' => (string) $branch_name, 'parameter_name' => 'branch_name'],
                  ['type' => 'text', 'text' => (string) ($branch_data->cre_mobile ?? '9677781155'), 'parameter_name' => 'contact_no'],
                  ['type' => 'text', 'text' => (string) ($branch_data->mail ?? 'info@elysiumacademy.org'), 'parameter_name' => 'contact_email'],
                ],
              ],
              [
                'type' => 'button',
                'sub_type' => 'copy_code',
                'index' => '0',
                'parameters' => [['type' => 'coupon_code', 'coupon_code' => 'NOOFFER']],
              ],
            ];

            $sendResult = app(\App\Services\WhatsAppManagerService::class)->queueWorkflow([
              'branch_id' => (int) $branch_id,
              'event_key' => 'lead.created',
              'to' => $welcomePhone,
              'components' => $welcomeComponents,
              'source_type' => 'Lead',
              'source_id' => (int) ($add_category->sno ?? 0),
              'created_by' => (int) $user_id,
              'idempotency_key' => 'lead-welcome:' . (int) $branch_id . ':' . (int) ($add_category->sno ?? 0),
            ]);

            if (empty($sendResult['ok'])) {
              \Illuminate\Support\Facades\Log::warning('Lead welcome WhatsApp was not queued.', [
                'lead_id' => $add_category->sno ?? null,
                'branch_id' => $branch_id,
                'status' => $sendResult['status'] ?? 'blocked',
                'reason' => $sendResult['reason'] ?? 'Unknown policy or configuration block.',
              ]);
            }
          } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Lead was created but WhatsApp welcome queueing failed.', [
              'branch_id' => $branch_id,
              'exception' => class_basename($e),
            ]);
          }
        }

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      }
      // return $result;
      return redirect('sales/manage_lead');
    }
  }

  public function Edit($id)
  {
    // $lead = LeadModel::select('za_lead.*')
    // //   ->leftJoin('za_course', 'za_lead.course_id', '=', 'za_course.sno')
    // //   ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
    // //   ->join('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
    // //   ->where('za_lead.status', '!=', 2)
    //   ->where('za_lead.sno', $id)
    //   ->orderBy('za_lead.sno', 'desc')
    //   ->first();

    $lead = LeadModel::select('za_lead.*', 'za_lead_type.lead_type_name', 'za_course.course_name', 'za_lead_type.sno as lead_type_id', 'za_lead_source.lead_source_name', 'za_lead_source.sno as lead_source_id')
      ->leftJoin('za_course', 'za_lead.course_id', '=', 'za_course.sno')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->where('za_lead.status', '!=', 2)
      ->where('za_lead.sno', $id)
      ->orderBy('za_lead.sno', 'desc')
      ->first();


    if ($lead && isset($lead->course_id)) {
      $lead->course_id = json_decode($lead->course_id);
    }

    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    // return $lead;
    // Ensure that the `lead_dob` exists before formatting
    if ($lead && !empty($lead->lead_dob)) {
      $lead->lead_dob = date($common_date_format, strtotime($lead->lead_dob));
    } else {
      $lead->lead_dob = null; // Fallback to current date if lead_dob is null or empty
    }
    if ($lead && !empty($lead->registered_date)) {
      $lead->registered_date = date($common_date_format, strtotime($lead->registered_date));
    } else {
      $lead->registered_date = date($common_date_format); // Fallback to current date if lead_dob is null or empty
    }


    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead,
    ], 200);
  }

  public function View($id)
  {
    // Fetch the lead data with necessary joins and fields
    $lead = LeadModel::select(
      'za_lead.*',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name',
      'za_states.name AS state_name',
      'za_cities.name AS city_name',
      'za_countries.name AS country_name'
    )
      ->leftJoin('za_course', 'za_lead.course_id', '=', 'za_course.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_countries', 'za_lead.country', '=', 'za_countries.id')
      ->leftJoin('za_states', 'za_lead.state', '=', 'za_states.id')
      ->leftJoin('za_cities', 'za_lead.city', '=', 'za_cities.id')
      ->where('za_lead.sno', $id)
      ->orderBy('za_lead.sno', 'desc')
      ->first();

    // Check if lead exists before proceeding
    if (!$lead) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'error_msg' => 'No lead data found for the given ID',
        'data'      => null,
      ], 404);
    }

    // Decode course_id if it's JSON and fetch course names
    if (!empty($lead->course_id)) {
      $courseIds = json_decode($lead->course_id, true); // Ensure we decode to an array

      if (is_array($courseIds)) {
        // Fetch course names based on IDs
        $courses = DB::table('za_course')
          ->whereIn('sno', $courseIds)
          ->pluck('course_name');

        $lead->course_names = $courses;
      } else {
        $lead->course_names = [];
      }
    }

    // return $lead;
    // Helper to format date
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

    // Format lead_dob if it exists, else use current date
    $lead->lead_dob = !empty($lead->lead_dob) ? date($common_date_format, strtotime($lead->lead_dob)) : date($common_date_format); // Fallback to current date if lead_dob is null or empty

    // Return response with the lead data
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead,
    ], 200);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|max:255',
      'lead_mobile' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name       = $request->lead_name;
      $lead_id       = $request->lead_id;
      $Know_tag = is_array($request->lead_Knowledge_edit_tag) ? json_encode($request->lead_Knowledge_edit_tag) : $request->lead_Knowledge_edit_tag;
      $course_id       = json_encode($request->course_id_edit);
      $lead_dob = isset($request->lead_dob) ? date('Y-m-d', strtotime($request->lead_dob)) : null;
      $lead_reg_date_up = isset($request->lead_reg_date_up) ? date('Y-m-d', strtotime($request->lead_reg_date_up)) : null;
      $upd_lead =  LeadModel::where('sno', $lead_id)->first();

      $chk = LeadModel::where('lead_name', ucwords($lead_name))->where('status', '!=', 2)->first();

      if ($chk) {
        if ($chk->sno != $lead_id) {
          $result = response([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has been  already assigned!',
            'data'      => null,

          ], 200);
        } else {
        }
      }

      $upd_lead->lead_name             = Ucfirst($lead_name);
      $upd_lead->lead_mobile           = $request->lead_mobile;
      $upd_lead->inter_calls           = $request->country_code_name_edit;
      $upd_lead->lead_alternate_mobile = $request->lead_alternate_mobile;
      $upd_lead->lead_email_id         = $request->lead_email_id;
      $upd_lead->lead_gender           = $request->lead_gender;
      $upd_lead->lead_dob              = $lead_dob;
      $upd_lead->registered_date       = $lead_reg_date_up;
      $upd_lead->lead_marital_status   = $request->lead_marital_status;
      $upd_lead->country               = $request->country_edit;
      $upd_lead->state                 = $request->state_edit;
      $upd_lead->city                  = $request->city_edit;
      $upd_lead->address               = $request->address;
      $upd_lead->course_id             = $course_id;
      $upd_lead->lead_source_id        = $request->lead_source_id_edit;
      $upd_lead->lead_type_id          = $request->lead_type_id_edit;
      $upd_lead->lead_question_id      = $request->lead_question_id;
      $upd_lead->lead_comments         = $request->lead_comments;
      $upd_lead->lead_condition          = 2; //new lead
      $upd_lead->lead_knowledge_tags     = $Know_tag;
      $upd_lead->update();


      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      // return $result;
    }

    return redirect('sales/manage_lead');
  }

  public function Update_raw(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name       = $request->lead_name;
      $lead_id       = $request->lead_id;
      $Know_tag = is_array($request->lead_Knowledge_edit_tag) ? json_encode($request->lead_Knowledge_edit_tag) : $request->lead_Knowledge_edit_tag;
      $course_id       = json_encode($request->course_id_edit);
      $lead_dob = isset($request->lead_dob) ? date('Y-m-d', strtotime($request->lead_dob)) : null;
      $lead_reg_date_up = isset($request->lead_reg_date_up) ? date('Y-m-d', strtotime($request->lead_reg_date_up)) : date('Y-m-d');
      $upd_lead =  LeadModel::where('sno', $lead_id)->first();

      $chk = LeadModel::where('lead_name', ucwords($lead_name))->where('status', '!=', 2)->first();

      if ($chk) {
        if ($chk->sno != $lead_id) {
          $result = response([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has been  already assigned!',
            'data'      => null,

          ], 200);
        } else {
        }
      }

      $upd_lead->lead_name             = Ucfirst($lead_name);
      $upd_lead->lead_mobile           = $request->lead_mobile;
      $upd_lead->lead_alternate_mobile = $request->lead_alternate_mobile;
      $upd_lead->lead_email_id         = $request->lead_email_id;
      $upd_lead->lead_gender           = $request->lead_gender;
      $upd_lead->lead_dob              = $lead_dob;
      $upd_lead->registered_date       = $lead_reg_date_up;
      $upd_lead->lead_marital_status   = $request->lead_marital_status;
      $upd_lead->country               = $request->country_edit;
      $upd_lead->state                 = $request->state_edit;
      $upd_lead->city                  = $request->city_edit;
      $upd_lead->address               = $request->address;
      $upd_lead->course_id             = $course_id;
      $upd_lead->lead_source_id        = $request->lead_source_id_edit;
      $upd_lead->lead_type_id          = $request->lead_type_id_edit;
      $upd_lead->lead_question_id      = $request->lead_question_id;
      $upd_lead->lead_comments         = $request->lead_comments;
      $upd_lead->lead_condition          = 2; //new lead
      $upd_lead->lead_knowledge_tags     = $Know_tag;
      $upd_lead->update();


      $branch_data = BranchModel::where('sno', $request->user()->branch_id)->first();
      $branch_name = " ";
      if ($branch_data->branch_type == 1) {
        $branch_name = $branch_data->branch_name;
      } elseif ($branch_data->branch_type == 2) {
        $branch_name = $branch_data->franchise_name;
      }

      $lead_name = $lead_name;
      $lead_mobile = $request->lead_mobile;
      $lead_email_id = $request->lead_email_id;
      // sms thank you lead
      // if ($upd_lead && $lead_mobile) {

      //     $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
      //     $authkey = $result_sms ? $result_sms->authkey : '';
      //     $sender_id = $result_sms ? $result_sms->sender_id : '';
      //     $template_id = $result_sms ? $result_sms->template_id : '';
      //     $country_code = $result_sms ? $result_sms->country_code : '';
      //     $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
      //     $mobile_number = $country_code . $lead_mobile;

      //     $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

      //     // Replace placeholders with actual values
      //     $replacement_values = [$lead_name, $cre_mobile];
      //     $message_content = preg_replace_callback(
      //         '/\{#var#\}/',
      //         function () use (&$replacement_values) {
      //             return array_shift($replacement_values);
      //         },
      //         $message_content
      //     );

      //     $route = "default";
      //     $postData = array(
      //         'authkey' => $authkey,
      //         'mobiles' => $mobile_number,
      //         'message' => $message_content,
      //         'sender' => $sender_id,
      //         'route' => $route,
      //     );

      //     // API URL
      //     $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

      //     // Initialize the resource
      //     $ch = curl_init();
      //     curl_setopt_array($ch, array(
      //         CURLOPT_URL => $url,
      //         CURLOPT_RETURNTRANSFER => true,
      //         CURLOPT_POST => true,
      //         CURLOPT_POSTFIELDS => $postData,
      //         CURLOPT_SSL_VERIFYHOST => 0,
      //         CURLOPT_SSL_VERIFYPEER => 0,
      //     ));

      //     // Get response
      //     $response = curl_exec($ch);
      //     // return $response;
      //     $err = curl_error($ch);
      //     curl_close($ch);
      // }
      // // Thank you email send
      // if ($upd_lead && $lead_email_id) {
      //     $email_template_id = 6; // thank you template
      //     $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

      //     $content = $emailTemplate->email_subject;
      //     $content = str_replace('#name', $lead_name??'Dear Mr/Mrs', $content);
      //     $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
      //     $branchNo = $branch_data->mobile??'9677781155';
      //     $branchemail = $branch_data->mail??'info@elysiumacademy.org';
      //     $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
      //     $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
      //     $content = str_replace('#salesNo', $branch_data->sales_mobile ?? '9677781155', $content);
      //     $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
      //     $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
      //     $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

      //     $mailData = [
      //         'url' => 'Eapl.com',
      //         'subject' => $emailTemplate->email_name,
      //         'content' => $content,
      //         'branchNo' => $branchNo,
      //         'branchemail' => $branchemail, // Use the message content from the request
      //         'fbLink' => $fbLink, // Use the message content from the request
      //         'instaLink' => $instaLink, // Use the message content from the request
      //         'salesMobile' => $branch_data->sales_mobile??'9677781155',
      //     ];

      //     $to_address = $lead_email_id;
      //     $from_address = 'elysiumacademy@elysium.community';
      //     $from_name = 'Elysium Academy速';
      //     Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
      // }
      //  // whatsapp message
      // if ($upd_lead && $lead_mobile) {
      //             $templateName = "elysium_academy_welcome_message";

      //             $hasHeader  = false; // Example flag: set based on template
      //             $hasBody    = false; // Example flag: set based on template
      //             $hasFooter  = false; // Example flag: set based on template
      //             $hasButton  = false;
      //             $components = [];
      //             $couponCode = " ";
      //             date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
      //             $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
      //                                                       // $currentHour = date('H'); // Get current hour in 24-hour format
      //             if ($currentHour >= 5 && $currentHour < 12) {
      //                 $greeting = 'Good Morning';
      //             } elseif ($currentHour >= 12 && $currentHour < 18) {
      //                 $greeting = 'Good Afternoon';
      //             } else {
      //                 $greeting = 'Good Evening';
      //             }

      //             if ($templateName == 'elysium_academy_welcome_message') {

      //                 $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
      //                 $couponCode  = 'NOOFFER';
      //                 $buttonIndex = 0;
      //                 $bodyText    = [
      //                     [
      //                         'type'           => 'text',
      //                         'text'           => $greeting,
      //                         'parameter_name' => 'greet_msg',
      //                     ],
      //                     [
      //                         'type'           => 'text',
      //                         'text'           => $lead_name,
      //                         'parameter_name' => 'customer_name',
      //                     ],
      //                     [
      //                         'type'           => 'text',
      //                         'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
      //                         'parameter_name' => 'web_link',
      //                     ],
      //                     [
      //                         'type'           => 'text',
      //                         'text'           => $branch_name??'Elysium Academy',
      //                         'parameter_name' => 'branch_name',
      //                     ],
      //                     [
      //                         'type'           => 'text',
      //                         'text'           => $branch_data->cre_mobile ?? '9677781155',
      //                         'parameter_name' => 'contact_no',
      //                     ],
      //                     [
      //                         'type'           => 'text',
      //                         'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
      //                         'parameter_name' => 'contact_email',
      //                     ],
      //                 ];
      //                 $hasHeader = true;
      //                 $hasBody   = true;
      //                 $hasButton = true;
      //             }

      //             // Add Header if required
      //             if ($hasHeader) {
      //                 $components[] = [
      //                     'type'       => 'header',
      //                     'parameters' => [
      //                         [
      //                             'type'  => 'image',
      //                             'image' => [
      //                                 'link' => $headerImage, // Dynamically set header image
      //                             ],
      //                         ],
      //                     ],
      //                 ];
      //             }

      //             // Add Body if required
      //             if ($hasBody) {
      //                 $components[] = [
      //                     'type'       => 'body',
      //                     'parameters' => $bodyText,
      //                 ];
      //             }

      //             // Add Footer if required
      //             if ($hasFooter) {
      //                 $components[] = [
      //                     'type'       => 'footer',
      //                     'parameters' => [
      //                         [
      //                             'type'           => 'text',
      //                             'text'           => 'This is the footer text.',
      //                             'parameter_name' => 'footer_text',
      //                         ],
      //                     ],
      //                 ];
      //             }

      //             // Add Button if required
      //             if ($hasButton) {
      //                 $components[] = [
      //                     'type'       => 'button',
      //                     'sub_type'   => 'copy_code',
      //                     'index'      => $buttonIndex,
      //                     'parameters' => [
      //                         [
      //                             'type'        => 'coupon_code',
      //                             'coupon_code' => $couponCode,
      //                         ],
      //                     ],
      //                 ];

      //             }

      //             $dynamicParameters         = $templateParameters[$templateName] ?? [];
      //             $WhatsAppBusinessAccountId = $this->businessId;
      //             $accessToken               = $this->accessToken;
      //             $fromPhoneNumberId         = $this->phoneNumberId;

      //             $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

      //             $to           = $lead_mobile;
      //             $languageCode = 'en_US';

      //             if (strpos($to, '+91') !== 0) {
      //                 $to = '+91' . $to;
      //             }

      //             $message = 'test~message';
      //             if (empty($components)) {
      //                 $payload = [
      //                     'messaging_product' => 'whatsapp',
      //                     'to'                => $to,
      //                     'type'              => 'template',
      //                     'template'          => [
      //                         'name'     => $templateName,
      //                         'language' => [
      //                             'code' => $languageCode,
      //                         ],
      //                     ],
      //                 ];
      //             } else {
      //                 $payload = [
      //                     'messaging_product' => 'whatsapp',
      //                     'to'                => $to,
      //                     'type'              => 'template',
      //                     'template'          => [
      //                         'name'       => $templateName,
      //                         'language'   => [
      //                             'code' => $languageCode,
      //                         ],
      //                         'components' => $components,
      //                     ],
      //                 ];
      //             }

      //             $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
      //         }


      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      // return $result;
    }

    return redirect('sales/manage_lead');
  }

  public function Leadchecklist(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required|max:255',
      'answers' => 'required'
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
      $lead_question_ids = $request->input('question_ids');
      $chk_li_question  = $request->input('chk_li_question');
      $answers = json_decode($request->input('answers'), true);
      $lead_score = $request->input('lead_score');
      $lead_id = $request->input('lead_id');
      $user_id              = $request->user()->user_id;
      $branch_id            = $request->user()->branch_id;

      $upd_lead = LeadModel::where('sno', $lead_id)->first();
      $upd_lead->lead_question_id = json_encode($lead_question_ids);
      $upd_lead->lead_score = $lead_score;
      $upd_lead->lead_answer = $answers;
      $upd_lead->lead_condition          = 2;
      $upd_lead->save();


      if ($upd_lead) {
        // Embed the lead_name directly in notification content
        $notificationData = [
          'branch_id' => $branch_id,
          'notification_content' => '
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <span class="badge bg-gray-300">
                                <i class="mdi mdi-account-multiple-outline fs-3 text-black"></i>
                            </span>
                        </div>
                        <div class="me-2">
                            <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
                            <div class="text-secondary fs-8 fw-semibold">' . $upd_lead->lead_name . ' - Checklist Completed</div>
                        </div>
                    </div>',
          'who' => $user_id,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'status' => 0
        ];
        $notificationtype = 'CheckList';
        $newNotification = new \App\Helpers\Helpers();

        $newNotification->createNotification($notificationData, $notificationtype);

        // Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        $pointsData = $newNotification->get_points_by_id(2);
        $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // Save new points for the staff
        $newPoints = new StaffpointsModel();
        $newPoints->branch_id = $branch_id;
        $newPoints->staff_id = $user_id;
        $newPoints->points_by = $lead_id;
        $newPoints->points_id = 2;
        $newPoints->points = $point;
        $newPoints->reason = $reason;
        $newPoints->save();

        // Update staff's available points
        $staff_points = StaffModel::where('sno', $user_id)->first();
        if ($staff_points) {
          $staff_points->avaiable_points += $point; // Increment the available points
          $staff_points->save();
        }
      }
      if ($upd_lead) {

        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Lead Checklist Added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Checklist !'
        ]);
      }
    }

    return redirect()->back();
  }

  public function Delete($id, Request $request)
  {

    $user_id              = $request->user()->user_id;
    $branch_id            = $request->user()->branch_id;
    $lead =  LeadModel::where('sno', $id)->first();
    $staff =  StaffModel::where('sno', $user_id)->first();
    $lead->status  = 2;
    $lead->Update();

    if ($lead) {
      // Embed the lead_name directly in notification content
      $notificationData = [
        'branch_id' => $branch_id,
        'notification_content' => '
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <span class="badge bg-gray-300">
                                <i class="mdi mdi-account-multiple-outline fs-3 text-black"></i>
                            </span>
                        </div>
                        <div class="me-2">
                            <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
                            <div class="text-secondary fs-8 fw-semibold"> Lead ' . $lead->lead_name . ' Dropped by ' . $staff->staff_name . '</div>
                        </div>
                    </div>',
        'who' => $user_id,
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'status' => 0
      ];
      $notificationtype = 'CheckList';
      $newNotification = new \App\Helpers\Helpers();

      $newNotification->createNotification($notificationData, $notificationtype);
    }
    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $lead =  LeadModel::where('sno', $id)->first();

    $lead->status = $request->status;
    // return  $lead;
    if ($request->status == 0) {
      $lead->lead_status_id = 1;
      $lead->spam_reason = null;
      $lead->drop_reason = null;
      $lead->spam_comments = null;
      $lead->drop_comments = null;
      $lead->update();
    }
    $lead->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function LeadStatus($id, Request $request)
  {

    $lead =  LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    $lead->status = $request->status;
    // return  $lead;
    if ($request->status == 4) {
      $lead->lead_status_id = 5;
      // Encryption happens here
      $encryptedLeadId = $helper->encrypt_decrypt($id, 'encrypt');

      // Return the encrypted value in the JSON response instead of redirecting
      return response()->json([
        'status' => 200,
        'message' => 'Successfully Status Updated!',
        'encryptedValue' => $encryptedLeadId // Send encrypted value back to JS
      ]);
    }

    $lead->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  // public function drop_reason(Request $request)
  // {
  //   // Return the incoming request object for debugging
  //   // return $request;

  //   $id = $request->lead_id_drop;
  //   $branch_id = $request->user()->branch_id;
  //   $staff_id = $request->staff_id_drop;
  //   $reason_edit = $request->reason_edit;
  //   $lead = LeadModel::where('sno', $id)->first();
  //   $helper = new \App\Helpers\Helpers();
  //   // return $id;
  //   // return $lead;
  //   if ($request) {
  //     if ($reason_edit == 1) {
  //       $lead->drop_reason = $request->drop_reason_text;
  //     } else {
  //       $drop = DropReasonModel::where('reason_name', $reason_edit)->first();
  //       // return $drop;
  //       if ($drop->comments_check == 1) {
  //         $lead->drop_comments = $request->drop_comments_text;
  //       }
  //       $lead->drop_reason = $reason_edit;
  //     }


  //     $lead->lead_status_id = 4;
  //     $lead->status = 5;
  //     // return $lead;
  //     $lead->update();
  //     // Define point category:
  //     // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
  //     $helper = new \App\Helpers\Helpers();
  //     $pointsData = $helper->get_points_by_id(13);
  //     $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
  //     $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
  //     // Save new points for the staff
  //     $newPoints = new StaffpointsModel();
  //     $newPoints->branch_id = $branch_id;
  //     $newPoints->staff_id = $staff_id;
  //     $newPoints->points_by = $lead->sno;
  //     $newPoints->points_id = 1;
  //     $newPoints->points = $point;
  //     $newPoints->reason = $reason;
  //     $newPoints->save();

  //     // Update staff's available points
  //     $staff_points = StaffModel::where('sno', $staff_id)->first();
  //     if ($staff_points) {
  //       $staff_points->avaiable_points += $point; // Increment the available points
  //       // return $staff_points;
  //       $staff_points->save();
  //     }
  //     //****************** */ Update Staff Sales Person Points

  //     $encryptedLeadId = $helper->encrypt_decrypt($id, 'encrypt');
  //   }
  //   if ($lead) {
  //     session()->flash('toastr', [
  //       'type' => 'success',
  //       'message' => 'Successfully Status Updated!'
  //     ]);
  //   }

  //   return redirect()->back();
  // }

  // public function spam_reason(Request $request)
  // {
  //   // Return the incoming request object for debugging
  //   // return $request;

  //   $id = $request->lead_id_spam;
  //   $spam_reason_edit = $request->spam_reason_edit;
  //   $lead = LeadModel::where('sno', $id)->first();
  //   $helper = new \App\Helpers\Helpers();


  //   if ($request) {
  //     if ($spam_reason_edit == 1) {
  //       $lead->spam_reason = $request->spam_reason_text;  // Set drop_reason from drop_reason_text
  //     } else {
  //       $spam = SpamReasonModel::where('reason_name', $spam_reason_edit)->first();
  //       // return $spam;
  //       if ($spam->comments_check == 1) {
  //         $lead->spam_comments = $request->spam_comments_text;
  //       }
  //       $lead->spam_reason = $spam_reason_edit;
  //     }
  //     $lead->lead_status_id = 6;
  //     $lead->status = 7;
  //     // return $lead;
  //     $lead->update();
  //     $encryptedLeadId = $helper->encrypt_decrypt($id, 'encrypt');
  //   }

  //   // Update the lead in the database
  //   $lead->update();

  //   if ($lead) {
  //     session()->flash('toastr', [
  //       'type' => 'success',
  //       'message' => 'Successfully Status Updated!'
  //     ]);
  //   }

  //   return redirect()->back();
  // }

  public function spam_reason(Request $request)
  {
    // Return the incoming request object for debugging
    // return $request;
    $id = $request->lead_id_spam;
    $spam_reason_edit = $request->spam_reason_edit;
    $lead = LeadModel::where('sno', $id)->first();
    if ($lead) {
      if ($spam_reason_edit == 1) {
        $lead->spam_reason = $request->spam_reason_text;  // Set drop_reason from drop_reason_text
      } else {
        $spam = SpamReasonModel::where('reason_name', $spam_reason_edit)->first();
        // return $spam;
        if ($spam->comments_check == 1) {
          $lead->spam_comments = $request->spam_comments_text;
        }
        $lead->spam_reason = $spam_reason_edit;
      }
      $user_id = $request->user()->user_id;
      // Close previous transfer history
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->whereNull('end_date')
        ->where('current_staff_id', $lead->created_by)
        ->first();

      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $lead->created_by;
        //$lead_history->transferred_from = 2; // spam transfer
        $lead_history->save();
      }

      // New transfer history entry
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d'); // new start date = today
      $add_history->current_staff_id = $lead->created_by ?? $user_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 2;
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save();

      $lead->lead_status_id = 6;
      $lead->transfer_status = 1;
      $lead->status = 7;
      // return $lead;

    }
    $lead->update();
    if ($lead) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    }

    return redirect()->back();
  }

  public function drop_reason(Request $request)
  {
    // Return the incoming request object for debugging
    // return $request;

    $id = $request->lead_id_drop;
    $branch_id = $request->user()->branch_id;
    $staff_id = $request->staff_id_drop;
    $reason_edit = $request->reason_edit;
    $lead = LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();
    // return $id;
    // return $lead;
    if ($request) {
      if ($reason_edit == 1) {
        $lead->drop_reason = $request->drop_reason_text;
      } else {
        $drop = DropReasonModel::where('reason_name', $reason_edit)->first();
        // return $drop;
        if ($drop->comments_check == 1) {
          $lead->drop_comments = $request->drop_comments_text;
        }
        $lead->drop_reason = $reason_edit;
      }

      $user_id = $request->user()->user_id;
      // Close previous transfer history
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->whereNull('end_date')
        ->where('current_staff_id', $lead->created_by)
        ->first();

      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $lead->created_by;
        // $lead_history->transferred_from = 3; // spam transfer
        $lead_history->save();
      }

      // New transfer history entry
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d'); // new start date = today
      $add_history->current_staff_id = $lead->created_by ?? $user_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 3;
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save();


      $lead->lead_status_id = 4;
      $lead->transfer_status = 1;
      $lead->status = 5;
      // return $lead;
      $lead->update();
      // Define point category:
      // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
      $helper = new \App\Helpers\Helpers();
      $pointsData = $helper->get_points_by_id(13);
      $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
      $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
      // Save new points for the staff
      $newPoints = new StaffpointsModel();
      $newPoints->branch_id = $branch_id;
      $newPoints->staff_id = $staff_id;
      $newPoints->points_by = $lead->sno;
      $newPoints->points_id = 1;
      $newPoints->points = $point;
      $newPoints->reason = $reason;
      $newPoints->save();

      // Update staff's available points
      $staff_points = StaffModel::where('sno', $staff_id)->first();
      if ($staff_points) {
        $staff_points->avaiable_points += $point; // Increment the available points
        // return $staff_points;
        $staff_points->save();
      }
      //****************** */ Update Staff Sales Person Points

      $encryptedLeadId = $helper->encrypt_decrypt($id, 'encrypt');
    }
    if ($lead) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    }

    return redirect()->back();
  }

  public function internal_reason(Request $request)
  {
    // Return the incoming request object for debugging


    $id = $request->lead_id_internal;
    // return $id;
    $reason_internal_select = $request->reason_internal_select;
    $lead = LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    if ($request) {
      if ($request->reason_internal_select == 1) {
        $lead->internal_reason = $request->internal_reason_text;
      } else {
        $internal = InternalReasonModel::where('reason_name', $reason_internal_select)->first();
        // return $spam;
        if ($internal->comments_check == 1) {
          $lead->internal_comments = $request->internal_comments_text;
        }
        $lead->internal_reason = $reason_internal_select;
      }
      $lead->internal_status = 1;
      // return $lead;
      $lead->update();
      $encryptedLeadId = $helper->encrypt_decrypt($id, 'encrypt');
    }

    // Update the lead in the database
    $lead->update();

    if ($lead) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Converted Successfully!'
      ]);
    }

    return redirect()->back();
  }



  public function Appointment(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'appointment_date' => 'required|max:255',
      'lead_id' => 'required'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      // return $request;
      $lead_id                  = $request->lead_id;
      // $appointment_date         = $request->appointment_date;
      $appointment_time         = $request->appointment_time;

      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);

      $user_id            = $request->user()->user_id;
      $branch_id          = $request->user()->branch_id;
      // $chk = LeadModel::where('lead_id', $lead_id)->where('status', '!=', 2)->first();

      // if ($chk) {
      //   session()->flash('toastr', [
      //     'type' => 'error',
      //     'message' => 'Name has been  already created!'
      //   ]);
      // } else {
      // return $request;

      $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


      if (!$category_check) {

        $year = substr(date("y"), -2);
        $appointment_id = "AP-0001/" . $year;
      } else {

        $data = $category_check->appointment_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request = sprintf("AP-%04d", $next_number);

        $year = substr(date("y"), -2);
        $appointment_id = $request . '/' . $year;
      }


      $add_category = new AppointmentModel();
      $add_category->appointment_id          = $appointment_id;
      $add_category->lead_id                 = $lead_id;
      $add_category->appointment_date        = $appointment_date;
      $add_category->appointment_time        = $appointment_time;
      $add_category->branch_id               = $branch_id;
      $add_category->status                  = 1;
      $add_category->created_by              = $user_id;
      $add_category->updated_by              = $user_id;


      $add_category->save();
      if ($add_category) {
        $lead =  LeadModel::where('sno', $lead_id)->first();
        $lead->lead_status_id          = 2; //followup lead
        $lead->update();

        // Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(3);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $lead_id;
        // $newPoints->points_id = 3;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();

        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
      }

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Appointment added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Appointment!'
        ]);
      }
      // }
      // return $result;
      return redirect('sales/manage_lead');
    }
  }

  public function AppointmentEdit($id)
  {
    // Fetch the latest appointment details for a specific lead_id
    $latestAppointment = AppointmentModel::select('za_appointment.*', 'za_lead.lead_name', 'za_lead.sno as lead_id')
      ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
      ->whereNotIn('za_appointment.status', [2])
      ->where('za_appointment.lead_id', $id)
      ->orderBy('za_appointment.sno', 'desc')
      ->first();

    $appointmentCount = AppointmentModel::where('lead_id', $id)
      ->whereNotIn('status', [2])
      ->count();

    // Fetch historical lead_id values excluding the current $id
    // $historicalLeadIds = AppointmentModel::select('za_appointment.*')
    //   ->where('lead_id', $id)
    //     ->whereNotIn('status', [2])
    //   ->orderBy('za_appointment.sno', 'desc')
    //   ->get();

    $historicalLeadIds = AppointmentModel::select('za_appointment.*', 'za_staff.staff_name')
      ->join('za_staff', 'za_appointment.created_by', '=', 'za_staff.sno')
      ->where('za_appointment.lead_id', $id)
      ->where('za_appointment.status', '!=', 2)
      ->orderBy('za_appointment.sno', 'desc')
      ->get();

    // Extract appointment_date and appointment_time from the latest appointment
    $appointment_date = null;
    $appointment_time = null;
    if ($latestAppointment) {
      $appointment_date = $latestAppointment->appointment_date;
      $appointment_time = $latestAppointment->appointment_time;
    }

    // Include previous appointment date and time in historicalLeadIds
    $historicalLeadIds = $historicalLeadIds->map(function ($appointment, $key) use ($id) {
      // Fetch the previous appointment by skipping the current one
      $previousAppointment = AppointmentModel::select('za_appointment.*')
        ->where('lead_id', $id)
        ->whereNotIn('status', [2])
        ->where('sno', '<', $appointment->sno)
        ->orderBy('sno', 'desc')
        ->first();

      $appointment->previous_appointment_date = $previousAppointment ? $previousAppointment->appointment_date : null;
      $appointment->previous_appointment_time = $previousAppointment ? $previousAppointment->appointment_time : null;

      return $appointment;
    });

    $lead_reschedule_count  = DB::table('za_appointment')
      ->where('lead_id', $id)
      ->where('status', 5)
      ->count();

    return response()->json([
      'status'    => 200,
      'message'   => 'Appointment details fetched successfully',
      'data'      => [
        'appointment_date' => $appointment_date,
        'appointment_time' => $appointment_time,
        'appointmentCount' => $appointmentCount,
        'latestAppointment' => $latestAppointment,
        'historicalLeadIds' => $historicalLeadIds,
        'lead_reschedule_count' => $lead_reschedule_count,
      ]
    ], 200);
  }

  public function AppointmentUpdate($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'progressed' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      //   return $request;
      $progressed       = $request->progressed;
      $reason_appt      = $request->reason;
      $appointment_time       = $request->appointment_time;
      $app_score          = $request->app_score;
      $hot_lead            = $request->hot_lead;
      $user_id            = $request->user()->user_id;
      $branch_id            = $request->user()->branch_id;
      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
      if ($progressed == 1) {
        $upd_lead =  AppointmentModel::where('lead_id', $id)->orderBy('sno', 'desc')->first();

        $upd_lead->progressed                 = $progressed;
        $upd_lead->app_score                  = $request->app_score;
        $upd_lead->convo_message              = $request->convo_message;
        $upd_lead->status                     = 4;
        // return $upd_lead;
        $upd_lead->update();
        //****************** */ Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(4);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $id;
        // $newPoints->points_id = 4;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();

        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
        //****************** */ Update Staff Sales Person Points
        // if ($hot_lead == 1) {
        //   $lead =  LeadModel::where('sno', $id)->first();
        //   $lead->lead_status_id          = 3; //Hot lead
        //   $lead->update();
        // }
      } else {
        $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        if (!$category_check) {

          $year = substr(date("y"), -2);
          $appointment_id = "AP-0001/" . $year;
        } else {

          $data = $category_check->appointment_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("AP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $appointment_id = $request . '/' . $year;
        }

        $upd_app = AppointmentModel::where('lead_id', $id)
          ->where('status', 1)
          ->where(function ($query) {
            $query->whereNull('progressed')
              ->orWhere('progressed', 2);
          })
          ->orderBy('sno', 'desc')
          ->first();

        if ($upd_app) {
          $upd_app->status = 5;
          $upd_app->update();
        }



        $upd_lead = new AppointmentModel();
        $upd_lead->appointment_id           = $appointment_id;
        $upd_lead->lead_id                  = $id;
        $upd_lead->branch_id                = $branch_id;
        $upd_lead->progressed               = $progressed;
        $upd_lead->app_score                = $app_score;
        $upd_lead->reason                   = $reason_appt;
        $upd_lead->appointment_date         = $appointment_date;
        $upd_lead->appointment_time         = $appointment_time;
        $upd_lead->status                   = 1;
        $upd_lead->created_by               = $user_id;
        $upd_lead->updated_by               = $user_id;
        //  return $upd_lead;
        $upd_lead->save();


        // $upd_app =  AppointmentModel::where('lead_id', $id)->whereIN('progressed', [null,2])->where('status', 1)->orderBy('sno', 'desc')->first();
        // if($upd_app){
        //     $upd_app->status = 5;
        //     $upd_app->update();
        // // }

        //****************** */ Update Staff Sales Person Points
        // Define point category:
        // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
        // $helper = new \App\Helpers\Helpers();
        // $pointsData = $helper->get_points_by_id(3);
        // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
        // // Save new points for the staff
        // $newPoints = new StaffpointsModel();
        // $newPoints->branch_id = $branch_id;
        // $newPoints->staff_id = $user_id;
        // $newPoints->points_by = $id;
        // $newPoints->points_id = 3;
        // $newPoints->points = $point;
        // $newPoints->reason = $reason;
        // $newPoints->save();

        // // Update staff's available points
        // $staff_points = StaffModel::where('sno', $user_id)->first();
        // if ($staff_points) {
        //   $staff_points->avaiable_points += $point; // Increment the available points
        //   $staff_points->save();
        // }
        //****************** */ Update Staff Sales Person Points

        // if ($hot_lead == 1) {
        //   $lead =  LeadModel::where('sno', $id)->first();
        //   $lead->lead_status_id          = 3; //Hot lead
        //   $lead->update();
        // }
      }
      //   if ($upd_lead) {
      //         // Embed the lead_name directly in notification content
      //         $notificationData = [
      //             'branch_id' => $branch_id,
      //             'notification_content' => '
      //                 <div class="d-flex align-items-center">
      //                     <div class="me-3">
      //                         <span class="badge bg-gray-300">
      //                             <i class="mdi mdi-account-multiple-outline fs-3 text-black"></i>
      //                         </span>
      //                     </div>
      //                     <div class="me-2">
      //                         <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
      //                         <div class="text-secondary fs-8 fw-semibold">' . $upd_lead->lead_name . ' - Checklist Not Completed</div>
      //                     </div>
      //                 </div>',
      //             'who' => $user_id,
      //             'created_by' => $user_id,
      //             'updated_by' => $user_id,
      //             'status' => 0
      //         ];
      //         $notificationtype = 'CheckList';
      //         $newNotification = new \App\Helpers\Helpers();

      //         $newNotification->createNotification($notificationData, $notificationtype);
      //     }
      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }

  public function AppointmentList($id)
  {
    $lead = AppointmentModel::select('za_appointment.*', 'za_lead.lead_name', 'za_lead.sno as lead_id')
      ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
      ->where('za_appointment.status', '!=', 2)
      ->where('za_appointment.lead_id', $id)
      ->orderBy('za_appointment.sno', 'desc')
      ->first();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead
    ], 200);
  }

  public function LeadImport(Request $requestData)
  {
    $validator = Validator::make($requestData->all(), [
      'file_import' => 'required|file|mimes:xls,xlsx|max:5120',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->all(),
        'data' => null,
      ], 400);
    }

    $file_import = $requestData->file('file_import');
    $lead_source_id = $requestData->input('lead_source_id');
    $lead_group = $requestData->input('lead_group');

    // Check if the lead group already exists
    // $chk = RawLeadModel::where('lead_group', $lead_group)->where('status', '!=', 2)->first();
    // if ($chk) {
    //   return response()->json([
    //     'status' => 'error',
    //     'message' => 'Group name already exists!',
    //     'error_msg' => ['Group name already exists!'],
    //   ], 207);
    // }

    $data = Excel::toCollection(new RawLeadModel, $file_import);
    // return $data;
    if ($data->isEmpty() || $data[0]->isEmpty()) {
      return response()->json([
        'status' => 401,
        'message' => 'The uploaded file is empty.',
        'error_msg' => ['The uploaded file is empty.'],
        'data' => null,
      ], 400);
    }

    $errors = [];
    $successfulImports = 0;
    $branch_data = BranchModel::where('sno', $requestData->user()->branch_id)->first();
    $branch_name = " ";
    if ($branch_data->branch_type == 1) {
      $branch_name = $branch_data->branch_name;
    } elseif ($branch_data->branch_type == 2) {
      $branch_name = $branch_data->franchise_name;
    }


    foreach ($data[0] as $key => $row) {
      if ($key > 0) {  // Skip the header row

        $lead_name = $row[0];
        $lead_mobile = $row[1];
        $lead_date     = $row[2];

        if (empty($lead_name) || empty($lead_mobile) || empty($lead_date)) {
          $errors[] = 'Missing required field in row ' . ($key + 1);
          continue;
        }

        $lead_date_raw = $row[2];

        // Determine if the date is an Excel numeric timestamp
        if (is_numeric($lead_date_raw)) {
          $lead_date = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($lead_date_raw)->format('Y-m-d');
        } else {
          // Try to parse as a normal date string
          try {
            $lead_date = date('Y-m-d', strtotime($lead_date_raw));
          } catch (\Exception $e) {
            $errors[] = 'Row ' . ($key + 1) . ': Invalid date format';
            continue;
          }
        }

        // if (is_numeric($lead_date)) {
        //   $lead_date = Date::excelToDateTimeObject($lead_date)->format('Y-m-d');
        // }

        if (isset($lead_date)) {
          $lead_date = date('Y-m-d', strtotime($lead_date));
        } else {
          $lead_date = date('Y-m-d');
        }

        // $lead_mobile = str_replace(' ', '', $lead_mobile);


        // Convert encoding to remove hidden characters
        $lead_mobile = mb_convert_encoding($lead_mobile, 'UTF-8', 'UTF-8');

        // Remove all non-numeric characters (including hidden spaces and special chars)
        $lead_mobile = preg_replace('/\D/', '', $lead_mobile);



        // Check for existing mobile number
        $chk = RawLeadModel::where('lead_mobile', $lead_mobile)->first();
        if ($chk) {
          $errors[] = 'Row ' . ($key + 1) . ': Mobile number ' . $lead_mobile . ' already exists!';
          continue;
        }

        // Generate new lead ID
        $branch_check = BranchModel::where('sno', $requestData->user()->branch_id)->first();
        $branch_code = $branch_check->city_short_code;

        $category_check = RawLeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "RL0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = $year . '/' . $branch_code . '/' . sprintf("RL%04d", $next_number);
        }

        $user_id = $requestData->user()->user_id;
        $branch_id = $requestData->user()->branch_id;

        // Create new lead
        $new_lead = new RawLeadModel();
        $new_lead->lead_id = $lead_id;
        $new_lead->lead_name = $lead_name;
        $new_lead->lead_mobile = $lead_mobile;
        $new_lead->lead_source_id = $lead_source_id;
        $new_lead->lead_group = $lead_group;
        $new_lead->registered_date = $lead_date;
        $new_lead->status = 6;
        $new_lead->branch_id = $branch_id;
        $new_lead->created_by = $user_id;
        $new_lead->updated_by = $user_id;

        // return $new_lead;

        if ($new_lead->save()) {
          $successfulImports++;

          //   if ($lead_mobile) {
          //     $templateName = 'elysium_academy_first_offer_erp';
          //     $components   = [];
          //     date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
          //     $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
          //                                               // $currentHour = date('H'); // Get current hour in 24-hour format
          //     if ($currentHour >= 5 && $currentHour < 12) {
          //         $greeting = 'Good Morning';
          //     } elseif ($currentHour >= 12 && $currentHour < 18) {
          //         $greeting = 'Good Afternoon';
          //     } else {
          //         $greeting = 'Good Evening';
          //     }

          //     $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Discount3.jpg';
          //     $bodyText    = [
          //         [
          //             'type'           => 'text',
          //             'text'           => $greeting,
          //             'parameter_name' => 'greet_msg',
          //         ],
          //         [
          //             'type'           => 'text',
          //             'text'           => $lead_name,
          //             'parameter_name' => 'customer_name',
          //         ],
          //         [
          //             'type'           => 'text',
          //             'text'           => $lead_mobile,
          //             'parameter_name' => 'contact_no',
          //         ],
          //         [
          //             'type'           => 'text',
          //             'text'           => $branch_data->website,
          //             'parameter_name' => 'web_url',
          //         ],
          //         [
          //             'type'           => 'text',
          //             'text'           => $branch_name,
          //             'parameter_name' => 'branch_name',
          //         ],
          //         [
          //             'type'           => 'text',
          //             'text'           => $branch_data->sales_mobile ?? '9677781155',
          //             'parameter_name' => 'sale_contact_no',
          //         ],
          //         [
          //             'type'           => 'text',
          //             'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
          //             'parameter_name' => 'sale_contact_email',
          //         ],
          //     ];

          //     $components[] = [
          //         'type'       => 'header',
          //         'parameters' => [
          //             [
          //                 'type'  => 'image',
          //                 'image' => [
          //                     'link' => $headerImage, // Dynamically set header image
          //                 ],
          //             ],
          //         ],
          //     ];

          //     $components[] = [
          //         'type'       => 'body',
          //         'parameters' => $bodyText,
          //     ];

          //     $dynamicParameters         = $templateParameters[$templateName] ?? [];
          //     $WhatsAppBusinessAccountId = $this->businessId;
          //     $accessToken               = $this->accessToken;
          //     $fromPhoneNumberId         = $this->phoneNumberId;

          //     $apiUri       = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
          //     $to           = $lead_mobile;
          //     $languageCode = 'en';

          //     if (strpos($to, '+91') !== 0) {
          //         $to = '+91' . $to;
          //     }

          //     $message = 'test~message';
          //     $payload = [
          //         'messaging_product' => 'whatsapp',
          //         'to'                => $to,
          //         'type'              => 'template',
          //         'template'          => [
          //             'name'       => $templateName,
          //             'language'   => [
          //                 'code' => $languageCode,
          //             ],
          //             'components' => $components,
          //         ],
          //     ];

          //     $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

          // }

        } else {
          $errors[] = 'Row ' . ($key + 1) . ': Could not import the lead ' . $lead_name . '!';
        }
      }
    }

    $responseMessage = $successfulImports . ' lead(s) imported successfully.';

    if (!empty($errors)) {
      return response()->json([
        'status' => 'partial_success',
        'message' => $responseMessage,
        'error_msg' => $errors,
      ], 207);
    }

    return response()->json([
      'status' => 'success',
      'message' => $responseMessage,
      'data' => null,
    ], 200);
  }

  public function CustomerConvert(Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }

    $lead_id = $request->lead_id;

    // Fetch lead details
    $upd_lead = LeadModel::where('sno', $lead_id)->first();
    if (!$upd_lead) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'data'      => null,
      ], 404);
    }

    // Prepare customer data
    $customerData = [
      'lead_id'                => $lead_id,
      'cus_name'               => ucfirst($upd_lead->lead_name),
      'cus_mobile'             => $upd_lead->lead_mobile,
      'cus_alternate_mobile'   => $upd_lead->lead_alternate_mobile,
      'cus_email_id'           => $upd_lead->lead_email_id,
      'cus_gender'             => $upd_lead->lead_gender,
      'cus_dob'                => $upd_lead->lead_dob,
      'cus_marital_status'     => $upd_lead->lead_marital_status,
      'country'                => $upd_lead->country,
      'state'                  => $upd_lead->state,
      'city'                   => $upd_lead->city,
      'address'                => $upd_lead->address,
      'branch_id'              => $request->user()->branch_id,
      'created_by'             => $request->user()->user_id,
      'updated_by'             => $request->user()->user_id,
      'status'                 => 2, // Assuming status = 2 for a new customer
    ];

    // Update or create the customer record
    CustomerModel::updateOrCreate(
      ['lead_id' => $lead_id], // Match condition
      $customerData            // Data to update or insert
    );

    if ($customerData) {
      $chk_cus_details = ContactDetailsModel::where('mobile_no', $customerData['cus_mobile'])
        ->where('name', $customerData['cus_name'])
        ->first();


      $pointsDataFullAttendance = $helper->get_points_by_id(24);

      // Get points and reason for full attendance
      $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
      $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

      // Save new points for the student (full attendance)
      $newPointsFull = new StudentpointsModel();
      $newPointsFull->branch_id = $customerData['branch_id'];
      $newPointsFull->student_id = $chk_cus_details->referral_by ?? 0;
      $newPointsFull->points_id = 24;
      $newPointsFull->points = $pointFull;
      $newPointsFull->reason = $reasonFull;

      // return $newPointsFull;
      $newPointsFull->save();

      // Update the student's available points in the CustomerModel
      $student_points = CustomerModel::where('lead_id', $chk_cus_details->referral_by ?? 0)->first();

      if ($student_points) {
        $student_points->points_score += $pointFull;
        $student_points->save();
      }
    }


    $encrypted_values = $helper->encrypt_decrypt($lead_id . '~' . '1', 'encrypt');
    return redirect()->route('customer_add', ['id' => $encrypted_values]);
  }

  public function bulk_raw_lead_conversion(Request $request)
  {
    $checked = $request->checked;
    $lead_source_id = $request->bulk_lead_source_id;
    $assign_staff_id = $request->bulk_assign_staff_id;
    $user_id = $request->user()->user_id;
    $count = isset($checked) ? count($checked) : 0;
    if (isset($checked) && !empty($checked)) {
      $success = true; // Flag for successful lead conversion

    //   foreach ($checked as $id) {
    //     $raw_lead = RawLeadModel::where('sno', $id)->first();
    //     // return $raw_lead;

    //     if ($raw_lead) {
    //       // Get the branch information
    //       $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

    //       if (!$branch_check) {
    //         return response([
    //           'status' => 400,
    //           'message' => 'Branch not found.',
    //           'error_msg' => 'Invalid branch ID.',
    //           'data' => null
    //         ], 400);
    //       }

    //       $branch_code = $branch_check->city_short_code;

    //       // Generate lead ID
    //       $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    //       $year = date("Y");

    //       if (!$category_check) {
    //         $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
    //       } else {
    //         $data = $category_check->lead_id;
    //         $slice = explode("/", $data);
    //         $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
    //         $next_number = (int)$resultcus + 1;
    //         $request_pay = sprintf("LED%04d", $next_number);
    //         $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
    //       }
          
    //     $chk = LeadModel::where('lead_mobile', $raw_lead->lead_mobile)->first();
    //     if ($chk) {
    //         continue; // Skip if duplicate
    //     }

    //       // Create new lead
    //       $add_category = new LeadModel();
    //       $add_category->lead_id = $lead_id;
    //       $add_category->lead_name = ucfirst($raw_lead->lead_name);
    //       $add_category->lead_mobile = $raw_lead->lead_mobile;
    //       $add_category->lead_source_id = $lead_source_id;
    //       $add_category->lead_group = $raw_lead->lead_group;
    //       $add_category->created_by = $assign_staff_id; // Same for updated_by
    //       $add_category->branch_id = $branch_check->sno; // Correct branch ID
    //       $add_category->updated_by = $user_id; // Same for updated_by
    //       $add_category->lead_status_id = 1; // new lead
    //       $add_category->lead_condition = 1; // standard lead
    //       // return $add_category;
    //       if (!$add_category->save()) {
    //         $success = false; // Mark as unsuccessful if save fails
    //       }
    //       $add_history = new LeadTransferLogModel();
    //       $add_history->lead_id = $add_category->sno;
    //       $add_history->branch_id = $add_category->branch_id;
    //       $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
    //       $add_history->current_staff_id = $add_category->created_by;
    //       $add_history->change_staff_id = 0;
    //       $add_history->transferred_from = 5; // from Bulk transfer
    //       $add_history->created_by = $user_id;
    //       $add_history->updated_by = $user_id;
    //       // return $add_history;
    //       $add_history->save();
    //       // Update raw lead status
    //       //   $staff = StaffModel::where('sno', $add_category->created_by)->first();
    //       //   if ($staff) {
    //       //     $staff->actual_lead_count += 1;
    //       //     $staff->original_lead_count += 1;
    //       //     // return $staff;
    //       //     $staff->save();
    //       //   }

    //       // Update raw lead status
    //       $raw_lead->status = 2;
    //       $raw_lead->save(); // Save changes to raw lead
    //     }
    //   }
    
    foreach ($checked as $id) {
    $raw_lead = RawLeadModel::find($id);

    if (!$raw_lead) {
        continue; // Skip if raw lead not found
    }

    // Get the branch information
    $branch_check = BranchModel::find($request->user()->branch_id);

    if (!$branch_check) {
        return response([
            'status' => 400,
            'message' => 'Branch not found.',
            'error_msg' => 'Invalid branch ID.',
            'data' => null
        ], 400);
    }

    $branch_code = $branch_check->city_short_code;

    // Generate lead ID
    $last_lead = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    $year = date("Y");

    if (!$last_lead) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
    } else {
        $slice = explode("/", $last_lead->lead_id);
        $number = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$number + 1;
        $lead_id = $year . '/' . $branch_code . '/' . sprintf("LED%04d", $next_number);
    }

    // Check for duplicate lead mobile
    $chk = LeadModel::where('lead_mobile', $raw_lead->lead_mobile)->first();
    if ($chk) {
        continue; // Skip if duplicate
    }

    // Create new lead
    $new_lead = new LeadModel();
    $new_lead->lead_id = $lead_id;
    $new_lead->lead_name = ucfirst($raw_lead->lead_name);
    $new_lead->lead_mobile = $raw_lead->lead_mobile;
    $new_lead->lead_source_id = $lead_source_id;
    $new_lead->lead_group = $raw_lead->lead_group;
    $new_lead->created_by = $assign_staff_id;
    $new_lead->branch_id = $branch_check->sno;
    $new_lead->updated_by = $user_id;
    $new_lead->lead_status_id = 1;
    $new_lead->lead_condition = 1;

    if (!$new_lead->save()) {
        $success = false; // Mark as unsuccessful
        continue; // Skip history creation if lead save fails
    }

    // Add history log
    $history = new LeadTransferLogModel();
    $history->lead_id = $new_lead->sno;
    $history->branch_id = $new_lead->branch_id;
    $history->start_date = $new_lead->created_at->format('Y-m-d');
    $history->current_staff_id = $new_lead->created_by;
    $history->change_staff_id = 0;
    $history->transferred_from = 5; // from Bulk transfer
    $history->created_by = $user_id;
    $history->updated_by = $user_id;
    $history->save();

    // Update raw lead status
    $raw_lead->status = 2;
    $raw_lead->save();
}

      // Set flash message based on success flag
      if ($success) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => $count . ' Leads Converted Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add some leads conversion!'
        ]);
      }
    }

    return redirect('sales/manage_lead');
  }

  // Raw Lead Bulk Conversion
  public function showTemplates()
  {
    $templates = $this->doubletickService->getWhatsAppTemplates($this->businessId, $this->accessToken);

    $formattedData = isset($templates['data']) ? $templates['data'] : [];

    // Filter only the templates with "status": "APPROVED"
    $approvedTemplates = array_filter($formattedData, function ($template) {
      return isset($template['status']) && $template['status'] === 'APPROVED';
    });

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => array_values($approvedTemplates),
    ], 200);
  }

  public function ConvertRawtoLead($id, Request $request)
  {
    // return $id;

    $raw_lead = RawLeadModel::where('sno', $id)->first();

    $lead_source_id = $request->lead_source_id;
    $assign_staff_id = $request->assg_staff_add;
    $user_id  = $request->user()->user_id;

    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status'    => 400,
          'message'   => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data'      => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id                 = $lead_id;
      $add_category->lead_name               = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile             = $raw_lead->lead_mobile;
      $add_category->lead_source_id          = $raw_lead->lead_source_id;
      $add_category->lead_group              = $raw_lead->lead_group;
      $add_category->lead_source_id          = $lead_source_id;
      $add_category->created_by              = $assign_staff_id; // Same for updated_by
      $add_category->branch_id               = $branch_check->sno; // Ensure correct branch ID
      $add_category->updated_by              = $request->user()->id; // Same for updated_by
      $add_category->lead_status_id          = 1; // new lead
      $add_category->lead_condition          = 1; // standard lead
      $add_category->save();

      if ($add_category) {

        // Update raw lead status
        $raw_lead->status = 2;
        $raw_lead->save(); // Save the changes to the raw lead

        $add_history = new LeadTransferLogModel();
        $add_history->lead_id = $add_category->sno;
        $add_history->branch_id = $add_category->branch_id;
        $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
        $add_history->current_staff_id = $add_category->created_by;
        $add_history->change_staff_id = 0;
        $add_history->transferred_from = 4; // from Bulk transfer
        $add_history->created_by = $user_id;
        $add_history->updated_by = $user_id;
        // return $add_history;
        $add_history->save();

        //   return $add_history;

      }

      return response([
        'status'    => 200,
        'message'   => 'Successfully converted the Raw Lead!',
        'error_msg' => null,
        'data'      => [
          'lead_id' => $add_category->sno, // Return new lead ID
        ]
      ], 200);
    }

    return response([
      'status'    => 404,
      'message'   => 'Raw lead not found.',
      'error_msg' => null,
      'data'      => null
    ], 404);
  }

  public function AppointmentHistory($id)
  {
    // Fetch the latest appointment details for a specific lead_id
    $latestAppointment = LeadAppointmentModel::select('za_lead_appointment.*', 'za_lead.lead_name', 'za_lead.sno as lead_id')
      ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
      ->where('za_lead_appointment.status', '!=', 2)
      ->where('za_lead_appointment.lead_id', $id)
      ->orderBy('za_lead_appointment.sno', 'desc')
      ->first();

    $appointmentCount = LeadAppointmentModel::where('lead_id', $id)
      ->where('status', '!=', 2)
      ->count();


    // Fetch historical lead_id values excluding the current $id
    $historicalLeadIds = LeadAppointmentModel::select('za_lead_appointment.*')
      ->where('lead_id', $id)
      ->where('status', '!=', 2)
      ->orderBy('za_lead_appointment.sno', 'desc')
      ->get();

    // Extract appointment_date and appointment_time from the latest appointment
    $appointment_date = null;
    $appointment_time = null;
    if ($latestAppointment) {
      $appointment_date = $latestAppointment->appointment_date ? date('Y-m-d', strtotime($latestAppointment->appointment_date)) : null;
      $appointment_time = $latestAppointment->appointment_date ? date('H:i:s', strtotime($latestAppointment->appointment_date)) : null;
    }

    // Include previous appointment date and time in historicalLeadIds
    $historicalLeadIds = $historicalLeadIds->map(function ($appointment, $key) use ($id) {
      // Fetch the previous appointment by skipping the current one
      $previousAppointment = LeadAppointmentModel::select('za_lead_appointment.*')
        ->where('lead_id', $id)
        ->where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->first();

      $appointment->previous_appointment_date =  $previousAppointment ? date('Y-m-d', strtotime($previousAppointment->appointment_date)) : null;
      $appointment->previous_appointment_time =  $previousAppointment ? date('H:i:s', strtotime($previousAppointment->appointment_date)) : null;

      return $appointment;
    });

    return response()->json([
      'status'    => 200,
      'message'   => 'Appointment details fetched successfully',
      'data'      => [
        'appointment_date' => $appointment_date,
        'appointment_time' => $appointment_time,
        'appointmentCount' => $appointmentCount,
        'latestAppointment' => $latestAppointment,
        'historicalLeadIds' => $historicalLeadIds
      ]
    ], 200);
  }

 public function LeadMessage(Request $request)
  {
    // Validate the incoming request data
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required|exists:za_lead,sno',
      // 'message' => 'required|string|max:500', // Adjust max length as needed
      'email'    => 'boolean',
      'sms'     => 'boolean',
      'whatsapp' => 'boolean'
    ]);

    // If validation fails, return a response with errors
    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }
    $branch_id = $request->user()->branch_id;
    $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

    $branch_name = " ";
    if ($branchData->branch_type == 1) {
      $branch_name = $branchData->branch_name;
    } elseif ($branchData->branch_type == 2) {
      $branch_name = $branchData->franchise_name;
    }

    // Extract the validated data
    $lead_id  = $request->lead_id;
    $email     = $request->email;
    $whatsapp_temp_id = $request->whatsapp_temp_id;
    $email_template_id = $request->email_template_id;
    $sms      = $request->sms;
    $whatsapp = $request->whatsapp;
    $message  = $request->message;
    $user_id  = $request->user()->user_id;


    // return $request;
    // Find the lead based on lead_id
    $lead = LeadModel::where('sno', $lead_id)
      ->first();

    // If the lead is not found, return an error response
    if (!$lead) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'error_msg' => 'The lead with the given ID does not exist',
        'data'      => null,
      ], 200);
    }

    $decode = json_decode($lead->course_id, true); // Ensure that $decode is an array

    // // Check if the decoded value is an array
    // if (is_array($decode)) {
    //   $course_ids = $decode; // $decode is already an array, no need to use explode
    // } else {
    //   // Handle the case where course_id is not a valid array
    //   return response([
    //     'status'  => 400,
    //     'message' => 'Invalid course_id format',
    //     'data'    => null,
    //   ], 200);
    // }
    // course_id = ["31"]
    // return $course_ids;
     $course_ids =['31'];

    // return $content;
    // here i need to do action
    $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
    $batch_details = BatchModel::where('sno', 34)->orderBy('sno', 'desc')->first();
    $slot = SlotModel::where('sno', $batch_details->slot_id)->orderBy('sno', 'desc')->first();
    $staff = StaffModel::where('sno', $batch_details->staff_id)->orderBy('sno', 'desc')->first();

    $cre = StaffModel::where('sno', $branch->cre_id)->orderBy('sno', 'desc')->first();
    // Send email if email flag is set to true
    if ($email == 1) {
      $coursename = ManageCoursesModel::where('status', 0)->whereIn('sno', $course_ids)->first();
      $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();



      // Format the start and end date into a readable format (e.g., 22 May 2024)
      $formattedStartDate = \Carbon\Carbon::parse($batch_details->start_date)->format('d M Y');
      $formattedEndDate = \Carbon\Carbon::parse($batch_details->end_date)->format('d M Y');
      // return $branch;
      // Gender condition
      $genderPrefix = 'Mr/Ms'; // Default value
      if ($lead->lead_gender == 1) {
        $genderPrefix = 'Mr';
      } elseif ($lead->lead_gender == 2) {
        $genderPrefix = 'Ms';
      }

      $content = $emailTemplate->email_subject;
      $content = str_replace('#name', $lead->lead_name, $content);
      $content = str_replace('#gender', $genderPrefix, $content);
      $content = str_replace('#CREname', $cre->staff_name ?? "Alex", $content);
      $content = str_replace('#Course', $coursename->course_name ?? 'course', $content);
      $content = str_replace('#start_date', $formattedStartDate, $content);
      $content = str_replace('#end_date', $formattedEndDate, $content);
      $content = str_replace('#staff_nick_name', $staff->nick_name ?? 'Staff', $content);
      $content = str_replace('#class_time', $slot->start_time ?? 'Class Time', $content);
      $branchNo = $branch->mobile;
      $branchemail = $branch->mail;
      $fbLink = $branch->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
      $instaLink = $branch->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
      $content = str_replace('#salesNo', $lead->lead_mobile ?? '9677781155', $content);
      $content = str_replace('#CRENo', $lead->lead_mobile ?? '9677781155', $content);
      $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

      $mailData = [
        'url' => 'Eapl.com',
        'subject' => $emailTemplate->email_name,
        'content' => $content,
        'branchNo' => $branchNo,
        'branchemail' => $branchemail, // Use the message content from the request
        'fbLink' => $fbLink, // Use the message content from the request
        'instaLink' => $instaLink, // Use the message content from the request
        'salesMobile' => $branch->sales_mobile,
      ];

      $to_address = $lead->lead_email_id;
      $from_address = $branchemail ?? 'info@elysiumacademy.org';
       $from_name = 'Elysium Academy ' . "\xC2\xAE";


      Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
    }


    // if ($email == 1) {
    //       // Fetch course name, branch info, and staff details
    //       $coursename = ManageCoursesModel::where('status', 0)->whereIn('sno', $course_ids)->first();
    //       $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', 12)->first();
    //       $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
    //       $batch_details = BatchModel::where('sno', 34)->orderBy('sno', 'desc')->first();
    //       $slot = SlotModel::where('sno', $batch_details->slot_id)->orderBy('sno', 'desc')->first();
    //       $staff = StaffModel::where('sno', $batch_details->staff_id)->orderBy('sno', 'desc')->first();

    //       // Format the start and end date into a readable format (e.g., 22 May 2024)
    //       $formattedStartDate = \Carbon\Carbon::parse($batch_details->start_date)->format('d M Y');
    //       $formattedEndDate = \Carbon\Carbon::parse($batch_details->end_date)->format('d M Y');

    //       // Prepare the email content by replacing placeholders with dynamic data
    //       $content = $emailTemplate->email_subject;
    //       $content = str_replace('#name', $lead->lead_name ?? 'Customer', $content);
    //       $content = str_replace('#staff_nick_name', $staff->nick_name ?? 'Staff', $content);
    //       $content = str_replace('#course', $coursename->course_name ?? 'Course Name', $content);
    //       $content = str_replace('#start_date', $formattedStartDate, $content);
    //       $content = str_replace('#end_date', $formattedEndDate, $content);
    //       $content = str_replace('#class_time', $slot->start_time ?? 'Class Time', $content);
    //       $content = str_replace('#branchNo1', $branch->mobile ?? 'Branch Mobile', $content);
    //       $content = str_replace('#branchNo2', $branch->mobile ?? 'Branch Mobile', $content);

    //       // Prepare the mail data
    //       $mailData = [
    //           'url'     => 'Eapl.com',
    //           'content' => $content,
    //       ];

    //       // Send email to the customer (lead)
    //       $to_address = $customer_details->email ?? 'default@email.com';
    //       $from_address = 'elysiumacademy@elysium.community';
    //       Mail::to($to_address)->send(new EAPLMail($mailData, $from_address));
    //     }
    //  if ($email == 1) {
    //      // Get the lead (this will depend on your logic)
    //     $lead = LeadModel::find($lead_id);

    //     // Set the template ID (this can be fetched based on the context, e.g., welcome email or course update)
    //     $templateId = $email_template_id;  // Example template ID
    //     // return  $lead;
    //     // Send the email
    //     Mail::to($lead->lead_email_id)->send(new DynamicTemplateEmail($lead, $templateId));
    // }

    // Send SMS if sms flag is set to true

    // if ($sms == 1) {

    //   $authkey         = '155099Ajzgw9B8dfq6737236aP1';
    //   $sender_id       = 'ELYSIU';
    //   $template_id     = '1007272850402890776';
    //   $country_code    = 91;
    //   $message_content = 'Thank you for your interest in Python Development Course at Elysium Academy! Total Course Duration is for 3 months and the Cost for the entire program is INR 9800';
    //   $mobile_number   = $country_code . $lead->lead_mobile;


    //   // Prepare recipients
    //   $recipients = [
    //     [
    //       "mobiles" => $mobile_number,
    //       "VAR1"    => "Python Development", // You can pass other variables here
    //       "VAR2"    => '3 months', // You can pass other variables here
    //       "VAR3"    => "INR 100" // You can pass other variables here
    //     ]
    //   ];
    //   // Prepare post data
    //   $postData = array(
    //     "sender"         => $sender_id,
    //     "template_id"    => $template_id,
    //     "recipients"     => $recipients
    //   );
    //   $postDataJson = json_encode($postData);
    //   // API URL
    //   $url = 'http://api.msg91.com/api/v5/flow/';

    //   // Initialize cURL request
    //   $curl = curl_init();
    //   curl_setopt_array($curl, array(
    //     CURLOPT_URL => $url,
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_CUSTOMREQUEST => "POST",
    //     CURLOPT_POSTFIELDS => $postDataJson,
    //     CURLOPT_HTTPHEADER => array(
    //       "authkey: $authkey",
    //       "content-type: application/json"
    //     ),
    //   ));

    //   $response = curl_exec($curl);
    //   $err = curl_error($curl);
    //   curl_close($curl);

    //   // Check for errors
    //   if ($err) {
    //     return response()->json(['status' => 500, 'message' => 'Failed to send SMS. cURL Error #: ' . $err], 500);
    //   } else {
    //     return response()->json(['status' => 200, 'message' => 'SMS sent successfully', 'response' => $response], 200);
    //   }
    // }
    if ($sms == 1) {

      // start here

      $authkey         = '155099Ajzgw9B8dfq6737236aP1';
      $sender_id       = 'ELYSIU';

      // $template_id     = '1007272850402890776'; // Ensure this is the correct template ID from Msg91
      //  $message_content = 'Thank you for your interest in Python Development Course at Elysium Academy! Total Course Duration is for 3 months and the Cost for the entire program is INR 9800';

      $country_code    = 91;
      $mobile_number   = $country_code . $lead->lead_mobile;


      $template_id     = '1007151306628426687'; // Ensure this is the correct template ID from Msg91
      // $message_content = 'Thank you for your interest in Python Development Course at Elysium Academy! Total Course Duration is for 3 months and the cost for the entire program is INR 9800 Feel free to reach out at 755818 4348 | 9677781155';

      $var1 = "Python Development";
      $var2 = "3 months";
      $var3 = "INR 9800";

      $message_content = 'Thank you for your interest in ' . $var1 . ' Course at Elysium Academy! Total Course Duration is for ' . $var2 . ' and the cost for the entire program is ' . $var3 . ' Feel free to reach out at 755818 4348 | 9677781155';
      $route = "default"; //Define route

      /*****  working with manual data starts here  *****/

      //Prepare you post parameters
      $postData = array(
        'authkey' => $authkey,
        'mobiles' => $mobile_number,
        'message' => $message_content,
        'sender' => $sender_id,
        'route' => $route
      );
      //API URL
      $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=$message_content&mobiles=$mobile_number&DLT_TE_ID=$template_id";

      // init the resource
      $ch = curl_init();
      curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData
        //,CURLOPT_FOLLOWLOCATION => true
      ));
      //Ignore SSL certificate verification
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

      //get response
      $response = curl_exec($ch);
      $err = curl_error($ch);
      curl_close($ch);
      if ($err) {
        return response()->json([
          'status'  => 500,
          'message' => 'Failed to send SMS. cURL Error #: ' . $err
        ], 500);
      } else {
        $decodedResponse = json_decode($response, true);

        // Check if the API returned an error
        if (isset($decodedResponse['type']) && $decodedResponse['type'] == 'error') {
          return response()->json([
            'status'  => 500,
            'message' => $decodedResponse['message']
          ], 500);
        }

        return response()->json([
          'status'  => 200,
          'message' => 'SMS sent successfully',
          'response' => $decodedResponse
        ], 200);
      }

      /*

        //get response
        $output = curl_exec($ch);

        //Print error if any
        if(curl_errno($ch))
        {
            echo 'error:' . curl_error($ch);
        }

        curl_close($ch);


        echo $output;
       // echo "<br>";
       // echo $url;
      //  exit;
      */

      /*********  working with manual data ends here  *****/

      /*********  trial  data starts  here  *****


      // Prepare recipients
      $recipients = [
        [
          "mobiles" => $mobile_number,
          "VAR1"    => "Python Development", // Variable 1 in your template
          "VAR2"    => '3 months',          // Variable 2 in your template
          "VAR3"    => "INR 9800"           // Variable 3 in your template
        ]
      ];
      $postData = array(
        "sender"      => $sender_id,
        "template_id" => $template_id,
        "recipients"  => $recipients
      );
      $postDataJson = json_encode($postData);
      // return $postDataJson;
      $url = 'https://control.msg91.com/api/v5/flow';
      $curl = curl_init();
      curl_setopt_array($curl, array(
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => "POST",
        CURLOPT_POSTFIELDS     => $postDataJson,
        CURLOPT_HTTPHEADER     => array(
          "authkey: $authkey",
          "content-type: application/json"
        ),
      ));
      $response = curl_exec($curl);
      $err = curl_error($curl);
      curl_close($curl);
      if ($err) {
        return response()->json([
          'status'  => 500,
          'message' => 'Failed to send SMS. cURL Error #: ' . $err
        ], 500);
      } else {
        $decodedResponse = json_decode($response, true);

        // Check if the API returned an error
        if (isset($decodedResponse['type']) && $decodedResponse['type'] == 'error') {
          return response()->json([
            'status'  => 500,
            'message' => $decodedResponse['message']
          ], 500);
        }

        return response()->json([
          'status'  => 200,
          'message' => 'SMS sent successfully',
          'response' => $decodedResponse
        ], 200);
      }
       *********  trial  data ends  here  *****/
    }
    // if ($sms == 1) {

    //   $authkey         = '155099Ajzgw9B8dfq6737236aP1';
    //   $sender_id       = 'ELYSIU';
    //   $template_id     = '1007272850402890776'; // Ensure this is the correct template ID from Msg91
    //   $country_code    = 91;
    //   $message_content = 'Thank you for your interest in Python Development Course at Elysium Academy! Total Course Duration is for 3 months and the Cost for the entire program is INR 9800';
    //   $mobile_number   = $country_code . $lead->lead_mobile;

    //   // Prepare recipients
    //   $recipients = [
    //     [
    //       "mobiles" => $mobile_number,
    //       "VAR1"    => "Python Development", // Variable 1 in your template
    //       "VAR2"    => '3 months',          // Variable 2 in your template
    //       "VAR3"    => "INR 9800"           // Variable 3 in your template
    //     ]
    //   ];

    //   $postData = array(
    //     "sender"      => "ELYSIU",
    //     "template_id" => "1007272850402890776",
    //     "recipients"  => $recipients
    //   );
    //   $postDataJson = json_encode($postData);

    //   $url = 'https://control.msg91.com/api/v5/flow';
    //   $curl = curl_init();
    //   curl_setopt_array($curl, array(
    //     CURLOPT_URL            => $url,
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_CUSTOMREQUEST  => "POST",
    //     CURLOPT_POSTFIELDS     => $postDataJson,
    //     CURLOPT_HTTPHEADER     => array(
    //       "authkey: 155099Ajzgw9B8dfq6737236aP1",
    //       "content-type: application/json"
    //     ),
    //   ));
    //   $response = curl_exec($curl);
    //   $err = curl_error($curl);
    //   curl_close($curl);

    //   if ($err) {
    //     return response()->json([
    //       'status'  => 500,
    //       'message' => 'Failed to send SMS. cURL Error #: ' . $err
    //     ], 500);
    //   } else {
    //     $decodedResponse = json_decode($response, true);

    //     // Check if the API returned an error
    //     if (isset($decodedResponse['type']) && $decodedResponse['type'] == 'error') {
    //       return response()->json([
    //         'status'  => 500,
    //         'message' => $decodedResponse['message']
    //       ], 500);
    //     }

    //     // After sending the SMS, check the message status using the message ID
    //     $message_id = $decodedResponse['message']; // This is the message ID you received
    //     // return $message_id;
    //     $statusCheckUrl = 'https://control.msg91.com/api/v5/message-status';
    //     $statusCurl = curl_init();
    //     curl_setopt_array($statusCurl, array(
    //       CURLOPT_URL            => $statusCheckUrl,
    //       CURLOPT_RETURNTRANSFER => true,
    //       CURLOPT_CUSTOMREQUEST  => "POST",
    //       CURLOPT_POSTFIELDS     => json_encode(['message_id' => $message_id]),
    //       CURLOPT_HTTPHEADER     => array(
    //         "authkey: 155099Ajzgw9B8dfq6737236aP1",
    //         "content-type: application/json"
    //       ),
    //     ));
    //     $statusResponse = curl_exec($statusCurl);
    //     $statusErr = curl_error($statusCurl);
    //     curl_close($statusCurl);

    //     if ($statusErr) {
    //       return response()->json([
    //         'status'  => 500,
    //         'message' => 'Failed to check message status. cURL Error #: ' . $statusErr
    //       ], 500);
    //     } else {
    //       $statusDecodedResponse = json_decode($statusResponse, true);

    //       if (isset($statusDecodedResponse['error'])) {
    //         // Handle the error, as 'error' might contain details
    //         return response()->json([
    //           'status'  => 500,
    //           'message' => 'Error fetching message status: ' . $statusDecodedResponse['error']
    //         ], 500);
    //       }
    //     }
    //   }
    // }


    // Send WhatsApp message if whatsapp flag is set to true
    if ($whatsapp == 1) {

      $coursename = ManageCoursesModel::where('status', 0)->whereIn('sno', $course_ids)->first();
      $templateName = $whatsapp_temp_id;

      // $dynamicParameters = [
      //     'header' => null,
      //     'body' => null,
      //     'footer' => null,
      // ];

      // switch ($templateName) {
      //     case 'diwali_greetings_elysiumpro':
      //         $dynamicParameters['header'] = [
      //             [
      //                 'type' => 'image',
      //                 'image' => [
      //                     'link' => 'https://i0.wp.com/gangautsav.in/wp-content/uploads/2024/03/diwali-dates.webp?resize=1792%2C1024&ssl=1',
      //                 ],
      //             ],
      //         ];
      //         break;

      //     // case 'testing_welcome':
      //     case 'welcome_message':
      //         // Header with image and body with text
      //         $dynamicParameters['header'] = [
      //             [
      //                 'type' => 'image',
      //                 'image' => [
      //                     'link' => 'https://elysiumpro.in/wp-content/uploads/2024/11/Final-Year-Web-Development-Projects.png',
      //                 ],
      //             ],
      //         ];
      //         $dynamicParameters['body'] = [
      //             [
      //                 'type' => 'text',
      //                 'text' => $lead->lead_name,
      //             ],
      //         ];
      //         break;
      //     case 'elysiumpro_support_001_13_11_2024':
      //         // Header with image and body with text
      //         $dynamicParameters['header'] = [
      //             [
      //                 'type' => 'image',
      //                 'image' => [
      //                     'link' => 'https://elysiumpro.in/wp-content/uploads/2024/11/Final-Year-Web-Development-Projects.png',
      //                 ],
      //             ],
      //         ];
      //         $dynamicParameters['body'] = [
      //             [
      //                 'type' => 'text',
      //                 'text' => $lead->lead_name,
      //             ],
      //         ];
      //         break;

      //     case 'welcome_message_epro':
      //         // Header with image and body with text
      //         $dynamicParameters['header'] = [
      //             [
      //                 'type' => 'image',
      //                 'image' => [
      //                     'link' => 'https://elysiumpro.in/wp-content/uploads/2024/11/Final-Year-Web-Development-Projects.png',
      //                 ],
      //             ],
      //         ];
      //         $dynamicParameters['body'] = [
      //             [
      //                 'type' => 'text',
      //                 'text' => $lead->lead_name,
      //             ],
      //         ];
      //         break;
      //     case 'hello_world':
      //         // Header with image and body with text
      //         $components = [];

      //         break;
      // }

      $hasHeader = false; // Example flag: set based on template
      $hasBody = false; // Example flag: set based on template
      $hasFooter = false; // Example flag: set based on template
      $hasButton = false;
      $components = [];
      $couponCode = "";
      $otp = "";
      date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
      $currentHour = (int) date('H'); // Get current hour in 24-hour format as an integer
      // $currentHour = date('H'); // Get current hour in 24-hour format
      if ($currentHour >= 5 && $currentHour < 12) {
        $greeting = 'Good Morning';
      } elseif ($currentHour >= 12 && $currentHour < 18) {
        $greeting = 'Good Afternoon';
      } else {
        $greeting = 'Good Evening';
      }

      switch ($templateName) {
        case 'elysium_academy_welcome_message':
          $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
          $couponCode = 'DISCOUNT20';
          $buttonIndex = 0;
          $bodyText = [
            [
              'type' => 'text',
              'text' => $greeting,
              'parameter_name' => 'greet_msg',
            ],
            [
              'type' => 'text',
              'text' => $lead->lead_name,
              'parameter_name' => 'customer_name',
            ],
            [
              'type' => 'text',
              'text' => 'https://elysiumacademy.org',
              'parameter_name' => 'web_link',
            ],
            [
              'type' => 'text',
              'text' => $branch_name,
              'parameter_name' => 'branch_name',
            ],
            [
              'type' => 'text',
              'text' => $branchData->cre_mobile ?? '9677781155',
              'parameter_name' => 'contact_no',
            ],
            [
              'type' => 'text',
              'text' => 'info@elysiumacademy.org',
              'parameter_name' => 'contact_email',
            ],
          ];
          $hasHeader = true;
          $hasBody = true;
          $hasButton = true;
          break;
        case 'elysium_academy_otp_erp':
          $otp = '5080';
          $buttonIndex = 0;
          $bodyText = [
            [
              'type' => 'text',
              'text' => $otp,
            ],
          ];
          $hasBody = true;
          $hasButton = true;
          break;
        case 'elysium_academy_first_offer_erp':
          $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Discount3.jpg';
          $buttonIndex = -1;
          $bodyText = [
            [
              'type' => 'text',
              'text' => $greeting,
              'parameter_name' => 'greet_msg',
            ],
            [
              'type' => 'text',
              'text' => $lead->lead_name,
              'parameter_name' => 'customer_name',
            ],
            [
              'type' => 'text',
              'text' => $lead->lead_mobile,
              'parameter_name' => 'contact_no',
            ],
            [
              'type' => 'text',
              'text' => $branchData->website,
              'parameter_name' => 'web_url',
            ],
            [
              'type' => 'text',
              'text' => $branch_name,
              'parameter_name' => 'branch_name',
            ],
            [
              'type' => 'text',
              'text' => $branchData->sales_mobile ?? '9677781155',
              'parameter_name' => 'sale_contact_no',
            ],
            [
              'type' => 'text',
              'text' => $branchData->mail ?? 'info@elysiumacademy.org',
              'parameter_name' => 'sale_contact_email',
            ],
          ];
          $hasHeader = true;
          $hasBody = true;
          break;
        case 'elysium_academy_appoint_message':
          $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Appointment_Header.jpg';
          $couponCode = 'DISCOUNT10';
          $buttonIndex = 1;
          $bodyText = [
            [
              'type' => 'text',
              'text' => $greeting,
              'parameter_name' => 'greet_msg',
            ],
            [
              'type' => 'text',
              'text' => $lead->lead_name,
              'parameter_name' => 'customer_name',
            ],
            [
              'type' => 'text',
              'text' => '13-01-2025',
              'parameter_name' => 'app_date',
            ],
            [
              'type' => 'text',
              'text' => '10:40 AM',
              'parameter_name' => 'app_time',
            ],
            [
              'type' => 'text',
              'text' => '227, IInd Floor, B Block, Elysium Campus, Church Rd, Anna Nagar, Madurai 625020',
              'parameter_name' => 'app_location',
            ],
            [
              'type' => 'text',
              'text' => $branchData->cre_mobile ?? '9677781155',
              'parameter_name' => 'contact1_no',
            ],
            [
              'type' => 'text',
              'text' => $branch_name,
              'parameter_name' => 'branch_name',
            ],
            [
              'type' => 'text',
              'text' => $branchData->cre_mobile ?? '9677781155',
              'parameter_name' => 'contact_no',
            ],
            [
              'type' => 'text',
              'text' => 'info@elysiumacademy.org',
              'parameter_name' => 'contact_email',
            ],
          ];
          $hasHeader = true;
          $hasBody = true;
          $hasButton = true;
          break;

        case 'hello_world':
          // No components for hello_world template
          $bodyText = [];
          $hasHeader = false;
          $hasBody = false;
          $hasFooter = false;
          $hasButton = false;
          break;
        default:
          $bodyText = [];
          $headerImage = ''; // Default empty header image
          $couponCode = ''; // Default empty coupon code
          $otp = ''; // Default empty coupon code
          $buttonIndex = -1;
          break;
      }

      // Add Header if required
      if ($hasHeader) {
        $components[] = [
          'type' => 'header',
          'parameters' => [
            [
              'type' => 'image',
              'image' => [
                'link' => $headerImage, // Dynamically set header image
              ],
            ],
          ],
        ];
      }

      // Add Body if required
      if ($hasBody) {
        $components[] = [
          'type' => 'body',
          'parameters' => $bodyText,
        ];
      }

      // Add Footer if required
      if ($hasFooter) {
        $components[] = [
          'type' => 'footer',
          'parameters' => [
            [
              'type' => 'text',
              'text' => 'This is the footer text.',
              'parameter_name' => 'footer_text',
            ],
          ],
        ];
      }

      // Add Button if required
      if ($hasButton) {
        if ($couponCode) {
          $components[] = [
            'type' => 'button',
            'sub_type' => 'copy_code',
            'index' => $buttonIndex,
            'parameters' => [
              [
                'type' => 'coupon_code',
                'coupon_code' => $couponCode,
              ],
            ],
          ];
        } elseif ($otp) {
          $components[] = [
            'type' => 'button',
            'sub_type' => 'url', // Change type to match API requirements
            'index' => $buttonIndex,
            'parameters' => [
              [
                'type' => 'text',
                'text' => $otp,
              ],
            ],
          ];
        }
      }

      $dynamicParameters = $templateParameters[$templateName] ?? [];
      $WhatsAppBusinessAccountId = $this->businessId;
      $accessToken = $this->accessToken;
      $fromPhoneNumberId = $this->phoneNumberId;

      // $WhatsAppBusinessAccountId = "257605474109908";
      // $WhatsAppBusinessAccountId = "453411981186795";
      // // $fromPhoneNumberId = '278333662032187';
      // $fromPhoneNumberId = '437594702776125';
      $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

      $to = '9677482114';
      // $to = '6382288402';
      // $to = $lead->lead_mobile;
      $languageCode = 'en';

      if (strpos($to, '+91') !== 0) {
        $to = '+91' . $to;
      }

      $message = 'test~message';
      if (empty($components)) {
        $payload = [
          'messaging_product' => 'whatsapp',
          'to' => $to,
          'type' => 'template',
          'template' => [
            'name' => $templateName,
            'language' => [
              'code' => $languageCode,
            ],
          ],
        ];
      } else {
        $payload = [
          'messaging_product' => 'whatsapp',
          'to' => $to,
          'type' => 'template',
          'template' => [
            'name' => $templateName,
            'language' => [
              'code' => $languageCode,
            ],
            'components' => $components,
          ],
        ];
      }

      $response = $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

      if ($response['status'] == 200) {

        $log_branch_id = 6;
        $unique_id = 0;
        $source ='OTP';
        $log_phone_no =$to;
        $log_template_name =$templateName;

               $save_log = $this->WhatsappSendLog(
                            $response,
                            $payload,
                            $log_phone_no,
                            $log_template_name,
                            $user_id,
                            $log_branch_id,
                            $unique_id,
                            $source
                        );
        
      }

      file_put_contents('whatsapp_log.txt', date('Y-m-d H:i:s') . " - Payload: " . json_encode($payload) . " - Response: " . json_encode($response) . "\n", FILE_APPEND);

      if ($response['status'] == 200) {

        $messageId = $response['data']['messages'][0]['id'] ?? null;

        // if ($messageId) {
        //     // Store the message ID and initial status in the database
        //     DB::table('webhook_histroy')->insert([
        //         'id' => $messageId,
        //         'lead_id' => $lead_id,
        //         'status' => 'sent',
        //         'created_at' => now(),
        //         'updated_at' => now(),
        //     ]);
        // }
        return response([
          'status' => 200,
          'message' => 'Message sent successfully!',
          'data' => $response['data'],
          'response_data' => json_encode($response),
        ], 200);
      } else {
        return response([
          'status' => 404,
          'message' => 'Failed to send message',
          'error_msg' => $response['error'],
        ], 400);
      }
    }





    // If the operation was successful, return a success response
    return response([
      'status'    => 200,
      'message'   => "Message sent successfully",
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }

  public function LeadImportOld(Request $requestData)
  {
    $validator = Validator::make($requestData->all(), [
      'file_import' => 'required|file|mimes:xls,xlsx|max:5120',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 400);
    }

    $file_import = $requestData->file('file_import');
    $data = Excel::toCollection(new LeadModel, $file_import);

    if ($data->isEmpty() || $data[0]->isEmpty()) {
      return response()->json([
        'status' => 401,
        'message' => 'The uploaded file is empty.',
        'error_msg' => ['The uploaded file is empty.'],
        'data' => null,
      ], 400);
    }

    $errors = [];
    $successfulImports = 0;

    foreach ($data[0] as $key => $row) {
      if ($key > 0) { // Skip the header row
        $lead_date     = $row[1];
        $lead_name     = $row[2];
        $lead_mobile   = $row[3];
        $lead_comments = $row[4];

        if (empty($lead_name) || empty($lead_mobile)) {
          $errors[] = 'Missing required field name or number in row ' . ($key + 1);
          continue; // Skip to the next row
        }
        // Read raw value
        $lead_date_raw = $row[2];

        // Determine if the date is an Excel numeric timestamp
        if (is_numeric($lead_date_raw)) {
          $lead_date = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($lead_date_raw)->format('Y-m-d');
        } else {
          // Try to parse as a normal date string
          try {
            $lead_date = date('Y-m-d', strtotime($lead_date_raw));
          } catch (\Exception $e) {
            $errors[] = 'Row ' . ($key + 1) . ': Invalid date format';
            continue;
          }
        }


        $lead_mobile = str_replace(' ', '', $lead_mobile);

        // Check for duplicate mobile number
        $chk = RawLeadModel::where('lead_mobile', $lead_mobile)
          ->first();

        if ($chk) {
          $errors[] = 'Row ' . ($key + 1) . ': Mobile number ' . $lead_mobile . ' already exists!';
          continue;
        }

        // Parse and save mobile numbers
        $mobileNumbers = explode('//', str_replace('/', '//', $lead_mobile));
        $lead_primary_mobile = preg_replace('/\s+/', '', $mobileNumbers[0]); // Remove spaces
        $lead_alternate_mobile = isset($mobileNumbers[1]) && !empty($mobileNumbers[1])
          ? preg_replace('/\s+/', '', $mobileNumbers[1])
          : null; // Use NULL if no alternate mobile is provided

        // Parse and format date
        $formatted_lead_date = date('Y-m-d', strtotime($lead_date));

        // Generate new lead ID
        $branch_check = BranchModel::where('sno', $requestData->user()->branch_id)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code;

        $category_check = RawLeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $request_pay = sprintf("LED%04d", $next_number);
          $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
        }

        $user_id = $requestData->user()->user_id;
        $branch_id = $requestData->user()->branch_id;

        // Create and save the lead
        $new_lead = new RawLeadModel();
        $new_lead->lead_id = $lead_id;
        $new_lead->lead_name = $lead_name;
        $new_lead->lead_mobile = $lead_primary_mobile;
        $new_lead->lead_alternate_mobile = $lead_alternate_mobile;
        $new_lead->lead_source_id = 7; // Add logic to set lead_source_id
        $new_lead->lead_type_id = 6; // Add logic to set lead_type_id
        $new_lead->status = 8; // Old data imported
        $new_lead->lead_comments = $lead_comments;
        $new_lead->branch_id = $branch_id;
        $new_lead->created_at = $formatted_lead_date;
        $new_lead->updated_at = $formatted_lead_date;
        $new_lead->created_by = $user_id;
        $new_lead->updated_by = $user_id;

        if ($new_lead->save()) {
          $successfulImports++;
        } else {
          $errors[] = 'Row ' . ($key + 1) . ': Could not import the lead ' . $lead_name . '!';
        }
      }
    }

    $responseMessage = $successfulImports . ' lead(s) imported successfully.';

    if (!empty($errors)) {
      return response()->json([
        'status' => 'partial_success',
        'message' => $responseMessage,
        'error_msg' => $errors,
      ], 207);
    } else {
      return response()->json([
        'status' => 'success',
        'message' => $responseMessage,
        'data' => null,
      ], 200);
    }
  }

  //   Manage Calls
  public function manage_calls(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;

    // Filters
    $department_fill  = $request->input('department_fill', '');
    $staff_fill       = $request->input('staff_fill', '');
    $date_filter      = $request->input('dt_fill_issue_rpt');
    $from_date_filter = $request->input('from_date_fillter_textbox');
    $to_date_filter   = $request->input('to_date_fillter_textbox');
    $fin_yr_fill      = $request->input('fin_yr_fill', '');

    $calls = DB::table('za_contact_book')
      ->select('za_contact_book.staff_id', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_department.department_name')
      ->join('za_staff', 'za_staff.sno', '=', 'za_contact_book.staff_id')
      ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->distinct('za_contact_book.staff_id')
      ->where('za_staff.status', 0);

    $staff_list = $calls->get();

    // Date Filtering
    if ($date_filter === "today") {
      $calls->whereDate('za_contact_book.created_at', now()->toDateString());
    } elseif ($date_filter === "week") {
      $calls->whereBetween('za_contact_book.created_at', [now()->startOfWeek(), now()->endOfWeek()]);
    } elseif ($date_filter === "monthly") {
      $calls->whereMonth('za_contact_book.created_at', now()->month)
        ->whereYear('za_contact_book.created_at', now()->year);
    } elseif ($date_filter === "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $calls->whereBetween('za_contact_book.created_at', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
      } elseif ($from_date_filter) {
        $calls->where('za_contact_book.created_at', '>=', Carbon::parse($from_date_filter));
      } elseif ($to_date_filter) {
        $calls->where('za_contact_book.created_at', '<=', Carbon::parse($to_date_filter));
      }
    }

    // Financial Year Filter
    if ($fin_yr_fill) {
      $helper            = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);
        if (is_array($monthsArray)) {
          $calls->where(function ($query) use ($monthsArray) {
            foreach ($monthsArray as $month) {
              $query->orWhereMonth('za_contact_book.created_at', $month)
                ->whereYear('za_contact_book.created_at', now()->year);
            }
          });
        }
      }
    }

    // Other Filters
    if ($department_fill) {
      $calls->where('za_staff.department_id', $department_fill);
    }

    if ($staff_fill) {
      $calls->where('za_contact_book.staff_id', $staff_fill);
    }

    $calls = $calls->orderBy('za_contact_book.contact_book_id', 'desc')->paginate($perpage);

    $department_list = DB::table('za_department')->where('status', 0)->get();

    // return $calls;
    return view('content.sales.manage_calls.call_list', [
      'calls'            => $calls,
      'perpage'          => $perpage,
      'department_list'  => $department_list,
      'staff_list'       => $staff_list,
      'date_filter'      => $date_filter,
      'department_fill'  => $department_fill,
      'staff_fill'       => $staff_fill,
      'fin_yr_fill'      => $fin_yr_fill,
      'from_date_filter' => $from_date_filter,
      'to_date_filter'   => $to_date_filter,
    ]);
  }

  public function call_history($id, Request $request)
  {
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $branch_id = $request->user()->branch_id;

    $helper          = new \App\Helpers\Helpers();
    $decryptedValue  = $helper->encrypt_decrypt($id, 'decrypt');
    $staff_id        = $decryptedValue;
    $call_start_date = date('Y-m-01'); // Start date (first day of the month)
    $call_end_date   = date('Y-m-t');

    // Filters
    $status_fill      = $request->input('status_fill', '');
    $date_filter      = $request->input('dt_fill_issue_rpt');
    $from_date_filter = $request->input('from_date_fillter_textbox');
    $to_date_filter   = $request->input('to_date_fillter_textbox');
    $fin_yr_fill      = $request->input('fin_yr_fill', '');

    // return $status_fill;

    $caller = DB::table('za_staff')->select('za_staff.*', 'za_department.department_name')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->where('za_staff.status', '!=', '2')
      ->where('za_staff.sno', $staff_id)
      ->first();

    $incoming_call_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('za_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('za_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('za_call_log.status', 1)                             // Status is 1
      ->count();

    $incoming_call_count = $incoming_call_count ?? 0;

    // Get the outgoing call count excluding the phone numbers in company_cug_detail
    $outgoingcall_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('za_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('za_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('za_call_log.status', 0)                             // Status is 0
      ->where('za_call_log.duration', '!=', '00:00:00')            // Duration is not '00:00:00'
      ->count();

    // Assign the result to a variable
    $outgoingcall_count = $outgoingcall_count ?? 0;

    // missed call
    $missedcall_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('za_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('za_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('za_call_log.status', 2)                             // Status is 2 for missed calls
      ->where('za_call_log.missed_status', 0)                      // Missed status is 0
      ->count();

    $rejected_call_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('za_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('za_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('za_call_log.status', 3)                             // Status is 3 for rejected calls
      ->count();

    // Assign the result to a variable
    $rejected_call_count = $rejected_call_count ?? 0;

    // Assign the result to a variable
    $missedcall_count = $missedcall_count ?? 0;

    $missed_call_ratio = 0;

    if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
      $total_calls = $incoming_call_count + $missedcall_count + $rejected_call_count;
      if ($total_calls > 0) {
        $missed_call_ratio = ($missedcall_count / $total_calls) * 100;
        $missed_call_ratio = $missed_call_ratio;
      } else {
        $missed_call_ratio = 0;
      }
    }

    $outgoing_call_ratio = 0;

    if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
      $total_calls_all = $incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count;
      if ($total_calls > 0) {
        $outgoing_call_ratio = ($outgoingcall_count / $total_calls_all) * 100;
        $outgoing_call_ratio = $outgoing_call_ratio;
      } else {
        $outgoing_call_ratio = 0;
      }
    }

    $calls = DB::table('za_call_log')->select('za_call_log.*', 'za_contact_book.contact_name', 'za_contact_book.phone_no', 'za_lead.lead_name')
      ->join('za_contact_book', 'za_contact_book.contact_book_id', '=', 'za_call_log.contact_book_id', 'left')
      ->leftJoin('za_lead', DB::raw("SUBSTRING(za_contact_book.phone_no, 4)"), '=', 'za_lead.lead_mobile') // Normalized phone_no
      ->where('za_call_log.staff_id', $staff_id)                                                           // Filter by user ID
      ->where('za_call_log.call_date', '>=', $call_start_date)                                             // Start date filter
      ->where('za_call_log.call_date', '<=', $call_end_date);

    // Date Filtering
    if ($date_filter === "today") {
      $calls->whereDate('za_call_log.call_date', now()->toDateString());
    } elseif ($date_filter === "week") {
      $calls->whereBetween('za_call_log.call_date', [now()->startOfWeek(), now()->endOfWeek()]);
    } elseif ($date_filter === "monthly") {
      $calls->whereMonth('za_call_log.call_date', now()->month)
        ->whereYear('za_call_log.call_date', now()->year);
    } elseif ($date_filter === "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $calls->whereBetween('za_call_log.call_date', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
      } elseif ($from_date_filter) {
        $calls->where('za_call_log.call_date', '>=', Carbon::parse($from_date_filter));
      } elseif ($to_date_filter) {
        $calls->where('za_call_log.call_date', '<=', Carbon::parse($to_date_filter));
      }
    }

    // Financial Year Filter
    if ($fin_yr_fill) {
      $helper            = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);
        if (is_array($monthsArray)) {
          $calls->where(function ($query) use ($monthsArray) {
            foreach ($monthsArray as $month) {
              $query->orWhereMonth('za_call_log.call_date', $month)
                ->whereYear('za_call_log.call_date', now()->year);
            }
          });
        }
      }
    }
    // return $status_fill;
    // Other Filters
    if ($status_fill) {
      $calls->where('za_call_log.status', $status_fill);
    } elseif ($status_fill == 0) {
      $calls->where('za_call_log.status', $status_fill);
    }

    $calls  = $calls->orderBy('za_call_log.call_log_id', 'desc')->paginate($perpage);
    $filter = true;

    return view(
      'content.sales.manage_calls.indiv_call_history',
      [
        'calls'               => $calls,
        'perpage'             => $perpage,
        'caller'              => $caller,
        'incoming_call_count' => $incoming_call_count,
        'outgoingcall_count'  => $outgoingcall_count,
        'missedcall_count'    => $missedcall_count,
        'rejected_call_count' => $rejected_call_count,
        'missed_call_ratio'   => $missed_call_ratio,
        'outgoing_call_ratio' => $outgoing_call_ratio,
        'date_filter'         => $date_filter,
        'status_fill'         => $status_fill,
        'fin_yr_fill'         => $fin_yr_fill,
        'from_date_filter'    => $from_date_filter,
        'to_date_filter'      => $to_date_filter,
        'filter'              => $filter,
      ]
    );
  }

  public function lead_call_history($id, $status, Request $request)
  {
    // return $status;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $branch_id = $request->user()->branch_id;

    $helper          = new \App\Helpers\Helpers();
    $decryptedValue  = $helper->encrypt_decrypt($id, 'decrypt');
    $lead_mobile     = $decryptedValue;
    $call_start_date = date('Y-m-01'); // Start date (first day of the month)
    $call_end_date   = date('Y-m-t');

    // Filters
    $status_fill      = $request->input('status_fill', '');
    $date_filter      = $request->input('dt_fill_issue_rpt');
    $from_date_filter = $request->input('from_date_fillter_textbox');
    $to_date_filter   = $request->input('to_date_fillter_textbox');
    $fin_yr_fill      = $request->input('fin_yr_fill', '');

    $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
    $phoneWithCountryCode = '+91' . $normalizedPhoneNo; // Add the country code

    $lead = DB::table('za_contact_book')->where('phone_no', $lead_mobile)
      ->orWhere('phone_no', $phoneWithCountryCode)->orderBy('contact_book_id', 'desc')->first();
    $staff_id = $lead->staff_id ?? "0";

    $caller = DB::table('za_staff')->select('za_staff.*', 'za_department.department_name')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->where('za_staff.status', '!=', '2')
      ->where('za_staff.sno', $staff_id)
      ->first();

    $incoming_call_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('za_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('za_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('za_call_log.status', 1)                             // Status is 1
      ->count();

    $incoming_call_count = $incoming_call_count ?? 0;

    // Get the outgoing call count excluding the phone numbers in company_cug_detail
    $outgoingcall_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('za_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('za_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('za_call_log.status', 0)                             // Status is 0
      ->where('za_call_log.duration', '!=', '00:00:00')            // Duration is not '00:00:00'
      ->count();

    // Assign the result to a variable
    $outgoingcall_count = $outgoingcall_count ?? 0;

    // missed call
    $missedcall_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('za_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('za_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('za_call_log.status', 2)                             // Status is 2 for missed calls
      ->where('za_call_log.missed_status', 0)                      // Missed status is 0
      ->count();

    $rejected_call_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.staff_id', $staff_id)                   // Filter by user ID
      ->whereDate('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->whereDate('za_call_log.call_date', '<=', $call_end_date)   // End date filter
      ->where('za_call_log.redirected_to', 0)                      // Redirected to 0
      ->where('za_call_log.status', 3)                             // Status is 3 for rejected calls
      ->count();

    // Assign the result to a variable
    $rejected_call_count = $rejected_call_count ?? 0;

    // Assign the result to a variable
    $missedcall_count = $missedcall_count ?? 0;

    $missed_call_ratio = 0;

    if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
      $total_calls = $incoming_call_count + $missedcall_count + $rejected_call_count;
      if ($total_calls > 0) {
        $missed_call_ratio = ($missedcall_count / $total_calls) * 100;
        $missed_call_ratio = $missed_call_ratio;
      } else {
        $missed_call_ratio = 0;
      }
    }

    $outgoing_call_ratio = 0;

    if ($incoming_call_count > 0 || $missedcall_count >= 0 || $rejected_call_count >= 0) {
      $total_calls_all = $incoming_call_count + $missedcall_count + $rejected_call_count + $outgoingcall_count;
      if ($total_calls > 0) {
        $outgoing_call_ratio = ($outgoingcall_count / $total_calls_all) * 100;
        $outgoing_call_ratio = $outgoing_call_ratio;
      } else {
        $outgoing_call_ratio = 0;
      }
    }

    $calls = DB::table('za_call_log')->select('za_call_log.*', 'za_contact_book.contact_name', 'za_contact_book.phone_no', 'za_lead.lead_name')
      ->join('za_contact_book', 'za_contact_book.contact_book_id', '=', 'za_call_log.contact_book_id', 'left')
      ->leftJoin('za_lead', DB::raw("SUBSTRING(za_contact_book.phone_no, 4)"), '=', 'za_lead.lead_mobile')
      ->where('za_call_log.staff_id', $staff_id)               // Filter by user ID
      ->where('za_call_log.staff_id', $staff_id)               // Filter by user ID
      ->where('za_call_log.call_date', '>=', $call_start_date) // Start date filter
      ->where('za_call_log.call_date', '<=', $call_end_date);

    // return $status;
    if (isset($status) && $status != 0) {
      if ($status == '2') {
        $calls->whereIn('za_call_log.status', [2, 3]);
      } elseif ($status == '1') {
        $calls->where('za_call_log.status', $status);
      }
    } else {
      $calls->where('za_call_log.status', 0);
    }

    $calls = $calls->orderBy('za_call_log.call_log_id', 'desc')->paginate($perpage);

    $filter = false;

    return view('content.sales.manage_calls.indiv_call_history', [
      'calls'               => $calls,
      'perpage'             => $perpage,
      'caller'              => $caller,
      'incoming_call_count' => $incoming_call_count,
      'outgoingcall_count'  => $outgoingcall_count,
      'missedcall_count'    => $missedcall_count,
      'rejected_call_count' => $rejected_call_count,
      'missed_call_ratio'   => $missed_call_ratio,
      'outgoing_call_ratio' => $outgoing_call_ratio,
      'date_filter'         => $date_filter,
      'status_fill'         => $status_fill,
      'fin_yr_fill'         => $fin_yr_fill,
      'from_date_filter'    => $from_date_filter,
      'to_date_filter'      => $to_date_filter,
      'filter'              => $filter,
    ]);
  }

  public function handleWebhookcatch(Request $request)
  {
    // Log the incoming payload for debugging
    // Log::info('Webhook received:', $request->all());
    echo "<script>console.log(" . json_encode($request->all()) . ");</script>";
    // Extract messages from the incoming payload
    $messages = $request->input('entry.0.changes.0.value.messages') ?? [];

    foreach ($messages as $message) {
      $userPhone = $message['from'] ?? null; // User's phone number
      $buttonText = $message['button']['text'] ?? null; // Button text clicked by the user

      if ($userPhone && $buttonText) {
        // Check the button response and send a corresponding reply
        if ($buttonText === 'Yes') {
          $this->sendReply($userPhone, 'Thank you for accepting the offer!');
        } elseif ($buttonText === 'No') {
          $this->sendReply($userPhone, 'No worries! Let us know if you have any questions.');
        } else {
          Log::info("Unhandled button response: $buttonText");
        }
      }
    }

    return response()->json(['status' => 'success']);
  }

  protected function sendReply($userPhone, $messageText)
  {
    $messageData = [
      'messaging_product' => 'whatsapp',
      'to' => $userPhone,
      'type' => 'text',
      'text' => [
        'body' => $messageText,
      ],
    ];

    $apiUri = "https://graph.facebook.com/v21.0/{$this->phoneNumberId}/messages";

    $response = Http::withHeaders([
      'Authorization' => 'Bearer ' . $this->accessToken,
    ])->post($apiUri, $messageData);

    if ($response->successful()) {
      Log::info('Reply sent successfully', ['response' => $response->json()]);
    } else {
      Log::error('Failed to send reply', ['error' => $response->json()]);
    }
  }
  // convert lead branch

  public function ConvertLeadBranch($id, Request $request)
  {
    $user_id = $request->user()->user_id;
    $lead    = LeadModel::where('sno', $id)->first();
    $helper  = new \App\Helpers\Helpers();

    if ($lead) {
      $lead->branch_id    = $request->convert_branch_id;
      $lead->created_by   = $request->convert_staff_id;
      $lead->updated_by   = $user_id;
      $lead->converted_by = $user_id;
      $lead->update();
      if ($lead->update()) {
        return response([
          'status'    => 200,
          'message'   => 'Successfully Branch Converted!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }
    }
    return response([
      'status'    => 200,
      'message'   => 'Successfully Branch Converted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  // staff for conver branch

  public function BranchStaffList(Request $request)
  {
    $branch_id = $request->input('branch_id');
    $dept_id   = 1; // sales department
    $staff     = StaffModel::select('za_staff.*', 'za_job_position.job_position_name as position_name')
      ->where('za_staff.status', 0)
      ->where('za_staff.department_id', $dept_id)
      ->join('za_job_position', 'za_job_position.sno', "=", "za_staff.position_role")
      ->where('za_staff.branch_id', $branch_id);
    $staff = $staff->orderBy('za_staff.staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $staff,
    ], 200);
  }

  // Hot lead status change
  public function HotLeadStatus($id, Request $request)
  {

    $lead = LeadModel::where('sno', $id)->first();

    $lead->lead_status_id = $request->status;
    if ($request->status == 3) {
      $lead->is_hot_lead = 1;
      $lead->last_hot_lead_date = date('Y-m-d');
    }
    $lead->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  // verify confirm spam
  public function ConfirmSpamLead(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }

    $id = $request->lead_id;
    $verify_reason_spam = $request->verify_reason_spam;
    $user_id = $request->user()->user_id;

    $spam_lead_upd = LeadModel::where('sno', $id)->first();

    if (!$spam_lead_upd) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'data'      => null,
      ], 200);
    }
    if ($request->verified_by == 1) {
      $spam_lead_upd->spam_tl_verified = 1;
      $spam_lead_upd->spam_tl_reason = $verify_reason_spam;
    } elseif ($request->verified_by == 2) {
      $spam_lead_upd->spam_verified = 1;
      $spam_lead_upd->spam_bh_reason = $verify_reason_spam;
    }
    $spam_lead_upd->updated_by = $user_id;

    // return $spam_lead_upd;
    // return $spam_lead_upd;
    $spam_lead_upd->save();

    // Check if the update was successful
    if ($spam_lead_upd->wasChanged()) {
      session()->flash('toastr', [
        'type'    => 'success',
        'message' => 'Spam Verified Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type'    => 'error',
        'message' => 'Could not verify the Spam',
      ]);
    }

    // Return the updated lead or redirect
    return redirect()->back();
  }

  // convert spam to lead branch
  public function ConvertSpamToLead($id, Request $request)
  {
    // return $request;
    // Get user info from the request
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $old_staff_id = $request->old_staff_id;
    $lead = LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    // Check if lead exists
    if ($lead) {
      // Get lead history and check if it exists
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->where('current_staff_id', $old_staff_id)
        ->first();

      // If there's a lead history, update it
      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $request->convert_staff_id;
        $lead_history->transferred_from = 2; // from spam transfer
        $lead_history->update(); // Actually update the record
      }

      // Add a new history record for Spam conversion
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
      $add_history->current_staff_id = $old_staff_id;
      $add_history->change_staff_id = 0; // Indicating it's a spam transfer
      $add_history->transferred_from = 2; // Spam transfer
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save(); // Save the new history entry
      //   return response([
      //     'status' => 200,
      //     'message' => 'Successfully Lead Converted!',
      //     'error_msg' => null,
      //     'data' => $add_history,
      // ], 200);



      // Update lead details
      $lead->status = 0;
      $lead->spam_verified = 0;
      $lead->lead_status_id = 1;
      $lead->created_by = $request->convert_staff_id;
      $lead->updated_by = $user_id;
      $lead->converted_by = $user_id;
      // return $lead;
      // Update the lead in the database
      if ($lead->update()) {
        // Define point category and calculate points
        $pointsData = $helper->get_points_by_id(11);
        $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string

        // Save new points for the staff
        $newPoints = new StaffpointsModel();
        $newPoints->branch_id = $branch_id;
        $newPoints->staff_id = $old_staff_id;
        $newPoints->points_by = $lead->sno;
        $newPoints->points_id = 1; // Assuming 1 represents the category for Lead Conversion
        $newPoints->points = $point;
        $newPoints->reason = $reason;
        $newPoints->save();

        // Update staff's available points
        $staff_points = StaffModel::where('sno', $old_staff_id)->first();
        if ($staff_points) {
          $staff_points->avaiable_points += $point; // Increment the available points
          $staff_points->save();
        }

        // Return success response
        return response([
          'status' => 200,
          'message' => 'Successfully Lead Converted!',
          'error_msg' => null,
          'data' => null,
        ], 200);
      }
    }

    // If no lead was found or the update failed, return an error
    return response([
      'status' => 400, // 400 Bad Request as the lead was not found or could not be updated
      'message' => 'Failed to convert lead. Lead not found or an error occurred.',
      'error_msg' => 'No lead found with the given ID.',
      'data' => null,
    ], 400);
  }

  // verify confirm drop
  public function ConfirmDropLead(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required|max:255',
    ]);
    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }
    $id = $request->lead_id;
    $verify_reason_drop = $request->verify_reason_drop;
    $user_id = $request->user()->user_id;

    $drop_lead_upd = LeadModel::where('sno', $id)->first();

    if (!$drop_lead_upd) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'data'      => null,
      ], 200);
    }
    if ($request->verified_by == 1) {
      $drop_lead_upd->drop_tl_verified = 1;
      $drop_lead_upd->drop_tl_reason = $verify_reason_drop;
    } elseif ($request->verified_by == 2) {
      $drop_lead_upd->drop_verified = 1;
      $drop_lead_upd->drop_bh_reason = $verify_reason_drop;
    }
    $drop_lead_upd->updated_by = $user_id;
    // return $drop_lead_upd;
    $drop_lead_upd->save();

    if ($drop_lead_upd) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type'    => 'success',
        'message' => 'Drop Verified Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type'    => 'error',
        'message' => 'Could not Verified the Drop',
      ]);
    }
    return redirect()->back();
  }

  public function ConvertDropLead(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required|max:255',
    ]);
    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }
    $id = $request->lead_id;
    $user_id = $request->user()->user_id;
    $drop_lead_upd = LeadModel::where('sno', $id)->first();

    if (!$drop_lead_upd) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'data'      => null,
      ], 200);
    }
    $drop_lead_upd->drop_tl_verified = 0;
    $drop_lead_upd->drop_tl_reason = null;
    $drop_lead_upd->drop_verified = 0;
    $drop_lead_upd->status = 0;
    $drop_lead_upd->lead_status_id = 1;
    $drop_lead_upd->drop_bh_reason = null;
    $drop_lead_upd->updated_by = $user_id;
    $drop_lead_upd->save();

    if ($drop_lead_upd) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type'    => 'success',
        'message' => 'Convert to Lead Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type'    => 'error',
        'message' => 'Could not Convert to Lead',
      ]);
    }
    return redirect()->back();
  }

  // convert drop to lead branch
  // convert drop to lead branch
  public function ConvertDropToLead($id, Request $request)
  {
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $old_staff_id = $request->old_staff_id;
    $lead = LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    if ($lead) {
      // Check for an existing lead transfer log entry
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->where('current_staff_id', $old_staff_id)
        ->first();
      //  return $lead_history;

      // If an existing entry is found, update it
      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $request->convert_staff_id;
        $lead_history->transferred_from = 3; // from Dead Lead transfer
        $lead_history->update(); // Update the existing entry
      }

      // Create a new history entry (this will always be created)
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
      $add_history->current_staff_id = $old_staff_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 3; // from Dead Lead transfer
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      // return $add_history;
      $add_history->save(); // Always save the new entry

      // Proceed with updating the lead status
      $lead->status = 0;
      $lead->drop_verified = 0;
      $lead->lead_status_id = 1;
      $lead->created_by = $request->convert_staff_id;
      $lead->updated_by = $user_id;
      $lead->converted_by = $user_id;
      // return $lead;
      // Save the updated lead
      $lead->update();

      // Define point category and assign points
      $pointsData = $helper->get_points_by_id(12);
      $point = $pointsData ? $pointsData->points : 0;
      $reason = $pointsData ? $pointsData->points_name : '';

      // Save new points for the staff
      $newPoints = new StaffpointsModel();
      $newPoints->branch_id = $branch_id;
      $newPoints->staff_id = $old_staff_id;
      $newPoints->points_by = $lead->sno;
      $newPoints->points_id = 1;
      $newPoints->points = $point;
      $newPoints->reason = $reason;
      $newPoints->save();

      // Update staff's available points
      $staff_points = StaffModel::where('sno', $old_staff_id)->first();
      if ($staff_points) {
        $staff_points->avaiable_points += $point; // Increment the available points
        $staff_points->save();
      }

      // Return success response
      return response([
        'status'    => 200,
        'message'   => 'Successfully Lead Converted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

    // Return response if lead doesn't exist
    return response([
      'status'    => 400,
      'message'   => 'Lead not found!',
      'error_msg' => 'The lead with the given ID does not exist.',
      'data'      => null,
    ], 400);
  }

  public function AddSpam(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'lead_name_spam' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name           = $request->lead_name_spam ?? 'Unknown';
      $lead_mobile         = $request->lead_mobile_spam;
      $spam_reason            = $request->spam_reason;
      $reason_text            = $request->reason_text;
      $spam_comments            = $request->spam_comments;
      $branch_id       = $request->user()->branch_id;
      $user_id            = $request->user()->user_id;
      // dd($request);
      $chk = LeadModel::where('lead_mobile', ucwords($lead_mobile))->where('za_lead.branch_id', $branch_id)->where('status', '!=', 2)->first();
      // return $chk;
      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Mobile Number already created!'
        ]);
      } else {
        $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;

        $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $request_pay = sprintf("LED%04d", $next_number);
          $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
        }

        // return $request;

        $spam = SpamReasonModel::where('reason_name', $spam_reason)->first();
        // return $spam;

        $add_category = new LeadModel();
        $add_category->lead_id                 = $lead_id;
        $add_category->lead_name               = $lead_name;
        $add_category->lead_mobile             = $lead_mobile;
        if ($spam->comments_check ?? 0 == 1) {
          $add_category->spam_comments         = $spam_comments;
        }
        if ($request->spam_reason == 1) {
          $add_category->spam_reason           = $reason_text;
        } else {
          $add_category->spam_reason           = $spam_reason;
        }
        $add_category->lead_status_id          = 6;
        $add_category->status                  = 7;
        $add_category->registered_date               = date('Y-m-d');
        $add_category->branch_id               = $branch_id;
        $add_category->created_by              = $user_id;
        $add_category->updated_by              = $user_id;
        // return $add_category;
        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Spam Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      }
      // return $result;
      return redirect('sales/manage_lead');
    }
  }

  // bulk sales staff Convert
  //   public function bulkSalesStaffConversion(Request $request)
  //   {
  //     $checked = $request->checked;
  //     $assign_staff_id = $request->bulk_assign_staff_id;
  //     $user_id = $request->user()->user_id;
  //     $created_by = $request->created_by; // Get the created_by values from the request
  //     $count = isset($checked) ? count($checked) : 0;
  //     // return $checked;

  //     // return $request;

  //     if (isset($checked) && ! empty($checked)) {
  //       $success = true; // Flag for successful lead conversion

  //       foreach ($checked as $id) {
  //         // return $id;
  //         $lead = LeadModel::where('sno', $id)->first();
  //         // dd($lead);

  //         if ($lead) {
  //           // return $lead;
  //           foreach ($created_by as  $staff_id_old) {
  //             $lead_history = LeadTransferLogModel::where('lead_id', $id)->where('end_date', null)->where('current_staff_id', $staff_id_old)->first();
  //             // return $lead_history;
  //             if ($lead_history) {




  //               $add_history = new LeadTransferLogModel();
  //               $add_history->lead_id = $lead->sno;
  //               $add_history->branch_id = $lead->branch_id;
  //               $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
  //               $add_history->end_date = null;
  //               $add_history->current_staff_id = $assign_staff_id;
  //               $add_history->change_staff_id = $staff_id_old;
  //               $add_history->transferred_from = 1; // from Bulk transfer
  //               $add_history->created_by = $user_id;
  //               $add_history->updated_by = $user_id;
  //               // return $add_history;
  //               $add_history->save();

  //               $lead_history->end_date  = date('Y-m-d');
  //               $lead_history->change_staff_id = $assign_staff_id;
  //               $lead_history->save();

  //             } elseif(!$lead_history){

  //               $add_history = new LeadTransferLogModel();
  //               $add_history->lead_id = $lead->sno;
  //               $add_history->branch_id = $lead->branch_id;
  //               $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
  //               $add_history->end_date = null;
  //               $add_history->current_staff_id = $assign_staff_id;
  //               $add_history->change_staff_id = $staff_id_old;
  //               $add_history->transferred_from = 1; // from Bulk transfer
  //               $add_history->created_by = $user_id;
  //               $add_history->updated_by = $user_id;

  //               $add_history->save();
  //             }
  //           }
  //           // return $add_history;
  //           // return $lead;
  //           $lead->created_by   = $assign_staff_id;
  //           $lead->updated_by   = $user_id;
  //           $lead->converted_by = $user_id;

  //           if (! $lead->update()) {
  //             $success = false; // Mark as unsuccessful if save fails
  //           }
  //           $lead->update();
  //         }
  //       }

  //       // Set flash message based on success flag
  //       if ($success) {
  //         session()->flash('toastr', [
  //           'type'    => 'success',
  //           'message' => $count . ' Sales Staff Converted Successfully!',
  //         ]);
  //       } else {
  //         session()->flash('toastr', [
  //           'type'    => 'error',
  //           'message' => 'Could not add some Sales Staff conversion!',
  //         ]);
  //       }
  //     }

  //     return redirect('sales/manage_lead');
  //   }

  public function bulkSalesStaffConversion(Request $request)
  {
    $checked = $request->checked;
    $assign_staff_id = $request->bulk_assign_staff_id;
    $user_id = $request->user()->user_id;

    $count = isset($checked) ? count($checked) : 0;

    if (isset($checked) && !empty($checked)) {
      $success = true; // Flag for successful lead conversion

      foreach ($checked as $id) {
        $lead = LeadModel::where('sno', $id)->first();

        if ($lead) {
          $staff_id_old = $lead->created_by; // Current staff handling the lead

          // Check if there's an existing open lead history
          $lead_history = LeadTransferLogModel::where('lead_id', $id)
            ->where('end_date', null)
            ->where('current_staff_id', $staff_id_old)
            ->first();

          // Close previous transfer log if exists
          if ($lead_history) {
            $lead_history->end_date = date('Y-m-d');
            $lead_history->change_staff_id = $assign_staff_id;
            $lead_history->save();
          }

          // Prevent duplicate open log for the same staff
          $existingNewTransfer = LeadTransferLogModel::where('lead_id', $id)
            ->where('current_staff_id', $assign_staff_id)
            ->whereNull('end_date')
            ->first();

          if (!$existingNewTransfer) {
            $add_history = new LeadTransferLogModel();
            $add_history->lead_id = $lead->sno;
            $add_history->branch_id = $lead->branch_id;
            $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
            $add_history->end_date = null;
            $add_history->current_staff_id = $assign_staff_id;
            $add_history->change_staff_id = $staff_id_old;
            $add_history->transferred_from = 1; // Bulk transfer
            $add_history->created_by = $user_id;
            $add_history->updated_by = $user_id;
            $add_history->save();
          }

          // Update lead ownership
          $lead->created_by = $assign_staff_id;
          $lead->updated_by = $user_id;
          $lead->converted_by = $user_id;

          if (!$lead->update()) {
            $success = false;
          }
        }
      }

      // Flash success or error message
      if ($success) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => $count . ' Sales Staff Converted Successfully!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not convert some Sales Staff!',
        ]);
      }
    }

    return redirect('sales/manage_lead');
  }

  public function Rawspam(Request $request)
  {
    // Return the incoming request object for debugging
    // return $request;

    $id = $request->rawlead_id_spam;
    $raw_lead = RawLeadModel::where('sno', $id)->first();


    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status'    => 400,
          'message'   => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data'      => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id                 = $lead_id;
      $add_category->lead_name               = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile             = $raw_lead->lead_mobile;
      $add_category->lead_source_id          = $raw_lead->lead_source_id;
      $add_category->lead_group              = $raw_lead->lead_group;
      $add_category->branch_id               = $branch_check->sno;
      $add_category->created_by              = $request->user()->id;
      $add_category->updated_by              = $request->user()->id;
      $add_category->lead_status_id          = 6; // new lead
      $add_category->status                  = 7; // new lead
      $add_category->lead_condition          = 1; // standard lead
      $spam_reason_edit = $request->spam_reason_edit;
      $add_category->spam_reason = $spam_reason_edit;
      // return $spam_reason_edit;
      if ($spam_reason_edit == 1) {
        $add_category->spam_reason = $request->spam_reason_text;
      } else {
        $spam = SpamReasonModel::where('reason_name', $spam_reason_edit)->first();
        // return $spam;
        if ($spam->comments_check ?? 0 == 1) {
          $add_category->spam_comments = $request->spam_comments_text;
        }
      }
      // return $add_category;
      $add_category->save();

      if ($add_category) {
        // Update raw lead status
        $raw_lead->status = 2;
        $raw_lead->save();
      }
    }

    if ($add_category) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    }

    return redirect()->back();
  }

  public function Rawdrop(Request $request)
  {
    // Return the incoming request object for debugging
    // return $request;

    $id = $request->rawlead_id_drop;
    $raw_lead = RawLeadModel::where('sno', $id)->first();


    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status'    => 400,
          'message'   => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data'      => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id                 = $lead_id;
      $add_category->lead_name               = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile             = $raw_lead->lead_mobile;
      $add_category->lead_source_id          = $raw_lead->lead_source_id;
      $add_category->lead_group              = $raw_lead->lead_group;
      $add_category->branch_id               = $branch_check->sno;
      $add_category->created_by              = $request->user()->id;
      $add_category->updated_by              = $request->user()->id;
      $add_category->lead_status_id          = 4; // new lead
      $add_category->status                  = 5; // new lead
      $add_category->lead_condition          = 1; // standard lead
      $reason_edit = $request->reason_edit;
      $add_category->drop_reason = $reason_edit;
      // return $reason_edit;
      if ($reason_edit == 1) {
        $add_category->drop_reason = $request->drop_reason_text;
      } else {
        $drop = DropReasonModel::where('reason_name', $reason_edit)->first();
        // return $drop;
        if ($drop->comments_check == 1) {
          $add_category->drop_comments = $request->drop_comments_text;
        }
      }
      // return $add_category;
      $add_category->save();

      if ($add_category) {
        // Update raw lead status
        $raw_lead->status = 2;
        $raw_lead->save();
      }
    }

    if ($add_category) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    }

    return redirect()->back();
  }

  public function FutureLead($id, Request $request)
  {
    // return $id;
    $lead =  RawLeadModel::where('sno', $id)->first();
    $lead->status = $request->status;
    // return $lead;
    $lead->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully converted to Future Lead!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function ConvertWallettoLead(Request $request)
  {
    // return $request;
    $created_by = $request->user()->user_id;
    $id = $request->lead_id_wallet;

    $lead = LeadModel::where('sno', $id)->first();

    $lead->wallet_status = 0;
    $lead->status = 0;
    $lead->created_by = $created_by;
    // return $lead;
    $lead->update();
    return redirect()->back();
  }

  public function EditConvertBank($id)
  {
    $lead = RawLeadModel::where('status', 7)
      ->where('sno', $id)
      ->first();

    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    // return $lead;

    if ($lead && isset($lead->registered_date)) {
      $lead->registered_date = date($common_date_format, strtotime($lead->registered_date));
    } else {
      $lead->registered_date = date($common_date_format);
    }

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead,
    ], 200);
  }

  public function ConvertBanktoLead(Request $request)
  {
    // return $request;
    // Check if staff exists in the same branch with active status
    $staff_check = StaffModel::where('sno', $request->user()->user_id)
      ->where('status', 0)
      ->first(); // Get the first matching staff record

    // return $staff_check;
    $lead_name       = $request->lead_name;
    $lead_id       = $request->lead_id;
    $lead_gender     = $request->lead_gender;
    $lead_mobile     = $request->lead_mobile;
    $inter_calls     = $request->country_code_name_edit;
    $lead_source_id     = $request->lead_source_id_edit;
    $Know_tag = is_array($request->lead_Knowledge_edit_tag) ? json_encode($request->lead_Knowledge_edit_tag) : $request->lead_Knowledge_edit_tag;
    $course_id       = json_encode($request->course_id_edit);
    $lead_dob = isset($request->lead_dob) ? date('Y-m-d', strtotime($request->lead_dob)) : null;
    $lead_reg_date_up = isset($request->lead_reg_date_up) ? date('Y-m-d', strtotime($request->lead_reg_date_up)) : null;
    $upd_lead =  LeadModel::where('lead_mobile', $lead_mobile)->first();
    if ($upd_lead) {
      session()->flash('toastr', [
        'type'    => 'error',
        'message' => 'Lead Already exists',
      ]);
      return redirect('sales/manage_lead');
    } else {


      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status'    => 400,
          'message'   => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data'      => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id        = $lead_id;
      $add_category->lead_name      = ucwords(strtolower($lead_name));
      $add_category->lead_mobile    = $lead_mobile;
      $add_category->lead_source_id = $lead_source_id;
      $add_category->inter_calls = $inter_calls;
      $add_category->created_by     = $request->user()->user_id;  // Passed from front-end
      $add_category->branch_id      = $branch_check->sno;
      $add_category->updated_by     = $request->user()->user_id;
      $add_category->lead_status_id = 1; // new lead
      $add_category->lead_condition = 1; // standard lead
      // return $add_category;
      $add_category->save();


      if ($add_category) {
        $staff_check->lead_bank_count = $staff_check->lead_bank_count - 1;
        $staff_check->save();
        $raw_lead = RawLeadModel::where('sno', $request->lead_id)->where('status', '=', 7)->first();
        if ($raw_lead) {
          $raw_lead->status = 2;
          $raw_lead->update();
        }
      }
      return redirect('sales/manage_lead');
    }
  }

  public function wallet_status(Request $request)
  {
    // Return the incoming request object for debugging
    // return $request;

    $id = $request->lead_id_wallet;
    $staff_id = $request->staff_id_wallet;
    $lead = LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    if ($request) {
      $lead->wallet_status = 1;
      //   $lead->status = 9;
      // return $lead;
      $lead->update();
      $encryptedLeadId = $helper->encrypt_decrypt($id, 'encrypt');
    }

    if ($lead) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    }

    return redirect()->back();
  }

  public function bulk_bank_lead_conversion(Request $request)
  {
    // return $request;
    $checked = $request->checked;
    // $lead_source_id = $request->bulk_lead_source_id;
    $assign_staff_id = $request->bulk_assign_staff_id;
    $user_id = $request->user()->user_id;
    $count = isset($checked) ? count($checked) : 0;
    if (isset($checked) && !empty($checked)) {

      $success = true; // Flag for successful lead conversion

      foreach ($checked as $id) {
        $raw_lead = RawLeadModel::where('sno', $id)->first();
        // return $raw_lead;

        if ($raw_lead) {
          // Get the branch information
          $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

          if (!$branch_check) {
            return response([
              'status' => 400,
              'message' => 'Branch not found.',
              'error_msg' => 'Invalid branch ID.',
              'data' => null
            ], 400);
          }

          $branch_code = $branch_check->city_short_code;

          // Generate lead ID
          $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
          $year = date("Y");

          if (!$category_check) {
            $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
          } else {
            $data = $category_check->lead_id;
            $slice = explode("/", $data);
            $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
            $next_number = (int)$resultcus + 1;
            $request_pay = sprintf("LED%04d", $next_number);
            $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
          }

          // Create new lead
          $add_category = new LeadModel();
          $add_category->lead_id = $lead_id;
          $add_category->lead_name = ucfirst($raw_lead->lead_name);
          $add_category->lead_mobile = $raw_lead->lead_mobile;
          // $add_category->lead_source_id = $lead_source_id;
          $add_category->lead_group = $raw_lead->lead_group;
          $add_category->created_by = $assign_staff_id; // Same for updated_by
          $add_category->branch_id = $branch_check->sno; // Correct branch ID
          $add_category->updated_by = $user_id; // Same for updated_by
          $add_category->lead_status_id = 1; // new lead
          $add_category->lead_condition = 1; // standard lead
          // return $add_category;
          if (!$add_category->save()) {
            $success = false; // Mark as unsuccessful if save fails
          }

          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->transferred_from = 7; // from Bulk transfer
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();

          // Update raw lead status
          //   $staff = StaffModel::where('sno', $add_category->created_by)->first();
          //   if ($staff) {
          //     $staff->actual_lead_count += 1;
          //     $staff->original_lead_count += 1;
          //     // return $staff;
          //     $staff->save();
          //   }
          $raw_lead->status = 2;
          $raw_lead->save(); // Save changes to raw lead
        }
      }

      // Set flash message based on success flag
      if ($success) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => $count . ' Leads Converted Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add some leads conversion!'
        ]);
      }
    }

    return redirect('sales/manage_lead');
  }

  public function bank_lead_conversion(Request $request)
  {
    // return $request;
    $lead_id = $request->lead_id;
    $assign_staff_id = $request->assg_staff_add;
    $user_id = $request->user()->user_id;

    $raw_lead = RawLeadModel::where('sno', $lead_id)->first();
    // return $raw_lead;

    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status' => 400,
          'message' => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data' => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id = $lead_id;
      $add_category->lead_name = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile = $raw_lead->lead_mobile;
      // $add_category->lead_source_id = $lead_source_id;
      $add_category->lead_group = $raw_lead->lead_group;
      $add_category->created_by = $assign_staff_id; // Same for updated_by
      $add_category->branch_id = $branch_check->sno; // Correct branch ID
      $add_category->updated_by = $user_id; // Same for updated_by
      $add_category->lead_status_id = 1; // new lead
      $add_category->lead_condition = 1; // standard lead
      // return $add_category;
      if (!$add_category->save()) {
        $success = false; // Mark as unsuccessful if save fails
      }
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $add_category->sno;
      $add_history->branch_id = $add_category->branch_id;
      $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
      $add_history->current_staff_id = $add_category->created_by;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 6; // from Bulk transfer
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      // return $add_history;
      $add_history->save();

      $raw_lead->status = 2;
      $raw_lead->save(); // Save changes to raw lead
    }

    return redirect('sales/manage_lead');
  }

  public function LeadTransfer($id, Request $request)
  {
    // Fetch all logs including staff info
    $transfer_lead = LeadTransferLogModel::select(
      'za_lead_transfer_log.*',
      'current_staff.staff_name as current_staff_name',
      'current_staff.sno as current_sno',
      'change_staff.staff_name as change_staff_name',
      'change_staff.sno as change_sno'
    )
      ->leftJoin('za_staff as current_staff', 'current_staff.sno', '=', 'za_lead_transfer_log.current_staff_id')
      ->leftJoin('za_staff as change_staff', 'change_staff.sno', '=', 'za_lead_transfer_log.change_staff_id')
      ->where('lead_id', $id)
      ->where('za_lead_transfer_log.status', 0)
      ->orderBy('za_lead_transfer_log.sno', 'ASC') // Use 'sno' as the primary key
      ->get();

    // Find the latest open (null end_date) transfer by 'sno'
    $latestOpenTransferSno = $transfer_lead->firstWhere('end_date', null)?->sno;

    // Filter records: include only those with end_date or the latest open one
    $filtered = $transfer_lead->filter(function ($transfer) use ($latestOpenTransferSno) {
      return $transfer->end_date !== null || $transfer->sno === $latestOpenTransferSno;
    });

    // Format dates and calculate durations
    $filtered->each(function ($transfer) {
      if ($transfer->start_date && $transfer->end_date) {
        $startDate = Carbon::parse($transfer->start_date);
        $endDate = Carbon::parse($transfer->end_date);
        $daysDifference = $startDate->diffInDays($endDate);
        $transfer->days_difference = str_pad($daysDifference, 2, '0', STR_PAD_LEFT) . ' days';
      } else {
        $transfer->days_difference = '0 days';
      }

      if ($transfer->start_date) {
        $transfer->start_date = Carbon::parse($transfer->start_date)->format('d-M-Y');
      }
      if ($transfer->end_date) {
        $transfer->end_date = Carbon::parse($transfer->end_date)->format('d-M-Y');
      }
    });

    return response([
      'status' => 200,
      'message' => 'Successfully retrieved Data',
      'error_msg' => null,
      'data' => $filtered->values(), // Reset keys for clean JSON
    ], 200);
  }
  public function validatePhoneNumber(Request $request)
  {
    // API URL
    $url = 'http://apilayer.net/api/validate';
    // Your API access key
    $accessKey = '60af509a52f854bf5efbf11595874b5c';
    $countryCode = $request->country_sort_name_add;
    $phoneNumber = $request->lead_mobile_add;

    // Set up cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url . '?access_key=' . $accessKey . '&number=' . $phoneNumber . '&country_code=' . $countryCode . '&format=1');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
      return response()->json([
        'error' => 'cURL error: ' . curl_error($ch),
      ], 500);
    }

    curl_close($ch);
    $data = json_decode($response, true);

    // Check if the phone number is valid
    if (isset($data['valid']) && $data['valid']) {
      return response()->json([
        'valid' => true,
        'message' => 'Valid phone number.',
        'location' => $data['country_name'] . ' - ' . $data['location'],
        'carrier' => $data['carrier'] . ' - ' . $data['line_type']
      ]);
    } else {
      return response()->json([
        'valid' => false,
        'message' => 'Invalid phone number.',
        'location' => '-',
        'carrier' => '-'
      ]);
    }
  }
  // public function validatePhoneNumber(Request $request)
  // {
  //     // Truecaller API URL
  //     $url = 'https://api4.truecaller.com/v1/verifyNumber';

  //     // Your Truecaller API key
  //     $accessKey = 'IMmIV6598f2a57d414b14891834cf93306e18';

  //     $countryCode = $request->country_sort_name_add;
  //     $phoneNumber = $request->lead_mobile_add;

  //     // Set up cURL
  //     $ch = curl_init();
  //     curl_setopt($ch, CURLOPT_URL, $url);
  //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  //     curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  //     curl_setopt($ch, CURLOPT_POST, true);
  //     curl_setopt($ch, CURLOPT_HTTPHEADER, [
  //         'Content-Type: application/json',
  //         'Authorization: Bearer ' . $accessKey
  //     ]);
  //     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
  //         'phoneNumber' => $phoneNumber,
  //         'countryCode' => $countryCode
  //     ]));

  //     $response = curl_exec($ch);

  //     if (curl_errno($ch)) {
  //         return response()->json([
  //             'error' => 'cURL error: ' . curl_error($ch),
  //         ], 500);
  //     }

  //     curl_close($ch);
  //   return $data = json_decode($response, true);

  //     // Check if the phone number is valid
  //     if (isset($data['status']) && $data['status'] === 'VERIFIED') {
  //         return response()->json([
  //             'valid' => true,
  //             'message' => 'Valid phone number.',
  //             'name' => $data['name'] ?? '-',
  //             'carrier' => $data['carrier'] ?? '-',
  //             'location' => $data['city'] ?? '-',
  //         ]);
  //     } else {
  //         return response()->json([
  //             'valid' => false,
  //             'message' => 'Invalid phone number.',
  //             'name' => '-',
  //             'carrier' => '-',
  //             'location' => '-'
  //         ]);
  //     }
  // }

  public function syllabusMessage(Request $request)
  {
    // Validate the incoming request data
    $validator = Validator::make($request->all(), [
      'lead_id'  => 'required|exists:za_lead,sno',
      'course_id'  => 'required',
      // 'message' => 'required|string|max:500', // Adjust max length as needed

    ]);

    // If validation fails, return a response with errors
    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }
    $branch_id  = $request->user()->branch_id;
    $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

    $course_id_msg = $request->course_id;
    $course_type = 4;

    $courseData    = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name')->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')->where('za_course.status', 0)->where('za_course.sno', $course_id_msg)->first();

    $branch_name = " ";
    if ($branchData->branch_type == 1) {
      $branch_name = $branchData->branch_name;
    } elseif ($branchData->branch_type == 2) {
      $branch_name = $branchData->franchise_name;
    }

    // Extract the validated data
    $lead_id           = $request->lead_id;


    $user_id           = $request->user()->user_id;

    // return $request;
    // Find the lead based on lead_id
    $lead = LeadModel::where('sno', $lead_id)
      ->first();


    // If the lead is not found, return an error response
    if (! $lead) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'error_msg' => 'The lead with the given ID does not exist',
        'data'      => null,
      ], 200);
    }


    // Send email if email flag is set to true
    $cre = StaffModel::where('sno', $branchData->cre_id)->orderBy('sno', 'desc')->first();

    if ($lead->lead_email_id) {
      $email_template_id = 17;
      $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
      $genderPrefix = 'Mr/Ms'; // Default value
      if ($lead->lead_gender == 1) {
        $genderPrefix = 'Mr';
      } elseif ($lead->lead_gender == 2) {
        $genderPrefix = 'Ms';
      }
      $content     = $emailTemplate->email_subject;
      $content     = str_replace('#name', $lead->lead_name ?? "Mr/Mrs", $content);
      $content     = str_replace('#gender', $genderPrefix, $content);
      $content     = str_replace('#CREname', $cre->staff_name ?? "Alex", $content);
      $content     = str_replace('#Course',  $courseData->course_name ?? "course", $content);
      $content     = str_replace('#type',  $courseData->course_type_name ?? "Professional Course", $content);
      $content     = str_replace('#duration', $courseData->course_days ?? "45 Days", $content);
      $branchNo    = $branchData->mobile;
      $branchemail = $branchData->mail;
      $fbLink      = $branchData->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
      $instaLink   = $branchData->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
      // $content     = str_replace('#salesNo', $lead->lead_mobile ?? 'Branch Mobile', $content);
      $content     = str_replace('#CRENo', $branchData->sales_mobile ?? "9677781155", $content);
      $content     = str_replace('#mail',  $branchData->mail ?? 'info@elysiumacademy.org', $content);
      $content     = str_replace('#BranchName', $branch_name ?? 'Madurai Branch', $content);

      $mailData = [
        'url'         => 'Eapl.com',
        'subject'     => $emailTemplate->email_name,
        'content'     => $content,
        'branchNo'    => $branchNo,
        'branchemail' => $branchemail, // Use the message content from the request
        'fbLink'      => $fbLink,      // Use the message content from the request
        'instaLink'   => $instaLink,   // Use the message content from the request
        'salesMobile' => $branchData->sales_mobile ?? "9677781155",
      ];



      $documentPath = "https://erp.elysium.academy/course_attachments/" . $courseData->attachment;

      $to_address   = $lead->lead_email_id;
      $from_address = 'elysiumacademy@elysium.community';
      $from_name = 'Elysium Academy ' . "\xC2\xAE";
      Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name, $documentPath));
    }
    if ($lead->lead_mobile) {


      $templateName = 'eapl_erp_syllabus_send2';


      $hasHeader  = false; // Example flag: set based on template
      $hasBody    = false; // Example flag: set based on template
      $hasFooter  = false; // Example flag: set based on template
      $hasButton  = false;
      $components = [];
      $couponCode = "";
      $otp        = "";
      date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
      $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
      // $currentHour = date('H'); // Get current hour in 24-hour format
      if ($currentHour >= 5 && $currentHour < 12) {
        $greeting = 'Good Morning';
      } elseif ($currentHour >= 12 && $currentHour < 18) {
        $greeting = 'Good Afternoon';
      } else {
        $greeting = 'Good Evening';
      }
      $documentPath = "https://erp.elysium.academy/course_attachments/" . $courseData->attachment;

      switch ($templateName) {
        case 'eapl_erp_syllabus_send2':
          $headerImage = $documentPath;
          $couponCode  = 'DISCOUNT20';
          $buttonIndex = 0;
          $bodyText    = [
            [
              'type'           => 'text',
              'text'           => $lead->lead_name,
              'parameter_name' => 'lead_name',
            ],
            [
              'type'           => 'text',
              'text'           => $courseData->course_name ?? "Java Course",
              'parameter_name' => 'course_name',
            ],
            [
              'type'           => 'text',
              'text'           => $courseData->course_type_name ?? "Professional Course",
              'parameter_name' => 'course_type',
            ],
            [
              'type'           => 'text',
              'text'           => $courseData->course_days ?? "45 Days",
              'parameter_name' => 'course_duration',
            ],
            [
              'type'           => 'text',
              'text'           => $branch_data->website ?? "https://elysiumacademy.org/",
              'parameter_name' => 'insert_link',
            ],
            [
              'type'           => 'text',
              'text'           => $branch_data->sales_mobile ?? "9677781155",
              'parameter_name' => 'contact_no',
            ],
            [
              'type'           => 'text',
              'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
              'parameter_name' => 'contact_email',
            ],
            [
              'type'           => 'text',
              'text'           => $branch_name ?? 'Madurai Branch',
              'parameter_name' => 'branch_name',
            ],
          ];
          $hasHeader = true;
          $hasBody   = true;
          $hasButton = false;
          break;
        default:
          $bodyText    = [];
          $headerImage = ''; // Default empty header image
          $couponCode  = ''; // Default empty coupon code
          $otp         = ''; // Default empty coupon code
          $buttonIndex = -1;
          break;
      }

      // Add Header if required
      if ($hasHeader) {
        $components[] = [
          'type'       => 'header',
          'parameters' => [

            [
              "type" => "document",
              "document" => [
                "link" => $headerImage,
                "filename" => $courseData->course_name
              ]
            ],

          ],
        ];
      }

      // Add Body if required
      if ($hasBody) {
        $components[] = [
          'type'       => 'body',
          'parameters' => $bodyText,
        ];
      }

      // Add Footer if required
      if ($hasFooter) {
        $components[] = [
          'type'       => 'footer',
          'parameters' => [
            [
              'type'           => 'text',
              'text'           => 'This is the footer text.',
              'parameter_name' => 'footer_text',
            ],
          ],
        ];
      }

      // Add Button if required
      if ($hasButton) {
        if ($couponCode) {
          $components[] = [
            'type'       => 'button',
            'sub_type'   => 'copy_code',
            'index'      => $buttonIndex,
            'parameters' => [
              [
                'type'        => 'coupon_code',
                'coupon_code' => $couponCode,
              ],
            ],
          ];
        } elseif ($otp) {
          $components[] = [
            'type'       => 'button',
            'sub_type'   => 'url', // Change type to match API requirements
            'index'      => $buttonIndex,
            'parameters' => [
              [
                'type' => 'text',
                'text' => $otp,
              ],
            ],
          ];
        }
      }

      $dynamicParameters         = $templateParameters[$templateName] ?? [];
      $WhatsAppBusinessAccountId = $this->businessId;
      $accessToken               = $this->accessToken;
      $fromPhoneNumberId         = $this->phoneNumberId;
      $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

      $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
      $to           = $lead->lead_mobile;
      $languageCode = 'en';

      if (strpos($to, $countryCode) !== 0) {
        $to = $countryCode . $to;
      }

      $message = 'test~message';
      if (empty($components)) {
        $payload = [
          'messaging_product' => 'whatsapp',
          'to'                => $to,
          'type'              => 'template',
          'template'          => [
            'name'     => $templateName,
            'language' => [
              'code' => $languageCode,
            ],
          ],
        ];
      } else {
        $payload = [
          'messaging_product' => 'whatsapp',
          'to'                => $to,
          'type'              => 'template',
          'template'          => [
            'name'       => $templateName,
            'language'   => [
              'code' => $languageCode,
            ],
            'components' => $components,
          ],
        ];
      }

      $response = $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
       if ($response['status'] == 200) {
               // 2. Syallabus Send
                $log_branch_id = $branch_id;
                $unique_id = $lead_id;
                $source ='Lead';
                $log_phone_no =$to;
                $log_template_name =$templateName;

                $save_log = $this->WhatsappSendLog(
                                    $response,
                                    $payload,
                                    $log_phone_no,
                                    $log_template_name,
                                    $user_id,
                                    $log_branch_id,
                                    $unique_id,
                                    $source
                                );
        $lead_send_upd = LeadModel::where('sno', $lead->sno)->first();
        if ($lead_send_upd) {
          $lead_send_upd->updated_by   = $user_id;
          $lead_send_upd->document_send_count += 1;
          $lead_send_upd->update();
        }

        $messageId = $response['data']['messages'][0]['id'] ?? null;
        // $webhookPayload = [
        //     'entry' => [
        //         [
        //             'id'        => $messageId,
        //             'status'    => 'sent', // The initial status when the message is sent
        //             'lead_id'   => $lead_id,
        //             'timestamp' => now()->toIso8601String(), // Use the current timestamp
        //         ],
        //     ],
        // ];

        // $webhookUrl      = 'https://wa-eapl.glitch.me/webhook'; // Your webhook URL
        // $webhookResponse = Http::post($webhookUrl, $webhookPayload);

        // Include the webhook response in your API response
        return response([
          'status'         => 200,
          'message'        => 'Message sent successfully!',
          'data'           => $response['data'],
          'response_data'  => json_encode($response),
        ], 200);
      } else {
        return response([
          'status'    => 404,
          'message'   => 'Failed to send message',
          'error_msg' => $response['error'],
        ], 400);
      }
    }



    return response([
      'status'    => 200,
      'message'   => "Message sent successfully",
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function ConfirmInternalCalls(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }

    $id = $request->lead_id;
    $internal_veri_reason = $request->verify_reason_spam;
    $user_id = $request->user()->user_id;

    $spam_lead_upd = LeadModel::where('sno', $id)->first();

    if (!$spam_lead_upd) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'data'      => null,
      ], 200);
    }
    $spam_lead_upd->internal_verify = 1;
    $spam_lead_upd->internal_veri_reason = $internal_veri_reason;

    $spam_lead_upd->updated_by = $user_id;

    // return $spam_lead_upd;
    // return $spam_lead_upd;
    $spam_lead_upd->save();

    // Check if the update was successful
    if ($spam_lead_upd->wasChanged()) {
      session()->flash('toastr', [
        'type'    => 'success',
        'message' => 'Internal calls Verified Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type'    => 'error',
        'message' => 'Could not verify the Internal calls',
      ]);
    }

    // Return the updated lead or redirect
    return redirect()->back();
  }

  public function ConvertInternalToLead($id, Request $request)
  {
    // return $request;
    // Get user info from the request
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $old_staff_id = $request->old_staff_id;
    $reject_reason_spam = $request->reject_reason_spam;
    $lead = LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    // // Check if lead exists
    // if ($lead) {
    //     // Get lead history and check if it exists
    //     $lead_history = LeadTransferLogModel::where('lead_id', $id)
    //         ->where('current_staff_id', $old_staff_id)
    //         ->first();

    //     // If there's a lead history, update it
    //     if ($lead_history) {
    //         $lead_history->end_date = date('Y-m-d');
    //         $lead_history->change_staff_id = $request->convert_staff_id;
    //         $lead_history->transferred_from = 2; // from spam transfer
    //         $lead_history->update(); // Actually update the record
    //     }

    //     // Add a new history record for Spam conversion
    //     $add_history = new LeadTransferLogModel();
    //     $add_history->lead_id = $lead->sno;
    //     $add_history->branch_id = $lead->branch_id;
    //     $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
    //     $add_history->current_staff_id = $old_staff_id;
    //     $add_history->change_staff_id = 0; // Indicating it's a spam transfer
    //     $add_history->transferred_from = 2; // Spam transfer
    //     $add_history->created_by = $user_id;
    //     $add_history->updated_by = $user_id;
    //     $add_history->save(); // Save the new history entry
    //   //   return response([
    //   //     'status' => 200,
    //   //     'message' => 'Successfully Lead Converted!',
    //   //     'error_msg' => null,
    //   //     'data' => $add_history,
    //   // ], 200);


    // Update lead details
    $lead->status = 0;
    $lead->internal_verify = 2;
    $lead->internal_reject_reason = $reject_reason_spam;
    $lead->lead_status_id = 1;
    $lead->internal_status = 0;
    $lead->created_by = $request->old_staff_id;
    $lead->updated_by = $user_id;
    $lead->converted_by = $user_id;
    // return $lead;
    // Update the lead in the database
    if ($lead->update()) {
      // // Define point category and calculate points
      // $pointsData = $helper->get_points_by_id(11);
      // $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
      // $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string

      // // Save new points for the staff
      // $newPoints = new StaffpointsModel();
      // $newPoints->branch_id = $branch_id;
      // $newPoints->staff_id = $old_staff_id;
      // $newPoints->points_by = $lead->sno;
      // $newPoints->points_id = 1; // Assuming 1 represents the category for Lead Conversion
      // $newPoints->points = $point;
      // $newPoints->reason = $reason;
      // $newPoints->save();

      // // Update staff's available points
      // $staff_points = StaffModel::where('sno', $old_staff_id)->first();
      // if ($staff_points) {
      //     $staff_points->avaiable_points += $point; // Increment the available points
      //     $staff_points->save();
      // }

      // Return success response
      return response([
        'status' => 200,
        'message' => 'Successfully Lead Converted!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    }


    // If no lead was found or the update failed, return an error
    return response([
      'status' => 400, // 400 Bad Request as the lead was not found or could not be updated
      'message' => 'Failed to convert lead. Lead not found or an error occurred.',
      'error_msg' => 'No lead found with the given ID.',
      'data' => null,
    ], 400);
  }

  public function ConfirmSpamLeadBulk(Request $request){

    $bulkData = $request->bulk_data;

    if (!is_array($bulkData) || count($bulkData) == 0) {
      return response([
        'status'  => 400,
        'message' => 'Invalid or empty data received.',
        'success_list' => [],
        'error_list'   => []
      ], 200);
    }

    $user_id = $request->user()->user_id;

    $success_list = [];
    $error_list   = [];

    foreach ($bulkData as $item) {

        $lead_id = $item['sno'] ?? null;
        $reason  = $item['spam_reason'] ?? null;
        $verify_by = $item['spam_verify_by'] ?? null;

        if (!$lead_id) {
          $error_list[] = [
            'sno' => null,
            'message' => 'Missing lead id'
          ];
          continue;
        }

        // Fetch lead
        $lead = LeadModel::where('sno', $lead_id)->first();

        if (!$lead) {
          $error_list[] = [
            'sno' => $lead_id,
            'message' => 'Lead not found'
          ];
          continue;
        }

        // Update based on verified_by
        if ($verify_by == 1) {
          $lead->spam_tl_verified = 1;
          $lead->spam_tl_reason   = $reason;
        } 
        elseif ($verify_by == 2) {
          $lead->spam_verified    = 1;
          $lead->spam_bh_reason   = $reason;
        }

        $lead->updated_by = $user_id;

        // Save and store result
        if ($lead->save()) {
          $success_list[] = [
            'sno' => $lead_id,
            'message' => 'Spam Lead Verified successfully'
          ];
        } else {
          $error_list[] = [
            'sno' => $lead_id,
            'message' => 'Update failed'
          ];
        }
    }

    return response([
      'status'  => 200,
      'message' => 'Bulk Spam Lead verification completed.',
      'success_list' => $success_list,
      'error_list'   => $error_list,
    ], 200);
  }
  
  public function ConfirmDropLeadBulk(Request $request){

    $bulkData = $request->bulk_data;

    if (!is_array($bulkData) || count($bulkData) == 0) {
      return response([
        'status'  => 400,
        'message' => 'Invalid or empty data received.',
        'success_list' => [],
        'error_list'   => []
      ], 200);
    }

    $user_id = $request->user()->user_id;

    $success_list = [];
    $error_list   = [];

    foreach ($bulkData as $item) {

        $lead_id = $item['sno'] ?? null;
        $reason  = $item['drop_reason'] ?? null;
        $verify_by = $item['drop_verify_by'] ?? null;

        if (!$lead_id) {
          $error_list[] = [
            'sno' => null,
            'message' => 'Missing lead id'
          ];
          continue;
        }

        // Fetch lead
        $lead = LeadModel::where('sno', $lead_id)->first();

        if (!$lead) {
          $error_list[] = [
            'sno' => $lead_id,
            'message' => 'Lead not found'
          ];
          continue;
        }

        // Update based on verified_by
        if ($verify_by == 1) {
          $lead->drop_tl_verified = 1;
          $lead->drop_tl_reason   = $reason;
        } 
        elseif ($verify_by == 2) {
          $lead->drop_verified    = 1;
          $lead->drop_bh_reason   = $reason;
        }

        $lead->updated_by = $user_id;

        // Save and store result
        if ($lead->save()) {
          $success_list[] = [
            'sno' => $lead_id,
            'message' => 'Drop Lead Verified successfully'
          ];
        } else {
          $error_list[] = [
            'sno' => $lead_id,
            'message' => 'Update failed'
          ];
        }
    }

    return response([
      'status'  => 200,
      'message' => 'Bulk Drop Lead verification completed.',
      'success_list' => $success_list,
      'error_list'   => $error_list,
    ], 200);
  }
  
private function WhatsappSendLog(
            array $response,
            array $payload,
            string $phone_no,
            string $template_name,
            int $user_id,
            int $branch_id = 0,
            int $unique_id = 0,
            ?string $source = null
        ) {
            $messageId = $response['data']['messages'][0]['id'] ?? null;
 
            return WhatsappTemplateLogModel::create([
                'phone_no' => $phone_no,
                'branch_id' => $branch_id,
                'unique_id' => $unique_id,
                'id_source' => $source,
                'template_name' => $template_name,
                'message_date_time' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                'type' => 'template',
                'from' => 1,
                'wama_id' => $messageId,
                'payload' => json_encode($payload),
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'message_status' => 'sent',
            ]);
        }
    public function getNotClosedFollowups(Request $request)
  {
    $before48Hours = Carbon::now()->subHours(48);
 
    $appointments = DB::table('za_appointment as a')
      ->join('za_lead as l', 'l.sno', '=', 'a.lead_id')
      ->where('a.created_by', $request->created_by)
      ->where('a.status', 1) // Appointment Not Closed
      ->where('l.status', 0) // Lead status = 0 only
      ->where('a.appointment_date', '<=', $before48Hours)
      ->select(
        'a.lead_id',
        'l.lead_name',
        'l.lead_mobile',
        DB::raw("DATE_FORMAT(a.appointment_date, '%d-%m-%Y') as appointment_date")
      )
      ->distinct('a.lead_id')
      ->get();
 
    return response()->json([
      'count' => $appointments->count(),
      'data'  => $appointments
    ]);
  }
public function getNotClosedDead(Request $request)
  {
 
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $appointments = DB::table('za_lead')
      ->where('za_lead.created_by', $request->created_by)
    //   ->where('za_lead.is_dead', 1)
      ->where('za_lead.status', 5)
      ->where('za_lead.drop_verified', '!=', 1)
      ->where('za_lead.branch_id', $branch_id)
      ->select(
        'za_lead.lead_id',
        'za_lead.lead_name',
        'za_lead.lead_mobile',
      )
      ->get();
 
 
    return response()->json([
      'count' => $appointments->count(),
      'data'  => $appointments
    ]);
  }
 
  public function getNotClosedSpam(Request $request)
  {
 
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $appointments = DB::table('za_lead')
      ->where('za_lead.created_by', $request->created_by)
    //   ->where('za_lead.is_spam', 1)
      ->where('za_lead.status', 7)
      ->where('za_lead.spam_verified', '!=', 1)
      ->where('za_lead.branch_id', $branch_id)
      ->select(
        'za_lead.lead_id',
        'za_lead.lead_name',
        'za_lead.lead_mobile',
      )
      ->get();
 
 
    return response()->json([
      'count' => $appointments->count(),
      'data'  => $appointments
    ]);
  }
  
}
