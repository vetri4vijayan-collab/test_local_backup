@extends('layouts/layoutMaster')

@section('title', 'WhatsApp Control Center')

@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">
<style>
  .wa-console{--wa-green:#00a884;--wa-ink:#111b21;--wa-muted:#667781;--wa-bg:#f0f2f5;color:var(--wa-ink)}
  .wa-hero{background:linear-gradient(125deg,#0b5f50,#008f77 58%,#13aa89);color:#fff;border-radius:18px;padding:24px;box-shadow:0 12px 32px rgba(0,96,80,.15)}
  .wa-hero .sub{color:rgba(255,255,255,.78)}
  .wa-kill{background:#fff;border:1px solid #d9e3e8;color:#18252b;border-radius:999px;padding:9px 15px;font-weight:700}
  .wa-kill.is-on{background:#fff0f0;color:#b42318;border-color:#ffcdcd}
  .wa-tabs{display:flex;gap:7px;overflow:auto;padding:7px;background:#e9eef0;border-radius:12px}
  .wa-tab{border:0;background:transparent;color:#44545d;font-weight:650;padding:10px 15px;border-radius:9px;white-space:nowrap}
  .wa-tab.active{background:#fff;color:#006b59;box-shadow:0 2px 7px rgba(20,40,50,.08)}
  .wa-panel{background:#fff;border:1px solid #e0e6e9;border-radius:15px;padding:20px;min-width:0}
  .wa-stat{background:#fff;border:1px solid #e1e7ea;border-radius:14px;padding:17px;height:100%}
  .wa-stat .value{font-size:1.75rem;font-weight:800;letter-spacing:-.03em}
  .wa-stat .caption{font-size:.82rem;color:var(--wa-muted)}
  .wa-label{font-size:.78rem;color:#64747d;font-weight:750;letter-spacing:.035em;text-transform:uppercase;margin-bottom:6px}
  .wa-form-control{border:1px solid #d6e0e4;border-radius:9px;padding:10px 12px;width:100%;min-width:0;background:#fff}
  .wa-btn{border:0;border-radius:9px;background:var(--wa-green);color:#fff;padding:10px 15px;font-weight:700}
  .wa-btn.secondary{background:#e8f5f1;color:#006b59}
  .wa-btn.dark{background:#173b35}
  .wa-btn.danger{background:#bf2e2e}
  .wa-btn:disabled{opacity:.55;cursor:not-allowed}
  .wa-table{width:100%;border-collapse:separate;border-spacing:0;font-size:.86rem}
  .wa-table th{color:#657780;background:#f6f8f9;font-weight:750;font-size:.74rem;text-transform:uppercase;letter-spacing:.035em}
  .wa-table th,.wa-table td{padding:12px;border-bottom:1px solid #edf0f1;vertical-align:middle}
  .wa-pill{display:inline-flex;align-items:center;gap:5px;border-radius:999px;padding:4px 9px;font-size:.72rem;font-weight:800;background:#eef1f3;color:#47545b}
  .wa-pill.good{background:#e5f7ee;color:#087443}.wa-pill.warn{background:#fff5d8;color:#8d6500}.wa-pill.bad{background:#ffebeb;color:#a61b1b}.wa-pill.blue{background:#eaf2ff;color:#245ca8}
  .wa-muted{color:var(--wa-muted)}
  .wa-chat-shell{display:grid;grid-template-columns:minmax(220px,320px) minmax(0,1fr);min-height:550px;border:1px solid #dce4e7;border-radius:13px;overflow:hidden;background:#f7f9fa}
  .wa-chat-sidebar{background:#fff;border-right:1px solid #dde5e8;min-width:0}
  .wa-chat-head{padding:16px;border-bottom:1px solid #e6ecee;font-weight:800}
  .wa-contact-list{max-height:485px;overflow:auto}
  .wa-contact{display:flex;gap:10px;padding:12px 14px;border:0;border-bottom:1px solid #f0f2f3;background:#fff;text-align:left;width:100%;color:#17252b}
  .wa-contact:hover,.wa-contact.active{background:#e7f7f2}
  .wa-avatar{flex:0 0 38px;height:38px;border-radius:50%;display:grid;place-items:center;background:#d8f3e9;color:#006b59;font-weight:800}
  .wa-contact-info{min-width:0;flex:1}.wa-contact-phone{font-weight:750;font-size:.86rem}.wa-contact-preview{font-size:.76rem;color:#728088;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:210px}
  .wa-chat-main{display:flex;flex-direction:column;min-width:0;background-color:#efeae2;background-image:radial-gradient(rgba(255,255,255,.48) 1px,transparent 1px);background-size:14px 14px}
  .wa-chat-top{padding:15px;background:#f7f9f9;border-bottom:1px solid #dce4e7;display:flex;align-items:center;justify-content:space-between;gap:10px}
  .wa-chat-messages{flex:1;min-height:380px;max-height:480px;overflow:auto;padding:20px;display:flex;flex-direction:column;gap:8px}
  .wa-bubble{padding:10px 12px;max-width:min(75%,520px);border-radius:10px;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.05);white-space:pre-wrap;overflow-wrap:anywhere;font-size:.89rem}
  .wa-bubble.out{align-self:flex-end;background:#d9fdd3}.wa-bubble-meta{font-size:.68rem;color:#6a7b73;text-align:right;margin-top:5px}
  .wa-chat-compose{display:flex;gap:8px;padding:13px;background:#f7f9f9;border-top:1px solid #dce4e7}.wa-chat-compose input{border-radius:999px}
  .wa-empty{display:grid;place-items:center;text-align:center;padding:32px;color:#728088;min-height:220px}
  .wa-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.8rem;background:#f5f7f8;border-radius:8px;padding:8px;overflow:auto;max-height:180px;white-space:pre-wrap}
  @media(max-width:900px){.wa-chat-shell{grid-template-columns:1fr}.wa-chat-sidebar{border-right:0;border-bottom:1px solid #dde5e8}.wa-contact-list{max-height:230px}.wa-chat-messages{min-height:280px}.wa-hero{padding:18px}}
</style>

<div class="container-fluid wa-console">
  <div class="wa-hero mb-4">
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3">
      <div>
        <div class="text-uppercase small fw-bold mb-2" style="letter-spacing:.16em">ERP Communication Suite</div>
        <h2 class="text-white mb-2">WhatsApp Control Center</h2>
        <div class="sub">Templates · customer conversations · consent · campaigns · delivery telemetry</div>
      </div>
      <div class="d-flex flex-wrap align-items-center gap-2">
        <label class="small fw-semibold" for="wa-branch">Branch</label>
        <input id="wa-branch" class="form-control" style="width:100px" type="number" min="1" value="{{ $defaultBranchId }}">
        <button id="wa-kill-switch" class="wa-kill" type="button">Global kill switch: loading…</button>
      </div>
    </div>
  </div>

  <div id="wa-alert" class="alert d-none" role="status"></div>

  <div class="row g-3 mb-4" id="wa-stats">
    <div class="col-6 col-xl"><div class="wa-stat"><div class="caption">Queued</div><div class="value" id="stat-queued">—</div><span class="wa-pill blue">Outbox</span></div></div>
    <div class="col-6 col-xl"><div class="wa-stat"><div class="caption">Accepted by Meta</div><div class="value" id="stat-sent">—</div><span class="wa-pill">Sent</span></div></div>
    <div class="col-6 col-xl"><div class="wa-stat"><div class="caption">Delivered</div><div class="value" id="stat-delivered">—</div><span class="wa-pill good">Delivery</span></div></div>
    <div class="col-6 col-xl"><div class="wa-stat"><div class="caption">Read</div><div class="value" id="stat-read">—</div><span class="wa-pill good">Engagement</span></div></div>
    <div class="col-6 col-xl"><div class="wa-stat"><div class="caption">Failed / Blocked</div><div class="value"><span id="stat-failed">—</span><small class="text-muted"> / </small><span id="stat-blocked">—</span></div><span class="wa-pill bad">Needs review</span></div></div>
  </div>

  <div class="wa-tabs mb-3" role="tablist">
    <button class="wa-tab active" data-wa-tab="overview">Overview</button>
    <button class="wa-tab" data-wa-tab="chats">Chats</button>
    <button class="wa-tab" data-wa-tab="templates">Templates</button>
    <button class="wa-tab" data-wa-tab="workflows">Automation rules</button>
    <button class="wa-tab" data-wa-tab="campaigns">Bulk campaigns</button>
    <button class="wa-tab" data-wa-tab="audiences">Custom audiences</button>
    <button class="wa-tab" data-wa-tab="outbox">Message logs</button>
    <button class="wa-tab" data-wa-tab="profiles">API profiles</button>
    <button class="wa-tab" data-wa-tab="consent">Consent</button>
  </div>

  <section class="wa-tab-panel" data-wa-panel="overview">
    <div class="row g-3">
      <div class="col-xl-7"><div class="wa-panel h-100">
        <div class="d-flex justify-content-between align-items-center gap-2 mb-3"><div><h5 class="mb-1">Operational status</h5><div class="wa-muted small">Sending is stopped by either the global kill switch or the branch profile toggle.</div></div><button class="wa-btn secondary" id="wa-refresh-overview">Refresh</button></div>
        <div id="wa-health" class="d-flex flex-column gap-2"><div class="wa-empty">Loading channel health…</div></div>
      </div></div>
      <div class="col-xl-5"><div class="wa-panel h-100">
        <h5 class="mb-1">Production guardrails</h5><p class="wa-muted small mb-3">This console uses the official Meta Cloud API; it does not bypass restrictions or template approval.</p>
        <div class="d-flex flex-column gap-3">
          <div><span class="wa-pill good">01 · Consent first</span><div class="small mt-1">Template initiation requires recorded, category-matching opt-in evidence.</div></div>
          <div><span class="wa-pill blue">02 · 24-hour window</span><div class="small mt-1">Free-form replies are allowed only while the last inbound customer message is within 24 hours.</div></div>
          <div><span class="wa-pill warn">03 · Queue & pacing</span><div class="small mt-1">Outbox jobs are paced per branch and ambiguous timeouts are not automatically retried.</div></div>
          <div><span class="wa-pill bad">04 · Fail closed</span><div class="small mt-1">Unapproved/disabled templates, opt-outs, missing consent or the kill switch block a send.</div></div>
        </div>
      </div></div>
    </div>
  </section>

  <section class="wa-tab-panel d-none" data-wa-panel="chats">
    <div class="wa-panel mb-3"><div class="d-flex flex-wrap justify-content-between align-items-center gap-2"><div><h5 class="mb-1">Conversations</h5><div class="wa-muted small">Lead / customer / unknown contacts. Free-form replies require an open 24-hour service window.</div></div><div class="d-flex flex-wrap gap-2"><input id="wa-chat-search" class="wa-form-control" style="width:210px" placeholder="Search phone"><select id="wa-chat-kind" class="wa-form-control" style="width:145px"><option value="all">All contacts</option><option value="lead">Leads</option><option value="customer">Customers</option><option value="unknown">Unknown</option></select><button id="wa-chat-refresh" class="wa-btn secondary">Refresh</button></div></div></div>
    <div class="wa-chat-shell">
      <aside class="wa-chat-sidebar"><div class="wa-chat-head">Messages <span class="wa-pill" id="wa-chat-count">0</span></div><div class="wa-contact-list" id="wa-contact-list"><div class="wa-empty">Loading conversations…</div></div></aside>
      <div class="wa-chat-main">
        <div class="wa-chat-top"><div><div id="wa-active-phone" class="fw-bold">Choose a conversation</div><div id="wa-session-state" class="small wa-muted">Select a contact to view messages</div></div><button class="wa-btn secondary" id="wa-open-template-send" disabled>Send template</button></div>
        <div class="wa-chat-messages" id="wa-chat-messages"><div class="wa-empty">Your conversation will appear here.</div></div>
        <form class="wa-chat-compose" id="wa-chat-form"><input id="wa-chat-text" class="wa-form-control" placeholder="Type a reply (24-hour window only)…" maxlength="4096" disabled><button class="wa-btn" id="wa-chat-send" disabled>Send</button></form>
      </div>
    </div>
  </section>

  <section class="wa-tab-panel d-none" data-wa-panel="templates">
    <div class="wa-panel">
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><div><h5 class="mb-1">Meta template registry</h5><div class="wa-muted small">Sync approved, pending, paused and rejected template metadata from the selected WABA.</div></div><div class="d-flex gap-2"><select id="wa-template-status" class="wa-form-control" style="width:150px"><option value="">All statuses</option><option>APPROVED</option><option>PENDING</option><option>REJECTED</option><option>PAUSED</option><option>DISABLED</option></select><button id="wa-template-sync" class="wa-btn">Sync from Meta</button></div></div>
      <div class="table-responsive"><table class="wa-table"><thead><tr><th>Template</th><th>Language</th><th>Category</th><th>Meta status</th><th>ERP status</th><th>Action</th></tr></thead><tbody id="wa-template-rows"><tr><td colspan="6" class="wa-muted">Load templates to begin.</td></tr></tbody></table></div>
      <hr class="my-4"><h6>Quick template send</h6><div class="wa-muted small mb-3">The template must be approved, enabled and supported by recorded opt-in evidence.</div>
      <form id="wa-send-template-form"><div class="row g-3"><div class="col-lg-3"><label class="wa-label">Recipient (E.164)</label><input id="wa-template-to" class="wa-form-control" placeholder="+919876543210" required></div><div class="col-lg-3"><label class="wa-label">Template name</label><input id="wa-template-name" class="wa-form-control" placeholder="welcome_template" required></div><div class="col-lg-2"><label class="wa-label">Language</label><input id="wa-template-language" class="wa-form-control" value="en_US" required></div><div class="col-lg-4"><label class="wa-label">Meta components JSON</label><textarea id="wa-template-components" class="wa-form-control" rows="2" placeholder='[{"type":"body","parameters":[{"type":"text","text":"Asha"}]}]'></textarea></div><div class="col-12"><button class="wa-btn" type="submit">Queue template message</button></div></div></form>
    </div>
  </section>

  <section class="wa-tab-panel d-none" data-wa-panel="workflows">
    <div class="row g-3">
      <div class="col-lg-5"><div class="wa-panel">
        <h5 class="mb-1">Event → template rule</h5>
        <p class="wa-muted small">The event key is called from ERP controller/service code. This form dynamically chooses the approved template and language for the selected branch. Template variables still come from the event-specific payload mapping in code.</p>
        <form id="wa-workflow-form">
          <div class="mb-3"><label class="wa-label">Event key</label><input id="wa-workflow-event" class="wa-form-control" required maxlength="100" pattern="[a-z][a-z0-9_.-]{1,99}" placeholder="lead.created"></div>
          <div class="row g-3 mb-3"><div class="col-8"><label class="wa-label">Template name</label><input id="wa-workflow-template" class="wa-form-control" required maxlength="191" placeholder="elysium_academy_welcome_message"></div><div class="col-4"><label class="wa-label">Language</label><input id="wa-workflow-language" class="wa-form-control" required maxlength="20" value="en_US"></div></div>
          <div class="mb-3"><label class="wa-label">Admin notes</label><input id="wa-workflow-notes" class="wa-form-control" maxlength="500" placeholder="Lead created welcome message"></div>
          <div class="form-check mb-3"><input id="wa-workflow-enabled" class="form-check-input" type="checkbox" checked><label class="form-check-label" for="wa-workflow-enabled">Enable this workflow event</label></div>
          <button class="wa-btn" type="submit">Save workflow rule</button>
        </form>
      </div></div>
      <div class="col-lg-7"><div class="wa-panel"><div class="d-flex justify-content-between align-items-center mb-3"><div><h5 class="mb-1">Branch automation map</h5><div class="wa-muted small">Disabled rules block the corresponding automatic send.</div></div><button id="wa-workflow-refresh" class="wa-btn secondary" type="button">Refresh</button></div>
        <div class="table-responsive"><table class="wa-table"><thead><tr><th>Event</th><th>Template / language</th><th>State</th><th>Action</th></tr></thead><tbody id="wa-workflow-rows"><tr><td colspan="4" class="wa-muted">Load automation rules to begin.</td></tr></tbody></table></div>
      </div></div>
    </div>
  </section>

  <section class="wa-tab-panel d-none" data-wa-panel="campaigns">
    <div class="wa-panel">
      <h5 class="mb-1">Bulk template campaign</h5><p class="wa-muted small">Campaigns are queued recipient-by-recipient, paced, deduplicated, and checked against opt-in/template rules before send. Start with a tiny opted-in test batch.</p>
      <form id="wa-bulk-form"><div class="row g-3">
        <div class="col-md-4"><label class="wa-label">Template name</label><input id="wa-bulk-template" class="wa-form-control" required placeholder="approved_template_name"></div>
        <div class="col-md-2"><label class="wa-label">Language</label><input id="wa-bulk-language" class="wa-form-control" value="en_US" required></div>
        <div class="col-md-2"><label class="wa-label">Pacing (sec/recipient)</label><input id="wa-bulk-pace" type="number" min="5" max="60" class="wa-form-control" value="10" required></div>
        <div class="col-md-4"><label class="wa-label">Shared template components JSON</label><textarea id="wa-bulk-components" class="wa-form-control" rows="2" placeholder='[]'></textarea></div>
        <div class="col-12"><label class="wa-label">Recipients · one international number per line</label><textarea id="wa-bulk-recipients" class="wa-form-control" rows="7" placeholder="+919876543210&#10;+919876543211&#10;+919876543212" required></textarea><div class="form-text">Configured hard cap: {{ config('whatsapp.bulk_max_recipients', 250) }} recipients per request. Invalid numbers are rejected; recipients without consent are recorded as blocked in the outbox.</div></div>
        <div class="col-12 d-flex flex-wrap align-items-center gap-2"><button class="wa-btn" type="submit">Validate & queue campaign</button><span class="wa-muted small">No messages are sent when the global or branch switch is off.</span></div>
      </div></form><div id="wa-bulk-result" class="mt-3"></div>
    </div>
  </section>

  <section class="wa-tab-panel d-none" data-wa-panel="audiences">
    <div class="row g-3"><div class="col-lg-5"><div class="wa-panel"><h5>Create custom audience</h5><p class="wa-muted small">Saved ERP recipient lists, not native WhatsApp group chats. Every recipient is still checked for consent.</p><form id="wa-audience-form"><label class="wa-label">Audience name</label><input id="wa-audience-name" class="wa-form-control mb-3" maxlength="120" required placeholder="Event October attendees"><label class="wa-label">Description</label><textarea id="wa-audience-description" class="wa-form-control mb-3" rows="2" placeholder="How this audience was defined"></textarea><button class="wa-btn">Create audience</button></form><hr><form id="wa-audience-members-form"><label class="wa-label">Audience</label><select id="wa-audience-id" class="wa-form-control mb-3" required></select><label class="wa-label">Numbers to add (one E.164 number per line)</label><textarea id="wa-audience-phones" class="wa-form-control mb-3" rows="5" required placeholder="+919876543210"></textarea><button class="wa-btn secondary">Add audience members</button><div class="form-text mt-2">Audience membership is not consent. Every bulk send still checks consent separately.</div></form></div></div><div class="col-lg-7"><div class="wa-panel"><h5>Saved audiences</h5><div id="wa-audience-list" class="d-flex flex-column gap-2"><div class="wa-muted">Loading audiences…</div></div></div></div></div>
  </section>

  <section class="wa-tab-panel d-none" data-wa-panel="outbox">
    <div class="wa-panel"><div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><div><h5 class="mb-1">Outbox & delivery log</h5><div class="wa-muted small">“Sent” means Meta accepted the API request; delivered/read are updated by status webhooks.</div></div><div class="d-flex gap-2"><select id="wa-log-status" class="wa-form-control" style="width:135px"><option value="">All statuses</option><option>queued</option><option>processing</option><option>sent</option><option>delivered</option><option>read</option><option>failed</option><option>blocked</option><option>unknown</option></select><input id="wa-log-search" class="wa-form-control" style="width:190px" placeholder="Phone / template / error"><button id="wa-log-refresh" class="wa-btn secondary">Refresh</button></div></div>
      <div class="table-responsive"><table class="wa-table"><thead><tr><th>ID / Date</th><th>Recipient</th><th>Message</th><th>Status</th><th>Meta ID</th><th>Reason</th></tr></thead><tbody id="wa-outbox-rows"><tr><td colspan="6" class="wa-muted">Loading outbox…</td></tr></tbody></table></div>
    </div>
  </section>

  <section class="wa-tab-panel d-none" data-wa-panel="profiles">
    <div class="row g-3"><div class="col-lg-7"><div class="wa-panel"><h5 class="mb-1">Meta Cloud API profile</h5><p class="wa-muted small">Tokens are encrypted server-side and never returned to this page. Leave the token blank to keep the saved token.</p>
      <form id="wa-config-form"><div class="row g-3"><div class="col-md-4"><label class="wa-label">Branch ID</label><input id="wa-config-branch" class="wa-form-control" type="number" min="1" required></div><div class="col-md-4"><label class="wa-label">Provider</label><select id="wa-config-provider" class="wa-form-control"><option value="meta_cloud_api">Meta Cloud API</option></select></div><div class="col-md-4"><label class="wa-label">Graph API version</label><input id="wa-config-version" class="wa-form-control" value="v26.0" pattern="v[0-9]+\.0" required></div><div class="col-md-6"><label class="wa-label">WhatsApp Business Account ID</label><input id="wa-config-waba" class="wa-form-control" required></div><div class="col-md-6"><label class="wa-label">Phone number ID</label><input id="wa-config-phone-id" class="wa-form-control" required></div><div class="col-12"><label class="wa-label">System-user access token</label><input id="wa-config-token" class="wa-form-control" type="password" autocomplete="new-password" placeholder="Paste to replace token; hidden after save"></div><div class="col-md-6"><label class="wa-label">Minimum send interval (seconds)</label><input id="wa-config-pace" class="wa-form-control" type="number" min="1" max="300" value="10" required></div><div class="col-md-6 d-flex align-items-end"><label class="d-flex align-items-center gap-2 mb-2"><input id="wa-config-enabled" type="checkbox"> Enable this branch profile</label></div><div class="col-12 d-flex flex-wrap gap-2"><button class="wa-btn">Save encrypted profile</button><button class="wa-btn secondary" id="wa-config-test" type="button">Test Meta connection</button></div></div></form></div></div>
      <div class="col-lg-5"><div class="wa-panel"><h5>Saved profiles</h5><div class="table-responsive"><table class="wa-table"><thead><tr><th>Branch</th><th>Phone ID</th><th>State</th><th>Action</th></tr></thead><tbody id="wa-config-rows"><tr><td colspan="4" class="wa-muted">Loading profiles…</td></tr></tbody></table></div><div class="small wa-muted mt-3">Use a dedicated system-user token with only required WhatsApp permissions. Rotate any token that was ever committed to source or shared in logs.</div></div></div>
    </div>
  </section>

  <section class="wa-tab-panel d-none" data-wa-panel="consent">
    <div class="row g-3"><div class="col-lg-5"><div class="wa-panel"><h5>Record verified consent / opt-out</h5><p class="wa-muted small">Record only actual evidence from the recipient. Do not use this screen to infer consent from a phone number, CRM entry, or group membership.</p><form id="wa-consent-form"><div class="mb-3"><label class="wa-label">Phone (E.164)</label><input id="wa-consent-phone" class="wa-form-control" required placeholder="+919876543210"></div><div class="row g-3 mb-3"><div class="col-6"><label class="wa-label">Category</label><select id="wa-consent-category" class="wa-form-control"><option value="all">All permitted messages</option><option value="utility">Utility</option><option value="marketing">Marketing</option><option value="authentication">Authentication</option></select></div><div class="col-6"><label class="wa-label">Status</label><select id="wa-consent-status" class="wa-form-control"><option value="opted_in">Opted in</option><option value="opted_out">Opted out</option></select></div></div><div class="mb-3"><label class="wa-label">Source</label><input id="wa-consent-source" class="wa-form-control" required placeholder="Website form / signed paper form"></div><div class="mb-3"><label class="wa-label">Evidence reference</label><textarea id="wa-consent-evidence" class="wa-form-control" rows="3" required placeholder="Consent event ID or secure record reference (avoid putting sensitive message content here)"></textarea></div><button class="wa-btn">Save consent record</button></form></div></div><div class="col-lg-7"><div class="wa-panel"><h5>Consent operating rule</h5><p class="wa-muted">Template sends are blocked unless the newest applicable evidence is opted in and its category matches the synced template. An inbound STOP/UNSUBSCRIBE/CANCEL/END/QUIT writes an all-category opt-out. Keep proof of when, where, and what the recipient agreed to receive, and honor requests across channels.</p><div class="wa-code">A contact list is a targeting list, not consent. A template approved by Meta is not a substitute for recipient opt-in. A new Meta app is not a way to bypass an existing app, WABA, or business restriction.</div></div></div></div>
  </section>
</div>

<script>
(function($){
  'use strict';
  var base='/wa-management', activePhone=null, sessionOpen=false, templatesCache=[], configsCache=[];
  function branch(){return parseInt($('#wa-branch').val()||'1',10)||1;}
  function csrf(){return $('meta[name="csrf-token"]').attr('content');}
  function escapeHtml(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];});}
  function waTicks(status){status=String(status||'').toLowerCase();if(status==='read')return '<span title="Read" style="color:#34a7e8;font-weight:800">✓✓</span>';if(status==='delivered')return '<span title="Delivered" style="color:#667781;font-weight:800">✓✓</span>';if(status==='sent')return '<span title="Sent to Meta" style="color:#667781;font-weight:800">✓</span>';if(status==='failed'||status==='blocked')return '<span title="Failed" style="color:#c43131;font-weight:800">!</span>';if(status==='queued'||status==='processing')return '<span title="Pending">◷</span>';return escapeHtml(status);}
  function alertBox(message,type){var el=$('#wa-alert');el.removeClass('d-none alert-success alert-danger alert-warning alert-info').addClass('alert-'+(type||'info')).text(message);window.setTimeout(function(){el.addClass('d-none');},6500);}
  function api(path,method,data,success){return $.ajax({url:base+path,type:method||'GET',data:data||{},headers:{'X-CSRF-TOKEN':csrf(),'Accept':'application/json'},dataType:'json'}).done(function(r){if(success)success(r);}).fail(function(xhr){var r=xhr.responseJSON||{};alertBox(r.message||'Request failed. Check permissions and application logs.','danger');});}
  function setBusy($el,busy,text){if(busy){$el.data('old-text',$el.text()).prop('disabled',true).text(text||'Working…');}else{$el.prop('disabled',false).text($el.data('old-text')||'Submit');}}
  function loadOverview(){api('/overview','GET',{branch_id:branch()},function(d){['queued','sent','delivered','read','failed','blocked'].forEach(function(k){$('#stat-'+k).text(d[k]||0);});$('#wa-kill-switch').toggleClass('is-on',d.global_kill_switch).text(d.global_kill_switch?'Global kill switch: ON':'Global kill switch: OFF');$('#wa-health').html('<div class="d-flex justify-content-between align-items-center border-bottom pb-2"><span>Branch profile</span>'+(d.profile_enabled?'<span class="wa-pill good">Enabled</span>':'<span class="wa-pill bad">Disabled</span>')+'</div><div class="d-flex justify-content-between align-items-center border-bottom pb-2"><span>Synced templates</span><strong>'+d.templates_total+'</strong></div><div class="d-flex justify-content-between align-items-center border-bottom pb-2"><span>Meta-approved templates</span><strong>'+d.templates_approved+'</strong></div><div class="d-flex justify-content-between align-items-center border-bottom pb-2"><span>Messages with unknown delivery state</span><span class="wa-pill '+(d.unknown?'warn':'good')+'">'+d.unknown+'</span></div><div class="small wa-muted pt-2">API acceptance and delivery receipts are separate states. Inspect failed and unknown rows before retrying.</div>');});}
  function pill(s){s=String(s||'unknown').toLowerCase();var cls=(['sent','delivered','read','approved'].indexOf(s)>=0)?'good':(['queued','processing','pending'].indexOf(s)>=0?'blue':(['blocked','unknown','paused'].indexOf(s)>=0?'warn':'bad'));return '<span class="wa-pill '+cls+'">'+escapeHtml(s)+'</span>';}
  function loadTemplates(){api('/templates','GET',{branch_id:branch(),status:$('#wa-template-status').val()},function(d){templatesCache=d.data||[];var html='';templatesCache.forEach(function(t){var schema=String(t.components_json||'[]');html+='<tr><td><div class="fw-bold">'+escapeHtml(t.name)+'</div><div class="small wa-muted">Meta ID: '+escapeHtml(t.meta_template_id||'—')+'</div><details class="small mt-1"><summary>Component schema</summary><pre class="wa-code">'+escapeHtml(schema)+'</pre></details></td><td>'+escapeHtml(t.language)+'</td><td>'+escapeHtml(t.category)+'</td><td>'+pill(t.approval_status)+'</td><td>'+(t.is_enabled?'<span class="wa-pill good">Enabled</span>':'<span class="wa-pill">Disabled</span>')+'</td><td><div class="d-flex flex-wrap gap-2"><button class="wa-btn secondary wa-template-use" data-name="'+escapeHtml(t.name)+'" data-language="'+escapeHtml(t.language)+'">Use</button><button class="wa-btn '+(t.is_enabled?'danger':'')+' wa-template-toggle" data-id="'+t.id+'" data-enabled="'+(t.is_enabled?'0':'1')+'" '+(String(t.approval_status).toUpperCase()!=='APPROVED'&&!t.is_enabled?'disabled':'')+'>'+(t.is_enabled?'Disable':'Enable')+'</button></div></td></tr>';});$('#wa-template-rows').html(html||'<tr><td colspan="6" class="wa-muted">No templates found. Save API profile and sync from Meta.</td></tr>');});}
  function loadConfigs(){api('/configs','GET',{},function(d){configsCache=d.data||[];var html='';configsCache.forEach(function(c){html+='<tr><td>'+c.branch_id+'</td><td>'+escapeHtml(c.phone_number_id)+'</td><td>'+(c.is_enabled?'<span class="wa-pill good">Enabled</span>':'<span class="wa-pill">Disabled</span>')+'</td><td><button class="wa-btn secondary wa-config-load" data-branch="'+c.branch_id+'">Edit</button> <button class="wa-btn '+(c.is_enabled?'danger':'')+' wa-config-toggle" data-branch="'+c.branch_id+'" data-enabled="'+(c.is_enabled?'0':'1')+'">'+(c.is_enabled?'Off':'On')+'</button></td></tr>';});$('#wa-config-rows').html(html||'<tr><td colspan="4" class="wa-muted">No saved profiles.</td></tr>');$('#wa-kill-switch').toggleClass('is-on',!!d.global_kill_switch).text(d.global_kill_switch?'Global kill switch: ON':'Global kill switch: OFF');});}
  function loadOutbox(){api('/outbox','GET',{branch_id:branch(),status:$('#wa-log-status').val(),q:$('#wa-log-search').val()},function(d){var html='';(d.data||[]).forEach(function(x){html+='<tr><td><strong>#'+x.id+'</strong><div class="small wa-muted">'+escapeHtml(x.created_at||'')+'</div></td><td>'+escapeHtml(x.phone_e164)+'</td><td><strong>'+escapeHtml(x.message_type==='template'?x.template_name:'Text message')+'</strong><div class="small wa-muted">'+escapeHtml(x.source_type)+(x.workflow_event_key?'<br><span class="wa-muted">Event: '+escapeHtml(x.workflow_event_key)+'</span>':'')+'</div></td><td>'+pill(x.status)+'</td><td><div class="small" style="max-width:150px;overflow-wrap:anywhere">'+escapeHtml(x.meta_message_id||'—')+'</div></td><td><div class="small" style="max-width:260px;overflow-wrap:anywhere">'+escapeHtml(x.error_message||'—')+'</div></td></tr>';});$('#wa-outbox-rows').html(html||'<tr><td colspan="6" class="wa-muted">No outbox records.</td></tr>');});}
  function loadChats(){api('/conversations','GET',{branch_id:branch(),kind:$('#wa-chat-kind').val(),q:$('#wa-chat-search').val()},function(d){var html='';(d.data||[]).forEach(function(c){var p=String(c.phone||'');html+='<button class="wa-contact '+(activePhone&&activePhone===p?'active':'')+'" data-phone="'+escapeHtml(p)+'"><span class="wa-avatar">'+escapeHtml(p.replace(/\D/g,'').slice(-2)||'WA')+'</span><span class="wa-contact-info"><span class="d-flex justify-content-between gap-2"><span class="wa-contact-phone">'+escapeHtml(p)+'</span><span class="wa-pill">'+escapeHtml(c.contact_kind)+'</span></span><span class="wa-contact-preview">'+escapeHtml(c.last_message||'No messages yet')+'</span></span></button>';});$('#wa-contact-list').html(html||'<div class="wa-empty">No contacts in this filter.</div>');$('#wa-chat-count').text((d.data||[]).length);if(activePhone) $('.wa-contact[data-phone="'+activePhone.replace(/"/g,'')+'"]').addClass('active');});}
  function loadMessages(phone){activePhone=phone;$('#wa-active-phone').text(phone);$('#wa-chat-text,#wa-chat-send,#wa-open-template-send').prop('disabled',false);$('#wa-chat-messages').html('<div class="wa-empty">Loading conversation…</div>');api('/conversations/'+encodeURIComponent(phone)+'/messages','GET',{branch_id:branch()},function(d){sessionOpen=!!d.session_open;$('#wa-session-state').html(sessionOpen?'<span class="wa-pill good">24-hour window open</span> · Last inbound '+escapeHtml(d.last_inbound_at||''):'<span class="wa-pill warn">24-hour window closed</span> · Use an approved template');$('#wa-chat-text').prop('disabled',!sessionOpen);$('#wa-chat-send').prop('disabled',!sessionOpen);var html='';(d.data||[]).forEach(function(m){var out=String(m.from)==='1';html+='<div class="wa-bubble '+(out?'out':'')+'">'+escapeHtml(m.message||'['+m.type+']')+(m.media_url?'<div><small>'+escapeHtml(m.media_caption||m.media_type||'Media')+'</small></div>':'')+'<div class="wa-bubble-meta">'+escapeHtml(m.message_date_time||'')+' · '+waTicks(m.message_status)+'</div></div>';});$('#wa-chat-messages').html(html||'<div class="wa-empty">No messages stored for this contact.</div>');var el=$('#wa-chat-messages')[0];el.scrollTop=el.scrollHeight;});}
  function loadWorkflows(){api('/workflows','GET',{branch_id:branch()},function(d){var html='';(d.data||[]).forEach(function(r){html+='<tr><td><strong>'+escapeHtml(r.event_key)+'</strong><div class="small wa-muted">'+escapeHtml(r.notes||'')+'</div></td><td>'+escapeHtml(r.template_name)+'<div class="small wa-muted">'+escapeHtml(r.language)+'</div></td><td>'+(r.is_enabled?'<span class="wa-pill good">Enabled</span>':'<span class="wa-pill">Disabled</span>')+'</td><td><button class="wa-btn '+(r.is_enabled?'danger':'secondary')+' wa-workflow-toggle" data-id="'+r.id+'" data-enabled="'+(r.is_enabled?'0':'1')+'">'+(r.is_enabled?'Disable':'Enable')+'</button></td></tr>';});$('#wa-workflow-rows').html(html||'<tr><td colspan="4" class="wa-muted">No workflow rules configured for this branch.</td></tr>');});}
  function loadAudiences(){api('/audiences','GET',{branch_id:branch()},function(d){var data=d.data||[],options='',cards='';data.forEach(function(a){options+='<option value="'+a.id+'">'+escapeHtml(a.name)+'</option>';cards+='<div class="d-flex justify-content-between align-items-center border rounded-3 p-3"><div><strong>'+escapeHtml(a.name)+'</strong><div class="small wa-muted">'+escapeHtml(a.description||'No description')+'</div></div><span class="wa-pill">Audience #'+a.id+'</span></div>';});$('#wa-audience-id').html(options||'<option value="">Create an audience first</option>');$('#wa-audience-list').html(cards||'<div class="wa-empty">No audiences saved yet.</div>');});}
  function activateTab(name){$('.wa-tab').removeClass('active');$('.wa-tab[data-wa-tab="'+name+'"]').addClass('active');$('.wa-tab-panel').addClass('d-none');$('.wa-tab-panel[data-wa-panel="'+name+'"]').removeClass('d-none');if(name==='overview')loadOverview();if(name==='chats')loadChats();if(name==='templates')loadTemplates();if(name==='workflows')loadWorkflows();if(name==='outbox')loadOutbox();if(name==='profiles')loadConfigs();if(name==='audiences')loadAudiences();}
  function parseComponents(value){if(!String(value||'').trim())return [];var v=JSON.parse(value);if(!Array.isArray(v))throw new Error('Components must be a JSON array.');return v;}
  $('.wa-tab').on('click',function(){activateTab($(this).data('wa-tab'));});
  $('#wa-branch').on('change',function(){loadOverview();loadConfigs();var active=$('.wa-tab.active').data('wa-tab');if(active==='templates')loadTemplates();if(active==='workflows')loadWorkflows();if(active==='chats')loadChats();if(active==='outbox')loadOutbox();if(active==='audiences')loadAudiences();});
  $('#wa-refresh-overview').on('click',loadOverview);$('#wa-chat-refresh').on('click',loadChats);$('#wa-chat-kind').on('change',loadChats);$('#wa-chat-search').on('keydown',function(e){if(e.key==='Enter'){e.preventDefault();loadChats();}});$('#wa-template-status').on('change',loadTemplates);$('#wa-log-refresh').on('click',loadOutbox);$('#wa-log-status').on('change',loadOutbox);$('#wa-log-search').on('keydown',function(e){if(e.key==='Enter'){e.preventDefault();loadOutbox();}});
  $('#wa-kill-switch').on('click',function(){var currently=$(this).hasClass('is-on');if(!window.confirm(currently?'Disable the global kill switch and allow branch-controlled sending?':'Enable GLOBAL kill switch and block all new sends?'))return;api('/kill-switch','POST',{enabled:!currently},function(d){alertBox(d.message,'warning');loadOverview();loadConfigs();});});
  $('#wa-workflow-refresh').on('click',loadWorkflows);
  $('#wa-workflow-form').on('submit',function(e){e.preventDefault();api('/workflows','POST',{branch_id:branch(),event_key:$('#wa-workflow-event').val().trim(),template_name:$('#wa-workflow-template').val().trim(),language:$('#wa-workflow-language').val().trim(),notes:$('#wa-workflow-notes').val(),is_enabled:$('#wa-workflow-enabled').is(':checked')?1:0},function(d){alertBox(d.message,'success');loadWorkflows();});});
  $(document).on('click','.wa-workflow-toggle',function(){var b=$(this);api('/workflows/'+b.data('id')+'/toggle','POST',{enabled:b.data('enabled')==='1'},function(d){alertBox(d.message,'success');loadWorkflows();});});
  $('#wa-template-sync').on('click',function(){var b=$(this);setBusy(b,true,'Syncing…');api('/templates/sync','POST',{branch_id:branch()},function(d){alertBox(d.message||'Sync complete.','success');loadTemplates();loadOverview();}).always(function(){setBusy(b,false);});});
  $(document).on('click','.wa-template-toggle',function(){var b=$(this);api('/templates/'+b.data('id')+'/toggle','POST',{enabled:b.data('enabled')==='1'},function(d){alertBox(d.message,'success');loadTemplates();});});
  $(document).on('click','.wa-template-use',function(){$('#wa-template-name').val($(this).data('name'));$('#wa-template-language').val($(this).data('language'));activateTab('templates');$('#wa-template-to').trigger('focus');});
  $('#wa-send-template-form').on('submit',function(e){e.preventDefault();var components;try{components=parseComponents($('#wa-template-components').val());}catch(err){alertBox(err.message,'danger');return;}api('/send/template','POST',{branch_id:branch(),to:$('#wa-template-to').val(),template_name:$('#wa-template-name').val(),language:$('#wa-template-language').val(),components:components},function(d){alertBox(d.message||('Template '+d.status+' (outbox #'+d.id+').'),d.status==='blocked'?'warning':'success');loadOverview();});});
  $('#wa-bulk-form').on('submit',function(e){e.preventDefault();var lines=$('#wa-bulk-recipients').val().split(/\r?\n/).map(function(x){return x.trim();}).filter(Boolean),components;try{components=parseComponents($('#wa-bulk-components').val());}catch(err){alertBox(err.message,'danger');return;}if(!lines.length){alertBox('Enter at least one recipient.','warning');return;}if(lines.length>{{ (int) config('whatsapp.bulk_max_recipients', 250) }}){alertBox('Recipient cap exceeded. Split into smaller reviewed batches.','danger');return;}if(!window.confirm('Queue '+lines.length+' recipients? Only recipients with matching consent and approved templates will be sent.'))return;api('/send/bulk','POST',{branch_id:branch(),template_name:$('#wa-bulk-template').val(),language:$('#wa-bulk-language').val(),pacing_seconds:$('#wa-bulk-pace').val(),components:components,recipients:lines.map(function(to){return {to:to,components:components};})},function(d){$('#wa-bulk-result').html('<div class="alert alert-info">Campaign '+escapeHtml(d.campaign_id)+': '+d.queued+' queued, '+d.blocked+' blocked. See Message logs for per-recipient reasons.</div>');alertBox('Bulk validation complete. Review blocked recipients before any remediation.','success');loadOverview();});});
  $('#wa-config-form').on('submit',function(e){e.preventDefault();api('/config','POST',{branch_id:$('#wa-config-branch').val(),provider:$('#wa-config-provider').val(),waba_id:$('#wa-config-waba').val(),phone_number_id:$('#wa-config-phone-id').val(),graph_api_version:$('#wa-config-version').val(),access_token:$('#wa-config-token').val(),min_send_interval_seconds:$('#wa-config-pace').val(),is_enabled:$('#wa-config-enabled').is(':checked')?1:0},function(d){$('#wa-config-token').val('');alertBox(d.message,'success');loadConfigs();loadOverview();});});
  $('#wa-config-test').on('click',function(){api('/config/test','POST',{branch_id:$('#wa-config-branch').val()||branch()},function(d){alertBox(d.message,d.ok?'success':'danger');loadConfigs();});});
  $(document).on('click','.wa-config-load',function(){var id=parseInt($(this).data('branch'),10),c=configsCache.find(function(x){return parseInt(x.branch_id,10)===id;});if(!c)return;$('#wa-config-branch').val(c.branch_id);$('#wa-config-provider').val(c.provider);$('#wa-config-version').val(c.graph_api_version);$('#wa-config-waba').val(c.waba_id);$('#wa-config-phone-id').val(c.phone_number_id);$('#wa-config-pace').val(c.min_send_interval_seconds);$('#wa-config-enabled').prop('checked',c.is_enabled);$('#wa-config-token').val('');});
  $(document).on('click','.wa-config-toggle',function(){var b=$(this);api('/config/'+b.data('branch')+'/toggle','POST',{enabled:b.data('enabled')==='1'},function(d){alertBox(d.message,'success');loadConfigs();loadOverview();});});
  $('#wa-chat-form').on('submit',function(e){e.preventDefault();if(!activePhone)return;var body=$('#wa-chat-text').val().trim();if(!body)return;if(!sessionOpen){alertBox('The 24-hour window is closed. Use the approved template flow.','warning');activateTab('templates');$('#wa-template-to').val(activePhone);return;}$('#wa-chat-send').prop('disabled',true);api('/send/text','POST',{branch_id:branch(),to:activePhone,text:body},function(d){$('#wa-chat-text').val('');alertBox('Reply queued. Outbox #'+d.id,'success');window.setTimeout(function(){loadMessages(activePhone);},1200);}).always(function(){$('#wa-chat-send').prop('disabled',!sessionOpen);});});
  $(document).on('click','.wa-contact',function(){var p=$(this).data('phone');$('.wa-contact').removeClass('active');$(this).addClass('active');loadMessages(p);});
  $('#wa-open-template-send').on('click',function(){activateTab('templates');$('#wa-template-to').val(activePhone||'');});
  $('#wa-audience-form').on('submit',function(e){e.preventDefault();api('/audiences','POST',{branch_id:branch(),name:$('#wa-audience-name').val(),description:$('#wa-audience-description').val()},function(d){alertBox(d.message,'success');$('#wa-audience-name,#wa-audience-description').val('');loadAudiences();});});
  $('#wa-audience-members-form').on('submit',function(e){e.preventDefault();var phones=$('#wa-audience-phones').val().split(/\r?\n/).map(function(x){return x.trim();}).filter(Boolean);api('/audiences/'+$('#wa-audience-id').val()+'/members','POST',{phones:phones},function(d){alertBox(d.message+' Added '+d.added+'; invalid '+(d.invalid||[]).length+'.','success');$('#wa-audience-phones').val('');});});
  $('#wa-consent-form').on('submit',function(e){e.preventDefault();api('/consent','POST',{branch_id:branch(),phone:$('#wa-consent-phone').val(),category:$('#wa-consent-category').val(),consent_status:$('#wa-consent-status').val(),source:$('#wa-consent-source').val(),evidence_ref:$('#wa-consent-evidence').val()},function(d){alertBox(d.message,'success');$('#wa-consent-form')[0].reset();});});
  $('#wa-config-branch').val(branch());loadOverview();loadConfigs();
})(jQuery);
</script>
@endsection
