<?php

namespace App\Http\Controllers;

use App\Models\WhatsAppAutomationConfig;
use App\Services\WhatsAppManagerService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;

class WhatsAppManagementController extends Controller
{
    public function __construct()
    {
        // Set WHATSAPP_ADMIN_USER_IDS before exposing these routes. Empty list intentionally fails closed.
        $this->middleware(function ($request, $next) {
            $user = $request->user();
            $allowed = array_map('strval', config('whatsapp.admin_user_ids', []));
            $userId = $user ? (string) ($user->user_id ?? $user->id ?? '') : '';
            abort_unless($user && $allowed && in_array($userId, $allowed, true), 403, 'WhatsApp management requires an authorized ERP administrator.');
            return $next($request);
        });
    }

    public function index(Request $request)
    {
        return view('content.whatsapp_management.index', [
            'pageConfigs' => ['myLayout' => 'default'],
            'defaultBranchId' => (int) ($request->user()->branch_id ?? 1),
        ]);
    }

    public function overview(Request $request)
    {
        $branchId = max(1, (int) $request->query('branch_id', $request->user()->branch_id ?? 1));
        $counts = DB::table('za_whatsapp_outbox')->where('branch_id', $branchId)
            ->select('status', DB::raw('COUNT(*) as total'))->groupBy('status')->pluck('total', 'status');
        $settings = DB::table('za_whatsapp_automation_settings')->where('branch_id', $branchId)->first();
        $templates = DB::table('za_whatsapp_template_registry')->where('branch_id', $branchId);
        return response()->json([
            'ok' => true,
            'branch_id' => $branchId,
            'global_kill_switch' => (bool) DB::table('za_whatsapp_automation_settings')->where('branch_id', 0)->value('kill_switch'),
            'profile_enabled' => (bool) ($settings->is_enabled ?? false),
            'templates_total' => (clone $templates)->count(),
            'templates_approved' => (clone $templates)->where('approval_status', 'APPROVED')->count(),
            'queued' => (int) ($counts['queued'] ?? 0),
            'sent' => (int) ($counts['sent'] ?? 0),
            'delivered' => (int) ($counts['delivered'] ?? 0),
            'read' => (int) ($counts['read'] ?? 0),
            'failed' => (int) ($counts['failed'] ?? 0),
            'blocked' => (int) ($counts['blocked'] ?? 0),
            'unknown' => (int) ($counts['unknown'] ?? 0),
        ]);
    }

    public function configs()
    {
        $rows = DB::table('za_whatsapp_automation_settings')->where('branch_id', '>', 0)->orderBy('branch_id')->get();
        $rows = $rows->map(function ($row) {
            return [
                'id' => $row->id, 'branch_id' => $row->branch_id, 'provider' => $row->provider,
                'waba_id' => $row->waba_id, 'phone_number_id' => $row->phone_number_id,
                'graph_api_version' => $row->graph_api_version, 'is_enabled' => (bool) $row->is_enabled,
                'token_configured' => !empty($row->access_token_encrypted),
                'min_send_interval_seconds' => (int) $row->min_send_interval_seconds,
                'last_tested_at' => $row->last_tested_at,
            ];
        });
        return response()->json(['ok' => true, 'data' => $rows, 'global_kill_switch' => (bool) DB::table('za_whatsapp_automation_settings')->where('branch_id', 0)->value('kill_switch')]);
    }

    public function saveConfig(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'branch_id' => 'required|integer|min:1',
            'provider' => ['required', Rule::in(['meta_cloud_api'])],
            'waba_id' => 'required|string|max:64',
            'phone_number_id' => 'required|string|max:64',
            'graph_api_version' => ['required', 'regex:/^v\d+\.0$/'],
            'access_token' => 'nullable|string|min:20|max:5000',
            'min_send_interval_seconds' => 'required|integer|min:1|max:300',
            'is_enabled' => 'required|boolean',
        ]);
        if ($validator->fails()) return response()->json(['ok' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);

        $branchId = (int) $request->input('branch_id');
        $existing = DB::table('za_whatsapp_automation_settings')->where('branch_id', $branchId)->first();
        $token = trim((string) $request->input('access_token', ''));
        if (!$existing && $token === '') return response()->json(['ok' => false, 'message' => 'An access token is required when creating a profile.'], 422);
        if ($token === '' && $existing && empty($existing->access_token_encrypted)) return response()->json(['ok' => false, 'message' => 'Saved profile has no token. Enter a token to enable sending.'], 422);

        $values = [
            'provider' => $request->input('provider'), 'waba_id' => trim($request->input('waba_id')),
            'phone_number_id' => trim($request->input('phone_number_id')), 'graph_api_version' => $request->input('graph_api_version'),
            'is_enabled' => $request->boolean('is_enabled') ? 1 : 0,
            'min_send_interval_seconds' => (int) $request->input('min_send_interval_seconds'),
            'updated_by' => (int) ($request->user()->user_id ?? $request->user()->id), 'updated_at' => now(),
        ];
        if ($token !== '') $values['access_token_encrypted'] = Crypt::encryptString($token);
        if ($existing) DB::table('za_whatsapp_automation_settings')->where('id', $existing->id)->update($values);
        else {
            $values['branch_id'] = $branchId;
            $values['kill_switch'] = 0;
            $values['created_by'] = (int) ($request->user()->user_id ?? $request->user()->id);
            $values['created_at'] = now();
            DB::table('za_whatsapp_automation_settings')->insert($values);
        }
        return response()->json(['ok' => true, 'message' => 'Encrypted API profile saved. Token is never returned to the browser.']);
    }

    public function testConfig(Request $request, WhatsAppManagerService $service)
    {
        $branchId = max(1, (int) $request->input('branch_id', $request->user()->branch_id ?? 1));
        $result = $service->testConnection($branchId);
        if ($result['ok']) DB::table('za_whatsapp_automation_settings')->where('branch_id', $branchId)->update(['last_tested_at' => now(), 'updated_at' => now()]);
        return response()->json($result, $result['ok'] ? 200 : 422);
    }

    public function toggleConfig(Request $request, int $branchId)
    {
        $enabled = $request->boolean('enabled');
        $updated = DB::table('za_whatsapp_automation_settings')->where('branch_id', $branchId)->update([
            'is_enabled' => $enabled ? 1 : 0, 'updated_by' => (int) ($request->user()->user_id ?? $request->user()->id), 'updated_at' => now(),
        ]);
        if (!$updated) return response()->json(['ok' => false, 'message' => 'API profile not found.'], 404);
        return response()->json(['ok' => true, 'message' => $enabled ? 'Branch WhatsApp sending enabled.' : 'Branch WhatsApp sending disabled.']);
    }

    public function killSwitch(Request $request)
    {
        $enabled = $request->boolean('enabled');
        DB::table('za_whatsapp_automation_settings')->updateOrInsert(
            ['branch_id' => 0],
            ['kill_switch' => $enabled ? 1 : 0, 'is_enabled' => 0, 'provider' => 'system',
                'updated_by' => (int) ($request->user()->user_id ?? $request->user()->id), 'updated_at' => now(), 'created_at' => now()]
        );
        return response()->json(['ok' => true, 'message' => $enabled ? 'GLOBAL KILL SWITCH ENABLED: all queued sends will be blocked.' : 'Global kill switch disabled. Branch profile switches still apply.']);
    }

    public function templates(Request $request)
    {
        $branchId = max(1, (int) $request->query('branch_id', $request->user()->branch_id ?? 1));
        $query = DB::table('za_whatsapp_template_registry')->where('branch_id', $branchId)->orderBy('approval_status')->orderBy('name');
        if ($request->filled('status')) $query->where('approval_status', strtoupper($request->query('status')));
        return response()->json(['ok' => true, 'data' => $query->limit(500)->get()]);
    }

    public function syncTemplates(Request $request, WhatsAppManagerService $service)
    {
        $branchId = max(1, (int) $request->input('branch_id', $request->user()->branch_id ?? 1));
        $result = $service->syncTemplates($branchId);
        return response()->json($result, $result['ok'] ? 200 : 422);
    }

    public function toggleTemplate(Request $request, int $id)
    {
        $template = DB::table('za_whatsapp_template_registry')->where('id', $id)->first();
        if (!$template) return response()->json(['ok' => false, 'message' => 'Template not found.'], 404);
        if (strtoupper($template->approval_status) !== 'APPROVED' && $request->boolean('enabled')) {
            return response()->json(['ok' => false, 'message' => 'Only Meta-approved templates can be enabled.'], 422);
        }
        DB::table('za_whatsapp_template_registry')->where('id', $id)->update(['is_enabled' => $request->boolean('enabled') ? 1 : 0, 'updated_at' => now()]);
        return response()->json(['ok' => true, 'message' => 'Template state updated.']);
    }

    public function workflowRules(Request $request)
    {
        $branchId = max(1, (int) $request->query('branch_id', $request->user()->branch_id ?? 1));
        $rows = DB::table('za_whatsapp_workflow_rules')->where('branch_id', $branchId)->orderBy('event_key')->get();
        return response()->json(['ok' => true, 'data' => $rows]);
    }

    public function saveWorkflowRule(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'branch_id' => 'required|integer|min:1',
            'event_key' => ['required', 'string', 'max:100', 'regex:/^[a-z][a-z0-9_.-]{1,99}$/'],
            'template_name' => 'required|string|max:191',
            'language' => 'required|string|max:20',
            'notes' => 'nullable|string|max:500',
            'is_enabled' => 'required|boolean',
        ]);
        if ($validator->fails()) return response()->json(['ok' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);

        $branchId = (int) $request->input('branch_id');
        $settings = DB::table('za_whatsapp_automation_settings')->where('branch_id', $branchId)->first();
        $template = $settings ? DB::table('za_whatsapp_template_registry')->where('branch_id', $branchId)
            ->where('waba_id', $settings->waba_id)->where('name', trim($request->input('template_name')))
            ->where('language', trim($request->input('language')))->first() : null;
        if (!$template || strtoupper((string) $template->approval_status) !== 'APPROVED' || !(int) $template->is_enabled) {
            return response()->json(['ok' => false, 'message' => 'Choose a synced, Meta-approved template that is enabled in the ERP first.'], 422);
        }

        $actorId = (int) ($request->user()->user_id ?? $request->user()->id);
        $ruleKey = ['branch_id' => $branchId, 'event_key' => trim($request->input('event_key'))];
        $ruleValues = ['template_name' => trim($request->input('template_name')), 'language' => trim($request->input('language')),
            'notes' => $request->input('notes'), 'is_enabled' => $request->boolean('is_enabled') ? 1 : 0,
            'updated_by' => $actorId, 'updated_at' => now()];
        $existingRule = DB::table('za_whatsapp_workflow_rules')->where($ruleKey)->first();
        if ($existingRule) {
            DB::table('za_whatsapp_workflow_rules')->where('id', $existingRule->id)->update($ruleValues);
        } else {
            $ruleValues['created_by'] = $actorId;
            $ruleValues['created_at'] = now();
            DB::table('za_whatsapp_workflow_rules')->insert(array_merge($ruleKey, $ruleValues));
        }
        return response()->json(['ok' => true, 'message' => 'Workflow rule saved. Controller code supplies event-specific template variables; this rule selects the template/language.']);
    }

    public function toggleWorkflowRule(Request $request, int $id)
    {
        $rule = DB::table('za_whatsapp_workflow_rules')->where('id', $id)->first();
        if (!$rule) return response()->json(['ok' => false, 'message' => 'Workflow rule not found.'], 404);
        $enabled = $request->boolean('enabled');
        if ($enabled) {
            $settings = DB::table('za_whatsapp_automation_settings')->where('branch_id', $rule->branch_id)->first();
            $template = $settings ? DB::table('za_whatsapp_template_registry')->where('branch_id', $rule->branch_id)
                ->where('waba_id', $settings->waba_id)->where('name', $rule->template_name)->where('language', $rule->language)->first() : null;
            if (!$template || strtoupper((string) $template->approval_status) !== 'APPROVED' || !(int) $template->is_enabled) {
                return response()->json(['ok' => false, 'message' => 'The mapped template is not currently approved and enabled.'], 422);
            }
        }
        DB::table('za_whatsapp_workflow_rules')->where('id', $id)->update([
            'is_enabled' => $enabled ? 1 : 0,
            'updated_by' => (int) ($request->user()->user_id ?? $request->user()->id),
            'updated_at' => now(),
        ]);
        return response()->json(['ok' => true, 'message' => $enabled ? 'Workflow enabled.' : 'Workflow disabled.']);
    }

    public function outbox(Request $request)
    {
        $query = DB::table('za_whatsapp_outbox')->orderByDesc('id');
        if ($request->filled('branch_id')) $query->where('branch_id', (int) $request->query('branch_id'));
        if ($request->filled('status')) $query->where('status', $request->query('status'));
        if ($request->filled('q')) {
            $q = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim($request->query('q'))) . '%';
            $query->where(function ($sub) use ($q) { $sub->where('phone_e164', 'like', $q)->orWhere('template_name', 'like', $q)->orWhere('error_message', 'like', $q); });
        }
        // Raw request/response JSON can contain message-variable PII; expose only operational fields by default.
        $query->select('id', 'branch_id', 'phone_e164', 'message_type', 'template_name', 'language', 'source_type', 'workflow_event_key', 'source_id', 'status', 'meta_message_id', 'scheduled_at', 'sent_at', 'delivered_at', 'read_at', 'failed_at', 'error_code', 'error_message', 'attempts', 'created_at', 'updated_at');
        return response()->json(['ok' => true, 'data' => $query->limit(250)->get()]);
    }

    public function sendTemplate(Request $request, WhatsAppManagerService $service)
    {
        $validator = Validator::make($request->all(), [
            'branch_id' => 'required|integer|min:1', 'to' => 'required|string|max:32', 'template_name' => 'required|string|max:191',
            'language' => 'required|string|max:20', 'components' => 'nullable|array',
        ]);
        if ($validator->fails()) return response()->json(['ok' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        $result = $service->queueTemplate([
            'branch_id' => $request->input('branch_id'), 'to' => $request->input('to'), 'template_name' => $request->input('template_name'),
            'language' => $request->input('language'), 'components' => $request->input('components', []),
            'source_type' => 'admin_manual', 'created_by' => (int) ($request->user()->user_id ?? $request->user()->id),
            'idempotency_key' => (string) Str::uuid(),
        ]);
        return response()->json($result, $result['ok'] ? 202 : 422);
    }

    public function sendText(Request $request, WhatsAppManagerService $service)
    {
        $validator = Validator::make($request->all(), ['branch_id' => 'required|integer|min:1', 'to' => 'required|string|max:32', 'text' => 'required|string|max:4096']);
        if ($validator->fails()) return response()->json(['ok' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        $result = $service->queueText([
            'branch_id' => $request->input('branch_id'), 'to' => $request->input('to'), 'text' => $request->input('text'),
            'created_by' => (int) ($request->user()->user_id ?? $request->user()->id), 'source_type' => 'admin_chat', 'idempotency_key' => (string) Str::uuid(),
        ]);
        return response()->json($result, $result['ok'] ? 202 : 422);
    }

    public function bulkSend(Request $request, WhatsAppManagerService $service)
    {
        $max = max(1, min(250, (int) config('whatsapp.bulk_max_recipients', 250)));
        $validator = Validator::make($request->all(), [
            'branch_id' => 'required|integer|min:1', 'template_name' => 'required|string|max:191', 'language' => 'required|string|max:20',
            'components' => 'nullable|array', 'pacing_seconds' => 'nullable|integer|min:5|max:60',
            'recipients' => 'required|array|min:1|max:' . $max,
            'recipients.*.to' => 'required|string|max:32', 'recipients.*.components' => 'nullable|array',
        ]);
        if ($validator->fails()) return response()->json(['ok' => false, 'message' => 'Validation failed or the bulk cap was exceeded.', 'errors' => $validator->errors()], 422);
        $campaignId = (string) Str::uuid();
        $pace = max(5, min(60, (int) $request->input('pacing_seconds', config('whatsapp.default_bulk_pacing_seconds', 10))));
        $queued = 0; $blocked = 0; $items = [];
        foreach ($request->input('recipients') as $i => $recipient) {
            $result = $service->queueTemplate([
                'branch_id' => $request->input('branch_id'), 'to' => $recipient['to'], 'template_name' => $request->input('template_name'),
                'language' => $request->input('language'), 'components' => $recipient['components'] ?? $request->input('components', []),
                'source_type' => 'bulk_campaign', 'source_id' => null, 'created_by' => (int) ($request->user()->user_id ?? $request->user()->id),
                'idempotency_key' => $campaignId . ':' . sha1((string) ($recipient['to'] ?? '') . ':' . $i), 'delay_seconds' => $i * $pace,
            ]);
            $items[] = ['to' => $recipient['to'], 'status' => $result['status'] ?? 'blocked', 'id' => $result['id'] ?? null, 'reason' => $result['reason'] ?? null];
            if (!empty($result['ok'])) $queued++; else $blocked++;
        }
        return response()->json(['ok' => true, 'campaign_id' => $campaignId, 'queued' => $queued, 'blocked' => $blocked, 'results' => $items], 202);
    }

    public function conversations(Request $request)
    {
        $branchId = max(1, (int) $request->query('branch_id', $request->user()->branch_id ?? 1));
        $kind = (string) $request->query('kind', 'all');
        $latest = DB::table('za_wb_messages')->select('contact_id', DB::raw('MAX(sno) as last_id'))->groupBy('contact_id');
        $query = DB::table('za_wb_contacts as c')
            ->leftJoinSub($latest, 'lm', function ($join) { $join->on('lm.contact_id', '=', 'c.sno'); })
            ->leftJoin('za_wb_messages as m', 'm.sno', '=', 'lm.last_id')
            ->select('c.sno as contact_id', 'c.phone', 'c.msg_count', 'm.message as last_message', 'm.type as last_type', 'm.message_date_time as last_message_time',
                DB::raw("CASE WHEN EXISTS (SELECT 1 FROM za_customer cu WHERE RIGHT(REPLACE(REPLACE(c.phone, '+', ''), ' ', ''), 10) = RIGHT(REPLACE(REPLACE(cu.cus_mobile, '+', ''), ' ', ''), 10) AND cu.branch_id = {$branchId}) THEN 'customer' WHEN EXISTS (SELECT 1 FROM za_lead l WHERE RIGHT(REPLACE(REPLACE(c.phone, '+', ''), ' ', ''), 10) = RIGHT(REPLACE(REPLACE(l.lead_mobile, '+', ''), ' ', ''), 10) AND l.branch_id = {$branchId} AND l.status != 2) THEN 'lead' ELSE 'unknown' END as contact_kind"))
            ->orderByDesc('m.sno')->limit(200);
        if ($request->filled('q')) $query->where('c.phone', 'like', '%' . trim($request->query('q')) . '%');
        $rows = $query->get()->filter(function ($row) use ($kind) { return $kind === 'all' || $row->contact_kind === $kind; })->values();
        return response()->json(['ok' => true, 'data' => $rows]);
    }

    public function conversationMessages(Request $request, string $phone)
    {
        $digits = preg_replace('/\D+/', '', $phone);
        abort_unless(strlen($digits) >= 8 && strlen($digits) <= 15, 422, 'Invalid phone number.');
        $contact = DB::table('za_wb_contacts')->where('phone', $digits)->orWhere('phone', '+' . $digits)->first();
        if (!$contact) {
            $matches = DB::table('za_wb_contacts')->whereRaw("RIGHT(REPLACE(REPLACE(phone, '+', ''), ' ', ''), 10) = ?", [substr($digits, -10)])->limit(2)->get();
            $contact = $matches->count() === 1 ? $matches->first() : null;
        }
        if (!$contact) return response()->json(['ok' => true, 'data' => [], 'session_open' => false]);
        $messages = DB::table('za_wb_messages')->where('contact_id', $contact->sno)->orderBy('sno')->limit(500)->get([
            'sno', 'message', 'type', 'from', 'wama_id', 'message_date_time', 'message_status', 'media_url', 'media_type', 'media_caption',
        ]);
        $branchId = max(1, (int) $request->query('branch_id', $request->user()->branch_id ?? 1));
        $session = DB::table('za_whatsapp_sessions')->where('branch_id', $branchId)->where('phone_e164', '+' . $digits)->first();
        $open = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
        return response()->json(['ok' => true, 'data' => $messages, 'session_open' => (bool) $open, 'last_inbound_at' => $session->last_inbound_at ?? null]);
    }

    public function recordConsent(Request $request, WhatsAppManagerService $service)
    {
        $validator = Validator::make($request->all(), [
            'branch_id' => 'required|integer|min:1', 'phone' => 'required|string|max:32',
            'category' => ['required', Rule::in(['all', 'marketing', 'utility', 'authentication'])],
            'consent_status' => ['required', Rule::in(['opted_in', 'opted_out'])],
            'source' => 'required|string|max:100', 'evidence_ref' => 'required|string|max:1000',
        ]);
        if ($validator->fails()) return response()->json(['ok' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        $result = $service->recordConsent(array_merge($request->all(), ['created_by' => (int) ($request->user()->user_id ?? $request->user()->id)]));
        return response()->json($result, $result['ok'] ? 200 : 422);
    }

    public function audiences(Request $request)
    {
        $branchId = max(1, (int) $request->query('branch_id', $request->user()->branch_id ?? 1));
        return response()->json(['ok' => true, 'data' => DB::table('za_whatsapp_audiences')->where('branch_id', $branchId)->where('is_active', 1)->orderBy('name')->get()]);
    }

    public function createAudience(Request $request)
    {
        $validator = Validator::make($request->all(), ['branch_id' => 'required|integer|min:1', 'name' => 'required|string|max:120', 'description' => 'nullable|string|max:500']);
        if ($validator->fails()) return response()->json(['ok' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        $id = DB::table('za_whatsapp_audiences')->insertGetId([
            'branch_id' => $request->input('branch_id'), 'name' => trim($request->input('name')), 'description' => $request->input('description'),
            'is_active' => 1, 'created_by' => (int) ($request->user()->user_id ?? $request->user()->id), 'updated_by' => (int) ($request->user()->user_id ?? $request->user()->id),
            'created_at' => now(), 'updated_at' => now(),
        ]);
        return response()->json(['ok' => true, 'id' => $id, 'message' => 'Custom audience created. Adding a number to an audience does not count as consent.'], 201);
    }

    public function addAudienceMembers(Request $request, int $id, WhatsAppManagerService $service)
    {
        $audience = DB::table('za_whatsapp_audiences')->where('id', $id)->first();
        if (!$audience) return response()->json(['ok' => false, 'message' => 'Audience not found.'], 404);
        $validator = Validator::make($request->all(), ['phones' => 'required|array|min:1|max:500', 'phones.*' => 'required|string|max:32']);
        if ($validator->fails()) return response()->json(['ok' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        $added = 0; $invalid = [];
        foreach ($request->input('phones') as $inputPhone) {
            try { $phone = $service->normalizePhone($inputPhone); }
            catch (\InvalidArgumentException $e) { $invalid[] = $inputPhone; continue; }
            DB::table('za_whatsapp_audience_members')->updateOrInsert(
                ['audience_id' => $id, 'phone_e164' => $phone],
                ['branch_id' => $audience->branch_id, 'created_by' => (int) ($request->user()->user_id ?? $request->user()->id), 'updated_at' => now(), 'created_at' => now()]
            );
            $added++;
        }
        return response()->json(['ok' => true, 'added' => $added, 'invalid' => $invalid, 'message' => 'Audience members saved. Message sends still require approved templates and recorded opt-in.']);
    }

    public function bulkFromAudience(Request $request, int $id)
    {
        $audience = DB::table('za_whatsapp_audiences')->where('id', $id)->where('is_active', 1)->first();
        if (!$audience) return response()->json(['ok' => false, 'message' => 'Audience not found or inactive.'], 404);
        $max = max(1, min(250, (int) config('whatsapp.bulk_max_recipients', 250)));
        $members = DB::table('za_whatsapp_audience_members')->where('audience_id', $id)->limit($max + 1)->get();
        if ($members->count() > $max) return response()->json(['ok' => false, 'message' => 'Audience exceeds the configured bulk cap. Split it into smaller reviewed batches.'], 422);
        return response()->json(['ok' => true, 'recipients' => $members->map(function ($member) { return ['to' => $member->phone_e164]; })]);
    }
}
