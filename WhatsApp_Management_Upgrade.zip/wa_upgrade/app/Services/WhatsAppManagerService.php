<?php

namespace App\Services;

use App\Jobs\ProcessWhatsAppOutboxJob;
use App\Models\WhatsAppAutomationConfig;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

/** Central WhatsApp Cloud API gateway for the ERP. Keep controllers out of HTTP/API details. */
class WhatsAppManagerService
{
    public function normalizePhone(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            throw new \InvalidArgumentException('Recipient phone number is required.');
        }
        // Accept E.164 (+919876543210) or international digits (919876543210), not an ambiguous local number.
        $hadPlus = isset($value[0]) && $value[0] === '+';
        $digits = preg_replace('/\D+/', '', $value);
        if (!$digits || strlen($digits) < 8 || strlen($digits) > 15 || $digits[0] === '0' || (!$hadPlus && strlen($digits) === 10)) {
            throw new \InvalidArgumentException('Use an international WhatsApp number, e.g. +919876543210. Do not enter a local 10-digit number without country code.');
        }
        return '+' . $digits;
    }

    private function phoneDigits(string $phone): string
    {
        return preg_replace('/\D+/', '', $phone);
    }

    public function settingsForBranch(int $branchId): ?object
    {
        return DB::table('za_whatsapp_automation_settings')->where('branch_id', $branchId)->first();
    }

    private function globalKillSwitchOn(): bool
    {
        return (bool) DB::table('za_whatsapp_automation_settings')->where('branch_id', 0)->value('kill_switch');
    }

    private function tokenForSettings(?object $settings): ?string
    {
        if (!$settings || empty($settings->access_token_encrypted)) {
            return null;
        }
        try {
            return Crypt::decryptString($settings->access_token_encrypted);
        } catch (Throwable $e) {
            Log::error('WhatsApp access token could not be decrypted; rotate/re-save the token.', [
                'branch_id' => $settings->branch_id ?? null,
            ]);
            return null;
        }
    }

    public function getAccessTokenForPhoneNumber(?string $phoneNumberId): ?string
    {
        if (!$phoneNumberId) {
            return null;
        }
        // Inbound webhook/media processing must continue even when an admin pauses outbound sends.
        $settings = DB::table('za_whatsapp_automation_settings')
            ->where('phone_number_id', $phoneNumberId)
            ->first();
        return $this->tokenForSettings($settings);
    }

    public function testConnection(int $branchId): array
    {
        $settings = $this->settingsForBranch($branchId);
        $token = $this->tokenForSettings($settings);
        if (!$settings || !$token || empty($settings->waba_id)) {
            return ['ok' => false, 'message' => 'Configure the WABA ID, phone number ID, and access token first.'];
        }
        try {
            $url = $this->graphBase($settings) . '/' . rawurlencode($settings->waba_id) . '/message_templates';
            $response = Http::withToken($token)->acceptJson()->timeout(20)->get($url, ['limit' => 1]);
            if ($response->successful()) {
                return ['ok' => true, 'message' => 'Meta accepted the credentials and the WABA template endpoint responded.'];
            }
            $json = $response->json();
            return ['ok' => false, 'message' => $json['error']['message'] ?? 'Meta API returned HTTP ' . $response->status(), 'error_code' => $json['error']['code'] ?? null];
        } catch (Throwable $e) {
            Log::warning('WhatsApp connection test failed', ['branch_id' => $branchId, 'exception' => class_basename($e)]);
            return ['ok' => false, 'message' => 'Connection failed. Check application logs and outbound HTTPS connectivity.'];
        }
    }

    private function graphBase(object $settings): string
    {
        $version = trim((string) ($settings->graph_api_version ?: config('whatsapp.api_version', 'v26.0')));
        $version = ltrim($version, '/');
        if (!preg_match('/^v\d+\.0$/', $version)) {
            throw new \InvalidArgumentException('Graph API version must look like v26.0.');
        }
        return 'https://graph.facebook.com/' . $version;
    }

    public function syncTemplates(int $branchId): array
    {
        $settings = $this->settingsForBranch($branchId);
        $token = $this->tokenForSettings($settings);
        if (!$settings || !$token || empty($settings->waba_id)) {
            return ['ok' => false, 'message' => 'Configure a valid WhatsApp API profile before syncing templates.'];
        }

        $base = $this->graphBase($settings) . '/' . rawurlencode($settings->waba_id) . '/message_templates';
        $url = $base;
        $params = ['limit' => 100];
        $count = 0;
        $pages = 0;
        try {
            // Guard against unexpectedly large/unbounded pagination responses.
            while ($url && $pages < 10) {
                if (parse_url($url, PHP_URL_HOST) !== 'graph.facebook.com') {
                    return ['ok' => false, 'message' => 'Meta template paging returned an unexpected host; sync stopped.'];
                }
                $response = Http::withToken($token)->acceptJson()->timeout(25)->get($url, $params);
                if (!$response->successful()) {
                    $json = $response->json();
                    return ['ok' => false, 'message' => $json['error']['message'] ?? 'Meta returned HTTP ' . $response->status(), 'error_code' => $json['error']['code'] ?? null];
                }
                $json = $response->json();
                foreach (($json['data'] ?? []) as $template) {
                    if (empty($template['name']) || empty($template['language'])) {
                        continue;
                    }
                    $name = (string) $template['name'];
                    $language = (string) $template['language'];
                    $key = sha1($name . '|' . $language);
                    $existing = DB::table('za_whatsapp_template_registry')
                        ->where('branch_id', $branchId)->where('waba_id', $settings->waba_id)->where('template_key', $key)->first();
                    $values = [
                        'branch_id' => $branchId,
                        'waba_id' => (string) $settings->waba_id,
                        'meta_template_id' => isset($template['id']) ? (string) $template['id'] : null,
                        'template_key' => $key,
                        'name' => $name,
                        'language' => $language,
                        'category' => strtoupper((string) ($template['category'] ?? 'UNKNOWN')),
                        'approval_status' => strtoupper((string) ($template['status'] ?? 'UNKNOWN')),
                        'components_json' => json_encode($template['components'] ?? [], JSON_UNESCAPED_UNICODE),
                        'raw_json' => json_encode($template, JSON_UNESCAPED_UNICODE),
                        'last_synced_at' => now(),
                        'updated_at' => now(),
                    ];
                    if ($existing) {
                        DB::table('za_whatsapp_template_registry')->where('id', $existing->id)->update($values);
                    } else {
                        $values['is_enabled'] = 0; // Explicit admin review before a synced template can be used.
                        $values['created_at'] = now();
                        DB::table('za_whatsapp_template_registry')->insert($values);
                    }
                    $count++;
                }
                $pages++;
                $url = $json['paging']['next'] ?? null;
                $params = []; // Paging URL already contains its cursor/limit.
            }
            return ['ok' => true, 'message' => 'Template sync complete. Review approval statuses and enable only templates intended for production.', 'count' => $count, 'pages' => $pages];
        } catch (Throwable $e) {
            Log::error('WhatsApp template sync failed', ['branch_id' => $branchId, 'exception' => class_basename($e)]);
            return ['ok' => false, 'message' => 'Template sync failed. Check application logs.'];
        }
    }

    /** Resolve a business event through an admin-managed branch rule, not a controller template literal. */
    public function queueWorkflow(array $input): array
    {
        $branchId = (int) ($input['branch_id'] ?? 0);
        $eventKey = trim((string) ($input['event_key'] ?? ''));
        if ($branchId < 1 || !preg_match('/^[a-z][a-z0-9_.-]{1,99}$/', $eventKey)) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => 'A valid branch and workflow event key are required.'];
        }

        $input['workflow_event_key'] = $eventKey;
        $rule = DB::table('za_whatsapp_workflow_rules')
            ->where('branch_id', $branchId)->where('event_key', $eventKey)->where('is_enabled', 1)->first();
        if (!$rule) {
            // Reuse the outbox policy path so missing/disabled workflow mappings are visible in Message logs.
            $input['template_name'] = '__workflow_not_configured__';
            $input['language'] = 'en_US';
            $input['components'] = [];
            $input['force_block_reason'] = 'No enabled WhatsApp workflow rule exists for event: ' . $eventKey;
            return $this->queueTemplate($input);
        }

        $input['template_name'] = $rule->template_name;
        $input['language'] = $rule->language;
        return $this->queueTemplate($input);
    }

    public function queueTemplate(array $input): array
    {
        $branchId = (int) ($input['branch_id'] ?? 0);
        $templateName = trim((string) ($input['template_name'] ?? ''));
        $language = trim((string) ($input['language'] ?? 'en_US'));
        $sourceType = substr(trim((string) ($input['source_type'] ?? 'admin_manual')), 0, 80);
        $sourceId = isset($input['source_id']) ? (int) $input['source_id'] : null;
        $actorId = isset($input['created_by']) ? (int) $input['created_by'] : null;
        $components = $input['components'] ?? [];
        $idempotencyKey = substr((string) ($input['idempotency_key'] ?? Str::uuid()), 0, 191);
        $delaySeconds = max(0, min(3600, (int) ($input['delay_seconds'] ?? 0)));

        try {
            $phone = $this->normalizePhone((string) ($input['to'] ?? ''));
        } catch (\InvalidArgumentException $e) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => $e->getMessage()];
        }
        if ($branchId < 1 || $templateName === '' || !is_array($components)) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => 'Branch, template name, and component array are required.'];
        }

        $settings = $this->settingsForBranch($branchId);
        $template = $settings ? DB::table('za_whatsapp_template_registry')
            ->where('branch_id', $branchId)->where('waba_id', $settings->waba_id)
            ->where('name', $templateName)->where('language', $language)->first() : null;
        $reason = trim((string) ($input['force_block_reason'] ?? '')) ?: null;
        if (!$reason) {
            if ($this->globalKillSwitchOn()) {
                $reason = 'Global WhatsApp kill switch is ON.';
            } elseif (!$settings || !(int) $settings->is_enabled) {
                $reason = 'WhatsApp API profile is missing or disabled for this branch.';
            } elseif (!$template) {
                $reason = 'Template is not synced for this WABA/language.';
            } elseif (strtoupper((string) $template->approval_status) !== 'APPROVED') {
                $reason = 'Meta template status is not APPROVED.';
            } elseif (!(int) $template->is_enabled) {
                $reason = 'Template is disabled in ERP settings.';
            } elseif (!$this->hasConsent($branchId, $phone, $this->consentCategory($template->category))) {
                $reason = 'No current, matching WhatsApp opt-in evidence. Record/import consent before initiating a template message.';
            }
        }

        $existing = DB::table('za_whatsapp_outbox')->where('idempotency_key', $idempotencyKey)->first();
        if ($existing) {
            return ['ok' => in_array($existing->status, ['queued', 'processing', 'sent', 'delivered', 'read'], true), 'id' => $existing->id, 'status' => $existing->status, 'reason' => $existing->error_message, 'duplicate_request' => true];
        }

        $status = $reason ? 'blocked' : 'queued';
        $scheduledAt = null;
        $outboxId = null;
        DB::transaction(function () use (&$outboxId, &$scheduledAt, $branchId, $settings, $phone, $templateName, $language, $components, $sourceType, $sourceId, $actorId, $idempotencyKey, $reason, $status, $delaySeconds) {
            // Serialise schedule assignment per branch to spread automatic/bulk sends instead of spiking traffic.
            $lockedSettings = $settings ? DB::table('za_whatsapp_automation_settings')->where('id', $settings->id)->lockForUpdate()->first() : null;
            if (!$reason && (!$lockedSettings || !(int) $lockedSettings->is_enabled || $this->globalKillSwitchOn())) {
                $actualStatus = 'blocked';
                $actualReason = 'WhatsApp sending was disabled while this message was being queued.';
            } else {
                $actualStatus = $status;
                $actualReason = $reason;
            }
            if ($actualStatus === 'queued') {
                $base = now()->addSeconds($delaySeconds);
                if ($lockedSettings && !empty($lockedSettings->next_send_at)) {
                    $next = \Carbon\Carbon::parse($lockedSettings->next_send_at);
                    if ($next->greaterThan($base)) {
                        $base = $next;
                    }
                }
                $scheduledAt = $base;
                $interval = max(1, min(300, (int) ($lockedSettings->min_send_interval_seconds ?? 10)));
                DB::table('za_whatsapp_automation_settings')->where('id', $lockedSettings->id)->update([
                    'next_send_at' => $base->copy()->addSeconds($interval),
                    'updated_at' => now(),
                ]);
            }
            $outboxId = DB::table('za_whatsapp_outbox')->insertGetId([
                'branch_id' => $branchId,
                'phone_e164' => $phone,
                'message_type' => 'template',
                'template_name' => $templateName,
                'language' => $language,
                'template_category' => $this->consentCategoryFromInput($branchId, $templateName, $language),
                'components_json' => json_encode($components, JSON_UNESCAPED_UNICODE),
                'text_body' => null,
                'source_type' => $sourceType,
                'workflow_event_key' => isset($input['workflow_event_key']) ? substr((string) $input['workflow_event_key'], 0, 100) : null,
                'source_id' => $sourceId,
                'created_by' => $actorId,
                'idempotency_key' => $idempotencyKey,
                'status' => $actualStatus,
                'scheduled_at' => $scheduledAt,
                'error_code' => $actualReason ? 'POLICY_GUARD' : null,
                'error_message' => $actualReason,
                'attempts' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        });

        if ($status === 'queued' && $scheduledAt && !$reason) {
            ProcessWhatsAppOutboxJob::dispatch($outboxId)->delay($scheduledAt);
            return ['ok' => true, 'id' => $outboxId, 'status' => 'queued', 'scheduled_at' => $scheduledAt->toDateTimeString()];
        }
        $row = DB::table('za_whatsapp_outbox')->where('id', $outboxId)->first();
        return ['ok' => false, 'id' => $outboxId, 'status' => $row->status ?? 'blocked', 'reason' => $row->error_message ?? $reason];
    }

    private function consentCategory(string $templateCategory): string
    {
        $category = strtoupper($templateCategory);
        if (in_array($category, ['AUTHENTICATION', 'UTILITY', 'MARKETING'], true)) {
            return strtolower($category);
        }
        return 'all';
    }

    private function consentCategoryFromInput(int $branchId, string $name, string $language): string
    {
        $settings = $this->settingsForBranch($branchId);
        if (!$settings) return 'unknown';
        $template = DB::table('za_whatsapp_template_registry')->where('branch_id', $branchId)->where('waba_id', $settings->waba_id)->where('name', $name)->where('language', $language)->first();
        return $template ? $this->consentCategory($template->category) : 'unknown';
    }

    private function hasConsent(int $branchId, string $phone, string $category): bool
    {
        $all = DB::table('za_whatsapp_consents')->where('branch_id', $branchId)->where('phone_e164', $phone)->where('category', 'all')->first();
        // An explicit STOP/all opt-out is a hard block until the all-category record is explicitly re-opted-in.
        if ($all && $all->consent_status !== 'opted_in') return false;
        $exact = $category === 'all' ? $all : DB::table('za_whatsapp_consents')->where('branch_id', $branchId)
            ->where('phone_e164', $phone)->where('category', $category)->first();
        if ($exact && $exact->consent_status !== 'opted_in') return false;
        if ($exact && $exact->consent_status === 'opted_in' && !empty($exact->opted_in_at)) return true;
        return $all && $all->consent_status === 'opted_in' && !empty($all->opted_in_at);
    }

    private function isOptedOut(int $branchId, string $phone): bool
    {
        $all = DB::table('za_whatsapp_consents')->where('branch_id', $branchId)->where('phone_e164', $phone)->where('category', 'all')->first();
        return $all && $all->consent_status === 'opted_out';
    }

    public function queueText(array $input): array
    {
        $branchId = (int) ($input['branch_id'] ?? 0);
        try {
            $phone = $this->normalizePhone((string) ($input['to'] ?? ''));
        } catch (\InvalidArgumentException $e) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => $e->getMessage()];
        }
        $text = trim((string) ($input['text'] ?? ''));
        if ($branchId < 1 || $text === '' || mb_strlen($text) > 4096) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => 'Branch and text (1–4096 characters) are required.'];
        }
        $settings = $this->settingsForBranch($branchId);
        $session = DB::table('za_whatsapp_sessions')->where('branch_id', $branchId)->where('phone_e164', $phone)->first();
        $active = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
        $reason = null;
        if ($this->globalKillSwitchOn()) $reason = 'Global WhatsApp kill switch is ON.';
        elseif (!$settings || !(int) $settings->is_enabled) $reason = 'WhatsApp API profile is missing or disabled for this branch.';
        elseif (!$active) $reason = 'The 24-hour customer service window is closed. Send an approved template instead.';
        elseif ($this->isOptedOut($branchId, $phone)) $reason = 'This recipient has opted out. Respect the opt-out request.';

        $idempotencyKey = substr((string) ($input['idempotency_key'] ?? Str::uuid()), 0, 191);
        $existing = DB::table('za_whatsapp_outbox')->where('idempotency_key', $idempotencyKey)->first();
        if ($existing) return ['ok' => in_array($existing->status, ['queued', 'processing', 'sent', 'delivered', 'read'], true), 'id' => $existing->id, 'status' => $existing->status, 'reason' => $existing->error_message, 'duplicate_request' => true];

        $outboxId = DB::table('za_whatsapp_outbox')->insertGetId([
            'branch_id' => $branchId, 'phone_e164' => $phone, 'message_type' => 'text', 'template_name' => null,
            'language' => null, 'template_category' => null, 'components_json' => null, 'text_body' => $text,
            'source_type' => substr((string) ($input['source_type'] ?? 'agent_chat'), 0, 80), 'source_id' => null,
            'created_by' => isset($input['created_by']) ? (int) $input['created_by'] : null, 'idempotency_key' => $idempotencyKey,
            'status' => $reason ? 'blocked' : 'queued', 'scheduled_at' => $reason ? null : now(),
            'error_code' => $reason ? 'POLICY_GUARD' : null, 'error_message' => $reason, 'attempts' => 0,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        if ($reason) return ['ok' => false, 'id' => $outboxId, 'status' => 'blocked', 'reason' => $reason];
        ProcessWhatsAppOutboxJob::dispatch($outboxId);
        return ['ok' => true, 'id' => $outboxId, 'status' => 'queued'];
    }

    public function processOutbox(int $outboxId): void
    {
        $row = DB::table('za_whatsapp_outbox')->where('id', $outboxId)->first();
        if (!$row || !in_array($row->status, ['queued'], true)) return; // protects against duplicate jobs
        if (!empty($row->scheduled_at) && \Carbon\Carbon::parse($row->scheduled_at)->isFuture()) {
            ProcessWhatsAppOutboxJob::dispatch($outboxId)->delay(\Carbon\Carbon::parse($row->scheduled_at));
            return;
        }
        $claimed = DB::table('za_whatsapp_outbox')->where('id', $outboxId)->where('status', 'queued')->update([
            'status' => 'processing', 'attempts' => DB::raw('attempts + 1'), 'updated_at' => now(),
        ]);
        if (!$claimed) return;
        $row = DB::table('za_whatsapp_outbox')->where('id', $outboxId)->first();
        $settings = $this->settingsForBranch((int) $row->branch_id);
        if ($this->globalKillSwitchOn() || !$settings || !(int) $settings->is_enabled) {
            $this->failOutbox($outboxId, 'SENDING_DISABLED', 'WhatsApp sending is currently disabled.');
            return;
        }
        $token = $this->tokenForSettings($settings);
        if (!$token || empty($settings->phone_number_id)) {
            $this->failOutbox($outboxId, 'CONFIG_MISSING', 'Missing/decryption-failed API token or phone number ID.');
            return;
        }

        if ($row->message_type === 'template') {
            if (!empty($row->workflow_event_key)) {
                $rule = DB::table('za_whatsapp_workflow_rules')
                    ->where('branch_id', $row->branch_id)
                    ->where('event_key', $row->workflow_event_key)
                    ->where('is_enabled', 1)->first();
                if (!$rule || $rule->template_name !== $row->template_name || $rule->language !== $row->language) {
                    $this->failOutbox($outboxId, 'WORKFLOW_DISABLED', 'Workflow rule was disabled or changed after the message was queued.');
                    return;
                }
            }
            $template = DB::table('za_whatsapp_template_registry')
                ->where('branch_id', $row->branch_id)->where('waba_id', $settings->waba_id)
                ->where('name', $row->template_name)->where('language', $row->language)->first();
            if (!$template || strtoupper($template->approval_status) !== 'APPROVED' || !(int) $template->is_enabled) {
                $this->failOutbox($outboxId, 'TEMPLATE_UNAVAILABLE', 'Template is not approved and enabled at send time.');
                return;
            }
            if (!$this->hasConsent((int) $row->branch_id, $row->phone_e164, $this->consentCategory($template->category))) {
                $this->failOutbox($outboxId, 'CONSENT_MISSING', 'Recipient consent is missing, revoked, or no longer matches the template category.');
                return;
            }
            $templateData = ['name' => $row->template_name, 'language' => ['code' => $row->language ?: 'en_US']];
            $components = $row->components_json ? json_decode($row->components_json, true) : [];
            if (is_array($components) && count($components)) $templateData['components'] = $components;
            $payload = ['messaging_product' => 'whatsapp', 'recipient_type' => 'individual', 'to' => $this->phoneDigits($row->phone_e164), 'type' => 'template', 'template' => $templateData];
        } elseif ($row->message_type === 'text') {
            $session = DB::table('za_whatsapp_sessions')->where('branch_id', $row->branch_id)->where('phone_e164', $row->phone_e164)->first();
            $active = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
            if (!$active) {
                $this->failOutbox($outboxId, 'WINDOW_CLOSED', 'The 24-hour customer service window is closed. Use an approved template.');
                return;
            }
            if ($this->isOptedOut((int) $row->branch_id, $row->phone_e164)) {
                $this->failOutbox($outboxId, 'RECIPIENT_OPTOUT', 'Recipient has opted out.');
                return;
            }
            $payload = ['messaging_product' => 'whatsapp', 'recipient_type' => 'individual', 'to' => $this->phoneDigits($row->phone_e164), 'type' => 'text', 'text' => ['preview_url' => false, 'body' => $row->text_body]];
        } else {
            $this->failOutbox($outboxId, 'UNSUPPORTED_MESSAGE_TYPE', 'Unsupported message type.');
            return;
        }

        try {
            $url = $this->graphBase($settings) . '/' . rawurlencode($settings->phone_number_id) . '/messages';
            // Do not automatically retry a POST after an ambiguous timeout; it might already have been accepted by Meta.
            $response = Http::withToken($token)->acceptJson()->asJson()->timeout(25)->post($url, $payload);
            $json = $response->json();
            $messageId = $json['messages'][0]['id'] ?? null;
            if ($response->successful() && $messageId) {
                DB::table('za_whatsapp_outbox')->where('id', $outboxId)->update([
                    'status' => 'sent', 'meta_message_id' => $messageId,
                    'request_json' => json_encode($payload, JSON_UNESCAPED_UNICODE),
                    'response_json' => json_encode($json, JSON_UNESCAPED_UNICODE),
                    'sent_at' => now(), 'error_code' => null, 'error_message' => null, 'updated_at' => now(),
                ]);
                $this->writeLegacyChatMessage($row, $messageId);
                return;
            }
            $error = $json['error'] ?? [];
            $this->failOutbox($outboxId, (string) ($error['code'] ?? ('HTTP_' . $response->status())), (string) ($error['message'] ?? 'Meta did not accept this message.'), $payload, $json);
        } catch (\Illuminate\Http\Client\ConnectionException $e) {
            // Unknown delivery state is safer than retrying automatically and risking duplicate notifications.
            DB::table('za_whatsapp_outbox')->where('id', $outboxId)->update([
                'status' => 'unknown', 'error_code' => 'NETWORK_RESULT_UNKNOWN',
                'error_message' => 'Network timeout/error; delivery state is unknown. Check webhook/Meta status before retrying.',
                'request_json' => json_encode($payload, JSON_UNESCAPED_UNICODE), 'updated_at' => now(),
            ]);
            Log::warning('WhatsApp send result is ambiguous; automatic retry suppressed.', ['outbox_id' => $outboxId]);
        } catch (Throwable $e) {
            $this->failOutbox($outboxId, 'UNEXPECTED_EXCEPTION', 'Unexpected send failure. Check server logs.', $payload ?? null, null);
            Log::error('WhatsApp send exception', ['outbox_id' => $outboxId, 'exception' => class_basename($e)]);
        }
    }

    private function failOutbox(int $id, string $code, string $message, ?array $request = null, ?array $response = null): void
    {
        DB::table('za_whatsapp_outbox')->where('id', $id)->update([
            'status' => 'failed', 'error_code' => substr($code, 0, 100), 'error_message' => mb_substr($message, 0, 2000),
            'request_json' => $request ? json_encode($request, JSON_UNESCAPED_UNICODE) : null,
            'response_json' => $response ? json_encode($response, JSON_UNESCAPED_UNICODE) : null,
            'failed_at' => now(), 'updated_at' => now(),
        ]);
    }

    private function writeLegacyChatMessage(object $outbox, string $messageId): void
    {
        try {
            $phoneDigits = $this->phoneDigits($outbox->phone_e164);
            $contact = DB::table('za_wb_contacts')->where('phone', $phoneDigits)->orWhere('phone', '+' . $phoneDigits)->first();
            if (!$contact) {
                $contactId = DB::table('za_wb_contacts')->insertGetId(['phone' => $phoneDigits, 'msg_count' => 0, 'status' => 0, 'created_by' => $outbox->created_by, 'updated_by' => $outbox->created_by, 'created_at' => now(), 'updated_at' => now()]);
            } else {
                $contactId = $contact->sno;
            }
            $display = $outbox->message_type === 'text' ? $outbox->text_body : '[Template] ' . $outbox->template_name;
            DB::table('za_wb_messages')->insert([
                'contact_id' => $contactId, 'message' => $display, 'type' => $outbox->message_type,
                'from' => 1, 'wama_id' => $messageId, 'message_date_time' => now(), 'message_status' => 'sent',
                'status' => 0, 'created_by' => $outbox->created_by, 'updated_by' => $outbox->created_by,
                'created_at' => now(), 'updated_at' => now(),
            ]);
        } catch (Throwable $e) {
            // A WhatsApp send accepted by Meta must not be marked failed because a legacy chat mirror failed.
            Log::warning('WhatsApp send succeeded but legacy chat mirror failed.', ['outbox_id' => $outbox->id ?? null]);
        }
    }

    public function recordInboundSession(string $phone, ?string $timestamp, ?string $phoneNumberId, ?string $messageText, ?string $messageId): void
    {
        $digits = $this->phoneDigits($phone);
        if (strlen($digits) < 8 || strlen($digits) > 15) return;
        $normalized = '+' . $digits;
        $settings = $phoneNumberId ? DB::table('za_whatsapp_automation_settings')->where('phone_number_id', $phoneNumberId)->first() : null;
        if (!$settings) {
            Log::warning('Inbound WhatsApp message did not match a configured phone-number profile.');
            return;
        }
        $branchId = (int) $settings->branch_id;
        $dateTime = $timestamp ? \Carbon\Carbon::createFromTimestamp((int) $timestamp, config('app.timezone', 'UTC')) : now();
        $sessionQuery = DB::table('za_whatsapp_sessions')->where('branch_id', $branchId)->where('phone_e164', $normalized);
        $session = $sessionQuery->first();
        if (!$session) {
            DB::table('za_whatsapp_sessions')->insert([
                'branch_id' => $branchId, 'phone_e164' => $normalized,
                'last_inbound_at' => $dateTime, 'last_inbound_meta_message_id' => $messageId,
                'created_at' => now(), 'updated_at' => now(),
            ]);
        } else {
            // Duplicate/out-of-order webhooks must not move the 24-hour window backwards.
            $sessionUpdate = ['updated_at' => now()];
            if (empty($session->last_inbound_at) || $dateTime->greaterThan(\Carbon\Carbon::parse($session->last_inbound_at))) {
                $sessionUpdate['last_inbound_at'] = $dateTime;
                $sessionUpdate['last_inbound_meta_message_id'] = $messageId;
            }
            $sessionQuery->update($sessionUpdate);
        }
        $upper = strtoupper(trim((string) $messageText));
        if (in_array($upper, ['STOP', 'STOP ALL', 'UNSUBSCRIBE', 'CANCEL', 'END', 'QUIT'], true)) {
            DB::table('za_whatsapp_consents')->updateOrInsert(
                ['branch_id' => $branchId, 'phone_e164' => $normalized, 'category' => 'all'],
                ['consent_status' => 'opted_out', 'source' => 'inbound_whatsapp', 'evidence_ref' => $messageId,
                    'opted_out_at' => $dateTime, 'opted_in_at' => null, 'updated_at' => now(), 'created_at' => now()]
            );
        }
    }

    public function updateOutboxStatus(string $messageId, string $status, ?array $error = null): void
    {
        $allowed = ['sent', 'delivered', 'read', 'failed'];
        if (!in_array($status, $allowed, true)) return;
        $current = DB::table('za_whatsapp_outbox')->where('meta_message_id', $messageId)->first(['id', 'status']);
        if (!$current) return;
        if (in_array($current->status, ['read', 'failed'], true)) return;
        $rank = ['queued' => 0, 'processing' => 1, 'unknown' => 1, 'sent' => 2, 'delivered' => 3, 'read' => 4, 'failed' => 5];
        if ($status !== 'failed' && ($rank[$status] ?? 0) < ($rank[$current->status] ?? 0)) return;
        $data = ['status' => $status, 'updated_at' => now()];
        if ($status === 'delivered') $data['delivered_at'] = now();
        if ($status === 'read') $data['read_at'] = now();
        if ($status === 'failed') {
            $data['failed_at'] = now();
            $data['error_code'] = isset($error['code']) ? (string) $error['code'] : 'WEBHOOK_FAILED';
            $data['error_message'] = isset($error['message']) ? mb_substr((string) $error['message'], 0, 2000) : 'Meta webhook reported a failure.';
        }
        DB::table('za_whatsapp_outbox')->where('meta_message_id', $messageId)->update($data);
    }

    public function recordConsent(array $input): array
    {
        $branchId = (int) ($input['branch_id'] ?? 0);
        $category = strtolower(trim((string) ($input['category'] ?? '')));
        $source = trim((string) ($input['source'] ?? ''));
        $evidence = trim((string) ($input['evidence_ref'] ?? ''));
        $consentStatus = ($input['consent_status'] ?? 'opted_in') === 'opted_out' ? 'opted_out' : 'opted_in';
        try { $phone = $this->normalizePhone((string) ($input['phone'] ?? '')); }
        catch (\InvalidArgumentException $e) { return ['ok' => false, 'message' => $e->getMessage()]; }
        if ($branchId < 1 || !in_array($category, ['all', 'marketing', 'utility', 'authentication'], true) || $source === '' || $evidence === '') {
            return ['ok' => false, 'message' => 'Branch, supported category, consent source and evidence reference are required. Never record consent without real recipient evidence.'];
        }
        DB::table('za_whatsapp_consents')->updateOrInsert(
            ['branch_id' => $branchId, 'phone_e164' => $phone, 'category' => $category],
            ['consent_status' => $consentStatus, 'source' => substr($source, 0, 100), 'evidence_ref' => mb_substr($evidence, 0, 1000),
                'opted_in_at' => $consentStatus === 'opted_in' ? now() : null, 'opted_out_at' => $consentStatus === 'opted_out' ? now() : null,
                'created_by' => isset($input['created_by']) ? (int) $input['created_by'] : null, 'updated_by' => isset($input['created_by']) ? (int) $input['created_by'] : null,
                'updated_at' => now(), 'created_at' => now()]
        );
        return ['ok' => true, 'message' => 'Consent record saved with evidence reference.'];
    }
}
