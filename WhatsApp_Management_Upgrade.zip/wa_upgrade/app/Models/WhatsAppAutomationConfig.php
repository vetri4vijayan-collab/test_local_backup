<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppAutomationConfig extends Model
{
    protected $table = 'za_whatsapp_automation_settings';
    protected $primaryKey = 'id';
    protected $guarded = [];
}
