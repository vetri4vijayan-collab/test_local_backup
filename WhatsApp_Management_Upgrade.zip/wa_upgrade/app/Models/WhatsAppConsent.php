<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppConsent extends Model
{
    protected $table = 'za_whatsapp_consents';
    protected $primaryKey = 'id';
    protected $guarded = [];
}
