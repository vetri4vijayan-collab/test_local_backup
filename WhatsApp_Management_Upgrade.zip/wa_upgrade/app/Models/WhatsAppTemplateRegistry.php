<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppTemplateRegistry extends Model
{
    protected $table = 'za_whatsapp_template_registry';
    protected $primaryKey = 'id';
    protected $guarded = [];
    protected $casts = ['components_json' => 'array', 'raw_json' => 'array', 'is_enabled' => 'boolean'];
}
