<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppOutbox extends Model
{
    protected $table = 'za_whatsapp_outbox';
    protected $primaryKey = 'id';
    protected $guarded = [];
    protected $casts = ['components_json' => 'array', 'request_json' => 'array', 'response_json' => 'array'];
}
