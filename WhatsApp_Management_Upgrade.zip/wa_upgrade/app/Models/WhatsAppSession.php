<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppSession extends Model
{
    protected $table = 'za_whatsapp_sessions';
    protected $primaryKey = 'id';
    protected $guarded = [];
}
