<?php

return [
    // Keep this on an actively supported version. Meta's latest as of Oct 2026 is v26.0.
    'api_version' => env('WHATSAPP_GRAPH_API_VERSION', 'v26.0'),
    'verify_token' => env('WHATSAPP_VERIFY_TOKEN'),
    'app_secret' => env('META_APP_SECRET'),
    // Comma-separated user_id values from the ERP's authenticated users table.
    // Empty means the management console fails closed (403) until admins are configured.
    'admin_user_ids' => array_values(array_filter(array_map('trim', explode(',', (string) env('WHATSAPP_ADMIN_USER_IDS', ''))))),
    'bulk_max_recipients' => (int) env('WHATSAPP_BULK_MAX_RECIPIENTS', 250),
    'default_bulk_pacing_seconds' => (int) env('WHATSAPP_BULK_PACING_SECONDS', 10),
];
