<?php

/**
 * Integration examples for owning ERP controller actions; not a standalone route.
 * Configure each event in /wa-management → Automation rules after its template is
 * synced, APPROVED, and enabled. Components are event-specific but the template
 * name and language are resolved dynamically from the branch workflow rule.
 */

use App\Services\WhatsAppManagerService;
use Illuminate\Support\Facades\Log;

// 1) Lead::Add uses event_key=lead.created (implemented in patches/Lead.php).
$welcomeResult = app(WhatsAppManagerService::class)->queueWorkflow([
    'branch_id' => (int) $branchId,
    'event_key' => 'lead.created',
    'to' => $leadPhoneE164,
    'components' => [
        ['type' => 'header', 'parameters' => [
            ['type' => 'image', 'image' => ['link' => $publicWelcomeImageUrl]],
        ]],
        ['type' => 'body', 'parameters' => [
            ['type' => 'text', 'text' => $greeting, 'parameter_name' => 'greet_msg'],
            ['type' => 'text', 'text' => $leadName, 'parameter_name' => 'customer_name'],
            ['type' => 'text', 'text' => $branchWebsite, 'parameter_name' => 'web_link'],
            ['type' => 'text', 'text' => $branchName, 'parameter_name' => 'branch_name'],
            ['type' => 'text', 'text' => $branchPhone, 'parameter_name' => 'contact_no'],
            ['type' => 'text', 'text' => $branchEmail, 'parameter_name' => 'contact_email'],
        ]],
    ],
    'source_type' => 'Lead',
    'source_id' => (int) $leadId,
    'created_by' => (int) $userId,
    'idempotency_key' => 'lead-welcome:' . (int) $branchId . ':' . (int) $leadId,
]);

if (empty($welcomeResult['ok'])) {
    Log::notice('Lead was saved; WhatsApp welcome was not queued.', [
        'lead_id' => $leadId,
        'outbox_id' => $welcomeResult['id'] ?? null,
        'reason' => $welcomeResult['reason'] ?? 'blocked',
    ]);
}

// 2) Customer-created welcome: configure customer.created in the admin console.
$customerWelcomeResult = app(WhatsAppManagerService::class)->queueWorkflow([
    'branch_id' => (int) $branchId,
    'event_key' => 'customer.created',
    'to' => $customerPhoneE164,
    'components' => [
        ['type' => 'body', 'parameters' => [
            ['type' => 'text', 'text' => $customerName],
            ['type' => 'text', 'text' => $customerPortalUrl],
        ]],
    ],
    'source_type' => 'Customer',
    'source_id' => (int) $customerId,
    'created_by' => (int) $userId,
    'idempotency_key' => 'customer-welcome:' . (int) $branchId . ':' . (int) $customerId,
]);

// 3) Event certificate ready: configure event.certificate_ready in the admin console.
$certificateResult = app(WhatsAppManagerService::class)->queueWorkflow([
    'branch_id' => (int) $branchId,
    'event_key' => 'event.certificate_ready',
    'to' => $recipientPhoneE164,
    'components' => [
        ['type' => 'body', 'parameters' => [
            ['type' => 'text', 'text' => $studentName],
            ['type' => 'text', 'text' => $certificatePublicUrl],
        ]],
    ],
    'source_type' => 'EventCertificate',
    'source_id' => (int) $certificateId,
    'created_by' => (int) $userId,
    'idempotency_key' => 'certificate-ready:' . (int) $branchId . ':' . (int) $certificateId,
]);

// 4) Free-form agent reply is allowed only while the 24-hour service window is open.
$replyResult = app(WhatsAppManagerService::class)->queueText([
    'branch_id' => (int) $branchId,
    'to' => $recipientPhoneE164,
    'text' => $replyText,
    'source_type' => 'agent_chat',
    'created_by' => (int) $userId,
    'idempotency_key' => (string) \Illuminate\Support\Str::uuid(),
]);

// Every result includes ok/status/reason and, when inserted, an outbox id. Do not log secrets.
