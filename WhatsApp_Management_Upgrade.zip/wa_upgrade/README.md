# ERP WhatsApp Management Upgrade (Laravel MVC)

This is an **additive upgrade overlay** designed for the Laravel MVC code included in the supplied archive. It centralizes new sends through Meta WhatsApp Cloud API, adds an outbox and message status tracking, and includes an AJAX/jQuery management console styled in a WhatsApp-Web-inspired layout.

> **Deployment warning:** The supplied ZIP did not include `composer.json`, a database SQL dump, all deployment config, or the live database schema. I cannot certify this overlay against your actual Laravel version, existing schema, queue driver, or every controller in the live ERP. Apply on a staging clone, compare the two replaced controllers with your currently deployed versions, and deploy incrementally. This is not a blind production drop-in.

## Included

- `app/Services/WhatsAppManagerService.php`: centralized API, consent/window checks, template sync, admin-managed event-to-template workflow resolution, paced outbox, delivery/read/failed status, idempotency keys, legacy chat mirroring.
- `app/Jobs/ProcessWhatsAppOutboxJob.php`: queued send job; no automatic resend after ambiguous network errors.
- `app/Http/Controllers/WhatsAppManagementController.php`: admin APIs, branch/global switches, templates, chats, bulk, audiences and consent.
- `resources/views/content/whatsapp_management/index.blade.php`: responsive AJAX/jQuery console (no direct browser `fetch()` calls).
- `config/whatsapp.php`: API version, webhook secrets, admin list and bulk throttle settings.
- `database/whatsapp_management_upgrade.sql`: additive MySQL tables, including per-branch event-to-template workflow rules; does not alter existing legacy tables.
- `routes/whatsapp_management.php`: route snippet to merge inside the ERP's authenticated web route group.
- `overlay/`: copies arranged at project-relative paths.
- `patches/Lead.php`: full Lead controller copied from the supplied archive with the Lead::Add welcome send replaced by the central queue call.
- `patches/WhatsAppConfig.php`: full webhook controller copied from the supplied archive with hard-coded tokens removed from this file, webhook signature checks, inbound session tracking and outbox receipt updates.
- `examples/controller_integration_examples.php`: patterns for lead/customer/event/certificate integration using workflow mapping.
- `docs/LEGACY_SEND_INVENTORY.md`: file-by-file inventory of the 105 send-helper references found in the supplied archive and a safe migration order.

## Critical security actions before enabling

1. **Revoke/rotate every Meta access token and webhook verification secret previously embedded in source, comments, logs, or stored in the legacy DB.** Treat the credentials found in the uploaded source as compromised. This overlay deliberately does not repeat their values.
2. Do not assume that creating a new Developer App clears enforcement on the Business Portfolio, WABA, phone number, or templates. Check Meta Business Support Home / Account Quality, open an appeal if appropriate, and use only assets/permissions authorized for the app.
3. Use a dedicated System User token with only the permissions your app needs (`whatsapp_business_management` and `whatsapp_business_messaging`) and verify that the system user/app are assigned to the correct WABA and phone-number asset.
4. `APP_KEY` must be stable and backed up. Laravel `Crypt::encryptString()` protects tokens in the DB; changing `APP_KEY` without a planned re-encryption/restore procedure makes them undecryptable.
5. Set a strong random webhook verify token and the Meta App Secret. The patched webhook rejects POST events if `META_APP_SECRET` is absent or the `X-Hub-Signature-256` signature is invalid.
6. Webhooks must be reachable over HTTPS. Because this callback lives in `routes/web.php` in the supplied project, make `/meta_whatsapp_callback` CSRF-exempt in the Laravel CSRF middleware **only** for this route (or move the callback to an API route while preserving the configured Meta callback URL). Keep HMAC signature verification enabled; do not disable CSRF globally.

## Install on staging first

1. Take a database backup and apply `database/whatsapp_management_upgrade.sql` to a staging copy of the production database. The SQL is MySQL 5.7+/8.0 oriented and only creates new tables. Confirm table collation, DB user permissions, and indexes for your actual MySQL/MariaDB version.
2. Copy the files from `overlay/` into the Laravel project root. Review `overlay/app/Http/Controllers/sales/lead/Lead.php` and `overlay/app/Http/Controllers/WhatsAppConfig.php` against your live versions before replacement; preserve any local changes made after the supplied archive.
3. Add the contents of `routes/whatsapp_management.php` **inside** the existing `auth:web`/session-protected route group in `routes/web.php`. Do not expose the management routes publicly.
4. Set these environment values, then run `php artisan config:clear` (and rebuild config cache as part of your deployment):

   ```dotenv
   WHATSAPP_GRAPH_API_VERSION=v26.0
   WHATSAPP_VERIFY_TOKEN=replace-with-a-long-random-webhook-verification-secret
   META_APP_SECRET=the-app-secret-from-the-Meta-developer-console
   WHATSAPP_ADMIN_USER_IDS=123,456
   WHATSAPP_BULK_MAX_RECIPIENTS=250
   WHATSAPP_BULK_PACING_SECONDS=10
   ```

   `WHATSAPP_ADMIN_USER_IDS` must contain the actual authenticated ERP `user_id` values (or `id` if the account model has no `user_id`). It intentionally fails closed with HTTP 403 when empty. Restrict the list to trusted administrators.
5. Configure a **durable async queue** (Redis or a configured database queue); do not use the `sync` driver for production bulk campaigns. If using the database queue, verify your `jobs` and failed-job tables exist. Start a supervised worker with a single attempt, for example:

   ```bash
   php artisan queue:work --queue=whatsapp,default --tries=1 --timeout=60
   ```

   Run a separate worker under Supervisor/systemd/container orchestration and monitor worker crashes and the failed-job table.
6. Open `/wa-management` as a user listed in `WHATSAPP_ADMIN_USER_IDS`. Add a profile for each branch using the correct WABA ID, phone-number ID, and a freshly rotated System User token. Keep its sending switch **off** initially, test connection, sync templates, review the status/category/components in Meta and ERP, then enable only templates you intend to use.
7. Open **Automation rules** and map `lead.created` to the approved/enabled welcome template. Add other branch/event mappings only after integrating that event with `queueWorkflow()` in the corresponding controller. The code intentionally has no default template fallback if a workflow mapping is absent or disabled.
8. Before any live campaign, import or record genuine consent evidence. Test a single internal/staging number that explicitly opted in, then a two-recipient batch, then increment carefully. Validate webhook callbacks and message status progression.

## Production behavior

- **Template sends:** require a configured/enabled branch profile, global kill switch disabled, synced Meta template with `APPROVED` status, ERP template toggle on, and a matching recorded consent record. An approved template is not proof of recipient consent.
- **Free-form text:** require the last inbound user message to be less than 24 hours old and no global opt-out. The window is reset by each inbound message.
- **Bulk:** hard-capped by configuration (maximum 250 recipients/request in this package), paced per branch, logged per recipient, deduplicated with an idempotency key. This cap is an application safety setting, not a Meta messaging quota or a promise about account throughput.
- **Delivery indicators:** `sent` means Meta accepted the send request. `delivered`, `read`, and `failed` are driven by signed Meta status webhooks. An ambiguous timeout is saved as `unknown` rather than automatically resent, to reduce accidental duplicates.
- **Kill switch:** the global switch blocks sending at queue time and execution time; branch profile switches remain separate. Queued records that are encountered while sending is disabled become failed/blocked rather than bypassing the switch.
- **Audiences:** “Custom audience” in this overlay means a saved ERP recipient list, not a native WhatsApp group. This version sends individually and does not call the Groups API. Meta has a separate Groups API with eligibility and participation limits; do not assume your WABA is eligible.
- **Legacy send paths:** the Lead welcome block in `Lead::Add` is migrated as a concrete example, and the management console uses the new central service. The supplied project contains 105 `sendRequestToWhatsApp` references across 29 PHP files, plus direct Graph API calls in lead/customer/events/cron/dashboard controllers and historical controller copies; see `docs/LEGACY_SEND_INVENTORY.md`. Those calls are **not all automatically rewritten in this overlay**. Migrate each live workflow to `WhatsAppManagerService::queueTemplate()` (or `queueText()` for an in-window reply) and retire the old direct post in a controlled staged release; otherwise old flows can still bypass central consent/pacing/logging rules.


## Dynamic workflow template selection

1. Open **Automation rules** for the branch and create `lead.created` → `elysium_academy_welcome_message` / `en_US` after the template is synced, approved and enabled.
2. The Lead controller supplies its event-specific components (greeting, name, branch, website, etc.) but no longer chooses the Meta template name. The service resolves the template and language from `za_whatsapp_workflow_rules` at runtime.
3. Use the same pattern for `customer.created`, `event.certificate_ready`, `event.reminder`, or other stable ERP event keys. Update each controller to call `queueWorkflow()` with a matching event key; add the mapping in the UI per branch.
4. Disabling the rule stops future workflow sends and causes already queued messages for that workflow to be blocked at execution time; changing the mapping also blocks stale queued messages. Disabling the mapped template or branch/API profile likewise blocks sends.

This keeps event-specific variable construction in code (where ERP values are known) and business template choice/enablement in the admin console. It does not use `eval()` or execute admin-entered PHP/JavaScript expressions.

## Important data note

The legacy webhook continues to store chat messages in `za_wb_contacts` and `za_wb_messages`; the new outbox also mirrors accepted outgoing messages to those tables for the current chat UI. That mirror uses the legacy columns found in the uploaded source and catches failures rather than marking an already accepted Meta send as failed. Validate those columns against your production schema before enabling it. The outbox keeps message bodies/component payloads for support and delivery troubleshooting; restrict database/log access and define a retention/redaction policy appropriate for your ERP data.

## Rollback

- First set the global kill switch ON and disable branch profiles.
- Roll back the application overlay to the tagged prior application version while keeping the new tables untouched; existing ERP tables are not modified by this SQL.
- Do not drop the new tables until you have exported the outbox, consent and campaign audit records and confirmed no queued job or webhook process depends on them.

See `docs/VALIDATION_AND_LIMITATIONS.md` for test results and known rollout gates.
