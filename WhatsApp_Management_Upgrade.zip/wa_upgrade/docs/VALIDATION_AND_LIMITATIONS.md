# Validation, known limits, and pre-production checklist

## Checks performed on this package

- PHP syntax validation was run with the available PHP CLI on all package PHP files, the copied overlay controllers and examples. The inline JavaScript was extracted from Blade with the Blade config expression normalized and passed `node --check`. The new overlay was scanned for literal Meta access-token strings; that does not make the original uploaded ERP source safe.
- The source bundle did not contain `composer.json`, a SQL dump, deployment `.env`, full middleware configuration, or a live schema, so Laravel boot tests, DB migration execution, HTTP integration tests, Meta API tests and queue-worker tests could not be run here.
- Run the full checks against your actual deployed checkout and a staging database before enabling the service.

## Staging acceptance checks

1. Confirm admin allowlist blocks a normal ERP user and allows only the configured admin.
2. Confirm missing `META_APP_SECRET`, missing webhook signature and invalid signature return non-2xx; valid Meta GET verification returns the challenge.
3. Send inbound text from an opted-in test account; confirm a session row is written for the configured phone-number ID/branch.
4. Send a plain text reply with the window open (accepted into queue), then simulate a window older than 24 hours (blocked).
5. Sync a test WABA's templates; confirm imported templates are disabled until reviewed, non-approved templates cannot be enabled, and template sends without consent are blocked/logged. Configure `lead.created` in Automation rules and confirm the Lead controller resolves that rule dynamically; disabling either the rule or template must block sends.
6. Record explicit, documented consent for a test recipient; queue a single approved template to that test contact; confirm the outbox progresses queued -> processing -> sent -> delivered/read using actual webhooks.
7. Simulate opt-out keywords (STOP, STOP ALL, UNSUBSCRIBE, CANCEL, END, QUIT); confirm subsequent template initiation is blocked until a legitimate new opt-in is recorded.
8. Turn on global kill switch while items are queued; confirm no queued job sends after switch is on. Turn branch switch off and test again.
9. Queue a bulk batch that includes invalid, opted-out, non-consenting and consenting test users; verify per-recipient outcomes, hard cap, paced `scheduled_at` values and no duplicates after retrying the browser request.
10. Inspect worker logs, failed jobs, queue delay, webhook signature failures, API error rates, business quality/rating, template quality and account limits during a limited pilot.

## Known limits

- `Lead::Add` now calls the central queue. This does not imply all historic send sites in the supplied ERP have been migrated. The project includes many direct `graph.facebook.com/.../messages` posts across current and historical controller files; they must be migrated separately and verified.
- Inbound controller logic was legacy code and selects the first webhook entry/change and first inbound message in that change; robust multi-entry/multi-message iteration and media type coverage should be completed/tested against real Meta payloads before production rollout.
- The legacy table mirror is best-effort and depends on the production schema matching the columns discovered in the uploaded source.
- No test credentials were used, the SQL was not executed against a MySQL instance, and no real WhatsApp message was sent.
- WhatsApp/Meta may restrict apps, WABAs, phone numbers or businesses based on quality, policy or other enforcement signals. The code cannot guarantee zero restrictions. If the new app is restricted, resolve the underlying enforcement in Meta Support/Account Quality rather than trying to evade it by rotating apps.
