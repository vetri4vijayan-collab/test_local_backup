<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class EntitySalaryBalanceService
{
    public function summary($month, $year, $company_id_filt)
    {
        $payrollService = app(PayrollPreviewService::class);

        if($company_id_filt == 0){

            $companies = DB::table('egc_department')
                    ->join('egc_staff','egc_staff.department_id','=', 'egc_department.sno')
                    ->where('egc_department.status', 0)
                    ->where('egc_department.company_id', 0)
                    ->select(
                        'egc_department.sno as entity_id',
                        'egc_department.company_id',
                        'egc_department.department_name as entity_name',
                    )
                    ->distinct()
                    ->get();
            // return $companies;

            $response = [];

            foreach ($companies as $company) {

                $endOfMonth = Carbon::create($year,$month,1)->endOfMonth();
                $payrollDate = Carbon::create($year, $month, 1);
                $monthStart = $payrollDate->copy()->startOfMonth()->toDateString();
                $endOfMonth = $payrollDate->copy()->endOfMonth()->toDateString();
                $payrollMonth = $payrollDate->format('Y-m');

                $staffQuery =  DB::table('egc_staff as s')
                    ->leftJoin('egc_company', 's.company_id', '=', 'egc_company.sno')
                    ->leftJoin('egc_entity', 's.entity_id', '=', 'egc_entity.sno')
                    ->leftJoin('egc_department', 's.department_id', '=', 'egc_department.sno')
                    ->leftJoin('egc_division', 's.division_id', '=', 'egc_division.sno')
                    ->leftJoin('egc_job_role', 's.job_role_id', '=', 'egc_job_role.sno')
                    ->where('s.status','!=', 2)
                    ->where(function ($q) use ( $month, $year, $payrollMonth, $monthStart,$endOfMonth) {
                        /* ACTIVE STAFF*/
                        $q->whereIn('s.status', [0, 1]);
                        /* NOTICE PERIOD STAFF */
                        $q->orWhere(function ($notice) use ($payrollMonth) {
                            $notice->where('s.status', 4)
                                ->whereNotNull('s.notice_end_date')
                                ->whereRaw("
                                    ? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                                    AND DATE_FORMAT(s.notice_end_date, '%Y-%m')
                                ", [$payrollMonth]);
                        });

                        /* EXITED STAFF */
                        $q->orWhere(function ($exit) use ( $payrollMonth,$monthStart, $endOfMonth) {

                            $exit->whereIn('s.status', [5, 6, 7])
                                ->whereNotNull('s.staff_last_date')
                                ->whereNotIn('s.sno', [211, 212, 94, 77])
                                ->whereRaw("
                                    ? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                                    AND DATE_FORMAT(s.staff_last_date, '%Y-%m')
                                ", [$payrollMonth])
                                ->whereRaw("
                                    DATEDIFF(
                                        LEAST(s.staff_last_date, ?),
                                        GREATEST(s.date_of_joining, ?)
                                    ) + 1 > ?
                                ", [
                                    $endOfMonth,
                                    $monthStart,
                                    4
                                ]);
                        });

                        /* SPECIAL EXIT STAFF */
                        $q->orWhere(function ($special) use ($payrollMonth ) {

                            $special->whereIn('s.sno', [211, 212, 94, 77])
                                ->whereIn('s.status', [5, 6, 7])
                                ->whereNotNull('s.staff_last_date')
                                ->whereRaw("
                                    ? BETWEEN DATE_FORMAT(
                                        s.date_of_joining,
                                        '%Y-%m'
                                    )
                                    AND DATE_FORMAT(
                                        DATE_SUB(
                                            s.staff_last_date,
                                            INTERVAL 1 MONTH
                                        ),
                                        '%Y-%m'
                                    )
                                ", [$payrollMonth])
                                ->whereRaw("
                                    DATEDIFF(
                                        s.staff_last_date,
                                        s.date_of_joining
                                    ) > ?
                                ", [4]);
                        });
                    })
                    ->whereDate('s.date_of_joining', '<=', $endOfMonth)
                    ->where('s.sno', '>', 0)
                    ->select(
                        's.*',
                        's.sno',
                        's.staff_name',
                        's.staff_id as staff_code',
                        's.company_id',
                        's.entity_id',
                        's.nick_name',
                        's.mobile_no',
                        's.staff_image',
                        's.company_type',
                        's.gender',
                        's.salary_type',
                        's.salary_date',
                        's.staff_last_date',
                        's.notice_start_date',
                        's.notice_end_date',
                        's.date_of_joining',
                        'egc_entity.entity_name',
                        'egc_entity.entity_short_name',
                        'egc_company.company_base_color',
                        'egc_company.company_name',
                        'egc_department.department_name',
                        'egc_division.division_name',
                        'egc_job_role.job_position_name as job_role_name'
                    );
                    /*
                    |--------------------------------------------------------------------------
                    | Company Filter
                    |--------------------------------------------------------------------------
                    */
                
                    $staffQuery->where('s.department_id',$company->entity_id);
                    
                    $staffs = $staffQuery
                        ->orderBy('s.date_of_joining', 'desc')
                            ->get();

                    
                    $actual_salary = 0;

                    foreach ($staffs as $staff) {

                        $salary = $payrollService->calculateStaffFixed(
                            $staff,
                            $month,
                            $year,
                            0
                        );
                        $actual_salary += $salary['fiexd_gross_salary'];

                    }

                    $companyStaffCount =$staffs->count();
                    $avg_salary = $companyStaffCount > 0 ? ($actual_salary/$companyStaffCount) : 0 ;
                

                    $response[] = [
                        'entity_id' => $company->entity_id,
                        'entity_name' => $company->entity_name,
                        'entity_base_color' =>  null,
                        'entity_favicon' => null,
                        'staff' => $companyStaffCount,
                        'actual_salary' => round($actual_salary),
                        'avg_salary' => round($avg_salary),
                        'shared_value' => 0,
                        'other_company_share' => 0,
                        'shared_staff' => 0,
                        'sales_value' => 0,
                        'company_contribution_percentage' => 0,
                        'salary_consumption_percentage' => 0,
                        'status' => NULL,
                    ];
        
            }

            return $response;

        }else{

        
            /*
            |--------------------------------------------------------------------------
            | Group By
            |--------------------------------------------------------------------------
            */

            $current = Carbon::create($year, $month, 1);

        
            $previous = $current->copy()->subMonth();

            $previousMonth = $previous->month;
            $previousYear  = $previous->year;
        
            $salesData = DB::table('egc_target_achievements')
            ->join('egc_entity', 'egc_entity.sno', '=', 'egc_target_achievements.entity_id')
            ->whereMonth('egc_target_achievements.achieved_date', $previousMonth)
            ->whereYear('egc_target_achievements.achieved_date', $previousYear)
            ->where('egc_target_achievements.status', 0)
            ->groupBy('egc_target_achievements.entity_id')
            ->select(
                'egc_target_achievements.entity_id',
                DB::raw('SUM(egc_target_achievements.achieved_amount) as sales')
            )
            ->pluck('sales', 'entity_id');

                
                

                $helper = new \App\Helpers\Helpers();
                $general_setting = $helper->general_setting_data();

                $companies = DB::table('egc_entity')
                ->join('egc_company', 'egc_company.sno', '=', 'egc_entity.company_id')
                    ->join('egc_staff','egc_staff.company_id','=', 'egc_company.sno')
                    ->where('egc_entity.status', 0)
                    ->where('egc_entity.company_id', $company_id_filt)
                    ->select(
                        'egc_entity.sno as entity_id',
                        'egc_entity.company_id',
                        'egc_entity.entity_name',
                        'egc_entity.entity_favicon',
                        'egc_entity.entity_base_color',
                    )
                    ->distinct()
                    ->get();

            $response = [];

            foreach ($companies as $company) {

                $endOfMonth = Carbon::create($year,$month,1)->endOfMonth();
                $payrollDate = Carbon::create($year, $month, 1);
                $monthStart = $payrollDate->copy()->startOfMonth()->toDateString();
                $endOfMonth = $payrollDate->copy()->endOfMonth()->toDateString();
                $payrollMonth = $payrollDate->format('Y-m');

                $staffQuery =  DB::table('egc_staff as s')
                    ->leftJoin('egc_company', 's.company_id', '=', 'egc_company.sno')
                    ->leftJoin('egc_entity', 's.entity_id', '=', 'egc_entity.sno')
                    ->leftJoin('egc_department', 's.department_id', '=', 'egc_department.sno')
                    ->leftJoin('egc_division', 's.division_id', '=', 'egc_division.sno')
                    ->leftJoin('egc_job_role', 's.job_role_id', '=', 'egc_job_role.sno')
                    ->where('s.status','!=', 2)
                    ->where(function ($q) use ( $month, $year, $payrollMonth, $monthStart,$endOfMonth) {
                        /* ACTIVE STAFF*/
                        $q->whereIn('s.status', [0, 1]);
                        /* NOTICE PERIOD STAFF */
                        $q->orWhere(function ($notice) use ($payrollMonth) {
                            $notice->where('s.status', 4)
                                ->whereNotNull('s.notice_end_date')
                                ->whereRaw("
                                    ? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                                    AND DATE_FORMAT(s.notice_end_date, '%Y-%m')
                                ", [$payrollMonth]);
                        });

                        /* EXITED STAFF */
                        $q->orWhere(function ($exit) use ( $payrollMonth,$monthStart, $endOfMonth) {

                            $exit->whereIn('s.status', [5, 6, 7])
                                ->whereNotNull('s.staff_last_date')
                                ->whereNotIn('s.sno', [211, 212, 94, 77])
                                ->whereRaw("
                                    ? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                                    AND DATE_FORMAT(s.staff_last_date, '%Y-%m')
                                ", [$payrollMonth])
                                ->whereRaw("
                                    DATEDIFF(
                                        LEAST(s.staff_last_date, ?),
                                        GREATEST(s.date_of_joining, ?)
                                    ) + 1 > ?
                                ", [
                                    $endOfMonth,
                                    $monthStart,
                                    4
                                ]);
                        });

                        /* SPECIAL EXIT STAFF */
                        $q->orWhere(function ($special) use ($payrollMonth ) {

                            $special->whereIn('s.sno', [211, 212, 94, 77])
                                ->whereIn('s.status', [5, 6, 7])
                                ->whereNotNull('s.staff_last_date')
                                ->whereRaw("
                                    ? BETWEEN DATE_FORMAT(
                                        s.date_of_joining,
                                        '%Y-%m'
                                    )
                                    AND DATE_FORMAT(
                                        DATE_SUB(
                                            s.staff_last_date,
                                            INTERVAL 1 MONTH
                                        ),
                                        '%Y-%m'
                                    )
                                ", [$payrollMonth])
                                ->whereRaw("
                                    DATEDIFF(
                                        s.staff_last_date,
                                        s.date_of_joining
                                    ) > ?
                                ", [4]);
                        });
                    })
                    ->whereDate('s.date_of_joining', '<=', $endOfMonth)
                    ->where('s.sno', '>', 0)
                    ->select(
                        's.*',
                        's.sno',
                        's.staff_name',
                        's.staff_id as staff_code',
                        's.company_id',
                        's.entity_id',
                        's.nick_name',
                        's.mobile_no',
                        's.staff_image',
                        's.company_type',
                        's.gender',
                        's.salary_type',
                        's.salary_date',
                        's.staff_last_date',
                        's.notice_start_date',
                        's.notice_end_date',
                        's.date_of_joining',
                        'egc_entity.entity_name',
                        'egc_entity.entity_short_name',
                        'egc_company.company_base_color',
                        'egc_company.company_name',
                        'egc_department.department_name',
                        'egc_division.division_name',
                        'egc_job_role.job_position_name as job_role_name'
                    );
                    /*
                    |--------------------------------------------------------------------------
                    | Company Filter
                    |--------------------------------------------------------------------------
                    */
                
                    $staffQuery->where('s.entity_id',$company->entity_id);
                    
                    $staffs = $staffQuery
                        ->orderBy('s.date_of_joining', 'desc')
                            ->get();

                    
                    $actual_salary = 0;

                    foreach ($staffs as $staff) {

                        $salary = $payrollService->calculateStaffFixed(
                            $staff,
                            $month,
                            $year,
                            0
                        );
                        $actual_salary += $salary['fiexd_gross_salary'];

                    }

                    $sales = $salesData[$company->entity_id] ?? 0;

                    $companyStaffCount =$staffs->count();
                    $avg_salary = $companyStaffCount > 0 ? ($actual_salary/$companyStaffCount) : 0 ;
                

                    $response[] = [
                        'entity_id' => $company->entity_id,
                        'entity_name' => $company->entity_name,
                        'entity_base_color' => $company->entity_base_color ?? null,
                        'entity_favicon' => $company->entity_favicon,
                        'staff' => $companyStaffCount,
                        'actual_salary' => round($actual_salary),
                        'avg_salary' => round($avg_salary),
                        'shared_value' => 0,
                        'other_company_share' => 0,
                        'shared_staff' => 0,
                        'sales_value' => round($sales),
                        'company_contribution_percentage' => 0,
                        'salary_consumption_percentage' => 0,
                        'status' => NULL,
                    ];
        
            }

            // Company 0 salary
            $totalEntityActual = collect($response)->sum('actual_salary');

            $companyService = app(\App\Services\CompanySalaryBalanceService::class);
            $companySummary = collect(
                $companyService->summary($month, $year)
            )->firstWhere('company_id', $company_id_filt);
            $companyShare = $companySummary['other_company_share'] ?? 0;

            foreach($response as &$entity){

                $ratio = $totalEntityActual > 0 ? $entity['actual_salary'] / $totalEntityActual : 0;

                $entity['company_contribution_percentage'] = round($ratio*100,1);

                $entity['other_company_share'] = round($companyShare*$ratio);

                $entity['shared_value'] = $entity['actual_salary'] + $entity['other_company_share'];

                 $entity['salary_consumption_percentage'] = $entity['sales_value'] > 0 ? round(($entity['shared_value'] / $entity['sales_value']) * 100,) : 0;


                if ($entity['sales_value'] <= 0) {
                    $entity['status'] = 'danger';
                } elseif ($entity['salary_consumption_percentage'] <= 40) {
                    $entity['status'] = 'profit';
                } elseif ($entity['salary_consumption_percentage'] <= 60) {
                    $entity['status'] = 'loss';
                } else {
                    $entity['status'] = 'danger';
                }

            }

            unset($company);

        

            return $response;
        }
    }

}