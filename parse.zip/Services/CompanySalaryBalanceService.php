<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CompanySalaryBalanceService
{
    public function summary($month, $year, $type = 'company')
    {
        $payrollService = app(PayrollPreviewService::class);

        /*
        |--------------------------------------------------------------------------
        | Group By
        |--------------------------------------------------------------------------
        */

        $current = Carbon::create($year, $month, 1);

       
        $previous = $current->copy()->subMonth();

        $previousMonth = $previous->month;
        $previousYear  = $previous->year;
       
        $salesData = DB::table('egc_target_achievements')
        ->join('egc_entity', 'egc_entity.sno', '=', 'egc_target_achievements.entity_id')
        ->join('egc_company', 'egc_company.sno', '=', 'egc_entity.company_id')
        ->whereMonth('egc_target_achievements.achieved_date', $previousMonth)
        ->whereYear('egc_target_achievements.achieved_date', $previousYear)
        ->where('egc_target_achievements.status', 0)
        ->groupBy('egc_entity.company_id')
        ->select(
            'egc_entity.company_id',
            DB::raw('SUM(egc_target_achievements.achieved_amount) as sales')
        )
        ->pluck('sales', 'company_id');

         

            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();

            $companies = DB::table('egc_company')
                ->join(
                    'egc_staff',
                    'egc_staff.company_id',
                    '=',
                    'egc_company.sno'
                )
                ->where('egc_company.status', 0)
                ->select(
                    'egc_company.sno',
                    'egc_company.company_name',
                    'egc_company.company_favicon',
                    'egc_company.company_base_color',
                )
                ->distinct()
                ->get();

            $mainCompanyStaffExists = DB::table('egc_staff')
                ->where('company_id', 0)
                ->where('status', '!=', 2)
                ->exists();

            if ($mainCompanyStaffExists) {
                $companies->prepend((object)[
                    'sno' => 0,
                    'company_name' => $general_setting->title,
                    'company_favicon' => $general_setting->fav_icon,
                    'company_base_color' => '#ab2b22'
                ]);
            }
        
       
        $response = [];

        foreach ($companies as $company) {

            

            $endOfMonth = Carbon::create($year,$month,1)->endOfMonth();
            $payrollDate = Carbon::create($year, $month, 1);
            $monthStart = $payrollDate->copy()->startOfMonth()->toDateString();
            $endOfMonth = $payrollDate->copy()->endOfMonth()->toDateString();
            $payrollMonth = $payrollDate->format('Y-m');

            $staffQuery =  DB::table('egc_staff  as s')
                ->leftJoin('egc_company', 's.company_id', '=', 'egc_company.sno')
                ->leftJoin('egc_entity', 's.entity_id', '=', 'egc_entity.sno')
                ->leftJoin('egc_department', 's.department_id', '=', 'egc_department.sno')
                ->leftJoin('egc_division', 's.division_id', '=', 'egc_division.sno')
                ->leftJoin('egc_job_role', 's.job_role_id', '=', 'egc_job_role.sno')
                ->where('s.status','!=', 2)
                ->where(function ($q) use ( $month, $year, $payrollMonth, $monthStart,$endOfMonth) {
                    /* ACTIVE STAFF*/
                    $q->whereIn('s.status', [0, 1]);
                    /* NOTICE PERIOD STAFF */
                    $q->orWhere(function ($notice) use ($payrollMonth) {
                        $notice->where('s.status', 4)
                            ->whereNotNull('s.notice_end_date')
                            ->whereRaw("
                                ? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                                AND DATE_FORMAT(s.notice_end_date, '%Y-%m')
                            ", [$payrollMonth]);
                    });

                    /* EXITED STAFF */
                    $q->orWhere(function ($exit) use ( $payrollMonth,$monthStart, $endOfMonth) {

                        $exit->whereIn('s.status', [5, 6, 7])
                            ->whereNotNull('s.staff_last_date')
                            ->whereNotIn('s.sno', [211, 212, 94, 77])
                            ->whereRaw("
                                ? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                                AND DATE_FORMAT(s.staff_last_date, '%Y-%m')
                            ", [$payrollMonth])
                            ->whereRaw("
                                DATEDIFF(
                                    LEAST(s.staff_last_date, ?),
                                    GREATEST(s.date_of_joining, ?)
                                ) + 1 > ?
                            ", [
                                $endOfMonth,
                                $monthStart,
                                4
                            ]);
                    });

                    /* SPECIAL EXIT STAFF */
                    $q->orWhere(function ($special) use ($payrollMonth ) {

                        $special->whereIn('s.sno', [211, 212, 94, 77])
                            ->whereIn('s.status', [5, 6, 7])
                            ->whereNotNull('s.staff_last_date')
                            ->whereRaw("
                                ? BETWEEN DATE_FORMAT(
                                    s.date_of_joining,
                                    '%Y-%m'
                                )
                                AND DATE_FORMAT(
                                    DATE_SUB(
                                        s.staff_last_date,
                                        INTERVAL 1 MONTH
                                    ),
                                    '%Y-%m'
                                )
                            ", [$payrollMonth])
                            ->whereRaw("
                                DATEDIFF(
                                    s.staff_last_date,
                                    s.date_of_joining
                                ) > ?
                            ", [4]);
                    });
                })
                ->whereDate('s.date_of_joining', '<=', $endOfMonth)
                ->where('s.sno', '>', 0)
                ->select(
                    's.*',
                    's.sno',
                    's.staff_name',
                    's.staff_id as staff_code',
                    's.company_id',
                    's.entity_id',
                    's.nick_name',
                    's.mobile_no',
                    's.staff_image',
                    's.company_type',
                    's.gender',
                    's.salary_type',
                    's.salary_date',
                    's.staff_last_date',
                    's.notice_start_date',
                    's.notice_end_date',
                    's.date_of_joining',
                    'egc_entity.entity_name',
                    'egc_entity.entity_short_name',
                    'egc_company.company_base_color',
                    'egc_company.company_name',
                    'egc_department.department_name',
                    'egc_division.division_name',
                    'egc_job_role.job_position_name as job_role_name'
                );
                /*
                |--------------------------------------------------------------------------
                | Company Filter
                |--------------------------------------------------------------------------
                */
                if ($company->sno == 0) {
                    $staffQuery->where('s.company_id', 0);
                } else {
                    $staffQuery->where('s.company_id',$company->sno);
                }
                
                $staffs = $staffQuery
                    ->orderBy('s.date_of_joining', 'desc')
                        ->get();

                
                $actual_salary = 0;

                foreach ($staffs as $staff) {

                    $salary = $payrollService->calculateStaffFixed(
                        $staff,
                        $month,
                        $year,
                        0
                    );

                    $actual_salary += $salary['fiexd_gross_salary'];

                }

                $sales = $salesData[$company->sno] ?? 0;
                


                $companyStaffCount =$staffs->count();
                $avg_salary = $companyStaffCount > 0 ? ($actual_salary/$companyStaffCount) : 0 ;
               

                $response[] = [
                    'company_id' => $company->sno,
                    'company_name' => $company->company_name,
                    'company_base_color' => $company->company_base_color ?? null,
                    'company_favicon' => $company->company_favicon,
                    'staff' => $companyStaffCount,
                    'actual_salary' => round($actual_salary),
                    'avg_salary' => round($avg_salary),
                    'shared_value' => 0,
                    'other_company_share' => 0,
                    'shared_staff' => 0,
                    'sales_value' => round($sales),
                    'company_contribution_percentage' => 0,
                    'salary_consumption_percentage' => 0,
                    'status' => NULL,
                ];
       
        }

        // Company 0 salary
        $company0 = collect($response)->firstWhere('company_id', 0);
        $company0Salary = $company0['actual_salary'] ?? 0;

        // Total salary of actual companies only
        $totalActualSalary = collect($response)
            ->where('company_id', '!=', 0)
            ->sum('actual_salary');

        foreach ($response as &$company) {

            if ($company['company_id'] == 0) {

                $company['shared_value'] = 0;
                $company['company_contribution_percentage'] = 0;
                $company['salary_consumption_percentage'] = 0;
                $company['status'] = null;

                continue;
            }

            // Contribution %
            $contribution =
                $totalActualSalary > 0
                    ? ($company['actual_salary'] / $totalActualSalary)
                    : 0;

            $company['company_contribution_percentage'] =
                round($contribution * 100, 1);

            // Company 0 distributed share
            $shareFromCompany0 =
                round($company0Salary * $contribution);

            // Final shared salary
            $company['shared_value'] =
                $company['actual_salary'] + $shareFromCompany0;

            $company['other_company_share'] =
                $shareFromCompany0;

            // Salary consumption
            $company['salary_consumption_percentage'] =
                $company['sales_value'] > 0
                    ? round(
                        ($company['shared_value'] / $company['sales_value']) * 100,
                        1
                    )
                    : 0;

            if ($company['sales_value'] <= 0) {

                $company['status'] = 'danger';

            } elseif ($company['salary_consumption_percentage'] <= 40) {

                $company['status'] = 'profit';

            } elseif ($company['salary_consumption_percentage'] <= 60) {

                $company['status'] = 'loss';

            } else {

                $company['status'] = 'danger';

            }
        }

        unset($company);

        $response = collect($response)
            ->sortBy(function ($item) {
                return $item['company_id'] == 0 ? 1 : 0;
            })
            ->values()
            ->toArray();

        return $response;
    }
}