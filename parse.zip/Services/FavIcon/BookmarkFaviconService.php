<?php

namespace App\Services\FavIcon;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

/**
 * BookMarks-specific official favicon resolver.
 *
 * The browser receives an ERP-owned favicon URL. The server resolves the
 * target site's official icon and caches it locally, so BookMarks does not
 * depend on a third-party favicon proxy.
 */
class BookmarkFaviconService
{
    private const MAX_REDIRECTS = 3;
    private const MAX_BYTES = 524288;
    private const MAX_HTML_BYTES = 4 * 1024 * 1024;

    public function getFavicon(string $websiteUrl, bool $forceRefresh = false): ?string
    {
        $websiteUrl = $this->normalizeUrl($websiteUrl);
        if (!$websiteUrl || !$this->isSafePublicUrl($websiteUrl)) {
            return null;
        }

        $host = strtolower((string) parse_url($websiteUrl, PHP_URL_HOST));
        $port = (string) (parse_url($websiteUrl, PHP_URL_PORT) ?: '');
        $cacheBase = 'favicons/bookmark_' . sha1($host . ':' . $port);

        // Reuse a previously cached official icon unless the caller explicitly
        // asks for a refresh (used for legacy/fallback icons).
        if (!$forceRefresh) {
            foreach (['ico', 'png', 'jpg', 'jpeg', 'webp', 'svg', 'gif', 'bmp'] as $extension) {
                $cacheKey = $cacheBase . '.' . $extension;
                if (Storage::disk('public')->exists($cacheKey)) {
                    return $this->getCachedFaviconUrl(basename($cacheKey));
                }
            }
        }

        try {
            $page = $this->requestFollowingSafeRedirects($websiteUrl, false);

            // If the page cannot be fetched, the site's same-origin
            // /favicon.ico is the browser's implicit official favicon.
            // No generated, domain-letter, or third-party fallback is used.
            if (!$page || !$page->successful()) {
                return $this->downloadDefault($websiteUrl, $cacheBase);
            }

            $contentLength = (int) ($page->header('Content-Length') ?: 0);
            if ($contentLength > self::MAX_HTML_BYTES) {
                return $this->downloadDefault($websiteUrl, $cacheBase);
            }

            $html = (string) $page->body();
            if ($html === '' || strlen($html) > self::MAX_HTML_BYTES) {
                return $this->downloadDefault($websiteUrl, $cacheBase);
            }

            // Only use actual favicon declarations from the site's HTML.
            // Apple touch / mask icons are deliberately excluded because they
            // are not the browser tab/favicon asset the user expects.
            foreach ($this->extractFaviconCandidates($html) as $candidate) {
                $faviconUrl = $this->makeAbsoluteUrl($candidate['href'], $websiteUrl);
                if (!$faviconUrl || !$this->isSafePublicUrl($faviconUrl)) {
                    continue;
                }

                $cached = $this->downloadAndCache($faviconUrl, $cacheBase);
                if ($cached) {
                    return $cached;
                }
            }

            // The site's same-origin /favicon.ico is the standard implicit
            // favicon. It is the only non-header source permitted here.
            return $this->downloadDefault($websiteUrl, $cacheBase);
        } catch (\Throwable $exception) {
            report($exception);
            return $this->downloadDefault($websiteUrl, $cacheBase);
        }
    }

    public function getOfficialTitle(string $websiteUrl): ?string
    {
        $websiteUrl = $this->normalizeUrl($websiteUrl);
        if (!$websiteUrl || !$this->isSafePublicUrl($websiteUrl)) {
            return null;
        }

        try {
            $page = $this->requestFollowingSafeRedirects($websiteUrl, false);
            if (!$page || !$page->successful()) {
                return null;
            }

            $html = (string) $page->body();
            if ($html === '' || strlen($html) > self::MAX_HTML_BYTES) {
                return null;
            }

            libxml_use_internal_errors(true);
            $dom = new \DOMDocument();
            if (!@$dom->loadHTML($html)) {
                libxml_clear_errors();
                return null;
            }

            $title = $dom->getElementsByTagName('title')->item(0);
            $value = $title ? trim(html_entity_decode($title->textContent, ENT_QUOTES | ENT_HTML5, 'UTF-8')) : '';
            libxml_clear_errors();

            if ($value === '') {
                return null;
            }

            return mb_substr(preg_replace('/\s+/u', ' ', $value) ?: $value, 0, 180);
        } catch (\Throwable $exception) {
            report($exception);
            return null;
        }
    }

    public function isSafePublicUrl(string $url): bool
    {
        $url = trim($url);
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = strtolower((string) ($parts['host'] ?? ''));

        if (!in_array($scheme, ['http', 'https'], true) || $host === '') {
            return false;
        }

        if ($this->isBlockedHostname($host)) {
            return false;
        }

        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return $this->isPublicIp($host);
        }

        $records = @dns_get_record($host, DNS_A | DNS_AAAA);
        if (!$records) {
            return false;
        }

        foreach ($records as $record) {
            $ip = $record['ip'] ?? ($record['ipv6'] ?? null);
            if ($ip && !$this->isPublicIp($ip)) {
                return false;
            }
        }

        return true;
    }

    private function normalizeUrl(string $url): ?string
    {
        $url = trim($url);
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return null;
        }

        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = $parts['host'] ?? null;
        if (!in_array($scheme, ['http', 'https'], true) || !$host) {
            return null;
        }

        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $path = $parts['path'] ?? '/';
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';

        return $scheme . '://' . $host . $port . $path . $query;
    }

    private function isBlockedHostname(string $host): bool
    {
        return $host === 'localhost'
            || str_ends_with($host, '.localhost')
            || str_ends_with($host, '.local')
            || str_ends_with($host, '.internal')
            || $host === 'metadata.google.internal'
            || $host === 'host.docker.internal';
    }

    private function isPublicIp(string $ip): bool
    {
        return (bool) filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        );
    }

    private function extractFaviconCandidates(string $html): array
    {
        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();

        if (!@$dom->loadHTML($html)) {
            libxml_clear_errors();
            return [];
        }

        $candidates = [];

        foreach ($dom->getElementsByTagName('link') as $index => $link) {
            $rel = strtolower(trim($link->getAttribute('rel')));
            $href = trim($link->getAttribute('href'));
            $type = strtolower(trim($link->getAttribute('type')));
            $sizes = strtolower(trim($link->getAttribute('sizes')));

            if ($href === '' || $this->unsafeIconHref($href)) {
                continue;
            }

            $relTokens = preg_split('/\s+/', $rel, -1, PREG_SPLIT_NO_EMPTY) ?: [];
            $isIcon = in_array('icon', $relTokens, true);
            $isShortcutIcon = in_array('shortcut', $relTokens, true) && in_array('icon', $relTokens, true);

            // Strict mode: only real favicon declarations from the site's
            // header are eligible. Do not substitute Apple touch, mask,
            // OpenGraph, text initials, or generated icons.
            if (!$isIcon && !$isShortcutIcon) {
                continue;
            }

            // Lower score = closer to a normal browser tab/favicon asset.
            $score = $isIcon ? 10 : 20;

            if ($type === 'image/x-icon' || $type === 'image/vnd.microsoft.icon') {
                $score -= 3;
            } elseif ($type === 'image/png') {
                $score -= 2;
            } elseif ($type === 'image/svg+xml' || $type === 'image/svg') {
                $score -= 1;
            }

            if ($sizes !== '') {
                if (preg_match('/(^|\s)32x32(\s|$)/', $sizes)) {
                    $score -= 2;
                } elseif (preg_match('/(^|\s)16x16(\s|$)/', $sizes)) {
                    $score -= 1;
                }
            }

            $candidates[] = [
                'href' => $href,
                'score' => $score,
                'index' => $index,
            ];
        }

        libxml_clear_errors();

        usort($candidates, static function (array $a, array $b): int {
            return ($a['score'] <=> $b['score']) ?: ($a['index'] <=> $b['index']);
        });

        return $candidates;
    }

    private function extractFaviconUrl(string $html): ?string
    {
        $candidates = $this->extractFaviconCandidates($html);
        return $candidates[0]['href'] ?? null;
    }

    private function unsafeIconHref(string $href): bool
    {
        $lower = strtolower(trim($href));

        return str_starts_with($lower, 'data:')
            || str_starts_with($lower, 'javascript:')
            || str_starts_with($lower, 'mailto:')
            || str_starts_with($lower, 'tel:');
    }

    private function makeAbsoluteUrl(string $target, string $baseUrl): ?string
    {
        $target = trim(html_entity_decode($target, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($target === '' || $this->unsafeIconHref($target)) {
            return null;
        }

        if (filter_var($target, FILTER_VALIDATE_URL)) {
            return $this->normalizeUrl($target);
        }

        $base = parse_url($baseUrl);
        if (!$base || empty($base['host'])) {
            return null;
        }

        $scheme = $base['scheme'] ?? 'https';
        $host = $base['host'];
        $port = isset($base['port']) ? ':' . (int) $base['port'] : '';
        $origin = $scheme . '://' . $host . $port;

        if (str_starts_with($target, '//')) {
            return $this->normalizeUrl($scheme . ':' . $target);
        }

        if (str_starts_with($target, '/')) {
            return $this->normalizeUrl($origin . $target);
        }

        $path = $base['path'] ?? '/';
        $directory = rtrim(str_replace('\\', '/', dirname($path)), '/');
        if ($directory === '.' || $directory === '\\') {
            $directory = '';
        }

        return $this->normalizeUrl(
            $origin . ($directory ? $directory . '/' : '/') . ltrim($target, '/')
        );
    }

    /**
     * Fetch the site's implicit, same-origin favicon.
     *
     * This is not a visual fallback generated by BookMarks. The bytes must
     * come directly from the bookmarked host's own /favicon.ico endpoint.
     */
    private function downloadDefault(string $websiteUrl, string $cacheBase): ?string
    {
        $parts = parse_url($websiteUrl);
        if (!$parts || empty($parts['host'])) {
            return null;
        }

        $scheme = $parts['scheme'] ?? 'https';
        $host = $parts['host'];
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $faviconUrl = $scheme . '://' . $host . $port . '/favicon.ico';

        return $this->isSafePublicUrl($faviconUrl)
            ? $this->downloadAndCache($faviconUrl, $cacheBase)
            : null;
    }

    private function downloadAndCache(string $faviconUrl, string $cacheBase): ?string
    {
        $response = $this->requestFollowingSafeRedirects($faviconUrl, true);
        if (!$response || !$response->successful()) {
            return null;
        }

        $contentLength = (int) ($response->header('Content-Length') ?: 0);
        if ($contentLength > self::MAX_BYTES) {
            return null;
        }

        $contentType = strtolower(trim(explode(';', (string) $response->header('Content-Type', ''))[0]));
        $body = (string) $response->body();
        if ($body === '' || strlen($body) > self::MAX_BYTES) {
            return null;
        }

        if ($contentType === 'image/svg+xml' || $contentType === 'image/svg') {
            $body = $this->sanitizeSvg($body);
            if ($body === null) {
                return null;
            }
            $extension = 'svg';
        } else {
            $mime = class_exists(\finfo::class)
                ? (new \finfo(FILEINFO_MIME_TYPE))->buffer($body)
                : null;
            $effectiveMime = strtolower((string) ($mime ?: $contentType));

            $extension = match ($effectiveMime) {
                'image/png' => 'png',
                'image/jpeg', 'image/jpg' => 'jpg',
                'image/webp' => 'webp',
                'image/gif' => 'gif',
                'image/bmp', 'image/x-ms-bmp' => 'bmp',
                'image/x-icon', 'image/vnd.microsoft.icon', 'application/octet-stream' => 'ico',
                default => null,
            };

            if ($extension === null) {
                return null;
            }
        }

        $cacheKey = $cacheBase . '.' . $extension;

        try {
            Storage::disk('public')->put($cacheKey, $body);
        } catch (\Throwable $exception) {
            // Keep the official favicon nullable when the cache cannot be written.
            // The public-path fallback below is only used when the cached bytes can
            // be written directly under Laravel's public directory.
            report($exception);

            if (!$this->writePublicFallback($cacheKey, $body)) {
                return null;
            }
        }

        return $this->getCachedFaviconUrl(basename($cacheKey));
    }

    /**
     * Resolve a cached ERP favicon to a browser-safe URL.
     *
     * Production deployments normally expose storage/app/public through
     * public/storage (php artisan storage:link). If that public symlink is
     * unavailable or the web server does not expose it correctly, a direct
     * public/favicons copy is used as a server-side fallback.
     */
    public function getCachedFaviconUrl(string $filename): ?string
    {
        $filename = basename(trim($filename));

        if (!preg_match('/^bookmark_[a-f0-9]{40}\.(ico|png|jpg|jpeg|webp|svg|gif|bmp)$/i', $filename)) {
            return null;
        }

        $cacheKey = 'favicons/' . $filename;
        $disk = Storage::disk('public');
        $storagePath = null;

        if ($disk->exists($cacheKey)) {
            try {
                $storagePath = $disk->path($cacheKey);
            } catch (\Throwable $exception) {
                report($exception);
            }

            // Preferred production URL when `public/storage` is available.
            $storagePublicPath = public_path('storage/' . $cacheKey);
            if (is_file($storagePublicPath)) {
                return url('/storage/' . $cacheKey);
            }

            // Production fallback: expose the same cached bytes directly from
            // public/favicons when the storage symlink is missing/broken.
            $publicFallbackPath = public_path($cacheKey);
            if (!is_file($publicFallbackPath) && $storagePath && is_file($storagePath)) {
                $this->copyToPublicFallback($storagePath, $publicFallbackPath);
            }

            if (is_file($publicFallbackPath)) {
                return url('/' . $cacheKey);
            }

            // Last-resort compatibility with the existing Laravel route.
            return url('/favicon/' . $filename);
        }

        // If the storage disk no longer has the file, still support a previously
        // created direct public fallback without making the favicon non-null.
        $publicFallbackPath = public_path($cacheKey);
        if (is_file($publicFallbackPath)) {
            return url('/' . $cacheKey);
        }

        return null;
    }

    private function writePublicFallback(string $cacheKey, string $body): bool
    {
        if (!str_starts_with($cacheKey, 'favicons/')) {
            return false;
        }

        $path = public_path($cacheKey);
        $directory = dirname($path);

        if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
            return false;
        }

        return @file_put_contents($path, $body, LOCK_EX) !== false;
    }

    private function copyToPublicFallback(string $sourcePath, string $destinationPath): bool
    {
        $directory = dirname($destinationPath);

        if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
            return false;
        }

        return @copy($sourcePath, $destinationPath);
    }

    private function sanitizeSvg(string $svg): ?string
    {
        $svg = trim($svg);
        if ($svg === '' || strlen($svg) > self::MAX_BYTES) {
            return null;
        }

        $svg = preg_replace('/<\?xml[^>]*>/i', '', $svg) ?? $svg;
        $svg = preg_replace('/<!DOCTYPE[\s\S]*?>/i', '', $svg) ?? $svg;
$svg = preg_replace('/<script\b[\s\S]*?<\ /script>/i', '', $svg) ?? $svg;
    $svg = preg_replace('/<foreignObject\b[\s\S]*?<\ /foreignObject>/i', '', $svg) ?? $svg;
        $svg = preg_replace('/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $svg) ?? $svg;
        $svg = preg_replace('/(?:href|xlink:href)\s*=\s*("|\')\s*(?:javascript:|data:)/i', '$1#', $svg) ?? $svg;

        return preg_match('/<svg\b[^>]*>/i', $svg) ? $svg : null;
            }

            private function requestFollowingSafeRedirects(string $url, bool $image): ?Response
            {
            $current = $this->normalizeUrl($url);
            if (!$current || !$this->isSafePublicUrl($current)) {
            return null;
            }

            for ($attempt = 0; $attempt <= self::MAX_REDIRECTS; $attempt++) { $response=$this->
                httpClient($image)->send('GET', $current, [
                'allow_redirects' => false,
                ]);

                if ($response->successful()) {
                return $response;
                }

                $status = $response->status();
                if (!in_array($status, [301, 302, 303, 307, 308], true)) {
                return $response;
                }

                $location = trim((string) $response->header('Location'));
                if ($location === '') {
                return $response;
                }

                $next = $this->makeAbsoluteUrl($location, $current);
                if (!$next || !$this->isSafePublicUrl($next)) {
                return null;
                }

                $current = $next;
                }

                return null;
                }

                private function httpClient(bool $image): PendingRequest
                {
                return Http::timeout(8)
                ->connectTimeout(4)
                ->retry(1, 150)
                ->withHeaders([
                'User-Agent' => 'Mozilla/5.0 (compatible; EGC-BookMarks/1.0)',
                'Accept' => $image
                ? 'image/avif,image/webp,image/png,image/jpeg,image/gif,image/x-icon,image/svg+xml,*/*'
                : 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.1',
                ]);
                }
                }