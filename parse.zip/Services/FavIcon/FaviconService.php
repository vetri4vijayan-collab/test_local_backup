<?php

namespace App\Services\FavIcon;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

class FaviconService
{
    public function getFavicon(string $websiteUrl): ?string
    {
        $websiteUrl = trim($websiteUrl);

        if (!$this->isValidUrl($websiteUrl)) {
            return null;
        }

        $host = parse_url($websiteUrl, PHP_URL_HOST);

        if (!$host) {
            return null;
        }

        $host = strtolower($host);

        // Cache per domain
        $cacheKey = 'favicons/' . sha1($host) . '.ico';

        if (Storage::disk('public')->exists($cacheKey)) {
            return url('/favicon/' . basename($cacheKey));
        }

        try {
            /*
             * First request the website itself.
             */
            $response = Http::timeout(5)
                ->connectTimeout(3)
                ->withHeaders([
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                    'Accept' => 'text/html,application/xhtml+xml',
                ])
                ->get($websiteUrl);

            if (!$response->successful()) {
                return $this->tryDefaultFavicon(
                    $websiteUrl,
                    $host,
                    $cacheKey
                );
            }

            $html = $response->body();

            /*
             * Find rel="icon", rel="shortcut icon",
             * apple-touch-icon, etc.
             *
             * Attribute order does not matter.
             */
            $faviconUrl = $this->extractFaviconUrl($html);

            /*
             * If <link rel="icon"> was not found,
             * try /favicon.ico.
             */
            if (!$faviconUrl) {
                return $this->tryDefaultFavicon(
                    $websiteUrl,
                    $host,
                    $cacheKey
                );
            }

            /*
             * Convert relative URL to absolute URL correctly.
             */
            $faviconUrl = $this->makeAbsoluteUrl(
                $faviconUrl,
                $websiteUrl
            );

            if (!$faviconUrl) {
                return null;
            }

            return $this->downloadAndCache(
                $faviconUrl,
                $cacheKey
            );

        } catch (\Throwable $e) {
            report($e);

            return null;
        }
    }

    /**
     * Validate URL.
     */
    private function isValidUrl(string $url): bool
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $scheme = strtolower(
            parse_url($url, PHP_URL_SCHEME) ?? ''
        );

        return in_array($scheme, ['http', 'https'], true);
    }

    /**
     * Extract favicon from HTML.
     */
    private function extractFaviconUrl(string $html): ?string
    {
        libxml_use_internal_errors(true);

        $dom = new \DOMDocument();

        if (!@$dom->loadHTML($html)) {
            return null;
        }

        $links = $dom->getElementsByTagName('link');

        foreach ($links as $link) {
            $rel = strtolower(
                trim($link->getAttribute('rel'))
            );

            if (
                str_contains($rel, 'icon') ||
                str_contains($rel, 'apple-touch-icon')
            ) {
                $href = trim(
                    $link->getAttribute('href')
                );

                if ($href !== '') {
                    return $href;
                }
            }
        }

        return null;
    }

    /**
     * Convert relative favicon URL to absolute URL.
     */
    private function makeAbsoluteUrl(
        string $faviconUrl,
        string $websiteUrl
    ): ?string {
        $faviconUrl = trim($faviconUrl);

        if ($faviconUrl === '') {
            return null;
        }

        /*
         * Already absolute.
         */
        if (filter_var($faviconUrl, FILTER_VALIDATE_URL)) {
            return $faviconUrl;
        }

        $parts = parse_url($websiteUrl);

        if (!$parts || empty($parts['host'])) {
            return null;
        }

        $scheme = $parts['scheme'] ?? 'https';
        $host = $parts['host'];
        $port = isset($parts['port'])
            ? ':' . $parts['port']
            : '';

        $base = $scheme . '://' . $host . $port;

        /*
         * Protocol-relative:
         * //cdn.example.com/favicon.ico
         */
        if (str_starts_with($faviconUrl, '//')) {
            return $scheme . ':' . $faviconUrl;
        }

        /*
         * Root-relative:
         * /assets/favicon.png
         */
        if (str_starts_with($faviconUrl, '/')) {
            return $base . $faviconUrl;
        }

        /*
         * Relative:
         * images/favicon.png
         */
        $path = $parts['path'] ?? '/';

        $directory = rtrim(
            dirname($path),
            '/'
        );

        if ($directory === '.' || $directory === '') {
            $directory = '';
        }

        return $base
            . $directory
            . '/'
            . ltrim($faviconUrl, '/');
    }

    /**
     * Try the standard /favicon.ico.
     */
    private function tryDefaultFavicon(
        string $websiteUrl,
        string $host,
        string $cacheKey
    ): ?string {
        $parts = parse_url($websiteUrl);

        if (!$parts) {
            return null;
        }

        $scheme = $parts['scheme'] ?? 'https';

        $faviconUrl = $scheme
            . '://'
            . $host
            . '/favicon.ico';

        return $this->downloadAndCache(
            $faviconUrl,
            $cacheKey
        );
    }

    /**
     * Download favicon and cache it.
     */
    private function downloadAndCache(
        string $faviconUrl,
        string $cacheKey
    ): ?string {
        try {
            $response = Http::timeout(5)
                ->connectTimeout(3)
                ->withHeaders([
                    'User-Agent' => 'Mozilla/5.0',
                    'Accept' => 'image/avif,image/webp,image/png,image/jpeg,image/x-icon,*/*',
                ])
                ->get($faviconUrl);

            if (!$response->successful()) {
                return null;
            }

            $contentType = strtolower(
                $response->header('Content-Type', '')
            );

            /*
             * Do not save an HTML error page as favicon.
             */
            if (
                !str_contains($contentType, 'image/')
                && !str_contains($contentType, 'icon')
            ) {
                return null;
            }

            $body = $response->body();

            if ($body === '') {
                return null;
            }

            Storage::disk('public')->put(
                $cacheKey,
                $body
            );

            return url('/favicon/' . basename($cacheKey));

        } catch (\Throwable $e) {
            report($e);

            return null;
        }
    }
}