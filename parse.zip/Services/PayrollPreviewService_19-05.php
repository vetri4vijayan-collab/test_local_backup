<?php

namespace App\Services;

use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;
use App\Helpers\PayrollFormulaHelper;

class PayrollPreviewService
{

    public function calculateLivePayroll($staff, $month, $year)
    {

        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();

        if (
            (int)$month == (int)date('m') &&
            (int)$year == (int)date('Y')
        ) {
            $endDate = Carbon::today();
        }


        $attendance = DB::table('egc_staff_attendance')
            ->where('staff_id', $staff->sno)
            ->whereBetween('date', [$startDate, $endDate])
            ->where('status', 0)
            ->get();

        $holidayDates = $this->getHolidayDates(
            $startDate,
            $endDate
        );

        $presentDays     = 0;
        $absentDays      = 0;
        $leaveDays       = 0;
        $permissionDays  = 0;
        $ondutyDays      = 0;

        foreach ($attendance as $att) {

            if ($holidayDates->contains($att->date)) {
                continue;
            }


            if ($att->attendance == 'P') {
                $presentDays += 1;
            }


            if ($att->attendance == 'OD') {
                $ondutyDays += 1;
                $presentDays += 1;
            }

            if ($att->attendance == 'PR') {
                $permissionDays += 1;
                $presentDays += 1;
            }


            if ($att->attendance == 'A') {
                $absentDays += 1;
            }

            /*
            |--------------------------------------------------------------------------
            | LEAVE
            |--------------------------------------------------------------------------
            */

            if ($att->attendance == 'L') {

                if ($att->leave_type == 'full') {

                    $leaveDays += 1;
                    $absentDays += 1;
                }

                if (
                    in_array(
                        $att->leave_type,
                        ['first_half', 'second_half']
                    )
                ) {

                    $leaveDays += 0.5;
                    $absentDays += 0.5;
                }
            }
        }


        $lateCount = $this->getLateCount(
            $staff->sno,
            $month,
            $year
        );


        $weekOffCount = $this->getWeekOffCount(
            $month,
            $year
        );



        $holidayCount = $holidayDates->count();


        $earningDays =
            $presentDays +
            $holidayCount +
            $weekOffCount;


        $basicSalary = (float)($staff->basic_salary ?? 0);

        $perDaySalary = (float)($staff->per_day_salary ?? 0);

        $joiningDate = Carbon::parse(
            $staff->date_of_joining
        );

        $isJoiningMonth =
            $joiningDate->month == $month &&
            $joiningDate->year == $year;

        if ($isJoiningMonth) {

            $basicEarned =
                $earningDays * $perDaySalary;
        } else {

            $basicEarned = $basicSalary;
        }


        $salaryComponents = DB::table(
            'egc_payroll_employee_structure_details as esd'
        )
            ->join(
                'egc_payroll_employee_structures as ps',
                'ps.sno',
                '=',
                'esd.payroll_employee_structure_sno'
            )
            ->join(
                'egc_payroll_components as pc',
                'pc.sno',
                '=',
                'esd.payroll_component_sno'
            )
            ->where('ps.employee_sno', $staff->sno)
            ->where('ps.is_current', 1)
            ->where('ps.status', 0)
            ->where('esd.status', 0)
            ->orderBy('esd.display_order')
            ->select(
                'pc.sno',
                'pc.component_name',
                'pc.category as component_type',
                'pc.calculation_type',
                'pc.component_code',

                'esd.percentage_value',
                'esd.fixed_amount',
                'esd.calculated_amount',

                'esd.calculation_type as structure_calculation_type'
            )
            ->get();



        $grossSalary      = 0;
        $totalEarnings    = 0;
        $totalDeductions  = 0;

        $componentBreakdown = [];






        $componentVariables = [

            'basic' => $basicEarned,
            'basic_salary' => $basicEarned,
            'gross_salary' => $grossSalary,
        ];



        foreach ($salaryComponents as $component) {

            $amount = 0;

            $calculationType =
                $component->structure_calculation_type
                ?? $component->calculation_type;

            /*
    |--------------------------------------------------------------------------
    | PERCENTAGE
    |--------------------------------------------------------------------------
    */

            if ($calculationType == 'percentage') {

                $percentage =
                    (float)$component->percentage_value;

                $amount =
                    ($basicEarned * $percentage) / 100;
            }

            /*
    |--------------------------------------------------------------------------
    | FIXED
    |--------------------------------------------------------------------------
    */

            if ($calculationType == 'fixed') {

                $amount =
                    (float)$component->fixed_amount;
            }

            /*
    |--------------------------------------------------------------------------
    | FORMULA
    |--------------------------------------------------------------------------
    */

            if ($calculationType == 'formula') {

                $formula =
                    $component->formula_expression
                    ?? '';

                $amount = PayrollFormulaHelper::evaluate(
                    $formula,
                    $componentVariables
                );
            }

            /*
    |--------------------------------------------------------------------------
    | MANUAL INPUT
    |--------------------------------------------------------------------------
    */

            // if ($calculationType == 'manual_input') {

            //     $amount =
            //         (float)$component->calculated_amount;
            // }

             if ($calculationType == 'manual_input') {



                if (
                    strtoupper($component->component_code)
                    == 'VARIABLE'
                ) {

                    $currentMonth =
                        Carbon::create($year, $month, 1)
                        ->format('Y-m-01');


                    $variableAmount =
                        DB::table('egc_payroll_variable_amounts')

                        ->where('employee_sno', $staff->sno)

                        ->where('status', 0)

                        ->where('is_expired', 0)

                        ->whereDate(
                            'start_month',
                            '<=',
                            $currentMonth
                        )

                        ->whereDate(
                            'end_month',
                            '>=',
                            $currentMonth
                        )

                        ->orderByDesc('sno')

                        ->first();



                    if ($variableAmount) {

                        $amount =
                            (float)$variableAmount->amount;
                    } else {

                        $amount = 0;
                    }
                } else {

                    $amount =
                        (float)$component->calculated_amount;
                }
            }

            /*
    |--------------------------------------------------------------------------
    | ROUND
    |--------------------------------------------------------------------------
    */

            $amount = round($amount, 2);

            /*
    |--------------------------------------------------------------------------
    | EARNINGS
    |--------------------------------------------------------------------------
    */

            if ($component->component_type == 'earning') {

                $grossSalary += $amount;

                $totalEarnings += $amount;
            }

            /*
    |--------------------------------------------------------------------------
    | DEDUCTIONS
    |--------------------------------------------------------------------------
    */

            if ($component->component_type == 'deduction') {

                $totalDeductions += $amount;
            }

            /*
    |--------------------------------------------------------------------------
    | FORMULA VARIABLES
    |--------------------------------------------------------------------------
    */

            $componentCode =
                strtolower($component->component_code);

            $componentVariables[$componentCode] = $amount;

            /*
    |--------------------------------------------------------------------------
    | BREAKDOWN
    |--------------------------------------------------------------------------
    */

            $componentBreakdown[] = [
                'sno' =>
                $component->sno,
                'component' =>
                $component->component_name,

                'code' =>
                $component->component_code,

                'type' =>
                $component->component_type,

                'calculation_type' =>
                $calculationType,

                'percentage' =>
                $component->percentage_value,

                'amount' =>
                round($amount, 2)
            ];
        }


        $ruleData = $this->applyRules(

            $staff,
            $month,
            $year,
            $grossSalary,
            $basicEarned,
            $absentDays,
            $lateCount
        );

        $totalDeductions +=
            $ruleData['total_deductions'];


        foreach ($ruleData['breakdown'] as $ruleBreakdown) {

            $componentBreakdown[] = [

                'component' => $ruleBreakdown['rule_name'],

                'type' => 'deduction',

                'amount' => round(
                    $ruleBreakdown['amount'],
                    2
                )
            ];
        }



        $netSalary =
            $grossSalary - $totalDeductions;


        return [

            'staff_id' => $staff->sno,

            'staff_name' => $staff->staff_name,

            'basic_salary' => round($basicSalary, 2),

            'gross_salary' => round($grossSalary, 2),

            'earnings' => round($totalEarnings, 2),

            'deductions' => round($totalDeductions, 2),

            'net_salary' => round($netSalary, 2),

            'lop_days' => round(
                $ruleData['lop_days'],
                2
            ),

            'lop_amount' => round(
                $ruleData['lop_amount'],
                2
            ),

            'present_days' => round($presentDays, 2),

            'absent_days' => round($absentDays, 2),

            'leave_days' => round($leaveDays, 2),

            'permission_days' => round($permissionDays, 2),

            'onduty_days' => round($ondutyDays, 2),

            'late_count' => round($lateCount, 2),

            'weekoff_days' => round($weekOffCount, 2),

            'holiday_days' => round($holidayCount, 2),

            'earning_days' => round($earningDays, 2),

            'components' => $componentBreakdown,

            'rules' => $ruleData['breakdown'],
        ];
    }


    private function applyRules(
        $staff,
        $month,
        $year,
        $grossSalary,
        $basicSalary,
        $absentDays,
        $lateCount
    ) {

        $rules = DB::table('egc_payroll_rules')
            ->where('is_active', 1)
            ->where('status', 0)
            ->where(function ($q) use ($year, $month) {

                $currentDate =
                    Carbon::create($year, $month, 1)
                    ->format('Y-m-d');

                $q->whereNull('effective_from')
                    ->orWhere('effective_from', '<=', $currentDate);
            })
            ->where(function ($q) use ($year, $month) {

                $currentDate =
                    Carbon::create($year, $month, 1)
                    ->format('Y-m-d');

                $q->whereNull('effective_to')
                    ->orWhere('effective_to', '>=', $currentDate);
            })
            ->orderBy('priority_order')
            ->get();

        $totalDeductions = 0;

        $lopDays = 0;

        $lopAmount = 0;

        $breakdown = [];



        $variables = [

            'basic' => $basicSalary,

            'basic_salary' => $basicSalary,

            'gross_salary' => $grossSalary,

            'late_count' => $lateCount,

            'lop_days' => 0,

            'per_day_salary' =>
            (float)$staff->per_day_salary,

            'month' => (int)$month,
        ];

        foreach ($rules as $rule) {


            if ($rule->rule_category == 'lop') {

                $allowedLeave =
                    $staff->casual_leave_count_per_month ?? 0;

                $lopDays =
                    max(0, $absentDays - $allowedLeave);

                $variables['lop_days'] = $lopDays;
            }


            $amount =
                PayrollFormulaHelper::evaluate(
                    $rule->rule_expression,
                    $variables
                );

            if ($amount <= 0) {
                continue;
            }


            if ($rule->rule_category == 'lop') {
                $lopAmount = $amount;
            }


            $totalDeductions += $amount;


            $breakdown[] = [

                'rule_name' =>
                $rule->rule_name,

                'rule_code' =>
                $rule->rule_code,

                'rule_category' =>
                $rule->rule_category,

                'amount' =>
                round($amount, 2)
            ];
        }

        return [

            'total_deductions' =>
            round($totalDeductions, 2),

            'lop_days' =>
            round($lopDays, 2),

            'lop_amount' =>
            round($lopAmount, 2),

            'breakdown' => $breakdown
        ];
    }



    private function getHolidayDates(
        $startDate,
        $endDate
    ) {

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use (
                $startDate,
                $endDate
            ) {

                $q->whereBetween(
                    'hol_date',
                    [$startDate, $endDate]
                )
                    ->orWhereBetween(
                        'hol_end_date',
                        [$startDate, $endDate]
                    );
            })
            ->get();

        $holidayDates = collect();

        foreach ($holidays as $holiday) {

            $start =
                Carbon::parse($holiday->hol_date);

            $end =
                $holiday->hol_end_date
                ? Carbon::parse(
                    $holiday->hol_end_date
                )
                : $start;

            foreach (
                CarbonPeriod::create($start, $end)
                as $d
            ) {

                $holidayDates->push(
                    $d->format('Y-m-d')
                );
            }
        }

        return $holidayDates->unique();
    }

    private function getLateCount(
        $staffId,
        $month,
        $year
    ) {

        $lateCount = DB::table('egc_staff_attendance as att')
            ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')

            ->join('egc_shift_time_log as stl', function ($join) {
                $join->on('stl.staff_id', '=', 'att.staff_id');
            })

            ->join('egc_shift_day_times as sd', function ($join) {
                $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                    ->where('sd.status', 0);
            })
            ->where('att.staff_id', $staffId)
            // 👉 Month filter
            ->whereMonth('att.date', $month)
            ->whereYear('att.date', $year)
            ->where('att.status', 0)
            ->whereNotNull('att.in_time')
            // ✅ JOINING DATE CHECK
            ->whereRaw("DATE(att.date) >= DATE(s.date_of_joining)")
            // ✅ SHIFT DATE RANGE CHECK
            ->whereRaw("
                        DATE(att.date) BETWEEN stl.start_date 
                        AND IFNULL(stl.end_date, '9999-12-31')
                    ")
            // ✅ DAY MATCH (Mon, Tue...)
            ->whereRaw("
                        LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))
                    ")
            // ✅ LATE CHECK
            // ->whereRaw("
            //     TIME(att.in_time) > TIME(sd.time_from)
            // ")
            ->whereRaw("TIME(att.in_time) > ADDTIME(sd.time_from, '00:16:00')")
            ->count();

        return $lateCount;
    }



    private function getWeekOffCount(
        $month,
        $year
    ) {

        $startDate =
            Carbon::create($year, $month, 1);

        $endDate =
            Carbon::create($year, $month, 1)
            ->endOfMonth();

        if (
            (int)$month == (int)date('m') &&
            (int)$year == (int)date('Y')
        ) {

            $endDate = Carbon::today();
        }

        $count = 0;

        foreach (
            CarbonPeriod::create(
                $startDate,
                $endDate
            ) as $date
        ) {

            if ($date->isSunday()) {
                $count++;
            }
        }

        return $count;
    }
}
