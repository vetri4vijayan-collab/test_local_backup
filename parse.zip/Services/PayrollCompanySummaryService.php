<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PayrollCompanySummaryService
{
    public function summary($month, $year, $type = 'company')
    {
        $payrollService = app(PayrollPreviewService::class);

        /*
        |--------------------------------------------------------------------------
        | Group By
        |--------------------------------------------------------------------------
        */

        if ($type == 'salary_company') {

            $companies = DB::table('egc_company')
                ->join(
                    'egc_staff_salary_accounts',
                    'egc_staff_salary_accounts.salary_company_id',
                    '=',
                    'egc_company.sno'
                )
                ->where('egc_company.status', 0)
                ->select(
                    'egc_company.sno',
                    'egc_company.company_name',
                    'egc_company.company_favicon',
                    'egc_company.company_base_color',
                )
                ->distinct()
                ->get();

        } else {

            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();

            $companies = DB::table('egc_company')
                ->join(
                    'egc_staff',
                    'egc_staff.company_id',
                    '=',
                    'egc_company.sno'
                )
                ->where('egc_company.status', 0)
                ->select(
                    'egc_company.sno',
                    'egc_company.company_name',
                    'egc_company.company_favicon',
                    'egc_company.company_base_color',
                )
                ->distinct()
                ->get();

            $mainCompanyStaffExists = DB::table('egc_staff')
                ->where('company_id', 0)
                ->where('status', '!=', 2)
                ->exists();

            if ($mainCompanyStaffExists) {

                $companies->prepend((object)[
                    'sno' => 0,
                    'company_name' => $general_setting->title,
                    'company_favicon' => $general_setting->fav_icon,
                    'company_base_color' => '#ab2b22'
                ]);

            }
        }

        $response = [];

        foreach ($companies as $company) {

         $endOfMonth = Carbon::create($year,$month,1)->endOfMonth();
         $payrollDate = Carbon::create($year, $month, 1);
        $monthStart = $payrollDate->copy()->startOfMonth()->toDateString();
        $endOfMonth = $payrollDate->copy()->endOfMonth()->toDateString();
        $payrollMonth = $payrollDate->format('Y-m');

        $staffQuery =  DB::table('egc_staff_salary_accounts')
            ->join('egc_staff as s','s.sno','=','egc_staff_salary_accounts.staff_id')
            ->leftJoin('egc_company as salary_company', 'egc_staff_salary_accounts.salary_company_id', '=', 'salary_company.sno')
            ->leftJoin('egc_company', 's.company_id', '=', 'egc_company.sno')
            ->leftJoin('egc_entity', 's.entity_id', '=', 'egc_entity.sno')
            ->leftJoin('egc_department', 's.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 's.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 's.job_role_id', '=', 'egc_job_role.sno')
            ->where('s.status','!=', 2)
            ->where('egc_staff_salary_accounts.status',0)
            ->where(function ($q) use ( $month, $year, $payrollMonth, $monthStart,$endOfMonth) {
                /* ACTIVE STAFF*/
                $q->whereIn('s.status', [0, 1]);
                /* NOTICE PERIOD STAFF */
                $q->orWhere(function ($notice) use ($payrollMonth) {
                    $notice->where('s.status', 4)
                        ->whereNotNull('s.notice_end_date')
                        ->whereRaw("
                            ? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                            AND DATE_FORMAT(s.notice_end_date, '%Y-%m')
                        ", [$payrollMonth]);
                });

                /* EXITED STAFF */
                $q->orWhere(function ($exit) use ( $payrollMonth,$monthStart, $endOfMonth) {

                    $exit->whereIn('s.status', [5, 6, 7])
                        ->whereNotNull('s.staff_last_date')
                        ->whereNotIn('s.sno', [211, 212, 94, 77])
                        ->whereRaw("
                            ? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                            AND DATE_FORMAT(s.staff_last_date, '%Y-%m')
                        ", [$payrollMonth])
                        ->whereRaw("
                            DATEDIFF(
                                LEAST(s.staff_last_date, ?),
                                GREATEST(s.date_of_joining, ?)
                            ) + 1 > ?
                        ", [
                            $endOfMonth,
                            $monthStart,
                            4
                        ]);
                });

                /* SPECIAL EXIT STAFF */
                $q->orWhere(function ($special) use ($payrollMonth ) {

                    $special->whereIn('s.sno', [211, 212, 94, 77])
                        ->whereIn('s.status', [5, 6, 7])
                        ->whereNotNull('s.staff_last_date')
                        ->whereRaw("
                            ? BETWEEN DATE_FORMAT(
                                s.date_of_joining,
                                '%Y-%m'
                            )
                            AND DATE_FORMAT(
                                DATE_SUB(
                                    s.staff_last_date,
                                    INTERVAL 1 MONTH
                                ),
                                '%Y-%m'
                            )
                        ", [$payrollMonth])
                        ->whereRaw("
                            DATEDIFF(
                                s.staff_last_date,
                                s.date_of_joining
                            ) > ?
                        ", [4]);
                });
            })
            ->whereDate('s.date_of_joining', '<=', $endOfMonth)
            ->where('s.sno', '>', 0)
            ->select(
                's.*',
                's.sno',
                's.staff_name',
                's.staff_id as staff_code',
                'egc_staff_salary_accounts.sno as salary_account_id',
                'egc_staff_salary_accounts.gross_salary as basic_salary',
                'egc_staff_salary_accounts.per_day_salary',
                's.company_id',
                's.entity_id',
                's.nick_name',
                's.mobile_no',
                's.staff_image',
                's.company_type',
                's.gender',
                's.salary_type',
                's.salary_date',
                's.staff_last_date',
                's.notice_start_date',
                's.notice_end_date',
                's.date_of_joining',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'salary_company.company_base_color as salary_company_base_color',
                'salary_company.company_name as salary_company_name',
                'egc_company.company_base_color',
                'egc_company.company_name',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name'
            );
            /*
            |--------------------------------------------------------------------------
            | Company Filter
            |--------------------------------------------------------------------------
            */

            if ($type == 'salary_company') {

                $staffQuery->where(
                    'egc_staff_salary_accounts.salary_company_id',
                    $company->sno
                );

            } else {

                if ($company->sno == 0) {

                    $staffQuery->where('s.company_id', 0);

                } else {

                    $staffQuery->where(
                        's.company_id',
                        $company->sno
                    );

                }
            }

          
            $staffs = $staffQuery
                ->orderBy('s.date_of_joining', 'desc')
                    ->get();

            $gross = 0;
            $fixed_salary = 0;
            $deduction = 0;
            $net = 0;

            foreach ($staffs as $staff) {

                $salary = $payrollService->calculateLivePayroll(
                    $staff,
                    $month,
                    $year,
                    0
                );

                $fixed_salary += $salary['basic_salary'];
                $gross += $salary['gross_salary'];
                $deduction += $salary['deductions'];
                $net += $salary['net_salary'];
            }

            $response[] = [
                'company_id' => $company->sno,
                'company_name' => $company->company_name,
                'company_base_color' => $company->company_base_color ?? null,
                'company_favicon' => $company->company_favicon,
                'staff' => $staffs->count(),
                'fixed_salary' => round($fixed_salary),
                'gross' => round($gross),
                'deduction' => round($deduction),
                'net' => round($net),
            ];
        }

        return $response;
    }
}