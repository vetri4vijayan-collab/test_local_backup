<?php

namespace App\Services\CloudStorage;

use Aws\S3\S3Client;
use RuntimeException;

/**
 * One shared S3-compatible client factory for all ERP features.
 * Feature enablement/authorization belongs to CloudStorageManager or the owning module;
 * this class only validates credentials and creates the Wasabi client.
 */
class WasabiS3ClientFactory
{
    private ?S3Client $client = null;

    public function client(): S3Client
    {
        if ($this->client instanceof S3Client) {
            return $this->client;
        }

        if (!class_exists(S3Client::class)) {
            throw new RuntimeException('AWS SDK is missing. Run composer require aws/aws-sdk-php from the ERP project root.');
        }

        $endpoint = rtrim(trim((string) config('wasabi.endpoint')), '/');
        $key = trim((string) config('wasabi.access_key'));
        $secret = trim((string) config('wasabi.secret_key'));
        $bucket = trim((string) config('wasabi.bucket'));
        if ($endpoint === '' || $key === '' || $secret === '' || $bucket === '') {
            throw new RuntimeException('Wasabi is not fully configured. Verify the endpoint, access key, secret key and bucket.');
        }
        if (!str_starts_with(strtolower($endpoint), 'https://')) {
            throw new RuntimeException('WASABI_ENDPOINT must use HTTPS.');
        }

        $this->client = new S3Client([
            'version' => 'latest',
            'region' => (string) config('wasabi.region', 'us-east-2'),
            'endpoint' => $endpoint,
            'use_path_style_endpoint' => true,
            'signature_version' => 'v4',
            'credentials' => ['key' => $key, 'secret' => $secret],
            'http' => [
                'connect_timeout' => max(1, (int) config('wasabi.connect_timeout_seconds', 5)),
                'timeout' => max(5, (int) config('wasabi.request_timeout_seconds', 60)),
            ],
        ]);

        return $this->client;
    }
}
