<?php

namespace App\Services\CloudStorage;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * Reusable cloud object storage for ERP modules.
 *
 * A module supplies a feature key (for example applicant.resume, staff.document or invoice.pdf)
 * and its own authorization checks. This manager validates the feature policy, creates private
 * Wasabi objects, verifies uploads by size + SHA-256 metadata, records object metadata, issues
 * short-lived signed URLs, and audits storage operations. It intentionally does not expose a
 * generic HTTP upload/delete endpoint; controllers must authorize access to their own records.
 */
class CloudStorageManager
{
    private WasabiS3ClientFactory $clientFactory;

    public function __construct(WasabiS3ClientFactory $clientFactory)
    {
        $this->clientFactory = $clientFactory;
    }

    /** Resolve a feature's active settings; the DB registry overrides config defaults. */
    public function featureSettings(string $featureKey): array
    {
        $featureKey = $this->normalizeFeatureKey($featureKey);

        if (DB::getSchemaBuilder()->hasTable('egc_storage_feature_settings')) {
            $row = DB::table('egc_storage_feature_settings')->where('feature_key', $featureKey)->first();
            if ($row) {
                return [
                    'feature_key' => $featureKey,
                    'enabled' => (bool) $row->enabled,
                    'driver' => strtolower((string) $row->driver),
                    'max_file_size_bytes' => max(1, (int) ($row->max_file_size_bytes ?: config('erp_storage.max_file_size_bytes', 52428800))),
                    'allowed_extensions' => (string) ($row->allowed_extensions ?? ''),
                    'allowed_mime_types' => (string) ($row->allowed_mime_types ?? ''),
                    'private_access' => (bool) $row->private_access,
                    'signed_url_expiry_seconds' => max(60, min(900, (int) ($row->signed_url_expiry_seconds ?: config('erp_storage.signed_url_expiry_seconds', 300)))),
                ];
            }
        }

        $features = (array) config('erp_storage.features', []);
        if (!isset($features[$featureKey]) || !is_array($features[$featureKey])) {
            throw new RuntimeException('Storage feature is not registered: ' . $featureKey . '. Add a feature setting before using cloud storage.');
        }

        $settings = $features[$featureKey];
        return [
            'feature_key' => $featureKey,
            'enabled' => (bool) ($settings['enabled'] ?? false),
            'driver' => strtolower((string) ($settings['driver'] ?? 'wasabi')),
            'max_file_size_bytes' => max(1, (int) ($settings['max_file_size_bytes'] ?? config('erp_storage.max_file_size_bytes', 52428800))),
            'allowed_extensions' => (string) ($settings['allowed_extensions'] ?? ''),
            'allowed_mime_types' => (string) ($settings['allowed_mime_types'] ?? ''),
            'private_access' => (bool) ($settings['private_access'] ?? config('erp_storage.private_by_default', true)),
            'signed_url_expiry_seconds' => max(60, min(900, (int) ($settings['signed_url_expiry_seconds'] ?? config('erp_storage.signed_url_expiry_seconds', 300)))),
        ];
    }

    /**
     * Register/update feature policy. Call only from trusted admin/service code; do not expose
     * this method directly through an unauthenticated API. The DB registry is the control plane.
     */
    public function configureFeature(string $featureKey, array $settings): array
    {
        $featureKey = $this->normalizeFeatureKey($featureKey);
        if (!DB::getSchemaBuilder()->hasTable('egc_storage_feature_settings')) {
            throw new RuntimeException('Common storage SQL is not installed (missing egc_storage_feature_settings).');
        }

        $driver = strtolower((string) ($settings['driver'] ?? 'wasabi'));
        if ($driver !== 'wasabi') {
            throw new RuntimeException('This release implements the wasabi driver. Existing ERP/local files remain unchanged when a feature is disabled.');
        }

        $extensions = $this->normalizeCsv($settings['allowed_extensions'] ?? '');
        $mimeTypes = $this->normalizeCsv($settings['allowed_mime_types'] ?? '');
        $row = [
            'feature_key' => $featureKey,
            'enabled' => !empty($settings['enabled']) ? 1 : 0,
            'driver' => $driver,
            'max_file_size_bytes' => max(1, (int) ($settings['max_file_size_bytes'] ?? config('erp_storage.max_file_size_bytes', 52428800))),
            'allowed_extensions' => implode(',', $extensions),
            'allowed_mime_types' => implode(',', $mimeTypes),
            'private_access' => 1,
            'signed_url_expiry_seconds' => max(60, min(900, (int) ($settings['signed_url_expiry_seconds'] ?? config('erp_storage.signed_url_expiry_seconds', 300)))),
            'updated_at' => now(),
        ];

        $exists = DB::table('egc_storage_feature_settings')->where('feature_key', $featureKey)->exists();
        if ($exists) {
            DB::table('egc_storage_feature_settings')->where('feature_key', $featureKey)->update($row);
        } else {
            $row['created_at'] = now();
            DB::table('egc_storage_feature_settings')->insert($row);
        }

        return $this->featureSettings($featureKey);
    }

    public function isFeatureEnabled(string $featureKey): bool
    {
        try {
            $settings = $this->featureSettings($featureKey);
            return $settings['enabled'] && $settings['driver'] === 'wasabi' && (bool) config('wasabi.enabled', true);
        } catch (Throwable $e) {
            return false;
        }
    }

    /**
     * Store an existing local file for any registered ERP feature.
     * ownerType/ownerId identify the ERP record but do not grant access to it.
     */
    public function storePath(
        string $featureKey,
        string $ownerType,
        string $ownerId,
        string $sourcePath,
        string $originalName,
        ?int $actorId = null,
        string $sourceProvider = 'upload',
        ?string $sourceReference = null
    ): array {
        $settings = $this->featureSettings($featureKey);
        if ($settings['feature_key'] === 'applicant.resume') {
            throw new RuntimeException('Applicant Resume is in compatibility mode. Use WasabiResumeStorageService so the shared registry and legacy applicant pointer are updated together.');
        }
        if (!$settings['enabled'] || $settings['driver'] !== 'wasabi' || !(bool) config('wasabi.enabled', true)) {
            throw new RuntimeException('Wasabi storage is not enabled for the feature: ' . $settings['feature_key']);
        }
        if (!$settings['private_access']) {
            throw new RuntimeException('This ERP storage manager supports private Wasabi objects only; public files require a separately reviewed policy.');
        }
        if (!DB::getSchemaBuilder()->hasTable('egc_storage_objects') || !DB::getSchemaBuilder()->hasTable('egc_storage_audit')) {
            throw new RuntimeException('Common storage SQL is not installed. Apply database/sql/erp_common_storage.sql.');
        }

        $ownerType = $this->normalizeOwnerType($ownerType);
        $ownerId = trim($ownerId);
        if ($ownerId === '' || mb_strlen($ownerId) > 191 || preg_match('/[^A-Za-z0-9._:-]/', $ownerId)) {
            throw new RuntimeException('ownerId must be a non-empty ERP identifier containing only letters, numbers, dot, underscore, colon or hyphen.');
        }
        if (!is_file($sourcePath) || !is_readable($sourcePath)) {
            throw new RuntimeException('Source file does not exist or is not readable.');
        }

        $size = filesize($sourcePath);
        if ($size === false || $size < 1) {
            throw new RuntimeException('The source file is empty or its size could not be read.');
        }
        if ($size > $settings['max_file_size_bytes']) {
            throw new RuntimeException('File exceeds the configured feature size limit (' . $settings['max_file_size_bytes'] . ' bytes).');
        }

        $safeName = $this->safeOriginalName($originalName);
        $extension = strtolower((string) pathinfo($safeName, PATHINFO_EXTENSION));
        $extension = preg_replace('/[^a-z0-9]/', '', $extension) ?: 'bin';
        $allowedExtensions = $this->normalizeCsv($settings['allowed_extensions']);
        if ($allowedExtensions && !in_array($extension, $allowedExtensions, true)) {
            throw new RuntimeException('File extension .' . $extension . ' is not permitted for feature ' . $settings['feature_key'] . '.');
        }

        $mimeType = $this->detectMimeType($sourcePath);
        $allowedMimes = $this->normalizeCsv($settings['allowed_mime_types']);
        if ($allowedMimes) {
            $mimeAllowed = false;
            foreach ($allowedMimes as $allowedMime) {
                if ($allowedMime === '*' || $allowedMime === strtolower($mimeType)) {
                    $mimeAllowed = true;
                    break;
                }
                if (str_ends_with($allowedMime, '/*') && str_starts_with(strtolower($mimeType), substr($allowedMime, 0, -1))) {
                    $mimeAllowed = true;
                    break;
                }
            }
            if (!$mimeAllowed) {
                throw new RuntimeException('Detected MIME type is not permitted for feature ' . $settings['feature_key'] . ': ' . $mimeType);
            }
        }

        $sha256 = hash_file('sha256', $sourcePath);
        if (!is_string($sha256) || strlen($sha256) !== 64) {
            throw new RuntimeException('Unable to calculate source SHA-256 checksum.');
        }

        $bucket = trim((string) config('wasabi.bucket'));
        $basePrefix = trim((string) config('wasabi.prefix', config('erp_storage.object_prefix', 'erp')), '/');
        $featurePath = str_replace('.', '/', $settings['feature_key']);
        $safeOwner = preg_replace('/[^A-Za-z0-9_-]/', '_', $ownerType) ?: 'record';
        $safeOwnerId = preg_replace('/[^A-Za-z0-9_-]/', '_', $ownerId) ?: hash('sha256', $ownerId);
        $objectKey = ($basePrefix !== '' ? $basePrefix . '/' : '')
            . 'features/' . $featurePath . '/' . $safeOwner . '/' . $safeOwnerId . '/' . (string) Str::uuid() . '.' . $extension;

        $stream = fopen($sourcePath, 'rb');
        if ($stream === false) {
            throw new RuntimeException('Could not open the source file for cloud upload.');
        }

        try {
            $this->clientFactory->client()->putObject([
                'Bucket' => $bucket,
                'Key' => $objectKey,
                'Body' => $stream,
                'ContentType' => $mimeType,
                'CacheControl' => 'private, no-store, max-age=0',
                'Metadata' => [
                    'feature-key' => str_replace('.', '-', $settings['feature_key']),
                    'owner-type' => $safeOwner,
                    'owner-id-hash' => substr(hash('sha256', $ownerId), 0, 32),
                    'sha256' => $sha256,
                    'source-provider' => preg_replace('/[^a-z0-9_-]/i', '', $sourceProvider) ?: 'upload',
                ],
            ]);
        } catch (Throwable $e) {
            $this->audit(null, $settings['feature_key'], $ownerType, $ownerId, 'upload', null, $sha256, 'failed', $e->getMessage(), $actorId);
            Log::error('ERP cloud storage upload failed.', ['feature_key' => $settings['feature_key'], 'owner_type' => $ownerType, 'message' => $e->getMessage()]);
            throw new RuntimeException('Cloud upload failed. Existing ERP/local storage was not changed.', 0, $e);
        } finally {
            if (is_resource($stream)) fclose($stream);
        }

        try {
            $head = $this->clientFactory->client()->headObject(['Bucket' => $bucket, 'Key' => $objectKey]);
            $storedSize = (int) ($head['ContentLength'] ?? -1);
            $storedHash = (string) ($head['Metadata']['sha256'] ?? '');
            if ($storedSize !== (int) $size || !hash_equals($sha256, $storedHash)) {
                throw new RuntimeException('Cloud object verification failed (size/checksum mismatch).');
            }
        } catch (Throwable $e) {
            try { $this->clientFactory->client()->deleteObject(['Bucket' => $bucket, 'Key' => $objectKey]); } catch (Throwable $cleanupError) {
                Log::warning('Could not clean up unverified cloud object.', ['object_key' => $objectKey, 'message' => $cleanupError->getMessage()]);
            }
            throw new RuntimeException('Upload completed but object verification failed; no metadata pointer was activated.', 0, $e);
        }

        try {
            $id = DB::transaction(function () use ($settings, $ownerType, $ownerId, $bucket, $objectKey, $safeName, $mimeType, $size, $sha256, $sourceProvider, $sourceReference, $actorId) {
                $id = DB::table('egc_storage_objects')->insertGetId([
                    'feature_key' => $settings['feature_key'],
                    'owner_type' => $ownerType,
                    'owner_id' => $ownerId,
                    'driver' => 'wasabi',
                    'bucket_name' => $bucket,
                    'object_key' => $objectKey,
                    'disk_path' => null,
                    'original_name' => $safeName,
                    'mime_type' => $mimeType,
                    'file_size' => (int) $size,
                    'sha256' => $sha256,
                    'source_provider' => substr(preg_replace('/[^a-z0-9_-]/i', '', $sourceProvider) ?: 'upload', 0, 32),
                    'source_reference_hash' => $sourceReference ? hash('sha256', $sourceReference) : null,
                    'storage_status' => 'active',
                    'private_access' => $settings['private_access'] ? 1 : 0,
                    'deleted_at' => null,
                    'created_by' => $actorId,
                    'updated_by' => $actorId,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
                $this->audit((int) $id, $settings['feature_key'], $ownerType, $ownerId, 'upload', $objectKey, $sha256, 'success', 'Object uploaded, verified and registered.', $actorId);
                return (int) $id;
            });
        } catch (Throwable $e) {
            try { $this->clientFactory->client()->deleteObject(['Bucket' => $bucket, 'Key' => $objectKey]); } catch (Throwable $cleanupError) {
                Log::warning('Could not clean up cloud object after metadata registration failure.', ['object_key' => $objectKey, 'message' => $cleanupError->getMessage()]);
            }
            throw $e;
        }

        return $this->getObject($id);
    }

    /**
     * Register a Wasabi object uploaded and verified by a trusted compatibility adapter.
     * This lets the Applicant adapter keep its legacy table/API while its object also appears
     * in the shared ERP registry. The caller must already have verified the remote object.
     */
    public function registerExistingObject(
        string $featureKey,
        string $ownerType,
        string $ownerId,
        string $bucket,
        string $objectKey,
        string $originalName,
        string $mimeType,
        int $fileSize,
        string $sha256,
        ?int $actorId = null,
        string $sourceProvider = 'upload',
        ?string $sourceReference = null
    ): int {
        $settings = $this->featureSettings($featureKey);
        if (!$settings['enabled'] || $settings['driver'] !== 'wasabi' || !(bool) config('wasabi.enabled', true)) {
            throw new RuntimeException('Wasabi storage is not enabled for feature ' . $settings['feature_key'] . '.');
        }
        if (!$settings['private_access']) {
            throw new RuntimeException('Verified object registration requires private object policy.');
        }
        if (!DB::getSchemaBuilder()->hasTable('egc_storage_objects') || !DB::getSchemaBuilder()->hasTable('egc_storage_audit')) {
            throw new RuntimeException('Common storage SQL is not installed. Apply database/sql/erp_common_storage.sql.');
        }

        $ownerType = $this->normalizeOwnerType($ownerType);
        $ownerId = trim($ownerId);
        if ($ownerId === '' || mb_strlen($ownerId) > 191 || preg_match('/[^A-Za-z0-9._:-]/', $ownerId)) {
            throw new RuntimeException('Invalid owner id for common storage registration.');
        }
        if ($bucket === '' || $objectKey === '' || $fileSize < 1 || !preg_match('/^[a-f0-9]{64}$/i', $sha256)) {
            throw new RuntimeException('Verified object metadata is incomplete.');
        }

        return (int) DB::transaction(function () use ($settings, $ownerType, $ownerId, $bucket, $objectKey, $originalName, $mimeType, $fileSize, $sha256, $actorId, $sourceProvider, $sourceReference) {
            DB::table('egc_storage_objects')
                ->where('feature_key', $settings['feature_key'])
                ->where('owner_type', $ownerType)
                ->where('owner_id', $ownerId)
                ->where('storage_status', 'active')
                ->update(['storage_status' => 'superseded', 'updated_by' => $actorId, 'updated_at' => now()]);

            $id = DB::table('egc_storage_objects')->insertGetId([
                'feature_key' => $settings['feature_key'],
                'owner_type' => $ownerType,
                'owner_id' => $ownerId,
                'driver' => 'wasabi',
                'bucket_name' => $bucket,
                'object_key' => $objectKey,
                'disk_path' => null,
                'original_name' => $this->safeOriginalName($originalName),
                'mime_type' => $mimeType ?: 'application/octet-stream',
                'file_size' => $fileSize,
                'sha256' => strtolower($sha256),
                'source_provider' => substr(preg_replace('/[^a-z0-9_-]/i', '', $sourceProvider) ?: 'upload', 0, 32),
                'source_reference_hash' => $sourceReference ? hash('sha256', $sourceReference) : null,
                'storage_status' => 'active',
                'private_access' => 1,
                'deleted_at' => null,
                'created_by' => $actorId,
                'updated_by' => $actorId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $this->audit((int) $id, $settings['feature_key'], $ownerType, $ownerId, 'register_compat_object', $objectKey, $sha256, 'success', 'Verified compatibility object registered in shared ERP storage.', $actorId);
            return (int) $id;
        });
    }

    public function getObject(int $objectId): array
    {
        $row = DB::table('egc_storage_objects')->where('sno', $objectId)->first();
        if (!$row) throw new RuntimeException('Stored object was not found.');
        return (array) $row;
    }

    public function findLatest(string $featureKey, string $ownerType, string $ownerId): ?array
    {
        $featureKey = $this->normalizeFeatureKey($featureKey);
        $ownerType = $this->normalizeOwnerType($ownerType);
        $row = DB::table('egc_storage_objects')
            ->where('feature_key', $featureKey)
            ->where('owner_type', $ownerType)
            ->where('owner_id', $ownerId)
            ->where('storage_status', 'active')
            ->orderByDesc('sno')
            ->first();
        return $row ? (array) $row : null;
    }

    /** Create a short-lived URL. Call only after the owning module authorizes this object. */
    public function temporaryUrl(int $objectId, string $disposition = 'inline', ?int $expirySeconds = null): string
    {
        if (!(bool) config('wasabi.enabled', true)) throw new RuntimeException('Wasabi provider access is disabled.');
        $row = (object) $this->getObject($objectId);
        if (($row->storage_status ?? '') !== 'active') throw new RuntimeException('Stored object is not active.');
        if (strtolower((string) ($row->driver ?? '')) !== 'wasabi') throw new RuntimeException('Unsupported storage driver for this object.');
        if (!in_array($disposition, ['inline', 'attachment'], true)) throw new RuntimeException('Invalid content disposition.');

        $settings = $this->featureSettings((string) $row->feature_key);
        if (!$settings['private_access']) throw new RuntimeException('Only private feature storage is supported by this service.');
        $expiry = $expirySeconds ?? $settings['signed_url_expiry_seconds'];
        $expiry = max(60, min(900, (int) $expiry));
        $name = $this->safeOriginalName((string) ($row->original_name ?? 'file'));
        $extension = strtolower((string) pathinfo($name, PATHINFO_EXTENSION));
        if (in_array($extension, ['html', 'htm', 'svg', 'xhtml', 'xml', 'js'], true)) $disposition = 'attachment';
        $asciiName = preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?: 'file';
        $contentDisposition = $disposition . '; filename="' . $asciiName . '"; filename*=UTF-8\'\'' . rawurlencode($name);

        $command = $this->clientFactory->client()->getCommand('GetObject', [
            'Bucket' => (string) $row->bucket_name,
            'Key' => (string) $row->object_key,
            'ResponseContentType' => (string) ($row->mime_type ?: 'application/octet-stream'),
            'ResponseContentDisposition' => $contentDisposition,
            'ResponseCacheControl' => 'private, no-store, max-age=0',
        ]);
        return (string) $this->clientFactory->client()->createPresignedRequest($command, '+' . $expiry . ' seconds')->getUri();
    }

    /** Download and verify a private Wasabi object to a protected temporary path. */
    public function downloadToPath(int $objectId, string $destinationPath): void
    {
        if (!(bool) config('wasabi.enabled', true)) throw new RuntimeException('Wasabi provider access is disabled.');
        $row = (object) $this->getObject($objectId);
        if (($row->storage_status ?? '') !== 'active' || strtolower((string) ($row->driver ?? '')) !== 'wasabi') {
            throw new RuntimeException('Stored object is not active or does not use Wasabi.');
        }
        if (!(bool) $row->private_access) throw new RuntimeException('Only private feature storage is supported by this service.');
        $directory = dirname($destinationPath);
        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
            throw new RuntimeException('Unable to create protected temporary directory.');
        }
        $result = $this->clientFactory->client()->getObject(['Bucket' => (string) $row->bucket_name, 'Key' => (string) $row->object_key]);
        $body = $result['Body'] ?? null;
        $out = fopen($destinationPath, 'wb');
        if ($out === false) throw new RuntimeException('Unable to create destination file.');
        try {
            if (is_resource($body)) {
                stream_copy_to_stream($body, $out);
            } elseif (is_object($body) && method_exists($body, 'eof') && method_exists($body, 'read')) {
                while (!$body->eof()) {
                    $chunk = $body->read(1024 * 1024);
                    if ($chunk === '') break;
                    fwrite($out, $chunk);
                }
            } else {
                throw new RuntimeException('Unexpected response stream from Wasabi.');
            }
        } finally {
            fclose($out);
        }
        $downloadedSize = is_file($destinationPath) ? filesize($destinationPath) : false;
        $downloadedHash = is_file($destinationPath) ? hash_file('sha256', $destinationPath) : false;
        if ($downloadedSize !== (int) $row->file_size || !is_string($downloadedHash) || !hash_equals((string) $row->sha256, $downloadedHash)) {
            @unlink($destinationPath);
            throw new RuntimeException('Downloaded object failed size or SHA-256 verification.');
        }
    }

    /** Delete cloud object with an intermediate state; failures restore the active metadata row. */
    public function delete(int $objectId, ?int $actorId = null): bool
    {
        if (!(bool) config('wasabi.enabled', true)) throw new RuntimeException('Wasabi provider access is disabled.');
        $row = DB::table('egc_storage_objects')->where('sno', $objectId)->first();
        if ($row && (string) $row->feature_key === 'applicant.resume') {
            throw new RuntimeException('Applicant Resume must be deleted through WasabiResumeStorageService to keep compatibility metadata synchronized.');
        }
        if (!$row || ($row->storage_status ?? '') !== 'active' || strtolower((string) ($row->driver ?? '')) !== 'wasabi') return false;

        $claimed = DB::table('egc_storage_objects')->where('sno', $objectId)->where('storage_status', 'active')->update([
            'storage_status' => 'deleting', 'updated_by' => $actorId, 'updated_at' => now(),
        ]);
        if ($claimed < 1) return false;

        $cloudObjectDeleted = (bool) config('erp_storage.delete_cloud_object_on_delete', true);
        try {
            if ($cloudObjectDeleted) {
                $this->clientFactory->client()->deleteObject(['Bucket' => (string) $row->bucket_name, 'Key' => (string) $row->object_key]);
            }
        } catch (Throwable $e) {
            DB::table('egc_storage_objects')->where('sno', $objectId)->where('storage_status', 'deleting')->update([
                'storage_status' => 'active', 'updated_by' => $actorId, 'updated_at' => now(),
            ]);
            $this->audit($objectId, (string) $row->feature_key, (string) $row->owner_type, (string) $row->owner_id, 'delete', (string) $row->object_key, (string) $row->sha256, 'failed', 'Cloud deletion failed; active pointer restored.', $actorId);
            throw new RuntimeException('Cloud object could not be deleted; metadata was restored to active.', 0, $e);
        }

        $updated = DB::table('egc_storage_objects')->where('sno', $objectId)->where('storage_status', 'deleting')->update([
            'storage_status' => 'deleted', 'deleted_at' => now(), 'updated_by' => $actorId, 'updated_at' => now(),
        ]);
        $auditMessage = $cloudObjectDeleted
            ? ($updated ? 'Cloud object deleted and metadata deactivated.' : 'Cloud object deleted, but metadata changed concurrently.')
            : ($updated ? 'Metadata deactivated; cloud object retained by configured policy.' : 'Metadata changed concurrently; cloud object retained by configured policy.');
        $this->audit($objectId, (string) $row->feature_key, (string) $row->owner_type, (string) $row->owner_id, 'delete', (string) $row->object_key, (string) $row->sha256, $updated ? 'success' : 'warning', $auditMessage, $actorId);
        return $updated > 0;
    }

    public function safeOriginalName(string $name): string
    {
        $name = basename(str_replace('\\', '/', trim($name)));
        $name = preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?? 'file';
        $name = trim($name, " .\t\n\r\0\x0B");
        if ($name === '' || $name === '.' || $name === '..') $name = 'file';
        return mb_substr($name, 0, 240);
    }

    /** Add an audit entry for a trusted compatibility adapter that performs the cloud operation. */
    public function recordExternalAudit(?int $objectId, string $featureKey, string $ownerType, string $ownerId, string $action, ?string $objectKey, ?string $sha256, string $outcome, string $message, ?int $actorId = null): void
    {
        try {
            $this->audit($objectId, $this->normalizeFeatureKey($featureKey), $this->normalizeOwnerType($ownerType), $ownerId, $action, $objectKey, $sha256, $outcome, $message, $actorId);
        } catch (Throwable $e) {
            Log::warning('Could not record external storage audit event.', ['feature_key' => $featureKey, 'message' => $e->getMessage()]);
        }
    }

    private function audit(?int $objectId, string $featureKey, string $ownerType, string $ownerId, string $action, ?string $objectKey, ?string $sha256, string $outcome, string $message, ?int $actorId): void
    {
        try {
            if (!DB::getSchemaBuilder()->hasTable('egc_storage_audit')) return;
            DB::table('egc_storage_audit')->insert([
                'object_sno' => $objectId,
                'feature_key' => mb_substr($featureKey, 0, 120),
                'owner_type' => mb_substr($ownerType, 0, 100),
                'owner_id_hash' => hash('sha256', $ownerId),
                'action_name' => mb_substr($action, 0, 40),
                'object_key' => $objectKey,
                'sha256' => $sha256,
                'outcome' => mb_substr($outcome, 0, 20),
                'message' => mb_substr($message, 0, 4000),
                'actor_id' => $actorId,
                'created_at' => now(),
            ]);
        } catch (Throwable $e) {
            Log::warning('ERP storage audit insert failed.', ['feature_key' => $featureKey, 'message' => $e->getMessage()]);
        }
    }

    private function normalizeFeatureKey(string $key): string
    {
        $key = strtolower(trim($key));
        if (!preg_match('/^[a-z0-9][a-z0-9._-]{1,119}$/', $key)) {
            throw new RuntimeException('Invalid storage feature key. Use a stable key such as invoice.pdf or staff.document.');
        }
        return $key;
    }

    private function normalizeOwnerType(string $ownerType): string
    {
        $ownerType = strtolower(trim($ownerType));
        if (!preg_match('/^[a-z][a-z0-9._-]{0,99}$/', $ownerType)) {
            throw new RuntimeException('Invalid storage owner type.');
        }
        return $ownerType;
    }

    private function normalizeCsv($value): array
    {
        $items = is_array($value) ? $value : explode(',', (string) $value);
        $result = [];
        foreach ($items as $item) {
            $item = strtolower(trim((string) $item));
            if ($item !== '' && preg_match('/^[a-z0-9.*+_\/-]+$/', $item)) $result[] = $item;
        }
        return array_values(array_unique($result));
    }

    private function detectMimeType(string $path): string
    {
        $mime = function_exists('finfo_open') ? (new \finfo(FILEINFO_MIME_TYPE))->file($path) : false;
        if (!is_string($mime) || $mime === '') $mime = function_exists('mime_content_type') ? mime_content_type($path) : false;
        return is_string($mime) && $mime !== '' ? strtolower($mime) : 'application/octet-stream';
    }
}
