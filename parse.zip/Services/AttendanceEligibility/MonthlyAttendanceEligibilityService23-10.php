<?php

namespace App\Services\AttendanceEligibility;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;

/**
 * Shared monthly attendance evaluator used by the Master Attendance and Early Bird reports.
 *
 * Eligibility is intentionally evaluated against the shift log effective on each date instead
 * of assuming the currently assigned shift applied to historical months.
 */
class MonthlyAttendanceEligibilityService
{
    public function generate(
        string $reportType,
        array $filters = [],
        bool $includeDetails = true,
        bool $paginate = true,
        bool $eligibleOnly = false,
        bool $useConfirmedStatus = true
    ): array {
        if (!in_array($reportType, ['master', 'early_bird'], true)) {
            throw new InvalidArgumentException('Unknown attendance report type.');
        }

        // The date picker submits short-month/year values such as Oct-2026 (M-Y).
        // Keep validation and parsing on the same format to prevent false 422 responses.
        $month = trim((string) ($filters['month'] ?? now()->format('M-Y')));
        try {
            $monthStart = Carbon::createFromFormat('!M-Y', $month);
        } catch (\Throwable $exception) {
            throw new InvalidArgumentException('Select a valid report month.');
        }
        if (!$monthStart || $monthStart->format('M-Y') !== $month) {
            throw new InvalidArgumentException('Select a valid report month.');
        }
        $monthStart->startOfMonth();
        if ($monthStart->greaterThan(now()->startOfMonth())) {
            throw new InvalidArgumentException('Future months cannot be selected.');
        }

        $startDate = $monthStart->copy();
        $endDate = $monthStart->copy()->endOfMonth();
        // Notice/exit staff should appear only in months strictly before the month
        // containing their end date. Example: last date 15-Oct-2026 appears through
        // Sep-2026, but is excluded from Oct-2026 onward.
        $nextMonthStart = $monthStart->copy()->addMonth()->startOfMonth()->toDateString();
        if ($monthStart->isSameMonth(now())) {
            $endDate = now()->startOfDay();
        }

        $scope = (string) ($filters['scope'] ?? 'all');
        $search = trim((string) ($filters['search'] ?? ''));
        $rowFilter = $eligibleOnly ? 'eligible' : (string) ($filters['row_filter'] ?? 'all');
        $perPage = (int) ($filters['per_page'] ?? 25);
        if (!in_array($perPage, [10, 25, 50, 100], true)) {
            $perPage = 25;
        }
        $page = max(1, (int) ($filters['page'] ?? 1));

        $staffQuery = DB::table('egc_staff as s')
            ->leftJoin('egc_company as c', 's.company_id', '=', 'c.sno')
            ->leftJoin('egc_entity as e', 's.entity_id', '=', 'e.sno')
            ->leftJoin('egc_department as d', 's.department_id', '=', 'd.sno')
            ->leftJoin('egc_division as dv', 's.division_id', '=', 'dv.sno')
            ->leftJoin('egc_job_role as jr', 's.job_role_id', '=', 'jr.sno')
            ->where('s.sno', '>', 0)
            ->where(function ($query) use ($endDate) {
                $query->whereNull('s.date_of_joining')
                    ->orWhereDate('s.date_of_joining', '<=', $endDate->toDateString());
            })
            ->where(function ($query) use ($startDate, $nextMonthStart) {
                $query->where('s.status', 0)
                    // The standard staff list also includes inactive status 1. Keep these staff
                    // when they overlapped the requested month, using last-working date if set.
                    ->orWhere(function ($inactive) use ($startDate) {
                        $inactive->where('s.status', 1)
                            ->where(function ($date) use ($startDate) {
                                $date->whereNull('s.staff_last_date')
                                    ->orWhereDate('s.staff_last_date', '>=', $startDate->toDateString());
                            });
                    })
                    // Status 4 = Notice: use notice_end_date only. Include only report
                    // months strictly before the month containing the notice end date.
                    // Missing notice_end_date means we cannot establish historical inclusion.
                    ->orWhere(function ($notice) use ($nextMonthStart) {
                        $notice->where('s.status', 4)
                            ->whereNotNull('s.notice_end_date')
                            ->whereRaw("COALESCE(STR_TO_DATE(s.notice_end_date, '%Y-%m-%d'), STR_TO_DATE(s.notice_end_date, '%d-%m-%Y'), STR_TO_DATE(s.notice_end_date, '%d-%m-%y')) >= ?", [$nextMonthStart]);
                    })
                    // Statuses 5/6/7 = Exited: use staff_last_date only. If last date is
                    // 15-Oct-2026, include through Sep-2026 and exclude Oct-2026 onward.
                    // Missing staff_last_date means we cannot establish historical inclusion.
                    ->orWhere(function ($exited) use ($nextMonthStart) {
                        $exited->whereIn('s.status', [5, 6, 7])
                            ->whereNotNull('s.staff_last_date')
                            ->whereRaw("COALESCE(STR_TO_DATE(s.staff_last_date, '%Y-%m-%d'), STR_TO_DATE(s.staff_last_date, '%d-%m-%Y'), STR_TO_DATE(s.staff_last_date, '%d-%m-%y')) >= ?", [$nextMonthStart]);
                    });
            });

        if ($scope === 'egc') {
            $staffQuery->where('s.company_type', 1);
        } elseif (ctype_digit($scope) && (int) $scope > 0) {
            $staffQuery->where('s.company_type', 2)->where('s.entity_id', (int) $scope);
        }

        if ($search !== '') {
            $staffQuery->where(function ($query) use ($search) {
                $query->where('s.staff_name', 'like', '%' . $search . '%')
                    ->orWhere('s.nick_name', 'like', '%' . $search . '%')
                    ->orWhere('s.staff_id', 'like', '%' . $search . '%')
                    ->orWhere('s.mobile_no', 'like', '%' . $search . '%');
            });
        }

        $staff = $staffQuery->select([
            's.sno as staff_pk',
            's.staff_id as employee_id',
            's.staff_name',
            's.nick_name',
            's.gender',
            's.staff_image',
            's.company_type',
            's.company_id',
            's.entity_id',
            's.department_id',
            's.date_of_joining',
            's.staff_last_date',
            's.notice_end_date',
            's.status as staff_status',
            'c.company_name',
            'c.company_base_color',
            'e.entity_base_color',
            'e.entity_name',
            'e.entity_short_name',
            'd.department_name',
            'dv.division_name',
            'jr.job_position_name as job_role_name',
        ])->orderBy('s.staff_name')->get();

        $staffIds = $staff->pluck('staff_pk')->map(function ($id) {
            return (int) $id;
        })->all();

        $employeeIds = $staff->pluck('employee_id')->filter(function ($id) {
            return $id !== null && $id !== '';
        })->unique()->values()->all();

        $context = $this->loadContext($staffIds, $employeeIds, $startDate, $endDate);
        $staffById = [];
        $summaryRows = [];
        $confirmationsByStaffId = [];

        // A confirmed monthly result is the HR-reviewed snapshot for that staff/month.
        // Keep this optional so existing deployments continue working before the new log tables are installed.
        $confirmationTable = $reportType === 'early_bird'
            ? 'egc_staff_early_bird_log'
            : 'egc_master_attendance_log';
        if ($useConfirmedStatus && !empty($staffIds) && Schema::hasTable($confirmationTable)) {
            $confirmationColumns = [
                'staff_id', 'eligibility_status', 'scheduled_days', 'attended_days',
                'leave_days', 'permission_days', 'absent_days', 'missing_days',
                'shift_log_gap_days', 'attendance_percent', 'reason',
                'confirmed_by', 'confirmed_at',
            ];
            // These columns were added by the production-safe patch upgrade. Keep list rendering
            // backward-compatible if a deployment has not yet run the matching SQL update.
            if (Schema::hasColumn($confirmationTable, 'decision_mode')) {
                $confirmationColumns[] = 'decision_mode';
            }
            if (Schema::hasColumn($confirmationTable, 'calculated_eligibility_status')) {
                $confirmationColumns[] = 'calculated_eligibility_status';
            }
            if ($reportType === 'early_bird') {
                array_push($confirmationColumns, 'early_days', 'late_days', 'missing_in_time_days', 'early_percent');
                if (Schema::hasColumn($confirmationTable, 'not_early_days')) {
                    $confirmationColumns[] = 'not_early_days';
                }
            }

            $confirmations = DB::table($confirmationTable)
                ->whereDate('report_month', $monthStart->toDateString())
                ->whereIn('staff_id', $staffIds)
                ->get($confirmationColumns);

            foreach ($confirmations as $confirmation) {
                $confirmationsByStaffId[(int) $confirmation->staff_id] = $confirmation;
            }
        }

        foreach ($staff as $member) {
            $staffId = (int) $member->staff_pk;
            $staffById[$staffId] = $member;
            $row = $this->evaluateStaff($member, $context, $reportType, false);
            if (isset($confirmationsByStaffId[$staffId])) {
                $row = $this->applyConfirmedSnapshot($row, $confirmationsByStaffId[$staffId], $reportType);
            }
            $summaryRows[] = $row;
        }

        // Eligibility-first ordering is applied before pagination, so eligible staff remain on top
        // across all pages instead of only within a single fetched page.
        usort($summaryRows, function (array $left, array $right) {
            if ($left['eligible'] !== $right['eligible']) {
                return $left['eligible'] ? -1 : 1;
            }

            return strcasecmp($left['staff_name'], $right['staff_name']);
        });

        $summary = [
            'total_staff' => count($summaryRows),
            'eligible' => 0,
            'not_eligible' => 0,
            'scheduled_workdays' => 0,
            'leave_days' => 0,
            'permission_days' => 0,
            'absent_days' => 0,
            'missing_attendance_days' => 0,
            'shift_log_gap_days' => 0,
            'early_days' => 0,
            'not_early_days' => 0,
            'late_days' => 0,
            'missing_in_time_days' => 0,
        ];

        foreach ($summaryRows as $row) {
            $summary[$row['eligible'] ? 'eligible' : 'not_eligible']++;
            $summary['scheduled_workdays'] += $row['scheduled_days'];
            $summary['leave_days'] += $row['leave_days'];
            $summary['permission_days'] += $row['permission_days'];
            $summary['absent_days'] += $row['absent_days'];
            $summary['missing_attendance_days'] += $row['missing_days'];
            $summary['shift_log_gap_days'] += $row['shift_log_gap_days'];
            $summary['early_days'] += $row['early_days'];
            $summary['not_early_days'] += $row['not_early_days'];
            $summary['late_days'] += $row['late_days'];
            $summary['missing_in_time_days'] += $row['missing_in_time_days'];
        }

        $filteredRows = array_values(array_filter($summaryRows, function (array $row) use ($rowFilter) {
            if ($rowFilter === 'eligible') {
                return $row['eligible'];
            }
            if ($rowFilter === 'not_eligible') {
                return !$row['eligible'];
            }
            return true;
        }));

        $total = count($filteredRows);
        $lastPage = max(1, (int) ceil($total / $perPage));
        if ($page > $lastPage) {
            $page = $lastPage;
        }

        if ($paginate) {
            $offset = ($page - 1) * $perPage;
            $pageRows = array_slice($filteredRows, $offset, $perPage);
        } else {
            $offset = 0;
            $pageRows = $filteredRows;
        }

        if ($includeDetails) {
            foreach ($pageRows as $index => $row) {
                $staffId = (int) $row['staff_pk'];
                if (isset($staffById[$staffId])) {
                    $detailRow = $this->evaluateStaff($staffById[$staffId], $context, $reportType, true);
                    if ($useConfirmedStatus && isset($confirmationsByStaffId[$staffId])) {
                        $detailRow = $this->applyConfirmedSnapshot($detailRow, $confirmationsByStaffId[$staffId], $reportType);
                    }
                    $pageRows[$index] = $detailRow;
                }
            }
        }

        $rangeStart = $total === 0 ? 0 : $offset + 1;
        $rangeEnd = $total === 0 ? 0 : min($offset + count($pageRows), $total);

        return [
            'rows' => array_values($pageRows),
            'summary' => $summary,
            'pagination' => [
                'current_page' => $page,
                'last_page' => $lastPage,
                'per_page' => $perPage,
                'total' => $total,
                'from' => $rangeStart,
                'to' => $rangeEnd,
            ],
            'period' => [
                'month' => $month,
                'start_date' => $startDate->toDateString(),
                'start_date_label' => $startDate->format('d M Y'),
                'end_date' => $endDate->toDateString(),
                'end_date_label' => $endDate->format('d M Y'),
                'is_current_month' => $monthStart->isSameMonth(now()),
            ],
        ];
    }

    private function loadContext(array $staffIds, array $employeeIds, Carbon $startDate, Carbon $endDate): array
    {
        $start = $startDate->toDateString();
        $end = $endDate->toDateString();

        $holidayDates = [];
        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->whereDate('hol_date', '<=', $end)
            ->where(function ($query) use ($start) {
                $query->whereNull('hol_end_date')
                    ->orWhereDate('hol_end_date', '>=', $start);
            })
            ->get(['hol_date', 'hol_end_date']);

        foreach ($holidays as $holiday) {
            if (empty($holiday->hol_date)) {
                continue;
            }
            $from = Carbon::parse($holiday->hol_date)->startOfDay();
            $to = Carbon::parse($holiday->hol_end_date ?: $holiday->hol_date)->startOfDay();
            if ($from->lt($startDate)) {
                $from = $startDate->copy();
            }
            if ($to->gt($endDate)) {
                $to = $endDate->copy();
            }
            if ($to->lt($from)) {
                continue;
            }
            for ($date = $from->copy(); $date->lte($to); $date->addDay()) {
                $holidayDates[$date->toDateString()] = true;
            }
        }

        $shiftLogsByStaff = [];
        $shiftIds = [];
        if (!empty($staffIds)) {
            $shiftLogs = DB::table('egc_shift_time_log as stl')
                ->leftJoin('egc_shift_time as st', 'st.sno', '=', 'stl.change_shift_id')
                ->whereIn('stl.staff_id', $staffIds)
                ->whereDate('stl.start_date', '<=', $end)
                ->where(function ($query) use ($start) {
                    $query->whereNull('stl.end_date')
                        ->orWhereDate('stl.end_date', '>=', $start);
                })
                ->orderByDesc('stl.start_date')
                ->orderByDesc('stl.sno')
                ->get([
                    'stl.sno as shift_log_id',
                    'stl.staff_id',
                    'stl.start_date',
                    'stl.end_date',
                    'stl.change_shift_id as shift_id',
                    'st.shift_name',
                ]);

            foreach ($shiftLogs as $log) {
                $staffId = (int) $log->staff_id;
                if (!isset($shiftLogsByStaff[$staffId])) {
                    $shiftLogsByStaff[$staffId] = [];
                }
                $shiftLogsByStaff[$staffId][] = $log;
                if ((int) $log->shift_id > 0) {
                    $shiftIds[] = (int) $log->shift_id;
                }
            }
        }

        $shiftDaysByShift = [];
        $shiftIds = array_values(array_unique($shiftIds));
        if (!empty($shiftIds)) {
            $shiftDays = DB::table('egc_shift_day_times')
                ->whereIn('shift_id', $shiftIds)
                ->where('status', 0)
                ->orderBy('sno')
                ->get(['shift_id', 'day_name', 'time_from', 'time_to']);

            foreach ($shiftDays as $shiftDay) {
                $shiftId = (int) $shiftDay->shift_id;
                $dayName = $this->normaliseDayName((string) $shiftDay->day_name);
                if ($dayName === '') {
                    continue;
                }
                if (!isset($shiftDaysByShift[$shiftId])) {
                    $shiftDaysByShift[$shiftId] = [];
                }
                // If old data has duplicate weekday rows, the latest returned active config wins.
                $shiftDaysByShift[$shiftId][$dayName] = $shiftDay;
            }
        }

        $attendanceByStaffDate = [];
        if (!empty($staffIds)) {
            $records = DB::table('egc_staff_attendance')
                ->whereIn('staff_id', $staffIds)
                ->where('date', '>=', $start)
                ->where('date', '<', Carbon::parse($end)->addDay()->toDateString())
                ->where('status', 0)
                ->orderBy('sno')
                ->get([
                    'sno', 'staff_id', 'date', 'attendance', 'in_time', 'out_time',
                    'time_start', 'time_end', 'leave_type', 'reason', 'status',
                ]);

            foreach ($records as $record) {
                $dateKey = substr((string) $record->date, 0, 10);
                $attendanceByStaffDate[(int) $record->staff_id][$dateKey] = $record;
            }
        }

        $esslByEmployeeDate = [];
        if (!empty($employeeIds)) {
            $esslRows = DB::table('egc_staff_essl')
                ->whereIn('employee_id', $employeeIds)
                ->where('date', '>=', $start)
                ->where('date', '<', Carbon::parse($end)->addDay()->toDateString())
                ->orderBy('sno')
                ->get(['sno', 'employee_id', 'date', 'in_time', 'out_time', 'essl_status']);

            foreach ($esslRows as $row) {
                $dateKey = substr((string) $row->date, 0, 10);
                $employeeKey = (string) $row->employee_id;
                $esslByEmployeeDate[$employeeKey][$dateKey] = $row;
            }
        }

        $approvedRequestsByStaffDate = [];
        if (!empty($staffIds)) {
            $requests = DB::table('egc_leave_permission')
                ->whereIn('staff_id', $staffIds)
                ->where('status', 1) // Final approved leave/permission only.
                ->where('from_date', '>=', $start)
                ->where('from_date', '<', Carbon::parse($end)->addDay()->toDateString())
                ->orderBy('sno')
                ->get(['sno', 'staff_id', 'from_date', 'request_type', 'leave_type', 'reason']);

            foreach ($requests as $request) {
                $dateKey = substr((string) $request->from_date, 0, 10);
                $approvedRequestsByStaffDate[(int) $request->staff_id][$dateKey][] = $request;
            }
        }

        return [
            'start_date' => $start,
            'end_date' => $end,
            'dates' => $this->dateKeys($startDate, $endDate),
            'holiday_dates' => $holidayDates,
            'shift_logs' => $shiftLogsByStaff,
            'shift_days' => $shiftDaysByShift,
            'attendance' => $attendanceByStaffDate,
            'essl' => $esslByEmployeeDate,
            'approved_requests' => $approvedRequestsByStaffDate,
        ];
    }

    private function evaluateStaff($staff, array $context, string $reportType, bool $includeDetails): array
    {
        $staffId = (int) $staff->staff_pk;
        $employeeId = (string) ($staff->employee_id ?? '');
        $joiningDate = $staff->date_of_joining ? substr((string) $staff->date_of_joining, 0, 10) : null;
        $employmentEnd = $this->employmentEndDate($staff);
        $shiftLogs = $context['shift_logs'][$staffId] ?? [];
        $stats = [
            'scheduled_days' => 0,
            'attended_days' => 0,
            'leave_days' => 0,
            'permission_days' => 0,
            'absent_days' => 0,
            'missing_days' => 0,
            'shift_log_gap_days' => 0,
            'other_status_days' => 0,
            'early_days' => 0,
            'not_early_days' => 0,
            'late_days' => 0,
            'missing_in_time_days' => 0,
        ];
        $details = [];

        foreach ($context['dates'] as $dateKey) {
            $carbonDate = Carbon::createFromFormat('!Y-m-d', $dateKey);
            $dayName = strtolower($carbonDate->format('D'));
            $detail = [
                'date' => $dateKey,
                'date_label' => $carbonDate->format('d M Y'),
                'day_name' => $carbonDate->format('D'),
                'shift_name' => null,
                'shift_start' => null,
                'shift_end' => null,
                'expected_early_by' => null,
                'not_early_from' => null,
                'not_early_until' => null,
                'late_threshold_from' => null,
                'attendance_code' => null,
                'attendance_label' => '—',
                'in_time' => null,
                'out_time' => null,
                'scheduled' => false,
                'eligible_day' => false,
                'day_result' => 'Excluded',
                'message' => '',
            ];

            // Resolve attendance before evaluating exclusions so HR can still inspect punches
            // on Sundays, holidays, weekly offs, and dates outside the employment period.
            $attendanceRecord = $context['attendance'][$staffId][$dateKey] ?? null;
            $esslRecord = $employeeId !== '' ? ($context['essl'][$employeeId][$dateKey] ?? null) : null;
            $approvedRequests = $context['approved_requests'][$staffId][$dateKey] ?? [];
            $approvedType = $this->approvedRequestType($approvedRequests);

            $inTime = ($attendanceRecord && !empty($attendanceRecord->in_time))
                ? $attendanceRecord->in_time
                : (($esslRecord && !empty($esslRecord->in_time)) ? $esslRecord->in_time : null);
            $outTime = ($attendanceRecord && !empty($attendanceRecord->out_time))
                ? $attendanceRecord->out_time
                : (($esslRecord && !empty($esslRecord->out_time)) ? $esslRecord->out_time : null);

            $attendanceCode = $approvedType ?: strtoupper(trim((string) ($attendanceRecord->attendance ?? '')));
            // A biometric punch can be used as attendance only when no manual/attendance row exists.
            if ($attendanceCode === '' && !$attendanceRecord && $esslRecord && $inTime) {
                $attendanceCode = 'P';
            }

            $detail['attendance_code'] = $attendanceCode !== '' ? $attendanceCode : null;
            $detail['attendance_label'] = $this->attendanceLabel($attendanceCode);
            $detail['in_time'] = $this->formatTime($inTime);
            $detail['out_time'] = $this->formatTime($outTime);

            // Resolve schedule details before exclusions, so HR can inspect shift and punch
            // information even on Sundays/holidays; excluded dates never affect the counters.
            $effectiveShift = $this->effectiveShiftForDate($shiftLogs, $dateKey);
            $shiftDay = null;
            $expectedEarlyRaw = null;
            $lateThresholdRaw = null;
            if ($effectiveShift) {
                $shiftId = (int) $effectiveShift->shift_id;
                $detail['shift_name'] = $effectiveShift->shift_name ?: ('Shift #' . $shiftId);
                $shiftDay = $context['shift_days'][$shiftId][$dayName] ?? null;
                if ($shiftDay) {
                    $detail['shift_start'] = $this->formatTime($shiftDay->time_from ?? null);
                    $detail['shift_end'] = $this->formatTime($shiftDay->time_to ?? null);
                    $expectedEarlyRaw = $this->subtractMinutes($shiftDay->time_from ?? null, 5);
                    $lateThresholdRaw = $this->addMinutes($shiftDay->time_from ?? null, 2);
                    $notEarlyStartRaw = $expectedEarlyRaw ? $this->addMinutes($expectedEarlyRaw, 1) : null;
                    $notEarlyEndRaw = $lateThresholdRaw ? $this->subtractMinutes($lateThresholdRaw, 1) : null;
                    $detail['expected_early_by'] = $expectedEarlyRaw ? $this->formatTime($expectedEarlyRaw) : null;
                    $detail['not_early_from'] = $notEarlyStartRaw ? $this->formatTime($notEarlyStartRaw) : null;
                    $detail['not_early_until'] = $notEarlyEndRaw ? $this->formatTime($notEarlyEndRaw) : null;
                    $detail['late_threshold_from'] = $lateThresholdRaw ? $this->formatTime($lateThresholdRaw) : null;
                }
            }

            // Sunday and official holidays are always excluded, even if a shift is configured.
            if ($carbonDate->dayOfWeek === Carbon::SUNDAY) {
                $detail['day_result'] = 'Sunday';
                $detail['message'] = 'Sunday is excluded from the working-day calculation.';
                if ($includeDetails) {
                    $details[] = $detail;
                }
                continue;
            }
            if (isset($context['holiday_dates'][$dateKey])) {
                $detail['day_result'] = 'Holiday';
                $detail['message'] = 'Configured holiday is excluded from the working-day calculation.';
                if ($includeDetails) {
                    $details[] = $detail;
                }
                continue;
            }
            if (($joiningDate && $dateKey < $joiningDate) || ($employmentEnd && $dateKey > $employmentEnd)) {
                $detail['day_result'] = 'Outside employment';
                $detail['message'] = 'Date falls outside the employee employment period.';
                if ($includeDetails) {
                    $details[] = $detail;
                }
                continue;
            }

            if (!$effectiveShift) {
                $stats['shift_log_gap_days']++;
                $detail['day_result'] = 'Shift not configured';
                $detail['message'] = 'No shift-log assignment was active for this weekday; HR should verify the missing shift history.';
                if ($includeDetails) {
                    $details[] = $detail;
                }
                continue;
            }

            if (!$shiftDay) {
                $detail['day_result'] = 'Weekly off';
                $detail['message'] = 'The effective shift has no active schedule for this weekday.';
                if ($includeDetails) {
                    $details[] = $detail;
                }
                continue;
            }

            $stats['scheduled_days']++;
            $detail['scheduled'] = true;


            if ($attendanceCode === 'L') {
                $stats['leave_days']++;
                $detail['day_result'] = 'Leave';
                $detail['message'] = 'Approved leave or leave attendance was recorded on this working day.';
            } elseif ($attendanceCode === 'PR') {
                $stats['permission_days']++;
                $detail['day_result'] = 'Permission';
                $detail['message'] = 'Approved permission or permission attendance was recorded on this working day.';
            } elseif ($attendanceCode === 'A') {
                $stats['absent_days']++;
                $detail['day_result'] = 'Absent';
                $detail['message'] = 'Attendance is marked absent.';
            } elseif (in_array($attendanceCode, ['P', 'OD'], true)) {
                $stats['attended_days']++;
                $detail['eligible_day'] = true;
                $detail['day_result'] = 'Present';
                $detail['message'] = $attendanceCode === 'OD'
                    ? 'On-duty attendance counts as attended for Master Attendance.'
                    : 'Present on the scheduled working day.';

                if ($reportType === 'early_bird') {
                    if (!$inTime) {
                        $stats['missing_in_time_days']++;
                        $detail['eligible_day'] = false;
                        $detail['day_result'] = 'In-time missing';
                        $detail['message'] = 'A punch/in-time is required to confirm an early arrival.';
                    } elseif (!$expectedEarlyRaw) {
                        $stats['missing_in_time_days']++;
                        $detail['eligible_day'] = false;
                        $detail['day_result'] = 'Shift start missing';
                        $detail['message'] = 'Shift start time is missing, so the five-minute rule cannot be verified.';
                    } elseif ($this->timeIsOnOrBefore($inTime, $expectedEarlyRaw)) {
                        // Example: a 09:50 shift starts the Early Bird window through 09:45.
                        $stats['early_days']++;
                        $detail['day_result'] = 'Early bird';
                        $detail['message'] = 'In-time is at least five minutes before the scheduled shift start.';
                    } elseif ($lateThresholdRaw && $this->timeIsBefore($inTime, $lateThresholdRaw)) {
                        // Example: 09:46–09:51 for a 09:50 shift is Not Early, but not Late.
                        $stats['not_early_days']++;
                        $detail['eligible_day'] = false;
                        $detail['day_result'] = 'Not early';
                        $detail['message'] = 'In-time is after the early cutoff but before the late threshold.';
                    } else {
                        // Example: 09:52 onward for a 09:50 shift is Late.
                        $stats['late_days']++;
                        $detail['eligible_day'] = false;
                        $detail['day_result'] = 'Late';
                        $detail['message'] = 'In-time is at least two minutes after the scheduled shift start.';
                    }
                }
            } else {
                $stats['missing_days']++;
                $detail['day_result'] = 'Attendance missing';
                $detail['message'] = $attendanceCode === ''
                    ? 'No attendance record or biometric in-time was found.'
                    : 'Attendance code is not a qualifying present/on-duty code.';
                if ($attendanceCode !== '') {
                    $stats['other_status_days']++;
                }
            }

            if ($includeDetails) {
                $details[] = $detail;
            }
        }

        $baselineEligible = $stats['scheduled_days'] > 0
            && $stats['attended_days'] === $stats['scheduled_days']
            && $stats['leave_days'] === 0
            && $stats['permission_days'] === 0
            && $stats['absent_days'] === 0
            && $stats['missing_days'] === 0
            && $stats['shift_log_gap_days'] === 0;

        $eligible = $baselineEligible;
        if ($reportType === 'early_bird') {
            $eligible = $baselineEligible && $stats['early_days'] === $stats['scheduled_days'];
        }

        $reasons = [];
        if ($stats['scheduled_days'] === 0) {
            $reasons[] = 'No scheduled working days were found for this employee in the selected period.';
        }
        if ($stats['leave_days'] > 0) {
            $reasons[] = $stats['leave_days'] . ' leave day(s).';
        }
        if ($stats['permission_days'] > 0) {
            $reasons[] = $stats['permission_days'] . ' permission day(s).';
        }
        if ($stats['absent_days'] > 0) {
            $reasons[] = $stats['absent_days'] . ' absent day(s).';
        }
        if ($stats['missing_days'] > 0) {
            $reasons[] = $stats['missing_days'] . ' working day(s) without qualifying attendance.';
        }
        if ($stats['shift_log_gap_days'] > 0) {
            $reasons[] = $stats['shift_log_gap_days'] . ' weekday(s) have no effective shift-log assignment.';
        }
        if ($reportType === 'early_bird' && $stats['early_days'] < $stats['scheduled_days']) {
            $reasons[] = ($stats['scheduled_days'] - $stats['early_days']) . ' working day(s) did not meet the five-minute early-arrival rule.';
        }
        if ($eligible) {
            $reasons = ['All scheduled working days meet the report eligibility rules.'];
        }

        $name = trim((string) ($staff->staff_name ?? ''));
        if ($name === '') {
            $name = trim((string) ($staff->nick_name ?? '')) ?: 'Staff #' . $staffId;
        }

        $row = [
            'staff_pk' => $staffId,
            'employee_id' => (string) ($staff->employee_id ?? ''),
            'staff_name' => $name,
            'nick_name' => (string) ($staff->nick_name ?? ''),
            'profile_image_url' => $this->profileImageUrl($staff),
            'department_name' => (string) ($staff->department_name ?? '—'),
            'division_name' => (string) ($staff->division_name ?? '—'),
            'job_role_name' => (string) ($staff->job_role_name ?? '—'),
            'company_name' => (string) ($staff->company_name ?? ''),
            'company_base_color' => (string) ($staff->company_base_color ?? '#ab2b22'),
            'entity_base_color' => (string) ($staff->entity_base_color ?? '#ab2b22'),
            'entity_name' => (string) ($staff->entity_name ?? ''),
            'entity_short_name' => (string) ($staff->entity_short_name ?? ''),
            'company_type' => (int) ($staff->company_type ?? 0),
            'company_id' => $staff->company_id,
            'entity_id' => $staff->entity_id,
            'date_of_joining' => $joiningDate,
            'eligible' => $eligible,
            'calculated_eligible' => $eligible,
            'decision_mode' => 'calculated',
            'is_confirmed' => false,
            'confirmed_at' => null,
            'confirmed_by' => null,
            'status' => $eligible ? 'Eligible' : 'Not Eligible',
            'reason' => implode(' ', $reasons),
            'scheduled_days' => $stats['scheduled_days'],
            'attended_days' => $stats['attended_days'],
            'leave_days' => $stats['leave_days'],
            'permission_days' => $stats['permission_days'],
            'absent_days' => $stats['absent_days'],
            'missing_days' => $stats['missing_days'],
            'shift_log_gap_days' => $stats['shift_log_gap_days'],
            'other_status_days' => $stats['other_status_days'],
            'early_days' => $stats['early_days'],
            'not_early_days' => $stats['not_early_days'],
            'late_days' => $stats['late_days'],
            'missing_in_time_days' => $stats['missing_in_time_days'],
            'attendance_percent' => $stats['scheduled_days'] > 0
                ? round(($stats['attended_days'] / $stats['scheduled_days']) * 100, 1)
                : 0,
            'early_percent' => $stats['scheduled_days'] > 0
                ? round(($stats['early_days'] / $stats['scheduled_days']) * 100, 1)
                : 0,
        ];

        if ($includeDetails) {
            $row['details'] = $details;
        }

        return $row;
    }

    /** Apply the saved HR decision and the metrics captured when that month was confirmed. */
    private function applyConfirmedSnapshot(array $row, $confirmation, string $reportType): array
    {
        $row['eligible'] = (int) ($confirmation->eligibility_status ?? 0) === 1;
        $row['status'] = $row['eligible'] ? 'Eligible' : 'Not Eligible';
        $row['calculated_eligible'] = property_exists($confirmation, 'calculated_eligibility_status')
            ? (int) $confirmation->calculated_eligibility_status === 1
            : $row['eligible'];
        $row['decision_mode'] = (string) ($confirmation->decision_mode ?? 'calculated');
        $row['is_confirmed'] = true;
        $row['confirmed_at'] = $confirmation->confirmed_at ?? null;
        $row['confirmed_by'] = $confirmation->confirmed_by ?? null;

        foreach ([
            'scheduled_days', 'attended_days', 'leave_days', 'permission_days',
            'absent_days', 'missing_days', 'shift_log_gap_days', 'attendance_percent', 'reason',
        ] as $field) {
            if (isset($confirmation->{$field}) || property_exists($confirmation, $field)) {
                $row[$field] = $confirmation->{$field};
            }
        }

        if ($reportType === 'early_bird') {
            // Older confirmations stored every post-cutoff arrival in late_days. Only trust
            // the saved early-bird counters once not_early_days is populated by this version.
            // For older rows, retain the counters calculated from the attendance source.
            if (property_exists($confirmation, 'not_early_days') && $confirmation->not_early_days !== null) {
                foreach (['early_days', 'not_early_days', 'late_days', 'missing_in_time_days', 'early_percent'] as $field) {
                    if (isset($confirmation->{$field}) || property_exists($confirmation, $field)) {
                        $row[$field] = $confirmation->{$field};
                    }
                }
            }
        }

        return $row;
    }

    /** Match StaffModel::profile_image_url for rows loaded with DB::table(). */
    private function profileImageUrl($staff): string
    {
        $defaultPath = (int) ($staff->gender ?? 0) === 1
            ? 'assets/egc_images/auth/user_2.png'
            : 'assets/egc_images/auth/user_6.png';

        $imageName = trim((string) ($staff->staff_image ?? ''));
        if ($imageName === '') {
            return asset($defaultPath);
        }

        // The StaffModel stores a filename, not a directory path. basename() prevents
        // database values from escaping the expected public image directory.
        $imageName = basename($imageName);
        $relativePath = (int) ($staff->company_type ?? 0) === 1
            ? 'staff_images/Management/' . $imageName
            : 'staff_images/Buisness/' . (int) ($staff->company_id ?? 0) . '/' . (int) ($staff->entity_id ?? 0) . '/' . $imageName;

        return is_file(public_path($relativePath)) ? asset($relativePath) : asset($defaultPath);
    }

    private function effectiveShiftForDate(array $shiftLogs, string $dateKey)
    {
        // Logs are fetched in descending start-date/ID order; first applicable one is effective.
        foreach ($shiftLogs as $log) {
            $start = substr((string) $log->start_date, 0, 10);
            $end = $log->end_date ? substr((string) $log->end_date, 0, 10) : '9999-12-31';
            if ($start <= $dateKey && $end >= $dateKey) {
                return (int) ($log->shift_id ?? 0) > 0 ? $log : null;
            }
        }

        return null;
    }

    private function employmentEndDate($staff): ?string
    {
        $status = (int) ($staff->staff_status ?? 0);
        if ($status === 4) {
            // Notice staff use their notice end date as the sole employment end date.
            return !empty($staff->notice_end_date)
                ? substr((string) $staff->notice_end_date, 0, 10)
                : null;
        }
        if ($status === 1) {
            return !empty($staff->staff_last_date)
                ? substr((string) $staff->staff_last_date, 0, 10)
                : null;
        }
        if (in_array($status, [5, 6, 7], true)) {
            // Exited staff use staff_last_date only; do not substitute notice_end_date.
            return !empty($staff->staff_last_date)
                ? substr((string) $staff->staff_last_date, 0, 10)
                : null;
        }

        return null;
    }

    private function approvedRequestType(array $requests): ?string
    {
        $hasLeave = false;
        $hasPermission = false;
        foreach ($requests as $request) {
            $type = strtolower(trim((string) ($request->request_type ?? '')));
            if ($type === 'leave') {
                $hasLeave = true;
            } elseif ($type === 'permission') {
                $hasPermission = true;
            }
        }

        // Leave takes precedence if inconsistent data contains both on one date.
        if ($hasLeave) {
            return 'L';
        }
        if ($hasPermission) {
            return 'PR';
        }

        return null;
    }

    private function dateKeys(Carbon $startDate, Carbon $endDate): array
    {
        $dates = [];
        for ($date = $startDate->copy()->startOfDay(); $date->lte($endDate); $date->addDay()) {
            $dates[] = $date->toDateString();
        }

        return $dates;
    }

    private function normaliseDayName(string $dayName): string
    {
        $normalised = strtolower(trim($dayName));
        return substr($normalised, 0, 3);
    }

    private function formatTime($value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            return Carbon::parse($value)->format('h:i A');
        } catch (\Throwable $exception) {
            return (string) $value;
        }
    }

    private function subtractMinutes($value, int $minutes): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            return Carbon::parse($value)->subMinutes($minutes)->format('H:i:s');
        } catch (\Throwable $exception) {
            return null;
        }
    }

    private function addMinutes($value, int $minutes): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        try {
            return Carbon::parse($value)->addMinutes($minutes)->format('H:i:s');
        } catch (\Throwable $exception) {
            return null;
        }
    }

    private function timeIsBefore($inTime, string $threshold): bool
    {
        try {
            return Carbon::parse($inTime)->format('H:i:s') < Carbon::parse($threshold)->format('H:i:s');
        } catch (\Throwable $exception) {
            return false;
        }
    }

    private function timeIsOnOrBefore($inTime, string $threshold): bool
    {
        try {
            return Carbon::parse($inTime)->format('H:i:s') <= Carbon::parse($threshold)->format('H:i:s');
        } catch (\Throwable $exception) {
            return false;
        }
    }

    private function attendanceLabel(string $code): string
    {
        $labels = [
            'P' => 'Present',
            'OD' => 'On Duty',
            'A' => 'Absent',
            'L' => 'Leave',
            'PR' => 'Permission',
            'HD' => 'Holiday',
            'WO' => 'Weekly Off',
        ];

        return $labels[$code] ?? ($code !== '' ? $code : 'No record');
    }
}
