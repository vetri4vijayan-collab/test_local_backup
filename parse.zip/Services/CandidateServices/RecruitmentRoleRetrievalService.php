<?php

namespace App\Services\CandidateServices;

class RecruitmentRoleRetrievalService
{
    /**
     * Retrieve plausible company roles.
     *
     * This is NOT the final matching decision.
     *
     * It only reduces the number of roles sent to
     * the expensive LLM evaluation stage.
     */
    public function retrieve(
        string $resume,
        array $roles,
        int $maxRoles = 20
    ): array {

        $resumeText = mb_strtolower(
            $resume
        );

        $scored = [];

        foreach ($roles as $role) {

            $score = 0;

            $searchText = mb_strtolower(
                implode(
                    ' ',
                    [
                        $role['role_name'] ?? '',
                        $role['role_description'] ?? '',
                        implode(
                            ' ',
                            $role['mandatory_skills'] ?? []
                        ),
                        implode(
                            ' ',
                            $role['preferred_skills'] ?? []
                        ),
                        implode(
                            ' ',
                            $role['responsibilities'] ?? []
                        ),
                    ]
                )
            );

            /*
             * Exact meaningful phrase overlap.
             *
             * This does NOT make the final decision.
             */

            $terms = $this->extractTerms(
                $searchText
            );

            foreach ($terms as $term) {

                if (
                    mb_strlen($term) < 3
                ) {
                    continue;
                }

                if (
                    str_contains(
                        $resumeText,
                        $term
                    )
                ) {

                    $score++;
                }
            }

            /*
             * Role title signal.
             */
            $roleName =
                mb_strtolower(
                    $role['role_name'] ?? ''
                );

            $roleTerms = preg_split(
                '/\s+/',
                $roleName
            );

            foreach ($roleTerms as $term) {

                if (
                    mb_strlen($term) >= 3 &&
                    str_contains(
                        $resumeText,
                        $term
                    )
                ) {

                    $score += 2;
                }
            }

            $scored[] = [
                'score' => $score,
                'role' => $role,
            ];
        }

        usort(
            $scored,
            fn ($a, $b) =>
                $b['score']
                <=>
                $a['score']
        );

        return array_values(
            array_map(
                fn ($item) => $item['role'],
                array_slice(
                    $scored,
                    0,
                    $maxRoles
                )
            )
        );
    }

    protected function extractTerms(
        string $text
    ): array {

        $text = preg_replace(
            '/[^a-z0-9+#.\- ]/i',
            ' ',
            $text
        );

        $words = preg_split(
            '/\s+/',
            $text
        );

        $stopWords = [
            'and',
            'the',
            'for',
            'with',
            'from',
            'role',
            'developer',
            'development',
            'engineer',
            'experience',
            'years',
            'using',
            'work',
            'working',
            'skills',
            'knowledge',
        ];

        return array_values(
            array_unique(
                array_filter(
                    $words,
                    function ($word) use ($stopWords) {

                        return strlen($word) >= 3
                            && !in_array(
                                $word,
                                $stopWords,
                                true
                            );
                    }
                )
            )
        );
    }
}