<?php

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class RecruitmentRoleProfileService
{
    /**
     * Get all active AI-enabled company roles.
     */
    public function getActiveProfiles(): array
    {
        return Cache::remember(
            'recruitment_ai_role_profiles_v1',
            now()->addMinutes(30),
            function () {

                return DB::table(
                    'egc_recruitment_roles'
                )
                    ->where('status', 0)
                    ->where(
                        'ai_matching_enabled',
                        true
                    )
                    ->orderBy('sno')
                    ->get([
                        'sno',
                        'jobrole_name',
                        'role_description',
                        'mandatory_skills',
                        'preferred_skills',
                        'responsibilities',
                        'minimum_experience',
                        'education_requirements',
                        'seniority',
                        'ai_profile_version',
                    ])
                    ->map(function ($role) {

                        return $this->normalize(
                            $role
                        );

                    })
                    ->values()
                    ->toArray();
            }
        );
    }

    /**
     * Get one role.
     */
    public function getProfile(
        int $roleId
    ): ?array {

        $role = DB::table(
            'egc_recruitment_roles'
        )
            ->where('sno', $roleId)
            ->where('status', 0)
            ->where(
                'ai_matching_enabled',
                true
            )
            ->first([
                'sno',
                'jobrole_name',
                'role_description',
                'mandatory_skills',
                'preferred_skills',
                'responsibilities',
                'minimum_experience',
                'education_requirements',
                'seniority',
                'ai_profile_version',
            ]);

        if (!$role) {
            return null;
        }

        return $this->normalize(
            $role
        );
    }

    /**
     * Normalize DB role into AI-safe structure.
     */
    protected function normalize(
        object $role
    ): array {

        return [
            'role_id' => (int) $role->sno,

            'role_name' => trim(
                (string) $role->jobrole_name
            ),

            'role_description' =>
                $this->cleanText(
                    $role->role_description
                ),

            'mandatory_skills' =>
                $this->decodeArray(
                    $role->mandatory_skills
                ),

            'preferred_skills' =>
                $this->decodeArray(
                    $role->preferred_skills
                ),

            'responsibilities' =>
                $this->decodeArray(
                    $role->responsibilities
                ),

            'minimum_experience' =>
                $this->cleanText(
                    $role->minimum_experience
                ),

            'education_requirements' =>
                $this->cleanText(
                    $role->education_requirements
                ),

            'seniority' =>
                $this->cleanText(
                    $role->seniority
                ),

            'profile_version' =>
                (int) (
                    $role->ai_profile_version
                    ?? 1
                ),
        ];
    }

    /**
     * Decode JSON arrays safely.
     */
    protected function decodeArray(
        mixed $value
    ): array {

        if (is_array($value)) {
            return array_values(
                array_filter(
                    array_map(
                        'trim',
                        $value
                    )
                )
            );
        }

        if (
            $value === null ||
            trim((string) $value) === ''
        ) {
            return [];
        }

        $decoded = json_decode(
            $value,
            true
        );

        if (is_array($decoded)) {

            return array_values(
                array_filter(
                    array_map(
                        'trim',
                        $decoded
                    )
                )
            );
        }

        /*
         * Backward compatibility:
         *
         * Existing comma-separated values
         * can still be read.
         */
        return array_values(
            array_filter(
                array_map(
                    'trim',
                    preg_split(
                        '/[,;\n]+/',
                        (string) $value
                    )
                )
            )
        );
    }

    /**
     * Clean role text.
     */
    protected function cleanText(
        mixed $value
    ): string {

        if (
            $value === null
        ) {
            return '';
        }

        $value = strip_tags(
            (string) $value
        );

        $value = preg_replace(
            '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/',
            '',
            $value
        );

        return trim(
            $value
        );
    }

    /**
     * Clear role cache.
     */
    public function clearCache(): void
    {
        Cache::forget(
            'recruitment_ai_role_profiles_v1'
        );
    }
}