<?php

namespace App\Services\StaffService;

use App\Models\StaffModel;
use App\Models\StaffFamilyModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffAttachmentModel;

class StaffProfileCompletionService
{
    public function calculate(int $staffId): array
    {
        $staff = StaffModel::where('sno', $staffId)->first();

        if (!$staff) {
            throw new \RuntimeException('Staff not found.');
        }

        $family = StaffFamilyModel::where('staff_id', $staffId)
            ->where('status', '!=', 2)
            ->first();

        $education = StaffEducationInfoModel::where('staff_id', $staffId)
            ->where('status', '!=', 2)
            ->get();

        $attachments = StaffAttachmentModel::where('staff_id', $staffId)
            ->where('status', '!=', 2)
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Employee editable profile stages
        |--------------------------------------------------------------------------
        |
        | IMPORTANT:
        | Stage 6-10 are intentionally not included here.
        |
        */

        $steps = [];

        $steps['personal'] = $this->personal(
            $staff
        );

        $steps['family'] = $this->family(
            $staff,
            $family
        );

        $steps['contact'] = $this->contact(
            $staff
        );

        $steps['social_media'] = $this->socialMedia(
            $staff
        );

        $steps['education'] = $this->education(
            $staff,
            $education
        );

        /*
        |--------------------------------------------------------------------------
        | HR managed stages
        |--------------------------------------------------------------------------
        */

        $steps['work_type'] = $this->excludedStep(
            'Work Type',
            'hr_managed'
        );

        $steps['company'] = $this->excludedStep(
            'Company Details',
            'hr_managed'
        );

        $steps['salary'] = $this->excludedStep(
            'Salary Details',
            'hr_managed'
        );

        $steps['application'] = $this->excludedStep(
            'Application Details',
            'hr_managed'
        );

        $steps['checklist'] = $this->excludedStep(
            'Checklist',
            'hr_managed'
        );

        /*
        |--------------------------------------------------------------------------
        | Overall
        |--------------------------------------------------------------------------
        */

        $completed = 0;
        $total = 0;

        foreach ($steps as $step) {

            if (($step['included'] ?? false) !== true) {
                continue;
            }

            $completed += (int) ($step['completed'] ?? 0);
            $total += (int) ($step['total'] ?? 0);
        }

        $percentage = $total > 0
            ? round(($completed / $total) * 100, 1)
            : 100;

        return [
            'version' => 3,

            'scope' => 'employee_profile',

            'overall' => [
                'percentage' => $percentage,
                'completed' => $completed,
                'total' => $total,
                'remaining' => max(0, $total - $completed),
                'is_complete' => $percentage >= 100,
            ],

            'steps' => $steps,

            'calculated_at' => now()->toISOString(),
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | Personal
    |--------------------------------------------------------------------------
    */

    protected function personal($staff): array
    {
        $fields = [];

        $fields[] = $this->field(
            'Staff Name',
            $staff->staff_name,
            'required'
        );

        $fields[] = $this->field(
            'Mobile Number',
            $staff->mobile_no,
            'required'
        );

        $fields[] = $this->field(
            'Gender',
            $staff->gender,
            'required'
        );

        $fields[] = $this->field(
            'Date of Birth',
            $staff->dob,
            'required'
        );

        $fields[] = $this->field(
            'Email',
            $staff->email_id,
            'optional'
        );

        $fields[] = $this->field(
            'Mother Tongue',
            $staff->mother_tongue,
            'required'
        );

        $fields[] = $this->field(
            'Languages',
            $staff->languages,
            'optional'
        );

        $fields[] = $this->field(
            'Hobbies',
            $staff->hobby,
            'optional'
        );

        $fields[] = $this->field(
            'Description',
            $staff->description,
            'optional'
        );

        $fields[] = $this->field(
            'Birth Place',
            $staff->birth_place,
            'optional'
        );

        $fields[] = $this->field(
            'Blood Group',
            $staff->blood_group,
            'optional'
        );

        $fields[] = $this->field(
            'Height',
            $staff->height,
            'optional'
        );

        $fields[] = $this->field(
            'Weight',
            $staff->weight,
            'optional'
        );

        $fields[] = $this->field(
            'Nationality',
            $staff->nationality_id,
            'optional'
        );

        $fields[] = $this->field(
            'Religion',
            $staff->religion_id,
            'optional'
        );

        $fields[] = $this->field(
            'Community',
            $staff->community_id,
            'optional'
        );

        $fields[] = $this->field(
            'Caste',
            $staff->caste_id,
            'optional'
        );

        $fields[] = $this->field(
            'Identification Mark',
            $staff->identification_mark,
            'optional'
        );

        $fields[] = $this->field(
            'Profile Photo',
            $staff->staff_image,
            'optional'
        );

        /*
        |--------------------------------------------------------------------------
        | Statutory
        |--------------------------------------------------------------------------
        */

        $statutory = \App\Models\StaffStatutoryDetailsModel::where(
            'staff_id',
            $staff->sno
        )->first();

        $fields[] = $this->field(
            'Aadhar Number',
            $statutory?->aadhar_no,
            'optional'
        );

        $fields[] = $this->field(
            'PAN Number',
            $statutory?->pan_no,
            'optional'
        );

        /*
        |--------------------------------------------------------------------------
        | Vehicle
        |--------------------------------------------------------------------------
        */

        $vehicleSelected = (int) $staff->vehicle_check === 1;

        $fields[] = $this->field(
            'Vehicle Information',
            $staff->vehicle_check,
            'optional'
        );

        if ($vehicleSelected) {

            $fields[] = $this->field(
                'Driving License Number',
                $staff->driving_license_no,
                'required'
            );

            $fields[] = $this->field(
                'Vehicle Registration Number',
                $staff->vehicle_register_no,
                'required'
            );

            $fields[] = $this->field(
                'License Expiry Date',
                $staff->license_expiry,
                'required'
            );
        }

        return $this->buildStep(
            'Personal Details',
            'personal',
            $fields
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Family
    |--------------------------------------------------------------------------
    */

    protected function family($staff, $family): array
    {
        $fields = [];

        $fields[] = $this->field(
            'Father Name',
            $family?->father_name,
            'required'
        );

        $fields[] = $this->field(
            'Father Occupation',
            $family?->father_occup,
            'required'
        );

        $fields[] = $this->field(
            'Mother Name',
            $family?->mother_name,
            'required'
        );

        $fields[] = $this->field(
            'Mother Occupation',
            $family?->mother_occup,
            'required'
        );

        /*
        |--------------------------------------------------------------------------
        | Marital status
        |--------------------------------------------------------------------------
        */

        $maritalStatus =
            $staff->martial_status ??
            $family?->marital_status;

        $fields[] = $this->field(
            'Marital Status',
            $maritalStatus,
            'required'
        );

        if ((string) $maritalStatus === '1') {

            $fields[] = $this->field(
                'Anniversary Date',
                $family?->anniversary_date,
                'optional'
            );

            $fields[] = $this->field(
                'Spouse Name',
                $family?->spouse_name,
                'optional'
            );

            $fields[] = $this->field(
                'Spouse Mobile',
                $family?->spouse_mobile,
                'optional'
            );

            $fields[] = $this->field(
                'Spouse Date of Birth',
                $family?->spouse_dob,
                'optional'
            );

            /*
             * "No" is still a valid answer.
             */
            $fields[] = $this->field(
                'Spouse Working',
                $family?->spouse_working,
                'optional'
            );

            if (
                strtolower(
                    trim(
                        (string) $family?->spouse_working
                    )
                ) === 'yes'
            ) {

                $fields[] = $this->field(
                    'Spouse Designation',
                    $family?->spouse_designation,
                    'optional'
                );

                $fields[] = $this->field(
                    'Spouse Company',
                    $family?->spouse_company_name,
                    'optional'
                );

                $fields[] = $this->field(
                    'Spouse Salary',
                    $family?->spouse_salary,
                    'optional'
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Children
        |--------------------------------------------------------------------------
        */

        $hasChildren = strtolower(
            trim(
                (string) $family?->has_children
            )
        );

        $fields[] = $this->field(
            'Children Selection',
            $family?->has_children,
            'optional'
        );

        if ($hasChildren === 'yes') {

            $children = $this->decode(
                $family?->children_details
            );

            $count = max(
                (int) ($family?->children_count ?? 0),
                count($children)
            );

            $fields[] = $this->field(
                'Children Count',
                $count > 0 ? $count : null,
                'required'
            );

            for ($i = 0; $i < $count; $i++) {

                $child = $children[$i] ?? [];

                /*
                 * Current Blade requires child name.
                 * Other child fields are optional.
                 */
                $fields[] = $this->field(
                    'Child ' . ($i + 1) . ' Name',
                    $child['child_name'] ?? null,
                    'required'
                );

                $fields[] = $this->field(
                    'Child ' . ($i + 1) . ' DOB',
                    $child['child_dob'] ?? null,
                    'optional'
                );

                $fields[] = $this->field(
                    'Child ' . ($i + 1) . ' Standard / Degree',
                    $child['child_std'] ?? null,
                    'optional'
                );

                $fields[] = $this->field(
                    'Child ' . ($i + 1) . ' Year',
                    $child['child_year'] ?? null,
                    'optional'
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Siblings
        |--------------------------------------------------------------------------
        */

        $hasSiblings = strtolower(
            trim(
                (string) $family?->has_siblings
            )
        );

        $fields[] = $this->field(
            'Siblings Selection',
            $family?->has_siblings,
            'optional'
        );

        if ($hasSiblings === 'yes') {

            $siblings = $this->decode(
                $family?->siblings_detail
            );

            $count = max(
                (int) ($family?->sibling_count ?? 0),
                count($siblings)
            );

            $fields[] = $this->field(
                'Siblings Count',
                $count > 0 ? $count : null,
                'required'
            );

            for ($i = 0; $i < $count; $i++) {

                $sibling = $siblings[$i] ?? [];

                $fields[] = $this->field(
                    'Sibling ' . ($i + 1) . ' Name',
                    $sibling['sibling_name'] ?? null,
                    'required'
                );

                $fields[] = $this->field(
                    'Sibling ' . ($i + 1) . ' Elder / Younger',
                    $sibling['sibling_type'] ?? null,
                    'required'
                );

                $fields[] = $this->field(
                    'Sibling ' . ($i + 1) . ' Occupation / Education',
                    $sibling['sibling_std'] ?? null,
                    'optional'
                );

                $fields[] = $this->field(
                    'Sibling ' . ($i + 1) . ' Annual Income',
                    $sibling['sibling_income'] ?? null,
                    'optional'
                );
            }
        }

        return $this->buildStep(
            'Family Details',
            'family',
            $fields
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Contact
    |--------------------------------------------------------------------------
    */

    protected function contact($staff): array
    {
        $fields = [];

        $fields[] = $this->field(
            'Permanent Address',
            $staff->address,
            'required'
        );

        $fields[] = $this->field(
            'Residential Address',
            $staff->residential_address,
            'optional'
        );

        $fields[] = $this->field(
            'Location URL',
            $staff->location_url,
            'optional'
        );

        $fields[] = $this->field(
            'Latitude',
            $staff->latitude,
            'optional'
        );

        $fields[] = $this->field(
            'Longitude',
            $staff->longitude,
            'optional'
        );

        $names = $this->decode(
            $staff->contact_person_name
        );

        $numbers = $this->decode(
            $staff->contact_person_no
        );

        $relations = $this->decode(
            $staff->contact_person_relation
        );

        $count = max(
            count($names),
            count($numbers),
            count($relations)
        );

        /*
         * At least one emergency contact is required.
         */
        if ($count === 0) {

            $fields[] = $this->field(
                'Emergency Contact Name',
                null,
                'required'
            );

            $fields[] = $this->field(
                'Emergency Contact Relation',
                null,
                'required'
            );

            $fields[] = $this->field(
                'Emergency Contact Mobile',
                null,
                'required'
            );
        }

        for ($i = 0; $i < $count; $i++) {

            $fields[] = $this->field(
                'Emergency Contact ' . ($i + 1) . ' Name',
                $names[$i] ?? null,
                'required'
            );

            $fields[] = $this->field(
                'Emergency Contact ' . ($i + 1) . ' Relation',
                $relations[$i] ?? null,
                'required'
            );

            $fields[] = $this->field(
                'Emergency Contact ' . ($i + 1) . ' Mobile',
                $numbers[$i] ?? null,
                'required'
            );
        }

        return $this->buildStep(
            'Contact Details',
            'contact',
            $fields
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Social Media
    |--------------------------------------------------------------------------
    */

    protected function socialMedia($staff): array
    {
        $social = $this->decode(
            $staff->social_media_details
        );

        /*
         * Having no social media account is valid.
         *
         * Therefore the section is complete when no platform
         * has been selected.
         */
        if (empty($social)) {

            return [
                'key' => 'social_media',
                'label' => 'Social Media',
                'included' => true,
                'percentage' => 100,
                'completed' => 1,
                'total' => 1,
                'remaining' => 0,

                'fields' => [
                    [
                        'key' => 'social_media_selection',
                        'label' => 'Social Media Selection',
                        'mode' => 'optional',
                        'included' => true,
                        'filled' => true,
                        'status' => 'completed',
                    ],
                ],
            ];
        }

        $fields = [];

        foreach ($social as $platform => $url) {

            $fields[] = $this->field(
                ucfirst(
                    str_replace('_', ' ', $platform)
                ),
                $url,
                'optional'
            );
        }

        return $this->buildStep(
            'Social Media',
            'social_media',
            $fields
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Education
    |--------------------------------------------------------------------------
    */

    protected function education($staff, $education): array
    {
        $fields = [];

        if ($education->count() === 0) {

            $fields[] = $this->field(
                'Education Record',
                null,
                'required'
            );

        } else {

            foreach ($education as $index => $row) {

                $qualification =
                    (string) $row->qualification_type;

                $fields[] = $this->field(
                    'Qualification ' . ($index + 1),
                    $row->qualification_type,
                    'required'
                );

                /*
                 * Existing validation logic does not require
                 * major/university for these qualification types.
                 */
                $specialQualification = in_array(
                    $qualification,
                    ['4', '5', '6', 'Others'],
                    true
                );

                if (!$specialQualification) {

                    $fields[] = $this->field(
                        'Major ' . ($index + 1),
                        $row->major,
                        'required'
                    );

                    $fields[] = $this->field(
                        'University ' . ($index + 1),
                        $row->university_name,
                        'required'
                    );
                }

                $fields[] = $this->field(
                    'Year ' . ($index + 1),
                    $row->year,
                    'required'
                );
            }
        }

        /*
         * Course selection.
         */
        $fields[] = $this->field(
            'Any Course Completed?',
            $staff->is_Course,
            'required'
        );

        if ((string) $staff->is_Course === 'Yes') {

            $fields[] = $this->field(
                'Course',
                $this->decode($staff->course_tag),
                'required'
            );
        }

        return $this->buildStep(
            'Education',
            'education',
            $fields
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Field
    |--------------------------------------------------------------------------
    */

    protected function field(
        string $label,
        $value,
        string $mode = 'required'
    ): array {

        $included = $mode !== 'excluded';

        $filled = $included
            ? $this->hasValue($value)
            : false;

        return [
            'label' => $label,
            'mode' => $mode,
            'included' => $included,
            'filled' => $filled,

            'status' => !$included
                ? 'not_applicable'
                : (
                    $filled
                        ? 'completed'
                        : 'incomplete'
                ),
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | Step
    |--------------------------------------------------------------------------
    */

    protected function buildStep(
        string $label,
        string $key,
        array $fields
    ): array {

        $completed = 0;
        $total = 0;

        foreach ($fields as $field) {

            if (($field['included'] ?? false) !== true) {
                continue;
            }

            $total++;

            if (($field['filled'] ?? false) === true) {
                $completed++;
            }
        }

        $percentage = $total > 0
            ? round(
                ($completed / $total) * 100,
                1
            )
            : 100;

        return [
            'key' => $key,
            'label' => $label,
            'included' => true,

            'percentage' => $percentage,

            'completed' => $completed,
            'total' => $total,
            'remaining' => max(
                0,
                $total - $completed
            ),

            'is_complete' => $percentage >= 100,

            'fields' => $fields,
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | Excluded HR stage
    |--------------------------------------------------------------------------
    */

    protected function excludedStep(
        string $label,
        string $reason
    ): array {

        return [
            'label' => $label,
            'included' => false,
            'percentage' => null,
            'completed' => 0,
            'total' => 0,
            'remaining' => 0,
            'is_complete' => null,
            'reason' => $reason,
            'fields' => [],
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | Value detection
    |--------------------------------------------------------------------------
    */

    protected function hasValue($value): bool
    {
        if ($value === null) {
            return false;
        }

        if (is_string($value)) {
            return trim($value) !== '';
        }

        if (is_array($value)) {
            return count($value) > 0;
        }

        /*
         * IMPORTANT:
         * 0 and "0" are valid values.
         */
        return true;
    }


    /*
    |--------------------------------------------------------------------------
    | JSON
    |--------------------------------------------------------------------------
    */

    protected function decode($value): array
    {
        if (is_array($value)) {
            return $value;
        }

        if (!is_string($value) || trim($value) === '') {
            return [];
        }

        $decoded = json_decode(
            $value,
            true
        );

        return is_array($decoded)
            ? $decoded
            : [];
    }
}