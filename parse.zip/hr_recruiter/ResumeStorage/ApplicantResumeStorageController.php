<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\ResumeStorage;

use App\Http\Controllers\Controller;
use App\Jobs\QueueApplicantResumeMigrationChunk;
use App\Jobs\ResumeApplicantResumeMigrationRun;
use App\Jobs\MigrateApplicantResumeRecord;
use App\Models\ApplicantModel;
use App\Services\ApplicantResumeStorage\WasabiResumeStorageService;
use App\Services\GoogleDriveService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

class ApplicantResumeStorageController extends Controller
{
    private WasabiResumeStorageService $storage;

    public function __construct(WasabiResumeStorageService $storage)
    {
        $this->storage = $storage;
    }

    /** Return stable ERP resolver URLs; each access rechecks Wasabi then falls back to Drive and local storage. */
    public function urls(Request $request, int $sno)
    {
        $applicant = $this->findApplicant($sno);
        if (!$applicant) {
            return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);
        }

        $inlineUrl = url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=inline');
        $downloadUrl = url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=attachment');
        $provider = $this->legacyProvider($applicant);
        $originalName = $this->legacyOriginalName($applicant, $sno);
        $mimeType = null;
        $fileSize = null;
        $expiry = null;

        try {
            if ($this->storageReady()) {
                $row = $this->storage->anyRow($sno);
                if ($row && ($row->storage_status ?? '') === 'deleted') {
                    return response()->json([
                        'status' => false,
                        'message' => 'The active resume was deleted. Legacy copies, if any, were retained for rollback.',
                    ], 410);
                }
                if ($row && ($row->storage_status ?? '') === 'deleting') {
                    return response()->json(['status' => false, 'message' => 'Resume deletion is in progress. Retry shortly.'], 423);
                }
                if ($row && ($row->storage_status ?? '') === 'active' && $this->storage->objectAvailable($row)) {
                    $provider = 'wasabi';
                    $originalName = (string) ($row->original_name ?: $originalName);
                    $mimeType = $row->mime_type ?? null;
                    $fileSize = isset($row->file_size) ? (int) $row->file_size : null;
                    $expiry = max(60, min(900, (int) config('wasabi.url_expiry_seconds', 300)));
                }
            }
        } catch (Throwable $e) {
            Log::warning('Wasabi resume metadata lookup failed; resolver URLs will use the legacy fallback order.', [
                'applicant_sno' => $sno,
                'message' => $e->getMessage(),
            ]);
        }

        return response()->json([
            'status' => true,
            'provider' => $provider,
            'expires_in_seconds' => $expiry,
            'view_url' => $inlineUrl,
            'download_url' => $downloadUrl,
            'original_name' => $originalName,
            'mime_type' => $mimeType,
            'file_size' => $fileSize,
            'message' => 'Use these authenticated ERP resolver URLs; the source is checked in priority order on each request.',
        ]);
    }

    /** Resolve in order: reachable Wasabi object -> authenticated Google Drive file/link -> local legacy file. */
    public function open(Request $request, int $sno)
    {
        $applicant = $this->findApplicant($sno);
        if (!$applicant) {
            abort(404, 'Applicant not found.');
        }

        $disposition = strtolower((string) $request->query('disposition', 'inline'));
        if (!in_array($disposition, ['inline', 'attachment'], true)) {
            $disposition = 'inline';
        }

        // 1. Wasabi: only redirect after a real HEAD request confirms that the object is available.
        try {
            if ($this->storageReady()) {
                $row = $this->storage->anyRow($sno);
                if ($row && ($row->storage_status ?? '') === 'deleted') {
                    abort(410, 'The active resume was deleted.');
                }
                if ($row && ($row->storage_status ?? '') === 'deleting') {
                    abort(423, 'Resume deletion is in progress.');
                }
                if ($row && ($row->storage_status ?? '') === 'active') {
                    if ($this->storage->objectAvailable($row)) {
                        try {
                            return redirect()->away($this->storage->temporaryUrl($row, $disposition));
                        } catch (Throwable $e) {
                            Log::warning('Wasabi signed URL could not be created; trying legacy resume sources.', [
                                'applicant_sno' => $sno,
                                'message' => $e->getMessage(),
                            ]);
                        }
                    }
                }
            }
        } catch (\Symfony\Component\HttpKernel\Exception\HttpException $e) {
            throw $e;
        } catch (Throwable $e) {
            Log::warning('Wasabi resume lookup failed; trying Google Drive and local fallback.', [
                'applicant_sno' => $sno,
                'message' => $e->getMessage(),
            ]);
        }

        // 2. Google Drive: prefer an authenticated file-id download. This confirms the file can really be read.
        $drive = $this->decodeDriveData($applicant->drive_data ?? null);
        $webViewLink = (string) ($drive['webViewLink'] ?? '');
        $driveId = trim((string) ($drive['file_id'] ?? ''));
        if ($driveId === '' && $this->isAllowedDriveLink($webViewLink)) {
            $driveId = $this->extractDriveFileId($webViewLink);
        }
        if ($driveId !== '') {
            $temporaryDirectory = storage_path('app/tmp/legacy-resume-access');
            if (!is_dir($temporaryDirectory) && !mkdir($temporaryDirectory, 0700, true) && !is_dir($temporaryDirectory)) {
                Log::error('Unable to create the private temporary resume directory.', ['applicant_sno' => $sno]);
            } else {
                $originalName = $this->storage->safeOriginalName((string) ($drive['file_name'] ?? $applicant->attachment ?? ('resume-' . $sno . '.pdf')));
                $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
                $extension = preg_replace('/[^a-z0-9]/i', '', $extension) ?: 'bin';
                $temporaryPath = $temporaryDirectory . DIRECTORY_SEPARATOR . Str::uuid() . '.' . $extension;

                try {
                    app(GoogleDriveService::class)->downloadToFile($driveId, $temporaryPath);
                    $size = is_file($temporaryPath) ? filesize($temporaryPath) : false;
                    $maxBytes = max(1, (int) config('wasabi.max_file_size_bytes', 52428800));
                    if ($size === false || $size < 1) {
                        throw new \RuntimeException('Google Drive returned an empty resume.');
                    }
                    if ($size > $maxBytes) {
                        @unlink($temporaryPath);
                        Log::warning('Google Drive resume exceeded the configured transfer size; trying local fallback.', [
                            'applicant_sno' => $sno,
                            'size_bytes' => $size,
                        ]);
                    } else {
                        if (in_array($extension, ['html', 'htm', 'svg', 'xhtml', 'xml', 'js'], true)) {
                            $disposition = 'attachment';
                        }
                        $mime = function_exists('mime_content_type') ? (mime_content_type($temporaryPath) ?: 'application/octet-stream') : 'application/octet-stream';
                        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $originalName) ?: 'resume';
                        $headers = [
                            'Content-Type' => $mime,
                            'Content-Disposition' => $disposition . '; filename="' . $safeName . '"',
                            'Cache-Control' => 'private, no-store, max-age=0',
                            'Pragma' => 'no-cache',
                            'X-Content-Type-Options' => 'nosniff',
                            'X-Frame-Options' => 'SAMEORIGIN',
                        ];
                        if ($disposition === 'attachment') {
                            return response()->download($temporaryPath, $originalName, $headers)->deleteFileAfterSend(true);
                        }
                        return response()->file($temporaryPath, $headers)->deleteFileAfterSend(true);
                    }
                } catch (Throwable $e) {
                    if (is_file($temporaryPath)) {
                        @unlink($temporaryPath);
                    }
                    Log::warning('Google Drive resume could not be downloaded; trying the local fallback.', [
                        'applicant_sno' => $sno,
                        'message' => $e->getMessage(),
                    ]);
                }
            }
        }

        // If the stored Drive link had no extractable file id, allow only HTTPS links on approved Google hosts.
        if ($driveId === '' && $this->isAllowedDriveLink($webViewLink) && $disposition === 'inline') {
            return redirect()->away($webViewLink);
        }

        // 3. Local public-folder legacy copy is the last fallback, but is served via this authenticated route.
        $localPath = $this->resolveLegacyLocalPath((string) ($applicant->attachment ?? ''));
        if ($localPath) {
            $name = basename($localPath);
            $extension = strtolower((string) pathinfo($name, PATHINFO_EXTENSION));
            if (in_array($extension, ['html', 'htm', 'svg', 'xhtml', 'xml', 'js'], true)) {
                $disposition = 'attachment';
            }
            $mime = function_exists('mime_content_type') ? (mime_content_type($localPath) ?: 'application/octet-stream') : 'application/octet-stream';
            $headers = [
                'Content-Type' => $mime,
                'Content-Disposition' => $disposition . '; filename="' . (preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?: 'resume') . '"',
                'Cache-Control' => 'private, no-store, max-age=0',
                'Pragma' => 'no-cache',
                'X-Content-Type-Options' => 'nosniff',
                'X-Frame-Options' => 'SAMEORIGIN',
            ];
            if ($disposition === 'attachment') {
                return response()->download($localPath, $name, $headers);
            }
            return response()->file($localPath, $headers);
        }

        abort(404, 'No readable resume source is available in Wasabi, Google Drive, or the local legacy folder.');
    }

    /** Upload/replace a resume for an existing applicant; keep a legacy mirror for old screens. */
    public function upload(Request $request, int $sno)
    {
        $applicant = $this->findApplicant($sno);
        if (!$applicant) return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);
        if (!$this->storageReady()) {
            return response()->json(['status' => false, 'message' => 'Wasabi is not ready. Verify configuration, install aws/aws-sdk-php and apply the Wasabi storage SQL.'], 503);
        }

        $validated = $request->validate([
            'upload_resume' => ['required', 'file', 'max:10240', 'mimes:pdf,doc,docx,docm,odt,rtf,txt,text,md,markdown,html,htm,ppt,pptx,xls,xlsx,jpg,jpeg,png,webp,bmp,gif,tif,tiff'],
        ]);
        $file = $validated['upload_resume'];
        $oldAttachment = (string) ($applicant->attachment ?? '');
        $safeExtension = strtolower((string) $file->getClientOriginalExtension());
        $safeExtension = preg_replace('/[^a-z0-9]/i', '', $safeExtension) ?: 'bin';
        $newName = 'RESUME-' . $sno . '-' . Str::uuid() . '.' . $safeExtension;
        $localPath = public_path('job_applications/resume_files/' . $newName);
        $localDirectory = dirname($localPath);
        if (!File::exists($localDirectory)) File::makeDirectory($localDirectory, 0775, true);

        // Copy, don't move: Laravel may need the UploadedFile through the request lifecycle.
        if (!copy($file->getRealPath(), $localPath)) {
            return response()->json(['status' => false, 'message' => 'Could not create the compatibility copy. No resume was changed.'], 500);
        }

        $oldResumeText = $applicant->resume_text;
        $oldResumeHash = $applicant->recruitment_resume_sha256;
        $oldUpdatedBy = $applicant->updated_by;
        $oldUpdatedAt = $applicant->updated_at;
        $actorId = (int) (auth()->user()->user_id ?? auth()->id() ?? 0);
        try {
            // Switch the legacy attachment pointer first; restore it if Wasabi rejects the new object.
            $applicant->attachment = $newName;
            $applicant->resume_text = null;
            $applicant->recruitment_resume_sha256 = hash_file('sha256', $localPath);
            $applicant->updated_by = $actorId > 0 ? $actorId : null;
            $applicant->updated_at = now();
            $applicant->save();

            $stored = $this->storage->storePath(
                $sno,
                $localPath,
                $file->getClientOriginalName(),
                'upload',
                'upload:' . $file->getClientOriginalName(),
                $actorId > 0 ? $actorId : null,
                true
            );

            return response()->json([
                'status' => true,
                'message' => 'Resume uploaded and verified in Wasabi. A local compatibility mirror was retained for older ERP screens.',
                'data' => [
                    'applicant_sno' => $sno,
                    'provider' => 'wasabi',
                    'original_name' => $stored['original_name'],
                    'file_size' => $stored['file_size'],
                    'sha256' => $stored['sha256'],
                    'view_url' => url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=inline'),
                    'download_url' => url('/hr-recruiter/applicants/' . $sno . '/resume/open?disposition=attachment'),
                ],
            ]);
        } catch (Throwable $e) {
            try {
                $applicant->attachment = $oldAttachment ?: null;
                $applicant->resume_text = $oldResumeText;
                $applicant->recruitment_resume_sha256 = $oldResumeHash;
                $applicant->updated_by = $oldUpdatedBy;
                $applicant->updated_at = $oldUpdatedAt;
                $applicant->save();
            } catch (Throwable $restoreError) {
                Log::critical('Could not restore the previous applicant attachment after Wasabi upload failure.', ['applicant_sno' => $sno, 'message' => $restoreError->getMessage()]);
            }
            @unlink($localPath);
            Log::error('Existing applicant Wasabi resume upload failed.', ['applicant_sno' => $sno, 'message' => $e->getMessage()]);
            return response()->json(['status' => false, 'message' => 'Wasabi upload failed. The previous active resume was preserved.'], 503);
        }
    }

    /** Delete the active cloud object only; retain legacy local/Drive sources for controlled rollback. */
    public function destroy(Request $request, int $sno)
    {
        if (!$this->findApplicant($sno)) return response()->json(['status' => false, 'message' => 'Applicant not found.'], 404);
        if (!$this->storageReady()) return response()->json(['status' => false, 'message' => 'Wasabi is not ready.'], 503);

        try {
            $actorId = (int) (auth()->user()->user_id ?? auth()->id() ?? 0);
            $deleted = $this->storage->deleteApplicantObject($sno, $actorId > 0 ? $actorId : null);
            if (!$deleted) return response()->json(['status' => false, 'message' => 'No active Wasabi object was found.'], 404);
            return response()->json(['status' => true, 'message' => 'Wasabi object deleted. Legacy local/Drive copies were not removed.']);
        } catch (Throwable $e) {
            Log::error('Wasabi resume deletion failed.', ['applicant_sno' => $sno, 'message' => $e->getMessage()]);
            return response()->json(['status' => false, 'message' => 'Wasabi delete failed. Storage metadata was not marked deleted.'], 503);
        }
    }

    /**
     * Protected by a separate high-entropy API token (X-Wasabi-Migration-Token).
     * dry_run defaults to true. The source files are never deleted by this endpoint.
     */
    public function migrate(Request $request)
    {
        $configuredToken = (string) config('wasabi.migration_api_token', '');
        $providedToken = (string) $request->header('X-Wasabi-Migration-Token', '');
        if (strlen($configuredToken) < 32) {
            return response()->json(['status' => false, 'message' => 'WASABI_MIGRATION_API_TOKEN must contain at least 32 characters.'], 503);
        }
        if ($providedToken === '' || !hash_equals($configuredToken, $providedToken)) {
            return response()->json(['status' => false, 'message' => 'Unauthorized migration request.'], 401);
        }
        if (!$this->storageReady()) {
            return response()->json(['status' => false, 'message' => 'Wasabi is not ready. Verify config, SDK dependency and SQL.'], 503);
        }

        $validated = $request->validate([
            'applicant_sno' => ['nullable', 'integer', 'min:1'],
            'source' => ['nullable', 'in:auto,local,drive'],
            'dry_run' => ['nullable', 'boolean'],
            'limit' => ['nullable', 'integer', 'min:1', 'max:1000'],
            'after_sno' => ['nullable', 'integer', 'min:0'],
            'replace' => ['nullable', 'boolean'],
            'async' => ['nullable', 'boolean'],
            // Re-dispatch existing queued items in an already-scanned run without creating a new run.
            'resume_run_id' => ['nullable', 'uuid'],
            // Inline resume mode is used only for controlled recovery when queue connectivity is unavailable.
            'inline' => ['nullable', 'boolean'],
            // Independent modulo lanes let multiple authenticated Postman requests work without selecting the same items.
            'parallel_lanes' => ['nullable', 'integer', 'min:1', 'max:8'],
            'parallel_lane' => ['nullable', 'integer', 'min:0', 'max:7'],
        ]);

        if (!empty($validated['resume_run_id'])) {
            return $this->resumeExistingAsyncMigration($request, (string) $validated['resume_run_id']);
        }

        $dryRun = array_key_exists('dry_run', $validated) ? (bool) $validated['dry_run'] : true;
        $sourceChoice = (string) ($validated['source'] ?? 'auto');
        $async = (bool) ($validated['async'] ?? false);
        $limit = (int) ($validated['limit'] ?? ($async ? 500 : 25));
        $replace = (bool) ($validated['replace'] ?? false);

        // Keep the existing synchronous API bounded. Large production migrations must use queue workers.
        // if (!$async && $limit > 100) {
        //     return response()->json([
        //         'status' => false,
        //         'message' => 'Synchronous migration remains limited to 100 records per request. Set async=true for a resumable background migration.',
        //     ], 422);
        // }

        if ($async) {
            if (!empty($validated['applicant_sno'])) {
                return response()->json(['status' => false, 'message' => 'async=true is for batch migration; omit applicant_sno.'], 422);
            }
            return $this->startAsyncMigration($validated, $sourceChoice, $dryRun, $limit, $replace, $request);
        }

        $query = ApplicantModel::query()->where('status', '!=', 2);
        if (!empty($validated['applicant_sno'])) {
            $query->where('sno', (int) $validated['applicant_sno']);
            $limit = 1;
        } else {
            if (array_key_exists('after_sno', $validated)) $query->where('sno', '>', (int) $validated['after_sno']);
            $query->where(function ($q) {
                $q->whereNotNull('attachment')->orWhereNotNull('drive_data');
            });
            $query->orderBy('sno')->limit($limit);
        }
        $applicants = $query->get(['sno', 'attachment', 'drive_data', 'applicant_id']);
        $results = [];
        $counts = ['planned' => 0, 'migrated' => 0, 'skipped' => 0, 'failed' => 0];
        $lastSno = null;
        $singleApplicant = !empty($validated['applicant_sno']);

        foreach ($applicants as $applicant) {
            $sno = (int) $applicant->sno;
            $lastSno = $sno;
            $temporaryFile = null;
            try {
                $existing = $this->storage->anyRow($sno);
                if ($existing && ($existing->storage_status ?? '') === 'active' && !$replace) {
                    $counts['skipped']++;
                    $results[] = ['applicant_sno' => $sno, 'status' => 'skipped', 'reason' => 'active_wasabi_object_already_exists'];
                    continue;
                }
                if ($existing && ($existing->storage_status ?? '') === 'deleted' && !$replace) {
                    $counts['skipped']++;
                    $results[] = ['applicant_sno' => $sno, 'status' => 'skipped', 'reason' => 'cloud_object_was_deleted; pass replace=true to restore'];
                    continue;
                }

                $driveData = $this->decodeDriveData($applicant->drive_data ?? null);
                $driveId = trim((string) ($driveData['file_id'] ?? ''));
                $localPath = $this->resolveLegacyLocalPath((string) ($applicant->attachment ?? ''));
                $selectedProvider = null;
                $sourcePath = null;
                $originalName = '';
                $temporaryFile = null;

                if ($sourceChoice === 'local' || ($sourceChoice === 'auto' && $localPath)) {
                    if (!$localPath) throw new \RuntimeException('The legacy public-path file was not found.');
                    $selectedProvider = 'local';
                    $sourcePath = $localPath;
                    $originalName = basename($localPath);
                } elseif ($sourceChoice === 'drive' || ($sourceChoice === 'auto' && !$localPath)) {
                    if ($driveId === '') throw new \RuntimeException('No Google Drive file_id is present in drive_data and no usable local source was found.');
                    $selectedProvider = 'drive';
                    $originalName = (string) ($driveData['file_name'] ?? $applicant->attachment ?? ('resume-' . $sno . '.pdf'));
                    if (!$dryRun) {
                        $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
                        $extension = preg_replace('/[^a-z0-9]/i', '', $extension) ?: 'bin';
                        $temporaryDirectory = storage_path('app/tmp/wasabi-migration');
                        if (!is_dir($temporaryDirectory) && !mkdir($temporaryDirectory, 0700, true) && !is_dir($temporaryDirectory)) {
                            throw new \RuntimeException('Could not create secure temporary directory for Drive download.');
                        }
                        $temporaryFile = $temporaryDirectory . DIRECTORY_SEPARATOR . Str::uuid() . '.' . $extension;
                        app(GoogleDriveService::class)->downloadToFile($driveId, $temporaryFile);
                        $sourcePath = $temporaryFile;
                    }
                } else {
                    throw new \RuntimeException('No valid legacy resume source was found.');
                }

                if ($dryRun) {
                    $counts['planned']++;
                    $results[] = [
                        'applicant_sno' => $sno,
                        'status' => 'planned',
                        'source' => $selectedProvider,
                        'source_name' => basename($originalName),
                        'would_replace' => $replace,
                    ];
                    continue;
                }

                if (!$sourcePath || !is_file($sourcePath)) throw new \RuntimeException('Selected source did not produce a readable file.');
                $stored = $this->storage->storePath(
                    $sno,
                    $sourcePath,
                    $originalName,
                    $selectedProvider,
                    $selectedProvider === 'drive' ? $driveId : ('local:' . basename($sourcePath)),
                    null,
                    $replace
                );
                $counts['migrated']++;
                $results[] = [
                    'applicant_sno' => $sno,
                    'status' => 'migrated',
                    'source' => $selectedProvider,
                    'object_key' => $stored['object_key'],
                    'sha256' => $stored['sha256'],
                    'file_size' => $stored['file_size'],
                ];
            } catch (Throwable $e) {
                $counts['failed']++;
                $this->storage->audit($sno, 'migration', $sourceChoice, null, null, 'failed', $e->getMessage(), null);
                Log::error('Applicant Wasabi migration failed.', ['applicant_sno' => $sno, 'source' => $sourceChoice, 'message' => $e->getMessage()]);
                $results[] = ['applicant_sno' => $sno, 'status' => 'failed', 'message' => 'Migration failed; inspect the server log/audit record.'];
            } finally {
                if (!empty($temporaryFile) && is_file($temporaryFile)) @unlink($temporaryFile);
            }
        }

        return response()->json([
            'status' => true,
            'dry_run' => $dryRun,
            'source' => $sourceChoice,
            'limit' => $limit,
            'counts' => $counts,
            'last_processed_sno' => $lastSno,
            'next_after_sno' => $singleApplicant ? null : $lastSno,
            'results' => $results,
            'source_files_deleted' => false,
        ]);
    }

    /** Start a queue-driven migration. The HTTP request only creates the run and returns a run ID. */
    private function startAsyncMigration(array $validated, string $sourceChoice, bool $dryRun, int $batchSize, bool $replace, Request $request)
    {
        $runsTable = 'egc_wasabi_resume_migration_runs';
        $itemsTable = 'egc_wasabi_resume_migration_items';
        if (!DB::getSchemaBuilder()->hasTable($runsTable) || !DB::getSchemaBuilder()->hasTable($itemsTable)) {
            return response()->json([
                'status' => false,
                'message' => 'Async migration tables are missing. Apply database/sql/wasabi_resume_async_migration.sql before using async=true.',
            ], 503);
        }

        // Use a dedicated Wasabi queue connection so the ERP global queue can remain
        // unchanged (including sync) for all other modules.
        $queueConnection = trim((string) config('wasabi.migration_connection', 'wasabi_migration'));
        $queueConnectionConfig = $queueConnection !== ''
            ? config('queue.connections.' . $queueConnection)
            : null;
        $queueDriver = is_array($queueConnectionConfig)
            ? strtolower((string) ($queueConnectionConfig['driver'] ?? ''))
            : '';

        if ($queueConnection === '' || !is_array($queueConnectionConfig) || $queueDriver === '' || $queueDriver === 'sync') {
            return response()->json([
                'status' => false,
                'message' => 'Dedicated Wasabi migration queue is not configured. Add the wasabi_migration connection to config/queue.php, set WASABI_MIGRATION_CONNECTION=wasabi_migration, and keep a worker running for the wasabi-migration queue.',
                'required_connection' => $queueConnection !== '' ? $queueConnection : 'wasabi_migration',
                'required_queue' => (string) config('wasabi.migration_queue', 'wasabi-migration'),
            ], 503);
        }

        // Resolve the connection before creating a run so invalid connection settings
        // fail fast. The API cannot reliably prove that a worker process is alive.
        try {
            app('queue')->connection($queueConnection);
        } catch (Throwable $e) {
            Log::error('Wasabi migration queue connection could not be initialized.', [
                'connection' => $queueConnection,
                'message' => $e->getMessage(),
            ]);
            return response()->json([
                'status' => false,
                'message' => 'Wasabi migration queue connection could not be initialized. Verify config/queue.php and the database/Redis connection.',
            ], 503);
        }

        $activeRun = DB::table($runsTable)
            ->whereIn('status', ['queued', 'running'])
            ->orderByDesc('id')
            ->first(['run_uuid', 'status', 'cursor_sno']);
        if ($activeRun) {
            return response()->json([
                'status' => false,
                'message' => 'Another Wasabi migration run is already queued or running. Check its status before starting another run.',
                'active_run_id' => $activeRun->run_uuid,
                'active_status' => $activeRun->status,
                'cursor_sno' => (int) $activeRun->cursor_sno,
            ], 409);
        }

        $afterSno = (int) ($validated['after_sno'] ?? 0);
        $batchSize = max(1, min(1000, $batchSize));
        $runUuid = (string) Str::uuid();
        $actorId = (int) (auth()->user()->user_id ?? auth()->id() ?? 0);
        $now = now();

        $runId = DB::table($runsTable)->insertGetId([
            'run_uuid' => $runUuid,
            'status' => 'queued',
            'source' => $sourceChoice,
            'dry_run' => $dryRun ? 1 : 0,
            'replace_existing' => $replace ? 1 : 0,
            'actor_id' => $actorId > 0 ? $actorId : null,
            'start_after_sno' => $afterSno,
            'cursor_sno' => $afterSno,
            'batch_size' => $batchSize,
            'scan_complete' => 0,
            'scanned_count' => 0,
            'pending_count' => 0,
            'processed_count' => 0,
            'migrated_count' => 0,
            'planned_count' => 0,
            'skipped_count' => 0,
            'failed_count' => 0,
            'last_error' => null,
            'started_at' => null,
            'finished_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        try {
            QueueApplicantResumeMigrationChunk::dispatch($runUuid, $afterSno)
                ->onConnection($queueConnection)
                ->onQueue((string) config('wasabi.migration_queue', 'wasabi-migration'));
        } catch (Throwable $e) {
            DB::table($runsTable)->where('id', $runId)->update([
                'status' => 'failed',
                'last_error' => substr($e->getMessage(), 0, 4000),
                'finished_at' => now(),
                'updated_at' => now(),
            ]);
            Log::error('Unable to queue Wasabi migration run.', ['run_uuid' => $runUuid, 'message' => $e->getMessage()]);
            return response()->json(['status' => false, 'message' => 'Could not enqueue the migration. Verify queue configuration and worker setup.'], 503);
        }

        $statusUrl = url('/api/wasabi/applicants/migrations/' . $runUuid);
        return response()->json([
            'status' => true,
            'mode' => 'async',
            'message' => 'Migration queued. The API request has returned; queue workers will process records in the background.',
            'run_id' => $runUuid,
            'run_status' => 'queued',
            'dry_run' => $dryRun,
            'source' => $sourceChoice,
            'batch_size' => $batchSize,
            'after_sno' => $afterSno,
            'replace' => $replace,
            'status_url' => $statusUrl,
            'source_files_deleted' => false,
        ], 202);
    }

    /**
     * Resume the queued items of an existing run using versioned jobs.
     * This supports deployments where long-running workers still have the previous job class loaded.
     * Old queued jobs become no-ops because their items are moved out of status=queued before dispatch.
     * Previously failed items are not retried automatically; Drive-only failures may require valid OAuth.
     */
    private function resumeExistingAsyncMigration(Request $request, string $runUuid)
    {
        // Code-only fallback for deployments where the queue cannot accept new jobs.
        // Keep this opt-in and bounded; normal async recovery remains unchanged.
        if ($request->boolean('inline')) {
            return $this->resumeExistingRunInline($request, $runUuid);
        }

        $runsTable = 'egc_wasabi_resume_migration_runs';
        $itemsTable = 'egc_wasabi_resume_migration_items';

        if (!DB::getSchemaBuilder()->hasTable($runsTable) || !DB::getSchemaBuilder()->hasTable($itemsTable)) {
            return response()->json(['status' => false, 'message' => 'Migration tracking tables are not installed.'], 503);
        }

        $queueConnection = trim((string) config('wasabi.migration_connection', 'wasabi_migration'));
        $queueConfig = $queueConnection !== '' ? config('queue.connections.' . $queueConnection) : null;
        $queueDriver = is_array($queueConfig) ? strtolower((string) ($queueConfig['driver'] ?? '')) : '';
        if ($queueConnection === '' || !is_array($queueConfig) || $queueDriver === '' || $queueDriver === 'sync') {
            return response()->json([
                'status' => false,
                'message' => 'The dedicated Wasabi queue connection is not configured.',
                'required_connection' => 'wasabi_migration',
                'required_queue' => (string) config('wasabi.migration_queue', 'wasabi-migration'),
            ], 503);
        }

        try {
            app('queue')->connection($queueConnection);
        } catch (Throwable $e) {
            Log::error('Unable to initialize Wasabi resume queue connection.', [
                'run_uuid' => $runUuid,
                'message' => $e->getMessage(),
            ]);
            return response()->json(['status' => false, 'message' => 'Wasabi queue connection could not be initialized.'], 503);
        }

        $promotion = DB::transaction(function () use ($runsTable, $itemsTable, $runUuid) {
            $run = DB::table($runsTable)->where('run_uuid', $runUuid)->lockForUpdate()->first();
            if (!$run) {
                return ['error' => 'not_found'];
            }
            if (!in_array($run->status, ['queued', 'running'], true)) {
                return ['error' => 'not_active', 'status' => $run->status];
            }
            if (!(bool) $run->scan_complete) {
                return ['error' => 'scan_incomplete'];
            }

            // Move only pending queued items to a versioned state. Already-queued legacy jobs
            // check for status=queued and therefore safely no-op instead of using stale code.
            $promoted = DB::table($itemsTable)
                ->where('run_id', $run->id)
                ->where('status', 'queued')
                ->update([
                    'status' => 'retry_pending',
                    'dispatched_at' => null,
                    'started_at' => null,
                    'finished_at' => null,
                    'error_message' => null,
                    'updated_at' => now(),
                ]);

            // Make this request idempotent: undispatched or not-yet-claimed versioned items
            // can be safely re-enqueued. V2's atomic claim prevents duplicate uploads.
            DB::table($itemsTable)
                ->where('run_id', $run->id)
                ->where('status', 'retry_pending')
                ->update(['dispatched_at' => null, 'updated_at' => now()]);

            $pending = (int) DB::table($itemsTable)
                ->where('run_id', $run->id)
                ->whereIn('status', ['queued', 'retry_pending', 'processing'])
                ->count();

            return [
                'run_id' => $run->run_uuid,
                'promoted' => (int) $promoted,
                'pending_items' => $pending,
                'cursor_sno' => (int) $run->cursor_sno,
            ];
        });

        if (isset($promotion['error'])) {
            if ($promotion['error'] === 'not_found') {
                return response()->json(['status' => false, 'message' => 'Migration run not found.'], 404);
            }
            if ($promotion['error'] === 'scan_incomplete') {
                return response()->json(['status' => false, 'message' => 'This run is still scanning. Use its status endpoint and resume after scan_complete is true.'], 409);
            }
            return response()->json([
                'status' => false,
                'message' => 'This migration run is not active and cannot be resumed through the pending-items action.',
                'run_status' => $promotion['status'] ?? 'unknown',
            ], 409);
        }

        try {
            ResumeApplicantResumeMigrationRun::dispatch($runUuid)
                ->onConnection($queueConnection)
                ->onQueue((string) config('wasabi.migration_queue', 'wasabi-migration'));
        } catch (Throwable $e) {
            Log::error('Could not enqueue existing Wasabi migration recovery planner.', [
                'run_uuid' => $runUuid,
                'message' => $e->getMessage(),
            ]);
            // Items remain retry_pending with dispatched_at=NULL; calling this same API request again is safe.
            return response()->json([
                'status' => false,
                'message' => 'Recovery planner could not be queued. Pending items are retained; retry this same request after queue connectivity is restored.',
            ], 503);
        }

        return response()->json([
            'status' => true,
            'mode' => 'resume_existing_run',
            'message' => 'Pending items were moved to the versioned queue flow. No new migration run was created and failed items were not retried.',
            'run_id' => $runUuid,
            'promoted_to_retry_pending' => (int) $promotion['promoted'],
            'pending_items' => (int) $promotion['pending_items'],
            'source_files_deleted' => false,
            'status_url' => url('/api/wasabi/applicants/migrations/' . $runUuid),
        ], 202);
    }

    /**
     * Process a bounded batch of pending items directly from the authenticated API.
     * This path is intended for code-only recovery when queue dispatch is unavailable.
     * It calls the same versioned job handler, including the atomic item claim and counters.
     */
    private function resumeExistingRunInline(Request $request, string $runUuid)
    {
        $runsTable = 'egc_wasabi_resume_migration_runs';
        $itemsTable = 'egc_wasabi_resume_migration_items';
        if (!DB::getSchemaBuilder()->hasTable($runsTable) || !DB::getSchemaBuilder()->hasTable($itemsTable)) {
            return response()->json(['status' => false, 'message' => 'Migration tracking tables are not installed.'], 503);
        }

        // Bounded inline recovery. Multiple requests can run concurrently by assigning each a
        // distinct modulo lane. A lane never selects another lane's item IDs, so requests don't
        // spend their time competing for the same oldest pending records.
        $batchSize = max(1, min(1000, (int) $request->input('limit', 1000)));
        $parallelLanes = max(1, min(8, (int) $request->input('parallel_lanes', 1)));
        $parallelLane = (int) $request->input('parallel_lane', 0);
        if ($parallelLane < 0 || $parallelLane >= $parallelLanes) {
            return response()->json([
                'status' => false,
                'message' => 'parallel_lane must be between 0 and parallel_lanes - 1.',
                'parallel_lane' => $parallelLane,
                'parallel_lanes' => $parallelLanes,
            ], 422);
        }
        $requestStartedAt = microtime(true);
        // Keep each HTTP process bounded. The deployed 40-second budget left a few seconds
        // for slow transfers before returning; the actual hosting timeout must exceed this.
        $requestTimeBudgetSeconds = 40;
        $budgetExhausted = false;

        $promotion = DB::transaction(function () use ($runsTable, $itemsTable, $runUuid) {
            $run = DB::table($runsTable)->where('run_uuid', $runUuid)->lockForUpdate()->first();
            if (!$run) return ['error' => 'not_found'];
            if (!in_array($run->status, ['queued', 'running'], true)) {
                return ['error' => 'not_active', 'run_status' => $run->status];
            }
            if (!(bool) $run->scan_complete) return ['error' => 'scan_incomplete'];

            // The failed recovery API already promoted these, but promoting queued items again is safe.
            $promoted = DB::table($itemsTable)
                ->where('run_id', (int) $run->id)
                ->where('status', 'queued')
                ->update([
                    'status' => 'retry_pending',
                    'dispatched_at' => null,
                    'started_at' => null,
                    'finished_at' => null,
                    'error_message' => null,
                    'updated_at' => now(),
                ]);

            return ['run_id' => $run->run_uuid, 'run_db_id' => (int) $run->id, 'promoted' => (int) $promoted];
        });

        if (isset($promotion['error'])) {
            if ($promotion['error'] === 'not_found') {
                return response()->json(['status' => false, 'message' => 'Migration run not found.'], 404);
            }
            if ($promotion['error'] === 'scan_incomplete') {
                return response()->json(['status' => false, 'message' => 'The original scan is not complete; inline recovery is not available yet.'], 409);
            }
            return response()->json([
                'status' => false,
                'message' => 'This migration run is not active and cannot be resumed.',
                'run_status' => $promotion['run_status'] ?? 'unknown',
            ], 409);
        }

        $itemsQuery = DB::table($itemsTable)
            ->where('run_id', (int) $promotion['run_db_id'])
            ->where('status', 'retry_pending');
        if ($parallelLanes > 1) {
            // Disjoint lane assignment using the existing primary key; no SQL schema changes.
            $itemsQuery->whereRaw('MOD(id, ?) = ?', [$parallelLanes, $parallelLane]);
        }
        $items = $itemsQuery
            ->orderBy('id')
            ->limit($batchSize)
            ->get(['id', 'applicant_sno']);

        $selectedIds = $items->pluck('id')->map(static fn ($id) => (int) $id)->all();
        $unhandledErrors = [];
        foreach ($items as $item) {
            // Leave enough time for Laravel to serialize the response before typical web timeouts.
            // The next Collection Runner request picks up still-pending items safely.
            if ((microtime(true) - $requestStartedAt) >= $requestTimeBudgetSeconds) {
                $budgetExhausted = true;
                break;
            }

            try {
                // handle() claims status=retry_pending atomically. Competing queue deliveries become no-ops.
                (new MigrateApplicantResumeRecord($runUuid, (int) $item->id))->handle($this->storage);
            } catch (Throwable $e) {
                Log::error('Inline Wasabi migration item failed outside normal handling.', [
                    'run_uuid' => $runUuid,
                    'item_id' => (int) $item->id,
                    'applicant_sno' => (int) $item->applicant_sno,
                    'message' => $e->getMessage(),
                ]);
                $unhandledErrors[] = [
                    'applicant_sno' => (int) $item->applicant_sno,
                    'message' => 'This item could not be handled in this request; inspect the server log before retrying.',
                ];
            }
        }

        $completedThisRequest = 0;
        $remainingSelected = 0;
        if ($selectedIds) {
            $states = DB::table($itemsTable)->whereIn('id', $selectedIds)->pluck('status')->all();
            foreach ($states as $state) {
                if (in_array((string) $state, ['migrated', 'planned', 'skipped', 'failed'], true)) {
                    $completedThisRequest++;
                } elseif (in_array((string) $state, ['retry_pending', 'queued', 'processing'], true)) {
                    $remainingSelected++;
                }
            }
        }

        $run = DB::table($runsTable)->where('run_uuid', $runUuid)->first();
        if (!$run) return response()->json(['status' => false, 'message' => 'Migration run disappeared during recovery.'], 500);

        $laneEligibleQuery = DB::table($itemsTable)
            ->where('run_id', (int) $run->id)
            ->where('status', 'retry_pending');
        if ($parallelLanes > 1) {
            $laneEligibleQuery->whereRaw('MOD(id, ?) = ?', [$parallelLanes, $parallelLane]);
        }
        $lanePending = (int) (clone $laneEligibleQuery)->count();
        $hasInlineEligible = $lanePending > 0;
        $pending = max(0, (int) $run->pending_count);
        // Each lane continues only while its own shard has pending records, preventing finished
        // lanes from looping just because other lanes still have work.
        $nextRequired = $pending > 0 && $hasInlineEligible;

        return response()->json([
            'status' => true,
            'mode' => 'inline_resume',
            'message' => $items->isEmpty()
                ? 'No retryable items were available in this request. Check status; items may be processing, or the run may already be complete.'
                : ($budgetExhausted
                    ? 'The per-request time budget was reached. Continue with the same request; remaining items were retained.'
                    : 'Inline recovery batch finished. Repeat this request with the same run_id while next_request_required is true.'),
            'run_id' => $runUuid,
            'batch_limit' => $batchSize,
            'parallel_lane' => $parallelLane,
            'parallel_lanes' => $parallelLanes,
            'lane_pending' => $lanePending,
            'request_time_budget_seconds' => $requestTimeBudgetSeconds,
            'elapsed_seconds' => round(microtime(true) - $requestStartedAt, 2),
            'time_budget_exhausted' => $budgetExhausted,
            'selected_items' => count($selectedIds),
            'completed_this_request' => $completedThisRequest,
            'items_still_pending_from_batch' => $remainingSelected,
            'promoted_from_queued' => (int) $promotion['promoted'],
            'next_request_required' => $nextRequired,
            'run_status' => (string) $run->status,
            'counts' => [
                'scanned' => (int) $run->scanned_count,
                'pending' => (int) $run->pending_count,
                'processed' => (int) $run->processed_count,
                'migrated' => (int) $run->migrated_count,
                'planned' => (int) $run->planned_count,
                'skipped' => (int) $run->skipped_count,
                'failed' => (int) $run->failed_count,
            ],
            'unhandled_errors' => $unhandledErrors,
            'source_files_deleted' => false,
            'status_url' => url('/api/wasabi/applicants/migrations/' . $runUuid),
        ], 200);
    }

    /** Run status is also protected by the migration token; it exposes no file contents or URLs. */
    public function migrationStatus(Request $request, string $runUuid)
    {
        if (!$this->validMigrationToken($request)) {
            return response()->json(['status' => false, 'message' => 'Unauthorized migration request.'], 401);
        }
        if (!DB::getSchemaBuilder()->hasTable('egc_wasabi_resume_migration_runs')) {
            return response()->json(['status' => false, 'message' => 'Migration tracking tables are not installed.'], 503);
        }

        $run = DB::table('egc_wasabi_resume_migration_runs')->where('run_uuid', $runUuid)->first();
        if (!$run) return response()->json(['status' => false, 'message' => 'Migration run not found.'], 404);

        $failureSamples = [];
        if (DB::getSchemaBuilder()->hasTable('egc_wasabi_resume_migration_items')) {
            $failureSamples = DB::table('egc_wasabi_resume_migration_items')
                ->where('run_id', $run->id)
                ->where('status', 'failed')
                ->orderByDesc('id')
                ->limit(5)
                ->get(['applicant_sno', 'error_message'])
                ->map(static fn ($item) => [
                    'applicant_sno' => (int) $item->applicant_sno,
                    'message' => $item->error_message,
                ])->all();
        }

        return response()->json([
            'status' => true,
            'run_id' => $run->run_uuid,
            'run_status' => $run->status,
            'source' => $run->source,
            'dry_run' => (bool) $run->dry_run,
            'replace' => (bool) $run->replace_existing,
            'batch_size' => (int) $run->batch_size,
            'start_after_sno' => (int) $run->start_after_sno,
            'last_scanned_sno' => (int) $run->cursor_sno,
            'scan_complete' => (bool) $run->scan_complete,
            'counts' => [
                'scanned' => (int) $run->scanned_count,
                'pending' => (int) $run->pending_count,
                'processed' => (int) $run->processed_count,
                'migrated' => (int) $run->migrated_count,
                'planned' => (int) $run->planned_count,
                'skipped' => (int) $run->skipped_count,
                'failed' => (int) $run->failed_count,
            ],
            'started_at' => $run->started_at,
            'finished_at' => $run->finished_at,
            'last_error' => $run->last_error,
            'recent_failures' => $failureSamples,
            'source_files_deleted' => false,
        ]);
    }

    /** Paginated failed records for controlled retry/inspection. */
    public function migrationFailures(Request $request, string $runUuid)
    {
        if (!$this->validMigrationToken($request)) {
            return response()->json(['status' => false, 'message' => 'Unauthorized migration request.'], 401);
        }
        if (!DB::getSchemaBuilder()->hasTable('egc_wasabi_resume_migration_items')) {
            return response()->json(['status' => false, 'message' => 'Migration tracking tables are not installed.'], 503);
        }
        $run = DB::table('egc_wasabi_resume_migration_runs')->where('run_uuid', $runUuid)->first();
        if (!$run) return response()->json(['status' => false, 'message' => 'Migration run not found.'], 404);

        $perPage = max(1, min(100, (int) $request->query('per_page', 50)));
        $items = DB::table('egc_wasabi_resume_migration_items')
            ->where('run_id', $run->id)
            ->where('status', 'failed')
            ->orderBy('applicant_sno')
            ->paginate($perPage, ['applicant_sno', 'status', 'source_provider', 'error_message', 'attempts', 'finished_at']);

        return response()->json(['status' => true, 'run_id' => $runUuid, 'failures' => $items]);
    }

    private function validMigrationToken(Request $request): bool
    {
        $configuredToken = (string) config('wasabi.migration_api_token', '');
        $providedToken = (string) $request->header('X-Wasabi-Migration-Token', '');
        return strlen($configuredToken) >= 32 && $providedToken !== '' && hash_equals($configuredToken, $providedToken);
    }

    private function findApplicant(int $sno): ?ApplicantModel
    {
        return ApplicantModel::query()->where('sno', $sno)->where('status', '!=', 2)->first();
    }

    private function storageReady(): bool
    {
        if (!$this->storage->isConfigured()) return false;
        try {
            $this->storage->assertConfigured();
            return true;
        } catch (Throwable $e) {
            return false;
        }
    }

    private function resolveLegacyLocalPath(string $attachment): ?string
    {
        $attachment = trim($attachment);
        if ($attachment === '') return null;
        $baseDirectory = realpath(public_path('job_applications/resume_files'));
        if (!$baseDirectory) return null;
        $basename = basename(str_replace('\\', '/', $attachment));
        if ($basename === '' || $basename === '.' || $basename === '..') return null;
        $candidate = realpath($baseDirectory . DIRECTORY_SEPARATOR . $basename);
        if (!$candidate || !is_file($candidate) || !is_readable($candidate)) return null;
        if (!str_starts_with($candidate, $baseDirectory . DIRECTORY_SEPARATOR)) return null;
        return $candidate;
    }

    private function decodeDriveData($driveData): array
    {
        if (is_array($driveData)) return $driveData;
        if (!is_string($driveData) || trim($driveData) === '') return [];
        $decoded = json_decode($driveData, true);
        return is_array($decoded) ? $decoded : [];
    }

    /** Extract a Google Drive resource id from supported Drive/Docs viewer URL shapes. */
    private function extractDriveFileId(string $url): string
    {
        if (!$this->isAllowedDriveLink($url)) {
            return '';
        }

        $parts = parse_url($url);
        $path = (string) ($parts['path'] ?? '');
        if (preg_match('~/(?:file|document|spreadsheets|presentation|forms)/d/([A-Za-z0-9_-]+)~', $path, $matches)) {
            return $matches[1];
        }

        parse_str((string) ($parts['query'] ?? ''), $query);
        $queryId = trim((string) ($query['id'] ?? ''));
        return preg_match('/^[A-Za-z0-9_-]{10,}$/', $queryId) ? $queryId : '';
    }

    private function isAllowedDriveLink(string $url): bool
    {
        if ($url === '') return false;
        $parts = parse_url($url);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https') return false;
        $host = strtolower((string) ($parts['host'] ?? ''));
        return in_array($host, ['drive.google.com', 'docs.google.com'], true);
    }

    private function legacyProvider(ApplicantModel $applicant): string
    {
        $drive = $this->decodeDriveData($applicant->drive_data ?? null);
        if (!empty($drive['file_id']) || $this->isAllowedDriveLink((string) ($drive['webViewLink'] ?? ''))) {
            return 'google_drive';
        }
        if ($this->resolveLegacyLocalPath((string) ($applicant->attachment ?? ''))) {
            return 'local';
        }
        return 'unavailable';
    }

    private function legacyOriginalName(ApplicantModel $applicant, int $sno): ?string
    {
        $drive = $this->decodeDriveData($applicant->drive_data ?? null);
        $name = trim((string) ($drive['file_name'] ?? ''));
        if ($name === '') {
            $name = basename((string) ($applicant->attachment ?? ''));
        }
        if ($name === '') {
            return null;
        }
        return $this->storage->safeOriginalName($name);
    }
}
