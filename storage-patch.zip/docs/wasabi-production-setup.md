# ERP Common Wasabi Storage — production overlay

## What this patch is

This package establishes a **shared cloud-storage layer for the ERP**, not a resume-only storage design. Applicant resumes are the first enabled feature. Other ERP modules can later adopt the same service by registering their own feature key and calling `CloudStorageManager` from the relevant module after that module authorizes access to its record.

New/updated shared architecture:

- `App\Services\CloudStorage\WasabiS3ClientFactory`: a single reusable S3-compatible client factory for all modules.
- `App\Services\CloudStorage\CloudStorageManager`: feature-aware upload, integrity verification, metadata lookup, short-lived signed URLs, protected downloads, delete-state handling, and generic audit logging.
- `config/erp_storage.php`: defaults and environment-driven bootstrap settings.
- `egc_storage_feature_settings`: per-feature enable/disable, driver, size cap, allowed extensions/MIME types, privacy setting and signed URL lifetime.
- `egc_storage_objects`: common object metadata with `feature_key`, `owner_type`, and `owner_id`, so modules do not need cloud object keys in their business tables.
- `egc_storage_audit`: common action audit log.
- The existing `WasabiResumeStorageService` remains as a compatibility adapter for already-patched Applicant screens and the current Postman legacy migration API. It shares the same S3 client factory and obeys the `applicant.resume` feature switch. Its current applicant-specific tables remain to prevent regression while old resume consumers are being transitioned.

The generic service deliberately does **not** add a public catch-all upload/delete API. Each module's controller must check login, record permissions, tenant/company access and business rules before calling it. This avoids creating an endpoint that could access any object merely by guessing an ID.

## Files and SQL

Overlay the ZIP content into the actual ERP Laravel project root while preserving paths. The key new files are:

- `app/Services/CloudStorage/WasabiS3ClientFactory.php`
- `app/Services/CloudStorage/CloudStorageManager.php`
- `config/erp_storage.php`
- `database/sql/erp_common_storage.sql`

The patch also contains applicant integration updates and the Postman collection for migrating legacy resumes. The uploaded source archive available for the prior patch did not include `composer.json`, Laravel bootstrap files, or the live database schema, so verify these files against the real deployment before enabling the feature.

## 1. Requirements and environment

Run from the real ERP project root (directory containing `composer.json`):

```bash
composer require aws/aws-sdk-php
```

Add the values shown in `docs/wasabi.env.example` to your server's environment/secrets. Replace placeholder values and keep secrets out of Git, tickets and Postman exports. The required provider settings are:

```dotenv
WASABI_ENABLED=true
WASABI_ACCESS_KEY=replace_with_access_key
WASABI_SECRET_KEY=replace_with_secret_key
WASABI_DEFAULT_REGION=us-east-2
WASABI_BUCKET=replace_with_bucket_name
WASABI_ENDPOINT=https://s3.us-east-2.wasabisys.com
WASABI_PREFIX=erp
```

Generate a migration token independently:

```bash
php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
```

Use a dedicated Wasabi access key restricted to the required bucket/prefix and only required actions: `PutObject`, `GetObject`, object metadata read/`HeadObject`, and `DeleteObject`. Keep the bucket private; objects created by this service are private and do not use `public-read` ACLs. The bucket must already exist in the `us-east-2` region.

`WASABI_ENABLED` is the provider-level switch. Feature-level enabling is controlled by `egc_storage_feature_settings`, with `config/erp_storage.php` as a bootstrap fallback. Set PHP `upload_max_filesize`, `post_max_size`, web server body-size limits and request timeouts to values consistent with your configured per-feature limit.

## 2. Safe rollout

1. Take a complete production database backup and retain a copy of the currently deployed application files.
2. Apply **one** SQL script: `database/sql/erp_common_storage.sql`. `database/sql/wasabi_applicant_storage.sql` is provided as a compatibility-named copy of the same combined schema for deployments following the previous resume patch; do not run both.
3. Verify the tables `egc_storage_feature_settings`, `egc_storage_objects`, `egc_storage_audit`, `egc_applicant_file_storage` and `egc_applicant_storage_audit` exist.
4. Deploy the overlay files. Check permissions on Laravel `storage/` and `bootstrap/cache/`.
5. Clear/rebuild caches from the project root:

   ```bash
   php artisan config:clear
   php artisan cache:clear
   php artisan route:clear
   php artisan config:cache
   ```

6. Check the seeded `applicant.resume` row before the first upload. It is the only feature enabled by this package. Missing provider credentials make the cloud feature unavailable; legacy local/Drive fallbacks remain in place during the compatibility period.
7. Run the Postman dry-run first. Migrate one local resume and one Drive-only resume in staging, compare sizes/checksums and test view/download before any batch migration.

The SQL does not alter applicant, employee, invoice or other business tables and does not delete any legacy local file or Drive object.

## 3. Feature registry and controls

Every module uses a stable `feature_key`. Current first feature:

- `applicant.resume` — enabled by the supplied SQL.

Examples for future modules:

- `staff.document`
- `invoice.pdf`
- `expense.attachment`
- `customer.document`
- `product.image`

Do not enable a future feature until its controller integration, permission checks, file-type policy and fallback behavior have been reviewed and tested.

To register/enable a feature using SQL, configure the extension allowlist and size cap appropriate for that module. Example (starts **disabled**):

```sql
INSERT INTO egc_storage_feature_settings
(feature_key, enabled, driver, max_file_size_bytes, allowed_extensions,
 allowed_mime_types, private_access, signed_url_expiry_seconds)
VALUES
('staff.document', 0, 'wasabi', 52428800, 'pdf,doc,docx,jpg,jpeg,png', '', 1, 300)
ON DUPLICATE KEY UPDATE
  enabled = VALUES(enabled),
  driver = VALUES(driver),
  max_file_size_bytes = VALUES(max_file_size_bytes),
  allowed_extensions = VALUES(allowed_extensions),
  allowed_mime_types = VALUES(allowed_mime_types),
  private_access = VALUES(private_access),
  signed_url_expiry_seconds = VALUES(signed_url_expiry_seconds);
```

After the owning module has been patched and tested, explicitly enable it:

```sql
UPDATE egc_storage_feature_settings
SET enabled = 1, updated_at = CURRENT_TIMESTAMP
WHERE feature_key = 'staff.document';
```

To pause new cloud uploads for a feature:

```sql
UPDATE egc_storage_feature_settings
SET enabled = 0, updated_at = CURRENT_TIMESTAMP
WHERE feature_key = 'applicant.resume';
```

Keep in mind that the existing Applicant compatibility adapter uses its feature switch for Wasabi resolution and will return to its legacy local/Drive sources if disabled. Legacy copies are intentionally retained during this transition. For future modules, the module should explicitly define how disabling uploads affects reads of existing cloud objects.

## 4. Using the common storage service in a future module

Do not copy S3 calls into module controllers. Validate the upload and authorize the business record in the module first, then call the common manager. For example:

```php
use App\Services\CloudStorage\CloudStorageManager;

// Inside an already authenticated/authorized invoice controller:
// 1. Authorize the invoice and the current user's company/tenant access.
// 2. Validate the request file against the invoice feature's policy.
// 3. Store the file using the common service.
$storage = app(CloudStorageManager::class);
$object = $storage->storePath(
    'invoice.pdf',
    'invoice',
    (string) $invoice->id,
    $request->file('attachment')->getRealPath(),
    $request->file('attachment')->getClientOriginalName(),
    (int) (auth()->id() ?? 0),
    'upload'
);

// Persist/reference $object['sno'] or find it later with feature_key + owner_type + owner_id.
// Only after authorizing that same invoice, issue a short-lived URL:
$viewUrl = $storage->temporaryUrl((int) $object['sno'], 'inline');
$downloadUrl = $storage->temporaryUrl((int) $object['sno'], 'attachment');

// Only after authorizing the invoice and confirming business rules, delete by object ID:
// $storage->delete((int) $object['sno'], (int) (auth()->id() ?? 0));
```

`storePath` returns common metadata including `sno`, `feature_key`, `owner_type`, `owner_id`, `object_key`, `mime_type`, `file_size`, and `sha256`. Do not expose raw `object_key` values or write signed URLs to persistent tables/logs. Use `findLatest($featureKey, $ownerType, $ownerId)` when a feature expects one current object; if a feature allows multiple files, list all active records for that owner rather than assuming a single row.

**Authorization note:** the generic service handles storage integrity, feature policy and audit. It does not determine whether a user can view a candidate, invoice, staff file or customer attachment. Do that in the owning controller/policy on every URL and delete request. Signed URLs are bearer links until they expire.

## 5. Applicant resume compatibility endpoints and migration

The previous resume integration remains available and is the only module wired to the UI in this patch. These routes inherit the existing HR authenticated web group:

| Method | Path | Purpose |
|---|---|---|
| GET | `/hr-recruiter/applicants/{sno}/resume/urls` | Return short-lived Wasabi URL or authenticated legacy resolver URL |
| GET | `/hr-recruiter/applicants/{sno}/resume/open?disposition=inline` | View active cloud resume or securely resolve legacy source |
| GET | `/hr-recruiter/applicants/{sno}/resume/open?disposition=attachment` | Download active cloud resume or legacy source |
| POST | `/hr-recruiter/applicants/{sno}/resume` | Upload/replace an existing applicant resume |
| DELETE | `/hr-recruiter/applicants/{sno}/resume` | Delete active Wasabi object while keeping legacy rollback copies |

The token-guarded migration API for Postman is:

`POST {{base_url}}/api/wasabi/applicants/migrate`

Headers:

```http
Accept: application/json
Content-Type: application/json
X-Wasabi-Migration-Token: {{migration_token}}
```

Start with this dry-run payload:

```json
{"dry_run":true,"source":"auto","limit":25,"after_sno":0}
```

Then migrate one applicant:

```json
{"applicant_sno":123,"dry_run":false,"source":"auto"}
```

`auto` prefers an existing readable local file and then attempts the Drive `file_id`. For batches, use the returned `next_after_sno` as the next `after_sno`, keep the batch small at first, and inspect failed records before retrying. `source: "local"` and `source: "drive"` explicitly select the source. Only use `replace: true` after reviewing the active object. Migration does not delete the local file or Drive source.

## 6. Integrity, delete and access semantics

- Uploads are performed using unique object keys, and the service verifies `ContentLength` plus a SHA-256 metadata value before a storage row becomes active.
- Objects are private. View/download uses a signed GET URL with expiry clamped to 60–900 seconds; active HTML/SVG/script-like file types are forced to attachment disposition.
- Download-to-temp validates the downloaded byte length and SHA-256 before returning the file to its caller.
- Delete uses an intermediate `deleting` status; an S3 deletion failure restores `active` metadata and records the failure.
- Generic and applicant compatibility audit tables are separate by design during the transition.
- Do not delete legacy sources or close public directories until the whole ERP has been searched for direct `asset()` paths, `attachment` references, `drive_data` use, and other consumers. This package deliberately avoids breaking those readers.

## 7. Rollback and deployment verification

If storage errors occur, pause the feature through the feature registry and check `storage/logs/laravel.log`, Wasabi IAM/policy, bucket region, DNS/connectivity and the storage audit tables. Preserve SQL rows and source files while diagnosing. Rollback can disable `WASABI_ENABLED` or the `applicant.resume` feature and restore the prior deployed PHP/Blade overlay; the applicant compatibility flow can fall back to unchanged local/Drive sources as long as those sources still exist.

Run these checks in staging before production:

- Add a candidate with a PDF and one Office resume; confirm existing candidate fields and Google Drive behavior still work.
- View/download a newly uploaded resume and an older local resume.
- Migrate a Drive-only resume using the dry-run, then compare object size and SHA-256.
- Attempt an unauthorized request, invalid migration token, invalid extension, oversized upload and expired signed URL.
- Verify that cloud deletion does not delete the local/Drive rollback source.
- For a future module, test tenant/owner authorization for upload, URL creation and deletion independently.

The PHP patch can be linted without production credentials, but only a staging run can validate your actual Laravel version, DB collation/schema, Wasabi bucket policy, Google Drive integration and surrounding ERP permissions.

## Official references

- Wasabi S3 API docs: https://docs.wasabi.com/apidocs
- Wasabi service URLs: https://docs.wasabi.com/docs/service-urls-for-wasabis-storage-regions
- AWS SDK for PHP S3 pre-signed URLs: https://docs.aws.amazon.com/sdk-for-php/v3/developer-guide/s3-presigned-url.html
