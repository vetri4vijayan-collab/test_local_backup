-- ERP Common Wasabi Storage Registry
-- MySQL 5.7+/MariaDB-compatible. Take a database backup before deployment.
-- Run this script once. It creates shared registry/settings/audit tables and the
-- applicant-resume compatibility tables required by the existing resume integration.
-- It does NOT alter applicant/employee/invoice tables and does NOT delete source files.

CREATE TABLE IF NOT EXISTS `egc_storage_feature_settings` (
  `feature_key` VARCHAR(120) NOT NULL,
  `enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `driver` VARCHAR(32) NOT NULL DEFAULT 'wasabi',
  `max_file_size_bytes` BIGINT UNSIGNED NOT NULL DEFAULT 52428800,
  `allowed_extensions` VARCHAR(3000) NOT NULL DEFAULT '',
  `allowed_mime_types` VARCHAR(3000) NOT NULL DEFAULT '',
  `private_access` TINYINT(1) NOT NULL DEFAULT 1,
  `signed_url_expiry_seconds` SMALLINT UNSIGNED NOT NULL DEFAULT 300,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`feature_key`),
  KEY `idx_egc_storage_feature_enabled` (`enabled`, `driver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `egc_storage_objects` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `feature_key` VARCHAR(120) NOT NULL,
  `owner_type` VARCHAR(100) NOT NULL,
  `owner_id` VARCHAR(191) NOT NULL,
  `driver` VARCHAR(32) NOT NULL DEFAULT 'wasabi',
  `bucket_name` VARCHAR(255) NOT NULL,
  `object_key` VARCHAR(768) NOT NULL,
  `disk_path` VARCHAR(768) DEFAULT NULL,
  `original_name` VARCHAR(240) NOT NULL,
  `mime_type` VARCHAR(191) DEFAULT NULL,
  `file_size` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `sha256` CHAR(64) NOT NULL,
  `source_provider` VARCHAR(32) NOT NULL DEFAULT 'upload',
  `source_reference_hash` CHAR(64) DEFAULT NULL,
  `storage_status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `private_access` TINYINT(1) NOT NULL DEFAULT 1,
  `deleted_at` DATETIME DEFAULT NULL,
  `created_by` BIGINT DEFAULT NULL,
  `updated_by` BIGINT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`),
  KEY `idx_egc_storage_owner` (`feature_key`, `owner_type`, `owner_id`, `storage_status`),
  KEY `idx_egc_storage_feature_created` (`feature_key`, `created_at`),
  KEY `idx_egc_storage_object_key` (`object_key`(191)),
  KEY `idx_egc_storage_sha256` (`sha256`),
  KEY `idx_egc_storage_status` (`storage_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `egc_storage_audit` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `object_sno` BIGINT UNSIGNED DEFAULT NULL,
  `feature_key` VARCHAR(120) NOT NULL,
  `owner_type` VARCHAR(100) NOT NULL,
  `owner_id_hash` CHAR(64) NOT NULL,
  `action_name` VARCHAR(40) NOT NULL,
  `object_key` VARCHAR(768) DEFAULT NULL,
  `sha256` CHAR(64) DEFAULT NULL,
  `outcome` VARCHAR(20) NOT NULL,
  `message` TEXT,
  `actor_id` BIGINT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`),
  KEY `idx_egc_storage_audit_object_created` (`object_sno`, `created_at`),
  KEY `idx_egc_storage_audit_feature_created` (`feature_key`, `created_at`),
  KEY `idx_egc_storage_audit_outcome_created` (`outcome`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Existing applicant-resume integration compatibility tables. Keep names/columns stable
-- until all resume consumers have moved to CloudStorageManager.
CREATE TABLE IF NOT EXISTS `egc_applicant_file_storage` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `applicant_sno` BIGINT UNSIGNED NOT NULL,
  `bucket_name` VARCHAR(255) NOT NULL,
  `object_key` VARCHAR(768) NOT NULL,
  `original_name` VARCHAR(240) NOT NULL,
  `mime_type` VARCHAR(191) DEFAULT NULL,
  `file_size` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `sha256` CHAR(64) NOT NULL,
  `source_provider` VARCHAR(32) NOT NULL DEFAULT 'upload',
  `source_reference_hash` CHAR(64) DEFAULT NULL,
  `storage_status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `deleted_at` DATETIME DEFAULT NULL,
  `created_by` BIGINT DEFAULT NULL,
  `updated_by` BIGINT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_egc_applicant_storage_applicant` (`applicant_sno`),
  KEY `idx_egc_applicant_storage_status` (`storage_status`),
  KEY `idx_egc_applicant_storage_sha256` (`sha256`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `egc_applicant_storage_audit` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `applicant_sno` BIGINT UNSIGNED NOT NULL,
  `action_name` VARCHAR(40) NOT NULL,
  `source_provider` VARCHAR(32) DEFAULT NULL,
  `object_key` VARCHAR(768) DEFAULT NULL,
  `sha256` CHAR(64) DEFAULT NULL,
  `outcome` VARCHAR(20) NOT NULL,
  `message` TEXT,
  `actor_id` BIGINT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`),
  KEY `idx_egc_storage_audit_applicant_created` (`applicant_sno`, `created_at`),
  KEY `idx_egc_storage_audit_outcome_created` (`outcome`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Enable Wasabi for Applicant Resume as the only feature enabled by this deployment.
-- INSERT IGNORE preserves any existing operator decision (including enabled=0).
INSERT IGNORE INTO `egc_storage_feature_settings`
 (`feature_key`, `enabled`, `driver`, `max_file_size_bytes`, `allowed_extensions`, `allowed_mime_types`, `private_access`, `signed_url_expiry_seconds`)
VALUES
 ('applicant.resume', 1, 'wasabi', 52428800,
  'pdf,doc,docx,docm,odt,rtf,txt,text,md,markdown,html,htm,ppt,pptx,xls,xlsx,jpg,jpeg,png,webp,bmp,gif,tif,tiff',
  '', 1, 300);

-- Backfill already-tracked private Wasabi resume objects into the common registry without
-- moving/re-uploading objects. This is idempotent and intentionally only copies metadata.
INSERT INTO `egc_storage_objects`
 (`feature_key`, `owner_type`, `owner_id`, `driver`, `bucket_name`, `object_key`, `disk_path`,
  `original_name`, `mime_type`, `file_size`, `sha256`, `source_provider`, `source_reference_hash`,
  `storage_status`, `private_access`, `deleted_at`, `created_by`, `updated_by`, `created_at`, `updated_at`)
SELECT
 'applicant.resume', 'applicant', CAST(a.`applicant_sno` AS CHAR), 'wasabi', a.`bucket_name`, a.`object_key`, NULL,
 a.`original_name`, a.`mime_type`, a.`file_size`, a.`sha256`, a.`source_provider`, a.`source_reference_hash`,
 a.`storage_status`, 1, a.`deleted_at`, a.`created_by`, a.`updated_by`, a.`created_at`, a.`updated_at`
FROM `egc_applicant_file_storage` a
WHERE a.`storage_status` = 'active'
  AND NOT EXISTS (SELECT 1 FROM `egc_storage_objects` g WHERE g.`object_key` = a.`object_key` AND g.`feature_key` = 'applicant.resume');

-- Example for a future feature (kept disabled until deliberately enabled):
-- INSERT INTO egc_storage_feature_settings
--  (feature_key, enabled, driver, max_file_size_bytes, allowed_extensions, allowed_mime_types, private_access, signed_url_expiry_seconds)
-- VALUES ('staff.document', 0, 'wasabi', 52428800, 'pdf,doc,docx,jpg,jpeg,png', '', 1, 300);
