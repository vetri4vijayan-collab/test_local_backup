<?php

/*
| Shared ERP file storage feature registry defaults.
| Feature-level values in egc_storage_feature_settings take precedence after SQL is applied.
| Add new module keys here or register them in the feature settings table; do not hard-code
| Wasabi credentials or object paths in controllers.
*/
return [
    'default_driver' => env('ERP_STORAGE_DEFAULT_DRIVER', 'legacy'),
    'private_by_default' => (bool) env('ERP_STORAGE_PRIVATE_BY_DEFAULT', true),
    'signed_url_expiry_seconds' => (int) env('ERP_STORAGE_SIGNED_URL_EXPIRY_SECONDS', 300),
    'max_file_size_bytes' => (int) env('ERP_STORAGE_MAX_FILE_SIZE_BYTES', 52428800),
    'object_prefix' => trim((string) env('ERP_STORAGE_OBJECT_PREFIX', 'erp'), '/'),
    'delete_cloud_object_on_delete' => (bool) env('ERP_STORAGE_DELETE_CLOUD_OBJECT_ON_DELETE', true),

    // Only this feature is enabled by default for this deployment. Other features must be
    // explicitly enabled with a row in egc_storage_feature_settings or a module-specific config.
    'features' => [
        'applicant.resume' => [
            'enabled' => (bool) env('ERP_STORAGE_FEATURE_APPLICANT_RESUME_ENABLED', true),
            'driver' => env('ERP_STORAGE_FEATURE_APPLICANT_RESUME_DRIVER', 'wasabi'),
            'max_file_size_bytes' => (int) env('ERP_STORAGE_FEATURE_APPLICANT_RESUME_MAX_BYTES', 52428800),
            'allowed_extensions' => 'pdf,doc,docx,docm,odt,rtf,txt,text,md,markdown,html,htm,ppt,pptx,xls,xlsx,jpg,jpeg,png,webp,bmp,gif,tif,tiff',
            'private_access' => true,
            'signed_url_expiry_seconds' => (int) env('ERP_STORAGE_FEATURE_APPLICANT_RESUME_URL_TTL', 300),
        ],
    ],
];
