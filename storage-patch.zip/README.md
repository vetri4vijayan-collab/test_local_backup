# ERP Common Wasabi Storage — production overlay

This patch makes Wasabi a reusable ERP storage provider with **feature-level control**. Applicant Resume is the only feature enabled by the included SQL seed. Future ERP modules can register their own feature key, allowed file types, size limits and signed URL lifetime, then call `App\Services\CloudStorage\CloudStorageManager` only after their own controller authorizes the business record.

## Key files

- `app/Services/CloudStorage/WasabiS3ClientFactory.php` — shared S3 client.
- `app/Services/CloudStorage/CloudStorageManager.php` — generic cloud upload, checksum verification, metadata, signed URLs, protected downloads, delete state and audit API.
- `config/erp_storage.php` — feature defaults and common limits.
- `database/sql/erp_common_storage.sql` — shared feature registry/object/audit tables plus Applicant compatibility tables and backfill of already-tracked Wasabi resume objects.
- `docs/wasabi-production-setup.md` — deployment, feature registration, example service calls, Postman migration, rollback and access-control notes.
- `docs/wasabi.env.example` — environment sample with placeholders only.
- `docs/Wasabi-Applicant-Resume-Migration.postman_collection.json` — legacy Applicant resume migration endpoint.

## Deploy safely

1. From the actual ERP project root, install `aws/aws-sdk-php`.
2. Back up production SQL and apply `database/sql/erp_common_storage.sql` once. The compatibility-named `database/sql/wasabi_applicant_storage.sql` contains the same combined schema; do not run both.
3. Set Wasabi secrets in the production secret manager and enable only `applicant.resume` initially.
4. Deploy the overlay, clear/rebuild Laravel configuration and route caches, then test in staging.
5. In Postman, run the migration dry-run before migrating a single local resume and a single Drive-only resume.

The generic manager intentionally has no unrestricted public upload/delete routes. Each module must authorize its own records before it asks for a signed URL or deletes an object. Other modules are **not automatically moved to Wasabi** by this patch; they can adopt the shared service individually when their read/write paths and permissions have been integrated and tested.

The source archive did not include the production Composer manifest or live schema, and no Wasabi credentials were supplied. The PHP files were syntax-checked; end-to-end validation must be performed in your staging deployment before production rollout.
