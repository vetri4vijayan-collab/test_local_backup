<?php

namespace App\Console\Commands;

use App\Services\Productivity\WebsiteStatusMonitorService;
use Illuminate\Console\Command;
use Throwable;

class CheckWebsiteStatuses extends Command
{
    protected $signature = 'productivity:websites-check {--limit=25 : Maximum number of due websites to check in one run}';
    protected $description = 'Check due Website Status monitor records and save the latest HTTP status.';

    public function handle(WebsiteStatusMonitorService $monitor): int
    {
        try {
            $result = $monitor->checkDue((int) $this->option('limit'));
            $this->info(sprintf(
                'Website checks completed. Checked: %d | Skipped: %d | Due found: %d',
                $result['checked'],
                $result['skipped'],
                $result['found']
            ));
            return self::SUCCESS;
        } catch (Throwable $exception) {
            report($exception);
            $this->error('Website status monitoring failed: ' . $exception->getMessage());
            return self::FAILURE;
        }
    }
}
