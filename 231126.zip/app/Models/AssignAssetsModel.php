<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class AssignAssetsModel extends Model
{
    use HasFactory;
    protected $table = 'egc_it_assign_assets';
    protected $primaryKey = 'sno';
    public $timestamps = true;
   protected $fillable = [
    'assigned_to',
    'assigned_to_id',
    'asset_id',
    'issue_date',
    'acknowledgement_note',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
];
    protected $casts = [
        'issue_date' => 'date:Y-m-d',
        'status' => 'integer',
    ];
}
