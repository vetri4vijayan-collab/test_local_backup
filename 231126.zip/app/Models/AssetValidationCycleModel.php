<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssetValidationCycleModel extends Model
{
    protected $table = 'egc_it_asset_validation_cycles';

    protected $primaryKey = 'sno';

    protected $fillable = [
        'cycle_name',
        'company_id',
        'audit_date',
        'category_id',
        'status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'audit_date' => 'date',
        'company_id' => 'integer',
        'category_id' => 'integer',
        'status' => 'integer',
        'created_by' => 'integer',
        'updated_by' => 'integer',
    ];

    public function items(): HasMany
    {
        return $this->hasMany(
            AssetValidationItemModel::class,
            'cycle_id',
            'sno'
        );
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(
            CompanyModel::class,
            'company_id',
            'sno'
        );
    }

    public function getStatusTextAttribute(): string
    {
        return match ((int) $this->status) {
            0 => 'In Progress',
            1 => 'Completed',
            2 => 'Deleted',
            default => 'Unknown',
        };
    }
}
