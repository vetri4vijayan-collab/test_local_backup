<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetCategoryModel extends Model
{
    use HasFactory;
    public $table = 'egc_it_asset_category';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'category_name',
        'description',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
