<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetManagementModel extends Model
{
    use HasFactory;
    public $table = 'egc_it_asset_management';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'category_id',
        'make',
        'model',
        'serial_number',
        'vendor_id',
        'purchase_date',
        'warranty_until',
        'location_id',
        'company_id',
        'asset_tag',
        'item_name',
        'warranty_status',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
