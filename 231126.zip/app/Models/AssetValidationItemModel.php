<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssetValidationItemModel extends Model
{
    protected $table = 'egc_it_asset_validation_items';

    protected $primaryKey = 'sno';

    protected $fillable = [
        'cycle_id',
        'asset_id',
        'status',
        'audit_note',
        'updated_by',
        'created_by',
    ];

    protected $casts = [
        'cycle_id' => 'integer',
        'asset_id' => 'integer',
        'status' => 'integer',
        'updated_by' => 'integer',
    ];

    public function cycle(): BelongsTo
    {
        return $this->belongsTo(
            AssetValidationCycleModel::class,
            'cycle_id',
            'sno'
        );
    }

    public function getStatusTextAttribute(): string
    {
        return match ((int) $this->status) {
            0 => 'Not Checked',
            1 => 'Verified',
            3 => 'Missing',
            4 => 'Damaged',
            default => 'Unknown',
        };
    }
}
