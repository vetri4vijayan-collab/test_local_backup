<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AddLogIssueModel extends Model
{
    use HasFactory;
    public $table = "egc_crpt_add_log_issue";
    public $primaryKey = 'sno';

    protected $fillable = [
        'reference',
        'accounts_id',
        'isp_category_id',
        'building_id',
        'issue_type_id',
        'rasied_date',
        'owner',
        'priority',
        'description',
        'created_by',
        'created_at',
        'updated_at',   
        'status',
    ];
}
