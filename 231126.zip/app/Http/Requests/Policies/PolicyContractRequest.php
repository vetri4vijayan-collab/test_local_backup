<?php
namespace App\Http\Requests\Policies;
use Illuminate\Foundation\Http\FormRequest;
class PolicyContractRequest extends FormRequest {
    public function authorize(): bool { 
        return true; 
    }
    public function rules(): array { 
        return [
            'title'=>['required','string','max:190'],
            'reference_number'=>['nullable','string','max:100'],
            'provider_name'=>['required','string','max:190'],
            'category'=>['nullable','string','max:100'],
            'owner_name'=>['nullable','string','max:190'],
            'start_date'=>['nullable','date'],
            'end_date'=>['required','date','after_or_equal:start_date'],
            'next_due_date'=>['nullable','date'],
            'sum_insured'=>['nullable','numeric','min:0','decimal:0,2'],
            'premium_amount'=>['nullable','numeric','min:0','decimal:0,2'],
            'contract_amount'=>['nullable','numeric','min:0','decimal:0,2'],
            'payment_frequency'=>['nullable','string','max:40'],
            'policy_number'=>['nullable','string','max:100'],
            'asset_name'=>['nullable','string','max:190'],
            'notes'=>['nullable','string','max:5000'],
            'status'=>['sometimes','integer','in:0,1']
        ]; 
    }
}
