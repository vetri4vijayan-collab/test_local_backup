<?php
namespace App\Http\Requests\Policies;
use Illuminate\Foundation\Http\FormRequest;
class SubscriptionRequest extends FormRequest {

    public function authorize(): bool { 
        return true; 
    }

    public function rules(): array { 
        return [
            'subscription_name'=>['required','string','max:190'],
            'provider_name'=>['required','string','max:190'],
            'category'=>['nullable','string','max:100'],
            'subscription_type'=>['nullable','string','max:80'],
            'tier'=>['nullable','string','max:100'],
            'benefits'=>['nullable','string','max:5000'],
            'contact_name'=>['nullable','string','max:190'],
            'contact_email'=>['nullable','email','max:190'],
            'start_date'=>['nullable','date'],
            'renewal_date'=>['required','date'],
            'billing_cycle'=>['required','in:monthly,quarterly,half_yearly,yearly,one_time,custom'],
            'seat_count'=>['nullable','integer','min:0'],
            'used_seats'=>['nullable','integer','min:0','lte:seat_count'],
            'unit_cost'=>['nullable','numeric','min:0','decimal:0,2'],
            'annual_cost'=>['required','numeric','min:0','decimal:0,2'],
            'currency'=>['nullable','string','size:3'],
            'credential_username'=>['nullable','string','max:190'],
            'credential_secret'=>['nullable','string','max:1000'],
            'notes'=>['nullable','string','max:5000']
        ]; 
    }
}
