<?php
namespace App\Http\Requests\Policies;
use Illuminate\Foundation\Http\FormRequest;
class AmountPaymentRequest extends FormRequest {

    public function authorize(): bool { 
        return true; 
    }

    public function rules(): array { 
        return [
            'amount'=>['required','numeric','gt:0','decimal:0,2'],
            'paid_at'=>['nullable','date'],
            'payment_mode'=>['nullable','string','max:60'],
            'reference_no'=>['nullable','string','max:120'],
            'idempotency_key'=>['nullable','uuid'],
            'notes'=>['nullable','string','max:2000']
        ]; 
    }
}
