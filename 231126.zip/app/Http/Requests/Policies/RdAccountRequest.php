<?php
namespace App\Http\Requests\Policies;
use Illuminate\Foundation\Http\FormRequest;
class RdAccountRequest extends FormRequest {
    public function authorize(): bool { 
        return true; 
    }
    public function rules(): array { 
        return [
            'account_name'=>['required','string','max:190'],
            'bank_name'=>['required','string','max:190'],
            'account_number'=>['nullable','string','max:100'],
            'opening_date'=>['required','date'],
            'maturity_date'=>['required','date','after:opening_date'],
            'tenure_months'=>['required','integer','min:1','max:600'],
            'monthly_installment'=>['required','numeric','gt:0','decimal:0,2'],
            'interest_rate_pa'=>['required','numeric','min:0','max:100','decimal:0,4'],
            'interest_method'=>['required','in:bank_confirmed'],
            'maturity_value'=>['nullable','numeric','min:0','decimal:0,2'],
            'interest_earned'=>['nullable','numeric','min:0','decimal:0,2'],
            'notes'=>['nullable','string','max:5000']
        ]; 
    }
}
