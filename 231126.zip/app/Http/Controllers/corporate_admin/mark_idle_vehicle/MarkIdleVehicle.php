<?php

namespace App\Http\Controllers\corporate_admin\mark_idle_vehicle;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\MarkIdleModel;
use App\Models\MarkIdleVehicleModel;
class MarkIdleVehicle extends Controller
{
    public function ListIdleVehicle(Request $request)
    {
        $categorylist = MarkIdleVehicleModel::select(
            'egc_crpt_mark_idle_vehicle.*',
            'egc_crpt_mark_idle_reason.idle_reason_id as idle_reason_id')->join('egc_crpt_mark_idle_reason','egc_crpt_mark_idle_reason.sno','=','egc_crpt_mark_idle_vehicle.idle_reason_id')
        ->where('egc_crpt_mark_idle_vehicle.status','!=',2)->orderBy('egc_crpt_mark_idle_vehicle.sno','desc')->get();
        return view('content.corporate_admin.vehicle_management.asset_list',['categorylist' => $categorylist]);
    }
    public function StoreIdle(Request $request)
    {
        $validator = Validator::make($request->all(),['idle_reason_id' => ['required','integer','exists:egc_crpt_mark_idle_reason,sno',],'effective_date' => ['required','date',],'effective_return' => ['required','date','after_or_equal:effective_date',],'notes' => ['required','string','max:2000',],],
             [
                'idle_reason_id.required' =>'Reason is required.',
                'idle_reason_id.exists' =>'Selected reason is invalid.',
                'effective_date.required' =>'Effective date is required.',
                'effective_date.date' =>'Please enter a valid effective date.',
                'effective_return.required' =>'Expected return date is required.',
                'effective_return.date' =>'Please enter a valid expected return date.',
                'effective_return.after_or_equal' =>'Expected return date must be on or after the effective date.',
                'notes.required' =>'Notes are required.',
                'notes.max' =>'Notes may not be greater than 2000 characters.',
            ]
        );
        if ($validator->fails()) {
            return response()->json(
                [
                    'status' => 422,
                    'message' => 'Validation failed.',
                    'error_msg' => $validator->errors(),
                    'errors' => $validator->errors(),
                    'data' => null,
                ],
                422
            );
        }
        $idleVehicle = new MarkIdleVehicleModel();
        $idleVehicle->idle_reason_id =$request->idle_reason_id;
        $idleVehicle->effective_date =date('Y-m-d',strtotime($request->input('effective_date')));
        $idleVehicle->effective_return =date('Y-m-d',strtotime($request->input('effective_return')));
        $idleVehicle->notes =$request->notes;
        $userId = auth()->id() ?? 1;
        $idleVehicle->created_by = $userId;
        $idleVehicle->updated_by = $userId;
        $idleVehicle->status = 0;
        $idleVehicle->save();
        return response()->json(
            [
                'status' => 200,
                'message' =>
                    'Vehicle marked idle successfully!',
                'data' => $idleVehicle,
            ],
            200
        );
    }
    public function ListReason()
    {
        $dispositions = MarkIdleModel::where('status',0)->get();
        return response()->json(
            [
                'status' => 200,
                'message' => null,
                'error_msg' => null,
                'data' => $dispositions,
            ],
            200
        );
    }
}
