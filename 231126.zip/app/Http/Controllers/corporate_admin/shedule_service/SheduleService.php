<?php
namespace App\Http\Controllers\corporate_admin\shedule_service;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WorkshopModel;
use App\Models\TriggerModel;
use App\Models\SheduleServiceModel;
use Illuminate\Support\Facades\Validator;
class SheduleService extends Controller
{
    public function index(Request $request)
    {
        $categorylist = SheduleServiceModel::select('egc_crpt_schedule_service.*','egc_crpt_trigger_vehicle.trigger_name as trigger_name','egc_crpt_workshop_vehicle.workshop_name	 as workshop_name')
        ->join('egc_crpt_trigger_vehicle','egc_crpt_trigger_vehicle.sno','=','egc_crpt_schedule_service.trigger_id')
        ->join('egc_crpt_workshop_vehicle','egc_crpt_workshop_vehicle.sno','=','egc_crpt_schedule_service.workshop_id')
        ->where('egc_crpt_schedule_service.status', '!=', 2)->orderBy('egc_crpt_schedule_service.sno', 'desc');
        return view('content.corporate_admin.vehicle_management.asset_list',['categorylist' => $categorylist]);
    }
    public function StoreStore(Request $request)
{
    $validator = Validator::make(
        $request->all(),
        [
            'vehicle_id' => ['required','integer','exists:egc_crpt_vechicle_management,sno',],
            'trigger_id' => ['required','integer','exists:egc_crpt_trigger_vehicle,sno',],
            'workshop_id' => ['required','integer','exists:egc_crpt_workshop_vehicle,sno',],
            'shedule_date' => ['required','date',],
            'down_time' => ['required'],
        ],
        [
            'vehicle_id.required' => 'Vehicle is required.',
            'vehicle_id.integer' =>'Invalid vehicle.',
            'vehicle_id.exists' =>  'Selected vehicle does not exist.',
            'trigger_id.required' => 'Trigger is required.',
            'trigger_id.integer' => 'Invalid trigger.',
            'trigger_id.exists' =>  'Selected trigger does not exist.',
            'workshop_id.required' =>  'Workshop is required.',
            'workshop_id.integer' => 'Invalid workshop.',
            'workshop_id.exists' =>  'Selected workshop does not exist.',
            'shedule_date.required' =>  'Scheduled date is required.',
            'shedule_date.date' =>  'Invalid scheduled date.',
            'down_time.required' => 'Estimated downtime is required.',
        ]
    );
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation failed.',
            'error_msg' => $validator->errors(),
            'errors' => $validator->errors(),
            'data' => null,
        ], 422);
    }
    $sheduleservice = new SheduleServiceModel();
    $sheduleservice->vehicle_id =$request->vehicle_id;
    $sheduleservice->trigger_id = $request->trigger_id;
    $sheduleservice->workshop_id = $request->workshop_id;
    $sheduleservice->shedule_date = date('Y-m-d',strtotime($request->input('shedule_date')));
    $sheduleservice->down_time = date('H:i:s',strtotime($request->input('down_time')));
    $userId = $request->user()->userId ?? 1;
    $sheduleservice->created_by = $userId;
    $sheduleservice->updated_by = $userId;
    $sheduleservice->status = 0;
    $sheduleservice->save();
    return response()->json([
        'status' => 200,
        'message' => 'Service scheduled successfully!',
        'data' => $sheduleservice,
    ], 200);
}
    public function Listtrigger()
    {
        $channel_type = TriggerModel::where('status', 0)->get();
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $channel_type,
        ], 200);
    }
    public function Listworkshop()
    {
        $channel_type = WorkshopModel::where('status', 0)->get();
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $channel_type,
        ], 200);
    }
}
