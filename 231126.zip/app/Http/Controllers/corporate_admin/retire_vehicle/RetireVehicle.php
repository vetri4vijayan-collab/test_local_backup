<?php

namespace App\Http\Controllers\corporate_admin\retire_vehicle;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DispositionModel;
use App\Models\BuyerModel;
use App\Models\RetireVehicleModel;
use Illuminate\Support\Facades\Validator;

class RetireVehicle extends Controller
{
    public function ListRetireVehicle(Request $request)
    {
        $categorylist = RetireVehicleModel::select('egc_crpt_retire_vehicle.*','egc_crpt_buyer_scrap_dealer.buyer_name as buyer_name','egc_crpt_dispostion_vehicles.disposition_type as disposition_type')
        ->join('egc_crpt_buyer_scrap_dealer','egc_crpt_buyer_scrap_dealer.sno','=','egc_crpt_retire_vehicle.buyer_id')
        ->join('egc_crpt_dispostion_vehicles','egc_crpt_dispostion_vehicles.sno','=','egc_crpt_retire_vehicle.dispostion_id')
        ->where('egc_crpt_retire_vehicle.status', '!=', 2)
        ->orderBy('egc_crpt_retire_vehicle.sno', 'desc');
        return view('content.corporate_admin.vehicle_management.asset_list',['categorylist' => $categorylist]);
    }
     public function StoreRetire(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'buyer_id' =>'required|integer|exists:egc_crpt_buyer_scrap_dealer,sno',
                'dispostion_id' =>'required|integer|exists:egc_crpt_dispostion_vehicles,sno',
                'effective_date' =>'required|date',
                'sale_value' =>'required|numeric|min:0',
                'disposal_document' =>'required|file|mimes:pdf,jpg,jpeg,png,doc,docx|max:10240',
                'reason' =>'required|string|max:2000',
            ],
            [
                'buyer_id.required' =>'Buyer / scrap dealer is required.',
                'buyer_id.integer' =>'Invalid buyer / scrap dealer.',
                'buyer_id.exists' => 'Selected buyer / scrap dealer does not exist.',
                'dispostion_id.required' => 'Disposition is required.',
                'dispostion_id.integer' =>'Invalid disposition.',
                'dispostion_id.exists' =>'Selected disposition does not exist.',
                'effective_date.required' =>'Effective date is required.',
                'effective_date.date' => 'Invalid effective date.',
                'sale_value.required' =>'Sale value is required.',
                'sale_value.numeric' => 'Sale value must be a number.',
                'sale_value.min' =>'Sale value cannot be negative.',
                'disposal_document.required' => 'Disposal document is required.',
                'disposal_document.file' => 'Invalid disposal document.',
                'disposal_document.mimes' => 'Disposal document must be PDF, JPG, JPEG, PNG, DOC or DOCX.',
                'disposal_document.max' =>'Disposal document must not exceed 10 MB.',
                'reason.required' =>'Reason / Justification is required.',
                'reason.string' =>'Reason / Justification must be valid text.',
                'reason.max' => 'Reason / Justification cannot exceed 2000 characters.'
            ]
        );
        if ($validator->fails()) {
            return response()->json(
                [
                    'status' => 422,
                    'message' => 'Validation failed',
                    'error_msg' =>$validator->errors(),
                    'errors' =>$validator->errors(),
                    'data' => null,
                ],
                422
            );
        }
        $documentPath = null;
        if ($request->hasFile('disposal_document')) {
            $file = $request->file('disposal_document');
            $fileName =time() . '_' .$file->getClientOriginalName();
            $documentPath =$file->storeAs('retire_vehicle',$fileName,'public');
        }
        $retireVehicle =new RetireVehicleModel();
        $retireVehicle->dispostion_id =$request->dispostion_id;
        $retireVehicle->buyer_id =$request->buyer_id;
        $retireVehicle->effective_date = date('Y-m-d',strtotime($request->input('effective_date')));
        $retireVehicle->sale_value =str_replace(',','',$request->sale_value);
        $retireVehicle->disposal_document =$documentPath;
        $retireVehicle->reason =$request->reason;
        $userId =$request->user()->userId ?? 1;
        $retireVehicle->created_by =$userId;
        $retireVehicle->updated_by =$userId;
        $retireVehicle->status =0;
        $retireVehicle->save();
        return response()->json(
            [
                'status' => 200,
                'message' =>
                    'Vehicle retired successfully!',
                'data' =>
                    $retireVehicle,
            ],
            200
        );
    }
    public function ListBuyer()
    {
        $channel_type = BuyerModel::where('status', 0)->get();
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $channel_type,
        ], 200);
    }
    public function Listworkshop()
    {
        $channel_type = WorkshopModel::where('status', 0)->get();
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $channel_type,
        ], 200);
    }
    public function ListDisposition()
{
    $dispositions = DispositionModel::where('status', 0)->get();
    return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $dispositions,
    ], 200);
}
}
