<?php

namespace App\Http\Controllers\corporate_admin\FuelLog;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ChannelModel;
use App\Models\FuelLogModel;
use Illuminate\Support\Facades\Validator;
class FuelLog extends Controller
{
    public function index(Request $request)
    {
        $categorylist = FuelLogModel::select('egc_crpt_fuel_log.*','egc_crpt_channel.channel_name as channel_name')
        ->join('egc_crpt_channel','egc_crpt_channel.sno','=','egc_crpt_fuel_log.channel_id')
        ->where('egc_crpt_fuel_log.status', '!=', 2)
        ->orderBy('egc_crpt_fuel_log.sno', 'desc');
        return view('content.corporate_admin.vehicle_management.asset_list',['categorylist' => $categorylist]);
    }
    public function LogStore(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'vehicle_id' => 'required|integer',
            'channel_id' => 'required|integer',
            'log_date_time' => 'required',
            'log_liters' => 'required|numeric|min:0',
            'log_amount' => 'required|numeric|min:0',
            'log_odometer' => 'required|numeric|min:0',
            'log_station' => 'required|string|max:255',
            'document_attachement' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status'    => 422,
                'message'   => 'Validation failed',
                'error_msg' => $validator->errors(),
                'data'      => null,
            ], 422);
        }
        $fuelLog = new FuelLogModel();
        $fuelLog->vehicle_id = $request->vehicle_id;
        $fuelLog->channel_id = $request->channel_id;
        $fuelLog->log_date_time = date('Y-m-d H:i:s',strtotime($request->log_date_time));
        $fuelLog->log_liters = $request->log_liters;
        $fuelLog->log_amount = $request->log_amount;
        $fuelLog->log_odometer = $request->log_odometer;
        $fuelLog->log_station = $request->log_station;
        $userId = $request->user()->userId ?? 1;
        $fuelLog->created_by = $userId;
        $fuelLog->updated_by = $userId;
        $fuelLog->status = 0;
        if ($request->hasFile('document_attachement')) {
            $file = $request->file('document_attachement');
            $uploadPath = public_path('uploads/vehicle_documents');
            if (!file_exists($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $fileName =time(). '_document_'. uniqid(). '.'. $file->getClientOriginalExtension();
            $file->move($uploadPath, $fileName);
            $fuelLog->document_attachement = $fileName;
        }
        $fuelLog->save();
        return response()->json([
            'status'  => 200,
            'message' => 'Fuel log added successfully!',
            'data'    => $fuelLog,
        ], 200);
    }
    public function Listchannel()
    {
        $channel_type = ChannelModel::where('status', 0)->get();
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $channel_type,
        ], 200);
    }
}
