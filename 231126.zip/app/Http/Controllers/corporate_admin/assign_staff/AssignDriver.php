<?php

namespace App\Http\Controllers\corporate_admin\assign_staff;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FuelModel;
use App\Models\ChannelModel;
use App\Models\StaffModel;
use App\Models\DepartmentModel;
use App\Models\AssignstaffModel;
use Illuminate\Support\Facades\Validator;
class AssignDriver extends Controller
{
    public function index(Request $request){
    $categorylist = VechicleManagementModel::select('egc_staff.nick_name as nick_name')->join('egc_staff','egc_staff.sno', '=', 'egc_crpt_assign_staff.staff_id')->where('egc_crpt_assign_staff.status', '!=', 2)->orderBy('egc_crpt_assign_staff.sno', 'desc');
    return view('content.corporate_admin.vehicle_management.asset_list', ['categorylist' => $categorylist]);
    }
    public function AssignAdd(Request $request)
    {
        $validator = Validator::make($request->all(),['vehicle_id' => 'required|integer','staff_id'   => 'required|integer',]);
        if ($validator->fails()) {
            return response()->json([
                'status'    => 422,
                'message'   => 'Validation failed',
                'error_msg' => $validator->errors(),
                'data'      => null,
            ], 422);
        }

        $vehicleId = $request->vehicle_id;
        $staffId   = $request->staff_id;
        $userId = $request->user()->userId ?? 1;
        $existingAssignment = AssignstaffModel::where('vehicle_id',$vehicleId)->where('status',0)->first();
        if ($existingAssignment) {
            return response()->json([
                'status'  => 409,
                'message' => 'A driver is already assigned to this vehicle.',
                'data'    => $existingAssignment,
            ], 409);
        }
        $assignment = new AssignstaffModel();
        $assignment->vehicle_id = $vehicleId;
        $assignment->staff_id   = $staffId;
        $assignment->created_by = $userId;
        $assignment->updated_by = $userId;
        $assignment->status     = 0;
        $assignment->save();
        return response()->json([
            'status'  => 200,
            'message' => 'Driver assigned successfully!',
            'error_msg' => null,
            'data'    => $assignment,
        ], 200);
    }
     public function ListAssigndriver()
  {
    $driver = StaffModel::where('status', 0)->where('egc_staff.job_role_id', '=', 27)->get();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $driver,
    ], 200);
  }
}
