<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SubscriptionAndOthers extends Controller
{
  public function index()
  {
      $user = Auth::user();
      abort_unless($user && $user->hasPermission('Corporate Admin', 'Policies & RD Accounts', 'Manage Subscriptions'), 403);
      return view('content.corporate_admin.Policies_and_yerd.subscription_and_others.subscription_list');
  }

}
