<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use App\Http\Requests\Policies\{PolicyContractRequest,SubscriptionRequest,RdAccountRequest,AmountPaymentRequest,MasterRequest};
use App\Http\Resources\Policies\{PolicyContractResource,SubscriptionResource,RdAccountResource};
use App\Models\Policies\{PolicyContract,Subscription,RdAccount,RdInstallment,InsuranceClaim,PolicySurrender,AmcMaintenance,AmcServiceReport,PolicyDocument};
use App\Services\Policies\PoliciesAccountsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class PoliciesAccountsController extends Controller
{
    public function __construct(private PoliciesAccountsService $service) {}

    private function guard(string $section): void
    {
        $user=auth()->user();
        abort_unless($user && $user->hasPermission('Corporate Admin','Policies & RD Accounts',$section),403);
    }
    private function guardMasterType(?string $type): void
    {
        $section=match($type){
            'subscription_type'=>'Manage Subscriptions',
            'rd_bank'=>'Manage RD',
            'payment_frequency','claim_type','maintenance_type'=>'Manage Insurance & AMC',
            default=>null
        };
        if($section) { $this->guard($section); return; }
        if(in_array($type,['provider','category'],true)) {
            $user=auth()->user();
            abort_unless($user && (
                $user->hasPermission('Corporate Admin','Policies & RD Accounts','Manage Insurance & AMC') ||
                $user->hasPermission('Corporate Admin','Policies & RD Accounts','Manage Subscriptions')
            ),403);
            return;
        }
        $user=auth()->user();
        abort_unless($user && (
            $user->hasPermission('Corporate Admin','Policies & RD Accounts','Manage Insurance & AMC') ||
            $user->hasPermission('Corporate Admin','Policies & RD Accounts','Manage Subscriptions') ||
            $user->hasPermission('Corporate Admin','Policies & RD Accounts','Manage RD')
        ),403);
    }
    private function guardType(string $type): void
    {
        $section=match($type){
            'insurance','amc'=>'Manage Insurance & AMC',
            'subscription'=>'Manage Subscriptions',
            'rd'=>'Manage RD',
            default=>abort(404)
        };
        $this->guard($section);
    }

    private function moneyGreaterThan($left,$right): bool
    {
        $result=DB::selectOne('SELECT CAST(? AS DECIMAL(18,2)) > CAST(? AS DECIMAL(18,2)) AS result',[(string)$left,(string)$right]);
        return (int)$result->result===1;
    }

    public function index(string $type,Request $request) { $this->guardType($type);
        $rows=$this->service->list($type,$request->only(['search','status','from_date','to_date','per_page']));
        $resource=match($type){'insurance','amc'=>PolicyContractResource::collection($rows),'subscription'=>SubscriptionResource::collection($rows),'rd'=>RdAccountResource::collection($rows),default=>abort(404)};
        return response()->json(['success'=>true,'data'=>$resource,'meta'=>[
            'current_page'=>$rows->currentPage(),'last_page'=>$rows->lastPage(),'per_page'=>$rows->perPage(),'total'=>$rows->total()
        ]]);
    }

    public function store(string $type,Request $request) { $this->guardType($type);
        $data=match($type){
            'insurance','amc'=>$request->validate((new PolicyContractRequest())->rules()),
            'subscription'=>$request->validate((new SubscriptionRequest())->rules()),
            'rd'=>$request->validate(array_replace((new RdAccountRequest())->rules(),['account_number'=>['required','string','max:100']])), 
            default=>abort(404)
        };
        $row=$this->service->create($type,$data);
        $resource=match($type){'insurance','amc'=>new PolicyContractResource($row),'subscription'=>new SubscriptionResource($row),'rd'=>new RdAccountResource($row)};
        return response()->json(['success'=>true,'message'=>'Record created successfully.','data'=>$resource],201);
    }

    public function show(string $type,int $id) { $this->guardType($type);
        $row=$this->service->find($type,$id);
        $resource=match($type){'insurance','amc'=>new PolicyContractResource($row),'subscription'=>new SubscriptionResource($row),'rd'=>new RdAccountResource($row)};
        return response()->json(['success'=>true,'data'=>$resource]);
    }

    public function update(string $type,int $id,Request $request) { $this->guardType($type);
        $rules=match($type){
            'insurance','amc'=>(new PolicyContractRequest())->rules(),
            'subscription'=>(new SubscriptionRequest())->rules(),
            'rd'=>(new RdAccountRequest())->rules(), default=>abort(404)
        };
        $row=$this->service->update($type,$id,$request->validate($rules));
        $resource=match($type){'insurance','amc'=>new PolicyContractResource($row),'subscription'=>new SubscriptionResource($row),'rd'=>new RdAccountResource($row)};
        return response()->json(['success'=>true,'message'=>'Record updated successfully.','data'=>$resource]);
    }

    public function destroy(string $type,int $id) { $this->guardType($type);
        $this->service->archive($type,$id);
        return response()->json(['success'=>true,'message'=>'Record archived successfully.']);
    }

    public function dashboard() { $this->guard('Executive Dashbaord'); return response()->json(['success'=>true,'data'=>$this->service->dashboard()]); }

    public function renewals(Request $request) { $this->guard('Manage Renewal Calendar');
        $filters=$request->validate(['from'=>['nullable','date'],'to'=>['nullable','date','after_or_equal:from'],'status'=>['nullable','in:0,1,2'],'per_page'=>['nullable','integer','min:10','max:100'],'search'=>['nullable','string','max:190']]);
        $q=$this->service->table('egc_policy_renewals')->where('status',(int)($filters['status']??1));
        if($request->filled('from')) $q->whereDate('due_date','>=',$request->input('from'));
        if($request->filled('to')) $q->whereDate('due_date','<=',$request->input('to'));
        if($request->filled('search')) $q->where(function($w)use($request){$w->where('title','like','%'.$request->search.'%')->orWhere('provider_name','like','%'.$request->search.'%');});
        return response()->json($q->orderBy('due_date')->paginate(min(100,max(10,(int)$request->input('per_page',25))),['sno','source_type','source_id','title','provider_name','due_date','amount','status','renewed_at']));
    }


    public function closeRd(Request $request,int $id) {
        $this->guard('Manage RD'); $ctx=$this->service->context();
        $data=$request->validate([
            'close_date'=>['required','date'],'closing_value'=>['required','numeric','min:0','decimal:0,2'],
            'penalty_amount'=>['nullable','numeric','min:0','decimal:0,2'],'reason'=>['required','string','max:2000']
        ]);
        $penalty=$data['penalty_amount']??'0.00';
        $invalid=DB::selectOne('SELECT CAST(? AS DECIMAL(18,2)) > CAST(? AS DECIMAL(18,2)) AS invalid',[$penalty,$data['closing_value']])->invalid;
        if((int)$invalid===1) return response()->json(['message'=>'Penalty cannot exceed closing value.'],422);
        $account=DB::transaction(function()use($ctx,$id,$data,$penalty){
            $account=RdAccount::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->lockForUpdate()->findOrFail($id);
            abort_unless((int)$account->status===1,409,'RD account is already closed.');
            $exists=DB::table('egc_policy_rd_closures')->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('account_id',$id)->exists();
            abort_if($exists,409,'A closure record already exists for this RD account.');
            $net=DB::selectOne('SELECT CAST(? AS DECIMAL(18,2)) - CAST(? AS DECIMAL(18,2)) AS net',[$data['closing_value'],$penalty])->net;
            $data['penalty_amount']=$penalty;
            $closure=\App\Models\Policies\RdClosure::create(array_merge($data,['company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'account_id'=>$id,'net_payable'=>$net,'created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()]));
            $account->update(['status'=>2,'updated_by'=>$ctx['user_id']]);
            $this->service->table('egc_policy_renewals')->where('source_type','rd')->where('source_id',$id)->update(['status'=>0,'updated_at'=>now()]);
            $this->service->logAction('rd_closed','rd_account',$id,null,$closure->toArray());
            return $closure;
        });
        return response()->json(['success'=>true,'data'=>$account],201);
    }

    public function rdSchedule(Request $request) { $this->guard('Manage RD');
        $request->validate(['month'=>['nullable','date_format:Y-m'],'per_page'=>['nullable','integer','min:10','max:100']]);
        $ctx=$this->service->context();
        $q=DB::table('egc_policy_rd_installments as i')
            ->join('egc_policy_rd_accounts as a','a.sno','=','i.account_id')
            ->where('i.company_id',$ctx['company_id'])->where('i.entity_id',$ctx['entity_id'])
            ->where('a.company_id',$ctx['company_id'])->where('a.entity_id',$ctx['entity_id'])
            ->where('a.status',1)
            ->select('i.sno','i.account_id','i.installment_no','i.due_date','i.due_amount','i.paid_amount','i.status','a.account_name','a.bank_name')
            ->orderBy('i.due_date');
        if($request->filled('month')) $q->whereRaw("DATE_FORMAT(i.due_date,'%Y-%m') = ?",[$request->input('month')]);
        return response()->json($q->paginate(min(100,max(10,(int)$request->input('per_page',25)))));
    }

    public function completeRenewal(int $id) { $this->guard('Manage Renewal Calendar');
        $ctx=$this->service->context();
        $row=$this->service->table('egc_policy_renewals')->where('sno',$id)->where('status',1)->first();
        abort_unless($row,404);
        $this->service->table('egc_policy_renewals')->where('sno',$id)->update(['status'=>2,'renewed_at'=>now()->toDateString(),'updated_at'=>now()]);
        $this->service->logAction('renewal_processed','renewal',$id,(array)$row,['status'=>2,'renewed_at'=>now()->toDateString()]);
        return response()->json(['success'=>true,'message'=>'Renewal marked as processed.']);
    }

    public function masters(Request $request) { $this->guardMasterType($request->query('type'));
        return response()->json(['success'=>true,'data'=>$this->service->masters($request->query('type'))]);
    }
    public function saveMaster(MasterRequest $request,?int $id=null) { $this->guardMasterType($request->input('master_type'));
        $row=$this->service->saveMaster($request->validated(),$id);
        return response()->json(['success'=>true,'data'=>$row],$id?200:201);
    }
    public function deleteMaster(int $id) {
        $ctx=$this->service->context();
        $row=$this->service->table('egc_policy_masters')->where('sno',$id)->first();
        abort_unless($row,404); $this->guardMasterType($row->master_type);
        $this->service->table('egc_policy_masters')->where('sno',$id)->update(['status'=>0,'updated_by'=>$ctx['user_id'],'updated_at'=>now()]);
        $this->service->logAction('master_archived','master',$id,(array)$row,null);
        return response()->json(['success'=>true,'message'=>'Master archived.']);
    }

    public function rdInstallments(int $id) { $this->guard('Manage RD');
        $ctx=$this->service->context();
        $account=RdAccount::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->findOrFail($id);
        $account->makeHidden(['account_number_encrypted','account_number_hash']);
        $rows=DB::table('egc_policy_rd_installments')->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('account_id',$id)
            ->select('sno','account_id','installment_no','due_date','due_amount','paid_amount','status')->selectRaw('CAST(due_amount - paid_amount AS CHAR) AS balance')->orderBy('installment_no')->paginate(50);
        return response()->json(['success'=>true,'account'=>new RdAccountResource($account),'data'=>$rows]);
    }
    public function rdTransactions(int $id) {
        $this->guard('Manage RD'); $ctx=$this->service->context();
        $this->service->find('rd',$id);
        $rows=DB::table('egc_policy_rd_transactions')->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('account_id',$id)->orderByDesc('paid_at')
            ->paginate(50,['sno','account_id','installment_id','transaction_type','amount','paid_at','payment_mode','reference_no','reversal_of','notes']);
        return response()->json($rows);
    }

    public function rdPayment(AmountPaymentRequest $request,int $id,int $installment) { $this->guard('Manage RD');
        $row=$this->service->recordRdPayment($id,$installment,$request->validated());
        return response()->json(['success'=>true,'message'=>'RD payment recorded.','data'=>$row],201);
    }
    public function reverseRdPayment(Request $request,int $transactionId) {
        $this->guard('Manage RD');
        $data=$request->validate(['reason'=>['required','string','max:1000']]);
        $row=$this->service->reverseRdPayment($transactionId,$data['reason']);
        return response()->json(['success'=>true,'message'=>'RD payment reversed with an immutable ledger entry.','data'=>$row]);
    }

    public function subscriptionPayments(Request $request) {
        $this->guard('Manage Subscriptions'); $ctx=$this->service->context();
        $q=DB::table('egc_policy_subscription_payments as p')
            ->join('egc_policy_subscriptions as s','s.sno','=','p.subscription_id')
            ->where('p.company_id',$ctx['company_id'])->where('p.entity_id',$ctx['entity_id'])
            ->select('p.sno','p.paid_at','p.reference_no','p.payment_mode','p.amount','s.subscription_name')
            ->orderByDesc('p.paid_at');
        return response()->json($q->paginate(min(100,max(10,(int)$request->input('per_page',25)))));
    }

    public function subscriptionPayment(AmountPaymentRequest $request,int $id) { $this->guard('Manage Subscriptions');
        $row=$this->service->recordSubscriptionPayment($id,$request->validated());
        return response()->json(['success'=>true,'message'=>'Subscription payment recorded.','data'=>$row],201);
    }

    public function contractPayments(string $type,int $id) {
        $this->guardType($type);
        abort_unless(in_array($type,['insurance','amc'],true),404);
        return response()->json($this->service->contractPayments($type,$id));
    }
    public function storeContractPayment(Request $request,string $type,int $id) {
        $this->guardType($type);
        abort_unless(in_array($type,['insurance','amc'],true),404);
        $data=$request->validate([
            'payment_kind'=>['required','in:premium,amc_fee,other'],'due_date'=>['nullable','date'],
            'amount'=>['required','numeric','gt:0','decimal:0,2'],'paid_at'=>['nullable','date'],
            'payment_mode'=>['nullable','string','max:60'],'reference_no'=>['nullable','string','max:120'],
            'idempotency_key'=>['nullable','uuid'],'notes'=>['nullable','string','max:2000']
        ]);
        $row=$this->service->recordContractPayment($type,$id,$data);
        return response()->json(['success'=>true,'data'=>$row],201);
    }

    public function claims(Request $request,int $contractId) { $this->guard('Manage Insurance & AMC');
        $ctx=$this->service->context();
        $this->service->find('insurance',$contractId);
        $q=InsuranceClaim::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('contract_id',$contractId)->orderByDesc('sno');
        return response()->json($q->paginate(25,['sno','contract_id','claim_number','claim_type','claim_date','claimed_amount','approved_amount','settled_amount','status','notes']));
    }
    public function updateClaim(Request $request,int $contractId,int $claimId) {
        $this->guard('Manage Insurance & AMC'); $ctx=$this->service->context();
        $this->service->find('insurance',$contractId);
        $claim=InsuranceClaim::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('contract_id',$contractId)->findOrFail($claimId);
        $data=$request->validate([
            'approved_amount'=>['sometimes','numeric','min:0','decimal:0,2'],
            'settled_amount'=>['sometimes','numeric','min:0','decimal:0,2'],
            'status'=>['sometimes','in:submitted,under_review,approved,rejected,settled'],
            'notes'=>['sometimes','nullable','string','max:5000']
        ]);
        $approved=$data['approved_amount']??$claim->approved_amount;
        $settled=$data['settled_amount']??$claim->settled_amount;
        if($this->moneyGreaterThan($approved,$claim->claimed_amount)) return response()->json(['message'=>'Approved amount cannot exceed claimed amount.'],422);
        if($this->moneyGreaterThan($settled,$approved)) return response()->json(['message'=>'Settled amount cannot exceed approved amount.'],422);
        $before=$claim->toArray(); $claim->update($data+['updated_by'=>$ctx['user_id']]);
        $this->service->logAction('claim_updated','claim',$claimId,$before,$claim->fresh()->toArray());
        return response()->json(['success'=>true,'data'=>$claim->fresh()]);
    }

    public function storeClaim(Request $request,int $contractId) { $this->guard('Manage Insurance & AMC');
        $data=$request->validate([
            'claim_number'=>['nullable','string','max:100'],'claim_type'=>['required','string','max:100'],
            'claim_date'=>['required','date'],'claimed_amount'=>['required','numeric','gt:0','decimal:0,2'],
            'approved_amount'=>['nullable','numeric','min:0','decimal:0,2'],'settled_amount'=>['nullable','numeric','min:0','decimal:0,2'],
            'status'=>['required','in:submitted,under_review,approved,rejected,settled'],'notes'=>['nullable','string','max:5000']
        ]);
        $data['approved_amount']=$data['approved_amount']??'0.00';
        $data['settled_amount']=$data['settled_amount']??'0.00';
        if($this->moneyGreaterThan($data['approved_amount'],$data['claimed_amount'])) return response()->json(['message'=>'Approved amount cannot exceed claimed amount.'],422);
        if($this->moneyGreaterThan($data['settled_amount'],$data['approved_amount'])) return response()->json(['message'=>'Settled amount cannot exceed approved amount.'],422);
        $row=$this->service->createClaim($contractId,$data);
        return response()->json(['success'=>true,'data'=>$row],201);
    }

    public function surrender(Request $request,int $contractId) { $this->guard('Manage Insurance & AMC');
        $ctx=$this->service->context(); $contract=$this->service->find('insurance',$contractId);
        abort_unless((int)$contract->status===1,409,'Policy is not active.');
        $data=$request->validate([
            'surrender_date'=>['required','date'],'surrender_value'=>['required','numeric','min:0','decimal:0,2'],
            'penalty_amount'=>['nullable','numeric','min:0','decimal:0,2'],'reason'=>['required','string','max:2000']
        ]);
        $penalty=$data['penalty_amount']??'0.00';
        $invalidPenalty=DB::selectOne('SELECT CAST(? AS DECIMAL(18,2)) > CAST(? AS DECIMAL(18,2)) AS invalid',[$penalty,$data['surrender_value']])->invalid;
        if ((int)$invalidPenalty===1) {
            return response()->json(['message'=>'Penalty cannot exceed surrender value.'],422);
        }
        // Monetary subtraction is executed by the DECIMAL database engine, not PHP float arithmetic.
        $row=DB::transaction(function()use($ctx,$contract,$data,$penalty){
            $net=DB::selectOne('SELECT CAST(? AS DECIMAL(18,2)) - CAST(? AS DECIMAL(18,2)) AS net',[$data['surrender_value'],$penalty])->net;
            $data['penalty_amount']=$penalty;
            $s=PolicySurrender::create(array_merge($data,['company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'contract_id'=>$contract->sno,'net_payable'=>$net,'created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()]));
            $contract->update(['status'=>0,'updated_by'=>$ctx['user_id']]);
            $this->service->table('egc_policy_renewals')->where('source_type','insurance')->where('source_id',$contract->sno)->update(['status'=>0,'updated_at'=>now()]);
            $this->service->logAction('policy_surrendered','insurance',$contract->sno,null,$s->toArray());
            return $s;
        });
        return response()->json(['success'=>true,'data'=>$row],201);
    }

    public function maintenance(Request $request,int $contractId) { $this->guard('Manage Insurance & AMC');
        $ctx=$this->service->context(); $contract=$this->service->find('amc',$contractId);
        $q=AmcMaintenance::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('contract_id',$contract->sno)->orderBy('scheduled_at');
        return response()->json($q->paginate(25,['sno','contract_id','maintenance_type','scheduled_at','completed_at','estimated_cost','actual_cost','assigned_to','status','notes']));
    }
    public function storeMaintenance(Request $request,int $contractId) { $this->guard('Manage Insurance & AMC');
        $ctx=$this->service->context(); $contract=$this->service->find('amc',$contractId);
        abort_unless((int)$contract->status===1,409,'AMC contract is not active.');
        $data=$request->validate(['maintenance_type'=>['required','string','max:100'],'scheduled_at'=>['required','date'],'estimated_cost'=>['nullable','numeric','min:0','decimal:0,2'],'assigned_to'=>['nullable','string','max:190'],'notes'=>['nullable','string','max:5000']]);
        $data['estimated_cost']=$data['estimated_cost']??'0.00';
        $row=AmcMaintenance::create($data+['company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'contract_id'=>$contract->sno,'status'=>'scheduled','created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()]);
        $this->service->logAction('maintenance_scheduled','amc',$contract->sno,null,$row->toArray());
        return response()->json(['success'=>true,'data'=>$row],201);
    }
    public function storeServiceReport(Request $request,int $contractId) { $this->guard('Manage Insurance & AMC');
        $ctx=$this->service->context(); $contract=$this->service->find('amc',$contractId);
        abort_unless((int)$contract->status===1,409,'AMC contract is not active.');
        $data=$request->validate(['maintenance_id'=>['nullable','integer'],'service_date'=>['required','date'],'service_summary'=>['required','string','max:5000'],'service_cost'=>['nullable','numeric','min:0','decimal:0,2'],'rating'=>['nullable','integer','min:1','max:5'],'next_service_date'=>['nullable','date']]);
        if(!empty($data['maintenance_id'])) abort_unless(AmcMaintenance::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('contract_id',$contractId)->where('sno',$data['maintenance_id'])->exists(),404);
        $data['service_cost']=$data['service_cost']??'0.00';
        $row=AmcServiceReport::create($data+['company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'contract_id'=>$contract->sno,'created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()]);
        if(!empty($data['maintenance_id'])) AmcMaintenance::where('sno',$data['maintenance_id'])->where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->update(['status'=>'completed','completed_at'=>now(),'actual_cost'=>$data['service_cost']??0]);
        $this->service->logAction('service_report_created','amc',$contract->sno,null,$row->toArray());
        return response()->json(['success'=>true,'data'=>$row],201);
    }

    public function documents(string $type,int $id) {
        $this->guardType($type); $ctx=$this->service->context(); $this->service->find($type,$id);
        $rows=PolicyDocument::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->where('record_type',$type)->where('record_id',$id)->orderByDesc('sno')->get(['sno','document_type','original_name','mime_type','size_bytes','created_at']);
        return response()->json(['success'=>true,'data'=>$rows]);
    }

    public function uploadDocument(Request $request,string $type,int $id) { $this->guardType($type);
        $data=$request->validate(['file'=>['required','file','max:10240','mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx'],'document_type'=>['nullable','string','max:100'],'notes'=>['nullable','string','max:1000']]);
        $ctx=$this->service->context();
        $record=$this->service->find($type,$id);
        $path=$request->file('file')->store('policies/'.$ctx['company_id'].'/'.$ctx['entity_id'],'local');
        $doc=PolicyDocument::create(['company_id'=>$ctx['company_id'],'entity_id'=>$ctx['entity_id'],'record_type'=>$type,'record_id'=>$record->sno,'document_type'=>$data['document_type']??null,'original_name'=>$request->file('file')->getClientOriginalName(),'storage_path'=>$path,'mime_type'=>$request->file('file')->getMimeType(),'size_bytes'=>$request->file('file')->getSize(),'notes'=>$data['notes']??null,'created_by'=>$ctx['user_id'],'created_at'=>now(),'updated_at'=>now()]);
        $this->service->logAction('document_uploaded',$type,$record->sno,null,$doc->toArray());
        return response()->json(['success'=>true,'data'=>$doc],201);
    }
    public function downloadDocument(int $id) {
        $ctx=$this->service->context();
        $doc=PolicyDocument::where('company_id',$ctx['company_id'])->where('entity_id',$ctx['entity_id'])->findOrFail($id);
        $this->guardType($doc->record_type);
        abort_unless(Storage::disk('local')->exists($doc->storage_path),404);
        return Storage::disk('local')->download($doc->storage_path,$doc->original_name);
    }
}
