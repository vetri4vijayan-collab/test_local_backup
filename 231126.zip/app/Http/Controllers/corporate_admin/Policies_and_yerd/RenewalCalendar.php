<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RenewalCalendar extends Controller
{
  public function index()
  {
      $user = Auth::user();
      abort_unless($user && $user->hasPermission('Corporate Admin', 'Policies & RD Accounts', 'Manage Renewal Calendar'), 403);
      return view('content.corporate_admin.Policies_and_yerd.renewal_calendar.renewal_calendar_list');
  }
}
