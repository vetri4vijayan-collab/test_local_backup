<?php

namespace App\Http\Controllers\corporate_admin\vehicle_management;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FuelModel;
use App\Models\VechicleModel;
use App\Models\BranchModel;
use App\Models\StaffModel;
use App\Models\DepartmentModel;
use Illuminate\Support\Facades\Validator;
use App\Models\VechicleManagementModel;
class VehicleMachinery extends Controller
{
   public function index(Request $request)
{
    $helper = new \App\Helpers\Helpers();
    $search_filter = $request->input('search_filter', '');
    $perpage = (int) $request->input('sorting_filter', 25);
    $latestAssignment = DB::table('egc_crpt_assign_staff as eas1')->select('eas1.vehicle_id', 'eas1.staff_id')->where('eas1.status', 0)
    ->whereRaw('
        eas1.sno = (
            SELECT MAX(eas2.sno)
            FROM egc_crpt_assign_staff as eas2
            WHERE eas2.vehicle_id = eas1.vehicle_id
            AND eas2.status = 0
        )
    ');
    $categorylist = VechicleManagementModel::select(
            'egc_crpt_vechicle_management.*','egc_crpt_fuel_type.fuel_type as fuel_type','egc_crpt_vechicle_purpose.vechicle_purpose as vechicle_purpose',
            DB::raw('
                COALESCE(
                    assigned_staff.nick_name,
                    vehicle_driver.nick_name
                ) AS nick_name
            '),
            DB::raw('
                COALESCE(
                    latest_assignment.staff_id,
                    egc_crpt_vechicle_management.driver_id
                ) AS assigned_driver_id
            '),
            \DB::raw('
                COALESCE((
                  SELECT fl.log_odometer
                  FROM egc_crpt_fuel_log fl
                  WHERE fl.vehicle_id = egc_crpt_vechicle_management.sno
                    AND fl.status = 0
                    AND fl.log_odometer IS NOT NULL
                  ORDER BY fl.log_odometer DESC
                  LIMIT 1
              ), 0) as log_odometer
            ')
        )
        ->leftJoin('egc_crpt_fuel_type', 'egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_crpt_vechicle_purpose','egc_crpt_vechicle_purpose.sno','=','egc_crpt_vechicle_management.purpose_id')
        ->leftJoin('egc_staff as vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff as assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->where('egc_crpt_vechicle_management.status','!=',2)
        ->when($search_filter != '', function ($query) use ($search_filter) {
            $query->where('egc_crpt_vechicle_management.registration_number','LIKE',"%{$search_filter}%");
        })
        ->orderBy('egc_crpt_vechicle_management.sno','desc')
        ->paginate($perpage);
    if ($request->ajax()) {
        $data = $categorylist->map(function ($item) use ($helper) {
    $mileage = $this->calculateVehicleMileage($item->sno);
    return [
        'sno' => $item->sno,
        'status' => $item->status,
        'document_status' => $item->document_status,
        'registration_number' => $item->registration_number,
        'nick_name' => $item->nick_name,
        'assigned_driver_id' => $item->assigned_driver_id,
        'log_odometer' => $item->log_odometer,
        'mileage' => $mileage,
        'fuel_type' => $item->fuel_type,
        'vechicle_purpose' => $item->vechicle_purpose,
        'chasis_number' => $item->chasis_number,
        'engine_number' => $item->engine_number,
        'purchase_date' => $item->purchase_date,
        'make' => $item->make,
        'model' => $item->model,
        'fuel_id' => $item->fuel_id,
        'department' => $item->department,
        'driver_id' => $item->driver_id,
        'purpose_id' => $item->purpose_id,
        'item' => $item,
        'encrypted_id' => $helper->encrypt_decrypt(
            $item->sno,
            'encrypt'
        ),
    ];
});
        return response()->json([
            'data' => $data,
            'current_page' =>$categorylist->currentPage(),
            'last_page' =>$categorylist->lastPage(),
            'total' => $categorylist->total(),
        ]);
    }
    return view(
        'content.corporate_admin.vehicle_management.asset_list',
        [
            'perpage' =>$perpage,
            'search_filter' =>$search_filter,
            'categorylist' =>$categorylist,
        ]
    );
}
private function calculateVehicleMileage($vehicleId)
{
    $fuelLogs = DB::table('egc_crpt_fuel_log')->where('vehicle_id', $vehicleId)->where('status', 0)->whereNotNull('log_odometer')->whereNotNull('log_liters')->where('log_liters', '>', 0)->orderBy('log_odometer', 'asc')->get(['log_odometer','log_liters',]);
    if ($fuelLogs->count() < 2) {
        return null;
    }
    $totalDistance = 0;
    $totalFuel = 0;
    for ($i = 1; $i < $fuelLogs->count(); $i++) {
        $previousOdometer = (float) $fuelLogs[$i - 1]->log_odometer;
        $currentOdometer  = (float) $fuelLogs[$i]->log_odometer;
        $fuelLiters = (float) $fuelLogs[$i]->log_liters;
        $distance = $currentOdometer - $previousOdometer;
        if ($distance <= 0 || $fuelLiters <= 0) {
            continue;
        }
        $totalDistance += $distance;
        $totalFuel += $fuelLiters;
    }
    if ($totalFuel <= 0) {
        return null;
    }
    return round($totalDistance / $totalFuel, 2);
}
    public function add()
    {
        return view('content.corporate_admin.vehicle_management.add_asset');
    }
    public function edit($edit_id)
{
    $fuelTypes = FuelModel::where('status', 0)->get();
    $drivers = StaffModel::where('status', 0)->where('egc_staff.job_role_id', 27)->get();
    $purposes = VechicleModel::where('status', 0)->get();
    $categorylist = VechicleManagementModel::where('sno', $edit_id)->where('status', '!=', 2)->first();
    if (!$categorylist) {
        return redirect()->route('vehicle-management.index')->with('error', 'Vehicle not found.');
    }
    $assignedDriverId = DB::table('egc_crpt_assign_staff')->where('vehicle_id', $categorylist->sno)->where('status', 0)->orderByDesc('sno')->value('staff_id');
    $categorylist->assigned_driver_id =
        $assignedDriverId ?? $categorylist->driver_id;
    if ($categorylist->assigned_driver_id) {
        $drivers = $drivers->keyBy('sno');
        $assignedDriver = StaffModel::where('sno',$categorylist->assigned_driver_id)->first();
        if ($assignedDriver) {
            $drivers->put($assignedDriver->sno, $assignedDriver);
        }
        $drivers = $drivers->values();
    }
    return view('content.corporate_admin.vehicle_management.edit_asset',compact('categorylist','drivers','fuelTypes','purposes'));
}
public function update(Request $request)
{
$validator = Validator::make($request->all(), [
    'edit_id' => 'required|integer',
    'registration_number' => 'required|string|max:100',
    'chasis_number' => 'nullable|string|max:100',
    'engine_number' => 'nullable|string|max:100',
    'purchase_date' => 'required|date',
    'make' => 'required|string|max:100',
    'model' => 'required|string|max:100',
    'fuel_id' => 'required',
    'ownership' => 'required',
    'branch_id' => 'nullable',
    'department' => 'required|string|max:255',
    'driver_id' => 'nullable',
    'purpose_id' => 'nullable',
    'reg_certificate' => ['nullable','file','mimes:jpg,jpeg,png,pdf','max:5120'],
    'insurance_policy' => ['nullable','file','mimes:jpg,jpeg,png,pdf','max:5120'],
    'document_type' => 'nullable|array',
    'document_type.*' => ['nullable','integer','in:1,2,3'],
    'document_attachement' => 'nullable|array',
    'document_attachement.*' => ['nullable','file','mimes:jpg,jpeg,png,pdf','max:5120'],
]);

if ($validator->fails()) {
    return redirect()->back()->withErrors($validator)->withInput();
}
$edit_id = $request->edit_id;
$vehicle = VechicleManagementModel::where('sno', $edit_id)->where('status', '!=', 2)->first();
if (!$vehicle) {
    return redirect()->back()->with('error', 'Vehicle not found.');
}
$duplicateVehicle = VechicleManagementModel::where('registration_number',$request->registration_number)->where('sno', '!=', $edit_id)->where('status', '!=', 2)->exists();
if ($duplicateVehicle) {
    return redirect()->back()->withInput()->with('error','Registration Number Already Exists.');
}
DB::beginTransaction();
try {
    $user_id = $request->user()->userId ?? 1;
    $uploadPath = public_path('uploads/vehicle_documents');
    if (!file_exists($uploadPath)) {
        mkdir($uploadPath,0777,true);
    }
    $vehicle->registration_number =$request->registration_number;
    $vehicle->chasis_number =$request->chasis_number;
    $vehicle->engine_number =$request->engine_number;
    $vehicle->purchase_date =$request->purchase_date? date('Y-m-d',strtotime($request->purchase_date)): null;
    $vehicle->make =$request->make;
    $vehicle->model =$request->model;
    $vehicle->fuel_id =$request->fuel_id;
    $vehicle->ownership =$request->ownership;
    $vehicle->branch_id =$request->branch_id;
    $vehicle->department =$request->department;
    $vehicle->driver_id =$request->driver_id ?: null;
    $vehicle->purpose_id =
        $request->purpose_id ?: null;
    if ($request->hasFile('reg_certificate')) {
        $file =
            $request->file('reg_certificate');
        if ($file->isValid()) {
            $fileName =
                time()
                . '_reg_certificate_'
                . uniqid()
                . '.'
                . $file->getClientOriginalExtension();
            $file->move($uploadPath,$fileName);
            $vehicle->reg_certificate =$fileName;
        }
    }
    if ($request->hasFile('insurance_policy')) {
        $file =$request->file('insurance_policy');
        if ($file->isValid()) {

            $fileName =
                time()
                . '_insurance_'
                . uniqid()
                . '.'
                . $file->getClientOriginalExtension();
            $file->move(
                $uploadPath,
                $fileName
            );
            $vehicle->insurance_policy =$fileName;
        }
    }
    $existingDocumentTypes =json_decode($vehicle->document_type ?? '[]',true);
    $existingDocumentAttachments =json_decode($vehicle->document_attachement ?? '[]',true);
    if (!is_array($existingDocumentTypes)) {
        $existingDocumentTypes = [];
    }
    if (!is_array($existingDocumentAttachments)) {
        $existingDocumentAttachments = [];
    }
    $documentTypes =$request->input('document_type',[]);
    $documentFiles =$request->file('document_attachement',[]);
    if (!is_array($documentTypes)) {
        $documentTypes = [];
    }
    if (!is_array($documentFiles)) {
        $documentFiles = [];
    }
    $finalDocumentTypes = [];
    $finalDocumentAttachments = [];
    foreach ($documentTypes as $index => $documentType) {
        if (empty($documentType)) {
            continue;
        }
        $documentType =(int) $documentType;
        $finalDocumentTypes[] =$documentType;
        if (
            isset($documentFiles[$index])
            &&
            $documentFiles[$index] instanceof
            \Illuminate\Http\UploadedFile
            &&
            $documentFiles[$index]->isValid()
        ) {
            $file =$documentFiles[$index];
            $fileName =
                time()
                . '_document_'
                . $index
                . '_'
                . uniqid()
                . '.'
                . $file->getClientOriginalExtension();
            $file->move(
                $uploadPath,
                $fileName
            );
            $finalDocumentAttachments[] = $fileName;
        }
        else {
            if (
                isset(
                    $existingDocumentAttachments[$index]
                )
                &&
                !empty(
                    $existingDocumentAttachments[$index]
                )
            ) {
                $finalDocumentAttachments[] =
                    $existingDocumentAttachments[$index];
            }
            else {

                $finalDocumentAttachments[] =
                    null;
            }
        }
    }
    if (!empty($finalDocumentTypes)) {

        $vehicle->document_type =
            json_encode(
                array_values(
                    $finalDocumentTypes
                )
            );
        $vehicle->document_attachement =
            json_encode(
                array_values(
                    $finalDocumentAttachments
                )
            );
    }
    else {
        $vehicle->document_type = null;
        $vehicle->document_attachement = null;
    }
    $vehicle->updated_by =$user_id;
    $vehicle->save();
    DB::commit();
    return redirect()->route('vehicle-management.index')
        ->with('success','Vehicle Management edited successfully!');
} catch (\Throwable $e) {
    DB::rollBack();
    return redirect()->back()->withInput()->with('error','Could not update the Vehicle: '. $e->getMessage());
}
}
    public function active(Request $request)
    { $helper = new \App\Helpers\Helpers();
    $search_filter = $request->input('search_filter', '');
    $perpage = (int) $request->input('sorting_filter', 25);
    $latestAssignment = \DB::table('egc_crpt_assign_staff as eas1')
        ->select('eas1.vehicle_id','eas1.staff_id')
        ->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff as eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                AND eas2.status = 0
            )
        ');
    $categorylist = VechicleManagementModel::select(
            'egc_crpt_vechicle_management.*','egc_crpt_fuel_type.fuel_type as fuel_type','egc_crpt_vechicle_purpose.vechicle_purpose as vechicle_purpose',
            \DB::raw('
                COALESCE(
                    assigned_staff.nick_name,
                    vehicle_driver.nick_name
                ) as nick_name
            '),
            \DB::raw('
                COALESCE(
                    latest_assignment.staff_id,
                    egc_crpt_vechicle_management.driver_id
                ) as assigned_driver_id
            '),
            \DB::raw('
                COALESCE((
                    SELECT SUM(fl.log_odometer)
                    FROM egc_crpt_fuel_log fl
                    WHERE fl.vehicle_id = egc_crpt_vechicle_management.sno
                    AND fl.status != 2
                ), 0) as log_odometer
            ')
        )
        ->leftJoin('egc_crpt_fuel_type', 'egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_crpt_vechicle_purpose','egc_crpt_vechicle_purpose.sno','=','egc_crpt_vechicle_management.purpose_id')
        ->leftJoin('egc_staff as vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff as assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->where('egc_crpt_vechicle_management.status','=',0)
        ->when($search_filter != '', function ($query) use ($search_filter) {
            $query->where('egc_crpt_vechicle_management.registration_number','LIKE',"%{$search_filter}%");
        })
        ->orderBy('egc_crpt_vechicle_management.sno','desc')
        ->paginate($perpage);
    if ($request->ajax()) {
        $data = $categorylist->map(function ($item) use ($helper) {
            return [
            'sno' => $item->sno,
            'status' => $item->status,
            'document_status' => $item->document_status,
            'registration_number' => $item->registration_number,
            'nick_name' => $item->nick_name,
            'assigned_driver_id' => $item->assigned_driver_id,
            'log_odometer' => $item->log_odometer,
            'fuel_type' => $item->fuel_type,
            'vechicle_purpose' => $item->vechicle_purpose,
            'chasis_number' => $item->chasis_number,
            'engine_number' => $item->engine_number,
            'purchase_date' => $item->purchase_date,
            'make' => $item->make,
            'model' => $item->model,
            'fuel_id' => $item->fuel_id,
            'department' => $item->department,
            'driver_id' => $item->driver_id,
            'purpose_id' => $item->purpose_id,
            'item' => $item,
            'encrypted_id' => $helper->encrypt_decrypt($item->sno,'encrypt'),
        ];
        });
        return response()->json([
            'data' => $data,
            'current_page' =>$categorylist->currentPage(),
            'last_page' =>$categorylist->lastPage(),
            'total' => $categorylist->total(),
        ]);
    }

    return view('content.corporate_admin.vehicle_management.active_vehicle', [
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'categorylist' => $categorylist,
    ]);
    }

    public function in_service(Request $request)
    { $helper = new \App\Helpers\Helpers();
    $search_filter = $request->input('search_filter', '');
    $perpage = (int) $request->input('sorting_filter', 25);
    $latestAssignment = \DB::table('egc_crpt_assign_staff as eas1')
        ->select('eas1.vehicle_id','eas1.staff_id')
        ->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff as eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                AND eas2.status =0
            )
        ');
    $categorylist = VechicleManagementModel::select(
            'egc_crpt_vechicle_management.*','egc_crpt_fuel_type.fuel_type as fuel_type','egc_crpt_vechicle_purpose.vechicle_purpose as vechicle_purpose',
            \DB::raw('
                COALESCE(
                    assigned_staff.nick_name,
                    vehicle_driver.nick_name
                ) as nick_name
            '),
            \DB::raw('
                COALESCE(
                    latest_assignment.staff_id,
                    egc_crpt_vechicle_management.driver_id
                ) as assigned_driver_id
            '),
            \DB::raw('
                COALESCE((
                    SELECT SUM(fl.log_odometer)
                    FROM egc_crpt_fuel_log fl
                    WHERE fl.vehicle_id = egc_crpt_vechicle_management.sno
                    AND fl.status != 2
                ), 0) as log_odometer
            ')
        )
        ->leftJoin('egc_crpt_fuel_type', 'egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_crpt_vechicle_purpose','egc_crpt_vechicle_purpose.sno','=','egc_crpt_vechicle_management.purpose_id')
        ->leftJoin('egc_staff as vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff as assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->where('egc_crpt_vechicle_management.status','=',3)
        ->when($search_filter != '', function ($query) use ($search_filter) {
            $query->where('egc_crpt_vechicle_management.registration_number','LIKE',"%{$search_filter}%");
        })
        ->orderBy('egc_crpt_vechicle_management.sno','desc')
        ->paginate($perpage);
    if ($request->ajax()) {
        $data = $categorylist->map(function ($item) use ($helper) {
           return [
            'sno' => $item->sno,
            'status' => $item->status,
            'document_status' => $item->document_status,
            'registration_number' => $item->registration_number,
            'nick_name' => $item->nick_name,
            'assigned_driver_id' => $item->assigned_driver_id,
            'log_odometer' => $item->log_odometer,
            'fuel_type' => $item->fuel_type,
            'vechicle_purpose' => $item->vechicle_purpose,
            'chasis_number' => $item->chasis_number,
            'engine_number' => $item->engine_number,
            'purchase_date' => $item->purchase_date,
            'make' => $item->make,
            'model' => $item->model,
            'fuel_id' => $item->fuel_id,
            'department' => $item->department,
            'driver_id' => $item->driver_id,
            'purpose_id' => $item->purpose_id,
            'item' => $item,
            'encrypted_id' => $helper->encrypt_decrypt($item->sno,'encrypt'),
        ];
        });
        return response()->json([
            'data' => $data,
            'current_page' =>$categorylist->currentPage(),
            'last_page' =>$categorylist->lastPage(),
            'total' => $categorylist->total(),
        ]);
    }

    return view('content.corporate_admin.vehicle_management.inservice_vehicle', [
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'categorylist' => $categorylist,
    ]);
    }
    public function idle(Request $request)
    { $helper = new \App\Helpers\Helpers();
    $search_filter = $request->input('search_filter', '');
    $perpage = (int) $request->input('sorting_filter', 25);
    $latestAssignment = \DB::table('egc_crpt_assign_staff as eas1')
        ->select(
            'eas1.vehicle_id',
            'eas1.staff_id'
        )
        ->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff as eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                AND eas2.status = 0
            )
        ');
    $categorylist = VechicleManagementModel::select(
            'egc_crpt_vechicle_management.*','egc_crpt_fuel_type.fuel_type as fuel_type','egc_crpt_vechicle_purpose.vechicle_purpose as vechicle_purpose',
            \DB::raw('
                COALESCE(
                    assigned_staff.nick_name,
                    vehicle_driver.nick_name
                ) as nick_name
            '),
            \DB::raw('
                COALESCE(
                    latest_assignment.staff_id,
                    egc_crpt_vechicle_management.driver_id
                ) as assigned_driver_id
            '),
            \DB::raw('
                COALESCE((
                    SELECT SUM(fl.log_odometer)
                    FROM egc_crpt_fuel_log fl
                    WHERE fl.vehicle_id = egc_crpt_vechicle_management.sno
                    AND fl.status !=2
                ), 0) as log_odometer
            ')
        )
        ->leftJoin('egc_crpt_fuel_type', 'egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_crpt_vechicle_purpose','egc_crpt_vechicle_purpose.sno','=','egc_crpt_vechicle_management.purpose_id')
        ->leftJoin('egc_staff as vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub($latestAssignment,'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff as assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->where('egc_crpt_vechicle_management.status','=',4)
        ->when($search_filter != '', function ($query) use ($search_filter) {
            $query->where('egc_crpt_vechicle_management.registration_number','LIKE',"%{$search_filter}%");
        })
        ->orderBy('egc_crpt_vechicle_management.sno','desc')
        ->paginate($perpage);
    if ($request->ajax()) {
        $data = $categorylist->map(function ($item) use ($helper) {
            return [
            'sno' => $item->sno,
            'status' => $item->status,
            'document_status' => $item->document_status,
            'registration_number' => $item->registration_number,
            'nick_name' => $item->nick_name,
            'assigned_driver_id' => $item->assigned_driver_id,
            'log_odometer' => $item->log_odometer,
            'fuel_type' => $item->fuel_type,
            'vechicle_purpose' => $item->vechicle_purpose,
            'chasis_number' => $item->chasis_number,
            'engine_number' => $item->engine_number,
            'purchase_date' => $item->purchase_date,
            'make' => $item->make,
            'model' => $item->model,
            'fuel_id' => $item->fuel_id,
            'department' => $item->department,
            'driver_id' => $item->driver_id,
            'purpose_id' => $item->purpose_id,
            'item' => $item,
            'encrypted_id' => $helper->encrypt_decrypt($item->sno,'encrypt'),
        ];
        });
        return response()->json([
            'data' => $data,
            'current_page' =>$categorylist->currentPage(),
            'last_page' =>$categorylist->lastPage(),
            'total' => $categorylist->total(),
        ]);
    }

    return view('content.corporate_admin.vehicle_management.idle_vehicle', [
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'categorylist' => $categorylist,
    ]);
    }

    public function lapsed(Request $request)
    { $helper = new \App\Helpers\Helpers();
    $search_filter = $request->input('search_filter', '');
    $perpage = (int) $request->input('sorting_filter', 25);
    $latestAssignment = \DB::table('egc_crpt_assign_staff as eas1')
        ->select(
            'eas1.vehicle_id',
            'eas1.staff_id'
        )
        ->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff as eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                AND eas2.status = 0
            )
        ');
    $categorylist = VechicleManagementModel::select(
            'egc_crpt_vechicle_management.*','egc_crpt_fuel_type.fuel_type as fuel_type','egc_crpt_vechicle_purpose.vechicle_purpose as vechicle_purpose',
            \DB::raw('
                COALESCE(
                    assigned_staff.nick_name,
                    vehicle_driver.nick_name
                ) as nick_name
            '),
            \DB::raw('
                COALESCE(
                    latest_assignment.staff_id,
                    egc_crpt_vechicle_management.driver_id
                ) as assigned_driver_id
            '),
            \DB::raw('
                COALESCE((
                    SELECT SUM(fl.log_odometer)
                    FROM egc_crpt_fuel_log fl
                    WHERE fl.vehicle_id = egc_crpt_vechicle_management.sno
                    AND fl.status != 2
                ), 0) as log_odometer
            ')
        )
        ->leftJoin('egc_crpt_fuel_type', 'egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_crpt_vechicle_purpose','egc_crpt_vechicle_purpose.sno','=','egc_crpt_vechicle_management.purpose_id')
        ->leftJoin('egc_staff as vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff as assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->where('egc_crpt_vechicle_management.document_status','=',6)
        ->when($search_filter != '', function ($query) use ($search_filter) {
            $query->where('egc_crpt_vechicle_management.registration_number','LIKE',"%{$search_filter}%");
        })
        ->orderBy('egc_crpt_vechicle_management.sno','desc')
        ->paginate($perpage);
    if ($request->ajax()) {
        $data = $categorylist->map(function ($item) use ($helper) {
            return [
            'sno' => $item->sno,
            'status' => $item->status,
            'document_status' => $item->document_status,
            'registration_number' => $item->registration_number,
            'nick_name' => $item->nick_name,
            'assigned_driver_id' => $item->assigned_driver_id,
            'log_odometer' => $item->log_odometer,
            'fuel_type' => $item->fuel_type,
            'vechicle_purpose' => $item->vechicle_purpose,
            'chasis_number' => $item->chasis_number,
            'engine_number' => $item->engine_number,
            'purchase_date' => $item->purchase_date,
            'make' => $item->make,
            'model' => $item->model,
            'fuel_id' => $item->fuel_id,
            'department' => $item->department,
            'driver_id' => $item->driver_id,
            'purpose_id' => $item->purpose_id,
            'item' => $item,
            'encrypted_id' => $helper->encrypt_decrypt($item->sno,'encrypt'),
        ];
        });
        return response()->json([
            'data' => $data,
            'current_page' =>$categorylist->currentPage(),
            'last_page' =>$categorylist->lastPage(),
            'total' => $categorylist->total(),
        ]);
    }

    return view('content.corporate_admin.vehicle_management.lapsed_vehicle', [
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'categorylist' => $categorylist,
    ]);
    }
    public function expired(Request $request)
    { $helper = new \App\Helpers\Helpers();
    $search_filter = $request->input('search_filter', '');
    $perpage = (int) $request->input('sorting_filter', 25);
    $latestAssignment = \DB::table('egc_crpt_assign_staff as eas1')
        ->select(
            'eas1.vehicle_id',
            'eas1.staff_id'
        )
        ->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff as eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                AND eas2.status = 0
            )
        ');
    $categorylist = VechicleManagementModel::select(
            'egc_crpt_vechicle_management.*','egc_crpt_fuel_type.fuel_type as fuel_type','egc_crpt_vechicle_purpose.vechicle_purpose as vechicle_purpose',
            \DB::raw('
                COALESCE(
                    assigned_staff.nick_name,
                    vehicle_driver.nick_name
                ) as nick_name
            '),
            \DB::raw('
                COALESCE(
                    latest_assignment.staff_id,
                    egc_crpt_vechicle_management.driver_id
                ) as assigned_driver_id
            '),
            \DB::raw('
                COALESCE((
                    SELECT SUM(fl.log_odometer)
                    FROM egc_crpt_fuel_log fl
                    WHERE fl.vehicle_id = egc_crpt_vechicle_management.sno
                    AND fl.status != 2
                ), 0) as log_odometer
            ')
        )
        ->leftJoin('egc_crpt_fuel_type', 'egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_crpt_vechicle_purpose','egc_crpt_vechicle_purpose.sno','=','egc_crpt_vechicle_management.purpose_id')
        ->leftJoin('egc_staff as vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff as assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->where('egc_crpt_vechicle_management.document_status','=',6)
        ->when($search_filter != '', function ($query) use ($search_filter) {
            $query->where('egc_crpt_vechicle_management.registration_number','LIKE',"%{$search_filter}%");
        })
        ->orderBy('egc_crpt_vechicle_management.sno','desc')
        ->paginate($perpage);
    if ($request->ajax()) {
        $data = $categorylist->map(function ($item) use ($helper) {
            return [
            'sno' => $item->sno,
            'status' => $item->status,
            'document_status' => $item->document_status,
            'registration_number' => $item->registration_number,
            'nick_name' => $item->nick_name,
            'assigned_driver_id' => $item->assigned_driver_id,
            'log_odometer' => $item->log_odometer,
            'fuel_type' => $item->fuel_type,
            'vechicle_purpose' => $item->vechicle_purpose,
            'chasis_number' => $item->chasis_number,
            'engine_number' => $item->engine_number,
            'purchase_date' => $item->purchase_date,
            'make' => $item->make,
            'model' => $item->model,
            'fuel_id' => $item->fuel_id,
            'department' => $item->department,
            'driver_id' => $item->driver_id,
            'purpose_id' => $item->purpose_id,
            'item' => $item,
            'encrypted_id' => $helper->encrypt_decrypt($item->sno,'encrypt'),
        ];
        });
        return response()->json([
            'data' => $data,
            'current_page' =>$categorylist->currentPage(),
            'last_page' =>$categorylist->lastPage(),
            'total' => $categorylist->total(),
        ]);
    }
    return view('content.corporate_admin.vehicle_management.expired_vehicle', [
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'categorylist' => $categorylist,
    ]);
    }
    public function Listfuel()
  {
    $fuel_type = FuelModel::where('status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $fuel_type,
    ], 200);
  }
    public function Listdriver()
  {
    $driver = StaffModel::where('status', 0)->where('egc_staff.job_role_id', '=', 27)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $driver,
    ], 200);
  }
   public function Listpurpose()
  {
    $purpose = VechicleModel::where('status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $purpose,
    ], 200);
  }
    public function Store(Request $request)
{
    $validator = Validator::make($request->all(), [
        'registration_number' => 'required|string|max:100',
        'chasis_number'       => 'nullable|string|max:100',
        'engine_number'       => 'nullable|string|max:100',
        'purchase_date'       => 'nullable|date',
        'make'                => 'required|string|max:100',
        'model'               => 'required|string|max:100',
        'fuel_id'             => 'required',
        'ownership'           => 'required',
        'department'          => 'required|string|max:255',
        'driver_id'           => 'nullable',
        'purpose_id'          => 'nullable',
        'reg_certificate' => ['nullable','file','mimes:jpg,jpeg,png,pdf','max:5120'],
        'insurance_policy' => ['nullable','file','mimes:jpg,jpeg,png,pdf','max:5120'],
        'document_type' => 'nullable|array',
        'document_type.*' => 'nullable|integer',
        'document_attachement' => 'nullable|array',
        'document_attachement.*' => ['nullable','file','mimes:jpg,jpeg,png,pdf','max:5120'],
    ]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation failed.',
            'errors' => $validator->errors(),
        ], 422);
    }
    $vehicleExists = VechicleManagementModel::where('registration_number',$request->registration_number)
    ->where('status', '!=', 2)
    ->exists();
    if ($vehicleExists) {
        return response()->json([
            'status' => 422,
            'message' => 'Registration Number Already Exists.',
        ], 422);
    }
    DB::beginTransaction();
    try {
        $user_id = 1;
        $uploadPath = public_path('uploads/vehicle_documents');

        if (!file_exists($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }
        $vehicle = new VechicleManagementModel();
        $vehicle->registration_number = $request->registration_number;
        $vehicle->chasis_number       = $request->chasis_number;
        $vehicle->engine_number       = $request->engine_number;
        $vehicle->purchase_date = $request->purchase_date? date('Y-m-d', strtotime($request->purchase_date)): null;
        $vehicle->make       = $request->make;
        $vehicle->model      = $request->model;
        $vehicle->fuel_id    = $request->fuel_id;
        $vehicle->ownership  = $request->ownership;
        $vehicle->branch_id  = $request->branch_id;
        $vehicle->department = $request->department;
        $vehicle->driver_id  = $request->driver_id ?: null;
        $vehicle->purpose_id = $request->purpose_id ?: null;
        if ($request->hasFile('reg_certificate')) {
            $file = $request->file('reg_certificate');
            if ($file->isValid()) {
                $fileName = time()
                    . '_reg_certificate_'
                    . uniqid()
                    . '.'
                    . $file->getClientOriginalExtension();
                $file->move($uploadPath, $fileName);
                $vehicle->reg_certificate = $fileName;
            }
        }
        if ($request->hasFile('insurance_policy')) {
            $file = $request->file('insurance_policy');
            if ($file->isValid()) {
                $fileName = time()
                    . '_insurance_'
                    . uniqid()
                    . '.'
                    . $file->getClientOriginalExtension();
                $file->move($uploadPath, $fileName);
                $vehicle->insurance_policy = $fileName;
            }
        }
        $documentTypes = $request->input('document_type', []);
        $documentFiles = $request->file('document_attachement', []);
        $documents = [];
        foreach ($documentFiles as $index => $file) {
            $documentType = $documentTypes[$index] ?? null;
            if (empty($documentType)) {
                continue;
            }
            if (!$file || !$file->isValid()) {
                continue;
            }
            $fileName = time()
                . '_document_'
                . $index
                . '_'
                . uniqid()
                . '.'
                . $file->getClientOriginalExtension();
            $file->move($uploadPath, $fileName);
            $documents[] = ['document_type' => (int) $documentType,'document_attachment' => $fileName,];
        }
        if (!empty($documents)) {

            $vehicle->document_type = json_encode(array_column($documents, 'document_type'));
            $vehicle->document_attachement = json_encode(array_column($documents, 'document_attachment'));
        }
        $vehicle->created_by = $user_id;
        $vehicle->updated_by = $user_id;
        $vehicle->status     = 0;
        $vehicle->save();
        DB::commit();
        return response()->json([
            'status' => 200,
            'message' => 'Vehicle added successfully!',
            'data' => [
                'vehicle_id' => $vehicle->sno,
            ],
        ], 200);

    } catch (\Throwable $e) {
        DB::rollBack();
        return response()->json([
            'status' => 500,
            'message' => 'Could not add the Vehicle.',
            'error' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
        ], 500);
    }
}
  public function Delete($id)
    {
        $upd_CourseCategoryModel = VechicleManagementModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();
        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
public function View($id)
{
    $view_data = VechicleManagementModel::where('status', '!=', 2)->where('sno', $id)->first();
    if (!$view_data) {
        return response()->json([
            'status' => 404,
            'message' => 'Vehicle not found',
            'error_msg' => null,
            'data' => null,
        ], 404);
    }
    $service = DB::table('egc_crpt_schedule_service as ss')
        ->leftJoin('egc_crpt_trigger_vehicle as tv','tv.sno','=','ss.trigger_id')
        ->leftJoin('egc_crpt_workshop_vehicle as wv','wv.sno','=','ss.workshop_id')
        ->where('ss.vehicle_id', $id)
        ->where('ss.status', '!=', 2)
        ->select('ss.sno','ss.vehicle_id','ss.trigger_id','tv.trigger_name','ss.workshop_id','wv.workshop_name','ss.shedule_date','ss.down_time'
        )->orderBy('ss.sno', 'desc')->first();
    $fuelLog = DB::table('egc_crpt_fuel_log as fl')
        ->leftJoin('egc_crpt_channel as c','c.sno','=','fl.channel_id')->where('fl.vehicle_id', $id)->where('fl.status', 0)->select('fl.sno','fl.vehicle_id','fl.channel_id','c.channel_name','fl.log_date_time','fl.log_liters','fl.log_amount','fl.log_odometer','fl.log_station','fl.document_attachement')
        ->orderBy('fl.sno', 'desc')->first();
    return response()->json([
        'status' => 200,
        'message' => 'Vehicle details fetched successfully',
        'error_msg' => null,
        'data' => [
            'vehicle' => $view_data,
            'service' => $service,
            'fuel_log' => $fuelLog,
        ],
    ], 200);
}
public function logView($id)
{
    $latestAssignment = DB::table('egc_crpt_assign_staff as eas1')
        ->select('eas1.vehicle_id', 'eas1.staff_id')
        ->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff AS eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                  AND eas2.status = 0
            )
        ');

    $vehicle = VechicleManagementModel::query()
        ->select(
            'egc_crpt_vechicle_management.*',
            'egc_crpt_fuel_type.fuel_type',
            'egc_crpt_fuel_log.log_odometer',
            'egc_crpt_fuel_log.log_date_time',
            'egc_crpt_fuel_log.log_liters',
            'egc_crpt_fuel_log.log_amount',
            'egc_crpt_fuel_log.log_station',
            DB::raw('COALESCE(
                assigned_staff.nick_name,
                vehicle_driver.nick_name
            ) AS driver_name')
        )
        ->leftJoin('egc_crpt_fuel_type','egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_staff as vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff as assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->leftJoin(
            'egc_crpt_fuel_log',
            function ($join) {
                $join->on('egc_crpt_fuel_log.vehicle_id','=','egc_crpt_vechicle_management.sno')->where('egc_crpt_fuel_log.status', '=', 0);
            }
        )
        ->where('egc_crpt_vechicle_management.sno', $id)
        ->where('egc_crpt_vechicle_management.status', '!=', 2)
        ->first();
    if (!$vehicle) {
        return response()->json([
            'status' => 404,
            'message' => 'Vehicle not found.',
            'data' => null,
        ], 404);
    }
    return response()->json([
        'status' => 200,
        'message' => 'Vehicle details fetched successfully.',
        'data' => $vehicle,
    ], 200);
}
public function view_service($id)
{
    $latestAssignment = DB::table('egc_crpt_assign_staff as eas1')
        ->select('eas1.vehicle_id', 'eas1.staff_id')->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff AS eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                  AND eas2.status = 0
            )
        ');
    $vehicle = VechicleManagementModel::query()
        ->select(
            'egc_crpt_vechicle_management.*',
            'egc_crpt_fuel_type.fuel_type',
            'egc_crpt_fuel_log.log_odometer',
            'egc_crpt_fuel_log.log_date_time',
            'egc_crpt_fuel_log.log_liters',
            'egc_crpt_fuel_log.log_amount',
            'egc_crpt_fuel_log.log_station',
            DB::raw('COALESCE(
                assigned_staff.nick_name,
                vehicle_driver.nick_name
            ) AS driver_name')
        )
        ->leftJoin('egc_crpt_fuel_type','egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_staff AS vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff AS assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->leftJoin(
            'egc_crpt_fuel_log',
            function ($join) {
                $join->on('egc_crpt_fuel_log.vehicle_id','=','egc_crpt_vechicle_management.sno')->where('egc_crpt_fuel_log.status', '=', 0);
            }
        )
        ->where('egc_crpt_vechicle_management.sno', $id)->where('egc_crpt_vechicle_management.status', '!=', 2)->first();
    if (!$vehicle) {
        return response()->json([
            'status' => 404,
            'message' => 'Vehicle not found.',
            'data' => null,
        ], 404);
    }
    return response()->json([
        'status' => 200,
        'message' => 'Vehicle details fetched successfully.',
        'data' => $vehicle,
    ], 200);
}
public function view_assign($id)
{
    $latestAssignment = DB::table('egc_crpt_assign_staff as eas1')
        ->select('eas1.vehicle_id', 'eas1.staff_id')
        ->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff AS eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                  AND eas2.status = 0
            )
        ');

    $vehicle = VechicleManagementModel::query()
        ->select(
            'egc_crpt_vechicle_management.*',
            'egc_crpt_fuel_type.fuel_type',
            'egc_crpt_fuel_log.log_odometer',
            'egc_crpt_fuel_log.log_date_time',
            'egc_crpt_fuel_log.log_liters',
            'egc_crpt_fuel_log.log_amount',
            'egc_crpt_fuel_log.log_station',
            DB::raw('COALESCE(
                assigned_staff.nick_name,
                vehicle_driver.nick_name
            ) AS driver_name')
        )
        ->leftJoin('egc_crpt_fuel_type','egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_staff AS vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff AS assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->leftJoin(
            'egc_crpt_fuel_log',
            function ($join) {
                $join->on('egc_crpt_fuel_log.vehicle_id','=','egc_crpt_vechicle_management.sno')->where('egc_crpt_fuel_log.status', '=', 0);
            }
        )
        ->where('egc_crpt_vechicle_management.sno', $id)->where('egc_crpt_vechicle_management.status', '!=', 2)->first();
    if (!$vehicle) {
        return response()->json([
            'status' => 404,
            'message' => 'Vehicle not found.',
            'data' => null,
        ], 404);
    }
    return response()->json([
        'status' => 200,
        'message' => 'Vehicle details fetched successfully.',
        'data' => $vehicle,
    ], 200);
}
public function view_idle($id)
{
    $latestAssignment = DB::table('egc_crpt_assign_staff as eas1')
        ->select('eas1.vehicle_id', 'eas1.staff_id')->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff AS eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                  AND eas2.status = 0
            )
        ');

    $vehicle = VechicleManagementModel::query()
        ->select(
            'egc_crpt_vechicle_management.*',
            'egc_crpt_fuel_type.fuel_type',
            'egc_crpt_fuel_log.log_odometer',
            'egc_crpt_fuel_log.log_date_time',
            'egc_crpt_fuel_log.log_liters',
            'egc_crpt_fuel_log.log_amount',
            'egc_crpt_fuel_log.log_station',
            DB::raw('COALESCE(
                assigned_staff.nick_name,
                vehicle_driver.nick_name
            ) AS driver_name')
        )
        ->leftJoin('egc_crpt_fuel_type','egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_staff AS vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff AS assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->leftJoin(
            'egc_crpt_fuel_log',
            function ($join) {
                $join->on('egc_crpt_fuel_log.vehicle_id','=','egc_crpt_vechicle_management.sno')->where('egc_crpt_fuel_log.status', '=', 0);
            }
        )
        ->where('egc_crpt_vechicle_management.sno', $id)->where('egc_crpt_vechicle_management.status', '!=', 2)->first();
    if (!$vehicle) {
        return response()->json([
            'status' => 404,
            'message' => 'Vehicle not found.',
            'data' => null,
        ], 404);
    }
    return response()->json([
        'status' => 200,
        'message' => 'Vehicle details fetched successfully.',
        'data' => $vehicle,
    ], 200);
}
public function view_retire($id)
{
    $latestAssignment = DB::table('egc_crpt_assign_staff as eas1')
        ->select('eas1.vehicle_id', 'eas1.staff_id')
        ->where('eas1.status', 0)
        ->whereRaw('
            eas1.sno = (
                SELECT MAX(eas2.sno)
                FROM egc_crpt_assign_staff AS eas2
                WHERE eas2.vehicle_id = eas1.vehicle_id
                  AND eas2.status = 0
            )
        ');

    $vehicle = VechicleManagementModel::query()
        ->select(
            'egc_crpt_vechicle_management.*',
            'egc_crpt_fuel_type.fuel_type',
            'egc_crpt_fuel_log.log_odometer',
            'egc_crpt_fuel_log.log_date_time',
            'egc_crpt_fuel_log.log_liters',
            'egc_crpt_fuel_log.log_amount',
            'egc_crpt_fuel_log.log_station',
            DB::raw('COALESCE(
                assigned_staff.nick_name,
                vehicle_driver.nick_name
            ) AS driver_name')
        )
        ->leftJoin('egc_crpt_fuel_type','egc_crpt_fuel_type.sno','=','egc_crpt_vechicle_management.fuel_id')
        ->leftJoin('egc_staff AS vehicle_driver','vehicle_driver.sno','=','egc_crpt_vechicle_management.driver_id')
        ->leftJoinSub(
            $latestAssignment,
            'latest_assignment',
            function ($join) {
                $join->on('latest_assignment.vehicle_id','=','egc_crpt_vechicle_management.sno');
            }
        )
        ->leftJoin('egc_staff AS assigned_staff','assigned_staff.sno','=','latest_assignment.staff_id')
        ->leftJoin(
            'egc_crpt_fuel_log',
            function ($join) {
                $join->on('egc_crpt_fuel_log.vehicle_id','=','egc_crpt_vechicle_management.sno')->where('egc_crpt_fuel_log.status', '=', 0);
            }
        )
        ->where('egc_crpt_vechicle_management.sno', $id)->where('egc_crpt_vechicle_management.status', '!=', 2)->first();
    if (!$vehicle) {
        return response()->json([
            'status' => 404,
            'message' => 'Vehicle not found.',
            'data' => null,
        ], 404);
    }
    return response()->json([
        'status' => 200,
        'message' => 'Vehicle details fetched successfully.',
        'data' => $vehicle,
    ], 200);
}
public function Status($id, Request $request)
{   $userId =  $request->user()->userId ?? 1;
    $validator = Validator::make($request->all(), ['status' => 'required|integer|in:0,1,3,4',]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Invalid vehicle status.',
            'error_msg' => $validator->errors(),
            'data' => null,
        ], 422);
    }
    $vehicle = VechicleManagementModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$vehicle) {
        return response()->json([
            'status' => 404,
            'message' => 'Vehicle not found.',
            'error_msg' => null,
            'data' => null,
        ], 404);
    }
    $vehicle->status = (int) $request->status;
    $vehicle->updated_by =$userId;
    $vehicle->save();
    return response()->json([
        'status' => 200,
        'message' => 'Vehicle status updated successfully.',
        'error_msg' => null,
        'data' => [
            'sno' => $vehicle->sno,
            'status' => $vehicle->status,
        ],
    ], 200);
}
public function DocumentStatus($id, Request $request)
{    $userId =  $request->user()->userId ?? 1;
    $validator = Validator::make($request->all(), [
        'document_status' => 'required|integer|in:0,5,6',
    ]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Invalid document status.',
            'error_msg' => $validator->errors(),
            'data' => null,
        ], 422);
    }
    $vehicle = VechicleManagementModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$vehicle) {
        return response()->json([
            'status' => 404,
            'message' => 'Vehicle not found.',
            'error_msg' => null,
            'data' => null,
        ], 404);
    }
    $vehicle->document_status = (int) $request->document_status;
    $vehicle->updated_by = $userId;
    $vehicle->save();
    return response()->json([
        'status' => 200,
        'message' => 'Document status updated successfully.',
        'error_msg' => null,
        'data' => [
            'sno' => $vehicle->sno,
            'document_status' => $vehicle->document_status,
        ],
    ], 200);
}

public function getVehicleCounts()
{
    $counts = [
        'all' => VechicleManagementModel::where('status', '!=', 2)->count(),
        'active' => VechicleManagementModel::where('status', 0)->count(),
        'inactive' => VechicleManagementModel::where('status', 1)->count(),
        'in_service' => VechicleManagementModel::where('status', 3)->count(),
        'idle' => VechicleManagementModel::where('status', 4)->count(),
        'document_active' => VechicleManagementModel::where('document_status', 0)->count(),
        'lapsed' => VechicleManagementModel::where('document_status', 5)->count(),
        'expired' => VechicleManagementModel::where('document_status', 6)->count(),
    ];
    return response()->json([
        'status' => 200,
        'message' => 'Vehicle counts fetched successfully.',
        'error_msg' => null,
        'data' => $counts,
    ], 200);
}
}
