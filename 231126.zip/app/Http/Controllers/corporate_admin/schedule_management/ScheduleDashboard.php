<?php
namespace App\Http\Controllers\corporate_admin\schedule_management;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
class ScheduleDashboard extends Controller
{
    public function index()
    {
        return view('content.corporate_admin.schedule_management.schedule_dashboard.schedule_dashboard');
    }
    public function getDashboardData(Request $request)
    {
        $validated = $request->validate([
            'start_date' => ['nullable', 'date_format:Y-m-d'],
            'end_date'   => ['nullable', 'date_format:Y-m-d'],
        ]);
        $startDate = $validated['start_date'] ?? Carbon::today()->toDateString();
        $endDate = $validated['end_date'] ?? Carbon::today()->toDateString();
        $start = Carbon::parse($startDate)->startOfDay();
        $end = Carbon::parse($endDate)->endOfDay();
        if ($start->gt($end)) {
            return response()->json([
                'success' => false,
                'message' => 'Start date cannot be greater than end date.',
            ], 422);
        }
        return response()->json([
            'success' => true,
            'data' => [
                'visitors' => $this->visitorAnalytics($start, $end),
                'events' => $this->eventAnalytics($start, $end),
                'conference' => $this->conferenceAnalytics($start, $end),
                'pantry' => $this->pantryAnalytics($start, $end),
            ],
        ]);
    }
    private function visitorAnalytics($start, $end)
    {
        $base = DB::table('egc_crpt_visitor_schedule');
        $today = Carbon::today()->toDateString();
        $todayCount = (clone $base)->whereDate('visit_date', $today)->count();
        $total = (clone $base)->whereBetween('visit_date', [$start->toDateString(),$end->toDateString(),])->count();
        $daily = (clone $base)
            ->selectRaw('DATE(visit_date) as date, COUNT(*) as total')->whereBetween('visit_date', [$start->toDateString(),$end->toDateString(),])->groupByRaw('DATE(visit_date)')->orderBy('date')->get();
        $weekday = (clone $base)
            ->selectRaw('DAYNAME(visit_date) as day, COUNT(*) as total')->whereBetween('visit_date', [$start->toDateString(),$end->toDateString(),])->groupByRaw('DAYOFWEEK(visit_date), DAYNAME(visit_date)')->orderByRaw('DAYOFWEEK(visit_date)')->get();
        return [
            'today' => $todayCount,
            'total' => $total,
            'busiest_date' => $daily->sortByDesc('total')->first(),
            'busiest_day' => $weekday->sortByDesc('total')->first(),
            'daily' => $daily,
            'weekday' => $weekday,
        ];
    }
    private function eventAnalytics($start, $end)
{
    $base = DB::table('egc_crpt_event_management')->where('status', '!=', 2);
    $today = Carbon::today()->toDateString();
    $todayCount = (clone $base)->whereDate('event_date', $today)->count();
    $total = (clone $base)->whereBetween('event_date', [$start->toDateString(),$end->toDateString()])->count();
    $daily = (clone $base)->selectRaw('DATE(event_date) as date, COUNT(*) as total')->whereBetween('event_date', [$start->toDateString(),$end->toDateString()])->groupByRaw('DATE(event_date)')->orderBy('date')->get();
    $monthly = (clone $base)->selectRaw("YEAR(event_date) as year,MONTH(event_date) as month,DATE_FORMAT(event_date, '%b %Y') as month_name,COUNT(*) as total")
        ->whereBetween('event_date', [$start->toDateString(),$end->toDateString()])
        ->groupByRaw("YEAR(event_date),MONTH(event_date),DATE_FORMAT(event_date, '%b %Y')")->orderByRaw('YEAR(event_date), MONTH(event_date)')->get();
    $weekday = (clone $base)->selectRaw('DAYNAME(event_date) as day, COUNT(*) as total')
        ->whereBetween('event_date', [$start->toDateString(),$end->toDateString()])->groupByRaw('DAYOFWEEK(event_date), DAYNAME(event_date)')->orderByRaw('DAYOFWEEK(event_date)')->get();
    return [
        'today' => $todayCount,
        'total' => $total,
        'busiest_date' => $daily->sortByDesc('total')->first(),
        'busiest_month' => $monthly->sortByDesc('total')->first(),
        'daily' => $daily,
        'monthly' => $monthly,
        'weekday' => $weekday,
    ];
}
    private function conferenceAnalytics($start, $end)
    {
        $base = DB::table('egc_crpt_conference_booking')->where('status', '!=', 2);
        $today = Carbon::today()->toDateString();
        $todayBookings = (clone $base)->whereDate('meeting_date', $today);
        $todayCount = (clone $todayBookings)->count();
        $statusCounts = (clone $todayBookings)->selectRaw('status, COUNT(*) as total')->groupBy('status')->pluck('total', 'status');
        $roomBooked = (clone $todayBookings)->where('status', 1)->distinct()->count('conference_room_id');
        $ongoing = (int) ($statusCounts[0] ?? 0);
        $booked = (int) ($statusCounts[1] ?? 0);
        $completed = (int) ($statusCounts[3] ?? 0);
        $cancelled = (int) ($statusCounts[4] ?? 0);
        $totalParticipants = (clone $base)->whereBetween('meeting_date', [$start,$end,])->sum('member_count');
        $daily = (clone $base)->selectRaw('DATE(meeting_date) as date,COUNT(*) as total')->whereBetween('meeting_date', [$start,$end,])->groupByRaw('DATE(meeting_date)')->orderBy('date')->get();
        $roomUsage = (clone $base)->selectRaw('conference_room_id,COUNT(*) as total')->whereBetween('meeting_date', [$start,$end,])->groupBy('conference_room_id')->orderByDesc('total')->limit(10)->get();
        return [
            'today' => $todayCount,
            'room_booked' => $roomBooked,
            'ongoing' => $ongoing,
            'booked' => $booked,
            'completed' => $completed,
            'cancelled' => $cancelled,
            'participants' => $totalParticipants,
            'daily' => $daily,
            'room_usage' => $roomUsage,
        ];
    }
    private function pantryAnalytics($start, $end)
    {
        $today = Carbon::today()->toDateString();
        $base = DB::table('egc_crpt_conference_booking')->where('status', '!=', 2)->whereNotNull('service_details');
        $bookings = (clone $base)->select('sno','meeting_date','service_id','service_details')->whereBetween('meeting_date', [$start,$end,])->get();
        $todayCount = (clone $base)->whereDate('meeting_date', $today)->count();
        $serviceCategories = ['1' => 'Gifts','3' => 'Refreshment',];
        $categoryCounts = [];
        $itemCounts = [];
        foreach ($bookings as $booking) {
            $details = json_decode($booking->service_details,true);
            if (!is_array($details)) {
                continue;
            }
            $serviceIds = array_filter(explode(',', (string) $booking->service_id));
            foreach ($serviceIds as $serviceId) {
                $serviceId = (string) trim($serviceId);
                $category = $serviceCategories[$serviceId] ?? null;
                if (!$category) {
                    continue;
                }
                if (!isset($categoryCounts[$category])) {
                    $categoryCounts[$category] = 0;
                }
                $categoryCounts[$category]++;
                $item = $details[$serviceId] ?? null;
                if (is_string($item) && trim($item) !== '') {
                    $item = trim($item);
                    if (!isset($itemCounts[$category])) {
                        $itemCounts[$category] = [];
                    }
                    if (!isset($itemCounts[$category][$item])) {
                        $itemCounts[$category][$item] = 0;
                    }
                    $itemCounts[$category][$item]++;
                }
            }
        }
        $categories = [];
        foreach ($categoryCounts as $category => $count) {
            $items = $itemCounts[$category] ?? [];
            arsort($items);
            $categories[] = [
                'category' => $category,
                'total' => $count,
                'most_requested_item' => count($items) ? array_key_first($items) : '-',
                'item_count' => count($items) ? reset($items) : 0,
                'items' => $items,
            ];
        }
        usort($categories, function ($a, $b) {
            return $b['total'] <=> $a['total'];
        });
        $daily = DB::table('egc_crpt_conference_booking')->selectRaw('DATE(meeting_date) as date,COUNT(*) as total')
            ->where('status', '!=', 2)->whereNotNull('service_details')->whereBetween('meeting_date', [$start,$end,])->groupByRaw('DATE(meeting_date)')->orderBy('date')->get();
        return [
            'today' => $todayCount,
            'total' => $bookings->count(),
            'categories' => $categories,
            'daily' => $daily,
        ];
    }
}
