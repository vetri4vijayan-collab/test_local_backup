<?php
namespace App\Http\Controllers\corporate_admin\schedule_management;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\VisitorScheduleModel;
use App\Models\VisitorModel;
use App\Models\VisitorPurposeModel;
use App\Models\VisitorServiceModel;
use Illuminate\Support\Facades\Validator;
use App\Models\CompanyModel;
use App\Models\StaffModel;
class ManageVisitor extends Controller
{
    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'visitor_type_id' =>'required|integer',
            'visitor_name' =>'required|string|max:255',
            'mobile_number' =>'required|string|max:20',
            'company_name' =>'nullable|string|max:255',
            'company_id' =>'required|integer',
            'host_id' =>'required|integer',
            'visitor_purpose_id' =>'required|integer',
            'visit_date' =>'required|date',
            'visit_time' =>'required',
            'service_id' =>'required|array|min:1',
            'service_id.*' =>'required|integer',
            'notes' =>'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' =>
                    'Validation failed',
                'error_msg' =>
                    $validator->errors(),
                'data' => null,
            ], 422);
        }

        try {
            $Managevisitor =new VisitorScheduleModel();
            $Managevisitor->visitor_type_id =$request->visitor_type_id;
            $Managevisitor->visitor_name =$request->visitor_name;
            $Managevisitor->mobile_number =$request->mobile_number;
            $Managevisitor->company_name =$request->company_name;
            $Managevisitor->company_id =$request->company_id;
            $Managevisitor->host_id =$request->host_id;
            $Managevisitor->visitor_purpose_id =$request->visitor_purpose_id;
            $Managevisitor->visit_date =date('Y-m-d',strtotime($request->visit_date));
            $Managevisitor->visit_time =date('H:i:s',strtotime($request->visit_time));
            $serviceIds =array_map('intval',$request->input('service_id', []));
            $Managevisitor->service_id =json_encode($serviceIds);
            $Managevisitor->notes =$request->notes;
            $userId = $request->user()->userId ?? 1;
            $Managevisitor->created_by = $userId;
            $Managevisitor->updated_by =$userId;
            $Managevisitor->status =0;
            $Managevisitor->save();
            return response()->json([
                'status' => 200,
                'message' =>
                    'Visitor Schedule added successfully!',
                'data' =>
                    $Managevisitor,

            ], 200);
        } catch (\Throwable $e) {
            \Log::error(
                'Visitor Schedule Add Error',
                [
                    'message' => $e->getMessage(),
                    'file' =>$e->getFile(),
                    'line' =>$e->getLine(),
                    'request' =>$request->all(),
                ]
            );
            return response()->json([
                'status' => 500,
                'message' =>
                    'Something went wrong while adding visitor.',
                'error' =>
                    $e->getMessage(),
            ], 500);
        }
    }
    public function Edit($edit_id)
    {
        try {
            $visitoredit =
                VisitorScheduleModel::select(
                    'egc_crpt_visitor_schedule.*',
                    'egc_crpt_visitor_type.visitor_type as visitor_type',
                    'egc_company.company_name as company_name',
                    'egc_crpt_visitor_purpose.visitor_purpose as visitor_purpose',
                    'egc_staff.staff_name as staff_name'
                )
                ->join('egc_crpt_visitor_type','egc_crpt_visitor_type.sno','=','egc_crpt_visitor_schedule.visitor_type_id')
                ->join('egc_company','egc_company.sno','=','egc_crpt_visitor_schedule.company_id')
                ->join('egc_crpt_visitor_purpose','egc_crpt_visitor_purpose.sno','=','egc_crpt_visitor_schedule.visitor_purpose_id')
                ->join('egc_staff','egc_staff.sno','=','egc_crpt_visitor_schedule.host_id')
                ->where('egc_crpt_visitor_schedule.sno',$edit_id)->first();
            if (!$visitoredit) {
                return response()->json([
                    'status' => 404,
                    'message' =>
                        'Visitor schedule not found.',
                    'error_msg' => null,
                    'data' => null

                ], 404);
            }
            $serviceIds = [];
            if (
                !empty($visitoredit->service_id)
            ) {
                $decoded =
                    json_decode($visitoredit->service_id,true);
                if (is_array($decoded)) {
                    $serviceIds =array_map('intval',$decoded);
                } else {
                    $serviceIds =array_map('intval',array_filter(explode(',',$visitoredit->service_id)));
                }
            }
            $visitoredit->service_ids =$serviceIds;
            return response()->json([
                'status' => 200,
                'message' => null,
                'error_msg' => null,
                'data' => $visitoredit
            ], 200);
        } catch (\Throwable $e) {
            \Log::error(
                'Visitor Schedule Edit Error',
                [
                    'message' =>$e->getMessage(),
                    'file' =>$e->getFile(),
                    'line' =>$e->getLine(),
                ]
            );
            return response()->json([
                'status' => 500,
                'message' =>'Something went wrong.',
                'error_msg' =>$e->getMessage(),
                'data' => null
            ], 500);
        }
    }
    public function Update(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                 'edit_id' =>'required|integer|exists:egc_crpt_visitor_schedule,sno',
                 'visitor_type_id' =>'required|integer',
                  'visitor_name' =>'required|string|max:255',
                  'mobile_number' =>'required|string|max:20',
                  'company_name' =>'nullable|string|max:255',
                  'company_id' =>'required|integer',
                  'host_id' =>'required|integer',
                  'visitor_purpose_id' =>'required|integer',
                  'visit_date' =>'required|date',
                  'visit_time' =>'required',
                  'service_id' =>'required|array|min:1',
                  'service_id.*' =>'required|integer',
                  'notes' =>'nullable|string|max:255',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' =>'Validation failed',
                'error_msg' =>
                    $validator->errors(),

                'data' => null,
            ], 422);
        }
        try {
            $Managevisitor =VisitorScheduleModel::where('sno',$request->edit_id)->first();
            if (!$Managevisitor) {
                return response()->json([
                    'status' => 404,
                    'message' =>'Visitor schedule not found.',
                    'error_msg' => null,
                    'data' => null,
                ], 404);
            }
             $Managevisitor->visitor_type_id =$request->visitor_type_id;
            $Managevisitor->visitor_name =$request->visitor_name;
            $Managevisitor->mobile_number =$request->mobile_number;
            $Managevisitor->company_name =$request->company_name;
            $Managevisitor->company_id =$request->company_id;
            $Managevisitor->host_id =$request->host_id;
            $Managevisitor->visitor_purpose_id =$request->visitor_purpose_id;
            $Managevisitor->visit_date =date('Y-m-d',strtotime($request->visit_date));
            $Managevisitor->visit_time =date('H:i:s',strtotime($request->visit_time));
            $serviceIds =array_map('intval',$request->input('service_id', []));
            $Managevisitor->service_id =json_encode($serviceIds);
            $Managevisitor->notes =$request->notes;
            $userId = $request->user()->userId ?? 1;
            $Managevisitor->created_by = $userId;
            $Managevisitor->updated_by =$userId;
            $Managevisitor->status =0;
            $Managevisitor->save();
            return response()->json([
                'status' => 200,
                'message' =>'Visitor Schedule updated successfully!',
                'error_msg' => null,
                'data' =>
                    $Managevisitor,
            ], 200);
        } catch (\Throwable $e) {
            \Log::error(
                'Visitor Schedule Update Error',
                [
                    'message' =>$e->getMessage(),
                    'file' =>$e->getFile(),
                    'line' =>$e->getLine(),
                    'request' =>$request->all(),
                ]
            );
            return response()->json([
                'status' => 500,
                'message' =>
                    'Something went wrong while updating visitor.',
                'error_msg' =>$e->getMessage(),
                'data' => null,
            ], 500);
        }
    }
    public function index(Request $request)
{
    $perpage = (int) $request->input('sorting_filter', 25);
    $search_filter = trim($request->input('search_filter', ''));
    $visitorList = VisitorScheduleModel::select(
        'egc_crpt_visitor_schedule.*',
        'egc_crpt_visitor_type.visitor_type as visitor_type',
        'egc_company.company_name as company_name',
        'egc_crpt_visitor_purpose.visitor_purpose as visitor_purpose',
        'egc_staff.staff_name as staff_name',)
    ->join('egc_crpt_visitor_type','egc_crpt_visitor_type.sno','=','egc_crpt_visitor_schedule.visitor_type_id')
    ->join('egc_company','egc_company.sno','=','egc_crpt_visitor_schedule.company_id')
    ->join('egc_crpt_visitor_purpose','egc_crpt_visitor_purpose.sno','=','egc_crpt_visitor_schedule.visitor_purpose_id')
    ->join('egc_staff','egc_staff.sno','=','egc_crpt_visitor_schedule.host_id')
    ->where('egc_crpt_visitor_schedule.status', '!=', 2);
    if ($search_filter !== '') {
        $visitorList->where(function ($query) use ($search_filter) {
            $query->where(
                'egc_crpt_visitor_schedule.visitor_name','LIKE',"%{$search_filter}%")
            ->orWhere('egc_crpt_visitor_schedule.mobile_number','LIKE',"%{$search_filter}%")
            ->orWhere('egc_crpt_visitor_schedule.company_name','LIKE',"%{$search_filter}%")
            ->orWhere('egc_company.company_name','LIKE',"%{$search_filter}%")
            ->orWhere('egc_staff.staff_name','LIKE',"%{$search_filter}%")
            ->orWhere('egc_crpt_visitor_purpose.visitor_purpose','LIKE',"%{$search_filter}%");
        });
    }

    $visitorList = $visitorList
        ->orderBy('egc_crpt_visitor_schedule.sno', 'desc')
        ->paginate($perpage);
    $serviceList = VisitorServiceModel::where('status', 0)->get();

    if ($request->ajax()) {
        return response()->json([
            'status'       => 200,
            'data'         => $visitorList->items(),
            'current_page' => $visitorList->currentPage(),
            'last_page'    => $visitorList->lastPage(),
            'total'        => $visitorList->total(),
            'per_page'     => $visitorList->perPage(),
        ]);
    }

    return view(
        'content.corporate_admin.schedule_management.visitor_list',
        [
            'categorylist' => $visitorList,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'serviceList' => $serviceList,
        ]
    );
}
    public function ListVistitorType()
    {
        $channel_type = VisitorModel::where('status', 0)->get();
        return response()->json([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $channel_type,
        ], 200);
    }
    public function ListVisitorPurpose()
    {
        $channel_type = VisitorPurposeModel::where('status', 0)->get();
        return response()->json([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $channel_type,
        ], 200);
    }
    public function ListCompany()
    {
        $channel_type = CompanyModel::where('status', 0)->get();
        return response()->json([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $channel_type,
        ], 200);
    }

    public function ListStaff()
    {
        $driver = StaffModel::where('status', 0)->get();
        return response()->json([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $driver,
        ], 200);
    }
  public function Status($id, Request $request)
{
   $validator = Validator::make($request->all(), [
    'status' => 'required|integer|in:0,1,3',
]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Invalid visitor status.',
            'error_msg' => $validator->errors(),
            'data' => null,
        ], 422);
    }
    $visitor = VisitorScheduleModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$visitor) {
        return response()->json([
            'status' => 404,
            'message' => 'Visitor not found.',
            'error_msg' => null,
            'data' => null,
        ], 404);
    }
    $visitor->status = (int) $request->status;
    $userId = $request->user()->userId ?? 1;
    $visitor->updated_by =user()->userId ?? 1;
    $visitor->save();
    return response()->json([
        'status' => 200,
        'message' => 'Visitor status updated successfully.',
        'error_msg' => null,
        'data' => [
            'sno' => $visitor->sno,
            'status' => $visitor->status,
        ],
    ], 200);
}
}
