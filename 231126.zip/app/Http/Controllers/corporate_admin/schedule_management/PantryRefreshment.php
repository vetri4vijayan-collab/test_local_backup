<?php

namespace App\Http\Controllers\corporate_admin\schedule_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use Carbon\Carbon;

class PantryRefreshment extends Controller
{
    public function index(Request $request)
    {
        if (!$request->ajax()) {
            return view('content.corporate_admin.schedule_management.pantry_list');
        }
        $perPage = (int) $request->input('perpage', 25);
        $allowedPerPage = [5, 10, 25, 50, 100, 500];
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $page = max(1, (int) $request->input('page', 1));
        $search = trim((string) $request->input('search', ''));
        $query = DB::table('egc_crpt_conference_booking as booking')
            ->join('egc_crpt_conference_room as room','room.sno','=','booking.conference_room_id')
            ->join('egc_locations as location','location.sno','=','room.location_id')
            ->join('egc_buildings as building','building.sno','=','room.conference_building_id')
            ->join('egc_building_floors as floor','floor.sno','=','room.conference_floor_id')->where('booking.status', '!=', 2)
            ->select(
                'booking.sno',
                'booking.purpose_of_meeting',
                'booking.member_count',
                'booking.meeting_date',
                'booking.meeting_time',
                'booking.service_details',
                'room.conference_room',
                'location.area',
                'building.building_name',
                'floor.floor_name'
            );
        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('booking.purpose_of_meeting','LIKE',"%{$search}%")
                ->orWhere('room.conference_room','LIKE',"%{$search}%")
                ->orWhere('location.area','LIKE',"%{$search}%")
                ->orWhere('building.building_name','LIKE',"%{$search}%")
                ->orWhere('floor.floor_name','LIKE',"%{$search}%")
                ->orWhere('booking.member_count','LIKE',"%{$search}%")
                ->orWhere('booking.meeting_date','LIKE',"%{$search}%")
                ->orWhere('booking.meeting_time','LIKE',"%{$search}%")
                ->orWhere('booking.service_details','LIKE',"%{$search}%");
            });
        }
        $bookings = $query->orderByDesc('booking.sno')->get()
            ->map(function ($booking) {
                $details = $booking->service_details;
                if (is_string($details)) {
                    $details = json_decode($details, true);
                }
                $booking->service_details = is_array($details) ? $details : [];
                $booking->service_details = collect($booking->service_details)->filter(function ($value) {
                    return is_string($value) && trim($value) !== '';
                })->all();
                return $booking;
            })
            ->filter(function ($booking) {
                return !empty($booking->service_details);
            })->values();
        $total = $bookings->count();
        $lastPage = max(1, (int) ceil($total / $perPage));
        $page = min($page, $lastPage);
        $items = $bookings->slice(($page - 1) * $perPage, $perPage)->values()
            ->map(function ($booking) {
                return [
                    'sno' => $booking->sno,
                    'purpose_of_meeting' => $booking->purpose_of_meeting,
                    'conference_room' => $booking->conference_room,
                    'member_count' => $booking->member_count ?? 0,
                    'area' => $booking->area,
                    'building_name' => $booking->building_name,
                    'floor_name' => $booking->floor_name,
                    'meeting_date' => $booking->meeting_date ? Carbon::parse($booking->meeting_date)->format('d-M-Y'): '-',
                    'meeting_time' => $booking->meeting_time ? Carbon::parse($booking->meeting_time)->format('h:i A'): '-',
                    'service_details' => array_values($booking->service_details),
                ];
            });
        return response()->json([
            'success' => true,
            'data' => $items,
            'pagination' => [
                'current_page' => $page,
                'last_page' => $lastPage,
                'per_page' => $perPage,
                'total' => $total,
                'from' => $total > 0 ? (($page - 1) * $perPage) + 1 : null,
                'to' => $total > 0 ? min($page * $perPage, $total) : null,
            ],
        ]);
    }
}
