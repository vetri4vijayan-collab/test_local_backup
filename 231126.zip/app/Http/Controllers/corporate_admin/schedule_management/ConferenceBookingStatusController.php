<?php
namespace App\Http\Controllers\corporate_admin\schedule_management;
use App\Http\Controllers\Controller;
use App\Models\ConferenceBookingModel;
use App\Models\ConferenceStatusLogModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class ConferenceBookingStatusController extends Controller
{
    public function update(Request $request, $id)
    {
        $request->validate([
            'status' => [
                'required',
                'integer',
                Rule::in([0, 1, 3, 4]),
            ],
        ]);

        $userId = auth()->id();

        if (!$userId) {
            abort(401);
        }

        DB::transaction(function () use ($id, $request, $userId) {
            // Replace with your actual booking model and key.
            $booking = ConferenceBookingModel::where(
                'sno',
                $id
            )->lockForUpdate()->firstOrFail();

            $roomId = $booking->conference_room_id;
            $locationId = $booking->location_id;
            $status = (int) $request->status;
            $now = now();

            // Update the current booking status.
            $booking->status = $status;
            $booking->save();

            // Add a new log entry for this status change.
            ConferenceStatusLogModel::create([
                'conference_room_id' => $roomId,
                'location_id'        => $locationId,
                'status'             => $status,
                'created_by'         => $userId,
                'created_at'         => $now,
                'updated_by'         => $userId,
                'updated_at'         => $now,
            ]);
        });

        return back()->with(
            'success',
            'Conference booking status updated successfully.'
        );
    }
}
