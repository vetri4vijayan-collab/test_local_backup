<?php
namespace App\Http\Controllers\corporate_admin\schedule_management;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CompanyModel;
use App\Models\DepartmentModel;
use App\Models\DivisionModel;
use App\Models\EventManagementModel;
use App\Models\EventTypeModel;
use App\Models\ManageEntityModel;
use App\Models\StaffModel;
use App\Models\VisitorServiceModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
class ManageEvent extends Controller
{
    public function index(Request $request)
    {
        $perPage = (int) $request->input('sorting_filter', 25);
        if (!in_array($perPage, [10, 25, 50, 100])) {
            $perPage = 25;
        }
        $searchFilter = trim($request->input('search_filter', ''));
        $companyFill = $request->input('company_fill', '');
        $entityFill = $request->input('entity_fill', '');
        $departmentFill = $request->input('department_fill', '');
        $divisionFill = $request->input('division_fill', '');
        $companyList = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $location_list = DB::table('egc_locations')->select('sno', 'area')->get();

        return view(
            'content.corporate_admin.schedule_management.event_list',
            [
                'company_list' => $companyList,
                'location_list' => $location_list,
                'perpage' => $perPage,
                'search_filter' => $searchFilter,
                'company_fill' => $companyFill,
                'entity_fill' => $entityFill,
                'department_fill' => $departmentFill,
                'division_fill' => $divisionFill,
            ]
        );
    }
    public function getEvents(Request $request): JsonResponse
    {
        $perPage = (int) $request->input('perpage',$request->input('sorting_filter', 25));
        if (!in_array($perPage, [10, 25, 50, 100])) {
            $perPage = 25;
        }
        $search = trim($request->input('search',$request->input('search_filter', '')));
        $companyFill = $request->input('company_fill','');
        $entityFill = $request->input('entity_fill','');
        $departmentFill = $request->input('department_fill','');
        $divisionFill = $request->input('division_fill','');
       $query = EventManagementModel::query()->from('egc_crpt_event_management')
    ->leftJoin('egc_company','egc_crpt_event_management.company_id','=','egc_company.sno')
    ->leftJoin('egc_entity','egc_crpt_event_management.entity_id','=','egc_entity.sno')
    ->join('egc_department','egc_crpt_event_management.department_id','=','egc_department.sno')
    ->leftJoin('egc_branch','egc_crpt_event_management.branch_id','=','egc_branch.sno')
    ->join('egc_division','egc_crpt_event_management.division_id','=','egc_division.sno')
    ->join('egc_staff','egc_crpt_event_management.staff_id','=','egc_staff.sno')
    ->join('egc_crpt_event_type','egc_crpt_event_management.event_type_id','=','egc_crpt_event_type.sno')
    ->join('egc_event_category','egc_crpt_event_management.event_category_id','=','egc_event_category.sno')
    ->join('egc_event_venue','egc_crpt_event_management.event_venue_id','=','egc_event_venue.sno')
    ->join('egc_conference_hall','egc_crpt_event_management.conference_hall_id','=','egc_conference_hall.sno')
    ->join('egc_participant','egc_crpt_event_management.participant_id','=','egc_participant.sno')
    ->join('egc_locations','egc_crpt_event_management.venue_id','=','egc_locations.sno')
    ->select(
       'egc_crpt_event_management.*',
        'egc_company.company_name',
        'egc_company.company_base_color',
        'egc_entity.entity_name',
        'egc_entity.entity_short_name',
        'egc_crpt_event_type.type_event',
        'egc_branch.branch_name',
        'egc_department.department_name',
        'egc_division.division_name',
        'egc_event_category.category_name',
        'egc_event_venue.venue_name',
        'egc_locations.area as area',
        'egc_conference_hall.hall_name',
        'egc_participant.participant_name',
        'egc_staff.staff_name'
    )
    ->where('egc_crpt_event_management.status', '!=', 2);
        if ($search !== '') {
            $query->where(function ($q) use ($search) {$q->where('egc_crpt_event_management.event_name','LIKE','%' . $search . '%')
                ->orWhere('egc_company.company_name','LIKE','%' . $search . '%')
                ->orWhere('egc_crpt_event_type.type_event','LIKE','%' . $search . '%')
                ->orWhere('egc_branch.branch_name','LIKE','%' . $search . '%')
                ->orWhere('egc_entity.entity_name','LIKE','%' . $search . '%')
                ->orWhere('egc_department.department_name','LIKE','%' . $search . '%')
                ->orWhere('egc_division.division_name','LIKE','%' . $search . '%')
                ->orWhere('egc_crpt_event_management.event_type_id','LIKE','%' . $search . '%')
                ->orWhere('egc_crpt_event_management.event_category_id','LIKE','%' . $search . '%');
            });
        }
        if ($companyFill !== '') {
            $query->where('egc_crpt_event_management.company_id',$companyFill);
        }
        if ($entityFill !== '') {
            $query->where('egc_crpt_event_management.entity_id',$entityFill);
        }
        if ($departmentFill !== '') {
            $query->where('egc_crpt_event_management.department_id',$departmentFill);
        }
        if ($divisionFill !== '') {
            $query->where('egc_crpt_event_management.division_id',$divisionFill);
        }
        $events = $query
            ->orderByDesc('egc_crpt_event_management.sno')->paginate($perPage);

        $data = collect($events->items())
            ->map(function ($event) {
                return $this->formatEvent($event);
            })->values();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $data,
            'pagination' => [
                'current_page' => $events->currentPage(),
                'last_page' => $events->lastPage(),
                'per_page' => $events->perPage(),
                'total' => $events->total(),
                'from' => $events->firstItem(),
                'to' => $events->lastItem(),
            ],
        ]);
    }
    public function Store(Request $request): JsonResponse
    {
        $validator = Validator::make(
            $request->all(),
            [
                'event_name' => ['required','string','max:255'],
                'venue_id' => ['required','string','max:255'],
                'event_type_id' => ['required','integer'],
                'event_category_id' => ['required','integer'],
                'event_date' => ['required', 'date_format:d-M-Y'],
                'event_end_date' => ['required', 'date_format:d-M-Y', 'after_or_equal:event_date'],
                'event_end_time' => ['required', 'date_format:H:i'],
                'event_end_time' => ['required'],
                'is_recurring' => ['nullable','boolean'],
                'recurring_type' => ['nullable','integer'],
                'event_venue_id' => ['required','integer'],
                'conference_hall_id' => ['required','integer'],
                'organizing_company_type' => ['string','max:255'],
                'company_id' => ['nullable','integer'],
                'entity_id' => ['nullable','integer'],
                'branch_id' => ['nullable','integer'],
                'department_id' => ['nullable', 'integer'],
                'division_id' => ['nullable','integer'],
                'staff_id' => ['nullable','integer'],
                'participant_id' => ['required','integer'],
                'participant_count' => ['required','integer','min:0'],
                'service_id' => ['nullable'],
                'notes' => ['nullable','string'],
                'description' => ['nullable','string'],
                'feedback' => ['nullable','boolean'],
                'refreshment' => ['nullable','string','max:255'],
                'status' => ['nullable', 'integer', 'in:0,1'],
            ]
        );
        $validator->after(function ($validator) use ($request) {
            try {
                $startDate = Carbon::createFromFormat('d-M-Y',$request->event_date);
                $endDate = Carbon::createFromFormat('d-M-Y',$request->event_end_date);
                if (!$startDate || !$endDate) {
                    $validator->errors()->add('event_date','Invalid date format. Expected dd-M-yyyy.');
                    return;
                }
                if ($endDate->lt($startDate)) {
                    $validator->errors()->add('event_end_date','Event End Date cannot be before Event Date.');
                }
                $startTime = Carbon::createFromFormat('H:i',$request->event_start_time);
                $endTime = Carbon::createFromFormat('H:i',$request->event_end_time);
                if ($startDate->isSameDay($endDate) && $endTime->lessThanOrEqualTo($startTime)) {
                    $validator->errors()->add('event_end_time','End Time must be greater than Start Time.');
                }
            } catch (\Throwable $e) {
                $validator->errors()->add('event_date','Invalid date or time format.');
            }
            if ($request->boolean('is_recurring') && !$request->filled('recurring_type')) {
                $validator->errors()->add('recurring_type','Recurring type is required.');
            }
        });
        if ($validator->fails()) {
            return response()->json(
                [
                    'success' => false,
                    'status' => 422,
                    'message' => 'Validation failed.',
                    'errors' => $validator->errors()
                ],
                422
            );
        }
        DB::beginTransaction();
        try {
            $userId = $request->user()->userId ?? 1;
            $event = new EventManagementModel();
            $event->event_name =$request->event_name;
            $event->venue_id =$request->venue_id;
            $event->event_type_id =$request->event_type_id;
            $event->event_category_id =$request->event_category_id;
            $event->event_date =Carbon::parse($request->event_date)->format('Y-m-d');
            $event->event_end_date =Carbon::parse($request->event_end_date)->format('Y-m-d');
            $event->event_start_time =$request->event_start_time;
            $event->event_end_time =$request->event_end_time;
            $event->is_recurring =$request->boolean('is_recurring') ? 1 : 0;
            $event->recurring_type =$request->boolean('is_recurring')? $request->recurring_type: null;
            $event->event_venue_id =$request->event_venue_id;
            $event->conference_hall_id =$request->conference_hall_id;
            $companyType = strtolower(trim($request->input('organizing_company_type', '')));
            $event->organizing_company_type = in_array($companyType,['business', 'bussiness'],true) ? 'business' : 'management';
            $event->company_id =$request->company_id;
            $event->entity_id =$request->entity_id;
            $event->branch_id =$request->branch_id;
            $event->department_id =$request->department_id;
            $event->division_id =$request->division_id;
            $event->staff_id =$request->staff_id;
            $event->participant_id = $request->participant_id;
            $event->participant_count =$request->participant_count;
           $services = $request->input('service_id', []);
           if (is_string($services)) {
            $decoded = json_decode($services, true);
            $services = json_last_error() === JSON_ERROR_NONE? $decoded: [$services];}
            if (!is_array($services)) {
              $services = [];
              }
              $services = array_values(
                array_filter(array_map('intval', $services)));
              $event->service_id = json_encode($services);
              $serviceData = $request->input('service_data', []);
              if (is_string($serviceData)) {
                  $decodedServiceData = json_decode($serviceData, true);
                  if (json_last_error() === JSON_ERROR_NONE) {
                      $serviceData = $decodedServiceData;
                  }
              }

              if (!is_array($serviceData)) {
                  $serviceData = [];
              }
            $event->service_details = json_encode($serviceData);
            $event->notes =$request->notes;
            $event->description =$request->description;
            $event->feedback =$request->boolean('feedback') ? 1 : 0;
            $event->refreshment =$request->refreshment;
            $event->status = $request->filled('status')? (int) $request->status: 0;
            $event->created_by =$userId;
            $event->updated_by =$userId;
            $event->save();
            DB::commit();
            return response()->json(
                [
                    'success' => true,
                    'status' => 200,
                    'message' => 'Event added successfully.',
                    'data' => [
                        'event_id' => $event->sno,
                        'event' => $this->formatEvent($event,true)
                    ]
                ],
                200
            );
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error(
                'Event Store Error',
                [
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'request' => $request->except(['password','password_confirmation'])
                ]
            );
            return response()->json(
                [
                    'success' => false,
                    'status' => 500,
                    'message' => 'Could not add the Event.',
                    'error' => config('app.debug')
                        ? $e->getMessage()
                        : null
                ],
                500
            );
        }
    }
private function getEventWithRelations($id)
{
    return EventManagementModel::query()->from('egc_crpt_event_management')
    ->leftJoin('egc_company','egc_crpt_event_management.company_id','=','egc_company.sno')
    ->leftJoin('egc_entity','egc_crpt_event_management.entity_id','=','egc_entity.sno')
    ->join('egc_department','egc_crpt_event_management.department_id','=','egc_department.sno')
    ->leftJoin('egc_branch','egc_crpt_event_management.branch_id','=','egc_branch.sno')
    ->join('egc_division','egc_crpt_event_management.division_id','=','egc_division.sno')
    ->join('egc_staff','egc_crpt_event_management.staff_id','=','egc_staff.sno')
    ->join('egc_crpt_event_type','egc_crpt_event_management.event_type_id','=','egc_crpt_event_type.sno')
    ->join('egc_event_category','egc_crpt_event_management.event_category_id','=','egc_event_category.sno')
    ->join('egc_event_venue','egc_crpt_event_management.event_venue_id','=','egc_event_venue.sno')
    ->join('egc_conference_hall','egc_crpt_event_management.conference_hall_id','=','egc_conference_hall.sno')
    ->join('egc_participant','egc_crpt_event_management.participant_id','=','egc_participant.sno')
    ->join('egc_locations','egc_crpt_event_management.venue_id','=','egc_locations.sno')->where('egc_crpt_event_management.sno',$id)
        ->select(
            'egc_crpt_event_management.*',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_branch.branch_name',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_crpt_event_type.type_event',
            'egc_event_category.category_name',
            'egc_event_venue.venue_name',
            'egc_conference_hall.hall_name',
            'egc_participant.participant_name',
            'egc_locations.area as area',
            'egc_staff.staff_name'
        )
        ->first();
}
   public function update(Request $request,$id): JsonResponse {
        $event = EventManagementModel::find($id);
        if (!$event) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Event not found.'
            ], 404);
        }
        $validator = Validator::make(
            $request->all(),
            [
                'event_name' => ['required','string','max:255'],
                'venue_id' => ['required','string','max:255'],
                'event_type_id' => ['required','integer'],
                'event_category_id' => ['required','integer'],
                'event_date' => ['required', 'date_format:d-M-Y'],
                'event_end_date' => ['required', 'date_format:d-M-Y', 'after_or_equal:event_date'],
                'event_start_time' => ['required', 'date_format:H:i'],
                'event_end_time' => ['required', 'date_format:H:i'],
                'is_recurring' => ['nullable','boolean'],
                'recurring_type' => ['nullable','integer'],
                'event_venue_id' => ['required','integer'],
                'conference_hall_id' => ['required','integer'],
                'organizing_company_type' => ['string','max:255'],
                'company_id' => ['nullable','integer'],
                'entity_id' => ['nullable','integer'],
                'branch_id' => ['nullable','integer'],
                'department_id' => ['nullable', 'integer'],
                'division_id' => ['nullable','integer'],
                'staff_id' => ['nullable','integer'],
                'participant_id' => ['required','integer'],
                'participant_count' => ['required','integer','min:0'],
                'service_id' => ['nullable'],
                'notes' => ['nullable','string'],
                'description' => ['nullable','string'],
                'feedback' => ['nullable','boolean'],
                'refreshment' => ['nullable','string','max:255'],
                'status' => ['nullable', 'integer', 'in:0,1'],
            ]
        );
        $validator->after(function ($validator) use ($request) {
            if (
                $request->filled('event_date') &&
                $request->filled('event_end_date') &&
                $request->event_date === $request->event_end_date &&
                $request->filled('event_start_time') &&
                $request->filled('event_end_time')
            ) {
                try {
                    $start = Carbon::createFromFormat('H:i',$request->event_start_time);
                    $end = Carbon::createFromFormat('H:i',$request->event_end_time);
                    if ($end->lessThanOrEqualTo($start)) {
                        $validator->errors()->add('event_end_time','End Time must be greater than Start Time.');
                    }
                } catch (\Throwable $e) {
                    $validator->errors()->add('event_start_time','Invalid time format. Expected HH:mm.');
                }
            }
            if ($request->boolean('is_recurring') &&
                !$request->filled('recurring_type')
            ) {
                $validator->errors()->add('recurring_type','Recurring type is required.');
            }
        });
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors()
            ], 422);
        }
        DB::beginTransaction();
        try {
            $userId = $request->user()->userId ?? 1;
            $event->event_name =$request->event_name;
            $event->venue_id =$request->venue_id;
            $event->event_type_id =$request->event_type_id;
            $event->event_category_id =$request->event_category_id;
            $event->event_date =Carbon::parse($request->event_date)->format('Y-m-d');
            $event->event_end_date =Carbon::parse($request->event_end_date)->format('Y-m-d');
            $event->event_start_time =$request->event_start_time;
            $event->event_end_time =$request->event_end_time;
            $event->is_recurring =$request->boolean('is_recurring') ? 1 : 0;
            $event->recurring_type =$request->boolean('is_recurring')? $request->recurring_type: null;
            $event->event_venue_id =$request->event_venue_id;
            $event->conference_hall_id =$request->conference_hall_id;
            $companyType = strtolower(trim($request->input('organizing_company_type', '')));
            $event->organizing_company_type = in_array($companyType,['business', 'bussiness'],true) ? 'business' : 'management';
            $event->company_id =$request->company_id;
            $event->entity_id =$request->entity_id;
            $event->branch_id =$request->branch_id;
            $event->department_id =$request->department_id;
            $event->division_id =$request->division_id;
            $event->staff_id =$request->staff_id;
            $event->participant_id = $request->participant_id;
            $event->participant_count =$request->participant_count;
            $services = $request->input('service_id', []);
              if (!is_array($services)) {
                  $services = [];
              }
              $services = array_values(
                  array_filter(array_map('intval', $services),function ($id) {return $id > 0;}));
              $event->service_id = json_encode($services);
              $serviceData = $request->input('service_data', []);
              if (!is_array($serviceData)) {
                  $serviceData = [];
              }
              $cleanServiceData = [];
              foreach ($services as $serviceId) {
                  $cleanServiceData[$serviceId] = $serviceData[$serviceId] ?? '';
              }
            $event->service_details = json_encode($cleanServiceData);
            $event->notes =$request->notes;
            $event->description =$request->description;
            $event->feedback =$request->boolean('feedback') ? 1 : 0;
            $event->refreshment =$request->refreshment;
            $event->status = $request->filled('status')? (int) $request->status: $event->status;
            $event->updated_by =$userId;
            $event->save();
            DB::commit();
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Event updated successfully.',
                'data' => [
                    'event_id' => $event->sno,
                    'event' => $this->formatEvent(
                        $event,
                        true
                    )
                ]
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error(
                'Event Update Error',
                [
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                ]
            );
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Unable to update event.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null
            ], 500);
        }
    }
   private function formatEvent($event, bool $full = false): array
{
    $serviceIds = $event->service_id;
    if (is_string($serviceIds) &&$this->isJson($serviceIds)) {
        $serviceIds = json_decode($serviceIds, true);
    }
    if (!is_array($serviceIds)) {
        $serviceIds = [];
    }
    $serviceIds = array_values(
        array_filter(
            array_map('intval', $serviceIds)
        )
    );
    $services = [];
    if (!empty($serviceIds)) {
        $services = VisitorServiceModel::whereIn('sno', $serviceIds)
            ->where('status', 0)
            ->orderBy('sno', 'ASC')
            ->get(['sno', 'service'])
            ->map(function ($service) {
                return [
                    'id' => (int) $service->sno,
                    'name' => $service->service,
                ];
            })->values()->toArray();
    }
    $serviceDetails = $event->service_details;
    if (is_string($serviceDetails) && $this->isJson($serviceDetails)) {
        $serviceDetails = json_decode($serviceDetails, true);
    }
    if (!is_array($serviceDetails)) {
        $serviceDetails = [];
    }
    return [
        'sno' => $event->sno,
        'event_name' => $event->event_name,
        'venue_id' => $event->venue_id,
        'event_type_id' => $event->event_type_id,
        'event_category_id' => $event->event_category_id,
        'event_venue_id' => $event->event_venue_id,
        'participant_id' => $event->participant_id,
        'type_event' => $event->type_event ?? '-',
        'event_category_name' => $event->category_name ?? '-',
        'venue_name' => $event->venue_name ?? '-',
        'conference_hall_id' => $event->conference_hall_id ?? '-',
        'conference_hall_name' => $event->hall_name ?? '-',
        'participant_name' => $event->participant_name ?? '-',
        'event_date' => $this->formatDate($event->event_date),
        'event_end_date' => $this->formatDate($event->event_end_date),
        'event_start_time' => $this->formatTime($event->event_start_time),
        'event_end_time' => $this->formatTime($event->event_end_time),
        'is_recurring' => (int) $event->is_recurring,
        'recurring_type' => $event->recurring_type,
        'organizing_company_type' => $event->organizing_company_type,
        'company_id' => $event->company_id,
        'company_name' => $event->company_name ?? '-',
        'entity_id' => $event->entity_id,
        'entity_name' => $event->entity_name ?? '-',
        'branch_id' => $event->branch_id,
        'branch_name' => $event->branch_name ?? '-',
        'department_id' => $event->department_id,
        'department_name' => $event->department_name ?? '-',
        'division_id' => $event->division_id,
        'division_name' => $event->division_name ?? '-',
        'staff_id' => $event->staff_id,
        'staff_name' => $event->staff_name ?? '-',
        'participant_count' => $event->participant_count,
        'service_id' => $serviceIds,
        'services' => $services,
        'service_details' => $serviceDetails,
        'notes' => $event->notes,
        'description' => $event->description,
        'feedback' => (int) $event->feedback,
        'refreshment' => $event->refreshment,
        'status' => (int) $event->status,
        'created_by' => $event->created_by,
        'updated_by' => $event->updated_by,
    ];
}
    private function isJson($value): bool
{
    if (!is_string($value)) {
        return false;
    }
    json_decode($value, true);
    return json_last_error() === JSON_ERROR_NONE;
}
    private function formatDate($date): string
    {
        if (!$date) {
            return '';
        }
        try {
            return Carbon::parse($date)
                ->format('d-M-Y');
        } catch (\Throwable $e) {
            return (string) $date;
        }
    }
    private function formatTime($time): string{
    if (!$time) {
        return '';
    }
    try {
        return Carbon::parse($time)->format('H:i');
    } catch (\Throwable $e) {
        return (string) $time;
    }
}
    public function changeStatus(Request $request, $id): JsonResponse
{
    $event = EventManagementModel::find($id);
    if (!$event) {
        return response()->json([
            'success' => false,
            'status' => 404,
            'message' => 'Event not found.'
        ], 404);
    }
    $validator = Validator::make(
        $request->all(),['status' => ['required', 'integer', 'in:0,1'],]);
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Invalid status.',
            'errors' => $validator->errors()
        ], 422);
    }
    $event->status = (int) $request->status;
    $event->updated_by = Auth::id() ?? 1;
    $event->save();
    return response()->json([
        'success' => true,
        'status' => 200,
        'message' => $event->status === 1? 'Event activated successfully.': 'Event deactivated successfully.',
        'data' => [
            'event_id' => $event->sno,
            'status' => (int) $event->status
        ]
    ], 200);
}
    public function Delete($id): JsonResponse
    {
        $event = EventManagementModel::find($id);
        if (!$event) {
            return response()->json(
                [
                    'success' => false,
                    'status' => 404,
                    'message' => 'Event not found.'
                ],
                404
            );
        }
        try {
            $event->status = 2;
            $event->updated_by =Auth::id() ?? 1;
            $event->save();
            return response()->json(
                [
                    'success' => true,
                    'status' => 200,
                    'message' => 'Event deleted successfully.'
                ]
            );
        } catch (\Throwable $e) {
            Log::error('Event Delete Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine()]);
            return response()->json(
                [
                    'success' => false,
                    'status' => 500,
                    'message' => 'Unable to delete event.',
                    'error' => config('app.debug')
                        ? $e->getMessage()
                        : null
                ],
                500
            );
        }
    }
    public function getEntityByCompany(Request $request): JsonResponse
{
    $validator = Validator::make(
        $request->all(),['company_id' => ['required','integer']]);
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Invalid company.',
            'errors' => $validator->errors()
        ], 422);
    }

    $entityList = ManageEntityModel::where('company_id',$request->company_id)->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','entity_name','entity_short_name']);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $entityList
    ]);
}
    public function getBranchByEntity(Request $request): JsonResponse
{
    $validator = Validator::make($request->all(),['entity_id' => ['required','integer']]);
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Invalid entity.',
            'errors' => $validator->errors()
        ], 422);
    }
    $branchList = BranchModel::where('entity_id',$request->entity_id)->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','branch_name']);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $branchList
    ]);
}
    public function getDepartment(Request $request): JsonResponse
{
    $departments = DB::table('egc_department')->where('status', 0)->orderBy('department_name', 'ASC')->get(['sno','department_name',]);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $departments,
    ]);
}
    public function getDivisionByDepartment(Request $request): JsonResponse
{
    $validator = Validator::make($request->all(),['department_id' => ['required','integer']]);
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Invalid department.',
            'errors' => $validator->errors()
        ], 422);
    }
    $divisionList = DivisionModel::where('department_id',$request->department_id)->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','division_name']);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $divisionList
    ]);
}
   public function getStaff(Request $request): JsonResponse
{
    $validator = Validator::make($request->all(), ['department_id' => ['required','integer','exists:egc_department,sno',],
    ]);
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Invalid department.',
            'errors' => $validator->errors(),
        ], 422);
    }
    $staffs = DB::table('egc_staff')->where('department_id', $request->department_id)->where('status', 0)->where('sno', '>', 1)->orderBy('staff_name', 'ASC')->get(['sno','staff_name',]);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $staffs,
    ]);
}

    public function calender()
    {
        return view('content.corporate_admin.schedule_management.event_calender');
    }
    public function add()
{
    $companyList = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    $location_list = DB::table('egc_locations')->select('sno', 'area')->orderBy('area', 'ASC')->get();
    return view(
        'content.corporate_admin.schedule_management.event_add',
        [
            'company_list' => $companyList,
            'location_list' => $location_list,
        ]
    );
}
    public function edit($id)
    {
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get(['sno','company_name','company_base_color']);
        $event = EventManagementModel::where('sno', $id)->where('status', '!=', 2)->first();
        $location_list = DB::table('egc_locations')->select('sno', 'area')->orderBy('area', 'ASC')->get();
        if (!$event) {
            return redirect('/manage_event')->with('error', 'Event not found.');
        }

    $serviceIds = $event->service_id;
    if (is_string($serviceIds)) {
        $serviceIds = json_decode($serviceIds,true);
    }
    if (!is_array($serviceIds)) {
        $serviceIds = [];
    }
    $serviceDetails = $event->service_details;
    if (is_string($serviceDetails)) {
        $serviceDetails = json_decode($serviceDetails,true);
    }
    if (!is_array($serviceDetails)) {
        $serviceDetails = [];
    }
        return view('content.corporate_admin.schedule_management.event_edit',['event_id' => $id, 'location_list' => $location_list,'company_list' => $company_list,'event' => $event,], compact('event','serviceIds','serviceDetails'));
    }
    public function show($id): JsonResponse
{
    $event = $this->getEventWithRelations($id);
    if (!$event) {
        return response()->json([
            'success' => false,
            'status' => 404,
            'message' => 'Event not found.'
        ], 404);
    }
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $this->formatEvent($event, true)
    ]);
}
    public function day()
    {
        return view(
            'content.corporate_admin.schedule_management.event_day_view'
        );
    }
    public function ListeventType(): JsonResponse
    {
        $eventTypes = EventTypeModel::where('status',0)->orderBy('sno', 'ASC')->get();
        return response()->json(
            [
                'status' => 200,
                'message' => null,
                'error_msg' => null,
                'data' => $eventTypes
            ],
            200
        );
    }
    public function ListService(): JsonResponse
{
    $services = VisitorServiceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    return response()->json([
        'status' => 200,
        'message' => null,
        'error_msg' => null,
        'data' => $services
    ], 200);
}
    public function ListCompany(): JsonResponse
    {
        $companies = CompanyModel::where('status',0)->orderBy('sno', 'ASC')->get();
        return response()->json(
            [
                'status' => 200,
                'message' => null,
                'error_msg' => null,
                'data' => $companies
            ],
            200
        );
    }
}
