<?php
namespace App\Http\Controllers\corporate_admin\schedule_management;

use App\Http\Controllers\Controller;
use App\Models\ServiceLocationModel;
use App\Models\FacilityMaintenanceModel;
use App\Models\FacilityStatusLogModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Carbon\Carbon;
class FacilityMaintenance extends Controller
{
   public function index(Request $request)
    {
        $buildings = DB::table('egc_buildings')->select('sno', 'building_name')->get();
        $allowedPerPage = [5, 10, 25, 50, 100];
        $perPage = (int) $request->input('perpage', 25);
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $floors = DB::table('egc_building_floors')->select('sno', 'floor_name')->get();
        $locations = ServiceLocationModel::where('status', 0)->get();
        $tasks = DB::table('egc_crpt_facility_task')->select('sno', 'task_name')->where('status', 0)->get();
        $staff = DB::table('egc_staff')
            ->join('egc_job_role', 'egc_job_role.sno', '=', 'egc_staff.job_role_id')
            ->select('egc_staff.sno', 'egc_staff.staff_name')
            ->where('egc_staff.status', 0)
            ->where('egc_staff.department_id', 4)
            ->where('egc_staff.division_id', 7)
            ->get();
        $search = trim($request->input('search', ''));
        $works = DB::table('egc_crpt_facility_maintenance_work as work_crpt')
            ->join('egc_crpt_service_location as locat_crpt', 'locat_crpt.sno', '=', 'work_crpt.service_location_id')
            ->join('egc_crpt_facility_task as task_crpt', 'task_crpt.sno', '=', 'work_crpt.work_task_id')
            ->join('egc_staff as staff_crpt', 'staff_crpt.sno', '=', 'work_crpt.staff_id')
            ->join('egc_buildings as build_crpt', 'build_crpt.sno', '=', 'locat_crpt.building_id')
            ->join('egc_building_floors as floor_crpt', 'floor_crpt.sno', '=', 'locat_crpt.floor_id')
            ->whereIn('work_crpt.status', [0, 1, 3])
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('locat_crpt.service_location', 'LIKE', "%{$search}%")
                        ->orWhere('task_crpt.task_name', 'LIKE', "%{$search}%")
                        ->orWhere('staff_crpt.staff_name', 'LIKE', "%{$search}%")
                        ->orWhere('build_crpt.building_name', 'LIKE', "%{$search}%")
                        ->orWhere('floor_crpt.floor_name', 'LIKE', "%{$search}%")
                        ->orWhere('work_crpt.notes', 'LIKE', "%{$search}%");
                });
            })
            ->select('work_crpt.*','locat_crpt.service_location','task_crpt.task_name','staff_crpt.staff_name','build_crpt.building_name','floor_crpt.floor_name')
            ->orderByDesc('work_crpt.sno')->paginate($perPage)->withQueryString();
        return view('content.corporate_admin.schedule_management.facility_maintanence_list',compact('buildings','perPage','floors','locations','tasks','staff','works','search'));
    }
    public function storeLocation(Request $request)
{
    $validated = $request->validate([
        'building_id' => ['required','exists:egc_buildings,sno',],
        'floor_id' => ['required',Rule::exists('egc_building_floors', 'sno')->where('building_id', $request->input('building_id')),],
        'service_location' => ['required','string','max:255',],
    ]);
    $userId =  $request->user()->userId ?? 1;
    ServiceLocationModel::create([
        ...$validated,
        'created_by' => $userId,
        'updated_by' => $userId,
        'status' => 0,
    ]);
    return redirect()->back()->with(
        'success',
        'Service location added successfully.'
    );
}
    public function storeWork(Request $request)
    {
        $validated = $request->validate([
            'service_location_id' => ['required','exists:egc_crpt_service_location,sno',],
            'work_task_id' => ['required','exists:egc_crpt_facility_task,sno',],
            'time_line' => ['required',Rule::in([1, 2, 3, 4]),],
            'week_day' => ['nullable','integer','min:1','max:7',],
            'month_date' => ['nullable','date',],
            'custom_date' => ['nullable','date',],
            'staff_id' => ['required','exists:egc_staff,sno',],
            'notes' => ['required','string','max:255',],
        ]);
        if ($validated['time_line'] == 2 &&
            empty($validated['week_day'])) {
            return back()->withErrors(['week_day' => 'Select a weekday for weekly work.',])->withInput();
        }
       if (!empty($validated['month_date'])) {
            $validated['month_date'] = Carbon::createFromFormat(
                'd-M-Y',
                $validated['month_date']
            )->format('Y-m-d');
        }

        if (!empty($validated['custom_date'])) {
            $validated['custom_date'] = Carbon::createFromFormat(
                'd-M-Y',
                $validated['custom_date']
            )->format('Y-m-d');
        }
        $userId =  $request->user()->userId ?? 1;
        DB::transaction(function () use ($validated, $userId) {
            $work = FacilityMaintenanceModel::create([
                'service_location_id' => $validated['service_location_id'],
                'work_task_id' => $validated['work_task_id'],
                'time_line' => $validated['time_line'],
                'week_day' => $validated['time_line'] == 2? $validated['week_day'] : null,
                'month_date' => $validated['time_line'] == 3? $validated['month_date'] : null,
                'custom_date' => $validated['time_line'] == 4? $validated['custom_date'] : null,
                'staff_id' => $validated['staff_id'],
                'notes' => $validated['notes'],
                'created_by' => $userId,
                'updated_by' => $userId,
                'status' => 0,
            ]);
            FacilityStatusLogModel::create([
                'service_location_id' =>$work->service_location_id,
                'work_id' => $work->sno,
                'timeline_id' => $work->time_line,
                'created_by' => $userId,
                'updated_by' => $userId,
                'status' => 0,
            ]);
        });
        return redirect()->back()->with('success', 'Facility maintenance work assigned successfully.');
    }
    public function updateStatus(Request $request, $id)
    {
        $validated = $request->validate([
            'status' => [
                'required',
                Rule::in([1, 3]),
            ],
        ]);
        $userId =  $request->user()->userId ?? 1;
        DB::transaction(function () use ($id, $validated, $userId) {
            $work = FacilityMaintenanceModel::where('sno', $id)->lockForUpdate()->firstOrFail();
            $allowed = [
                0 => [1],
                1 => [3],
                3 => [],
            ];
            if (!in_array(
                (int) $validated['status'],
                $allowed[(int) $work->status] ?? [],
                true
            )) {
                abort(422, 'Invalid maintenance status transition.');
            }
            $work->update(['status' => $validated['status'],'updated_by' => $userId,]);
            FacilityStatusLogModel::create([
                'service_location_id' => $work->service_location_id,
                'work_id' => $work->sno,
                'timeline_id' => $work->time_line,
                'created_by' => $userId,
                'updated_by' => $userId,
                'status' => $validated['status'],
            ]);
        });
        return redirect()->back()->with('success', 'Maintenance status updated successfully.');
    }
    public function Delete($id)
    {
        $userId =  $request->user()->userId ?? 1;
        DB::transaction(function () use ($id, $userId) {
            $work = FacilityMaintenanceModel::where('sno', $id)->lockForUpdate()->firstOrFail();
            if ((int) $work->status === 2) {
                return;
            }
            $work->update(['status' => 2,'updated_by' => $userId,]);
            FacilityStatusLogModel::create([
                'service_location_id' => $work->service_location_id,
                'work_id' => $work->sno,
                'timeline_id' => $work->time_line,
                'created_by' => $userId,
                'updated_by' => $userId,
                'status' => 2,
            ]);
        });
        return redirect()->back()->with('success', 'Maintenance work deleted successfully.');
    }
    public function show($id)
{
    $work = DB::table('egc_crpt_facility_maintenance_work as work_crpt')
        ->join('egc_crpt_service_location as locat_crpt', 'locat_crpt.sno', '=', 'work_crpt.service_location_id')
        ->join('egc_crpt_facility_task as task_crpt', 'task_crpt.sno', '=', 'work_crpt.work_task_id')
        ->join('egc_staff as staff_crpt', 'staff_crpt.sno', '=', 'work_crpt.staff_id')
        ->join('egc_buildings as build_crpt', 'build_crpt.sno', '=', 'locat_crpt.building_id')
        ->join('egc_building_floors as floor_crpt', 'floor_crpt.sno', '=', 'locat_crpt.floor_id')
        ->where('work_crpt.sno', $id)
        ->whereIn('work_crpt.status', [0, 1, 3])
        ->select(
            'work_crpt.*',
            'locat_crpt.service_location',
            'task_crpt.task_name',
            'staff_crpt.staff_name',
            'build_crpt.building_name',
            'floor_crpt.floor_name'
        )
        ->first();

    abort_if(!$work, 404);

    return response()->json($work);
}

public function update(Request $request, $id)
{
    $validated = $request->validate([
        'service_location_id' => 'required|exists:egc_crpt_service_location,sno',
        'work_task_id' => 'required|exists:egc_crpt_facility_task,sno',
        'time_line' => ['required', Rule::in([1, 2, 3, 4])],
        'week_day' => 'nullable|integer|min:1|max:7',
        'month_date' => 'nullable|date',
        'custom_date' => 'nullable|date',
        'staff_id' => 'required|exists:egc_staff,sno',
        'notes' => 'required|string|max:255',
    ]);

    if ($validated['time_line'] == 2 && empty($validated['week_day'])) {
        return back()->withErrors([
            'week_day' => 'Select a weekday for weekly work.',
        ])->withInput();
    }

     if (!empty($validated['month_date'])) {
            $validated['month_date'] = Carbon::createFromFormat(
                'd-M-Y',
                $validated['month_date']
            )->format('Y-m-d');
        }
        if (!empty($validated['custom_date'])) {
            $validated['custom_date'] = Carbon::createFromFormat(
                'd-M-Y',
                $validated['custom_date']
            )->format('Y-m-d');
        }

    $userId =  $request->user()->userId ?? 1;

    $work = FacilityMaintenanceModel::where('sno', $id)
        ->whereIn('status', [0, 1])
        ->firstOrFail();

    $work->update([
        'service_location_id' => $validated['service_location_id'],
        'work_task_id' => $validated['work_task_id'],
        'time_line' => $validated['time_line'],
        'week_day' => $validated['time_line'] == 2 ? $validated['week_day'] : null,
        'month_date' => $validated['time_line'] == 3 ? $validated['month_date'] : null,
        'custom_date' => $validated['time_line'] == 4 ? $validated['custom_date'] : null,
        'staff_id' => $validated['staff_id'],
        'notes' => $validated['notes'],
        'updated_by' => $userId,
    ]);

    return redirect()->back()
        ->with('success', 'Facility maintenance work updated successfully.');
}
public function getBuildingFloors($buildingId)
{
    $floors = DB::table('egc_building_floors')->where('building_id', $buildingId)->select('sno', 'floor_name', 'floor_no')->orderBy('floor_no')->get();
    return response()->json($floors);
}
}
