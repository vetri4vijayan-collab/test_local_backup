<?php
namespace App\Http\Controllers\corporate_admin\schedule_management;
use App\Http\Controllers\Controller;
use App\Models\ConferenceRoomModel;
use App\Models\ConferenceFacilityListModel;
use App\Models\ConferenceStatusLogModel;
use App\Models\ConferenceMomModel;
use App\Models\ConferenceBookingModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Carbon\Carbon;

class ConferenceSupport extends Controller
{
    public function index(Request $request)
    {
        $locations = DB::table('egc_locations')->select('sno', 'area')->orderBy('area')->get();
        $buildings = DB::table('egc_buildings')->select('sno', 'building_name', 'location_id')->orderBy('sno')->get();
        $floors = DB::table('egc_building_floors')->select('sno', 'floor_name', 'building_id')->orderBy('sno')->get();
        $facilities = DB::table('egc_crpt_conference_facilities')->select('sno', 'facility_name')->where('status', '!=', 2)->orderBy('facility_name')->get();
        $rooms = ConferenceRoomModel::query()
            ->join('egc_locations as locat_crpt','locat_crpt.sno','=','egc_crpt_conference_room.location_id')
            ->join('egc_buildings as build_crpt','build_crpt.sno','=','egc_crpt_conference_room.conference_building_id')
            ->join('egc_building_floors as floor_crpt','floor_crpt.sno','=','egc_crpt_conference_room.conference_floor_id')
            ->select('egc_crpt_conference_room.*','locat_crpt.area','build_crpt.building_name','floor_crpt.floor_name')
            ->where('egc_crpt_conference_room.status', 0)
            ->orderByDesc('egc_crpt_conference_room.sno')
            ->get();
            $allowedPerPage = [5,10, 25, 50, 100];
    $perPage = (int) $request->input('perpage', 25);
    if (!in_array($perPage, $allowedPerPage, true)) {
        $perPage = 25;
    }
    $bookingsQuery = DB::table('egc_crpt_conference_booking as booking')
        ->join('egc_crpt_conference_room as room','room.sno','=','booking.conference_room_id')
        ->join('egc_locations as location','location.sno','=','room.location_id')
        ->join('egc_buildings as building','building.sno','=','room.conference_building_id')
        ->join('egc_building_floors as floor','floor.sno','=','room.conference_floor_id')
        ->leftJoin('egc_company as company','company.sno','=','booking.company_id')
        ->leftJoin('egc_entity as entity','entity.sno','=','booking.entity_id')
        ->leftJoin('egc_branch as branch','branch.sno','=','booking.branch_id')
        ->join('egc_department as department','department.sno','=','booking.department_id')
        ->join('egc_division as division','division.sno','=','booking.division_id')
        ->join('egc_staff as staff','staff.sno','=','booking.staff_id')
        ->leftJoinSub(
            DB::table('egc_crpt_conference_status_log')
                ->select('conference_room_id','location_id',DB::raw('MAX(sno) as latest_sno'))->groupBy('conference_room_id', 'location_id'),
            'latest_status',
            function ($join) {
                $join->on('latest_status.conference_room_id','=','room.sno')->on('latest_status.location_id','=','room.location_id');
            }
        )
        ->leftJoin('egc_crpt_conference_status_log as status_log','status_log.sno','=','latest_status.latest_sno')
        ->select(
            'booking.*',
            'room.conference_room',
            'room.location_id',
            'room.seatings',
            'location.area',
            'building.building_name',
            'floor.floor_name',
            'company.company_name',
            'entity.entity_name',
            'branch.branch_name',
            'department.department_name',
            'division.division_name',
            'staff.staff_name',
            'status_log.status as room_status'
        )
        ->where('booking.status', '!=', 2);
        $search = trim($request->input('search', ''));
        if ($search !== '') {
            $bookingsQuery->where(function ($query) use ($search) {
                $query->where('room.conference_room', 'LIKE', "%{$search}%")
                    ->orWhere('location.area', 'LIKE', "%{$search}%")
                    ->orWhere('building.building_name', 'LIKE', "%{$search}%")
                    ->orWhere('floor.floor_name', 'LIKE', "%{$search}%")
                    ->orWhere('booking.purpose_of_meeting', 'LIKE', "%{$search}%")
                    ->orWhere('staff.staff_name', 'LIKE', "%{$search}%")
                    ->orWhere('company.company_name', 'LIKE', "%{$search}%")
                    ->orWhere('entity.entity_name', 'LIKE', "%{$search}%")
                    ->orWhere('branch.branch_name', 'LIKE', "%{$search}%")
                    ->orWhere('department.department_name', 'LIKE', "%{$search}%")
                    ->orWhere('division.division_name', 'LIKE', "%{$search}%");
            });
        }
        $bookings = $bookingsQuery->orderByDesc('booking.sno')->paginate($perPage)->withQueryString();
        $companies = DB::table('egc_company')->select('sno', 'company_name')->where('status', 0)->orderBy('company_name')->get();
        $departments = DB::table('egc_department')->select('sno', 'department_name')->where('status', 0)->orderBy('department_name')->get();
        $divisions = DB::table('egc_division')->select('sno', 'division_name')->where('status', 0)->orderBy('division_name')->get();
        $staffs = DB::table('egc_staff')->select('sno', 'staff_name')->where('status', 0)->where('sno', '>', 1)->orderBy('staff_name')->get();
        $services = DB::table('egc_crpt_visitor_service')->select('sno', 'service')->where('status', 0)->orderBy('service')->get();
        return view('content.corporate_admin.schedule_management.conference_support_list',
            compact('locations','buildings','floors','perPage','facilities','rooms','bookings','companies','departments','divisions','staffs','services')
        );
    }
  public function calendarView(Request $request)
{
    $month = (int) $request->input('month', now()->month);
    $year = (int) $request->input('year', now()->year);
    if ($month < 1 || $month > 12 || $year < 1900 || $year > 2100) {
        abort(400, 'Invalid month or year.');
    }
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = $startDate->copy()->endOfMonth();
    $calendarMeetings = DB::table('egc_crpt_conference_booking as booking')
        ->leftJoin('egc_crpt_conference_room as room','room.sno','=','booking.conference_room_id')
        ->leftJoin('egc_company as company','company.sno','=','booking.company_id')
        ->whereBetween('booking.meeting_date', [
            $startDate->toDateString(),
            $endDate->toDateString()
        ])
        ->where('booking.status', '!=', 2)
        ->select('booking.meeting_date','booking.purpose_of_meeting','booking.meeting_time','booking.status','company.company_name','room.conference_room')
        ->orderBy('booking.meeting_date')
        ->orderBy('booking.meeting_time')
        ->get()
        ->map(function ($booking) {
            $statuses = [
                0 => 'Pending',
                1 => 'Booked',
                3 => 'Completed',
                4 => 'Cancelled',
            ];
            return [
                'date' => Carbon::parse($booking->meeting_date)
                    ->toDateString(),
                'title' => $booking->purpose_of_meeting,
                'company' => $booking->company_name ?? '',
                'room' => $booking->conference_room ?? '',
                'time' => $booking->meeting_time,
                'status' => $statuses[(int) $booking->status] ?? 'Unknown',
            ];
        })
        ->values();
    if ($request->ajax()) {
        return response()->json([
            'success' => true,
            'month' => $month,
            'year' => $year,
            'data' => $calendarMeetings,
        ]);
    }
    return view('content.corporate_admin.schedule_management.conference_calendar_view',compact('calendarMeetings', 'month', 'year'));
}
  public function day_view(Request $request)
{
    $inputDate = $request->query('date', now()->toDateString());
    try {
        $selectedDate = Carbon::createFromFormat('!Y-m-d', $inputDate)->format('Y-m-d');
    } catch (\Throwable $e) {
        abort(400, 'Invalid date.');
    }
    $date = Carbon::createFromFormat('!Y-m-d', $selectedDate);
    $startDate = $date->copy()->startOfMonth()->toDateString();
    $endDate = $date->copy()->endOfMonth()->toDateString();
    $meetingDates = DB::table('egc_crpt_conference_booking as booking')
        ->whereBetween('booking.meeting_date', [$startDate,$endDate])
        ->where('booking.status', '!=', 2)
        ->select('booking.meeting_date',DB::raw('COUNT(*) as total_meetings'))->groupBy('booking.meeting_date')->orderBy('booking.meeting_date')->get();
    $meetings = DB::table('egc_crpt_conference_booking as booking')
        ->leftJoin('egc_crpt_conference_room as room','room.sno','=','booking.conference_room_id')
        ->leftJoin('egc_company as company','company.sno','=','booking.company_id')
        ->whereDate('booking.meeting_date', $selectedDate)
        ->where('booking.status', '!=', 2)
        ->select(
            'booking.sno',
            'booking.purpose_of_meeting',
            'booking.meeting_date',
            'booking.meeting_time',
            'booking.status',
            'booking.organizing_company',
            'company.company_name',
            'room.conference_room'
        )
        ->orderBy('booking.meeting_time')->get();
    $statuses = [
        0 => 'Pending',
        1 => 'Booked',
        3 => 'Completed',
        4 => 'Cancelled',
    ];

    $meetings = $meetings->map(function ($meeting) use ($statuses) {
        $meeting->status_label = $statuses[(int) $meeting->status]?? 'Unknown';
        $meeting->status_class = match ((int) $meeting->status) {
            1 => 'bg-primary',
            3 => 'bg-success',
            4 => 'bg-danger',
            default => 'bg-secondary',
        };
        $meeting->display_time = $meeting->meeting_time? Carbon::parse($meeting->meeting_time)->format('h:i A'): 'Time not specified';
        $meeting->display_company = $meeting->company_name ?: 'Internal';
        return $meeting;
    });
    return view(
        'content.corporate_admin.schedule_management.conference_day_view',
        compact('selectedDate', 'meetingDates', 'meetings')
    );
}
    public function getBuildingsByLocation(Request $request)
{
    $validated = $request->validate([
        'location_id' => ['required','integer','exists:egc_locations,sno',],
    ]);
    $buildings = DB::table('egc_buildings')->where('location_id', $validated['location_id'])->orderBy('building_name')->get(['sno','building_name',]);
    return response()->json([
        'success' => true,
        'data' => $buildings,
    ]);
}
public function getFloorsByBuilding(Request $request)
{
    $validated = $request->validate([
        'building_id' => ['required','integer','exists:egc_buildings,sno',],
        'location_id' => ['required','integer','exists:egc_locations,sno',],
    ]);

    $buildingExists = DB::table('egc_buildings')->where('sno', $validated['building_id'])->where('location_id', $validated['location_id'])->exists();
    if (!$buildingExists) {
        return response()->json([
            'success' => false,
            'message' => 'The selected building does not belong to this location.',
            'data' => [],
        ], 422);
    }
    $floors = DB::table('egc_building_floors')->where('building_id', $validated['building_id'])->orderBy('floor_name')->get(['sno','floor_name',]);
    return response()->json([
        'success' => true,
        'data' => $floors,
    ]);
}
    public function storeRoom(Request $request)
    {
        $validated = $request->validate([
            'location_id' => ['required','integer','exists:egc_locations,sno',],
            'conference_building_id' => ['required','integer','exists:egc_buildings,sno',],
            'conference_floor_id' => ['required','integer',Rule::exists('egc_building_floors', 'sno')->where('building_id',$request->input('conference_building_id')),],
            'conference_room' => ['required','string','max:255',],
            'seatings' => ['required','integer','min:1',],
            'facility_id' => ['required','array','min:1',],
            'facility_id.*' => ['required','integer','exists:egc_crpt_conference_facilities,sno',],
        ]);
        $userId = $request->user()->userId ?? 1;;
        $room = DB::transaction(function () use ($validated, $userId) {
            return ConferenceRoomModel::create([
                'location_id' => $validated['location_id'],
                'conference_building_id' => $validated['conference_building_id'],
                'conference_floor_id' => $validated['conference_floor_id'],
                'conference_room' => $validated['conference_room'],
                'seatings' => $validated['seatings'],
                'facility_id' => implode(',', $validated['facility_id']),
                'created_by' => $userId,
                'updated_by' => $userId,
                'status' => 0,
            ]);
        });
        return response()->json([
            'success' => true,
            'message' => 'Conference room added successfully.',
            'data' => $room,
        ], 201);
    }
    public function getEntityByCompany(Request $request)
    {
        $validated = $request->validate(['company_id' => ['required','integer','exists:egc_company,sno',],]);
        $entities = DB::table('egc_entity')->where('company_id', $validated['company_id'])->where('status', 0)->orderBy('sno')->get(['sno', 'entity_name', 'entity_short_name']);
        return response()->json([
            'success' => true,
            'data' => $entities,
        ]);
    }
    public function getBranchByEntity(Request $request)
    {
        $validated = $request->validate([
            'entity_id' => ['required','integer','exists:egc_entity,sno',],
        ]);
        $branches = DB::table('egc_branch')->where('entity_id', $validated['entity_id'])->where('status', 0)->orderBy('sno')->get(['sno', 'branch_name']);
        return response()->json([
            'success' => true,
            'data' => $branches,
        ]);
    }
    public function getDepartmentByEntity(Request $request)
{
    $departments = DB::table('egc_department')
        ->where('status', 0)->orderBy('department_name')->get(['sno','department_name']);
    return response()->json([
        'success' => true,
        'data' => $departments,
    ]);
}
    public function getDivisionByDepartment(Request $request)
    {
        $validated = $request->validate([
            'department_id' => ['required','integer','exists:egc_department,sno',],
        ]);
        $divisions = DB::table('egc_division')
            ->where('department_id', $validated['department_id'])->where('status', 0)->orderBy('sno')->get(['sno', 'division_name']);
        return response()->json([
            'success' => true,
            'data' => $divisions,
        ]);
    }
    public function getStaffByEntity(Request $request)
    {
        $validated = $request->validate([
            'department_id' => ['required','integer','exists:egc_department,sno',],
        ]);
        $staffs = DB::table('egc_staff')
            ->where('department_id', $validated['department_id'])->where('status', 0)->where('sno', '>', 1)->orderBy('sno')->get(['sno', 'staff_name']);
        return response()->json([
            'success' => true,
            'data' => $staffs,
        ]);
    }
    public function getFacilities()
    {
        $facilities = DB::table('egc_crpt_conference_facilities')->where('status', '!=', 2)->orderBy('sno')->get(['sno', 'facility_name']);
        return response()->json([
            'success' => true,
            'data' => $facilities,
        ]);
    }
    public function getRooms()
    {
        $rooms = DB::table('egc_crpt_conference_room as room')
            ->join('egc_locations as location','location.sno','=','room.location_id')
            ->join('egc_buildings as building','building.sno','=','room.conference_building_id')
            ->join('egc_building_floors as floor','floor.sno','=','room.conference_floor_id')
            ->where('room.status', 0)
            ->orderBy('room.conference_room')
            ->get(['room.sno','room.conference_room','room.location_id','room.seatings','building.building_name','floor.floor_name','location.area',]);
        return response()->json([
            'success' => true,
            'data' => $rooms,
        ]);
    }
  public function storeBooking(Request $request)
{
    $time = trim((string) $request->input('meeting_time'));
    $normalizedTime = null;
    $formats = [
        'H:i',
        'H:i:s',
        'h:i A',
        'h:i a',
        'g:i A',
        'g:i a',
        'h:i:s A',
        'h:i:s a',
    ];
    foreach ($formats as $format) {
        try {$parsedTime = Carbon::createFromFormat('!' . $format,$time);
            $errors = Carbon::getLastErrors();
            if ($parsedTime !== false && ($errors === false ||($errors['warning_count'] === 0 && $errors['error_count'] === 0)) && $parsedTime->format($format) === $time) {
                $normalizedTime = $parsedTime->format('h:i A');
                break;
            }
        } catch (\Throwable $e) {
        }
    }
    if ($normalizedTime !== null) {
        $request->merge([
            'meeting_time' => $normalizedTime,
        ]);
    }
    $validated = $request->validate([
        'conference_room_id' => ['required','integer','exists:egc_crpt_conference_room,sno',],
        'purpose_of_meeting' => ['required','string','max:255',],
        'member_count' => ['required','integer','min:1',],
        'organizing_company' => ['required',Rule::in(['option1', 'option2']),],
        'company_id' => ['nullable','required_if:organizing_company,option1','integer','exists:egc_company,sno',],
        'entity_id' => ['nullable','required_if:organizing_company,option1','integer','exists:egc_entity,sno',],
        'branch_id' => ['nullable','required_if:organizing_company,option1','integer','exists:egc_branch,sno',],
        'department_id' => ['required','integer','exists:egc_department,sno',],
        'division_id' => ['required','integer','exists:egc_division,sno',],
        'staff_id' => ['required','integer','exists:egc_staff,sno',],
        'facilites_id' => ['required','array','min:1',],
        'facilites_id.*' => ['required','integer','exists:egc_crpt_conference_facilities,sno',],
        'meeting_date' => ['required','date_format:d-M-Y',],
        'meeting_time' => ['required','date_format:h:i A',],
        'service_id' => ['required','array','min:1',],
        'service_id.*' => ['required','integer','distinct','exists:egc_crpt_visitor_service,sno',],
        'service_details' => ['nullable','json',],
    ]);
    $serviceDetails = null;
    if (!empty($validated['service_details'])) {
        $serviceDetails = json_decode($validated['service_details'],true);
        if (!is_array($serviceDetails)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid service details.',
            ], 422);
        }
    }
    $room = ConferenceRoomModel::where('sno',$validated['conference_room_id'])->where('status', 0)->first();
    if (!$room) {
        return response()->json([
            'success' => false,
            'message' => 'The selected conference room is unavailable.',
        ], 422);
    }
    if ((int) $validated['member_count'] > (int) $room->seatings) {
        return response()->json([
            'success' => false,
            'message' => 'Member count exceeds the room seating capacity.',
        ], 422);
    }
    $meetingDate = Carbon::createFromFormat('d-M-Y',$validated['meeting_date'])->format('Y-m-d');
    $meetingTime = Carbon::createFromFormat('!h:i A',$validated['meeting_time'])->format('H:i:s');
    $serviceIds = implode(',', $validated['service_id']);
    $facilityIds = implode(',', $validated['facilites_id']);
    $userId =  $request->user()->userId ?? 1;
    $booking = DB::transaction(function () use (
        $validated,
        $room,
        $userId,
        $meetingDate,
        $meetingTime,
        $serviceIds,
        $facilityIds,
        $serviceDetails
    ) {
        $booking = ConferenceBookingModel::create([
            'conference_room_id' => $room->sno,
            'purpose_of_meeting' => $validated['purpose_of_meeting'],
            'member_count' => $validated['member_count'],
            'organizing_company' => $validated['organizing_company'],
            'company_id' => $validated['organizing_company'] === 'option1'? $validated['company_id']: null,
            'entity_id' => $validated['organizing_company'] === 'option1'? $validated['entity_id']: null,
            'branch_id' => $validated['organizing_company'] === 'option1'? $validated['branch_id']: null,
            'department_id' => $validated['department_id'],
            'division_id' => $validated['division_id'],
            'staff_id' => $validated['staff_id'],
            'facilites_id' => $facilityIds,
            'meeting_date' => $meetingDate,
            'meeting_time' => $meetingTime,
            'service_id' => $serviceIds,
            'service_details' => $serviceDetails !== null? json_encode($serviceDetails): null,
            'created_by' => $userId,
            'updated_by' => $userId,
            'status' => 1,
        ]);
        DB::table('egc_crpt_conference_status_log')->insert([
            'conference_room_id' => $room->sno,
            'location_id' => $room->location_id,
            'status' => 1,
            'created_by' => $userId,
            'updated_by' => $userId,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return $booking;
    });
    return response()->json([
        'success' => true,
        'message' => 'Booking added successfully.',
        'data' => $booking,
    ], 201);
}
    public function getMomDetails($bookingId)
    {
        $booking = DB::table('egc_crpt_conference_booking as booking')
            ->join('egc_crpt_conference_room as room','room.sno','=','booking.conference_room_id')
            ->join('egc_locations as location','location.sno','=','room.location_id')
            ->join('egc_buildings as building','building.sno','=','room.conference_building_id')
            ->join('egc_building_floors as floor','floor.sno','=','room.conference_floor_id')
            ->leftJoin('egc_company as company','company.sno','=','booking.company_id')
            ->leftJoin('egc_entity as entity','entity.sno','=','booking.entity_id')
            ->leftJoin('egc_branch as branch','branch.sno','=','booking.branch_id')
            ->join('egc_department as department','department.sno','=','booking.department_id')
            ->join('egc_division as division','division.sno','=','booking.division_id')
            ->join('egc_staff as staff','staff.sno','=','booking.staff_id')->where('booking.sno', $bookingId)
            ->select(
                'booking.*',
                'room.conference_room',
                'room.location_id',
                'location.area',
                'building.building_name',
                'floor.floor_name',
                'company.company_name',
                'entity.entity_name',
                'branch.branch_name',
                'department.department_name',
                'division.division_name',
                'staff.staff_name'
            )->first();
        if (!$booking) {
            return response()->json([
                'success' => false,
                'message' => 'Booking not found.',
            ], 404);
        }
        $momPoints = ConferenceMomModel::where('conference_room_id',$booking->conference_room_id)->where('location_id', $booking->location_id)->where('status', '!=', 2)->orderBy('sno')->get();
        return response()->json([
            'success' => true,
            'data' => $booking,
            'mom_points' => $momPoints,
        ]);
    }
    public function updateStatus(Request $request, $id)
{
    $validated = $request->validate([
        'status' => ['required', 'integer', Rule::in([0, 1, 3, 4])],
    ]);
    $userId =  $request->user()->userId ?? 1;
    DB::transaction(function () use ($id, $validated, $userId) {
        $booking = ConferenceBookingModel::where('sno', $id)->lockForUpdate()->firstOrFail();
        $room = ConferenceRoomModel::where('sno',$booking->conference_room_id)->firstOrFail();
        $status = (int) $validated['status'];
        $now = now();
        $booking->status = $status;
        $booking->updated_by = $userId;
        $booking->updated_at = $now;
        $booking->save();
        DB::table('egc_crpt_conference_status_log')->insert([
            'conference_room_id' => $room->sno,
            'location_id'        => $room->location_id,
            'status'              => $status,
            'created_by'          => $userId,
            'created_at'          => $now,
            'updated_by'          => $userId,
            'updated_at'          => $now,
        ]);
    });
    return back()->with(
        'success',
        'Conference booking status updated successfully.'
    );
}
public function storeMom(Request $request)
{
    $validated = $request->validate([
        'booking_id'   => ['required', 'integer', 'exists:egc_crpt_conference_booking,sno'],
        'mom_points'   => ['required', 'array', 'min:1'],
        'mom_points.*' => ['required', 'string', 'max:5000'],
        'attachment'   => ['nullable', 'array'],
        'attachment.*' => ['file', 'max:10240'],
    ]);
    $userId =  $request->user()->userId ?? 1;
    $booking = ConferenceBookingModel::where('sno',$validated['booking_id'])->firstOrFail();
    if ((int) $booking->status !== 3) {
        return response()->json([
            'success' => false,
            'message' => 'MoM can only be submitted for completed bookings.',
        ], 422);
    }
    $room = ConferenceRoomModel::where('sno',$booking->conference_room_id)->firstOrFail();
    $roomId = $room->sno;
    $locationId = $room->location_id;
    $files = [];
    try {
        foreach ($request->file('attachment', []) as $file) {
            $files[] = $file->store('conference-mom', 'public');
        }
        DB::transaction(function () use ($validated,$userId,$roomId,$locationId,$files) {
            foreach ($validated['mom_points'] as $point) {
                ConferenceMomModel::create([
                    'mom_points'         => trim($point),
                    'conference_room_id' => $roomId,
                    'location_id'        => $locationId,
                    'attachment'         => $files ? json_encode($files) : null,
                    'created_by'         => $userId,
                    'updated_by'         => $userId,
                    'created_at'         => now(),
                    'updated_at'         => now(),
                    'status'             => 0,
                ]);
            }
        });
    } catch (\Throwable $e) {
        foreach ($files as $file) {
            Storage::disk('public')->delete($file);
        }
        throw $e;
    }
    return response()->json([
        'success' => true,
        'message' => 'MoM saved successfully.',
    ]);
}
public function momBookingDetails($bookingId)
{
    $booking = DB::table('egc_crpt_conference_booking as booking')
        ->join('egc_crpt_conference_room as room','room.sno','=','booking.conference_room_id')
        ->join('egc_locations as location','location.sno','=','room.location_id')
        ->join('egc_buildings as building','building.sno','=','room.conference_building_id')
        ->join('egc_building_floors as floor','floor.sno','=','room.conference_floor_id')
        ->leftJoin('egc_company as company','company.sno','=','booking.company_id')
        ->leftJoin('egc_entity as entity','entity.sno','=','booking.entity_id')
        ->leftJoin('egc_branch as branch','branch.sno','=','booking.branch_id')
        ->join('egc_department as department','department.sno','=','booking.department_id')
        ->join('egc_division as division','division.sno','=','booking.division_id')
        ->join('egc_staff as staff','staff.sno','=','booking.staff_id')
        ->where('booking.sno', $bookingId)->where('booking.status', '!=', 2)
        ->select([
            'booking.sno as booking_id',
            'booking.purpose_of_meeting',
            'booking.meeting_date',
            'booking.meeting_time',
            'booking.member_count',
            'booking.company_id',
            'booking.entity_id',
            'booking.branch_id',
            'booking.department_id',
            'booking.division_id',
            'booking.staff_id',
            'company.company_name',
            'entity.entity_name',
            'branch.branch_name',
            'department.department_name',
            'division.division_name',
            'staff.staff_name',
            'room.conference_room',
            'room.location_id',
            'location.area',
            'building.building_name',
            'floor.floor_name',
        ])->first();
    if (!$booking) {
        return response()->json([
            'success' => false,
            'message' => 'Conference booking not found.',
        ], 404);
    }
    return response()->json([
        'success' => true,
        'data' => $booking,
    ]);
}
public function momDetails($id)
{
    $booking = DB::table('egc_crpt_conference_booking as booking')
        ->join('egc_crpt_conference_room as room','room.sno','=','booking.conference_room_id')
        ->join('egc_locations as location','location.sno','=','room.location_id')
        ->leftJoin('egc_company as company','company.sno','=','booking.company_id')
        ->leftJoin('egc_entity as entity','entity.sno','=','booking.entity_id')
        ->leftJoin('egc_branch as branch','branch.sno','=','booking.branch_id')
        ->join('egc_department as department','department.sno','=','booking.department_id')
        ->join('egc_division as division','division.sno','=','booking.division_id')
        ->join('egc_staff as staff','staff.sno','=','booking.staff_id')
        ->where('booking.sno', $id)->where('booking.status', '!=', 2)
        ->select([
            'booking.sno as id',
            'booking.purpose_of_meeting as purpose',
            'booking.meeting_date as date',
            'booking.meeting_time as time',
            'booking.organizing_company',
            'company.company_name',
            'entity.entity_name',
            'branch.branch_name',
            'department.department_name',
            'division.division_name',
            'staff.staff_name',
            'room.conference_room',
            'location.area as location',
        ])->first();
    if (!$booking) {
        return response()->json([
            'success' => false,
            'message' => 'Conference booking not found.',
        ], 404);
    }
    $staffs = [];
    if (!empty($booking->staff_name)) {
        $staffs[] = ['staff_name' => $booking->staff_name,];
    }
    $mom = DB::table('egc_crpt_mom_points')->where('conference_room_id', function ($query) use ($id) {
            $query->select('conference_room_id')->from('egc_crpt_conference_booking')->where('sno', $id);
        })
        ->where('status', '!=', 2)->get();
    return response()->json([
        'success' => true,
        'data' => [
            'id' => $booking->id,
            'company_name' => $booking->company_name,
            'client' => $booking->entity_name ?: $booking->branch_name,
            'project' => $booking->division_name?: $booking->department_name,
            'purpose' => $booking->purpose,
            'conference_room' => $booking->conference_room,
            'location' => $booking->location,
            'date' => $booking->date,
            'time' => $booking->time,
            'staffs' => $staffs,
        ],
        'mom' => $mom,
    ]);
}
public function searchMomBookings(Request $request)
{
    $keyword = trim((string) $request->input('keyword', ''));
    $bookings = DB::table('egc_crpt_conference_booking as booking')
        ->leftJoin('egc_crpt_conference_room as room','room.sno','=','booking.conference_room_id')->leftJoin('egc_company as company','company.sno','=','booking.company_id')
        ->where('booking.status', '!=', 2)
        ->when($keyword !== '', function ($query) use ($keyword) {
            $query->where(function ($subQuery) use ($keyword) {
                $subQuery->where('company.company_name', 'like', "%{$keyword}%")->orWhere('room.conference_room', 'like', "%{$keyword}%")->orWhere('booking.purpose_of_meeting','like',"%{$keyword}%");
            });
        })
        ->select([
            'booking.sno',
            'booking.purpose_of_meeting',
            'booking.meeting_date',
            'booking.meeting_time',
            'company.company_name',
            'room.conference_room',
        ])
        ->orderByDesc('booking.sno')->limit(50)->get();
    return response()->json([
        'success' => true,
        'data' => $bookings,
    ]);
}
public function edit($id)
{
    $booking = ConferenceBookingModel::where('sno', $id)->firstOrFail();
    return response()->json([
        'success' => true,
        'data' => [
            'id' => $booking->sno,
            'conference_room_id' => $booking->conference_room_id,
            'purpose_of_meeting' => $booking->purpose_of_meeting,
            'member_count' => $booking->member_count,
            'organizing_company' => $booking->organizing_company,
            'company_id' => $booking->company_id,
            'entity_id' => $booking->entity_id,
            'branch_id' => $booking->branch_id,
            'department_id' => $booking->department_id,
            'division_id' => $booking->division_id,
            'staff_id' => $booking->staff_id,
            'meeting_date' => $booking->meeting_date,
            'meeting_time' => $booking->meeting_time,
            'facility_ids' => $booking->facilites_id
                ? array_map('strval', explode(',', $booking->facilites_id))
                : [],
            'service_ids' => $booking->service_id
                ? array_map('strval', explode(',', $booking->service_id))
                : [],
            'service_details' => $booking->service_details,
        ],
    ]);
}

public function update(Request $request, $id)
{
    $booking = ConferenceBookingModel::findOrFail($id);
    $userId =  $request->user()->userId ?? 1;
    $validated = $request->validate([
        'conference_room_id' => ['required','integer','exists:egc_crpt_conference_room,sno',],
        'purpose_of_meeting' => ['required','string','max:255',],
        'member_count' => ['required','integer','min:1',],
        'company_id' => ['nullable','integer','exists:egc_company,sno',],
        'entity_id' => ['nullable','integer','exists:egc_entity,sno',],
        'branch_id' => ['nullable','integer','exists:egc_branch,sno',],
        'department_id' => ['required','integer','exists:egc_department,sno',],
        'division_id' => ['required','integer','exists:egc_division,sno',],
        'staff_id' => ['required','integer','exists:egc_staff,sno',],
        'meeting_date' => ['required','date_format:d-M-Y',],
        'meeting_time' => ['required','date_format:g:i A',],
        'service_id' => ['required','array','min:1',],
        'service_id.*' => ['required','integer','distinct','exists:egc_crpt_visitor_service,sno',],
        'facility_id' => ['required','array','min:1',],
        'facility_id.*' => ['required','integer','distinct','exists:egc_crpt_conference_facilities,sno',],
        'service_details' => ['nullable','json',],
    ]);
    $room = ConferenceRoomModel::where('sno',$validated['conference_room_id'])->where('status', 0)->first();
    if (!$room) {
        return response()->json([
            'success' => false,
            'message' => 'The selected conference room is unavailable.',
        ], 422);
    }
    if ((int) $validated['member_count'] > (int) $room->seatings) {
        return response()->json([
            'success' => false,
            'message' => 'Member count exceeds the room seating capacity.',
        ], 422);
    }
    $meetingDate = Carbon::createFromFormat('d-M-Y',$validated['meeting_date'])->format('Y-m-d');
    $meetingTime = Carbon::createFromFormat('!h:i A',$validated['meeting_time'])->format('H:i:s');
    $serviceIds = implode(',', $validated['service_id']);
    $facilityIds = implode(',', $validated['facility_id']);
    $serviceDetails = [];
    if (!empty($validated['service_details'])) {
        $serviceDetails = json_decode($validated['service_details'],true);
        if (!is_array($serviceDetails)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid service details.',
            ], 422);
        }
    }
    DB::transaction(function () use (
        $booking,
        $validated,
        $meetingDate,
        $meetingTime,
        $serviceIds,
        $facilityIds,
        $userId,
        $serviceDetails
    ) {
        $booking->conference_room_id = $validated['conference_room_id'];
        $booking->purpose_of_meeting = $validated['purpose_of_meeting'];
        $booking->member_count = $validated['member_count'];
        $booking->company_id = $validated['company_id'] ?? null;
        $booking->entity_id = $validated['entity_id'] ?? null;
        $booking->branch_id = $validated['branch_id'] ?? null;
        $booking->department_id = $validated['department_id'];
        $booking->division_id = $validated['division_id'];
        $booking->staff_id = $validated['staff_id'];
        $booking->facilites_id = $facilityIds;
        $booking->meeting_date = $meetingDate;
        $booking->meeting_time = $meetingTime;
        $booking->service_id = $serviceIds;
        $booking->service_details = !empty($serviceDetails) ? json_encode($serviceDetails) : null;
        $booking->updated_by = $userId;
        $booking->updated_at = now();
        $booking->save();
    });

    return response()->json([
        'success' => true,
        'message' => 'Booking updated successfully.',
    ]);
}
public function Delete($id)
    {
        $upd_CourseCategoryModel = ConferenceBookingModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();
        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
