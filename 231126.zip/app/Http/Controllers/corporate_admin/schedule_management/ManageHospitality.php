<?php
namespace App\Http\Controllers\corporate_admin\schedule_management;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
class ManageHospitality extends Controller
{
    public function index()
    {
        return view('content.corporate_admin.schedule_management.hospitality_schedule');
    }
    public function view()
    {
        return view('content.corporate_admin.schedule_management.calender_view');
    }
    public function calendarCounts(Request $request)
{
    $validated = $request->validate([
        'month' => ['required', 'date_format:Y-m'],
    ]);
    $month = Carbon::createFromFormat('!Y-m', $validated['month']);
    $startDate = $month->copy()->startOfMonth()->toDateString();
    $nextMonth = $month->copy()->addMonth()->startOfMonth()->toDateString();
    $endDate = $month->copy()->endOfMonth()->toDateString();
    $visitors = DB::table('egc_crpt_visitor_schedule')
        ->selectRaw('DATE(visit_date) as schedule_date, COUNT(*) as total')->where('visit_date', '>=', $startDate)
        ->where('visit_date', '<', $nextMonth)->where('status', '!=', 2)->groupByRaw('DATE(visit_date)')->pluck('total', 'schedule_date');
    $meetings = DB::table('egc_crpt_conference_booking')
        ->selectRaw('DATE(meeting_date) as schedule_date, COUNT(*) as total')->where('meeting_date', '>=', $startDate)
        ->where('meeting_date', '<', $nextMonth)->where('status', '!=', 2)->groupByRaw('DATE(meeting_date)')->pluck('total', 'schedule_date');
    $pantry = DB::table('egc_crpt_conference_booking')
        ->selectRaw('DATE(meeting_date) as schedule_date, COUNT(*) as total')->where('meeting_date', '>=', $startDate)->where('meeting_date', '<', $nextMonth)
        ->where('status', '!=', 2)->whereNotNull('service_details')->whereRaw("TRIM(service_details) NOT IN ('', '[]', 'null')")->groupByRaw('DATE(meeting_date)')
        ->pluck('total', 'schedule_date');
    $events = DB::table('egc_crpt_event_management')
        ->selectRaw('DATE(event_date) as schedule_date, COUNT(*) as total')->where('event_date', '>=', $startDate)
        ->where('event_date', '<', $nextMonth)->where('status', '!=', 2)->groupByRaw('DATE(event_date)')->pluck('total', 'schedule_date');
    $result = [];
    $cursor = $month->copy()->startOfMonth();
    while ($cursor->lte($month->copy()->endOfMonth())) {
        $date = $cursor->toDateString();
        $result[$date] = [
            'visitors' => (int) ($visitors[$date] ?? 0),
            'meetings' => (int) ($meetings[$date] ?? 0),
            'pantry'   => (int) ($pantry[$date] ?? 0),
            'events'   => (int) ($events[$date] ?? 0),
            'travel'   => 0,
            'support'  => 0,
        ];
        $cursor->addDay();
    }
    return response()->json([
        'status' => 200,
        'data' => $result,
        'summary' => [
            'visitors' => (int) $visitors->sum(),
            'meetings' => (int) $meetings->sum(),
            'pantry'   => (int) $pantry->sum(),
            'events'   => (int) $events->sum(),
            'travel'   => 0,
            'support'  => 0,
        ],
    ]);
}
}
