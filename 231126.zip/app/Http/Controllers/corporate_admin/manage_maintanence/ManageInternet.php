<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\CompanyModel;
use App\Models\IspCategoryModel;
use App\Models\InternetTypeModel;
use App\Models\BuildingModel;
use App\Models\BuildingFloorModel;
use App\Models\ManageInternetModel;
use App\Models\LogIssueTypeModel;
use App\Models\AddLogIssueModel;
use App\Models\PaymentBillModel;
use App\Models\AssignedToModel;
use App\Models\IpAddressModel;

class ManageInternet extends Controller
{
  public function index(Request $request)
{
    $helper = new \App\Helpers\Helpers();
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $level = ManageInternetModel::where('egc_crpt_manage_internet.status', '!=', 2)
        ->select('egc_crpt_manage_internet.*', 'egc_buildings.building_name', 'egc_building_floors.floor_no',
         'egc_crpt_internet_type.internet_type', 'egc_crpt_isp_category.isp_category')
        ->Join('egc_buildings', 'egc_crpt_manage_internet.building_id', 'egc_buildings.sno')
        ->join('egc_building_floors', 'egc_crpt_manage_internet.floor_id', 'egc_building_floors.sno')
        ->join('egc_crpt_isp_category', 'egc_crpt_manage_internet.isp_type_id', 'egc_crpt_isp_category.sno')
        ->join('egc_crpt_internet_type', 'egc_crpt_manage_internet.internet_type_id', 'egc_crpt_internet_type.sno');

    if ($search_filter != '') {
        $level->where(function ($subquery) use ($search_filter) {
            $subquery->where('plan', 'LIKE', "%{$search_filter}%");
            $subquery->where('isp_category', 'LIKE', "%{$search_filter}%");
            $subquery->where('building_name', 'LIKE', "%{$search_filter}%");
        });
    }
    $level = $level->orderBy('sno', 'ASC')->paginate($perpage);
    

    $secondQuery = IpAddressModel::where('egc_crpt_ip_address.status', '!=', 2)
    ->select('egc_crpt_ip_address.*', 'egc_crpt_manage_internet.accounts_id','egc_crpt_assigned_to.assigned_to')
    ->leftjoin('egc_crpt_assigned_to', 'egc_crpt_ip_address.assigned_to_id', 'egc_crpt_assigned_to.sno')
    ->Join('egc_crpt_manage_internet', 'egc_crpt_ip_address.accounts_id', 'egc_crpt_manage_internet.sno');
    if ($search_filter != '') {
        $secondQuery->where('ip_address', 'LIKE', "%{$search_filter}%");
    }
    $secondTableData = $secondQuery->orderBy('sno', 'ASC')->get(); 


    $third = AddLogIssueModel::where('egc_crpt_add_log_issue.status', '!=', 2)
        ->select('egc_crpt_add_log_issue.*', 'egc_buildings.building_name', 'egc_crpt_log_issue_types.issue_types',
         'egc_crpt_isp_category.isp_category','egc_crpt_manage_internet.accounts_id')
        ->Join('egc_buildings', 'egc_crpt_add_log_issue.building_id', 'egc_buildings.sno')
        ->Join('egc_crpt_manage_internet', 'egc_crpt_add_log_issue.accounts_id', 'egc_crpt_manage_internet.sno')
        ->join('egc_crpt_log_issue_types', 'egc_crpt_add_log_issue.issue_type_id', 'egc_crpt_log_issue_types.sno')
        ->join('egc_crpt_isp_category', 'egc_crpt_add_log_issue.isp_category_id', 'egc_crpt_isp_category.sno');
        if ($search_filter != '') {
        $third->where('building_name', 'LIKE', "%{$search_filter}%");
    }
     $thirdTableData = $third->orderBy('sno', 'ASC')->get();


     $fourth = PaymentBillModel::where('egc_crpt_payment_bill.status', '!=', 2)
        ->select('egc_crpt_payment_bill.*','egc_crpt_isp_category.isp_category','egc_crpt_manage_internet.accounts_id')
        ->Join('egc_crpt_manage_internet', 'egc_crpt_payment_bill.account_id', 'egc_crpt_manage_internet.sno')
        ->join('egc_crpt_isp_category', 'egc_crpt_payment_bill.isp_type_id', 'egc_crpt_isp_category.sno');
        if ($search_filter != '') {
        $fourth->where('bill_no', 'LIKE', "%{$search_filter}%");
    }
     $fourthTableData = $fourth->orderBy('sno', 'ASC')->get();



    if ($request->ajax()) {

        $dataOne = $level->map(function ($item) use ($helper) {
            return [
                'sno' =>$item->sno,
                'accounts_id'    => $item->accounts_id,
                'account_number' => $item->account_number,
                'status'         => $item->status,
                'building'       => $item->building_name,
                'floor'          => $item->floor_no,
                'isp_category'   => $item->isp_category,
                'internet_type'  => $item->internet_type,
                'plan'           => $item->plan,
                'price'          => $item->price,
                'public_ips'     => $item->public_ips,
                'item'           => $item,
                'encrypted_id'   => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });
        $dataTwo = $secondTableData->map(function ($item) use ($helper) {
            return [
                'sno' =>$item->sno,
                'ip_address'           => $item->ip_address,
                'ip_type'         => $item->ip_type,        
                'accounts_id'      => $item->accounts_id,     
                'assigned_to'      => $item->assigned_to,   
                'status'         => $item->status,  
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });
        $dataThree = $thirdTableData->map(function ($item) use ($helper) {
            return [
                'sno'    =>$item->sno,
                'reference'           => $item->reference,
                'isp_type'         => $item->isp_category,        
                'issue_type'         => $item->issue_types,        
                'accounts_id'      => $item->accounts_id,     
                'date'      => $item->raised_date,   
                'building'      => $item->building_name,   
                'owner'      => $item->owner,   
                'priority'      => $item->priority,   
                'status'         => $item->status,  
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });
         $dataFour = $fourthTableData->map(function ($item) use ($helper) {
            $check=$item->status;
            if($check==0){
                  $current_date = now();
                 $payment_date=$item->due_date;
                 
                if($current_date>$payment_date){
                    $item->status=3;  
                }
                }
            return [
                'sno'    =>$item->sno,
                'bill_no'           => $item->bill_no,
                'account_id'         => $item->accounts_id,        
                'isp_type'         => $item->isp_category,        
                'period'         => $item->period_type,        
                'amount'      => $item->amount,   
                'due_date'      => $item->due_date,     
                'status'         => $item->status,  
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });
         
  
        return response()->json([        
                'data'         => $dataOne,
                'current_page' => $level->currentPage(),
                'last_page'    => $level->lastPage(),
                'total'        => $level->total(),
                'datas'         => $dataTwo,
                'datathree'   => $dataThree,
                'datafour'   => $dataFour
        ]);
    }        
    $total_issues = AddLogIssueModel::where('egc_crpt_add_log_issue.status', 0)
        ->count('egc_crpt_add_log_issue.sno');
    
    $total_issues_para = AddLogIssueModel::where('egc_crpt_add_log_issue.status', 3)
        ->count('egc_crpt_add_log_issue.sno');
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    $isp_status = AddLogIssueModel::where('egc_crpt_add_log_issue.status', 0)->orderBy('sno', 'ASC')->first();

    $isp_list = IspCategoryModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    $type_list = InternetTypeModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    $building_list = BuildingModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    $account_list = ManageInternetModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    $assign_list = AssignedToModel::where('status', 0)->orderBy('sno', 'ASC')->get();

    $issue_type = LogIssueTypeModel::where('status', 0)->orderBy('sno', 'ASC')->get();

    $active_accounts = ManageInternetModel::where('egc_crpt_manage_internet.status', 0)->count('egc_crpt_manage_internet.sno');
    $total_accounts = ManageInternetModel::count('egc_crpt_manage_internet.sno');
    $amount_spend = ManageInternetModel::where('egc_crpt_manage_internet.status', '=', 0)
        ->whereYear('egc_crpt_manage_internet.activate_date', now()->year)
        ->whereMonth('egc_crpt_manage_internet.activate_date', now()->month)
        ->sum('egc_crpt_manage_internet.price');
        
    $total_ips = ManageInternetModel::sum('egc_crpt_manage_internet.public_ips');

    $total_issues = AddLogIssueModel::where('egc_crpt_add_log_issue.status', 0)
         ->count('egc_crpt_add_log_issue.sno');
    
    $amount_paid = PaymentBillModel::where('egc_crpt_payment_bill.status', '=', 1)
        ->sum('egc_crpt_payment_bill.amount');

    $due_amount = PaymentBillModel::where('egc_crpt_payment_bill.status',0)
        ->whereYear('egc_crpt_payment_bill.due_date', now()->year)
        ->whereMonth('egc_crpt_payment_bill.due_date', now()->month)
        ->sum('egc_crpt_payment_bill.amount');
    
    $overdue_count = PaymentBillModel::where('egc_crpt_payment_bill.status','=', 0)
        ->whereYear('egc_crpt_payment_bill.due_date', now()->year)
        ->whereMonth('egc_crpt_payment_bill.due_date', now()->month)
        ->whereDay('egc_crpt_payment_bill.due_date','>', now()->day)
        ->count('egc_crpt_payment_bill.sno');
    
    return view('content.corporate_admin.manage_maintanence.manage_internet.internet_list', [
        'search_filter'   => $search_filter,
        'isp_list'        => $isp_list,
        'assign_list'     => $assign_list,
        'issue_type'      => $issue_type,
        'amount_paid'      => $amount_paid,
        'overdue_count'      => $overdue_count,
        'due_amount'      => $due_amount,
        'type_list'       => $type_list,
        'company_list'       => $company_list,
        'total_issues'    => $total_issues,
        'total_issues_para'    => $total_issues_para,
        'level'   => $level,
        'building_list'   => $building_list,
        'account_list'    => $account_list,
        'total_ips'       => $total_ips,
        'active_accounts' => $active_accounts,
        'amount_spend'    => $amount_spend,
        'total_accounts'  => $total_accounts,
        'perpage'         => $perpage,
    ]);
}



   public function FloorList(Request $request)
  {
    
    $building_id = $request->building_id;

    $floor = BuildingFloorModel::where('building_id', $building_id)->where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $floor,
    ], 200);
  }

   public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
             'isp_category' => 'required|exists:egc_crpt_isp_category,sno',
             'building' => 'required|exists:egc_buildings,sno',
             'floor' => 'required|exists:egc_building_floors,sno',
             'internet_type' => 'required|exists:egc_crpt_internet_type,sno',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $account_number = $request->account_number;
            $internet_type = $request->input('internet_type');
            $isp_category = $request->input('isp_category');
            $building = $request->input('building');
            $floor = $request->input('floor');

            $chk = ManageInternetModel::where('account_number', ucwords($account_number))->where('building_id', ucwords($building))->where('floor_id', ucwords($floor))->where('status', '!=', 2)->first();
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Data has been already created!',
                ]);
            } else {
                $check = InternetTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $acc_id=$check->account_id;
                $sno=$check->sno;
                $padding=3;
                $id=$acc_id+$sno+1;
                $formattedId = sprintf("INT"."-"."%0" . $padding . "d", $id);
               
                $add_category = new ManageInternetModel();
                $add_category->accounts_id = $formattedId;
                $add_category->account_number = Ucfirst($account_number);
                $add_category->isp_type_id = Ucfirst($isp_category);
                $add_category->building_id = Ucfirst($building);
                $add_category->floor_id = Ucfirst($floor);
                $add_category->internet_type_id = Ucfirst($internet_type);
                $add_category->price = $request->price;
                $add_category->plan = $request->plan;
                $add_category->public_ips = $request->public_ips;
                $add_category->activate_date = $request->activation_date;
                $add_category->created_by = 1;
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Manage Internet added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Manage Internet!',
                    ]);
                }
            }
        }
    }

    public function AddIp(Request $request)
    {
   
        $validator = Validator::make($request->all(), [
             'accounts_id' => 'required|exists:egc_crpt_manage_internet,sno',
             
             
             'ip_internet_type' => 'required|exists:egc_crpt_internet_type,sno',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $accounts_id = $request->input('accounts_id');
            $internet_type = $request->input('ip_internet_type');
            $assigned_to = $request->assigned_to_id;
         
            $ip_address = $request->ip_address;
        
            $chk = IpAddressModel::where('ip_address', ucwords($ip_address))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'IP has been  already created!',
                ]);
            } else {
                $add_category = new IpAddressModel();
                $add_category->accounts_id = Ucfirst($accounts_id);
                $add_category->ip_type = $request->ip_type;
                $add_category->ip_address = $request->ip_address;
                $add_category->ip_internet_type_id = Ucfirst($internet_type);
                $add_category->assigned_to_id = $assigned_to;
                $add_category->notes = $request->notes;
                $add_category->created_by = 1;
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'IP Address added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the IP Address!',
                    ]);
                }
            }
        }
    }
public function AddIssue(Request $request)
    {
   
        $validator = Validator::make($request->all(), [             
             'issues_type' => 'required|exists:egc_crpt_log_issue_types,sno',
             'acct_id' => 'required|exists:egc_crpt_manage_internet,sno',
        ]);
        if ($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $issue_type = $request->input('issues_type');
            $accounts_id = $request->input('acct_id');
    
            $check = ManageInternetModel::where('sno', $accounts_id)->first();
            
            $account_id=$check->accounts_id;
            $isp_type=$check->isp_type_id;
            $building=$check->building_id;
            $chk = AddLogIssueModel::where('accounts_id', ucwords($account_id))->where('issue_type_id', ucwords($issue_type))->where('isp_category_id', ucwords($isp_type))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Log Issue has been  already created!',
                ]);
            } else {
                $add_category = new AddLogIssueModel();
                $add_category->issue_type_id = $issue_type;
                $add_category->accounts_id = $accounts_id;
                $add_category->isp_category_id = $isp_type;
                $add_category->building_id = $building;
                $add_category->raised_date = $request->raised_date;
                $add_category->priority = $request->priority;
                $add_category->description = $request->description;
                $add_category->owner = $request->owner;
                $add_category->reference = $request->isp_refer;
                $add_category->created_by = 1;
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Log Issues added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Log Issues!',
                    ]);
                }
            }
        }
    }

    public function StatusIssue($id, Request $request)
    {
        
        $upd_CourseCategoryModel = AddLogIssueModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function View($id)
    {
        $data = ManageInternetModel::where('sno', $id)->first();    
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function AddBill(Request $request)
    {
       
        $validator = Validator::make($request->all(), [             
             'payment_isp_type' => 'required|exists:egc_crpt_isp_category,sno',
             'payment_acc_id' => 'required|exists:egc_crpt_manage_internet,sno',
             'building_id' => 'required|exists:egc_buildings,sno',

        ]);
        if ($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $company_id = $request->company_name ?? 0;
            $accounts_id = $request->input('payment_acc_id');
            $isp_type = $request->input('payment_isp_type');
            $building_id = $request->input('building_id');

            $chk = PaymentBillModel::where('account_id', ucwords($accounts_id))->where('isp_type_id', ucwords($isp_type))->where('building_id', ucwords($building_id))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Payment Bill has been already created!',
                ]);
            } else {
                $check = PaymentBillModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                $sno=$check->sno??0;
                $padding=3;
                $id=$sno+1;
                $bill_no = sprintf("NET"."-"."INV"."-"."%0" . $padding ."d", $id);


                $add_category = new PaymentBillModel();
                $add_category->bill_no = $bill_no;
                $add_category->company_id = $company_id;
                $add_category->account_id = $accounts_id;
                $add_category->isp_type_id = $isp_type;
                $add_category->building_id = $building_id;
                $add_category->due_date = $request->due_date;
                $add_category->amount = $request->pay_amount;
                $add_category->document_number = $request->document_number;
                $add_category->gst_number = $request->gst_number;
                $add_category->period_type = $request->period_type;
                $add_category->created_by = 1;
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Payment Bill added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Payment Bill!',
                    ]);
                }
            }
        }
    }
public function ViewAssign($id)
    {
        $data = IpAddressModel::where('sno', $id)->first();    
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }
}
