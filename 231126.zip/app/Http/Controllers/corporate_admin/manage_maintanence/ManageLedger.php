<?php
namespace App\Http\Controllers\corporate_admin\manage_maintanence;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageLedger extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.manage_maintanence.manage_ledger.ledger_list');
  }
public function manageLedger(Request $request)
{
    $today = Carbon::today()->format('Y-m-d');
    $latestAdjustments = DB::table('egc_crpt_lease_deposit_adjustments')
        ->select('lease_id',DB::raw('MAX(sno) as latest_id'))->groupBy('lease_id');
    $query = DB::table('egc_crpt_manage_lease as lease')
        ->join('egc_crpt_manage_lessor as lessor', 'lessor.sno', '=', 'lease.lessor_id')
        ->join('egc_buildings as building', 'building.sno', '=', 'lease.building_id')
        ->leftJoinSub($latestAdjustments, 'latest', function ($join) {
            $join->on('latest.lease_id', '=', 'lease.sno');
        })
        ->leftJoin('egc_crpt_lease_deposit_adjustments as adjustment','adjustment.sno','=','latest.latest_id')->where('lease.status', '!=', 2)
        ->select(
            'lease.sno',
            'lease.start_date',
            'lease.end_date',
            'lease.paid_on',
            'lease.amount as deposit_amount',
            'lease.status',
            'lessor.lessor_name',
            'building.building_name',
            DB::raw('COALESCE(adjustment.adjustment_amount, 0) as adjustment_amount'),
            DB::raw('COALESCE(adjustment.final_amount, lease.amount) as final_deposit_amount'),
            DB::raw('COALESCE(adjustment.repair_expenses, 0) as repair_expenses'),
            DB::raw('COALESCE(adjustment.refund_amount, lease.amount) as refund_amount'),'adjustment.adjustment_date');
    if ($request->filled('search_filter')) {
        $search = trim($request->search_filter);
        $query->where(function ($q) use ($search) {
            $q->where('building.building_name', 'like', "%{$search}%")
              ->orWhere('lessor.lessor_name', 'like', "%{$search}%")
              ->orWhere('lease.amount', 'like', "%{$search}%");
        });
    }
    $summaryQuery = clone $query;
    $summary = [
        'total_deposits' => (clone $summaryQuery)->sum(DB::raw('COALESCE(adjustment.final_amount, lease.amount)')),
        'expired_deposits' => (clone $summaryQuery)->where('lease.status', '!=', 5)->whereDate('lease.end_date', '<', $today)
            ->sum(DB::raw('COALESCE(adjustment.final_amount, lease.amount)')),
        'pending_refund' => (clone $summaryQuery)->where('lease.status', '!=', 5)->sum(DB::raw('COALESCE(adjustment.refund_amount, lease.amount)')),
        'refunded_ytd' => (clone $summaryQuery)->where('lease.status', 5)->sum(DB::raw('COALESCE(adjustment.refund_amount, lease.amount)')),
    ];
    $totalQuery = clone $query;
    $totals = [
        'deposit_amount' => (clone $totalQuery)->sum('lease.amount'),
        'adjustment_amount' => (clone $totalQuery)->sum(DB::raw('COALESCE(adjustment.adjustment_amount, 0)')),
        'final_deposit_amount' => (clone $totalQuery)->sum(DB::raw('COALESCE(adjustment.final_amount, lease.amount)')),
        'repair_expenses' => (clone $totalQuery)->sum(DB::raw('COALESCE(adjustment.repair_expenses, 0)')),
        'refund_amount' => (clone $totalQuery)->sum(DB::raw('COALESCE(adjustment.refund_amount, lease.amount)')),
        'balance' => (clone $totalQuery)->where('lease.status', '!=', 5)->sum(DB::raw('COALESCE(adjustment.refund_amount, lease.amount)')),
    ];
    $perpage = (int) $request->input('sorting_filter', 10);
    $perpage = in_array($perpage, [5, 10, 25, 100, 500]) ? $perpage : 10;
    $records = $query->orderByDesc('lease.sno')->paginate($perpage);
    $records->getCollection()->transform(function ($item) use ($today) {
    $item->paid_on = $item->paid_on ? Carbon::parse($item->paid_on)->format('d M Y') : '-';
    $item->adjustment_date = $item->adjustment_date ? Carbon::parse($item->adjustment_date)->format('d M Y') : '-';
    $item->status = $this->getLeaseStatus($item);
    $statusNames = [
        0 => 'Active',
        1 => 'Inactive',
        3 => 'Renew Due',
        4 => 'Expired',
        5 => 'Closed',
    ];
    $item->status_name = $statusNames[$item->status] ?? 'Unknown';
    $item->is_closed = (int) $item->status === 5;
    $item->balance = $item->is_closed ? 0 : (float) $item->refund_amount;
    return $item;
});
    return response()->json([
    'status' => 200,
    'data' => $records->items(),
    'current_page' => $records->currentPage(),
    'last_page' => $records->lastPage(),
    'total' => $records->total(),
    'summary' => $summary,
    'totals' => $totals
    ]);
}
private function getLeaseStatus($lease, $manualStatus = null)
{
    $status = (int) ($manualStatus ?? $lease->status);
    if ($status === 5) {
        return 5;
    }
    $today = Carbon::today();
    $startDate = !empty($lease->start_date)? Carbon::parse($lease->start_date)->startOfDay(): null;
    $endDate = !empty($lease->end_date)? Carbon::parse($lease->end_date)->startOfDay(): null;
    if ($endDate && $endDate->lt($today)) {
        return 4;
    }
    if ($startDate && $startDate->lte($today) && $endDate && $endDate->lte($today->copy()->addDays(30))) {
        return 3;
    }
    return in_array($status, [0, 1], true) ? $status : 0;
}
}
//coalesce for first non null value
