<?php
namespace App\Http\Controllers\corporate_admin\manage_maintanence;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use App\Models\StaffModel;
use Carbon\Carbon;
use App\Models\LeaseTerminateCheckListModel;
use App\Models\TerminateClosureModel;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Models\ManageLessorModel;
use App\Models\ManageLeaseModel;
use Illuminate\Http\Request;
use App\Models\LeaseDepositAdjustment;
class LeaseRegister extends Controller
{
 public function index(Request $request)
  {
      $allowedPerPage = [5, 10, 25, 50, 100];
      $perPage = (int) $request->input('perpage', 25);
      if (!in_array($perPage, $allowedPerPage, true)) {
          $perPage = 25;
      }
      $search = trim($request->input('search', ''));
      $leaseTable = (new ManageLeaseModel())->getTable();
      $today = Carbon::today()->toDateString();
      $renewDueDate = Carbon::today()->addDays(30)->toDateString();
      $lessorTable = (new ManageLessorModel())->getTable();
      $floorQuery = DB::table('egc_crpt_manage_lease_floors as mapping')
          ->join('egc_building_floors as floor','floor.sno','=','mapping.floor_id')
          ->select('mapping.lease_id',DB::raw("GROUP_CONCAT(DISTINCT floor.floor_name ORDER BY floor.sno SEPARATOR ', ') as floor_names"))
          ->groupBy('mapping.lease_id');
      $leasesQuery = DB::table($leaseTable . ' as lease')
          ->join($lessorTable . ' as lessor','lessor.sno','=','lease.lessor_id')
          ->join('egc_buildings as building','building.sno','=','lease.building_id')
          ->leftJoin('egc_entity as entity','entity.sno','=','lease.entity_id')
          ->leftJoin('egc_branch as branch','branch.sno','=','lease.branch_id')
          ->leftJoinSub($floorQuery,'lease_floors',function ($join) {$join->on('lease_floors.lease_id','=','lease.sno');
              })
          ->select('lease.*','lessor.lessor_name','building.building_name','entity.entity_name','branch.branch_name','lease_floors.floor_names')
          ->where('lease.status', '!=', 2);
      if ($search !== '') {
          $leasesQuery->where(function ($query) use ($search) {
              $query->where('building.building_name', 'LIKE', "%{$search}%")
                  ->orWhere('lease_floors.floor_names', 'LIKE', "%{$search}%")
                  ->orWhere('entity.entity_name', 'LIKE', "%{$search}%")
                  ->orWhere('branch.branch_name', 'LIKE', "%{$search}%")
                  ->orWhere('lessor.lessor_name', 'LIKE', "%{$search}%")
                  ->orWhere('lease.payment_reference', 'LIKE', "%{$search}%");
          });
      }
      $leases = $leasesQuery->orderByDesc('lease.sno')->paginate($perPage)->withQueryString();
      $helper = new \App\Helpers\Helpers();
      $generalSetting = $helper->general_setting_data();
      $generalEntityName = $generalSetting->title ?? '';
      $leases->getCollection()->transform(function ($lease) use ($generalEntityName) {
          if ((int) $lease->entity_id === 0) {
              $lease->entity_name = $generalEntityName;
          }
          $lease->floor_names = $lease->floor_names ?: '';
          $lease->next_due_date = $this->getNextLeaseDueDate($lease);
          $lease->status = $this->getLeaseStatus($lease);
          return $lease;
      });
      if ($request->ajax() || $request->expectsJson()) {
          return response()->json([
              'status' => 200,
              'data' => $leases->items(),
              'current_page' => $leases->currentPage(),
              'last_page' => $leases->lastPage(),
              'total' => $leases->total(),
              'per_page' => $leases->perPage(),
          ]);
      }
      return view('content.corporate_admin.manage_maintanence.manage_lease.lease_list',compact('leases', 'perPage'));
  }
  private function getNextLeaseDueDate($lease)
{
    if (empty($lease->start_date) || empty($lease->due_day)) {
        return null;
    }
    try {
        $intervals = [
            1 => 1,
            2 => 3,
            3 => 12,
        ];
        $months = $intervals[(int) $lease->frequency] ?? 1;
        $today = Carbon::today();
        $startDate = Carbon::parse($lease->start_date);
        $dueDay = (int) $lease->due_day;
        $dueDate = $startDate->copy()->startOfMonth()->day(min($dueDay, $startDate->daysInMonth));
        while ($dueDate->lt($today)) {
            $dueDate->addMonthsNoOverflow($months);
            $dueDate->day(min($dueDay, $dueDate->daysInMonth));
        }
        if (!empty($lease->end_date)) {
            $endDate = Carbon::parse($lease->end_date);
            if ($dueDate->gt($endDate)) {
                return null;
            }
        }
        return $dueDate->format('Y-m-d');
    } catch (\Throwable $e) {
        return null;
    }
}
private function getLeaseStatus($lease, $manualStatus = null)
{
    $status = (int) ($manualStatus ?? $lease->status);
    if ($status === 5) {
        return 5;
    }
    $today = Carbon::today();
    $startDate = !empty($lease->start_date)? Carbon::parse($lease->start_date)->startOfDay(): null;
    $endDate = !empty($lease->end_date)? Carbon::parse($lease->end_date)->startOfDay(): null;
    if ($endDate && $endDate->lt($today)) {
        return 4;
    }
    if ($startDate && $startDate->lte($today) && $endDate && $endDate->lte($today->copy()->addDays(30))) {
        return 3;
    }
    return in_array($status, [0, 1], true) ? $status : 0;
}
  public function add()
  {
    return view('content.corporate_admin.manage_maintanence.manage_lease.add_lease');
  }
  public function edit($id)
{
    $lease = ManageLeaseModel::where('sno', $id)->where('status', '!=', 2)->firstOrFail();
    $selectedFloorIds = DB::table('egc_crpt_manage_lease_floors')->where('lease_id', $id)->pluck('floor_id')->toArray();
    $existingDocuments = json_decode($lease->document_upload ?? '[]', true) ?? [];
    return view('content.corporate_admin.manage_maintanence.manage_lease.edit_lease',compact('lease', 'selectedFloorIds', 'existingDocuments'));
}
  public function view()
  {
    return view('content.corporate_admin.manage_maintanence.manage_lease.view_lease');
  }
  public function terminate_lease($id)
{
    $leaseTable = (new ManageLeaseModel())->getTable();
    $lease = DB::table($leaseTable . ' as lease')
        ->join('egc_buildings as building', 'building.sno', '=', 'lease.building_id')
        ->leftJoin('egc_crpt_manage_lessor as lessor', 'lessor.sno', '=', 'lease.lessor_id')
        ->leftJoin('egc_cities as city', 'city.id', '=', 'lessor.city_id')
        ->leftJoin('egc_entity as entity', 'entity.sno', '=', 'lease.entity_id')
        ->leftJoin('egc_branch as branch', 'branch.sno', '=', 'lease.branch_id')
        ->where('lease.sno', $id)
        ->where('lease.status', '!=', 2)
        ->select('lease.*','building.building_name','city.name as city_name','entity.entity_name','branch.branch_name')->first();
    if (!$lease) {
        abort(404, 'Lease not found');
    }
    $helper = new \App\Helpers\Helpers();
    $generalSetting = $helper->general_setting_data();
    if ((int) $lease->entity_id === 0) {
        $lease->entity_name = $generalSetting->title ?? '';
    }
    $lease->status = $this->getLeaseStatus($lease);
    $statusNames = [
        0 => 'Active',
        1 => 'Inactive',
        3 => 'Renew Due',
        4 => 'Expired',
        5 => 'Closed',
    ];
    $statusName = $statusNames[$lease->status] ?? 'Unknown';
    $monthlyRent = (float) $lease->monthly_rent;
    $effectiveDate = !empty($lease->start_date) ? Carbon::parse($lease->start_date)->format('d-M-Y') : '-';
    $depositAmount = (float) $lease->amount;
    $depositEquivalentMonths = $monthlyRent > 0 ? round($depositAmount / $monthlyRent, 2): 0;
    $latestDepositAdjustment = DB::table('egc_crpt_lease_deposit_adjustments')->where('lease_id', $id)->orderByDesc('sno')->first();
    $depositAdjustments = $latestDepositAdjustment ? (float) $latestDepositAdjustment->adjustment_amount : 0;
    $depositAdjustmentDate = $latestDepositAdjustment ? Carbon::parse($latestDepositAdjustment->adjustment_date)->format('d-M-Y') : '-';
    $finalDepositAmount = $latestDepositAdjustment ? (float) $latestDepositAdjustment->final_amount : $depositAmount;
    $repairExpenses = $latestDepositAdjustment ? (float) $latestDepositAdjustment->repair_expenses : 0;
    $refundDue = $latestDepositAdjustment ? (float) $latestDepositAdjustment->refund_amount : $depositAmount;
    $checklist = DB::table('egc_crpt_lease_terminate_checklist')->where('lease_id', $id)->where('status', '!=', 2)->get();
    $totalTasks = $checklist->count();
    $completedTasks = $checklist->where('is_completed', 1)->count();
    $progressPercentage = $totalTasks > 0 ? round(($completedTasks / $totalTasks) * 100) : 0;
    return view('content.corporate_admin.manage_maintanence.manage_lease.termination_checklist',compact('lease','depositAmount','repairExpenses','monthlyRent','finalDepositAmount','statusName','effectiveDate','refundDue','depositAdjustments','completedTasks','totalTasks','progressPercentage'));
}
   public function ListLessor()
    {
        $lessors = ManageLessorModel::where('status', 0)->select('sno', 'lessor_name')->orderBy('lessor_name', 'asc')->get();
        return response()->json([
            'status' => 200,
            'message' => 'Lessor fetched successfully.',
            'data' => $lessors,
        ]);
    }
    public function details($id)
  {
      $lessor = ManageLessorModel::with('city')->where('sno', $id)->where('status', '!=', 2)->first();
      if (!$lessor) {
          return response()->json([
              'status' => 404,
              'message' => 'Lessor not found!'
          ], 404);
      }
      return response()->json([
          'status' => 200,
          'data' => [
              'sno' => $lessor->sno,
              'lessor_name' => $lessor->lessor_name,
              'contact' => $lessor->contact_person ?? '',
              'phone' => $lessor->mobile_number ?? '',
              'city_name' => $lessor->city->name ?? '',
              'pan_number' => $lessor->pan_number ?? '',
              'gstin' => $lessor->gstin ?? '',
              'kyc_status' => $lessor->kyc_status ?? 0,
          ]
      ]);
  }
public function ListBuildings()
{
    $buildings = DB::table('egc_buildings')->orderBy('sno')->get(['sno', 'building_name']);
    return response()->json([
        'status' => 200,
        'data' => $buildings
    ]);
}
public function getFloorsByBuilding(Request $request)
{
    $validated = $request->validate([
        'building_id' => ['required', 'integer', 'exists:egc_buildings,sno']
    ]);
    $floors = DB::table('egc_building_floors')->where('building_id', $validated['building_id'])->orderBy('sno')->get(['sno', 'floor_name', 'building_id']);
    return response()->json([
        'status' => 200,
        'data' => $floors
    ]);
}
public function ListEntities()
{
    $helper = new \App\Helpers\Helpers();
    $generalSetting = $helper->general_setting_data();
    $entities = DB::table('egc_entity')->where('status', 0)->orderBy('sno')->get(['sno','entity_name','entity_short_name']);
    if ($generalSetting) {
        $entities->prepend((object) [
            'sno' => 0,
            'entity_name' => $generalSetting->title,
            'entity_short_name' => ''
        ]);
    }
    return response()->json([
        'status' => 200,
        'data' => $entities
    ]);
}
public function getBranchByEntity(Request $request)
{
    $validated = $request->validate(['entity_id' => ['required', 'integer', 'min:0']]);
    if ($validated['entity_id'] == 0) {
        return response()->json([
            'status' => 200,
            'data' => []
        ]);
    }
    $entityExists = DB::table('egc_entity')->where('sno', $validated['entity_id'])->where('status', 0)->exists();
    if (!$entityExists) {
        return response()->json([
            'status' => 422,
            'message' => 'Invalid entity selected.'
        ], 422);
    }
    $branches = DB::table('egc_branch')->where('entity_id', $validated['entity_id'])->where('status', 0)->orderBy('sno')->get(['sno', 'branch_name']);
    return response()->json([
        'status' => 200,
        'data' => $branches
    ]);
    return $branches;
}
public function store(Request $request)
{  $userId = $request->user()->userId ?? 1;
    $validator = Validator::make($request->all(), [
        'lessor_id' => ['required', 'integer'],
        'building_id' => ['required', 'integer', 'exists:egc_buildings,sno'],
        'entity_id' => ['required', 'integer', 'min:0'],
        'branch_id' => ['nullable', 'integer', 'required_unless:entity_id,0'],
        'floor_id' => ['required', 'array', 'min:1'],
        'floor_id.*' => ['required', 'integer'],
        'start_date' => ['required', 'date'],
        'end_date' => ['required', 'date', 'after:start_date'],
        'lock_in_months' => ['required', 'numeric', 'min:0'],
        'notice_period' => ['required', 'numeric', 'min:0'],
        'term_length' => ['required', 'numeric', 'min:1'],
        'monthly_rent' => ['required', 'numeric', 'min:0'],
        'frequency' => ['required', 'in:1,2,3'],
        'due_day' => ['required', 'integer', 'between:1,31'],
        'ann_escalation' => ['required', 'numeric', 'min:0'],
        'deposit_month_rent' => ['required', 'numeric', 'min:0'],
        'amount' => ['required', 'numeric', 'min:0'],
        'bargain_adjustment' => ['required', 'numeric', 'min:0'],
        'paid_on' => ['required', 'date'],
        'payment_reference' => ['required', 'string', 'max:255'],
        'documents.*' => ['nullable', 'file', 'mimes:pdf,docx,jpg,jpeg,png', 'max:20480'],
        'document_types' => ['nullable', 'array'],
    ]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'errors' => $validator->errors()
        ], 422);
    }
    try {
        DB::beginTransaction();
        $entityId = (int) $request->entity_id;
        if ($entityId !== 0) {
            $branchExists = DB::table('egc_branch')->where('sno', $request->branch_id)->where('entity_id', $entityId)->where('status', 0)->exists();
            if (!$branchExists) {
                DB::rollBack();
                return response()->json([
                    'status' => 422,
                    'message' => 'Invalid branch selected.'
                ], 422);
            }
        }
        $floorIds = array_map('intval', $request->floor_id);
        $validFloors = DB::table('egc_building_floors')->where('building_id', $request->building_id)->whereIn('sno', $floorIds)->pluck('sno')
            ->map(fn ($id) => (int) $id)->all();
        if (count($validFloors) !== count(array_unique($floorIds))) {
            DB::rollBack();
            return response()->json([
                'status' => 422,
                'message' => 'Invalid floor selection.'
            ], 422);
        }
        $uploadedDocuments = [];
        if ($request->hasFile('documents')) {
            $destinationPath = public_path('lease_documents');
            if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0755, true);
            }
            foreach ($request->file('documents') as $index => $file) {
                $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move($destinationPath, $fileName);
               $uploadedDocuments[] = [
                'name' => $file->getClientOriginalName(),
                'path' => 'lease_documents/' . $fileName,
                'type' => $request->document_types[$index] ?? 'Other',
                'version' => 1,
                'uploaded_by' => $userId,
                'uploaded_on' => now()->format('Y-m-d H:i:s'),
                'expiry' => !empty($request->end_date) ? Carbon::parse($request->end_date)->format('Y-m-d') : null,
            ];
            }
        }
        $lease = new ManageLeaseModel();
        $lease->lessor_id = $request->lessor_id;
        $lease->building_id = $request->building_id;
        $lease->entity_id = $entityId;
        $lease->branch_id = $entityId === 0 ? null : $request->branch_id;
        $lease->start_date = date('Y-m-d', strtotime($request->start_date));
        $lease->end_date = date('Y-m-d', strtotime($request->end_date));
        $lease->lock_in_months = $request->lock_in_months;
        $lease->notice_period = $request->notice_period;
        $lease->term_length = $request->term_length;
        $lease->floor_id = $floorIds[0];
        $lease->monthly_rent = $request->monthly_rent;
        $lease->frequency = $request->frequency;
        $lease->bargain_adjustment = $request->bargain_adjustment;
        $lease->due_day = $request->due_day;
        $lease->ann_escalation = $request->ann_escalation;
        $lease->deposit_month_rent = $request->deposit_month_rent;
        $lease->amount = $request->amount;
        $lease->paid_on = date('Y-m-d', strtotime($request->paid_on));
        $lease->document_upload = json_encode($uploadedDocuments);
        $lease->payment_reference = $request->payment_reference;
        $lease->created_by = $userId;
        $lease->updated_by = $userId;
        $lease->created_at = now();
        $lease->status = 0;
        $lease->save();
        $this->addLeaseEvent($lease->sno,'Lease created from new lease wizard','plus',$userId);
        $this->addLeaseEvent($lease->sno,'Deposit of ₹' . number_format($lease->amount, 2) . ' recorded','wallet',$userId);
        foreach ($floorIds as $floorId) {
            DB::table('egc_crpt_manage_lease_floors')->insert([
                'lease_id' => $lease->sno,
                'floor_id' => $floorId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        DB::commit();
        return response()->json([
            'status' => 200,
            'message' => 'Lease registered successfully!'
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        return response()->json([
            'status' => 500,
            'message' => 'Unable to register lease.',
            'error' => config('app.debug') ? $e->getMessage() : null
        ], 500);
    }
}
public function update(Request $request, $id)
{
    $userId = $request->user()->userId ?? 1;
    $validator = Validator::make($request->all(), [
        'lessor_id' => ['required', 'integer'],
        'building_id' => ['required', 'integer', 'exists:egc_buildings,sno'],
        'entity_id' => ['required', 'integer', 'min:0'],
        'branch_id' => ['nullable', 'integer', 'required_unless:entity_id,0'],
        'floor_id' => ['required', 'array', 'min:1'],
        'floor_id.*' => ['required', 'integer'],
        'start_date' => ['required', 'date'],
        'end_date' => ['required', 'date', 'after:start_date'],
        'lock_in_months' => ['required', 'numeric', 'min:0'],
        'notice_period' => ['required', 'numeric', 'min:0'],
        'term_length' => ['required', 'numeric', 'min:1'],
        'monthly_rent' => ['required', 'numeric', 'min:0'],
        'frequency' => ['required', 'in:1,2,3'],
        'due_day' => ['required', 'integer', 'between:1,31'],
        'ann_escalation' => ['required', 'numeric', 'min:0'],
        'deposit_month_rent' => ['required', 'numeric', 'min:0'],
        'amount' => ['required', 'numeric', 'min:0'],
        'bargain_adjustment' => ['required', 'numeric', 'min:0'],
        'paid_on' => ['required', 'date'],
        'payment_reference' => ['required', 'string', 'max:255'],
        'documents.*' => ['nullable', 'file', 'mimes:pdf,docx,jpg,jpeg,png', 'max:20480'],
        'document_types' => ['nullable', 'array'],
        'existing_documents' => ['nullable', 'array'],
        'existing_document_expiry' => ['nullable', 'array'],
        'existing_document_expiry.*' => ['nullable', 'date'],
    ]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'errors' => $validator->errors()
        ], 422);
    }
    try {
        DB::beginTransaction();
        $lease = ManageLeaseModel::where('sno', $id)->where('status', '!=', 2)->lockForUpdate()->first();
        if (!$lease) {
            DB::rollBack();
            return response()->json([
                'status' => 404,
                'message' => 'Lease not found!'
            ], 404);
        }
        $oldRent = (float) $lease->monthly_rent;
        $entityId = (int) $request->entity_id;
        if ($entityId !== 0) {
            $branchExists = DB::table('egc_branch')->where('sno', $request->branch_id)->where('entity_id', $entityId)->where('status', 0)->exists();
            if (!$branchExists) {
                DB::rollBack();
                return response()->json([
                    'status' => 422,
                    'message' => 'Invalid branch selected.'
                ], 422);
            }
        }
        $floorIds = array_unique(array_map('intval', $request->floor_id));
        $validFloors = DB::table('egc_building_floors')->where('building_id', $request->building_id)->whereIn('sno', $floorIds)->pluck('sno')->map(fn($id) => (int) $id)->all();
        if (count($validFloors) !== count($floorIds)) {
            DB::rollBack();
            return response()->json([
                'status' => 422,
                'message' => 'Invalid floor selection.'
            ], 422);
        }
        $uploadedDocuments = [];
        $oldDocuments = json_decode($lease->document_upload ?? '[]',true) ?? [];
        $existingDocuments = $request->input('existing_documents', []);
        foreach ($oldDocuments as $index => $document) {
            if (in_array($document['path'], $existingDocuments, true)) {
                $document['expiry'] = $request->input('existing_document_expiry.' . $document['path'],$document['expiry'] ?? null);
                $uploadedDocuments[] = $document;
            }
        }
        if ($request->hasFile('documents')) {
        $destinationPath = public_path('lease_documents');
        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0755, true);
        }
        foreach ($request->file('documents') as $index => $file) {
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move($destinationPath, $fileName);
            $expiryDate = $request->end_date;
            $uploadedDocuments[] = [
                'name' => $file->getClientOriginalName(),
                'path' => 'lease_documents/' . $fileName,
                'type' => $request->input("document_types.$index", 'Other'),
                'version' => 1,
                'uploaded_by' => $userId,
                'uploaded_on' => now()->format('Y-m-d H:i:s'),
                'expiry' => !empty($expiryDate) ? Carbon::parse($expiryDate)->format('Y-m-d'): null,
            ];
        }
    }
        $lease->document_upload = json_encode($uploadedDocuments);
        $lease->lessor_id = $request->lessor_id;
        $lease->building_id = $request->building_id;
        $lease->entity_id = $entityId;
        $lease->branch_id = $entityId === 0 ? null : $request->branch_id;
        $lease->start_date = date('Y-m-d', strtotime($request->start_date));
        $lease->end_date = date('Y-m-d', strtotime($request->end_date));
        $lease->lock_in_months = $request->lock_in_months;
        $lease->notice_period = $request->notice_period;
        $lease->term_length = $request->term_length;
        $lease->floor_id = $floorIds[0];
        $lease->monthly_rent = $request->monthly_rent;
        $lease->frequency = $request->frequency;
        $lease->bargain_adjustment = $request->bargain_adjustment;
        $lease->due_day = $request->due_day;
        $lease->ann_escalation = $request->ann_escalation;
        $lease->deposit_month_rent = $request->deposit_month_rent;
        $lease->amount = $request->amount;
        $lease->paid_on = date('Y-m-d', strtotime($request->paid_on));
        $lease->payment_reference = $request->payment_reference;
        $lease->updated_by = $userId;
        $lease->updated_at = now();
        $lease->save();
        if ($oldRent != (float) $lease->monthly_rent) {
            $this->addLeaseEvent($lease->sno,'Monthly rent changed from ₹' . number_format($oldRent, 2) . ' to ₹' . number_format($lease->monthly_rent, 2),'settings',$userId);
        }
        $newDocuments = count($uploadedDocuments) - count($oldDocuments);
        if ($newDocuments > 0) {
            $this->addLeaseEvent($lease->sno,'Uploaded ' . $newDocuments . ' new lease document(s)','file',$userId);
        }
        DB::table('egc_crpt_manage_lease_floors')->where('lease_id', $lease->sno)->delete();
        foreach ($floorIds as $floorId) {
            DB::table('egc_crpt_manage_lease_floors')->insert([
                'lease_id' => $lease->sno,
                'floor_id' => $floorId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        DB::commit();
        return response()->json([
            'status' => 200,
            'message' => 'Lease updated successfully!'
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        return response()->json([
            'status' => 500,
            'message' => 'Unable to update lease.',
            'error' => config('app.debug') ? $e->getMessage() : null
        ], 500);
    }
}
public function changeStatus(Request $request, $id)
{
    $validator = Validator::make($request->all(), [
        'status' => ['required', 'integer', 'in:0,1'],
    ]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Invalid status selected.',
            'errors' => $validator->errors()
        ], 422);
    }
    try {
        DB::beginTransaction();
        $lease = ManageLeaseModel::where('sno', $id)->where('status', '!=', 2)->lockForUpdate()->first();
        if ((int) $lease->status === 5) {
            DB::rollBack();
            return response()->json([
                'status' => 422,
                'message' => 'Closed leases cannot be reactivated or modified.'
            ], 422);
        }
        if (!$lease) {
            DB::rollBack();
            return response()->json([
                'status' => 404,
                'message' => 'Lease not found!'
            ], 404);
        }
        $selectedStatus = (int) $request->status;
        $finalStatus = $this->getLeaseStatus($lease,$selectedStatus);
        $lease->status = $finalStatus;
        $lease->updated_by = $request->user()->userId ?? 1;
        $lease->updated_at = now();
        $lease->save();
        $statusName = [
            0 => 'Active',
            1 => 'Inactive',
            3 => 'Renew Due',
            4 => 'Expired',
        ];
        $this->addLeaseEvent($lease->sno,'Lease status changed to ' . ($statusName[$finalStatus] ?? 'Unknown'),'flag',$request->user()->userId ?? 1);
        DB::commit();
        $statusNames = [
            0 => 'Active',
            1 => 'Inactive',
            3 => 'Renew Due',
            4 => 'Expired',
        ];
        return response()->json([
            'status' => 200,
            'message' => 'Lease status updated successfully.',
            'data' => [
                'status' => $finalStatus,
                'status_name' => $statusNames[$finalStatus],
            ]
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        return response()->json([
            'status' => 500,
            'message' => 'Unable to update lease status.',
            'error' => config('app.debug') ? $e->getMessage() : null
        ], 500);
    }
    if ((int) $lease->status !== $finalStatus && $finalStatus === 0) {
    $this->addLeaseEvent($lease->sno,'Lease activated','check',$request->user()->userId ?? 1);
}
}
public function show($id)
{
    $leaseTable = (new ManageLeaseModel())->getTable();
    $floorQuery = DB::table('egc_crpt_manage_lease_floors as mapping')->join('egc_building_floors as floor', 'floor.sno', '=', 'mapping.floor_id')
        ->where('mapping.lease_id', $id)->select('floor.sno','floor.floor_name')->get();
    $lease = DB::table($leaseTable . ' as lease')
        ->join('egc_crpt_manage_lessor as lessor', 'lessor.sno', '=', 'lease.lessor_id')
        ->join('egc_buildings as building', 'building.sno', '=', 'lease.building_id')
        ->leftJoin('egc_entity as entity', 'entity.sno', '=', 'lease.entity_id')
        ->leftJoin('egc_branch as branch', 'branch.sno', '=', 'lease.branch_id')
        ->where('lease.sno', $id)
        ->where('lease.status', '!=', 2)
       ->select(
        'lease.*',
        'lessor.sno as lessor_id',
        'lessor.lessor_name',
        'lessor.mobile_number',
        'lessor.pan_number',
        'lessor.gstin',
        'lessor.ifsc_code',
        'building.building_name',
        'entity.entity_name',
        'branch.branch_name')->first();
    if (!$lease) {
        abort(404);
    }
    $helper = new \App\Helpers\Helpers();
    $generalSetting = $helper->general_setting_data();
    if ((int) $lease->entity_id === 0) {
        $lease->entity_name = $generalSetting->title ?? '';
    }
    $lease->floors = $floorQuery;
    $lease->floor_names = $floorQuery->pluck('floor_name')->implode(', ');
    $lease->next_due_date = $this->getNextLeaseDueDate($lease);
    $lease->status = $this->getLeaseStatus($lease);
    $documents = json_decode($lease->document_upload ?? '[]', true) ?? [];
    $staffIds = collect($documents)->pluck('uploaded_by')->filter()->unique()->values()->toArray();
    $staffNames = DB::table('egc_staff')->whereIn('sno', $staffIds)->pluck('staff_name', 'sno')->toArray();
    foreach ($documents as &$document) {
        $document['uploaded_by_name'] = $staffNames[$document['uploaded_by'] ?? 0] ?? 'System';
        $document['version'] = 'V' . ($document['version'] ?? 1);
        $document['uploaded_on'] = !empty($document['uploaded_on']) ? Carbon::parse($document['uploaded_on'])->format('d M Y') : '-';
        $document['expiry'] = !empty($document['expiry']) ? Carbon::parse($document['expiry'])->format('d M Y'): '-';
    }
    unset($document);
    if (!$lease) {
        abort(404, 'Lease not found');
    }
    $monthlyRent = (float) $lease->monthly_rent;
    $escalation = (float) $lease->ann_escalation;
    $termLength = (int) $lease->term_length;
    $startDate = \Carbon\Carbon::parse($lease->start_date);
    $today = \Carbon\Carbon::today();
    $escalationHistory = [];
    $currentRent = $monthlyRent;
    $totalContractValue = 0;
    for ($year = 1; $year <= $termLength; $year++) {
        $yearlyRent = $currentRent * 12;
        $yearStart = $startDate->copy()->addYears($year - 1);
        $yearEnd = $yearStart->copy()->addYear();
        $isCurrent = $today->gte($yearStart) && $today->lt($yearEnd);
        $isFuture = $today->lt($yearStart);
        $escalationHistory[] = [
            'year' => $year,
            'monthly_rent' => $currentRent,
            'annual_rent' => $yearlyRent,
            'date' => $yearStart->format('M Y'),
            'is_current' => $isCurrent,
            'is_future' => $isFuture,
        ];
        $totalContractValue += $yearlyRent;
        $currentRent *= (1 + ($escalation / 100));
    }
    $payments = DB::table('egc_crpt_lease_payments')->where('lease_id', $id)->orderBy('due_date', 'asc')->get();
    $paidAmount = $payments->where('payment_status', 1)->sum('amount');
    $dueAmount = $payments->where('payment_status', 2)->sum('amount');
    $scheduledAmount = $payments->where('payment_status', 0)->sum('amount');
    $paidCount = $payments->where('payment_status', 1)->count();
    $dueCount = $payments->where('payment_status', 2)->count();
    $scheduledCount = $payments->where('payment_status', 0)->count();
    $today = Carbon::today();
    $yearStart = Carbon::now()->startOfYear();
    $yearToDatePaid = $payments->where('payment_status', 1)->filter(function ($payment) use ($yearStart, $today) {
            return !empty($payment->paid_on) && Carbon::parse($payment->paid_on)->betweenIncluded($yearStart, $today);
        })->sum('amount');
    $annualCommitment = (float) $lease->monthly_rent * 12;
    $totalInstallments = $payments->count();
    $paidInstallmentCount = $paidCount;
    $paymentProgress = $totalInstallments > 0 ? round(($paidInstallmentCount / $totalInstallments) * 100, 2) : 0;
    $totalPaymentAmount = $payments->sum('amount');
    $nextInstallments = $payments->where('payment_status', 0)->sortBy('due_date')->take(6);
    $monthlyRent = (float) $lease->monthly_rent;
    // Deposit calculations
    $depositAmount = (float) $lease->amount;
    $depositEquivalentMonths = $monthlyRent > 0 ? round($depositAmount / $monthlyRent, 2): 0;
    // Fetch latest deposit adjustment
    $latestDepositAdjustment = DB::table('egc_crpt_lease_deposit_adjustments')->where('lease_id', $id)->orderByDesc('sno')->first();
    $depositAdjustments = $latestDepositAdjustment ? (float) $latestDepositAdjustment->adjustment_amount : 0;
    $depositAdjustmentDate = $latestDepositAdjustment ? Carbon::parse($latestDepositAdjustment->adjustment_date)->format('d-M-Y') : '-';
    $finalDepositAmount = $latestDepositAdjustment ? (float) $latestDepositAdjustment->final_amount : $depositAmount;
    $repairExpenses = $latestDepositAdjustment ? (float) $latestDepositAdjustment->repair_expenses : 0;
    $refundDue = $latestDepositAdjustment ? (float) $latestDepositAdjustment->refund_amount : $depositAmount;
    $depositPaidOn = $lease->paid_on;
    $depositPaymentReference = $lease->payment_reference;
    $events = DB::table('egc_crpt_lease_events as events')
    ->leftJoin('egc_staff as staff', 'staff.sno', '=', 'events.created_by')->where('events.lease_id', $id)
    ->orderByDesc('events.created_at')->select('events.event_title','events.event_type','events.created_at','staff.staff_name')->get()
    ->map(function ($event) {
        $event->event_date = Carbon::parse($event->created_at)->format('d M Y');
        $event->event_user = $event->staff_name ?? 'System';
        return $event;
    });
    return view('content.corporate_admin.manage_maintanence.manage_lease.view_lease',
    compact(
        'lease',
        'documents',
        'escalationHistory',
        'totalContractValue',
        'payments',
        'paidAmount',
        'dueAmount',
        'scheduledAmount',
        'paidCount',
        'dueCount',
        'latestDepositAdjustment',
        'depositAdjustmentDate',
        'finalDepositAmount',
        'repairExpenses',
        'scheduledCount',
        'yearToDatePaid',
        'annualCommitment',
        'paymentProgress',
        'totalInstallments',
        'paidInstallmentCount',
        'totalPaymentAmount',
        'nextInstallments',
        'depositAmount',
        'depositEquivalentMonths',
        'depositAdjustments',
        'events',
        'refundDue',
        'depositPaidOn',
        'depositPaymentReference'
    ));
}
public function payments($id)
{
    $lease = ManageLeaseModel::where('sno', $id)->where('status', '!=', 2)->firstOrFail();
    try {
        DB::beginTransaction();
        $intervals = [
            1 => 1, 2 => 3, 3 => 12,
        ];
        $months = $intervals[(int) $lease->frequency] ?? 1;
        $startDate = Carbon::parse($lease->start_date)->startOfMonth();
        $endDate = Carbon::parse($lease->end_date)->startOfDay();
        $dueDay = (int) $lease->due_day;
        $monthlyRent = (float) $lease->monthly_rent;
        $escalation = (float) $lease->ann_escalation;
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $periodStart = $currentDate->copy();
            $dueDate = $periodStart->copy()->day(min($dueDay, $periodStart->daysInMonth));
            if ($dueDate->gt($endDate)) {
                break;
            }
            $monthsDifference = $startDate->diffInMonths($periodStart);
            $yearNumber = (int) floor($monthsDifference / 12);
            $escalatedRent = $monthlyRent * pow(1 + ($escalation / 100),$yearNumber);
            $amount = $escalatedRent * $months;
            $dueDateString = $dueDate->format('Y-m-d');
            $existingPayment = DB::table('egc_crpt_lease_payments')->where('lease_id', $lease->sno)->where('due_date', $dueDateString)->first();
            if ($existingPayment) {
                DB::table('egc_crpt_lease_payments')->where('sno', $existingPayment->sno)
                    ->update([
                        'period_start' => $periodStart->format('Y-m-d'), 'amount' => $amount, 'updated_at' => now(),
                    ]);
            } else {
                DB::table('egc_crpt_lease_payments')->insert([
                    'lease_id' => $lease->sno,
                    'due_date' => $dueDateString,
                    'period_start' => $periodStart->format('Y-m-d'),
                    'amount' => $amount,
                    'payment_status' => 0,
                    'paid_on' => null,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            if ($yearNumber > 0 && $periodStart->month === $startDate->month && $periodStart->year > $startDate->year) {
                $previousRent = $monthlyRent * pow(1 + ($escalation / 100),$yearNumber - 1);
                $eventTitle = $escalation . '% escalation applied — ₹' . number_format($previousRent, 2) . ' → ₹' . number_format($escalatedRent, 2);
                $eventExists = DB::table('egc_crpt_lease_events')->where('lease_id', $lease->sno)->where('event_title', $eventTitle)->exists();
                if (!$eventExists) {
                    $this->addLeaseEvent($lease->sno,$eventTitle,'refresh',null);
                }
            }
            $currentDate->addMonthsNoOverflow($months);
        }
        DB::table('egc_crpt_lease_payments')->where('lease_id', $lease->sno)->where('payment_status', 0)->whereDate('due_date', '<', Carbon::today())
            ->update([
                'payment_status' => 2,'updated_at' => now(),
            ]);
        DB::commit();
        $payments = DB::table('egc_crpt_lease_payments')->where('lease_id', $lease->sno)->orderBy('due_date')->get();
        return response()->json([
            'status' => 200,
            'data' => $payments,
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        \Log::error('Lease payment schedule failed', [
            'lease_id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);
        return response()->json([
            'status' => 500,
            'message' => 'Unable to fetch payment schedule.',
            'error' => config('app.debug') ? $e->getMessage() : null,
        ], 500);
    }
}
public function updatePaymentStatus(Request $request, $paymentId)
{
    $validator = Validator::make($request->all(), [
        'payment_status' => ['required', 'integer', 'in:1,2'],
        'paid_on' => ['nullable', 'date', 'required_if:payment_status,1'],
    ]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation failed.',
            'errors' => $validator->errors(),
        ], 422);
    }
    try {
        DB::beginTransaction();
        $payment = DB::table('egc_crpt_lease_payments')->where('sno', $paymentId)->lockForUpdate()->first();
        if (!$payment) {
            DB::rollBack();
            return response()->json([
                'status' => 404,
                'message' => 'Payment record not found.',
            ], 404);
        }
        $newStatus = (int) $request->payment_status;
        DB::table('egc_crpt_lease_payments')->where('sno', $paymentId)
            ->update([
                'payment_status' => $newStatus,'paid_on' => $newStatus === 1 ? $request->paid_on : null,'updated_at' => now(),
            ]);
        $eventTitle = $newStatus === 1 ? 'Rent payment of ₹' . number_format($payment->amount, 2) . ' marked as paid' : 'Rent payment of ₹' . number_format($payment->amount, 2) . ' marked as due';
        if ($newStatus !== (int) $payment->payment_status) {
            $this->addLeaseEvent($payment->lease_id,$eventTitle,'check',$request->user()->userId ?? 1);
        }
        DB::commit();
        return response()->json([
            'status' => 200,
            'message' => 'Payment status updated successfully.',
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        \Log::error('Payment status update failed', [
            'payment_id' => $paymentId,
            'error' => $e->getMessage(),
        ]);
        return response()->json([
            'status' => 500,
            'message' => 'Unable to update payment status.',
            'error' => config('app.debug') ? $e->getMessage() : null,
        ], 500);
    }
}
//app.debug logic
// // Method 1: Using the config helper
// if (config('app.debug')) {
//     // Run debug-only logic
// }

// // Method 2: Using the App facade
// if (\Illuminate\Support\Facades\App::hasDebugModeEnabled()) {
//     // Run debug-only logic
// }
private function addLeaseEvent($leaseId, $title, $type = 'plus', $userId = null)
{
    DB::table('egc_crpt_lease_events')->insert([
        'lease_id' => $leaseId,
        'event_title' => $title,
        'event_type' => $type,
        'created_by' => $userId ?? 1,
        'created_at' => now(),
        'updated_at' => now(),
    ]);
}
public function terminateChecklist($leaseId)
{
    $lease = ManageLeaseModel::where('sno', $leaseId)->where('status', '!=', 2)->first();
    if (!$lease) {
        return response()->json([
            'status' => 404,
            'message' => 'Lease not found!'
        ], 404);
    }
    $tasks = TerminateClosureModel::where('status', 0)->select('sno', 'tasks', 'description')->orderBy('tasks')->get();
    $checklist = DB::table('egc_crpt_lease_terminate_checklist as checklist')
        ->join('egc_crpt_terminate_closure as tasks','tasks.sno','=','checklist.tasks_id')
        ->where('checklist.lease_id', $leaseId)->where('checklist.status', '!=', 2)
        ->select(
            'checklist.sno',
            'checklist.lease_id',
            'checklist.task_type',
            'checklist.tasks_id',
            'checklist.assign_date',
            'checklist.is_completed',
            'checklist.completed_at',
            'tasks.tasks',
            'tasks.description'
        )->orderBy('checklist.sno')->get();
    $allCompleted = $checklist->isNotEmpty() && $checklist->every(fn($item) => (int) $item->is_completed === 1);
      $taskTypeNames = [1 => 'Operations',2 => 'Finance',3 => 'Facilities',4 => 'Admin',];
      $checklist->transform(function ($item) use ($taskTypeNames) {
          $item->task_type_name = $taskTypeNames[$item->task_type] ?? '-';
          return $item;
      });
    return response()->json([
        'status' => 200,
        'tasks' => $tasks,
        'checklist' => $checklist,
        'all_completed' => $allCompleted,
        'lease_status' => (int) $lease->status,
        'is_closed' => (int) $lease->status === 5
    ]);
}
public function updateTerminateChecklist(Request $request, $id)
{
    $validator = Validator::make($request->all(), ['is_completed' => ['required', 'integer', 'in:0,1']]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation failed.',
            'errors' => $validator->errors()
        ], 422);
    }
    try {
        DB::beginTransaction();
        $checklist = LeaseTerminateCheckListModel::where('sno', $id)->where('status', '!=', 2)->lockForUpdate()->first();
        if (!$checklist) {
            DB::rollBack();
            return response()->json([
                'status' => 404,
                'message' => 'Checklist task not found.'
            ], 404);
        }
        $lease = ManageLeaseModel::where('sno', $checklist->lease_id)->lockForUpdate()->first();
        if (!$lease || (int) $lease->status === 5) {
            DB::rollBack();
            return response()->json([
                'status' => 422,
                'message' => 'This lease is already closed or unavailable.'
            ], 422);
        }
        $completed = (int) $request->is_completed;
        $userId = $request->user()->userId ?? 1;
        $checklist->is_completed = $completed;
        $checklist->completed_at = $completed ? now() : null;
        $checklist->completed_by = $completed ? $userId : null;
        $checklist->updated_by = $userId;
        $checklist->save();
        DB::commit();
        return response()->json([
            'status' => 200,
            'message' => 'Checklist updated successfully.',
            'data' => [
                'is_completed' => $completed,
                'completed_at' => $checklist->completed_at
            ]
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        return response()->json([
            'status' => 500,
            'message' => 'Unable to update checklist.',
            'error' => config('app.debug') ? $e->getMessage() : null
        ], 500);
    }
}
public function closeLease($leaseId)
{
    try {
        DB::beginTransaction();
        $lease = ManageLeaseModel::where('sno', $leaseId)->where('status', '!=', 2)->lockForUpdate()->first();
        if (!$lease) {
            DB::rollBack();
            return response()->json([
                'status' => 404,
                'message' => 'Lease not found!'
            ], 404);
        }
        if ((int) $lease->status === 5) {
            DB::rollBack();
            return response()->json([
                'status' => 422,
                'message' => 'Lease is already closed.'
            ], 422);
        }
        $checklist = DB::table('egc_crpt_lease_terminate_checklist')->where('lease_id', $leaseId)->where('status', '!=', 2)->get();
        if ($checklist->isEmpty() ||
            !$checklist->every(function ($task) {
                return (int) $task->is_completed === 1;
            })) {
            DB::rollBack();
            return response()->json([
                'status' => 422,
                'message' => 'Complete all closure tasks before closing the lease.'
            ], 422);
        }
        $lease->status = 5;
        $lease->updated_by = request()->user()->userId ?? 1;
        $lease->updated_at = now();
        $lease->save();
        $this->addLeaseEvent($lease->sno,'Lease successfully closed','check',request()->user()->userId ?? 1);
        DB::commit();
        return response()->json([
            'status' => 200,
            'message' => 'Lease closed successfully!'
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        return response()->json([
            'status' => 500,
            'message' => 'Unable to close lease.',
            'error' => config('app.debug') ? $e->getMessage() : null
        ], 500);
    }
}
public function saveTerminateChecklist(Request $request, $leaseId)
{
    $validator = Validator::make($request->all(), [
        'tasks_id' => ['required','integer','exists:egc_crpt_terminate_closure,sno'],
        'task_type' => ['required', 'integer', 'in:1,2,3,4'],
        'assign_date' => ['required','date_format:d-M-Y'],]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation failed.',
            'errors' => $validator->errors()
        ], 422);
    }
    $lease = ManageLeaseModel::where('sno', $leaseId)->where('status', '!=', 2)->first();
    if (!$lease) {
        return response()->json([
            'status' => 404,
            'message' => 'Lease not found!'
        ], 404);
    }
    $task = TerminateClosureModel::where('sno', $request->tasks_id)->where('status', 0)->first();
    if (!$task) {
        return response()->json([
            'status' => 422,
            'message' => 'Selected task is not active.'
        ], 422);
    }
    $user = $request->user();
    $userId = $user ? ($user->user_id ?? $user->userId ?? 1) : 1;
    $assignDate = Carbon::createFromFormat('d-M-Y',$request->assign_date)->format('Y-m-d');
    $checklist = new LeaseTerminateCheckListModel();
    $checklist->lease_id = $leaseId;
    $checklist->task_type = $request->task_type;
    $checklist->tasks_id = $request->tasks_id;
    $checklist->assign_date = $assignDate;
    $checklist->created_by = $userId;
    $checklist->updated_by = $userId;
    $checklist->status = 0;
    $checklist->save();
    return response()->json([
        'status' => 200,
        'message' => 'Terminate checklist task added successfully!',
        'data' => $checklist
    ]);
}
public function deleteTerminateChecklist($id)
{
    $checklist = LeaseTerminateCheckListModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$checklist) {
        return response()->json([
            'status' => 404,
            'message' => 'Terminate checklist task not found!'
        ], 404);
    }
    $checklist->status = 2;
    $user = request()->user();
    $checklist->updated_by = $user ? ($user->user_id ?? $user->userId ?? 1) : 1;
    $checklist->save();
    return response()->json([
        'status' => 200,
        'message' => 'Terminate checklist task deleted successfully!'
    ]);
}
public function getDepositAdjustment($id)
{
    $helper = new \App\Helpers\Helpers();
    $generalSetting = $helper->general_setting_data();
    $lease = DB::table('egc_crpt_manage_lease as lease')
        ->join('egc_crpt_manage_lessor as lessor','lessor.sno', '=', 'lease.lessor_id')
        ->join('egc_buildings as building','building.sno', '=', 'lease.building_id')
        ->leftJoin('egc_entity as entity','entity.sno', '=', 'lease.entity_id')
        ->leftJoin('egc_branch as branch','branch.sno', '=', 'lease.branch_id')
        ->leftJoinSub(DB::table('egc_crpt_manage_lease_floors as mapping')
                ->join('egc_building_floors as floor','floor.sno', '=', 'mapping.floor_id')
                ->select('mapping.lease_id',DB::raw("GROUP_CONCAT(DISTINCT floor.floor_name ORDER BY floor.sno SEPARATOR ', ') as floor_names")
                )->groupBy('mapping.lease_id'),
            'floors',
            function ($join) {
                $join->on('floors.lease_id', '=', 'lease.sno');
            }
        )
        ->where('lease.sno', $id)->where('lease.status', '!=', 2)
        ->select(
            'lease.sno',
            'lease.entity_id',
            'lease.branch_id',
            'lease.amount as deposit_amount',
            'lease.bargain_adjustment',
            'lease.start_date',
            'lease.end_date',
            'building.building_name',
            'floors.floor_names',
            'lessor.lessor_name',
            'lessor.mobile_number',
            'entity.entity_name',
            'branch.branch_name'
        )->first();
    if (!$lease) {
        return response()->json([
            'status' => 404,
            'message' => 'Lease not found.'
        ], 404);
    }
    if ((int) $lease->entity_id === 0) {
        $lease->entity_name = $generalSetting->title ?? '';
    }
    $lease->entity_name = $lease->entity_name ?: '-';
    $lease->branch_name = $lease->branch_name ?: '';
    $adjustment = DB::table('egc_crpt_lease_deposit_adjustments')->where('lease_id', $id)->orderByDesc('sno')->first();
    $lease->adjustment_type = $adjustment->adjustment_type ?? 'add';
    $lease->adjustment_amount = $adjustment->adjustment_amount ?? $lease->bargain_adjustment ?? 0;
    $lease->adjustment_date = isset($adjustment->adjustment_date) ? Carbon::parse($adjustment->adjustment_date)->format('d-M-Y') : '';
    $lease->repair_expenses = $adjustment->repair_expenses ?? 0;
    return response()->json([
        'status' => 200,
        'data' => $lease
    ]);
}
public function saveDepositAdjustment(Request $request, $id)
{
    $validator = Validator::make($request->all(), [
        'adjustment_type' => 'required|in:add,subtract',
        'adjustment_amount' => 'required|numeric|min:0',
        'adjustment_date' => 'required|date_format:d-M-Y',
        'repair_expenses' => 'required|numeric|min:0',
    ]);
    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation failed.',
            'errors' => $validator->errors()
        ], 422);
    }
    $lease = ManageLeaseModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$lease) {
        return response()->json([
            'status' => 404,
            'message' => 'Lease not found.'
        ], 404);
    }
    $depositAmount = (float) $lease->amount;
    $adjustmentAmount = (float) $request->adjustment_amount;
    $repairExpenses = (float) $request->repair_expenses;
    $finalAmount = $request->adjustment_type === 'add' ? $depositAmount + $adjustmentAmount : $depositAmount - $adjustmentAmount;
    if ($finalAmount < 0) {
        return response()->json([
            'status' => 422,
            'message' => 'Adjustment amount cannot exceed the deposit amount.'
        ], 422);
    }
    if ($repairExpenses > $finalAmount) {
        return response()->json([
            'status' => 422,
            'message' => 'Repair expenses cannot exceed the final amount.'
        ], 422);
    }
    $refundAmount = $finalAmount - $repairExpenses;
    $user = $request->user();
    $userId = $user ? ($user->userId ?? $user->user_id ?? 1) : 1;
    try {
        $adjustment = DB::transaction(function () use ($id,$request,$adjustmentAmount,$repairExpenses,$finalAmount,$refundAmount,$userId) {
            return LeaseDepositAdjustment::create([
                'lease_id' => $id,
                'adjustment_type' => $request->adjustment_type,
                'adjustment_amount' => $adjustmentAmount,
                'adjustment_date' => Carbon::createFromFormat('d-M-Y',$request->adjustment_date)->format('Y-m-d'),
                'final_amount' => $finalAmount,
                'repair_expenses' => $repairExpenses,
                'refund_amount' => $refundAmount,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);
        });
        return response()->json([
            'status' => 200,
            'message' => 'Deposit adjustment saved successfully.',
            'data' => [
                'adjustment_id' => $adjustment->sno,
                'lease_id' => $adjustment->lease_id,
                'deposit_amount' => $depositAmount,
                'adjustment_type' => $adjustment->adjustment_type,
                'adjustment_amount' => $adjustment->adjustment_amount,
                'adjustment_date' => $adjustment->adjustment_date->format('d-M-Y'),
                'final_amount' => $adjustment->final_amount,
                'repair_expenses' => $adjustment->repair_expenses,
                'refund_amount' => $adjustment->refund_amount,
            ]
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();
        \Log::error('Deposit adjustment save error', [
            'lease_id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);
        return response()->json([
            'status' => 500,
            'message' => 'Unable to save deposit adjustment.',
            'error' => config('app.debug') ? $e->getMessage() : null
        ], 500);
    }
}
public function getDepositAdjustmentDetails($id)
{
    $helper = new \App\Helpers\Helpers();
    $generalSetting = $helper->general_setting_data();
    $lease = DB::table('egc_crpt_manage_lease as lease')
        ->join('egc_crpt_manage_lessor as lessor','lessor.sno', '=', 'lease.lessor_id')
        ->join('egc_buildings as building','building.sno', '=', 'lease.building_id')
        ->leftJoin('egc_entity as entity','entity.sno', '=', 'lease.entity_id')
        ->leftJoin('egc_branch as branch','branch.sno', '=', 'lease.branch_id')
        ->leftJoinSub(
            DB::table('egc_crpt_manage_lease_floors as mapping')->join('egc_building_floors as floor','floor.sno', '=', 'mapping.floor_id')
                ->select('mapping.lease_id', DB::raw("GROUP_CONCAT(DISTINCT floor.floor_name ORDER BY floor.sno SEPARATOR ', ') as floor_names")
                )->groupBy('mapping.lease_id'),'floors',
            function ($join) {
                $join->on('floors.lease_id', '=', 'lease.sno');
            }
        )->where('lease.sno', $id)->where('lease.status', '!=', 2)
        ->select(
            'lease.sno',
            'lease.entity_id',
            'lease.branch_id',
            'lease.amount as deposit_amount',
            'lease.start_date',
            'lease.end_date',
            'building.building_name',
            'floors.floor_names',
            'lessor.lessor_name',
            'lessor.mobile_number',
            'entity.entity_name',
            'branch.branch_name'
        )->first();
    if (!$lease) {
        return response()->json([
            'status' => 404,
            'message' => 'Lease not found.'
        ], 404);
    }
    if ((int) $lease->entity_id === 0) {
        $lease->entity_name = $generalSetting->title ?? '';
    }
    $lease->entity_name = $lease->entity_name ?: '-';
    $lease->branch_name = $lease->branch_name ?: '';
    $latest = DB::table('egc_crpt_lease_deposit_adjustments')->where('lease_id', $id)->orderByDesc('sno')->first();
    if ($latest) {
        $latest->adjustment_date = $latest->adjustment_date ? Carbon::parse($latest->adjustment_date)->format('d-M-Y') : '';
        $latest->created_at_time = $latest->created_at ? Carbon::parse($latest->created_at)->format('h:i A') : '-';
    }
    return response()->json([
        'status' => 200,
        'lease' => $lease,
        'latest' => $latest
    ]);
}
public function getDepositAdjustmentHistory($id)
{
    $lease = ManageLeaseModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$lease) {
        return response()->json([
            'status' => 404,
            'message' => 'Lease not found.'
        ], 404);
    }
    $records = DB::table('egc_crpt_lease_deposit_adjustments')->where('lease_id', $id)->orderByDesc('sno')->get()->map(function ($item) {
            $item->adjustment_date = $item->adjustment_date ? Carbon::parse($item->adjustment_date)->format('d-M-Y') : '';
            $item->created_at_time = $item->created_at ? Carbon::parse($item->created_at)->format('h:i A') : '-';
            return $item;
        });
    return response()->json([
        'status' => 200,
        'data' => $records
    ]);
}
}
//egc_crpt_manage_lease_floors
//egc_crpt_manage_lease
//egc_crpt_lease_deposit_adjustments
//egc_crpt_lease_events
//egc_crpt_lease_payments
//egc_crpt_lease_terminate_checklist
