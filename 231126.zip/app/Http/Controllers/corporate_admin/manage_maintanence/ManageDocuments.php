<?php
namespace App\Http\Controllers\corporate_admin\manage_maintanence;
use App\Http\Controllers\Controller;
use App\Models\ManageDocumentsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Throwable;
class ManageDocuments extends Controller
{
    private function uploadDirectory(): string
    {
        return public_path('uploads/corporate_admin_documents');
    }
    public function index(Request $request)
{
    $categories = DB::table('egc_crpt_document_category')->select('sno', 'category_name')->orderBy('category_name')->get();
    $allowedPerPage = [5, 10, 25, 100, 500];
    $perPage = (int) $request->input('perpage', 25);
    if (!in_array($perPage, $allowedPerPage, true)) {
        $perPage = 25;
    }
    $search = trim($request->input('search', ''));
    $documentsQuery = ManageDocumentsModel::query()
        ->join('egc_crpt_document_category as categories','egc_crpt_document_management.document_category_id','=','categories.sno')
        ->select('egc_crpt_document_management.*','categories.category_name')
        ->where('egc_crpt_document_management.status', 0);
    if ($search !== '') {
        $documentsQuery->where(function ($query) use ($search) {
            $query->where('egc_crpt_document_management.document_name','like','%' . $search . '%')
            ->orWhere('categories.category_name','like','%' . $search . '%')
            ->orWhere('egc_crpt_document_management.linked_to','like','%' . $search . '%')
            ->orWhere('egc_crpt_document_management.notes','like','%' . $search . '%');
        });
    }
    $documents = $documentsQuery->orderByDesc('egc_crpt_document_management.sno')->paginate($perPage)->withQueryString();
    $directory = $this->uploadDirectory();
    $totalStorageBytes = 0;
    if (File::isDirectory($directory)) {
        foreach (File::allFiles($directory) as $file) {
            $totalStorageBytes += $file->getSize();
        }
    }
    $allDocuments = ManageDocumentsModel::query()->where('status', 0)->get(['sno', 'expiry_date', 'document_category_id']);
    $stats = [
        'total_documents' => $allDocuments->count(),
        'expired_documents' => $allDocuments->filter(function ($document) {
            if (empty($document->expiry_date)) {
                return false;
            }
            return \Illuminate\Support\Carbon::parse($document->expiry_date)->startOfDay()->lt(now()->startOfDay());
        })->count(),
        'categories_in_use' => $allDocuments->pluck('document_category_id')->filter()->unique()->count(),
        'total_storage' => $this->formatBytes($totalStorageBytes),
    ];
    foreach ($documents as $document) {
        $files = $this->decodeFiles($document->upload_documents);
        $document->display_size = $this->formatBytes(
            collect($files)->sum(function ($file) {
                $path = is_array($file) ? ($file['path'] ?? '') : (is_string($file) ? $file : '');
                if (!$path) {
                    return 0;
                }
                $fullPath = public_path($path);
                return File::isFile($fullPath) ? File::size($fullPath) : 0;
            })
        );
        $document->created_by_name = null;
    }
    return view('content.corporate_admin.manage_maintanence.manage_documents.document_list',compact('categories', 'documents', 'stats', 'perPage', 'search'));
}
    public function store(Request $request)
    {
        $validated = $request->validate([
            'document_name' => ['required','string','max:255',],
            'document_category_id' => ['required','integer','exists:egc_crpt_document_category,sno',],
            'linked_to' => ['required','string','max:255',],
            'expiry_date' => ['nullable','date',],
            'notes' => ['required','string','max:255',],
            'attachment' => ['required','array','min:1',],
            'attachment.*' => ['required','file','max:20480','mimes:pdf,doc,docx,xls,xlsx,csv,jpg,jpeg,png',],
        ]);
        $directory = $this->uploadDirectory();
        if (!File::isDirectory($directory)) {
            File::makeDirectory($directory, 0755, true);
        }
        if (!File::isWritable($directory)) {
            return back()->withInput()->with('error', 'The document upload directory is not writable.');
        }
        $uploadedFiles = [];
        $createdDocument = null;
        try {
            DB::beginTransaction();
            foreach ($request->file('attachment', []) as $file) {
                $originalName = $file->getClientOriginalName();
                $extension = strtolower($file->extension() ?: 'bin');
                $storedName = Str::uuid()->toString(). '.' . $extension;
                $file->move($directory, $storedName);
                $relativePath = 'uploads/corporate_admin_documents/' . $storedName;
                $uploadedFiles[] = ['original_name' => $originalName,'path' => $relativePath,];
            }
            $userId = Auth::id() ?? 0;
            $createdDocument = ManageDocumentsModel::create([
                'document_name' => $validated['document_name'],
                'document_category_id' => $validated['document_category_id'],
                'linked_to' => $validated['linked_to'],
                'expiry_date' => !empty($validated['expiry_date'])? $validated['expiry_date']: now()->toDateTimeString(),
                'notes' => $validated['notes'],
                'upload_documents' => json_encode($uploadedFiles,JSON_UNESCAPED_SLASHES),
                'created_by' => $userId,
                'updated_by' => $userId,
                'status' => 0,
            ]);
            DB::commit();
             return redirect()->back()->with('toastr', ['type' => 'success','message' => 'Document uploaded successfully!']);
        } catch (Throwable $exception) {
            DB::rollBack();
            foreach ($uploadedFiles as $uploadedFile) {
                $path = public_path($uploadedFile['path']);
                if (File::isFile($path)) {
                    File::delete($path);
                }
            }
            report($exception);
            return back()->withInput()->with('error', 'Unable to upload documents. Please try again.');
        }
    }
    public function download($id, $fileIndex)
    {
        $document = ManageDocumentsModel::query()->where('sno', $id)->where('status', 0)->firstOrFail();
        $files = $this->decodeFiles($document->upload_documents);
        if (!is_numeric($fileIndex) ||!isset($files[(int) $fileIndex])) {
            abort(404, 'Document file not found.');
        }
        $file = $files[(int) $fileIndex];
        $relativePath = is_array($file)? ($file['path'] ?? ''): (is_string($file) ? $file : '');
        $originalName = is_array($file)? ($file['original_name'] ?? basename($relativePath)): basename($relativePath);
        $expectedPrefix = 'uploads/corporate_admin_documents/';
        if (!is_string($relativePath) ||!Str::startsWith($relativePath, $expectedPrefix) ||str_contains($relativePath, '..')) {
            abort(404, 'Invalid document path.');
        }
        $fullPath = public_path($relativePath);
        if (!File::isFile($fullPath)) {
            abort(404, 'The requested file does not exist.');
        }
        return response()->download(
        $fullPath,
        basename($originalName),
        [
            'Content-Type' => File::mimeType($fullPath)?: 'application/octet-stream',
            'Cache-Control' => 'private, no-store, max-age=0',
            'X-Content-Type-Options' => 'nosniff',
        ]
    );
    }
    private function decodeFiles($value): array
    {
        if (is_array($value)) {
            return $value;
        }
        if (!is_string($value) || $value === '') {
            return [];
        }
        $decoded = json_decode($value, true);
        if (!is_array($decoded)) {
            return [];
        }
        return $decoded;
    }
    private function formatBytes(int $bytes): string
    {
        if ($bytes < 1024) {
            return $bytes . ' B';
        }
        if ($bytes < 1024 * 1024) {
            return round($bytes / 1024, 2) . ' KB';
        }
        if ($bytes < 1024 * 1024 * 1024) {
            return round($bytes / (1024 * 1024), 2) . ' MB';
        }
        return round($bytes / (1024 * 1024 * 1024), 2) . ' GB';
    }
}
