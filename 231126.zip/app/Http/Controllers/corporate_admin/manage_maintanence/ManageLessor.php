<?php
namespace App\Http\Controllers\corporate_admin\manage_maintanence;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\CityModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\ManageLessorModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
class ManageLessor extends Controller
{
public function index(Request $request)
{
    $helper = new \App\Helpers\Helpers();
    $search_filter = $request->search_filter ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 10);
    $perpage = max(1, min($perpage, 500));
    $lessorlist = ManageLessorModel::where('status', '!=', 2);
    if ($search_filter != '') {
        $lessorlist->where(function ($subquery) use ($search_filter) {
            $subquery->where('lessor_name', 'LIKE', "%{$search_filter}%")
                ->orWhere('legal_name', 'LIKE', "%{$search_filter}%")
                ->orWhere('ifsc_code', 'LIKE', "%{$search_filter}%")
                ->orWhere('mobile_number', 'LIKE', "%{$search_filter}%")
                ->orWhere('email_id', 'LIKE', "%{$search_filter}%")
                ->orWhereHas('city', function ($cityQuery) use ($search_filter) {
                    $cityQuery->where('name', 'LIKE', "%{$search_filter}%");
                });
        });
    }
    $lessorlist = $lessorlist->orderBy('sno', 'desc')->paginate($perpage);
    if ($request->ajax()) {
        $data = $lessorlist->map(function ($item) use ($helper) {
            return [
              'sno' => $item->sno,
              'legal_name' => $item->legal_name,
              'lessor_name' => $item->lessor_name,
              'lessor_code' => 'LSR-' . str_pad($item->sno, 3, '0', STR_PAD_LEFT),
              'ifsc_code' => $item->ifsc_code,
              'city_name' => $item->city->name ?? '',
              'leases_count' => DB::table('egc_crpt_manage_lease')->where('lessor_id', $item->sno)->where('status', '!=', 2)->count(),
              'status' => $item->status,
              'image' => asset('assets/egc_images/auth/user_2.png'),
          ];
        });
        return response()->json([
            'data' => $data,
            'current_page' => $lessorlist->currentPage(),
            'last_page' => $lessorlist->lastPage(),
            'total' => $lessorlist->total(),
        ]);
    }
    return view('content.corporate_admin.manage_maintanence.manage_lessor.lessor_list',
        [
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'lessorlist' => $lessorlist,
        ]
    );
}
    // Country List
    public function ListCountry()
    {
        $countries = CountryModel::where('status', 0)->select('id', 'name')->orderBy('name', 'asc')->get();
        return response()->json([
            'status' => 200,
            'message' => 'Countries fetched successfully.',
            'data' => $countries,
        ]);
    }
    // State List
    public function List($countryId)
    {
        $states = StateModel::where('country_id', $countryId)->where('status', 0)->select('id', 'country_id', 'name')->orderBy('name', 'asc')->get();
        return response()->json([
            'status' => 200,
            'message' => 'States fetched successfully.',
            'data' => $states,
        ]);
    }
    // City List
    public function ListCity($stateId)
    {
        $cities = CityModel::where('state_id', $stateId)->where('status', 0)->select('id', 'state_id', 'name')->orderBy('name', 'asc')->get();
        return response()->json([
            'status' => 200,
            'message' => 'Cities fetched successfully.',
            'data' => $cities,
        ]);
    }
    // Add Lessor
    public function Add(Request $request)
    {   $userId = $request->user()->userId ?? 1;
        $validator = Validator::make($request->all(), [
            'legal_name' => 'required|string|max:255',
            'lessor_name' => 'required|string|max:255',
            'mobile_number' => 'required|string|max:20',
            'country_id' => 'required|exists:egc_countries,id',
            'state_id' => 'required|exists:egc_states,id',
            'city_id' => 'required|exists:egc_cities,id',
            'bank_name' => 'required|string|max:255',
            'bank_branch_name' => 'required|string|max:255',
            'acc_holder_name' => 'required|string|max:255',
            'acc_holder_number' => 'required|string|max:30',
            'ifsc_code' => 'required|string|max:20',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Please check the required fields.',
                'error_msg' => $validator->errors(),
                'data' => null,
            ]);
        }
        $exists = ManageLessorModel::where('lessor_name', $request->lessor_name)->where('status', '!=', 2)->exists();
        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'Lessor Name Already Exists!',
                'data' => null,
            ]);
        }
        $lessor = new ManageLessorModel();
        $lessor->legal_name = $request->legal_name;
        $lessor->lessor_name = $request->lessor_name;
        $lessor->mobile_number = $request->mobile_number;
        $lessor->email_id = $request->email_id;
        $lessor->country_id = $request->country_id;
        $lessor->state_id = $request->state_id;
        $lessor->city_id = $request->city_id;
        $lessor->pan_number = $request->pan_number;
        $lessor->gstin = $request->gstin;
        $lessor->description = $request->description;
        $lessor->bank_name = $request->bank_name;
        $lessor->bank_branch_name = $request->bank_branch_name;
        $lessor->acc_holder_name = $request->acc_holder_name;
        $lessor->acc_holder_number = $request->acc_holder_number;
        $lessor->ifsc_code = $request->ifsc_code;
        $lessor->created_by = $userId;
        $lessor->updated_by = $userId;
        $lessor->status = 0;
        $lessor->save();
        return response()->json([
            'status' => 200,
            'message' => 'Lessor added successfully!',
            'data' => $lessor,
        ]);
    }
    // Fetch Lessor for Edit
    public function Edit($id)
    {
        $lessor = ManageLessorModel::where('sno', $id)->where('status', '!=', 2)->first();
        if (!$lessor) {
            return response()->json([
                'status' => 404,
                'message' => 'Lessor not found!',
                'data' => null,
            ]);
        }
        return response()->json([
            'status' => 200,
            'message' => 'Lessor fetched successfully.',
            'data' => $lessor,
        ]);
    }
    // Update Lessor
    public function Update(Request $request)
    {   $userId = $request->user()->userId ?? 1;
        $validator = Validator::make($request->all(), [
            'edit_id' => 'required|exists:egc_crpt_manage_lessor,sno',
            'legal_name' => 'required|string|max:255',
            'lessor_name' => 'required|string|max:255',
            'mobile_number' => 'required|string|max:20',
            'country_id' => 'required|exists:egc_countries,id',
            'state_id' => 'required|exists:egc_states,id',
            'city_id' => 'required|exists:egc_cities,id',
            'bank_name' => 'required|string|max:255',
            'bank_branch_name' => 'required|string|max:255',
            'acc_holder_name' => 'required|string|max:255',
            'acc_holder_number' => 'required|string|max:30',
            'ifsc_code' => 'required|string|max:20',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Please check the required fields.',
                'error_msg' => $validator->errors(),
                'data' => null,
            ]);
        }
        $lessor = ManageLessorModel::where('sno', $request->edit_id)->where('status', '!=', 2)->first();
        if (!$lessor) {
            return response()->json([
                'status' => 404,
                'message' => 'Lessor not found!',
                'data' => null,
            ]);
        }
        $exists = ManageLessorModel::where('lessor_name', $request->lessor_name)->where('sno', '!=', $request->edit_id)->where('status', '!=', 2)->exists();
        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'Lessor Name Already Exists!',
                'data' => null,
            ]);
        }
        $lessor->legal_name = $request->legal_name;
        $lessor->lessor_name = $request->lessor_name;
        $lessor->mobile_number = $request->mobile_number;
        $lessor->email_id = $request->email_id;
        $lessor->country_id = $request->country_id;
        $lessor->state_id = $request->state_id;
        $lessor->city_id = $request->city_id;
        $lessor->pan_number = $request->pan_number;
        $lessor->gstin = $request->gstin;
        $lessor->description = $request->description;
        $lessor->bank_name = $request->bank_name;
        $lessor->bank_branch_name = $request->bank_branch_name;
        $lessor->acc_holder_name = $request->acc_holder_name;
        $lessor->acc_holder_number = $request->acc_holder_number;
        $lessor->ifsc_code = $request->ifsc_code;
        $lessor->updated_by = $userId;
        $lessor->save();
        return response()->json([
            'status' => 200,
            'message' => 'Lessor updated successfully!',
            'data' => $lessor,
        ]);
    }
    public function details($id)
{
    $lessor = ManageLessorModel::with('city')->where('sno', $id)->where('status', '!=', 2)->first();
    if (!$lessor) {
        return response()->json([
            'status' => 404,
            'message' => 'Lessor not found!'
        ], 404);
    }
    return response()->json([
        'status' => 200,
        'data' => [
            'sno' => $lessor->sno,
            'legal_name' => $lessor->legal_name,
            'lessor_name' => $lessor->lessor_name,
            'mobile_number' => $lessor->mobile_number,
            'email_id' => $lessor->email_id,
            'city_name' => $lessor->city->name ?? '',
            'pan_number' => $lessor->pan_number,
            'gstin' => $lessor->gstin,
            'bank_name' => $lessor->bank_name,
            'bank_branch_name' => $lessor->bank_branch_name,
            'acc_holder_name' => $lessor->acc_holder_name,
            'acc_holder_number' => $lessor->acc_holder_number,
            'ifsc_code' => $lessor->ifsc_code,
            'status' => $lessor->status,
            'leases_count' => 0,
        ]
    ]);
}
public function updateStatus(Request $request, $id)
{
    $lessor = ManageLessorModel::where('sno', $id)->first();
    if (!$lessor) {
        return response()->json([
            'status' => 404,
            'message' => 'Lessor not found!'
        ]);
    }
    $request->validate([
        'status' => 'required|in:0,1'
    ]);
    $lessor->status = $request->status;
    $lessor->save();
    return response()->json([
        'status' => 200,
        'message' => 'Lessor status updated successfully!'
    ]);
}
public function getLessorLeases($id)
{
    $leases = DB::table('egc_crpt_manage_lease as lease')
        ->join('egc_buildings as building', 'building.sno', '=', 'lease.building_id')
        ->where('lease.lessor_id', $id)
        ->where('lease.status', '!=', 2)
        ->select(
            'lease.sno',
            DB::raw("CONCAT('LSE-',YEAR(lease.created_at),'-',LPAD(lease.sno, 4, '0')) as lease_number"),
            'lease.start_date',
            'lease.end_date',
            'lease.term_length',
            'lease.monthly_rent',
            'lease.status',
            'building.building_name'
        )->orderByDesc('lease.sno')->get();
    $leases->transform(function ($lease) {
        $lease->status = $this->getLeaseStatus($lease);
        return $lease;
    });
    return response()->json([
        'status' => 200,
        'data' => $leases
    ]);
}
private function getLeaseStatus($lease)
{
    $today = \Carbon\Carbon::today();
    $startDate = !empty($lease->start_date) ? \Carbon\Carbon::parse($lease->start_date)->startOfDay() : null;
    $endDate = !empty($lease->end_date) ? \Carbon\Carbon::parse($lease->end_date)->startOfDay() : null;
    if ($endDate && $endDate->lt($today)) {
        return 4;
    }
    if ($startDate && $startDate->lte($today)
        && $endDate && $endDate->lte($today->copy()->addDays(30))) {
        return 3;
    }
    return in_array((int) $lease->status, [0, 1], true) ? (int) $lease->status : 0;
}
}
