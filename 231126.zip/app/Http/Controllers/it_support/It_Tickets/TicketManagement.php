<?php
namespace App\Http\Controllers\it_support\It_Tickets;
use App\Http\Controllers\Controller;
use App\Models\StaffModel;
use App\Models\TicketRequestModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
class TicketManagement extends Controller

// in this the self functions and Private variables and functions are refered from the brower website name -> stack overflow -> you can also use it
{
    private const STATUS_TEXT = [0 => 'In Progress',1 => 'Open',2 => 'Deleted',3 => 'On Hold',4 => 'Resolved',5 => 'Closed',];
    private const PRIORITY_TEXT = [1 => 'P1 — Critical',2 => 'P2 — High',3 => 'P3 — Medium',4 => 'P4 — Low',];
    public function index()
    {
        return view('content.it_support.it_tickets.tickets_management');
    }
    public function listTickets(Request $request): JsonResponse
    {   $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $generalCompanyName = $generalSetting->title ?? '-';
        $query = TicketRequestModel::query()
            ->from('egc_it_raise_ticket as ticket')
            ->join('egc_it_asset_category as cat','cat.sno','=','ticket.category_id')
            ->leftJoin('egc_company as company','company.sno','=','ticket.company_id')
            ->join('egc_branch as branch','branch.sno','=','ticket.branch_id')
            ->join('egc_staff as requester','requester.sno','=','ticket.requester_id')
            ->join('egc_staff as assignee','assignee.sno','=','ticket.assignee_id')
            ->join('egc_it_asset_management as asset','asset.sno','=','ticket.asset_id')
            ->where('ticket.status', '!=', 2)
            ->select([
                'ticket.sno',
                'ticket.ticket_number',
                'ticket.title',
                'ticket.description',
                'ticket.category_id',
                'ticket.priority',
                'ticket.status',
                'ticket.company_id',
                'ticket.branch_id',
                'ticket.requester_id',
                'ticket.assignee_id',
                'ticket.asset_id',
                'ticket.created_by',
                'ticket.created_at',
                'ticket.updated_at',
                'cat.category_name',
                'company.company_name',
                'branch.branch_name',
                'requester.staff_name as requester_name',
                'assignee.staff_name as assignee_name',
                'asset.make as asset_make',
            ])->addSelect(DB::raw('CASE WHEN ticket.company_id = 0 THEN ' . DB::getPdo()->quote($generalCompanyName) . ' ELSE company.company_name END AS company_name'))
            ->orderByDesc('ticket.sno');
        if ($request->filled('search')) {
            $search = trim($request->search);
            $query->where(function ($q) use ($search) {
                $q->where('ticket.ticket_number', 'like', "%{$search}%")
                    ->orWhere('ticket.title', 'like', "%{$search}%")
                    ->orWhere('cat.category_name', 'like', "%{$search}%")
                    ->orWhere('company.company_name', 'like', "%{$search}%")
                    ->orWhere('requester.staff_name', 'like', "%{$search}%")
                    ->orWhere('assignee.staff_name', 'like', "%{$search}%");
            });
        }
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('ticket.status', (int) $request->status);
        }
        if ($request->filled('priority') && $request->priority !== 'all') {
            $query->where('ticket.priority', (int) $request->priority);
        }
        if ($request->filled('assignee_id') && $request->assignee_id !== 'all') {
            if ($request->assignee_id === 'unassigned') {
                $query->whereNull('ticket.assignee_id');
            } else {
                $query->where('ticket.assignee_id', (int) $request->assignee_id);
            }
        }
        $perPage = (int) $request->input('per_page', 25);
        if (!in_array($perPage, [5, 10, 25, 100, 500], true)) {
            $perPage = 25;
        }
        $tickets = $query->paginate($perPage);
        $data = $tickets->getCollection()->map(function ($ticket) {
            return $this->formatTicket($ticket);
        });
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $data,
            'current_page' => $tickets->currentPage(),
            'last_page' => $tickets->lastPage(),
            'per_page' => $tickets->perPage(),
            'total' => $tickets->total(),
        ]);
    }
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make(
            $request->all(),
            [
                'title' => ['required','string','max:255',],
                'description' => ['nullable','string','max:5000',],
                'category_id' => ['required','integer','exists:egc_it_asset_category,sno',],
                'priority' => ['required','integer','in:1,2,3,4',],
                'company_id' => [
                    'required',
                    'integer',
                    'min:0',
                    function ($attribute, $value, $fail) {
                        if ((int) $value === 0) {
                            return;
                        }

                        if (!DB::table('egc_company')
                            ->where('sno', $value)
                            ->where('status', 0)
                            ->exists()) {
                            $fail('The selected company is invalid.');
                        }
                    },
                ],
                'branch_id' => ['nullable','integer','exists:egc_branch,sno',],
                'requester_id' => ['required','integer','exists:egc_staff,sno',],
                'assignee_id' => ['nullable','integer','exists:egc_staff,sno',],
                'asset_id' => ['nullable','integer','exists:egc_it_asset_management,sno',],
            ],
            [
                'title.required' => 'Title is required.',
                'category_id.required' => 'Category is required.',
                'priority.required' => 'Priority is required.',
                'company_id.required' => 'Company is required.',
                'requester_id.required' => 'Requester is required.',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Please correct the highlighted fields.',
                'errors' => $validator->errors(),
            ], 422);
        }
        DB::beginTransaction();
        try {
            $lastTicket = TicketRequestModel::query()->whereNotNull('ticket_number')->orderByDesc('sno')->lockForUpdate()->first();
            $nextNumber = 1;
            if ($lastTicket && preg_match('/(\d+)$/', $lastTicket->ticket_number, $matches)) {
                $nextNumber = ((int) $matches[1]) + 1;
            }
            $ticketNumber = 'TKT-' . str_pad($nextNumber,4,'0',STR_PAD_LEFT);
            $userId = $request->user()->userId ?? 1;
            $ticket = TicketRequestModel::create([
                'ticket_number' => $ticketNumber,
                'title' => trim($request->title),
                'description' => $request->description,
                'category_id' => $request->category_id,
                'priority' => $request->priority,
                'status' => 1,
                'company_id' => $request->company_id,
                'branch_id' => $request->branch_id ?: null,
                'requester_id' => $request->requester_id,
                'assignee_id' => $request->assignee_id ?: null,
                'asset_id' => $request->asset_id ?: null,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);
            DB::commit();
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Ticket created successfully.',
                'data' => $this->getTicketDetails($ticket->sno),
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Unable to create ticket.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null,
            ], 500);
        }
    }
    public function show($id): JsonResponse
    {
        $ticket = $this->getTicketDetails($id);
        if (!$ticket) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Ticket not found.',
            ], 404);
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $ticket,
        ]);
    }
    public function update(Request $request, $id): JsonResponse
    {   $userId = $request->user()->userId ?? 1;
        $ticket = TicketRequestModel::find($id);
        if (!$ticket || (int) $ticket->status === 2) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Ticket not found.',
            ], 404);
        }
        $validator = Validator::make(
            $request->all(),
            [
                'title' => ['required','string','max:255',],
                'description' => ['nullable','string','max:5000',],
                'category_id' => ['required','integer','exists:egc_it_asset_category,sno',],
                'priority' => ['required','integer','in:1,2,3,4',],
                'company_id' => ['required','integer','min:0',
                    function ($attribute, $value, $fail) {
                        if ((int) $value === 0) {
                            return;
                        }
                        if (!DB::table('egc_company')->where('sno', $value)->where('status', 0)->exists()) {$fail('The selected company is invalid.');
                        }
                    },
                ],
                'branch_id' => ['nullable','integer','exists:egc_branch,sno',],
                'requester_id' => ['required','integer','exists:egc_staff,sno',],
                'assignee_id' => ['nullable','integer','exists:egc_staff,sno',],
                'asset_id' => ['nullable','integer','exists:egc_it_asset_management,sno',],
            ],
        );

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Please correct the highlighted fields.',
                'errors' => $validator->errors(),
            ], 422);
        }
        try {
            $ticket->update([
                'title' => trim($request->title),
                'description' => $request->description,
                'category_id' => $request->category_id,
                'priority' => $request->priority,
                'status' => $request->status,
                'company_id' => $request->company_id,
                'branch_id' => $request->branch_id ?: null,
                'requester_id' => $request->requester_id,
                'assignee_id' => $request->assignee_id ?: null,
                'asset_id' => $request->asset_id ?: null,
                'updated_by' => $userId,
            ]);
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Ticket updated successfully.',
                'data' => $this->getTicketDetails($ticket->sno),
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Unable to update ticket.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null,
            ], 500);
        }
    }
    public function updateStatus(Request $request, $id): JsonResponse
    {   $userId = $request->user()->userId ?? 1;
        $validator = Validator::make($request->all(),['status' => ['required','integer','in:0,1,3,4,5',],]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Invalid ticket status.',
                'errors' => $validator->errors(),
            ], 422);
        }
        $ticket = TicketRequestModel::find($id);
        if (!$ticket || (int) $ticket->status === 2) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Ticket not found.',
            ], 404);
        }
        $ticket->update(['status' => (int) $request->status,'updated_by' => $userId,]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Ticket status updated successfully.',
            'data' => $this->getTicketDetails($ticket->sno),
        ]);
    }
    public function Delete(Request $request,$id): JsonResponse
    {   $userId = $request->user()->userId ?? 1;
        $ticket = TicketRequestModel::find($id);
        if (!$ticket) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Ticket not found.',
            ], 404);
        }
        if ((int) $ticket->status === 2) {
            return response()->json([
                'success' => false,
                'status' => 400,
                'message' => 'Ticket is already deleted.',
            ], 400);
        }
        $ticket->update(['status' => 2,'updated_by' =>$userId,]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Ticket deleted successfully.',
        ]);
    }
    public function listTicketCategories(): JsonResponse
    {
        $categories = DB::table('egc_it_asset_category')->where('status', 0)->orderBy('category_name', 'ASC')->get(['sno','category_name',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $categories,
        ]);
    }
    public function listTicketCompanies(): JsonResponse
{
    $helper = new \App\Helpers\Helpers();
    $generalSetting = $helper->general_setting_data();
    $companies = DB::table('egc_company')->where('status', 0)->orderBy('company_name', 'ASC')->get(['sno', 'company_name']);
    if ($generalSetting) {
        $companies->prepend((object) [
            'sno' => 0,
            'company_name' => $generalSetting->title,
        ]);
    }
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $companies,
    ]);
}
    public function listTicketBranches(): JsonResponse
    {
        $branches = DB::table('egc_branch')->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','branch_name',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $branches,
        ]);
    }
   public function listTicketRequesters(): JsonResponse
{
    $requesters = StaffModel::query()->where('status', 0)->orderBy('staff_name', 'ASC')->get(['sno', 'staff_name']);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $requesters,
    ]);
}
    public function listTicketAssignees(): JsonResponse
    {
        $assignees = StaffModel::query()->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','staff_name',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $assignees,
        ]);
    }
    public function listTicketAssets(): JsonResponse
    {
        $assets = DB::table('egc_it_asset_management')->where('status', '!=', 4)->orderBy('make', 'ASC')->get(['sno','make',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $assets,
        ]);
    }

    private function formatTicket($ticket): array
    {
        return [
            'sno' => (int) $ticket->sno,
            'ticket_number' => $ticket->ticket_number,
            'title' => $ticket->title,
            'description' => $ticket->description,
            'category_id' => $ticket->category_id,
            'category_name' => $ticket->category_name,
            'priority' => (int) $ticket->priority,
            'priority_text' => self::PRIORITY_TEXT[(int) $ticket->priority] ?? '-',
            'status' => (int) $ticket->status,
            'status_text' => self::STATUS_TEXT[(int) $ticket->status] ?? '-',
            'company_id' => $ticket->company_id,
            'company_name' => $ticket->company_name,
            'branch_id' => $ticket->branch_id,
            'branch_name' => $ticket->branch_name,
            'requester_id' => $ticket->requester_id,
            'requester_name' => $ticket->requester_name,
            'assignee_id' => $ticket->assignee_id,
            'assignee_name' => $ticket->assignee_name,
            'asset_id' => $ticket->asset_id,
            'asset_make' => $ticket->asset_make,
            'created_at' => $ticket->created_at? Carbon::parse($ticket->created_at)->format('d M Y · h:i A'): '-',
            'created_person' => $ticket->created_at? Carbon::parse($ticket->created_at)->diffForHumans(): '-',
            'sla' => $this->buildSlaData($ticket),
        ];
    }
    private function getTicketDetails($id): ?array
    {
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $generalCompanyName = $generalSetting->title ?? '-';
        $ticket = DB::table('egc_it_raise_ticket as ticket')
           ->join('egc_it_asset_category as cat','cat.sno','=','ticket.category_id')
            ->leftJoin('egc_company as company','company.sno','=','ticket.company_id')
            ->join('egc_branch as branch','branch.sno','=','ticket.branch_id')
            ->leftJoin('egc_staff as requester','requester.sno','=','ticket.requester_id')
            ->leftJoin('egc_staff as assignee','assignee.sno','=','ticket.assignee_id')
            ->join('egc_it_asset_management as asset','asset.sno','=','ticket.asset_id')
            ->where('ticket.sno', $id)
            ->select([
                'ticket.*',
                'cat.category_name',
                'company.company_name',
                'branch.branch_name',
                'requester.staff_name as requester_name',
                'assignee.staff_name as assignee_name',
                'asset.make as asset_make',
            ]) ->selectRaw(
            'CASE
                WHEN ticket.company_id = 0 THEN ?
                ELSE company.company_name
            END AS company_name',
            [$generalCompanyName]
        )
        ->first();
        if (!$ticket) {
            return null;
        }
        return [
            'sno' => (int) $ticket->sno,
            'ticket_number' => $ticket->ticket_number,
            'title' => $ticket->title,
            'description' => $ticket->description,
            'category_id' => $ticket->category_id,
            'category_name' => $ticket->category_name,
            'priority' => (int) $ticket->priority,
            'priority_text' => self::PRIORITY_TEXT[(int) $ticket->priority] ?? '-',
            'status' => (int) $ticket->status,
            'status_text' => self::STATUS_TEXT[(int) $ticket->status] ?? '-',
            'company_id' => $ticket->company_id,
            'company_name' => $ticket->company_name,
            'branch_id' => $ticket->branch_id,
            'branch_name' => $ticket->branch_name,
            'requester_id' => $ticket->requester_id,
            'requester_name' => $ticket->requester_name,
            'assignee_id' => $ticket->assignee_id,
            'assignee_name' => $ticket->assignee_name,
            'asset_id' => $ticket->asset_id,
            'asset_make' => $ticket->asset_make,
            'created_at' => $ticket->created_at? Carbon::parse($ticket->created_at)->format('d M Y · h:i A'): '-',
            'created_person' => $ticket->created_at? Carbon::parse($ticket->created_at)->diffForHumans(): '-',
            'updated_at' => $ticket->updated_at? Carbon::parse($ticket->updated_at)->format('d M Y · h:i A'): '-',
            'sla' => $this->buildSlaData($ticket),
        ];
    }

    //here the carbon diffForHumans i got it from the browers for the timestamp website name -> LaravelDaily
    private function buildSlaData($ticket): array
    {
        return ['label' => 'On track','class' => 'on-track','target' => '-','due_at' => null,];
    }
}
