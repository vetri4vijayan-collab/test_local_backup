<?php
namespace App\Http\Controllers\it_support\Licence_Subscription;
use App\Http\Controllers\Controller;
use App\Models\StaffModel;
use App\Models\TicketRequestModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\Models\LicencesSubscriptionsModel;
use App\Models\LicenceSeatAssignmentModel;
use Illuminate\Validation\Rule;
class LicenceSubscription extends Controller
{
    private const ACTIVE = 0;
    private const INACTIVE = 1;
    private const DELETED = 2;
    private const TYPE_SUBSCRIPTION = 1;
    private const BILLING_ANNUAL = 1;
    private const BILLING_MONTHLY = 2;
    public function index()
    {
        return view('content.it_support.licences_subscriptions.licences_subscriptions');
    }
    private function jsonError(string $message, int $code = 422): JsonResponse
    {
        return response()->json([
            'success' => false,
            'message' => $message,
        ], $code);
    }
    private function licenceQuery()
    {
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $generalCompanyName = $generalSetting->title ?? '-';
        return LicencesSubscriptionsModel::query()
            ->join('egc_it_vendor_category as v','v.sno','=','egc_it_licence.vendor_id')
            ->leftJoin('egc_company as c','c.sno','=','egc_it_licence.company_id')
            ->leftJoin('egc_staff as o','o.sno','=','egc_it_licence.owner_id')
            ->select('egc_it_licence.*','v.vendor_category_name as vendor_name','c.company_name','o.staff_name as owner_name')
            ->addSelect(DB::raw('CASE WHEN egc_it_licence.company_id = 0 THEN ' . DB::getPdo()->quote($generalCompanyName) . ' ELSE c.company_name END AS company_name'))
            ->withCount(['activeSeatAssignments as used_seats',]);
    }
    private function formatLicence($licence): array
    {
        $used = (int) ($licence->used_seats ?? 0);
        $total = (int) $licence->total_seats;
        $renewal = $licence->renewal_date? Carbon::parse($licence->renewal_date)->startOfDay(): null;
        $today = now()->startOfDay();
        $daysRemaining = $renewal? (int) $today->diffInDays($renewal, false): null;
        return [
            'sno' => (int) $licence->sno,
            'product_name' => $licence->product_name,
            'vendor_id' => (int) $licence->vendor_id,
            'vendor_name' => $licence->vendor_name ?? '-',
            'type_id' => (int) $licence->type_id,
            'type_name' => $this->typeName($licence->type_id),
            'total_seats' => $total,
            'used_seats' => $used,
            'available_seats' => max(0, $total - $used),
            'cost' => (float) $licence->cost,
            'billing_cycle_id' => (int) $licence->billing_cycle_id,
            'billing_cycle_name' => $this->billingName($licence->billing_cycle_id),
            'renewal_date' => $renewal?->format('Y-m-d'),
            'renewal_display' => $renewal?->format('d M Y'),
            'days_remaining' => $daysRemaining,
            'owner_id' => (int) $licence->owner_id,
            'owner_name' => $licence->owner_name ?? '-',
            'company_id' => (int) $licence->company_id,
            'company_name' => $licence->company_name ?? '-',
            'status' => (int) $licence->status,
            'status_name' => (int) $licence->status === self::ACTIVE? 'Active': 'Inactive',
        ];
    }
    private function typeName($id): string
    {
        return (int) $id === self::TYPE_SUBSCRIPTION? 'Subscription': 'Licence';
    }

    private function billingName($id): string
    {
        return match ((int) $id) {
            self::BILLING_ANNUAL => 'Annual',
            self::BILLING_MONTHLY => 'Monthly',
            default => 'Unknown',
        };
    }
    private function rules(): array
    {
        return [
            'product_name' => ['required', 'string', 'max:255'],
            'vendor_id' => ['required','integer',Rule::exists('egc_it_vendor_category', 'sno'),],
            'type_id' => ['required','integer',Rule::in([self::TYPE_SUBSCRIPTION]),],
            'total_seats' => ['required', 'integer', 'min:1', 'max:100000'],
            'cost' => ['required', 'numeric', 'min:0', 'max:999999999'],
            'billing_cycle_id' => ['required','integer',Rule::in([self::BILLING_ANNUAL,self::BILLING_MONTHLY,]),],
            'renewal_date' => ['nullable','date_format:d-M-Y',],
            'owner_id' => ['required','integer',Rule::exists('egc_staff', 'sno')->where('status', 0),],
           'company_id' => ['required','integer','min:0',
            function ($attribute, $value, $fail) {
                if ((int) $value === 0) {
                    return;
                }
                if (!DB::table('egc_company')->where('sno', $value)->where('status', 0)
                    ->exists()) {
                    $fail('The selected company is invalid.');
                }
            },
        ],
            'status' => ['sometimes', 'integer', Rule::in([0, 1])],
        ];
    }
    public function list(Request $request): JsonResponse
    {
        $allowedPerPage = [5, 10, 25, 100, 500];
        $perPage = (int) $request->input('licencePerPage', 25);
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $query = $this->licenceQuery()->where('egc_it_licence.status', '!=', self::DELETED);
        if ($request->filled('search')) {
            $search = trim($request->search);
            $query->where(function ($q) use ($search) {
                $q->where('egc_it_licence.product_name', 'like', "%{$search}%")
                    ->orWhere('v.vendor_category_name', 'like', "%{$search}%")
                    ->orWhere('c.company_name', 'like', "%{$search}%")
                    ->orWhere('o.staff_name', 'like', "%{$search}%");
            });
        }
        if ($request->filled('type_id') && $request->type_id !== 'all') {
            $query->where('egc_it_licence.type_id',$request->type_id);
        }
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('egc_it_licence.status',$request->status);
        }
        if ($request->input('renewal') === '30') {
            $query->whereNotNull('egc_it_licence.renewal_date')
                ->whereBetween('egc_it_licence.renewal_date', [
                    today()->toDateString(),
                    today()->addDays(30)->toDateString(),
                ]);
        }
        $records = $query->orderBy('egc_it_licence.renewal_date')->orderByDesc('egc_it_licence.sno')->paginate($perPage)->withQueryString();
        $records->getCollection()->transform(fn ($row) => $this->formatLicence($row));
        $active = $this->licenceQuery()->where('egc_it_licence.status', self::ACTIVE)->get();
        $monthlyRunRate = 0.0;
        $annualised = 0.0;
        $usedSeats = 0;
        $totalSeats = 0;
        foreach ($active as $licence) {
            $cost = (float) $licence->cost;
            if ((int) $licence->billing_cycle_id === self::BILLING_ANNUAL) {
                $monthlyRunRate += $cost / 12;
                $annualised += $cost;
            } else {
                $monthlyRunRate += $cost;
                $annualised += $cost * 12;
            }

            $usedSeats += (int) ($licence->used_seats ?? 0);
            $totalSeats += (int) $licence->total_seats;
        }
        $renewing = $active->filter(function ($licence) {
            if (!$licence->renewal_date) {
                return false;
            }
            $date = Carbon::parse($licence->renewal_date)->startOfDay();
            return $date->betweenIncluded(today()->startOfDay(),today()->addDays(30)->endOfDay());
        })->map(function ($licence) {
            $date = Carbon::parse($licence->renewal_date)->startOfDay();
            return [
                'product_name' => $licence->product_name,
                'days_remaining' => (int) today()->diffInDays($date, false),
            ];
        })->values();
        return response()->json([
            'success' => true,
            'data' => $records->items(),
            'pagination' => [
                'current_page' => $records->currentPage(),
                'per_page' => $records->perPage(),
                'total' => $records->total(),
                'last_page' => $records->lastPage(),
                'from' => $records->firstItem(),
                'to' => $records->lastItem(),
            ],
            'dashboard' => [
                'renewing_count' => $renewing->count(),
                'renewing_products' => $renewing,
                'monthly_run_rate' => round($monthlyRunRate, 2),
                'annualised_cost' => round($annualised, 2),
                'subscription_count' => $active->count(),
                'used_seats' => $usedSeats,
                'total_seats' => $totalSeats,
                'full_capacity_count' => $active->filter(
                    fn ($licence) =>
                        (int) $licence->total_seats > 0
                        && (int) ($licence->used_seats ?? 0)
                            >= (int) $licence->total_seats
                )->count(),
            ],
        ]);
    }
    public function masters(): JsonResponse
    {
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $vendors = DB::table('egc_it_vendor_category')->orderBy('vendor_category_name')->get(['sno', 'vendor_category_name']);
         $companies = DB::table('egc_company')->where('status', 0)->orderBy('company_name')->get(['sno', 'company_name']);
        if ($generalSetting) {
            $companies->prepend((object) ['sno' => 0,'company_name' => $generalSetting->title,]);
        }
        $owners = StaffModel::query()->where('status', 0)->orderBy('staff_name')->get(['sno', 'staff_name']);
        return response()->json([
            'success' => true,
            'data' => [
                'vendors' => $vendors,
                'companies' => $companies,
                'owners' => $owners,
                'types' => [
                    ['id' => 1, 'name' => 'Subscription'],
                ],
                'billing_cycles' => [
                    ['id' => 1, 'name' => 'Annual'],
                    ['id' => 2, 'name' => 'Monthly'],
                ],
            ],
        ]);
    }
    public function show(int $id): JsonResponse
    {
        $licence = $this->licenceQuery()->where('egc_it_licence.sno', $id)->where('egc_it_licence.status', '!=', self::DELETED)->first();
        if (!$licence) {
            return $this->jsonError('Licence not found.', 404);
        }
        $data = $this->formatLicence($licence);
        $assignments = LicenceSeatAssignmentModel::query()->where('licence_id', $id)->where('status', 0)->orderBy('sno')->get();
        $employeeIds = $assignments->pluck('employee_id')->unique();
        $employees = StaffModel::query()->whereIn('sno', $employeeIds)->get(['sno', 'staff_name'])->keyBy('sno');
        $data['assignments'] = $assignments->map(function ($assignment) use ($employees) {
            $employee = $employees->get($assignment->employee_id);
            return [
                'id' => $assignment->sno,
                'employee_id' => $assignment->employee_id,
                'employee_name' => $employee?->staff_name ?? 'Unknown employee',
            ];
        })->values();
        $data['activity'] = [
            [
                'action' => 'Licence registered',
                'date' => $licence->created_at,
                'user' => $licence->created_by,
            ],
        ];
        return response()->json([
            'success' => true,
            'data' => $data,
        ]);
    }
    public function store(Request $request): JsonResponse
{   $userId = $request->user()->userId ?? 1;
    $validator = Validator::make($request->all(),$this->rules());
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $validator->errors(),
        ], 422);
    }
    $data = $validator->validated();
    $licence = LicencesSubscriptionsModel::create([
        'product_name' => $data['product_name'],
        'vendor_id' => $data['vendor_id'],
        'type_id' => $data['type_id'],
        'total_seats' => $data['total_seats'],
        'cost' => $data['cost'],
        'billing_cycle_id' => $data['billing_cycle_id'],
        'renewal_date' => !empty($data['renewal_date'])? Carbon::createFromFormat('d-M-Y', $data['renewal_date'])->format('Y-m-d'): null,
        'owner_id' => $data['owner_id'],
        'company_id' => $data['company_id'],
        'created_by' => $userId,
        'updated_by' => $userId,
        'status' => $data['status'] ?? self::ACTIVE,
    ]);
    return response()->json([
        'success' => true,
        'message' => 'Licence created successfully.',
        'data' => [
            'sno' => $licence->sno,
        ],
    ], 201);
}
    public function update(Request $request, int $id): JsonResponse
    {   $userId = $request->user()->userId ?? 1;
        $licence = LicencesSubscriptionsModel::query()->where('sno', $id)->where('status', '!=', self::DELETED)->first();
        if (!$licence) {
            return $this->jsonError('Licence not found.', 404);
        }
        $validator = Validator::make($request->all(), $this->rules());
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Please correct the highlighted fields.',
                'errors' => $validator->errors(),
            ], 422);
        }
        $data = $validator->validated();
        // Do not reduce capacity below the number of seats already assigned.
        $used = $licence->activeSeatAssignments()->count();
        if ((int) $data['total_seats'] < $used) {
            return $this->jsonError("Total seats cannot be less than {$used} assigned seats.");
        }
        $data['renewal_date'] = !empty($data['renewal_date'])? Carbon::createFromFormat('d-M-Y',$data['renewal_date'])->format('Y-m-d'): null;
        $licence->fill($data);
        $licence->updated_by = $userId;
        $licence->save();
        return response()->json([
            'success' => true,
            'message' => 'Licence updated successfully.',
        ]);
    }
    public function changeStatus(Request $request, int $id): JsonResponse
    {   $userId = $request->user()->userId ?? 1;
        $request->validate(['status' => ['required', 'integer', Rule::in([0, 1])],]);
        $licence = LicencesSubscriptionsModel::query()->where('sno', $id)->where('status', '!=', self::DELETED)->first();
        if (!$licence) {
            return $this->jsonError('Licence not found.', 404);
        }
        $licence->status = (int) $request->status;
        $licence->updated_by = $userId;
        $licence->save();
        return response()->json([
            'success' => true,
            'message' => 'Licence status updated successfully.',
        ]);
    }
    public function Delete(Request $request,int $id): JsonResponse
    {   $userId = $request->user()->userId ?? 1;
        $licence = LicencesSubscriptionsModel::query()->where('sno', $id)->where('status', '!=', self::DELETED)->first();
        if (!$licence) {
            return $this->jsonError('Licence not found.', 404);
        }
        if ($licence->activeSeatAssignments()->exists()) {
            return $this->jsonError(
                'Release all assigned seats before deleting this licence.'
            );
        }
        $licence->status = self::DELETED;
        $licence->updated_by = $userId;
        $licence->save();
        return response()->json([
            'success' => true,
            'message' => 'Licence deleted successfully.',
        ]);
    }
    public function employees(int $id): JsonResponse
    {
        $licence = LicencesSubscriptionsModel::query()->where('sno', $id)->where('status', self::ACTIVE)->first();
        if (!$licence) {
            return $this->jsonError('Active licence not found.', 404);
        }
        $assignedIds = LicenceSeatAssignmentModel::query()->where('licence_id', $id)->where('status', 0)->pluck('employee_id');
        $employees = StaffModel::query()->where('status', 0)->whereNotIn('sno', $assignedIds)->orderBy('staff_name')->get(['sno', 'staff_name']);
        return response()->json([
            'success' => true,
            'data' => $employees,
            'available_seats' => max(
                0,
                (int) $licence->total_seats
                    - $licence->activeSeatAssignments()->count()
            ),
        ]);
    }
   public function assignSeat(Request $request, int $id): JsonResponse
    {
        $userId = $request->user()->userId ?? 1;
        $validator = Validator::make($request->all(), [
            'employee_id' => ['required', 'integer',Rule::exists('egc_staff', 'sno')->where('status', 0),],
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Please correct the highlighted fields.',
                'errors' => $validator->errors(),
            ], 422);
        }
        try {
            return DB::transaction(function () use ($request, $id, $userId) {
                $licence = LicencesSubscriptionsModel::query()
                    ->where('sno', $id)->lockForUpdate()->first();
                if (!$licence || (int) $licence->status !== self::ACTIVE) {
                    return $this->jsonError('Only active licences can receive seat assignments.');
                }
                $exists = LicenceSeatAssignmentModel::query()->where('licence_id', $id)->where('employee_id', $request->employee_id)->where('status', 0)->exists();
                if ($exists) {
                    return $this->jsonError('This employee already has a seat assigned.');
                }
                $used = $licence->activeSeatAssignments()->count();
                if ($used >= (int) $licence->total_seats) {
                    return $this->jsonError('All seats are assigned. Increase capacity before assigning another seat.');
                }
                LicenceSeatAssignmentModel::create([
                    'licence_id' => $id,
                    'employee_id' => $request->employee_id,
                    'assigned_by' => $userId,
                    'created_by' => $userId,
                    'updated_by' => $userId,
                    'status' => 0,
                ]);
                return response()->json([
                    'success' => true,
                    'message' => 'Seat assigned successfully.',
                    'used_seats' => $used + 1,
                    'available_seats' => (int) $licence->total_seats - $used - 1,
                ]);
            });
        } catch (\Throwable $e) {
            Log::error('Licence seat assignment failed', [
                'licence_id' => $id,
                'employee_id' => $request->employee_id,
                'error' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
            return $this->jsonError(
                'Unable to assign the seat. ' . $e->getMessage(),
                500
            );
        }
    }
    public function releaseSeat(int $id, int $assignmentId): JsonResponse
    {
        $assignment = LicenceSeatAssignmentModel::query()->where('sno', $assignmentId)->where('licence_id', $id)->where('status', 0)->first();
        if (!$assignment) {
            return $this->jsonError('Active seat assignment not found.', 404);
        }
        $assignment->status = 1;
        $assignment->save();
        return response()->json([
            'success' => true,
            'message' => 'Seat released successfully.',
        ]);
    }
}
