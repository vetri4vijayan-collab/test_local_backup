<?php
namespace App\Http\Controllers\it_support\Asset_Management;
use App\Http\Controllers\Controller;
use App\Models\CompanyModel;
use App\Models\StaffModel;
use App\Models\AssetManagementModel;
use App\Models\AssignAssetsModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
class AssetManagement extends Controller
// in this the self functions and Private variables and functions are refered from the brower website name -> stack overflow -> you can also use it
{
    public function index()
    {
        return view('content.it_support.assets_management.asset_management');
    }
    public function dashboard(): JsonResponse
    {
      //here the clone query i refered it from the website -> laravelDaily -> you can also refer and use this
      // here why iam using the clone because to use the same query with different conditons
        $base = DB::table('egc_it_asset_management');
        $total = (clone $base)->where('status', '!=', self::STATUS_DELETED)->count();
        $inStock = (clone $base)->where('status', self::STATUS_IN_STOCK)->count();
        $assigned = (clone $base)->where('status', self::STATUS_ASSIGNED)->count();
        $repair = (clone $base)->where('status', self::STATUS_REPAIR)->count();
        $retired = (clone $base)->where('status', self::STATUS_RETIRED)->count();
        $active = 0;
        $expiring = 0;
        $expired = 0;
        if (Schema::hasColumn('egc_it_asset_management', 'warranty_status')) {
            $active = (clone $base)->where('status', '!=', self::STATUS_DELETED)->where('warranty_status', self::WARRANTY_ACTIVE)->count();
            $expiring = (clone $base)->where('status', '!=', self::STATUS_DELETED)->where('warranty_status', self::WARRANTY_EXPIRING)->count();
            $expired = (clone $base)->where('status', '!=', self::STATUS_DELETED)->where('warranty_status', self::WARRANTY_EXPIRED)->count();
        } else {
            $today = now()->startOfDay();
            $soon = now()->addDays(90)->endOfDay();
            $active = (clone $base)->where('status', '!=', self::STATUS_DELETED)->whereDate('warranty_until', '>', $soon)->count();
            $expiring = (clone $base)->where('status', '!=', self::STATUS_DELETED)->whereDate('warranty_until', '>=', $today)->whereDate('warranty_until', '<=', $soon)->count();
            $expired = (clone $base)->where('status', '!=', self::STATUS_DELETED)->whereDate('warranty_until', '<', $today)->count();
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => ['total' => $total,'in_stock' => $inStock,'assigned' => $assigned,'repair' => $repair,'retired' => $retired,'active' => $active,'expiring' => $expiring,'expired' => $expired,
            ],
        ]);
    }
    public function masters(): JsonResponse
    {
        $categories = collect();
        if (Schema::hasTable('egc_it_asset_category')) {
            $categories = DB::table('egc_it_asset_category')->when(Schema::hasColumn('egc_it_asset_category', 'status'),fn ($q) => $q->where('status', '!=', 2))->whereNotNull('category_name')
            ->where('category_name', '!=', '')->orderBy('category_name')->get(['sno', 'category_name'])->map(fn ($row) => ['sno' => (int) $row->sno,'category_name' => $row->category_name,])->values();
        }
        $vendors = collect();
        if (Schema::hasTable('egc_it_vendor_category')) {
            $vendorColumn = $this->findColumn('egc_it_vendor_category',['vendor_category_name','vendor','category_name','name',]);
            if ($vendorColumn) {
                $vendors = DB::table('egc_it_vendor_category')
                    ->when(Schema::hasColumn('egc_it_vendor_category', 'status'),fn ($q) => $q->where('status', 0))
                    ->whereNotNull($vendorColumn)
                    ->where($vendorColumn, '!=', '')->orderBy($vendorColumn)->get(['sno', $vendorColumn])->map(fn ($row) => ['sno' => (int) $row->sno,'vendor_name' => $row->{$vendorColumn},])->values();
            }
        }
        $locations = collect();
        if (Schema::hasTable('egc_locations')) {
            $locations = DB::table('egc_locations')
                ->when(Schema::hasColumn('egc_locations', 'status'),fn ($q) => $q->where('status', '!=', 2))
                ->whereNotNull('area')->where('area', '!=', '')->orderBy('area')->get(['sno','area',])->map(fn ($row) => ['sno' => (int) $row->sno,'area' => $row->area,])->values();
        }
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $companies = CompanyModel::query()->where('status', 0)->orderBy('company_name', 'ASC')->get(['sno', 'company_name']);
        if ($generalSetting) {
          $companies->prepend((object) [
            'sno' => 0,
            'company_name' => $generalSetting->title ?? '-',
            ]);
            }
        $employees = collect();
        $staffColumn = $this->findColumn('egc_staff',['staff_name','employee_name','name','full_name',]);
        if ($staffColumn) {
            $employees = StaffModel::query()
                ->when(Schema::hasColumn('egc_staff', 'status'),fn ($q) => $q->where('status', 0))
                ->orderBy($staffColumn)->get(['sno',$staffColumn,])->map(fn ($row) => ['sno' => (int) $row->sno,'staff_name' => $row->{$staffColumn},])->values();
        }
        $statuses = collect([
            ['value' => 0,'label' => 'In Stock',],
            ['value' => 1,'label' => 'Assigned',],
            ['value' => 3,'label' => 'Under Repair',],
            ['value' => 4,'label' => 'Retired',],
        ]);
        $warrantyStatuses = collect([
            ['value' => 0,'label' => 'Active',],
            ['value' => 1,'label' => 'Expiring',],
            ['value' => 3,'label' => 'Expired',],
        ]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => [
                'categories' => $categories,
                'vendors' => $vendors,
                'locations' => $locations,
                'companies' => $companies,
                'employees' => $employees,
                'statuses' => $statuses,
                'warranty_statuses' => $warrantyStatuses,
            ],
        ]);
    }
    public function list(Request $request): JsonResponse
    {
        $search = trim((string) $request->input('search', ''));
        $status = $request->input('status', '');
        $warranty = $request->input('warranty_status', '');
        $category = $request->input('category_id', '');
        $perPage = (int) $request->input('perpage', 25);
        $allowedPerPage = [5, 10, 25, 100, 500];
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $query = $this->assetQuery();
        $query->where('asset.status', '!=', self::STATUS_DELETED);
        if ($status !== '' && $status !== 'all' && $status !== null) {
            $query->where('asset.status',(int) $status);
        }
        if ($warranty !== '' &&$warranty !== 'all' &&$warranty !== null &&Schema::hasColumn('egc_it_asset_management', 'warranty_status')) {
            $query->where('asset.warranty_status',(int) $warranty);
        }
        if ($category !== '' &&$category !== 'all' &&$category !== null) {
            $query->where('asset.category_id',(int) $category);
        }
        if ($search !== '') {
            $like = '%' . $search . '%';
            $query->where(function ($q) use ($like) {
                $q->where('asset.make', 'LIKE', $like)
                    ->orWhere('asset.model', 'LIKE', $like)
                    ->orWhere('asset.item_name', 'LIKE', $like)
                    ->orWhere('asset.serial_number', 'LIKE', $like)
                    ->orWhere('company.company_name', 'LIKE', $like);
                if (Schema::hasTable('egc_it_asset_category') &&Schema::hasColumn('egc_it_asset_category', 'category_name')) {
                    $q->orWhere('category.category_name','LIKE',$like);
                }
                if (Schema::hasTable('egc_it_vendor_category')) {
                    $vendorColumn = $this->findColumn('egc_it_vendor_category',['vendor_category_name','vendor','category_name','name',]);
                    if ($vendorColumn) {
                        $q->orWhere("vendor.{$vendorColumn}",'LIKE',$like);
                    }
                }
                if (Schema::hasTable('egc_locations') &&Schema::hasColumn('egc_locations', 'area')) {
                    $q->orWhere('location.area','LIKE',$like);
                }
                if (Schema::hasTable('egc_staff')) {
                    $staffColumn = $this->findColumn('egc_staff',['staff_name','employee_name','name','full_name',]);
                    if ($staffColumn) {
                        $q->orWhere("staff.{$staffColumn}",'LIKE',$like);
                    }
                }
            });
        }
        $assets = $query->orderByDesc('asset.sno')->paginate($perPage);
        $data = collect($assets->items())->map(fn ($asset) => $this->formatAsset($asset))->values();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $data,
            'pagination' => [
                'current_page' => $assets->currentPage(),
                'last_page' => $assets->lastPage(),
                'per_page' => $assets->perPage(),
                'total' => $assets->total(),
                'from' => $assets->firstItem(),
                'to' => $assets->lastItem(),
            ],
        ]);
    }
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make(
            $request->all(),
            [
                'category_id' => ['required','integer','exists:egc_it_asset_category,sno',],
                'status' => ['required','integer','in:0,3,4',],
                'make' => ['required','string','max:150',],
                'model' => ['nullable','string','max:150',],
                'serial_number' => ['required','string','max:150',],
                'vendor_id' => ['nullable','integer','exists:egc_it_vendor_category,sno',],
                'purchase_date' => ['nullable','date',],
                'warranty_until' => ['nullable','date',],
                'location_id' => ['nullable','integer','exists:egc_locations,sno',],
                'company_id' => [
                    'required',
                    'integer',
                    'min:0',
                    function ($attribute, $value, $fail) {
                        if ((int) $value === 0) {
                            return;
                        }
                        if (!DB::table('egc_company')->where('sno', $value)->where('status', 0)->exists()) {
                          $fail('The selected company is invalid.');
                        }
                    },
                ],
            ],
            [
                'category_id.required' => 'Category is required.',
                'status.required' => 'Lifecycle status is required.',
                'make.required' => 'Make is required.',
                'serial_number.required' => 'Serial number is required.',
                'company_id.required' => 'Company is required.',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        try {
            $userId = $request->user()->user_id ?? 1;
            $asset = DB::transaction(function () use ($request,$userId) {
                $asset = new AssetManagementModel();
                $asset->category_id = $request->category_id;
                $asset->status = (int) $request->status;
                $asset->make = trim($request->make);
                $asset->model = trim((string) $request->model);
                $asset->serial_number = trim($request->serial_number);
                $asset->vendor_id =$request->vendor_id ?: null;
                $asset->purchase_date = $this->convertDate($request->purchase_date);
                $asset->warranty_until = $this->convertDate($request->warranty_until);
                $asset->location_id =$request->location_id ?: null;
                $asset->company_id = $request->company_id;
                $asset->item_name = trim($request->make . ' ' . $request->model);
                if (Schema::hasColumn('egc_it_asset_management','warranty_status')) {
                    $asset->warranty_status =$this->calculateWarrantyStatus($request->warranty_until);
                }
                $asset->created_by = $userId;
                $asset->updated_by = $userId;
                $asset->save();
                $this->addHistory(
                    $asset->sno,
                    'Asset registered in Asset Management',
                    $userId
                );
                return $asset;
            });
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Asset registered successfully.',
                'data' => ['asset_id' => (int) $asset->sno,
                'asset_tag' => $this->assetTag($asset),],
            ]);

        } catch (\Throwable $e) {
            Log::error('Asset Registration Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Unable to register asset.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null,
            ], 500);
        }
    }
    public function show(Request $request,$id): JsonResponse
    {   $userId =$request->user()->user_id ?? 1;
        $asset = $this->assetQuery()->where('asset.sno', $id)->first();
        if (!$asset) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Asset not found.',
            ], 404);
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $this->formatAsset($asset),
        ]);
    }
    public function assign(Request $request,$id): JsonResponse {
        $userId =$request->user()->user_id ?? 1;
        $validator = Validator::make(
            $request->all(),
            [
                'employee_id' => ['required','integer','exists:egc_staff,sno',],
                'issue_date' => ['required','date',],
                'acknowledgement_note' => ['nullable','string','max:1000',],
            ],
            [
                'employee_id.required' =>'Employee is required.',
                'issue_date.required' =>'Issue date is required.',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        try {
            DB::transaction(function () use ($id,$request,$userId) {
                $asset = AssetManagementModel::query()->where('sno', $id)->lockForUpdate()->first();
                if (!$asset) {
                    throw new \RuntimeException('Asset not found.');
                }
                if ((int) $asset->status !==self::STATUS_IN_STOCK) {
                    throw new \RuntimeException('Only assets currently In Stock can be assigned.');
                }
                $assignment = new AssignAssetsModel();
                $assignment->assigned_to =$request->employee_id;
                $assignment->assigned_to_id =$request->employee_id;
                $assignment->issue_date = $this->convertDate($request->issue_date);
                $assignment->acknowledgement_note =$request->acknowledgement_note;
                $assignment->created_by =$userId;
                $assignment->updated_by =$userId;
                $assignment->status = 0;
                if (Schema::hasColumn('egc_it_assign_assets','asset_id')) {
                    $assignment->asset_id =$asset->sno;
                }
                $assignment->save();
                $asset->status =self::STATUS_ASSIGNED;
                $asset->updated_by =$userId;
                $asset->save();
                $this->addHistory($asset->sno,'Asset assigned to employee',$userId);
            });
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Asset assigned successfully.',
            ]);
        } catch (\Throwable $e) {
            Log::error('Asset Assignment Error',['asset_id' => $id,'message' => $e->getMessage(),]);
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => $e->getMessage(),
            ], 422);
        }
    }
   public function reclaim(Request $request,$id): JsonResponse
{   $userId =$request->user()->user_id ?? 1;
    try {
        DB::transaction(function () use ($id,$userId) {
            $asset = AssetManagementModel::where('sno', $id)->lockForUpdate()->firstOrFail();
            if ((int) $asset->status !== self::STATUS_ASSIGNED) {
                throw new \RuntimeException(
                    'Only assigned assets can be reclaimed.'
                );
            }
            // Return the asset to In Stock.
            $asset->status = self::STATUS_IN_STOCK;
            $asset->updated_by = $userId;
            $asset->save();
            // Mark the active assignment as Returned.
            if (
                Schema::hasTable('egc_it_assign_assets') &&
                Schema::hasColumn('egc_it_assign_assets', 'asset_id')
            ) {
                DB::table('egc_it_assign_assets')->where('asset_id', $asset->sno)->where('status', 0)
                    ->update(['status' => 1,'updated_by' => $userId,'updated_at' => now(),]);
            }
            $this->addHistory($asset->sno,'Asset reclaimed and returned to stock',$userId);
        });
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Asset reclaimed successfully.',
        ]);
    } catch (\Throwable $e) {
        Log::error('Asset Reclaim Error', [
            'asset_id' => $id,
            'message' => $e->getMessage(),
        ]);

        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => $e->getMessage(),
        ], 422);
    }
}
    public function repair(Request $request, $id): JsonResponse
    {
        return $this->simpleStatusChange($request,$id,self::STATUS_REPAIR,'Asset marked under repair successfully.');
    }
    public function retire(Request $request, $id): JsonResponse
    {
        return $this->simpleStatusChange($request,$id,self::STATUS_RETIRED,'Asset retired successfully.');
    }
    public function Delete(Request $request,$id): JsonResponse
    {   $userId =$request->user()->user_id ?? 1;
        try {
            $asset = AssetManagementModel::query()->where('sno', $id)->first();
            if (!$asset) {
                return response()->json([
                    'success' => false,
                    'status' => 404,
                    'message' => 'Asset not found.',
                ], 404);
            }
            $asset->status =self::STATUS_DELETED;
            $asset->updated_by =$userId;
            $asset->save();
            $this->addHistory($asset->sno,'Asset deleted from Asset Management',$userId);
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Asset deleted successfully.',
            ]);
        } catch (\Throwable $e) {
            Log::error('Asset Delete Error',['asset_id' => $id,'message' => $e->getMessage(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Unable to delete asset.',
            ], 500);
        }
    }
    public function update(Request $request, $id): JsonResponse
{   $userId =$request->user()->user_id ?? 1;
    $validator = Validator::make($request->all(), [
        'category_id' => ['required', 'integer', 'exists:egc_it_asset_category,sno'],
        'status' => ['required', 'integer', 'in:0,1,3,4'],
        'make' => ['required', 'string', 'max:150'],
        'model' => ['nullable', 'string', 'max:150'],
        'serial_number' => ['required', 'string', 'max:150'],
        'vendor_id' => ['nullable', 'integer', 'exists:egc_it_vendor_category,sno'],
        'purchase_date' => ['nullable', 'date'],
        'warranty_until' => ['nullable', 'date'],
        'location_id' => ['nullable', 'integer', 'exists:egc_locations,sno'],
        'company_id' => [
            'required',
            'integer',
            'min:0',
            function ($attribute, $value, $fail) {
                if ((int) $value === 0) {
                    return;
                }
                if (!DB::table('egc_company')->where('sno', $value)->where('status', 0)->exists()) {
                  $fail('The selected company is invalid.');
                }
            },
        ],
    ]);
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Validation failed.',
            'errors' => $validator->errors(),
        ], 422);
    }
    try {
            DB::transaction(function () use ($id, $userId,$request) {
            $asset = AssetManagementModel::where('sno', $id)->lockForUpdate()->first();
            if (!$asset) {
                throw new \RuntimeException('Asset not found.');
            }
            $asset->category_id = $request->category_id;
            $asset->status = (int) $request->status;
            $asset->make = trim($request->make);
            $asset->model = trim((string) $request->model);
            $asset->serial_number = trim($request->serial_number);
            $asset->vendor_id = $request->vendor_id ?: null;
            $asset->purchase_date = $this->convertDate($request->purchase_date);
            $asset->warranty_until = $this->convertDate($request->warranty_until);
            $asset->location_id = $request->location_id ?: null;
            $asset->company_id = $request->company_id;
            $asset->item_name = trim($request->make . ' ' . $request->model);
            if (Schema::hasColumn('egc_it_asset_management','warranty_status')) {
                $asset->warranty_status =$this->calculateWarrantyStatus($asset->warranty_until);
            }
            $asset->updated_by = $userId;
            $asset->save();
            $this->addHistory($asset->sno,'Asset record updated',$userId);
        });
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Asset updated successfully.',
        ]);
    } catch (\Throwable $e) {
        Log::error('Asset Update Error', [
            'asset_id' => $id,
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);
        return response()->json([
            'success' => false,
            'status' => 500,
            'message' => 'Unable to update asset.',
            'error' => config('app.debug') ? $e->getMessage() : null,
        ], 500);
    }
}
    private function assetQuery()
    {
        $query = DB::table('egc_it_asset_management as asset');
        $query->leftJoin('egc_company as company','asset.company_id','=','company.sno');
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $generalCompanyName = $generalSetting->title ?? '-';

        $query->select('asset.*')
            ->addSelect(DB::raw('CASE WHEN asset.company_id = 0 THEN ' . DB::getPdo()->quote($generalCompanyName) . 'ELSE company.company_name END AS company_name'));
        if (Schema::hasTable('egc_it_asset_category') &&Schema::hasColumn('egc_it_asset_category','category_name')) {
            $query->leftJoin('egc_it_asset_category as category','asset.category_id','=','category.sno');
            $query->addSelect('category.category_name');
        }
        if (Schema::hasTable('egc_it_vendor_category')) {
            $vendorColumn = $this->findColumn('egc_it_vendor_category',['vendor_category_name','vendor','category_name','name',]);
            if ($vendorColumn) {
                $query->leftJoin('egc_it_vendor_category as vendor','asset.vendor_id','=','vendor.sno');
                $query->addSelect(DB::raw("vendor.{$vendorColumn} as vendor_name"));
            }
        }
        if (Schema::hasTable('egc_locations') &&Schema::hasColumn('egc_locations','area')) {
            $query->leftJoin('egc_locations as location','asset.location_id','=','location.sno');
            $query->addSelect('location.area');
        }
       if (Schema::hasTable('egc_it_assign_assets') && Schema::hasColumn('egc_it_assign_assets', 'asset_id')) {
            $query->leftJoin('egc_it_assign_assets as assignment',function ($join) {
              $join->on('assignment.asset_id', '=', 'asset.sno')->where('assignment.status', 0);
              });
            $query->addSelect(['assignment.assigned_to', 'assignment.assigned_to_id', 'assignment.issue_date', 'assignment.acknowledgement_note',]);
        if (Schema::hasTable('egc_staff')) {
            $staffColumn = $this->findColumn('egc_staff',['staff_name', 'employee_name', 'name', 'full_name']);
            if ($staffColumn) {
                $query->leftJoin('egc_staff as staff', 'assignment.assigned_to_id', '=', 'staff.sno');
                $query->addSelect(
                    DB::raw("staff.{$staffColumn} as assigned_name")
                );
            }
        }
    }
        return $query;
    }
    private function formatAsset($asset): array
    {
        $warrantyStatus =isset($asset->warranty_status)? (int) $asset->warranty_status: $this->calculateWarrantyStatus($asset->warranty_until ?? null);
        return [
            'sno' => (int) $asset->sno,
            'asset_tag' =>$this->assetTag($asset),
            'item_name' =>$asset->item_name ??trim(($asset->make ?? '') .' ' .($asset->model ?? '')),
            'category_id' =>isset($asset->category_id)? (int) $asset->category_id: null,
            'category_name' =>$asset->category_name ?? '-',
            'status' =>(int) ($asset->status ?? 0),
            'status_text' =>$this->statusText($asset->status ?? 0),
            'warranty_status' =>$warrantyStatus,
            'warranty_status_text' =>$this->warrantyStatusText($warrantyStatus),
            'make' =>$asset->make ?? '',
            'model' => $asset->model ?? '',
            'serial_number' =>$asset->serial_number ?? '',
            'vendor_id' =>isset($asset->vendor_id)? (int) $asset->vendor_id: null,
            'vendor_name' =>$asset->vendor_name ?? '-',
            'location_id' =>isset($asset->location_id)? (int) $asset->location_id: null,
            'area' =>$asset->area ?? '-',
            'company_id' =>isset($asset->company_id)? (int) $asset->company_id: null,
            'company_name' =>$asset->company_name ?? '-',
            'assigned_to' =>$asset->assigned_name ?? null,
            'assigned_to_id' =>isset($asset->assigned_to_id)? (int) $asset->assigned_to_id: null,
            'purchase_date' =>$this->formatDate($asset->purchase_date ?? null),
            'warranty_until' =>$this->formatDate($asset->warranty_until ?? null),
            'issue_date' =>$this->formatDate($asset->issue_date ?? null),
            'acknowledgement_note' =>$asset->acknowledgement_note ?? '',
            'history' =>$this->history($asset->sno),
        ];
    }
    private function history($assetId)
    {
        if (!Schema::hasTable('egc_asset_history')) {
            return [];
        }
        $query = DB::table('egc_asset_history')->where('asset_id',$assetId)->orderByDesc('sno');
        $staffColumn = $this->findColumn('egc_staff',['staff_name','employee_name','name','full_name',]);
        if ($staffColumn &&Schema::hasColumn('egc_asset_history','created_by')) {
            $query->leftJoin('egc_staff as history_staff','egc_asset_history.created_by','=','history_staff.sno');
            $query->addSelect('egc_asset_history.*',DB::raw("history_staff.{$staffColumn} as actor_name"));
        } else {
            $query->select('egc_asset_history.*');
        }
        return $query->limit(50)->get()->map(function ($row) {
                return [
                    'id' => $row->sno ?? null,
                    'description' =>$row->description ??$row->action ??'Asset history updated',
                    'actor_name' =>$row->actor_name ??'System',
                    'created_at' =>$this->formatDateTime($row->created_at ?? null),
                ];
            })->values();
    }
      private function addHistory(int $assetId, string $description, int $userId): void {
        if (!Schema::hasTable('egc_asset_history')) {
            return;
        }
        $data = ['asset_id' => $assetId,'description' => $description,];
        if (Schema::hasColumn('egc_asset_history','created_by')) {
            $data['created_by'] = $userId;
        }
        if (Schema::hasColumn('egc_asset_history','created_at')) {
            $data['created_at'] = now();
        }
        if (Schema::hasColumn('egc_asset_history','updated_at')) {
            $data['updated_at'] = now();
        }
        DB::table('egc_asset_history')->insert($data);
    }
   private function simpleStatusChange(Request $request, $id, int $newStatus, string $successMessage): JsonResponse {
          $userId = $request->user()->user_id ?? 1;
          try {
              DB::transaction(function () use ($id, $newStatus, $userId) {
                  $asset = AssetManagementModel::query()->where('sno', $id)->lockForUpdate()->first();
                  if (!$asset) {
                      throw new \RuntimeException('Asset not found.');
                  }
                  $asset->status = $newStatus;
                  $asset->updated_by = $userId;
                  $asset->save();
                  $history = match ($newStatus) {
                      self::STATUS_REPAIR => 'Asset marked under repair',
                      self::STATUS_RETIRED => 'Asset retired',
                      default => 'Asset status updated',
                  };
                  $this->addHistory($asset->sno,$history,$userId);
              });
              return response()->json([
                  'success' => true,
                  'status' => 200,
                  'message' => $successMessage,
              ]);
          } catch (\Throwable $e) {
              Log::error('Asset Status Error', [
                  'asset_id' => $id,
                  'message' => $e->getMessage(),
              ]);
              return response()->json([
                  'success' => false,
                  'status' => 422,
                  'message' => $e->getMessage(),
              ], 422);
          }
      }
    private function assetTag($asset): string
    {
        return 'EG-AST-' .str_pad((string) $asset->sno,4,'0',STR_PAD_LEFT);
    }
    private function statusText($status): string
    {
        return match ((int) $status) {
            0 => 'In Stock',1 => 'Assigned',2 => 'Deleted',3 => 'Under Repair',4 => 'Retired',default => 'Unknown',
        };
    }
    private function warrantyStatusText($status): string {
        return match ((int) $status) {
            0 => 'Active',1 => 'Expiring',3 => 'Expired',default => 'Unknown',
        };
    }
    private function calculateWarrantyStatus($date): int {
        if (!$date) {
            return self::WARRANTY_EXPIRED;
        }
        try {
            $warranty = Carbon::parse($date);
            $today = now()->startOfDay();
            $expiryWindow =now()->addDays(90)->endOfDay();
            if ($warranty->lt($today)) {
                return self::WARRANTY_EXPIRED;
            }
            if ($warranty->lte($expiryWindow)) {
                return self::WARRANTY_EXPIRING;
            }
            return self::WARRANTY_ACTIVE;
        } catch (\Throwable $e) {
            return self::WARRANTY_EXPIRED;
        }
    }
    private function formatDate($date): ?string
    {
        if (!$date) {
            return null;
        }
        try {
            return Carbon::parse($date)->format('d M Y');
        } catch (\Throwable $e) {
            return null;
        }
    }
    private function formatDateTime($date): ?string {
        if (!$date) {
            return null;
        }
        try {
            return Carbon::parse($date)->format('d M Y H:i');
        } catch (\Throwable $e) {
            return null;
        }
    }
    private function findColumn(string $table,array $columns): ?string {
        foreach ($columns as $column) {
            if (Schema::hasColumn($table,$column)) {
                return $column;
            }
        }
        return null;
    }
//Reference: Devops Support
//Private functions encapsulate internal logic within the controller class and are not accessible from external sources. Important aspects of private functions include:
// class BlogController extends Controller {
//     public function index() {
//         $data = $this->fetchBlogData();
//         return view('blog.index', compact('data'));
//     }

//     private function fetchBlogData() {
//         // Logic for fetching blog data
//     }
// }
//9 Date Formats -> ItSolutionStuff
// <?php
// namespace App\Http\Controllers;
// use Illuminate\Http\Request;
// use Carbon\Carbon;
// class DemoController extends Controller
// {
//     /**
//      * Write code on Method
//      *
//      * @return response()
//      */
//     public function index()
//     {
//         $date = date('Y-m-d H:i:s');
//         $newDate = Carbon::createFromFormat('Y-m-d H:i:s', $date)
//                                     ->format('m/d/Y');
//         dd($newDate);
//     }
// }
      private function convertDate($date): ?string
{
    if (empty($date)) {
        return null;
    }
    try {
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return Carbon::createFromFormat('Y-m-d', $date)->format('Y-m-d');
        }
        return Carbon::createFromFormat('d-M-Y', $date)->format('Y-m-d');
    } catch (\Throwable $e) {
        Log::error('Asset Date Conversion Error', ['date' => $date,'error' => $e->getMessage(),]);
        return null;
    }
}
//Reference:
//<?php
// preg_match('/(foo)(bar)(baz)/', 'foobarbaz', $matches, PREG_OFFSET_CAPTURE);
// print_r($matches);
//in this preg_match
// pattern
// The pattern to search for, as a string.
// subject
// The input string.
// matches
// If matches is provided, then it is filled with the results of search. $matches[0] will contain the text that matched the full pattern, $matches[1] will have the text that matched the first captured parenthesized subpattern, and so on.
// flags
// flags can be a combination of the following flags:
    private const STATUS_IN_STOCK = 0;
    private const STATUS_ASSIGNED = 1;
    private const STATUS_DELETED = 2;
    private const STATUS_REPAIR = 3;
    private const STATUS_RETIRED = 4;
    private const WARRANTY_ACTIVE = 0;
    private const WARRANTY_EXPIRING = 1;
    private const WARRANTY_EXPIRED = 3;
}
