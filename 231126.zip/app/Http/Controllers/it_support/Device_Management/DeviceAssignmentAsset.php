<?php
namespace App\Http\Controllers\it_support\Device_Management;
use App\Http\Controllers\Controller;
use App\Models\AssignAssetsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Throwable;

class DeviceAssignmentAsset extends Controller
{
    private string $assetTable = 'egc_it_asset_management';
    private string $staffTable = 'egc_staff';
    public function index()
    {
        return view('content.it_support.device_assignment.device_assignment');
    }
    public function masters()
    {
        try {
            $employees = DB::table($this->staffTable)->select('sno', 'staff_name')->orderBy('staff_name')->get();
            $assetsQuery = DB::table($this->assetTable . ' as a')->where('a.status', 0);
            $assets = $assetsQuery->select('a.*')->orderBy('a.sno', 'desc')->get()
                ->map(function ($asset) {
                    return ['sno' => $asset->sno,'asset_tag' => $asset->asset_tag ?? ('AST-' . $asset->sno),'item_name' => $asset->item_name?? $asset->model?? 'Asset #' . $asset->sno,'company_name' => $asset->company_name ?? '',];
                });
            return response()->json([
                'success' => true,
                'data' => ['employees' => $employees,'assets' => $assets,'in_stock_count' => $assets->count(),
                ],
            ]);
        } catch (\Throwable $e) {
    \Log::error('Device Assignment dropdown error', ['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),
    ]);
    return response()->json([
        'success' => false,
        'message' => 'Unable to load assignment dropdowns.',
    ], 500);
}
    }
    public function list(Request $request)
{
    try {
        $query = DB::table('egc_it_assign_assets as aa')
            ->join('egc_it_asset_management as a','a.sno','=','aa.asset_id')
            ->leftJoin('egc_staff as s','s.sno','=','aa.assigned_to_id')
            ->select([
                'aa.sno as assignment_id',
                'aa.asset_id',
                'aa.assigned_to_id',
                'aa.assigned_to',
                'aa.issue_date',
                'aa.acknowledgement_note',
                'aa.status as assignment_status',
                'a.item_name',
                'a.asset_tag',
                'a.category_id',
                'a.make',
                'a.model',
                's.staff_name',
            ])->where('aa.status', '!=', 2);
        if ($request->filled('search')) {
            $search = trim($request->input('search'));
            $query->where(function ($q) use ($search) {
                $q->where('a.item_name', 'like', "%{$search}%")
                    ->orWhere('a.make', 'like', "%{$search}%")
                    ->orWhere('a.model', 'like', "%{$search}%")
                    ->orWhere('a.asset_tag', 'like', "%{$search}%")
                    ->orWhere('s.staff_name', 'like', "%{$search}%")
                    ->orWhere('aa.assigned_to', 'like', "%{$search}%");
            });
        }
        $employeeId = $request->input('employee_id',$request->input('employee'));
        if ($employeeId !== null && $employeeId !== '') {
            $query->where('aa.assigned_to_id', $employeeId);
        }
        if (
            $request->filled('status') &&
            in_array((string) $request->input('status'), ['0', '1'], true)
        ) {
            $query->where(
                'aa.status',
                (int) $request->input('status')
            );
        }
        $perPage = (int) $request->input('perpage', 25);
        $allowedPerPage = [5, 10, 25, 100, 500];
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $assignments = $query->orderByDesc('aa.sno')->paginate($perPage);
        $assignments->getCollection()->transform(
            function ($assignment) {
                $assignment->device_name =$assignment->item_name?: trim(($assignment->make ?? '') . ' ' .($assignment->model ?? ''))?: 'Unknown device';
                  $assignment->formatted_issue_date = !empty($assignment->issue_date)? \Carbon\Carbon::parse($assignment->issue_date)->format('d M Y'): '—';
                $assignment->employee_name =
                $assignment->staff_name?: (!empty($assignment->assigned_to) &&!is_numeric($assignment->assigned_to)? $assignment->assigned_to: 'Unknown employee');
                $assignment->formatted_issue_date = '—';
                if (!empty($assignment->issue_date)) {
                    try {
                        $assignment->formatted_issue_date =Carbon::parse($assignment->issue_date)->format('d M Y');
                    } catch (\Throwable $e) {
                        $assignment->formatted_issue_date = '—';
                    }
                }
                $assignment->category_name =$assignment->category_id !== null? 'Category ' . $assignment->category_id: '—';
                $assignment->assignment_status_text =
                    match ((int) $assignment->assignment_status) {
                        0 => 'Active',
                        1 => 'Returned',
                        2 => 'Deleted',
                        default => 'Unknown',
                    };
                return $assignment;
            }
        );
        if ($request->ajax() || $request->expectsJson()) {
            return response()->json([
                'success' => true,
                'data' => $assignments->items(),
                'pagination' => [
                    'current_page' => $assignments->currentPage(),
                    'last_page' => $assignments->lastPage(),
                    'per_page' => $assignments->perPage(),
                    'total' => $assignments->total(),
                    'from' => $assignments->firstItem(),
                    'to' => $assignments->lastItem(),
                ],
            ]);
        }
        return view(
            'content.it_support.device_assignment.device_assignment',
            ['assignments' => $assignments]
        );
    } catch (\Throwable $e) {
        Log::error('Device assignment list failed', [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);
        if ($request->ajax() || $request->expectsJson()) {
            return response()->json([
                'success' => false,
                'message' => 'Unable to load device assignments. Check the Laravel log.',
            ], 500);
        }
        return back()->with(
            'error',
            'Unable to load device assignments.'
        );
    }
}
    public function store(Request $request)
{
    $validator = Validator::make($request->all(), [
        'employee_id' => 'required|integer',
        'asset_id' => 'required|integer',
        'issue_date' => 'required|date',
        'acknowledgement_note' => 'nullable|string|max:255',
    ]);
    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'message' => 'Please check the assignment details.',
            'errors' => $validator->errors(),
        ], 422);
    }
    try {
        $userId = $request->user()->userId ?? 1;
        $result = DB::transaction(function () use ($userId,$request) {
            $employee = DB::table('egc_staff')->where('sno', $request->employee_id)->first();
            if (!$employee) {
                throw new \RuntimeException('Selected employee was not found.');
            }
            $asset = DB::table('egc_it_asset_management')->where('sno', $request->asset_id)->lockForUpdate()->first();
            if (!$asset) {
                throw new \RuntimeException('Selected asset was not found.');
            }
            if ((int) $asset->status !== 0) {
                throw new \RuntimeException(
                    'Only in-stock assets can be assigned.'
                );
            }

            $assignment = AssignAssetsModel::create([
                'assigned_to' => $employee->staff_name,
                'assigned_to_id' => $employee->sno,
                'asset_id' => $asset->sno,
                'issue_date' => $request->issue_date,
                'acknowledgement_note' =>
                    $request->acknowledgement_note,
                'created_by' => $userId,
                'updated_by' => $userId,
                'status' => 0,
            ]);
            DB::table('egc_it_asset_management')->where('sno', $asset->sno)->update(['status' => 1,]);
            return $assignment;
        });
        return response()->json([
            'success' => true,
            'message' => 'Device assigned successfully.',
            'data' => $result,
        ]);
    } catch (\Throwable $e) {
        Log::error('Device assignment failed', [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'employee_id' => $request->employee_id,
            'asset_id' => $request->asset_id,
        ]);
        if ($e instanceof \RuntimeException) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
        if ($e instanceof \Symfony\Component\HttpKernel\Exception\HttpException) {
            throw $e;
        }
        return response()->json([
            'success' => false,
            'message' => 'Unable to assign device. Check the Laravel log.',
        ], 500);
    }
}
    public function show($id)
{
$assignment = AssignAssetsModel::where('sno', $id)->where('status', '!=', 2)->firstOrFail();
$asset = DB::table($this->assetTable)->where('sno', $assignment->asset_id)->first();
$employeeId = $assignment->assigned_to_id;
if (empty($employeeId) && is_numeric($assignment->assigned_to)) {
    $employeeId = (int) $assignment->assigned_to;
}
$employee = $employeeId? DB::table($this->staffTable)->where('sno', $employeeId)->first(): null;
$employeeName = $employee->staff_name?? (!is_numeric($assignment->assigned_to)? $assignment->assigned_to: null);
return response()->json([
    'success' => true,
    'data' => [
        'assignment' => $assignment,
        'asset' => $asset,
        'asset_id' => $assignment->asset_id,
        'employee_id' => $employee?->sno ?? $employeeId,
        'employee_name' => $employeeName,
        'assigned_to_name' => $employeeName,
        'assigned_to' => $employeeName,
        'issue_date' => $assignment->issue_date,
        'acknowledgement_note' => $assignment->acknowledgement_note,
        'status' => (int) $assignment->status,
    ],
]);

}
    public function update(Request $request, $id)
    {   $userId = $request->user()->userId ?? 1;
        $validated = $request->validate([
            'employee_id' => ['required', 'integer'],
            'issue_date' => ['required', 'date'],
            'acknowledgement_note' => ['nullable', 'string', 'max:2000'],
        ]);
        try {
            DB::transaction(function () use ($validated,$userId, $id) {
                $assignment = AssignAssetsModel::where('sno', $id)->lockForUpdate()->firstOrFail();
                if ((int) $assignment->status !== 0) {
                    throw ValidationException::withMessages([
                        'status' => 'Only active assignments can be edited.',
                    ]);
                }
                $employee = DB::table($this->staffTable)->where('sno', $validated['employee_id'])->first();
                if (!$employee) {
                    throw ValidationException::withMessages([
                        'employee_id' => 'Selected employee was not found.',
                    ]);
                }
                $assignment->update(['assigned_to' => $employee->staff_name,'assigned_to_id' => $employee->sno,'issue_date' => $validated['issue_date'],'acknowledgement_note' =>$validated['acknowledgement_note'] ?? null,'updated_by' => $userId,]);
            });
            return response()->json([
                'success' => true,
                'message' => 'Assignment updated successfully.',
            ]);
        } catch (ValidationException $e) {
            throw $e;
        } catch (Throwable $e) {
            report($e);
            return response()->json([
                'success' => false,
                'message' => 'Unable to update assignment.',
            ], 500);
        }
    }
    public function reclaim(Request $request,$id)
{   $userId = $request->user()->userId ?? 1;
    try {
        DB::transaction(function () use ($id,$userId) {
            $assignment = AssignAssetsModel::where('sno', $id)->lockForUpdate()->firstOrFail();
            if ((int) $assignment->status !== 0) {
                throw ValidationException::withMessages([
                    'status' => 'This assignment has already been returned.',
                ]);
            }
            $asset = DB::table($this->assetTable)->where('sno', $assignment->asset_id)->lockForUpdate()->first();
            if (!$asset) {
                throw ValidationException::withMessages([
                    'asset_id' => 'The associated asset was not found.',
                ]);
            }
            DB::table($this->assetTable)->where('sno', $assignment->asset_id)->update(['status' => 0,'updated_by' => $userId,'updated_at' => now(),]);
            $assignment->update([
                'status' => 1,
                'updated_by' => $userId,
                'updated_at' => now(),
            ]);
        });
        return response()->json([
            'success' => true,
            'message' => 'Device reclaimed successfully. Status changed to Returned.',
        ]);
    } catch (ValidationException $e) {
        return response()->json([
            'success' => false,
            'message' => $e->getMessage(),
            'errors' => $e->errors(),
        ], 422);
    } catch (Throwable $e) {
        Log::error('Device reclaim failed', [
            'assignment_id' => $id,
            'message' => $e->getMessage(),
        ]);
        return response()->json([
            'success' => false,
            'message' => 'Unable to reclaim device.',
        ], 500);
    }
}
    public function Delete(Request $request,$id)
    {  $userId = $request->user()->userId ?? 1;
        try {
            DB::transaction(function () use ($id,$userId) {
                $assignment = AssignAssetsModel::where('sno', $id)->lockForUpdate()->firstOrFail();
                if ((int) $assignment->status === 0) {
                    DB::table($this->assetTable)->where('sno', $assignment->asset_id)->update(['status' => 0,]);
                }
                $assignment->update([
                    'status' => 2,
                    'updated_by' => $userId,
                ]);
            });
            return response()->json([
                'success' => true,
                'message' => 'Assignment deleted successfully.',
            ]);
        } catch (Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to delete assignment.',
            ], 500);
        }
    }
public function updateStatus(Request $request, $id)
{   $userId = $request->user()->userId ?? 1;
    $validated = $request->validate(['status' => ['required', 'integer', 'in:0,1'],]);
    try {
        DB::transaction(function () use ($validated, $userId,$id) {
            $assignment = AssignAssetsModel::where('sno', $id)->lockForUpdate()->firstOrFail();
            if ((int) $assignment->status === 2) {
                throw ValidationException::withMessages([
                    'status' => 'Deleted assignments cannot be changed.',
                ]);
            }
            $newStatus = (int) $validated['status'];
            $oldStatus = (int) $assignment->status;
            if ($newStatus === $oldStatus) {
                return;
            }
            $asset = DB::table($this->assetTable)->where('sno', $assignment->asset_id)->lockForUpdate()->first();
            if (!$asset) {
                throw ValidationException::withMessages([
                    'status' => 'The associated asset was not found.',
                ]);
            }
            $assetStatus = (int) $asset->status;
            if (!in_array($assetStatus, [0, 1], true)) {
                throw ValidationException::withMessages([
                    'status' => 'The asset must be In Stock or Assigned.',
                ]);
            }
            $newAssetStatus = $newStatus === 0 ? 1 : 0;
            DB::table($this->assetTable)->where('sno', $assignment->asset_id)->update(['status' => $newAssetStatus,'updated_by' => $userId,'updated_at' => now(),]);
            $assignment->update([
                'status' => $newStatus,
                'updated_by' => $userId,
                'updated_at' => now(),
            ]);
        });
        return response()->json([
            'success' => true,
            'message' => 'Assignment status updated successfully.',
        ]);
    } catch (ValidationException $e) {
        return response()->json([
            'success' => false,
            'message' => $e->getMessage(),
            'errors' => $e->errors(),
        ], 422);
    } catch (\Throwable $e) {
        Log::error('Assignment status update failed', [
            'assignment_id' => $id,
            'message' => $e->getMessage(),
        ]);
        return response()->json([
            'success' => false,
            'message' => 'Unable to update assignment status.',
        ], 500);
    }
}
}
